import unittest
from ModifierWrapper import ModifierWrapper


class TestIsVolatile(unittest.TestCase):
    """Test case for java.lang.reflect.Modifier.isVolatile()"""

    def test_isVolatile_test_8980(self):
        """Test isVolatile with value 8"""
        # Test that isVolatile(8) returns False
        result = ModifierWrapper.isVolatile(8)
        self.assertFalse(result, f"'{result}' != 'False'")


if __name__ == '__main__':
    unittest.main()