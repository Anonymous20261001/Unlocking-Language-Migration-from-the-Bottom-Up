import unittest

class ModifierWrapper:
    @staticmethod
    def isInterface(mod):
        return (mod & 0x0200) != 0

    @staticmethod
    def classModifiers():
        return 0x3107

    @staticmethod
    def isFinal(mod):
        return (mod & 0x0010) != 0

    @staticmethod
    def isPublic(mod):
        return (mod & 0x0001) != 0

    @staticmethod
    def isStatic(mod):
        return (mod & 0x0008) != 0

    @staticmethod
    def isProtected(mod):
        return (mod & 0x0004) != 0

    @staticmethod
    def methodModifiers():
        return 0x30DF

    @staticmethod
    def constructorModifiers():
        return 0x3007

    @staticmethod
    def isAbstract(mod):
        return (mod & 0x0400) != 0

    @staticmethod
    def isVolatile(mod):
        return (mod & 0x0040) != 0

    @staticmethod
    def isPrivate(mod):
        return (mod & 0x0002) != 0

    @staticmethod
    def isNative(mod):
        return (mod & 0x0100) != 0

    @staticmethod
    def isSynchronized(mod):
        return (mod & 0x0020) != 0

    @staticmethod
    def isTransient(mod):
        return (mod & 0x0080) != 0

    @staticmethod
    def isStrict(mod):
        return (mod & 0x0800) != 0

    @staticmethod
    def interfaceModifiers():
        return 0x2607

    @staticmethod
    def fieldModifiers():
        return 0x00DF

    @staticmethod
    def parameterModifiers():
        return 0x3010


class TestModifierWrapper(unittest.TestCase):
    
    def test_isPublic_test_8974(self):
        """Test isPublic with modifier value 1 (which is PUBLIC)"""
        # Test with modifier value 1 (PUBLIC flag)
        boolean1 = ModifierWrapper.isPublic(1)
        # Assert that isPublic(1) returns True
        self.assertTrue(boolean1, f"'{boolean1}' != 'True'")
        self.assertEqual(boolean1, True, f"'{boolean1}' != 'True'")


if __name__ == '__main__':
    unittest.main()