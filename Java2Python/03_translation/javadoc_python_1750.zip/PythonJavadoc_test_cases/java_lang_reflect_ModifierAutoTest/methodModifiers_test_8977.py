import unittest
from ModifierWrapper import ModifierWrapper

class TestMethodModifiers(unittest.TestCase):
    
    def test_methodModifiers_test_8977(self):
        """Randoop-generated regression test for ModifierWrapper.methodModifiers()."""
        result = ModifierWrapper.methodModifiers()
        self.assertTrue(f"'{result}' != '3391'", result == 3391)

if __name__ == '__main__':
    unittest.main()