import unittest
from ModifierWrapper import ModifierWrapper


class TestIsSynchronized(unittest.TestCase):
    """Test case for java.lang.reflect.Modifier.isSynchronized()"""

    def test_isSynchronized_test_8983(self):
        """Test isSynchronized with value 4"""
        # Test with value 4 (which is 0x0004, representing protected modifier)
        result = ModifierWrapper.isSynchronized(4)
        self.assertFalse(result, f"'{result}' != 'False'")


if __name__ == '__main__':
    unittest.main()