import unittest
from ModifierWrapper import ModifierWrapper


class TestClassModifiers(unittest.TestCase):
    
    def test_classModifiers_test_8972(self):
        """Test that classModifiers() returns the expected value 3103"""
        result = ModifierWrapper.classModifiers()
        self.assertEqual(result, 3103, f"'{result}' != '3103'")


if __name__ == '__main__':
    unittest.main()