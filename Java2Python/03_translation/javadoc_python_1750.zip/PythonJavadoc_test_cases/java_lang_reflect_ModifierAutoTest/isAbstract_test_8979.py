import unittest
from ModifierWrapper import ModifierWrapper


class TestIsAbstract(unittest.TestCase):
    """Test case for java.lang.reflect.Modifier.isAbstract()"""

    def test_isAbstract_test_8979(self):
        """Test isAbstract with value 2"""
        # Test that isAbstract(2) returns False
        result = ModifierWrapper.isAbstract(2)
        self.assertFalse(result, f"'{result}' != 'False'")


if __name__ == '__main__':
    unittest.main()