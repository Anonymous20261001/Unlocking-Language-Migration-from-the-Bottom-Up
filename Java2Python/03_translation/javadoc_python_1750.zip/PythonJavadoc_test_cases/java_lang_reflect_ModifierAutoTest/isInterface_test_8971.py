import unittest
from ModifierWrapper import ModifierWrapper


class TestIsInterface(unittest.TestCase):
    """Test case for java.lang.reflect.Modifier.isInterface()"""

    def test_isInterface_test_8971(self):
        """Test isInterface with value 512 (0x200) which should return True"""
        # Test with value 512 (0x200) which has the interface bit set
        result = ModifierWrapper.isInterface(512)
        self.assertTrue(result, f"'{result}' != 'True'")


if __name__ == '__main__':
    unittest.main()