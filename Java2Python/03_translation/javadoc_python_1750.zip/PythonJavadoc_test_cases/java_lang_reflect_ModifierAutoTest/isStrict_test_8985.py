import unittest
from ModifierWrapper import ModifierWrapper


class TestIsStrict(unittest.TestCase):
    """Test case for isStrict method"""

    def test_isStrict_test_8985(self):
        """Test isStrict with value 4"""
        # Test that isStrict(4) returns False
        result = ModifierWrapper.isStrict(4)
        self.assertFalse(result, f"isStrict(4) should return False, but got {result}")


if __name__ == '__main__':
    unittest.main()