import unittest

class Byte:
    def __init__(self, value):
        if isinstance(value, str):
            self.value = int(value)
        else:
            self.value = value & 0xFF
        if self.value > 127:
            self.value -= 256

    @staticmethod
    def compareUnsigned(p0, p1):
        return (p0 & 0xFF) - (p1 & 0xFF)

    def compareTo(self, p0):
        return self.value - p0

    @staticmethod
    def compare(p0, p1):
        return p0 - p1

    def byteValue(self):
        return self.value

    def shortValue(self):
        return self.value

    def intValue(self):
        return self.value

    def longValue(self):
        return self.value

    def floatValue(self):
        return float(self.value)

    def doubleValue(self):
        return float(self.value)

    @staticmethod
    def valueOf(p0, p1=None):
        if p1 is None:
            if isinstance(p0, str):
                return Byte(int(p0))
            return Byte(p0)
        return Byte(int(p0, p1))

    @staticmethod
    def decode(p0):
        if p0.startswith("0x") or p0.startswith("0X"):
            return Byte(int(p0, 16))
        elif p0.startswith("0") and len(p0) > 1:
            return Byte(int(p0, 8))
        else:
            return Byte(int(p0))

    def describeConstable(self):
        return self.value

    @staticmethod
    def toUnsignedLong(p0):
        return p0 & 0xFF

    @staticmethod
    def toUnsignedInt(p0):
        return p0 & 0xFF

    @staticmethod
    def parseByte(p0, p1=None):
        if p1 is None:
            return Byte(int(p0))
        return Byte(int(p0, p1))


class TestJavaLangByteAutoTest(unittest.TestCase):
    """Test class for java.lang.Byte.parseByte()"""

    def test_parseByte_test_1984(self):
        """Randoop-generated regression test for java.lang.Byte.parseByte()."""
        # Parse "81" in base 9, which equals 73 in decimal
        byte2 = Byte.parseByte("81", 9)
        
        # Assert that the parsed value equals 73
        self.assertTrue(byte2.value == 73, 
                       f"'{byte2.value}' != '{73}'")
        
        # Additional check to match the Java assertion exactly
        self.assertEqual(byte2.value, 73, 
                        f"'{byte2.value}' != '{73}'")


if __name__ == '__main__':
    unittest.main()