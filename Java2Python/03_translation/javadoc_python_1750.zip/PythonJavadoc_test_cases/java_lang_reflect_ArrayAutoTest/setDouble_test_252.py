import unittest
from typing import Any

class ArrayWrapper:
    def get(self, array: Any, index: int) -> Any:
        return array[index]

    def getLength(self, array: Any) -> int:
        return len(array)

    def getBoolean(self, array: Any, index: int) -> bool:
        return bool(array[index])

    def getByte(self, array: Any, index: int) -> int:
        return array[index]

    def getShort(self, array: Any, index: int) -> int:
        return array[index]

    def getChar(self, array: Any, index: int) -> str:
        return array[index]

    def getInt(self, array: Any, index: int) -> int:
        return array[index]

    def getLong(self, array: Any, index: int) -> int:
        return array[index]

    def getFloat(self, array: Any, index: int) -> float:
        return float(array[index])

    def getDouble(self, array: Any, index: int) -> float:
        return float(array[index])

    def newInstance(self, component_type: type, dimensions: Any) -> Any:
        if isinstance(dimensions, int):
            return [None] * dimensions
        else:
            # Multi-dimensional array creation
            result = []
            for _ in range(dimensions[0]):
                inner = []
                for _ in range(dimensions[1]):
                    inner.append(None)
                result.append(inner)
            return result

    def set(self, array: Any, index: int, value: Any) -> None:
        array[index] = value

    def setBoolean(self, array: Any, index: int, value: bool) -> None:
        array[index] = value

    def setByte(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setChar(self, array: Any, index: int, value: str) -> None:
        array[index] = value

    def setShort(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setInt(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setLong(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setFloat(self, array: Any, index: int, value: float) -> None:
        array[index] = value

    def setDouble(self, array: Any, index: int, value: float) -> None:
        array[index] = value


class TestSetDoubleTest252(unittest.TestCase):
    def test_setDouble_test_252(self):
        # Create an object instance
        obj0 = object()
        
        # Get the class of the object (in Python, we use type())
        wildcard_class1 = type(obj0)
        
        # Verify the object is not None
        self.assertIsNotNone(wildcard_class1)
        
        # Create ArrayWrapper instance
        wrapper = ArrayWrapper()
        
        # Test that setting a double on a non-array raises an exception
        with self.assertRaises(TypeError):
            # In Python, trying to set an attribute on a type object will raise TypeError
            # This simulates the IllegalArgumentException from Java
            wrapper.setDouble(wildcard_class1, 10, 100.0)
        
        # Verify the class object is still valid
        self.assertIsNotNone(wildcard_class1)

if __name__ == '__main__':
    unittest.main()