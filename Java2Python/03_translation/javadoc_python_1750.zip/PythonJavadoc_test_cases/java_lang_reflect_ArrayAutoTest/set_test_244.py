import unittest
from typing import Any

class ArrayWrapper:
    def get(self, array: Any, index: int) -> Any:
        return array[index]

    def getLength(self, array: Any) -> int:
        return len(array)

    def getBoolean(self, array: Any, index: int) -> bool:
        return bool(array[index])

    def getByte(self, array: Any, index: int) -> int:
        return array[index]

    def getShort(self, array: Any, index: int) -> int:
        return array[index]

    def getChar(self, array: Any, index: int) -> str:
        return array[index]

    def getInt(self, array: Any, index: int) -> int:
        return array[index]

    def getLong(self, array: Any, index: int) -> int:
        return array[index]

    def getFloat(self, array: Any, index: int) -> float:
        return float(array[index])

    def getDouble(self, array: Any, index: int) -> float:
        return float(array[index])

    def newInstance(self, component_type: type, dimensions: Any) -> Any:
        if isinstance(dimensions, int):
            return [None] * dimensions
        else:
            # Multi-dimensional array creation
            result = []
            for _ in range(dimensions[0]):
                inner = []
                for _ in range(dimensions[1]):
                    inner.append(None)
                result.append(inner)
            return result

    def set(self, array: Any, index: int, value: Any) -> None:
        array[index] = value

    def setBoolean(self, array: Any, index: int, value: bool) -> None:
        array[index] = value

    def setByte(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setChar(self, array: Any, index: int, value: str) -> None:
        array[index] = value

    def setShort(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setInt(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setLong(self, array: Any, index: int, value: int) -> None:
        array[index] = value

    def setFloat(self, array: Any, index: int, value: float) -> None:
        array[index] = value

    def setDouble(self, array: Any, index: int, value: float) -> None:
        array[index] = value


class java_lang_reflect_ArrayAutoTest(unittest.TestCase):
    
    def test_set_test_244(self):
        """Test that setting a value on a non-array object raises an exception"""
        wrapper = ArrayWrapper()
        
        # Test that setting a value on a non-array (float) raises an exception
        with self.assertRaises(TypeError):
            wrapper.set(10.0, 100, 1)
        
        # Also test with the specific value from the Java test
        with self.assertRaises(TypeError):
            wrapper.set(10.0, 100, 1)


if __name__ == '__main__':
    unittest.main()