import unittest
import math

class CubicCurve2D:
    """Wrapper class for CubicCurve2D static methods"""
    
    @staticmethod
    def getFlatnessSq(*args):
        """Calculate flatness squared of a cubic curve"""
        if len(args) == 8:
            # 8 double parameters
            x0, y0, x1, y1, x2, y2, x3, y3 = args
            # Calculate flatness squared using control point distances
            dx1 = x1 - x0
            dy1 = y1 - y0
            dx2 = x2 - x1
            dy2 = y2 - y1
            dx3 = x3 - x2
            dy3 = y3 - y2
            return max(dx1*dx1 + dy1*dy1, dx2*dx2 + dy2*dy2, dx3*dx3 + dy3*dy3)
        elif len(args) == 2:
            # coords array and offset
            coords, offset = args
            x0, y0 = coords[offset], coords[offset+1]
            x1, y1 = coords[offset+2], coords[offset+3]
            x2, y2 = coords[offset+4], coords[offset+5]
            x3, y3 = coords[offset+6], coords[offset+7]
            dx1 = x1 - x0
            dy1 = y1 - y0
            dx2 = x2 - x1
            dy2 = y2 - y1
            dx3 = x3 - x2
            dy3 = y3 - y2
            return max(dx1*dx1 + dy1*dy1, dx2*dx2 + dy2*dy2, dx3*dx3 + dy3*dy3)
        raise ValueError("Invalid arguments")
    
    @staticmethod
    def getFlatness(*args):
        """Calculate flatness of a cubic curve"""
        if len(args) == 8:
            return math.sqrt(CubicCurve2D.getFlatnessSq(*args))
        elif len(args) == 2:
            coords, offset = args
            return math.sqrt(CubicCurve2D.getFlatnessSq(coords, offset))
        raise ValueError("Invalid arguments")
    
    @staticmethod
    def subdivide(*args):
        """Subdivide a cubic curve into two parts"""
        if len(args) == 6:
            # coords array, offset, left array, left offset, right array, right offset
            src, src_off, left, left_off, right, right_off = args
            x0, y0 = src[src_off], src[src_off+1]
            x1, y1 = src[src_off+2], src[src_off+3]
            x2, y2 = src[src_off+4], src[src_off+5]
            x3, y3 = src[src_off+6], src[src_off+7]
            
            # Compute midpoints
            mx1 = (x0 + x1) / 2
            my1 = (y0 + y1) / 2
            mx2 = (x1 + x2) / 2
            my2 = (y1 + y2) / 2
            mx3 = (x2 + x3) / 2
            my3 = (y2 + y3) / 2
            
            # Compute second midpoints
            mmx1 = (mx1 + mx2) / 2
            mmy1 = (my1 + my2) / 2
            mmx2 = (mx2 + mx3) / 2
            mmy2 = (my2 + my3) / 2
            
            # Compute final midpoint
            final_x = (mmx1 + mmx2) / 2
            final_y = (mmy1 + mmy2) / 2
            
            # Fill left curve
            left[left_off] = x0
            left[left_off+1] = y0
            left[left_off+2] = mx1
            left[left_off+3] = my1
            left[left_off+4] = mmx1
            left[left_off+5] = mmy1
            left[left_off+6] = final_x
            left[left_off+7] = final_y
            
            # Fill right curve
            right[right_off] = final_x
            right[right_off+1] = final_y
            right[right_off+2] = mmx2
            right[right_off+3] = mmy2
            right[right_off+4] = mx3
            right[right_off+5] = my3
            right[right_off+6] = x3
            right[right_off+7] = y3
        elif len(args) == 3:
            # curve objects
            src, left, right = args
            # Assume curve objects have getX1, getY1, etc methods
            x0, y0 = src.getX1(), src.getY1()
            x1, y1 = src.getCtrlX1(), src.getCtrlY1()
            x2, y2 = src.getCtrlX2(), src.getCtrlY2()
            x3, y3 = src.getX2(), src.getY2()
            
            # Compute midpoints
            mx1 = (x0 + x1) / 2
            my1 = (y0 + y1) / 2
            mx2 = (x1 + x2) / 2
            my2 = (y1 + y2) / 2
            mx3 = (x2 + x3) / 2
            my3 = (y2 + y3) / 2
            
            # Compute second midpoints
            mmx1 = (mx1 + mx2) / 2
            mmy1 = (my1 + my2) / 2
            mmx2 = (mx2 + mx3) / 2
            mmy2 = (my2 + my3) / 2
            
            # Compute final midpoint
            final_x = (mmx1 + mmx2) / 2
            final_y = (mmy1 + mmy2) / 2
            
            # Set left curve
            left.setCurve(x0, y0, mx1, my1, mmx1, mmy1, final_x, final_y)
            # Set right curve
            right.setCurve(final_x, final_y, mmx2, mmy2, mx3, my3, x3, y3)
        else:
            raise ValueError("Invalid arguments")
    
    @staticmethod
    def solveCubic(*args):
        """Solve cubic equation"""
        if len(args) == 2:
            eqn, res = args
            # Simple placeholder - actual implementation would solve cubic
            # For this test wrapper, just copy the equation to results
            for i in range(min(len(eqn), len(res))):
                res[i] = eqn[i]
            return len(eqn)
        elif len(args) == 1:
            eqn = args[0]
            # Return number of real roots (placeholder)
            return len(eqn)
        raise ValueError("Invalid arguments")

class TestCubicCurve2D(unittest.TestCase):

    def test_solveCubic_test_3132(self):
        # Test with null first array (should raise NullPointerException equivalent)
        doubleArray0 = None
        doubleArray2 = [100.0]  # equivalent to (short) 100 cast to double
        
        # Verify the array is not null before the call
        self.assertIsNotNone(doubleArray2)
        
        # Test that calling solveCubic with None raises an exception
        with self.assertRaises(Exception) as context:
            CubicCurve2D.solveCubic(doubleArray0, doubleArray2)
        
        # Verify the exception message contains information about null
        self.assertIn("null", str(context.exception))
        
        # Verify the array is still intact after the exception
        self.assertIsNotNone(doubleArray2)
        self.assertEqual(doubleArray2, [100.0])
        self.assertAlmostEqual(doubleArray2[0], 100.0, places=15)

if __name__ == '__main__':
    unittest.main()