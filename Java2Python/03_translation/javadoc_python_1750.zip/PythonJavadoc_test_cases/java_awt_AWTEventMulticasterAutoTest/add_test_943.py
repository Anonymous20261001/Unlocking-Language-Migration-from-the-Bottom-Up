import unittest
from typing import Any, Optional
from unittest.mock import MagicMock


class AWTEventMulticaster:
    @staticmethod
    def getListeners(listener: Any, listener_type: Any) -> Any:
        return None

    @staticmethod
    def remove(listener_a: Any, listener_b: Any) -> Any:
        return None

    @staticmethod
    def add(listener_a: Any, listener_b: Any) -> Any:
        return None


class TestAWTEventMulticasterAdd(unittest.TestCase):
    """Randoop-generated regression test for AWTEventMulticaster.add()."""

    def test_add_test_943(self):
        """Test that adding two null listeners returns None."""
        # Create null listeners (simulating Java's null KeyListener)
        key_listener0 = None
        key_listener1 = None
        
        # Call the add method with both null listeners
        key_listener2 = AWTEventMulticaster.add(key_listener0, key_listener1)
        
        # Assert that the result is None
        self.assertIsNone(key_listener2)


if __name__ == '__main__':
    unittest.main()