import unittest
from typing import Any, Optional


class AWTEventMulticaster:
    @staticmethod
    def getListeners(listener: Any, listener_type: Any) -> Any:
        return None

    @staticmethod
    def remove(listener_a: Any, listener_b: Any) -> Any:
        return None

    @staticmethod
    def add(listener_a: Any, listener_b: Any) -> Any:
        return None


class TestAWTEventMulticasterAdd(unittest.TestCase):
    
    def test_add_test_932(self):
        """Test that adding two null listeners returns null"""
        # Arrange
        key_listener_0 = None
        key_listener_1 = None
        
        # Act
        key_listener_2 = AWTEventMulticaster.add(key_listener_0, key_listener_1)
        
        # Assert
        self.assertIsNone(key_listener_2)


if __name__ == '__main__':
    unittest.main()