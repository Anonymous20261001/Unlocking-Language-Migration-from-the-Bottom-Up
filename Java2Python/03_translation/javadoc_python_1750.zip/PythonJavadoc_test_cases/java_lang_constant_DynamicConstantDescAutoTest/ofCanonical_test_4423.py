import unittest
from typing import Optional, List
from unittest.mock import Mock, patch

# Wrapper classes as provided
class DirectMethodHandleDesc:
    """Mock class for DirectMethodHandleDesc"""
    pass


class ClassDesc:
    """Mock class for ClassDesc"""
    pass


class ConstantDesc:
    """Mock class for ConstantDesc"""
    pass


class DynamicConstantDesc:
    """Wrapper class for DynamicConstantDesc"""
    
    @staticmethod
    def of(p0: DirectMethodHandleDesc, p1: Optional[List[ConstantDesc]] = None):
        """Create a DynamicConstantDesc from a DirectMethodHandleDesc and optional ConstantDesc array"""
        if p1 is None:
            return DynamicConstantDesc(p0)
        return DynamicConstantDesc(p0, p1)
    
    @staticmethod
    def ofNamed(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a named DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2)
    
    @staticmethod
    def ofCanonical(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a canonical DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2, canonical=True)
    
    def __init__(self, bootstrap_method, constant_descs=None, name=None, class_desc=None, canonical=False):
        self.bootstrap_method = bootstrap_method
        self.constant_descs = constant_descs or []
        self.name = name
        self.class_desc = class_desc
        self.canonical = canonical


class TestDynamicConstantDescOfCanonical(unittest.TestCase):
    """Test class for DynamicConstantDesc.ofCanonical() method"""
    
    def test_ofCanonical_test_4423(self):
        """Test ofCanonical with null DirectMethodHandleDesc should raise NullPointerException"""
        # Setup test data
        direct_method_handle_desc = None  # null DirectMethodHandleDesc
        class_desc = None  # null ClassDesc
        constant_desc_array = []  # empty ConstantDesc array
        
        # Verify the array is initially empty
        self.assertEqual(len(constant_desc_array), 0)
        
        # Test that calling ofCanonical with null bootstrap method raises NullPointerException
        with self.assertRaises(NullPointerException) as context:
            DynamicConstantDesc.ofCanonical(
                direct_method_handle_desc, 
                "", 
                class_desc, 
                constant_desc_array
            )
        
        # Verify the exception message
        self.assertEqual(str(context.exception), "null")
        
        # Verify the array is still empty after the exception
        self.assertEqual(len(constant_desc_array), 0)
        self.assertEqual(constant_desc_array, [])


# Custom exception class to match Java's NullPointerException
class NullPointerException(Exception):
    """Custom exception to mimic Java's NullPointerException"""
    pass


if __name__ == '__main__':
    unittest.main()