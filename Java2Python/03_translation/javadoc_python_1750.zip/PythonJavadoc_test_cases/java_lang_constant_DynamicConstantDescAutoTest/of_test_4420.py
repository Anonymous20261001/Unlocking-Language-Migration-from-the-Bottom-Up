import unittest
from typing import Optional, List
from unittest.mock import Mock, patch

# === Python Wrapper Class (use these exact methods) ===
class DirectMethodHandleDesc:
    """Mock class for DirectMethodHandleDesc"""
    pass


class ClassDesc:
    """Mock class for ClassDesc"""
    pass


class ConstantDesc:
    """Mock class for ConstantDesc"""
    pass


class DynamicConstantDesc:
    """Wrapper class for DynamicConstantDesc"""
    
    @staticmethod
    def of(p0: DirectMethodHandleDesc, p1: Optional[List[ConstantDesc]] = None):
        """Create a DynamicConstantDesc from a DirectMethodHandleDesc and optional ConstantDesc array"""
        if p1 is None:
            return DynamicConstantDesc(p0)
        return DynamicConstantDesc(p0, p1)
    
    @staticmethod
    def ofNamed(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a named DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2)
    
    @staticmethod
    def ofCanonical(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a canonical DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2, canonical=True)
    
    def __init__(self, bootstrap_method, constant_descs=None, name=None, class_desc=None, canonical=False):
        self.bootstrap_method = bootstrap_method
        self.constant_descs = constant_descs or []
        self.name = name
        self.class_desc = class_desc
        self.canonical = canonical


class TestDynamicConstantDescOf(unittest.TestCase):
    """Randoop-generated regression test for DynamicConstantDesc.of()."""

    def test_of_test_4420(self):
        """Test that of() raises NullPointerException when bootstrap method is null"""
        # Setup
        direct_method_handle_desc_0 = None  # null DirectMethodHandleDesc
        constant_desc_array_1 = []  # empty ConstantDesc array
        
        # Verify the array is empty before the test
        self.assertEqual(len(constant_desc_array_1), 0)
        
        # Test that calling of() with null bootstrap method raises an exception
        with self.assertRaises(Exception) as context:
            DynamicConstantDesc.of(direct_method_handle_desc_0, constant_desc_array_1)
        
        # Verify the exception message matches the Java behavior
        self.assertIn("bootstrapMethod", str(context.exception))
        self.assertIn("null", str(context.exception))
        
        # Verify the array is still intact after the exception
        self.assertIsNotNone(constant_desc_array_1)
        self.assertEqual(constant_desc_array_1, [])


if __name__ == '__main__':
    unittest.main()