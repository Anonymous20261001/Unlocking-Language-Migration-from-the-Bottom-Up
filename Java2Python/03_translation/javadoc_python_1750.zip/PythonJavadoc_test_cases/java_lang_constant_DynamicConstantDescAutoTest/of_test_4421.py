import unittest
from typing import Optional, List
from unittest.mock import Mock, patch

# === Python Wrapper Class (use these exact methods) ===
class DirectMethodHandleDesc:
    """Mock class for DirectMethodHandleDesc"""
    pass


class ClassDesc:
    """Mock class for ClassDesc"""
    pass


class ConstantDesc:
    """Mock class for ConstantDesc"""
    pass


class DynamicConstantDesc:
    """Wrapper class for DynamicConstantDesc"""
    
    @staticmethod
    def of(p0: DirectMethodHandleDesc, p1: Optional[List[ConstantDesc]] = None):
        """Create a DynamicConstantDesc from a DirectMethodHandleDesc and optional ConstantDesc array"""
        if p1 is None:
            return DynamicConstantDesc(p0)
        return DynamicConstantDesc(p0, p1)
    
    @staticmethod
    def ofNamed(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a named DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2)
    
    @staticmethod
    def ofCanonical(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a canonical DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2, canonical=True)
    
    def __init__(self, bootstrap_method, constant_descs=None, name=None, class_desc=None, canonical=False):
        self.bootstrap_method = bootstrap_method
        self.constant_descs = constant_descs or []
        self.name = name
        self.class_desc = class_desc
        self.canonical = canonical


class TestDynamicConstantDescOf(unittest.TestCase):
    """Test class for DynamicConstantDesc.of() method"""
    
    def test_of_test_4421(self):
        """Test that of() raises NullPointerException when bootstrap method is null"""
        # Create null bootstrap method (simulating Java's null)
        direct_method_handle_desc = None
        
        # Test that calling of() with null raises the expected exception
        with self.assertRaises(NullPointerException) as context:
            DynamicConstantDesc.of(direct_method_handle_desc)
        
        # Verify the exception message matches the Java behavior
        self.assertEqual(
            str(context.exception),
            'Cannot invoke "java.lang.constant.DirectMethodHandleDesc.invocationType()" because "bootstrapMethod" is null'
        )


if __name__ == '__main__':
    unittest.main()