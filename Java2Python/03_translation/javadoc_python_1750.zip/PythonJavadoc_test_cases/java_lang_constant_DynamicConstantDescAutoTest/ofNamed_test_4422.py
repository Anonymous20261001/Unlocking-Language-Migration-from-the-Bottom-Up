import unittest
from typing import Optional, List
from unittest.mock import Mock

# === Python Wrapper Class (use these exact methods) ===
class DirectMethodHandleDesc:
    """Mock class for DirectMethodHandleDesc"""
    pass


class ClassDesc:
    """Mock class for ClassDesc"""
    pass


class ConstantDesc:
    """Mock class for ConstantDesc"""
    pass


class DynamicConstantDesc:
    """Wrapper class for DynamicConstantDesc"""
    
    @staticmethod
    def of(p0: DirectMethodHandleDesc, p1: Optional[List[ConstantDesc]] = None):
        """Create a DynamicConstantDesc from a DirectMethodHandleDesc and optional ConstantDesc array"""
        if p1 is None:
            return DynamicConstantDesc(p0)
        return DynamicConstantDesc(p0, p1)
    
    @staticmethod
    def ofNamed(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a named DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2)
    
    @staticmethod
    def ofCanonical(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a canonical DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2, canonical=True)
    
    def __init__(self, bootstrap_method, constant_descs=None, name=None, class_desc=None, canonical=False):
        self.bootstrap_method = bootstrap_method
        self.constant_descs = constant_descs or []
        self.name = name
        self.class_desc = class_desc
        self.canonical = canonical


class TestDynamicConstantDescOfNamed(unittest.TestCase):
    """Test class for DynamicConstantDesc.ofNamed() method"""

    def test_ofNamed_test_4422(self):
        """Randoop-generated regression test for DynamicConstantDesc.ofNamed()"""
        # Setup test data
        direct_method_handle_desc = None  # null DirectMethodHandleDesc
        class_desc = None  # null ClassDesc
        constant_desc_array = []  # empty ConstantDesc array
        
        # Test that calling ofNamed with null arguments raises NullPointerException
        with self.assertRaises(NullPointerException) as context:
            DynamicConstantDesc.ofNamed(
                direct_method_handle_desc, 
                "", 
                class_desc, 
                constant_desc_array
            )
        
        # Verify the exception message
        self.assertEqual(str(context.exception), "null")
        
        # Verify the constant_desc_array is not None and is empty
        self.assertIsNotNone(constant_desc_array)
        self.assertEqual(constant_desc_array, [])


# Define NullPointerException for Python (simulating Java's NPE)
class NullPointerException(Exception):
    """Simulates Java's NullPointerException"""
    pass


if __name__ == '__main__':
    unittest.main()