import unittest
from unittest.mock import patch
from CookieHandler import CookieHandler


class TestGetDefault(unittest.TestCase):
    """Randoop-generated regression test for CookieHandler.getDefault()."""

    def test_get_default_3025(self):
        """Test that getDefault() returns None when no default is set."""
        # Ensure the default is None before the test
        CookieHandler._default = None
        
        # Call getDefault() and verify it returns None
        cookie_handler = CookieHandler.getDefault()
        
        # Assert that the result is None
        self.assertIsNone(cookie_handler)


if __name__ == '__main__':
    unittest.main()