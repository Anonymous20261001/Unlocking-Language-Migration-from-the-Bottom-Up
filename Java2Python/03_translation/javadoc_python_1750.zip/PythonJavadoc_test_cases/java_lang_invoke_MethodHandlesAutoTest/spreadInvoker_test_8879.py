import unittest
from enum import Enum
from typing import Any


class MethodType:
    pass


class VarHandle:
    class AccessMode(Enum):
        GET = "get"
        SET = "set"


class MethodHandle:
    pass


class MethodHandles:
    @staticmethod
    def throwException(p0, p1):
        pass

    @staticmethod
    def lookup():
        pass

    @staticmethod
    def empty(p0):
        pass

    @staticmethod
    def constant(p0, p1):
        pass

    @staticmethod
    def identity(p0):
        pass

    @staticmethod
    def spreadInvoker(p0, p1):
        pass

    @staticmethod
    def arrayLength(p0):
        pass

    @staticmethod
    def varHandleInvoker(p0, p1):
        pass

    @staticmethod
    def publicLookup():
        pass

    @staticmethod
    def tryFinally(p0, p1):
        pass

    @staticmethod
    def loop(p0):
        pass

    @staticmethod
    def tableSwitch(p0, p1):
        pass

    @staticmethod
    def arrayConstructor(p0):
        pass

    @staticmethod
    def exactInvoker(p0):
        pass

    @staticmethod
    def foldArguments(p0, p1):
        pass

    @staticmethod
    def foldArguments(p0, p1, p2):
        pass

    @staticmethod
    def invoker(p0):
        pass

    @staticmethod
    def reflectAs(p0, p1):
        pass

    @staticmethod
    def zero(p0):
        pass

    @staticmethod
    def dropArgumentsToMatch(p0, p1, p2, p3):
        pass

    @staticmethod
    def dropArguments(p0, p1, p2):
        pass

    @staticmethod
    def dropArguments(p0, p1, p2):
        pass

    @staticmethod
    def countedLoop(p0, p1, p2, p3):
        pass

    @staticmethod
    def countedLoop(p0, p1, p2):
        pass

    @staticmethod
    def permuteArguments(p0, p1, p2):
        pass

    @staticmethod
    def filterValue(p0, p1, p2):
        pass

    @staticmethod
    def filterCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def insertCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def permuteCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def collectCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def dropCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def arrayElementGetter(p0):
        pass

    @staticmethod
    def arrayElementSetter(p0):
        pass

    @staticmethod
    def arrayElementVarHandle(p0):
        pass

    @staticmethod
    def byteArrayViewVarHandle(p0, p1):
        pass

    @staticmethod
    def byteBufferViewVarHandle(p0, p1):
        pass

    @staticmethod
    def varHandleExactInvoker(p0, p1):
        pass

    @staticmethod
    def explicitCastArguments(p0, p1):
        pass

    @staticmethod
    def insertArguments(p0, p1, p2):
        pass

    @staticmethod
    def dropReturn(p0):
        pass

    @staticmethod
    def filterArguments(p0, p1, p2):
        pass

    @staticmethod
    def collectArguments(p0, p1, p2):
        pass

    @staticmethod
    def filterReturnValue(p0, p1):
        pass

    @staticmethod
    def guardWithTest(p0, p1, p2):
        pass

    @staticmethod
    def catchException(p0, p1, p2):
        pass

    @staticmethod
    def whileLoop(p0, p1, p2):
        pass

    @staticmethod
    def doWhileLoop(p0, p1, p2):
        pass

    @staticmethod
    def iteratedLoop(p0, p1, p2):
        pass


class TestMethodHandles(unittest.TestCase):

    def test_spreadInvoker_test_8879(self):
        # Test that spreadInvoker with null MethodType and -1 throws IllegalArgumentException
        method_type0 = None
        
        # Verify that calling spreadInvoker with invalid arguments raises an exception
        with self.assertRaises(Exception) as context:
            MethodHandles.spreadInvoker(method_type0, -1)
        
        # Verify the exception message matches the expected Java behavior
        self.assertIn("bad argument count: -1", str(context.exception))


if __name__ == '__main__':
    unittest.main()