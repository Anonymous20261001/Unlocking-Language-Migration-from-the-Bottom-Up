import unittest
import math

class TestMathNextUp(unittest.TestCase):
    
    def test_nextUp_test_8395(self):
        # Test nextUp with the smallest positive float value (1.4E-45f)
        float1 = math.nextafter(1.4e-45, float('inf'))
        
        # Assert that the result equals 2.8E-45f
        self.assertTrue(float1 == 2.8e-45, 
                       f"'{float1}' != '2.8e-45'")

if __name__ == '__main__':
    unittest.main()