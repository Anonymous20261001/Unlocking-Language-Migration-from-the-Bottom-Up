import unittest

class MathWrapper:
    """Wrapper class for Java's Math.floorMod functionality"""
    
    @staticmethod
    def floorMod(x, y):
        """Java's Math.floorMod equivalent for long and int parameters"""
        # Java's floorMod returns the floor modulus
        # For negative divisors, Java's behavior differs from Python's %
        if y == 0:
            raise ZeroDivisionError("divisor cannot be zero")
        
        # Convert to long if needed (Python handles arbitrary precision)
        result = x % y
        # Java's floorMod ensures result has same sign as divisor
        if result != 0 and (result < 0) != (y < 0):
            result += y
        return result


class TestMathFloorMod(unittest.TestCase):
    """Test class for java.lang.Math.floorMod()"""
    
    def test_floorMod_test_8354(self):
        """Randoop-generated regression test for java.lang.Math.floorMod()"""
        # Test case: floorMod((-100L), 110) should return 10
        int2 = MathWrapper.floorMod(-100, 110)
        self.assertTrue(f"'{int2}' != '10'", int2 == 10)
        self.assertEqual(int2, 10, f"Expected 10 but got {int2}")


if __name__ == '__main__':
    unittest.main()