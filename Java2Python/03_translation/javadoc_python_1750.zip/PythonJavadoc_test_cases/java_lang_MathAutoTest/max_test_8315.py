import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math.max for integers"""
    @staticmethod
    def max(a, b):
        return a if a > b else b

class TestMathMax(unittest.TestCase):
    """Test class for MathWrapper.max()"""
    
    def test_max_8315(self):
        """Test max with positive and negative integers"""
        # Test: Math.max(35, -2704) should return 35
        result = MathWrapper.max(35, -2704)
        self.assertEqual(result, 35, f"'{result}' != '35'")

if __name__ == '__main__':
    unittest.main()