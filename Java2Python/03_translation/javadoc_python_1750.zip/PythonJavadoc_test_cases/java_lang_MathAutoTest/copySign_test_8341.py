import unittest
import math

class TestMathCopySign(unittest.TestCase):
    
    def test_copySign_test_8341(self):
        # Java: java.lang.Math.copySign(53.0d, (double) 'a')
        # 'a' has ASCII value 97, so (double) 'a' = 97.0
        # Python: math.copysign(53.0, 97.0)
        result = math.copysign(53.0, 97.0)
        
        # Java assertion: double2 == 53.0d
        self.assertTrue(result == 53.0, 
                       f"'{result}' != '{53.0}'")
        
        # Additional check for exact equality
        self.assertEqual(result, 53.0)

if __name__ == '__main__':
    unittest.main()