import unittest
import math

class TestMathUlp(unittest.TestCase):
    
    def test_ulp_test_8390(self):
        """Randoop-generated regression test for math.ulp()."""
        # Test ulp of 110.0f (float in Java, but Python uses double precision)
        # In Java, Math.ulp(110.0f) returns 7.6293945E-6f
        # In Python, we need to convert to float32 to match Java's float behavior
        import struct
        
        # Convert 110.0 to float32 to match Java's float precision
        float32_value = struct.unpack('f', struct.pack('f', 110.0))[0]
        
        # Calculate ulp for float32
        # Python's math.ulp works with double precision, so we need to implement
        # float32 ulp calculation
        def ulp_float32(x):
            # Convert to float32
            x = struct.unpack('f', struct.pack('f', x))[0]
            
            # Handle special cases
            if math.isnan(x) or math.isinf(x) or x == 0:
                return 0.0
            
            # Get the next representable float32 value
            # Use struct to get the bits
            bits = struct.unpack('I', struct.pack('f', x))[0]
            
            if x > 0:
                next_bits = bits + 1
            else:
                next_bits = bits - 1
            
            next_value = struct.unpack('f', struct.pack('I', next_bits))[0]
            
            return abs(next_value - x)
        
        # Calculate ulp for 110.0f
        result = ulp_float32(110.0)
        
        # Expected value from Java test
        expected = 7.6293945E-6
        
        # Assert the result matches expected value
        self.assertAlmostEqual(result, expected, places=10)
        
        # Also verify with Python's built-in math.ulp for double precision
        # This is for reference but the test specifically checks float32 behavior
        double_ulp = math.ulp(110.0)
        print(f"Float32 ulp: {result}")
        print(f"Double ulp: {double_ulp}")
        print(f"Expected: {expected}")

if __name__ == '__main__':
    unittest.main()