import unittest
import math

class TestMathToIntExact(unittest.TestCase):
    
    def test_toIntExact_8386(self):
        """Test for math.toIntExact() equivalent"""
        # Java: java.lang.Math.toIntExact(99L) should return 99
        result = math.trunc(99)  # Python equivalent for long to int conversion
        self.assertEqual(result, 99, f"'{result}' != '{99}'")

if __name__ == '__main__':
    unittest.main()