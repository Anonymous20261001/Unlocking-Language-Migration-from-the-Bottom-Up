import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math.min() behavior"""
    @staticmethod
    def min(a, b):
        return a if a < b else b

class TestMathMin(unittest.TestCase):
    """Test class for MathWrapper.min() method"""
    
    def test_min_test_8311(self):
        """Test min() with two zeros"""
        # Test case: min(0, 0) should return 0
        int2 = MathWrapper.min(0, 0)
        
        # Assert that the result equals 0
        self.assertTrue(int2 == 0, f"'{int2}' != '0'")
        
        # Additional assertion for clarity
        self.assertEqual(int2, 0, f"Expected 0 but got {int2}")

if __name__ == '__main__':
    unittest.main()