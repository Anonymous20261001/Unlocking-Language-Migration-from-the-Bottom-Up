import unittest
import math

class TestMathGetExponent(unittest.TestCase):
    
    def test_getExponent_8352(self):
        """Randoop-generated regression test for math.getExponent()."""
        result = math.getExponent(-1.0)
        self.assertEqual(result, 0, f"'{result}' != '{0}'")

if __name__ == '__main__':
    unittest.main()