import unittest

class MathWrapper:
    """Wrapper class for Java's Math methods"""
    
    @staticmethod
    def multiplyFull(a, b):
        """Returns the exact mathematical product of the arguments."""
        return a * b


class TestMathMultiplyFull(unittest.TestCase):
    """Test cases for MathWrapper.multiplyFull method"""
    
    def test_multiplyFull_test_8387(self):
        """Test multiplyFull with zero arguments"""
        # Test: multiplyFull(0, 0) should return 0
        result = MathWrapper.multiplyFull(0, 0)
        self.assertEqual(result, 0, f"'{result}' != '0'")
        self.assertTrue(result == 0, f"'{result}' != '0'")


if __name__ == '__main__':
    unittest.main()