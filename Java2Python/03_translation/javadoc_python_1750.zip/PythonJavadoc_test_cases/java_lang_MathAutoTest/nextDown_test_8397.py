import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math methods"""
    
    @staticmethod
    def nextDown(value):
        """Returns the floating-point value adjacent to the given float in the direction of negative infinity"""
        import struct
        
        # Convert float to its IEEE 754 representation
        if isinstance(value, float):
            # Get the bits of the float
            bits = struct.unpack('I', struct.pack('f', value))[0]
            
            # Handle special cases
            if value != value:  # NaN
                return value
            if value == float('inf'):  # Positive infinity
                return 3.4028234663852886e+38  # Max float value
            if value == float('-inf'):  # Negative infinity
                return float('-inf')
            if value == 0.0:  # Zero
                return -1.401298464324817e-45  # Smallest negative subnormal
            
            # Decrement the bits to move towards negative infinity
            if bits & 0x80000000:  # Negative number
                bits += 1
            else:  # Positive number
                bits -= 1
            
            # Convert back to float
            return struct.unpack('f', struct.pack('I', bits))[0]
        
        # Handle integer input by converting to float first
        return MathWrapper.nextDown(float(value))

class TestMathNextDown(unittest.TestCase):
    """Test class for java.lang.Math.nextDown()"""
    
    def test_nextDown_test_8397(self):
        """Test nextDown with 1.0f should return 0.99999994f"""
        float1 = MathWrapper.nextDown(1.0)
        self.assertTrue(float1 == 0.99999994, 
                       f"'{float1}' != '{0.99999994}'")
        
        # Additional verification
        self.assertAlmostEqual(float1, 0.99999994, places=7)

if __name__ == '__main__':
    unittest.main()