import unittest
import math
import random

class TestMathRandom(unittest.TestCase):
    
    def test_random_test_8379(self):
        """
        Randoop-generated regression test for math.random().
        Note: The original Java test is flaky because random() returns
        a different value each time. This test verifies that the result
        is within the valid range [0.0, 1.0).
        """
        # Call math.random() which returns a random float in [0.0, 1.0)
        result = random.random()
        
        # Verify the result is in the valid range
        self.assertGreaterEqual(result, 0.0)
        self.assertLess(result, 1.0)
        
        # Verify it's a float
        self.assertIsInstance(result, float)
        
        # Verify it's not NaN
        self.assertFalse(math.isnan(result))
        
        # Verify it's finite
        self.assertTrue(math.isfinite(result))

if __name__ == '__main__':
    unittest.main()