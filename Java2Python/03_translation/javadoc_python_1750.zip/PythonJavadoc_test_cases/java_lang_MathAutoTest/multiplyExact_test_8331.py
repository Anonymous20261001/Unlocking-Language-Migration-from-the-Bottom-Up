import unittest

class MathWrapper:
    @staticmethod
    def multiplyExact(a, b):
        # Python doesn't have overflow checking like Java, but we can simulate it
        result = a * b
        # Check for integer overflow (32-bit signed)
        if result > 2147483647 or result < -2147483648:
            raise ArithmeticError("integer overflow")
        return result

class TestMathMultiplyExact(unittest.TestCase):
    
    def test_multiplyExact_8331(self):
        # Test: multiplyExact((int) '#', 1) should return 35
        # '#' has ASCII value 35
        int2 = MathWrapper.multiplyExact(ord('#'), 1)
        self.assertEqual(int2, 35, f"'{int2}' != '35'")

if __name__ == '__main__':
    unittest.main()