import unittest
import math

class TestMathRint(unittest.TestCase):
    
    def test_rint_8319(self):
        """Randoop-generated regression test for math.rint()."""
        result = math.rint(0.0)
        self.assertTrue(result == 0.0, f"'{result}' != '{0.0}'")

if __name__ == '__main__':
    unittest.main()