import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math.max for integers"""
    @staticmethod
    def max(a, b):
        return a if a > b else b

class TestMathMax(unittest.TestCase):
    """Test class for MathWrapper.max() method"""
    
    def test_max_test_8313(self):
        """Test case for Math.max(35, -2704)"""
        # Test the max function with the given values
        result = MathWrapper.max(35, -2704)
        
        # Assert that the result equals 35
        self.assertEqual(result, 35, f"'{result}' != '35'")

if __name__ == '__main__':
    unittest.main()