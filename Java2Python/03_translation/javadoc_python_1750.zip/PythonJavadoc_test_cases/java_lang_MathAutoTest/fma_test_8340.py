import unittest

class MathWrapper:
    """Wrapper class for Java's Math.fma() method"""
    
    @staticmethod
    def fma(a, b, c):
        """Returns a * b + c with single rounding"""
        return a * b + c


class TestJavaLangMathFma(unittest.TestCase):
    """Test class for java.lang.Math.fma()"""
    
    def test_fma_test_8340(self):
        """Randoop-generated regression test for java.lang.Math.fma()"""
        
        # Test case: fma(-1.0f, (float) 0L, (float) 1L)
        # Java: float float3 = java.lang.Math.fma((-1.0f), (float) 0L, (float) 1L);
        float3 = MathWrapper.fma(-1.0, 0.0, 1.0)
        
        # Assert that the result equals 1.0f
        # Java: org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        self.assertTrue(float3 == 1.0, f"'{float3}' != '1.0'")
        
        # Additional check for exact value
        self.assertEqual(float3, 1.0, f"Expected 1.0 but got {float3}")


if __name__ == '__main__':
    unittest.main()