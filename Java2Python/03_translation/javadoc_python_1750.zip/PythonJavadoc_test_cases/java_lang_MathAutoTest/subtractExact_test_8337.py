import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def subtractExact(a, b):
        """Equivalent to Java's Math.subtractExact(long, long)"""
        result = a - b
        # Check for overflow (Python doesn't have this issue with arbitrary precision,
        # but we keep the method for API compatibility)
        return result

class TestMathSubtractExact(unittest.TestCase):
    """Test class for MathWrapper.subtractExact method"""
    
    def test_subtractExact_test_8337(self):
        """Test case: subtractExact(0L, 1L) should return -1L"""
        # Test the operation
        result = MathWrapper.subtractExact(0, 1)
        
        # Assert the result equals -1
        self.assertEqual(result, -1, f"'{result}' != '{-1}'")
        
        # Additional assertion to match the Java test's style
        self.assertTrue(result == -1, f"'{result}' != '{-1}'")

if __name__ == '__main__':
    unittest.main()