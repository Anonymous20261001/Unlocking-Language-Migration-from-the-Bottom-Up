import unittest
import math

class TestMathAtan(unittest.TestCase):
    
    def test_atan_8358(self):
        """Randoop-generated regression test for math.atan()."""
        double1 = math.atan(-4.9E-324)
        self.assertTrue(double1 == -4.9E-324, 
                       f"'{double1}' != '{-4.9E-324}'")

if __name__ == '__main__':
    unittest.main()