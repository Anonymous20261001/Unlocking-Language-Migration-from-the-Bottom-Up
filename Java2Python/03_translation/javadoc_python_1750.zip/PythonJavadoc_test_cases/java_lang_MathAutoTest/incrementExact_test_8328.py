import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def incrementExact(value):
        """Increment the given integer by 1, raising an error on overflow"""
        if value == 2147483647:  # Integer.MAX_VALUE
            raise ArithmeticError("integer overflow")
        return value + 1


class TestMathIncrementExact(unittest.TestCase):
    """Test class for MathWrapper.incrementExact()"""
    
    def test_incrementExact_test_8328(self):
        """Test incrementExact with value 11, expecting 12"""
        # Test the incrementExact method with input 11
        int1 = MathWrapper.incrementExact(11)
        
        # Assert that the result equals 12
        self.assertEqual(int1, 12, f"'{int1}' != '12'")


if __name__ == '__main__':
    unittest.main()