import unittest
import math

class TestMathScalb(unittest.TestCase):
    
    def test_scalb_8350(self):
        """Randoop-generated regression test for math.scalb()."""
        # Java: java.lang.Math.scalb(0.0f, (int) ' ')
        # ' ' is space character with ASCII value 32
        # Java float is single precision, Python float is double precision
        # math.scalb in Python works with double precision
        result = math.scalb(0.0, 32)  # 0.0 * 2^32 = 0.0
        
        # Java: float2 == 0.0f
        # In Python, we compare with 0.0
        self.assertTrue(result == 0.0, 
                       f"'{result}' != '{0.0}'")

if __name__ == '__main__':
    unittest.main()