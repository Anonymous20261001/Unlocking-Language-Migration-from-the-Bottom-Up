import unittest

class MathWrapper:
    """Python wrapper class matching the Java Math functionality"""
    
    @staticmethod
    def addExact(a, b):
        """Adds two integers, raising an exception if overflow occurs"""
        result = a + b
        # Check for overflow in Python (though Python handles big integers natively)
        # This mimics Java's behavior for int overflow
        if result > 2147483647 or result < -2147483648:
            raise ArithmeticError("integer overflow")
        return result


class TestMathWrapper(unittest.TestCase):
    """Test class for MathWrapper.addExact()"""
    
    def test_addExact_test_8324(self):
        """Test addExact with positive integers"""
        # Test case: addExact(6, 101) should return 107
        result = MathWrapper.addExact(6, 101)
        self.assertEqual(result, 107, f"'{result}' != '107'")


if __name__ == '__main__':
    unittest.main()