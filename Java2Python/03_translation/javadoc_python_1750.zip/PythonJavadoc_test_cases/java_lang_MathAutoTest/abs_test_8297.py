import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math class methods"""
    
    @staticmethod
    def abs(x):
        """Returns the absolute value of an int"""
        return abs(x)


class TestMathAbs(unittest.TestCase):
    """Test class for MathWrapper.abs() method"""
    
    def test_abs_test_8297(self):
        """Test abs() with positive integer input"""
        # Test with value 10
        int1 = MathWrapper.abs(10)
        self.assertTrue(int1 == 10, f"'{int1}' != '10'")
        
        # Additional assertion to match Java's behavior
        self.assertEqual(int1, 10)


if __name__ == '__main__':
    unittest.main()