import unittest
import math

class TestMathToRadians(unittest.TestCase):
    
    def test_toRadians_test_8377(self):
        """Randoop-generated regression test for math.toRadians()."""
        result = math.radians(float('nan'))
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()