import unittest
import math

class TestMathCbrt(unittest.TestCase):
    
    def test_cbrt_test_8323(self):
        """Randoop-generated regression test for math.cbrt()."""
        # Test cbrt of 0.0f (converted to double)
        double1 = math.cbrt(float(0.0))
        
        # Assert that the result equals 0.0
        self.assertTrue(double1 == 0.0, 
                       f"'{double1}' != '0.0'")

if __name__ == '__main__':
    unittest.main()