import unittest
import math

class TestMathAcos(unittest.TestCase):
    
    def test_acos_8357(self):
        # Java: java.lang.Math.acos((double) '4')
        # '4' is a char with ASCII value 52
        # Cast to double: 52.0
        # acos(52.0) returns NaN since 52.0 is outside [-1, 1]
        double1 = math.acos(float(ord('4')))
        
        # Java: org.junit.Assert.assertTrue(Double.isNaN(double1))
        self.assertTrue(math.isnan(double1))

if __name__ == '__main__':
    unittest.main()