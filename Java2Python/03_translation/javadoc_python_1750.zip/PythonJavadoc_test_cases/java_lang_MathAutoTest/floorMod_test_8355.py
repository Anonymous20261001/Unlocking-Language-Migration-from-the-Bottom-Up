import unittest
import math

class TestMathFloorMod(unittest.TestCase):
    
    def test_floorMod_test_8355(self):
        """Randoop-generated regression test for math.floorMod()."""
        # Test floorMod with long and int arguments
        result = math.floorMod(-100, 110)
        
        # Assert the result equals 10
        self.assertEqual(result, 10, f"'{result}' != '10'")

if __name__ == '__main__':
    unittest.main()