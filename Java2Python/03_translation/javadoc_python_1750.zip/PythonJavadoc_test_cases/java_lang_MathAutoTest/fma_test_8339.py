import unittest

class MathWrapper:
    """Wrapper class for Java's Math.fma() method"""
    
    @staticmethod
    def fma(a, b, c):
        """Fused multiply-add: computes (a * b) + c with single rounding"""
        return (a * b) + c


class TestMathFma(unittest.TestCase):
    """Test class for MathWrapper.fma() method"""
    
    def test_fma_8339(self):
        """Test fma with float values"""
        # Java: java.lang.Math.fma((-1.0f), (float) 0L, (float) 1L)
        # Python equivalent: MathWrapper.fma(-1.0, 0.0, 1.0)
        result = MathWrapper.fma(-1.0, 0.0, 1.0)
        
        # Java assertion: float3 == 1.0f
        self.assertEqual(result, 1.0, 
                         f"'{result}' != '1.0'")
        
        # Additional check to match Java's exact behavior
        self.assertTrue(result == 1.0, 
                       f"'{result}' != '1.0'")


if __name__ == '__main__':
    unittest.main()