import unittest
import math

class TestMathSqrt(unittest.TestCase):
    
    def test_sqrt_8304(self):
        """Randoop-generated regression test for math.sqrt()."""
        # Test sqrt of -1.0 (as float)
        result = math.sqrt(float(-1.0))
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()