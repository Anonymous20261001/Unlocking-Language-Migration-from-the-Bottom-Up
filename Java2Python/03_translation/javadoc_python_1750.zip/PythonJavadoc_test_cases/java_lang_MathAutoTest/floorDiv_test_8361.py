import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def floorDiv(a, b):
        """Equivalent to Java's Math.floorDiv for long values"""
        if b == 0:
            raise ZeroDivisionError("Division by zero")
        
        # Handle the special case where a is Long.MIN_VALUE and b is -1
        if a == -2**63 and b == -1:
            return -2**63
        
        # Java's floorDiv returns the floor of the division
        # For positive results, it's the same as integer division
        # For negative results, it rounds down (towards negative infinity)
        result = a // b
        
        # Check if we need to adjust for negative results
        # Java's floorDiv rounds towards negative infinity
        if (a % b != 0) and ((a < 0) != (b < 0)):
            result -= 1
            
        return result

class TestMathFloorDiv(unittest.TestCase):
    """Test class for MathWrapper.floorDiv method"""
    
    def test_floorDiv_test_8361(self):
        """Test case for floorDiv with 35L and (long)'#' (35)"""
        # Java: long long2 = java.lang.Math.floorDiv(35L, (long) '#');
        # '#' has ASCII value 35
        long2 = MathWrapper.floorDiv(35, 35)
        
        # Java: assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        self.assertTrue(long2 == 1, f"'{long2}' != '1'")

if __name__ == '__main__':
    unittest.main()