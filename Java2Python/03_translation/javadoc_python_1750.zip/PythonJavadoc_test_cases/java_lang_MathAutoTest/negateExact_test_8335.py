import unittest

class MathWrapper:
    """Python wrapper class that mimics Java's Math.negateExact method"""
    
    @staticmethod
    def negateExact(x):
        """Negates the argument, throwing an exception if the result overflows an int"""
        if x == -2147483648:  # Integer.MIN_VALUE
            raise ArithmeticError("integer overflow")
        return -x


class TestMathNegateExact(unittest.TestCase):
    """Test class for MathWrapper.negateExact method"""
    
    def test_negateExact_test_8335(self):
        """Test negateExact with 0 as input"""
        # Test with 0
        result = MathWrapper.negateExact(0)
        self.assertEqual(result, 0, f"Expected 0 but got {result}")
        
        # Additional edge case tests for completeness
        # Test with positive number
        result = MathWrapper.negateExact(5)
        self.assertEqual(result, -5, f"Expected -5 but got {result}")
        
        # Test with negative number
        result = MathWrapper.negateExact(-5)
        self.assertEqual(result, 5, f"Expected 5 but got {result}")
        
        # Test with Integer.MAX_VALUE
        result = MathWrapper.negateExact(2147483647)
        self.assertEqual(result, -2147483647, f"Expected -2147483647 but got {result}")
        
        # Test with Integer.MIN_VALUE (should raise exception)
        with self.assertRaises(ArithmeticError):
            MathWrapper.negateExact(-2147483648)


if __name__ == '__main__':
    unittest.main()