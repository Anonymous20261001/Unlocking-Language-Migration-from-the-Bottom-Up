import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math class methods"""
    
    @staticmethod
    def multiplyExact(a, b):
        """Multiply two integers exactly, raising OverflowError if overflow occurs"""
        result = a * b
        # Check for overflow (Python handles arbitrary precision, but we simulate Java's behavior)
        if result > 2**31 - 1 or result < -2**31:
            raise OverflowError("integer overflow")
        return result

class TestMathMultiplyExact(unittest.TestCase):
    """Test class for java.lang.Math.multiplyExact()"""
    
    def test_multiplyExact_test_8330(self):
        """Randoop-generated regression test for java.lang.Math.multiplyExact()."""
        # Test: multiplyExact((int) '#', 1) should return 35
        # In Java, '#' has ASCII value 35
        int2 = MathWrapper.multiplyExact(ord('#'), 1)
        self.assertTrue(f"'{int2}' != '{35}'", int2 == 35)
        self.assertEqual(int2, 35)

if __name__ == '__main__':
    unittest.main()