import unittest
import math


class TestMathAsin(unittest.TestCase):
    
    def test_asin_test_8356(self):
        """Randoop-generated regression test for math.asin()."""
        # Test asin with value 110 (outside valid domain [-1, 1])
        double1 = math.asin(110)
        self.assertTrue(math.isnan(double1))


if __name__ == '__main__':
    unittest.main()