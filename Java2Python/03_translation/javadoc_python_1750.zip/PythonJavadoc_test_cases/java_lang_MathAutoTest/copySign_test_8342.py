import unittest
import math

class TestMathCopySign(unittest.TestCase):
    
    def test_copySign_test_8342(self):
        """Randoop-generated regression test for math.copysign()."""
        # Java: Math.copySign(53.0d, (double) 'a')
        # 'a' is 97 in ASCII, so (double) 'a' = 97.0
        # Python's math.copysign(x, y) returns x with the sign of y
        result = math.copysign(53.0, 97.0)
        
        # Java assertion: double2 == 53.0d
        self.assertTrue(result == 53.0, 
                       f"'{result}' != '53.0'")
        
        # Additional check to ensure the sign is positive
        self.assertGreater(result, 0, "Result should be positive")

if __name__ == '__main__':
    unittest.main()