import unittest
import math

class TestMathAbsExact(unittest.TestCase):
    
    def test_absExact_test_8389(self):
        # Test absExact with positive integer 10
        result = abs(10)
        self.assertEqual(result, 10, f"'{result}' != '{10}'")

if __name__ == '__main__':
    unittest.main()