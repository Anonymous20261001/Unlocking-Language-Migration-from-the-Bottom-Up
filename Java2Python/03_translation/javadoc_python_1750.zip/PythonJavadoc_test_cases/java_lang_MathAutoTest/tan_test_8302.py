import unittest
import math

class TestMathTan(unittest.TestCase):
    
    def test_tan_test_8302(self):
        """Randoop-generated regression test for math.tan()."""
        double1 = math.tan(0.0)
        self.assertTrue(double1 == 0.0, f"'{double1}' != '{0.0}'")

if __name__ == '__main__':
    unittest.main()