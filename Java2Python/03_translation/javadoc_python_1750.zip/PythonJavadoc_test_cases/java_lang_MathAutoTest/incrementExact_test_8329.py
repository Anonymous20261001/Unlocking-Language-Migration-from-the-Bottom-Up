import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def incrementExact(value):
        """Increments an integer by 1, raising an error on overflow"""
        if value == 2147483647:  # Integer.MAX_VALUE
            raise ArithmeticError("integer overflow")
        return value + 1


class TestMathIncrementExact(unittest.TestCase):
    """Test case for MathWrapper.incrementExact()"""
    
    def test_incrementExact_test_8329(self):
        """Test incrementExact with value 11"""
        # Test the wrapper class
        result = MathWrapper.incrementExact(11)
        self.assertEqual(result, 12, f"'{result}' != '12'")
        
        # Also test with Python's built-in equivalent for comparison
        self.assertEqual(11 + 1, 12, "Basic increment check failed")


if __name__ == '__main__':
    unittest.main()