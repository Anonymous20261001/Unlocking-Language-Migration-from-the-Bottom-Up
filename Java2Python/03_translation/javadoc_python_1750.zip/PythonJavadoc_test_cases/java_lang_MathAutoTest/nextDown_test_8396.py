import unittest

class MathWrapper:
    """Python wrapper class matching the Java Math functionality"""
    
    @staticmethod
    def nextDown(value):
        """Returns the floating-point value adjacent to the given value in the direction of negative infinity"""
        import struct
        
        if isinstance(value, float):
            # Handle float (32-bit) values
            # Convert to 32-bit float representation
            packed = struct.pack('f', value)
            bits = struct.unpack('I', packed)[0]
            
            # Handle special cases
            if value != value:  # NaN
                return value
            if value == float('inf'):  # Positive infinity
                return 3.4028234663852886e+38  # Max float value
            if value == float('-inf'):  # Negative infinity
                return float('-inf')
            if value == 0.0:  # Zero
                return -1.401298464324817e-45  # Smallest negative subnormal
            
            # Decrement the bits (move toward negative infinity)
            if bits & 0x80000000:  # Negative number
                bits += 1
            else:  # Positive number
                bits -= 1
            
            # Convert back to float
            result = struct.unpack('f', struct.pack('I', bits))[0]
            return result
        else:
            raise TypeError("Input must be a float")

class TestMathWrapper(unittest.TestCase):
    """Test class for MathWrapper.nextDown()"""
    
    def test_nextDown_test_8396(self):
        """Test nextDown with 1.0f should return 0.99999994f"""
        float1 = MathWrapper.nextDown(1.0)
        self.assertTrue(float1 == 0.99999994, 
                       f"'{float1}' != '{0.99999994}'")
        
        # Additional assertion to match Java's behavior more precisely
        self.assertAlmostEqual(float1, 0.99999994, places=7)

if __name__ == '__main__':
    unittest.main()