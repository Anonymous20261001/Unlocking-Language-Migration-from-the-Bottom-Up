import unittest
import math

class TestMathTanh(unittest.TestCase):
    
    def test_tanh_test_8322(self):
        """Randoop-generated regression test for math.tanh()."""
        # Java: java.lang.Math.tanh((double) '#')
        # '#' has ASCII value 35, cast to double
        double1 = math.tanh(float(ord('#')))
        
        # Java: assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d)
        self.assertTrue(double1 == 1.0, 
                       f"'{double1}' != '{1.0}'")

if __name__ == '__main__':
    unittest.main()