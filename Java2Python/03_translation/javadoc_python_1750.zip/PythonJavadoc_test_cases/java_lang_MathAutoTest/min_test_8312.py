import unittest

class MathWrapper:
    """Wrapper class for java.lang.Math static methods"""
    
    @staticmethod
    def min(a, b):
        """Returns the smaller of two int values"""
        return a if a < b else b

class TestMathMin(unittest.TestCase):
    """Test class for java.lang.Math.min() method"""
    
    def test_min_test_8312(self):
        """Randoop-generated regression test for java.lang.Math.min()"""
        int2 = MathWrapper.min(0, 0)
        self.assertTrue(int2 == 0, f"'{int2}' != '0'")

if __name__ == '__main__':
    unittest.main()