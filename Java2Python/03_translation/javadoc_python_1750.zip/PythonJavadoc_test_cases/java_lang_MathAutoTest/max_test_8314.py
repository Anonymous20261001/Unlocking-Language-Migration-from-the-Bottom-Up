import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math class methods"""
    
    @staticmethod
    def max(a, b):
        """Returns the greater of two int values"""
        return a if a > b else b


class TestMathMax(unittest.TestCase):
    """Test class for MathWrapper.max() method"""
    
    def test_max_8314(self):
        """Test case for Math.max(35, -2704)"""
        # Test the max function with positive and negative numbers
        result = MathWrapper.max(35, -2704)
        
        # Assert that the result equals 35 (the larger value)
        self.assertEqual(result, 35, f"'{result}' != '35'")
        
        # Additional assertion to match Java's assertTrue behavior
        self.assertTrue(result == 35, f"'{result}' != '35'")


if __name__ == '__main__':
    unittest.main()