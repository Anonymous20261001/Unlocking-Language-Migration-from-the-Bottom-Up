import unittest

class MathWrapper:
    """Wrapper class for java.lang.Math static methods"""
    
    @staticmethod
    def abs(x):
        """Returns the absolute value of an int value"""
        return abs(x)


class TestMathAbs(unittest.TestCase):
    """Test class for MathWrapper.abs() method"""
    
    def test_abs_test_8296(self):
        """Test abs() with positive integer 10"""
        # Test with positive integer 10
        result = MathWrapper.abs(10)
        self.assertEqual(result, 10, f"'{result}' != '10'")


if __name__ == '__main__':
    unittest.main()