import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math methods"""
    
    @staticmethod
    def addExact(a, b):
        """Adds two integers, throwing an exception if overflow occurs"""
        result = a + b
        # Check for overflow (Java int range: -2^31 to 2^31-1)
        if result > 2147483647 or result < -2147483648:
            raise ArithmeticError("integer overflow")
        return result

class TestMathAddExact(unittest.TestCase):
    """Test class for java.lang.Math.addExact()"""
    
    def test_addExact_8325(self):
        """Test addExact with values 6 and 101"""
        # Test the addExact method with the same values as the Java test
        result = MathWrapper.addExact(6, 101)
        
        # Assert that the result equals 107
        self.assertEqual(result, 107, f"'{result}' != '107'")

if __name__ == '__main__':
    unittest.main()