import unittest

class MathWrapper:
    @staticmethod
    def floorDiv(a, b):
        return a // b

class TestFloorDiv(unittest.TestCase):
    
    def test_floorDiv_8362(self):
        # Test case: floorDiv(35L, (long) '#')
        # '#' has ASCII value 35
        long2 = MathWrapper.floorDiv(35, ord('#'))
        
        # Assert that the result equals 1L
        self.assertEqual(long2, 1, f"'{long2}' != '1'")

if __name__ == '__main__':
    unittest.main()