import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math methods"""
    
    @staticmethod
    def multiplyExact(a, b):
        """Wrapper for java.lang.Math.multiplyExact(int, int)"""
        result = a * b
        # Check for integer overflow (Java's int is 32-bit)
        if result < -2**31 or result > 2**31 - 1:
            raise ArithmeticError("integer overflow")
        return result

class TestMathMultiplyExact(unittest.TestCase):
    """Test class for java.lang.Math.multiplyExact()"""
    
    def test_multiplyExact_test_8332(self):
        """Randoop-generated regression test for java.lang.Math.multiplyExact()"""
        # Test: multiplyExact((int) '#', 1) should return 35
        # In Java, '#' has ASCII value 35
        int2 = MathWrapper.multiplyExact(ord('#'), 1)
        self.assertTrue(f"'{int2}' != '{35}'", int2 == 35)
        self.assertEqual(int2, 35)

if __name__ == '__main__':
    unittest.main()