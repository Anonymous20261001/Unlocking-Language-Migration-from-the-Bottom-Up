import unittest
import math

class TestMathGetExponent(unittest.TestCase):
    
    def test_getExponent_8351(self):
        """Test for math.getExponent() with -1.0f (float)"""
        # Java: java.lang.Math.getExponent((-1.0f))
        # Python: math.getExponent() doesn't exist, but we can use math.frexp() 
        # or implement equivalent functionality
        
        # For -1.0f, the exponent should be 0
        # In Java, Math.getExponent(-1.0f) returns 0
        # In Python, we can get the exponent using math.frexp()
        
        value = -1.0
        mantissa, exponent = math.frexp(value)
        
        # Java's getExponent returns the unbiased exponent
        # For -1.0, frexp returns (0.5, 1) which means 0.5 * 2^1 = 1.0
        # Java's getExponent returns 0 for -1.0f
        # The relationship: Java exponent = Python exponent - 1 (for normalized values)
        
        java_exponent = exponent - 1
        
        # Assert that the exponent equals 0
        self.assertEqual(java_exponent, 0, 
                        f"'{java_exponent}' != '{0}'")
        
        # Alternative direct check
        # For -1.0, the exponent in IEEE 754 is 0
        self.assertEqual(0, 0)

if __name__ == '__main__':
    unittest.main()