import unittest

class MathWrapper:
    """Wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def multiplyHigh(x, y):
        """Returns the most significant 64 bits of the 128-bit product of two 64-bit signed integers"""
        # Convert to unsigned 64-bit for the multiplication
        x_unsigned = x & 0xFFFFFFFFFFFFFFFF
        y_unsigned = y & 0xFFFFFFFFFFFFFFFF
        
        # Perform 128-bit multiplication
        product = x_unsigned * y_unsigned
        
        # Extract the high 64 bits (bits 64-127)
        high_bits = (product >> 64) & 0xFFFFFFFFFFFFFFFF
        
        # Convert to signed 64-bit
        if high_bits >= 0x8000000000000000:
            high_bits -= 0x10000000000000000
        
        return high_bits

class TestMathWrapper(unittest.TestCase):
    """Test class for MathWrapper.multiplyHigh()"""
    
    def test_multiplyHigh_test_8333(self):
        """Test multiplyHigh with (-100) and 0L"""
        # Test case: multiplyHigh((-100), 0L) should return 0L
        long2 = MathWrapper.multiplyHigh(-100, 0)
        
        # Assert that the result equals 0
        self.assertEqual(long2, 0, f"'{long2}' != '0'")

if __name__ == '__main__':
    unittest.main()