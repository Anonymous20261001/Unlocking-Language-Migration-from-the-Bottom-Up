import unittest
import math

class TestMathCos(unittest.TestCase):
    
    def test_cos_test_8301(self):
        """Randoop-generated regression test for math.cos()"""
        result = math.cos(0.0)
        self.assertTrue(result == 1.0, 
                       f"'{result}' != '{1.0}'")
        
if __name__ == '__main__':
    unittest.main()