import unittest
import math

class TestMathExp(unittest.TestCase):
    
    def test_exp_test_8308(self):
        """Randoop-generated regression test for math.exp()."""
        result = math.exp(0.0)
        self.assertTrue(result == 1.0, 
                       f"'{result}' != '{1.0}'")

if __name__ == '__main__':
    unittest.main()