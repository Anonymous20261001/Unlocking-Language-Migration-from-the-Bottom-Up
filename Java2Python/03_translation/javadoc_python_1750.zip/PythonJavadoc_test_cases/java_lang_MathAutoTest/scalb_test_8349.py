import unittest
import math

class TestMathScalb(unittest.TestCase):
    
    def test_scalb_test_8349(self):
        """Randoop-generated regression test for math.scalb()."""
        # Java: java.lang.Math.scalb(0.0f, (int) ' ')
        # ' ' is space character with ASCII value 32
        # Java float is equivalent to Python float
        float2 = math.scalb(0.0, 32)  # scalb(0.0f, 32)
        
        # Java: org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f)
        # Assert that float2 equals 0.0
        self.assertEqual(float2, 0.0, 
                         f"'{float2}' != '{0.0}'")

if __name__ == '__main__':
    unittest.main()