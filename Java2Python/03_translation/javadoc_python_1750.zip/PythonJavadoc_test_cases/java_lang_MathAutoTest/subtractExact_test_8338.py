import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math equivalent operations"""
    
    @staticmethod
    def subtractExact(a, b):
        """Equivalent to java.lang.Math.subtractExact(long, long)"""
        result = a - b
        # Check for overflow (Java's subtractExact throws ArithmeticException on overflow)
        if (b > 0 and result > a) or (b < 0 and result < a):
            raise ArithmeticError("long overflow")
        return result


class TestMathWrapper(unittest.TestCase):
    """Test class for MathWrapper.subtractExact method"""
    
    def test_subtractExact_test_8338(self):
        """Test case for subtractExact(0L, 1L)"""
        # Test the operation
        long2 = MathWrapper.subtractExact(0, 1)
        
        # Assert the result equals -1
        self.assertTrue(long2 == -1, 
                       f"'{long2}' != '{(-1)}'")
        
        # Additional assertion for clarity
        self.assertEqual(long2, -1, "subtractExact(0, 1) should return -1")


if __name__ == '__main__':
    unittest.main()