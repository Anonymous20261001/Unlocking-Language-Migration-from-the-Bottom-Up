import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math methods"""
    
    @staticmethod
    def negateExact(x):
        """Negates the value, throwing an exception if the result overflows"""
        if x == -2147483648:  # Integer.MIN_VALUE
            raise ArithmeticError("integer overflow")
        return -x

class TestMathNegateExact(unittest.TestCase):
    """Test case for java.lang.Math.negateExact()"""
    
    def test_negateExact_8336(self):
        """Test negateExact with input 0"""
        # Test with input 0
        int1 = MathWrapper.negateExact(0)
        self.assertTrue(int1 == 0, f"'{int1}' != '0'")

if __name__ == '__main__':
    unittest.main()