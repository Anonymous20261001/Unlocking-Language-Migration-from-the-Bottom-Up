import unittest
import math

class TestMathNextAfter(unittest.TestCase):
    
    def test_nextAfter_8393(self):
        """Randoop-generated regression test for math.nextafter()."""
        float2 = math.nextafter(0.0, 1.0)
        self.assertTrue(float2 == 1.4e-45, f"'{float2}' != '{1.4e-45}'")

if __name__ == '__main__':
    unittest.main()