import unittest
import math

class TestMathPow(unittest.TestCase):
    
    def test_pow_test_8307(self):
        # Test java.lang.Math.pow((-2604L), 0.15348481875996808d)
        # In Java, Math.pow with negative base and non-integer exponent returns NaN
        result = math.pow(-2604, 0.15348481875996808)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()