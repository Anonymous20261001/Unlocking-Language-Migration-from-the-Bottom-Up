import unittest
import math

class TestMathLog(unittest.TestCase):
    
    def test_log_test_8305(self):
        """Randoop-generated regression test for math.log()"""
        # Test log of negative number returns NaN
        result = math.log(-10.0)
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()