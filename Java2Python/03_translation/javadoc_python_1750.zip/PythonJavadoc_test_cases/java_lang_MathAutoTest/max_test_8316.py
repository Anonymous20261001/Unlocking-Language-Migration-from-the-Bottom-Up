import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math static methods"""
    
    @staticmethod
    def max(a, b):
        """Returns the greater of two int values"""
        return max(a, b)


class TestMathMax(unittest.TestCase):
    """Test case for MathWrapper.max() method"""
    
    def test_max_8316(self):
        """Test max(35, -2704) should return 35"""
        # Test the wrapper method
        result = MathWrapper.max(35, -2704)
        
        # Assert the result equals 35
        self.assertEqual(result, 35, f"'{result}' != '35'")
        
        # Additional assertion to match Java's assertTrue behavior
        self.assertTrue(result == 35, f"'{result}' != '35'")


if __name__ == '__main__':
    unittest.main()