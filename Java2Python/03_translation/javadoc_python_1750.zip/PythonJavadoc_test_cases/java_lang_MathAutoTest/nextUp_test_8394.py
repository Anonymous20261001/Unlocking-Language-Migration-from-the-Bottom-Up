import unittest
import math

class TestMathNextUp(unittest.TestCase):
    
    def test_nextUp_8394(self):
        """Randoop-generated regression test for java.lang.Math.nextUp()."""
        # Java: float float1 = java.lang.Math.nextUp(1.4E-45f);
        # Python equivalent using math.nextafter (since Python doesn't have nextUp directly)
        # 1.4E-45f in Java is the smallest positive float (Float.MIN_VALUE)
        # In Python, we need to use float32 to match Java's float precision
        import numpy as np
        
        # Convert to float32 to match Java's float precision
        input_val = np.float32(1.4e-45)
        
        # Java's Math.nextUp returns the next float value towards positive infinity
        # Python's math.nextafter(x, math.inf) does the same
        float1 = np.float32(math.nextafter(float(input_val), math.inf))
        
        # Expected value: 2.8E-45f
        expected = np.float32(2.8e-45)
        
        # Assert equality
        self.assertEqual(float1, expected, 
                         f"'{float1}' != '{expected}'")

if __name__ == '__main__':
    unittest.main()