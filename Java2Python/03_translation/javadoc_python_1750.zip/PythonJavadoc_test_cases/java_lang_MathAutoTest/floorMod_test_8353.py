import unittest
import math

class TestMathFloorMod(unittest.TestCase):
    
    def test_floorMod_test_8353(self):
        # Test floorMod with negative long and positive int
        result = math.floor(-100 / 110)  # This won't work directly for floorMod
        # Python's equivalent for Java's Math.floorMod(long, int)
        # Java: Math.floorMod((-100L), 110) returns 10
        # Python equivalent: use modulo operator with adjustment for negative numbers
        result = (-100) % 110
        # In Python, -100 % 110 = 10 (Python's modulo always returns non-negative for positive divisor)
        self.assertEqual(result, 10, f"'{result}' != '10'")

if __name__ == '__main__':
    unittest.main()