import unittest
import math

class TestMathSin(unittest.TestCase):
    
    def test_sin_test_8300(self):
        """Randoop-generated regression test for math.sin()."""
        # Java: java.lang.Math.sin((double) 0L)
        # Python: math.sin(0.0) - converting long 0 to double
        double1 = math.sin(0.0)
        
        # Java: org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d)
        # Python: assert double1 == 0.0
        self.assertTrue(double1 == 0.0, f"'{double1}' != '0.0'")

if __name__ == '__main__':
    unittest.main()