import unittest
import math

class TestMathSinh(unittest.TestCase):
    
    def test_sinh_8369(self):
        """Randoop-generated regression test for math.sinh()."""
        # Test with the character '#' which has ASCII value 35
        double1 = math.sinh(ord('#'))
        
        # Expected value from the Java test
        expected = 7.930067261567154E14
        
        # Assert the values are equal
        self.assertTrue(double1 == expected, 
                       f"'{double1}' != '{expected}'")

if __name__ == '__main__':
    unittest.main()