import unittest
import math

class TestMathAbsExact(unittest.TestCase):
    
    def test_absExact_8388(self):
        """Randoop-generated regression test for math.absExact()"""
        int1 = abs(10)  # Python's abs() is equivalent to Java's Math.absExact() for int
        self.assertTrue(int1 == 10, f"'{int1}' != '{10}'")

if __name__ == '__main__':
    unittest.main()