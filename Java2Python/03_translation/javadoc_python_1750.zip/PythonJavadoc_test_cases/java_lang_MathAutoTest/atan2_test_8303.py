import unittest
import math

class TestMathAtan2(unittest.TestCase):
    
    def test_atan2_8303(self):
        """Randoop-generated regression test for math.atan2()."""
        result = math.atan2(0.0, float(1))
        self.assertTrue(f"'{result}' != '{0.0}'", result == 0.0)

if __name__ == '__main__':
    unittest.main()