import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math class methods"""
    
    @staticmethod
    def decrementExact(x):
        """Decrements the argument by one, throwing an exception if the result overflows"""
        if x == -2147483648:  # Integer.MIN_VALUE
            raise ArithmeticError("integer overflow")
        return x - 1

class TestMathDecrementExact(unittest.TestCase):
    """Test class for MathWrapper.decrementExact()"""
    
    def test_decrementExact_test_8327(self):
        """Test decrementExact with input 0, expecting -1"""
        # Test with input 0
        int1 = MathWrapper.decrementExact(0)
        
        # Assert that the result equals -1
        self.assertTrue(f"'{int1}' != '{-1}'", int1 == -1)
        # Alternative assertion (more Pythonic):
        # self.assertEqual(int1, -1, f"'{int1}' != '{-1}'")

if __name__ == '__main__':
    unittest.main()