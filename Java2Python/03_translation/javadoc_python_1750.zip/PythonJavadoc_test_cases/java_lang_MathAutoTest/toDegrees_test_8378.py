import unittest
import math

class TestMathToDegrees(unittest.TestCase):
    
    def test_toDegrees_8378(self):
        """Test for math.degrees() with 0.0"""
        result = math.degrees(0.0)
        self.assertTrue(result == 0.0, f"'{result}' != '0.0'")

if __name__ == '__main__':
    unittest.main()