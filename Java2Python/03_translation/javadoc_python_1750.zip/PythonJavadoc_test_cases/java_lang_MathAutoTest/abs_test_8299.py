import unittest
import math

class TestMathAbs(unittest.TestCase):
    
    def test_abs_test_8299(self):
        """Test for math.abs() with positive integer input"""
        # Test abs(10) should return 10
        result = abs(10)
        self.assertEqual(result, 10, f"'{result}' != '10'")

if __name__ == '__main__':
    unittest.main()