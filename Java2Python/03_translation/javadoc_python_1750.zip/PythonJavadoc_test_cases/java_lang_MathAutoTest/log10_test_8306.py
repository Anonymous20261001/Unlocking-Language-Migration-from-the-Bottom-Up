import unittest
import math

class TestMathLog10(unittest.TestCase):
    
    def test_log10_8306(self):
        """Randoop-generated regression test for math.log10()."""
        # Java: (double) (short) 10 = 10.0
        double1 = math.log10(float(10))
        self.assertTrue(double1 == 1.0, f"'{double1}' != '1.0'")

if __name__ == '__main__':
    unittest.main()