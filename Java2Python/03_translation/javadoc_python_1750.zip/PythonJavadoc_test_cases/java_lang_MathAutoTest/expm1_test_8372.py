import unittest
import math

class TestMathExpm1(unittest.TestCase):
    
    def test_expm1_8372(self):
        """Randoop-generated regression test for math.expm1()."""
        # In Java: (double) '#' converts the character '#' (ASCII 35) to double 35.0
        double1 = math.expm1(35.0)
        self.assertTrue(double1 == 1.5860134523134298E15, 
                       f"'{double1}' != '1.5860134523134298E15'")

if __name__ == '__main__':
    unittest.main()