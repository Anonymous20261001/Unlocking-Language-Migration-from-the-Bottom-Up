import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math.round() behavior"""
    
    @staticmethod
    def round(value):
        """Round a float to the nearest integer (Python's round uses banker's rounding, 
        so we need to implement Java's rounding behavior which rounds half up)"""
        if isinstance(value, float):
            # Java's Math.round() rounds half up, Python's round() rounds half to even
            import math
            if value >= 0:
                return math.floor(value + 0.5)
            else:
                return math.ceil(value - 0.5)
        return round(value)

class TestMathRound(unittest.TestCase):
    """Test class for MathWrapper.round() method"""
    
    def test_round_test_8321(self):
        """Test rounding of a very small float value (4.9E-44f)"""
        # Test value: 4.9E-44f (very small positive float)
        float_value = 4.9E-44
        
        # Call the round method
        result = MathWrapper.round(float_value)
        
        # Assert that the result equals 0
        self.assertEqual(result, 0, f"'{result}' != '0'")
        
        # Additional assertion to match the Java test format
        self.assertTrue(result == 0, f"'{result}' != '{0}'")

if __name__ == '__main__':
    unittest.main()