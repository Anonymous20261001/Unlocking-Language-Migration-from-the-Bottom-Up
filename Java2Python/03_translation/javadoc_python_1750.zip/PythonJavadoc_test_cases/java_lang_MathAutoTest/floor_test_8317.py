import unittest
import math

class TestMathFloor(unittest.TestCase):
    
    def test_floor_test_8317(self):
        """Randoop-generated regression test for math.floor()."""
        result = math.floor(0.0)
        self.assertTrue(result == 0.0, f"'{result}' != '{0.0}'")

if __name__ == '__main__':
    unittest.main()