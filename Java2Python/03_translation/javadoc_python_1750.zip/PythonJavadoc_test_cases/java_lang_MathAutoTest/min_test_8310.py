import unittest

class MathWrapper:
    """Wrapper class for Java's Math methods"""
    
    @staticmethod
    def min(a, b):
        """Returns the smaller of two int values"""
        return a if a < b else b


class TestMathMin(unittest.TestCase):
    """Test class for MathWrapper.min() method"""
    
    def test_min_8310(self):
        """Test min with both arguments being 0"""
        # Test case: min(0, 0) should return 0
        result = MathWrapper.min(0, 0)
        
        # Assert that the result equals 0
        self.assertEqual(result, 0, f"'{result}' != '0'")


if __name__ == '__main__':
    unittest.main()