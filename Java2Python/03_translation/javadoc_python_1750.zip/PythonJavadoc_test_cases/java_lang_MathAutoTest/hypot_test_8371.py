import unittest
import math

class TestMathHypot(unittest.TestCase):
    
    def test_hypot_test_8371(self):
        """Randoop-generated regression test for math.hypot()."""
        double2 = math.hypot(22026.465794806718, float('nan'))
        self.assertTrue(math.isnan(double2))

if __name__ == '__main__':
    unittest.main()