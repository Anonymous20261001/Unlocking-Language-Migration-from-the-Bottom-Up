import unittest
import math

class TestMathIEEEremainder(unittest.TestCase):
    
    def test_IEEEremainder_8359(self):
        # Test IEEEremainder with (byte)100 = 100 and -1.0
        double2 = math.remainder(100.0, -1.0)
        self.assertTrue(double2 == 0.0, f"'{double2}' != '0.0'")

if __name__ == '__main__':
    unittest.main()