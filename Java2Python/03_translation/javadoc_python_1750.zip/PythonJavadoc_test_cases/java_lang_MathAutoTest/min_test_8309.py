import unittest

class MathWrapper:
    """Python wrapper class for java.lang.Math static methods"""
    
    @staticmethod
    def min(a, b):
        """Returns the smaller of two int values"""
        return min(a, b)


class TestMathMin(unittest.TestCase):
    """Test class for MathWrapper.min() method"""
    
    def test_min_8309(self):
        """Test case for MathWrapper.min() with two zeros"""
        # Test: Math.min(0, 0) should return 0
        result = MathWrapper.min(0, 0)
        
        # Assert that the result equals 0
        self.assertEqual(result, 0, f"'{result}' != '0'")


if __name__ == '__main__':
    unittest.main()