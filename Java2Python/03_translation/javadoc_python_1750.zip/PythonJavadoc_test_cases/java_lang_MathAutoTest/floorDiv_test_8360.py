import unittest

class MathWrapper:
    """Wrapper class to mimic Java's Math class methods"""
    
    @staticmethod
    def floorDiv(a, b):
        """Java's Math.floorDiv for long values"""
        if b == 0:
            raise ArithmeticError("/ by zero")
        
        # Handle the special case where a is Long.MIN_VALUE and b is -1
        if a == -9223372036854775808 and b == -1:
            return -9223372036854775808
        
        result = a // b
        
        # Java's floorDiv rounds toward negative infinity
        # Python's // already does this for integers
        return result


class TestMathFloorDiv(unittest.TestCase):
    """Test class for java.lang.Math.floorDiv()"""
    
    def test_floorDiv_test_8360(self):
        """Randoop-generated regression test for java.lang.Math.floorDiv()"""
        
        # Test case: floorDiv(35L, (long) '#')
        # '#' is ASCII 35, so (long) '#' = 35L
        # floorDiv(35, 35) = 1
        
        long2 = MathWrapper.floorDiv(35, ord('#'))
        
        # Assert that the result equals 1L
        self.assertTrue(long2 == 1, f"'{long2}' != '1'")
        self.assertEqual(long2, 1, f"'{long2}' != '1'")


if __name__ == '__main__':
    unittest.main()