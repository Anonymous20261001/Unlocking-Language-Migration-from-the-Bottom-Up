import unittest
from AlphaComposite import AlphaComposite

class TestAlphaCompositeGetInstance(unittest.TestCase):
    
    def test_getInstance_test_145(self):
        # Create AlphaComposite instance with rule 10 and alpha 1.0
        alpha_composite_2 = AlphaComposite.getInstance(10, 1.0)
        
        # Get the SrcIn constant (which should be a specific rule value)
        # In Java, SrcIn is a static final field with rule value 9
        alpha_composite_3 = AlphaComposite.SrcIn
        
        # Check equality between the two instances
        boolean_4 = alpha_composite_2.equals(alpha_composite_3)
        
        # Assertions
        self.assertIsNotNone(alpha_composite_2)
        self.assertIsNotNone(alpha_composite_3)
        self.assertFalse(boolean_4, f"Expected False but got {boolean_4}")

if __name__ == '__main__':
    unittest.main()