import unittest

class TextHitInfo:
    @staticmethod
    def trailing(char_index):
        return TextHitInfo(char_index, True)

    @staticmethod
    def leading(char_index):
        return TextHitInfo(char_index, False)

    @staticmethod
    def beforeOffset(offset):
        return TextHitInfo(offset - 1, True)

    @staticmethod
    def afterOffset(offset):
        return TextHitInfo(offset, False)

    def __init__(self, char_index, is_trailing):
        self.char_index = char_index
        self.is_trailing = is_trailing


class TestTextHitInfo(unittest.TestCase):
    
    def test_beforeOffset_test_12589(self):
        # Test beforeOffset with offset = 1 (cast from short)
        text_hit_info1 = TextHitInfo.beforeOffset(1)
        
        # Get the class of the object
        wildcard_class2 = text_hit_info1.__class__
        
        # Assert that the object is not None
        self.assertIsNotNone(text_hit_info1)
        
        # Assert that the class is not None
        self.assertIsNotNone(wildcard_class2)
        
        # Additional assertions to verify the behavior
        self.assertEqual(text_hit_info1.char_index, 0)  # offset - 1 = 0
        self.assertTrue(text_hit_info1.is_trailing)  # beforeOffset creates trailing hit


if __name__ == '__main__':
    unittest.main()