import unittest

class TextHitInfo:
    @staticmethod
    def trailing(char_index):
        return TextHitInfo(char_index, True)

    @staticmethod
    def leading(char_index):
        return TextHitInfo(char_index, False)

    @staticmethod
    def beforeOffset(offset):
        return TextHitInfo(offset - 1, True)

    @staticmethod
    def afterOffset(offset):
        return TextHitInfo(offset, False)

    def __init__(self, char_index, is_trailing):
        self.char_index = char_index
        self.is_trailing = is_trailing


class TestTextHitInfo(unittest.TestCase):
    
    def test_trailing_test_12587(self):
        # Test trailing() with char_index = 0
        text_hit_info1 = TextHitInfo.trailing(0)
        
        # Get the class of the object
        wildcard_class2 = text_hit_info1.__class__
        
        # Assert that the object is not None
        self.assertIsNotNone(text_hit_info1)
        
        # Assert that the class is not None
        self.assertIsNotNone(wildcard_class2)


if __name__ == '__main__':
    unittest.main()