import unittest
from your_module import TextHitInfo  # Replace with actual import

class TestTextHitInfoAfterOffset(unittest.TestCase):
    
    def test_afterOffset_test_12590(self):
        # Java: java.awt.font.TextHitInfo.afterOffset((int) '#')
        # '#' has ASCII value 35
        text_hit_info1 = TextHitInfo.afterOffset(35)
        
        # Java: textHitInfo1.getClass()
        wildcard_class2 = text_hit_info1.__class__
        
        # Java: org.junit.Assert.assertNotNull(textHitInfo1)
        self.assertIsNotNone(text_hit_info1)
        
        # Java: org.junit.Assert.assertNotNull(wildcardClass2)
        self.assertIsNotNone(wildcard_class2)

if __name__ == '__main__':
    unittest.main()