import unittest

class TextHitInfo:
    @staticmethod
    def trailing(char_index):
        return TextHitInfo(char_index, True)

    @staticmethod
    def leading(char_index):
        return TextHitInfo(char_index, False)

    @staticmethod
    def beforeOffset(offset):
        return TextHitInfo(offset - 1, True)

    @staticmethod
    def afterOffset(offset):
        return TextHitInfo(offset, False)

    def __init__(self, char_index, is_trailing):
        self.char_index = char_index
        self.is_trailing = is_trailing

    def equals(self, obj):
        if obj is None:
            return False
        if not isinstance(obj, TextHitInfo):
            return False
        return self.char_index == obj.char_index and self.is_trailing == obj.is_trailing

    def toString(self):
        suffix = "T" if self.is_trailing else "L"
        return f"TextHitInfo[{self.char_index}{suffix}]"


class TestTextHitInfo(unittest.TestCase):
    def test_leading_test_12588(self):
        # Create TextHitInfo with leading at index 0
        text_hit_info1 = TextHitInfo.leading(0)
        
        # Test equals with None
        obj2 = None
        boolean3 = text_hit_info1.equals(obj2)
        
        # Test toString
        str4 = text_hit_info1.toString()
        
        # Assertions
        self.assertIsNotNone(text_hit_info1)
        self.assertFalse(boolean3, f"'{boolean3}' != 'False'")
        self.assertEqual(str4, "TextHitInfo[0L]", f"'{str4}' != 'TextHitInfo[0L]'")


if __name__ == '__main__':
    unittest.main()