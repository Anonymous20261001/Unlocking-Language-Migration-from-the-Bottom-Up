import unittest
from unittest.mock import patch, MagicMock
from keyboard_focus_manager import KeyboardFocusManager


class TestKeyboardFocusManager(unittest.TestCase):
    
    def test_getCurrentKeyboardFocusManager_test_7612(self):
        """
        Randoop-generated regression test for 
        KeyboardFocusManager.getCurrentKeyboardFocusManager()
        """
        # Get the current keyboard focus manager
        keyboard_focus_manager0 = KeyboardFocusManager.getCurrentKeyboardFocusManager()
        
        # Set it as the current keyboard focus manager
        KeyboardFocusManager.setCurrentKeyboardFocusManager(keyboard_focus_manager0)
        
        # Get the class of the keyboard focus manager
        wildcard_class2 = keyboard_focus_manager0.__class__
        
        # Assertions
        self.assertIsNotNone(keyboard_focus_manager0)
        self.assertIsNotNone(wildcard_class2)


if __name__ == '__main__':
    unittest.main()