import unittest
from urllib.parse import urlparse

class URI:
    def __init__(self, uri_string):
        self.uri_string = uri_string
        parsed = urlparse(uri_string)
        self.scheme = parsed.scheme
        self.netloc = parsed.netloc
        self.path = parsed.path
        self.params = parsed.params
        self.query = parsed.query
        self.fragment = parsed.fragment
        self.username = parsed.username
        self.password = parsed.password
        self.hostname = parsed.hostname
        self.port = parsed.port
        self.userinfo = f"{parsed.username}:{parsed.password}" if parsed.username else None

    @classmethod
    def create(cls, uri_string):
        if not isinstance(uri_string, str):
            raise TypeError("URI string must be a string")
        if " " in uri_string:
            raise ValueError("Invalid URI: contains spaces")
        return cls(uri_string)

    def __str__(self):
        return self.uri_string

    def __repr__(self):
        return f"URI('{self.uri_string}')"


class TestURICreate(unittest.TestCase):
    
    def test_create_test_13237(self):
        # Create URI with "hi!" string
        uRI1 = URI.create("hi!")
        
        # Get the class of the URI object
        wildcardClass2 = uRI1.__class__
        
        # Assert that the URI object is not None
        self.assertIsNotNone(uRI1)
        
        # Assert that the class object is not None
        self.assertIsNotNone(wildcardClass2)


if __name__ == '__main__':
    unittest.main()