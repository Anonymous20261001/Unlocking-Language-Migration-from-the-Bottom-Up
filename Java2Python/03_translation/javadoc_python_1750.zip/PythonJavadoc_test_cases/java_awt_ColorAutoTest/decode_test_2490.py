import unittest
import colorsys

class Color:
    def __init__(self, rgb: int):
        self.rgb = rgb & 0xFFFFFFFF
        self.red = (rgb >> 16) & 0xFF
        self.green = (rgb >> 8) & 0xFF
        self.blue = rgb & 0xFF
        self.alpha = (rgb >> 24) & 0xFF

    def getComponents(self, colorSpace=None, components=None):
        if colorSpace is not None and components is not None:
            return None
        return None

    @staticmethod
    def getColor(name: str, fallback=None):
        if fallback is not None:
            return fallback
        return None

    def brighter(self):
        return self

    def darker(self):
        return self

    def getRGB(self):
        return self.rgb

    def getRed(self):
        return self.red

    def getGreen(self):
        return self.green

    def getBlue(self):
        return self.blue

    def getAlpha(self):
        return self.alpha

    @staticmethod
    def HSBtoRGB(h: float, s: float, b: float):
        r, g, bl = colorsys.hsv_to_rgb(h, s, b)
        return (int(r*255) << 16) | (int(g*255) << 8) | int(bl*255)

    def getRGBComponents(self, components=None):
        if components is not None:
            return None
        return None

    def getRGBColorComponents(self, components=None):
        if components is not None:
            return None
        return None

    @staticmethod
    def RGBtoHSB(r: int, g: int, b: int, hsbvals=None):
        h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        if hsbvals is not None:
            hsbvals[0] = h
            hsbvals[1] = s
            hsbvals[2] = v
        return hsbvals

    @staticmethod
    def getHSBColor(h: float, s: float, b: float):
        r, g, bl = colorsys.hsv_to_rgb(h, s, b)
        return Color((int(r*255) << 16) | (int(g*255) << 8) | int(bl*255))

    def getColorComponents(self, components=None):
        if components is not None:
            return None
        return None

    def getColorSpace(self):
        return None

    def createContext(self, cm, r, r2d, at, rh):
        return None

    def getTransparency(self):
        return self.alpha

    @staticmethod
    def decode(nm: str):
        # Simulate Java's Color.decode behavior
        if nm is None:
            raise NullPointerException("Name is null")
        
        # Remove leading '#' if present
        if nm.startswith('#'):
            nm = nm[1:]
        
        # Handle empty string
        if len(nm) == 0:
            raise ValueError("Zero length string")
        
        # Parse the hex value
        try:
            value = int(nm, 16)
        except ValueError:
            raise ValueError(f"For input string: \"{nm}\"")
        
        # Handle 24-bit color (add alpha)
        if len(nm) <= 6:
            value = value | 0xFF000000
        
        return Color(value)

class NullPointerException(Exception):
    pass

class TestColorAuto(unittest.TestCase):

    def test_decode_test_2490(self):
        p0 = ""
        
        # Test that decoding an empty string raises an exception
        with self.assertRaises(ValueError) as context:
            Color.decode(p0)
        
        # Verify the error message matches Java's behavior
        self.assertEqual(str(context.exception), "Zero length string")

if __name__ == '__main__':
    unittest.main()