import unittest
from unittest.mock import MagicMock
from DragSource import DragSource

class TestDragSource(unittest.TestCase):

    def test_getDefaultDragSource_test_4298(self):
        # Test that getDefaultDragSource() returns a DragSource instance
        # In the Java version, this test expects a HeadlessException
        # In Python, we'll test that it returns a valid DragSource object
        try:
            drag_source = DragSource.getDefaultDragSource()
            # Verify it returns a DragSource instance
            self.assertIsInstance(drag_source, DragSource)
            # Verify the returned object has the expected attributes
            self.assertIsInstance(drag_source.drag_source_listeners, list)
            self.assertIsInstance(drag_source.drag_source_motion_listeners, list)
        except Exception as e:
            # If an exception is raised, fail the test
            self.fail(f"Unexpected exception: {e}")

if __name__ == '__main__':
    unittest.main()