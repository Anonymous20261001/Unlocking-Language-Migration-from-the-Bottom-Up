import unittest
from unittest.mock import MagicMock
from DragSource import DragSource


class TestDragSource(unittest.TestCase):

    def test_isDragImageSupported_test_4299(self):
        """Randoop-generated regression test for DragSource.isDragImageSupported()."""
        boolean0 = DragSource.isDragImageSupported()
        self.assertTrue(f"'{boolean0}' != '{False}'", boolean0 == False)


if __name__ == '__main__':
    unittest.main()