import unittest
from typing import Optional


class ResponseCacheWrapper:
    """Wrapper class for ResponseCache static methods"""
    _default: Optional['ResponseCacheWrapper'] = None

    @classmethod
    def getDefault(cls):
        return cls._default

    @classmethod
    def setDefault(cls, response_cache: Optional['ResponseCacheWrapper']):
        cls._default = response_cache


class TestResponseCache(unittest.TestCase):

    def test_getDefault_test_10628(self):
        # Test that getDefault() returns None when no default is set
        result = ResponseCacheWrapper.getDefault()
        self.assertIsNone(result)


if __name__ == '__main__':
    unittest.main()