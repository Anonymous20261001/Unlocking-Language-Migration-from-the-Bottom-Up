import unittest
from java.awt.event import InputEvent

class InputEventWrapper:
    @staticmethod
    def getModifiersExText(p0):
        return InputEvent.getModifiersExText(p0)

    @staticmethod
    def getMaskForButton(p0):
        return InputEvent.getMaskForButton(p0)

class java_awt_event_InputEventAutoTest(unittest.TestCase):
    
    def test_getModifiersExText_test_5831(self):
        """Randoop-generated regression test for java.awt.event.InputEvent.getModifiersExText()."""
        str1 = InputEventWrapper.getModifiersExText(0)
        self.assertEqual(str1, "", f"'{str1}' != '{''}'")

if __name__ == '__main__':
    unittest.main()