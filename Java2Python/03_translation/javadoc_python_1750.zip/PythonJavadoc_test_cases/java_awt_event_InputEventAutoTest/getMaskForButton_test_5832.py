import unittest
from java.awt.event import InputEvent

class InputEventWrapper:
    @staticmethod
    def getModifiersExText(p0):
        return InputEvent.getModifiersExText(p0)

    @staticmethod
    def getMaskForButton(p0):
        return InputEvent.getMaskForButton(p0)

class TestGetMaskForButton(unittest.TestCase):
    
    def test_getMaskForButton_test_5832(self):
        """Randoop-generated regression test for java.awt.event.InputEvent.getMaskForButton()."""
        int1 = InputEventWrapper.getMaskForButton(1)
        self.assertEqual(int1, 1024, f"'{int1}' != '{1024}'")

if __name__ == '__main__':
    unittest.main()