import unittest
from threading import Thread
from unittest.mock import Mock, patch


class ThreadFactory:
    def new_thread(self, runnable):
        return Thread(target=runnable)


class Cleaner:
    @staticmethod
    def create(thread_factory=None):
        if thread_factory is None:
            return Cleaner()
        return Cleaner(thread_factory)

    def __init__(self, thread_factory=None):
        self._thread_factory = thread_factory
        self._cleanables = []

    def register(self, obj, action):
        cleanable = _Cleanable(obj, action, self)
        self._cleanables.append(cleanable)
        return cleanable

    def clean(self):
        for cleanable in self._cleanables:
            cleanable.clean()
        self._cleanables.clear()


class _Cleanable:
    def __init__(self, obj, action, cleaner):
        self._obj = obj
        self._action = action
        self._cleaner = cleaner
        self._cleaned = False

    def clean(self):
        if not self._cleaned:
            self._action()
            self._cleaned = True

    def __del__(self):
        self.clean()


class TestCleanerCreate(unittest.TestCase):
    def test_create_test_2319(self):
        # Create a Cleaner instance
        cleaner0 = Cleaner.create()
        
        # Create a simple object to register
        obj1 = object()
        
        # Get the class of the object (similar to getClass() in Java)
        wildcardClass2 = obj1.__class__
        
        # Set action to None (null in Java)
        runnable3 = None
        
        # Test that registering with None action raises NullPointerException
        with self.assertRaises(NullPointerException) as context:
            cleanable4 = cleaner0.register(obj1, runnable3)
        
        # Verify the exception message
        self.assertEqual(str(context.exception), "action")
        
        # Assertions to verify objects are not None
        self.assertIsNotNone(cleaner0)
        self.assertIsNotNone(wildcardClass2)


class NullPointerException(Exception):
    """Custom exception to mimic Java's NullPointerException"""
    pass


if __name__ == '__main__':
    unittest.main()