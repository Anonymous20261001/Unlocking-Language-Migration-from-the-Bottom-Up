import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathFma(unittest.TestCase):
    
    def test_fma_test_11637(self):
        """Randoop-generated regression test for StrictMath.fma()"""
        wrapper = StrictMathWrapper()
        
        # Test: StrictMath.fma((double) 35L, 0.19334632705655574d, Double.NaN)
        double3 = wrapper.fma(35.0, 0.19334632705655574, float('nan'))
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(double3))

if __name__ == '__main__':
    unittest.main()