import unittest
import math
from generated.test.StrictMathWrapper import StrictMathWrapper

class TestJavaLangStrictMathAutoTest(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_scalb_test_11647(self):
        """Randoop-generated regression test for java.lang.StrictMath.scalb()."""
        # Test scalb with double 10 and scale factor -1
        double2 = self.strict_math.scalb(10.0, -1)
        self.assertTrue(f"'{double2}' != '5.0'", double2 == 5.0)
        self.assertEqual(double2, 5.0)

if __name__ == '__main__':
    unittest.main()