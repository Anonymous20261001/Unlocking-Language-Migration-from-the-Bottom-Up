import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathCos(unittest.TestCase):
    
    def test_cos_test_11598(self):
        """Randoop-generated regression test for StrictMath.cos()"""
        wrapper = StrictMathWrapper()
        
        # Test: cos(0) should equal 1.0
        double1 = wrapper.cos((short) 0 if False else 0)  # In Python, just use 0
        double1 = wrapper.cos(0)
        
        self.assertTrue(double1 == 1.0, 
                       f"'{double1}' != '1.0d'")
        
        # Additional assertion to match Java's Assert.assertTrue with message
        self.assertEqual(double1, 1.0, 
                        f"'{double1}' != '1.0d'")

if __name__ == '__main__':
    unittest.main()
```

However, since the Java test casts `(short) 0` to double, and in Python we don't have the same casting semantics, the simplified version would be:

```python
import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathCos(unittest.TestCase):
    
    def test_cos_test_11598(self):
        """Randoop-generated regression test for StrictMath.cos()"""
        wrapper = StrictMathWrapper()
        
        # Test: cos(0) should equal 1.0
        double1 = wrapper.cos(0)
        
        self.assertTrue(double1 == 1.0, 
                       f"'{double1}' != '1.0d'")
        
        # Additional assertion to match Java's Assert.assertTrue with message
        self.assertEqual(double1, 1.0, 
                        f"'{double1}' != '1.0d'")

if __name__ == '__main__':
    unittest.main()