import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathFloorMod(unittest.TestCase):
    
    def test_floorMod_test_11652(self):
        """Randoop-generated regression test for StrictMath.floorMod()."""
        wrapper = StrictMathWrapper()
        
        # Test: StrictMath.floorMod(35L, 1) should return 0
        int2 = wrapper.floorMod(35, 1)
        
        # Assert that the result equals 0
        self.assertEqual(int2, 0, f"'{int2}' != '0'")

if __name__ == '__main__':
    unittest.main()