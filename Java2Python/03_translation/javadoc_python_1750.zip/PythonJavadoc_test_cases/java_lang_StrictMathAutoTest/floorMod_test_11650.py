import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathFloorMod(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_floorMod_test_11650(self):
        """Test case for floorMod(35L, 1)"""
        # Test floorMod with long value 35 and int 1
        result = self.strict_math.floorMod(35, 1)
        
        # Assert that the result equals 0
        self.assertEqual(result, 0, f"floorMod(35, 1) should be 0, but got {result}")
        
        # Additional verification
        self.assertTrue(result == 0, f"floorMod(35, 1) should be 0, but got {result}")

if __name__ == '__main__':
    unittest.main()