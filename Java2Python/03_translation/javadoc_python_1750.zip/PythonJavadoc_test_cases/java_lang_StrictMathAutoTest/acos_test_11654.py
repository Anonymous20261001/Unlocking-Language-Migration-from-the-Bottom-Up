import unittest
import math

class StrictMathWrapper:
    def abs(self, a):
        return abs(a)

    def sin(self, a):
        return math.sin(a)

    def cos(self, a):
        return math.cos(a)

    def tan(self, a):
        return math.tan(a)

    def atan2(self, y, x):
        return math.atan2(y, x)

    def sqrt(self, a):
        return math.sqrt(a)

    def log(self, a):
        return math.log(a)

    def log10(self, a):
        return math.log10(a)

    def pow(self, a, b):
        return math.pow(a, b)

    def exp(self, a):
        return math.exp(a)

    def min(self, a, b):
        return min(a, b)

    def max(self, a, b):
        return max(a, b)

    def floor(self, a):
        return math.floor(a)

    def ceil(self, a):
        return math.ceil(a)

    def rint(self, a):
        return round(a)

    def round(self, a):
        return round(a)

    def tanh(self, a):
        return math.tanh(a)

    def cbrt(self, a):
        return math.cbrt(a)

    def addExact(self, a, b):
        result = a + b
        if (isinstance(a, int) and isinstance(b, int)):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def decrementExact(self, a):
        result = a - 1
        if isinstance(a, int):
            if result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def incrementExact(self, a):
        result = a + 1
        if isinstance(a, int):
            if result > 2**31 - 1:
                raise OverflowError("integer overflow")
        return result

    def multiplyExact(self, a, b):
        result = a * b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def multiplyHigh(self, a, b):
        return (a * b) >> 64

    def unsignedMultiplyHigh(self, a, b):
        return (a * b) >> 64

    def negateExact(self, a):
        result = -a
        if isinstance(a, int):
            if result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def subtractExact(self, a, b):
        result = a - b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def fma(self, a, b, c):
        return a * b + c

    def copySign(self, magnitude, sign):
        return math.copysign(magnitude, sign)

    def signum(self, a):
        if a > 0:
            return 1.0
        elif a < 0:
            return -1.0
        else:
            return 0.0

    def clamp(self, value, min_value, max_value):
        return max(min_value, min(value, max_value))

    def scalb(self, a, scale_factor):
        return a * (2 ** scale_factor)

    def getExponent(self, a):
        return math.getexp(a)

    def floorMod(self, a, b):
        return a % b

    def asin(self, a):
        return math.asin(a)

    def acos(self, a):
        return math.acos(a)

    def atan(self, a):
        return math.atan(a)

    def IEEEremainder(self, a, b):
        return math.remainder(a, b)

    def floorDiv(self, a, b):
        return math.floor(a / b)

    def ceilDiv(self, a, b):
        return math.ceil(a / b)

    def ceilMod(self, a, b):
        return a - self.ceilDiv(a, b) * b

    def sinh(self, a):
        return math.sinh(a)

    def cosh(self, a):
        return math.cosh(a)

    def hypot(self, a, b):
        return math.hypot(a, b)

    def expm1(self, a):
        return math.expm1(a)

    def log1p(self, a):
        return math.log1p(a)

    def unsignedMultiplyExact(self, a, b):
        result = a * b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**64 - 1:
                raise OverflowError("integer overflow")
        return result

    def toRadians(self, a):
        return math.radians(a)

    def toDegrees(self, a):
        return math.degrees(a)

    def random(self):
        import random
        return random.random()

    def divideExact(self, a, b):
        result = a / b
        if isinstance(a, int) and isinstance(b, int):
            if result != int(result):
                raise ArithmeticError("division not exact")
        return result

    def floorDivExact(self, a, b):
        result = math.floor(a / b)
        if isinstance(a, int) and isinstance(b, int):
            if result * b != a:
                raise ArithmeticError("division not exact")
        return result

    def ceilDivExact(self, a, b):
        result = math.ceil(a / b)
        if isinstance(a, int) and isinstance(b, int):
            if result * b != a:
                raise ArithmeticError("division not exact")
        return result

    def toIntExact(self, a):
        if a > 2**31 - 1 or a < -2**31:
            raise OverflowError("integer overflow")
        return int(a)

    def multiplyFull(self, a, b):
        return a * b

    def absExact(self, a):
        result = abs(a)
        if isinstance(a, int):
            if result > 2**31 - 1:
                raise OverflowError("integer overflow")
        return result

    def ulp(self, a):
        return math.ulp(a)

    def nextAfter(self, start, direction):
        return math.nextafter(start, direction)

    def nextUp(self, a):
        return math.nextafter(a, float('inf'))

    def nextDown(self, a):
        return math.nextafter(a, float('-inf'))

    def powExact(self, a, b):
        result = a ** b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**63 - 1:
                raise OverflowError("integer overflow")
        return result

    def unsignedPowExact(self, a, b):
        result = a ** b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**64 - 1:
                raise OverflowError("integer overflow")
        return result


class TestStrictMathAutoTest(unittest.TestCase):
    """Test class for java_lang_StrictMathAutoTest"""

    def setUp(self):
        self.strict_math = StrictMathWrapper()

    def test_acos_test_11654(self):
        """Randoop-generated regression test for java.lang.StrictMath.acos()."""
        double1 = self.strict_math.acos(0.0)
        self.assertTrue(double1 == 1.5707963267948966, 
                        f"'{double1}' != '1.5707963267948966'")
        self.assertEqual(double1, 1.5707963267948966)


if __name__ == '__main__':
    unittest.main()