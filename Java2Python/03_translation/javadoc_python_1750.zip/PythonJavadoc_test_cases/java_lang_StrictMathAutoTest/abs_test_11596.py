import unittest
import math
from generated.test.StrictMathWrapper import StrictMathWrapper

class TestStrictMathAbs(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_abs_test_11596(self):
        """Randoop-generated regression test for StrictMath.abs()"""
        # Test abs(0) should return 0
        int1 = self.strict_math.abs(0)
        
        # Assert that the result equals 0
        self.assertEqual(int1, 0, f"'{int1}' != '0'")
        
        # Additional assertion to match Java's assertTrue
        self.assertTrue(int1 == 0, f"'{int1}' != '0'")

if __name__ == '__main__':
    unittest.main()