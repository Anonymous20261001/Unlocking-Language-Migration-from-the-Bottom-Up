import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathNextUp(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_nextUp_test_11691(self):
        # Test nextUp with a float value close to -1.0
        float1 = self.strict_math.nextUp(-1.0000001)
        
        # Assert that the result equals -1.0
        self.assertTrue(float1 == -1.0, 
                       f"'{float1}' != '{-1.0}'")
        
        # Additional assertion to verify the exact value
        self.assertEqual(float1, -1.0)

if __name__ == '__main__':
    unittest.main()