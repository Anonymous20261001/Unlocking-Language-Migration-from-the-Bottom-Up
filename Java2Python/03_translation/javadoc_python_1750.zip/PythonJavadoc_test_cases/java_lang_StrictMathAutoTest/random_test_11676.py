import unittest
import math
import random
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathRandom(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_random_test_11676(self):
        """
        Randoop-generated regression test for java.lang.StrictMath.random().
        Note: This test is inherently flaky because random() returns a random value.
        The original Java test was commented out due to this flakiness.
        """
        # Generate a random double value
        double0 = self.strict_math.random()
        
        # Verify that the result is a valid double in the range [0.0, 1.0)
        self.assertIsInstance(double0, float)
        self.assertGreaterEqual(double0, 0.0)
        self.assertLess(double0, 1.0)
        
        # Note: The original test checked for a specific value (0.9002435474900726)
        # but this is commented out because it's flaky (random values change each run)
        # Instead, we verify the basic properties of the random value
        
        # Additional verification that the random value is not always the same
        # Generate another random value and verify they're different (with high probability)
        double1 = self.strict_math.random()
        self.assertNotEqual(double0, double1, "Random values should not be identical")

if __name__ == '__main__':
    unittest.main()