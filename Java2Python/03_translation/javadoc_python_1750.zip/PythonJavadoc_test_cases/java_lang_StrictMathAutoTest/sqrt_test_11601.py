import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathSqrt(unittest.TestCase):
    
    def test_sqrt_test_11601(self):
        """Test sqrt of negative number returns NaN"""
        wrapper = StrictMathWrapper()
        
        # Test sqrt of -9
        result = wrapper.sqrt(-9)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(result))
        
        # Additional verification that the result is indeed NaN
        self.assertNotEqual(result, result)  # NaN is not equal to itself

if __name__ == '__main__':
    unittest.main()