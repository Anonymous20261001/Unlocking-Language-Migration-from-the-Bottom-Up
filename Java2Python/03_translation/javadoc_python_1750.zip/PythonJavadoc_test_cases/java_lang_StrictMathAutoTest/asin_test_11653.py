import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathAsin(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_asin_test_11653(self):
        # Test asin with value 101 (out of domain [-1, 1])
        # Java's StrictMath.asin(101) returns NaN
        double1 = self.strict_math.asin(101)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(double1))

if __name__ == '__main__':
    unittest.main()