import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathRint(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_rint_test_11616(self):
        """Randoop-generated regression test for StrictMath.rint()."""
        double1 = self.strict_math.rint(3.141592653589793)
        self.assertTrue(double1 == 3.0, 
                        f"'{double1}' != '{3.0}'")
        
        # Additional assertion to match Java's behavior more closely
        self.assertEqual(double1, 3.0)

if __name__ == '__main__':
    unittest.main()