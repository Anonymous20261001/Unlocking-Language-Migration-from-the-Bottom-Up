import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathAtan2(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_atan2_test_11600(self):
        """Randoop-generated regression test for java.lang.StrictMath.atan2()."""
        # Java: java.lang.StrictMath.atan2((double) 1L, 22025.465794806718d)
        # (double) 1L is 1.0 in Java
        result = self.strict_math.atan2(1.0, 22025.465794806718)
        
        # Expected value from Java test
        expected = 4.540199097849144E-5
        
        # Assert the result matches the expected value
        self.assertEqual(result, expected, 
                         f"'{result}' != '{expected}'")

if __name__ == '__main__':
    unittest.main()