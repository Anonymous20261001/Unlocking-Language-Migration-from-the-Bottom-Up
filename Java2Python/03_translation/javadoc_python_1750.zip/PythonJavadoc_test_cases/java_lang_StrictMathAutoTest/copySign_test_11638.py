import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathCopySign(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_copySign_test_11638(self):
        # Test copySign with 0.0f and 6.0f
        # Java: float float2 = java.lang.StrictMath.copySign(0.0f, (float) 6);
        # This should return 0.0f since the magnitude is 0.0
        result = self.strict_math.copySign(0.0, 6.0)
        
        # Assert that the result equals 0.0
        self.assertEqual(result, 0.0)
        
        # Additional assertion to match Java's float comparison
        self.assertTrue(result == 0.0)

if __name__ == '__main__':
    unittest.main()