import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathNextAfter(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_nextAfter_test_11690(self):
        """Randoop-generated regression test for java.lang.StrictMath.nextAfter()."""
        # Test nextAfter with NaN and 200.0
        result = self.strict_math.nextAfter(float('nan'), 200.0)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()