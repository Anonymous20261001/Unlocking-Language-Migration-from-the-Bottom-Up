import unittest
import math
from generated.test.StrictMathWrapper import StrictMathWrapper

class TestStrictMathMultiplyFull(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_multiplyFull_test_11684(self):
        # Test: java.lang.StrictMath.multiplyFull(6, (int) (short) 1)
        # Expected result: 6L
        
        # In Java: (short) 1 casts 1 to short, then (int) casts it back to int
        # In Python, we can just use 1 directly since Python handles this automatically
        short_value = 1
        int_value = int(short_value)
        
        # Call multiplyFull with the values
        result = self.strict_math.multiplyFull(6, int_value)
        
        # Assert the result equals 6
        self.assertEqual(result, 6, f"Expected 6 but got {result}")
        
        # Additional assertion to match Java's long type behavior
        self.assertIsInstance(result, int, "Result should be an integer")

if __name__ == '__main__':
    unittest.main()