import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathMax(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_max_test_11610(self):
        """Randoop-generated regression test for StrictMath.max()."""
        int2 = self.strict_math.max(1, 1)
        self.assertEqual(int2, 1, f"'{int2}' != '{1}'")
    
if __name__ == '__main__':
    unittest.main()