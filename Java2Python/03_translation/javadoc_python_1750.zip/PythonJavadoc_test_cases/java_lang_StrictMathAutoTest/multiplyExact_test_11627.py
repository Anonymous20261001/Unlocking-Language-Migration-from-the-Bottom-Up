import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathMultiplyExact(unittest.TestCase):
    
    def test_multiplyExact_11627(self):
        """Randoop-generated regression test for StrictMath.multiplyExact()."""
        wrapper = StrictMathWrapper()
        
        # Test: multiplyExact(0L, 10) should return 0L
        result = wrapper.multiplyExact(0, 10)
        
        # Assert the result equals 0
        self.assertEqual(result, 0, f"'{result}' != '0'")
        
        # Also verify it's an integer type
        self.assertIsInstance(result, int, f"Result should be an integer, got {type(result)}")

if __name__ == '__main__':
    unittest.main()