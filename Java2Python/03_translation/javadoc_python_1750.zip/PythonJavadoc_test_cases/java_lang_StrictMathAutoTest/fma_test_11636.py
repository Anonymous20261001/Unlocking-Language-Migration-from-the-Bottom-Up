import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathFma(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_fma_test_11636(self):
        # Test: java.lang.StrictMath.fma((double) 35L, 0.19334632705655574d, Double.NaN)
        # Expected: Double.isNaN(double3) should be True
        
        # Convert 35L to double (in Python, integers are arbitrary precision, 
        # but we need to ensure it's treated as a float for the fma operation)
        a = float(35)
        b = 0.19334632705655574
        c = float('nan')
        
        # Call the fma method
        result = self.strict_math.fma(a, b, c)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(result), f"Expected NaN but got {result}")

if __name__ == '__main__':
    unittest.main()