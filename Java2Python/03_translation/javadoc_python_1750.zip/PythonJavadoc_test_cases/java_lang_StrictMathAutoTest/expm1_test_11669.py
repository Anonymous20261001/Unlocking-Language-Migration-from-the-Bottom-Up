import unittest
import math
from generated.test.StrictMathWrapper import StrictMathWrapper

class TestJavaLangStrictMathAutoTest(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_expm1_test_11669(self):
        """Randoop-generated regression test for java.lang.StrictMath.expm1()."""
        double1 = self.strict_math.expm1(10.0)
        self.assertTrue(double1 == 22025.465794806718, 
                       f"'{double1}' != '22025.465794806718'")

if __name__ == '__main__':
    unittest.main()