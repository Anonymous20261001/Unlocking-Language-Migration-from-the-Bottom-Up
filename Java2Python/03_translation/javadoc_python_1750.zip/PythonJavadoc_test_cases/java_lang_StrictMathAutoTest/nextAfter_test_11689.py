import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathNextAfter(unittest.TestCase):
    
    def test_nextAfter_test_11689(self):
        """Randoop-generated regression test for StrictMath.nextAfter()."""
        wrapper = StrictMathWrapper()
        
        # Test nextAfter with NaN and 200.0
        result = wrapper.nextAfter(float('nan'), 200.0)
        
        # Assert that the result is NaN
        self.assertTrue(math.isnan(result))

if __name__ == '__main__':
    unittest.main()