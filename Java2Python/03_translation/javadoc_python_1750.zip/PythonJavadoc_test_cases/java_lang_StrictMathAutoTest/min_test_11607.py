import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathMin(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_min_test_11607(self):
        """Randoop-generated regression test for StrictMath.min()."""
        # Test: min(-1, 53) should return -1
        int2 = self.strict_math.min(-1, 53)
        self.assertEqual(int2, -1, f"'{int2}' != '{-1}'")
        self.assertTrue(int2 == -1, f"'{int2}' != '{-1}'")

if __name__ == '__main__':
    unittest.main()