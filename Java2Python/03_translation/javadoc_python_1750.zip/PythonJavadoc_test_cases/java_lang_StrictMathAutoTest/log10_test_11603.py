import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathLog10(unittest.TestCase):
    
    def test_log10_test_11603(self):
        """Randoop-generated regression test for StrictMath.log10()."""
        wrapper = StrictMathWrapper()
        
        # Test log10(100) should equal 2.0
        double1 = wrapper.log10(float(100))
        
        # Assert that the result equals 2.0
        self.assertTrue(double1 == 2.0, 
                       f"'{double1}' != '{2.0d}'" if hasattr(2.0, 'd') else 
                       f"'{double1}' != '{2.0}'")
        
        # Alternative assertion using assertEqual for better error messages
        # self.assertEqual(double1, 2.0, f"log10(100) should be 2.0, got {double1}")

if __name__ == '__main__':
    unittest.main()