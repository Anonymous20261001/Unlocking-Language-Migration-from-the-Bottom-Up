import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathTan(unittest.TestCase):
    
    def test_tan_test_11599(self):
        """Randoop-generated regression test for StrictMath.tan()"""
        wrapper = StrictMathWrapper()
        double1 = wrapper.tan(2.0)
        self.assertTrue(double1 == -2.185039863261519, 
                       f"'{double1}' != '{-2.185039863261519}'")

if __name__ == '__main__':
    unittest.main()