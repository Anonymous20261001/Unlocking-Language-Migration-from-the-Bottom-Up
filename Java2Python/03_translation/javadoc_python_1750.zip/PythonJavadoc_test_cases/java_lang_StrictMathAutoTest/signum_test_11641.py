import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathSignum(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_signum_test_11641(self):
        # Test signum with a small positive float value
        float1 = self.strict_math.signum(1.1920929E-7)
        
        # Assert that the result equals 1.0
        self.assertEqual(float1, 1.0, 
                         f"'{float1}' != '{1.0}'")
        # Alternative assertion using assertTrue for exact match
        self.assertTrue(float1 == 1.0, 
                        f"'{float1}' != '{1.0}'")

if __name__ == '__main__':
    unittest.main()