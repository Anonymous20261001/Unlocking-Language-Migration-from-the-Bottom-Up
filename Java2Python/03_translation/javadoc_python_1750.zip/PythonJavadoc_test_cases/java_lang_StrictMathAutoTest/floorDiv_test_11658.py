import unittest
import math
from StrictMathWrapper import StrictMathWrapper

class TestStrictMathFloorDiv(unittest.TestCase):
    
    def setUp(self):
        self.strict_math = StrictMathWrapper()
    
    def test_floorDiv_test_11658(self):
        # Test: java.lang.StrictMath.floorDiv(2L, 200) should return 0L
        result = self.strict_math.floorDiv(2, 200)
        self.assertEqual(result, 0, f"'{result}' != '{0}'")
        
        # Additional verification that the result is an integer
        self.assertIsInstance(result, int, "Result should be an integer")

if __name__ == '__main__':
    unittest.main()