import unittest
import math
from generated.test.StrictMathWrapper import StrictMathWrapper

class TestStrictMathMultiplyExact(unittest.TestCase):
    
    def test_multiplyExact_11629(self):
        """Randoop-generated regression test for StrictMath.multiplyExact()."""
        wrapper = StrictMathWrapper()
        
        # Test: multiplyExact(0L, 10) should return 0L
        result = wrapper.multiplyExact(0, 10)
        
        # Assert that the result equals 0
        self.assertEqual(result, 0, f"'{result}' != '0'")
        
        # Additional assertion to match the Java test's assertTrue with == comparison
        self.assertTrue(result == 0, f"'{result}' != '0'")

if __name__ == '__main__':
    unittest.main()