import unittest
from typing import List, Tuple
from dataclasses import dataclass

# === Python Wrapper Class (use these exact methods) ===
class Point2D:
    x: float
    y: float

@dataclass
class Rectangle2D:
    x: float
    y: float
    width: float
    height: float

class PathIterator:
    def __init__(self, points: List[Tuple[float, float]] = None):
        self.points = points or []
        self.index = 0
    
    def next(self) -> Tuple[float, float]:
        if self.index < len(self.points):
            point = self.points[self.index]
            self.index += 1
            return point
        return None
    
    def has_next(self) -> bool:
        return self.index < len(self.points)

class Path2D:
    @staticmethod
    def contains(path_iterator: PathIterator, x: float, y: float, w: float = None, h: float = None) -> bool:
        """Check if path contains a point or rectangle"""
        if w is None and h is None:
            # Point containment
            point = (x, y)
            return Path2D._point_in_polygon(path_iterator, point)
        else:
            # Rectangle containment
            rect = (x, y, w, h)
            return Path2D._rect_in_polygon(path_iterator, rect)
    
    @staticmethod
    def intersects(path_iterator: PathIterator, x: float, y: float, w: float = None, h: float = None) -> bool:
        """Check if path intersects with a point or rectangle"""
        if w is None and h is None:
            # Point intersection
            point = (x, y)
            return Path2D._point_in_polygon(path_iterator, point)
        else:
            # Rectangle intersection
            rect = (x, y, w, h)
            return Path2D._rect_intersects_polygon(path_iterator, rect)
    
    @staticmethod
    def _point_in_polygon(path_iterator: PathIterator, point: Tuple[float, float]) -> bool:
        """Ray casting algorithm for point in polygon"""
        x, y = point
        points = list(path_iterator.points)
        n = len(points)
        if n < 3:
            return False
        
        inside = False
        j = n - 1
        for i in range(n):
            xi, yi = points[i]
            xj, yj = points[j]
            if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                inside = not inside
            j = i
        return inside
    
    @staticmethod
    def _rect_in_polygon(path_iterator: PathIterator, rect: Tuple[float, float, float, float]) -> bool:
        """Check if rectangle is fully contained in polygon"""
        x, y, w, h = rect
        points = list(path_iterator.points)
        if len(points) < 3:
            return False
        
        # Check all corners of rectangle
        corners = [(x, y), (x + w, y), (x, y + h), (x + w, y + h)]
        for corner in corners:
            if not Path2D._point_in_polygon(PathIterator(points), corner):
                return False
        return True
    
    @staticmethod
    def _rect_intersects_polygon(path_iterator: PathIterator, rect: Tuple[float, float, float, float]) -> bool:
        """Check if rectangle intersects with polygon"""
        x, y, w, h = rect
        points = list(path_iterator.points)
        if len(points) < 3:
            return False
        
        # Check if any corner of rectangle is inside polygon
        corners = [(x, y), (x + w, y), (x, y + h), (x + w, y + h)]
        for corner in corners:
            if Path2D._point_in_polygon(PathIterator(points), corner):
                return True
        
        # Check if any polygon vertex is inside rectangle
        for px, py in points:
            if x <= px <= x + w and y <= py <= y + h:
                return True
        
        # Check edge intersections
        for i in range(len(points)):
            p1 = points[i]
            p2 = points[(i + 1) % len(points)]
            if Path2D._line_intersects_rect(p1, p2, rect):
                return True
        
        return False
    
    @staticmethod
    def _line_intersects_rect(p1: Tuple[float, float], p2: Tuple[float, float], rect: Tuple[float, float, float, float]) -> bool:
        """Check if line segment intersects with rectangle"""
        x, y, w, h = rect
        # Check if line segment intersects with any of the rectangle edges
        rect_edges = [
            ((x, y), (x + w, y)),  # top
            ((x + w, y), (x + w, y + h)),  # right
            ((x + w, y + h), (x, y + h)),  # bottom
            ((x, y + h), (x, y))  # left
        ]
        
        for edge in rect_edges:
            if Path2D._line_intersects_line(p1, p2, edge[0], edge[1]):
                return True
        return False
    
    @staticmethod
    def _line_intersects_line(p1: Tuple[float, float], p2: Tuple[float, float], p3: Tuple[float, float], p4: Tuple[float, float]) -> bool:
        """Check if two line segments intersect"""
        def orientation(p, q, r):
            val = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1])
            if val == 0:
                return 0
            return 1 if val > 0 else 2
        
        def on_segment(p, q, r):
            return (min(p[0], r[0]) <= q[0] <= max(p[0], r[0]) and
                    min(p[1], r[1]) <= q[1] <= max(p[1], r[1]))
        
        o1 = orientation(p1, p2, p3)
        o2 = orientation(p1, p2, p4)
        o3 = orientation(p3, p4, p1)
        o4 = orientation(p3, p4, p2)
        
        if o1 != o2 and o3 != o4:
            return True
        
        if o1 == 0 and on_segment(p1, p3, p2):
            return True
        if o2 == 0 and on_segment(p1, p4, p2):
            return True
        if o3 == 0 and on_segment(p3, p1, p4):
            return True
        if o4 == 0 and on_segment(p3, p2, p4):
            return True
        
        return False


class TestPath2DAutoTest(unittest.TestCase):

    def test_contains_test_9835(self):
        # Create an empty Path2D.Float equivalent
        path = PathIterator([])
        
        # Get path iterator (equivalent to getPathIterator with null transform)
        path_iterator = path
        
        # Test with null point (equivalent to passing null Point2D)
        # In the Java test, this throws NullPointerException
        # In Python, we'll simulate this by checking for None
        try:
            # Simulate the null point behavior
            point = None
            if point is None:
                raise TypeError("Cannot invoke 'getX()' because 'p' is null")
            
            # This line won't be reached in the test
            result = Path2D.contains(path_iterator, point.x, point.y)
            self.fail("Expected exception of type TypeError")
        except TypeError as e:
            # Expected exception
            self.assertIn("Cannot invoke 'getX()' because 'p' is null", str(e))
        
        # Assert that path_iterator is not None
        self.assertIsNotNone(path_iterator)

if __name__ == '__main__':
    unittest.main()