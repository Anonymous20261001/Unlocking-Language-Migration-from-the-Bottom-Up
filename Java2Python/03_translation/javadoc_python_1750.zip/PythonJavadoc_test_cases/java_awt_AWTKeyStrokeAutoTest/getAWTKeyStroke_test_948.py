import unittest
import sys
import os

# Add the parent directory to path to import the wrapper
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from AWTKeyStrokeWrapper import AWTKeyStrokeWrapper


class TestAWTKeyStroke(unittest.TestCase):
    """Test class for AWTKeyStrokeWrapper"""

    def test_getAWTKeyStroke_test_948(self):
        """Test getAWTKeyStroke with space character and zero modifiers"""
        # Create AWTKeyStroke with space character (32) and zero modifiers
        aWTKeyStroke2 = AWTKeyStrokeWrapper.getAWTKeyStroke(ord(' '), 0)
        
        # Get string representation
        str3 = aWTKeyStroke2.toString()
        
        # Get class of the object
        wildcardClass4 = aWTKeyStroke2.getClass()
        
        # Assertions
        self.assertIsNotNone(aWTKeyStroke2)
        self.assertEqual(str3, "pressed SPACE", 
                         f"'{str3}' != 'pressed SPACE'")
        self.assertIsNotNone(wildcardClass4)


if __name__ == '__main__':
    unittest.main()