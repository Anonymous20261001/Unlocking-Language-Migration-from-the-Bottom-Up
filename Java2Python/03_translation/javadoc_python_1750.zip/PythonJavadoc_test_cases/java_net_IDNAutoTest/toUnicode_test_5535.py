import unittest
import idna

class IDN:
    @staticmethod
    def toASCII(input, flag=0):
        return idna.encode(input, uts46=True).decode('ascii')
    
    @staticmethod
    def toUnicode(input, flag=0):
        return idna.decode(input)

class TestJavaNetIDN(unittest.TestCase):

    def test_toUnicode_test_5535(self):
        # Test toUnicode with empty string input
        str1 = IDN.toUnicode("")
        
        # Assert that the result equals the expected empty string
        self.assertEqual(str1, "", f"'{str1}' != '{''}'")

if __name__ == '__main__':
    unittest.main()