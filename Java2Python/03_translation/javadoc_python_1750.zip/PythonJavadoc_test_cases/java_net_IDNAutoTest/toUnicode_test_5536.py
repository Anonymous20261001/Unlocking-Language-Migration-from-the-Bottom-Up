import unittest
import idna

class IDN:
    @staticmethod
    def toASCII(input, flag=0):
        return idna.encode(input, uts46=True).decode('ascii')
    
    @staticmethod
    def toUnicode(input, flag=0):
        return idna.decode(input)

class TestJavaNetIDN(unittest.TestCase):

    def test_toUnicode_test_5536(self):
        p0 = ""
        p1 = 0
        result = IDN.toUnicode(p0, p1)
        self.assertEqual(result, "")

if __name__ == '__main__':
    unittest.main()