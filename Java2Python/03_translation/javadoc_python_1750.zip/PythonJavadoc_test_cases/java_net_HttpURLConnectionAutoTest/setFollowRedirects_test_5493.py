import unittest
from unittest.mock import patch
import sys
import os

# Add the path to the wrapper class if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class HttpURLConnectionWrapper:
    """Wrapper class mimicking java.net.HttpURLConnection static methods"""
    _follow_redirects = True
    
    @classmethod
    def setFollowRedirects(cls, set):
        """Set whether HTTP redirects should be automatically followed"""
        cls._follow_redirects = set
    
    @classmethod
    def getFollowRedirects(cls):
        """Get whether HTTP redirects should be automatically followed"""
        return cls._follow_redirects

class java_net_HttpURLConnectionAutoTest(unittest.TestCase):
    """Test class for java.net.HttpURLConnection.setFollowRedirects()"""
    
    def test_setFollowRedirects_test_5493(self):
        """Randoop-generated regression test for java.net.HttpURLConnection.setFollowRedirects()."""
        # Call the static method with true
        HttpURLConnectionWrapper.setFollowRedirects(True)
        
        # Verify the redirects are set to True
        self.assertTrue(HttpURLConnectionWrapper.getFollowRedirects())

if __name__ == '__main__':
    unittest.main()