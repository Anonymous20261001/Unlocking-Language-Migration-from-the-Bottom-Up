import unittest
from unittest.mock import patch
import sys
import os

# Add the path to the wrapper class if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class HttpURLConnectionWrapper:
    """Wrapper class mimicking java.net.HttpURLConnection static methods"""
    _follow_redirects = True
    
    @classmethod
    def setFollowRedirects(cls, set):
        """Set whether HTTP redirects should be automatically followed"""
        cls._follow_redirects = set
    
    @classmethod
    def getFollowRedirects(cls):
        """Get whether HTTP redirects should be automatically followed"""
        return cls._follow_redirects

class java_net_HttpURLConnectionAutoTest(unittest.TestCase):
    """Test class for HttpURLConnectionWrapper"""
    
    def test_getFollowRedirects_test_5494(self):
        """Randoop-generated regression test for HttpURLConnectionWrapper.getFollowRedirects()."""
        # Get the current value of follow redirects
        boolean0 = HttpURLConnectionWrapper.getFollowRedirects()
        
        # Assert that the value is True (matching the Java test expectation)
        self.assertTrue(boolean0 == True, f"'{boolean0}' != '{True}'")

if __name__ == '__main__':
    unittest.main()