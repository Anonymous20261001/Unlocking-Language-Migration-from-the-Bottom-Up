import unittest
from typing import Optional

# === Python Wrapper Class (use these exact methods) ===
class Printable:
    """Mock Printable class to match Java's java.awt.print.Printable"""
    pass


class PageFormat:
    """Mock PageFormat class to match Java's java.awt.print.PageFormat"""
    pass


class Book:
    """Python implementation of java.awt.print.Book"""
    
    def __init__(self):
        self._pages = []  # List of (Printable, PageFormat) tuples
        
    def getPrintable(self, page_index: int) -> Optional[Printable]:
        if 0 <= page_index < len(self._pages):
            return self._pages[page_index][0]
        raise IndexError("Page index out of range")
        
    def getPageFormat(self, page_index: int) -> Optional[PageFormat]:
        if 0 <= page_index < len(self._pages):
            return self._pages[page_index][1]
        raise IndexError("Page index out of range")
        
    def getNumberOfPages(self) -> int:
        return len(self._pages)
        
    def setPage(self, page_index: int, printable: Printable, page_format: PageFormat) -> None:
        if page_index < 0:
            raise IndexError("Page index cannot be negative")
        while len(self._pages) <= page_index:
            self._pages.append(None)
        self._pages[page_index] = (printable, page_format)
        
    def append(self, printable: Printable, page_format: PageFormat, num_pages: int = 1) -> None:
        for _ in range(num_pages):
            self._pages.append((printable, page_format))


class TestJavaAwtPrintBookAutoTest(unittest.TestCase):

    def test_getPageFormat_test_1764(self):
        # Create a new Book instance
        book0 = Book()
        
        # Get number of pages (should be 0)
        int1 = book0.getNumberOfPages()
        int2 = book0.getNumberOfPages()
        
        # The following exception was thrown during execution in test generation
        try:
            # Attempt to get page format at index 0 (should raise IndexError)
            pageFormat4 = book0.getPageFormat(0)
            self.fail("Expected exception of type IndexError; message: 0 >= 0")
        except IndexError as e:
            # Expected exception
            pass
        
        # Assert that the number of pages is 0
        self.assertTrue(int1 == 0, f"'{int1}' != '0'")
        self.assertTrue(int2 == 0, f"'{int2}' != '0'")


if __name__ == '__main__':
    unittest.main()