import unittest
from java.lang.invoke import MethodType

class MethodTypeWrapper:
    @staticmethod
    def methodType(*args):
        return MethodType.methodType(*args)
    
    @staticmethod
    def genericMethodType(*args):
        return MethodType.genericMethodType(*args)
    
    @staticmethod
    def fromMethodDescriptorString(*args):
        return MethodType.fromMethodDescriptorString(*args)

class TestGenericMethodType(unittest.TestCase):
    
    def test_genericMethodType_test_8928(self):
        # Create a generic method type with 10 parameters and include leading parameters
        method_type2 = MethodTypeWrapper.genericMethodType(10, True)
        
        # Get the class of the method type object
        wildcard_class3 = method_type2.getClass()
        
        # Assert that the method type object is not null
        self.assertIsNotNone(method_type2)
        
        # Assert that the class object is not null
        self.assertIsNotNone(wildcard_class3)

if __name__ == '__main__':
    unittest.main()