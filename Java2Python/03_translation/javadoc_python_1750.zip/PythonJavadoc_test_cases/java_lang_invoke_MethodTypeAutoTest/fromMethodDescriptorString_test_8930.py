import unittest
from java.lang.invoke import MethodType

class MethodTypeWrapper:
    @staticmethod
    def methodType(*args):
        return MethodType.methodType(*args)
    
    @staticmethod
    def genericMethodType(*args):
        return MethodType.genericMethodType(*args)
    
    @staticmethod
    def fromMethodDescriptorString(*args):
        return MethodType.fromMethodDescriptorString(*args)

class TestFromMethodDescriptorString(unittest.TestCase):
    
    def test_fromMethodDescriptorString_test_8930(self):
        # Test case: fromMethodDescriptorString_test_8930
        classLoader1 = None
        methodType2 = MethodTypeWrapper.fromMethodDescriptorString("(Ljava/lang/Object;)Ljava/lang/Object;", classLoader1)
        wildcardClass3 = methodType2.getClass()
        
        self.assertIsNotNone(methodType2)
        self.assertIsNotNone(wildcardClass3)

if __name__ == '__main__':
    unittest.main()