import unittest

class DataBufferWrapper:
    @staticmethod
    def getDataTypeSize(data_type):
        # Placeholder implementation - actual Java method returns size of data type
        sizes = {0: 8, 1: 16, 2: 32, 3: 32, 4: 64, 5: 32}
        if data_type not in sizes:
            raise ValueError(f"Invalid data type: {data_type}")
        return sizes[data_type]


class TestGetDataTypeSize(unittest.TestCase):
    """Randoop-generated regression test for DataBufferWrapper.getDataTypeSize()."""
    
    def test_getDataTypeSize_test_3173(self):
        """Test that getDataTypeSize(0) returns 8."""
        # Test with data type 0 (TYPE_BYTE)
        result = DataBufferWrapper.getDataTypeSize(0)
        
        # Assert the result equals 8
        self.assertEqual(result, 8, f"'{result}' != '8'")


if __name__ == '__main__':
    unittest.main()