import unittest
from unittest.mock import patch
import sys
import os

# Add the path to the wrapper class if needed
# sys.path.insert(0, os.path.dirname(__file__))

class GraphicsEnvironment:
    @staticmethod
    def isHeadless():
        # Simulate Java's GraphicsEnvironment.isHeadless()
        return True

    @staticmethod
    def getLocalGraphicsEnvironment():
        # Simulate Java's GraphicsEnvironment.getLocalGraphicsEnvironment()
        return GraphicsEnvironment()
    
    def getAvailableFontFamilyNames(self, locale=None):
        # Simulate Java's getAvailableFontFamilyNames method
        font_families = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", 
                        "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif"]
        return font_families


class TestGraphicsEnvironment(unittest.TestCase):
    """Test class for java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment()"""
    
    def test_getLocalGraphicsEnvironment_test_5149(self):
        """Randoop-generated regression test for java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment()."""
        
        # Get the local graphics environment
        graphics_environment = GraphicsEnvironment.getLocalGraphicsEnvironment()
        
        # Test with null locale
        locale = None
        str_array_2 = graphics_environment.getAvailableFontFamilyNames(locale)
        
        # Test without locale
        str_array_3 = graphics_environment.getAvailableFontFamilyNames()
        str_array_4 = graphics_environment.getAvailableFontFamilyNames()
        
        # Assertions
        self.assertIsNotNone(graphics_environment)
        self.assertIsNotNone(str_array_2)
        self.assertEqual(str_array_2, ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", 
                                      "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif"])
        self.assertIsNotNone(str_array_3)
        self.assertEqual(str_array_3, ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", 
                                      "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif"])
        self.assertIsNotNone(str_array_4)
        self.assertEqual(str_array_4, ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", 
                                      "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif"])


if __name__ == '__main__':
    unittest.main()