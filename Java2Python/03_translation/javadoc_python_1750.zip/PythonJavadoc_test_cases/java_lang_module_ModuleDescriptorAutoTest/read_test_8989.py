import unittest
import java.nio.ByteBuffer
from java.util.function import Supplier
from java.lang.module import ModuleDescriptor

class TestModuleDescriptorRead(unittest.TestCase):
    
    def test_read_test_8989(self):
        # Create a ByteBuffer with capacity 10 (short value 10)
        byteBuffer1 = java.nio.ByteBuffer.allocate(int((short) 10))
        
        # Create a duplicate of the buffer
        byteBuffer2 = byteBuffer1.duplicate()
        
        # Create a null supplier for Set<String>
        strSetSupplier3 = None
        
        # Test that reading with null supplier throws NullPointerException
        with self.assertRaises(java.lang.NullPointerException) as context:
            moduleDescriptor4 = ModuleDescriptor.read(byteBuffer2, strSetSupplier3)
        
        # Verify the exception message is null
        self.assertIsNone(context.exception.getMessage())
        
        # Verify the buffers are not null
        self.assertIsNotNone(byteBuffer1)
        self.assertIsNotNone(byteBuffer2)

if __name__ == '__main__':
    unittest.main()