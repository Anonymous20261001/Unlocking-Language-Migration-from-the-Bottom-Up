import unittest
from java.lang.module import ModuleDescriptor
from java.lang import IllegalArgumentException

class TestModuleDescriptor(unittest.TestCase):
    
    def test_newOpenModule_test_8993(self):
        """Randoop-generated regression test for ModuleDescriptor.newOpenModule()."""
        # The following exception was thrown during execution in test generation
        try:
            builder1 = ModuleDescriptor.newOpenModule("")
            self.fail("Expected exception of type IllegalArgumentException; message: : Invalid module name: '' is not a Java identifier")
        except IllegalArgumentException as e:
            # Expected exception.
            pass

if __name__ == '__main__':
    unittest.main()