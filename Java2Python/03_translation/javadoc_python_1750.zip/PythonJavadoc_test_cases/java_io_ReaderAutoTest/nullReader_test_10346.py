import unittest

class Reader:
    @staticmethod
    def nullReader():
        return NullReader()

    @staticmethod
    def of(char_sequence):
        return StringReader(char_sequence)


class NullReader:
    def read(self):
        return -1


class StringReader:
    def __init__(self, char_sequence):
        self.char_sequence = char_sequence

    def read(self):
        if not self.char_sequence:
            return -1
        char = self.char_sequence[0]
        self.char_sequence = self.char_sequence[1:]
        return ord(char)


class java_io_ReaderAutoTest(unittest.TestCase):
    
    def test_nullReader_test_10346(self):
        # Create a null reader
        reader0 = Reader.nullReader()
        
        # Create a char array with a single character '4'
        char_array2 = ['4']
        
        # Read from the null reader into the char array
        int3 = reader0.read(char_array2)
        
        # Get the class of the reader
        wildcard_class4 = reader0.__class__
        
        # Assertions
        self.assertIsNotNone(reader0)
        self.assertIsNotNone(char_array2)
        self.assertEqual(char_array2, ['4'])
        self.assertEqual(int3, -1)
        self.assertIsNotNone(wildcard_class4)


if __name__ == '__main__':
    unittest.main()