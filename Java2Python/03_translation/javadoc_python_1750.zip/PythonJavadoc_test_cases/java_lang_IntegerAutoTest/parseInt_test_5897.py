import unittest
from IntegerWrapper import IntegerWrapper

class TestIntegerParseInt(unittest.TestCase):
    
    def test_parseInt_test_5897(self):
        """Randoop-generated regression test for java.lang.Integer.parseInt()."""
        int2 = IntegerWrapper.parseInt("1100001", 3)
        self.assertTrue(f"'{int2}' != '{973}'", int2 == 973)

if __name__ == '__main__':
    unittest.main()