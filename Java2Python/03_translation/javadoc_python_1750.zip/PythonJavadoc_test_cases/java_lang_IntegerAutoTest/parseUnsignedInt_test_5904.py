import unittest

class IntegerWrapper:
    def __init__(self, value):
        self.value = value & 0xFFFFFFFF
    
    @staticmethod
    def _to_signed(value):
        return value - 0x100000000 if value >= 0x80000000 else value
    
    @classmethod
    def numberOfLeadingZeros(cls, i):
        if i == 0:
            return 32
        n = 0
        for j in range(31, -1, -1):
            if (i >> j) & 1:
                return 31 - j
        return 32
    
    @classmethod
    def numberOfTrailingZeros(cls, i):
        if i == 0:
            return 32
        n = 0
        while (i & 1) == 0:
            i >>= 1
            n += 1
        return n
    
    @classmethod
    def bitCount(cls, i):
        i = i - ((i >> 1) & 0x55555555)
        i = (i & 0x33333333) + ((i >> 2) & 0x33333333)
        i = (i + (i >> 4)) & 0x0f0f0f0f
        i = i + (i >> 8)
        i = i + (i >> 16)
        return i & 0x3f
    
    @staticmethod
    def min(a, b):
        return a if a < b else b
    
    @staticmethod
    def max(a, b):
        return a if a > b else b
    
    @staticmethod
    def signum(i):
        return (i > 0) - (i < 0)
    
    @classmethod
    def expand(cls, i, mask):
        result = 0
        m = 0
        for bit in range(32):
            if (mask >> bit) & 1:
                if (i >> m) & 1:
                    result |= (1 << bit)
                m += 1
        return cls._to_signed(result)
    
    @staticmethod
    def compareUnsigned(x, y):
        x &= 0xFFFFFFFF
        y &= 0xFFFFFFFF
        return (x > y) - (x < y)
    
    @staticmethod
    def divideUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError("Division by zero")
        dividend &= 0xFFFFFFFF
        divisor &= 0xFFFFFFFF
        return dividend // divisor
    
    @staticmethod
    def remainderUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError("Division by zero")
        dividend &= 0xFFFFFFFF
        divisor &= 0xFFFFFFFF
        return dividend % divisor
    
    @classmethod
    def reverse(cls, i):
        result = 0
        for bit in range(32):
            if (i >> bit) & 1:
                result |= (1 << (31 - bit))
        return cls._to_signed(result)
    
    @classmethod
    def reverseBytes(cls, i):
        i &= 0xFFFFFFFF
        return cls._to_signed(((i & 0xFF) << 24) | ((i & 0xFF00) << 8) | ((i & 0xFF0000) >> 8) | ((i >> 24) & 0xFF))
    
    @classmethod
    def compress(cls, i, mask):
        result = 0
        m = 0
        for bit in range(32):
            if (mask >> bit) & 1:
                if (i >> bit) & 1:
                    result |= (1 << m)
                m += 1
        return cls._to_signed(result)
    
    def compareTo(self, other):
        return (self.value > other) - (self.value < other)
    
    @staticmethod
    def compare(x, y):
        return (x > y) - (x < y)
    
    def byteValue(self):
        return self._to_signed(self.value & 0xFF)
    
    def shortValue(self):
        return self._to_signed(self.value & 0xFFFF)
    
    def intValue(self):
        return self._to_signed(self.value)
    
    def longValue(self):
        return self._to_signed(self.value)
    
    def floatValue(self):
        return float(self._to_signed(self.value))
    
    def doubleValue(self):
        return float(self._to_signed(self.value))
    
    @classmethod
    def valueOf(cls, *args):
        if len(args) == 1:
            if isinstance(args[0], str):
                return cls._to_signed(int(args[0], 10))
            else:
                return cls._to_signed(args[0])
        elif len(args) == 2:
            return cls._to_signed(int(args[0], args[1]))
        return None
    
    @classmethod
    def toHexString(cls, i):
        return format(cls._to_signed(i) & 0xFFFFFFFF, 'x')
    
    @classmethod
    def decode(cls, nm):
        nm = nm.strip()
        if nm.startswith('0x') or nm.startswith('0X'):
            return cls._to_signed(int(nm[2:], 16))
        elif nm.startswith('0') and len(nm) > 1:
            return cls._to_signed(int(nm[1:], 8))
        elif nm.startswith('#') and len(nm) > 1:
            return cls._to_signed(int(nm[1:], 16))
        else:
            return cls._to_signed(int(nm, 10))
    
    def resolveConstantDesc(self, lookup):
        return self.value
    
    def describeConstable(self):
        return self.value
    
    @classmethod
    def parseInt(cls, *args):
        if len(args) == 1:
            return cls._to_signed(int(args[0], 10))
        elif len(args) == 2:
            return cls._to_signed(int(args[0], args[1]))
        elif len(args) == 4:
            s, begin, end, radix = args
            return cls._to_signed(int(s[begin:end], radix))
        return None
    
    @staticmethod
    def toUnsignedLong(x):
        return x & 0xFFFFFFFF
    
    @staticmethod
    def sum(a, b):
        return a + b
    
    @classmethod
    def toUnsignedString(cls, *args):
        if len(args) == 1:
            return str(cls.toUnsignedLong(args[0]))
        elif len(args) == 2:
            i, radix = args
            i &= 0xFFFFFFFF
            if i == 0:
                return "0"
            digits = []
            while i > 0:
                digits.append(int(i % radix))
                i //= radix
            result = ""
            for d in reversed(digits):
                if d < 10:
                    result += str(d)
                else:
                    result += chr(ord('a') + d - 10)
            return result
        return None
    
    @classmethod
    def parseUnsignedInt(cls, *args):
        if len(args) == 1:
            return cls._to_signed(int(args[0], 10))
        elif len(args) == 2:
            return cls._to_signed(int(args[0], args[1]))
        elif len(args) == 4:
            s, begin, end, radix = args
            # Check bounds like Java's IndexOutOfBoundsException
            if begin < 0 or end > len(s) or begin > end:
                raise IndexError("Index out of bounds")
            return cls._to_signed(int(s[begin:end], radix))
        return None
    
    @classmethod
    def getInteger(cls, *args):
        if len(args) == 1:
            try:
                return cls.valueOf(args[0])
            except:
                return None
        elif len(args) == 2:
            try:
                return cls.valueOf(args[0])
            except:
                return args[1]
        return None
    
    @classmethod
    def toOctalString(cls, i):
        return format(cls._to_signed(i) & 0xFFFFFFFF, 'o')
    
    @classmethod
    def toBinaryString(cls, i):
        return format(cls._to_signed(i) & 0xFFFFFFFF, 'b')
    
    @classmethod
    def highestOneBit(cls, i):
        i &= 0xFFFFFFFF
        if i == 0:
            return 0
        i |= (i >> 1)
        i |= (i >> 2)
        i |= (i >> 4)
        i |= (i >> 8)
        i |= (i >> 16)
        return cls._to_signed(i - (i >> 1))
    
    @classmethod
    def lowestOneBit(cls, i):
        return cls._to_signed(i & (-i))
    
    @classmethod
    def rotateLeft(cls, i, distance):
        i &= 0xFFFFFFFF
        distance &= 31
        return cls._to_signed(((i << distance) | (i >> (32 - distance))) & 0xFFFFFFFF)
    
    @classmethod
    def rotateRight(cls, i, distance):
        i &= 0xFFFFFFFF
        distance &= 31
        return cls._to_signed(((i >> distance) | (i << (32 - distance))) & 0xFFFFFFFF)


class TestParseUnsignedInt(unittest.TestCase):
    
    def test_parseUnsignedInt_test_5904(self):
        """Test that parseUnsignedInt with invalid indices raises IndexError"""
        # Test that calling parseUnsignedInt with begin=1, end=0 (begin > end) raises IndexError
        with self.assertRaises(IndexError):
            IntegerWrapper.parseUnsignedInt("43", 1, 0, 0)
        
        # Additional test to verify the exception is raised as expected
        try:
            IntegerWrapper.parseUnsignedInt("43", 1, 0, 0)
            self.fail("Expected exception of type IndexError")
        except IndexError as e:
            # Expected exception
            pass


if __name__ == '__main__':
    unittest.main()