import unittest
from IntegerWrapper import IntegerWrapper

class TestParseInt5896(unittest.TestCase):
    """Randoop-generated regression test for IntegerWrapper.parseInt()."""
    
    def test_parseInt_5896(self):
        # Test parsing the string "0" as an integer
        int1 = IntegerWrapper.parseInt("0")
        
        # Assert that the parsed value equals 0
        self.assertTrue(
            f"'{int1}' != '{0}'",
            int1 == 0
        )

if __name__ == '__main__':
    unittest.main()