import unittest
from IntegerWrapper import IntegerWrapper

class TestJavaLangIntegerAutoTest(unittest.TestCase):
    
    def test_parseUnsignedInt_test_5903(self):
        """Randoop-generated regression test for java.lang.Integer.parseUnsignedInt()."""
        int1 = IntegerWrapper.parseUnsignedInt("31")
        self.assertTrue(f"'{int1}' != '{31}'", int1 == 31)

if __name__ == '__main__':
    unittest.main()