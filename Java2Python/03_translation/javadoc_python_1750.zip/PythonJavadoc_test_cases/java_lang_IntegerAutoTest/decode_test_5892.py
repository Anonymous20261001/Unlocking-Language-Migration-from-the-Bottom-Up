import unittest
from IntegerWrapper import IntegerWrapper

class TestIntegerDecode(unittest.TestCase):
    
    def test_decode_test_5892(self):
        """Randoop-generated regression test for IntegerWrapper.decode()."""
        int1 = IntegerWrapper.decode("0")
        self.assertTrue(f"'{int1}' != '{0}'", int1 == 0)

if __name__ == '__main__':
    unittest.main()