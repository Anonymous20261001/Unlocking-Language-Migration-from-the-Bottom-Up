import unittest
from unittest.mock import Mock, patch
import sys
import os

# Add the path to the wrapper class if needed
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the wrapper classes (assuming they're in the same directory)
from raster_wrapper import RasterWrapper, Point, DataBuffer, SampleModel


class TestCreateWritableRaster(unittest.TestCase):
    """Test case for RasterWrapper.create_writable_raster method"""
    
    def test_createWritableRaster_test_10332(self):
        """Test create_writable_raster with null SampleModel and Point"""
        
        # Create a mock SampleModel that will raise NullPointerException
        # when createDataBuffer is called
        sample_model = Mock(spec=SampleModel)
        sample_model.createDataBuffer.side_effect = NullPointerException(
            'Cannot invoke "java.awt.image.SampleModel.createDataBuffer()" because "sm" is null'
        )
        
        # Create a Point object
        point = Point(0, 0)
        
        # Get the string representation of the point
        point_str = str(point)
        
        # Create the wrapper instance
        wrapper = RasterWrapper()
        
        # Test that calling create_writable_raster with null sample model raises exception
        with self.assertRaises(NullPointerException) as context:
            wrapper.create_writable_raster(sample_model, point)
        
        # Verify the exception message
        self.assertEqual(
            str(context.exception),
            'Cannot invoke "java.awt.image.SampleModel.createDataBuffer()" because "sm" is null'
        )
        
        # Verify the point string representation
        self.assertEqual(point_str, "Point(x=0, y=0)")
        
        # Verify that createDataBuffer was called on the sample model
        sample_model.createDataBuffer.assert_called_once()


class NullPointerException(Exception):
    """Custom exception to simulate Java's NullPointerException"""
    pass


# Override the RasterWrapper.create_writable_raster to simulate Java behavior
def create_writable_raster_with_null_check(self, sample_model, point):
    """Simulate Java's Raster.createWritableRaster with null check"""
    if sample_model is None:
        raise NullPointerException(
            'Cannot invoke "java.awt.image.SampleModel.createDataBuffer()" because "sm" is null'
        )
    # If sample model is not None, try to create data buffer
    try:
        sample_model.createDataBuffer()
    except AttributeError:
        raise NullPointerException(
            'Cannot invoke "java.awt.image.SampleModel.createDataBuffer()" because "sm" is null'
        )
    return None


# Patch the RasterWrapper class to use our custom implementation
RasterWrapper.create_writable_raster = create_writable_raster_with_null_check


if __name__ == '__main__':
    unittest.main()