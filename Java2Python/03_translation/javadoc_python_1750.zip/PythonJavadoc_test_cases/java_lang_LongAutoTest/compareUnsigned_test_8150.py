import unittest
import ctypes

class Long:
    """Wrapper class mimicking Java's Long class"""
    
    def __init__(self, value):
        if isinstance(value, str):
            self.value = int(value)
        else:
            self.value = int(value)
    
    def compareTo(self, other):
        return (self.value > other) - (self.value < other)
    
    def byteValue(self):
        return ctypes.c_byte(self.value).value
    
    def shortValue(self):
        return ctypes.c_short(self.value).value
    
    def intValue(self):
        return ctypes.c_int(self.value).value
    
    def longValue(self):
        return self.value
    
    def floatValue(self):
        return float(self.value)
    
    def doubleValue(self):
        return float(self.value)
    
    def resolveConstantDesc(self, lookup):
        return self.value
    
    def describeConstable(self):
        return self.value
    
    @staticmethod
    def numberOfLeadingZeros(i):
        if i == 0:
            return 64
        return 64 - i.bit_length()
    
    @staticmethod
    def numberOfTrailingZeros(i):
        if i == 0:
            return 64
        return (i & -i).bit_length() - 1
    
    @staticmethod
    def bitCount(i):
        return bin(i & 0xFFFFFFFFFFFFFFFF).count('1')
    
    @staticmethod
    def min(a, b):
        return min(a, b)
    
    @staticmethod
    def max(a, b):
        return max(a, b)
    
    @staticmethod
    def signum(i):
        if i > 0:
            return 1
        elif i < 0:
            return -1
        return 0
    
    @staticmethod
    def expand(i, mask):
        result = 0
        m = 1
        for bit in range(64):
            if mask & (1 << bit):
                if i & m:
                    result |= (1 << bit)
                m <<= 1
        return result
    
    @staticmethod
    def compareUnsigned(x, y):
        x_unsigned = x & 0xFFFFFFFFFFFFFFFF
        y_unsigned = y & 0xFFFFFFFFFFFFFFFF
        return (x_unsigned > y_unsigned) - (x_unsigned < y_unsigned)
    
    @staticmethod
    def divideUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError
        dividend_unsigned = dividend & 0xFFFFFFFFFFFFFFFF
        divisor_unsigned = divisor & 0xFFFFFFFFFFFFFFFF
        return dividend_unsigned // divisor_unsigned
    
    @staticmethod
    def remainderUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError
        dividend_unsigned = dividend & 0xFFFFFFFFFFFFFFFF
        divisor_unsigned = divisor & 0xFFFFFFFFFFFFFFFF
        return dividend_unsigned % divisor_unsigned
    
    @staticmethod
    def reverse(i):
        return int('{:064b}'.format(i & 0xFFFFFFFFFFFFFFFF)[::-1], 2)
    
    @staticmethod
    def reverseBytes(i):
        return int.from_bytes(i.to_bytes(8, 'little'), 'big')
    
    @staticmethod
    def compress(i, mask):
        result = 0
        bit = 0
        for j in range(64):
            if mask & (1 << j):
                if i & (1 << j):
                    result |= (1 << bit)
                bit += 1
        return result
    
    @staticmethod
    def getLong(nm, val=None):
        # Simulate system property lookup (returns default value)
        if val is not None:
            return val if isinstance(val, Long) else Long(val)
        return None
    
    @staticmethod
    def compare(x, y):
        return (x > y) - (x < y)
    
    @staticmethod
    def valueOf(*args):
        if len(args) == 1:
            if isinstance(args[0], str):
                return Long(int(args[0]))
            return Long(args[0])
        elif len(args) == 2:
            return Long(int(args[0], args[1]))
        return None
    
    @staticmethod
    def toHexString(i):
        return hex(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def decode(nm):
        return Long(int(nm, 0))
    
    @staticmethod
    def sum(a, b):
        return a + b
    
    @staticmethod
    def toUnsignedString(i, radix=10):
        if i >= 0:
            return str(i)
        return str(i & 0xFFFFFFFFFFFFFFFF)
    
    @staticmethod
    def toOctalString(i):
        return oct(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def toBinaryString(i):
        return bin(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def highestOneBit(i):
        if i == 0:
            return 0
        return 1 << (i.bit_length() - 1)
    
    @staticmethod
    def lowestOneBit(i):
        return i & -i
    
    @staticmethod
    def rotateLeft(i, distance):
        distance %= 64
        return ((i << distance) | (i >> (64 - distance))) & 0xFFFFFFFFFFFFFFFF
    
    @staticmethod
    def rotateRight(i, distance):
        distance %= 64
        return ((i >> distance) | (i << (64 - distance))) & 0xFFFFFFFFFFFFFFFF
    
    @staticmethod
    def parseLong(s, radix=10):
        return int(s, radix)
    
    @staticmethod
    def parseUnsignedLong(s, radix=10):
        return int(s, radix) & 0xFFFFFFFFFFFFFFFF


class TestJavaLangLong(unittest.TestCase):

    def test_compareUnsigned_test_8150(self):
        # Test case: compareUnsigned(27L, 0L) should return 1
        # because 27 > 0 when compared as unsigned values
        result = Long.compareUnsigned(27, 0)
        self.assertEqual(result, 1, f"Expected 1 but got {result}")


if __name__ == '__main__':
    unittest.main()