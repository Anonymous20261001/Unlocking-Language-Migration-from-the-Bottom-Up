import unittest
from java.lang.management import ManagementFactory

class ManagementFactoryWrapper:
    """Wrapper class containing methods called by the tests"""
    
    @staticmethod
    def getPlatformMXBean(cls):
        return ManagementFactory.getPlatformMXBean(cls)
    
    @staticmethod
    def getPlatformMXBeans(cls):
        return ManagementFactory.getPlatformMXBeans(cls)
    
    @staticmethod
    def getClassLoadingMXBean():
        return ManagementFactory.getClassLoadingMXBean()
    
    @staticmethod
    def getMemoryMXBean():
        return ManagementFactory.getMemoryMXBean()
    
    @staticmethod
    def getThreadMXBean():
        return ManagementFactory.getThreadMXBean()
    
    @staticmethod
    def getRuntimeMXBean():
        return ManagementFactory.getRuntimeMXBean()
    
    @staticmethod
    def getCompilationMXBean():
        return ManagementFactory.getCompilationMXBean()
    
    @staticmethod
    def getOperatingSystemMXBean():
        return ManagementFactory.getOperatingSystemMXBean()
    
    @staticmethod
    def getMemoryPoolMXBeans():
        return ManagementFactory.getMemoryPoolMXBeans()
    
    @staticmethod
    def getMemoryManagerMXBeans():
        return ManagementFactory.getMemoryManagerMXBeans()
    
    @staticmethod
    def getGarbageCollectorMXBeans():
        return ManagementFactory.getGarbageCollectorMXBeans()
    
    @staticmethod
    def getPlatformMBeanServer():
        return ManagementFactory.getPlatformMBeanServer()
    
    @staticmethod
    def getPlatformManagementInterfaces():
        return ManagementFactory.getPlatformManagementInterfaces()

class TestManagementFactory(unittest.TestCase):
    """Test class for ManagementFactory operations"""
    
    def test_getOperatingSystemMXBean_test_8269(self):
        """Test getOperatingSystemMXBean method"""
        # Get the OperatingSystemMXBean instance
        operating_system_mx_bean = ManagementFactoryWrapper.getOperatingSystemMXBean()
        
        # Get the class of the returned object
        wildcard_class = operating_system_mx_bean.__class__
        
        # Assert that the object is not None
        self.assertIsNotNone(operating_system_mx_bean)
        
        # Assert that the class is not None
        self.assertIsNotNone(wildcard_class)

if __name__ == '__main__':
    unittest.main()