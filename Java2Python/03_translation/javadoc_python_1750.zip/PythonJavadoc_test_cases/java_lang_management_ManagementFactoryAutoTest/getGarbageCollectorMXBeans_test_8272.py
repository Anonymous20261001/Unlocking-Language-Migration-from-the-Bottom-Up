import unittest
from java.lang.management import ManagementFactory

class ManagementFactoryWrapper:
    """Wrapper class containing methods called by the tests"""
    
    @staticmethod
    def getPlatformMXBean(cls):
        return ManagementFactory.getPlatformMXBean(cls)
    
    @staticmethod
    def getPlatformMXBeans(cls):
        return ManagementFactory.getPlatformMXBeans(cls)
    
    @staticmethod
    def getClassLoadingMXBean():
        return ManagementFactory.getClassLoadingMXBean()
    
    @staticmethod
    def getMemoryMXBean():
        return ManagementFactory.getMemoryMXBean()
    
    @staticmethod
    def getThreadMXBean():
        return ManagementFactory.getThreadMXBean()
    
    @staticmethod
    def getRuntimeMXBean():
        return ManagementFactory.getRuntimeMXBean()
    
    @staticmethod
    def getCompilationMXBean():
        return ManagementFactory.getCompilationMXBean()
    
    @staticmethod
    def getOperatingSystemMXBean():
        return ManagementFactory.getOperatingSystemMXBean()
    
    @staticmethod
    def getMemoryPoolMXBeans():
        return ManagementFactory.getMemoryPoolMXBeans()
    
    @staticmethod
    def getMemoryManagerMXBeans():
        return ManagementFactory.getMemoryManagerMXBeans()
    
    @staticmethod
    def getGarbageCollectorMXBeans():
        return ManagementFactory.getGarbageCollectorMXBeans()
    
    @staticmethod
    def getPlatformMBeanServer():
        return ManagementFactory.getPlatformMBeanServer()
    
    @staticmethod
    def getPlatformManagementInterfaces():
        return ManagementFactory.getPlatformManagementInterfaces()


class TestManagementFactory(unittest.TestCase):
    """Test class for ManagementFactory wrapper methods"""
    
    def test_getGarbageCollectorMXBeans_test_8272(self):
        """Test that getGarbageCollectorMXBeans returns a non-null list"""
        # Call the method through the wrapper
        garbage_collector_mx_bean_list = ManagementFactoryWrapper.getGarbageCollectorMXBeans()
        
        # Assert that the result is not None
        self.assertIsNotNone(garbage_collector_mx_bean_list)
        
        # Get the class of the returned object
        wildcard_class = garbage_collector_mx_bean_list.__class__
        
        # Assert that the class is not None
        self.assertIsNotNone(wildcard_class)
        
        # Additional assertions to match Java behavior
        # The result should be a list
        self.assertIsInstance(garbage_collector_mx_bean_list, list)
        
        # The list should not be empty (as there's typically at least one GC)
        self.assertGreater(len(garbage_collector_mx_bean_list), 0)


if __name__ == '__main__':
    unittest.main()