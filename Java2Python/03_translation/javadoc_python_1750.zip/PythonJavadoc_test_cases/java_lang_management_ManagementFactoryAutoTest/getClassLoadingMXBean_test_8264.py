import unittest
from java.lang.management import ManagementFactory

class ManagementFactoryWrapper:
    """Wrapper class containing methods called by the tests"""
    
    @staticmethod
    def getPlatformMXBean(cls):
        return ManagementFactory.getPlatformMXBean(cls)
    
    @staticmethod
    def getPlatformMXBeans(cls):
        return ManagementFactory.getPlatformMXBeans(cls)
    
    @staticmethod
    def getClassLoadingMXBean():
        return ManagementFactory.getClassLoadingMXBean()
    
    @staticmethod
    def getMemoryMXBean():
        return ManagementFactory.getMemoryMXBean()
    
    @staticmethod
    def getThreadMXBean():
        return ManagementFactory.getThreadMXBean()
    
    @staticmethod
    def getRuntimeMXBean():
        return ManagementFactory.getRuntimeMXBean()
    
    @staticmethod
    def getCompilationMXBean():
        return ManagementFactory.getCompilationMXBean()
    
    @staticmethod
    def getOperatingSystemMXBean():
        return ManagementFactory.getOperatingSystemMXBean()
    
    @staticmethod
    def getMemoryPoolMXBeans():
        return ManagementFactory.getMemoryPoolMXBeans()
    
    @staticmethod
    def getMemoryManagerMXBeans():
        return ManagementFactory.getMemoryManagerMXBeans()
    
    @staticmethod
    def getGarbageCollectorMXBeans():
        return ManagementFactory.getGarbageCollectorMXBeans()
    
    @staticmethod
    def getPlatformMBeanServer():
        return ManagementFactory.getPlatformMBeanServer()
    
    @staticmethod
    def getPlatformManagementInterfaces():
        return ManagementFactory.getPlatformManagementInterfaces()


class TestManagementFactory(unittest.TestCase):
    """Test class for ManagementFactory wrapper methods"""
    
    def test_getClassLoadingMXBean_test_8264(self):
        """Test getClassLoadingMXBean method"""
        # Get the ClassLoadingMXBean instance
        class_loading_mx_bean = ManagementFactoryWrapper.getClassLoadingMXBean()
        
        # Assert that the bean is not null
        self.assertIsNotNone(class_loading_mx_bean)
        
        # Get the class of the bean
        bean_class = class_loading_mx_bean.getClass()
        
        # Assert that the class is not null
        self.assertIsNotNone(bean_class)


if __name__ == '__main__':
    unittest.main()