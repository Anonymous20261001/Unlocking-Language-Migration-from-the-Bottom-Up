import unittest
from math import sqrt

class QuadCurve2D:
    @staticmethod
    def getFlatnessSq(*args):
        if len(args) == 6:
            x1, y1, ctrlx, ctrly, x2, y2 = args
            return (ctrlx - x1) ** 2 + (ctrly - y1) ** 2 + (ctrlx - x2) ** 2 + (ctrly - y2) ** 2
        elif len(args) == 2 and isinstance(args[0], (list, tuple)):
            coords, offset = args
            x1, y1 = coords[offset], coords[offset + 1]
            ctrlx, ctrly = coords[offset + 2], coords[offset + 3]
            x2, y2 = coords[offset + 4], coords[offset + 5]
            return (ctrlx - x1) ** 2 + (ctrly - y1) ** 2 + (ctrlx - x2) ** 2 + (ctrly - y2) ** 2
        raise ValueError("Invalid arguments")

    @staticmethod
    def getFlatness(*args):
        if len(args) == 6:
            return sqrt(QuadCurve2D.getFlatnessSq(*args))
        elif len(args) == 2 and isinstance(args[0], (list, tuple)):
            coords, offset = args
            return sqrt(QuadCurve2D.getFlatnessSq(coords, offset))
        raise ValueError("Invalid arguments")

    @staticmethod
    def subdivide(*args):
        if len(args) == 6:
            src, srcOff, left, leftOff, right, rightOff = args
            x1, y1 = src[srcOff], src[srcOff + 1]
            ctrlx, ctrly = src[srcOff + 2], src[srcOff + 3]
            x2, y2 = src[srcOff + 4], src[srcOff + 5]
            
            left[leftOff] = x1
            left[leftOff + 1] = y1
            left[leftOff + 2] = (x1 + ctrlx) / 2
            left[leftOff + 3] = (y1 + ctrly) / 2
            left[leftOff + 4] = (x1 + 2 * ctrlx + x2) / 4
            left[leftOff + 5] = (y1 + 2 * ctrly + y2) / 4
            
            right[rightOff] = (x1 + 2 * ctrlx + x2) / 4
            right[rightOff + 1] = (y1 + 2 * ctrly + y2) / 4
            right[rightOff + 2] = (ctrlx + x2) / 2
            right[rightOff + 3] = (ctrly + y2) / 2
            right[rightOff + 4] = x2
            right[rightOff + 5] = y2
        elif len(args) == 3:
            curve, left, right = args
            x1, y1 = curve.getP1()
            ctrlx, ctrly = curve.getCtrlPt()
            x2, y2 = curve.getP2()
            left.setCurve(x1, y1, (x1 + ctrlx) / 2, (y1 + ctrly) / 2, 
                          (x1 + 2 * ctrlx + x2) / 4, (y1 + 2 * ctrly + y2) / 4)
            right.setCurve((x1 + 2 * ctrlx + x2) / 4, (y1 + 2 * ctrly + y2) / 4,
                           (ctrlx + x2) / 2, (ctrly + y2) / 2, x2, y2)
        else:
            raise ValueError("Invalid arguments")

    @staticmethod
    def solveQuadratic(eq, roots=None):
        if roots is None:
            roots = []
        a, b, c = eq[0], eq[1], eq[2]
        if a == 0:
            if b != 0:
                roots.append(-c / b)
        else:
            disc = b * b - 4 * a * c
            if disc >= 0:
                sqrt_disc = sqrt(disc)
                roots.append((-b + sqrt_disc) / (2 * a))
                roots.append((-b - sqrt_disc) / (2 * a))
        return roots


class QuadCurve2DWrapper:
    @staticmethod
    def getFlatnessSq(p0, p1, p2=None, p3=None, p4=None, p5=None):
        if p2 is not None and p3 is not None and p4 is not None and p5 is not None:
            return QuadCurve2D.getFlatnessSq(p0, p1, p2, p3, p4, p5)
        return QuadCurve2D.getFlatnessSq(p0, p1)

    @staticmethod
    def getFlatness(p0, p1, p2=None, p3=None, p4=None, p5=None):
        if p2 is not None and p3 is not None and p4 is not None and p5 is not None:
            return QuadCurve2D.getFlatness(p0, p1, p2, p3, p4, p5)
        return QuadCurve2D.getFlatness(p0, p1)

    @staticmethod
    def subdivide(p0, p1, p2=None, p3=None, p4=None, p5=None):
        if p2 is not None and p3 is not None and p4 is not None and p5 is not None:
            return QuadCurve2D.subdivide(p0, p1, p2, p3, p4, p5)
        return QuadCurve2D.subdivide(p0, p1, p2)

    @staticmethod
    def solveQuadratic(p0, p1=None):
        if p1 is not None:
            return QuadCurve2D.solveQuadratic(p0, p1)
        return QuadCurve2D.solveQuadratic(p0)


class TestQuadCurve2D(unittest.TestCase):

    def test_solveQuadratic_test_10241(self):
        # Test with coefficients [100.0, 0.0, 100.0]
        # This represents the equation: 100x² + 0x + 100 = 0
        # The discriminant is 0² - 4*100*100 = -40000 < 0
        # So there are no real roots, and the method should return 0 roots
        
        eq = [100.0, 0.0, 100.0]
        roots = []
        result = QuadCurve2DWrapper.solveQuadratic(eq, roots)
        
        # Verify the input array is unchanged
        self.assertEqual(eq, [100.0, 0.0, 100.0])
        
        # Verify the roots list is empty (no real solutions)
        self.assertEqual(len(roots), 0)
        
        # Verify the return value is 0 (number of roots found)
        self.assertEqual(result, 0)


if __name__ == '__main__':
    unittest.main()