import unittest
from unittest.mock import Mock, patch
import sys
import os

# Add path to find the wrapper class if needed
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class DynamicCallSiteDesc:
    @staticmethod
    def of(p0, p1, p2=None, p3=None):
        """
        Static factory method mimicking Java's DynamicCallSiteDesc.of()
        Supports 2, 3, or 4 arguments
        """
        if p2 is None and p3 is None:
            # 2-argument version: of(DirectMethodHandleDesc, MethodTypeDesc)
            return DynamicCallSiteDesc(p0, p1)
        elif p3 is None:
            # 3-argument version: of(DirectMethodHandleDesc, String, MethodTypeDesc)
            return DynamicCallSiteDesc(p0, p2, invocation_name=p1)
        else:
            # 4-argument version: of(DirectMethodHandleDesc, String, MethodTypeDesc, ConstantDesc[])
            return DynamicCallSiteDesc(p0, p2, invocation_name=p1, bootstrap_args=p3)
    
    def __init__(self, bootstrap_method, invocation_type, invocation_name=None, bootstrap_args=None):
        self.bootstrap_method = bootstrap_method
        self.invocation_type = invocation_type
        self.invocation_name = invocation_name
        self.bootstrap_args = bootstrap_args or []


class TestDynamicCallSiteDesc(unittest.TestCase):

    def test_of_test_4419(self):
        """Test that of() raises NullPointerException when bootstrap method is null"""
        # Setup test data matching the Java test
        p0 = None  # DirectMethodHandleDesc placeholder (null in Java test)
        p1 = "hi!"  # Method name string
        p2 = None  # MethodTypeDesc placeholder (null in Java test)
        
        # Verify that calling of() with null bootstrap method raises an exception
        with self.assertRaises(Exception) as context:
            DynamicCallSiteDesc.of(p0, p1, p2)
        
        # Verify the exception type matches Java's NullPointerException
        self.assertIsInstance(context.exception, (TypeError, ValueError, Exception))
        
        # Additional verification that the exception is raised
        self.assertTrue(context.exception is not None)
        
        # Verify the exception message if it's a TypeError (Python's closest to NPE)
        if isinstance(context.exception, TypeError):
            self.assertIn("None", str(context.exception))


if __name__ == '__main__':
    unittest.main()