import unittest
from unittest.mock import MagicMock

# Python Wrapper Class (use these exact methods)
class DynamicCallSiteDesc:
    @staticmethod
    def of(p0, p1, p2=None, p3=None):
        """
        Static factory method mimicking Java's DynamicCallSiteDesc.of()
        Supports 2, 3, or 4 arguments
        """
        if p2 is None and p3 is None:
            # 2-argument version: of(DirectMethodHandleDesc, MethodTypeDesc)
            return DynamicCallSiteDesc(p0, p1)
        elif p3 is None:
            # 3-argument version: of(DirectMethodHandleDesc, String, MethodTypeDesc)
            return DynamicCallSiteDesc(p0, p2, invocation_name=p1)
        else:
            # 4-argument version: of(DirectMethodHandleDesc, String, MethodTypeDesc, ConstantDesc[])
            return DynamicCallSiteDesc(p0, p2, invocation_name=p1, bootstrap_args=p3)
    
    def __init__(self, bootstrap_method, invocation_type, invocation_name=None, bootstrap_args=None):
        self.bootstrap_method = bootstrap_method
        self.invocation_type = invocation_type
        self.invocation_name = invocation_name
        self.bootstrap_args = bootstrap_args or []


class TestDynamicCallSiteDesc(unittest.TestCase):

    def test_of_test_4417(self):
        # Setup test data
        p0 = None  # DirectMethodHandleDesc placeholder (null)
        p1 = "hi!"  # String invocation name
        p2 = None  # MethodTypeDesc placeholder (null)
        p3 = []  # ConstantDesc[] placeholder (empty array)
        
        # Verify the input array is empty before the call
        self.assertEqual(p3, [])
        
        # Test that calling of() with null bootstrap method raises an exception
        with self.assertRaises(Exception) as context:
            DynamicCallSiteDesc.of(p0, p1, p2, p3)
        
        # Verify an exception was raised (in Java this would be NullPointerException)
        self.assertTrue(context.exception is not None)
        
        # Verify the array is still empty after the call (unchanged)
        self.assertEqual(p3, [])
        
        # Additional assertion to match Java's assertArrayEquals
        self.assertListEqual(p3, [])


if __name__ == '__main__':
    unittest.main()