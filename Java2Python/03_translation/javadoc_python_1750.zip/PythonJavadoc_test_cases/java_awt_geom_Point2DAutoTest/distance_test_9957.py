import math
import unittest


class Point2DWrapper:
    @staticmethod
    def distanceSq(x1, y1, x2, y2):
        return (x1 - x2) ** 2 + (y1 - y2) ** 2
    
    @staticmethod
    def distance(x1, y1, x2, y2):
        return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


class TestPoint2D(unittest.TestCase):
    
    def test_distance_test_9957(self):
        # Test case: distance((double) 'a', (double) (short) 1, (double) 10, 1.0d)
        # 'a' = 97, (short) 1 = 1
        double4 = Point2DWrapper.distance(97.0, 1.0, 10.0, 1.0)
        self.assertTrue(double4 == 87.0, f"'{double4}' != '87.0'")


if __name__ == '__main__':
    unittest.main()