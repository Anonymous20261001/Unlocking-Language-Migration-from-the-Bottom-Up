import math
import unittest

class Point2DWrapper:
    @staticmethod
    def distanceSq(x1, y1, x2, y2):
        return (x1 - x2) ** 2 + (y1 - y2) ** 2
    
    @staticmethod
    def distance(x1, y1, x2, y2):
        return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

class TestPoint2DWrapper(unittest.TestCase):
    
    def test_distanceSq_test_9956(self):
        # Test case: distanceSq(1.0, 1.0, 0.0, 100.0) should equal 9802.0
        double4 = Point2DWrapper.distanceSq(1.0, 1.0, 0.0, 100.0)
        self.assertTrue(double4 == 9802.0, 
                       f"'{double4}' != '9802.0'")

if __name__ == '__main__':
    unittest.main()