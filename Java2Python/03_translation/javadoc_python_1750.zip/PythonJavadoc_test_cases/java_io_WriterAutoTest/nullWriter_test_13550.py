import unittest
from io import StringIO

class Writer:
    @staticmethod
    def nullWriter():
        return StringIO()

class TestWriterMethods(unittest.TestCase):

    def test_nullWriter_test_13550(self):
        writer0 = Writer.nullWriter()
        wildcardClass1 = writer0.__class__
        self.assertIsNotNone(writer0)
        self.assertIsNotNone(wildcardClass1)

if __name__ == '__main__':
    unittest.main()