import unittest
from unittest.mock import Mock, patch
import sys
import os

class ClassLoaderWrapper:
    @staticmethod
    def get_platform_class_loader():
        return None

    @staticmethod
    def get_system_class_loader():
        return None

    @staticmethod
    def get_system_resource_as_stream(name):
        return None

    @staticmethod
    def get_system_resource(name):
        return None


class TestGetSystemClassLoader(unittest.TestCase):
    
    def test_getSystemClassLoader_test_2315(self):
        """Randoop-generated regression test for ClassLoader.getSystemClassLoader()."""
        
        # Mock the system class loader
        mock_system_loader = Mock()
        mock_parent_loader = Mock()
        
        # Set up the mock hierarchy
        mock_system_loader.getParent.return_value = mock_parent_loader
        
        # Patch the static method to return our mock
        with patch.object(ClassLoaderWrapper, 'get_system_class_loader', return_value=mock_system_loader):
            # Get the system class loader
            class_loader0 = ClassLoaderWrapper.get_system_class_loader()
            
            # Get its parent
            class_loader1 = class_loader0.getParent()
            
            # Get the class of the loader (simulating getClass())
            wildcard_class2 = type(class_loader0)
            
            # Assertions
            self.assertIsNotNone(class_loader0)
            self.assertIsNotNone(class_loader1)
            self.assertIsNotNone(wildcard_class2)
            
            # Additional verification that the mock was called correctly
            mock_system_loader.getParent.assert_called_once()
            
            # Verify the class is a Mock class (simulating the Java Class object)
            self.assertEqual(wildcard_class2, Mock)


if __name__ == '__main__':
    unittest.main()