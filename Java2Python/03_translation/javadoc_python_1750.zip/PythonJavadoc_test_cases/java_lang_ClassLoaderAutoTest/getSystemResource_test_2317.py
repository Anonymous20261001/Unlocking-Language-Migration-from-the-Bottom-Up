import unittest
from unittest.mock import patch, MagicMock
import sys
import os

class ClassLoaderWrapper:
    @staticmethod
    def get_platform_class_loader():
        return None

    @staticmethod
    def get_system_class_loader():
        return None

    @staticmethod
    def get_system_resource_as_stream(name):
        return None

    @staticmethod
    def get_system_resource(name):
        return None

class java_lang_ClassLoaderAutoTest(unittest.TestCase):
    
    def test_getSystemResource_test_2317(self):
        """Randoop-generated regression test for java.lang.ClassLoader.getSystemResource()."""
        # Mock the get_system_resource method to return None for "hi!"
        with patch.object(ClassLoaderWrapper, 'get_system_resource', return_value=None) as mock_method:
            # Call the method with "hi!" as the resource name
            result = ClassLoaderWrapper.get_system_resource("hi!")
            
            # Assert that the method was called with "hi!"
            mock_method.assert_called_once_with("hi!")
            
            # Assert that the result is None (equivalent to Java's assertNull)
            self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()