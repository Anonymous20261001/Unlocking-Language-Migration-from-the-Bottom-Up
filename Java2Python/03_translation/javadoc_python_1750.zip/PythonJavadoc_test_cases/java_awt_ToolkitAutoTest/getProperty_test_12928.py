import unittest
from unittest.mock import Mock

class Toolkit:
    """Wrapper class for java.awt.Toolkit static methods"""
    
    @staticmethod
    def getDefaultToolkit():
        """Returns the default toolkit instance"""
        return Mock()
    
    @staticmethod
    def getProperty(key, default_value):
        """Gets a system property with a default value"""
        return default_value


class TestJavaAwtToolkit(unittest.TestCase):
    """Test class for java.awt.Toolkit wrapper"""
    
    def test_getProperty_test_12928(self):
        """Randoop-generated regression test for java.awt.Toolkit.getProperty()."""
        # Call getProperty with empty string key and empty string default value
        str2 = Toolkit.getProperty("", "")
        
        # Assert that the returned value equals the empty string
        self.assertEqual(str2, "", f"'{str2}' != '{''}'")


if __name__ == '__main__':
    unittest.main()