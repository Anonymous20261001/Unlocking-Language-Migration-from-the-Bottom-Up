import unittest
from unittest.mock import patch, MagicMock
from java_awt_MouseInfo import java_awt_MouseInfo


class TestJavaAwtMouseInfo(unittest.TestCase):
    """Test class for java.awt.MouseInfo.getPointerInfo()"""

    def test_getPointerInfo_test_9026(self):
        """
        Test that getPointerInfo() raises an exception when called in a headless environment.
        This corresponds to the Java test that expects a HeadlessException.
        """
        # Simulate headless environment - getPointerInfo should raise an exception
        with patch.object(java_awt_MouseInfo.MouseInfo, 'getPointerInfo', 
                         side_effect=Exception("HeadlessException")):
            try:
                # Attempt to call getPointerInfo
                pointer_info = java_awt_MouseInfo.MouseInfo.getPointerInfo()
                # If we get here, the test should fail because we expected an exception
                self.fail("Expected exception of type HeadlessException; message: null")
            except Exception as e:
                # Verify the exception message matches what we expect
                self.assertEqual(str(e), "HeadlessException", 
                               f"Expected HeadlessException but got: {e}")


if __name__ == '__main__':
    unittest.main()