import unittest
from unittest.mock import MagicMock, patch


class TestPrinterJobAuto(unittest.TestCase):

    def test_lookupStreamPrintServices_test_10010(self, p0):
        PrinterJob.lookupStreamPrintServices(p0)

class PrinterJob:
    @staticmethod
    def getPrinterJob():
        return MagicMock()

    @staticmethod
    def lookupPrintServices():
        return []

    @staticmethod
    def lookupStreamPrintServices(mime_type):
        return []
