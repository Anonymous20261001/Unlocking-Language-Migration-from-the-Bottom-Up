import unittest
from unittest.mock import MagicMock, patch


class TestPrinterJobAuto(unittest.TestCase):

    def test_getPrinterJob_test_10008(self):
        PrinterJob.getPrinterJob()

class PrinterJob:
    @staticmethod
    def getPrinterJob():
        return MagicMock()

    @staticmethod
    def lookupPrintServices():
        return []

    @staticmethod
    def lookupStreamPrintServices(mime_type):
        return []
