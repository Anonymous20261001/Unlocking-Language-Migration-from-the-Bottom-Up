import unittest
from unittest.mock import MagicMock, patch


class TestPrinterJobAuto(unittest.TestCase):

    def test_lookupPrintServices_test_10009(self):
        PrinterJob.lookupPrintServices()

class PrinterJob:
    @staticmethod
    def getPrinterJob():
        return MagicMock()

    @staticmethod
    def lookupPrintServices():
        return []

    @staticmethod
    def lookupStreamPrintServices(mime_type):
        return []
