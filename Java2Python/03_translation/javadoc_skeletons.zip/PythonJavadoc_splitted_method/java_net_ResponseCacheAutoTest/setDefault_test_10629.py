import unittest
from typing import Optional

class ResponseCacheWrapper:
    """Wrapper class for ResponseCache static methods"""
    _default: Optional['ResponseCacheWrapper'] = None

    @classmethod
    def getDefault(cls):
        return cls._default

    @classmethod
    def setDefault(cls, response_cache: Optional['ResponseCacheWrapper']):
        cls._default = response_cache


class TestResponseCache(unittest.TestCase):

    def test_setDefault_test_10629(self):
        p0 = ResponseCacheWrapper()
        ResponseCacheWrapper.setDefault(p0)

if __name__ == '__main__':
    unittest.main()
