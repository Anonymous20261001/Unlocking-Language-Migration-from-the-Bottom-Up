import unittest
from unittest.mock import Mock
from threading import Thread


class TestCleanerAuto(unittest.TestCase):

    def test_create_test_2319(self):
        Cleaner.create()

class ThreadFactory:
    def new_thread(self, runnable):
        return Thread(target=runnable)


class Cleaner:
    @staticmethod
    def create(thread_factory=None):
        if thread_factory is None:
            return Cleaner()
        return Cleaner(thread_factory)

    def __init__(self, thread_factory=None):
        self._thread_factory = thread_factory
        self._cleanables = []

    def register(self, obj, action):
        cleanable = _Cleanable(obj, action, self)
        self._cleanables.append(cleanable)
        return cleanable

    def clean(self):
        for cleanable in self._cleanables:
            cleanable.clean()
        self._cleanables.clear()


class _Cleanable:
    def __init__(self, obj, action, cleaner):
        self._obj = obj
        self._action = action
        self._cleaner = cleaner
        self._cleaned = False

    def clean(self):
        if not self._cleaned:
            self._action()
            self._cleaned = True

    def __del__(self):
        self.clean()


    unittest.main()
