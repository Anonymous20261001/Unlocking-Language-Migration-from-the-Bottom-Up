import unittest
from java.lang import Package

class TestJavaLangPackageAutoTest(unittest.TestCase):

    def test_getPackage_test_9713(self):
        p0 = "java.lang"
        Package.getPackage(p0)

class Package:
    @staticmethod
    def getPackage(name):
        # Implementation here
        pass
    
    @staticmethod
    def getPackages():
        # Implementation here
        pass

    unittest.main()
