import unittest
import struct
from ctypes import c_short, c_int, c_float

class FloatWrapper:
    """Wrapper class for Float operations"""
    
    @staticmethod
    def min(p0, p1):
        return min(p0, p1)
    
    @staticmethod
    def max(p0, p1):
        return max(p0, p1)
    
    @staticmethod
    def isInfinite(p0):
        return p0 == float('inf') or p0 == float('-inf')
    
    @staticmethod
    def isFinite(p0):
        return p0 != float('inf') and p0 != float('-inf') and not (p0 != p0)
    
    @staticmethod
    def floatToRawIntBits(p0):
        return struct.unpack('>i', struct.pack('>f', p0))[0]
    
    @staticmethod
    def floatToIntBits(p0):
        return struct.unpack('>i', struct.pack('>f', p0))[0]
    
    @staticmethod
    def intBitsToFloat(p0):
        return struct.unpack('>f', struct.pack('>i', p0))[0]
    
    @staticmethod
    def float16ToFloat(p0):
        # Convert 16-bit float to 32-bit float
        sign = (p0 >> 15) & 0x1
        exponent = (p0 >> 10) & 0x1F
        fraction = p0 & 0x3FF
        
        if exponent == 0:
            if fraction == 0:
                return 0.0 if sign == 0 else -0.0
            else:
                # Subnormal number
                value = fraction / 1024.0 * 2**(-14)
                return value if sign == 0 else -value
        elif exponent == 31:
            if fraction == 0:
                return float('inf') if sign == 0 else float('-inf')
            else:
                return float('nan')
        else:
            value = (1 + fraction / 1024.0) * 2**(exponent - 15)
            return value if sign == 0 else -value
    
    @staticmethod
    def floatToFloat16(p0):
        # Convert 32-bit float to 16-bit float
        if p0 != p0:  # NaN
            return 0x7E00
        if p0 == float('inf'):
            return 0x7C00
        if p0 == float('-inf'):
            return 0xFC00
        if p0 == 0:
            return 0x0000 if p0 > 0 or (p0 == 0 and not (p0 < 0)) else 0x8000
        
        sign = 0 if p0 > 0 else 1
        p0 = abs(p0)
        
        # Find exponent
        exp = 0
        while p0 >= 2:
            p0 /= 2
            exp += 1
        while p0 < 1:
            p0 *= 2
            exp -= 1
        
        if exp > 15:
            return 0x7C00 if sign == 0 else 0xFC00  # Overflow to infinity
        if exp < -14:
            return 0x0000 if sign == 0 else 0x8000  # Underflow to zero
        
        fraction = int((p0 - 1) * 1024)
        if exp == -14:
            # Subnormal
            fraction = int(p0 * 1024)
            exp_bits = 0
        else:
            exp_bits = exp + 15
        
        return (sign << 15) | (exp_bits << 10) | fraction
    
    @staticmethod
    def compare(p0, p1):
        if p0 < p1:
            return -1
        elif p0 > p1:
            return 1
        else:
            return 0
    
    @staticmethod
    def valueOf(p0):
        if isinstance(p0, str):
            return float(p0)
        return p0
    
    @staticmethod
    def toHexString(p0):
        return p0.hex()
    
    @staticmethod
    def isNaN(p0):
        return p0 != p0
    
    @staticmethod
    def sum(p0, p1):
        return p0 + p1
    
    @staticmethod
    def parseFloat(p0):
        return float(p0)

class TestFloatMethods(unittest.TestCase):

    def test_valueOf_test_4843(self):
        p0 = 1.5
        FloatWrapper.valueOf(p0)

if __name__ == '__main__':
    unittest.main()
