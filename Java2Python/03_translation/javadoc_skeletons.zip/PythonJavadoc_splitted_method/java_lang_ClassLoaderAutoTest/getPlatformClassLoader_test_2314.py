import unittest

class TestClassLoaderAuto(unittest.TestCase):

    def test_getPlatformClassLoader_test_2314(self):
        ClassLoaderWrapper.get_platform_class_loader()

class ClassLoaderWrapper:
    @staticmethod
    def get_platform_class_loader():
        return None

    @staticmethod
    def get_system_class_loader():
        return None

    @staticmethod
    def get_system_resource_as_stream(name):
        return None

    @staticmethod
    def get_system_resource(name):
        return None


    unittest.main()
