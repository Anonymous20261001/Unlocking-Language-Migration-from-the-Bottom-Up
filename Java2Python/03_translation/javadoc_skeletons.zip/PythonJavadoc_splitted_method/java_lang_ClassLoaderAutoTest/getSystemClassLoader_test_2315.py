import unittest

class TestClassLoaderAuto(unittest.TestCase):

    def test_getSystemClassLoader_test_2315(self):
        ClassLoaderWrapper.get_system_class_loader()

class ClassLoaderWrapper:
    @staticmethod
    def get_platform_class_loader():
        return None

    @staticmethod
    def get_system_class_loader():
        return None

    @staticmethod
    def get_system_resource_as_stream(name):
        return None

    @staticmethod
    def get_system_resource(name):
        return None


    unittest.main()
