import unittest
from typing import CharSequence


class TestReaderAuto(unittest.TestCase):

    def test_nullReader_test_10346(self):
        Reader.nullReader()

class Reader:
    @staticmethod
    def nullReader():
        return NullReader()

    @staticmethod
    def of(char_sequence):
        return StringReader(char_sequence)


class NullReader:
    def read(self):
        return -1


class StringReader:
    def __init__(self, char_sequence):
        self.char_sequence = char_sequence

    def read(self):
        if not self.char_sequence:
            return -1
        char = self.char_sequence[0]
        self.char_sequence = self.char_sequence[1:]
        return ord(char)


    unittest.main()
