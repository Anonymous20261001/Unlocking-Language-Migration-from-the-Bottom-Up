import unittest
from unittest.mock import MagicMock

class DragSource:
    def __init__(self):
        self.drag_source_listeners = []
        self.drag_source_motion_listeners = []
    
    @staticmethod
    def getDefaultDragSource():
        return DragSource()
    
    @staticmethod
    def isDragImageSupported():
        return True
    
    @staticmethod
    def getDragThreshold():
        return 10
    
    def addDragSourceListener(self, p0):
        self.drag_source_listeners.append(p0)
    
    def addDragSourceMotionListener(self, p0):
        self.drag_source_motion_listeners.append(p0)
    
    def createDefaultDragGestureRecognizer(self, p0, p1, p2):
        return MagicMock()
    
    def removeDragSourceListener(self, p0):
        if p0 in self.drag_source_listeners:
            self.drag_source_listeners.remove(p0)
    
    def getDragSourceListeners(self):
        return self.drag_source_listeners
    
    def removeDragSourceMotionListener(self, p0):
        if p0 in self.drag_source_motion_listeners:
            self.drag_source_motion_listeners.remove(p0)
    
    def getDragSourceMotionListeners(self):
        return self.drag_source_motion_listeners
    
    def getListeners(self, p0):
        return []
    
    def createDragGestureRecognizer(self, p0, p1, p2, p3):
        return MagicMock()
    
    def startDrag(self, *args):
        return MagicMock()
    
    def getFlavorMap(self):
        return MagicMock()


class TestDragSource(unittest.TestCase):

    def test_getDefaultDragSource_test_4298(self):
        DragSource.getDefaultDragSource()

if __name__ == '__main__':
    unittest.main()
