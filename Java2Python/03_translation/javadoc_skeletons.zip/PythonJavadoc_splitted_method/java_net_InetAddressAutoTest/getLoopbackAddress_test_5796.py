import unittest
import socket


class TestInetAddress(unittest.TestCase):

    def getLoopbackAddress_test_5796(self):
        socket.gethostbyname('localhost')

class InetAddressWrapper:
    @staticmethod
    def ofLiteral(p0):
        return socket.inet_aton(p0)

    @staticmethod
    def getLoopbackAddress():
        return socket.gethostbyname('localhost')


    unittest.main()
