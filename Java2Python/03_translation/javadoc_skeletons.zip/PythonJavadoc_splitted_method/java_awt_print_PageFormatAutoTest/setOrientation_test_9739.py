import unittest


class TestPageFormat(unittest.TestCase):

    def test_setOrientation_test_9739(self):
        instance = PageFormat()
        instance.setOrientation(0)

class PageFormat:
    def __init__(self):
        self.width = 612.0
        self.height = 792.0
        self.orientation = 0
        self.imageable_x = 0.0
        self.imageable_y = 0.0
        self.imageable_width = 612.0
        self.imageable_height = 792.0
        self.paper = None
        self.matrix = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]

    def getWidth(self):
        return self.width

    def getHeight(self):
        return self.height

    def getOrientation(self):
        return self.orientation

    def getMatrix(self):
        return self.matrix

    def setOrientation(self, orientation):
        self.orientation = orientation

    def getImageableY(self):
        return self.imageable_y

    def getImageableHeight(self):
        return self.imageable_height

    def getImageableX(self):
        return self.imageable_x

    def getImageableWidth(self):
        return self.imageable_width

    def getPaper(self):
        return self.paper

    def setPaper(self, paper):
        self.paper = paper


class Paper:
    def __init__(self):
        self.width = 612.0
        self.height = 792.0
        self.imageable_x = 0.0
        self.imageable_y = 0.0
        self.imageable_width = 612.0
        self.imageable_height = 792.0


    unittest.main()
