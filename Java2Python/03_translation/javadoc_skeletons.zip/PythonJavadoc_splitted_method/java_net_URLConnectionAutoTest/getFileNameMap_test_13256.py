import unittest
from unittest.mock import MagicMock
from urllib.request import URLopener


class TestJavaNetURLConnectionAutoTest(unittest.TestCase):

    def test_getFileNameMap_test_13256(self):
        URLConnectionWrapper.getFileNameMap()

class URLConnectionWrapper:
    """Wrapper class for URLConnection static methods"""

    @staticmethod
    def getDefaultUseCaches(p0):
        return URLopener().open(p0) is not None

    @staticmethod
    def getFileNameMap():
        return {}

    @staticmethod
    def setFileNameMap(p0):
        return p0

    @staticmethod
    def setDefaultAllowUserInteraction(p0):
        return p0

    @staticmethod
    def getDefaultAllowUserInteraction():
        return False

    @staticmethod
    def setDefaultUseCaches(p0, p1):
        return p0, p1

    @staticmethod
    def setDefaultRequestProperty(p0, p1):
        return p0, p1

    @staticmethod
    def getDefaultRequestProperty(p0):
        return p0

    @staticmethod
    def setContentHandlerFactory(p0):
        return p0

    @staticmethod
    def guessContentTypeFromName(p0):
        return p0


    unittest.main()
