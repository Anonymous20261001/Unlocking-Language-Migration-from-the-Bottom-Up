import unittest
import struct
import math
from enum import Enum

class Double:
    def __init__(self, value):
        self.value = float(value)
    
    def isInfinite(self):
        return math.isinf(self.value)
    
    def isNaN(self):
        return math.isnan(self.value)
    
    def compareTo(self, other):
        if isinstance(other, Double):
            other = other.value
        if self.value < other:
            return -1
        elif self.value > other:
            return 1
        else:
            return 0
    
    def byteValue(self):
        return int(self.value) & 0xFF
    
    def shortValue(self):
        return int(self.value) & 0xFFFF
    
    def intValue(self):
        return int(self.value)
    
    def longValue(self):
        return int(self.value)
    
    def floatValue(self):
        return float(self.value)
    
    def doubleValue(self):
        return float(self.value)
    
    def resolveConstantDesc(self, lookup):
        return self.value
    
    def describeConstable(self):
        return self.value
    
    @staticmethod
    def min(a, b):
        return min(a, b)
    
    @staticmethod
    def max(a, b):
        return max(a, b)
    
    @staticmethod
    def isInfinite(value):
        return math.isinf(value)
    
    @staticmethod
    def isFinite(value):
        return math.isfinite(value)
    
    @staticmethod
    def doubleToRawLongBits(value):
        return struct.unpack('q', struct.pack('d', value))[0]
    
    @staticmethod
    def doubleToLongBits(value):
        return struct.unpack('q', struct.pack('d', value))[0]
    
    @staticmethod
    def longBitsToDouble(value):
        return struct.unpack('d', struct.pack('q', value))[0]
    
    @staticmethod
    def compare(a, b):
        if a < b:
            return -1
        elif a > b:
            return 1
        else:
            return 0
    
    @staticmethod
    def valueOf(value):
        if isinstance(value, str):
            return float(value)
        return float(value)
    
    @staticmethod
    def toHexString(value):
        return float.hex(value)
    
    @staticmethod
    def isNaN(value):
        return math.isnan(value)
    
    @staticmethod
    def sum(a, b):
        return a + b
    
    @staticmethod
    def parseDouble(value):
        return float(value)

class MethodHandles:
    class Lookup:
        pass

class TestDouble(unittest.TestCase):

    def test_parseDouble_test_4248(self):
        p0 = "1.5"
        Double.parseDouble(p0)

if __name__ == '__main__':
    unittest.main()
