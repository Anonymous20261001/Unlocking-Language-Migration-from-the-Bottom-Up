import unittest
import math

class TestAlphaComposite(unittest.TestCase):

    def getInstance_test_144(self, p0):
        AlphaComposite.getInstance(p0)

class AlphaComposite:
    @staticmethod
    def getInstance(rule, alpha=1.0):
        # Implementation of AlphaComposite.getInstance
        pass

    unittest.main()
