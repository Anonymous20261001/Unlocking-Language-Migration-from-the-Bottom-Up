import unittest
from unittest.mock import patch, MagicMock

class TestJavaNetHttpURLConnectionAutoTest(unittest.TestCase):

    def test_setFollowRedirects_test_5493(self):
        # Test setting follow redirects
        HttpURLConnectionWrapper.setFollowRedirects(True)
        self.assertTrue(HttpURLConnectionWrapper.getFollowRedirects())

class HttpURLConnectionWrapper:
    """Wrapper class mimicking java.net.HttpURLConnection static methods"""
    _follow_redirects = True
    
    @classmethod
    def setFollowRedirects(cls, set):
        """Set whether HTTP redirects should be automatically followed"""
        cls._follow_redirects = set
    
    @classmethod
    def getFollowRedirects(cls):
        """Get whether HTTP redirects should be automatically followed"""
        return cls._follow_redirects

    unittest.main()
