import unittest
from unittest.mock import patch, MagicMock

class TestJavaNetHttpURLConnectionAutoTest(unittest.TestCase):

    def test_getFollowRedirects_test_5494(self):
        # Test getting follow redirects
        HttpURLConnectionWrapper.setFollowRedirects(False)
        result = HttpURLConnectionWrapper.getFollowRedirects()
        self.assertFalse(result)

class HttpURLConnectionWrapper:
    """Wrapper class mimicking java.net.HttpURLConnection static methods"""
    _follow_redirects = True
    
    @classmethod
    def setFollowRedirects(cls, set):
        """Set whether HTTP redirects should be automatically followed"""
        cls._follow_redirects = set
    
    @classmethod
    def getFollowRedirects(cls):
        """Get whether HTTP redirects should be automatically followed"""
        return cls._follow_redirects

    unittest.main()
