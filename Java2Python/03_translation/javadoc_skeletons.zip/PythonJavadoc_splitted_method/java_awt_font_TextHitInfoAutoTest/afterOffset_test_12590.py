import unittest

class TestTextHitInfo(unittest.TestCase):

    def afterOffset_test_12590(self, p0):
        TextHitInfo.afterOffset(p0)

class TextHitInfo:
    @staticmethod
    def trailing(char_index):
        return TextHitInfo(char_index, True)

    @staticmethod
    def leading(char_index):
        return TextHitInfo(char_index, False)

    @staticmethod
    def beforeOffset(offset):
        return TextHitInfo(offset - 1, True)

    @staticmethod
    def afterOffset(offset):
        return TextHitInfo(offset, False)

    def __init__(self, char_index, is_trailing):
        self.char_index = char_index
        self.is_trailing = is_trailing


    unittest.main()
