import unittest
from unittest.mock import Mock
import socket


class TestProxySelector(unittest.TestCase):

    def test_getDefault_test_10220(self):
        ProxySelector.getDefault()

class InetSocketAddress:
    def __init__(self, address, port):
        self.address = address
        self.port = port


class ProxySelector:
    @staticmethod
    def of(address):
        return ProxySelector()

    @staticmethod
    def getDefault():
        return None

    @staticmethod
    def setDefault(selector):
        return None


    unittest.main()
