import unittest
from typing import Any


class TestAWTEventMulticaster(unittest.TestCase):

    def test_add_test_934(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

class AWTEventMulticaster:
    @staticmethod
    def getListeners(listener: Any, listener_type: Any) -> Any:
        return None

    @staticmethod
    def remove(listener_a: Any, listener_b: Any) -> Any:
        return None

    @staticmethod
    def add(listener_a: Any, listener_b: Any) -> Any:
        return None


    unittest.main()
