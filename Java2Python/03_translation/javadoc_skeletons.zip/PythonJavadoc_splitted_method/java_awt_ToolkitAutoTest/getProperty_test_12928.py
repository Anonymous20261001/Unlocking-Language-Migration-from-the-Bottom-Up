import unittest
from unittest.mock import Mock, patch
import java_awt_ToolkitAutoTest


class TestJavaAwtToolkitAutoTest(unittest.TestCase):

    def test_getProperty_test_12928(self):
        p0 = "test_prop"
        p1 = "default_value"
        with patch('java_awt_ToolkitAutoTest.Toolkit') as mock_toolkit:
            mock_toolkit.getProperty.return_value = "mocked_result"
            result = mock_toolkit.getProperty(p0, p1)
            self.assertEqual(result, "mocked_result")
            mock_toolkit.getProperty.assert_called_once_with(p0, p1)

class Toolkit:
    """Wrapper class for java.awt.Toolkit static methods"""
    
    @staticmethod
    def getDefaultToolkit():
        """Returns the default toolkit instance"""
        return Mock()
    
    @staticmethod
    def getProperty(key, default_value):
        """Gets a system property with a default value"""
        return default_value


    unittest.main()
