import unittest
import java.awt.event.InputEvent

class TestJavaAwtEventInputEventAutoTest(unittest.TestCase):

    def test_getMaskForButton_test_5832(self):
        p0 = 0
        InputEvent.getMaskForButton(p0)

class InputEventWrapper:
    @staticmethod
    def getModifiersExText(p0):
        return InputEvent.getModifiersExText(p0)

    @staticmethod
    def getMaskForButton(p0):
        return InputEvent.getMaskForButton(p0)

    unittest.main()
