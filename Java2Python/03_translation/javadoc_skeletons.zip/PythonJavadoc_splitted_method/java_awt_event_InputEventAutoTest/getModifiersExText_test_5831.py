import unittest
import java.awt.event.InputEvent

class TestJavaAwtEventInputEventAutoTest(unittest.TestCase):

    def test_getModifiersExText_test_5831(self):
        p0 = 0
        InputEvent.getModifiersExText(p0)

class InputEventWrapper:
    @staticmethod
    def getModifiersExText(p0):
        return InputEvent.getModifiersExText(p0)

    @staticmethod
    def getMaskForButton(p0):
        return InputEvent.getMaskForButton(p0)

    unittest.main()
