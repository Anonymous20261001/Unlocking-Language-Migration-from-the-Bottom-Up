import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_nextDown_test_8397(self):
        m = MathWrapper()
        m.nextDown_test_8397(1.0)
        m.nextDown_test_8397(-1.0)
        m.nextDown_test_8397(0.0)

class MathWrapper:
