import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_absExact_test_8388(self):
        m = MathWrapper()
        m.absExact_test_8388(10)
        m.absExact_test_8388(-10)
        m.absExact_test_8388(0)

class MathWrapper:
