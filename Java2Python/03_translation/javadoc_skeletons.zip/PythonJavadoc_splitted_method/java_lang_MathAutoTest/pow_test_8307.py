import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def pow_test_8307(self, p0, p1):
        return math.pow(p0, p1)

class MathWrapper:
