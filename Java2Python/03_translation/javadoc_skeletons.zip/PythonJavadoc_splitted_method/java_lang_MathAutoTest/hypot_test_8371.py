import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_hypot_test_8371(self):
        m = MathWrapper()
        m.hypot_test_8371(3.0, 4.0)
        m.hypot_test_8371(-3.0, 4.0)
        m.hypot_test_8371(0.0, 0.0)

class MathWrapper:
