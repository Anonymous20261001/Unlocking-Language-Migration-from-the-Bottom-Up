import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_toIntExact_test_8386(self):
        m = MathWrapper()
        m.toIntExact_test_8386(10)
        m.toIntExact_test_8386(-10)
        m.toIntExact_test_8386(0)

class MathWrapper:
