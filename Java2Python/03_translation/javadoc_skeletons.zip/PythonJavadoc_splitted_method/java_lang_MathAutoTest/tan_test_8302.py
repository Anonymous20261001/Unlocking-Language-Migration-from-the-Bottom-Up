import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def tan_test_8302(self, p0):
        return math.tan(p0)

class MathWrapper:
