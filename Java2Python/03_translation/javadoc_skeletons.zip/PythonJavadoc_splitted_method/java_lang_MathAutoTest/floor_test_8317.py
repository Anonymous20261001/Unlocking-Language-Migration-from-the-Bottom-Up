import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def floor_test_8317(self, p0):
        return math.floor(p0)

class MathWrapper:
