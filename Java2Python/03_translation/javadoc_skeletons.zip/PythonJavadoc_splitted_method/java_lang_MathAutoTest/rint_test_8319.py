import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def rint_test_8319(self, p0):
        return round(p0)

class MathWrapper:
