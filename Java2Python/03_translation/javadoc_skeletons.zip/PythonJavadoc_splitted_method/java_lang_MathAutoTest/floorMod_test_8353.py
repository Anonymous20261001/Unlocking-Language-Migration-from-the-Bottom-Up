import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def floorMod_test_8353(self, p0, p1):
        return p0 % p1

class MathWrapper:
