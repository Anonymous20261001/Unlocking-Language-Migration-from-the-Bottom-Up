import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def addExact_test_8325(self, p0, p1):
        return p0 + p1

class MathWrapper:
