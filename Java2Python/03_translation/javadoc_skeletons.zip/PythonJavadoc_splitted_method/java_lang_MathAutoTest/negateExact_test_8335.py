import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def negateExact_test_8335(self, p0):
        return -p0

class MathWrapper:
