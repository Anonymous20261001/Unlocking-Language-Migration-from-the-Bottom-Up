import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def ceil_test_8318(self, p0):
        return math.ceil(p0)

class MathWrapper:
