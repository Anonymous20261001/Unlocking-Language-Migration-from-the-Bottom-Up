import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def max_test_8316(self, p0, p1):
        return max(p0, p1)

class MathWrapper:
