import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_sinh_test_8369(self):
        m = MathWrapper()
        m.sinh_test_8369(0.5)
        m.sinh_test_8369(-0.5)
        m.sinh_test_8369(1.0)

class MathWrapper:
