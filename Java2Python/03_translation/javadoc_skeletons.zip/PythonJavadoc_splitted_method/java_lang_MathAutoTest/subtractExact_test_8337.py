import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def subtractExact_test_8337(self, p0, p1):
        return p0 - p1

class MathWrapper:
