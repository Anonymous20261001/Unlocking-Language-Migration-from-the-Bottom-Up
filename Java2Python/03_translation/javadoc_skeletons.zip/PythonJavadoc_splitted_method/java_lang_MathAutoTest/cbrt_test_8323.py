import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def cbrt_test_8323(self, p0):
        return p0 ** (1/3) if p0 >= 0 else -((-p0) ** (1/3))

class MathWrapper:
