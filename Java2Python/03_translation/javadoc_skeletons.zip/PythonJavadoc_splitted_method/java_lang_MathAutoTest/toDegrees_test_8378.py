import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_toDegrees_test_8378(self):
        m = MathWrapper()
        m.toDegrees_test_8378(3.141592653589793)
        m.toDegrees_test_8378(1.5707963267948966)
        m.toDegrees_test_8378(0.0)

class MathWrapper:
