import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_nextDown_test_8396(self):
        m = MathWrapper()
        m.nextDown_test_8396(1.0)
        m.nextDown_test_8396(-1.0)
        m.nextDown_test_8396(0.0)

class MathWrapper:
