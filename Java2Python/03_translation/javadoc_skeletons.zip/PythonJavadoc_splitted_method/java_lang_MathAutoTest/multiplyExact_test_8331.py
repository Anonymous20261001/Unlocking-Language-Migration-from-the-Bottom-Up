import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def multiplyExact_test_8331(self, p0, p1):
        return p0 * p1

class MathWrapper:
