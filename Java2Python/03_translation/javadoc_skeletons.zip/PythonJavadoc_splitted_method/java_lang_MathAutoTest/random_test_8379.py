import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_random_test_8379(self):
        m = MathWrapper()
        m.random_test_8379()
        m.random_test_8379()
        m.random_test_8379()

class MathWrapper:
