import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def getExponent_test_8352(self, p0):
        return math.frexp(p0)[1] - 1

class MathWrapper:
