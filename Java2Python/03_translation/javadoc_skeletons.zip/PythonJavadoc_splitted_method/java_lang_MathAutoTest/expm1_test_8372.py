import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_expm1_test_8372(self):
        m = MathWrapper()
        m.expm1_test_8372(0.0)
        m.expm1_test_8372(1.0)
        m.expm1_test_8372(-1.0)

class MathWrapper:
