import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def max_test_8315(self, p0, p1):
        return max(p0, p1)

class MathWrapper:
