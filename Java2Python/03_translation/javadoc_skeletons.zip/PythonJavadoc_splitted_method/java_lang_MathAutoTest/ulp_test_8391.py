import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_ulp_test_8391(self):
        m = MathWrapper()
        m.ulp_test_8391(1.0)
        m.ulp_test_8391(-1.0)
        m.ulp_test_8391(0.0)

class MathWrapper:
