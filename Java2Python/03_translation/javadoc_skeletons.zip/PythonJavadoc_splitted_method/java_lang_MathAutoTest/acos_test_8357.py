import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def acos_test_8357(self, p0):
        return math.acos(p0)

class MathWrapper:
