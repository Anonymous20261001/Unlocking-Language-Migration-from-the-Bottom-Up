import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_nextAfter_test_8392(self):
        m = MathWrapper()
        m.nextAfter_test_8392(1.0, 2.0)
        m.nextAfter_test_8392(-1.0, 2.0)
        m.nextAfter_test_8392(0.0, -1.0)

class MathWrapper:
