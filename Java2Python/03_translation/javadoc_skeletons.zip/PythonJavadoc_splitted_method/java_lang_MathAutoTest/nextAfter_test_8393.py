import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_nextAfter_test_8393(self):
        m = MathWrapper()
        m.nextAfter_test_8393(1.0, 2.0)
        m.nextAfter_test_8393(-1.0, 2.0)
        m.nextAfter_test_8393(0.0, -1.0)

class MathWrapper:
