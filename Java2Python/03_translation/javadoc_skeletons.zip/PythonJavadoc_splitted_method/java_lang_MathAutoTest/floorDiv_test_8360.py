import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_floorDiv_test_8360(self):
        m = MathWrapper()
        m.floorDiv_test_8360(10, 3)
        m.floorDiv_test_8360(-10, 3)
        m.floorDiv_test_8360(10, -3)

class MathWrapper:
