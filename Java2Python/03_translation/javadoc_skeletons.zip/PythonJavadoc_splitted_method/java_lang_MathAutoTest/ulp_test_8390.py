import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_ulp_test_8390(self):
        m = MathWrapper()
        m.ulp_test_8390(1.0)
        m.ulp_test_8390(-1.0)
        m.ulp_test_8390(0.0)

class MathWrapper:
