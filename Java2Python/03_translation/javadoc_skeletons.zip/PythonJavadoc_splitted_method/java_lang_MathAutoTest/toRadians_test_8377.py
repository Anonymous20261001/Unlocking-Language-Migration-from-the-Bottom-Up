import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_toRadians_test_8377(self):
        m = MathWrapper()
        m.toRadians_test_8377(180.0)
        m.toRadians_test_8377(90.0)
        m.toRadians_test_8377(0.0)

class MathWrapper:
