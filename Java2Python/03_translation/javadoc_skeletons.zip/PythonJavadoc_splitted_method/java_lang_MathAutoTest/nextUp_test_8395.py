import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_nextUp_test_8395(self):
        m = MathWrapper()
        m.nextUp_test_8395(1.0)
        m.nextUp_test_8395(-1.0)
        m.nextUp_test_8395(0.0)

class MathWrapper:
