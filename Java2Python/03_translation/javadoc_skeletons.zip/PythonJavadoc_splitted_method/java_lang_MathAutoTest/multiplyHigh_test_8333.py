import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def multiplyHigh_test_8333(self, p0, p1):
        return (p0 * p1) >> 64

class MathWrapper:
