import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def fma_test_8340(self, p0, p1, p2):
        return p0 * p1 + p2

class MathWrapper:
