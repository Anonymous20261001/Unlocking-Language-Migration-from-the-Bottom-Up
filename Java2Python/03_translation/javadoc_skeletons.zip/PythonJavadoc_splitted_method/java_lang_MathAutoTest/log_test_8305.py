import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def log_test_8305(self, p0):
        return math.log(p0)

class MathWrapper:
