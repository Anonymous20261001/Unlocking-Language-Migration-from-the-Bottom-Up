import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def min_test_8312(self, p0, p1):
        return min(p0, p1)

class MathWrapper:
