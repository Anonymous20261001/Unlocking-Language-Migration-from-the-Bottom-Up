import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def log10_test_8306(self, p0):
        return math.log10(p0)

class MathWrapper:
