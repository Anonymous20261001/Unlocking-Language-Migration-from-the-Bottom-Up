import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def cos_test_8301(self, p0):
        return math.cos(p0)

class MathWrapper:
