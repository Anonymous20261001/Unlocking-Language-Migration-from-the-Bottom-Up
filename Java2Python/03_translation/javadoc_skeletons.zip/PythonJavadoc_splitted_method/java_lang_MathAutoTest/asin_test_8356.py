import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def asin_test_8356(self, p0):
        return math.asin(p0)

class MathWrapper:
