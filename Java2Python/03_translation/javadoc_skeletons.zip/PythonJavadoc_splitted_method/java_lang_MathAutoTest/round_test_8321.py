import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def round_test_8321(self, p0):
        return round(p0)

class MathWrapper:
