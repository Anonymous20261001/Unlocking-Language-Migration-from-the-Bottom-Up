import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def atan_test_8358(self, p0):
        return math.atan(p0)

class MathWrapper:
