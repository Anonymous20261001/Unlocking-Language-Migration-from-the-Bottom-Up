import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def scalb_test_8349(self, p0, p1):
        return p0 * (2 ** p1)

class MathWrapper:
