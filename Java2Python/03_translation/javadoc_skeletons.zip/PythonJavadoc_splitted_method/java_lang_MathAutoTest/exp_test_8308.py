import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def exp_test_8308(self, p0):
        return math.exp(p0)

class MathWrapper:
