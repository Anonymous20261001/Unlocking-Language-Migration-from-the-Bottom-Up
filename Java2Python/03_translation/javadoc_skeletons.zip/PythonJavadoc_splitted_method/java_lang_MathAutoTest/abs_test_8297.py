import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def abs_test_8297(self, p0):
        return abs(p0)

class MathWrapper:
