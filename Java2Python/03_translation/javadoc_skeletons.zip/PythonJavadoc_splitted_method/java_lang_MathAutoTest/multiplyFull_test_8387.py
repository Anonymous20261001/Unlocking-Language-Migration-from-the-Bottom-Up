import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):

    def test_multiplyFull_test_8387(self):
        m = MathWrapper()
        m.multiplyFull_test_8387(2, 3)
        m.multiplyFull_test_8387(-2, 3)
        m.multiplyFull_test_8387(0, 5)

class MathWrapper:
