import unittest
import java.lang.invoke.MethodType

class TestMethodTypeAutoTest(unittest.TestCase):

    def test_genericMethodType_test_8928(self):
        p0 = 0
        p1 = False
        MethodType.genericMethodType(p0, p1)

# Wrapper class with the methods called by the tests
class MethodTypeWrapper:
    @staticmethod
    def methodType(*args):
        return MethodType.methodType(*args)
    
    @staticmethod
    def genericMethodType(*args):
        return MethodType.genericMethodType(*args)
    
    @staticmethod
    def fromMethodDescriptorString(*args):
        return MethodType.fromMethodDescriptorString(*args)

    unittest.main()
