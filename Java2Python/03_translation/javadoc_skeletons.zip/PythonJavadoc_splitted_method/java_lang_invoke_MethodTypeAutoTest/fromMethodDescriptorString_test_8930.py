import unittest
import java.lang.invoke.MethodType

class TestMethodTypeAutoTest(unittest.TestCase):

    def test_fromMethodDescriptorString_test_8930(self):
        p0 = ""
        p1 = None
        MethodType.fromMethodDescriptorString(p0, p1)

# Wrapper class with the methods called by the tests
class MethodTypeWrapper:
    @staticmethod
    def methodType(*args):
        return MethodType.methodType(*args)
    
    @staticmethod
    def genericMethodType(*args):
        return MethodType.genericMethodType(*args)
    
    @staticmethod
    def fromMethodDescriptorString(*args):
        return MethodType.fromMethodDescriptorString(*args)

    unittest.main()
