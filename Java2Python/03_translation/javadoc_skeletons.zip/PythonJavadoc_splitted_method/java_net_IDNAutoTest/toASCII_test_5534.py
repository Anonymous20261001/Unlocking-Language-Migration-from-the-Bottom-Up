import unittest
import idna

class IDN:
    @staticmethod
    def toASCII(input, flag=0):
        return idna.encode(input, uts46=True).decode('ascii')
    
    @staticmethod
    def toUnicode(input, flag=0):
        return idna.decode(input)

class TestJavaNetIDN(unittest.TestCase):

    def test_toASCII_test_5534(self):
        p0 = "example.com"
        IDN.toASCII(p0)

if __name__ == '__main__':
    unittest.main()
