import unittest
import idna

class IDN:
    @staticmethod
    def toASCII(input, flag=0):
        return idna.encode(input, uts46=True).decode('ascii')
    
    @staticmethod
    def toUnicode(input, flag=0):
        return idna.decode(input)

class TestJavaNetIDN(unittest.TestCase):

    def test_toUnicode_test_5535(self):
        p0 = "xn--example-9db.com"
        IDN.toUnicode(p0)

if __name__ == '__main__':
    unittest.main()
