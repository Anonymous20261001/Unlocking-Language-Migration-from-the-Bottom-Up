import unittest
from unittest.mock import Mock
import http.cookiejar

class TestCookieHandler(unittest.TestCase):

    def test_setDefault_test_3026(self):
        p0 = Mock(spec=CookieHandler)
        CookieHandler.setDefault(p0)
        self.assertEqual(CookieHandler.getDefault(), p0)

class CookieHandler:
    _default = None
    
    @classmethod
    def getDefault(cls):
        return cls._default
    
    @classmethod
    def setDefault(cls, handler):
        cls._default = handler
