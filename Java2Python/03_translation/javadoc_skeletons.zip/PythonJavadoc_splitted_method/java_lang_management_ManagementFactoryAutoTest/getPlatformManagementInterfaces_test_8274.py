import unittest
from unittest.mock import MagicMock, patch
import java.lang.management.ManagementFactory as ManagementFactory


class TestManagementFactory(unittest.TestCase):

    def test_getPlatformManagementInterfaces_test_8274(self):
        ManagementFactory.getPlatformManagementInterfaces()

class ManagementFactoryWrapper:
    """Wrapper class containing methods called by the tests"""
    
    @staticmethod
    def getPlatformMXBean(cls):
        return ManagementFactory.getPlatformMXBean(cls)
    
    @staticmethod
    def getPlatformMXBeans(cls):
        return ManagementFactory.getPlatformMXBeans(cls)
    
    @staticmethod
    def getClassLoadingMXBean():
        return ManagementFactory.getClassLoadingMXBean()
    
    @staticmethod
    def getMemoryMXBean():
        return ManagementFactory.getMemoryMXBean()
    
    @staticmethod
    def getThreadMXBean():
        return ManagementFactory.getThreadMXBean()
    
    @staticmethod
    def getRuntimeMXBean():
        return ManagementFactory.getRuntimeMXBean()
    
    @staticmethod
    def getCompilationMXBean():
        return ManagementFactory.getCompilationMXBean()
    
    @staticmethod
    def getOperatingSystemMXBean():
        return ManagementFactory.getOperatingSystemMXBean()
    
    @staticmethod
    def getMemoryPoolMXBeans():
        return ManagementFactory.getMemoryPoolMXBeans()
    
    @staticmethod
    def getMemoryManagerMXBeans():
        return ManagementFactory.getMemoryManagerMXBeans()
    
    @staticmethod
    def getGarbageCollectorMXBeans():
        return ManagementFactory.getGarbageCollectorMXBeans()
    
    @staticmethod
    def getPlatformMBeanServer():
        return ManagementFactory.getPlatformMBeanServer()
    
    @staticmethod
    def getPlatformManagementInterfaces():
        return ManagementFactory.getPlatformManagementInterfaces()


    unittest.main()
