import unittest
from typing import List, Optional
from unittest.mock import MagicMock


class TestDynamicConstantDesc(unittest.TestCase):

    def test_of_test_4421(self):
        p0 = MagicMock()
        DynamicConstantDesc.of(p0)

class DirectMethodHandleDesc:
    """Mock class for DirectMethodHandleDesc"""
    pass


class ClassDesc:
    """Mock class for ClassDesc"""
    pass


class ConstantDesc:
    """Mock class for ConstantDesc"""
    pass


class DynamicConstantDesc:
    """Wrapper class for DynamicConstantDesc"""
    
    @staticmethod
    def of(p0: DirectMethodHandleDesc, p1: Optional[List[ConstantDesc]] = None):
        """Create a DynamicConstantDesc from a DirectMethodHandleDesc and optional ConstantDesc array"""
        if p1 is None:
            return DynamicConstantDesc(p0)
        return DynamicConstantDesc(p0, p1)
    
    @staticmethod
    def ofNamed(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a named DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2)
    
    @staticmethod
    def ofCanonical(p0: DirectMethodHandleDesc, p1: str, p2: ClassDesc, p3: List[ConstantDesc]):
        """Create a canonical DynamicConstantDesc"""
        return DynamicConstantDesc(p0, p3, name=p1, class_desc=p2, canonical=True)
    
    def __init__(self, bootstrap_method, constant_descs=None, name=None, class_desc=None, canonical=False):
        self.bootstrap_method = bootstrap_method
        self.constant_descs = constant_descs or []
        self.name = name
        self.class_desc = class_desc
        self.canonical = canonical


    unittest.main()
