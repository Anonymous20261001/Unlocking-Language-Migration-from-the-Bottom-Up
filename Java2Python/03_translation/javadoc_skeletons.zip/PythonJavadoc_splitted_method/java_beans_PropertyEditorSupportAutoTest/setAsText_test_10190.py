import unittest
from unittest.mock import MagicMock
from java.awt import Graphics, Rectangle
from java.beans import PropertyChangeListener


class TestPropertyEditorSupport(unittest.TestCase):

    def test_setAsText_test_10190(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=str)
        instance.setAsText(p0)

class PropertyEditorSupport:
    def __init__(self):
        self.source = None
        self.value = None
        self.listeners = []

    def firePropertyChange(self):
        pass

    def addPropertyChangeListener(self, listener):
        self.listeners.append(listener)

    def removePropertyChangeListener(self, listener):
        if listener in self.listeners:
            self.listeners.remove(listener)

    def setSource(self, source):
        self.source = source

    def isPaintable(self):
        return False

    def paintValue(self, gfx, box):
        pass

    def getJavaInitializationString(self):
        return ""

    def getAsText(self):
        return str(self.value) if self.value is not None else ""

    def setAsText(self, text):
        self.value = text

    def getTags(self):
        return None

    def getCustomEditor(self):
        return None

    def supportsCustomEditor(self):
        return False

    def getValue(self):
        return self.value

    def setValue(self, value):
        self.value = value

    def getSource(self):
        return self.source


    unittest.main()
