import unittest
from unittest.mock import patch, MagicMock


class TestGraphicsEnvironmentAuto(unittest.TestCase):

    def test_getLocalGraphicsEnvironment_test_5149(self):
        with patch('java_awt_GraphicsEnvironmentAuto.GraphicsEnvironment.getLocalGraphicsEnvironment') as mock_method:
            mock_env = MagicMock()
            mock_method.return_value = mock_env
            result = GraphicsEnvironment.getLocalGraphicsEnvironment()
            mock_method.assert_called_once()
            self.assertEqual(result, mock_env)

class GraphicsEnvironment:
    @staticmethod
    def isHeadless():
        # Simulate Java's GraphicsEnvironment.isHeadless()
        return True

    @staticmethod
    def getLocalGraphicsEnvironment():
        # Simulate Java's GraphicsEnvironment.getLocalGraphicsEnvironment()
        return GraphicsEnvironment()


    unittest.main()
