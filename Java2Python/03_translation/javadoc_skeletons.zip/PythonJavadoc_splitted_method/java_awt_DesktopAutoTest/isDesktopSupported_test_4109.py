import unittest
from unittest.mock import Mock, patch


class TestDesktop(unittest.TestCase):

    def test_isDesktopSupported_test_4109(self):
        with patch('builtins.Desktop') as mock_desktop:
            Desktop.isDesktopSupported()
            mock_desktop.isDesktopSupported.assert_called_once()

class Desktop:
    @staticmethod
    def getDesktop():
        pass

    @staticmethod
    def isDesktopSupported():
        pass


    unittest.main()
