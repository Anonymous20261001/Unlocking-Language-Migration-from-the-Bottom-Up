import unittest
from unittest.mock import Mock, patch


class TestDesktop(unittest.TestCase):

    def test_getDesktop_test_4108(self):
        with patch('builtins.Desktop') as mock_desktop:
            Desktop.getDesktop()
            mock_desktop.getDesktop.assert_called_once()

class Desktop:
    @staticmethod
    def getDesktop():
        pass

    @staticmethod
    def isDesktopSupported():
        pass


    unittest.main()
