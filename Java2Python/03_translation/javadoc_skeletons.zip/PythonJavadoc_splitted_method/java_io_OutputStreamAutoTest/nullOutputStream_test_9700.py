import unittest
import io

class TestJavaIoOutputStreamAutoTest(unittest.TestCase):

    def test_nullOutputStream_test_9700(self):
        output_stream = OutputStreamWrapper.nullOutputStream()
        self.assertIsNotNone(output_stream)

class OutputStreamWrapper:
    @staticmethod
    def nullOutputStream():
        return io.BytesIO()

    unittest.main()
