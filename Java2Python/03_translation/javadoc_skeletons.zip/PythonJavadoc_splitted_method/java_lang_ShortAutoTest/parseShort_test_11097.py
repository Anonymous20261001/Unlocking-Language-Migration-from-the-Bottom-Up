import unittest

class TestShort(unittest.TestCase):

    def test_parseShort_test_11097(self, p0, p1):
        Short.parseShort(p0, p1)

class Short:
    def __init__(self, value):
        self.value = value

    @staticmethod
    def compareUnsigned(x, y):
        pass

    @staticmethod
    def reverseBytes(x):
        pass

    def compareTo(self, other):
        pass

    @staticmethod
    def compare(x, y):
        pass

    def byteValue(self):
        pass

    def shortValue(self):
        pass

    def intValue(self):
        pass

    def longValue(self):
        pass

    def floatValue(self):
        pass

    def doubleValue(self):
        pass

    @staticmethod
    def valueOf(*args):
        pass

    @staticmethod
    def decode(s):
        pass

    def describeConstable(self):
        pass

    @staticmethod
    def toUnsignedLong(x):
        pass

    @staticmethod
    def toUnsignedInt(x):
        pass

    @staticmethod
    def parseShort(*args):
        pass

    unittest.main()
