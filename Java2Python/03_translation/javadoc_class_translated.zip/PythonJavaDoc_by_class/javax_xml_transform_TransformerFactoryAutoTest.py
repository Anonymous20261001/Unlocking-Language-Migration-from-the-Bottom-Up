import unittest
from javax.xml.transform import TransformerFactory

class TestJavaxXmlTransformTransformerFactoryAutoTest(unittest.TestCase):
    def test_newDefaultInstance_test_12971(self):
        TransformerFactory.newDefaultInstance()
    
    def test_newInstance_test_12972(self, p0, p1):
        TransformerFactory.newInstance(p0, p1)
    
    def test_newInstance_test_12973(self):
        TransformerFactory.newInstance()

class TransformerFactoryWrapper:
    @staticmethod
    def newDefaultInstance():
        return TransformerFactory.newDefaultInstance()
    
    @staticmethod
    def newInstance(p0=None, p1=None):
        return TransformerFactory.newInstance(p0, p1)