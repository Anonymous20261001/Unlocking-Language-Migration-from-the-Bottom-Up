import unittest
from unittest.mock import MagicMock
from urllib.request import URLopener


class TestJavaNetURLConnectionAutoTest(unittest.TestCase):

    def test_getDefaultUseCaches_test_13255(self, p0):
        URLConnectionWrapper.getDefaultUseCaches(p0)

    def test_getFileNameMap_test_13256(self):
        URLConnectionWrapper.getFileNameMap()

    def test_setFileNameMap_test_13257(self, p0):
        URLConnectionWrapper.setFileNameMap(p0)

    def test_setDefaultAllowUserInteraction_test_13258(self, p0):
        URLConnectionWrapper.setDefaultAllowUserInteraction(p0)

    def test_getDefaultAllowUserInteraction_test_13259(self):
        URLConnectionWrapper.getDefaultAllowUserInteraction()

    def test_setDefaultUseCaches_test_13260(self, p0, p1):
        URLConnectionWrapper.setDefaultUseCaches(p0, p1)

    def test_setDefaultRequestProperty_test_13261(self, p0, p1):
        URLConnectionWrapper.setDefaultRequestProperty(p0, p1)

    def test_getDefaultRequestProperty_test_13262(self, p0):
        URLConnectionWrapper.getDefaultRequestProperty(p0)

    def test_setContentHandlerFactory_test_13263(self, p0):
        URLConnectionWrapper.setContentHandlerFactory(p0)

    def test_guessContentTypeFromName_test_13264(self, p0):
        URLConnectionWrapper.guessContentTypeFromName(p0)


class URLConnectionWrapper:
    """Wrapper class for URLConnection static methods"""

    @staticmethod
    def getDefaultUseCaches(p0):
        return URLopener().open(p0) is not None

    @staticmethod
    def getFileNameMap():
        return {}

    @staticmethod
    def setFileNameMap(p0):
        return p0

    @staticmethod
    def setDefaultAllowUserInteraction(p0):
        return p0

    @staticmethod
    def getDefaultAllowUserInteraction():
        return False

    @staticmethod
    def setDefaultUseCaches(p0, p1):
        return p0, p1

    @staticmethod
    def setDefaultRequestProperty(p0, p1):
        return p0, p1

    @staticmethod
    def getDefaultRequestProperty(p0):
        return p0

    @staticmethod
    def setContentHandlerFactory(p0):
        return p0

    @staticmethod
    def guessContentTypeFromName(p0):
        return p0


if __name__ == '__main__':
    unittest.main()