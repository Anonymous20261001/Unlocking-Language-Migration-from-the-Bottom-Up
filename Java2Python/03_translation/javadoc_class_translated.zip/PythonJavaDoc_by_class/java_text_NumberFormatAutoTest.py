import unittest
from datetime import datetime
import locale
from decimal import Decimal


class TestNumberFormat(unittest.TestCase):
    def getInstance_test_9557(self, p0):
        NumberFormat.getInstance(p0)
    
    def getInstance_test_9558(self):
        NumberFormat.getInstance()
    
    def getAvailableLocales_test_9559(self):
        NumberFormat.getAvailableLocales()
    
    def getCurrencyInstance_test_9560(self, p0):
        NumberFormat.getCurrencyInstance(p0)
    
    def getCurrencyInstance_test_9561(self):
        NumberFormat.getCurrencyInstance()
    
    def getPercentInstance_test_9562(self):
        NumberFormat.getPercentInstance()
    
    def getPercentInstance_test_9563(self, p0):
        NumberFormat.getPercentInstance(p0)
    
    def getIntegerInstance_test_9564(self, p0):
        NumberFormat.getIntegerInstance(p0)
    
    def getIntegerInstance_test_9565(self):
        NumberFormat.getIntegerInstance()
    
    def getCompactNumberInstance_test_9566(self, p0, p1):
        NumberFormat.getCompactNumberInstance(p0, p1)
    
    def getCompactNumberInstance_test_9567(self):
        NumberFormat.getCompactNumberInstance()
    
    def getNumberInstance_test_9568(self):
        NumberFormat.getNumberInstance()
    
    def getNumberInstance_test_9569(self, p0):
        NumberFormat.getNumberInstance(p0)


class NumberFormat:
    @staticmethod
    def getInstance(locale=None):
        return NumberFormat(locale)
    
    @staticmethod
    def getAvailableLocales():
        return list(locale.locale_alias.keys())
    
    @staticmethod
    def getCurrencyInstance(locale=None):
        return NumberFormat(locale, 'currency')
    
    @staticmethod
    def getPercentInstance(locale=None):
        return NumberFormat(locale, 'percent')
    
    @staticmethod
    def getIntegerInstance(locale=None):
        return NumberFormat(locale, 'integer')
    
    @staticmethod
    def getCompactNumberInstance(locale=None, style=None):
        return NumberFormat(locale, 'compact', style)
    
    @staticmethod
    def getNumberInstance(locale=None):
        return NumberFormat(locale, 'number')
    
    def __init__(self, locale=None, format_type='number', style=None):
        self.locale = locale
        self.format_type = format_type
        self.style = style


if __name__ == '__main__':
    unittest.main()