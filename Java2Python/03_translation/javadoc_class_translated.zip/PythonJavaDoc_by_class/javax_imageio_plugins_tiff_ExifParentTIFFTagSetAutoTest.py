import unittest

class TestExifParentTIFFTagSet(unittest.TestCase):
    def getInstance_test_4663(self):
        ExifParentTIFFTagSet.getInstance()

class ExifParentTIFFTagSet:
    _instance = None

    @classmethod
    def getInstance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

if __name__ == '__main__':
    unittest.main()