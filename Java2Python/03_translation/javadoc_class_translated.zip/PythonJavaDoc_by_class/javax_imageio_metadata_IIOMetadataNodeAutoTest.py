import unittest
from javax.imageio.metadata import IIOMetadataNode
from org.w3c.dom import Attr, Node, UserDataHandler

class TestIIOMetadataNode(unittest.TestCase):
    def test_getTagName_test_5556(self):
        instance = IIOMetadataNode()
        instance.getTagName()

    def test_getAttributeNode_test_5557(self, p0):
        instance = IIOMetadataNode()
        instance.getAttributeNode(p0)

    def test_setAttributeNode_test_5558(self, p0):
        instance = IIOMetadataNode()
        instance.setAttributeNode(p0)

    def test_removeAttributeNode_test_5559(self, p0):
        instance = IIOMetadataNode()
        instance.removeAttributeNode(p0)

    def test_setAttributeNS_test_5560(self, p0, p1, p2):
        instance = IIOMetadataNode()
        instance.setAttributeNS(p0, p1, p2)

    def test_removeAttributeNS_test_5561(self, p0, p1):
        instance = IIOMetadataNode()
        instance.removeAttributeNS(p0, p1)

    def test_getAttributeNodeNS_test_5562(self, p0, p1):
        instance = IIOMetadataNode()
        instance.getAttributeNodeNS(p0, p1)

    def test_setAttributeNodeNS_test_5563(self, p0):
        instance = IIOMetadataNode()
        instance.setAttributeNodeNS(p0)

    def test_hasAttribute_test_5564(self, p0):
        instance = IIOMetadataNode()
        instance.hasAttribute(p0)

    def test_hasAttributeNS_test_5565(self, p0, p1):
        instance = IIOMetadataNode()
        instance.hasAttributeNS(p0, p1)

    def test_getSchemaTypeInfo_test_5566(self):
        instance = IIOMetadataNode()
        instance.getSchemaTypeInfo()

    def test_setIdAttribute_test_5567(self, p0, p1):
        instance = IIOMetadataNode()
        instance.setIdAttribute(p0, p1)

    def test_setIdAttributeNode_test_5568(self, p0, p1):
        instance = IIOMetadataNode()
        instance.setIdAttributeNode(p0, p1)

    def test_getNamespaceURI_test_5569(self):
        instance = IIOMetadataNode()
        instance.getNamespaceURI()

    def test_removeAttribute_test_5570(self, p0):
        instance = IIOMetadataNode()
        instance.removeAttribute(p0)

    def test_getUserObject_test_5571(self):
        instance = IIOMetadataNode()
        instance.getUserObject()

    def test_getNextSibling_test_5572(self):
        instance = IIOMetadataNode()
        instance.getNextSibling()

    def test_getPreviousSibling_test_5573(self):
        instance = IIOMetadataNode()
        instance.getPreviousSibling()

    def test_getFirstChild_test_5574(self):
        instance = IIOMetadataNode()
        instance.getFirstChild()

    def test_getLastChild_test_5575(self):
        instance = IIOMetadataNode()
        instance.getLastChild()

    def test_setUserObject_test_5576(self, p0):
        instance = IIOMetadataNode()
        instance.setUserObject(p0)

    def test_getUserData_test_5577(self, p0):
        instance = IIOMetadataNode()
        instance.getUserData(p0)

    def test_setUserData_test_5578(self, p0, p1, p2):
        instance = IIOMetadataNode()
        instance.setUserData(p0, p1, p2)

    def test_getPrefix_test_5579(self):
        instance = IIOMetadataNode()
        instance.getPrefix()

    def test_getElementsByTagName_test_5580(self, p0):
        instance = IIOMetadataNode()
        instance.getElementsByTagName(p0)

    def test_getElementsByTagNameNS_test_5581(self, p0, p1):
        instance = IIOMetadataNode()
        instance.getElementsByTagNameNS(p0, p1)

    def test_getNodeName_test_5582(self):
        instance = IIOMetadataNode()
        instance.getNodeName()

    def test_getNodeValue_test_5583(self):
        instance = IIOMetadataNode()
        instance.getNodeValue()

    def test_setNodeValue_test_5584(self, p0):
        instance = IIOMetadataNode()
        instance.setNodeValue(p0)

    def test_getParentNode_test_5585(self):
        instance = IIOMetadataNode()
        instance.getParentNode()

    def test_getChildNodes_test_5586(self):
        instance = IIOMetadataNode()
        instance.getChildNodes()

    def test_getOwnerDocument_test_5587(self):
        instance = IIOMetadataNode()
        instance.getOwnerDocument()

    def test_insertBefore_test_5588(self, p0, p1):
        instance = IIOMetadataNode()
        instance.insertBefore(p0, p1)

    def test_replaceChild_test_5589(self, p0, p1):
        instance = IIOMetadataNode()
        instance.replaceChild(p0, p1)

    def test_removeChild_test_5590(self, p0):
        instance = IIOMetadataNode()
        instance.removeChild(p0)

    def test_appendChild_test_5591(self, p0):
        instance = IIOMetadataNode()
        instance.appendChild(p0)

    def test_hasChildNodes_test_5592(self):
        instance = IIOMetadataNode()
        instance.hasChildNodes()

    def test_cloneNode_test_5593(self, p0):
        instance = IIOMetadataNode()
        instance.cloneNode(p0)

    def test_setPrefix_test_5594(self, p0):
        instance = IIOMetadataNode()
        instance.setPrefix(p0)

    def test_getLocalName_test_5595(self):
        instance = IIOMetadataNode()
        instance.getLocalName()

    def test_hasAttributes_test_5596(self):
        instance = IIOMetadataNode()
        instance.hasAttributes()

    def test_getBaseURI_test_5597(self):
        instance = IIOMetadataNode()
        instance.getBaseURI()

    def test_compareDocumentPosition_test_5598(self, p0):
        instance = IIOMetadataNode()
        instance.compareDocumentPosition(p0)

    def test_getTextContent_test_5599(self):
        instance = IIOMetadataNode()
        instance.getTextContent()

    def test_setTextContent_test_5600(self, p0):
        instance = IIOMetadataNode()
        instance.setTextContent(p0)

    def test_isSameNode_test_5601(self, p0):
        instance = IIOMetadataNode()
        instance.isSameNode(p0)

    def test_lookupPrefix_test_5602(self, p0):
        instance = IIOMetadataNode()
        instance.lookupPrefix(p0)

    def test_isDefaultNamespace_test_5603(self, p0):
        instance = IIOMetadataNode()
        instance.isDefaultNamespace(p0)

    def test_lookupNamespaceURI_test_5604(self, p0):
        instance = IIOMetadataNode()
        instance.lookupNamespaceURI(p0)

    def test_isEqualNode_test_5605(self, p0):
        instance = IIOMetadataNode()
        instance.isEqualNode(p0)

    def test_getLength_test_5606(self):
        instance = IIOMetadataNode()
        instance.getLength()

    def test_isSupported_test_5607(self, p0, p1):
        instance = IIOMetadataNode()
        instance.isSupported(p0, p1)

    def test_getAttributes_test_5608(self):
        instance = IIOMetadataNode()
        instance.getAttributes()

    def test_normalize_test_5609(self):
        instance = IIOMetadataNode()
        instance.normalize()

    def test_setAttribute_test_5610(self, p0, p1):
        instance = IIOMetadataNode()
        instance.setAttribute(p0, p1)

    def test_getAttribute_test_5611(self, p0):
        instance = IIOMetadataNode()
        instance.getAttribute(p0)

    def test_item_test_5612(self, p0):
        instance = IIOMetadataNode()
        instance.item(p0)

    def test_getNodeType_test_5613(self):
        instance = IIOMetadataNode()
        instance.getNodeType()

    def test_getFeature_test_5614(self, p0, p1):
        instance = IIOMetadataNode()
        instance.getFeature(p0, p1)

    def test_getAttributeNS_test_5615(self, p0, p1):
        instance = IIOMetadataNode()
        instance.getAttributeNS(p0, p1)

    def test_setIdAttributeNS_test_5616(self, p0, p1, p2):
        instance = IIOMetadataNode()
        instance.setIdAttributeNS(p0, p1, p2)


class IIOMetadataNodeWrapper:
    def __init__(self):
        self.instance = IIOMetadataNode()

    def getTagName(self):
        return self.instance.getTagName()

    def getAttributeNode(self, p0):
        return self.instance.getAttributeNode(p0)

    def setAttributeNode(self, p0):
        return self.instance.setAttributeNode(p0)

    def removeAttributeNode(self, p0):
        return self.instance.removeAttributeNode(p0)

    def setAttributeNS(self, p0, p1, p2):
        return self.instance.setAttributeNS(p0, p1, p2)

    def removeAttributeNS(self, p0, p1):
        return self.instance.removeAttributeNS(p0, p1)

    def getAttributeNodeNS(self, p0, p1):
        return self.instance.getAttributeNodeNS(p0, p1)

    def setAttributeNodeNS(self, p0):
        return self.instance.setAttributeNodeNS(p0)

    def hasAttribute(self, p0):
        return self.instance.hasAttribute(p0)

    def hasAttributeNS(self, p0, p1):
        return self.instance.hasAttributeNS(p0, p1)

    def getSchemaTypeInfo(self):
        return self.instance.getSchemaTypeInfo()

    def setIdAttribute(self, p0, p1):
        return self.instance.setIdAttribute(p0, p1)

    def setIdAttributeNode(self, p0, p1):
        return self.instance.setIdAttributeNode(p0, p1)

    def getNamespaceURI(self):
        return self.instance.getNamespaceURI()

    def removeAttribute(self, p0):
        return self.instance.removeAttribute(p0)

    def getUserObject(self):
        return self.instance.getUserObject()

    def getNextSibling(self):
        return self.instance.getNextSibling()

    def getPreviousSibling(self):
        return self.instance.getPreviousSibling()

    def getFirstChild(self):
        return self.instance.getFirstChild()

    def getLastChild(self):
        return self.instance.getLastChild()

    def setUserObject(self, p0):
        return self.instance.setUserObject(p0)

    def getUserData(self, p0):
        return self.instance.getUserData(p0)

    def setUserData(self, p0, p1, p2):
        return self.instance.setUserData(p0, p1, p2)

    def getPrefix(self):
        return self.instance.getPrefix()

    def getElementsByTagName(self, p0):
        return self.instance.getElementsByTagName(p0)

    def getElementsByTagNameNS(self, p0, p1):
        return self.instance.getElementsByTagNameNS(p0, p1)

    def getNodeName(self):
        return self.instance.getNodeName()

    def getNodeValue(self):
        return self.instance.getNodeValue()

    def setNodeValue(self, p0):
        return self.instance.setNodeValue(p0)

    def getParentNode(self):
        return self.instance.getParentNode()

    def getChildNodes(self):
        return self.instance.getChildNodes()

    def getOwnerDocument(self):
        return self.instance.getOwnerDocument()

    def insertBefore(self, p0, p1):
        return self.instance.insertBefore(p0, p1)

    def replaceChild(self, p0, p1):
        return self.instance.replaceChild(p0, p1)

    def removeChild(self, p0):
        return self.instance.removeChild(p0)

    def appendChild(self, p0):
        return self.instance.appendChild(p0)

    def hasChildNodes(self):
        return self.instance.hasChildNodes()

    def cloneNode(self, p0):
        return self.instance.cloneNode(p0)

    def setPrefix(self, p0):
        return self.instance.setPrefix(p0)

    def getLocalName(self):
        return self.instance.getLocalName()

    def hasAttributes(self):
        return self.instance.hasAttributes()

    def getBaseURI(self):
        return self.instance.getBaseURI()

    def compareDocumentPosition(self, p0):
        return self.instance.compareDocumentPosition(p0)

    def getTextContent(self):
        return self.instance.getTextContent()

    def setTextContent(self, p0):
        return self.instance.setTextContent(p0)

    def isSameNode(self, p0):
        return self.instance.isSameNode(p0)

    def lookupPrefix(self, p0):
        return self.instance.lookupPrefix(p0)

    def isDefaultNamespace(self, p0):
        return self.instance.isDefaultNamespace(p0)

    def lookupNamespaceURI(self, p0):
        return self.instance.lookupNamespaceURI(p0)

    def isEqualNode(self, p0):
        return self.instance.isEqualNode(p0)

    def getLength(self):
        return self.instance.getLength()

    def isSupported(self, p0, p1):
        return self.instance.isSupported(p0, p1)

    def getAttributes(self):
        return self.instance.getAttributes()

    def normalize(self):
        return self.instance.normalize()

    def setAttribute(self, p0, p1):
        return self.instance.setAttribute(p0, p1)

    def getAttribute(self, p0):
        return self.instance.getAttribute(p0)

    def item(self, p0):
        return self.instance.item(p0)

    def getNodeType(self):
        return self.instance.getNodeType()

    def getFeature(self, p0, p1):
        return self.instance.getFeature(p0, p1)

    def getAttributeNS(self, p0, p1):
        return self.instance.getAttributeNS(p0, p1)

    def setIdAttributeNS(self, p0, p1, p2):
        return self.instance.setIdAttributeNS(p0, p1, p2)


if __name__ == '__main__':
    unittest.main()