import unittest
from unittest.mock import MagicMock
from jarfile import JarFile

class TestJarFileAutoTest(unittest.TestCase):
    def test_runtimeVersion_test_5997(self):
        JarFile.runtimeVersion()

    def test_baseVersion_test_5998(self):
        JarFile.baseVersion()


class JarFile:
    @staticmethod
    def runtimeVersion():
        return MagicMock()

    @staticmethod
    def baseVersion():
        return MagicMock()

if __name__ == '__main__':
    unittest.main()