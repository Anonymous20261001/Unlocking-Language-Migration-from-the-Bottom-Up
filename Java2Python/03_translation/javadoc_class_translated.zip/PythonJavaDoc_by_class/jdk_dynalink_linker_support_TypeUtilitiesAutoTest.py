import unittest
from typing import Optional


class TestTypeUtilities(unittest.TestCase):
    
    def test_isWrapperType_test_13103(self):
        p0 = int
        result = TypeUtilities.isWrapperType(p0)
        self.assertIsNotNone(result)
    
    def test_getPrimitiveType_test_13104(self):
        p0 = int
        result = TypeUtilities.getPrimitiveType(p0)
        self.assertIsNotNone(result)
    
    def test_isSubtype_test_13105(self):
        p0 = int
        p1 = object
        result = TypeUtilities.isSubtype(p0, p1)
        self.assertIsNotNone(result)
    
    def test_getWrapperType_test_13106(self):
        p0 = int
        result = TypeUtilities.getWrapperType(p0)
        self.assertIsNotNone(result)
    
    def test_isConvertibleWithoutLoss_test_13107(self):
        p0 = int
        p1 = float
        result = TypeUtilities.isConvertibleWithoutLoss(p0, p1)
        self.assertIsNotNone(result)
    
    def test_isMethodInvocationConvertible_test_13108(self):
        p0 = int
        p1 = float
        result = TypeUtilities.isMethodInvocationConvertible(p0, p1)
        self.assertIsNotNone(result)
    
    def test_getPrimitiveTypeByName_test_13109(self):
        p0 = "int"
        result = TypeUtilities.getPrimitiveTypeByName(p0)
        self.assertIsNotNone(result)


class TypeUtilities:
    """Wrapper class for type utilities."""
    
    @staticmethod
    def isWrapperType(cls: type) -> bool:
        """Check if the given class is a wrapper type."""
        return cls in {bool, byte, short, int, long, float, double, char}
    
    @staticmethod
    def getPrimitiveType(cls: type) -> Optional[type]:
        """Get the primitive type corresponding to a wrapper type."""
        wrapper_to_primitive = {
            bool: bool,
            byte: int,
            short: int,
            int: int,
            long: int,
            float: float,
            double: float,
            char: str
        }
        return wrapper_to_primitive.get(cls)
    
    @staticmethod
    def isSubtype(subtype: type, supertype: type) -> bool:
        """Check if subtype is a subtype of supertype."""
        return issubclass(subtype, supertype)
    
    @staticmethod
    def getWrapperType(cls: type) -> Optional[type]:
        """Get the wrapper type corresponding to a primitive type."""
        primitive_to_wrapper = {
            bool: bool,
            int: int,
            float: float,
            str: str
        }
        return primitive_to_wrapper.get(cls)
    
    @staticmethod
    def isConvertibleWithoutLoss(source: type, target: type) -> bool:
        """Check if source can be converted to target without loss."""
        # Simplified conversion rules
        if source == target:
            return True
        if source == int and target in {float, complex}:
            return True
        if source == float and target == complex:
            return True
        return False
    
    @staticmethod
    def isMethodInvocationConvertible(source: type, target: type) -> bool:
        """Check if source can be converted to target for method invocation."""
        return TypeUtilities.isConvertibleWithoutLoss(source, target) or TypeUtilities.isSubtype(source, target)
    
    @staticmethod
    def getPrimitiveTypeByName(name: str) -> Optional[type]:
        """Get primitive type by its name."""
        primitive_types = {
            "boolean": bool,
            "byte": int,
            "short": int,
            "int": int,
            "long": int,
            "float": float,
            "double": float,
            "char": str
        }
        return primitive_types.get(name)


if __name__ == '__main__':
    unittest.main()