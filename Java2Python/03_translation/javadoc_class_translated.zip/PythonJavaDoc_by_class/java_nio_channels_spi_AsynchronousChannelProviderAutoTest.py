import unittest
from java.nio.channels.spi import AsynchronousChannelProvider

class TestJavaNioChannelsSpiAsynchronousChannelProviderAutoTest(unittest.TestCase):
    def provider_test_544(self):
        AsynchronousChannelProvider.provider()


class AsynchronousChannelProviderWrapper:
    @staticmethod
    def provider():
        return AsynchronousChannelProvider.provider()