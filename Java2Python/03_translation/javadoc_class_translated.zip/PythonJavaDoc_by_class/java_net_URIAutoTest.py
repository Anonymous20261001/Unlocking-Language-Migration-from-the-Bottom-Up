import unittest
from urllib.parse import urlparse

class TestURIMethods(unittest.TestCase):
    def test_create_test_13237(self):
        uri = URI.create("https://example.com")
        self.assertIsNotNone(uri)

    def test_create_test_13237_with_empty_string(self):
        uri = URI.create("")
        self.assertIsInstance(uri, URI)

    def test_create_test_13237_with_invalid_uri(self):
        with self.assertRaises(ValueError):
            URI.create("invalid uri")

    def test_create_test_13237_with_query(self):
        uri = URI.create("https://example.com/path?query=1")
        self.assertEqual(uri.query, "query=1")

    def test_create_test_13237_with_fragment(self):
        uri = URI.create("https://example.com/path#fragment")
        self.assertEqual(uri.fragment, "fragment")

    def test_create_test_13237_with_port(self):
        uri = URI.create("https://example.com:8080/path")
        self.assertEqual(uri.port, 8080)

    def test_create_test_13237_with_user_info(self):
        uri = URI.create("https://user:pass@example.com/path")
        self.assertEqual(uri.userinfo, "user:pass")

    def test_create_test_13237_with_scheme(self):
        uri = URI.create("ftp://example.com/file")
        self.assertEqual(uri.scheme, "ftp")

    def test_create_test_13237_with_path(self):
        uri = URI.create("https://example.com/path/to/file")
        self.assertEqual(uri.path, "/path/to/file")

    def test_create_test_13237_with_relative_uri(self):
        uri = URI.create("/relative/path")
        self.assertEqual(uri.path, "/relative/path")

    def test_create_test_13237_with_authority(self):
        uri = URI.create("https://example.com")
        self.assertEqual(uri.netloc, "example.com")

    def test_create_test_13237_with_ipv6(self):
        uri = URI.create("https://[::1]:8080/path")
        self.assertEqual(uri.hostname, "::1")

    def test_create_test_13237_with_percent_encoding(self):
        uri = URI.create("https://example.com/path%20with%20spaces")
        self.assertEqual(uri.path, "/path%20with%20spaces")

    def test_create_test_13237_with_special_chars(self):
        uri = URI.create("https://example.com/path?q=hello world")
        self.assertEqual(uri.query, "q=hello world")

    def test_create_test_13237_with_long_uri(self):
        long_path = "/" + "a" * 1000
        uri = URI.create("https://example.com" + long_path)
        self.assertEqual(uri.path, long_path)


class URI:
    def __init__(self, uri_string):
        self.uri_string = uri_string
        parsed = urlparse(uri_string)
        self.scheme = parsed.scheme
        self.netloc = parsed.netloc
        self.path = parsed.path
        self.params = parsed.params
        self.query = parsed.query
        self.fragment = parsed.fragment
        self.username = parsed.username
        self.password = parsed.password
        self.hostname = parsed.hostname
        self.port = parsed.port
        self.userinfo = f"{parsed.username}:{parsed.password}" if parsed.username else None

    @classmethod
    def create(cls, uri_string):
        if not isinstance(uri_string, str):
            raise TypeError("URI string must be a string")
        if " " in uri_string:
            raise ValueError("Invalid URI: contains spaces")
        return cls(uri_string)

    def __str__(self):
        return self.uri_string

    def __repr__(self):
        return f"URI('{self.uri_string}')"