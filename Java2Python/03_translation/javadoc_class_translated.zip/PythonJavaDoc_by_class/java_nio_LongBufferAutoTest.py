import unittest
import array


class TestLongBuffer(unittest.TestCase):

    def wrap_test_8207(self, p0):
        LongBuffer.wrap(p0)

    def wrap_test_8208(self, p0, p1, p2):
        LongBuffer.wrap(p0, p1, p2)

    def allocate_test_8209(self, p0):
        LongBuffer.allocate(p0)


class LongBuffer:
    """Wrapper class mimicking java.nio.LongBuffer functionality"""

    def __init__(self, data, offset=0, length=None):
        self._data = data
        self._offset = offset
        self._length = length if length is not None else len(data)

    @classmethod
    def wrap(cls, array_data, offset=0, length=None):
        """Wrap an array of longs into a LongBuffer"""
        if isinstance(array_data, array.array):
            data = array_data
        else:
            data = array.array('q', array_data)
        return cls(data, offset, length if length is not None else len(data))

    @classmethod
    def allocate(cls, capacity):
        """Allocate a new LongBuffer with given capacity"""
        data = array.array('q', [0] * capacity)
        return cls(data, 0, capacity)


if __name__ == '__main__':
    unittest.main()