import unittest
from datetime import time
from datetime import datetime
from datetime import timezone
from datetime import timedelta
from zoneinfo import ZoneInfo
from typing import Any


class TestLocalTime(unittest.TestCase):
    def of_test_8080(self, p0: int, p1: int, p2: int, p3: int):
        LocalTime.of(p0, p1, p2, p3)

    def of_test_8081(self, p0: int, p1: int):
        LocalTime.of(p0, p1)

    def of_test_8082(self, p0: int, p1: int, p2: int):
        LocalTime.of(p0, p1, p2)

    def from_test_8083(self, p0: Any):
        LocalTime.from(p0)

    def parse_test_8084(self, p0: str):
        LocalTime.parse(p0)

    def parse_test_8085(self, p0: str, p1: Any):
        LocalTime.parse(p0, p1)

    def now_test_8086(self):
        LocalTime.now()

    def now_test_8087(self, p0: Any):
        LocalTime.now(p0)

    def now_test_8088(self, p0: Any):
        LocalTime.now(p0)

    def ofInstant_test_8089(self, p0: Any, p1: Any):
        LocalTime.ofInstant(p0, p1)

    def ofNanoOfDay_test_8090(self, p0: int):
        LocalTime.ofNanoOfDay(p0)

    def ofSecondOfDay_test_8091(self, p0: int):
        LocalTime.ofSecondOfDay(p0)


class LocalTime:
    @staticmethod
    def of(hour: int, minute: int, second: int = 0, nano: int = 0) -> time:
        return time(hour, minute, second, nano)

    @staticmethod
    def from(temporal: Any) -> time:
        if isinstance(temporal, time):
            return temporal
        elif isinstance(temporal, datetime):
            return temporal.time()
        else:
            raise ValueError(f"Cannot convert {type(temporal)} to LocalTime")

    @staticmethod
    def parse(text: str, formatter: Any = None) -> time:
        if formatter is None:
            formats = ["%H:%M:%S", "%H:%M", "%H:%M:%S.%f"]
            for fmt in formats:
                try:
                    return datetime.strptime(text, fmt).time()
                except ValueError:
                    continue
            raise ValueError(f"Unable to parse time: {text}")
        else:
            return formatter.parse(text)

    @staticmethod
    def now(clock: Any = None) -> time:
        if clock is None:
            return datetime.now().time()
        elif isinstance(clock, timezone):
            return datetime.now(clock).time()
        elif isinstance(clock, ZoneInfo):
            return datetime.now(clock).time()
        else:
            return clock.now().time()

    @staticmethod
    def ofInstant(instant: Any, zone: Any) -> time:
        if isinstance(instant, datetime):
            if isinstance(zone, ZoneInfo):
                return instant.astimezone(zone).time()
            elif isinstance(zone, timezone):
                return instant.astimezone(zone).time()
        return datetime.fromtimestamp(instant, tz=zone).time()

    @staticmethod
    def ofNanoOfDay(nano_of_day: int) -> time:
        seconds = nano_of_day // 1_000_000_000
        nanos = nano_of_day % 1_000_000_000
        return time(seconds // 3600, (seconds % 3600) // 60, seconds % 60, nanos)

    @staticmethod
    def ofSecondOfDay(second_of_day: int) -> time:
        hours = second_of_day // 3600
        minutes = (second_of_day % 3600) // 60
        seconds = second_of_day % 60
        return time(hours, minutes, seconds)


if __name__ == '__main__':
    unittest.main()