import unittest
import math
import struct

class TestJavaLangStrictMath(unittest.TestCase):
    def abs_test_11593(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.abs(p0)

    def abs_test_11594(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.abs(p0)

    def abs_test_11595(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.abs(p0)

    def abs_test_11596(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.abs(p0)

    def sin_test_11597(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.sin(p0)

    def cos_test_11598(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.cos(p0)

    def tan_test_11599(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.tan(p0)

    def atan2_test_11600(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.atan2(p0, p1)

    def sqrt_test_11601(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.sqrt(p0)

    def log_test_11602(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.log(p0)

    def log10_test_11603(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.log10(p0)

    def pow_test_11604(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.pow(p0, p1)

    def exp_test_11605(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.exp(p0)

    def min_test_11606(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.min(p0, p1)

    def min_test_11607(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.min(p0, p1)

    def min_test_11608(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.min(p0, p1)

    def min_test_11609(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.min(p0, p1)

    def max_test_11610(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.max(p0, p1)

    def max_test_11611(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.max(p0, p1)

    def max_test_11612(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.max(p0, p1)

    def max_test_11613(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.max(p0, p1)

    def floor_test_11614(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.floor(p0)

    def ceil_test_11615(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.ceil(p0)

    def rint_test_11616(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.rint(p0)

    def round_test_11617(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.round(p0)

    def round_test_11618(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.round(p0)

    def tanh_test_11619(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.tanh(p0)

    def cbrt_test_11620(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.cbrt(p0)

    def addExact_test_11621(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.addExact(p0, p1)

    def addExact_test_11622(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.addExact(p0, p1)

    def decrementExact_test_11623(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.decrementExact(p0)

    def decrementExact_test_11624(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.decrementExact(p0)

    def incrementExact_test_11625(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.incrementExact(p0)

    def incrementExact_test_11626(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.incrementExact(p0)

    def multiplyExact_test_11627(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.multiplyExact(p0, p1)

    def multiplyExact_test_11628(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.multiplyExact(p0, p1)

    def multiplyExact_test_11629(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.multiplyExact(p0, p1)

    def multiplyHigh_test_11630(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.multiplyHigh(p0, p1)

    def unsignedMultiplyHigh_test_11631(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedMultiplyHigh(p0, p1)

    def negateExact_test_11632(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.negateExact(p0)

    def negateExact_test_11633(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.negateExact(p0)

    def subtractExact_test_11634(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.subtractExact(p0, p1)

    def subtractExact_test_11635(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.subtractExact(p0, p1)

    def fma_test_11636(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.fma(p0, p1, p2)

    def fma_test_11637(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.fma(p0, p1, p2)

    def copySign_test_11638(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.copySign(p0, p1)

    def copySign_test_11639(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.copySign(p0, p1)

    def signum_test_11640(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.signum(p0)

    def signum_test_11641(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.signum(p0)

    def clamp_test_11642(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.clamp(p0, p1, p2)

    def clamp_test_11643(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.clamp(p0, p1, p2)

    def clamp_test_11644(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.clamp(p0, p1, p2)

    def clamp_test_11645(self, p0, p1, p2):
        wrapper = StrictMathWrapper()
        wrapper.clamp(p0, p1, p2)

    def scalb_test_11646(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.scalb(p0, p1)

    def scalb_test_11647(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.scalb(p0, p1)

    def getExponent_test_11648(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.getExponent(p0)

    def getExponent_test_11649(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.getExponent(p0)

    def floorMod_test_11650(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorMod(p0, p1)

    def floorMod_test_11651(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorMod(p0, p1)

    def floorMod_test_11652(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorMod(p0, p1)

    def asin_test_11653(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.asin(p0)

    def acos_test_11654(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.acos(p0)

    def atan_test_11655(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.atan(p0)

    def IEEEremainder_test_11656(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.IEEEremainder(p0, p1)

    def floorDiv_test_11657(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorDiv(p0, p1)

    def floorDiv_test_11658(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorDiv(p0, p1)

    def floorDiv_test_11659(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorDiv(p0, p1)

    def ceilDiv_test_11660(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilDiv(p0, p1)

    def ceilDiv_test_11661(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilDiv(p0, p1)

    def ceilDiv_test_11662(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilDiv(p0, p1)

    def ceilMod_test_11663(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilMod(p0, p1)

    def ceilMod_test_11664(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilMod(p0, p1)

    def ceilMod_test_11665(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilMod(p0, p1)

    def sinh_test_11666(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.sinh(p0)

    def cosh_test_11667(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.cosh(p0)

    def hypot_test_11668(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.hypot(p0, p1)

    def expm1_test_11669(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.expm1(p0)

    def log1p_test_11670(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.log1p(p0)

    def unsignedMultiplyExact_test_11671(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedMultiplyExact(p0, p1)

    def unsignedMultiplyExact_test_11672(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedMultiplyExact(p0, p1)

    def unsignedMultiplyExact_test_11673(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedMultiplyExact(p0, p1)

    def toRadians_test_11674(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.toRadians(p0)

    def toDegrees_test_11675(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.toDegrees(p0)

    def random_test_11676(self):
        wrapper = StrictMathWrapper()
        wrapper.random()

    def divideExact_test_11677(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.divideExact(p0, p1)

    def divideExact_test_11678(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.divideExact(p0, p1)

    def floorDivExact_test_11679(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorDivExact(p0, p1)

    def floorDivExact_test_11680(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.floorDivExact(p0, p1)

    def ceilDivExact_test_11681(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilDivExact(p0, p1)

    def ceilDivExact_test_11682(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.ceilDivExact(p0, p1)

    def toIntExact_test_11683(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.toIntExact(p0)

    def multiplyFull_test_11684(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.multiplyFull(p0, p1)

    def absExact_test_11685(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.absExact(p0)

    def absExact_test_11686(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.absExact(p0)

    def ulp_test_11687(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.ulp(p0)

    def ulp_test_11688(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.ulp(p0)

    def nextAfter_test_11689(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.nextAfter(p0, p1)

    def nextAfter_test_11690(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.nextAfter(p0, p1)

    def nextUp_test_11691(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.nextUp(p0)

    def nextUp_test_11692(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.nextUp(p0)

    def nextDown_test_11693(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.nextDown(p0)

    def nextDown_test_11694(self, p0):
        wrapper = StrictMathWrapper()
        wrapper.nextDown(p0)

    def powExact_test_11695(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.powExact(p0, p1)

    def powExact_test_11696(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.powExact(p0, p1)

    def unsignedPowExact_test_11697(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedPowExact(p0, p1)

    def unsignedPowExact_test_11698(self, p0, p1):
        wrapper = StrictMathWrapper()
        wrapper.unsignedPowExact(p0, p1)


class StrictMathWrapper:
    def abs(self, a):
        return abs(a)

    def sin(self, a):
        return math.sin(a)

    def cos(self, a):
        return math.cos(a)

    def tan(self, a):
        return math.tan(a)

    def atan2(self, y, x):
        return math.atan2(y, x)

    def sqrt(self, a):
        return math.sqrt(a)

    def log(self, a):
        return math.log(a)

    def log10(self, a):
        return math.log10(a)

    def pow(self, a, b):
        return math.pow(a, b)

    def exp(self, a):
        return math.exp(a)

    def min(self, a, b):
        return min(a, b)

    def max(self, a, b):
        return max(a, b)

    def floor(self, a):
        return math.floor(a)

    def ceil(self, a):
        return math.ceil(a)

    def rint(self, a):
        return round(a)

    def round(self, a):
        return round(a)

    def tanh(self, a):
        return math.tanh(a)

    def cbrt(self, a):
        return math.cbrt(a)

    def addExact(self, a, b):
        result = a + b
        if (isinstance(a, int) and isinstance(b, int)):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def decrementExact(self, a):
        result = a - 1
        if isinstance(a, int):
            if result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def incrementExact(self, a):
        result = a + 1
        if isinstance(a, int):
            if result > 2**31 - 1:
                raise OverflowError("integer overflow")
        return result

    def multiplyExact(self, a, b):
        result = a * b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def multiplyHigh(self, a, b):
        return (a * b) >> 64

    def unsignedMultiplyHigh(self, a, b):
        return (a * b) >> 64

    def negateExact(self, a):
        result = -a
        if isinstance(a, int):
            if result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def subtractExact(self, a, b):
        result = a - b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**31 - 1 or result < -2**31:
                raise OverflowError("integer overflow")
        return result

    def fma(self, a, b, c):
        return a * b + c

    def copySign(self, magnitude, sign):
        return math.copysign(magnitude, sign)

    def signum(self, a):
        if a > 0:
            return 1.0
        elif a < 0:
            return -1.0
        else:
            return 0.0

    def clamp(self, value, min_value, max_value):
        return max(min_value, min(value, max_value))

    def scalb(self, a, scale_factor):
        return a * (2 ** scale_factor)

    def getExponent(self, a):
        return math.getexp(a)

    def floorMod(self, a, b):
        return a % b

    def asin(self, a):
        return math.asin(a)

    def acos(self, a):
        return math.acos(a)

    def atan(self, a):
        return math.atan(a)

    def IEEEremainder(self, a, b):
        return math.remainder(a, b)

    def floorDiv(self, a, b):
        return math.floor(a / b)

    def ceilDiv(self, a, b):
        return math.ceil(a / b)

    def ceilMod(self, a, b):
        return a - self.ceilDiv(a, b) * b

    def sinh(self, a):
        return math.sinh(a)

    def cosh(self, a):
        return math.cosh(a)

    def hypot(self, a, b):
        return math.hypot(a, b)

    def expm1(self, a):
        return math.expm1(a)

    def log1p(self, a):
        return math.log1p(a)

    def unsignedMultiplyExact(self, a, b):
        result = a * b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**64 - 1:
                raise OverflowError("integer overflow")
        return result

    def toRadians(self, a):
        return math.radians(a)

    def toDegrees(self, a):
        return math.degrees(a)

    def random(self):
        import random
        return random.random()

    def divideExact(self, a, b):
        result = a / b
        if isinstance(a, int) and isinstance(b, int):
            if result != int(result):
                raise ArithmeticError("division not exact")
        return result

    def floorDivExact(self, a, b):
        result = math.floor(a / b)
        if isinstance(a, int) and isinstance(b, int):
            if result * b != a:
                raise ArithmeticError("division not exact")
        return result

    def ceilDivExact(self, a, b):
        result = math.ceil(a / b)
        if isinstance(a, int) and isinstance(b, int):
            if result * b != a:
                raise ArithmeticError("division not exact")
        return result

    def toIntExact(self, a):
        if a > 2**31 - 1 or a < -2**31:
            raise OverflowError("integer overflow")
        return int(a)

    def multiplyFull(self, a, b):
        return a * b

    def absExact(self, a):
        result = abs(a)
        if isinstance(a, int):
            if result > 2**31 - 1:
                raise OverflowError("integer overflow")
        return result

    def ulp(self, a):
        return math.ulp(a)

    def nextAfter(self, start, direction):
        return math.nextafter(start, direction)

    def nextUp(self, a):
        return math.nextafter(a, float('inf'))

    def nextDown(self, a):
        return math.nextafter(a, float('-inf'))

    def powExact(self, a, b):
        result = a ** b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**63 - 1:
                raise OverflowError("integer overflow")
        return result

    def unsignedPowExact(self, a, b):
        result = a ** b
        if isinstance(a, int) and isinstance(b, int):
            if result > 2**64 - 1:
                raise OverflowError("integer overflow")
        return result