import unittest
from unittest.mock import MagicMock
from typing import Any, Optional


class TestJavaxManagementMonitorGaugeMonitorAutoTest(unittest.TestCase):
    def test_getDifferenceMode_test_5084(self):
        instance = GaugeMonitor()
        instance.getDifferenceMode()

    def test_setDifferenceMode_test_5085(self, p0=False):
        instance = GaugeMonitor()
        instance.setDifferenceMode(p0)

    def test_getNotificationInfo_test_5086(self):
        instance = GaugeMonitor()
        instance.getNotificationInfo()

    def test_getDerivedGauge_test_5087(self):
        instance = GaugeMonitor()
        instance.getDerivedGauge()

    def test_getDerivedGauge_test_5088(self, p0=None):
        instance = GaugeMonitor()
        instance.getDerivedGauge(p0)

    def test_getDerivedGaugeTimeStamp_test_5089(self):
        instance = GaugeMonitor()
        instance.getDerivedGaugeTimeStamp()

    def test_getDerivedGaugeTimeStamp_test_5090(self, p0=None):
        instance = GaugeMonitor()
        instance.getDerivedGaugeTimeStamp(p0)

    def test_getHighThreshold_test_5091(self):
        instance = GaugeMonitor()
        instance.getHighThreshold()

    def test_getLowThreshold_test_5092(self):
        instance = GaugeMonitor()
        instance.getLowThreshold()

    def test_setThresholds_test_5093(self, p0=None, p1=None):
        instance = GaugeMonitor()
        instance.setThresholds(p0, p1)

    def test_getNotifyHigh_test_5094(self):
        instance = GaugeMonitor()
        instance.getNotifyHigh()

    def test_setNotifyHigh_test_5095(self, p0=False):
        instance = GaugeMonitor()
        instance.setNotifyHigh(p0)

    def test_getNotifyLow_test_5096(self):
        instance = GaugeMonitor()
        instance.getNotifyLow()

    def test_setNotifyLow_test_5097(self, p0=False):
        instance = GaugeMonitor()
        instance.setNotifyLow(p0)

    def test_start_test_5098(self):
        instance = GaugeMonitor()
        instance.start()

    def test_stop_test_5099(self):
        instance = GaugeMonitor()
        instance.stop()


class GaugeMonitor:
    """Wrapper class for GaugeMonitor with mocked methods."""
    
    def __init__(self):
        self._difference_mode = False
        self._notification_info = None
        self._derived_gauge = 0.0
        self._derived_gauge_timestamp = 0
        self._high_threshold = 0.0
        self._low_threshold = 0.0
        self._notify_high = False
        self._notify_low = False
        self._running = False
        self._gauges = {}

    def getDifferenceMode(self):
        return self._difference_mode

    def setDifferenceMode(self, value):
        self._difference_mode = value

    def getNotificationInfo(self):
        return self._notification_info

    def getDerivedGauge(self, object_name=None):
        if object_name is None:
            return self._derived_gauge
        return self._gauges.get(str(object_name), 0.0)

    def getDerivedGaugeTimeStamp(self, object_name=None):
        if object_name is None:
            return self._derived_gauge_timestamp
        return self._gauges.get(f"ts_{object_name}", 0)

    def getHighThreshold(self):
        return self._high_threshold

    def getLowThreshold(self):
        return self._low_threshold

    def setThresholds(self, high, low):
        self._high_threshold = high
        self._low_threshold = low

    def getNotifyHigh(self):
        return self._notify_high

    def setNotifyHigh(self, value):
        self._notify_high = value

    def getNotifyLow(self):
        return self._notify_low

    def setNotifyLow(self, value):
        self._notify_low = value

    def start(self):
        self._running = True

    def stop(self):
        self._running = False


if __name__ == '__main__':
    unittest.main()