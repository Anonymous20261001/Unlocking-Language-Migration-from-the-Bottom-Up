import unittest
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from typing import Optional


class TestJavaTimeZonedDateTime(unittest.TestCase):
    def test_ofLocal_test_13709(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456)
        p1 = ZoneInfo("America/New_York")
        p2 = timezone(timedelta(hours=-5))
        ZonedDateTimeWrapper.ofLocal(p0, p1, p2)

    def test_ofStrict_test_13710(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456)
        p1 = timezone(timedelta(hours=-5))
        p2 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.ofStrict(p0, p1, p2)

    def test_of_test_13711(self):
        p0, p1, p2, p3, p4, p5, p6 = 2024, 1, 15, 10, 30, 45, 123456789
        p7 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.of(p0, p1, p2, p3, p4, p5, p6, p7)

    def test_of_test_13712(self):
        p0 = datetime(2024, 1, 15).date()
        p1 = datetime(2024, 1, 15, 10, 30, 45).time()
        p2 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.of(p0, p1, p2)

    def test_of_test_13713(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456)
        p1 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.of(p0, p1)

    def test_from_test_13714(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456, tzinfo=ZoneInfo("America/New_York"))
        ZonedDateTimeWrapper.from_(p0)

    def test_parse_test_13715(self):
        p0 = "2024-01-15T10:30:45.123456-05:00[America/New_York]"
        p1 = None  # DateTimeFormatter equivalent
        ZonedDateTimeWrapper.parse(p0, p1)

    def test_parse_test_13716(self):
        p0 = "2024-01-15T10:30:45.123456-05:00[America/New_York]"
        ZonedDateTimeWrapper.parse(p0)

    def test_now_test_13717(self):
        ZonedDateTimeWrapper.now()

    def test_now_test_13718(self):
        p0 = None  # Clock equivalent
        ZonedDateTimeWrapper.now(p0)

    def test_now_test_13719(self):
        p0 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.now(p0)

    def test_ofInstant_test_13720(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456)
        p1 = timezone(timedelta(hours=-5))
        p2 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.ofInstant(p0, p1, p2)

    def test_ofInstant_test_13721(self):
        p0 = datetime(2024, 1, 15, 10, 30, 45, 123456, tzinfo=timezone.utc)
        p1 = ZoneInfo("America/New_York")
        ZonedDateTimeWrapper.ofInstant(p0, p1)


class ZonedDateTimeWrapper:
    @staticmethod
    def ofLocal(p0, p1, p2):
        return p0.astimezone(p1)

    @staticmethod
    def ofStrict(p0, p1, p2):
        return p0.astimezone(p2)

    @staticmethod
    def of(*args):
        if len(args) == 8:
            year, month, day, hour, minute, second, microsecond, zone = args
            return datetime(year, month, day, hour, minute, second, microsecond, tzinfo=zone)
        elif len(args) == 3:
            if isinstance(args[0], datetime.date) and isinstance(args[1], datetime.time):
                date, time, zone = args
                return datetime(date.year, date.month, date.day, time.hour, time.minute, time.second, time.microsecond, tzinfo=zone)
            elif isinstance(args[0], datetime) and isinstance(args[1], ZoneInfo):
                dt, zone = args
                return dt.astimezone(zone)
        elif len(args) == 2:
            dt, zone = args
            return dt.astimezone(zone)

    @staticmethod
    def from_(p0):
        return p0

    @staticmethod
    def parse(p0, p1=None):
        if p1 is None:
            return datetime.fromisoformat(p0.replace("Z", "+00:00"))
        return datetime.fromisoformat(p0)

    @staticmethod
    def now(*args):
        if len(args) == 0:
            return datetime.now()
        elif len(args) == 1:
            if isinstance(args[0], ZoneInfo):
                return datetime.now(args[0])
            else:
                return datetime.now()

    @staticmethod
    def ofInstant(p0, p1, p2):
        return p0.astimezone(p2)


if __name__ == '__main__':
    unittest.main()