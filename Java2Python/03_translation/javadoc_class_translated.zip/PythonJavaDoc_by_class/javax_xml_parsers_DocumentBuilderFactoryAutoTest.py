import unittest
from xml.dom import minidom
from xml.parsers.expat import ExpatError
import xml.etree.ElementTree as ET

class TestDocumentBuilderFactory(unittest.TestCase):
    def test_newDefaultInstance_test_4194(self):
        factory = DocumentBuilderFactory.newDefaultInstance()
        self.assertIsNotNone(factory)

    def test_newDefaultNSInstance_test_4195(self):
        factory = DocumentBuilderFactory.newDefaultNSInstance()
        self.assertIsNotNone(factory)

    def test_newNSInstance_test_4196(self):
        factory = DocumentBuilderFactory.newNSInstance()
        self.assertIsNotNone(factory)

    def test_newNSInstance_test_4197(self, p0, p1):
        factory = DocumentBuilderFactory.newNSInstance(p0, p1)
        self.assertIsNotNone(factory)

    def test_newInstance_test_4198(self, p0, p1):
        factory = DocumentBuilderFactory.newInstance(p0, p1)
        self.assertIsNotNone(factory)

    def test_newInstance_test_4199(self):
        factory = DocumentBuilderFactory.newInstance()
        self.assertIsNotNone(factory)


class DocumentBuilderFactory:
    """Wrapper class mimicking javax.xml.parsers.DocumentBuilderFactory"""
    
    @staticmethod
    def newDefaultInstance():
        return DocumentBuilderFactory()
    
    @staticmethod
    def newDefaultNSInstance():
        return DocumentBuilderFactory()
    
    @staticmethod
    def newNSInstance():
        return DocumentBuilderFactory()
    
    @staticmethod
    def newNSInstance(factory_class, class_loader=None):
        return DocumentBuilderFactory()
    
    @staticmethod
    def newInstance(factory_class, class_loader=None):
        return DocumentBuilderFactory()
    
    @staticmethod
    def newInstance():
        return DocumentBuilderFactory()
    
    def __init__(self):
        self._namespace_aware = False
        self._validating = False
    
    def setNamespaceAware(self, awareness):
        self._namespace_aware = awareness
    
    def setValidating(self, validating):
        self._validating = validating
    
    def newDocumentBuilder(self):
        return DocumentBuilder(self)
    
    def newDocument(self):
        return minidom.Document()


class DocumentBuilder:
    def __init__(self, factory):
        self.factory = factory
    
    def parse(self, source):
        return minidom.parse(source)
    
    def newDocument(self):
        return minidom.Document()


if __name__ == '__main__':
    unittest.main()