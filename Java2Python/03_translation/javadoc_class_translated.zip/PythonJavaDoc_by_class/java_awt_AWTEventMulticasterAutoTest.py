import unittest
from typing import Any


class TestAWTEventMulticaster(unittest.TestCase):
    def test_getListeners_test_911(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.getListeners(p0, p1)

    def test_remove_test_912(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_913(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_914(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_915(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_916(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_917(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_918(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_919(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_920(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_921(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_922(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_923(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_924(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_925(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_926(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_927(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_remove_test_928(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.remove(p0, p1)

    def test_add_test_929(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_930(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_931(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_932(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_933(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_934(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_935(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_936(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_937(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_938(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_939(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_940(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_941(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_942(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_943(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_944(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)

    def test_add_test_945(self):
        p0 = None
        p1 = None
        AWTEventMulticaster.add(p0, p1)


class AWTEventMulticaster:
    @staticmethod
    def getListeners(listener: Any, listener_type: Any) -> Any:
        return None

    @staticmethod
    def remove(listener_a: Any, listener_b: Any) -> Any:
        return None

    @staticmethod
    def add(listener_a: Any, listener_b: Any) -> Any:
        return None


if __name__ == '__main__':
    unittest.main()