import unittest
from io import BytesIO

class TestInputStreamAuto(unittest.TestCase):
    def test_nullInputStream_test_5854(self):
        result = InputStreamWrapper.nullInputStream()
        self.assertIsNotNone(result)

class InputStreamWrapper:
    @staticmethod
    def nullInputStream():
        return BytesIO(b'')