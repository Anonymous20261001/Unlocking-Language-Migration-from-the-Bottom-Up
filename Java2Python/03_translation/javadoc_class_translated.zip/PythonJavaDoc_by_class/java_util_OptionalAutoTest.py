import unittest
from typing import Optional as TypingOptional

class TestJavaUtilOptionalAutoTest(unittest.TestCase):
    def of_test_9689(self, p0):
        OptionalWrapper.of(p0)

    def empty_test_9690(self):
        OptionalWrapper.empty()

    def ofNullable_test_9691(self, p0):
        OptionalWrapper.ofNullable(p0)


class OptionalWrapper:
    @staticmethod
    def of(value):
        return TypingOptional.of(value)

    @staticmethod
    def empty():
        return TypingOptional.empty()

    @staticmethod
    def ofNullable(value):
        return TypingOptional.ofNullable(value)


if __name__ == '__main__':
    unittest.main()