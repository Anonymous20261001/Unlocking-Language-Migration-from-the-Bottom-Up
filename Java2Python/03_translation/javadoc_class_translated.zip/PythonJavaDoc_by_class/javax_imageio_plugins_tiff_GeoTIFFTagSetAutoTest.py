import unittest
from javax.imageio.plugins.tiff import GeoTIFFTagSet

class TestGeoTIFFTagSetAutoTest(unittest.TestCase):
    def getInstance_test_5102(self):
        GeoTIFFTagSet.getInstance()


class GeoTIFFTagSetWrapper:
    @staticmethod
    def getInstance():
        return GeoTIFFTagSet.getInstance()