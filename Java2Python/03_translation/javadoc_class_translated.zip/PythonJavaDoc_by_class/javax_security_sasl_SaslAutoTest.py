import unittest
from javax.security.sasl import Sasl

class TestJavaxSecuritySaslSaslAutoTest(unittest.TestCase):
    def test_getSaslClientFactories_test_10758(self):
        Sasl.getSaslClientFactories()
    
    def test_getSaslServerFactories_test_10759(self):
        Sasl.getSaslServerFactories()


class SaslWrapper:
    @staticmethod
    def getSaslClientFactories():
        return Sasl.getSaslClientFactories()
    
    @staticmethod
    def getSaslServerFactories():
        return Sasl.getSaslServerFactories()

if __name__ == '__main__':
    unittest.main()