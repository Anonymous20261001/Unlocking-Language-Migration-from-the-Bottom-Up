import unittest
from urllib.parse import unquote
from urllib.parse import unquote_to_bytes

class TestJavaNetURLDecoderAutoTest(unittest.TestCase):
    def decode_test_13265(self, p0, p1):
        unquote(p0, encoding=p1)

    def decode_test_13266(self, p0):
        unquote(p0)


class URLDecoder:
    @staticmethod
    def decode(s, charset=None):
        if charset is not None:
            charset_name = charset.name() if hasattr(charset, 'name') else str(charset)
            return unquote(s, encoding=charset_name)
        return unquote(s)

if __name__ == '__main__':
    unittest.main()