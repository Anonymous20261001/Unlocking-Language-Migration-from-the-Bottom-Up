import unittest
from java.nio.charset import Charset  # Assuming a Java-to-Python bridge or implementation

class TestCharsetMethods(unittest.TestCase):
    
    def test_forName_test_2235(self):
        p0 = "UTF-8"
        p1 = Charset.forName("UTF-8")
        Charset.forName(p0, p1)
    
    def test_forName_test_2236(self):
        p0 = "UTF-8"
        Charset.forName(p0)
    
    def test_defaultCharset_test_2237(self):
        Charset.defaultCharset()
    
    def test_isSupported_test_2238(self):
        p0 = "UTF-8"
        Charset.isSupported(p0)
    
    def test_availableCharsets_test_2239(self):
        Charset.availableCharsets()


class CharsetWrapper:
    @staticmethod
    def forName(name, fallback=None):
        if fallback is not None:
            return Charset.forName(name, fallback)
        return Charset.forName(name)
    
    @staticmethod
    def defaultCharset():
        return Charset.defaultCharset()
    
    @staticmethod
    def isSupported(name):
        return Charset.isSupported(name)
    
    @staticmethod
    def availableCharsets():
        return Charset.availableCharsets()