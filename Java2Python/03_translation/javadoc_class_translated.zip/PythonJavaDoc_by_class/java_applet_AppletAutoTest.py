import unittest
from unittest.mock import MagicMock
from typing import Optional, Any
import urllib.parse


class TestJavaAppletAutoTest(unittest.TestCase):
    def test_getDocumentBase_test_163(self):
        instance = Applet()
        instance.getDocumentBase()

    def test_getCodeBase_test_164(self):
        instance = Applet()
        instance.getCodeBase()

    def test_getAppletContext_test_165(self):
        instance = Applet()
        instance.getAppletContext()

    def test_showStatus_test_166(self, p0=None):
        instance = Applet()
        instance.showStatus(p0)

    def test_getAudioClip_test_167(self, p0=None, p1=None):
        instance = Applet()
        instance.getAudioClip(p0, p1)

    def test_getAudioClip_test_168(self, p0=None):
        instance = Applet()
        instance.getAudioClip(p0)

    def test_play_test_169(self, p0=None):
        instance = Applet()
        instance.play(p0)

    def test_play_test_170(self, p0=None, p1=None):
        instance = Applet()
        instance.play(p0, p1)

    def test_setStub_test_171(self, p0=None):
        instance = Applet()
        instance.setStub(p0)

    def test_newAudioClip_test_172(self, p0=None):
        Applet.newAudioClip(p0)

    def test_getAppletInfo_test_173(self):
        instance = Applet()
        instance.getAppletInfo()

    def test_getParameterInfo_test_174(self):
        instance = Applet()
        instance.getParameterInfo()

    def test_isValidateRoot_test_175(self):
        instance = Applet()
        instance.isValidateRoot()

    def test_getAccessibleContext_test_176(self):
        instance = Applet()
        instance.getAccessibleContext()

    def test_getImage_test_177(self, p0=None, p1=None):
        instance = Applet()
        instance.getImage(p0, p1)

    def test_getImage_test_178(self, p0=None):
        instance = Applet()
        instance.getImage(p0)

    def test_init_test_179(self):
        instance = Applet()
        instance.init()

    def test_start_test_180(self):
        instance = Applet()
        instance.start()

    def test_stop_test_181(self):
        instance = Applet()
        instance.stop()

    def test_destroy_test_182(self):
        instance = Applet()
        instance.destroy()

    def test_isActive_test_183(self):
        instance = Applet()
        instance.isActive()

    def test_resize_test_184(self, p0=0, p1=0):
        instance = Applet()
        instance.resize(p0, p1)

    def test_resize_test_185(self, p0=None):
        instance = Applet()
        instance.resize(p0)

    def test_getLocale_test_186(self):
        instance = Applet()
        instance.getLocale()

    def test_getParameter_test_187(self, p0=None):
        instance = Applet()
        instance.getParameter(p0)


class AppletStub:
    pass


class Applet:
    def __init__(self):
        self._stub = None

    def getDocumentBase(self):
        return None

    def getCodeBase(self):
        return None

    def getAppletContext(self):
        return None

    def showStatus(self, p0: Optional[str] = None):
        return None

    def getAudioClip(self, p0: Optional[Any] = None, p1: Optional[str] = None):
        return None

    def play(self, p0: Optional[Any] = None, p1: Optional[str] = None):
        return None

    def setStub(self, p0: Optional[AppletStub] = None):
        self._stub = p0

    @staticmethod
    def newAudioClip(p0: Optional[Any] = None):
        return None

    def getAppletInfo(self):
        return None

    def getParameterInfo(self):
        return None

    def isValidateRoot(self):
        return False

    def getAccessibleContext(self):
        return None

    def getImage(self, p0: Optional[Any] = None, p1: Optional[str] = None):
        return None

    def init(self):
        pass

    def start(self):
        pass

    def stop(self):
        pass

    def destroy(self):
        pass

    def isActive(self):
        return False

    def resize(self, p0: Any = 0, p1: Any = 0):
        pass

    def getLocale(self):
        return None

    def getParameter(self, p0: Optional[str] = None):
        return None


if __name__ == '__main__':
    unittest.main()