import unittest
from unittest.mock import MagicMock
import ssl
from typing import Optional


class TestHttpsURLConnectionAuto(unittest.TestCase):
    def test_getDefaultSSLSocketFactory_test_5489(self):
        HttpsURLConnectionWrapper.get_default_ssl_socket_factory()

    def test_setDefaultHostnameVerifier_test_5490(self):
        verifier = MagicMock()
        HttpsURLConnectionWrapper.set_default_hostname_verifier(verifier)

    def test_getDefaultHostnameVerifier_test_5491(self):
        HttpsURLConnectionWrapper.get_default_hostname_verifier()

    def test_setDefaultSSLSocketFactory_test_5492(self):
        factory = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        HttpsURLConnectionWrapper.set_default_ssl_socket_factory(factory)


class HttpsURLConnectionWrapper:
    _default_hostname_verifier = None
    _default_ssl_socket_factory = None

    @classmethod
    def get_default_ssl_socket_factory(cls):
        return cls._default_ssl_socket_factory

    @classmethod
    def set_default_hostname_verifier(cls, verifier):
        cls._default_hostname_verifier = verifier

    @classmethod
    def get_default_hostname_verifier(cls):
        return cls._default_hostname_verifier

    @classmethod
    def set_default_ssl_socket_factory(cls, factory):
        cls._default_ssl_socket_factory = factory


if __name__ == '__main__':
    unittest.main()