import unittest
from unittest.mock import MagicMock, patch
from typing import Any, Callable


class TestJdkJfrFlightRecorderAutoTest(unittest.TestCase):
    def test_addListener_test_4816(self):
        p0 = MagicMock()
        FlightRecorder.addListener(p0)

    def test_removeListener_test_4817(self):
        p0 = MagicMock()
        FlightRecorder.removeListener(p0)

    def test_isAvailable_test_4818(self):
        FlightRecorder.isAvailable()

    def test_getFlightRecorder_test_4819(self):
        FlightRecorder.getFlightRecorder()

    def test_addPeriodicEvent_test_4820(self):
        p0 = MagicMock()
        p1 = MagicMock()
        FlightRecorder.addPeriodicEvent(p0, p1)

    def test_removePeriodicEvent_test_4821(self):
        p0 = MagicMock()
        FlightRecorder.removePeriodicEvent(p0)

    def test_register_test_4822(self):
        p0 = MagicMock()
        FlightRecorder.register(p0)

    def test_unregister_test_4823(self):
        p0 = MagicMock()
        FlightRecorder.unregister(p0)

    def test_isInitialized_test_4824(self):
        FlightRecorder.isInitialized()


class FlightRecorder:
    _listeners = []
    _periodic_events = []
    _registered_classes = []
    _initialized = False
    _available = True
    _recorder = None

    @classmethod
    def addListener(cls, listener):
        cls._listeners.append(listener)

    @classmethod
    def removeListener(cls, listener):
        if listener in cls._listeners:
            cls._listeners.remove(listener)

    @classmethod
    def isAvailable(cls):
        return cls._available

    @classmethod
    def getFlightRecorder(cls):
        if cls._recorder is None:
            cls._recorder = cls()
        return cls._recorder

    @classmethod
    def addPeriodicEvent(cls, event_class, runnable):
        cls._periodic_events.append((event_class, runnable))

    @classmethod
    def removePeriodicEvent(cls, runnable):
        cls._periodic_events = [(c, r) for c, r in cls._periodic_events if r != runnable]

    @classmethod
    def register(cls, event_class):
        cls._registered_classes.append(event_class)

    @classmethod
    def unregister(cls, event_class):
        if event_class in cls._registered_classes:
            cls._registered_classes.remove(event_class)

    @classmethod
    def isInitialized(cls):
        return cls._initialized


if __name__ == '__main__':
    unittest.main()