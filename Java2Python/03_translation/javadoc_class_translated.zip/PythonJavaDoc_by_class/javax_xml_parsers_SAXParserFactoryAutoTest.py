import unittest
from xml.sax.saxutils import prepare_input_source
from xml.sax import make_parser, SAXParserFactory


class TestSAXParserFactory(unittest.TestCase):
    
    def test_newDefaultInstance_test_10762(self):
        factory = SAXParserFactory.newDefaultInstance()
        self.assertIsNotNone(factory)
    
    def test_newDefaultNSInstance_test_10763(self):
        factory = SAXParserFactory.newDefaultNSInstance()
        self.assertIsNotNone(factory)
    
    def test_newNSInstance_test_10764(self):
        factory = SAXParserFactory.newNSInstance()
        self.assertIsNotNone(factory)
    
    def test_newNSInstance_test_10765(self, p0, p1):
        factory = SAXParserFactory.newNSInstance(p0, p1)
        self.assertIsNotNone(factory)
    
    def test_newInstance_test_10766(self, p0, p1):
        factory = SAXParserFactory.newInstance(p0, p1)
        self.assertIsNotNone(factory)
    
    def test_newInstance_test_10767(self):
        factory = SAXParserFactory.newInstance()
        self.assertIsNotNone(factory)


class SAXParserFactory:
    """Wrapper class providing static factory methods similar to Java's SAXParserFactory"""
    
    @staticmethod
    def newDefaultInstance():
        return make_parser()
    
    @staticmethod
    def newDefaultNSInstance():
        return make_parser(namespaceHandling=True)
    
    @staticmethod
    def newNSInstance():
        return make_parser(namespaceHandling=True)
    
    @staticmethod
    def newNSInstance(features=None, class_loader=None):
        parser = make_parser(namespaceHandling=True)
        if features:
            for feature, value in features.items():
                parser.setFeature(feature, value)
        return parser
    
    @staticmethod
    def newInstance(features=None, class_loader=None):
        parser = make_parser()
        if features:
            for feature, value in features.items():
                parser.setFeature(feature, value)
        return parser
    
    @staticmethod
    def newInstance():
        return make_parser()


if __name__ == '__main__':
    unittest.main()