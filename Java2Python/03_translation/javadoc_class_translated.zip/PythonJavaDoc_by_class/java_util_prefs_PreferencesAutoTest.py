import unittest
from typing import Type


class Preferences:
    @staticmethod
    def userRoot():
        pass
    
    @staticmethod
    def systemRoot():
        pass
    
    @staticmethod
    def userNodeForPackage(p0: Type):
        pass
    
    @staticmethod
    def systemNodeForPackage(p0: Type):
        pass


class TestJavaUtilPrefsPreferencesAutoTest(unittest.TestCase):
    def test_userRoot_test_10000(self):
        Preferences.userRoot()
    
    def test_systemRoot_test_10001(self):
        Preferences.systemRoot()
    
    def test_userNodeForPackage_test_10002(self):
        p0 = type("TestClass", (), {})
        Preferences.userNodeForPackage(p0)
    
    def test_systemNodeForPackage_test_10003(self):
        p0 = type("TestClass", (), {})
        Preferences.systemNodeForPackage(p0)


if __name__ == '__main__':
    unittest.main()