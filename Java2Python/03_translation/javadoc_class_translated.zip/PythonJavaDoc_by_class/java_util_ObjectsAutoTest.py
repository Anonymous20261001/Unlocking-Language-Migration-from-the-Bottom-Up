import unittest
import sys
from typing import Any, Callable, List, Optional

class Objects:
    """Wrapper class mimicking Java's java.util.Objects"""
    
    @staticmethod
    def checkIndex(index: int, length: int) -> int:
        if index < 0 or index >= length:
            raise IndexError(f"Index {index} out of bounds for length {length}")
        return index
    
    @staticmethod
    def compare(a: Any, b: Any, c: Callable) -> int:
        if a == b:
            return 0
        if a is None:
            return -1
        if b is None:
            return 1
        return c(a, b)
    
    @staticmethod
    def hash(*args: Any) -> int:
        result = 1
        for arg in args:
            result = 31 * result + (hash(arg) if arg is not None else 0)
        return result
    
    @staticmethod
    def requireNonNull(obj: Any, message: Any = None) -> Any:
        if obj is None:
            if message is None:
                raise ValueError("Object is null")
            elif callable(message):
                raise ValueError(str(message()))
            else:
                raise ValueError(str(message))
        return obj
    
    @staticmethod
    def checkFromToIndex(fromIndex: int, toIndex: int, length: int) -> int:
        if fromIndex < 0 or toIndex < fromIndex or toIndex > length:
            raise IndexError(f"Range [{fromIndex}, {toIndex}) out of bounds for length {length}")
        return fromIndex
    
    @staticmethod
    def checkFromIndexSize(fromIndex: int, size: int, length: int) -> int:
        if fromIndex < 0 or size < 0 or fromIndex + size > length:
            raise IndexError(f"Range [{fromIndex}, {fromIndex + size}) out of bounds for length {length}")
        return fromIndex
    
    @staticmethod
    def deepEquals(a: Any, b: Any) -> bool:
        if a is b:
            return True
        if a is None or b is None:
            return False
        if isinstance(a, list) and isinstance(b, list):
            if len(a) != len(b):
                return False
            return all(Objects.deepEquals(x, y) for x, y in zip(a, b))
        return a == b
    
    @staticmethod
    def toIdentityString(obj: Any) -> str:
        return f"{type(obj).__name__}@{id(obj):x}"
    
    @staticmethod
    def isNull(obj: Any) -> bool:
        return obj is None
    
    @staticmethod
    def nonNull(obj: Any) -> bool:
        return obj is not None
    
    @staticmethod
    def requireNonNullElse(obj: Any, defaultObj: Any) -> Any:
        if obj is None:
            return defaultObj
        return obj
    
    @staticmethod
    def requireNonNullElseGet(obj: Any, supplier: Callable) -> Any:
        if obj is None:
            return supplier()
        return obj


class TestJavaUtilObjectsAutoTest(unittest.TestCase):
    
    def test_checkIndex_test_9597(self):
        Objects.checkIndex(5, 10)
        self.assertTrue(True)
    
    def test_checkIndex_test_9598(self):
        Objects.checkIndex(5, 10)
        self.assertTrue(True)
    
    def test_compare_test_9599(self):
        Objects.compare(5, 10, lambda x, y: x - y)
        self.assertTrue(True)
    
    def test_hash_test_9600(self):
        Objects.hash([1, 2, 3])
        self.assertTrue(True)
    
    def test_requireNonNull_test_9601(self):
        Objects.requireNonNull("test", lambda: "message")
        self.assertTrue(True)
    
    def test_requireNonNull_test_9602(self):
        Objects.requireNonNull("test", "message")
        self.assertTrue(True)
    
    def test_requireNonNull_test_9603(self):
        Objects.requireNonNull("test")
        self.assertTrue(True)
    
    def test_checkFromToIndex_test_9604(self):
        Objects.checkFromToIndex(1, 5, 10)
        self.assertTrue(True)
    
    def test_checkFromToIndex_test_9605(self):
        Objects.checkFromToIndex(1, 5, 10)
        self.assertTrue(True)
    
    def test_checkFromIndexSize_test_9606(self):
        Objects.checkFromIndexSize(1, 5, 10)
        self.assertTrue(True)
    
    def test_checkFromIndexSize_test_9607(self):
        Objects.checkFromIndexSize(1, 5, 10)
        self.assertTrue(True)
    
    def test_deepEquals_test_9608(self):
        Objects.deepEquals([1, 2], [1, 2])
        self.assertTrue(True)
    
    def test_toIdentityString_test_9609(self):
        Objects.toIdentityString("test")
        self.assertTrue(True)
    
    def test_isNull_test_9610(self):
        Objects.isNull(None)
        self.assertTrue(True)
    
    def test_nonNull_test_9611(self):
        Objects.nonNull("test")
        self.assertTrue(True)
    
    def test_requireNonNullElse_test_9612(self):
        Objects.requireNonNullElse(None, "default")
        self.assertTrue(True)
    
    def test_requireNonNullElseGet_test_9613(self):
        Objects.requireNonNullElseGet(None, lambda: "default")
        self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()