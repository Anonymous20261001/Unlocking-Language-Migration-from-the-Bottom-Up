import unittest
from unittest.mock import MagicMock

class TestJShellAutoTest(unittest.TestCase):
    def test_builder_test_6941(self):
        JShell.builder()
    
    def test_create_test_6942(self):
        JShell.create()


class JShell:
    @staticmethod
    def builder():
        return MagicMock()
    
    @staticmethod
    def create():
        return MagicMock()

if __name__ == '__main__':
    unittest.main()