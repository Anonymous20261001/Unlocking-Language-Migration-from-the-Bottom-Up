import unittest

class TestValueRange(unittest.TestCase):
    def of_test_13306(self, p0, p1):
        ValueRange.of(p0, p1)
    
    def of_test_13307(self, p0, p1, p2, p3):
        ValueRange.of(p0, p1, p2, p3)
    
    def of_test_13308(self, p0, p1, p2):
        ValueRange.of(p0, p1, p2)


class ValueRange:
    @staticmethod
    def of(min, max):
        return ValueRange(min, max)
    
    @staticmethod
    def of(min, max, smallest, largest):
        return ValueRange(min, max, smallest, largest)
    
    @staticmethod
    def of(min, max, smallest):
        return ValueRange(min, max, smallest)
    
    def __init__(self, min, max, smallest=None, largest=None):
        self.min = min
        self.max = max
        self.smallest = smallest
        self.largest = largest


if __name__ == '__main__':
    unittest.main()