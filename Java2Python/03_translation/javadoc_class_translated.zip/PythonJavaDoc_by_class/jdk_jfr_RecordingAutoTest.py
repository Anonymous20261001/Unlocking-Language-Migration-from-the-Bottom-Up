import unittest
from datetime import timedelta
from typing import Dict, Type, Any


class TestJdkJfrRecordingAutoTest(unittest.TestCase):
    def test_getSettings_test_10348(self):
        instance = Recording()
        instance.getSettings()

    def test_setMaxAge_test_10349(self):
        instance = Recording()
        instance.setMaxAge(timedelta(seconds=10))

    def test_getMaxAge_test_10350(self):
        instance = Recording()
        instance.getMaxAge()

    def test_setSettings_test_10351(self):
        instance = Recording()
        instance.setSettings({})

    def test_isToDisk_test_10352(self):
        instance = Recording()
        instance.isToDisk()

    def test_getStartTime_test_10353(self):
        instance = Recording()
        instance.getStartTime()

    def test_getStopTime_test_10354(self):
        instance = Recording()
        instance.getStopTime()

    def test_getDestination_test_10355(self):
        instance = Recording()
        instance.getDestination()

    def test_getMaxSize_test_10356(self):
        instance = Recording()
        instance.getMaxSize()

    def test_setMaxSize_test_10357(self):
        instance = Recording()
        instance.setMaxSize(1000)

    def test_getDumpOnExit_test_10358(self):
        instance = Recording()
        instance.getDumpOnExit()

    def test_setDumpOnExit_test_10359(self):
        instance = Recording()
        instance.setDumpOnExit(True)

    def test_setToDisk_test_10360(self):
        instance = Recording()
        instance.setToDisk(True)

    def test_scheduleStart_test_10361(self):
        instance = Recording()
        instance.scheduleStart(timedelta(seconds=5))

    def test_setDuration_test_10362(self):
        instance = Recording()
        instance.setDuration(timedelta(seconds=30))

    def test_getName_test_10363(self):
        instance = Recording()
        instance.getName()

    def test_copy_test_10364(self):
        instance = Recording()
        instance.copy(True)

    def test_start_test_10365(self):
        instance = Recording()
        instance.start()

    def test_stop_test_10366(self):
        instance = Recording()
        instance.stop()

    def test_setName_test_10367(self):
        instance = Recording()
        instance.setName("test")

    def test_getId_test_10368(self):
        instance = Recording()
        instance.getId()

    def test_getState_test_10369(self):
        instance = Recording()
        instance.getState()

    def test_close_test_10370(self):
        instance = Recording()
        instance.close()

    def test_getSize_test_10371(self):
        instance = Recording()
        instance.getSize()

    def test_enable_test_10372(self):
        instance = Recording()
        instance.enable(str)

    def test_enable_test_10373(self):
        instance = Recording()
        instance.enable("test")

    def test_getDuration_test_10374(self):
        instance = Recording()
        instance.getDuration()

    def test_disable_test_10375(self):
        instance = Recording()
        instance.disable("test")

    def test_disable_test_10376(self):
        instance = Recording()
        instance.disable(str)


class Recording:
    def __init__(self):
        self._settings = {}
        self._max_age = None
        self._max_size = None
        self._to_disk = True
        self._dump_on_exit = False
        self._name = ""
        self._start_time = None
        self._stop_time = None
        self._destination = None
        self._state = "NEW"
        self._id = 0
        self._duration = None
        self._size = 0

    def getSettings(self):
        return self._settings

    def setMaxAge(self, duration: timedelta):
        self._max_age = duration

    def getMaxAge(self):
        return self._max_age

    def setSettings(self, settings: Dict[str, str]):
        self._settings = settings

    def isToDisk(self):
        return self._to_disk

    def getStartTime(self):
        return self._start_time

    def getStopTime(self):
        return self._stop_time

    def getDestination(self):
        return self._destination

    def getMaxSize(self):
        return self._max_size

    def setMaxSize(self, size: int):
        self._max_size = size

    def getDumpOnExit(self):
        return self._dump_on_exit

    def setDumpOnExit(self, dump_on_exit: bool):
        self._dump_on_exit = dump_on_exit

    def setToDisk(self, to_disk: bool):
        self._to_disk = to_disk

    def scheduleStart(self, delay: timedelta):
        pass

    def setDuration(self, duration: timedelta):
        self._duration = duration

    def getName(self):
        return self._name

    def copy(self, stop: bool):
        return Recording()

    def start(self):
        self._state = "RUNNING"

    def stop(self):
        self._state = "STOPPED"

    def setName(self, name: str):
        self._name = name

    def getId(self):
        return self._id

    def getState(self):
        return self._state

    def close(self):
        self._state = "CLOSED"

    def getSize(self):
        return self._size

    def enable(self, event: Any):
        pass

    def getDuration(self):
        return self._duration

    def disable(self, event: Any):
        pass


if __name__ == '__main__':
    unittest.main()