import unittest

class TestOptionalInt(unittest.TestCase):
    def of_test_9694(self, p0):
        OptionalInt.of(p0)

    def empty_test_9695(self):
        OptionalInt.empty()

class OptionalInt:
    @staticmethod
    def of(value):
        return OptionalInt(value)

    @staticmethod
    def empty():
        return OptionalInt(None)

    def __init__(self, value):
        self.value = value

if __name__ == '__main__':
    unittest.main()