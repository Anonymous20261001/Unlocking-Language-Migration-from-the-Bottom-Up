import unittest

class TestJdiExecutionControlProviderAutoTest(unittest.TestCase):
    def name_test_6148(self):
        instance = JdiExecutionControlProvider()
        instance.name()

    def defaultParameters_test_6149(self):
        instance = JdiExecutionControlProvider()
        instance.defaultParameters()


class JdiExecutionControlProvider:
    def name(self):
        pass

    def defaultParameters(self):
        pass


if __name__ == '__main__':
    unittest.main()