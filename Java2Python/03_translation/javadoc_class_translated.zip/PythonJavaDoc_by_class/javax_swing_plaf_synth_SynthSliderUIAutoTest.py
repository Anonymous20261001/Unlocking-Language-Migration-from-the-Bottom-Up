import unittest
from javax.swing import JComponent
from javax.swing.plaf.synth import SynthSliderUI

class TestSynthSliderUI(unittest.TestCase):
    def createUI_test_12334(self, p0):
        SynthSliderUI.createUI(p0)


class SynthSliderUIWrapper:
    @staticmethod
    def createUI(p0):
        return SynthSliderUI.createUI(p0)


if __name__ == '__main__':
    unittest.main()