import unittest
import logging
from unittest.mock import MagicMock
from javax.sql.rowset.spi import SyncFactory

class TestJavaxSqlRowsetSpiSyncFactoryAutoTest(unittest.TestCase):
    def test_getSyncFactory_test_12123(self):
        result = SyncFactory.getSyncFactory()
        self.assertIsNotNone(result)

    def test_setLogger_test_12124(self):
        p0 = MagicMock(spec=logging.Logger)
        SyncFactory.setLogger(p0)
        self.assertTrue(hasattr(SyncFactory, '_logger'))
        self.assertEqual(SyncFactory._logger, p0)

    def test_setLogger_test_12125(self):
        p0 = MagicMock(spec=logging.Logger)
        p1 = MagicMock(spec=logging.Level)
        SyncFactory.setLogger(p0, p1)
        self.assertTrue(hasattr(SyncFactory, '_logger'))
        self.assertEqual(SyncFactory._logger, p0)
        self.assertTrue(hasattr(SyncFactory, '_level'))
        self.assertEqual(SyncFactory._level, p1)

class SyncFactory:
    _logger = None
    _level = None
    
    @classmethod
    def getSyncFactory(cls):
        if cls._instance is None:
            cls._instance = SyncFactory()
        return cls._instance
    
    @classmethod
    def setLogger(cls, logger, level=None):
        cls._logger = logger
        if level is not None:
            cls._level = level
    
    _instance = None

if __name__ == '__main__':
    unittest.main()