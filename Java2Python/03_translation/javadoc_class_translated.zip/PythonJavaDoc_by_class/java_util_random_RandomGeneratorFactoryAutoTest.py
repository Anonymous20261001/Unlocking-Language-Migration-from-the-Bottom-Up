import unittest
from typing import List, Iterator
import random


class RandomGeneratorFactory:
    @staticmethod
    def of(name: str) -> 'RandomGeneratorFactory':
        # Implementation for creating a random generator factory by name
        return RandomGeneratorFactory()

    @staticmethod
    def getDefault() -> 'RandomGeneratorFactory':
        # Returns the default random generator factory
        return RandomGeneratorFactory()

    @staticmethod
    def all() -> Iterator['RandomGeneratorFactory']:
        # Returns an iterator of all available random generator factories
        # Simplified: return a list of some factories
        factories = [RandomGeneratorFactory(), RandomGeneratorFactory()]
        return iter(factories)


class TestJavaUtilRandomRandomGeneratorFactoryAutoTest(unittest.TestCase):
    def test_of_test_10322(self):
        p0 = "L64X128MixRandom"
        RandomGeneratorFactory.of(p0)

    def test_getDefault_test_10323(self):
        RandomGeneratorFactory.getDefault()

    def test_all_test_10324(self):
        RandomGeneratorFactory.all()


if __name__ == '__main__':
    unittest.main()