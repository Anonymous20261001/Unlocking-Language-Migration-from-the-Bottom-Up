import unittest
from unittest.mock import Mock

class TestHttpClientAutoTest(unittest.TestCase):
    def test_newBuilder_test_5409(self):
        result = HttpClientWrapper.newBuilder()
        self.assertIsNotNone(result)

    def test_newHttpClient_test_5410(self):
        result = HttpClientWrapper.newHttpClient()
        self.assertIsNotNone(result)


class HttpClientWrapper:
    @staticmethod
    def newBuilder():
        return Mock()

    @staticmethod
    def newHttpClient():
        return Mock()

if __name__ == '__main__':
    unittest.main()