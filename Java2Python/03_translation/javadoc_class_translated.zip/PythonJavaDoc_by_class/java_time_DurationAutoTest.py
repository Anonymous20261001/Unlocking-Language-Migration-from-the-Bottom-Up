import unittest
from datetime import timedelta
from typing import Any


class TestJavaTimeDurationAutoTest(unittest.TestCase):
    def of_test_4406(self, p0: int, p1: Any) -> None:
        DurationWrapper.of(p0, p1)
    
    def from_test_4407(self, p0: Any) -> None:
        DurationWrapper.from_(p0)
    
    def parse_test_4408(self, p0: str) -> None:
        DurationWrapper.parse(p0)
    
    def between_test_4409(self, p0: Any, p1: Any) -> None:
        DurationWrapper.between(p0, p1)
    
    def ofSeconds_test_4410(self, p0: int, p1: int) -> None:
        DurationWrapper.of_seconds(p0, p1)
    
    def ofSeconds_test_4411(self, p0: int) -> None:
        DurationWrapper.of_seconds(p0)
    
    def ofNanos_test_4412(self, p0: int) -> None:
        DurationWrapper.of_nanos(p0)
    
    def ofDays_test_4413(self, p0: int) -> None:
        DurationWrapper.of_days(p0)
    
    def ofHours_test_4414(self, p0: int) -> None:
        DurationWrapper.of_hours(p0)
    
    def ofMinutes_test_4415(self, p0: int) -> None:
        DurationWrapper.of_minutes(p0)
    
    def ofMillis_test_4416(self, p0: int) -> None:
        DurationWrapper.of_millis(p0)


class DurationWrapper:
    @staticmethod
    def of(amount: int, unit: Any) -> timedelta:
        return timedelta(seconds=amount * 1)  # Simplified implementation
    
    @staticmethod
    def from_(amount: Any) -> timedelta:
        if hasattr(amount, 'total_seconds'):
            return timedelta(seconds=amount.total_seconds())
        raise ValueError("Cannot convert to Duration")
    
    @staticmethod
    def parse(text: str) -> timedelta:
        # Simple parser for ISO-8601 duration format
        import re
        match = re.match(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?', text)
        if not match:
            return timedelta(0)
        hours = int(match.group(1) or 0)
        minutes = int(match.group(2) or 0)
        seconds = float(match.group(3) or 0)
        return timedelta(hours=hours, minutes=minutes, seconds=seconds)
    
    @staticmethod
    def between(start: Any, end: Any) -> timedelta:
        return end - start
    
    @staticmethod
    def of_seconds(seconds: int, nano_adjustment: int = 0) -> timedelta:
        return timedelta(seconds=seconds, microseconds=nano_adjustment / 1000)
    
    @staticmethod
    def of_nanos(nanos: int) -> timedelta:
        return timedelta(microseconds=nanos / 1000)
    
    @staticmethod
    def of_days(days: int) -> timedelta:
        return timedelta(days=days)
    
    @staticmethod
    def of_hours(hours: int) -> timedelta:
        return timedelta(hours=hours)
    
    @staticmethod
    def of_minutes(minutes: int) -> timedelta:
        return timedelta(minutes=minutes)
    
    @staticmethod
    def of_millis(millis: int) -> timedelta:
        return timedelta(milliseconds=millis)