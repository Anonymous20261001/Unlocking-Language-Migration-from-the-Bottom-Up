import unittest
import array
from typing import CharSequence


class TestCharBufferAuto(unittest.TestCase):
    
    def test_wrap_test_2230(self):
        p0 = "hello"
        p1 = 1
        p2 = 3
        CharBufferWrapper.wrap(p0, p1, p2)
    
    def test_wrap_test_2231(self):
        p0 = array.array('u', ['h', 'e', 'l', 'l', 'o'])
        CharBufferWrapper.wrap(p0)
    
    def test_wrap_test_2232(self):
        p0 = "hello"
        CharBufferWrapper.wrap(p0)
    
    def test_wrap_test_2233(self):
        p0 = array.array('u', ['h', 'e', 'l', 'l', 'o'])
        p1 = 1
        p2 = 3
        CharBufferWrapper.wrap(p0, p1, p2)
    
    def test_allocate_test_2234(self):
        p0 = 10
        CharBufferWrapper.allocate(p0)


class CharBufferWrapper:
    @staticmethod
    def wrap(data, start=None, end=None):
        if isinstance(data, CharSequence) or isinstance(data, str):
            if start is not None and end is not None:
                return data[start:end]
            return data
        elif isinstance(data, array.array):
            if start is not None and end is not None:
                return data[start:end]
            return data
        return None
    
    @staticmethod
    def allocate(capacity):
        return array.array('u', ['\0'] * capacity)


if __name__ == '__main__':
    unittest.main()