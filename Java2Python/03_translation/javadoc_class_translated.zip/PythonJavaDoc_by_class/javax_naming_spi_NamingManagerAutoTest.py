import unittest
from javax.naming.spi import NamingManager

class TestJavaxNamingSpiNamingManagerAutoTest(unittest.TestCase):
    def test_hasInitialContextFactoryBuilder_test_9513(self):
        NamingManager.hasInitialContextFactoryBuilder()


class NamingManagerWrapper:
    @staticmethod
    def hasInitialContextFactoryBuilder():
        return NamingManager.hasInitialContextFactoryBuilder()