import unittest
from javax.imageio.plugins.tiff import ExifGPSTagSet

class TestExifGPSTagSet(unittest.TestCase):
    def getInstance_test_4661(self):
        ExifGPSTagSet.getInstance()


class ExifGPSTagSetWrapper:
    @staticmethod
    def getInstance():
        return ExifGPSTagSet.getInstance()