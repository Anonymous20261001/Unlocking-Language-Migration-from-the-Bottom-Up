import unittest
from javax.swing.colorchooser import ColorChooserComponentFactory

class TestJavaxSwingColorChooserColorChooserComponentFactoryAutoTest(unittest.TestCase):
    def test_getPreviewPanel_test_2491(self):
        ColorChooserComponentFactory.getPreviewPanel()

    def test_getDefaultChooserPanels_test_2492(self):
        ColorChooserComponentFactory.getDefaultChooserPanels()


class ColorChooserComponentFactoryWrapper:
    @staticmethod
    def getPreviewPanel():
        return ColorChooserComponentFactory.getPreviewPanel()

    @staticmethod
    def getDefaultChooserPanels():
        return ColorChooserComponentFactory.getDefaultChooserPanels()