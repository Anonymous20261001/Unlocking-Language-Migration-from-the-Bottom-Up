import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Any


class TestMinguoDate(unittest.TestCase):
    def of_test_8947(self, p0, p1, p2):
        MinguoDate.of(p0, p1, p2)

    def from_test_8948(self, p0):
        MinguoDate.from(p0)

    def now_test_8949(self):
        MinguoDate.now()

    def now_test_8950(self, p0):
        MinguoDate.now(p0)

    def now_test_8951(self, p0):
        MinguoDate.now(p0)


class MinguoDate:
    @staticmethod
    def of(year, month, day):
        # Minguo calendar is ROC calendar (1911 + Gregorian year)
        gregorian_year = year + 1911
        return datetime(gregorian_year, month, day)

    @staticmethod
    def from(temporal):
        # Convert from a temporal accessor (simplified - assume datetime)
        if hasattr(temporal, 'year'):
            return MinguoDate.of(temporal.year - 1911, temporal.month, temporal.day)
        raise ValueError("Unsupported temporal type")

    @staticmethod
    def now(zone=None):
        if zone is None:
            current = datetime.now()
        elif isinstance(zone, ZoneInfo):
            current = datetime.now(zone)
        else:
            current = datetime.now()
        return MinguoDate.of(current.year - 1911, current.month, current.day)


if __name__ == '__main__':
    unittest.main()