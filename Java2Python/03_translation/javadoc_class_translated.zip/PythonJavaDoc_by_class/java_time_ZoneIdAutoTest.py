import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Mapping, Optional
import zoneinfo


class TestJavaTimeZoneIdAutoTest(unittest.TestCase):

    def of_test_13722(self, p0: str, p1: Mapping):
        ZoneIdWrapper.of(p0, p1)

    def of_test_13723(self, p0: str):
        ZoneIdWrapper.of(p0)

    def from_test_13724(self, p0):
        ZoneIdWrapper.from_(p0)

    def systemDefault_test_13725(self):
        ZoneIdWrapper.system_default()

    def getAvailableZoneIds_test_13726(self):
        ZoneIdWrapper.get_available_zone_ids()

    def ofOffset_test_13727(self, p0: str, p1):
        ZoneIdWrapper.of_offset(p0, p1)


class ZoneIdWrapper:
    """Wrapper class mimicking java.time.ZoneId static methods"""

    @staticmethod
    def of(zone_id: str, alias_map: Optional[Mapping] = None) -> ZoneInfo:
        """
        Mimics ZoneId.of(String, Map) and ZoneId.of(String)
        """
        if alias_map is not None:
            # Handle alias mapping if provided
            if zone_id in alias_map:
                zone_id = alias_map[zone_id]
        try:
            return ZoneInfo(zone_id)
        except zoneinfo.ZoneInfoNotFoundError:
            # Try common JVM timezone IDs not in IANA database
            common_mappings = {
                "GMT": "UTC",
                "UTC": "UTC",
                "Etc/UTC": "UTC",
                "Etc/GMT": "UTC",
                "Etc/GMT+0": "UTC",
                "Etc/GMT-0": "UTC",
                "Etc/GMT0": "UTC",
                "Etc/Zulu": "UTC",
                "Z": "UTC",
                "GMT+0": "UTC",
                "GMT-0": "UTC",
                "GMT0": "UTC",
                "Greenwich": "UTC",
                "Universal": "UTC",
                "Zulu": "UTC",
            }
            if zone_id in common_mappings:
                return ZoneInfo(common_mappings[zone_id])
            # Try with 'Etc/' prefix for some common zones
            if zone_id.startswith("GMT+"):
                try:
                    offset_hours = int(zone_id[4:])
                    return ZoneInfo(f"Etc/GMT-{offset_hours}")
                except (ValueError, zoneinfo.ZoneInfoNotFoundError):
                    pass
            elif zone_id.startswith("GMT-"):
                try:
                    offset_hours = int(zone_id[4:])
                    return ZoneInfo(f"Etc/GMT+{offset_hours}")
                except (ValueError, zoneinfo.ZoneInfoNotFoundError):
                    pass
            raise ValueError(f"Unknown time-zone ID: {zone_id}")

    @staticmethod
    def from_(temporal_accessor) -> ZoneInfo:
        """
        Mimics ZoneId.from(TemporalAccessor)
        Accepts datetime or object with tzinfo
        """
        if hasattr(temporal_accessor, 'tzinfo') and temporal_accessor.tzinfo is not None:
            if isinstance(temporal_accessor.tzinfo, ZoneInfo):
                return temporal_accessor.tzinfo
            elif isinstance(temporal_accessor.tzinfo, datetime.timezone):
                # Convert UTC offset to ZoneInfo
                offset = temporal_accessor.tzinfo.utcoffset(None)
                if offset == datetime.timedelta(0):
                    return ZoneInfo("UTC")
                # For fixed offsets, try to find a matching zone
                for zone_name in zoneinfo.available_timezones():
                    try:
                        zone = ZoneInfo(zone_name)
                        if zone.utcoffset(datetime.now()) == offset:
                            return zone
                    except:
                        continue
                raise ValueError("Unable to obtain ZoneId from TemporalAccessor")
        raise ValueError("Unable to obtain ZoneId from TemporalAccessor")

    @staticmethod
    def system_default() -> ZoneInfo:
        """Mimics ZoneId.systemDefault()"""
        return datetime.now().astimezone().tzinfo

    @staticmethod
    def get_available_zone_ids():
        """Mimics ZoneId.getAvailableZoneIds()"""
        return set(zoneinfo.available_timezones())

    @staticmethod
    def of_offset(prefix: str, offset) -> ZoneInfo:
        """
        Mimics ZoneId.ofOffset(String, ZoneOffset)
        Creates a ZoneId from a prefix and offset
        """
        if not isinstance(offset, datetime.timezone):
            offset = datetime.timezone(offset)
        offset_seconds = offset.utcoffset(None).total_seconds()
        if offset_seconds == 0:
            return ZoneInfo("UTC")
        hours = int(abs(offset_seconds) // 3600)
        minutes = int((abs(offset_seconds) % 3600) // 60)
        sign = "+" if offset_seconds >= 0 else "-"
        if prefix == "GMT":
            return ZoneInfo(f"Etc/GMT{sign}{hours}")
        elif prefix == "UTC":
            return ZoneInfo(f"Etc/UTC{sign}{hours}")
        else:
            raise ValueError(f"Invalid prefix: {prefix}")

    # Alias for compatibility
    @staticmethod
    def ofOffset(prefix: str, offset):
        return ZoneIdWrapper.of_offset(prefix, offset)

    @staticmethod
    def systemDefault():
        return ZoneIdWrapper.system_default()

    @staticmethod
    def getAvailableZoneIds():
        return ZoneIdWrapper.get_available_zone_ids()


if __name__ == '__main__':
    unittest.main()