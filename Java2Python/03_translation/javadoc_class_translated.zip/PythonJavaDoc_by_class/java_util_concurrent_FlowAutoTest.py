import unittest
from typing import Any


class Flow:
    @staticmethod
    def defaultBufferSize() -> int:
        return 256


class TestJavaUtilConcurrentFlowAutoTest(unittest.TestCase):
    def test_defaultBufferSize_test_4895(self):
        Flow.defaultBufferSize()


if __name__ == '__main__':
    unittest.main()