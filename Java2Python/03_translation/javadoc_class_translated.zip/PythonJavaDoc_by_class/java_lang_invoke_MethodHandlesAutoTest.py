import unittest
from unittest.mock import MagicMock, patch
from typing import List, Any
from enum import Enum
from dataclasses import dataclass


class MethodType:
    pass


class VarHandle:
    class AccessMode(Enum):
        GET = "get"
        SET = "set"


class MethodHandle:
    pass


class MethodHandles:
    @staticmethod
    def throwException(p0, p1):
        pass

    @staticmethod
    def lookup():
        pass

    @staticmethod
    def empty(p0):
        pass

    @staticmethod
    def constant(p0, p1):
        pass

    @staticmethod
    def identity(p0):
        pass

    @staticmethod
    def spreadInvoker(p0, p1):
        pass

    @staticmethod
    def arrayLength(p0):
        pass

    @staticmethod
    def varHandleInvoker(p0, p1):
        pass

    @staticmethod
    def publicLookup():
        pass

    @staticmethod
    def tryFinally(p0, p1):
        pass

    @staticmethod
    def loop(p0):
        pass

    @staticmethod
    def tableSwitch(p0, p1):
        pass

    @staticmethod
    def arrayConstructor(p0):
        pass

    @staticmethod
    def exactInvoker(p0):
        pass

    @staticmethod
    def foldArguments(p0, p1):
        pass

    @staticmethod
    def foldArguments(p0, p1, p2):
        pass

    @staticmethod
    def invoker(p0):
        pass

    @staticmethod
    def reflectAs(p0, p1):
        pass

    @staticmethod
    def zero(p0):
        pass

    @staticmethod
    def dropArgumentsToMatch(p0, p1, p2, p3):
        pass

    @staticmethod
    def dropArguments(p0, p1, p2):
        pass

    @staticmethod
    def dropArguments(p0, p1, p2):
        pass

    @staticmethod
    def countedLoop(p0, p1, p2, p3):
        pass

    @staticmethod
    def countedLoop(p0, p1, p2):
        pass

    @staticmethod
    def permuteArguments(p0, p1, p2):
        pass

    @staticmethod
    def filterValue(p0, p1, p2):
        pass

    @staticmethod
    def filterCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def insertCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def permuteCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def collectCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def dropCoordinates(p0, p1, p2):
        pass

    @staticmethod
    def arrayElementGetter(p0):
        pass

    @staticmethod
    def arrayElementSetter(p0):
        pass

    @staticmethod
    def arrayElementVarHandle(p0):
        pass

    @staticmethod
    def byteArrayViewVarHandle(p0, p1):
        pass

    @staticmethod
    def byteBufferViewVarHandle(p0, p1):
        pass

    @staticmethod
    def varHandleExactInvoker(p0, p1):
        pass

    @staticmethod
    def explicitCastArguments(p0, p1):
        pass

    @staticmethod
    def insertArguments(p0, p1, p2):
        pass

    @staticmethod
    def dropReturn(p0):
        pass

    @staticmethod
    def filterArguments(p0, p1, p2):
        pass

    @staticmethod
    def collectArguments(p0, p1, p2):
        pass

    @staticmethod
    def filterReturnValue(p0, p1):
        pass

    @staticmethod
    def guardWithTest(p0, p1, p2):
        pass

    @staticmethod
    def catchException(p0, p1, p2):
        pass

    @staticmethod
    def whileLoop(p0, p1, p2):
        pass

    @staticmethod
    def doWhileLoop(p0, p1, p2):
        pass

    @staticmethod
    def iteratedLoop(p0, p1, p2):
        pass


class TestMethodHandles(unittest.TestCase):
    def test_throwException_test_8874(self):
        MethodHandles.throwException(int, Exception)
        self.assertTrue(True)

    def test_lookup_test_8875(self):
        MethodHandles.lookup()
        self.assertTrue(True)

    def test_empty_test_8876(self):
        MethodHandles.empty(MethodType())
        self.assertTrue(True)

    def test_constant_test_8877(self):
        MethodHandles.constant(int, 42)
        self.assertTrue(True)

    def test_identity_test_8878(self):
        MethodHandles.identity(int)
        self.assertTrue(True)

    def test_spreadInvoker_test_8879(self):
        MethodHandles.spreadInvoker(MethodType(), 0)
        self.assertTrue(True)

    def test_arrayLength_test_8880(self):
        MethodHandles.arrayLength(int)
        self.assertTrue(True)

    def test_varHandleInvoker_test_8881(self):
        MethodHandles.varHandleInvoker(VarHandle.AccessMode.GET, MethodType())
        self.assertTrue(True)

    def test_publicLookup_test_8882(self):
        MethodHandles.publicLookup()
        self.assertTrue(True)

    def test_tryFinally_test_8883(self):
        MethodHandles.tryFinally(MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_loop_test_8884(self):
        MethodHandles.loop([[MethodHandle()]])
        self.assertTrue(True)

    def test_tableSwitch_test_8885(self):
        MethodHandles.tableSwitch(MethodHandle(), [MethodHandle()])
        self.assertTrue(True)

    def test_arrayConstructor_test_8886(self):
        MethodHandles.arrayConstructor(int)
        self.assertTrue(True)

    def test_exactInvoker_test_8887(self):
        MethodHandles.exactInvoker(MethodType())
        self.assertTrue(True)

    def test_foldArguments_test_8888(self):
        MethodHandles.foldArguments(MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_foldArguments_test_8889(self):
        MethodHandles.foldArguments(MethodHandle(), 0, MethodHandle())
        self.assertTrue(True)

    def test_invoker_test_8890(self):
        MethodHandles.invoker(MethodType())
        self.assertTrue(True)

    def test_reflectAs_test_8891(self):
        MethodHandles.reflectAs(int, MethodHandle())
        self.assertTrue(True)

    def test_zero_test_8892(self):
        MethodHandles.zero(int)
        self.assertTrue(True)

    def test_dropArgumentsToMatch_test_8893(self):
        MethodHandles.dropArgumentsToMatch(MethodHandle(), 0, [], 0)
        self.assertTrue(True)

    def test_dropArguments_test_8894(self):
        MethodHandles.dropArguments(MethodHandle(), 0, [])
        self.assertTrue(True)

    def test_dropArguments_test_8895(self):
        MethodHandles.dropArguments(MethodHandle(), 0, [int])
        self.assertTrue(True)

    def test_countedLoop_test_8896(self):
        MethodHandles.countedLoop(MethodHandle(), MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_countedLoop_test_8897(self):
        MethodHandles.countedLoop(MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_permuteArguments_test_8898(self):
        MethodHandles.permuteArguments(MethodHandle(), MethodType(), [0])
        self.assertTrue(True)

    def test_filterValue_test_8899(self):
        MethodHandles.filterValue(VarHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_filterCoordinates_test_8900(self):
        MethodHandles.filterCoordinates(VarHandle(), 0, [MethodHandle()])
        self.assertTrue(True)

    def test_insertCoordinates_test_8901(self):
        MethodHandles.insertCoordinates(VarHandle(), 0, [object()])
        self.assertTrue(True)

    def test_permuteCoordinates_test_8902(self):
        MethodHandles.permuteCoordinates(VarHandle(), [], [0])
        self.assertTrue(True)

    def test_collectCoordinates_test_8903(self):
        MethodHandles.collectCoordinates(VarHandle(), 0, MethodHandle())
        self.assertTrue(True)

    def test_dropCoordinates_test_8904(self):
        MethodHandles.dropCoordinates(VarHandle(), 0, [int])
        self.assertTrue(True)

    def test_arrayElementGetter_test_8905(self):
        MethodHandles.arrayElementGetter(int)
        self.assertTrue(True)

    def test_arrayElementSetter_test_8906(self):
        MethodHandles.arrayElementSetter(int)
        self.assertTrue(True)

    def test_arrayElementVarHandle_test_8907(self):
        MethodHandles.arrayElementVarHandle(int)
        self.assertTrue(True)

    def test_byteArrayViewVarHandle_test_8908(self):
        MethodHandles.byteArrayViewVarHandle(int, "BIG_ENDIAN")
        self.assertTrue(True)

    def test_byteBufferViewVarHandle_test_8909(self):
        MethodHandles.byteBufferViewVarHandle(int, "BIG_ENDIAN")
        self.assertTrue(True)

    def test_varHandleExactInvoker_test_8910(self):
        MethodHandles.varHandleExactInvoker(VarHandle.AccessMode.GET, MethodType())
        self.assertTrue(True)

    def test_explicitCastArguments_test_8911(self):
        MethodHandles.explicitCastArguments(MethodHandle(), MethodType())
        self.assertTrue(True)

    def test_insertArguments_test_8912(self):
        MethodHandles.insertArguments(MethodHandle(), 0, [object()])
        self.assertTrue(True)

    def test_dropReturn_test_8913(self):
        MethodHandles.dropReturn(MethodHandle())
        self.assertTrue(True)

    def test_filterArguments_test_8914(self):
        MethodHandles.filterArguments(MethodHandle(), 0, [MethodHandle()])
        self.assertTrue(True)

    def test_collectArguments_test_8915(self):
        MethodHandles.collectArguments(MethodHandle(), 0, MethodHandle())
        self.assertTrue(True)

    def test_filterReturnValue_test_8916(self):
        MethodHandles.filterReturnValue(MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_guardWithTest_test_8917(self):
        MethodHandles.guardWithTest(MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_catchException_test_8918(self):
        MethodHandles.catchException(MethodHandle(), Exception, MethodHandle())
        self.assertTrue(True)

    def test_whileLoop_test_8919(self):
        MethodHandles.whileLoop(MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_doWhileLoop_test_8920(self):
        MethodHandles.doWhileLoop(MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)

    def test_iteratedLoop_test_8921(self):
        MethodHandles.iteratedLoop(MethodHandle(), MethodHandle(), MethodHandle())
        self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()