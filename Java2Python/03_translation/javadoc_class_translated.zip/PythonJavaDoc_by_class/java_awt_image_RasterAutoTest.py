import unittest
from java_awt_image_RasterAutoTest import RasterWrapper, Point, DataBuffer, SampleModel


class TestRasterAutoTest(unittest.TestCase):

    def test_createInterleavedRaster_test_10325(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_interleaved_raster(0, 1, 2, 3, 4, [5], Point(6, 7))

    def test_createInterleavedRaster_test_10326(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_interleaved_raster(0, 1, 2, 3, Point(4, 5))

    def test_createInterleavedRaster_test_10327(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_interleaved_raster(DataBuffer(), 1, 2, 3, 4, [5], Point(6, 7))

    def test_createPackedRaster_test_10328(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_packed_raster(0, 1, 2, [3], Point(4, 5))

    def test_createPackedRaster_test_10329(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_packed_raster(0, 1, 2, 3, 4, Point(5, 6))

    def test_createPackedRaster_test_10330(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_packed_raster(DataBuffer(), 1, 2, 3, [4], Point(5, 6))

    def test_createPackedRaster_test_10331(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_packed_raster(DataBuffer(), 1, 2, 3, Point(4, 5))

    def test_createWritableRaster_test_10332(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_writable_raster(SampleModel(), Point(1, 2))

    def test_createWritableRaster_test_10333(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_writable_raster(SampleModel(), DataBuffer(), Point(1, 2))

    def test_createBandedRaster_test_10334(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_banded_raster(DataBuffer(), 1, 2, 3, [4], [5], Point(6, 7))

    def test_createBandedRaster_test_10335(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_banded_raster(0, 1, 2, 3, Point(4, 5))

    def test_createBandedRaster_test_10336(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_banded_raster(0, 1, 2, 3, [4], [5], Point(6, 7))

    def test_createRaster_test_10337(self):
        raster_wrapper = RasterWrapper()
        raster_wrapper.create_raster(SampleModel(), DataBuffer(), Point(1, 2))


class RasterWrapper:
    def create_interleaved_raster(self, *args):
        # Implementation would call Raster.createInterleavedRaster equivalent
        pass

    def create_packed_raster(self, *args):
        # Implementation would call Raster.createPackedRaster equivalent
        pass

    def create_writable_raster(self, *args):
        # Implementation would call Raster.createWritableRaster equivalent
        pass

    def create_banded_raster(self, *args):
        # Implementation would call Raster.createBandedRaster equivalent
        pass

    def create_raster(self, *args):
        # Implementation would call Raster.createRaster equivalent
        pass


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class DataBuffer:
    pass


class SampleModel:
    pass


if __name__ == '__main__':
    unittest.main()