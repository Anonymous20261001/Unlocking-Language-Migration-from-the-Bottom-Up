import unittest
from javax.imageio.plugins.tiff import FaxTIFFTagSet

class TestFaxTIFFTagSet(unittest.TestCase):
    def getInstance_test_4674(self):
        FaxTIFFTagSet.getInstance()


class FaxTIFFTagSetWrapper:
    @staticmethod
    def getInstance():
        return FaxTIFFTagSet.getInstance()