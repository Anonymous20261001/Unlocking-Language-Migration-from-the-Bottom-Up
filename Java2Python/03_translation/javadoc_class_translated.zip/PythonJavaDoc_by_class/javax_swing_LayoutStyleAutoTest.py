import unittest
from javax.swing import LayoutStyle

class TestJavaxSwingLayoutStyle(unittest.TestCase):
    def setInstance_test_7711(self, p0):
        LayoutStyle.setInstance(p0)
    
    def getInstance_test_7712(self):
        LayoutStyle.getInstance()


class LayoutStyleWrapper:
    @staticmethod
    def setInstance(p0):
        LayoutStyle.setInstance(p0)
    
    @staticmethod
    def getInstance():
        return LayoutStyle.getInstance()

if __name__ == '__main__':
    unittest.main()