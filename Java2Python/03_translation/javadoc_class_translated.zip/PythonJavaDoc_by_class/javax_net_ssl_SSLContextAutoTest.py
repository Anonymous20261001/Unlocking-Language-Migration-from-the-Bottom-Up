import unittest
import ssl

class TestSSLContextAuto(unittest.TestCase):
    def test_setDefault_test_11400(self):
        p0 = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        SSLContextWrapper.setDefault(p0)

class SSLContextWrapper:
    @staticmethod
    def setDefault(context):
        ssl._create_default_https_context = context