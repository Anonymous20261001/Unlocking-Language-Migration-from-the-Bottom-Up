import unittest
import javax.net.ssl.TrustManagerFactory

class TestTrustManagerFactory(unittest.TestCase):
    def getDefaultAlgorithm_test_13101(self):
        TrustManagerFactory.getDefaultAlgorithm()


class TrustManagerFactoryWrapper:
    @staticmethod
    def getDefaultAlgorithm():
        return TrustManagerFactory.getDefaultAlgorithm()