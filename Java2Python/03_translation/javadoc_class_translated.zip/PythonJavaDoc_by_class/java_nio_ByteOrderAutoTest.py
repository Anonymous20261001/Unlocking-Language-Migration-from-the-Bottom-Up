import unittest
import sys

class ByteOrder:
    @staticmethod
    def nativeOrder():
        return sys.byteorder

class TestByteOrder(unittest.TestCase):
    def test_nativeOrder_test_2007(self):
        ByteOrder.nativeOrder()

if __name__ == '__main__':
    unittest.main()