import unittest
from typing import List, Any
import jdk.dynalink.DynamicLinkerFactory as DynamicLinkerFactoryModule
from jdk.dynalink.linker import GuardingDynamicLinker, GuardedInvocationTransformer, MethodHandleTransformer, MethodTypeConversionStrategy
from java.lang import ClassLoader

class TestJdkDynalinkDynamicLinkerFactoryAutoTest(unittest.TestCase):
    def test_setFallbackLinkers_test_4425(self):
        instance = DynamicLinkerFactory()
        p0 = []
        instance.setFallbackLinkers(p0)

    def test_setFallbackLinkers_test_4426(self):
        instance = DynamicLinkerFactory()
        p0 = []
        instance.setFallbackLinkers(p0)

    def test_setClassLoader_test_4427(self):
        instance = DynamicLinkerFactory()
        p0 = None
        instance.setClassLoader(p0)

    def test_setSyncOnRelink_test_4428(self):
        instance = DynamicLinkerFactory()
        p0 = True
        instance.setSyncOnRelink(p0)

    def test_createLinker_test_4429(self):
        instance = DynamicLinkerFactory()
        instance.createLinker()

    def test_setPrioritizedLinkers_test_4430(self):
        instance = DynamicLinkerFactory()
        p0 = []
        instance.setPrioritizedLinkers(p0)

    def test_setPrioritizedLinkers_test_4431(self):
        instance = DynamicLinkerFactory()
        p0 = []
        instance.setPrioritizedLinkers(p0)

    def test_setPrioritizedLinker_test_4432(self):
        instance = DynamicLinkerFactory()
        p0 = None
        instance.setPrioritizedLinker(p0)

    def test_setUnstableRelinkThreshold_test_4433(self):
        instance = DynamicLinkerFactory()
        p0 = 0
        instance.setUnstableRelinkThreshold(p0)

    def test_setPrelinkTransformer_test_4434(self):
        instance = DynamicLinkerFactory()
        p0 = None
        instance.setPrelinkTransformer(p0)

    def test_setAutoConversionStrategy_test_4435(self):
        instance = DynamicLinkerFactory()
        p0 = None
        instance.setAutoConversionStrategy(p0)

    def test_setInternalObjectsFilter_test_4436(self):
        instance = DynamicLinkerFactory()
        p0 = None
        instance.setInternalObjectsFilter(p0)

    def test_getAutoLoadingErrors_test_4437(self):
        instance = DynamicLinkerFactory()
        instance.getAutoLoadingErrors()


class DynamicLinkerFactory:
    def __init__(self):
        self._fallback_linkers = None
        self._class_loader = None
        self._sync_on_relink = False
        self._prioritized_linkers = None
        self._prioritized_linker = None
        self._unstable_relink_threshold = 0
        self._prelink_transformer = None
        self._auto_conversion_strategy = None
        self._internal_objects_filter = None
        self._auto_loading_errors = []

    def setFallbackLinkers(self, linkers):
        self._fallback_linkers = linkers

    def setClassLoader(self, class_loader):
        self._class_loader = class_loader

    def setSyncOnRelink(self, sync):
        self._sync_on_relink = sync

    def createLinker(self):
        return None

    def setPrioritizedLinkers(self, linkers):
        self._prioritized_linkers = linkers

    def setPrioritizedLinker(self, linker):
        self._prioritized_linker = linker

    def setUnstableRelinkThreshold(self, threshold):
        self._unstable_relink_threshold = threshold

    def setPrelinkTransformer(self, transformer):
        self._prelink_transformer = transformer

    def setAutoConversionStrategy(self, strategy):
        self._auto_conversion_strategy = strategy

    def setInternalObjectsFilter(self, filter):
        self._internal_objects_filter = filter

    def getAutoLoadingErrors(self):
        return self._auto_loading_errors


if __name__ == '__main__':
    unittest.main()