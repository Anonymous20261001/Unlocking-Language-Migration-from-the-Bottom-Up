import unittest
from unittest.mock import MagicMock
from typing import List, Optional

class Notification:
    """Mock Notification class for testing"""
    pass

class AttributeChangeNotificationFilter:
    """Wrapper class for javax.management.AttributeChangeNotificationFilter"""
    
    def __init__(self):
        self.enabled_attributes = []
    
    def isNotificationEnabled(self, notification: Notification) -> bool:
        """Check if notification is enabled"""
        if not hasattr(notification, 'getAttributeName'):
            return False
        attr_name = notification.getAttributeName()
        return attr_name in self.enabled_attributes
    
    def enableAttribute(self, attribute_name: str) -> None:
        """Enable an attribute"""
        if attribute_name not in self.enabled_attributes:
            self.enabled_attributes.append(attribute_name)
    
    def disableAttribute(self, attribute_name: str) -> None:
        """Disable an attribute"""
        if attribute_name in self.enabled_attributes:
            self.enabled_attributes.remove(attribute_name)
    
    def disableAllAttributes(self) -> None:
        """Disable all attributes"""
        self.enabled_attributes.clear()
    
    def getEnabledAttributes(self) -> List[str]:
        """Get enabled attributes"""
        return self.enabled_attributes.copy()


class TestJavaxManagementAttributeChangeNotificationFilterAutoTest(unittest.TestCase):
    
    def test_isNotificationEnabled_test_762(self):
        p0 = MagicMock(spec=Notification)
        p0.getAttributeName.return_value = "test_attr"
        instance = AttributeChangeNotificationFilter()
        instance.isNotificationEnabled(p0)
    
    def test_enableAttribute_test_763(self):
        p0 = "test_attr"
        instance = AttributeChangeNotificationFilter()
        instance.enableAttribute(p0)
    
    def test_disableAttribute_test_764(self):
        p0 = "test_attr"
        instance = AttributeChangeNotificationFilter()
        instance.disableAttribute(p0)
    
    def test_disableAllAttributes_test_765(self):
        instance = AttributeChangeNotificationFilter()
        instance.disableAllAttributes()
    
    def test_getEnabledAttributes_test_766(self):
        instance = AttributeChangeNotificationFilter()
        instance.getEnabledAttributes()


if __name__ == '__main__':
    unittest.main()