import unittest
from unittest.mock import Mock
from typing import Any


class TestNamedOperation(unittest.TestCase):
    def test_getName_test_9477(self):
        p0 = Mock(spec=Operation)
        NamedOperation.getName(p0)
    
    def test_getName_test_9478(self):
        c0 = Mock(spec=Operation)
        c1 = Mock()
        instance = NamedOperation(c0, c1)
        instance.getName()
    
    def test_changeName_test_9479(self):
        p0 = "new_name"
        c0 = Mock(spec=Operation)
        c1 = Mock()
        instance = NamedOperation(c0, c1)
        instance.changeName(p0)
    
    def test_getBaseOperation_test_9480(self):
        c0 = Mock(spec=Operation)
        c1 = Mock()
        instance = NamedOperation(c0, c1)
        instance.getBaseOperation()
    
    def test_getBaseOperation_test_9481(self):
        p0 = Mock(spec=Operation)
        NamedOperation.getBaseOperation(p0)


class Operation:
    """Base class for operations"""
    pass


class NamedOperation:
    def __init__(self, base_operation: Operation, name: Any):
        self.base_operation = base_operation
        self.name = name
    
    def getName(self):
        return self.name
    
    def changeName(self, new_name: str):
        self.name = new_name
    
    def getBaseOperation(self):
        return self.base_operation
    
    @staticmethod
    def getName(operation: Operation):
        return operation.name if hasattr(operation, 'name') else None
    
    @staticmethod
    def getBaseOperation(operation: Operation):
        return operation.base_operation if hasattr(operation, 'base_operation') else None


if __name__ == '__main__':
    unittest.main()