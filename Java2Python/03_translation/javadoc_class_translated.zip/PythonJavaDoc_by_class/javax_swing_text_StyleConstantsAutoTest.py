import unittest
from javax.swing.text import StyleConstants, MutableAttributeSet, AttributeSet, TabSet
from java.awt import Color, Component
from javax.swing import Icon

class TestStyleConstants(unittest.TestCase):
    def test_setFontFamily_test_11929(self):
        p0 = MutableAttributeSet()
        p1 = "Arial"
        StyleConstants.setFontFamily(p0, p1)

    def test_setFontSize_test_11930(self):
        p0 = MutableAttributeSet()
        p1 = 12
        StyleConstants.setFontSize(p0, p1)

    def test_isBold_test_11931(self):
        p0 = AttributeSet()
        StyleConstants.isBold(p0)

    def test_setBold_test_11932(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setBold(p0, p1)

    def test_isItalic_test_11933(self):
        p0 = AttributeSet()
        StyleConstants.isItalic(p0)

    def test_setItalic_test_11934(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setItalic(p0, p1)

    def test_setBidiLevel_test_11935(self):
        p0 = MutableAttributeSet()
        p1 = 1
        StyleConstants.setBidiLevel(p0, p1)

    def test_isUnderline_test_11936(self):
        p0 = AttributeSet()
        StyleConstants.isUnderline(p0)

    def test_isStrikeThrough_test_11937(self):
        p0 = AttributeSet()
        StyleConstants.isStrikeThrough(p0)

    def test_setStrikeThrough_test_11938(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setStrikeThrough(p0, p1)

    def test_setSubscript_test_11939(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setSubscript(p0, p1)

    def test_getFirstLineIndent_test_11940(self):
        p0 = AttributeSet()
        StyleConstants.getFirstLineIndent(p0)

    def test_setFirstLineIndent_test_11941(self):
        p0 = MutableAttributeSet()
        p1 = 0.5
        StyleConstants.setFirstLineIndent(p0, p1)

    def test_setRightIndent_test_11942(self):
        p0 = MutableAttributeSet()
        p1 = 0.5
        StyleConstants.setRightIndent(p0, p1)

    def test_setLeftIndent_test_11943(self):
        p0 = MutableAttributeSet()
        p1 = 0.5
        StyleConstants.setLeftIndent(p0, p1)

    def test_getLineSpacing_test_11944(self):
        p0 = AttributeSet()
        StyleConstants.getLineSpacing(p0)

    def test_setLineSpacing_test_11945(self):
        p0 = MutableAttributeSet()
        p1 = 1.5
        StyleConstants.setLineSpacing(p0, p1)

    def test_setSpaceAbove_test_11946(self):
        p0 = MutableAttributeSet()
        p1 = 0.5
        StyleConstants.setSpaceAbove(p0, p1)

    def test_setSpaceBelow_test_11947(self):
        p0 = MutableAttributeSet()
        p1 = 0.5
        StyleConstants.setSpaceBelow(p0, p1)

    def test_setAlignment_test_11948(self):
        p0 = MutableAttributeSet()
        p1 = 1
        StyleConstants.setAlignment(p0, p1)

    def test_getTabSet_test_11949(self):
        p0 = AttributeSet()
        StyleConstants.getTabSet(p0)

    def test_setTabSet_test_11950(self):
        p0 = MutableAttributeSet()
        p1 = TabSet()
        StyleConstants.setTabSet(p0, p1)

    def test_setSuperscript_test_11951(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setSuperscript(p0, p1)

    def test_setUnderline_test_11952(self):
        p0 = MutableAttributeSet()
        p1 = True
        StyleConstants.setUnderline(p0, p1)

    def test_getSpaceAbove_test_11953(self):
        p0 = AttributeSet()
        StyleConstants.getSpaceAbove(p0)

    def test_getLeftIndent_test_11954(self):
        p0 = AttributeSet()
        StyleConstants.getLeftIndent(p0)

    def test_getSpaceBelow_test_11955(self):
        p0 = AttributeSet()
        StyleConstants.getSpaceBelow(p0)

    def test_getRightIndent_test_11956(self):
        p0 = AttributeSet()
        StyleConstants.getRightIndent(p0)

    def test_getForeground_test_11957(self):
        p0 = AttributeSet()
        StyleConstants.getForeground(p0)

    def test_setForeground_test_11958(self):
        p0 = MutableAttributeSet()
        p1 = Color.BLACK
        StyleConstants.setForeground(p0, p1)

    def test_getBackground_test_11959(self):
        p0 = AttributeSet()
        StyleConstants.getBackground(p0)

    def test_setBackground_test_11960(self):
        p0 = MutableAttributeSet()
        p1 = Color.WHITE
        StyleConstants.setBackground(p0, p1)

    def test_setComponent_test_11961(self):
        p0 = MutableAttributeSet()
        p1 = Component()
        StyleConstants.setComponent(p0, p1)

    def test_getIcon_test_11962(self):
        p0 = AttributeSet()
        StyleConstants.getIcon(p0)

    def test_setIcon_test_11963(self):
        p0 = MutableAttributeSet()
        p1 = Icon()
        StyleConstants.setIcon(p0, p1)

    def test_getBidiLevel_test_11964(self):
        p0 = AttributeSet()
        StyleConstants.getBidiLevel(p0)

    def test_getAlignment_test_11965(self):
        p0 = AttributeSet()
        StyleConstants.getAlignment(p0)

    def test_getFontFamily_test_11966(self):
        p0 = AttributeSet()
        StyleConstants.getFontFamily(p0)

    def test_getFontSize_test_11967(self):
        p0 = AttributeSet()
        StyleConstants.getFontSize(p0)

    def test_isSuperscript_test_11968(self):
        p0 = AttributeSet()
        StyleConstants.isSuperscript(p0)

    def test_isSubscript_test_11969(self):
        p0 = AttributeSet()
        StyleConstants.isSubscript(p0)

    def test_getComponent_test_11970(self):
        p0 = AttributeSet()
        StyleConstants.getComponent(p0)


class StyleConstantsWrapper:
    @staticmethod
    def setFontFamily(p0, p1):
        return StyleConstants.setFontFamily(p0, p1)

    @staticmethod
    def setFontSize(p0, p1):
        return StyleConstants.setFontSize(p0, p1)

    @staticmethod
    def isBold(p0):
        return StyleConstants.isBold(p0)

    @staticmethod
    def setBold(p0, p1):
        return StyleConstants.setBold(p0, p1)

    @staticmethod
    def isItalic(p0):
        return StyleConstants.isItalic(p0)

    @staticmethod
    def setItalic(p0, p1):
        return StyleConstants.setItalic(p0, p1)

    @staticmethod
    def setBidiLevel(p0, p1):
        return StyleConstants.setBidiLevel(p0, p1)

    @staticmethod
    def isUnderline(p0):
        return StyleConstants.isUnderline(p0)

    @staticmethod
    def isStrikeThrough(p0):
        return StyleConstants.isStrikeThrough(p0)

    @staticmethod
    def setStrikeThrough(p0, p1):
        return StyleConstants.setStrikeThrough(p0, p1)

    @staticmethod
    def setSubscript(p0, p1):
        return StyleConstants.setSubscript(p0, p1)

    @staticmethod
    def getFirstLineIndent(p0):
        return StyleConstants.getFirstLineIndent(p0)

    @staticmethod
    def setFirstLineIndent(p0, p1):
        return StyleConstants.setFirstLineIndent(p0, p1)

    @staticmethod
    def setRightIndent(p0, p1):
        return StyleConstants.setRightIndent(p0, p1)

    @staticmethod
    def setLeftIndent(p0, p1):
        return StyleConstants.setLeftIndent(p0, p1)

    @staticmethod
    def getLineSpacing(p0):
        return StyleConstants.getLineSpacing(p0)

    @staticmethod
    def setLineSpacing(p0, p1):
        return StyleConstants.setLineSpacing(p0, p1)

    @staticmethod
    def setSpaceAbove(p0, p1):
        return StyleConstants.setSpaceAbove(p0, p1)

    @staticmethod
    def setSpaceBelow(p0, p1):
        return StyleConstants.setSpaceBelow(p0, p1)

    @staticmethod
    def setAlignment(p0, p1):
        return StyleConstants.setAlignment(p0, p1)

    @staticmethod
    def getTabSet(p0):
        return StyleConstants.getTabSet(p0)

    @staticmethod
    def setTabSet(p0, p1):
        return StyleConstants.setTabSet(p0, p1)

    @staticmethod
    def setSuperscript(p0, p1):
        return StyleConstants.setSuperscript(p0, p1)

    @staticmethod
    def setUnderline(p0, p1):
        return StyleConstants.setUnderline(p0, p1)

    @staticmethod
    def getSpaceAbove(p0):
        return StyleConstants.getSpaceAbove(p0)

    @staticmethod
    def getLeftIndent(p0):
        return StyleConstants.getLeftIndent(p0)

    @staticmethod
    def getSpaceBelow(p0):
        return StyleConstants.getSpaceBelow(p0)

    @staticmethod
    def getRightIndent(p0):
        return StyleConstants.getRightIndent(p0)

    @staticmethod
    def getForeground(p0):
        return StyleConstants.getForeground(p0)

    @staticmethod
    def setForeground(p0, p1):
        return StyleConstants.setForeground(p0, p1)

    @staticmethod
    def getBackground(p0):
        return StyleConstants.getBackground(p0)

    @staticmethod
    def setBackground(p0, p1):
        return StyleConstants.setBackground(p0, p1)

    @staticmethod
    def setComponent(p0, p1):
        return StyleConstants.setComponent(p0, p1)

    @staticmethod
    def getIcon(p0):
        return StyleConstants.getIcon(p0)

    @staticmethod
    def setIcon(p0, p1):
        return StyleConstants.setIcon(p0, p1)

    @staticmethod
    def getBidiLevel(p0):
        return StyleConstants.getBidiLevel(p0)

    @staticmethod
    def getAlignment(p0):
        return StyleConstants.getAlignment(p0)

    @staticmethod
    def getFontFamily(p0):
        return StyleConstants.getFontFamily(p0)

    @staticmethod
    def getFontSize(p0):
        return StyleConstants.getFontSize(p0)

    @staticmethod
    def isSuperscript(p0):
        return StyleConstants.isSuperscript(p0)

    @staticmethod
    def isSubscript(p0):
        return StyleConstants.isSubscript(p0)

    @staticmethod
    def getComponent(p0):
        return StyleConstants.getComponent(p0)


if __name__ == '__main__':
    unittest.main()