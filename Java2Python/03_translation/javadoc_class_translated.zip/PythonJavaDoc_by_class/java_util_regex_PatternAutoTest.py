import unittest
import re
from typing import CharSequence


class TestPattern(unittest.TestCase):
    def matches_test_9865(self, p0: str, p1: CharSequence):
        Pattern.matches(p0, p1)

    def compile_test_9866(self, p0: str):
        Pattern.compile(p0)

    def compile_test_9867(self, p0: str, p1: int):
        Pattern.compile(p0, p1)

    def quote_test_9868(self, p0: str):
        Pattern.quote(p0)


class Pattern:
    @staticmethod
    def matches(regex: str, input: CharSequence) -> bool:
        return re.match(regex, str(input)) is not None

    @staticmethod
    def compile(pattern: str, flags: int = 0) -> 'Pattern':
        return re.compile(pattern, flags)

    @staticmethod
    def quote(s: str) -> str:
        return re.escape(s)


if __name__ == '__main__':
    unittest.main()