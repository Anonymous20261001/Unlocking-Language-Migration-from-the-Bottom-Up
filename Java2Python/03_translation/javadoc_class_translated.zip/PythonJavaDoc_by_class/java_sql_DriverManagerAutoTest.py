import unittest
from unittest.mock import MagicMock
import java.sql.DriverManager as DriverManager


class TestJavaSqlDriverManagerAutoTest(unittest.TestCase):

    def test_setLogStream_test_4342(self):
        p0 = MagicMock()
        DriverManager.setLogStream(p0)

    def test_println_test_4343(self):
        p0 = "test string"
        DriverManager.println(p0)

    def test_getLogWriter_test_4344(self):
        DriverManager.getLogWriter()

    def test_getDrivers_test_4345(self):
        DriverManager.getDrivers()

    def test_setLogWriter_test_4346(self):
        p0 = MagicMock()
        DriverManager.setLogWriter(p0)

    def test_drivers_test_4347(self):
        DriverManager.drivers()

    def test_setLoginTimeout_test_4348(self):
        p0 = 30
        DriverManager.setLoginTimeout(p0)

    def test_getLoginTimeout_test_4349(self):
        DriverManager.getLoginTimeout()

    def test_getLogStream_test_4350(self):
        DriverManager.getLogStream()


class DriverManagerWrapper:
    """Wrapper class matching the DriverManager static methods"""
    
    @staticmethod
    def setLogStream(stream):
        return DriverManager.setLogStream(stream)
    
    @staticmethod
    def println(message):
        return DriverManager.println(message)
    
    @staticmethod
    def getLogWriter():
        return DriverManager.getLogWriter()
    
    @staticmethod
    def getDrivers():
        return DriverManager.getDrivers()
    
    @staticmethod
    def setLogWriter(writer):
        return DriverManager.setLogWriter(writer)
    
    @staticmethod
    def drivers():
        return DriverManager.drivers()
    
    @staticmethod
    def setLoginTimeout(seconds):
        return DriverManager.setLoginTimeout(seconds)
    
    @staticmethod
    def getLoginTimeout():
        return DriverManager.getLoginTimeout()
    
    @staticmethod
    def getLogStream():
        return DriverManager.getLogStream()


if __name__ == '__main__':
    unittest.main()