import unittest
import java.lang.invoke.MethodType

class TestMethodTypeAutoTest(unittest.TestCase):
    
    def test_methodType_test_8922(self):
        p0 = None
        p1 = None
        MethodType.methodType(p0, p1)
    
    def test_methodType_test_8923(self):
        p0 = None
        MethodType.methodType(p0)
    
    def test_methodType_test_8924(self):
        p0 = None
        p1 = None
        p2 = None
        MethodType.methodType(p0, p1, p2)
    
    def test_methodType_test_8925(self):
        p0 = None
        p1 = None
        MethodType.methodType(p0, p1)
    
    def test_methodType_test_8926(self):
        p0 = None
        p1 = None
        MethodType.methodType(p0, p1)
    
    def test_methodType_test_8927(self):
        p0 = None
        p1 = None
        MethodType.methodType(p0, p1)
    
    def test_genericMethodType_test_8928(self):
        p0 = 0
        p1 = False
        MethodType.genericMethodType(p0, p1)
    
    def test_genericMethodType_test_8929(self):
        p0 = 0
        MethodType.genericMethodType(p0)
    
    def test_fromMethodDescriptorString_test_8930(self):
        p0 = ""
        p1 = None
        MethodType.fromMethodDescriptorString(p0, p1)

# Wrapper class with the methods called by the tests
class MethodTypeWrapper:
    @staticmethod
    def methodType(*args):
        return MethodType.methodType(*args)
    
    @staticmethod
    def genericMethodType(*args):
        return MethodType.genericMethodType(*args)
    
    @staticmethod
    def fromMethodDescriptorString(*args):
        return MethodType.fromMethodDescriptorString(*args)

if __name__ == '__main__':
    unittest.main()