import unittest
from javax.management import Notification, ObjectName
from javax.management.relation import RelationService

class TestJavaxManagementRelationRelationServiceAutoTest(unittest.TestCase):
    def test_getNotificationInfo_test_10508(self):
        c0 = True
        instance = RelationService(c0)
        instance.getNotificationInfo()

    def test_postRegister_test_10509(self):
        p0 = Boolean(True)
        c0 = True
        instance = RelationService(c0)
        instance.postRegister(p0)

    def test_postDeregister_test_10510(self):
        c0 = True
        instance = RelationService(c0)
        instance.postDeregister()

    def test_handleNotification_test_10511(self):
        p0 = Notification("type", "source", 0)
        p1 = object()
        c0 = True
        instance = RelationService(c0)
        instance.handleNotification(p0, p1)

    def test_getAllRelationTypeNames_test_10512(self):
        c0 = True
        instance = RelationService(c0)
        instance.getAllRelationTypeNames()

    def test_isRelation_test_10513(self):
        p0 = ObjectName("domain:key=value")
        c0 = True
        instance = RelationService(c0)
        instance.isRelation(p0)

    def test_hasRelation_test_10514(self):
        p0 = "relation_id"
        c0 = True
        instance = RelationService(c0)
        instance.hasRelation(p0)

    def test_getAllRelationIds_test_10515(self):
        c0 = True
        instance = RelationService(c0)
        instance.getAllRelationIds()

    def test_findAssociatedMBeans_test_10516(self):
        p0 = ObjectName("domain:key=value")
        p1 = "relation_type"
        p2 = "role_name"
        c0 = True
        instance = RelationService(c0)
        instance.findAssociatedMBeans(p0, p1, p2)

    def test_setPurgeFlag_test_10517(self):
        p0 = True
        c0 = True
        instance = RelationService(c0)
        instance.setPurgeFlag(p0)

    def test_findReferencingRelations_test_10518(self):
        p0 = ObjectName("domain:key=value")
        p1 = "relation_type"
        p2 = "role_name"
        c0 = True
        instance = RelationService(c0)
        instance.findReferencingRelations(p0, p1, p2)

    def test_getPurgeFlag_test_10519(self):
        c0 = True
        instance = RelationService(c0)
        instance.getPurgeFlag()


class RelationServiceWrapper:
    def __init__(self, c0):
        self.instance = RelationService(c0)

    def getNotificationInfo(self):
        return self.instance.getNotificationInfo()

    def postRegister(self, p0):
        return self.instance.postRegister(p0)

    def postDeregister(self):
        return self.instance.postDeregister()

    def handleNotification(self, p0, p1):
        return self.instance.handleNotification(p0, p1)

    def getAllRelationTypeNames(self):
        return self.instance.getAllRelationTypeNames()

    def isRelation(self, p0):
        return self.instance.isRelation(p0)

    def hasRelation(self, p0):
        return self.instance.hasRelation(p0)

    def getAllRelationIds(self):
        return self.instance.getAllRelationIds()

    def findAssociatedMBeans(self, p0, p1, p2):
        return self.instance.findAssociatedMBeans(p0, p1, p2)

    def setPurgeFlag(self, p0):
        return self.instance.setPurgeFlag(p0)

    def findReferencingRelations(self, p0, p1, p2):
        return self.instance.findReferencingRelations(p0, p1, p2)

    def getPurgeFlag(self):
        return self.instance.getPurgeFlag()

if __name__ == '__main__':
    unittest.main()