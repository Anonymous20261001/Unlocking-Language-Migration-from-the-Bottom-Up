import unittest

class RoleInfo:
    def __init__(self, c0):
        self.c0 = c0
        self.description = "test description"
        self.min_degree = 1
        self.max_degree = 2
        self.ref_mbean_class_name = "TestClass"
        self.name = "TestRole"
        self.writable = True
        self.readable = True

    def getDescription(self):
        return self.description

    def getMinDegree(self):
        return self.min_degree

    def getMaxDegree(self):
        return self.max_degree

    def checkMinDegree(self, p0):
        return self.min_degree == p0

    def checkMaxDegree(self, p0):
        return self.max_degree == p0

    def getRefMBeanClassName(self):
        return self.ref_mbean_class_name

    def getName(self):
        return self.name

    def isWritable(self):
        return self.writable

    def isReadable(self):
        return self.readable


class TestRoleInfo(unittest.TestCase):
    def test_getDescription_test_10645(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.getDescription()

    def test_getMinDegree_test_10646(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.getMinDegree()

    def test_getMaxDegree_test_10647(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.getMaxDegree()

    def test_checkMinDegree_test_10648(self):
        p0 = 1
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.checkMinDegree(p0)

    def test_checkMaxDegree_test_10649(self):
        p0 = 2
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.checkMaxDegree(p0)

    def test_getRefMBeanClassName_test_10650(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.getRefMBeanClassName()

    def test_getName_test_10651(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.getName()

    def test_isWritable_test_10652(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.isWritable()

    def test_isReadable_test_10653(self):
        c0 = RoleInfo("test")
        instance = RoleInfo(c0)
        instance.isReadable()


if __name__ == '__main__':
    unittest.main()