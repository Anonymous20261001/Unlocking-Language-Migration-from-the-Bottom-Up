import unittest
from unittest.mock import MagicMock, patch
import java.lang.management.ManagementFactory as ManagementFactory


class TestManagementFactory(unittest.TestCase):

    def test_getPlatformMXBean_test_8262(self):
        p0 = MagicMock()
        ManagementFactory.getPlatformMXBean(p0)

    def test_getPlatformMXBeans_test_8263(self):
        p0 = MagicMock()
        ManagementFactory.getPlatformMXBeans(p0)

    def test_getClassLoadingMXBean_test_8264(self):
        ManagementFactory.getClassLoadingMXBean()

    def test_getMemoryMXBean_test_8265(self):
        ManagementFactory.getMemoryMXBean()

    def test_getThreadMXBean_test_8266(self):
        ManagementFactory.getThreadMXBean()

    def test_getRuntimeMXBean_test_8267(self):
        ManagementFactory.getRuntimeMXBean()

    def test_getCompilationMXBean_test_8268(self):
        ManagementFactory.getCompilationMXBean()

    def test_getOperatingSystemMXBean_test_8269(self):
        ManagementFactory.getOperatingSystemMXBean()

    def test_getMemoryPoolMXBeans_test_8270(self):
        ManagementFactory.getMemoryPoolMXBeans()

    def test_getMemoryManagerMXBeans_test_8271(self):
        ManagementFactory.getMemoryManagerMXBeans()

    def test_getGarbageCollectorMXBeans_test_8272(self):
        ManagementFactory.getGarbageCollectorMXBeans()

    def test_getPlatformMBeanServer_test_8273(self):
        ManagementFactory.getPlatformMBeanServer()

    def test_getPlatformManagementInterfaces_test_8274(self):
        ManagementFactory.getPlatformManagementInterfaces()


class ManagementFactoryWrapper:
    """Wrapper class containing methods called by the tests"""
    
    @staticmethod
    def getPlatformMXBean(cls):
        return ManagementFactory.getPlatformMXBean(cls)
    
    @staticmethod
    def getPlatformMXBeans(cls):
        return ManagementFactory.getPlatformMXBeans(cls)
    
    @staticmethod
    def getClassLoadingMXBean():
        return ManagementFactory.getClassLoadingMXBean()
    
    @staticmethod
    def getMemoryMXBean():
        return ManagementFactory.getMemoryMXBean()
    
    @staticmethod
    def getThreadMXBean():
        return ManagementFactory.getThreadMXBean()
    
    @staticmethod
    def getRuntimeMXBean():
        return ManagementFactory.getRuntimeMXBean()
    
    @staticmethod
    def getCompilationMXBean():
        return ManagementFactory.getCompilationMXBean()
    
    @staticmethod
    def getOperatingSystemMXBean():
        return ManagementFactory.getOperatingSystemMXBean()
    
    @staticmethod
    def getMemoryPoolMXBeans():
        return ManagementFactory.getMemoryPoolMXBeans()
    
    @staticmethod
    def getMemoryManagerMXBeans():
        return ManagementFactory.getMemoryManagerMXBeans()
    
    @staticmethod
    def getGarbageCollectorMXBeans():
        return ManagementFactory.getGarbageCollectorMXBeans()
    
    @staticmethod
    def getPlatformMBeanServer():
        return ManagementFactory.getPlatformMBeanServer()
    
    @staticmethod
    def getPlatformManagementInterfaces():
        return ManagementFactory.getPlatformManagementInterfaces()


if __name__ == '__main__':
    unittest.main()