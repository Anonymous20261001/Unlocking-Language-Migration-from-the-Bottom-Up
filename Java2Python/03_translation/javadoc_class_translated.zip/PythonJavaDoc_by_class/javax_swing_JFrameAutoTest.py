import unittest
from unittest.mock import MagicMock


class TestJFrame(unittest.TestCase):
    def test_getContentPane_test_6253(self):
        instance = JFrameWrapper()
        instance.getContentPane()

    def test_isDefaultLookAndFeelDecorated_test_6254(self):
        JFrameWrapper.isDefaultLookAndFeelDecorated()

    def test_getJMenuBar_test_6255(self):
        instance = JFrameWrapper()
        instance.getJMenuBar()

    def test_setJMenuBar_test_6256(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setJMenuBar(p0)

    def test_setContentPane_test_6257(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setContentPane(p0)

    def test_getLayeredPane_test_6258(self):
        instance = JFrameWrapper()
        instance.getLayeredPane()

    def test_setLayeredPane_test_6259(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setLayeredPane(p0)

    def test_getGlassPane_test_6260(self):
        instance = JFrameWrapper()
        instance.getGlassPane()

    def test_setGlassPane_test_6261(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setGlassPane(p0)

    def test_setDefaultCloseOperation_test_6262(self):
        p0 = 3
        instance = JFrameWrapper()
        instance.setDefaultCloseOperation(p0)

    def test_getDefaultCloseOperation_test_6263(self):
        instance = JFrameWrapper()
        instance.getDefaultCloseOperation()

    def test_setIconImage_test_6264(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setIconImage(p0)

    def test_setDefaultLookAndFeelDecorated_test_6265(self):
        p0 = True
        JFrameWrapper.setDefaultLookAndFeelDecorated(p0)

    def test_getGraphics_test_6266(self):
        instance = JFrameWrapper()
        instance.getGraphics()

    def test_getRootPane_test_6267(self):
        instance = JFrameWrapper()
        instance.getRootPane()

    def test_repaint_test_6268(self):
        p0, p1, p2, p3, p4 = 100, 0, 0, 10, 10
        instance = JFrameWrapper()
        instance.repaint(p0, p1, p2, p3, p4)

    def test_setTransferHandler_test_6269(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setTransferHandler(p0)

    def test_getTransferHandler_test_6270(self):
        instance = JFrameWrapper()
        instance.getTransferHandler()

    def test_getAccessibleContext_test_6271(self):
        instance = JFrameWrapper()
        instance.getAccessibleContext()

    def test_setLayout_test_6272(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.setLayout(p0)

    def test_remove_test_6273(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.remove(p0)

    def test_update_test_6274(self):
        p0 = MagicMock()
        instance = JFrameWrapper()
        instance.update(p0)


class JFrameWrapper:
    @staticmethod
    def isDefaultLookAndFeelDecorated():
        return MagicMock()

    @staticmethod
    def setDefaultLookAndFeelDecorated(decorated):
        return MagicMock()

    def __init__(self):
        self.content_pane = MagicMock()
        self.j_menu_bar = MagicMock()
        self.layered_pane = MagicMock()
        self.glass_pane = MagicMock()
        self.default_close_operation = MagicMock()
        self.icon_image = MagicMock()
        self.graphics = MagicMock()
        self.root_pane = MagicMock()
        self.transfer_handler = MagicMock()
        self.accessible_context = MagicMock()
        self.layout_manager = MagicMock()
        self.components = []

    def getContentPane(self):
        return self.content_pane

    def getJMenuBar(self):
        return self.j_menu_bar

    def setJMenuBar(self, menu_bar):
        self.j_menu_bar = menu_bar

    def setContentPane(self, content_pane):
        self.content_pane = content_pane

    def getLayeredPane(self):
        return self.layered_pane

    def setLayeredPane(self, layered_pane):
        self.layered_pane = layered_pane

    def getGlassPane(self):
        return self.glass_pane

    def setGlassPane(self, glass_pane):
        self.glass_pane = glass_pane

    def setDefaultCloseOperation(self, operation):
        self.default_close_operation = operation

    def getDefaultCloseOperation(self):
        return self.default_close_operation

    def setIconImage(self, image):
        self.icon_image = image

    def getGraphics(self):
        return self.graphics

    def getRootPane(self):
        return self.root_pane

    def repaint(self, tm, x, y, width, height):
        return MagicMock()

    def setTransferHandler(self, handler):
        self.transfer_handler = handler

    def getTransferHandler(self):
        return self.transfer_handler

    def getAccessibleContext(self):
        return self.accessible_context

    def setLayout(self, layout_manager):
        self.layout_manager = layout_manager

    def remove(self, component):
        if component in self.components:
            self.components.remove(component)

    def update(self, graphics):
        return MagicMock()


if __name__ == '__main__':
    unittest.main()