import unittest
from datetime import time, datetime, timezone, timedelta
from typing import Any

class TestJavaTimeOffsetTimeAutoTest(unittest.TestCase):
    def of_test_9651(self, p0: time, p1: timezone):
        OffsetTimeWrapper.of(p0, p1)
    
    def of_test_9652(self, p0: int, p1: int, p2: int, p3: int, p4: timezone):
        OffsetTimeWrapper.of(p0, p1, p2, p3, p4)
    
    def from_test_9653(self, p0: Any):
        OffsetTimeWrapper.from(p0)
    
    def parse_test_9654(self, p0: str):
        OffsetTimeWrapper.parse(p0)
    
    def parse_test_9655(self, p0: str, p1: Any):
        OffsetTimeWrapper.parse(p0, p1)
    
    def now_test_9656(self):
        OffsetTimeWrapper.now()
    
    def now_test_9657(self, p0: Any):
        OffsetTimeWrapper.now(p0)
    
    def now_test_9658(self, p0: Any):
        OffsetTimeWrapper.now(p0)
    
    def ofInstant_test_9659(self, p0: datetime, p1: Any):
        OffsetTimeWrapper.ofInstant(p0, p1)

class OffsetTimeWrapper:
    @staticmethod
    def of(time_obj: time, offset: timezone):
        return time_obj.replace(tzinfo=offset)
    
    @staticmethod
    def of(hour: int, minute: int, second: int, nano: int, offset: timezone):
        return time(hour, minute, second, nano, tzinfo=offset)
    
    @staticmethod
    def from(temporal: Any):
        if isinstance(temporal, time):
            return temporal
        elif isinstance(temporal, datetime):
            return temporal.timetz()
        raise ValueError(f"Cannot convert {type(temporal)} to OffsetTime")
    
    @staticmethod
    def parse(text: str, formatter: Any = None):
        if formatter is None:
            return datetime.strptime(text, "%H:%M:%S%z").timetz()
        return formatter.parse(text)
    
    @staticmethod
    def now(clock: Any = None):
        if clock is None:
            return datetime.now().timetz()
        return clock.now().timetz()
    
    @staticmethod
    def ofInstant(instant: datetime, zone: Any):
        return instant.astimezone(zone).timetz()

if __name__ == '__main__':
    unittest.main()