import unittest
import javax.management.QueryEval

class TestJavaxManagementQueryEval(unittest.TestCase):
    def test_getMBeanServer_test_10293(self):
        QueryEval.getMBeanServer()


class QueryEvalWrapper:
    @staticmethod
    def getMBeanServer():
        return javax.management.QueryEval.getMBeanServer()