import unittest
from unittest.mock import MagicMock
from java.awt import Graphics, Rectangle
from java.beans import PropertyChangeListener


class TestPropertyEditorSupport(unittest.TestCase):

    def test_firePropertyChange_test_10182(self):
        instance = PropertyEditorSupport()
        instance.firePropertyChange()

    def test_addPropertyChangeListener_test_10183(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=PropertyChangeListener)
        instance.addPropertyChangeListener(p0)

    def test_removePropertyChangeListener_test_10184(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=PropertyChangeListener)
        instance.removePropertyChangeListener(p0)

    def test_setSource_test_10185(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=object)
        instance.setSource(p0)

    def test_isPaintable_test_10186(self):
        instance = PropertyEditorSupport()
        instance.isPaintable()

    def test_paintValue_test_10187(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=Graphics)
        p1 = MagicMock(spec=Rectangle)
        instance.paintValue(p0, p1)

    def test_getJavaInitializationString_test_10188(self):
        instance = PropertyEditorSupport()
        instance.getJavaInitializationString()

    def test_getAsText_test_10189(self):
        instance = PropertyEditorSupport()
        instance.getAsText()

    def test_setAsText_test_10190(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=str)
        instance.setAsText(p0)

    def test_getTags_test_10191(self):
        instance = PropertyEditorSupport()
        instance.getTags()

    def test_getCustomEditor_test_10192(self):
        instance = PropertyEditorSupport()
        instance.getCustomEditor()

    def test_supportsCustomEditor_test_10193(self):
        instance = PropertyEditorSupport()
        instance.supportsCustomEditor()

    def test_getValue_test_10194(self):
        instance = PropertyEditorSupport()
        instance.getValue()

    def test_setValue_test_10195(self):
        instance = PropertyEditorSupport()
        p0 = MagicMock(spec=object)
        instance.setValue(p0)

    def test_getSource_test_10196(self):
        instance = PropertyEditorSupport()
        instance.getSource()


class PropertyEditorSupport:
    def __init__(self):
        self.source = None
        self.value = None
        self.listeners = []

    def firePropertyChange(self):
        pass

    def addPropertyChangeListener(self, listener):
        self.listeners.append(listener)

    def removePropertyChangeListener(self, listener):
        if listener in self.listeners:
            self.listeners.remove(listener)

    def setSource(self, source):
        self.source = source

    def isPaintable(self):
        return False

    def paintValue(self, gfx, box):
        pass

    def getJavaInitializationString(self):
        return ""

    def getAsText(self):
        return str(self.value) if self.value is not None else ""

    def setAsText(self, text):
        self.value = text

    def getTags(self):
        return None

    def getCustomEditor(self):
        return None

    def supportsCustomEditor(self):
        return False

    def getValue(self):
        return self.value

    def setValue(self, value):
        self.value = value

    def getSource(self):
        return self.source


if __name__ == '__main__':
    unittest.main()