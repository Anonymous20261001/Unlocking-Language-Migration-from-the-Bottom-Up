import unittest
from typing import List


class TestRoleUnresolved(unittest.TestCase):
    def setRoleName_test_10670(self, p0: str, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.setRoleName(p0)

    def setRoleValue_test_10671(self, p0: List, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.setRoleValue(p0)

    def setProblemType_test_10672(self, p0: int, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.setProblemType(p0)

    def getProblemType_test_10673(self, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.getProblemType()

    def getRoleName_test_10674(self, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.getRoleName()

    def getRoleValue_test_10675(self, c0: str, c1: List, c2: int):
        instance = RoleUnresolved(c0, c1, c2)
        instance.getRoleValue()


class RoleUnresolved:
    def __init__(self, role_name: str, role_value: List, problem_type: int):
        self._role_name = role_name
        self._role_value = role_value
        self._problem_type = problem_type

    def setRoleName(self, role_name: str):
        self._role_name = role_name

    def setRoleValue(self, role_value: List):
        self._role_value = role_value

    def setProblemType(self, problem_type: int):
        self._problem_type = problem_type

    def getProblemType(self) -> int:
        return self._problem_type

    def getRoleName(self) -> str:
        return self._role_name

    def getRoleValue(self) -> List:
        return self._role_value


if __name__ == '__main__':
    unittest.main()