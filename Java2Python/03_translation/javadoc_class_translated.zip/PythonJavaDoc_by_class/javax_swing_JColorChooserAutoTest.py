import unittest
from unittest.mock import MagicMock
from typing import List, Optional


class TestJavaxSwingJColorChooserAutoTest(unittest.TestCase):
    def test_getUIClassID_test_6023(self):
        instance = JColorChooser()
        instance.getUIClassID()

    def test_updateUI_test_6024(self):
        instance = JColorChooser()
        instance.updateUI()

    def test_getUI_test_6025(self):
        instance = JColorChooser()
        instance.getUI()

    def test_setUI_test_6026(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.setUI(p0)

    def test_getAccessibleContext_test_6027(self):
        instance = JColorChooser()
        instance.getAccessibleContext()

    def test_getColor_test_6028(self):
        instance = JColorChooser()
        instance.getColor()

    def test_getSelectionModel_test_6029(self):
        instance = JColorChooser()
        instance.getSelectionModel()

    def test_showDialog_test_6030(self):
        p0 = MagicMock()
        p1 = "test"
        p2 = MagicMock()
        JColorChooser.showDialog(p0, p1, p2)

    def test_showDialog_test_6031(self):
        p0 = MagicMock()
        p1 = "test"
        p2 = MagicMock()
        p3 = True
        JColorChooser.showDialog(p0, p1, p2, p3)

    def test_getChooserPanels_test_6032(self):
        instance = JColorChooser()
        instance.getChooserPanels()

    def test_createDialog_test_6033(self):
        p0 = MagicMock()
        p1 = "test"
        p2 = True
        p3 = MagicMock()
        p4 = MagicMock()
        p5 = MagicMock()
        JColorChooser.createDialog(p0, p1, p2, p3, p4, p5)

    def test_getPreviewPanel_test_6034(self):
        instance = JColorChooser()
        instance.getPreviewPanel()

    def test_setChooserPanels_test_6035(self):
        p0 = [MagicMock()]
        instance = JColorChooser()
        instance.setChooserPanels(p0)

    def test_setDragEnabled_test_6036(self):
        p0 = True
        instance = JColorChooser()
        instance.setDragEnabled(p0)

    def test_getDragEnabled_test_6037(self):
        instance = JColorChooser()
        instance.getDragEnabled()

    def test_setPreviewPanel_test_6038(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.setPreviewPanel(p0)

    def test_addChooserPanel_test_6039(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.addChooserPanel(p0)

    def test_removeChooserPanel_test_6040(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.removeChooserPanel(p0)

    def test_setSelectionModel_test_6041(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.setSelectionModel(p0)

    def test_setColor_test_6042(self):
        p0 = 255
        p1 = 0
        p2 = 0
        instance = JColorChooser()
        instance.setColor(p0, p1, p2)

    def test_setColor_test_6043(self):
        p0 = 255
        instance = JColorChooser()
        instance.setColor(p0)

    def test_setColor_test_6044(self):
        p0 = MagicMock()
        instance = JColorChooser()
        instance.setColor(p0)


class Color:
    def __init__(self, r=0, g=0, b=0):
        self.r = r
        self.g = g
        self.b = b


class Component:
    pass


class JComponent(Component):
    pass


class AbstractColorChooserPanel:
    pass


class ColorSelectionModel:
    pass


class ColorChooserUI:
    pass


class ActionListener:
    pass


class JColorChooser(JComponent):
    @staticmethod
    def showDialog(component: Component, title: str, initial_color: Color, preview: bool = False):
        pass

    @staticmethod
    def createDialog(component: Component, title: str, modal: bool, chooser: 'JColorChooser',
                     ok_listener: ActionListener, cancel_listener: ActionListener):
        pass

    def __init__(self):
        super().__init__()
        self._ui = None
        self._color = Color()
        self._selection_model = ColorSelectionModel()
        self._chooser_panels: List[AbstractColorChooserPanel] = []
        self._drag_enabled = False
        self._preview_panel = JComponent()

    def getUIClassID(self) -> str:
        return "ColorChooserUI"

    def updateUI(self):
        pass

    def getUI(self) -> Optional[ColorChooserUI]:
        return self._ui

    def setUI(self, ui: ColorChooserUI):
        self._ui = ui

    def getAccessibleContext(self):
        return None

    def getColor(self) -> Color:
        return self._color

    def getSelectionModel(self) -> ColorSelectionModel:
        return self._selection_model

    def getChooserPanels(self) -> List[AbstractColorChooserPanel]:
        return self._chooser_panels

    def getPreviewPanel(self) -> JComponent:
        return self._preview_panel

    def setChooserPanels(self, panels: List[AbstractColorChooserPanel]):
        self._chooser_panels = panels

    def setDragEnabled(self, enabled: bool):
        self._drag_enabled = enabled

    def getDragEnabled(self) -> bool:
        return self._drag_enabled

    def setPreviewPanel(self, panel: JComponent):
        self._preview_panel = panel

    def addChooserPanel(self, panel: AbstractColorChooserPanel):
        self._chooser_panels.append(panel)

    def removeChooserPanel(self, panel: AbstractColorChooserPanel):
        if panel in self._chooser_panels:
            self._chooser_panels.remove(panel)

    def setSelectionModel(self, model: ColorSelectionModel):
        self._selection_model = model

    def setColor(self, *args):
        if len(args) == 3:
            r, g, b = args
            self._color = Color(r, g, b)
        elif len(args) == 1:
            if isinstance(args[0], int):
                self._color = Color(args[0], args[0], args[0])
            else:
                self._color = args[0]


if __name__ == '__main__':
    unittest.main()