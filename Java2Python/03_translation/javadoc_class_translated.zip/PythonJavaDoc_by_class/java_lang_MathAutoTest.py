import unittest
import math
import random


class TestMathFunctions(unittest.TestCase):
    def test_abs_test_8296(self):
        m = MathWrapper()
        m.abs_test_8296(1.5)
        m.abs_test_8296(-2.5)
        m.abs_test_8296(0.0)

    def test_abs_test_8297(self):
        m = MathWrapper()
        m.abs_test_8297(10)
        m.abs_test_8297(-20)
        m.abs_test_8297(0)

    def test_abs_test_8298(self):
        m = MathWrapper()
        m.abs_test_8298(5)
        m.abs_test_8298(-10)
        m.abs_test_8298(0)

    def test_abs_test_8299(self):
        m = MathWrapper()
        m.abs_test_8299(1.5)
        m.abs_test_8299(-2.5)
        m.abs_test_8299(0.0)

    def test_sin_test_8300(self):
        m = MathWrapper()
        m.sin_test_8300(0.5)
        m.sin_test_8300(-1.0)
        m.sin_test_8300(2.0)

    def test_cos_test_8301(self):
        m = MathWrapper()
        m.cos_test_8301(0.5)
        m.cos_test_8301(-1.0)
        m.cos_test_8301(2.0)

    def test_tan_test_8302(self):
        m = MathWrapper()
        m.tan_test_8302(0.5)
        m.tan_test_8302(-1.0)
        m.tan_test_8302(2.0)

    def test_atan2_test_8303(self):
        m = MathWrapper()
        m.atan2_test_8303(1.0, 2.0)
        m.atan2_test_8303(-1.0, 0.5)
        m.atan2_test_8303(0.0, 1.0)

    def test_sqrt_test_8304(self):
        m = MathWrapper()
        m.sqrt_test_8304(4.0)
        m.sqrt_test_8304(0.0)
        m.sqrt_test_8304(9.0)

    def test_log_test_8305(self):
        m = MathWrapper()
        m.log_test_8305(1.0)
        m.log_test_8305(2.0)
        m.log_test_8305(10.0)

    def test_log10_test_8306(self):
        m = MathWrapper()
        m.log10_test_8306(1.0)
        m.log10_test_8306(100.0)
        m.log10_test_8306(1000.0)

    def test_pow_test_8307(self):
        m = MathWrapper()
        m.pow_test_8307(2.0, 3.0)
        m.pow_test_8307(4.0, 0.5)
        m.pow_test_8307(10.0, 2.0)

    def test_exp_test_8308(self):
        m = MathWrapper()
        m.exp_test_8308(0.0)
        m.exp_test_8308(1.0)
        m.exp_test_8308(2.0)

    def test_min_test_8309(self):
        m = MathWrapper()
        m.min_test_8309(1, 2)
        m.min_test_8309(-1, 1)
        m.min_test_8309(0, 0)

    def test_min_test_8310(self):
        m = MathWrapper()
        m.min_test_8310(1, 2)
        m.min_test_8310(-1, 1)
        m.min_test_8310(0, 0)

    def test_min_test_8311(self):
        m = MathWrapper()
        m.min_test_8311(1.5, 2.5)
        m.min_test_8311(-1.0, 1.0)
        m.min_test_8311(0.0, 0.0)

    def test_min_test_8312(self):
        m = MathWrapper()
        m.min_test_8312(1.5, 2.5)
        m.min_test_8312(-1.0, 1.0)
        m.min_test_8312(0.0, 0.0)

    def test_max_test_8313(self):
        m = MathWrapper()
        m.max_test_8313(1, 2)
        m.max_test_8313(-1, 1)
        m.max_test_8313(0, 0)

    def test_max_test_8314(self):
        m = MathWrapper()
        m.max_test_8314(1, 2)
        m.max_test_8314(-1, 1)
        m.max_test_8314(0, 0)

    def test_max_test_8315(self):
        m = MathWrapper()
        m.max_test_8315(1.5, 2.5)
        m.max_test_8315(-1.0, 1.0)
        m.max_test_8315(0.0, 0.0)

    def test_max_test_8316(self):
        m = MathWrapper()
        m.max_test_8316(1.5, 2.5)
        m.max_test_8316(-1.0, 1.0)
        m.max_test_8316(0.0, 0.0)

    def test_floor_test_8317(self):
        m = MathWrapper()
        m.floor_test_8317(1.7)
        m.floor_test_8317(-1.7)
        m.floor_test_8317(0.0)

    def test_ceil_test_8318(self):
        m = MathWrapper()
        m.ceil_test_8318(1.7)
        m.ceil_test_8318(-1.7)
        m.ceil_test_8318(0.0)

    def test_rint_test_8319(self):
        m = MathWrapper()
        m.rint_test_8319(1.7)
        m.rint_test_8319(-1.7)
        m.rint_test_8319(0.0)

    def test_round_test_8320(self):
        m = MathWrapper()
        m.round_test_8320(1.7)
        m.round_test_8320(-1.7)
        m.round_test_8320(0.0)

    def test_round_test_8321(self):
        m = MathWrapper()
        m.round_test_8321(1.7)
        m.round_test_8321(-1.7)
        m.round_test_8321(0.0)

    def test_tanh_test_8322(self):
        m = MathWrapper()
        m.tanh_test_8322(0.5)
        m.tanh_test_8322(-1.0)
        m.tanh_test_8322(2.0)

    def test_cbrt_test_8323(self):
        m = MathWrapper()
        m.cbrt_test_8323(8.0)
        m.cbrt_test_8323(-27.0)
        m.cbrt_test_8323(0.0)

    def test_addExact_test_8324(self):
        m = MathWrapper()
        m.addExact_test_8324(1, 2)
        m.addExact_test_8324(-1, 1)
        m.addExact_test_8324(0, 0)

    def test_addExact_test_8325(self):
        m = MathWrapper()
        m.addExact_test_8325(1, 2)
        m.addExact_test_8325(-1, 1)
        m.addExact_test_8325(0, 0)

    def test_decrementExact_test_8326(self):
        m = MathWrapper()
        m.decrementExact_test_8326(1)
        m.decrementExact_test_8326(0)
        m.decrementExact_test_8326(-1)

    def test_decrementExact_test_8327(self):
        m = MathWrapper()
        m.decrementExact_test_8327(1)
        m.decrementExact_test_8327(0)
        m.decrementExact_test_8327(-1)

    def test_incrementExact_test_8328(self):
        m = MathWrapper()
        m.incrementExact_test_8328(1)
        m.incrementExact_test_8328(0)
        m.incrementExact_test_8328(-1)

    def test_incrementExact_test_8329(self):
        m = MathWrapper()
        m.incrementExact_test_8329(1)
        m.incrementExact_test_8329(0)
        m.incrementExact_test_8329(-1)

    def test_multiplyExact_test_8330(self):
        m = MathWrapper()
        m.multiplyExact_test_8330(2, 3)
        m.multiplyExact_test_8330(-2, 3)
        m.multiplyExact_test_8330(0, 5)

    def test_multiplyExact_test_8331(self):
        m = MathWrapper()
        m.multiplyExact_test_8331(2, 3)
        m.multiplyExact_test_8331(-2, 3)
        m.multiplyExact_test_8331(0, 5)

    def test_multiplyExact_test_8332(self):
        m = MathWrapper()
        m.multiplyExact_test_8332(2, 3)
        m.multiplyExact_test_8332(-2, 3)
        m.multiplyExact_test_8332(0, 5)

    def test_multiplyHigh_test_8333(self):
        m = MathWrapper()
        m.multiplyHigh_test_8333(2, 3)
        m.multiplyHigh_test_8333(-2, 3)
        m.multiplyHigh_test_8333(0, 5)

    def test_unsignedMultiplyHigh_test_8334(self):
        m = MathWrapper()
        m.unsignedMultiplyHigh_test_8334(2, 3)
        m.unsignedMultiplyHigh_test_8334(-2, 3)
        m.unsignedMultiplyHigh_test_8334(0, 5)

    def test_negateExact_test_8335(self):
        m = MathWrapper()
        m.negateExact_test_8335(1)
        m.negateExact_test_8335(-1)
        m.negateExact_test_8335(0)

    def test_negateExact_test_8336(self):
        m = MathWrapper()
        m.negateExact_test_8336(1)
        m.negateExact_test_8336(-1)
        m.negateExact_test_8336(0)

    def test_subtractExact_test_8337(self):
        m = MathWrapper()
        m.subtractExact_test_8337(5, 3)
        m.subtractExact_test_8337(-5, 3)
        m.subtractExact_test_8337(0, 0)

    def test_subtractExact_test_8338(self):
        m = MathWrapper()
        m.subtractExact_test_8338(5, 3)
        m.subtractExact_test_8338(-5, 3)
        m.subtractExact_test_8338(0, 0)

    def test_fma_test_8339(self):
        m = MathWrapper()
        m.fma_test_8339(1.0, 2.0, 3.0)
        m.fma_test_8339(-1.0, 2.0, 3.0)
        m.fma_test_8339(0.0, 2.0, 3.0)

    def test_fma_test_8340(self):
        m = MathWrapper()
        m.fma_test_8340(1.0, 2.0, 3.0)
        m.fma_test_8340(-1.0, 2.0, 3.0)
        m.fma_test_8340(0.0, 2.0, 3.0)

    def test_copySign_test_8341(self):
        m = MathWrapper()
        m.copySign_test_8341(1.0, 2.0)
        m.copySign_test_8341(-1.0, 2.0)
        m.copySign_test_8341(0.0, -2.0)

    def test_copySign_test_8342(self):
        m = MathWrapper()
        m.copySign_test_8342(1.0, 2.0)
        m.copySign_test_8342(-1.0, 2.0)
        m.copySign_test_8342(0.0, -2.0)

    def test_signum_test_8343(self):
        m = MathWrapper()
        m.signum_test_8343(1.0)
        m.signum_test_8343(-1.0)
        m.signum_test_8343(0.0)

    def test_signum_test_8344(self):
        m = MathWrapper()
        m.signum_test_8344(1.0)
        m.signum_test_8344(-1.0)
        m.signum_test_8344(0.0)

    def test_clamp_test_8345(self):
        m = MathWrapper()
        m.clamp_test_8345(1.0, 0.0, 2.0)
        m.clamp_test_8345(-1.0, 0.0, 2.0)
        m.clamp_test_8345(3.0, 0.0, 2.0)

    def test_clamp_test_8346(self):
        m = MathWrapper()
        m.clamp_test_8346(1, 0, 2)
        m.clamp_test_8346(-1, 0, 2)
        m.clamp_test_8346(3, 0, 2)

    def test_clamp_test_8347(self):
        m = MathWrapper()
        m.clamp_test_8347(1.0, 0.0, 2.0)
        m.clamp_test_8347(-1.0, 0.0, 2.0)
        m.clamp_test_8347(3.0, 0.0, 2.0)

    def test_clamp_test_8348(self):
        m = MathWrapper()
        m.clamp_test_8348(1, 0, 2)
        m.clamp_test_8348(-1, 0, 2)
        m.clamp_test_8348(3, 0, 2)

    def test_scalb_test_8349(self):
        m = MathWrapper()
        m.scalb_test_8349(1.0, 2)
        m.scalb_test_8349(-1.0, 3)
        m.scalb_test_8349(0.0, 1)

    def test_scalb_test_8350(self):
        m = MathWrapper()
        m.scalb_test_8350(1.0, 2)
        m.scalb_test_8350(-1.0, 3)
        m.scalb_test_8350(0.0, 1)

    def test_getExponent_test_8351(self):
        m = MathWrapper()
        m.getExponent_test_8351(1.0)
        m.getExponent_test_8351(2.0)
        m.getExponent_test_8351(0.5)

    def test_getExponent_test_8352(self):
        m = MathWrapper()
        m.getExponent_test_8352(1.0)
        m.getExponent_test_8352(2.0)
        m.getExponent_test_8352(0.5)

    def test_floorMod_test_8353(self):
        m = MathWrapper()
        m.floorMod_test_8353(10, 3)
        m.floorMod_test_8353(-10, 3)
        m.floorMod_test_8353(10, -3)

    def test_floorMod_test_8354(self):
        m = MathWrapper()
        m.floorMod_test_8354(10, 3)
        m.floorMod_test_8354(-10, 3)
        m.floorMod_test_8354(10, -3)

    def test_floorMod_test_8355(self):
        m = MathWrapper()
        m.floorMod_test_8355(10, 3)
        m.floorMod_test_8355(-10, 3)
        m.floorMod_test_8355(10, -3)

    def test_asin_test_8356(self):
        m = MathWrapper()
        m.asin_test_8356(0.5)
        m.asin_test_8356(-0.5)
        m.asin_test_8356(1.0)

    def test_acos_test_8357(self):
        m = MathWrapper()
        m.acos_test_8357(0.5)
        m.acos_test_8357(-0.5)
        m.acos_test_8357(1.0)

    def test_atan_test_8358(self):
        m = MathWrapper()
        m.atan_test_8358(0.5)
        m.atan_test_8358(-0.5)
        m.atan_test_8358(1.0)

    def test_IEEEremainder_test_8359(self):
        m = MathWrapper()
        m.IEEEremainder_test_8359(5.0, 2.0)
        m.IEEEremainder_test_8359(-5.0, 2.0)
        m.IEEEremainder_test_8359(5.0, -2.0)

    def test_floorDiv_test_8360(self):
        m = MathWrapper()
        m.floorDiv_test_8360(10, 3)
        m.floorDiv_test_8360(-10, 3)
        m.floorDiv_test_8360(10, -3)

    def test_floorDiv_test_8361(self):
        m = MathWrapper()
        m.floorDiv_test_8361(10, 3)
        m.floorDiv_test_8361(-10, 3)
        m.floorDiv_test_8361(10, -3)

    def test_floorDiv_test_8362(self):
        m = MathWrapper()
        m.floorDiv_test_8362(10, 3)
        m.floorDiv_test_8362(-10, 3)
        m.floorDiv_test_8362(10, -3)

    def test_ceilDiv_test_8363(self):
        m = MathWrapper()
        m.ceilDiv_test_8363(10, 3)
        m.ceilDiv_test_8363(-10, 3)
        m.ceilDiv_test_8363(10, -3)

    def test_ceilDiv_test_8364(self):
        m = MathWrapper()
        m.ceilDiv_test_8364(10, 3)
        m.ceilDiv_test_8364(-10, 3)
        m.ceilDiv_test_8364(10, -3)

    def test_ceilDiv_test_8365(self):
        m = MathWrapper()
        m.ceilDiv_test_8365(10, 3)
        m.ceilDiv_test_8365(-10, 3)
        m.ceilDiv_test_8365(10, -3)

    def test_ceilMod_test_8366(self):
        m = MathWrapper()
        m.ceilMod_test_8366(10, 3)
        m.ceilMod_test_8366(-10, 3)
        m.ceilMod_test_8366(10, -3)

    def test_ceilMod_test_8367(self):
        m = MathWrapper()
        m.ceilMod_test_8367(10, 3)
        m.ceilMod_test_8367(-10, 3)
        m.ceilMod_test_8367(10, -3)

    def test_ceilMod_test_8368(self):
        m = MathWrapper()
        m.ceilMod_test_8368(10, 3)
        m.ceilMod_test_8368(-10, 3)
        m.ceilMod_test_8368(10, -3)

    def test_sinh_test_8369(self):
        m = MathWrapper()
        m.sinh_test_8369(0.5)
        m.sinh_test_8369(-0.5)
        m.sinh_test_8369(1.0)

    def test_cosh_test_8370(self):
        m = MathWrapper()
        m.cosh_test_8370(0.5)
        m.cosh_test_8370(-0.5)
        m.cosh_test_8370(1.0)

    def test_hypot_test_8371(self):
        m = MathWrapper()
        m.hypot_test_8371(3.0, 4.0)
        m.hypot_test_8371(-3.0, 4.0)
        m.hypot_test_8371(0.0, 0.0)

    def test_expm1_test_8372(self):
        m = MathWrapper()
        m.expm1_test_8372(0.0)
        m.expm1_test_8372(1.0)
        m.expm1_test_8372(-1.0)

    def test_log1p_test_8373(self):
        m = MathWrapper()
        m.log1p_test_8373(0.0)
        m.log1p_test_8373(1.0)
        m.log1p_test_8373(-0.5)

    def test_unsignedMultiplyExact_test_8374(self):
        m = MathWrapper()
        m.unsignedMultiplyExact_test_8374(2, 3)
        m.unsignedMultiplyExact_test_8374(-2, 3)
        m.unsignedMultiplyExact_test_8374(0, 5)

    def test_unsignedMultiplyExact_test_8375(self):
        m = MathWrapper()
        m.unsignedMultiplyExact_test_8375(2, 3)
        m.unsignedMultiplyExact_test_8375(-2, 3)
        m.unsignedMultiplyExact_test_8375(0, 5)

    def test_unsignedMultiplyExact_test_8376(self):
        m = MathWrapper()
        m.unsignedMultiplyExact_test_8376(2, 3)
        m.unsignedMultiplyExact_test_8376(-2, 3)
        m.unsignedMultiplyExact_test_8376(0, 5)

    def test_toRadians_test_8377(self):
        m = MathWrapper()
        m.toRadians_test_8377(180.0)
        m.toRadians_test_8377(90.0)
        m.toRadians_test_8377(0.0)

    def test_toDegrees_test_8378(self):
        m = MathWrapper()
        m.toDegrees_test_8378(3.141592653589793)
        m.toDegrees_test_8378(1.5707963267948966)
        m.toDegrees_test_8378(0.0)

    def test_random_test_8379(self):
        m = MathWrapper()
        m.random_test_8379()
        m.random_test_8379()
        m.random_test_8379()

    def test_divideExact_test_8380(self):
        m = MathWrapper()
        m.divideExact_test_8380(10, 2)
        m.divideExact_test_8380(-10, 2)
        m.divideExact_test_8380(10, -2)

    def test_divideExact_test_8381(self):
        m = MathWrapper()
        m.divideExact_test_8381(10, 2)
        m.divideExact_test_8381(-10, 2)
        m.divideExact_test_8381(10, -2)

    def test_floorDivExact_test_8382(self):
        m = MathWrapper()
        m.floorDivExact_test_8382(10, 3)
        m.floorDivExact_test_8382(-10, 3)
        m.floorDivExact_test_8382(10, -3)

    def test_floorDivExact_test_8383(self):
        m = MathWrapper()
        m.floorDivExact_test_8383(10, 3)
        m.floorDivExact_test_8383(-10, 3)
        m.floorDivExact_test_8383(10, -3)

    def test_ceilDivExact_test_8384(self):
        m = MathWrapper()
        m.ceilDivExact_test_8384(10, 3)
        m.ceilDivExact_test_8384(-10, 3)
        m.ceilDivExact_test_8384(10, -3)

    def test_ceilDivExact_test_8385(self):
        m = MathWrapper()
        m.ceilDivExact_test_8385(10, 3)
        m.ceilDivExact_test_8385(-10, 3)
        m.ceilDivExact_test_8385(10, -3)

    def test_toIntExact_test_8386(self):
        m = MathWrapper()
        m.toIntExact_test_8386(10)
        m.toIntExact_test_8386(-10)
        m.toIntExact_test_8386(0)

    def test_multiplyFull_test_8387(self):
        m = MathWrapper()
        m.multiplyFull_test_8387(2, 3)
        m.multiplyFull_test_8387(-2, 3)
        m.multiplyFull_test_8387(0, 5)

    def test_absExact_test_8388(self):
        m = MathWrapper()
        m.absExact_test_8388(10)
        m.absExact_test_8388(-10)
        m.absExact_test_8388(0)

    def test_absExact_test_8389(self):
        m = MathWrapper()
        m.absExact_test_8389(10)
        m.absExact_test_8389(-10)
        m.absExact_test_8389(0)

    def test_ulp_test_8390(self):
        m = MathWrapper()
        m.ulp_test_8390(1.0)
        m.ulp_test_8390(-1.0)
        m.ulp_test_8390(0.0)

    def test_ulp_test_8391(self):
        m = MathWrapper()
        m.ulp_test_8391(1.0)
        m.ulp_test_8391(-1.0)
        m.ulp_test_8391(0.0)

    def test_nextAfter_test_8392(self):
        m = MathWrapper()
        m.nextAfter_test_8392(1.0, 2.0)
        m.nextAfter_test_8392(-1.0, 2.0)
        m.nextAfter_test_8392(0.0, -1.0)

    def test_nextAfter_test_8393(self):
        m = MathWrapper()
        m.nextAfter_test_8393(1.0, 2.0)
        m.nextAfter_test_8393(-1.0, 2.0)
        m.nextAfter_test_8393(0.0, -1.0)

    def test_nextUp_test_8394(self):
        m = MathWrapper()
        m.nextUp_test_8394(1.0)
        m.nextUp_test_8394(-1.0)
        m.nextUp_test_8394(0.0)

    def test_nextUp_test_8395(self):
        m = MathWrapper()
        m.nextUp_test_8395(1.0)
        m.nextUp_test_8395(-1.0)
        m.nextUp_test_8395(0.0)

    def test_nextDown_test_8396(self):
        m = MathWrapper()
        m.nextDown_test_8396(1.0)
        m.nextDown_test_8396(-1.0)
        m.nextDown_test_8396(0.0)

    def test_nextDown_test_8397(self):
        m = MathWrapper()
        m.nextDown_test_8397(1.0)
        m.nextDown_test_8397(-1.0)
        m.nextDown_test_8397(0.0)

    def test_powExact_test_8398(self):
        m = MathWrapper()
        m.powExact_test_8398(2, 3)
        m.powExact_test_8398(-2, 3)
        m.powExact_test_8398(0, 5)

    def test_powExact_test_8399(self):
        m = MathWrapper()
        m.powExact_test_8399(2, 3)
        m.powExact_test_8399(-2, 3)
        m.powExact_test_8399(0, 5)

    def test_unsignedPowExact_test_8400(self):
        m = MathWrapper()
        m.unsignedPowExact_test_8400(2, 3)
        m.unsignedPowExact_test_8400(-2, 3)
        m.unsignedPowExact_test_8400(0, 5)

    def test_unsignedPowExact_test_8401(self):
        m = MathWrapper()
        m.unsignedPowExact_test_8401(2, 3)
        m.unsignedPowExact_test_8401(-2, 3)
        m.unsignedPowExact_test_8401(0, 5)


class MathWrapper:
    def abs_test_8296(self, p0):
        return abs(p0)

    def abs_test_8297(self, p0):
        return abs(p0)

    def abs_test_8298(self, p0):
        return abs(p0)

    def abs_test_8299(self, p0):
        return abs(p0)

    def sin_test_8300(self, p0):
        return math.sin(p0)

    def cos_test_8301(self, p0):
        return math.cos(p0)

    def tan_test_8302(self, p0):
        return math.tan(p0)

    def atan2_test_8303(self, p0, p1):
        return math.atan2(p0, p1)

    def sqrt_test_8304(self, p0):
        return math.sqrt(p0)

    def log_test_8305(self, p0):
        return math.log(p0)

    def log10_test_8306(self, p0):
        return math.log10(p0)

    def pow_test_8307(self, p0, p1):
        return math.pow(p0, p1)

    def exp_test_8308(self, p0):
        return math.exp(p0)

    def min_test_8309(self, p0, p1):
        return min(p0, p1)

    def min_test_8310(self, p0, p1):
        return min(p0, p1)

    def min_test_8311(self, p0, p1):
        return min(p0, p1)

    def min_test_8312(self, p0, p1):
        return min(p0, p1)

    def max_test_8313(self, p0, p1):
        return max(p0, p1)

    def max_test_8314(self, p0, p1):
        return max(p0, p1)

    def max_test_8315(self, p0, p1):
        return max(p0, p1)

    def max_test_8316(self, p0, p1):
        return max(p0, p1)

    def floor_test_8317(self, p0):
        return math.floor(p0)

    def ceil_test_8318(self, p0):
        return math.ceil(p0)

    def rint_test_8319(self, p0):
        return round(p0)

    def round_test_8320(self, p0):
        return round(p0)

    def round_test_8321(self, p0):
        return round(p0)

    def tanh_test_8322(self, p0):
        return math.tanh(p0)

    def cbrt_test_8323(self, p0):
        return p0 ** (1/3) if p0 >= 0 else -((-p0) ** (1/3))

    def addExact_test_8324(self, p0, p1):
        return p0 + p1

    def addExact_test_8325(self, p0, p1):
        return p0 + p1

    def decrementExact_test_8326(self, p0):
        return p0 - 1

    def decrementExact_test_8327(self, p0):
        return p0 - 1

    def incrementExact_test_8328(self, p0):
        return p0 + 1

    def incrementExact_test_8329(self, p0):
        return p0 + 1

    def multiplyExact_test_8330(self, p0, p1):
        return p0 * p1

    def multiplyExact_test_8331(self, p0, p1):
        return p0 * p1

    def multiplyExact_test_8332(self, p0, p1):
        return p0 * p1

    def multiplyHigh_test_8333(self, p0, p1):
        return (p0 * p1) >> 64

    def unsignedMultiplyHigh_test_8334(self, p0, p1):
        return (p0 * p1) >> 64

    def negateExact_test_8335(self, p0):
        return -p0

    def negateExact_test_8336(self, p0):
        return -p0

    def subtractExact_test_8337(self, p0, p1):
        return p0 - p1

    def subtractExact_test_8338(self, p0, p1):
        return p0 - p1

    def fma_test_8339(self, p0, p1, p2):
        return p0 * p1 + p2

    def fma_test_8340(self, p0, p1, p2):
        return p0 * p1 + p2

    def copySign_test_8341(self, p0, p1):
        return abs(p0) if p1 >= 0 else -abs(p0)

    def copySign_test_8342(self, p0, p1):
        return abs(p0) if p1 >= 0 else -abs(p0)

    def signum_test_8343(self, p0):
        return 1 if p0 > 0 else -1 if p0 < 0 else 0

    def signum_test_8344(self, p0):
        return 1 if p0 > 0 else -1 if p0 < 0 else 0

    def clamp_test_8345(self, p0, p1, p2):
        return max(p1, min(p2, p0))

    def clamp_test_8346(self, p0, p1, p2):
        return max(p1, min(p2, p0))

    def clamp_test_8347(self, p0, p1, p2):
        return max(p1, min(p2, p0))

    def clamp_test_8348(self, p0, p1, p2):
        return max(p1, min(p2, p0))

    def scalb_test_8349(self, p0, p1):
        return p0 * (2 ** p1)

    def scalb_test_8350(self, p0, p1):
        return p0 * (2 ** p1)

    def getExponent_test_8351(self, p0):
        return math.frexp(p0)[1] - 1

    def getExponent_test_8352(self, p0):
        return math.frexp(p0)[1] - 1

    def floorMod_test_8353(self, p0, p1):
        return p0 % p1

    def floorMod_test_8354(self, p0, p1):
        return p0 % p1

    def floorMod_test_8355(self, p0, p1):
        return p0 % p1

    def asin_test_8356(self, p0):
        return math.asin(p0)

    def acos_test_8357(self, p0):
        return math.acos(p0)

    def atan_test_8358(self, p0):
        return math.atan(p0)

    def IEEEremainder_test_8359(self, p0, p1):
        return math.fmod