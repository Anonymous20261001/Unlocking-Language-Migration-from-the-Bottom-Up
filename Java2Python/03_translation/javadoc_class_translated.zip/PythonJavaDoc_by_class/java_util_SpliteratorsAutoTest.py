import unittest
from typing import Iterator, Collection, List, Any
from abc import ABC, abstractmethod


class Spliterator(ABC):
    """Base class for spliterators"""
    
    @abstractmethod
    def characteristics(self) -> int:
        pass
    
    @abstractmethod
    def estimate_size(self) -> int:
        pass
    
    @abstractmethod
    def try_advance(self, consumer) -> bool:
        pass
    
    @abstractmethod
    def try_split(self):
        pass


class SpliteratorOfDouble(Spliterator):
    """Spliterator for double values"""
    pass


class SpliteratorOfInt(Spliterator):
    """Spliterator for int values"""
    pass


class SpliteratorOfLong(Spliterator):
    """Spliterator for long values"""
    pass


class PrimitiveIteratorOfInt(Iterator):
    """Iterator for primitive int values"""
    pass


class PrimitiveIteratorOfLong(Iterator):
    """Iterator for primitive long values"""
    pass


class PrimitiveIteratorOfDouble(Iterator):
    """Iterator for primitive double values"""
    pass


class Spliterators:
    """Static utility class for creating spliterators"""
    
    @staticmethod
    def iterator(spliterator):
        """Returns an iterator from a spliterator"""
        return iter(spliterator)
    
    @staticmethod
    def spliteratorUnknownSize(iterator, characteristics):
        """Creates a spliterator with unknown size"""
        return Spliterator()
    
    @staticmethod
    def spliterator(source, *args):
        """Creates a spliterator from various sources"""
        return Spliterator()
    
    @staticmethod
    def emptySpliterator():
        """Returns an empty spliterator"""
        return Spliterator()
    
    @staticmethod
    def emptyIntSpliterator():
        """Returns an empty int spliterator"""
        return SpliteratorOfInt()
    
    @staticmethod
    def emptyLongSpliterator():
        """Returns an empty long spliterator"""
        return SpliteratorOfLong()
    
    @staticmethod
    def emptyDoubleSpliterator():
        """Returns an empty double spliterator"""
        return SpliteratorOfDouble()


class TestJavaUtilSpliterators(unittest.TestCase):
    
    def test_iterator_test_11314(self):
        p0 = SpliteratorOfDouble()
        result = Spliterators.iterator(p0)
        self.assertIsNotNone(result)
    
    def test_iterator_test_11315(self):
        p0 = Spliterator()
        result = Spliterators.iterator(p0)
        self.assertIsNotNone(result)
    
    def test_iterator_test_11316(self):
        p0 = SpliteratorOfInt()
        result = Spliterators.iterator(p0)
        self.assertIsNotNone(result)
    
    def test_iterator_test_11317(self):
        p0 = SpliteratorOfLong()
        result = Spliterators.iterator(p0)
        self.assertIsNotNone(result)
    
    def test_spliteratorUnknownSize_test_11318(self):
        p0 = PrimitiveIteratorOfInt()
        p1 = 1
        result = Spliterators.spliteratorUnknownSize(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliteratorUnknownSize_test_11319(self):
        p0 = PrimitiveIteratorOfLong()
        p1 = 1
        result = Spliterators.spliteratorUnknownSize(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliteratorUnknownSize_test_11320(self):
        p0 = PrimitiveIteratorOfDouble()
        p1 = 1
        result = Spliterators.spliteratorUnknownSize(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliteratorUnknownSize_test_11321(self):
        p0 = iter([])
        p1 = 1
        result = Spliterators.spliteratorUnknownSize(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11322(self):
        p0 = [1, 2, 3]
        p1 = 1
        result = Spliterators.spliterator(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11323(self):
        p0 = iter([1, 2, 3])
        p1 = 3
        p2 = 1
        result = Spliterators.spliterator(p0, p1, p2)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11324(self):
        p0 = [1, 2, 3]
        p1 = 1
        result = Spliterators.spliterator(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11325(self):
        p0 = PrimitiveIteratorOfInt()
        p1 = 3
        p2 = 1
        result = Spliterators.spliterator(p0, p1, p2)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11326(self):
        p0 = PrimitiveIteratorOfLong()
        p1 = 3
        p2 = 1
        result = Spliterators.spliterator(p0, p1, p2)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11327(self):
        p0 = PrimitiveIteratorOfDouble()
        p1 = 3
        p2 = 1
        result = Spliterators.spliterator(p0, p1, p2)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11328(self):
        p0 = [1, 2, 3]
        p1 = 0
        p2 = 3
        p3 = 1
        result = Spliterators.spliterator(p0, p1, p2, p3)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11329(self):
        p0 = [1, 2, 3]
        p1 = 1
        result = Spliterators.spliterator(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11330(self):
        p0 = [1, 2, 3]
        p1 = 0
        p2 = 3
        p3 = 1
        result = Spliterators.spliterator(p0, p1, p2, p3)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11331(self):
        p0 = [1, 2, 3]
        p1 = 0
        p2 = 3
        p3 = 1
        result = Spliterators.spliterator(p0, p1, p2, p3)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11332(self):
        p0 = [1, 2, 3]
        p1 = 1
        result = Spliterators.spliterator(p0, p1)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11333(self):
        p0 = [1.0, 2.0, 3.0]
        p1 = 0
        p2 = 3
        p3 = 1
        result = Spliterators.spliterator(p0, p1, p2, p3)
        self.assertIsNotNone(result)
    
    def test_spliterator_test_11334(self):
        p0 = [1.0, 2.0, 3.0]
        p1 = 1
        result = Spliterators.spliterator(p0, p1)
        self.assertIsNotNone(result)
    
    def test_emptySpliterator_test_11335(self):
        result = Spliterators.emptySpliterator()
        self.assertIsNotNone(result)
    
    def test_emptyIntSpliterator_test_11336(self):
        result = Spliterators.emptyIntSpliterator()
        self.assertIsNotNone(result)
    
    def test_emptyLongSpliterator_test_11337(self):
        result = Spliterators.emptyLongSpliterator()
        self.assertIsNotNone(result)
    
    def test_emptyDoubleSpliterator_test_11338(self):
        result = Spliterators.emptyDoubleSpliterator()
        self.assertIsNotNone(result)


if __name__ == '__main__':
    unittest.main()