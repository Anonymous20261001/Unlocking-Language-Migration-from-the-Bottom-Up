import unittest
from enum import Enum

class JapaneseEra(Enum):
    MEIJI = 0
    TAISHO = 1
    SHOWA = 2
    HEISEI = 3
    REIWA = 4

    @classmethod
    def values(cls):
        return list(cls)

    @classmethod
    def valueOf(cls, name):
        return cls[name]

    @classmethod
    def of(cls, era_value):
        for era in cls:
            if era.value == era_value:
                return era
        raise ValueError(f"No JapaneseEra with value {era_value}")

class TestJapaneseEra(unittest.TestCase):
    def test_values_test_5974(self):
        JapaneseEra.values()

    def test_valueOf_test_5975(self):
        p0 = "HEISEI"
        JapaneseEra.valueOf(p0)

    def test_of_test_5976(self):
        p0 = 3
        JapaneseEra.of(p0)

if __name__ == '__main__':
    unittest.main()