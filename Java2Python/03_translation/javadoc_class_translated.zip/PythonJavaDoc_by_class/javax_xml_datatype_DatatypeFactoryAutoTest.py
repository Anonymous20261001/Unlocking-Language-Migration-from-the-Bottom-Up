import unittest
import javax.xml.datatype.DatatypeFactory

class TestJavaxXmlDatatypeDatatypeFactory(unittest.TestCase):
    def test_newDefaultInstance_test_3280(self):
        DatatypeFactory.newDefaultInstance()

if __name__ == '__main__':
    unittest.main()