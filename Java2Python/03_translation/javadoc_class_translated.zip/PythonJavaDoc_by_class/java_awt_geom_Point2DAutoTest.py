import unittest
import math

class TestPoint2D(unittest.TestCase):
    def test_distanceSq_test_9956(self):
        p0, p1, p2, p3 = 1.0, 2.0, 3.0, 4.0
        result = Point2DWrapper.distanceSq(p0, p1, p2, p3)
        self.assertIsNotNone(result)
    
    def test_distance_test_9957(self):
        p0, p1, p2, p3 = 1.0, 2.0, 3.0, 4.0
        result = Point2DWrapper.distance(p0, p1, p2, p3)
        self.assertIsNotNone(result)


class Point2DWrapper:
    @staticmethod
    def distanceSq(x1, y1, x2, y2):
        return (x1 - x2) ** 2 + (y1 - y2) ** 2
    
    @staticmethod
    def distance(x1, y1, x2, y2):
        return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


if __name__ == '__main__':
    unittest.main()