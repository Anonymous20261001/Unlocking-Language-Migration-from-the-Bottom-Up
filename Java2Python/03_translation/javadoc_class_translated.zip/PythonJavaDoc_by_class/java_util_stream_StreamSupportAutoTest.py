import unittest
from typing import Callable, Any, List, Iterator
import itertools


class Spliterator:
    """Minimal Spliterator implementation for testing."""
    def __init__(self, data: List[Any] = None):
        self.data = data if data is not None else []
        self.index = 0
    
    def try_advance(self, consumer: Callable[[Any], None]) -> bool:
        if self.index < len(self.data):
            consumer(self.data[self.index])
            self.index += 1
            return True
        return False
    
    def estimate_size(self) -> int:
        return len(self.data) - self.index
    
    def characteristics(self) -> int:
        return 0


class OfInt(Spliterator):
    """Spliterator for integers."""
    pass


class OfLong(Spliterator):
    """Spliterator for longs."""
    pass


class OfDouble(Spliterator):
    """Spliterator for doubles."""
    pass


class StreamSupportWrapper:
    """Wrapper class mimicking Java's StreamSupport static methods."""
    
    @staticmethod
    def stream(supplier: Callable[[], Spliterator], characteristics: int, parallel: bool):
        """Create a stream from a supplier."""
        spliterator = supplier()
        return list(spliterator.data)
    
    @staticmethod
    def stream_spliterator(spliterator: Spliterator, parallel: bool):
        """Create a stream from a spliterator."""
        return list(spliterator.data)
    
    @staticmethod
    def intStream(supplier: Callable[[], OfInt], characteristics: int, parallel: bool):
        """Create an int stream from a supplier."""
        spliterator = supplier()
        return list(spliterator.data)
    
    @staticmethod
    def intStream_spliterator(spliterator: OfInt, parallel: bool):
        """Create an int stream from a spliterator."""
        return list(spliterator.data)
    
    @staticmethod
    def longStream(supplier: Callable[[], OfLong], characteristics: int, parallel: bool):
        """Create a long stream from a supplier."""
        spliterator = supplier()
        return list(spliterator.data)
    
    @staticmethod
    def longStream_spliterator(spliterator: OfLong, parallel: bool):
        """Create a long stream from a spliterator."""
        return list(spliterator.data)
    
    @staticmethod
    def doubleStream(supplier: Callable[[], OfDouble], characteristics: int, parallel: bool):
        """Create a double stream from a supplier."""
        spliterator = supplier()
        return list(spliterator.data)
    
    @staticmethod
    def doubleStream_spliterator(spliterator: OfDouble, parallel: bool):
        """Create a double stream from a spliterator."""
        return list(spliterator.data)


class TestStreamSupport(unittest.TestCase):
    """Test cases for StreamSupport functionality."""
    
    def test_stream_test_11571(self):
        """Test stream with supplier."""
        supplier = lambda: Spliterator([1, 2, 3])
        result = StreamSupportWrapper.stream(supplier, 0, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_stream_test_11572(self):
        """Test stream with spliterator."""
        spliterator = Spliterator([1, 2, 3])
        result = StreamSupportWrapper.stream_spliterator(spliterator, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_intStream_test_11573(self):
        """Test int stream with supplier."""
        supplier = lambda: OfInt([1, 2, 3])
        result = StreamSupportWrapper.intStream(supplier, 0, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_intStream_test_11574(self):
        """Test int stream with spliterator."""
        spliterator = OfInt([1, 2, 3])
        result = StreamSupportWrapper.intStream_spliterator(spliterator, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_longStream_test_11575(self):
        """Test long stream with supplier."""
        supplier = lambda: OfLong([1, 2, 3])
        result = StreamSupportWrapper.longStream(supplier, 0, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_longStream_test_11576(self):
        """Test long stream with spliterator."""
        spliterator = OfLong([1, 2, 3])
        result = StreamSupportWrapper.longStream_spliterator(spliterator, False)
        self.assertEqual(result, [1, 2, 3])
    
    def test_doubleStream_test_11577(self):
        """Test double stream with spliterator."""
        spliterator = OfDouble([1.0, 2.0, 3.0])
        result = StreamSupportWrapper.doubleStream_spliterator(spliterator, False)
        self.assertEqual(result, [1.0, 2.0, 3.0])
    
    def test_doubleStream_test_11578(self):
        """Test double stream with supplier."""
        supplier = lambda: OfDouble([1.0, 2.0, 3.0])
        result = StreamSupportWrapper.doubleStream(supplier, 0, False)
        self.assertEqual(result, [1.0, 2.0, 3.0])


if __name__ == '__main__':
    unittest.main()