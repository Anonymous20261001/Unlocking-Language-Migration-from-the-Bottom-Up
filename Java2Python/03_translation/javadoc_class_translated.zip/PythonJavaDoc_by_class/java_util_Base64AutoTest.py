import unittest
import base64


class TestJavaUtilBase64AutoTest(unittest.TestCase):
    def test_getEncoder_test_977(self):
        Base64Wrapper.get_encoder()

    def test_getUrlEncoder_test_978(self):
        Base64Wrapper.get_url_encoder()

    def test_getMimeEncoder_test_979(self):
        Base64Wrapper.get_mime_encoder()

    def test_getMimeEncoder_test_980(self, p0, p1):
        Base64Wrapper.get_mime_encoder(p0, p1)

    def test_getDecoder_test_981(self):
        Base64Wrapper.get_decoder()

    def test_getUrlDecoder_test_982(self):
        Base64Wrapper.get_url_decoder()

    def test_getMimeDecoder_test_983(self):
        Base64Wrapper.get_mime_decoder()


class Base64Wrapper:
    @staticmethod
    def get_encoder():
        return base64.b64encode

    @staticmethod
    def get_url_encoder():
        return base64.urlsafe_b64encode

    @staticmethod
    def get_mime_encoder(line_length=76, line_separator=b'\n'):
        return lambda data: base64.encodebytes(data).replace(b'\n', line_separator) if line_length == 76 else None

    @staticmethod
    def get_decoder():
        return base64.b64decode

    @staticmethod
    def get_url_decoder():
        return base64.urlsafe_b64decode

    @staticmethod
    def get_mime_decoder():
        return base64.decodebytes


if __name__ == '__main__':
    unittest.main()