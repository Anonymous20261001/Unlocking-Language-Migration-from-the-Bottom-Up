import unittest
from unittest.mock import MagicMock
from typing import Optional
import locale


class TestStandardDocletAutoTest(unittest.TestCase):
    def test_getName_test_11482(self):
        instance = StandardDoclet()
        instance.getName()

    def test_run_test_11483(self):
        instance = StandardDoclet()
        p0 = MagicMock()
        instance.run(p0)

    def test_init_test_11484(self):
        instance = StandardDoclet()
        p0 = locale.Locale('en', 'US')
        p1 = MagicMock()
        instance.init(p0, p1)

    def test_getLocale_test_11485(self):
        instance = StandardDoclet()
        instance.getLocale()

    def test_getReporter_test_11486(self):
        instance = StandardDoclet()
        instance.getReporter()

    def test_getSupportedOptions_test_11487(self):
        instance = StandardDoclet()
        instance.getSupportedOptions()

    def test_getSupportedSourceVersion_test_11488(self):
        instance = StandardDoclet()
        instance.getSupportedSourceVersion()


class StandardDoclet:
    def __init__(self):
        self._locale = None
        self._reporter = None

    def getName(self):
        return "StandardDoclet"

    def run(self, environment):
        return True

    def init(self, locale, reporter):
        self._locale = locale
        self._reporter = reporter

    def getLocale(self):
        return self._locale

    def getReporter(self):
        return self._reporter

    def getSupportedOptions(self):
        return set()

    def getSupportedSourceVersion(self):
        return None


if __name__ == '__main__':
    unittest.main()