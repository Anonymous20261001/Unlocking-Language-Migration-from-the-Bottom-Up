import unittest
from unittest.mock import MagicMock


class TestJavaAwtAWTKeyStrokeAutoTest(unittest.TestCase):

    def test_getAWTKeyStroke_test_946(self):
        p0 = 'a'
        AWTKeyStrokeWrapper.getAWTKeyStroke(p0)

    def test_getAWTKeyStroke_test_947(self):
        p0 = "ctrl C"
        AWTKeyStrokeWrapper.getAWTKeyStroke(p0)

    def test_getAWTKeyStroke_test_948(self):
        p0 = 65
        p1 = 2
        AWTKeyStrokeWrapper.getAWTKeyStroke(p0, p1)

    def test_getAWTKeyStroke_test_949(self):
        p0 = 65
        p1 = 2
        p2 = True
        AWTKeyStrokeWrapper.getAWTKeyStroke(p0, p1, p2)

    def test_getAWTKeyStroke_test_950(self):
        p0 = 'a'
        p1 = 2
        AWTKeyStrokeWrapper.getAWTKeyStroke(p0, p1)

    def test_getAWTKeyStrokeForEvent_test_951(self):
        p0 = MagicMock()
        AWTKeyStrokeWrapper.getAWTKeyStrokeForEvent(p0)


class AWTKeyStrokeWrapper:
    """Wrapper class mimicking java.awt.AWTKeyStroke static methods"""

    @staticmethod
    def getAWTKeyStroke(*args):
        """Simulate AWTKeyStroke.getAWTKeyStroke overloads"""
        pass

    @staticmethod
    def getAWTKeyStrokeForEvent(event):
        """Simulate AWTKeyStroke.getAWTKeyStrokeForEvent"""
        pass


if __name__ == '__main__':
    unittest.main()