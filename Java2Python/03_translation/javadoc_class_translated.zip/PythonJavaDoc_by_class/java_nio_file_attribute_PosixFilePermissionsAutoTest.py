import unittest
import posixfilepermissions


class TestJavaNioFileAttributePosixFilePermissionsAutoTest(unittest.TestCase):

    def asFileAttribute_test_9995(self, p0):
        posixfilepermissions.PosixFilePermissions.asFileAttribute(p0)

    def fromString_test_9996(self, p0):
        posixfilepermissions.PosixFilePermissions.fromString(p0)


class PosixFilePermissions:
    @staticmethod
    def asFileAttribute(perms):
        return perms

    @staticmethod
    def fromString(perms_str):
        return perms_str


if __name__ == '__main__':
    unittest.main()