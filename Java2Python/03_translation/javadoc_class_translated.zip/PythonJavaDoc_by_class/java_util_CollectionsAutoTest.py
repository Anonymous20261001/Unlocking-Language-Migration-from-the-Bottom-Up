import unittest
from collections.abc import Collection, Sequence, Set, Mapping, MutableSequence, MutableSet, MutableMapping
from collections import deque
from typing import Any, Callable, Iterator, List, Optional, TypeVar
import random as random_module
from enum import Enum
import heapq
import bisect
from itertools import chain

T = TypeVar('T')


class JavaCollections:
    """Wrapper class mimicking java.util.Collections static methods"""
    
    @staticmethod
    def min(collection: Collection, comparator: Optional[Callable] = None) -> Any:
        if comparator:
            return min(collection, key=comparator)
        return min(collection)
    
    @staticmethod
    def max(collection: Collection, comparator: Optional[Callable] = None) -> Any:
        if comparator:
            return max(collection, key=comparator)
        return max(collection)
    
    @staticmethod
    def reverse(lst: MutableSequence) -> None:
        lst.reverse()
    
    @staticmethod
    def sort(lst: MutableSequence, comparator: Optional[Callable] = None) -> None:
        if comparator:
            lst.sort(key=comparator)
        else:
            lst.sort()
    
    @staticmethod
    def copy(dest: MutableSequence, src: Sequence) -> None:
        if len(dest) < len(src):
            raise IndexError("Source does not fit in dest")
        for i, item in enumerate(src):
            dest[i] = item
    
    @staticmethod
    def replaceAll(lst: MutableSequence, old_val: Any, new_val: Any) -> bool:
        found = False
        for i, item in enumerate(lst):
            if item == old_val:
                lst[i] = new_val
                found = True
        return found
    
    @staticmethod
    def fill(lst: MutableSequence, obj: Any) -> None:
        for i in range(len(lst)):
            lst[i] = obj
    
    @staticmethod
    def list(enumeration: Iterator) -> List:
        return list(enumeration)
    
    @staticmethod
    def addAll(collection: MutableSet, elements: Sequence) -> bool:
        added = False
        for elem in elements:
            if elem not in collection:
                collection.add(elem)
                added = True
        return added
    
    @staticmethod
    def emptyEnumeration() -> Iterator:
        return iter([])
    
    @staticmethod
    def newSetFromMap(map: MutableMapping) -> MutableSet:
        # Simplified: return key set
        return set(map.keys())
    
    @staticmethod
    def emptyList() -> List:
        return []
    
    @staticmethod
    def unmodifiableSet(set_obj: Set) -> Set:
        # Simplified: return as-is (immutability not enforced in Python)
        return set_obj
    
    @staticmethod
    def enumeration(collection: Collection) -> Iterator:
        return iter(collection)
    
    @staticmethod
    def synchronizedSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def synchronizedCollection(collection: Collection) -> Collection:
        return collection
    
    @staticmethod
    def emptyIterator() -> Iterator:
        return iter([])
    
    @staticmethod
    def nCopies(n: int, obj: Any) -> List:
        return [obj] * n
    
    @staticmethod
    def reverseOrder(comparator: Optional[Callable] = None) -> Callable:
        if comparator:
            def reversed_cmp(a, b):
                return -comparator(a, b)
            return reversed_cmp
        else:
            return lambda a, b: (a > b) - (a < b)
    
    @staticmethod
    def unmodifiableMap(map_obj: Mapping) -> Mapping:
        return map_obj
    
    @staticmethod
    def unmodifiableSortedMap(map_obj: Mapping) -> Mapping:
        return map_obj
    
    @staticmethod
    def swap(lst: MutableSequence, i: int, j: int) -> None:
        lst[i], lst[j] = lst[j], lst[i]
    
    @staticmethod
    def binarySearch(lst: Sequence, key: Any, comparator: Optional[Callable] = None) -> int:
        if comparator:
            # Simplified: use linear search with comparator
            for idx, item in enumerate(lst):
                if comparator(item, key) == 0:
                    return idx
            return -1
        else:
            try:
                return lst.index(key)
            except ValueError:
                return -1
    
    @staticmethod
    def shuffle(lst: MutableSequence, rng: Optional[random_module.Random] = None) -> None:
        if rng:
            rng.shuffle(lst)
        else:
            random_module.shuffle(lst)
    
    @staticmethod
    def rotate(lst: MutableSequence, distance: int) -> None:
        if not lst:
            return
        distance = distance % len(lst)
        if distance != 0:
            lst[:] = lst[-distance:] + lst[:-distance]
    
    @staticmethod
    def indexOfSubList(source: Sequence, target: Sequence) -> int:
        for i in range(len(source) - len(target) + 1):
            if list(source[i:i+len(target)]) == list(target):
                return i
        return -1
    
    @staticmethod
    def lastIndexOfSubList(source: Sequence, target: Sequence) -> int:
        for i in range(len(source) - len(target), -1, -1):
            if list(source[i:i+len(target)]) == list(target):
                return i
        return -1
    
    @staticmethod
    def unmodifiableCollection(collection: Collection) -> Collection:
        return collection
    
    @staticmethod
    def unmodifiableSequencedCollection(collection: Collection) -> Collection:
        return collection
    
    @staticmethod
    def unmodifiableSequencedSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def unmodifiableSortedSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def unmodifiableNavigableSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def unmodifiableList(lst: Sequence) -> Sequence:
        return lst
    
    @staticmethod
    def unmodifiableSequencedMap(map_obj: Mapping) -> Mapping:
        return map_obj
    
    @staticmethod
    def unmodifiableNavigableMap(map_obj: Mapping) -> Mapping:
        return map_obj
    
    @staticmethod
    def synchronizedSortedSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def synchronizedNavigableSet(set_obj: Set) -> Set:
        return set_obj
    
    @staticmethod
    def synchronizedList(lst: MutableSequence) -> MutableSequence:
        return lst
    
    @staticmethod
    def synchronizedMap(map_obj: MutableMapping) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def synchronizedSortedMap(map_obj: MutableMapping) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def synchronizedNavigableMap(map_obj: MutableMapping) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def checkedCollection(collection: Collection, type_: type) -> Collection:
        return collection
    
    @staticmethod
    def checkedQueue(queue: deque, type_: type) -> deque:
        return queue
    
    @staticmethod
    def checkedSet(set_obj: Set, type_: type) -> Set:
        return set_obj
    
    @staticmethod
    def checkedSortedSet(set_obj: Set, type_: type) -> Set:
        return set_obj
    
    @staticmethod
    def checkedNavigableSet(set_obj: Set, type_: type) -> Set:
        return set_obj
    
    @staticmethod
    def checkedList(lst: MutableSequence, type_: type) -> MutableSequence:
        return lst
    
    @staticmethod
    def checkedMap(map_obj: MutableMapping, key_type: type, value_type: type) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def checkedSortedMap(map_obj: MutableMapping, key_type: type, value_type: type) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def checkedNavigableMap(map_obj: MutableMapping, key_type: type, value_type: type) -> MutableMapping:
        return map_obj
    
    @staticmethod
    def emptyListIterator() -> Iterator:
        return iter([])
    
    @staticmethod
    def emptySet() -> Set:
        return set()
    
    @staticmethod
    def emptySortedSet() -> Set:
        return set()
    
    @staticmethod
    def emptyNavigableSet() -> Set:
        return set()
    
    @staticmethod
    def emptyMap() -> Mapping:
        return {}
    
    @staticmethod
    def emptySortedMap() -> Mapping:
        return {}
    
    @staticmethod
    def emptyNavigableMap() -> Mapping:
        return {}
    
    @staticmethod
    def singleton(obj: Any) -> Set:
        return {obj}
    
    @staticmethod
    def singletonList(obj: Any) -> List:
        return [obj]
    
    @staticmethod
    def singletonMap(key: Any, value: Any) -> Mapping:
        return {key: value}
    
    @staticmethod
    def frequency(collection: Collection, obj: Any) -> int:
        return sum(1 for item in collection if item == obj)
    
    @staticmethod
    def disjoint(c1: Collection, c2: Collection) -> bool:
        return not any(item in c2 for item in c1)
    
    @staticmethod
    def newSequencedSetFromMap(map_obj: Mapping) -> Set:
        return set(map_obj.keys())
    
    @staticmethod
    def asLifoQueue(deque_obj: deque) -> deque:
        return deque_obj


class TestJavaCollections(unittest.TestCase):
    
    def test_min_test_2353(self):
        p0 = [3, 1, 2]
        p1 = lambda x: x
        JavaCollections.min(p0, p1)
    
    def test_min_test_2354(self):
        p0 = [3, 1, 2]
        JavaCollections.min(p0)
    
    def test_max_test_2355(self):
        p0 = [3, 1, 2]
        JavaCollections.max(p0)
    
    def test_max_test_2356(self):
        p0 = [3, 1, 2]
        p1 = lambda x: x
        JavaCollections.max(p0, p1)
    
    def test_reverse_test_2357(self):
        p0 = [1, 2, 3]
        JavaCollections.reverse(p0)
    
    def test_sort_test_2358(self):
        p0 = [3, 1, 2]
        JavaCollections.sort(p0)
    
    def test_sort_test_2359(self):
        p0 = [3, 1, 2]
        p1 = lambda x: x
        JavaCollections.sort(p0, p1)
    
    def test_copy_test_2360(self):
        p0 = [0, 0, 0]
        p1 = [1, 2, 3]
        JavaCollections.copy(p0, p1)
    
    def test_replaceAll_test_2361(self):
        p0 = [1, 2, 1]
        p1 = 1
        p2 = 3
        JavaCollections.replaceAll(p0, p1, p2)
    
    def test_fill_test_2362(self):
        p0 = [1, 2, 3]
        p1 = 0
        JavaCollections.fill(p0, p1)
    
    def test_list_test_2363(self):
        p0 = iter([1, 2, 3])
        JavaCollections.list(p0)
    
    def test_addAll_test_2364(self):
        p0 = {1, 2}
        p1 = [3, 4]
        JavaCollections.addAll(p0, p1)
    
    def test_emptyEnumeration_test_2365(self):
        JavaCollections.emptyEnumeration()
    
    def test_newSetFromMap_test_2366(self):
        p0 = {'a': 1, 'b': 2}
        JavaCollections.newSetFromMap(p0)
    
    def test_emptyList_test_2367(self):
        JavaCollections.emptyList()
    
    def test_unmodifiableSet_test_2368(self):
        p0 = {1, 2, 3}
        JavaCollections.unmodifiableSet(p0)
    
    def test_enumeration_test_2369(self):
        p0 = [1, 2, 3]
        JavaCollections.enumeration(p0)
    
    def test_synchronizedSet_test_2370(self):
        p0 = {1, 2, 3}
        JavaCollections.synchronizedSet(p0)
    
    def test_synchronizedCollection_test_2371(self):
        p0 = [1, 2, 3]
        JavaCollections.synchronizedCollection(p0)
    
    def test_emptyIterator_test_2372(self):
        JavaCollections.emptyIterator()
    
    def test_nCopies_test_2373(self):
        p0 = 3
        p1 = 'a'
        JavaCollections.nCopies(p0, p1)
    
    def test_reverseOrder_test_2374(self):
        p0 = lambda a, b: (a > b) - (a < b)
        JavaCollections.reverseOrder(p0)
    
    def test_reverseOrder_test_2375(self):
        JavaCollections.reverseOrder()
    
    def test_unmodifiableMap_test_2376(self):
        p0 = {'a': 1}
        JavaCollections.unmodifiableMap(p0)
    
    def test_unmodifiableSortedMap_test_2377(self):
        p0 = {'a': 1}
        JavaCollections.unmodifiableSortedMap(p0)
    
    def test_swap_test_2378(self):
        p0 = [1, 2, 3]
        p1 = 0
        p2 = 2
        JavaCollections.swap(p0, p1, p2)
    
    def test_binarySearch_test_2379(self):
        p0 = [1, 2, 3]
        p1 = 2
        p2 = lambda a, b: a - b
        JavaCollections.binarySearch(p0, p1, p2)
    
    def test_binarySearch_test_2380(self):
        p0 = [1, 2, 3]
        p1 = 2
        JavaCollections.binarySearch(p0, p1)
    
    def test_shuffle_test_2381(self):
        p0 = [1, 2, 3]
        p1 = random_module.Random(42)
        JavaCollections.shuffle(p0, p1)
    
    def test_shuffle_test_2382(self):
        p0 = [1, 2, 3]
        JavaCollections.shuffle(p0)
    
    def test_shuffle_test_2383(self):
        p0 = [1, 2, 3]
        p1 = random_module.Random(42)
        JavaCollections.shuffle(p0, p1)
    
    def test_rotate_test_2384(self):
        p0 = [1, 2, 3, 4]
        p1 = 1
        JavaCollections.rotate(p0, p1)
    
    def test_indexOfSubList_test_2385(self):
        p0 = [1, 2, 3, 4, 5]
        p1 = [2, 3]
        JavaCollections.indexOfSubList(p0, p1)
    
    def test_lastIndexOfSubList_test_2386(self):
        p0 = [1, 2, 3, 2, 3]
        p1 = [2, 3]
        JavaCollections.lastIndexOfSubList(p0, p1)
    
    def test_unmodifiableCollection_test_2387(self):
        p0 = [1, 2, 3]
        JavaCollections.unmodifiableCollection(p0)
    
    def test_unmodifiableSequencedCollection_test_2388(self):
        p0 = [1, 2, 3]
        JavaCollections.unmodifiableSequencedCollection(p0)
    
    def test_unmodifiableSequencedSet_test_2389(self):
        p0 = {1, 2, 3}
        JavaCollections.unmodifiableSequencedSet(p0)
    
    def test_unmodifiableSortedSet_test_2390(self):
        p0 = {1, 2, 3}
        JavaCollections.unmodifiableSortedSet(p0)
    
    def test_unmodifiableNavigableSet_test_2391(self):
        p0 = {1, 2, 3}
        JavaCollections.unmodifiableNavigableSet(p0)
    
    def test_unmodifiableList_test_2392(self):
        p0 = [1, 2, 3]
        JavaCollections.unmodifiableList(p0)
    
    def test_unmodifiableSequencedMap_test_2393(self):
        p0 = {'a': 1}
        JavaCollections.unmodifiableSequencedMap(p0)
    
    def test_unmodifiableNavigableMap_test_2394(self):
        p0 = {'a': 1}
        JavaCollections.unmodifiableNavigableMap(p0)
    
    def test_synchronizedSortedSet_test_2395(self):
        p0 = {1, 2, 3}
        JavaCollections.synchronizedSortedSet(p0)
    
    def test_synchronizedNavigableSet_test_2396(self):
        p0 = {1, 2, 3}
        JavaCollections.synchronizedNavigableSet(p0)
    
    def test_synchronizedList_test_2397(self):
        p0 = [1, 2, 3]
        JavaCollections.synchronizedList(p0)
    
    def test_synchronizedMap_test_2398(self):
        p0 = {'a': 1}
        JavaCollections.synchronizedMap(p0)
    
    def test_synchronizedSortedMap_test_2399(self):
        p0 = {'a': 1}
        JavaCollections.synchronizedSortedMap(p0)
    
    def test_synchronizedNavigableMap_test_2400(self):
        p0 = {'a': 1}
        JavaCollections.synchronizedNavigableMap(p0)
    
    def test_checkedCollection_test_2401(self):
        p0 = [1, 2, 3]
        p1 = int
        JavaCollections.checkedCollection(p0, p1)
    
    def test_checkedQueue_test_2402(self):
        p0 = deque([1, 2, 3])
        p1 = int
        JavaCollections.checkedQueue(p0, p1)
    
    def test_checkedSet_test_2403(self):
        p0 = {1, 2, 3}
        p1 = int
        JavaCollections.checkedSet(p0, p1)
    
    def test_checkedSortedSet_test_2404(self):
        p0 = {1, 2, 3}
        p1 = int
        JavaCollections.checkedSortedSet(p0, p1)
    
    def test_checkedNavigableSet_test_2405(self):
        p0 = {1, 2, 3}
        p1 = int
        JavaCollections.checkedNavigableSet(p0, p1)
    
    def test_checkedList_test_2406(self):
        p0 = [1, 2, 3]
        p1 = int
        JavaCollections.checkedList(p0, p1)
    
    def test_checkedMap_test_2407(self):
        p0 = {'a': 1}
        p1 = str
        p2 = int
        JavaCollections.checkedMap(p0, p1, p2)
    
    def test_checkedSortedMap_test_2408(self):
        p0 = {'a': 1}
        p1 = str
        p2 = int
        JavaCollections.checkedSortedMap(p0, p1, p2)
    
    def test_checkedNavigableMap_test_2409(self):
        p0 = {'a': 1}
        p1 = str
        p2 = int
        JavaCollections.checkedNavigableMap(p0, p1, p2)
    
    def test_emptyListIterator_test_2410(self):
        JavaCollections.emptyListIterator()
    
    def test_emptySet_test_2411(self):
        JavaCollections.emptySet()
    
    def test_emptySortedSet_test_2412(self):
        JavaCollections.emptySortedSet()
    
    def test_emptyNavigableSet_test_2413(self):
        JavaCollections.emptyNavigableSet()
    
    def test_emptyMap_test_2414(self):
        JavaCollections.emptyMap()
    
    def test_emptySortedMap_test_2415(self):
        JavaCollections.emptySortedMap()
    
    def test_emptyNavigableMap_test_2416(self):
        JavaCollections.emptyNavigableMap()
    
    def test_singleton_test_2417(self):
        p0 = 'a'
        JavaCollections.singleton(p0)
    
    def test_singletonList_test_2418(self):
        p0 = 'a'
        JavaCollections.singletonList(p0)
    
    def test_singletonMap_test_2419(self):
        p0 = 'key'
        p1 = 'value'
        JavaCollections.singletonMap(p0, p1)
    
    def test_frequency_test_2420(self):
        p0 = [1, 2, 1, 3]
        p1 = 1
        JavaCollections.frequency(p0, p1)
    
    def test_disjoint_test_2421(self):
        p0 = [1, 2, 3]
        p1 = [4, 5, 6]
        JavaCollections.disjoint(p0, p1)
    
    def test_newSequencedSetFromMap_test_2422(self):
        p0 = {'a': 1}
        JavaCollections.newSequencedSetFromMap(p0)
    
    def test_asLifoQueue_test_2423(self):
        p0 = deque([1, 2, 3])
        JavaCollections.asLifoQueue(p0)


if __name__ == '__main__':
    unittest.main()