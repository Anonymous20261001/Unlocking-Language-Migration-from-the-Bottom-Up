import unittest
from pathlib import Path


class TestUnixDomainSocketAddress(unittest.TestCase):
    def of_test_13210(self, p0: Path):
        UnixDomainSocketAddress.of(p0)

    def of_test_13211(self, p0: str):
        UnixDomainSocketAddress.of(p0)


class UnixDomainSocketAddress:
    @staticmethod
    def of(path):
        if isinstance(path, Path):
            # Simulate UnixDomainSocketAddress.of(Path) - in Python, we can use path as is
            return path
        elif isinstance(path, str):
            # Simulate UnixDomainSocketAddress.of(String) - return the string
            return path
        else:
            raise TypeError("Unsupported type")