import unittest

class TestAbstractUndoableEdit(unittest.TestCase):
    def test_addEdit_test_14(self):
        p0 = None
        instance = AbstractUndoableEdit()
        instance.addEdit(p0)

    def test_redo_test_15(self):
        instance = AbstractUndoableEdit()
        instance.redo()

    def test_undo_test_16(self):
        instance = AbstractUndoableEdit()
        instance.undo()

    def test_getPresentationName_test_17(self):
        instance = AbstractUndoableEdit()
        instance.getPresentationName()

    def test_isSignificant_test_18(self):
        instance = AbstractUndoableEdit()
        instance.isSignificant()

    def test_getUndoPresentationName_test_19(self):
        instance = AbstractUndoableEdit()
        instance.getUndoPresentationName()

    def test_getRedoPresentationName_test_20(self):
        instance = AbstractUndoableEdit()
        instance.getRedoPresentationName()

    def test_die_test_21(self):
        instance = AbstractUndoableEdit()
        instance.die()

    def test_replaceEdit_test_22(self):
        p0 = None
        instance = AbstractUndoableEdit()
        instance.replaceEdit(p0)

    def test_canUndo_test_23(self):
        instance = AbstractUndoableEdit()
        instance.canUndo()

    def test_canRedo_test_24(self):
        instance = AbstractUndoableEdit()
        instance.canRedo()


class AbstractUndoableEdit:
    def __init__(self):
        self.alive = True

    def addEdit(self, p0):
        return False

    def redo(self):
        if not self.alive:
            raise Exception("Cannot redo: edit is dead")
        return None

    def undo(self):
        if not self.alive:
            raise Exception("Cannot undo: edit is dead")
        return None

    def getPresentationName(self):
        return ""

    def isSignificant(self):
        return True

    def getUndoPresentationName(self):
        return "Undo " + self.getPresentationName()

    def getRedoPresentationName(self):
        return "Redo " + self.getPresentationName()

    def die(self):
        self.alive = False

    def replaceEdit(self, p0):
        return False

    def canUndo(self):
        return self.alive

    def canRedo(self):
        return self.alive


if __name__ == '__main__':
    unittest.main()