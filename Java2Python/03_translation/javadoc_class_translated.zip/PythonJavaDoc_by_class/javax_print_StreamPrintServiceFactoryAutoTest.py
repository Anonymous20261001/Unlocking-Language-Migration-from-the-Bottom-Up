import unittest
from unittest.mock import MagicMock, patch
import javax.print.DocFlavor as DocFlavor
import javax.print.StreamPrintServiceFactory as StreamPrintServiceFactory

class TestJavaxPrintStreamPrintServiceFactoryAutoTest(unittest.TestCase):
    def test_lookupStreamPrintServiceFactories_test_11513(self):
        p0 = MagicMock(spec=DocFlavor)
        p1 = "test_mime_type"
        StreamPrintServiceFactory.lookupStreamPrintServiceFactories(p0, p1)
        StreamPrintServiceFactory.lookupStreamPrintServiceFactories.assert_called_once_with(p0, p1)

class StreamPrintServiceFactoryWrapper:
    @staticmethod
    def lookupStreamPrintServiceFactories(doc_flavor, mime_type):
        return StreamPrintServiceFactory.lookupStreamPrintServiceFactories(doc_flavor, mime_type)

if __name__ == '__main__':
    unittest.main()