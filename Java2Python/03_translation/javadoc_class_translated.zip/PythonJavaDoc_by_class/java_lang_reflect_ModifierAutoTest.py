import unittest


class TestJavaLangReflectModifier(unittest.TestCase):

    def test_isInterface_test_8971(self):
        p0 = 0
        ModifierWrapper.isInterface(p0)

    def test_classModifiers_test_8972(self):
        ModifierWrapper.classModifiers()

    def test_isFinal_test_8973(self):
        p0 = 0
        ModifierWrapper.isFinal(p0)

    def test_isPublic_test_8974(self):
        p0 = 0
        ModifierWrapper.isPublic(p0)

    def test_isStatic_test_8975(self):
        p0 = 0
        ModifierWrapper.isStatic(p0)

    def test_isProtected_test_8976(self):
        p0 = 0
        ModifierWrapper.isProtected(p0)

    def test_methodModifiers_test_8977(self):
        ModifierWrapper.methodModifiers()

    def test_constructorModifiers_test_8978(self):
        ModifierWrapper.constructorModifiers()

    def test_isAbstract_test_8979(self):
        p0 = 0
        ModifierWrapper.isAbstract(p0)

    def test_isVolatile_test_8980(self):
        p0 = 0
        ModifierWrapper.isVolatile(p0)

    def test_isPrivate_test_8981(self):
        p0 = 0
        ModifierWrapper.isPrivate(p0)

    def test_isNative_test_8982(self):
        p0 = 0
        ModifierWrapper.isNative(p0)

    def test_isSynchronized_test_8983(self):
        p0 = 0
        ModifierWrapper.isSynchronized(p0)

    def test_isTransient_test_8984(self):
        p0 = 0
        ModifierWrapper.isTransient(p0)

    def test_isStrict_test_8985(self):
        p0 = 0
        ModifierWrapper.isStrict(p0)

    def test_interfaceModifiers_test_8986(self):
        ModifierWrapper.interfaceModifiers()

    def test_fieldModifiers_test_8987(self):
        ModifierWrapper.fieldModifiers()

    def test_parameterModifiers_test_8988(self):
        ModifierWrapper.parameterModifiers()


class ModifierWrapper:
    @staticmethod
    def isInterface(mod):
        return (mod & 0x0200) != 0

    @staticmethod
    def classModifiers():
        return 0x3107

    @staticmethod
    def isFinal(mod):
        return (mod & 0x0010) != 0

    @staticmethod
    def isPublic(mod):
        return (mod & 0x0001) != 0

    @staticmethod
    def isStatic(mod):
        return (mod & 0x0008) != 0

    @staticmethod
    def isProtected(mod):
        return (mod & 0x0004) != 0

    @staticmethod
    def methodModifiers():
        return 0x30DF

    @staticmethod
    def constructorModifiers():
        return 0x3007

    @staticmethod
    def isAbstract(mod):
        return (mod & 0x0400) != 0

    @staticmethod
    def isVolatile(mod):
        return (mod & 0x0040) != 0

    @staticmethod
    def isPrivate(mod):
        return (mod & 0x0002) != 0

    @staticmethod
    def isNative(mod):
        return (mod & 0x0100) != 0

    @staticmethod
    def isSynchronized(mod):
        return (mod & 0x0020) != 0

    @staticmethod
    def isTransient(mod):
        return (mod & 0x0080) != 0

    @staticmethod
    def isStrict(mod):
        return (mod & 0x0800) != 0

    @staticmethod
    def interfaceModifiers():
        return 0x2607

    @staticmethod
    def fieldModifiers():
        return 0x00DF

    @staticmethod
    def parameterModifiers():
        return 0x3010


if __name__ == '__main__':
    unittest.main()