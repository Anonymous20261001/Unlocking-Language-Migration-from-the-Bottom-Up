import unittest
from unittest.mock import MagicMock
import logging


class TestJavaRmiServerLogStreamAutoTest(unittest.TestCase):
    
    def test_getDefaultStream_test_8139(self):
        LogStream.getDefaultStream()
    
    def test_setDefaultStream_test_8140(self):
        p0 = MagicMock()
        LogStream.setDefaultStream(p0)
    
    def test_parseLevel_test_8141(self):
        p0 = "INFO"
        LogStream.parseLevel(p0)
    
    def test_log_test_8142(self):
        p0 = "Test message"
        LogStream.log(p0)


class LogStream:
    _default_stream = None
    _level = logging.INFO
    
    @classmethod
    def getDefaultStream(cls):
        if cls._default_stream is None:
            cls._default_stream = logging.StreamHandler()
        return cls._default_stream
    
    @classmethod
    def setDefaultStream(cls, stream):
        cls._default_stream = stream
    
    @classmethod
    def parseLevel(cls, s):
        level_map = {
            "SEVERE": logging.CRITICAL,
            "WARNING": logging.WARNING,
            "INFO": logging.INFO,
            "CONFIG": logging.INFO,
            "FINE": logging.DEBUG,
            "FINER": logging.DEBUG,
            "FINEST": logging.DEBUG
        }
        return level_map.get(s.upper(), logging.INFO)
    
    @classmethod
    def log(cls, s):
        logging.log(cls._level, s)


if __name__ == '__main__':
    unittest.main()