import unittest
import ctypes
from typing import Optional

class Long:
    """Wrapper class mimicking Java's Long class"""
    
    def __init__(self, value):
        if isinstance(value, str):
            self.value = int(value)
        else:
            self.value = int(value)
    
    def compareTo(self, other):
        return (self.value > other) - (self.value < other)
    
    def byteValue(self):
        return ctypes.c_byte(self.value).value
    
    def shortValue(self):
        return ctypes.c_short(self.value).value
    
    def intValue(self):
        return ctypes.c_int(self.value).value
    
    def longValue(self):
        return self.value
    
    def floatValue(self):
        return float(self.value)
    
    def doubleValue(self):
        return float(self.value)
    
    def resolveConstantDesc(self, lookup):
        return self.value
    
    def describeConstable(self):
        return self.value
    
    @staticmethod
    def numberOfLeadingZeros(i):
        if i == 0:
            return 64
        return 64 - i.bit_length()
    
    @staticmethod
    def numberOfTrailingZeros(i):
        if i == 0:
            return 64
        return (i & -i).bit_length() - 1
    
    @staticmethod
    def bitCount(i):
        return bin(i & 0xFFFFFFFFFFFFFFFF).count('1')
    
    @staticmethod
    def min(a, b):
        return min(a, b)
    
    @staticmethod
    def max(a, b):
        return max(a, b)
    
    @staticmethod
    def signum(i):
        if i > 0:
            return 1
        elif i < 0:
            return -1
        return 0
    
    @staticmethod
    def expand(i, mask):
        result = 0
        m = 1
        for bit in range(64):
            if mask & (1 << bit):
                if i & m:
                    result |= (1 << bit)
                m <<= 1
        return result
    
    @staticmethod
    def compareUnsigned(x, y):
        x_unsigned = x & 0xFFFFFFFFFFFFFFFF
        y_unsigned = y & 0xFFFFFFFFFFFFFFFF
        return (x_unsigned > y_unsigned) - (x_unsigned < y_unsigned)
    
    @staticmethod
    def divideUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError
        dividend_unsigned = dividend & 0xFFFFFFFFFFFFFFFF
        divisor_unsigned = divisor & 0xFFFFFFFFFFFFFFFF
        return dividend_unsigned // divisor_unsigned
    
    @staticmethod
    def remainderUnsigned(dividend, divisor):
        if divisor == 0:
            raise ZeroDivisionError
        dividend_unsigned = dividend & 0xFFFFFFFFFFFFFFFF
        divisor_unsigned = divisor & 0xFFFFFFFFFFFFFFFF
        return dividend_unsigned % divisor_unsigned
    
    @staticmethod
    def reverse(i):
        return int('{:064b}'.format(i & 0xFFFFFFFFFFFFFFFF)[::-1], 2)
    
    @staticmethod
    def reverseBytes(i):
        return int.from_bytes(i.to_bytes(8, 'little'), 'big')
    
    @staticmethod
    def compress(i, mask):
        result = 0
        bit = 0
        for j in range(64):
            if mask & (1 << j):
                if i & (1 << j):
                    result |= (1 << bit)
                bit += 1
        return result
    
    @staticmethod
    def getLong(nm, val=None):
        # Simulate system property lookup (returns default value)
        if val is not None:
            return val if isinstance(val, Long) else Long(val)
        return None
    
    @staticmethod
    def compare(x, y):
        return (x > y) - (x < y)
    
    @staticmethod
    def valueOf(*args):
        if len(args) == 1:
            if isinstance(args[0], str):
                return Long(int(args[0]))
            return Long(args[0])
        elif len(args) == 2:
            return Long(int(args[0], args[1]))
        return None
    
    @staticmethod
    def toHexString(i):
        return hex(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def decode(nm):
        return Long(int(nm, 0))
    
    @staticmethod
    def sum(a, b):
        return a + b
    
    @staticmethod
    def toUnsignedString(i, radix=10):
        if i >= 0:
            return str(i)
        return str(i & 0xFFFFFFFFFFFFFFFF)
    
    @staticmethod
    def toOctalString(i):
        return oct(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def toBinaryString(i):
        return bin(i & 0xFFFFFFFFFFFFFFFF)[2:]
    
    @staticmethod
    def highestOneBit(i):
        if i == 0:
            return 0
        return 1 << (i.bit_length() - 1)
    
    @staticmethod
    def lowestOneBit(i):
        return i & -i
    
    @staticmethod
    def rotateLeft(i, distance):
        distance %= 64
        return ((i << distance) | (i >> (64 - distance))) & 0xFFFFFFFFFFFFFFFF
    
    @staticmethod
    def rotateRight(i, distance):
        distance %= 64
        return ((i >> distance) | (i << (64 - distance))) & 0xFFFFFFFFFFFFFFFF
    
    @staticmethod
    def parseLong(s, radix=10):
        return int(s, radix)
    
    @staticmethod
    def parseUnsignedLong(s, radix=10):
        return int(s, radix) & 0xFFFFFFFFFFFFFFFF


class TestJavaLangLong(unittest.TestCase):
    def test_numberOfLeadingZeros_test_8143(self):
        Long.numberOfLeadingZeros(0)
    
    def test_numberOfTrailingZeros_test_8144(self):
        Long.numberOfTrailingZeros(0)
    
    def test_bitCount_test_8145(self):
        Long.bitCount(0)
    
    def test_min_test_8146(self):
        Long.min(0, 1)
    
    def test_max_test_8147(self):
        Long.max(0, 1)
    
    def test_signum_test_8148(self):
        Long.signum(0)
    
    def test_expand_test_8149(self):
        Long.expand(0, 0)
    
    def test_compareUnsigned_test_8150(self):
        Long.compareUnsigned(0, 1)
    
    def test_divideUnsigned_test_8151(self):
        Long.divideUnsigned(0, 1)
    
    def test_remainderUnsigned_test_8152(self):
        Long.remainderUnsigned(0, 1)
    
    def test_reverse_test_8153(self):
        Long.reverse(0)
    
    def test_reverseBytes_test_8154(self):
        Long.reverseBytes(0)
    
    def test_compress_test_8155(self):
        Long.compress(0, 0)
    
    def test_compareTo_test_8156(self):
        instance = Long("0")
        instance.compareTo(0)
    
    def test_getLong_test_8157(self):
        Long.getLong("test", Long(0))
    
    def test_getLong_test_8158(self):
        Long.getLong("test")
    
    def test_getLong_test_8159(self):
        Long.getLong("test", 0)
    
    def test_compare_test_8160(self):
        Long.compare(0, 1)
    
    def test_byteValue_test_8161(self):
        instance = Long("0")
        instance.byteValue()
    
    def test_shortValue_test_8162(self):
        instance = Long("0")
        instance.shortValue()
    
    def test_intValue_test_8163(self):
        instance = Long("0")
        instance.intValue()
    
    def test_longValue_test_8164(self):
        instance = Long("0")
        instance.longValue()
    
    def test_floatValue_test_8165(self):
        instance = Long("0")
        instance.floatValue()
    
    def test_doubleValue_test_8166(self):
        instance = Long("0")
        instance.doubleValue()
    
    def test_valueOf_test_8167(self):
        Long.valueOf(0)
    
    def test_valueOf_test_8168(self):
        Long.valueOf("0")
    
    def test_valueOf_test_8169(self):
        Long.valueOf("0", 10)
    
    def test_toHexString_test_8170(self):
        Long.toHexString(0)
    
    def test_decode_test_8171(self):
        Long.decode("0")
    
    def test_resolveConstantDesc_test_8172(self):
        instance = Long("0")
        instance.resolveConstantDesc(None)
    
    def test_describeConstable_test_8173(self):
        instance = Long("0")
        instance.describeConstable()
    
    def test_sum_test_8174(self):
        Long.sum(0, 1)
    
    def test_toUnsignedString_test_8175(self):
        Long.toUnsignedString(0)
    
    def test_toUnsignedString_test_8176(self):
        Long.toUnsignedString(0, 10)
    
    def test_toOctalString_test_8177(self):
        Long.toOctalString(0)
    
    def test_toBinaryString_test_8178(self):
        Long.toBinaryString(0)
    
    def test_highestOneBit_test_8179(self):
        Long.highestOneBit(0)
    
    def test_lowestOneBit_test_8180(self):
        Long.lowestOneBit(0)
    
    def test_rotateLeft_test_8181(self):
        Long.rotateLeft(0, 1)
    
    def test_rotateRight_test_8182(self):
        Long.rotateRight(0, 1)
    
    def test_parseLong_test_8183(self):
        Long.parseLong("0")
    
    def test_parseLong_test_8184(self):
        Long.parseLong("0", 10)
    
    def test_parseLong_test_8185(self):
        Long.parseLong("0", 0, 1, 10)
    
    def test_parseUnsignedLong_test_8186(self):
        Long.parseUnsignedLong("0")
    
    def test_parseUnsignedLong_test_8187(self):
        Long.parseUnsignedLong("0", 10)
    
    def test_parseUnsignedLong_test_8188(self):
        Long.parseUnsignedLong("0", 0, 1, 10)


if __name__ == '__main__':
    unittest.main()