import unittest
from java.nio.file.spi.FileSystemProvider import FileSystemProvider

class TestJavaNioFileSpiFileSystemProviderAutoTest(unittest.TestCase):
    def test_installedProviders_test_4778(self):
        FileSystemProvider.installedProviders()


class FileSystemProviderWrapper:
    @staticmethod
    def installedProviders():
        return FileSystemProvider.installedProviders()