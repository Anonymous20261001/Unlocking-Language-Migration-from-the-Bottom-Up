import unittest
import javax.imageio.spi.IIORegistry as IIORegistry

class TestIIORegistry(unittest.TestCase):
    def getDefaultInstance_test_5617(self):
        IIORegistry.getDefaultInstance()


class IIORegistryWrapper:
    @staticmethod
    def getDefaultInstance():
        return IIORegistry.getDefaultInstance()