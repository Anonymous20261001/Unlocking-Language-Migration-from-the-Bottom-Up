import unittest
from javax.imageio.plugins.tiff import ExifTIFFTagSet

class TestExifTIFFTagSetAuto(unittest.TestCase):
    def getInstance_test_4664(self):
        ExifTIFFTagSet.getInstance()


class ExifTIFFTagSetWrapper:
    @staticmethod
    def getInstance():
        return ExifTIFFTagSet.getInstance()