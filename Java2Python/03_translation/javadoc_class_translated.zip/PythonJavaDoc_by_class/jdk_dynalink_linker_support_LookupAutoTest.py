import unittest
from unittest.mock import MagicMock
from typing import Any

class TestJdkDynalinkLinkerSupportLookup(unittest.TestCase):
    def test_findVirtual_test_8237(self):
        p0 = MagicMock()
        p1 = "testMethod"
        p2 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findVirtual(p0, p1, p2)

    def test_findStatic_test_8238(self):
        p0 = MagicMock()
        p1 = "testStaticMethod"
        p2 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findStatic(p0, p1, p2)

    def test_unreflect_test_8239(self):
        p0 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.unreflect(p0)

    def test_unreflect_test_8240(self):
        p0 = MagicMock()
        p1 = MagicMock()
        Lookup.unreflect(p0, p1)

    def test_unreflectConstructor_test_8241(self):
        p0 = MagicMock()
        p1 = MagicMock()
        Lookup.unreflectConstructor(p0, p1)

    def test_unreflectConstructor_test_8242(self):
        p0 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.unreflectConstructor(p0)

    def test_findSpecial_test_8243(self):
        p0 = MagicMock()
        p1 = "testSpecialMethod"
        p2 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findSpecial(p0, p1, p2)

    def test_findGetter_test_8244(self):
        p0 = MagicMock()
        p1 = "testField"
        p2 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findGetter(p0, p1, p2)

    def test_unreflectGetter_test_8245(self):
        p0 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.unreflectGetter(p0)

    def test_unreflectSetter_test_8246(self):
        p0 = MagicMock()
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.unreflectSetter(p0)

    def test_findOwnSpecial_test_8247(self):
        p0 = "testOwnSpecial"
        p1 = MagicMock()
        p2 = [MagicMock()]
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findOwnSpecial(p0, p1, p2)

    def test_findOwnSpecial_test_8248(self):
        p0 = MagicMock()
        p1 = "testOwnSpecial"
        p2 = MagicMock()
        p3 = [MagicMock()]
        Lookup.findOwnSpecial(p0, p1, p2, p3)

    def test_findOwnStatic_test_8249(self):
        p0 = MagicMock()
        p1 = "testOwnStatic"
        p2 = MagicMock()
        p3 = [MagicMock()]
        Lookup.findOwnStatic(p0, p1, p2, p3)

    def test_findOwnStatic_test_8250(self):
        p0 = "testOwnStatic"
        p1 = MagicMock()
        p2 = [MagicMock()]
        c0 = MagicMock()
        instance = Lookup(c0)
        instance.findOwnStatic(p0, p1, p2)


class Lookup:
    def __init__(self, lookup):
        self.lookup = lookup

    def findVirtual(self, p0, p1, p2):
        pass

    def findStatic(self, p0, p1, p2):
        pass

    def unreflect(self, p0):
        pass

    @staticmethod
    def unreflect(p0, p1):
        pass

    @staticmethod
    def unreflectConstructor(p0, p1):
        pass

    def unreflectConstructor(self, p0):
        pass

    def findSpecial(self, p0, p1, p2):
        pass

    def findGetter(self, p0, p1, p2):
        pass

    def unreflectGetter(self, p0):
        pass

    def unreflectSetter(self, p0):
        pass

    def findOwnSpecial(self, p0, p1, p2):
        pass

    @staticmethod
    def findOwnSpecial(p0, p1, p2, p3):
        pass

    @staticmethod
    def findOwnStatic(p0, p1, p2, p3):
        pass

    def findOwnStatic(self, p0, p1, p2):
        pass

if __name__ == '__main__':
    unittest.main()