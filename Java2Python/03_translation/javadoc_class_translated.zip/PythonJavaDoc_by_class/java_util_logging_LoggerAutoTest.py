import unittest
import logging


class TestJavaUtilLoggingLoggerAutoTest(unittest.TestCase):
    def getLogger_test_8104(self, p0):
        logging.getLogger(p0)

    def getLogger_test_8105(self, p0, p1):
        logging.getLogger(p0)

    def getAnonymousLogger_test_8106(self):
        logging.getLogger()

    def getAnonymousLogger_test_8107(self, p0):
        logging.getLogger(p0)

    def getGlobal_test_8108(self):
        logging.getLogger()


class LoggerWrapper:
    @staticmethod
    def getLogger(name):
        return logging.getLogger(name)

    @staticmethod
    def getAnonymousLogger():
        return logging.getLogger()

    @staticmethod
    def getGlobal():
        return logging.getLogger()


if __name__ == '__main__':
    unittest.main()