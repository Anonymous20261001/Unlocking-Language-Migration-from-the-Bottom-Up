import unittest
from unittest.mock import patch, MagicMock
import security_wrapper

class TestJavaSecuritySecurityAutoTest(unittest.TestCase):
    
    def test_getProperty_test_10968(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_property') as mock_method:
            security_wrapper.SecurityWrapper.get_property("key")
            mock_method.assert_called_once_with("key")
    
    def test_setProperty_test_10969(self):
        with patch.object(security_wrapper.SecurityWrapper, 'set_property') as mock_method:
            security_wrapper.SecurityWrapper.set_property("key", "value")
            mock_method.assert_called_once_with("key", "value")
    
    def test_addProvider_test_10970(self):
        with patch.object(security_wrapper.SecurityWrapper, 'add_provider') as mock_method:
            provider = MagicMock()
            security_wrapper.SecurityWrapper.add_provider(provider)
            mock_method.assert_called_once_with(provider)
    
    def test_insertProviderAt_test_10971(self):
        with patch.object(security_wrapper.SecurityWrapper, 'insert_provider_at') as mock_method:
            provider = MagicMock()
            security_wrapper.SecurityWrapper.insert_provider_at(provider, 1)
            mock_method.assert_called_once_with(provider, 1)
    
    def test_getProvider_test_10972(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_provider') as mock_method:
            security_wrapper.SecurityWrapper.get_provider("name")
            mock_method.assert_called_once_with("name")
    
    def test_getProviders_test_10973(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_providers') as mock_method:
            security_wrapper.SecurityWrapper.get_providers()
            mock_method.assert_called_once_with()
    
    def test_getProviders_test_10974(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_providers') as mock_method:
            providers_map = MagicMock()
            security_wrapper.SecurityWrapper.get_providers(providers_map)
            mock_method.assert_called_once_with(providers_map)
    
    def test_getProviders_test_10975(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_providers') as mock_method:
            security_wrapper.SecurityWrapper.get_providers("filter")
            mock_method.assert_called_once_with("filter")
    
    def test_getAlgorithmProperty_test_10976(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_algorithm_property') as mock_method:
            security_wrapper.SecurityWrapper.get_algorithm_property("alg", "prop")
            mock_method.assert_called_once_with("alg", "prop")
    
    def test_removeProvider_test_10977(self):
        with patch.object(security_wrapper.SecurityWrapper, 'remove_provider') as mock_method:
            security_wrapper.SecurityWrapper.remove_provider("name")
            mock_method.assert_called_once_with("name")
    
    def test_getAlgorithms_test_10978(self):
        with patch.object(security_wrapper.SecurityWrapper, 'get_algorithms') as mock_method:
            security_wrapper.SecurityWrapper.get_algorithms("service")
            mock_method.assert_called_once_with("service")


class SecurityWrapper:
    @staticmethod
    def get_property(key):
        pass
    
    @staticmethod
    def set_property(key, value):
        pass
    
    @staticmethod
    def add_provider(provider):
        pass
    
    @staticmethod
    def insert_provider_at(provider, position):
        pass
    
    @staticmethod
    def get_provider(name):
        pass
    
    @staticmethod
    def get_providers(*args):
        pass
    
    @staticmethod
    def get_algorithm_property(alg, prop):
        pass
    
    @staticmethod
    def remove_provider(name):
        pass
    
    @staticmethod
    def get_algorithms(service):
        pass


if __name__ == '__main__':
    unittest.main()