import unittest
from javax.swing import JComponent
from javax.swing.plaf import ComponentUI

class TestComponentUI(unittest.TestCase):
    
    def test_createUI_test_2673(self):
        p0 = JComponent()
        ComponentUI.createUI(p0)
    
    def test_createUI_test_2673_2(self):
        p0 = JComponent()
        ComponentUI.createUI(p0)
    
    def test_createUI_test_2673_3(self):
        p0 = JComponent()
        ComponentUI.createUI(p0)
    
    def test_createUI_test_2673_4(self):
        p0 = JComponent()
        ComponentUI.createUI(p0)
    
    def test_createUI_test_2673_5(self):
        p0 = JComponent()
        ComponentUI.createUI(p0)

class ComponentUIWrapper:
    @staticmethod
    def createUI(component):
        ComponentUI.createUI(component)