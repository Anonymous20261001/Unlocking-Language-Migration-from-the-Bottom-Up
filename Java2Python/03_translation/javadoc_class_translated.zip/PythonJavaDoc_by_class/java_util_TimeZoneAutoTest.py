import unittest
from datetime import timezone, timedelta


class TestJavaUtilTimeZone(unittest.TestCase):

    def test_getDefault_test_12901(self):
        TimeZone.getDefault()

    def test_getTimeZone_test_12902(self):
        p0 = "America/New_York"
        TimeZone.getTimeZone(p0)

    def test_getTimeZone_test_12903(self):
        p0 = timezone(timedelta(hours=-5))
        TimeZone.getTimeZone(p0)

    def test_setDefault_test_12904(self):
        p0 = TimeZone()
        TimeZone.setDefault(p0)

    def test_getAvailableIDs_test_12905(self):
        TimeZone.getAvailableIDs()

    def test_getAvailableIDs_test_12906(self):
        p0 = -5
        TimeZone.getAvailableIDs(p0)

    def test_availableIDs_test_12907(self):
        p0 = -5
        TimeZone.availableIDs(p0)

    def test_availableIDs_test_12908(self):
        TimeZone.availableIDs()


class TimeZone:
    _default = None
    _available_ids = ["UTC", "GMT", "America/New_York", "Europe/London"]

    @classmethod
    def getDefault(cls):
        if cls._default is None:
            cls._default = cls()
        return cls._default

    @classmethod
    def getTimeZone(cls, p0):
        if isinstance(p0, str):
            if p0 in cls._available_ids:
                return cls()
            return cls()
        elif isinstance(p0, timezone):
            return cls()
        return cls()

    @classmethod
    def setDefault(cls, p0):
        cls._default = p0

    @classmethod
    def getAvailableIDs(cls, p0=None):
        if p0 is not None:
            return [tz for tz in cls._available_ids if tz.startswith("GMT") or "UTC" in tz]
        return cls._available_ids

    @classmethod
    def availableIDs(cls, p0=None):
        if p0 is not None:
            return [tz for tz in cls._available_ids if tz.startswith("GMT") or "UTC" in tz]
        return cls._available_ids


if __name__ == "__main__":
    unittest.main()