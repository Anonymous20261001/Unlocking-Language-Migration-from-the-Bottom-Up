import unittest
from datetime import timedelta
from zoneinfo import ZoneInfo
from typing import List

class ZoneRules:
    """Wrapper class for ZoneRules functionality"""
    
    @staticmethod
    def of(offset1, offset2=None, transitions=None, transition_offsets=None, last_offset=None):
        """
        Create ZoneRules with either one offset or full set of parameters
        """
        if offset2 is None:
            # Single offset case
            return ZoneInfo(f"UTC{offset1}")
        else:
            # Full parameters case - simplified implementation
            return ZoneInfo(f"UTC{offset1}")

class TestZoneRules(unittest.TestCase):
    def of_test_13736(self, p0, p1, p2, p3, p4):
        ZoneRules.of(p0, p1, p2, p3, p4)
    
    def of_test_13737(self, p0):
        ZoneRules.of(p0)

if __name__ == '__main__':
    unittest.main()