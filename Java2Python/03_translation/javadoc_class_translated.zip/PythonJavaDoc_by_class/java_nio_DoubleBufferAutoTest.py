import unittest
import array


class TestJavaNioDoubleBuffer(unittest.TestCase):

    def test_wrap_test_4265(self):
        p0 = array.array('d', [1.0, 2.0, 3.0])
        DoubleBufferWrapper.wrap(p0)

    def test_wrap_test_4266(self):
        p0 = array.array('d', [1.0, 2.0, 3.0, 4.0])
        p1 = 1
        p2 = 2
        DoubleBufferWrapper.wrap(p0, p1, p2)

    def test_allocate_test_4267(self):
        p0 = 10
        DoubleBufferWrapper.allocate(p0)


class DoubleBufferWrapper:
    """Wrapper class simulating java.nio.DoubleBuffer static methods."""

    @staticmethod
    def wrap(array_data, offset=0, length=None):
        """Simulates DoubleBuffer.wrap() - returns a buffer-like object."""
        if length is None:
            length = len(array_data) - offset
        # Return a memoryview or a simple representation
        return memoryview(array_data)[offset:offset + length]

    @staticmethod
    def allocate(capacity):
        """Simulates DoubleBuffer.allocate() - returns a zeroed buffer."""
        return array.array('d', [0.0] * capacity)


if __name__ == '__main__':
    unittest.main()