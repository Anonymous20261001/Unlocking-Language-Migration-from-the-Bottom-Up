import unittest
from typing import List

class Role:
    def __init__(self, role_name: str, role_value: List):
        self.role_name = role_name
        self.role_value = role_value

    def setRoleName(self, role_name: str):
        self.role_name = role_name

    def setRoleValue(self, role_value: List):
        self.role_value = role_value

    def getRoleName(self) -> str:
        return self.role_name

    def getRoleValue(self) -> List:
        return self.role_value

    @staticmethod
    def roleValueToString(role_value: List) -> str:
        return str(role_value)


class TestJavaxManagementRelationRoleAutoTest(unittest.TestCase):
    def setUp(self):
        self.c0 = "test_role"
        self.c1 = ["value1", "value2"]
        self.instance = Role(self.c0, self.c1)

    def test_setRoleName_test_10640(self):
        p0 = "new_role_name"
        self.instance.setRoleName(p0)
        self.assertEqual(self.instance.getRoleName(), p0)

    def test_setRoleValue_test_10641(self):
        p0 = ["new_value1", "new_value2"]
        self.instance.setRoleValue(p0)
        self.assertEqual(self.instance.getRoleValue(), p0)

    def test_getRoleName_test_10642(self):
        result = self.instance.getRoleName()
        self.assertEqual(result, self.c0)

    def test_getRoleValue_test_10643(self):
        result = self.instance.getRoleValue()
        self.assertEqual(result, self.c1)

    def test_roleValueToString_test_10644(self):
        p0 = ["value1", "value2"]
        result = Role.roleValueToString(p0)
        self.assertEqual(result, str(p0))


if __name__ == '__main__':
    unittest.main()