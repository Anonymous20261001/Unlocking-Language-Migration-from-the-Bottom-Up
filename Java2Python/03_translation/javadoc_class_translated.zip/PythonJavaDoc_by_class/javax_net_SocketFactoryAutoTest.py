import unittest
from unittest.mock import Mock, patch
import socket

class TestSocketFactory(unittest.TestCase):
    def test_getDefault_test_11262(self):
        with patch('socket.socket') as mock_socket:
            SocketFactoryWrapper.getDefault()
            mock_socket.assert_called_once()

class SocketFactoryWrapper:
    @staticmethod
    def getDefault():
        return socket.socket()