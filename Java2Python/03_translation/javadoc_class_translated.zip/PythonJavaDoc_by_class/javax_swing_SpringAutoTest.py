import unittest
from typing import Optional


class TestSpringAuto(unittest.TestCase):
    def test_height_test_11360(self):
        component = Component()
        Spring.height(component)

    def test_max_test_11361(self):
        spring1 = Spring()
        spring2 = Spring()
        Spring.max(spring1, spring2)

    def test_scale_test_11362(self):
        spring = Spring()
        Spring.scale(spring, 1.5)

    def test_constant_test_11363(self):
        Spring.constant(10)

    def test_constant_test_11364(self):
        Spring.constant(10, 20, 30)

    def test_sum_test_11365(self):
        spring1 = Spring()
        spring2 = Spring()
        Spring.sum(spring1, spring2)

    def test_width_test_11366(self):
        component = Component()
        Spring.width(component)

    def test_minus_test_11367(self):
        spring = Spring()
        Spring.minus(spring)


class Component:
    pass


class Spring:
    @staticmethod
    def height(component: Component) -> Optional[Spring]:
        return None

    @staticmethod
    def max(spring1: Spring, spring2: Spring) -> Optional[Spring]:
        return None

    @staticmethod
    def scale(spring: Spring, factor: float) -> Optional[Spring]:
        return None

    @staticmethod
    def constant(value: int, min_value: Optional[int] = None, max_value: Optional[int] = None) -> Spring:
        return Spring()

    @staticmethod
    def sum(spring1: Spring, spring2: Spring) -> Optional[Spring]:
        return None

    @staticmethod
    def width(component: Component) -> Optional[Spring]:
        return None

    @staticmethod
    def minus(spring: Spring) -> Optional[Spring]:
        return None


if __name__ == '__main__':
    unittest.main()