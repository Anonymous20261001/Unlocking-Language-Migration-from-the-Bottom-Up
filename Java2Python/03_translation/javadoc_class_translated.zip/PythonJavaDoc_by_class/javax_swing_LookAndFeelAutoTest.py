import unittest
from javax.swing import LookAndFeel, JComponent, InputMap
from java.lang import Class, Object, String

class TestJavaxSwingLookAndFeel(unittest.TestCase):
    def test_makeIcon_test_8226(self, p0: Class, p1: String):
        LookAndFeel.makeIcon(p0, p1)
    
    def test_makeComponentInputMap_test_8227(self, p0: JComponent, p1: list):
        LookAndFeel.makeComponentInputMap(p0, p1)
    
    def test_installProperty_test_8228(self, p0: JComponent, p1: String, p2: Object):
        LookAndFeel.installProperty(p0, p1, p2)
    
    def test_installColors_test_8229(self, p0: JComponent, p1: String, p2: String):
        LookAndFeel.installColors(p0, p1, p2)
    
    def test_loadKeyBindings_test_8230(self, p0: InputMap, p1: list):
        LookAndFeel.loadKeyBindings(p0, p1)
    
    def test_makeKeyBindings_test_8231(self, p0: list):
        LookAndFeel.makeKeyBindings(p0)
    
    def test_makeInputMap_test_8232(self, p0: list):
        LookAndFeel.makeInputMap(p0)
    
    def test_getDesktopPropertyValue_test_8233(self, p0: String, p1: Object):
        LookAndFeel.getDesktopPropertyValue(p0, p1)
    
    def test_installColorsAndFont_test_8234(self, p0: JComponent, p1: String, p2: String, p3: String):
        LookAndFeel.installColorsAndFont(p0, p1, p2, p3)
    
    def test_installBorder_test_8235(self, p0: JComponent, p1: String):
        LookAndFeel.installBorder(p0, p1)
    
    def test_uninstallBorder_test_8236(self, p0: JComponent):
        LookAndFeel.uninstallBorder(p0)

class LookAndFeelWrapper:
    @staticmethod
    def makeIcon(p0: Class, p1: String):
        pass
    
    @staticmethod
    def makeComponentInputMap(p0: JComponent, p1: list):
        pass
    
    @staticmethod
    def installProperty(p0: JComponent, p1: String, p2: Object):
        pass
    
    @staticmethod
    def installColors(p0: JComponent, p1: String, p2: String):
        pass
    
    @staticmethod
    def loadKeyBindings(p0: InputMap, p1: list):
        pass
    
    @staticmethod
    def makeKeyBindings(p0: list):
        pass
    
    @staticmethod
    def makeInputMap(p0: list):
        pass
    
    @staticmethod
    def getDesktopPropertyValue(p0: String, p1: Object):
        pass
    
    @staticmethod
    def installColorsAndFont(p0: JComponent, p1: String, p2: String, p3: String):
        pass
    
    @staticmethod
    def installBorder(p0: JComponent, p1: String):
        pass
    
    @staticmethod
    def uninstallBorder(p0: JComponent):
        pass

if __name__ == '__main__':
    unittest.main()