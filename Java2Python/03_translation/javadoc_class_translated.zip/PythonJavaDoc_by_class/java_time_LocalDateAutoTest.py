import unittest
from datetime import datetime, date, timezone
from zoneinfo import ZoneInfo
from enum import Enum
from typing import Any


class Month(Enum):
    JANUARY = 1
    FEBRUARY = 2
    MARCH = 3
    APRIL = 4
    MAY = 5
    JUNE = 6
    JULY = 7
    AUGUST = 8
    SEPTEMBER = 9
    OCTOBER = 10
    NOVEMBER = 11
    DECEMBER = 12


class LocalDate:
    @staticmethod
    def of(year: int, month: int, day: int) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def of_year_month(year: int, month: Month, day: int) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def from(temporal_accessor: Any) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def parse(text: str, formatter: Any = None) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def now(clock: Any = None) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def of_instant(instant: Any, zone: Any) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def of_epoch_day(epoch_day: int) -> 'LocalDate':
        return LocalDate()
    
    @staticmethod
    def of_year_day(year: int, day_of_year: int) -> 'LocalDate':
        return LocalDate()


class TestLocalDate(unittest.TestCase):
    def test_of_test_7988(self):
        LocalDate.of(2023, 1, 15)
    
    def test_of_test_7989(self):
        LocalDate.of_year_month(2023, Month.JANUARY, 15)
    
    def test_from_test_7990(self):
        LocalDate.from(datetime.now())
    
    def test_parse_test_7991(self):
        LocalDate.parse("2023-01-15")
    
    def test_parse_test_7992(self):
        LocalDate.parse("2023-01-15", None)
    
    def test_now_test_7993(self):
        LocalDate.now()
    
    def test_now_test_7994(self):
        LocalDate.now(datetime.now().astimezone())
    
    def test_now_test_7995(self):
        LocalDate.now(ZoneInfo("UTC"))
    
    def test_of_instant_test_7996(self):
        LocalDate.of_instant(datetime.now(), ZoneInfo("UTC"))
    
    def test_of_epoch_day_test_7997(self):
        LocalDate.of_epoch_day(0)
    
    def test_of_year_day_test_7998(self):
        LocalDate.of_year_day(2023, 15)


if __name__ == '__main__':
    unittest.main()