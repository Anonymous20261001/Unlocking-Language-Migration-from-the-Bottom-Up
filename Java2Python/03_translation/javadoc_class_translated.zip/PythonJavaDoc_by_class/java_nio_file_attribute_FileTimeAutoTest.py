import unittest
import time
from datetime import datetime, timezone


class TestFileTime(unittest.TestCase):
    def from_test_4782(self, p0):
        FileTime.from_instant(p0)

    def from_test_4783(self, p0, p1):
        FileTime.from_timeunit(p0, p1)

    def fromMillis_test_4784(self, p0):
        FileTime.from_millis(p0)


class FileTime:
    @staticmethod
    def from_instant(instant):
        return FileTime(instant.timestamp() * 1000)

    @staticmethod
    def from_timeunit(value, timeunit):
        if timeunit == 'NANOSECONDS':
            return FileTime(value / 1_000_000)
        elif timeunit == 'MICROSECONDS':
            return FileTime(value / 1000)
        elif timeunit == 'MILLISECONDS':
            return FileTime(value)
        elif timeunit == 'SECONDS':
            return FileTime(value * 1000)
        elif timeunit == 'MINUTES':
            return FileTime(value * 60 * 1000)
        elif timeunit == 'HOURS':
            return FileTime(value * 3600 * 1000)
        elif timeunit == 'DAYS':
            return FileTime(value * 86400 * 1000)
        else:
            raise ValueError(f"Unsupported time unit: {timeunit}")

    @staticmethod
    def from_millis(millis):
        return FileTime(millis)

    def __init__(self, millis):
        self.millis = millis

    def to_millis(self):
        return self.millis


if __name__ == '__main__':
    unittest.main()