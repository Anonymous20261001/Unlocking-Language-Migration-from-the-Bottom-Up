import unittest
from typing import Any


class TestJLabel(unittest.TestCase):
    def test_getDisplayedMnemonic_test_6349(self):
        instance = JLabel()
        instance.getDisplayedMnemonic()

    def test_setDisplayedMnemonic_test_6350(self):
        p0 = 0
        instance = JLabel()
        instance.setDisplayedMnemonic(p0)

    def test_setDisplayedMnemonic_test_6351(self):
        p0 = 'a'
        instance = JLabel()
        instance.setDisplayedMnemonic(p0)

    def test_getLabelFor_test_6352(self):
        instance = JLabel()
        instance.getLabelFor()

    def test_setLabelFor_test_6353(self):
        p0 = Component()
        instance = JLabel()
        instance.setLabelFor(p0)

    def test_getUIClassID_test_6354(self):
        instance = JLabel()
        instance.getUIClassID()

    def test_updateUI_test_6355(self):
        instance = JLabel()
        instance.updateUI()

    def test_getUI_test_6356(self):
        instance = JLabel()
        instance.getUI()

    def test_setUI_test_6357(self):
        p0 = LabelUI()
        instance = JLabel()
        instance.setUI(p0)

    def test_getAccessibleContext_test_6358(self):
        instance = JLabel()
        instance.getAccessibleContext()

    def test_imageUpdate_test_6359(self):
        p0 = Image()
        p1 = 0
        p2 = 0
        p3 = 0
        p4 = 0
        p5 = 0
        instance = JLabel()
        instance.imageUpdate(p0, p1, p2, p3, p4, p5)

    def test_getIcon_test_6360(self):
        instance = JLabel()
        instance.getIcon()

    def test_getDisabledIcon_test_6361(self):
        instance = JLabel()
        instance.getDisabledIcon()

    def test_setDisplayedMnemonicIndex_test_6362(self):
        p0 = 0
        instance = JLabel()
        instance.setDisplayedMnemonicIndex(p0)

    def test_setText_test_6363(self):
        p0 = "text"
        instance = JLabel()
        instance.setText(p0)

    def test_setIcon_test_6364(self):
        p0 = Icon()
        instance = JLabel()
        instance.setIcon(p0)

    def test_setDisabledIcon_test_6365(self):
        p0 = Icon()
        instance = JLabel()
        instance.setDisabledIcon(p0)

    def test_setIconTextGap_test_6366(self):
        p0 = 0
        instance = JLabel()
        instance.setIconTextGap(p0)

    def test_getVerticalAlignment_test_6367(self):
        instance = JLabel()
        instance.getVerticalAlignment()

    def test_setVerticalAlignment_test_6368(self):
        p0 = 0
        instance = JLabel()
        instance.setVerticalAlignment(p0)

    def test_getHorizontalAlignment_test_6369(self):
        instance = JLabel()
        instance.getHorizontalAlignment()

    def test_setHorizontalAlignment_test_6370(self):
        p0 = 0
        instance = JLabel()
        instance.setHorizontalAlignment(p0)

    def test_getVerticalTextPosition_test_6371(self):
        instance = JLabel()
        instance.getVerticalTextPosition()

    def test_setVerticalTextPosition_test_6372(self):
        p0 = 0
        instance = JLabel()
        instance.setVerticalTextPosition(p0)

    def test_getHorizontalTextPosition_test_6373(self):
        instance = JLabel()
        instance.getHorizontalTextPosition()

    def test_setHorizontalTextPosition_test_6374(self):
        p0 = 0
        instance = JLabel()
        instance.setHorizontalTextPosition(p0)

    def test_getIconTextGap_test_6375(self):
        instance = JLabel()
        instance.getIconTextGap()

    def test_getDisplayedMnemonicIndex_test_6376(self):
        instance = JLabel()
        instance.getDisplayedMnemonicIndex()

    def test_getText_test_6377(self):
        instance = JLabel()
        instance.getText()


class Component:
    pass


class Image:
    pass


class Icon:
    pass


class LabelUI:
    pass


class JLabel:
    def __init__(self):
        self.displayed_mnemonic = None
        self.label_for = None
        self.ui = None
        self.icon = None
        self.disabled_icon = None
        self.displayed_mnemonic_index = None
        self.text = None
        self.icon_text_gap = None
        self.vertical_alignment = None
        self.horizontal_alignment = None
        self.vertical_text_position = None
        self.horizontal_text_position = None

    def getDisplayedMnemonic(self):
        return self.displayed_mnemonic

    def setDisplayedMnemonic(self, p0):
        self.displayed_mnemonic = p0

    def getLabelFor(self):
        return self.label_for

    def setLabelFor(self, p0):
        self.label_for = p0

    def getUIClassID(self):
        return "LabelUI"

    def updateUI(self):
        pass

    def getUI(self):
        return self.ui

    def setUI(self, p0):
        self.ui = p0

    def getAccessibleContext(self):
        return None

    def imageUpdate(self, p0, p1, p2, p3, p4, p5):
        return False

    def getIcon(self):
        return self.icon

    def getDisabledIcon(self):
        return self.disabled_icon

    def setDisplayedMnemonicIndex(self, p0):
        self.displayed_mnemonic_index = p0

    def setText(self, p0):
        self.text = p0

    def setIcon(self, p0):
        self.icon = p0

    def setDisabledIcon(self, p0):
        self.disabled_icon = p0

    def setIconTextGap(self, p0):
        self.icon_text_gap = p0

    def getVerticalAlignment(self):
        return self.vertical_alignment

    def setVerticalAlignment(self, p0):
        self.vertical_alignment = p0

    def getHorizontalAlignment(self):
        return self.horizontal_alignment

    def setHorizontalAlignment(self, p0):
        self.horizontal_alignment = p0

    def getVerticalTextPosition(self):
        return self.vertical_text_position

    def setVerticalTextPosition(self, p0):
        self.vertical_text_position = p0

    def getHorizontalTextPosition(self):
        return self.horizontal_text_position

    def setHorizontalTextPosition(self, p0):
        self.horizontal_text_position = p0

    def getIconTextGap(self):
        return self.icon_text_gap

    def getDisplayedMnemonicIndex(self):
        return self.displayed_mnemonic_index

    def getText(self):
        return self.text


if __name__ == '__main__':
    unittest.main()