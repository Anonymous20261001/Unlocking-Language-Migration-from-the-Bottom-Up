import unittest

class FailOverExecutionControlProvider:
    def name(self):
        pass

    def defaultParameters(self):
        pass


class TestFailOverExecutionControlProvider(unittest.TestCase):
    def name_test_4672(self):
        instance = FailOverExecutionControlProvider()
        instance.name()

    def defaultParameters_test_4673(self):
        instance = FailOverExecutionControlProvider()
        instance.defaultParameters()


if __name__ == '__main__':
    unittest.main()