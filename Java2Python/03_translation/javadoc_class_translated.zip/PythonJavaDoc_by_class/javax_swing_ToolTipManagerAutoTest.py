import unittest
import javax.swing.ToolTipManager

class TestJavaxSwingToolTipManagerAutoTest(unittest.TestCase):
    def test_sharedInstance_test_12932(self):
        ToolTipManager.sharedInstance()

if __name__ == '__main__':
    unittest.main()

class ToolTipManagerWrapper:
    @staticmethod
    def sharedInstance():
        return ToolTipManager.sharedInstance()