import unittest
from javax.naming.ldap import Rdn

class TestJavaxNamingLdapRdn(unittest.TestCase):
    def escapeValue_test_10344(self, p0):
        Rdn.escapeValue(p0)

    def unescapeValue_test_10345(self, p0):
        Rdn.unescapeValue(p0)


class RdnWrapper:
    @staticmethod
    def escapeValue(value):
        return Rdn.escapeValue(value)

    @staticmethod
    def unescapeValue(value):
        return Rdn.unescapeValue(value)