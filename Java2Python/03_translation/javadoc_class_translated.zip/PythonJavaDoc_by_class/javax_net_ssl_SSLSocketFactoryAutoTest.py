import unittest
import ssl

class TestSSLSocketFactory(unittest.TestCase):
    def test_getDefault_test_11440(self):
        ssl.SSLContext.create_default_context()
        ssl.SSLSocketFactory.getDefault()

# Wrapper class for SSLSocketFactory
class SSLSocketFactory:
    @staticmethod
    def getDefault():
        return ssl.SSLContext.create_default_context()

if __name__ == '__main__':
    unittest.main()