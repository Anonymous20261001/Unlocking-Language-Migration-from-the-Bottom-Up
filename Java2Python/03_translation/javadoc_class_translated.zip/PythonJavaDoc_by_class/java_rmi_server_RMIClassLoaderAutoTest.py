import unittest
import java.lang.Class
import java.lang.ClassLoader
from java.rmi.server import RMIClassLoader

class TestRMIClassLoaderAuto(unittest.TestCase):
    def test_getClassAnnotation_test_10630(self, p0):
        RMIClassLoader.getClassAnnotation(p0)

    def test_getDefaultProviderInstance_test_10631(self):
        RMIClassLoader.getDefaultProviderInstance()

    def test_getSecurityContext_test_10632(self, p0):
        RMIClassLoader.getSecurityContext(p0)


class RMIClassLoaderWrapper:
    @staticmethod
    def getClassAnnotation(p0):
        return RMIClassLoader.getClassAnnotation(p0)

    @staticmethod
    def getDefaultProviderInstance():
        return RMIClassLoader.getDefaultProviderInstance()

    @staticmethod
    def getSecurityContext(p0):
        return RMIClassLoader.getSecurityContext(p0)


if __name__ == '__main__':
    unittest.main()