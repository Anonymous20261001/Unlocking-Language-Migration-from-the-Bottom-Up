import unittest
from unittest.mock import MagicMock
from typing import List, Any


class TestJavaxSwingTransferHandlerTransferSupportAutoTest(unittest.TestCase):

    def test_getTransferable_test_12948(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getTransferable()

    def test_getDataFlavors_test_12949(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getDataFlavors()

    def test_getDropLocation_test_12950(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getDropLocation()

    def test_isDrop_test_12951(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.isDrop()

    def test_getDropAction_test_12952(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getDropAction()

    def test_getSourceDropActions_test_12953(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getSourceDropActions()

    def test_getUserDropAction_test_12954(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getUserDropAction()

    def test_setShowDropLocation_test_12955(self):
        p0 = True
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.setShowDropLocation(p0)

    def test_setDropAction_test_12956(self):
        p0 = 1
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.setDropAction(p0)

    def test_isDataFlavorSupported_test_12957(self):
        p0 = MagicMock()
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.isDataFlavorSupported(p0)

    def test_getComponent_test_12958(self):
        c0 = MagicMock()
        c1 = MagicMock()
        instance = TransferSupport(c0, c1)
        instance.getComponent()


class TransferSupport:
    """Wrapper class for TransferHandler.TransferSupport"""

    def __init__(self, component, transferable):
        self.component = component
        self.transferable = transferable
        self.drop_location = None
        self.is_drop = False
        self.drop_action = 0
        self.source_drop_actions = 0
        self.user_drop_action = 0
        self.show_drop_location = False

    def getTransferable(self):
        return self.transferable

    def getDataFlavors(self):
        return []

    def getDropLocation(self):
        return self.drop_location

    def isDrop(self):
        return self.is_drop

    def getDropAction(self):
        return self.drop_action

    def getSourceDropActions(self):
        return self.source_drop_actions

    def getUserDropAction(self):
        return self.user_drop_action

    def setShowDropLocation(self, show):
        self.show_drop_location = show

    def setDropAction(self, action):
        self.drop_action = action

    def isDataFlavorSupported(self, flavor):
        return False

    def getComponent(self):
        return self.component


if __name__ == '__main__':
    unittest.main()