import unittest
from unittest.mock import MagicMock
from javax.management import MBeanServer, MBeanServerFactory


class TestJavaxManagementMBeanServerFactory(unittest.TestCase):

    def createMBeanServer_test_8442(self):
        MBeanServerFactory.createMBeanServer()

    def createMBeanServer_test_8443(self, p0):
        MBeanServerFactory.createMBeanServer(p0)

    def newMBeanServer_test_8444(self, p0):
        MBeanServerFactory.newMBeanServer(p0)

    def newMBeanServer_test_8445(self):
        MBeanServerFactory.newMBeanServer()

    def releaseMBeanServer_test_8446(self, p0):
        MBeanServerFactory.releaseMBeanServer(p0)

    def findMBeanServer_test_8447(self, p0):
        MBeanServerFactory.findMBeanServer(p0)

    def getClassLoaderRepository_test_8448(self, p0):
        MBeanServerFactory.getClassLoaderRepository(p0)


class MBeanServerFactoryWrapper:
    """Wrapper class for MBeanServerFactory static methods"""
    
    @staticmethod
    def createMBeanServer(domain=None):
        return MBeanServerFactory.createMBeanServer(domain)
    
    @staticmethod
    def newMBeanServer(domain=None):
        return MBeanServerFactory.newMBeanServer(domain)
    
    @staticmethod
    def releaseMBeanServer(server):
        return MBeanServerFactory.releaseMBeanServer(server)
    
    @staticmethod
    def findMBeanServer(agent_id):
        return MBeanServerFactory.findMBeanServer(agent_id)
    
    @staticmethod
    def getClassLoaderRepository(server):
        return MBeanServerFactory.getClassLoaderRepository(server)


if __name__ == '__main__':
    unittest.main()