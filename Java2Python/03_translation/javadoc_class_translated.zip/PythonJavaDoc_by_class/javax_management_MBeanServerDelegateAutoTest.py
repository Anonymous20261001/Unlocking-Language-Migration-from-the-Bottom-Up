import unittest
from unittest.mock import MagicMock


class TestJavaxManagementMBeanServerDelegateAutoTest(unittest.TestCase):

    def test_getNotificationInfo_test_8432(self):
        instance = MBeanServerDelegateWrapper()
        instance.getNotificationInfo()

    def test_sendNotification_test_8433(self):
        instance = MBeanServerDelegateWrapper()
        p0 = MagicMock()
        instance.sendNotification(p0)

    def test_getMBeanServerId_test_8434(self):
        instance = MBeanServerDelegateWrapper()
        instance.getMBeanServerId()

    def test_getSpecificationName_test_8435(self):
        instance = MBeanServerDelegateWrapper()
        instance.getSpecificationName()

    def test_getImplementationName_test_8436(self):
        instance = MBeanServerDelegateWrapper()
        instance.getImplementationName()

    def test_addNotificationListener_test_8437(self):
        instance = MBeanServerDelegateWrapper()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        instance.addNotificationListener(p0, p1, p2)

    def test_getSpecificationVersion_test_8438(self):
        instance = MBeanServerDelegateWrapper()
        instance.getSpecificationVersion()

    def test_getSpecificationVendor_test_8439(self):
        instance = MBeanServerDelegateWrapper()
        instance.getSpecificationVendor()

    def test_getImplementationVersion_test_8440(self):
        instance = MBeanServerDelegateWrapper()
        instance.getImplementationVersion()

    def test_getImplementationVendor_test_8441(self):
        instance = MBeanServerDelegateWrapper()
        instance.getImplementationVendor()


class MBeanServerDelegateWrapper:
    """Wrapper class to mimic the behavior of MBeanServerDelegate."""

    def __init__(self):
        self._notification_listeners = []
        self._mbean_server_id = "mbean_server_id"
        self._specification_name = "specification_name"
        self._implementation_name = "implementation_name"
        self._specification_version = "1.0"
        self._specification_vendor = "specification_vendor"
        self._implementation_version = "1.0"
        self._implementation_vendor = "implementation_vendor"

    def getNotificationInfo(self):
        return []

    def sendNotification(self, notification):
        for listener, filter, handback in self._notification_listeners:
            if filter is None or filter.isNotificationEnabled(notification):
                listener.handleNotification(notification, handback)

    def getMBeanServerId(self):
        return self._mbean_server_id

    def getSpecificationName(self):
        return self._specification_name

    def getImplementationName(self):
        return self._implementation_name

    def addNotificationListener(self, listener, filter, handback):
        self._notification_listeners.append((listener, filter, handback))

    def getSpecificationVersion(self):
        return self._specification_version

    def getSpecificationVendor(self):
        return self._specification_vendor

    def getImplementationVersion(self):
        return self._implementation_version

    def getImplementationVendor(self):
        return self._implementation_vendor


if __name__ == '__main__':
    unittest.main()