import unittest
from javax.swing import JComponent
from javax.swing.plaf.synth import SynthInternalFrameUI

class TestSynthInternalFrameUI(unittest.TestCase):
    def test_createUI_test_12212(self):
        p0 = JComponent()
        SynthInternalFrameUI.createUI(p0)

# Wrapper class
class SynthInternalFrameUIWrapper:
    @staticmethod
    def createUI(component):
        return SynthInternalFrameUI.createUI(component)

if __name__ == '__main__':
    unittest.main()