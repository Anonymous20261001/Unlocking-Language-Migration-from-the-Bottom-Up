import unittest
from datetime import datetime
from enum import Enum
from typing import Optional


class FormatStyle(Enum):
    SHORT = "SHORT"
    MEDIUM = "MEDIUM"
    LONG = "LONG"
    FULL = "FULL"


class Locale:
    def __init__(self, language: str, country: str = ""):
        self.language = language
        self.country = country

    @classmethod
    def get_default(cls) -> "Locale":
        return cls("en", "US")


class DateTimeFormatter:
    def __init__(self, pattern: Optional[str] = None, locale: Optional[Locale] = None):
        self.pattern = pattern
        self.locale = locale or Locale.get_default()

    @classmethod
    def ofPattern(cls, pattern: str, locale: Optional[Locale] = None) -> "DateTimeFormatter":
        return cls(pattern, locale)

    @classmethod
    def ofLocalizedDate(cls, date_style: FormatStyle) -> "DateTimeFormatter":
        return cls(pattern=f"localized_date_{date_style.value}")

    @classmethod
    def ofLocalizedTime(cls, time_style: FormatStyle) -> "DateTimeFormatter":
        return cls(pattern=f"localized_time_{time_style.value}")

    @classmethod
    def ofLocalizedDateTime(cls, date_style: FormatStyle, time_style: Optional[FormatStyle] = None) -> "DateTimeFormatter":
        if time_style is None:
            return cls(pattern=f"localized_datetime_{date_style.value}")
        return cls(pattern=f"localized_datetime_{date_style.value}_{time_style.value}")

    @classmethod
    def ofLocalizedPattern(cls, pattern: str) -> "DateTimeFormatter":
        return cls(pattern=pattern)

    @classmethod
    def parsedExcessDays(cls) -> object:
        return datetime.timedelta(days=0)

    @classmethod
    def parsedLeapSecond(cls) -> bool:
        return False


class TestDateTimeFormatter(unittest.TestCase):
    def test_ofPattern_test_3355(self):
        DateTimeFormatter.ofPattern("yyyy-MM-dd")

    def test_ofPattern_test_3356(self):
        DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale("en", "US"))

    def test_ofLocalizedDate_test_3357(self):
        DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)

    def test_ofLocalizedTime_test_3358(self):
        DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)

    def test_ofLocalizedDateTime_test_3359(self):
        DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG)

    def test_ofLocalizedDateTime_test_3360(self):
        DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT, FormatStyle.MEDIUM)

    def test_ofLocalizedPattern_test_3361(self):
        DateTimeFormatter.ofLocalizedPattern("yyyy-MM-dd")

    def test_parsedExcessDays_test_3362(self):
        DateTimeFormatter.parsedExcessDays()

    def test_parsedLeapSecond_test_3363(self):
        DateTimeFormatter.parsedLeapSecond()


if __name__ == "__main__":
    unittest.main()