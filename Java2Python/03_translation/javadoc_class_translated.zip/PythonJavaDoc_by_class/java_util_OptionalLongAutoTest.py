import unittest

class TestOptionalLongAutoTest(unittest.TestCase):
    def of_test_9696(self, p0):
        OptionalLong.of(p0)

    def empty_test_9697(self):
        OptionalLong.empty()


class OptionalLong:
    @staticmethod
    def of(value):
        return OptionalLong(value)

    @staticmethod
    def empty():
        return OptionalLong(None)

    def __init__(self, value):
        self._value = value

    def is_present(self):
        return self._value is not None

    def get_as_long(self):
        if self._value is None:
            raise ValueError("No value present")
        return self._value

    def if_present(self, consumer):
        if self._value is not None:
            consumer(self._value)

    def or_else(self, other):
        return self._value if self._value is not None else other

    def or_else_get(self, supplier):
        return self._value if self._value is not None else supplier()

    def or_else_throw(self, exception_supplier):
        if self._value is None:
            raise exception_supplier()
        return self._value

    def __eq__(self, other):
        if not isinstance(other, OptionalLong):
            return False
        return self._value == other._value

    def __hash__(self):
        return hash(self._value)

    def __str__(self):
        return f"OptionalLong[{self._value}]" if self._value is not None else "OptionalLong.empty"