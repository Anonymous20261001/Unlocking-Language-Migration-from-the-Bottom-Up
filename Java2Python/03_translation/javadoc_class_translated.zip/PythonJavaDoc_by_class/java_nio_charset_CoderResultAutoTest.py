import unittest

class TestCoderResult(unittest.TestCase):
    def malformedForLength_test_2338(self, p0):
        CoderResult.malformedForLength(p0)

    def unmappableForLength_test_2339(self, p0):
        CoderResult.unmappableForLength(p0)

class CoderResult:
    @staticmethod
    def malformedForLength(length):
        return CoderResult(1, length)
    
    @staticmethod
    def unmappableForLength(length):
        return CoderResult(2, length)
    
    def __init__(self, type, length):
        self.type = type
        self.length = length
    
    def isError(self):
        return self.type != 0
    
    def isMalformed(self):
        return self.type == 1
    
    def isUnmappable(self):
        return self.type == 2
    
    def length(self):
        return self.length
    
    def toString(self):
        if self.type == 1:
            return f"Malformed[{self.length}]"
        elif self.type == 2:
            return f"Unmappable[{self.length}]"
        else:
            return "UNDEFINED"