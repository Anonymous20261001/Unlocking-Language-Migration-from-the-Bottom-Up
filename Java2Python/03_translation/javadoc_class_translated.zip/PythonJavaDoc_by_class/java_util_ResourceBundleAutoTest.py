import unittest
from unittest.mock import MagicMock, patch
import locale
from types import ModuleType


class TestResourceBundle(unittest.TestCase):
    def test_getBundle_test_10610(self):
        p0 = "test"
        p1 = locale.Locale("en", "US")
        ResourceBundleWrapper.getBundle(p0, p1)

    def test_getBundle_test_10611(self):
        p0 = "test"
        p1 = ModuleType("test_module")
        ResourceBundleWrapper.getBundle(p0, p1)

    def test_getBundle_test_10612(self):
        p0 = "test"
        p1 = ResourceBundle.Control()
        ResourceBundleWrapper.getBundle(p0, p1)

    def test_getBundle_test_10613(self):
        p0 = "test"
        ResourceBundleWrapper.getBundle(p0)

    def test_getBundle_test_10614(self):
        p0 = "test"
        p1 = locale.Locale("en", "US")
        p2 = MagicMock()
        ResourceBundleWrapper.getBundle(p0, p1, p2)

    def test_getBundle_test_10615(self):
        p0 = "test"
        p1 = locale.Locale("en", "US")
        p2 = MagicMock()
        p3 = ResourceBundle.Control()
        ResourceBundleWrapper.getBundle(p0, p1, p2, p3)

    def test_getBundle_test_10616(self):
        p0 = "test"
        p1 = locale.Locale("en", "US")
        p2 = ResourceBundle.Control()
        ResourceBundleWrapper.getBundle(p0, p1, p2)

    def test_getBundle_test_10617(self):
        p0 = "test"
        p1 = locale.Locale("en", "US")
        p2 = ModuleType("test_module")
        ResourceBundleWrapper.getBundle(p0, p1, p2)

    def test_clearCache_test_10618(self):
        p0 = MagicMock()
        ResourceBundleWrapper.clearCache(p0)

    def test_clearCache_test_10619(self):
        ResourceBundleWrapper.clearCache()


class ResourceBundleWrapper:
    @staticmethod
    def getBundle(*args):
        pass

    @staticmethod
    def clearCache(*args):
        pass


if __name__ == "__main__":
    unittest.main()