import unittest


class TestDescriptorSupport(unittest.TestCase):
    def test_getFieldNames_test_4099(self):
        instance = DescriptorSupport()
        instance.getFieldNames()

    def test_getFieldValues_test_4100(self, p0=None):
        instance = DescriptorSupport()
        instance.getFieldValues(p0)

    def test_setField_test_4101(self, p0=None, p1=None):
        instance = DescriptorSupport()
        instance.setField(p0, p1)

    def test_getFieldValue_test_4102(self, p0=None):
        instance = DescriptorSupport()
        instance.getFieldValue(p0)

    def test_removeField_test_4103(self, p0=None):
        instance = DescriptorSupport()
        instance.removeField(p0)

    def test_toXMLString_test_4104(self):
        instance = DescriptorSupport()
        instance.toXMLString()

    def test_getFields_test_4105(self):
        instance = DescriptorSupport()
        instance.getFields()

    def test_isValid_test_4106(self):
        instance = DescriptorSupport()
        instance.isValid()

    def test_setFields_test_4107(self, p0=None, p1=None):
        instance = DescriptorSupport()
        instance.setFields(p0, p1)


class DescriptorSupport:
    def __init__(self):
        self.fields = {}

    def getFieldNames(self):
        return list(self.fields.keys())

    def getFieldValues(self, field_names):
        if field_names is None:
            return list(self.fields.values())
        return [self.fields.get(name) for name in field_names]

    def setField(self, name, value):
        self.fields[name] = value

    def getFieldValue(self, name):
        return self.fields.get(name)

    def removeField(self, name):
        if name in self.fields:
            del self.fields[name]

    def toXMLString(self):
        return "<Descriptor>"

    def getFields(self):
        return list(self.fields.items())

    def isValid(self):
        return True

    def setFields(self, field_names, field_values):
        if field_names and field_values:
            for name, value in zip(field_names, field_values):
                self.fields[name] = value


if __name__ == '__main__':
    unittest.main()