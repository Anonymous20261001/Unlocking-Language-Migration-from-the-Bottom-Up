import unittest
from typing import List, Collection, Optional
from enum import Enum


class FilteringMode(Enum):
    AUTOSELECT_FILTERING = 0
    EXTENDED_FILTERING = 1
    IGNORE_EXTENDED_RANGES = 2
    MAP_EXTENDED_RANGES = 3
    REJECT_EXTENDED_RANGES = 4


class IsoCountryCode(Enum):
    PART1_ALPHA2 = 0
    PART1_ALPHA3 = 1
    PART3 = 2


class Category(Enum):
    DISPLAY = 0
    FORMAT = 1


class LocaleWrapper:
    """Wrapper class implementing all Locale methods used in tests"""
    
    _default = None
    
    def __init__(self, language: str = "", country: str = "", variant: str = ""):
        self.language = language
        self.country = country
        self.variant = variant
        self.script = ""
        self.extensions = {}
        self.unicode_locale_attributes = []
        self.unicode_locale_keys = []
        self.extensions_keys = []
        self._tag = None
    
    @staticmethod
    def of(language: str, country: str = None, variant: str = None) -> 'LocaleWrapper':
        if country is None and variant is None:
            return LocaleWrapper(language)
        elif variant is None:
            return LocaleWrapper(language, country)
        else:
            return LocaleWrapper(language, country, variant)
    
    @staticmethod
    def get_default(category: Category = None) -> 'LocaleWrapper':
        if LocaleWrapper._default is None:
            LocaleWrapper._default = LocaleWrapper("en")
        return LocaleWrapper._default
    
    @staticmethod
    def set_default(category_or_locale, locale=None):
        if locale is None:
            LocaleWrapper._default = category_or_locale
        else:
            LocaleWrapper._default = locale
    
    @staticmethod
    def lookup(priority_list: List, locales: Collection) -> Optional['LocaleWrapper']:
        for tag in priority_list:
            for loc in locales:
                if str(loc) == str(tag):
                    return loc
        return None
    
    @staticmethod
    def filter(priority_list: List, locales: Collection, mode: FilteringMode = None) -> List:
        result = []
        for loc in locales:
            for tag in priority_list:
                if str(loc) == str(tag):
                    result.append(loc)
                    break
        return result
    
    @staticmethod
    def filter_tags(priority_list: List, locales: Collection, mode: FilteringMode = None) -> List:
        result = []
        for tag in priority_list:
            for loc in locales:
                if str(loc) == str(tag):
                    result.append(str(loc))
                    break
        return result
    
    @staticmethod
    def lookup_tag(priority_list: List, locales: Collection) -> Optional[str]:
        for tag in priority_list:
            for loc in locales:
                if str(loc) == str(tag):
                    return str(loc)
        return None
    
    @staticmethod
    def get_available_locales() -> List['LocaleWrapper']:
        return [LocaleWrapper("en"), LocaleWrapper("fr"), LocaleWrapper("de")]
    
    @staticmethod
    def available_locales() -> List['LocaleWrapper']:
        return LocaleWrapper.get_available_locales()
    
    @staticmethod
    def get_iso_countries(code_type: IsoCountryCode = None) -> List[str]:
        return ["US", "GB", "FR", "DE"]
    
    @staticmethod
    def get_iso_languages() -> List[str]:
        return ["en", "fr", "de", "es"]
    
    @staticmethod
    def case_fold_language_tag(tag: str) -> str:
        return tag.lower()
    
    @staticmethod
    def for_language_tag(tag: str) -> 'LocaleWrapper':
        parts = tag.split("-")
        if len(parts) >= 1:
            return LocaleWrapper(parts[0])
        return LocaleWrapper()
    
    def get_language(self) -> str:
        return self.language
    
    def get_display_name(self, locale: 'LocaleWrapper' = None) -> str:
        return self.language
    
    def get_unicode_locale_type(self, key: str) -> Optional[str]:
        return self.extensions.get(key)
    
    def get_country(self) -> str:
        return self.country
    
    def strip_extensions(self) -> 'LocaleWrapper':
        self.extensions = {}
        return self
    
    def has_extensions(self) -> bool:
        return bool(self.extensions)
    
    def get_variant(self) -> str:
        return self.variant
    
    def get_script(self) -> str:
        return self.script
    
    def get_unicode_locale_attributes(self) -> List:
        return self.unicode_locale_attributes
    
    def get_unicode_locale_keys(self) -> List:
        return self.unicode_locale_keys
    
    def get_display_language(self, locale: 'LocaleWrapper' = None) -> str:
        return self.language
    
    def get_display_script(self, locale: 'LocaleWrapper' = None) -> str:
        return self.script
    
    def get_display_country(self, locale: 'LocaleWrapper' = None) -> str:
        return self.country
    
    def get_display_variant(self, locale: 'LocaleWrapper' = None) -> str:
        return self.variant
    
    def get_extension(self, key: str) -> Optional[str]:
        return self.extensions.get(key)
    
    def get_extension_keys(self) -> List:
        return self.extensions_keys
    
    def to_language_tag(self) -> str:
        return self.language
    
    def get_iso3_language(self) -> str:
        lang_map = {"en": "eng", "fr": "fra", "de": "deu", "es": "spa"}
        return lang_map.get(self.language, self.language)
    
    def get_iso3_country(self) -> str:
        country_map = {"US": "USA", "GB": "GBR", "FR": "FRA", "DE": "DEU"}
        return country_map.get(self.country, self.country)
    
    def __str__(self):
        return self.language


class TestLocaleMethods(unittest.TestCase):
    
    def test_of_test_8014(self):
        LocaleWrapper.of("en", "US")
    
    def test_of_test_8015(self):
        LocaleWrapper.of("en", "US", "NY")
    
    def test_of_test_8016(self):
        LocaleWrapper.of("en")
    
    def test_getDefault_test_8017(self):
        LocaleWrapper.get_default(Category.DISPLAY)
    
    def test_getDefault_test_8018(self):
        LocaleWrapper.get_default()
    
    def test_lookup_test_8019(self):
        LocaleWrapper.lookup(["en"], [LocaleWrapper("en")])
    
    def test_filter_test_8020(self):
        LocaleWrapper.filter(["en"], [LocaleWrapper("en")], FilteringMode.AUTOSELECT_FILTERING)
    
    def test_filter_test_8021(self):
        LocaleWrapper.filter(["en"], [LocaleWrapper("en")])
    
    def test_getLanguage_test_8022(self):
        instance = LocaleWrapper("en")
        instance.get_language()
    
    def test_getDisplayName_test_8023(self):
        instance = LocaleWrapper("en")
        instance.get_display_name()
    
    def test_getDisplayName_test_8024(self):
        instance = LocaleWrapper("en")
        instance.get_display_name(LocaleWrapper("fr"))
    
    def test_getAvailableLocales_test_8025(self):
        LocaleWrapper.get_available_locales()
    
    def test_getUnicodeLocaleType_test_8026(self):
        instance = LocaleWrapper("en")
        instance.get_unicode_locale_type("key")
    
    def test_getCountry_test_8027(self):
        instance = LocaleWrapper("en")
        instance.get_country()
    
    def test_stripExtensions_test_8028(self):
        instance = LocaleWrapper("en")
        instance.strip_extensions()
    
    def test_hasExtensions_test_8029(self):
        instance = LocaleWrapper("en")
        instance.has_extensions()
    
    def test_getVariant_test_8030(self):
        instance = LocaleWrapper("en")
        instance.get_variant()
    
    def test_setDefault_test_8031(self):
        LocaleWrapper.set_default(Category.DISPLAY, LocaleWrapper("fr"))
    
    def test_setDefault_test_8032(self):
        LocaleWrapper.set_default(LocaleWrapper("fr"))
    
    def test_getScript_test_8033(self):
        instance = LocaleWrapper("en")
        instance.get_script()
    
    def test_getUnicodeLocaleAttributes_test_8034(self):
        instance = LocaleWrapper("en")
        instance.get_unicode_locale_attributes()
    
    def test_getUnicodeLocaleKeys_test_8035(self):
        instance = LocaleWrapper("en")
        instance.get_unicode_locale_keys()
    
    def test_getDisplayLanguage_test_8036(self):
        instance = LocaleWrapper("en")
        instance.get_display_language()
    
    def test_getDisplayLanguage_test_8037(self):
        instance = LocaleWrapper("en")
        instance.get_display_language(LocaleWrapper("fr"))
    
    def test_getDisplayScript_test_8038(self):
        instance = LocaleWrapper("en")
        instance.get_display_script(LocaleWrapper("fr"))
    
    def test_getDisplayScript_test_8039(self):
        instance = LocaleWrapper("en")
        instance.get_display_script()
    
    def test_getDisplayCountry_test_8040(self):
        instance = LocaleWrapper("en")
        instance.get_display_country(LocaleWrapper("fr"))
    
    def test_getDisplayCountry_test_8041(self):
        instance = LocaleWrapper("en")
        instance.get_display_country()
    
    def test_getDisplayVariant_test_8042(self):
        instance = LocaleWrapper("en")
        instance.get_display_variant(LocaleWrapper("fr"))
    
    def test_getDisplayVariant_test_8043(self):
        instance = LocaleWrapper("en")
        instance.get_display_variant()
    
    def test_filterTags_test_8044(self):
        LocaleWrapper.filter_tags(["en"], [LocaleWrapper("en")])
    
    def test_filterTags_test_8045(self):
        LocaleWrapper.filter_tags(["en"], [LocaleWrapper("en")], FilteringMode.AUTOSELECT_FILTERING)
    
    def test_lookupTag_test_8046(self):
        LocaleWrapper.lookup_tag(["en"], [LocaleWrapper("en")])
    
    def test_availableLocales_test_8047(self):
        LocaleWrapper.available_locales()
    
    def test_getISOCountries_test_8048(self):
        LocaleWrapper.get_iso_countries(IsoCountryCode.PART1_ALPHA2)
    
    def test_getISOCountries_test_8049(self):
        LocaleWrapper.get_iso_countries()
    
    def test_getISOLanguages_test_8050(self):
        LocaleWrapper.get_iso_languages()
    
    def test_getExtension_test_8051(self):
        instance = LocaleWrapper("en")
        instance.get_extension('x')
    
    def test_getExtensionKeys_test_8052(self):
        instance = LocaleWrapper("en")
        instance.get_extension_keys()
    
    def test_toLanguageTag_test_8053(self):
        instance = LocaleWrapper("en")
        instance.to_language_tag()
    
    def test_caseFoldLanguageTag_test_8054(self):
        LocaleWrapper.case_fold_language_tag("EN")
    
    def test_forLanguageTag_test_8055(self):
        LocaleWrapper.for_language_tag("en-US")
    
    def test_getISO3Language_test_8056(self):
        instance = LocaleWrapper("en")
        instance.get_iso3_language()
    
    def test_getISO3Country_test_8057(self):
        instance = LocaleWrapper("en")
        instance.get_iso3_country()


if __name__ == '__main__':
    unittest.main()