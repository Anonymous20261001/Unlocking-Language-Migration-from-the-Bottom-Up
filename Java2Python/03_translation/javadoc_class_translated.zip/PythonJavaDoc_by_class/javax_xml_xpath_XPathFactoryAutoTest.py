import unittest
from javax.xml.xpath import XPathFactory

class TestJavaxXmlXpathXPathFactoryAutoTest(unittest.TestCase):
    def test_newDefaultInstance_test_13657(self):
        XPathFactory.newDefaultInstance()

    def test_newInstance_test_13658(self):
        XPathFactory.newInstance()


class XPathFactoryWrapper:
    @staticmethod
    def newDefaultInstance():
        return XPathFactory.newDefaultInstance()

    @staticmethod
    def newInstance():
        return XPathFactory.newInstance()

if __name__ == '__main__':
    unittest.main()