import unittest
import threading

class TestThreadLocalRandom(unittest.TestCase):
    def test_current_test_12713(self):
        ThreadLocalRandom.current()

class ThreadLocalRandom:
    _local = threading.local()
    
    @classmethod
    def current(cls):
        if not hasattr(cls._local, 'instance'):
            cls._local.instance = cls()
        return cls._local.instance

if __name__ == '__main__':
    unittest.main()