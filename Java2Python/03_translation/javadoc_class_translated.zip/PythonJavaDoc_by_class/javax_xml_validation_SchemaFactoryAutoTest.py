import unittest
from javax.xml.validation import SchemaFactory


class TestSchemaFactory(unittest.TestCase):

    def newDefaultInstance_test_10856(self):
        SchemaFactory.newDefaultInstance()

    def newInstance_test_10857(self, p0, p1, p2):
        SchemaFactory.newInstance(p0, p1, p2)

    def newInstance_test_10858(self, p0):
        SchemaFactory.newInstance(p0)


class SchemaFactoryWrapper:
    """Wrapper class containing the methods called by the tests."""
    
    @staticmethod
    def newDefaultInstance():
        return SchemaFactory.newDefaultInstance()
    
    @staticmethod
    def newInstance(schema_language, factory_impl, class_loader):
        return SchemaFactory.newInstance(schema_language, factory_impl, class_loader)
    
    @staticmethod
    def newInstance(schema_language):
        return SchemaFactory.newInstance(schema_language)