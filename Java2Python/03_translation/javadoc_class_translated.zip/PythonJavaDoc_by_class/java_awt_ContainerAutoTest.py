import unittest
from unittest.mock import MagicMock

class TestContainerMethods(unittest.TestCase):
    def test_addPropertyChangeListener_test_2934(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.addPropertyChangeListener(p0)

    def test_addPropertyChangeListener_test_2935(self):
        instance = ContainerWrapper()
        p0 = "test"
        p1 = MagicMock()
        instance.addPropertyChangeListener(p0, p1)

    def test_setFont_test_2936(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.setFont(p0)

    def test_getComponentCount_test_2937(self):
        instance = ContainerWrapper()
        instance.getComponentCount()

    def test_paint_test_2938(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.paint(p0)

    def test_isFocusCycleRoot_test_2939(self):
        instance = ContainerWrapper()
        instance.isFocusCycleRoot()

    def test_isFocusCycleRoot_test_2940(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.isFocusCycleRoot(p0)

    def test_getFocusTraversalPolicy_test_2941(self):
        instance = ContainerWrapper()
        instance.getFocusTraversalPolicy()

    def test_setFocusTraversalPolicy_test_2942(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.setFocusTraversalPolicy(p0)

    def test_getPreferredSize_test_2943(self):
        instance = ContainerWrapper()
        instance.getPreferredSize()

    def test_getMaximumSize_test_2944(self):
        instance = ContainerWrapper()
        instance.getMaximumSize()

    def test_getMinimumSize_test_2945(self):
        instance = ContainerWrapper()
        instance.getMinimumSize()

    def test_getInsets_test_2946(self):
        instance = ContainerWrapper()
        instance.getInsets()

    def test_getAlignmentY_test_2947(self):
        instance = ContainerWrapper()
        instance.getAlignmentY()

    def test_getAlignmentX_test_2948(self):
        instance = ContainerWrapper()
        instance.getAlignmentX()

    def test_setFocusTraversalKeys_test_2949(self):
        instance = ContainerWrapper()
        p0 = 1
        p1 = MagicMock()
        instance.setFocusTraversalKeys(p0, p1)

    def test_getListeners_test_2950(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.getListeners(p0)

    def test_addNotify_test_2951(self):
        instance = ContainerWrapper()
        instance.addNotify()

    def test_removeNotify_test_2952(self):
        instance = ContainerWrapper()
        instance.removeNotify()

    def test_getComponents_test_2953(self):
        instance = ContainerWrapper()
        instance.getComponents()

    def test_preferredSize_test_2954(self):
        instance = ContainerWrapper()
        instance.preferredSize()

    def test_minimumSize_test_2955(self):
        instance = ContainerWrapper()
        instance.minimumSize()

    def test_insets_test_2956(self):
        instance = ContainerWrapper()
        instance.insets()

    def test_isValidateRoot_test_2957(self):
        instance = ContainerWrapper()
        instance.isValidateRoot()

    def test_countComponents_test_2958(self):
        instance = ContainerWrapper()
        instance.countComponents()

    def test_getComponentZOrder_test_2959(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.getComponentZOrder(p0)

    def test_layout_test_2960(self):
        instance = ContainerWrapper()
        instance.layout()

    def test_doLayout_test_2961(self):
        instance = ContainerWrapper()
        instance.doLayout()

    def test_getComponentAt_test_2962(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.getComponentAt(p0)

    def test_getComponentAt_test_2963(self):
        instance = ContainerWrapper()
        p0 = 1
        p1 = 2
        instance.getComponentAt(p0, p1)

    def test_deliverEvent_test_2964(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.deliverEvent(p0)

    def test_locate_test_2965(self):
        instance = ContainerWrapper()
        p0 = 1
        p1 = 2
        instance.locate(p0, p1)

    def test_findComponentAt_test_2966(self):
        instance = ContainerWrapper()
        p0 = 1
        p1 = 2
        instance.findComponentAt(p0, p1)

    def test_findComponentAt_test_2967(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.findComponentAt(p0)

    def test_isFocusTraversalPolicyProvider_test_2968(self):
        instance = ContainerWrapper()
        instance.isFocusTraversalPolicyProvider()

    def test_applyComponentOrientation_test_2969(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.applyComponentOrientation(p0)

    def test_addContainerListener_test_2970(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.addContainerListener(p0)

    def test_getLayout_test_2971(self):
        instance = ContainerWrapper()
        instance.getLayout()

    def test_setComponentZOrder_test_2972(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = 1
        instance.setComponentZOrder(p0, p1)

    def test_setLayout_test_2973(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.setLayout(p0)

    def test_paintComponents_test_2974(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.paintComponents(p0)

    def test_printComponents_test_2975(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.printComponents(p0)

    def test_removeContainerListener_test_2976(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.removeContainerListener(p0)

    def test_getContainerListeners_test_2977(self):
        instance = ContainerWrapper()
        instance.getContainerListeners()

    def test_getMousePosition_test_2978(self):
        instance = ContainerWrapper()
        p0 = True
        instance.getMousePosition(p0)

    def test_isAncestorOf_test_2979(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.isAncestorOf(p0)

    def test_getFocusTraversalKeys_test_2980(self):
        instance = ContainerWrapper()
        p0 = 1
        instance.getFocusTraversalKeys(p0)

    def test_areFocusTraversalKeysSet_test_2981(self):
        instance = ContainerWrapper()
        p0 = 1
        instance.areFocusTraversalKeysSet(p0)

    def test_isFocusTraversalPolicySet_test_2982(self):
        instance = ContainerWrapper()
        instance.isFocusTraversalPolicySet()

    def test_setFocusCycleRoot_test_2983(self):
        instance = ContainerWrapper()
        p0 = True
        instance.setFocusCycleRoot(p0)

    def test_setFocusTraversalPolicyProvider_test_2984(self):
        instance = ContainerWrapper()
        p0 = True
        instance.setFocusTraversalPolicyProvider(p0)

    def test_transferFocusDownCycle_test_2985(self):
        instance = ContainerWrapper()
        instance.transferFocusDownCycle()

    def test_remove_test_2986(self):
        instance = ContainerWrapper()
        p0 = 1
        instance.remove(p0)

    def test_remove_test_2987(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.remove(p0)

    def test_update_test_2988(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.update(p0)

    def test_add_test_2989(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.add(p0)

    def test_add_test_2990(self):
        instance = ContainerWrapper()
        p0 = "test"
        p1 = MagicMock()
        instance.add(p0, p1)

    def test_add_test_2991(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = MagicMock()
        instance.add(p0, p1)

    def test_add_test_2992(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = 1
        instance.add(p0, p1, p2)

    def test_add_test_2993(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = 1
        instance.add(p0, p1)

    def test_list_test_2994(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = 1
        instance.list(p0, p1)

    def test_list_test_2995(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        p1 = 1
        instance.list(p0, p1)

    def test_validate_test_2996(self):
        instance = ContainerWrapper()
        instance.validate()

    def test_print_test_2997(self):
        instance = ContainerWrapper()
        p0 = MagicMock()
        instance.print(p0)

    def test_removeAll_test_2998(self):
        instance = ContainerWrapper()
        instance.removeAll()

    def test_getComponent_test_2999(self):
        instance = ContainerWrapper()
        p0 = 1
        instance.getComponent(p0)

    def test_invalidate_test_3000(self):
        instance = ContainerWrapper()
        instance.invalidate()


class ContainerWrapper:
    def __init__(self):
        pass

    def addPropertyChangeListener(self, *args):
        pass

    def setFont(self, *args):
        pass

    def getComponentCount(self):
        pass

    def paint(self, *args):
        pass

    def isFocusCycleRoot(self, *args):
        pass

    def getFocusTraversalPolicy(self):
        pass

    def setFocusTraversalPolicy(self, *args):
        pass

    def getPreferredSize(self):
        pass

    def getMaximumSize(self):
        pass

    def getMinimumSize(self):
        pass

    def getInsets(self):
        pass

    def getAlignmentY(self):
        pass

    def getAlignmentX(self):
        pass

    def setFocusTraversalKeys(self, *args):
        pass

    def getListeners(self, *args):
        pass

    def addNotify(self):
        pass

    def removeNotify(self):
        pass

    def getComponents(self):
        pass

    def preferredSize(self):
        pass

    def minimumSize(self):
        pass

    def insets(self):
        pass

    def isValidateRoot(self):
        pass

    def countComponents(self):
        pass

    def getComponentZOrder(self, *args):
        pass

    def layout(self):
        pass

    def doLayout(self):
        pass

    def getComponentAt(self, *args):
        pass

    def deliverEvent(self, *args):
        pass

    def locate(self, *args):
        pass

    def findComponentAt(self, *args):
        pass

    def isFocusTraversalPolicyProvider(self):
        pass

    def applyComponentOrientation(self, *args):
        pass

    def addContainerListener(self, *args):
        pass

    def getLayout(self):
        pass

    def setComponentZOrder(self, *args):
        pass

    def setLayout(self, *args):
        pass

    def paintComponents(self, *args):
        pass

    def printComponents(self, *args):
        pass

    def removeContainerListener(self, *args):
        pass

    def getContainerListeners(self):
        pass

    def getMousePosition(self, *args):
        pass

    def isAncestorOf(self, *args):
        pass

    def getFocusTraversalKeys(self, *args):
        pass

    def areFocusTraversalKeysSet(self, *args):
        pass

    def isFocusTraversalPolicySet(self):
        pass

    def setFocusCycleRoot(self, *args):
        pass

    def setFocusTraversalPolicyProvider(self, *args):
        pass

    def transferFocusDownCycle(self):
        pass

    def remove(self, *args):
        pass

    def update(self, *args):
        pass

    def add(self, *args):
        pass

    def list(self, *args):
        pass

    def validate(self):
        pass

    def print(self, *args):
        pass

    def removeAll(self):
        pass

    def getComponent(self, *args):
        pass

    def invalidate(self):
        pass

if __name__ == '__main__':
    unittest.main()