import unittest
import ctypes


class ByteBuffer:
    @staticmethod
    def wrap(data, offset=0, length=None):
        if length is None:
            length = len(data) - offset
        return ByteBuffer(data[offset:offset + length])

    @staticmethod
    def allocate(capacity):
        return ByteBuffer(bytearray(capacity))

    @staticmethod
    def allocate_direct(capacity):
        buf = ctypes.create_string_buffer(capacity)
        return ByteBuffer(bytearray(buf.raw))


class TestByteBuffer(unittest.TestCase):
    def test_wrap_test_2000(self):
        data = bytearray(b'hello')
        result = ByteBuffer.wrap(data, 1, 3)
        self.assertEqual(result, ByteBuffer(b'ell'))

    def test_wrap_test_2001(self):
        data = bytearray(b'hello')
        result = ByteBuffer.wrap(data)
        self.assertEqual(result, ByteBuffer(b'hello'))

    def test_allocate_test_2002(self):
        result = ByteBuffer.allocate(10)
        self.assertEqual(len(result), 10)

    def test_allocate_direct_test_2003(self):
        result = ByteBuffer.allocate_direct(10)
        self.assertEqual(len(result), 10)


if __name__ == '__main__':
    unittest.main()