import unittest
from typing import List, Optional
from javax.swing import Action

class TextAction:
    @staticmethod
    def augmentList(list1: Optional[List[Action]], list2: Optional[List[Action]]) -> List[Action]:
        if list1 is None:
            return list2 or []
        if list2 is None:
            return list1
        result = list(list1)
        for action in list2:
            if action not in result:
                result.append(action)
        return result

class TestJavaxSwingTextTextAction(unittest.TestCase):
    def test_augmentList_test_12543(self):
        p0 = [Action()]
        p1 = [Action()]
        result = TextAction.augmentList(p0, p1)
        self.assertIsNotNone(result)

if __name__ == '__main__':
    unittest.main()