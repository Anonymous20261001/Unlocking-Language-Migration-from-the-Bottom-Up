import unittest
from unittest.mock import MagicMock, patch

class TestJavaAwtSplashScreenAutoTest(unittest.TestCase):
    def test_getSplashScreen_test_11313(self):
        with patch('java_awt_SplashScreenAutoTest.SplashScreen.getSplashScreen') as mock_get:
            SplashScreen.getSplashScreen()
            mock_get.assert_called_once()

class SplashScreen:
    @staticmethod
    def getSplashScreen():
        return MagicMock()

if __name__ == '__main__':
    unittest.main()