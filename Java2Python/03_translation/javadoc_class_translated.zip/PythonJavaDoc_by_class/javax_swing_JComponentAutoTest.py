import unittest
from java.awt import Component
from java.util import Locale
from javax.swing import JComponent


class TestJComponent(unittest.TestCase):

    def test_getDefaultLocale_test_6106(self):
        JComponent.getDefaultLocale()

    def test_isLightweightComponent_test_6107(self):
        p0 = Component()
        JComponent.isLightweightComponent(p0)

    def test_setDefaultLocale_test_6108(self):
        p0 = Locale()
        JComponent.setDefaultLocale(p0)


class JComponentWrapper:
    @staticmethod
    def getDefaultLocale():
        return JComponent.getDefaultLocale()

    @staticmethod
    def isLightweightComponent(component):
        return JComponent.isLightweightComponent(component)

    @staticmethod
    def setDefaultLocale(locale):
        return JComponent.setDefaultLocale(locale)


if __name__ == '__main__':
    unittest.main()