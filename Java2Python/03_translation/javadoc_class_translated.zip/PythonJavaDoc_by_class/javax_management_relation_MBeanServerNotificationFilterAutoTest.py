import unittest
from unittest.mock import MagicMock

class MBeanServerNotificationFilter:
    def __init__(self):
        self.enabled_object_names = set()
        self.disabled_object_names = set()
        self.all_enabled = False
        self.all_disabled = False
    
    def disableAllObjectNames(self):
        self.all_disabled = True
        self.all_enabled = False
        self.enabled_object_names.clear()
    
    def disableObjectName(self, p0):
        self.disabled_object_names.add(p0)
        if p0 in self.enabled_object_names:
            self.enabled_object_names.remove(p0)
    
    def enableAllObjectNames(self):
        self.all_enabled = True
        self.all_disabled = False
        self.disabled_object_names.clear()
    
    def enableObjectName(self, p0):
        self.enabled_object_names.add(p0)
        if p0 in self.disabled_object_names:
            self.disabled_object_names.remove(p0)
    
    def getEnabledObjectNames(self):
        return list(self.enabled_object_names)
    
    def getDisabledObjectNames(self):
        return list(self.disabled_object_names)
    
    def isNotificationEnabled(self, p0):
        if self.all_enabled:
            return True
        if self.all_disabled:
            return False
        if p0 is not None and hasattr(p0, 'getSource'):
            source = p0.getSource()
            if isinstance(source, str):
                return source in self.enabled_object_names
        return False

class TestMBeanServerNotificationFilter(unittest.TestCase):
    def test_disableAllObjectNames_test_8454(self):
        instance = MBeanServerNotificationFilter()
        instance.disableAllObjectNames()
    
    def test_disableObjectName_test_8455(self):
        instance = MBeanServerNotificationFilter()
        p0 = MagicMock()
        instance.disableObjectName(p0)
    
    def test_enableAllObjectNames_test_8456(self):
        instance = MBeanServerNotificationFilter()
        instance.enableAllObjectNames()
    
    def test_enableObjectName_test_8457(self):
        instance = MBeanServerNotificationFilter()
        p0 = MagicMock()
        instance.enableObjectName(p0)
    
    def test_getEnabledObjectNames_test_8458(self):
        instance = MBeanServerNotificationFilter()
        instance.getEnabledObjectNames()
    
    def test_getDisabledObjectNames_test_8459(self):
        instance = MBeanServerNotificationFilter()
        instance.getDisabledObjectNames()
    
    def test_isNotificationEnabled_test_8460(self):
        instance = MBeanServerNotificationFilter()
        p0 = MagicMock()
        instance.isNotificationEnabled(p0)

if __name__ == '__main__':
    unittest.main()