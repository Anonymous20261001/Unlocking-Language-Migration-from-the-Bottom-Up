import unittest
import logging

class TestLevelParse(unittest.TestCase):
    def parse_test_7719(self, p0):
        LevelWrapper.parse(p0)

class LevelWrapper:
    @staticmethod
    def parse(name):
        return logging.getLevelName(name)