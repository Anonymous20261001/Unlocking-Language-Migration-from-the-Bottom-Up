import unittest
from datetime import datetime, timezone, timedelta


class TestClockMethods(unittest.TestCase):
    def offset_test_2329(self, p0, p1):
        Clock.offset(p0, p1)

    def system_test_2330(self, p0):
        Clock.system(p0)

    def fixed_test_2331(self, p0, p1):
        Clock.fixed(p0, p1)

    def systemUTC_test_2332(self):
        Clock.systemUTC()

    def systemDefaultZone_test_2333(self):
        Clock.systemDefaultZone()

    def tickMillis_test_2334(self, p0):
        Clock.tickMillis(p0)

    def tickSeconds_test_2335(self, p0):
        Clock.tickSeconds(p0)

    def tickMinutes_test_2336(self, p0):
        Clock.tickMinutes(p0)

    def tick_test_2337(self, p0, p1):
        Clock.tick(p0, p1)


class Clock:
    @staticmethod
    def offset(clock, duration):
        return clock + duration

    @staticmethod
    def system(zone_id):
        return datetime.now(zone_id)

    @staticmethod
    def fixed(instant, zone_id):
        return instant.astimezone(zone_id)

    @staticmethod
    def systemUTC():
        return datetime.now(timezone.utc)

    @staticmethod
    def systemDefaultZone():
        return datetime.now()

    @staticmethod
    def tickMillis(zone_id):
        return datetime.now(zone_id).replace(microsecond=0)

    @staticmethod
    def tickSeconds(zone_id):
        return datetime.now(zone_id).replace(microsecond=0)

    @staticmethod
    def tickMinutes(zone_id):
        now = datetime.now(zone_id)
        return now.replace(second=0, microsecond=0)

    @staticmethod
    def tick(clock, duration):
        return clock + duration


if __name__ == '__main__':
    unittest.main()