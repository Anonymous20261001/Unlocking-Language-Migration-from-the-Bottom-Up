import unittest
from typing import List, Any


class TestImmutableDescriptor(unittest.TestCase):
    def test_getFieldNames_test_5753(self, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.getFieldNames()

    def test_getFieldValues_test_5754(self, p0: List[str], c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.getFieldValues(p0)

    def test_setField_test_5755(self, p0: str, p1: Any, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.setField(p0, p1)

    def test_getFieldValue_test_5756(self, p0: str, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.getFieldValue(p0)

    def test_removeField_test_5757(self, p0: str, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.removeField(p0)

    def test_getFields_test_5758(self, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.getFields()

    def test_isValid_test_5759(self, c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.isValid()

    def test_setFields_test_5760(self, p0: List[str], p1: List[Any], c0: List[str]):
        instance = ImmutableDescriptor(c0)
        instance.setFields(p0, p1)

    def test_union_test_5761(self, p0: List[Any]):
        ImmutableDescriptor.union(p0)


class ImmutableDescriptor:
    def __init__(self, c0: List[str]):
        self.field_names = c0
        self.fields = {name: None for name in c0}

    def getFieldNames(self):
        return list(self.fields.keys())

    def getFieldValues(self, p0: List[str]):
        return [self.fields.get(name) for name in p0]

    def setField(self, p0: str, p1: Any):
        self.fields[p0] = p1

    def getFieldValue(self, p0: str):
        return self.fields.get(p0)

    def removeField(self, p0: str):
        if p0 in self.fields:
            del self.fields[p0]

    def getFields(self):
        return self.fields

    def isValid(self):
        return True

    def setFields(self, p0: List[str], p1: List[Any]):
        for name, value in zip(p0, p1):
            self.fields[name] = value

    @staticmethod
    def union(p0: List[Any]):
        return p0