import unittest
import io
import asyncio
from typing import BinaryIO, TextIO


class TestJavaNioChannelsChannelsAutoTest(unittest.TestCase):
    def test_newReader_test_2112(self):
        p0 = io.BytesIO(b"test data")
        p1 = None  # CharsetDecoder placeholder
        p2 = 1024
        result = ChannelsWrapper.newReader(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_newReader_test_2113(self):
        p0 = io.BytesIO(b"test data")
        p1 = "utf-8"
        result = ChannelsWrapper.newReader(p0, p1)
        self.assertIsNotNone(result)

    def test_newReader_test_2114(self):
        p0 = io.BytesIO(b"test data")
        p1 = "utf-8"
        result = ChannelsWrapper.newReader(p0, p1)
        self.assertIsNotNone(result)

    def test_newOutputStream_test_2115(self):
        p0 = None  # AsynchronousByteChannel placeholder
        result = ChannelsWrapper.newOutputStream(p0)
        self.assertIsNotNone(result)

    def test_newOutputStream_test_2116(self):
        p0 = io.BytesIO()
        result = ChannelsWrapper.newOutputStream(p0)
        self.assertIsNotNone(result)

    def test_newWriter_test_2117(self):
        p0 = io.BytesIO()
        p1 = None  # CharsetEncoder placeholder
        p2 = 1024
        result = ChannelsWrapper.newWriter(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_newWriter_test_2118(self):
        p0 = io.BytesIO()
        p1 = "utf-8"
        result = ChannelsWrapper.newWriter(p0, p1)
        self.assertIsNotNone(result)

    def test_newWriter_test_2119(self):
        p0 = io.BytesIO()
        p1 = "utf-8"
        result = ChannelsWrapper.newWriter(p0, p1)
        self.assertIsNotNone(result)

    def test_newInputStream_test_2120(self):
        p0 = io.BytesIO(b"test data")
        result = ChannelsWrapper.newInputStream(p0)
        self.assertIsNotNone(result)

    def test_newInputStream_test_2121(self):
        p0 = None  # AsynchronousByteChannel placeholder
        result = ChannelsWrapper.newInputStream(p0)
        self.assertIsNotNone(result)

    def test_newChannel_test_2122(self):
        p0 = io.BytesIO(b"test data")
        result = ChannelsWrapper.newChannel(p0)
        self.assertIsNotNone(result)

    def test_newChannel_test_2123(self):
        p0 = io.BytesIO()
        result = ChannelsWrapper.newChannel(p0)
        self.assertIsNotNone(result)


class ChannelsWrapper:
    @staticmethod
    def newReader(channel, decoder_or_charset, buffer_size=None):
        if isinstance(decoder_or_charset, str):
            return io.TextIOWrapper(channel, encoding=decoder_or_charset)
        return io.TextIOWrapper(channel)

    @staticmethod
    def newOutputStream(channel):
        if hasattr(channel, 'write'):
            return channel
        return io.BytesIO()

    @staticmethod
    def newWriter(channel, encoder_or_charset, buffer_size=None):
        if isinstance(encoder_or_charset, str):
            return io.TextIOWrapper(channel, encoding=encoder_or_charset)
        return io.TextIOWrapper(channel)

    @staticmethod
    def newInputStream(channel):
        if hasattr(channel, 'read'):
            return channel
        return io.BytesIO()

    @staticmethod
    def newChannel(stream):
        if hasattr(stream, 'read') or hasattr(stream, 'write'):
            return stream
        return io.BytesIO()