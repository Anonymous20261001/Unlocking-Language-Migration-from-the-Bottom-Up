import unittest
from javax.imageio.plugins.tiff import BaselineTIFFTagSet

class TestBaselineTIFFTagSet(unittest.TestCase):
    def getInstance_test_984(self):
        BaselineTIFFTagSet.getInstance()


class BaselineTIFFTagSetWrapper:
    @staticmethod
    def getInstance():
        return BaselineTIFFTagSet.getInstance()

if __name__ == '__main__':
    unittest.main()