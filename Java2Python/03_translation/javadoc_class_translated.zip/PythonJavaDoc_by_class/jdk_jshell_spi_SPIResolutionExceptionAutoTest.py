import unittest

class TestJdkJshellSpiSPIResolutionExceptionAutoTest(unittest.TestCase):
    def id_test_11312(self, c0):
        instance = SPIResolutionException(c0)
        instance.id()


class SPIResolutionException:
    def __init__(self, c0):
        self.c0 = c0

    def id(self):
        return self.c0


if __name__ == '__main__':
    unittest.main()