import unittest

class TestJavaxAnnotationProcessingCompletionsAutoTest(unittest.TestCase):
    def of_test_2610(self, p0, p1):
        Completions.of(p0, p1)

    def of_test_2611(self, p0):
        Completions.of(p0)


class Completions:
    @staticmethod
    def of(*args):
        pass