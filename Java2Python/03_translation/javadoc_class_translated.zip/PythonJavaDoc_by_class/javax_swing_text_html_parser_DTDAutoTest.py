import unittest
from javax.swing.text.html.parser.DTD import DTD

class TestJavaxSwingTextHtmlParserDTD(unittest.TestCase):
    def putDTDHash_test_4403(self, p0, p1):
        DTD.putDTDHash(p0, p1)

class DTDWrapper:
    @staticmethod
    def putDTDHash(name, dtd):
        DTD.putDTDHash(name, dtd)

if __name__ == '__main__':
    unittest.main()