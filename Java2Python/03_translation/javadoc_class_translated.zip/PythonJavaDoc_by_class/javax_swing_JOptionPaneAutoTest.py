import unittest
from unittest.mock import MagicMock
from typing import Any


class TestJavaxSwingJOptionPaneAutoTest(unittest.TestCase):

    def test_getUIClassID_test_6663(self):
        instance = JOptionPane()
        instance.getUIClassID()

    def test_updateUI_test_6664(self):
        instance = JOptionPane()
        instance.updateUI()

    def test_getUI_test_6665(self):
        instance = JOptionPane()
        instance.getUI()

    def test_setUI_test_6666(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setUI(p0)

    def test_getAccessibleContext_test_6667(self):
        instance = JOptionPane()
        instance.getAccessibleContext()

    def test_getIcon_test_6668(self):
        instance = JOptionPane()
        instance.getIcon()

    def test_setIcon_test_6669(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setIcon(p0)

    def test_createDialog_test_6670(self):
        instance = JOptionPane()
        p0 = MagicMock()
        p1 = "test"
        instance.createDialog(p0, p1)

    def test_createDialog_test_6671(self):
        instance = JOptionPane()
        p0 = "test"
        instance.createDialog(p0)

    def test_getMaxCharactersPerLineCount_test_6672(self):
        instance = JOptionPane()
        instance.getMaxCharactersPerLineCount()

    def test_getWantsInput_test_6673(self):
        instance = JOptionPane()
        instance.getWantsInput()

    def test_getSelectionValues_test_6674(self):
        instance = JOptionPane()
        instance.getSelectionValues()

    def test_getInitialSelectionValue_test_6675(self):
        instance = JOptionPane()
        instance.getInitialSelectionValue()

    def test_getMessageType_test_6676(self):
        instance = JOptionPane()
        instance.getMessageType()

    def test_getOptionType_test_6677(self):
        instance = JOptionPane()
        instance.getOptionType()

    def test_getInitialValue_test_6678(self):
        instance = JOptionPane()
        instance.getInitialValue()

    def test_setInputValue_test_6679(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setInputValue(p0)

    def test_selectInitialValue_test_6680(self):
        instance = JOptionPane()
        instance.selectInitialValue()

    def test_showInputDialog_test_6681(self):
        p0 = MagicMock()
        JOptionPane.showInputDialog(p0)

    def test_showInputDialog_test_6682(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showInputDialog(p0, p1, p2, p3)

    def test_showInputDialog_test_6683(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = MagicMock()
        p5 = []
        p6 = MagicMock()
        JOptionPane.showInputDialog(p0, p1, p2, p3, p4, p5, p6)

    def test_showInputDialog_test_6684(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showInputDialog(p0, p1)

    def test_showInputDialog_test_6685(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showInputDialog(p0, p1)

    def test_showInputDialog_test_6686(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        JOptionPane.showInputDialog(p0, p1, p2)

    def test_setWantsInput_test_6687(self):
        instance = JOptionPane()
        p0 = True
        instance.setWantsInput(p0)

    def test_setSelectionValues_test_6688(self):
        instance = JOptionPane()
        p0 = []
        instance.setSelectionValues(p0)

    def test_setInitialSelectionValue_test_6689(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setInitialSelectionValue(p0)

    def test_getRootFrame_test_6690(self):
        JOptionPane.getRootFrame()

    def test_getInputValue_test_6691(self):
        instance = JOptionPane()
        instance.getInputValue()

    def test_showMessageDialog_test_6692(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = MagicMock()
        JOptionPane.showMessageDialog(p0, p1, p2, p3, p4)

    def test_showMessageDialog_test_6693(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showMessageDialog(p0, p1)

    def test_showMessageDialog_test_6694(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showMessageDialog(p0, p1, p2, p3)

    def test_showOptionDialog_test_6695(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        p5 = MagicMock()
        p6 = []
        p7 = MagicMock()
        JOptionPane.showOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7)

    def test_showConfirmDialog_test_6696(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showConfirmDialog(p0, p1, p2, p3)

    def test_showConfirmDialog_test_6697(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showConfirmDialog(p0, p1)

    def test_showConfirmDialog_test_6698(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        p5 = MagicMock()
        JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4, p5)

    def test_showConfirmDialog_test_6699(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4)

    def test_showInternalMessageDialog_test_6700(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = MagicMock()
        JOptionPane.showInternalMessageDialog(p0, p1, p2, p3, p4)

    def test_showInternalMessageDialog_test_6701(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showInternalMessageDialog(p0, p1, p2, p3)

    def test_showInternalMessageDialog_test_6702(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showInternalMessageDialog(p0, p1)

    def test_showInternalOptionDialog_test_6703(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        p5 = MagicMock()
        p6 = []
        p7 = MagicMock()
        JOptionPane.showInternalOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7)

    def test_showInternalConfirmDialog_test_6704(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3)

    def test_showInternalConfirmDialog_test_6705(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        p5 = MagicMock()
        JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4, p5)

    def test_showInternalConfirmDialog_test_6706(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = 0
        JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4)

    def test_showInternalConfirmDialog_test_6707(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showInternalConfirmDialog(p0, p1)

    def test_createInternalFrame_test_6708(self):
        instance = JOptionPane()
        p0 = MagicMock()
        p1 = "test"
        instance.createInternalFrame(p0, p1)

    def test_showInternalInputDialog_test_6709(self):
        p0 = MagicMock()
        p1 = MagicMock()
        JOptionPane.showInternalInputDialog(p0, p1)

    def test_showInternalInputDialog_test_6710(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        JOptionPane.showInternalInputDialog(p0, p1, p2, p3)

    def test_showInternalInputDialog_test_6711(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = "test"
        p3 = 0
        p4 = MagicMock()
        p5 = []
        p6 = MagicMock()
        JOptionPane.showInternalInputDialog(p0, p1, p2, p3, p4, p5, p6)

    def test_getDesktopPaneForComponent_test_6712(self):
        p0 = MagicMock()
        JOptionPane.getDesktopPaneForComponent(p0)

    def test_getFrameForComponent_test_6713(self):
        p0 = MagicMock()
        JOptionPane.getFrameForComponent(p0)

    def test_setMessageType_test_6714(self):
        instance = JOptionPane()
        p0 = 0
        instance.setMessageType(p0)

    def test_setOptionType_test_6715(self):
        instance = JOptionPane()
        p0 = 0
        instance.setOptionType(p0)

    def test_setRootFrame_test_6716(self):
        p0 = MagicMock()
        JOptionPane.setRootFrame(p0)

    def test_setMessage_test_6717(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setMessage(p0)

    def test_setOptions_test_6718(self):
        instance = JOptionPane()
        p0 = []
        instance.setOptions(p0)

    def test_getValue_test_6719(self):
        instance = JOptionPane()
        instance.getValue()

    def test_getMessage_test_6720(self):
        instance = JOptionPane()
        instance.getMessage()

    def test_setValue_test_6721(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setValue(p0)

    def test_setInitialValue_test_6722(self):
        instance = JOptionPane()
        p0 = MagicMock()
        instance.setInitialValue(p0)

    def test_getOptions_test_6723(self):
        instance = JOptionPane()
        instance.getOptions()


class JOptionPane:
    """Wrapper class for JOptionPane-like functionality."""

    def __init__(self):
        self._ui = None
        self._icon = None
        self._message = None
        self._options = None
        self._value = None
        self._input_value = None
        self._initial_value = None
        self._selection_values = None
        self._initial_selection_value = None
        self._wants_input = False
        self._message_type = 0
        self._option_type = 0

    def getUIClassID(self):
        return "OptionPaneUI"

    def updateUI(self):
        pass

    def getUI(self):
        return self._ui

    def setUI(self, ui):
        self._ui = ui

    def getAccessibleContext(self):
        return None

    def getIcon(self):
        return self._icon

    def setIcon(self, icon):
        self._icon = icon

    def createDialog(self, parent_component, title):
        return None

    def getMaxCharactersPerLineCount(self):
        return 0

    def getWantsInput(self):
        return self._wants_input

    def getSelectionValues(self):
        return self._selection_values

    def getInitialSelectionValue(self):
        return self._initial_selection_value

    def getMessageType(self):
        return self._message_type

    def getOptionType(self):
        return self._option_type

    def getInitialValue(self):
        return self._initial_value

    def setInputValue(self, value):
        self._input_value = value

    def selectInitialValue(self):
        pass

    @staticmethod
    def showInputDialog(*args):
        return None

    def setWantsInput(self, wants_input):
        self._wants_input = wants_input

    def setSelectionValues(self, values):
        self._selection_values = values

    def setInitialSelectionValue(self, value):
        self._initial_selection_value = value

    @staticmethod
    def getRootFrame():
        return None

    def getInputValue(self):
        return self._input_value

    @staticmethod
    def showMessageDialog(*args):
        pass

    @staticmethod
    def showOptionDialog(*args):
        return 0

    @staticmethod
    def showConfirmDialog(*args):
        return 0

    @staticmethod
    def showInternalMessageDialog(*args):
        pass

    @staticmethod
    def showInternalOptionDialog(*args):
        return 0

    @staticmethod
    def showInternalConfirmDialog(*args):
        return 0

    def createInternalFrame(self, parent_component, title):
        return None

    @staticmethod
    def showInternalInputDialog(*args):
        return None

    @staticmethod
    def getDesktopPaneForComponent(component):
        return None

    @staticmethod
    def getFrameForComponent(component):
        return None

    def setMessageType(self, message_type):
        self._message_type = message_type

    def setOptionType(self, option_type):
        self._option_type = option_type

    @staticmethod
    def setRootFrame(frame):
        pass

    def setMessage(self, message):
        self._message = message

    def setOptions(self, options):
        self._options = options

    def getValue(self):
        return self._value

    def getMessage(self):
        return self._message

    def setValue(self, value):
        self._value = value

    def setInitialValue(self, value):
        self._initial_value = value

    def getOptions(self):
        return self._options


if __name__ == '__main__':
    unittest.main()