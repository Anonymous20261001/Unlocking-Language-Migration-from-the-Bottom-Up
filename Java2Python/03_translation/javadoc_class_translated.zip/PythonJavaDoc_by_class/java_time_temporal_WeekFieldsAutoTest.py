import unittest
from datetime import date
from enum import Enum
from typing import Optional


class DayOfWeek(Enum):
    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6


class Locale:
    def __init__(self, language: str = "", country: str = ""):
        self.language = language
        self.country = country

    @classmethod
    def get_default(cls):
        return cls()


class WeekFields:
    def __init__(self, first_day_of_week: DayOfWeek, minimal_days: int):
        self.first_day_of_week = first_day_of_week
        self.minimal_days = minimal_days

    @classmethod
    def of(cls, locale: Locale) -> 'WeekFields':
        # Default implementation based on locale
        return cls(DayOfWeek.MONDAY, 4)

    @classmethod
    def of_with_days(cls, first_day_of_week: DayOfWeek, minimal_days: int) -> 'WeekFields':
        return cls(first_day_of_week, minimal_days)


class TestWeekFields(unittest.TestCase):
    def test_of_test_13452(self):
        locale = Locale.get_default()
        WeekFields.of(locale)

    def test_of_test_13453(self):
        first_day = DayOfWeek.MONDAY
        minimal_days = 4
        WeekFields.of_with_days(first_day, minimal_days)


if __name__ == '__main__':
    unittest.main()