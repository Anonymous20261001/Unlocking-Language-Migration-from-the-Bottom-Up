import unittest
from typing import Callable, Any


class TestCollectors(unittest.TestCase):
    def test_joining_test_2424(self):
        wrapper = CollectorsWrapper()
        wrapper.joining("", "", "")

    def test_joining_test_2425(self):
        wrapper = CollectorsWrapper()
        wrapper.joining()

    def test_joining_test_2426(self):
        wrapper = CollectorsWrapper()
        wrapper.joining("")

    def test_toList_test_2427(self):
        wrapper = CollectorsWrapper()
        wrapper.toList()

    def test_toMap_test_2428(self):
        wrapper = CollectorsWrapper()
        wrapper.toMap(lambda x: x, lambda x: x, lambda x, y: x)

    def test_toMap_test_2429(self):
        wrapper = CollectorsWrapper()
        wrapper.toMap(lambda x: x, lambda x: x)

    def test_toMap_test_2430(self):
        wrapper = CollectorsWrapper()
        wrapper.toMap(lambda x: x, lambda x: x, lambda x, y: x, list)

    def test_toSet_test_2431(self):
        wrapper = CollectorsWrapper()
        wrapper.toSet()

    def test_maxBy_test_2432(self):
        wrapper = CollectorsWrapper()
        wrapper.maxBy(lambda x, y: 0)

    def test_minBy_test_2433(self):
        wrapper = CollectorsWrapper()
        wrapper.minBy(lambda x, y: 0)

    def test_mapping_test_2434(self):
        wrapper = CollectorsWrapper()
        wrapper.mapping(lambda x: x, None)

    def test_groupingBy_test_2435(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingBy(lambda x: x)

    def test_groupingBy_test_2436(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingBy(lambda x: x, None, None)

    def test_groupingBy_test_2437(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingBy(lambda x: x, None)

    def test_toCollection_test_2438(self):
        wrapper = CollectorsWrapper()
        wrapper.toCollection(list)

    def test_summingLong_test_2439(self):
        wrapper = CollectorsWrapper()
        wrapper.summingLong(lambda x: 0)

    def test_reducing_test_2440(self):
        wrapper = CollectorsWrapper()
        wrapper.reducing(lambda x, y: x)

    def test_reducing_test_2441(self):
        wrapper = CollectorsWrapper()
        wrapper.reducing(0, lambda x: x, lambda x, y: x)

    def test_reducing_test_2442(self):
        wrapper = CollectorsWrapper()
        wrapper.reducing(0, lambda x, y: x)

    def test_groupingByConcurrent_test_2443(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingByConcurrent(lambda x: x, None)

    def test_groupingByConcurrent_test_2444(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingByConcurrent(lambda x: x, None, None)

    def test_groupingByConcurrent_test_2445(self):
        wrapper = CollectorsWrapper()
        wrapper.groupingByConcurrent(lambda x: x)

    def test_partitioningBy_test_2446(self):
        wrapper = CollectorsWrapper()
        wrapper.partitioningBy(lambda x: True)

    def test_partitioningBy_test_2447(self):
        wrapper = CollectorsWrapper()
        wrapper.partitioningBy(lambda x: True, None)

    def test_collectingAndThen_test_2448(self):
        wrapper = CollectorsWrapper()
        wrapper.collectingAndThen(None, lambda x: x)

    def test_toConcurrentMap_test_2449(self):
        wrapper = CollectorsWrapper()
        wrapper.toConcurrentMap(lambda x: x, lambda x: x)

    def test_toConcurrentMap_test_2450(self):
        wrapper = CollectorsWrapper()
        wrapper.toConcurrentMap(lambda x: x, lambda x: x, lambda x, y: x, dict)

    def test_toConcurrentMap_test_2451(self):
        wrapper = CollectorsWrapper()
        wrapper.toConcurrentMap(lambda x: x, lambda x: x, lambda x, y: x)

    def test_toUnmodifiableList_test_2452(self):
        wrapper = CollectorsWrapper()
        wrapper.toUnmodifiableList()

    def test_toUnmodifiableSet_test_2453(self):
        wrapper = CollectorsWrapper()
        wrapper.toUnmodifiableSet()

    def test_flatMapping_test_2454(self):
        wrapper = CollectorsWrapper()
        wrapper.flatMapping(lambda x: x, None)

    def test_filtering_test_2455(self):
        wrapper = CollectorsWrapper()
        wrapper.filtering(lambda x: True, None)

    def test_counting_test_2456(self):
        wrapper = CollectorsWrapper()
        wrapper.counting()

    def test_summingInt_test_2457(self):
        wrapper = CollectorsWrapper()
        wrapper.summingInt(lambda x: 0)

    def test_summingDouble_test_2458(self):
        wrapper = CollectorsWrapper()
        wrapper.summingDouble(lambda x: 0)

    def test_averagingInt_test_2459(self):
        wrapper = CollectorsWrapper()
        wrapper.averagingInt(lambda x: 0)

    def test_averagingLong_test_2460(self):
        wrapper = CollectorsWrapper()
        wrapper.averagingLong(lambda x: 0)

    def test_averagingDouble_test_2461(self):
        wrapper = CollectorsWrapper()
        wrapper.averagingDouble(lambda x: 0)

    def test_toUnmodifiableMap_test_2462(self):
        wrapper = CollectorsWrapper()
        wrapper.toUnmodifiableMap(lambda x: x, lambda x: x)

    def test_toUnmodifiableMap_test_2463(self):
        wrapper = CollectorsWrapper()
        wrapper.toUnmodifiableMap(lambda x: x, lambda x: x, lambda x, y: x)

    def test_summarizingInt_test_2464(self):
        wrapper = CollectorsWrapper()
        wrapper.summarizingInt(lambda x: 0)

    def test_summarizingLong_test_2465(self):
        wrapper = CollectorsWrapper()
        wrapper.summarizingLong(lambda x: 0)

    def test_summarizingDouble_test_2466(self):
        wrapper = CollectorsWrapper()
        wrapper.summarizingDouble(lambda x: 0)

    def test_teeing_test_2467(self):
        wrapper = CollectorsWrapper()
        wrapper.teeing(None, None, lambda x, y: x)


class CollectorsWrapper:
    def joining(self, *args):
        pass

    def toList(self):
        pass

    def toMap(self, *args):
        pass

    def toSet(self):
        pass

    def maxBy(self, comparator):
        pass

    def minBy(self, comparator):
        pass

    def mapping(self, function, collector):
        pass

    def groupingBy(self, *args):
        pass

    def toCollection(self, supplier):
        pass

    def summingLong(self, function):
        pass

    def reducing(self, *args):
        pass

    def groupingByConcurrent(self, *args):
        pass

    def partitioningBy(self, *args):
        pass

    def collectingAndThen(self, collector, function):
        pass

    def toConcurrentMap(self, *args):
        pass

    def toUnmodifiableList(self):
        pass

    def toUnmodifiableSet(self):
        pass

    def flatMapping(self, function, collector):
        pass

    def filtering(self, predicate, collector):
        pass

    def counting(self):
        pass

    def summingInt(self, function):
        pass

    def summingDouble(self, function):
        pass

    def averagingInt(self, function):
        pass

    def averagingLong(self, function):
        pass

    def averagingDouble(self, function):
        pass

    def toUnmodifiableMap(self, *args):
        pass

    def summarizingInt(self, function):
        pass

    def summarizingLong(self, function):
        pass

    def summarizingDouble(self, function):
        pass

    def teeing(self, collector1, collector2, function):
        pass


if __name__ == '__main__':
    unittest.main()