import unittest
from unittest.mock import MagicMock

# Define test classes to match Java types
class Operation:
    pass

class Namespace:
    pass

class NamespaceOperation:
    def __init__(self, operation, namespaces):
        self.operation = operation
        self.namespaces = namespaces
    
    @staticmethod
    def contains(p0, p1, p2):
        return True
    
    def contains(self, p0):
        return p0 in self.namespaces
    
    def getNamespace(self, p0):
        return self.namespaces[p0]
    
    @staticmethod
    def getBaseOperation(p0):
        return p0
    
    def getBaseOperation(self):
        return self.operation
    
    @staticmethod
    def getNamespaces(p0):
        return p0
    
    def getNamespaces(self):
        return self.namespaces
    
    def getNamespaceCount(self):
        return len(self.namespaces)


class TestJdkDynalinkNamespaceOperation(unittest.TestCase):
    def test_contains_test_9483(self):
        p0 = MagicMock(spec=Operation)
        p1 = MagicMock(spec=Operation)
        p2 = MagicMock(spec=Namespace)
        NamespaceOperation.contains(p0, p1, p2)
    
    def test_contains_test_9484(self):
        p0 = MagicMock(spec=Namespace)
        c0 = MagicMock(spec=Operation)
        c1 = [MagicMock(spec=Namespace) for _ in range(3)]
        instance = NamespaceOperation(c0, c1)
        instance.contains(p0)
    
    def test_getNamespace_test_9485(self):
        p0 = 0
        c0 = MagicMock(spec=Operation)
        c1 = [MagicMock(spec=Namespace) for _ in range(3)]
        instance = NamespaceOperation(c0, c1)
        instance.getNamespace(p0)
    
    def test_getBaseOperation_test_9486(self):
        p0 = MagicMock(spec=Operation)
        NamespaceOperation.getBaseOperation(p0)
    
    def test_getBaseOperation_test_9487(self):
        c0 = MagicMock(spec=Operation)
        c1 = [MagicMock(spec=Namespace) for _ in range(3)]
        instance = NamespaceOperation(c0, c1)
        instance.getBaseOperation()
    
    def test_getNamespaces_test_9488(self):
        c0 = MagicMock(spec=Operation)
        c1 = [MagicMock(spec=Namespace) for _ in range(3)]
        instance = NamespaceOperation(c0, c1)
        instance.getNamespaces()
    
    def test_getNamespaces_test_9489(self):
        p0 = MagicMock(spec=Operation)
        NamespaceOperation.getNamespaces(p0)
    
    def test_getNamespaceCount_test_9490(self):
        c0 = MagicMock(spec=Operation)
        c1 = [MagicMock(spec=Namespace) for _ in range(3)]
        instance = NamespaceOperation(c0, c1)
        instance.getNamespaceCount()


if __name__ == '__main__':
    unittest.main()