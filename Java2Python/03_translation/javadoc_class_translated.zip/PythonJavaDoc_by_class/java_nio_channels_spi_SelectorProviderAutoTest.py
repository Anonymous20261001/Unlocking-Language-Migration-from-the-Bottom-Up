import unittest
from java.nio.channels.spi import SelectorProvider

class TestSelectorProvider(unittest.TestCase):
    def test_provider_test_11022(self):
        SelectorProvider.provider()

if __name__ == '__main__':
    unittest.main()

class SelectorProviderWrapper:
    @staticmethod
    def provider():
        return SelectorProvider.provider()