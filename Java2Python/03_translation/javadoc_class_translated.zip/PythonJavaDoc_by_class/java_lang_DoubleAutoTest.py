import unittest
import struct
import math
from enum import Enum

class Double:
    def __init__(self, value):
        self.value = float(value)
    
    def isInfinite(self):
        return math.isinf(self.value)
    
    def isNaN(self):
        return math.isnan(self.value)
    
    def compareTo(self, other):
        if isinstance(other, Double):
            other = other.value
        if self.value < other:
            return -1
        elif self.value > other:
            return 1
        else:
            return 0
    
    def byteValue(self):
        return int(self.value) & 0xFF
    
    def shortValue(self):
        return int(self.value) & 0xFFFF
    
    def intValue(self):
        return int(self.value)
    
    def longValue(self):
        return int(self.value)
    
    def floatValue(self):
        return float(self.value)
    
    def doubleValue(self):
        return float(self.value)
    
    def resolveConstantDesc(self, lookup):
        return self.value
    
    def describeConstable(self):
        return self.value
    
    @staticmethod
    def min(a, b):
        return min(a, b)
    
    @staticmethod
    def max(a, b):
        return max(a, b)
    
    @staticmethod
    def isInfinite(value):
        return math.isinf(value)
    
    @staticmethod
    def isFinite(value):
        return math.isfinite(value)
    
    @staticmethod
    def doubleToRawLongBits(value):
        return struct.unpack('q', struct.pack('d', value))[0]
    
    @staticmethod
    def doubleToLongBits(value):
        return struct.unpack('q', struct.pack('d', value))[0]
    
    @staticmethod
    def longBitsToDouble(value):
        return struct.unpack('d', struct.pack('q', value))[0]
    
    @staticmethod
    def compare(a, b):
        if a < b:
            return -1
        elif a > b:
            return 1
        else:
            return 0
    
    @staticmethod
    def valueOf(value):
        if isinstance(value, str):
            return float(value)
        return float(value)
    
    @staticmethod
    def toHexString(value):
        return float.hex(value)
    
    @staticmethod
    def isNaN(value):
        return math.isnan(value)
    
    @staticmethod
    def sum(a, b):
        return a + b
    
    @staticmethod
    def parseDouble(value):
        return float(value)

class MethodHandles:
    class Lookup:
        pass

class TestDouble(unittest.TestCase):
    def test_min_test_4224(self):
        p0, p1 = 1.5, 2.5
        Double.min(p0, p1)
    
    def test_max_test_4225(self):
        p0, p1 = 1.5, 2.5
        Double.max(p0, p1)
    
    def test_isInfinite_test_4226(self):
        c0 = float('inf')
        instance = Double(c0)
        instance.isInfinite()
    
    def test_isInfinite_test_4227(self):
        p0 = float('inf')
        Double.isInfinite(p0)
    
    def test_isFinite_test_4228(self):
        p0 = 1.5
        Double.isFinite(p0)
    
    def test_doubleToRawLongBits_test_4229(self):
        p0 = 1.5
        Double.doubleToRawLongBits(p0)
    
    def test_doubleToLongBits_test_4230(self):
        p0 = 1.5
        Double.doubleToLongBits(p0)
    
    def test_longBitsToDouble_test_4231(self):
        p0 = 123456789
        Double.longBitsToDouble(p0)
    
    def test_compareTo_test_4232(self):
        p0 = Double(2.5)
        c0 = 1.5
        instance = Double(c0)
        instance.compareTo(p0)
    
    def test_compare_test_4233(self):
        p0, p1 = 1.5, 2.5
        Double.compare(p0, p1)
    
    def test_byteValue_test_4234(self):
        c0 = 1.5
        instance = Double(c0)
        instance.byteValue()
    
    def test_shortValue_test_4235(self):
        c0 = 1.5
        instance = Double(c0)
        instance.shortValue()
    
    def test_intValue_test_4236(self):
        c0 = 1.5
        instance = Double(c0)
        instance.intValue()
    
    def test_longValue_test_4237(self):
        c0 = 1.5
        instance = Double(c0)
        instance.longValue()
    
    def test_floatValue_test_4238(self):
        c0 = 1.5
        instance = Double(c0)
        instance.floatValue()
    
    def test_doubleValue_test_4239(self):
        c0 = 1.5
        instance = Double(c0)
        instance.doubleValue()
    
    def test_valueOf_test_4240(self):
        p0 = "1.5"
        Double.valueOf(p0)
    
    def test_valueOf_test_4241(self):
        p0 = 1.5
        Double.valueOf(p0)
    
    def test_toHexString_test_4242(self):
        p0 = 1.5
        Double.toHexString(p0)
    
    def test_resolveConstantDesc_test_4243(self):
        p0 = MethodHandles.Lookup()
        c0 = 1.5
        instance = Double(c0)
        instance.resolveConstantDesc(p0)
    
    def test_describeConstable_test_4244(self):
        c0 = 1.5
        instance = Double(c0)
        instance.describeConstable()
    
    def test_isNaN_test_4245(self):
        c0 = float('nan')
        instance = Double(c0)
        instance.isNaN()
    
    def test_isNaN_test_4246(self):
        p0 = float('nan')
        Double.isNaN(p0)
    
    def test_sum_test_4247(self):
        p0, p1 = 1.5, 2.5
        Double.sum(p0, p1)
    
    def test_parseDouble_test_4248(self):
        p0 = "1.5"
        Double.parseDouble(p0)

if __name__ == '__main__':
    unittest.main()