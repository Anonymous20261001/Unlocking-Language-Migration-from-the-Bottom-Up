import unittest
from typing import List
from javax.management import Notification, NotificationFilterSupport


class TestNotificationFilterSupport(unittest.TestCase):

    def enableType_test_9547(self, p0: str):
        instance = NotificationFilterSupport()
        instance.enableType(p0)

    def getEnabledTypes_test_9548(self):
        instance = NotificationFilterSupport()
        instance.getEnabledTypes()

    def disableType_test_9549(self, p0: str):
        instance = NotificationFilterSupport()
        instance.disableType(p0)

    def disableAllTypes_test_9550(self):
        instance = NotificationFilterSupport()
        instance.disableAllTypes()

    def isNotificationEnabled_test_9551(self, p0: Notification):
        instance = NotificationFilterSupport()
        instance.isNotificationEnabled(p0)


class NotificationFilterSupportWrapper:
    """Wrapper class containing the methods called by the tests."""
    
    def __init__(self):
        self._instance = NotificationFilterSupport()

    def enableType(self, p0: str) -> None:
        self._instance.enableType(p0)

    def getEnabledTypes(self) -> List[str]:
        return self._instance.getEnabledTypes()

    def disableType(self, p0: str) -> None:
        self._instance.disableType(p0)

    def disableAllTypes(self) -> None:
        self._instance.disableAllTypes()

    def isNotificationEnabled(self, p0: Notification) -> bool:
        return self._instance.isNotificationEnabled(p0)


if __name__ == '__main__':
    unittest.main()