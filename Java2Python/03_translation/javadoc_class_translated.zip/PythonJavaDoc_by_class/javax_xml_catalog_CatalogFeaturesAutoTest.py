import unittest
from javax.xml.catalog import CatalogFeatures

class TestJavaxXmlCatalogCatalogFeaturesAutoTest(unittest.TestCase):
    def builder_test_2080(self):
        CatalogFeatures.builder()

    def defaults_test_2081(self):
        CatalogFeatures.defaults()


class CatalogFeaturesWrapper:
    @staticmethod
    def builder():
        return CatalogFeatures.builder()

    @staticmethod
    def defaults():
        return CatalogFeatures.defaults()


if __name__ == '__main__':
    unittest.main()