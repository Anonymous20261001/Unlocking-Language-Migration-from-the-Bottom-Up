import unittest
from unittest.mock import Mock
from io import BytesIO
import pickle


class TestStreamingExecutionControl(unittest.TestCase):

    def test_close_test_11512(self):
        c0 = Mock(spec=object)
        c1 = Mock(spec=object)
        instance = StreamingExecutionControl(c0, c1)
        instance.close()


class StreamingExecutionControl:
    def __init__(self, output, input):
        self.output = output
        self.input = input

    def close(self):
        pass