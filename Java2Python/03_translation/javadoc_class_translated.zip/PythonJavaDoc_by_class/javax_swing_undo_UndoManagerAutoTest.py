import unittest
from unittest.mock import Mock


class TestJavaxSwingUndoUndoManagerAutoTest(unittest.TestCase):

    def test_undoableEditHappened_test_13193(self):
        p0 = Mock()
        instance = UndoManager()
        instance.undoableEditHappened(p0)

    def test_addEdit_test_13194(self):
        p0 = Mock()
        instance = UndoManager()
        instance.addEdit(p0)

    def test_redo_test_13195(self):
        instance = UndoManager()
        instance.redo()

    def test_undo_test_13196(self):
        instance = UndoManager()
        instance.undo()

    def test_getUndoPresentationName_test_13197(self):
        instance = UndoManager()
        instance.getUndoPresentationName()

    def test_getRedoPresentationName_test_13198(self):
        instance = UndoManager()
        instance.getRedoPresentationName()

    def test_canUndo_test_13199(self):
        instance = UndoManager()
        instance.canUndo()

    def test_canRedo_test_13200(self):
        instance = UndoManager()
        instance.canRedo()

    def test_getLimit_test_13201(self):
        instance = UndoManager()
        instance.getLimit()

    def test_discardAllEdits_test_13202(self):
        instance = UndoManager()
        instance.discardAllEdits()

    def test_setLimit_test_13203(self):
        p0 = 10
        instance = UndoManager()
        instance.setLimit(p0)

    def test_undoOrRedo_test_13204(self):
        instance = UndoManager()
        instance.undoOrRedo()

    def test_canUndoOrRedo_test_13205(self):
        instance = UndoManager()
        instance.canUndoOrRedo()

    def test_getUndoOrRedoPresentationName_test_13206(self):
        instance = UndoManager()
        instance.getUndoOrRedoPresentationName()

    def test_end_test_13207(self):
        instance = UndoManager()
        instance.end()


class UndoableEditEvent:
    def __init__(self, source, edit):
        self.source = source
        self.edit = edit


class UndoableEdit:
    def __init__(self, presentation_name=""):
        self.presentation_name = presentation_name
        self._undoable = True
        self._redoable = True
        self._has_been_done = False

    def undo(self):
        self._has_been_done = False

    def redo(self):
        self._has_been_done = True

    def canUndo(self):
        return self._undoable

    def canRedo(self):
        return self._redoable

    def getPresentationName(self):
        return self.presentation_name


class UndoManager:
    def __init__(self):
        self.edits = []
        self.index = -1
        self.limit = 100
        self.in_progress = False

    def undoableEditHappened(self, e):
        if e.edit is not None:
            self.addEdit(e.edit)

    def addEdit(self, edit):
        if self.index != -1 and self.index < len(self.edits) - 1:
            self.edits = self.edits[:self.index + 1]
        self.edits.append(edit)
        self.index += 1
        if len(self.edits) > self.limit:
            self.edits.pop(0)
            self.index -= 1
        return True

    def redo(self):
        if self.canRedo():
            edit = self.edits[self.index + 1]
            edit.redo()
            self.index += 1

    def undo(self):
        if self.canUndo():
            edit = self.edits[self.index]
            edit.undo()
            self.index -= 1

    def getUndoPresentationName(self):
        if self.canUndo():
            return self.edits[self.index].getPresentationName()
        return ""

    def getRedoPresentationName(self):
        if self.canRedo():
            return self.edits[self.index + 1].getPresentationName()
        return ""

    def canUndo(self):
        return self.index >= 0 and self.edits[self.index].canUndo()

    def canRedo(self):
        return self.index < len(self.edits) - 1 and self.edits[self.index + 1].canRedo()

    def getLimit(self):
        return self.limit

    def discardAllEdits(self):
        self.edits = []
        self.index = -1

    def setLimit(self, limit):
        self.limit = limit
        while len(self.edits) > self.limit:
            self.edits.pop(0)
            self.index -= 1

    def undoOrRedo(self):
        if self.canUndo():
            self.undo()
        elif self.canRedo():
            self.redo()

    def canUndoOrRedo(self):
        return self.canUndo() or self.canRedo()

    def getUndoOrRedoPresentationName(self):
        if self.canUndo():
            return self.getUndoPresentationName()
        elif self.canRedo():
            return self.getRedoPresentationName()
        return ""

    def end(self):
        self.in_progress = False


if __name__ == '__main__':
    unittest.main()