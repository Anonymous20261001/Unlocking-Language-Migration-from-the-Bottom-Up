import unittest

class TestDataBufferAuto(unittest.TestCase):
    def test_getDataTypeSize_test_3173(self, p0):
        DataBufferWrapper.getDataTypeSize(p0)

class DataBufferWrapper:
    @staticmethod
    def getDataTypeSize(data_type):
        # Placeholder implementation - actual Java method returns size of data type
        sizes = {0: 8, 1: 16, 2: 32, 3: 32, 4: 64, 5: 32}
        if data_type not in sizes:
            raise ValueError(f"Invalid data type: {data_type}")
        return sizes[data_type]

if __name__ == '__main__':
    unittest.main()