import unittest
from typing import Optional


class TestHexFormat(unittest.TestCase):
    def of_test_5337(self):
        HexFormat.of()

    def fromHexDigits_test_5338(self, p0):
        HexFormat.fromHexDigits(p0)

    def fromHexDigits_test_5339(self, p0, p1, p2):
        HexFormat.fromHexDigits(p0, p1, p2)

    def fromHexDigit_test_5340(self, p0):
        HexFormat.fromHexDigit(p0)

    def fromHexDigitsToLong_test_5341(self, p0, p1, p2):
        HexFormat.fromHexDigitsToLong(p0, p1, p2)

    def fromHexDigitsToLong_test_5342(self, p0):
        HexFormat.fromHexDigitsToLong(p0)

    def ofDelimiter_test_5343(self, p0):
        HexFormat.ofDelimiter(p0)

    def isHexDigit_test_5344(self, p0):
        HexFormat.isHexDigit(p0)


class HexFormat:
    @staticmethod
    def of() -> 'HexFormat':
        return HexFormat()

    @staticmethod
    def fromHexDigits(chars) -> int:
        return int(str(chars), 16)

    @staticmethod
    def fromHexDigits(chars, start, end) -> int:
        return int(str(chars)[start:end], 16)

    @staticmethod
    def fromHexDigit(digit) -> int:
        return int(chr(digit), 16)

    @staticmethod
    def fromHexDigitsToLong(chars, start, end) -> int:
        return int(str(chars)[start:end], 16)

    @staticmethod
    def fromHexDigitsToLong(chars) -> int:
        return int(str(chars), 16)

    @staticmethod
    def ofDelimiter(delimiter) -> 'HexFormat':
        return HexFormat(delimiter)

    @staticmethod
    def isHexDigit(digit) -> bool:
        try:
            int(chr(digit), 16)
            return True
        except ValueError:
            return False

    def __init__(self, delimiter: Optional[str] = None):
        self.delimiter = delimiter if delimiter else ""