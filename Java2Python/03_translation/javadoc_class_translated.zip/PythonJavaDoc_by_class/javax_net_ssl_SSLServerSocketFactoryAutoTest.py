import unittest
import ssl

class TestSSLServerSocketFactory(unittest.TestCase):
    def getDefault_test_11437(self):
        ssl.SSLServerSocketFactory.get_default()


class SSLServerSocketFactory:
    @staticmethod
    def get_default():
        return None