import unittest
from datetime import timezone, timedelta
from typing import Any


class TestZoneOffset(unittest.TestCase):
    def of_test_13728(self, p0: str):
        ZoneOffset.of(p0)

    def from_test_13729(self, p0: Any):
        ZoneOffset.from(p0)

    def ofHours_test_13730(self, p0: int):
        ZoneOffset.ofHours(p0)

    def ofHoursMinutesSeconds_test_13731(self, p0: int, p1: int, p2: int):
        ZoneOffset.ofHoursMinutesSeconds(p0, p1, p2)

    def ofTotalSeconds_test_13732(self, p0: int):
        ZoneOffset.ofTotalSeconds(p0)

    def ofHoursMinutes_test_13733(self, p0: int, p1: int):
        ZoneOffset.ofHoursMinutes(p0, p1)


class ZoneOffset:
    @staticmethod
    def of(offset_id: str) -> 'ZoneOffset':
        """Parse the offset ID and create a ZoneOffset."""
        try:
            hours = int(offset_id[1:3])
            minutes = int(offset_id[4:6]) if len(offset_id) > 4 else 0
            seconds = int(offset_id[7:9]) if len(offset_id) > 7 else 0
            sign = -1 if offset_id[0] == '-' else 1
            total_seconds = sign * (hours * 3600 + minutes * 60 + seconds)
            return ZoneOffset(total_seconds)
        except (ValueError, IndexError):
            raise ValueError(f"Invalid offset ID: {offset_id}")

    @staticmethod
    def from(temporal: Any) -> 'ZoneOffset':
        """Get the ZoneOffset from a temporal object."""
        if hasattr(temporal, 'utcoffset'):
            offset = temporal.utcoffset()
            if offset is not None:
                return ZoneOffset(int(offset.total_seconds()))
        raise ValueError("Unable to obtain ZoneOffset from temporal")

    @staticmethod
    def ofHours(hours: int) -> 'ZoneOffset':
        """Create a ZoneOffset from hours."""
        if hours < -18 or hours > 18:
            raise ValueError("Zone offset hours out of range")
        return ZoneOffset(hours * 3600)

    @staticmethod
    def ofHoursMinutesSeconds(hours: int, minutes: int, seconds: int) -> 'ZoneOffset':
        """Create a ZoneOffset from hours, minutes, and seconds."""
        if hours < -18 or hours > 18:
            raise ValueError("Zone offset hours out of range")
        if minutes < -59 or minutes > 59:
            raise ValueError("Zone offset minutes out of range")
        if seconds < -59 or seconds > 59:
            raise ValueError("Zone offset seconds out of range")
        total_seconds = hours * 3600 + minutes * 60 + seconds
        if abs(total_seconds) > 18 * 3600:
            raise ValueError("Zone offset total seconds out of range")
        return ZoneOffset(total_seconds)

    @staticmethod
    def ofTotalSeconds(total_seconds: int) -> 'ZoneOffset':
        """Create a ZoneOffset from total seconds."""
        if total_seconds < -18 * 3600 or total_seconds > 18 * 3600:
            raise ValueError("Zone offset total seconds out of range")
        return ZoneOffset(total_seconds)

    @staticmethod
    def ofHoursMinutes(hours: int, minutes: int) -> 'ZoneOffset':
        """Create a ZoneOffset from hours and minutes."""
        return ZoneOffset.ofHoursMinutesSeconds(hours, minutes, 0)

    def __init__(self, total_seconds: int):
        self.total_seconds = total_seconds

    def __eq__(self, other):
        if isinstance(other, ZoneOffset):
            return self.total_seconds == other.total_seconds
        return False

    def __hash__(self):
        return hash(self.total_seconds)

    def __repr__(self):
        sign = '+' if self.total_seconds >= 0 else '-'
        abs_seconds = abs(self.total_seconds)
        hours = abs_seconds // 3600
        minutes = (abs_seconds % 3600) // 60
        seconds = abs_seconds % 60
        return f"ZoneOffset[{sign}{hours:02d}:{minutes:02d}:{seconds:02d}]"


if __name__ == '__main__':
    unittest.main()