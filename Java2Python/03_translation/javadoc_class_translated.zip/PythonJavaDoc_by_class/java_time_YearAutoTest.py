import unittest
from datetime import datetime
from typing import Any
import calendar


class Year:
    """Wrapper class mimicking java.time.Year"""
    
    def __init__(self, year):
        self.year = year
    
    @staticmethod
    def of(year):
        return Year(year)
    
    @staticmethod
    def from_(temporal):
        if hasattr(temporal, 'year'):
            return Year(temporal.year)
        raise ValueError("Cannot extract year from temporal")
    
    @staticmethod
    def parse(text, formatter=None):
        if formatter:
            dt = datetime.strptime(text, formatter)
            return Year(dt.year)
        else:
            # Try ISO format
            try:
                return Year(int(text))
            except:
                dt = datetime.strptime(text, "%Y")
                return Year(dt.year)
    
    @staticmethod
    def now(clock=None):
        if clock:
            return Year(clock.year)
        return Year(datetime.now().year)
    
    @staticmethod
    def is_leap(year):
        return calendar.isleap(year)
    
    def __repr__(self):
        return f"Year({self.year})"


class TestYearAuto(unittest.TestCase):
    def test_of_test_13666(self):
        Year.of(2020)
    
    def test_from_test_13667(self):
        class TempTemporal:
            year = 2023
        Year.from_(TempTemporal())
    
    def test_parse_test_13668(self):
        Year.parse("2023", "%Y")
    
    def test_parse_test_13669(self):
        Year.parse("2023")
    
    def test_now_test_13670(self):
        Year.now()
    
    def test_now_test_13671(self):
        class MockClock:
            year = 2024
        Year.now(MockClock())
    
    def test_now_test_13672(self):
        class MockZone:
            pass
        Year.now(MockZone())
    
    def test_isLeap_test_13673(self):
        Year.is_leap(2020)


if __name__ == '__main__':
    unittest.main()