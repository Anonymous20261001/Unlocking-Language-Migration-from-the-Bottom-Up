import unittest
from hashlib import sha256

class java_security_MessageDigestAutoTest(unittest.TestCase):
    def isEqual_test_8592(self, p0, p1):
        MessageDigest.isEqual(p0, p1)


class MessageDigest:
    @staticmethod
    def isEqual(digest_a, digest_b):
        if len(digest_a) != len(digest_b):
            return False
        result = 0
        for byte_a, byte_b in zip(digest_a, digest_b):
            result |= byte_a ^ byte_b
        return result == 0

if __name__ == '__main__':
    unittest.main()