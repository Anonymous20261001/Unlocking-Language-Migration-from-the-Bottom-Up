import unittest


class TestPageFormat(unittest.TestCase):
    def test_getWidth_test_9735(self):
        instance = PageFormat()
        instance.getWidth()

    def test_getHeight_test_9736(self):
        instance = PageFormat()
        instance.getHeight()

    def test_getOrientation_test_9737(self):
        instance = PageFormat()
        instance.getOrientation()

    def test_getMatrix_test_9738(self):
        instance = PageFormat()
        instance.getMatrix()

    def test_setOrientation_test_9739(self):
        instance = PageFormat()
        instance.setOrientation(0)

    def test_getImageableY_test_9740(self):
        instance = PageFormat()
        instance.getImageableY()

    def test_getImageableHeight_test_9741(self):
        instance = PageFormat()
        instance.getImageableHeight()

    def test_getImageableX_test_9742(self):
        instance = PageFormat()
        instance.getImageableX()

    def test_getImageableWidth_test_9743(self):
        instance = PageFormat()
        instance.getImageableWidth()

    def test_getPaper_test_9744(self):
        instance = PageFormat()
        instance.getPaper()

    def test_setPaper_test_9745(self):
        instance = PageFormat()
        instance.setPaper(Paper())


class PageFormat:
    def __init__(self):
        self.width = 612.0
        self.height = 792.0
        self.orientation = 0
        self.imageable_x = 0.0
        self.imageable_y = 0.0
        self.imageable_width = 612.0
        self.imageable_height = 792.0
        self.paper = None
        self.matrix = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]

    def getWidth(self):
        return self.width

    def getHeight(self):
        return self.height

    def getOrientation(self):
        return self.orientation

    def getMatrix(self):
        return self.matrix

    def setOrientation(self, orientation):
        self.orientation = orientation

    def getImageableY(self):
        return self.imageable_y

    def getImageableHeight(self):
        return self.imageable_height

    def getImageableX(self):
        return self.imageable_x

    def getImageableWidth(self):
        return self.imageable_width

    def getPaper(self):
        return self.paper

    def setPaper(self, paper):
        self.paper = paper


class Paper:
    def __init__(self):
        self.width = 612.0
        self.height = 792.0
        self.imageable_x = 0.0
        self.imageable_y = 0.0
        self.imageable_width = 612.0
        self.imageable_height = 792.0


if __name__ == '__main__':
    unittest.main()