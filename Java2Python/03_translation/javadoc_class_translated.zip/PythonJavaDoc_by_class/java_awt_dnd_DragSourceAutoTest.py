import unittest
from unittest.mock import MagicMock

class DragSource:
    def __init__(self):
        self.drag_source_listeners = []
        self.drag_source_motion_listeners = []
    
    @staticmethod
    def getDefaultDragSource():
        return DragSource()
    
    @staticmethod
    def isDragImageSupported():
        return True
    
    @staticmethod
    def getDragThreshold():
        return 10
    
    def addDragSourceListener(self, p0):
        self.drag_source_listeners.append(p0)
    
    def addDragSourceMotionListener(self, p0):
        self.drag_source_motion_listeners.append(p0)
    
    def createDefaultDragGestureRecognizer(self, p0, p1, p2):
        return MagicMock()
    
    def removeDragSourceListener(self, p0):
        if p0 in self.drag_source_listeners:
            self.drag_source_listeners.remove(p0)
    
    def getDragSourceListeners(self):
        return self.drag_source_listeners
    
    def removeDragSourceMotionListener(self, p0):
        if p0 in self.drag_source_motion_listeners:
            self.drag_source_motion_listeners.remove(p0)
    
    def getDragSourceMotionListeners(self):
        return self.drag_source_motion_listeners
    
    def getListeners(self, p0):
        return []
    
    def createDragGestureRecognizer(self, p0, p1, p2, p3):
        return MagicMock()
    
    def startDrag(self, *args):
        return MagicMock()
    
    def getFlavorMap(self):
        return MagicMock()


class TestDragSource(unittest.TestCase):
    def test_addDragSourceListener_test_4296(self):
        instance = DragSource()
        p0 = MagicMock()
        instance.addDragSourceListener(p0)

    def test_addDragSourceMotionListener_test_4297(self):
        instance = DragSource()
        p0 = MagicMock()
        instance.addDragSourceMotionListener(p0)

    def test_getDefaultDragSource_test_4298(self):
        DragSource.getDefaultDragSource()

    def test_isDragImageSupported_test_4299(self):
        DragSource.isDragImageSupported()

    def test_createDefaultDragGestureRecognizer_test_4300(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = 1
        p2 = MagicMock()
        instance.createDefaultDragGestureRecognizer(p0, p1, p2)

    def test_removeDragSourceListener_test_4301(self):
        instance = DragSource()
        p0 = MagicMock()
        instance.removeDragSourceListener(p0)

    def test_getDragSourceListeners_test_4302(self):
        instance = DragSource()
        instance.getDragSourceListeners()

    def test_removeDragSourceMotionListener_test_4303(self):
        instance = DragSource()
        p0 = MagicMock()
        instance.removeDragSourceMotionListener(p0)

    def test_getDragSourceMotionListeners_test_4304(self):
        instance = DragSource()
        instance.getDragSourceMotionListeners()

    def test_getDragThreshold_test_4305(self):
        DragSource.getDragThreshold()

    def test_getListeners_test_4306(self):
        instance = DragSource()
        p0 = MagicMock()
        instance.getListeners(p0)

    def test_createDragGestureRecognizer_test_4307(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = 1
        p3 = MagicMock()
        instance.createDragGestureRecognizer(p0, p1, p2, p3)

    def test_startDrag_test_4308(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        p3 = MagicMock()
        p4 = MagicMock()
        p5 = MagicMock()
        instance.startDrag(p0, p1, p2, p3, p4, p5)

    def test_startDrag_test_4309(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        p3 = MagicMock()
        instance.startDrag(p0, p1, p2, p3)

    def test_startDrag_test_4310(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        p3 = MagicMock()
        p4 = MagicMock()
        p5 = MagicMock()
        p6 = MagicMock()
        instance.startDrag(p0, p1, p2, p3, p4, p5, p6)

    def test_startDrag_test_4311(self):
        instance = DragSource()
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = MagicMock()
        p3 = MagicMock()
        p4 = MagicMock()
        instance.startDrag(p0, p1, p2, p3, p4)

    def test_getFlavorMap_test_4312(self):
        instance = DragSource()
        instance.getFlavorMap()


if __name__ == '__main__':
    unittest.main()