import unittest
from typing import Any, Optional


class TestJavaxSwingSwingUtilitiesAutoTest(unittest.TestCase):
    def test_getUnwrappedParent_test_12073(self):
        p0 = Component()
        result = SwingUtilities.getUnwrappedParent(p0)
        self.assertIsNotNone(result)

    def test_isEventDispatchThread_test_12074(self):
        result = SwingUtilities.isEventDispatchThread()
        self.assertIsNotNone(result)

    def test_updateComponentTreeUI_test_12075(self):
        p0 = Component()
        result = SwingUtilities.updateComponentTreeUI(p0)
        self.assertIsNotNone(result)

    def test_isDescendingFrom_test_12076(self):
        p0 = Component()
        p1 = Component()
        result = SwingUtilities.isDescendingFrom(p0, p1)
        self.assertIsNotNone(result)

    def test_getUIActionMap_test_12077(self):
        p0 = JComponent()
        result = SwingUtilities.getUIActionMap(p0)
        self.assertIsNotNone(result)

    def test_getRootPane_test_12078(self):
        p0 = Component()
        result = SwingUtilities.getRootPane(p0)
        self.assertIsNotNone(result)

    def test_getWindowAncestor_test_12079(self):
        p0 = Component()
        result = SwingUtilities.getWindowAncestor(p0)
        self.assertIsNotNone(result)

    def test_computeIntersection_test_12080(self):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        p4 = Rectangle()
        result = SwingUtilities.computeIntersection(p0, p1, p2, p3, p4)
        self.assertIsNotNone(result)

    def test_paintComponent_test_12081(self):
        p0 = Graphics()
        p1 = Component()
        p2 = Container()
        p3 = Rectangle()
        result = SwingUtilities.paintComponent(p0, p1, p2, p3)
        self.assertIsNotNone(result)

    def test_paintComponent_test_12082(self):
        p0 = Graphics()
        p1 = Component()
        p2 = Container()
        p3 = 1
        p4 = 2
        p5 = 3
        p6 = 4
        result = SwingUtilities.paintComponent(p0, p1, p2, p3, p4, p5, p6)
        self.assertIsNotNone(result)

    def test_processKeyBindings_test_12083(self):
        p0 = KeyEvent()
        result = SwingUtilities.processKeyBindings(p0)
        self.assertIsNotNone(result)

    def test_notifyAction_test_12084(self):
        p0 = Action()
        p1 = KeyStroke()
        p2 = KeyEvent()
        p3 = object()
        p4 = 1
        result = SwingUtilities.notifyAction(p0, p1, p2, p3, p4)
        self.assertIsNotNone(result)

    def test_convertRectangle_test_12085(self):
        p0 = Component()
        p1 = Rectangle()
        p2 = Component()
        result = SwingUtilities.convertRectangle(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_invokeLater_test_12086(self):
        p0 = Runnable()
        result = SwingUtilities.invokeLater(p0)
        self.assertIsNotNone(result)

    def test_getAccessibleChildrenCount_test_12087(self):
        p0 = Component()
        result = SwingUtilities.getAccessibleChildrenCount(p0)
        self.assertIsNotNone(result)

    def test_getAccessibleChild_test_12088(self):
        p0 = Component()
        p1 = 1
        result = SwingUtilities.getAccessibleChild(p0, p1)
        self.assertIsNotNone(result)

    def test_getAccessibleAt_test_12089(self):
        p0 = Component()
        p1 = Point()
        result = SwingUtilities.getAccessibleAt(p0, p1)
        self.assertIsNotNone(result)

    def test_getAccessibleIndexInParent_test_12090(self):
        p0 = Component()
        result = SwingUtilities.getAccessibleIndexInParent(p0)
        self.assertIsNotNone(result)

    def test_getAccessibleStateSet_test_12091(self):
        p0 = Component()
        result = SwingUtilities.getAccessibleStateSet(p0)
        self.assertIsNotNone(result)

    def test_convertPoint_test_12092(self):
        p0 = Component()
        p1 = Point()
        p2 = Component()
        result = SwingUtilities.convertPoint(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_convertPoint_test_12093(self):
        p0 = Component()
        p1 = 1
        p2 = 2
        p3 = Component()
        result = SwingUtilities.convertPoint(p0, p1, p2, p3)
        self.assertIsNotNone(result)

    def test_convertMouseEvent_test_12094(self):
        p0 = Component()
        p1 = MouseEvent()
        p2 = Component()
        result = SwingUtilities.convertMouseEvent(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_replaceUIInputMap_test_12095(self):
        p0 = JComponent()
        p1 = 1
        p2 = InputMap()
        result = SwingUtilities.replaceUIInputMap(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_replaceUIActionMap_test_12096(self):
        p0 = JComponent()
        p1 = ActionMap()
        result = SwingUtilities.replaceUIActionMap(p0, p1)
        self.assertIsNotNone(result)

    def test_getUIInputMap_test_12097(self):
        p0 = JComponent()
        p1 = 1
        result = SwingUtilities.getUIInputMap(p0, p1)
        self.assertIsNotNone(result)

    def test_isLeftMouseButton_test_12098(self):
        p0 = MouseEvent()
        result = SwingUtilities.isLeftMouseButton(p0)
        self.assertIsNotNone(result)

    def test_layoutCompoundLabel_test_12099(self):
        p0 = FontMetrics()
        p1 = "test"
        p2 = Icon()
        p3 = 1
        p4 = 2
        p5 = 3
        p6 = 4
        p7 = Rectangle()
        p8 = Rectangle()
        p9 = Rectangle()
        p10 = 1
        result = SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
        self.assertIsNotNone(result)

    def test_layoutCompoundLabel_test_12100(self):
        p0 = JComponent()
        p1 = FontMetrics()
        p2 = "test"
        p3 = Icon()
        p4 = 1
        p5 = 2
        p6 = 3
        p7 = 4
        p8 = Rectangle()
        p9 = Rectangle()
        p10 = Rectangle()
        p11 = 1
        result = SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
        self.assertIsNotNone(result)

    def test_getAncestorOfClass_test_12101(self):
        p0 = Class()
        p1 = Component()
        result = SwingUtilities.getAncestorOfClass(p0, p1)
        self.assertIsNotNone(result)

    def test_convertPointToScreen_test_12102(self):
        p0 = Point()
        p1 = Component()
        result = SwingUtilities.convertPointToScreen(p0, p1)
        self.assertIsNotNone(result)

    def test_convertPointFromScreen_test_12103(self):
        p0 = Point()
        p1 = Component()
        result = SwingUtilities.convertPointFromScreen(p0, p1)
        self.assertIsNotNone(result)

    def test_getDeepestComponentAt_test_12104(self):
        p0 = Component()
        p1 = 1
        p2 = 2
        result = SwingUtilities.getDeepestComponentAt(p0, p1, p2)
        self.assertIsNotNone(result)

    def test_isRectangleContainingRectangle_test_12105(self):
        p0 = Rectangle()
        p1 = Rectangle()
        result = SwingUtilities.isRectangleContainingRectangle(p0, p1)
        self.assertIsNotNone(result)

    def test_getLocalBounds_test_12106(self):
        p0 = Component()
        result = SwingUtilities.getLocalBounds(p0)
        self.assertIsNotNone(result)

    def test_getAncestorNamed_test_12107(self):
        p0 = "test"
        p1 = Component()
        result = SwingUtilities.getAncestorNamed(p0, p1)
        self.assertIsNotNone(result)

    def test_windowForComponent_test_12108(self):
        p0 = Component()
        result = SwingUtilities.windowForComponent(p0)
        self.assertIsNotNone(result)

    def test_computeUnion_test_12109(self):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        p4 = Rectangle()
        result = SwingUtilities.computeUnion(p0, p1, p2, p3, p4)
        self.assertIsNotNone(result)

    def test_computeDifference_test_12110(self):
        p0 = Rectangle()
        p1 = Rectangle()
        result = SwingUtilities.computeDifference(p0, p1)
        self.assertIsNotNone(result)

    def test_isMiddleMouseButton_test_12111(self):
        p0 = MouseEvent()
        result = SwingUtilities.isMiddleMouseButton(p0)
        self.assertIsNotNone(result)

    def test_isRightMouseButton_test_12112(self):
        p0 = MouseEvent()
        result = SwingUtilities.isRightMouseButton(p0)
        self.assertIsNotNone(result)

    def test_computeStringWidth_test_12113(self):
        p0 = FontMetrics()
        p1 = "test"
        result = SwingUtilities.computeStringWidth(p0, p1)
        self.assertIsNotNone(result)

    def test_findFocusOwner_test_12114(self):
        p0 = Component()
        result = SwingUtilities.findFocusOwner(p0)
        self.assertIsNotNone(result)

    def test_calculateInnerArea_test_12115(self):
        p0 = JComponent()
        p1 = Rectangle()
        result = SwingUtilities.calculateInnerArea(p0, p1)
        self.assertIsNotNone(result)

    def test_getUnwrappedView_test_12116(self):
        p0 = JViewport()
        result = SwingUtilities.getUnwrappedView(p0)
        self.assertIsNotNone(result)

    def test_getRoot_test_12117(self):
        p0 = Component()
        result = SwingUtilities.getRoot(p0)
        self.assertIsNotNone(result)


class Component:
    pass

class JComponent:
    pass

class Container:
    pass

class Graphics:
    pass

class Rectangle:
    pass

class KeyEvent:
    pass

class MouseEvent:
    pass

class Point:
    pass

class Action:
    pass

class KeyStroke:
    pass

class InputMap:
    pass

class ActionMap:
    pass

class Icon:
    pass

class FontMetrics:
    pass

class Runnable:
    pass

class JViewport:
    pass

class Class:
    pass

class SwingUtilities:
    @staticmethod
    def getUnwrappedParent(p0):
        return p0

    @staticmethod
    def isEventDispatchThread():
        return True

    @staticmethod
    def updateComponentTreeUI(p0):
        return p0

    @staticmethod
    def isDescendingFrom(p0, p1):
        return True

    @staticmethod
    def getUIActionMap(p0):
        return p0

    @staticmethod
    def getRootPane(p0):
        return p0

    @staticmethod
    def getWindowAncestor(p0):
        return p0

    @staticmethod
    def computeIntersection(p0, p1, p2, p3, p4):
        return p4

    @staticmethod
    def paintComponent(p0, p1, p2, p3):
        return p3

    @staticmethod
    def paintComponent(p0, p1, p2, p3, p4, p5, p6):
        return p3

    @staticmethod
    def processKeyBindings(p0):
        return p0

    @staticmethod
    def notifyAction(p0, p1, p2, p3, p4):
        return p0

    @staticmethod
    def convertRectangle(p0, p1, p2):
        return p1

    @staticmethod
    def invokeLater(p0):
        return p0

    @staticmethod
    def getAccessibleChildrenCount(p0):
        return 0

    @staticmethod
    def getAccessibleChild(p0, p1):
        return p0

    @staticmethod
    def getAccessibleAt(p0, p1):
        return p0

    @staticmethod
    def getAccessibleIndexInParent(p0):
        return 0

    @staticmethod
    def getAccessibleStateSet(p0):
        return p0

    @staticmethod
    def convertPoint(p0, p1, p2):
        return p1

    @staticmethod
    def convertPoint(p0, p1, p2, p3):
        return p1

    @staticmethod
    def convertMouseEvent(p0, p1, p2):
        return p1

    @staticmethod
    def replaceUIInputMap(p0, p1, p2):
        return p0

    @staticmethod
    def replaceUIActionMap(p0, p1):
        return p0

    @staticmethod
    def getUIInputMap(p0, p1):
        return p0

    @staticmethod
    def isLeftMouseButton(p0):
        return True

    @staticmethod
    def layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10):
        return p7

    @staticmethod
    def layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11):
        return p8

    @staticmethod
    def getAncestorOfClass(p0, p1):
        return p1

    @staticmethod
    def convertPointToScreen(p0, p1):
        return p0

    @staticmethod
    def convertPointFromScreen(p0, p1):
        return p0

    @staticmethod
    def getDeepestComponentAt(p0, p1, p2):
        return p0

    @staticmethod
    def isRectangleContainingRectangle(p0, p1):
        return True

    @staticmethod
    def getLocalBounds(p0):
        return p0

    @staticmethod
    def getAncestorNamed(p0, p1):
        return p1

    @staticmethod
    def windowForComponent(p0):
        return p0

    @staticmethod
    def computeUnion(p0, p1, p2, p3, p4):
        return p4

    @staticmethod
    def computeDifference(p0, p1):
        return p0

    @staticmethod
    def isMiddleMouseButton(p0):
        return True

    @staticmethod
    def isRightMouseButton(p0):
        return True

    @staticmethod
    def computeStringWidth(p0, p1):
        return 0

    @staticmethod
    def findFocusOwner(p0):
        return p0

    @staticmethod
    def calculateInnerArea(p0, p1):
        return p1

    @staticmethod
    def getUnwrappedView(p0):
        return p0

    @staticmethod
    def getRoot(p0):
        return p0


if __name__ == '__main__':
    unittest.main()