import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
import locale


class TestJavaUtilCalendarAutoTest(unittest.TestCase):
    def getInstance_test_2021(self):
        CalendarWrapper.getInstance()

    def getInstance_test_2022(self, p0):
        CalendarWrapper.getInstance(p0)

    def getInstance_test_2023(self, p0):
        CalendarWrapper.getInstance(p0)

    def getInstance_test_2024(self, p0, p1):
        CalendarWrapper.getInstance(p0, p1)

    def getAvailableLocales_test_2025(self):
        CalendarWrapper.getAvailableLocales()

    def getAvailableCalendarTypes_test_2026(self):
        CalendarWrapper.getAvailableCalendarTypes()


class CalendarWrapper:
    @staticmethod
    def getInstance(locale_or_timezone=None, locale_param=None):
        """Get current datetime, optionally with timezone/locale"""
        if locale_or_timezone is None:
            return datetime.now()
        elif isinstance(locale_or_timezone, str) and locale_param is None:
            # Timezone string
            return datetime.now(ZoneInfo(locale_or_timezone))
        elif isinstance(locale_or_timezone, str) and locale_param is not None:
            # Timezone + locale
            return datetime.now(ZoneInfo(locale_or_timezone))
        else:
            # Locale (string representation)
            return datetime.now()

    @staticmethod
    def getAvailableLocales():
        """Get list of available locales"""
        return list(locale.locale_alias.keys())

    @staticmethod
    def getAvailableCalendarTypes():
        """Get available calendar types"""
        return ['gregory', 'buddhist', 'japanese', 'roc', 'islamic']


if __name__ == '__main__':
    unittest.main()