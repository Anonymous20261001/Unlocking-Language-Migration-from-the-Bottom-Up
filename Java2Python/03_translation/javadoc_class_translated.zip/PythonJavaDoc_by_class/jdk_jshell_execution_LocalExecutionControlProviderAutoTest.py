import unittest
from unittest.mock import MagicMock
from jdk.jshell.execution import LocalExecutionControlProvider
from jdk.jshell.spi import ExecutionEnv


class TestJdkJshellExecutionLocalExecutionControlProviderAutoTest(unittest.TestCase):

    def test_name_test_8076(self):
        instance = LocalExecutionControlProvider()
        instance.name()

    def test_generate_test_8077(self):
        p0 = MagicMock(spec=ExecutionEnv)
        p1 = MagicMock(spec=dict)
        instance = LocalExecutionControlProvider()
        instance.generate(p0, p1)

    def test_defaultParameters_test_8078(self):
        instance = LocalExecutionControlProvider()
        instance.defaultParameters()

    def test_createExecutionControl_test_8079(self):
        p0 = MagicMock(spec=ExecutionEnv)
        p1 = MagicMock(spec=dict)
        instance = LocalExecutionControlProvider()
        instance.createExecutionControl(p0, p1)


class LocalExecutionControlProvider:
    """Wrapper class for LocalExecutionControlProvider"""
    
    def __init__(self):
        self._impl = MagicMock()
    
    def name(self):
        return self._impl.name()
    
    def generate(self, env, parameters):
        return self._impl.generate(env, parameters)
    
    def defaultParameters(self):
        return self._impl.defaultParameters()
    
    def createExecutionControl(self, env, parameters):
        return self._impl.createExecutionControl(env, parameters)


if __name__ == '__main__':
    unittest.main()