import unittest
from datetime import datetime
from typing import Iterable, List, Optional, Union


class RowFilter:
    """Wrapper class mimicking javax.swing.RowFilter static methods"""
    
    class ComparisonType:
        BEFORE = "BEFORE"
        AFTER = "AFTER"
        EQUALS = "EQUALS"
        NOT_EQUALS = "NOT_EQUALS"
    
    def __init__(self):
        pass
    
    @staticmethod
    def regexFilter(regex: str, indices: List[int]) -> None:
        """Static method mimicking regexFilter"""
        pass
    
    @staticmethod
    def dateFilter(comparison_type: ComparisonType, date: datetime, indices: List[int]) -> None:
        """Static method mimicking dateFilter"""
        pass
    
    @staticmethod
    def numberFilter(comparison_type: ComparisonType, number: Union[int, float], indices: List[int]) -> None:
        """Static method mimicking numberFilter"""
        pass
    
    @staticmethod
    def orFilter(filters: Iterable) -> None:
        """Static method mimicking orFilter"""
        pass
    
    @staticmethod
    def andFilter(filters: Iterable) -> None:
        """Static method mimicking andFilter"""
        pass
    
    @staticmethod
    def notFilter(filter_obj: 'RowFilter') -> None:
        """Static method mimicking notFilter"""
        pass


class TestRowFilterAutoTest(unittest.TestCase):
    def test_regexFilter_test_10708(self):
        p0 = "test.*"
        p1 = [0, 1, 2]
        RowFilter.regexFilter(p0, p1)

    def test_dateFilter_test_10709(self):
        p0 = RowFilter.ComparisonType.AFTER
        p1 = datetime(2023, 1, 1)
        p2 = [0, 1]
        RowFilter.dateFilter(p0, p1, p2)

    def test_numberFilter_test_10710(self):
        p0 = RowFilter.ComparisonType.EQUALS
        p1 = 42
        p2 = [0, 1, 2]
        RowFilter.numberFilter(p0, p1, p2)

    def test_orFilter_test_10711(self):
        p0 = [RowFilter(), RowFilter()]
        RowFilter.orFilter(p0)

    def test_andFilter_test_10712(self):
        p0 = [RowFilter(), RowFilter()]
        RowFilter.andFilter(p0)

    def test_notFilter_test_10713(self):
        p0 = RowFilter()
        RowFilter.notFilter(p0)


if __name__ == '__main__':
    unittest.main()