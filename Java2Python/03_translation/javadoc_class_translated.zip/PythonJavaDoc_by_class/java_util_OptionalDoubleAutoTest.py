import unittest
import math

class TestOptionalDouble(unittest.TestCase):
    
    def of_test_9692(self, p0):
        OptionalDouble.of(p0)
    
    def empty_test_9693(self):
        OptionalDouble.empty()


class OptionalDouble:
    """Wrapper class for OptionalDouble functionality"""
    
    def __init__(self, value=None, empty=True):
        self._value = value
        self._empty = empty
    
    @staticmethod
    def of(value):
        if not isinstance(value, (int, float)):
            raise ValueError("Value must be a double")
        return OptionalDouble(value, empty=False)
    
    @staticmethod
    def empty():
        return OptionalDouble(empty=True)
    
    def is_present(self):
        return not self._empty
    
    def get_as_double(self):
        if self._empty:
            raise ValueError("No value present")
        return self._value
    
    def or_else(self, other):
        return self._value if not self._empty else other
    
    def or_else_get(self, supplier):
        return self._value if not self._empty else supplier()
    
    def __eq__(self, other):
        if not isinstance(other, OptionalDouble):
            return False
        if self._empty and other._empty:
            return True
        if self._empty != other._empty:
            return False
        return self._value == other._value
    
    def __hash__(self):
        return hash((self._value, self._empty))
    
    def __repr__(self):
        if self._empty:
            return "OptionalDouble.empty"
        return f"OptionalDouble[{self._value}]"

if __name__ == '__main__':
    unittest.main()