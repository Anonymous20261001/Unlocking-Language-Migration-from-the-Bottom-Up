import unittest
from javax.swing import BorderFactory
from java.awt import Color, Font, BasicStroke, Paint
from javax.swing import Icon
from javax.swing.border import Border

class TestBorderFactory(unittest.TestCase):
    def test_createLoweredBevelBorder_test_1780(self):
        BorderFactory.createLoweredBevelBorder()

    def test_createBevelBorder_test_1781(self):
        p0 = 1
        BorderFactory.createBevelBorder(p0)

    def test_createBevelBorder_test_1782(self):
        p0 = 1
        p1 = Color.RED
        p2 = Color.BLUE
        BorderFactory.createBevelBorder(p0, p1, p2)

    def test_createBevelBorder_test_1783(self):
        p0 = 1
        p1 = Color.RED
        p2 = Color.BLUE
        p3 = Color.GREEN
        p4 = Color.YELLOW
        BorderFactory.createBevelBorder(p0, p1, p2, p3, p4)

    def test_createSoftBevelBorder_test_1784(self):
        p0 = 1
        BorderFactory.createSoftBevelBorder(p0)

    def test_createSoftBevelBorder_test_1785(self):
        p0 = 1
        p1 = Color.RED
        p2 = Color.BLUE
        BorderFactory.createSoftBevelBorder(p0, p1, p2)

    def test_createSoftBevelBorder_test_1786(self):
        p0 = 1
        p1 = Color.RED
        p2 = Color.BLUE
        p3 = Color.GREEN
        p4 = Color.YELLOW
        BorderFactory.createSoftBevelBorder(p0, p1, p2, p3, p4)

    def test_createEtchedBorder_test_1787(self):
        p0 = Color.RED
        p1 = Color.BLUE
        BorderFactory.createEtchedBorder(p0, p1)

    def test_createEtchedBorder_test_1788(self):
        p0 = 1
        BorderFactory.createEtchedBorder(p0)

    def test_createEtchedBorder_test_1789(self):
        BorderFactory.createEtchedBorder()

    def test_createEtchedBorder_test_1790(self):
        p0 = 1
        p1 = Color.RED
        p2 = Color.BLUE
        BorderFactory.createEtchedBorder(p0, p1, p2)

    def test_createTitledBorder_test_1791(self):
        p0 = BorderFactory.createEmptyBorder()
        p1 = "Title"
        p2 = 1
        p3 = 2
        p4 = Font("Arial", Font.PLAIN, 12)
        BorderFactory.createTitledBorder(p0, p1, p2, p3, p4)

    def test_createTitledBorder_test_1792(self):
        p0 = BorderFactory.createEmptyBorder()
        p1 = "Title"
        p2 = 1
        p3 = 2
        p4 = Font("Arial", Font.PLAIN, 12)
        p5 = Color.RED
        BorderFactory.createTitledBorder(p0, p1, p2, p3, p4, p5)

    def test_createTitledBorder_test_1793(self):
        p0 = "Title"
        BorderFactory.createTitledBorder(p0)

    def test_createTitledBorder_test_1794(self):
        p0 = BorderFactory.createEmptyBorder()
        BorderFactory.createTitledBorder(p0)

    def test_createTitledBorder_test_1795(self):
        p0 = BorderFactory.createEmptyBorder()
        p1 = "Title"
        BorderFactory.createTitledBorder(p0, p1)

    def test_createTitledBorder_test_1796(self):
        p0 = BorderFactory.createEmptyBorder()
        p1 = "Title"
        p2 = 1
        p3 = 2
        BorderFactory.createTitledBorder(p0, p1, p2, p3)

    def test_createCompoundBorder_test_1797(self):
        BorderFactory.createCompoundBorder()

    def test_createCompoundBorder_test_1798(self):
        p0 = BorderFactory.createEmptyBorder()
        p1 = BorderFactory.createEmptyBorder()
        BorderFactory.createCompoundBorder(p0, p1)

    def test_createMatteBorder_test_1799(self):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        p4 = Color.RED
        BorderFactory.createMatteBorder(p0, p1, p2, p3, p4)

    def test_createMatteBorder_test_1800(self):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        p4 = None  # Icon
        BorderFactory.createMatteBorder(p0, p1, p2, p3, p4)

    def test_createRaisedBevelBorder_test_1801(self):
        BorderFactory.createRaisedBevelBorder()

    def test_createRaisedSoftBevelBorder_test_1802(self):
        BorderFactory.createRaisedSoftBevelBorder()

    def test_createLoweredSoftBevelBorder_test_1803(self):
        BorderFactory.createLoweredSoftBevelBorder()

    def test_createDashedBorder_test_1804(self):
        p0 = Color.RED
        BorderFactory.createDashedBorder(p0)

    def test_createDashedBorder_test_1805(self):
        p0 = Color.RED
        p1 = 1.0
        p2 = 2.0
        BorderFactory.createDashedBorder(p0, p1, p2)

    def test_createDashedBorder_test_1806(self):
        p0 = Color.RED
        p1 = 1.0
        p2 = 2.0
        p3 = 3.0
        p4 = True
        BorderFactory.createDashedBorder(p0, p1, p2, p3, p4)

    def test_createStrokeBorder_test_1807(self):
        p0 = BasicStroke(1.0)
        p1 = Color.RED
        BorderFactory.createStrokeBorder(p0, p1)

    def test_createStrokeBorder_test_1808(self):
        p0 = BasicStroke(1.0)
        BorderFactory.createStrokeBorder(p0)

    def test_createEmptyBorder_test_1809(self):
        BorderFactory.createEmptyBorder()

    def test_createEmptyBorder_test_1810(self):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        BorderFactory.createEmptyBorder(p0, p1, p2, p3)

    def test_createLineBorder_test_1811(self):
        p0 = Color.RED
        p1 = 1
        p2 = True
        BorderFactory.createLineBorder(p0, p1, p2)

    def test_createLineBorder_test_1812(self):
        p0 = Color.RED
        BorderFactory.createLineBorder(p0)

    def test_createLineBorder_test_1813(self):
        p0 = Color.RED
        p1 = 1
        BorderFactory.createLineBorder(p0, p1)

class BorderFactoryWrapper:
    @staticmethod
    def createLoweredBevelBorder():
        return BorderFactory.createLoweredBevelBorder()

    @staticmethod
    def createBevelBorder(p0):
        return BorderFactory.createBevelBorder(p0)

    @staticmethod
    def createBevelBorder(p0, p1, p2):
        return BorderFactory.createBevelBorder(p0, p1, p2)

    @staticmethod
    def createBevelBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createBevelBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createSoftBevelBorder(p0):
        return BorderFactory.createSoftBevelBorder(p0)

    @staticmethod
    def createSoftBevelBorder(p0, p1, p2):
        return BorderFactory.createSoftBevelBorder(p0, p1, p2)

    @staticmethod
    def createSoftBevelBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createSoftBevelBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createEtchedBorder(p0, p1):
        return BorderFactory.createEtchedBorder(p0, p1)

    @staticmethod
    def createEtchedBorder(p0):
        return BorderFactory.createEtchedBorder(p0)

    @staticmethod
    def createEtchedBorder():
        return BorderFactory.createEtchedBorder()

    @staticmethod
    def createEtchedBorder(p0, p1, p2):
        return BorderFactory.createEtchedBorder(p0, p1, p2)

    @staticmethod
    def createTitledBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createTitledBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createTitledBorder(p0, p1, p2, p3, p4, p5):
        return BorderFactory.createTitledBorder(p0, p1, p2, p3, p4, p5)

    @staticmethod
    def createTitledBorder(p0):
        return BorderFactory.createTitledBorder(p0)

    @staticmethod
    def createTitledBorder(p0):
        return BorderFactory.createTitledBorder(p0)

    @staticmethod
    def createTitledBorder(p0, p1):
        return BorderFactory.createTitledBorder(p0, p1)

    @staticmethod
    def createTitledBorder(p0, p1, p2, p3):
        return BorderFactory.createTitledBorder(p0, p1, p2, p3)

    @staticmethod
    def createCompoundBorder():
        return BorderFactory.createCompoundBorder()

    @staticmethod
    def createCompoundBorder(p0, p1):
        return BorderFactory.createCompoundBorder(p0, p1)

    @staticmethod
    def createMatteBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createMatteBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createMatteBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createMatteBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createRaisedBevelBorder():
        return BorderFactory.createRaisedBevelBorder()

    @staticmethod
    def createRaisedSoftBevelBorder():
        return BorderFactory.createRaisedSoftBevelBorder()

    @staticmethod
    def createLoweredSoftBevelBorder():
        return BorderFactory.createLoweredSoftBevelBorder()

    @staticmethod
    def createDashedBorder(p0):
        return BorderFactory.createDashedBorder(p0)

    @staticmethod
    def createDashedBorder(p0, p1, p2):
        return BorderFactory.createDashedBorder(p0, p1, p2)

    @staticmethod
    def createDashedBorder(p0, p1, p2, p3, p4):
        return BorderFactory.createDashedBorder(p0, p1, p2, p3, p4)

    @staticmethod
    def createStrokeBorder(p0, p1):
        return BorderFactory.createStrokeBorder(p0, p1)

    @staticmethod
    def createStrokeBorder(p0):
        return BorderFactory.createStrokeBorder(p0)

    @staticmethod
    def createEmptyBorder():
        return BorderFactory.createEmptyBorder()

    @staticmethod
    def createEmptyBorder(p0, p1, p2, p3):
        return BorderFactory.createEmptyBorder(p0, p1, p2, p3)

    @staticmethod
    def createLineBorder(p0, p1, p2):
        return BorderFactory.createLineBorder(p0, p1, p2)

    @staticmethod
    def createLineBorder(p0):
        return BorderFactory.createLineBorder(p0)

    @staticmethod
    def createLineBorder(p0, p1):
        return BorderFactory.createLineBorder(p0, p1)

if __name__ == '__main__':
    unittest.main()