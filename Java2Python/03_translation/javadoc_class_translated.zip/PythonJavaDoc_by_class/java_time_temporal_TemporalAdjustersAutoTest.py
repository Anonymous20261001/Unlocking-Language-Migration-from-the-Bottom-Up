import unittest
from datetime import date
from enum import Enum
from typing import Callable


class DayOfWeek(Enum):
    MONDAY = 1
    TUESDAY = 2
    WEDNESDAY = 3
    THURSDAY = 4
    FRIDAY = 5
    SATURDAY = 6
    SUNDAY = 7


class TemporalAdjusters:
    @staticmethod
    def dayOfWeekInMonth(ordinal: int, dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            first_day = date(d.year, d.month, 1)
            first_target = first_day
            while first_target.weekday() != (dayOfWeek.value - 1):
                first_target = first_target.replace(day=first_target.day + 1)
            target_day = first_target.day + (ordinal - 1) * 7
            if target_day > 28 and target_day + 7 <= 31:
                # Check if next occurrence is still in same month
                next_occurrence = first_target.replace(day=target_day + 7)
                if next_occurrence.month == d.month:
                    target_day += 7
            return d.replace(day=min(target_day, 28))
        return adjuster

    @staticmethod
    def ofDateAdjuster(adjuster: Callable[[date], date]) -> Callable[[date], date]:
        return adjuster

    @staticmethod
    def firstDayOfMonth() -> Callable[[date], date]:
        return lambda d: d.replace(day=1)

    @staticmethod
    def firstDayOfNextMonth() -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            if d.month == 12:
                return date(d.year + 1, 1, 1)
            return date(d.year, d.month + 1, 1)
        return adjuster

    @staticmethod
    def lastDayOfYear() -> Callable[[date], date]:
        return lambda d: date(d.year, 12, 31)

    @staticmethod
    def firstDayOfNextYear() -> Callable[[date], date]:
        return lambda d: date(d.year + 1, 1, 1)

    @staticmethod
    def firstInMonth(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            first_day = date(d.year, d.month, 1)
            while first_day.weekday() != (dayOfWeek.value - 1):
                first_day = first_day.replace(day=first_day.day + 1)
            return first_day
        return adjuster

    @staticmethod
    def lastInMonth(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            last_day = date(d.year, d.month, 28)
            while last_day.month == d.month:
                if last_day.weekday() == (dayOfWeek.value - 1):
                    return last_day
                last_day = last_day.replace(day=last_day.day + 1)
            return last_day.replace(day=last_day.day - 1)
        return adjuster

    @staticmethod
    def next(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            result = d
            while True:
                result = result.replace(day=result.day + 1)
                if result.weekday() == (dayOfWeek.value - 1):
                    return result
        return adjuster

    @staticmethod
    def previous(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            result = d
            while True:
                result = result.replace(day=result.day - 1)
                if result.weekday() == (dayOfWeek.value - 1):
                    return result
        return adjuster

    @staticmethod
    def firstDayOfYear() -> Callable[[date], date]:
        return lambda d: date(d.year, 1, 1)

    @staticmethod
    def lastDayOfMonth() -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            if d.month == 12:
                return date(d.year, 12, 31)
            return date(d.year, d.month + 1, 1).replace(day=1) - __import__('datetime').timedelta(days=1)
        return adjuster

    @staticmethod
    def nextOrSame(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            if d.weekday() == (dayOfWeek.value - 1):
                return d
            result = d
            while True:
                result = result.replace(day=result.day + 1)
                if result.weekday() == (dayOfWeek.value - 1):
                    return result
        return adjuster

    @staticmethod
    def previousOrSame(dayOfWeek: DayOfWeek) -> Callable[[date], date]:
        def adjuster(d: date) -> date:
            if d.weekday() == (dayOfWeek.value - 1):
                return d
            result = d
            while True:
                result = result.replace(day=result.day - 1)
                if result.weekday() == (dayOfWeek.value - 1):
                    return result
        return adjuster


class TestTemporalAdjusters(unittest.TestCase):
    def test_dayOfWeekInMonth_test_12520(self):
        p0 = 2
        p1 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.dayOfWeekInMonth(p0, p1)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_ofDateAdjuster_test_12521(self):
        p0 = lambda d: d
        adjuster = TemporalAdjusters.ofDateAdjuster(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 1, 15))

    def test_firstDayOfMonth_test_12522(self):
        adjuster = TemporalAdjusters.firstDayOfMonth()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 1, 1))

    def test_firstDayOfNextMonth_test_12523(self):
        adjuster = TemporalAdjusters.firstDayOfNextMonth()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 2, 1))

    def test_lastDayOfYear_test_12524(self):
        adjuster = TemporalAdjusters.lastDayOfYear()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 12, 31))

    def test_firstDayOfNextYear_test_12525(self):
        adjuster = TemporalAdjusters.firstDayOfNextYear()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2025, 1, 1))

    def test_firstInMonth_test_12526(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.firstInMonth(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_lastInMonth_test_12527(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.lastInMonth(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_next_test_12528(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.next(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_previous_test_12529(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.previous(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_firstDayOfYear_test_12530(self):
        adjuster = TemporalAdjusters.firstDayOfYear()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 1, 1))

    def test_lastDayOfMonth_test_12531(self):
        adjuster = TemporalAdjusters.lastDayOfMonth()
        result = adjuster(date(2024, 1, 15))
        self.assertEqual(result, date(2024, 1, 31))

    def test_nextOrSame_test_12532(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.nextOrSame(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)

    def test_previousOrSame_test_12533(self):
        p0 = DayOfWeek.MONDAY
        adjuster = TemporalAdjusters.previousOrSame(p0)
        result = adjuster(date(2024, 1, 15))
        self.assertIsNotNone(result)


if __name__ == '__main__':
    unittest.main()