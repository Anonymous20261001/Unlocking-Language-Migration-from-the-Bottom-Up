import unittest
from unittest.mock import MagicMock
from typing import List, Optional


class TestAccessController(unittest.TestCase):
    
    def test_checkPermission_test_28(self):
        p0 = MagicMock()
        AccessController.checkPermission(p0)
    
    def test_doPrivileged_test_29(self):
        p0 = MagicMock()
        AccessController.doPrivileged(p0)
    
    def test_doPrivileged_test_30(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = [MagicMock()]
        AccessController.doPrivileged(p0, p1, p2)
    
    def test_doPrivileged_test_31(self):
        p0 = MagicMock()
        p1 = MagicMock()
        AccessController.doPrivileged(p0, p1)
    
    def test_doPrivilegedWithCombiner_test_32(self):
        p0 = MagicMock()
        AccessController.doPrivilegedWithCombiner(p0)
    
    def test_doPrivilegedWithCombiner_test_33(self):
        p0 = MagicMock()
        p1 = MagicMock()
        p2 = [MagicMock()]
        AccessController.doPrivilegedWithCombiner(p0, p1, p2)
    
    def test_getContext_test_34(self):
        AccessController.getContext()


class AccessController:
    """Wrapper class for AccessController methods"""
    
    @staticmethod
    def checkPermission(perm):
        pass
    
    @staticmethod
    def doPrivileged(action, context=None, perms=None):
        pass
    
    @staticmethod
    def doPrivilegedWithCombiner(action, context=None, perms=None):
        pass
    
    @staticmethod
    def getContext():
        pass


if __name__ == '__main__':
    unittest.main()