import unittest
from typing import List, Collection
from types import ModuleType


class TestConfiguration(unittest.TestCase):
    def test_empty_test_2903(self):
        Configuration.empty()

    def test_resolve_test_2904(self):
        p0 = ModuleFinder()
        p1 = List()
        p2 = ModuleFinder()
        p3 = Collection()
        Configuration.resolve(p0, p1, p2, p3)

    def test_resolveAndBind_test_2905(self):
        p0 = ModuleFinder()
        p1 = List()
        p2 = ModuleFinder()
        p3 = Collection()
        Configuration.resolveAndBind(p0, p1, p2, p3)


class ModuleFinder:
    def __init__(self):
        pass


class Collection:
    def __init__(self):
        pass


class Configuration:
    @staticmethod
    def empty():
        pass

    @staticmethod
    def resolve(p0, p1, p2, p3):
        pass

    @staticmethod
    def resolveAndBind(p0, p1, p2, p3):
        pass


if __name__ == '__main__':
    unittest.main()