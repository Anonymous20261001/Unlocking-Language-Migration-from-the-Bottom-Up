import unittest

class TestCertPathValidator(unittest.TestCase):
    def test_getDefaultType_test_2101(self):
        CertPathValidatorWrapper.getDefaultType()


class CertPathValidatorWrapper:
    @staticmethod
    def getDefaultType():
        return "PKIX"