import unittest
from unittest.mock import MagicMock, patch
import jdk.dynalink.DynamicLinker

class TestJdkDynalinkDynamicLinkerAutoTest(unittest.TestCase):
    def test_getLinkedCallSiteLocation_test_4424(self):
        with patch.object(DynamicLinker, 'getLinkedCallSiteLocation') as mock_method:
            mock_method.return_value = None
            result = DynamicLinker.getLinkedCallSiteLocation()
            mock_method.assert_called_once()
            self.assertIsNone(result)


class DynamicLinkerWrapper:
    @staticmethod
    def getLinkedCallSiteLocation():
        return DynamicLinker.getLinkedCallSiteLocation()