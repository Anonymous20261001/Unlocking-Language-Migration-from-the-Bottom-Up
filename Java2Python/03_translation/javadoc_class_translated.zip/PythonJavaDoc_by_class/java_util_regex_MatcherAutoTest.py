import unittest
import re

class TestMatcherAutoTest(unittest.TestCase):
    def test_quoteReplacement_test_8295(self):
        p0 = "test string"
        result = MatcherWrapper.quote_replacement(p0)
        self.assertIsInstance(result, str)

class MatcherWrapper:
    @staticmethod
    def quote_replacement(s):
        return re.escape(s)