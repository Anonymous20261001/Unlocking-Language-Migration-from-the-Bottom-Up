import unittest
from javax.management import ObjectName


class TestJavaxManagementObjectName(unittest.TestCase):
    def test_unquote_test_9594(self):
        p0 = "test_string"
        ObjectName.unquote(p0)

    def test_getInstance_test_9595(self):
        p0 = ObjectName("test:key=value")
        ObjectName.getInstance(p0)

    def test_quote_test_9596(self):
        p0 = "test_string"
        ObjectName.quote(p0)


class ObjectNameWrapper:
    @staticmethod
    def unquote(p0):
        return ObjectName.unquote(p0)

    @staticmethod
    def getInstance(p0):
        return ObjectName.getInstance(p0)

    @staticmethod
    def quote(p0):
        return ObjectName.quote(p0)


if __name__ == '__main__':
    unittest.main()