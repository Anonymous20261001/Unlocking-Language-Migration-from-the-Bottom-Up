import unittest
from java.nio.file.attribute import AclEntry

class TestAclEntry(unittest.TestCase):
    def test_newBuilder_test_55(self):
        p0 = AclEntry()
        AclEntry.newBuilder(p0)

    def test_newBuilder_test_56(self):
        AclEntry.newBuilder()


class AclEntryWrapper:
    @staticmethod
    def newBuilder(p0=None):
        if p0 is not None:
            return AclEntry.Builder(p0)
        return AclEntry.Builder()

    class Builder:
        def __init__(self, acl_entry=None):
            self.acl_entry = acl_entry

        def build(self):
            return self.acl_entry if self.acl_entry else AclEntry()

if __name__ == '__main__':
    unittest.main()