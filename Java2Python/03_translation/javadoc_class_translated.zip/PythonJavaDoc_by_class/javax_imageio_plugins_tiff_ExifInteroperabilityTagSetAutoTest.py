import unittest

class TestExifInteroperabilityTagSet(unittest.TestCase):
    def getInstance_test_4662(self):
        ExifInteroperabilityTagSetWrapper.getInstance()

class ExifInteroperabilityTagSetWrapper:
    @staticmethod
    def getInstance():
        return ExifInteroperabilityTagSet()

class ExifInteroperabilityTagSet:
    pass

if __name__ == '__main__':
    unittest.main()