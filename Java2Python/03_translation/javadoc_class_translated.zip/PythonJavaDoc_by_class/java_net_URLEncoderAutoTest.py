import unittest
from urllib.parse import quote
from urllib.parse import quote_plus


class TestJavaNetURLEncoderAutoTest(unittest.TestCase):
    def encode_test_13267(self, p0):
        URLEncoderWrapper.encode(p0)

    def encode_test_13268(self, p0, p1):
        URLEncoderWrapper.encode(p0, p1)


class URLEncoderWrapper:
    @staticmethod
    def encode(p0):
        return quote_plus(p0)

    @staticmethod
    def encode(p0, p1):
        # Python's quote doesn't support charset directly, but we can use encoding
        return quote_plus(p0, encoding=p1.name)


if __name__ == '__main__':
    unittest.main()