import unittest
from javax.swing.filechooser import FileSystemView

class TestFileSystemView(unittest.TestCase):
    def getFileSystemView_test_4781(self):
        FileSystemView.getFileSystemView()


class FileSystemViewWrapper:
    @staticmethod
    def getFileSystemView():
        return FileSystemView.getFileSystemView()