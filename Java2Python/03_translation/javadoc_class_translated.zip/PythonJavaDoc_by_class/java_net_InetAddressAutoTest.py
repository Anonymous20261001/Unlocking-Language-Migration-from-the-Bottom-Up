import unittest
import socket


class TestInetAddress(unittest.TestCase):

    def ofLiteral_test_5795(self, p0):
        socket.inet_aton(p0)

    def getLoopbackAddress_test_5796(self):
        socket.gethostbyname('localhost')


class InetAddressWrapper:
    @staticmethod
    def ofLiteral(p0):
        return socket.inet_aton(p0)

    @staticmethod
    def getLoopbackAddress():
        return socket.gethostbyname('localhost')


if __name__ == '__main__':
    unittest.main()