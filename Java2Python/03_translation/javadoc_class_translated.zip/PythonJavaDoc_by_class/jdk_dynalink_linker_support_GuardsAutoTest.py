import unittest
from typing import Any
import java.lang.Class as Class
import java.lang.Object as Object
import java.lang.invoke.MethodHandle as MethodHandle
import java.lang.invoke.MethodType as MethodType
import jdk.dynalink.linker.LinkerServices as LinkerServices
import jdk.dynalink.linker.support.Guards as Guards


class TestGuards(unittest.TestCase):
    def test_isInstance_test_5248(self):
        p0 = Class()
        p1 = MethodType()
        Guards.isInstance(p0, p1)

    def test_isInstance_test_5249(self):
        p0 = Class()
        p1 = 0
        p2 = MethodType()
        Guards.isInstance(p0, p1, p2)

    def test_isArray_test_5250(self):
        p0 = 0
        p1 = MethodType()
        Guards.isArray(p0, p1)

    def test_asType_test_5251(self):
        p0 = LinkerServices()
        p1 = MethodHandle()
        p2 = MethodType()
        Guards.asType(p0, p1, p2)

    def test_asType_test_5252(self):
        p0 = MethodHandle()
        p1 = MethodType()
        Guards.asType(p0, p1)

    def test_isNull_test_5253(self):
        Guards.isNull()

    def test_isOfClass_test_5254(self):
        p0 = Class()
        p1 = MethodType()
        Guards.isOfClass(p0, p1)

    def test_isNotNull_test_5255(self):
        Guards.isNotNull()

    def test_getClassGuard_test_5256(self):
        p0 = Class()
        Guards.getClassGuard(p0)

    def test_getInstanceOfGuard_test_5257(self):
        p0 = Class()
        Guards.getInstanceOfGuard(p0)

    def test_getIdentityGuard_test_5258(self):
        p0 = Object()
        Guards.getIdentityGuard(p0)


class Guards:
    @staticmethod
    def isInstance(p0: Class, p1: Any, *args) -> None:
        pass

    @staticmethod
    def isArray(p0: int, p1: MethodType) -> None:
        pass

    @staticmethod
    def asType(p0: Any, p1: MethodHandle, p2: MethodType) -> None:
        pass

    @staticmethod
    def isNull() -> None:
        pass

    @staticmethod
    def isOfClass(p0: Class, p1: MethodType) -> None:
        pass

    @staticmethod
    def isNotNull() -> None:
        pass

    @staticmethod
    def getClassGuard(p0: Class) -> None:
        pass

    @staticmethod
    def getInstanceOfGuard(p0: Class) -> None:
        pass

    @staticmethod
    def getIdentityGuard(p0: Object) -> None:
        pass


if __name__ == '__main__':
    unittest.main()