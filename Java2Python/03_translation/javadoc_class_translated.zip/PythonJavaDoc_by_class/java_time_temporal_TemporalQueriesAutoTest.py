import unittest

class TemporalQueries:
    @staticmethod
    def offset():
        pass
    
    @staticmethod
    def zone():
        pass
    
    @staticmethod
    def precision():
        pass
    
    @staticmethod
    def chronology():
        pass
    
    @staticmethod
    def zoneId():
        pass
    
    @staticmethod
    def localDate():
        pass
    
    @staticmethod
    def localTime():
        pass


class TestTemporalQueries(unittest.TestCase):
    def test_offset_test_12534(self):
        TemporalQueries.offset()
    
    def test_zone_test_12535(self):
        TemporalQueries.zone()
    
    def test_precision_test_12536(self):
        TemporalQueries.precision()
    
    def test_chronology_test_12537(self):
        TemporalQueries.chronology()
    
    def test_zoneId_test_12538(self):
        TemporalQueries.zoneId()
    
    def test_localDate_test_12539(self):
        TemporalQueries.localDate()
    
    def test_localTime_test_12540(self):
        TemporalQueries.localTime()


if __name__ == '__main__':
    unittest.main()