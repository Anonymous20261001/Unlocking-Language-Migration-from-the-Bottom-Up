import unittest
from pathlib import Path
from urllib.parse import urlparse


class TestFileSystems(unittest.TestCase):
    def test_getDefault_test_4779(self):
        FileSystems.getDefault()
    
    def test_getFileSystem_test_4780(self, p0):
        FileSystems.getFileSystem(p0)


class FileSystems:
    @staticmethod
    def getDefault():
        return FileSystems()
    
    @staticmethod
    def getFileSystem(uri):
        if not isinstance(uri, str):
            uri = str(uri)
        parsed = urlparse(uri)
        if parsed.scheme == 'file':
            return FileSystems()
        else:
            raise ValueError(f"Unsupported URI scheme: {parsed.scheme}")


if __name__ == '__main__':
    unittest.main()