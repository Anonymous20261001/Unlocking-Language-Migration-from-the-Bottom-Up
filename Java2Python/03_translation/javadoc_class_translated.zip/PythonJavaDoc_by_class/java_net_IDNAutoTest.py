import unittest
import idna

class IDN:
    @staticmethod
    def toASCII(input, flag=0):
        return idna.encode(input, uts46=True).decode('ascii')
    
    @staticmethod
    def toUnicode(input, flag=0):
        return idna.decode(input)

class TestJavaNetIDN(unittest.TestCase):
    def test_toASCII_test_5533(self):
        p0 = "example.com"
        p1 = 0
        IDN.toASCII(p0, p1)
    
    def test_toASCII_test_5534(self):
        p0 = "example.com"
        IDN.toASCII(p0)
    
    def test_toUnicode_test_5535(self):
        p0 = "xn--example-9db.com"
        IDN.toUnicode(p0)
    
    def test_toUnicode_test_5536(self):
        p0 = "xn--example-9db.com"
        p1 = 0
        IDN.toUnicode(p0, p1)

if __name__ == '__main__':
    unittest.main()