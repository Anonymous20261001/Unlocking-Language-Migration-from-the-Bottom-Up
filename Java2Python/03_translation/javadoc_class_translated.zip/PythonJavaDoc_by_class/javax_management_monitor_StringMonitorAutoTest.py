import unittest
from unittest.mock import MagicMock

class ObjectName:
    pass

class StringMonitor:
    def __init__(self):
        self.notify_match = False
        self.notify_differ = False
        self.string_to_compare = None
        self.derived_gauge = None
        self.derived_gauge_timestamp = 0
        self.notification_info = None
    
    def getNotificationInfo(self):
        return self.notification_info
    
    def getDerivedGauge(self, p0=None):
        return self.derived_gauge
    
    def getDerivedGaugeTimeStamp(self, p0=None):
        return self.derived_gauge_timestamp
    
    def getStringToCompare(self):
        return self.string_to_compare
    
    def setStringToCompare(self, p0):
        self.string_to_compare = p0
    
    def getNotifyMatch(self):
        return self.notify_match
    
    def setNotifyMatch(self, p0):
        self.notify_match = p0
    
    def getNotifyDiffer(self):
        return self.notify_differ
    
    def setNotifyDiffer(self, p0):
        self.notify_differ = p0
    
    def start(self):
        pass
    
    def stop(self):
        pass

class TestStringMonitor(unittest.TestCase):
    def test_getNotificationInfo_test_11889(self):
        instance = StringMonitor()
        instance.getNotificationInfo()

    def test_getDerivedGauge_test_11890(self):
        instance = StringMonitor()
        instance.getDerivedGauge()

    def test_getDerivedGauge_test_11891(self):
        p0 = ObjectName()
        instance = StringMonitor()
        instance.getDerivedGauge(p0)

    def test_getDerivedGaugeTimeStamp_test_11892(self):
        p0 = ObjectName()
        instance = StringMonitor()
        instance.getDerivedGaugeTimeStamp(p0)

    def test_getDerivedGaugeTimeStamp_test_11893(self):
        instance = StringMonitor()
        instance.getDerivedGaugeTimeStamp()

    def test_getStringToCompare_test_11894(self):
        instance = StringMonitor()
        instance.getStringToCompare()

    def test_setStringToCompare_test_11895(self):
        p0 = "test_string"
        instance = StringMonitor()
        instance.setStringToCompare(p0)

    def test_getNotifyMatch_test_11896(self):
        instance = StringMonitor()
        instance.getNotifyMatch()

    def test_setNotifyMatch_test_11897(self):
        p0 = True
        instance = StringMonitor()
        instance.setNotifyMatch(p0)

    def test_getNotifyDiffer_test_11898(self):
        instance = StringMonitor()
        instance.getNotifyDiffer()

    def test_setNotifyDiffer_test_11899(self):
        p0 = True
        instance = StringMonitor()
        instance.setNotifyDiffer(p0)

    def test_start_test_11900(self):
        instance = StringMonitor()
        instance.start()

    def test_stop_test_11901(self):
        instance = StringMonitor()
        instance.stop()

if __name__ == '__main__':
    unittest.main()