import unittest
from datetime import datetime, date, time, timezone, timedelta
from typing import Optional, Union


class TestOffsetDateTime(unittest.TestCase):
    def of_test_9640(self, p0: datetime, p1: timezone):
        OffsetDateTime.of(p0, p1)

    def of_test_9641(self, p0: int, p1: int, p2: int, p3: int, p4: int, p5: int, p6: int, p7: timezone):
        OffsetDateTime.of(p0, p1, p2, p3, p4, p5, p6, p7)

    def of_test_9642(self, p0: date, p1: time, p2: timezone):
        OffsetDateTime.of(p0, p1, p2)

    def from_test_9643(self, p0):
        OffsetDateTime.from(p0)

    def parse_test_9644(self, p0: str, p1):
        OffsetDateTime.parse(p0, p1)

    def parse_test_9645(self, p0: str):
        OffsetDateTime.parse(p0)

    def now_test_9646(self):
        OffsetDateTime.now()

    def now_test_9647(self, p0):
        OffsetDateTime.now(p0)

    def now_test_9648(self, p0):
        OffsetDateTime.now(p0)

    def ofInstant_test_9649(self, p0, p1):
        OffsetDateTime.ofInstant(p0, p1)

    def timeLineOrder_test_9650(self):
        OffsetDateTime.timeLineOrder()


class OffsetDateTime:
    @staticmethod
    def of(p0: Union[datetime, int], p1=None, p2=None, p3=None, p4=None, p5=None, p6=None, p7=None):
        if isinstance(p0, datetime) and isinstance(p1, timezone):
            return p0.astimezone(p1)
        elif isinstance(p0, int) and isinstance(p1, int) and isinstance(p2, int) and isinstance(p3, int) and isinstance(p4, int) and isinstance(p5, int) and isinstance(p6, int) and isinstance(p7, timezone):
            return datetime(p0, p1, p2, p3, p4, p5, p6, tzinfo=p7)
        elif isinstance(p0, date) and isinstance(p1, time) and isinstance(p2, timezone):
            return datetime.combine(p0, p1, tzinfo=p2)
        return None

    @staticmethod
    def from(temporal_accessor):
        return temporal_accessor

    @staticmethod
    def parse(text: str, formatter=None):
        if formatter:
            return datetime.strptime(text, formatter)
        return datetime.fromisoformat(text)

    @staticmethod
    def now(clock=None):
        if clock is None:
            return datetime.now().astimezone()
        return datetime.now(clock)

    @staticmethod
    def ofInstant(instant, zone_id):
        return datetime.fromtimestamp(instant.timestamp(), tz=zone_id)

    @staticmethod
    def timeLineOrder():
        return None


if __name__ == '__main__':
    unittest.main()