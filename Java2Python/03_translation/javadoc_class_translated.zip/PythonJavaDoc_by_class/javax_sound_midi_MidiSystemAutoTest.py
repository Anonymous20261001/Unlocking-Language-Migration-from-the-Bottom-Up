import unittest
from unittest.mock import MagicMock
import javax.sound.midi.MidiSystem as MidiSystem


class TestMidiSystem(unittest.TestCase):

    def test_isFileTypeSupported_test_8942(self):
        p0 = 1
        MidiSystem.isFileTypeSupported(p0)

    def test_isFileTypeSupported_test_8943(self):
        p0 = 1
        p1 = MagicMock()
        MidiSystem.isFileTypeSupported(p0, p1)

    def test_getMidiFileTypes_test_8944(self):
        p0 = MagicMock()
        MidiSystem.getMidiFileTypes(p0)

    def test_getMidiFileTypes_test_8945(self):
        MidiSystem.getMidiFileTypes()

    def test_getMidiDeviceInfo_test_8946(self):
        MidiSystem.getMidiDeviceInfo()


class MidiSystem:
    @staticmethod
    def isFileTypeSupported(file_type, sequence=None):
        if sequence is not None:
            return True
        return True

    @staticmethod
    def getMidiFileTypes(sequence=None):
        if sequence is not None:
            return []
        return []

    @staticmethod
    def getMidiDeviceInfo():
        return []