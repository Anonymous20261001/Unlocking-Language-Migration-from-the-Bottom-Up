import unittest
from typing import List

class jdk_jfr_EventFactoryAutoTest(unittest.TestCase):
    def create_test_4573(self, p0: List, p1: List):
        EventFactory.create(p0, p1)

class EventFactory:
    @staticmethod
    def create(p0: List, p1: List):
        pass