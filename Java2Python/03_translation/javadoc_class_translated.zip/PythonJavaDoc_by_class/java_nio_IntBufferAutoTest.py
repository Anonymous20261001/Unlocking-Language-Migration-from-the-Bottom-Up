import unittest
import array

class TestIntBuffer(unittest.TestCase):
    
    def test_wrap_test_5864(self):
        p0 = array.array('i', [1, 2, 3])
        IntBuffer.wrap(p0)
    
    def test_wrap_test_5865(self):
        p0 = array.array('i', [1, 2, 3, 4, 5])
        p1 = 1
        p2 = 3
        IntBuffer.wrap(p0, p1, p2)
    
    def test_allocate_test_5866(self):
        p0 = 10
        IntBuffer.allocate(p0)


class IntBuffer:
    @staticmethod
    def wrap(data, offset=0, length=None):
        if length is None:
            length = len(data) - offset
        buffer = array.array('i', data[offset:offset+length])
        return buffer
    
    @staticmethod
    def allocate(capacity):
        return array.array('i', [0] * capacity)


if __name__ == '__main__':
    unittest.main()