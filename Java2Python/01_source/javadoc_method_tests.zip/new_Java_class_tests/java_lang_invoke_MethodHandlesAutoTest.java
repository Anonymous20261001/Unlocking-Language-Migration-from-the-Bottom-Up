package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.VarHandle;
import java.nio.ByteOrder;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_MethodHandlesAutoTest {
  @Test
  public void throwException_test_8874(Class p0, Class p1) {
    MethodHandles.throwException(p0, p1);
  }

  @Test
  public void lookup_test_8875() {
    MethodHandles.lookup();
  }

  @Test
  public void empty_test_8876(MethodType p0) {
    MethodHandles.empty(p0);
  }

  @Test
  public void constant_test_8877(Class p0, Object p1) {
    MethodHandles.constant(p0, p1);
  }

  @Test
  public void identity_test_8878(Class p0) {
    MethodHandles.identity(p0);
  }

  @Test
  public void spreadInvoker_test_8879(MethodType p0, int p1) {
    MethodHandles.spreadInvoker(p0, p1);
  }

  @Test
  public void arrayLength_test_8880(Class p0) {
    MethodHandles.arrayLength(p0);
  }

  @Test
  public void varHandleInvoker_test_8881(VarHandle.AccessMode p0, MethodType p1) {
    MethodHandles.varHandleInvoker(p0, p1);
  }

  @Test
  public void publicLookup_test_8882() {
    MethodHandles.publicLookup();
  }

  @Test
  public void tryFinally_test_8883(MethodHandle p0, MethodHandle p1) {
    MethodHandles.tryFinally(p0, p1);
  }

  @Test
  public void loop_test_8884(MethodHandle[][] p0) {
    MethodHandles.loop(p0);
  }

  @Test
  public void tableSwitch_test_8885(MethodHandle p0, MethodHandle[] p1) {
    MethodHandles.tableSwitch(p0, p1);
  }

  @Test
  public void arrayConstructor_test_8886(Class p0) {
    MethodHandles.arrayConstructor(p0);
  }

  @Test
  public void exactInvoker_test_8887(MethodType p0) {
    MethodHandles.exactInvoker(p0);
  }

  @Test
  public void foldArguments_test_8888(MethodHandle p0, MethodHandle p1) {
    MethodHandles.foldArguments(p0, p1);
  }

  @Test
  public void foldArguments_test_8889(MethodHandle p0, int p1, MethodHandle p2) {
    MethodHandles.foldArguments(p0, p1, p2);
  }

  @Test
  public void invoker_test_8890(MethodType p0) {
    MethodHandles.invoker(p0);
  }

  @Test
  public void reflectAs_test_8891(Class p0, MethodHandle p1) {
    MethodHandles.reflectAs(p0, p1);
  }

  @Test
  public void zero_test_8892(Class p0) {
    MethodHandles.zero(p0);
  }

  @Test
  public void dropArgumentsToMatch_test_8893(MethodHandle p0, int p1, List p2, int p3) {
    MethodHandles.dropArgumentsToMatch(p0, p1, p2, p3);
  }

  @Test
  public void dropArguments_test_8894(MethodHandle p0, int p1, List p2) {
    MethodHandles.dropArguments(p0, p1, p2);
  }

  @Test
  public void dropArguments_test_8895(MethodHandle p0, int p1, Class[] p2) {
    MethodHandles.dropArguments(p0, p1, p2);
  }

  @Test
  public void countedLoop_test_8896(MethodHandle p0, MethodHandle p1, MethodHandle p2,
      MethodHandle p3) {
    MethodHandles.countedLoop(p0, p1, p2, p3);
  }

  @Test
  public void countedLoop_test_8897(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.countedLoop(p0, p1, p2);
  }

  @Test
  public void permuteArguments_test_8898(MethodHandle p0, MethodType p1, int[] p2) {
    MethodHandles.permuteArguments(p0, p1, p2);
  }

  @Test
  public void filterValue_test_8899(VarHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.filterValue(p0, p1, p2);
  }

  @Test
  public void filterCoordinates_test_8900(VarHandle p0, int p1, MethodHandle[] p2) {
    MethodHandles.filterCoordinates(p0, p1, p2);
  }

  @Test
  public void insertCoordinates_test_8901(VarHandle p0, int p1, Object[] p2) {
    MethodHandles.insertCoordinates(p0, p1, p2);
  }

  @Test
  public void permuteCoordinates_test_8902(VarHandle p0, List p1, int[] p2) {
    MethodHandles.permuteCoordinates(p0, p1, p2);
  }

  @Test
  public void collectCoordinates_test_8903(VarHandle p0, int p1, MethodHandle p2) {
    MethodHandles.collectCoordinates(p0, p1, p2);
  }

  @Test
  public void dropCoordinates_test_8904(VarHandle p0, int p1, Class[] p2) {
    MethodHandles.dropCoordinates(p0, p1, p2);
  }

  @Test
  public void arrayElementGetter_test_8905(Class p0) {
    MethodHandles.arrayElementGetter(p0);
  }

  @Test
  public void arrayElementSetter_test_8906(Class p0) {
    MethodHandles.arrayElementSetter(p0);
  }

  @Test
  public void arrayElementVarHandle_test_8907(Class p0) {
    MethodHandles.arrayElementVarHandle(p0);
  }

  @Test
  public void byteArrayViewVarHandle_test_8908(Class p0, ByteOrder p1) {
    MethodHandles.byteArrayViewVarHandle(p0, p1);
  }

  @Test
  public void byteBufferViewVarHandle_test_8909(Class p0, ByteOrder p1) {
    MethodHandles.byteBufferViewVarHandle(p0, p1);
  }

  @Test
  public void varHandleExactInvoker_test_8910(VarHandle.AccessMode p0, MethodType p1) {
    MethodHandles.varHandleExactInvoker(p0, p1);
  }

  @Test
  public void explicitCastArguments_test_8911(MethodHandle p0, MethodType p1) {
    MethodHandles.explicitCastArguments(p0, p1);
  }

  @Test
  public void insertArguments_test_8912(MethodHandle p0, int p1, Object[] p2) {
    MethodHandles.insertArguments(p0, p1, p2);
  }

  @Test
  public void dropReturn_test_8913(MethodHandle p0) {
    MethodHandles.dropReturn(p0);
  }

  @Test
  public void filterArguments_test_8914(MethodHandle p0, int p1, MethodHandle[] p2) {
    MethodHandles.filterArguments(p0, p1, p2);
  }

  @Test
  public void collectArguments_test_8915(MethodHandle p0, int p1, MethodHandle p2) {
    MethodHandles.collectArguments(p0, p1, p2);
  }

  @Test
  public void filterReturnValue_test_8916(MethodHandle p0, MethodHandle p1) {
    MethodHandles.filterReturnValue(p0, p1);
  }

  @Test
  public void guardWithTest_test_8917(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.guardWithTest(p0, p1, p2);
  }

  @Test
  public void catchException_test_8918(MethodHandle p0, Class p1, MethodHandle p2) {
    MethodHandles.catchException(p0, p1, p2);
  }

  @Test
  public void whileLoop_test_8919(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.whileLoop(p0, p1, p2);
  }

  @Test
  public void doWhileLoop_test_8920(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.doWhileLoop(p0, p1, p2);
  }

  @Test
  public void iteratedLoop_test_8921(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
    MethodHandles.iteratedLoop(p0, p1, p2);
  }
}
