package generated.test;

import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Permission;
import java.security.PrivilegedAction;
import org.junit.jupiter.api.Test;

public class java_security_AccessControllerAutoTest {
  @Test
  public void checkPermission_test_28(Permission p0) {
    AccessController.checkPermission(p0);
  }

  @Test
  public void doPrivileged_test_29(PrivilegedAction p0) {
    AccessController.doPrivileged(p0);
  }

  @Test
  public void doPrivileged_test_30(PrivilegedAction p0, AccessControlContext p1, Permission[] p2) {
    AccessController.doPrivileged(p0, p1, p2);
  }

  @Test
  public void doPrivileged_test_31(PrivilegedAction p0, AccessControlContext p1) {
    AccessController.doPrivileged(p0, p1);
  }

  @Test
  public void doPrivilegedWithCombiner_test_32(PrivilegedAction p0) {
    AccessController.doPrivilegedWithCombiner(p0);
  }

  @Test
  public void doPrivilegedWithCombiner_test_33(PrivilegedAction p0, AccessControlContext p1,
      Permission[] p2) {
    AccessController.doPrivilegedWithCombiner(p0, p1, p2);
  }

  @Test
  public void getContext_test_34() {
    AccessController.getContext();
  }
}
