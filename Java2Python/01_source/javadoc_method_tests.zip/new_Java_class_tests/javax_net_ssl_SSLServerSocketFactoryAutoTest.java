package generated.test;

import javax.net.ssl.SSLServerSocketFactory;
import org.junit.jupiter.api.Test;

public class javax_net_ssl_SSLServerSocketFactoryAutoTest {
  @Test
  public void getDefault_test_11437() {
    SSLServerSocketFactory.getDefault();
  }
}
