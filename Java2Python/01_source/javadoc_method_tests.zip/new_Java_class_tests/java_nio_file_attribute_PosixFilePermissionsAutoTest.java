package generated.test;

import java.lang.String;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class java_nio_file_attribute_PosixFilePermissionsAutoTest {
  @Test
  public void asFileAttribute_test_9995(Set p0) {
    PosixFilePermissions.asFileAttribute(p0);
  }

  @Test
  public void fromString_test_9996(String p0) {
    PosixFilePermissions.fromString(p0);
  }
}
