package generated.test;

import java.lang.String;
import javax.management.ObjectName;
import org.junit.jupiter.api.Test;

public class javax_management_ObjectNameAutoTest {
  @Test
  public void unquote_test_9594(String p0) {
    ObjectName.unquote(p0);
  }

  @Test
  public void getInstance_test_9595(ObjectName p0) {
    ObjectName.getInstance(p0);
  }

  @Test
  public void quote_test_9596(String p0) {
    ObjectName.quote(p0);
  }
}
