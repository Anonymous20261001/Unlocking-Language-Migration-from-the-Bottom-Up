package generated.test;

import java.lang.String;
import javax.annotation.processing.Completions;
import org.junit.jupiter.api.Test;

public class javax_annotation_processing_CompletionsAutoTest {
  @Test
  public void of_test_2610(String p0, String p1) {
    Completions.of(p0, p1);
  }

  @Test
  public void of_test_2611(String p0) {
    Completions.of(p0);
  }
}
