package generated.test;

import java.io.InputStream;
import org.junit.jupiter.api.Test;

public class java_io_InputStreamAutoTest {
  @Test
  public void nullInputStream_test_5854() {
    InputStream.nullInputStream();
  }
}
