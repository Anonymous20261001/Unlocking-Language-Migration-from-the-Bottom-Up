package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_ZonedDateTimeAutoTest {
  @Test
  public void ofLocal_test_13709(LocalDateTime p0, ZoneId p1, ZoneOffset p2) {
    ZonedDateTime.ofLocal(p0, p1, p2);
  }

  @Test
  public void ofStrict_test_13710(LocalDateTime p0, ZoneOffset p1, ZoneId p2) {
    ZonedDateTime.ofStrict(p0, p1, p2);
  }

  @Test
  public void of_test_13711(int p0, int p1, int p2, int p3, int p4, int p5, int p6, ZoneId p7) {
    ZonedDateTime.of(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void of_test_13712(LocalDate p0, LocalTime p1, ZoneId p2) {
    ZonedDateTime.of(p0, p1, p2);
  }

  @Test
  public void of_test_13713(LocalDateTime p0, ZoneId p1) {
    ZonedDateTime.of(p0, p1);
  }

  @Test
  public void from_test_13714(TemporalAccessor p0) {
    ZonedDateTime.from(p0);
  }

  @Test
  public void parse_test_13715(CharSequence p0, DateTimeFormatter p1) {
    ZonedDateTime.parse(p0, p1);
  }

  @Test
  public void parse_test_13716(CharSequence p0) {
    ZonedDateTime.parse(p0);
  }

  @Test
  public void now_test_13717() {
    ZonedDateTime.now();
  }

  @Test
  public void now_test_13718(Clock p0) {
    ZonedDateTime.now(p0);
  }

  @Test
  public void now_test_13719(ZoneId p0) {
    ZonedDateTime.now(p0);
  }

  @Test
  public void ofInstant_test_13720(LocalDateTime p0, ZoneOffset p1, ZoneId p2) {
    ZonedDateTime.ofInstant(p0, p1, p2);
  }

  @Test
  public void ofInstant_test_13721(Instant p0, ZoneId p1) {
    ZonedDateTime.ofInstant(p0, p1);
  }
}
