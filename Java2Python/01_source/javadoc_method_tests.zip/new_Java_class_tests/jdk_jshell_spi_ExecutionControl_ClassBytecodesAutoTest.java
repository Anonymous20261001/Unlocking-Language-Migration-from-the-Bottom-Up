package generated.test;

import java.lang.String;
import jdk.jshell.spi.ExecutionControl;
import org.junit.jupiter.api.Test;

public class jdk_jshell_spi_ExecutionControl_ClassBytecodesAutoTest {
  @Test
  public void name_test_4629(String c0, byte[] c1) {
    ExecutionControl.ClassBytecodes instance = new ExecutionControl.ClassBytecodes(c0, c1);
    instance.name();
  }

  @Test
  public void bytecodes_test_4630(String c0, byte[] c1) {
    ExecutionControl.ClassBytecodes instance = new ExecutionControl.ClassBytecodes(c0, c1);
    instance.bytecodes();
  }
}
