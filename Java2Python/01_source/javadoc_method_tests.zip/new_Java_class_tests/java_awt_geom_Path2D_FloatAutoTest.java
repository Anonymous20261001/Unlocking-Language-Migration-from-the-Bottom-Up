package generated.test;

import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Path2D_FloatAutoTest {
  @Test
  public void getBounds2D_test_9850() {
    Path2D.Float instance = new Path2D.Float();
    instance.getBounds2D();
  }

  @Test
  public void getPathIterator_test_9851(AffineTransform p0) {
    Path2D.Float instance = new Path2D.Float();
    instance.getPathIterator(p0);
  }

  @Test
  public void moveTo_test_9852(double p0, double p1) {
    Path2D.Float instance = new Path2D.Float();
    instance.moveTo(p0, p1);
  }

  @Test
  public void moveTo_test_9853(float p0, float p1) {
    Path2D.Float instance = new Path2D.Float();
    instance.moveTo(p0, p1);
  }

  @Test
  public void lineTo_test_9854(float p0, float p1) {
    Path2D.Float instance = new Path2D.Float();
    instance.lineTo(p0, p1);
  }

  @Test
  public void lineTo_test_9855(double p0, double p1) {
    Path2D.Float instance = new Path2D.Float();
    instance.lineTo(p0, p1);
  }

  @Test
  public void quadTo_test_9856(float p0, float p1, float p2, float p3) {
    Path2D.Float instance = new Path2D.Float();
    instance.quadTo(p0, p1, p2, p3);
  }

  @Test
  public void quadTo_test_9857(double p0, double p1, double p2, double p3) {
    Path2D.Float instance = new Path2D.Float();
    instance.quadTo(p0, p1, p2, p3);
  }

  @Test
  public void curveTo_test_9858(float p0, float p1, float p2, float p3, float p4, float p5) {
    Path2D.Float instance = new Path2D.Float();
    instance.curveTo(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void curveTo_test_9859(double p0, double p1, double p2, double p3, double p4, double p5) {
    Path2D.Float instance = new Path2D.Float();
    instance.curveTo(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void append_test_9860(PathIterator p0, boolean p1) {
    Path2D.Float instance = new Path2D.Float();
    instance.append(p0, p1);
  }

  @Test
  public void transform_test_9861(AffineTransform p0) {
    Path2D.Float instance = new Path2D.Float();
    instance.transform(p0);
  }

  @Test
  public void trimToSize_test_9862() {
    Path2D.Float instance = new Path2D.Float();
    instance.trimToSize();
  }
}
