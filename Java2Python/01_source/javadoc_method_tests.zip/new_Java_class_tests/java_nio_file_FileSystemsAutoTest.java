package generated.test;

import java.net.URI;
import java.nio.file.FileSystems;
import org.junit.jupiter.api.Test;

public class java_nio_file_FileSystemsAutoTest {
  @Test
  public void getDefault_test_4779() {
    FileSystems.getDefault();
  }

  @Test
  public void getFileSystem_test_4780(URI p0) {
    FileSystems.getFileSystem(p0);
  }
}
