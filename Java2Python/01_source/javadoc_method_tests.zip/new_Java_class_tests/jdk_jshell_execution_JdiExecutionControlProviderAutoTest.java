package generated.test;

import jdk.jshell.execution.JdiExecutionControlProvider;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_JdiExecutionControlProviderAutoTest {
  @Test
  public void name_test_6148() {
    JdiExecutionControlProvider instance = new JdiExecutionControlProvider();
    instance.name();
  }

  @Test
  public void defaultParameters_test_6149() {
    JdiExecutionControlProvider instance = new JdiExecutionControlProvider();
    instance.defaultParameters();
  }
}
