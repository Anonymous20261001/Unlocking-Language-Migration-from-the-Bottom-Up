package generated.test;

import javax.imageio.metadata.IIOMetadataFormatImpl;
import org.junit.jupiter.api.Test;

public class javax_imageio_metadata_IIOMetadataFormatImplAutoTest {
  @Test
  public void getStandardFormatInstance_test_5555() {
    IIOMetadataFormatImpl.getStandardFormatInstance();
  }
}
