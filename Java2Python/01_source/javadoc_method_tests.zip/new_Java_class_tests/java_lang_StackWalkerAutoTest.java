package generated.test;

import java.lang.StackWalker;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class java_lang_StackWalkerAutoTest {
  @Test
  public void getInstance_test_11454(StackWalker.Option p0) {
    StackWalker.getInstance(p0);
  }

  @Test
  public void getInstance_test_11455(Set p0) {
    StackWalker.getInstance(p0);
  }

  @Test
  public void getInstance_test_11456(Set p0, int p1) {
    StackWalker.getInstance(p0, p1);
  }

  @Test
  public void getInstance_test_11457() {
    StackWalker.getInstance();
  }
}
