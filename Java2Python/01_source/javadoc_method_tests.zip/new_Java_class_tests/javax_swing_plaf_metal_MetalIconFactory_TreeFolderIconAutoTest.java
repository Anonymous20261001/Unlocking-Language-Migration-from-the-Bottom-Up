package generated.test;

import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_TreeFolderIconAutoTest {
  @Test
  public void getShift_test_8735() {
    MetalIconFactory.TreeFolderIcon instance = new MetalIconFactory.TreeFolderIcon();
    instance.getShift();
  }

  @Test
  public void getAdditionalHeight_test_8736() {
    MetalIconFactory.TreeFolderIcon instance = new MetalIconFactory.TreeFolderIcon();
    instance.getAdditionalHeight();
  }
}
