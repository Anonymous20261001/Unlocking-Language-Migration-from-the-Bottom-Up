package generated.test;

import java.awt.geom.RoundRectangle2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_RoundRectangle2D_FloatAutoTest {
  @Test
  public void getWidth_test_10697() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_10698() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getHeight();
  }

  @Test
  public void getX_test_10699() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getX();
  }

  @Test
  public void getY_test_10700() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getY();
  }

  @Test
  public void getBounds2D_test_10701() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getBounds2D();
  }

  @Test
  public void getArcWidth_test_10702() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getArcWidth();
  }

  @Test
  public void getArcHeight_test_10703() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.getArcHeight();
  }

  @Test
  public void setRoundRect_test_10704(RoundRectangle2D p0) {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.setRoundRect(p0);
  }

  @Test
  public void setRoundRect_test_10705(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.setRoundRect(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void setRoundRect_test_10706(float p0, float p1, float p2, float p3, float p4, float p5) {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.setRoundRect(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void isEmpty_test_10707() {
    RoundRectangle2D.Float instance = new RoundRectangle2D.Float();
    instance.isEmpty();
  }
}
