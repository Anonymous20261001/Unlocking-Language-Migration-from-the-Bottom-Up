package generated.test;

import java.awt.font.TextHitInfo;
import java.awt.font.TextLayout;
import org.junit.jupiter.api.Test;

public class java_awt_font_TextLayout_CaretPolicyAutoTest {
  @Test
  public void getStrongCaret_test_12635(TextHitInfo p0, TextHitInfo p1, TextLayout p2) {
    TextLayout.CaretPolicy instance = new TextLayout.CaretPolicy();
    instance.getStrongCaret(p0, p1, p2);
  }
}
