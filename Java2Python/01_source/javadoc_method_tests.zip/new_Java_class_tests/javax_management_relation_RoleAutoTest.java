package generated.test;

import java.lang.String;
import java.util.List;
import javax.management.relation.Role;
import org.junit.jupiter.api.Test;

public class javax_management_relation_RoleAutoTest {
  @Test
  public void setRoleName_test_10640(String p0, String c0, List c1) {
    Role instance = new Role(c0, c1);
    instance.setRoleName(p0);
  }

  @Test
  public void setRoleValue_test_10641(List p0, String c0, List c1) {
    Role instance = new Role(c0, c1);
    instance.setRoleValue(p0);
  }

  @Test
  public void getRoleName_test_10642(String c0, List c1) {
    Role instance = new Role(c0, c1);
    instance.getRoleName();
  }

  @Test
  public void getRoleValue_test_10643(String c0, List c1) {
    Role instance = new Role(c0, c1);
    instance.getRoleValue();
  }

  @Test
  public void roleValueToString_test_10644(List p0) {
    Role.roleValueToString(p0);
  }
}
