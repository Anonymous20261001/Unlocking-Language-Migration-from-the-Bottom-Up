package generated.test;

import java.lang.String;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import org.junit.jupiter.api.Test;

public class java_net_URLDecoderAutoTest {
  @Test
  public void decode_test_13265(String p0, Charset p1) {
    URLDecoder.decode(p0, p1);
  }

  @Test
  public void decode_test_13266(String p0) {
    URLDecoder.decode(p0);
  }
}
