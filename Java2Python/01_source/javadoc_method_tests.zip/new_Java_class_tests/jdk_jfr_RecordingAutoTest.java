package generated.test;

import java.lang.Class;
import java.lang.String;
import java.time.Duration;
import java.util.Map;
import jdk.jfr.Recording;
import org.junit.jupiter.api.Test;

public class jdk_jfr_RecordingAutoTest {
  @Test
  public void getSettings_test_10348() {
    Recording instance = new Recording();
    instance.getSettings();
  }

  @Test
  public void setMaxAge_test_10349(Duration p0) {
    Recording instance = new Recording();
    instance.setMaxAge(p0);
  }

  @Test
  public void getMaxAge_test_10350() {
    Recording instance = new Recording();
    instance.getMaxAge();
  }

  @Test
  public void setSettings_test_10351(Map p0) {
    Recording instance = new Recording();
    instance.setSettings(p0);
  }

  @Test
  public void isToDisk_test_10352() {
    Recording instance = new Recording();
    instance.isToDisk();
  }

  @Test
  public void getStartTime_test_10353() {
    Recording instance = new Recording();
    instance.getStartTime();
  }

  @Test
  public void getStopTime_test_10354() {
    Recording instance = new Recording();
    instance.getStopTime();
  }

  @Test
  public void getDestination_test_10355() {
    Recording instance = new Recording();
    instance.getDestination();
  }

  @Test
  public void getMaxSize_test_10356() {
    Recording instance = new Recording();
    instance.getMaxSize();
  }

  @Test
  public void setMaxSize_test_10357(long p0) {
    Recording instance = new Recording();
    instance.setMaxSize(p0);
  }

  @Test
  public void getDumpOnExit_test_10358() {
    Recording instance = new Recording();
    instance.getDumpOnExit();
  }

  @Test
  public void setDumpOnExit_test_10359(boolean p0) {
    Recording instance = new Recording();
    instance.setDumpOnExit(p0);
  }

  @Test
  public void setToDisk_test_10360(boolean p0) {
    Recording instance = new Recording();
    instance.setToDisk(p0);
  }

  @Test
  public void scheduleStart_test_10361(Duration p0) {
    Recording instance = new Recording();
    instance.scheduleStart(p0);
  }

  @Test
  public void setDuration_test_10362(Duration p0) {
    Recording instance = new Recording();
    instance.setDuration(p0);
  }

  @Test
  public void getName_test_10363() {
    Recording instance = new Recording();
    instance.getName();
  }

  @Test
  public void copy_test_10364(boolean p0) {
    Recording instance = new Recording();
    instance.copy(p0);
  }

  @Test
  public void start_test_10365() {
    Recording instance = new Recording();
    instance.start();
  }

  @Test
  public void stop_test_10366() {
    Recording instance = new Recording();
    instance.stop();
  }

  @Test
  public void setName_test_10367(String p0) {
    Recording instance = new Recording();
    instance.setName(p0);
  }

  @Test
  public void getId_test_10368() {
    Recording instance = new Recording();
    instance.getId();
  }

  @Test
  public void getState_test_10369() {
    Recording instance = new Recording();
    instance.getState();
  }

  @Test
  public void close_test_10370() {
    Recording instance = new Recording();
    instance.close();
  }

  @Test
  public void getSize_test_10371() {
    Recording instance = new Recording();
    instance.getSize();
  }

  @Test
  public void enable_test_10372(Class p0) {
    Recording instance = new Recording();
    instance.enable(p0);
  }

  @Test
  public void enable_test_10373(String p0) {
    Recording instance = new Recording();
    instance.enable(p0);
  }

  @Test
  public void getDuration_test_10374() {
    Recording instance = new Recording();
    instance.getDuration();
  }

  @Test
  public void disable_test_10375(String p0) {
    Recording instance = new Recording();
    instance.disable(p0);
  }

  @Test
  public void disable_test_10376(Class p0) {
    Recording instance = new Recording();
    instance.disable(p0);
  }
}
