package generated.test;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import org.junit.jupiter.api.Test;

public class javax_net_ssl_HttpsURLConnectionAutoTest {
  @Test
  public void getDefaultSSLSocketFactory_test_5489() {
    HttpsURLConnection.getDefaultSSLSocketFactory();
  }

  @Test
  public void setDefaultHostnameVerifier_test_5490(HostnameVerifier p0) {
    HttpsURLConnection.setDefaultHostnameVerifier(p0);
  }

  @Test
  public void getDefaultHostnameVerifier_test_5491() {
    HttpsURLConnection.getDefaultHostnameVerifier();
  }

  @Test
  public void setDefaultSSLSocketFactory_test_5492(SSLSocketFactory p0) {
    HttpsURLConnection.setDefaultSSLSocketFactory(p0);
  }
}
