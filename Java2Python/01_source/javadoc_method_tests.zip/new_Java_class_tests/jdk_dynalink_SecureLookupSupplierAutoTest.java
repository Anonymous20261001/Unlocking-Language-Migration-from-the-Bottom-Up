package generated.test;

import java.lang.invoke.MethodHandles;
import jdk.dynalink.SecureLookupSupplier;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_SecureLookupSupplierAutoTest {
  @Test
  public void getLookup_test_10956(MethodHandles.Lookup c0) {
    SecureLookupSupplier instance = new SecureLookupSupplier(c0);
    instance.getLookup();
  }
}
