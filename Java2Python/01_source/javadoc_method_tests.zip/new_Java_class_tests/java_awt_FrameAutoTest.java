package generated.test;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.Rectangle;
import java.awt.Shape;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_FrameAutoTest {
  @Test
  public void getTitle_test_5045() {
    Frame instance = new Frame();
    instance.getTitle();
  }

  @Test
  public void setTitle_test_5046(String p0) {
    Frame instance = new Frame();
    instance.setTitle(p0);
  }

  @Test
  public void getFrames_test_5047() {
    Frame.getFrames();
  }

  @Test
  public void getExtendedState_test_5048() {
    Frame instance = new Frame();
    instance.getExtendedState();
  }

  @Test
  public void getMenuBar_test_5049() {
    Frame instance = new Frame();
    instance.getMenuBar();
  }

  @Test
  public void setMenuBar_test_5050(MenuBar p0) {
    Frame instance = new Frame();
    instance.setMenuBar(p0);
  }

  @Test
  public void setResizable_test_5051(boolean p0) {
    Frame instance = new Frame();
    instance.setResizable(p0);
  }

  @Test
  public void isResizable_test_5052() {
    Frame instance = new Frame();
    instance.isResizable();
  }

  @Test
  public void setShape_test_5053(Shape p0) {
    Frame instance = new Frame();
    instance.setShape(p0);
  }

  @Test
  public void setOpacity_test_5054(float p0) {
    Frame instance = new Frame();
    instance.setOpacity(p0);
  }

  @Test
  public void setIconImage_test_5055(Image p0) {
    Frame instance = new Frame();
    instance.setIconImage(p0);
  }

  @Test
  public void setMaximizedBounds_test_5056(Rectangle p0) {
    Frame instance = new Frame();
    instance.setMaximizedBounds(p0);
  }

  @Test
  public void setExtendedState_test_5057(int p0) {
    Frame instance = new Frame();
    instance.setExtendedState(p0);
  }

  @Test
  public void isUndecorated_test_5058() {
    Frame instance = new Frame();
    instance.isUndecorated();
  }

  @Test
  public void getIconImage_test_5059() {
    Frame instance = new Frame();
    instance.getIconImage();
  }

  @Test
  public void getMaximizedBounds_test_5060() {
    Frame instance = new Frame();
    instance.getMaximizedBounds();
  }

  @Test
  public void getCursorType_test_5061() {
    Frame instance = new Frame();
    instance.getCursorType();
  }

  @Test
  public void setBackground_test_5062(Color p0) {
    Frame instance = new Frame();
    instance.setBackground(p0);
  }

  @Test
  public void addNotify_test_5063() {
    Frame instance = new Frame();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_5064() {
    Frame instance = new Frame();
    instance.removeNotify();
  }

  @Test
  public void getAccessibleContext_test_5065() {
    Frame instance = new Frame();
    instance.getAccessibleContext();
  }

  @Test
  public void setCursor_test_5066(int p0) {
    Frame instance = new Frame();
    instance.setCursor(p0);
  }

  @Test
  public void setUndecorated_test_5067(boolean p0) {
    Frame instance = new Frame();
    instance.setUndecorated(p0);
  }

  @Test
  public void remove_test_5068(MenuComponent p0) {
    Frame instance = new Frame();
    instance.remove(p0);
  }

  @Test
  public void getState_test_5069() {
    Frame instance = new Frame();
    instance.getState();
  }

  @Test
  public void setState_test_5070(int p0) {
    Frame instance = new Frame();
    instance.setState(p0);
  }
}
