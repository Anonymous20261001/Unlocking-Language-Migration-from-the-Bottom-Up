package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_LocalDateTimeAutoTest {
  @Test
  public void of_test_7999(LocalDate p0, LocalTime p1) {
    LocalDateTime.of(p0, p1);
  }

  @Test
  public void of_test_8000(int p0, int p1, int p2, int p3, int p4) {
    LocalDateTime.of(p0, p1, p2, p3, p4);
  }

  @Test
  public void of_test_8001(int p0, Month p1, int p2, int p3, int p4, int p5, int p6) {
    LocalDateTime.of(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void of_test_8002(int p0, Month p1, int p2, int p3, int p4, int p5) {
    LocalDateTime.of(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void of_test_8003(int p0, Month p1, int p2, int p3, int p4) {
    LocalDateTime.of(p0, p1, p2, p3, p4);
  }

  @Test
  public void of_test_8004(int p0, int p1, int p2, int p3, int p4, int p5, int p6) {
    LocalDateTime.of(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void of_test_8005(int p0, int p1, int p2, int p3, int p4, int p5) {
    LocalDateTime.of(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void from_test_8006(TemporalAccessor p0) {
    LocalDateTime.from(p0);
  }

  @Test
  public void parse_test_8007(CharSequence p0) {
    LocalDateTime.parse(p0);
  }

  @Test
  public void parse_test_8008(CharSequence p0, DateTimeFormatter p1) {
    LocalDateTime.parse(p0, p1);
  }

  @Test
  public void now_test_8009() {
    LocalDateTime.now();
  }

  @Test
  public void now_test_8010(ZoneId p0) {
    LocalDateTime.now(p0);
  }

  @Test
  public void now_test_8011(Clock p0) {
    LocalDateTime.now(p0);
  }

  @Test
  public void ofEpochSecond_test_8012(long p0, int p1, ZoneOffset p2) {
    LocalDateTime.ofEpochSecond(p0, p1, p2);
  }

  @Test
  public void ofInstant_test_8013(Instant p0, ZoneId p1) {
    LocalDateTime.ofInstant(p0, p1);
  }
}
