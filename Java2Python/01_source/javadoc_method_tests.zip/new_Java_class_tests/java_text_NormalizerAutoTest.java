package generated.test;

import java.lang.CharSequence;
import java.text.Normalizer;
import org.junit.jupiter.api.Test;

public class java_text_NormalizerAutoTest {
  @Test
  public void normalize_test_9529(CharSequence p0, Normalizer.Form p1) {
    Normalizer.normalize(p0, p1);
  }

  @Test
  public void isNormalized_test_9530(CharSequence p0, Normalizer.Form p1) {
    Normalizer.isNormalized(p0, p1);
  }
}
