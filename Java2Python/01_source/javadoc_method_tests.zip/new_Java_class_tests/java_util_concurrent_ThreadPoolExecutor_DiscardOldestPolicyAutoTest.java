package generated.test;

import java.lang.Runnable;
import java.util.concurrent.ThreadPoolExecutor;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ThreadPoolExecutor_DiscardOldestPolicyAutoTest {
  @Test
  public void rejectedExecution_test_12744(Runnable p0, ThreadPoolExecutor p1) {
    ThreadPoolExecutor.DiscardOldestPolicy instance = new ThreadPoolExecutor.DiscardOldestPolicy();
    instance.rejectedExecution(p0, p1);
  }
}
