package generated.test;

import java.nio.channels.spi.AsynchronousChannelProvider;
import org.junit.jupiter.api.Test;

public class java_nio_channels_spi_AsynchronousChannelProviderAutoTest {
  @Test
  public void provider_test_544() {
    AsynchronousChannelProvider.provider();
  }
}
