package generated.test;

import java.awt.GraphicsConfiguration;
import javax.print.DocFlavor;
import javax.print.PrintService;
import javax.print.ServiceUI;
import javax.print.attribute.PrintRequestAttributeSet;
import org.junit.jupiter.api.Test;

public class javax_print_ServiceUIAutoTest {
  @Test
  public void printDialog_test_11071(GraphicsConfiguration p0, int p1, int p2, PrintService[] p3,
      PrintService p4, DocFlavor p5, PrintRequestAttributeSet p6) {
    ServiceUI.printDialog(p0, p1, p2, p3, p4, p5, p6);
  }
}
