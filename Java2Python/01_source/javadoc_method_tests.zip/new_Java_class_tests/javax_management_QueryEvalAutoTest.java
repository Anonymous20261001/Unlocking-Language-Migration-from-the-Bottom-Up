package generated.test;

import javax.management.QueryEval;
import org.junit.jupiter.api.Test;

public class javax_management_QueryEvalAutoTest {
  @Test
  public void getMBeanServer_test_10293() {
    QueryEval.getMBeanServer();
  }
}
