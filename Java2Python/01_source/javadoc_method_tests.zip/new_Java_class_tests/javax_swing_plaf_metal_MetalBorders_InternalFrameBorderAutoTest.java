package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.plaf.metal.MetalBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalBorders_InternalFrameBorderAutoTest {
  @Test
  public void paintBorder_test_8618(Component p0, Graphics p1, int p2, int p3, int p4, int p5) {
    MetalBorders.InternalFrameBorder instance = new MetalBorders.InternalFrameBorder();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8619(Component p0, Insets p1) {
    MetalBorders.InternalFrameBorder instance = new MetalBorders.InternalFrameBorder();
    instance.getBorderInsets(p0, p1);
  }
}
