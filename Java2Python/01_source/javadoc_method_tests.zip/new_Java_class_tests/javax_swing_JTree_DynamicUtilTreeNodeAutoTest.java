package generated.test;

import java.lang.Object;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import org.junit.jupiter.api.Test;

public class javax_swing_JTree_DynamicUtilTreeNodeAutoTest {
  @Test
  public void createChildren_test_7516(DefaultMutableTreeNode p0, Object p1) {
    JTree.DynamicUtilTreeNode.createChildren(p0, p1);
  }

  @Test
  public void getChildAt_test_7517(int p0, Object c0, Object c1) {
    JTree.DynamicUtilTreeNode instance = new JTree.DynamicUtilTreeNode(c0, c1);
    instance.getChildAt(p0);
  }

  @Test
  public void children_test_7518(Object c0, Object c1) {
    JTree.DynamicUtilTreeNode instance = new JTree.DynamicUtilTreeNode(c0, c1);
    instance.children();
  }

  @Test
  public void isLeaf_test_7519(Object c0, Object c1) {
    JTree.DynamicUtilTreeNode instance = new JTree.DynamicUtilTreeNode(c0, c1);
    instance.isLeaf();
  }

  @Test
  public void getChildCount_test_7520(Object c0, Object c1) {
    JTree.DynamicUtilTreeNode instance = new JTree.DynamicUtilTreeNode(c0, c1);
    instance.getChildCount();
  }
}
