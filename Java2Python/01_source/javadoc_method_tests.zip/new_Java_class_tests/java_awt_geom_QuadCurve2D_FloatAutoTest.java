package generated.test;

import java.awt.geom.QuadCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_QuadCurve2D_FloatAutoTest {
  @Test
  public void setCurve_test_10253(float p0, float p1, float p2, float p3, float p4, float p5) {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.setCurve(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void setCurve_test_10254(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.setCurve(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getCtrlX_test_10255() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getCtrlX();
  }

  @Test
  public void getCtrlY_test_10256() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getCtrlY();
  }

  @Test
  public void getCtrlPt_test_10257() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getCtrlPt();
  }

  @Test
  public void getX1_test_10258() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getX1();
  }

  @Test
  public void getY1_test_10259() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getY1();
  }

  @Test
  public void getX2_test_10260() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getX2();
  }

  @Test
  public void getY2_test_10261() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getY2();
  }

  @Test
  public void getP1_test_10262() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getP1();
  }

  @Test
  public void getP2_test_10263() {
    QuadCurve2D.Float instance = new QuadCurve2D.Float();
    instance.getP2();
  }
}
