package generated.test;

import java.lang.Class;
import java.lang.Enum;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_EnumAutoTest {
  @Test
  public void valueOf_test_4533(Class p0, String p1) {
    Enum.valueOf(p0, p1);
  }
}
