package generated.test;

import java.lang.String;
import java.util.List;
import java.util.Map;
import jdk.jshell.execution.JdiInitiator;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_JdiInitiatorAutoTest {
  @Test
  public void vm_test_6150(int c0, List c1, String c2, boolean c3, String c4, int c5, Map c6) {
    JdiInitiator instance = new JdiInitiator(c0, c1, c2, c3, c4, c5, c6);
    instance.vm();
  }

  @Test
  public void process_test_6151(int c0, List c1, String c2, boolean c3, String c4, int c5, Map c6) {
    JdiInitiator instance = new JdiInitiator(c0, c1, c2, c3, c4, c5, c6);
    instance.process();
  }
}
