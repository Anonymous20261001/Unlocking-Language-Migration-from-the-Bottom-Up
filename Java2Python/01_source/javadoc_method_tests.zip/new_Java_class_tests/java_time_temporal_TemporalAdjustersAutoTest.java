package generated.test;

import java.time.DayOfWeek;
import java.time.temporal.TemporalAdjusters;
import java.util.function.UnaryOperator;
import org.junit.jupiter.api.Test;

public class java_time_temporal_TemporalAdjustersAutoTest {
  @Test
  public void dayOfWeekInMonth_test_12520(int p0, DayOfWeek p1) {
    TemporalAdjusters.dayOfWeekInMonth(p0, p1);
  }

  @Test
  public void ofDateAdjuster_test_12521(UnaryOperator p0) {
    TemporalAdjusters.ofDateAdjuster(p0);
  }

  @Test
  public void firstDayOfMonth_test_12522() {
    TemporalAdjusters.firstDayOfMonth();
  }

  @Test
  public void firstDayOfNextMonth_test_12523() {
    TemporalAdjusters.firstDayOfNextMonth();
  }

  @Test
  public void lastDayOfYear_test_12524() {
    TemporalAdjusters.lastDayOfYear();
  }

  @Test
  public void firstDayOfNextYear_test_12525() {
    TemporalAdjusters.firstDayOfNextYear();
  }

  @Test
  public void firstInMonth_test_12526(DayOfWeek p0) {
    TemporalAdjusters.firstInMonth(p0);
  }

  @Test
  public void lastInMonth_test_12527(DayOfWeek p0) {
    TemporalAdjusters.lastInMonth(p0);
  }

  @Test
  public void next_test_12528(DayOfWeek p0) {
    TemporalAdjusters.next(p0);
  }

  @Test
  public void previous_test_12529(DayOfWeek p0) {
    TemporalAdjusters.previous(p0);
  }

  @Test
  public void firstDayOfYear_test_12530() {
    TemporalAdjusters.firstDayOfYear();
  }

  @Test
  public void lastDayOfMonth_test_12531() {
    TemporalAdjusters.lastDayOfMonth();
  }

  @Test
  public void nextOrSame_test_12532(DayOfWeek p0) {
    TemporalAdjusters.nextOrSame(p0);
  }

  @Test
  public void previousOrSame_test_12533(DayOfWeek p0) {
    TemporalAdjusters.previousOrSame(p0);
  }
}
