package generated.test;

import java.awt.Component;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import org.junit.jupiter.api.Test;

public class javax_swing_border_AbstractBorderAutoTest {
  @Test
  public void getInteriorRectangle_test_1(Component p0, Border p1, int p2, int p3, int p4, int p5) {
    AbstractBorder.getInteriorRectangle(p0, p1, p2, p3, p4, p5);
  }
}
