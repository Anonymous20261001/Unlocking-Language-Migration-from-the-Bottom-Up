package generated.test;

import java.lang.Byte;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_ByteAutoTest {
  @Test
  public void compareUnsigned_test_1967(byte p0, byte p1) {
    Byte.compareUnsigned(p0, p1);
  }

  @Test
  public void compareTo_test_1968(Byte p0, byte c0) {
    Byte instance = new Byte(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_1969(byte p0, byte p1) {
    Byte.compare(p0, p1);
  }

  @Test
  public void byteValue_test_1970(byte c0) {
    Byte instance = new Byte(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_1971(byte c0) {
    Byte instance = new Byte(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_1972(byte c0) {
    Byte instance = new Byte(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_1973(byte c0) {
    Byte instance = new Byte(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_1974(byte c0) {
    Byte instance = new Byte(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_1975(byte c0) {
    Byte instance = new Byte(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_1976(String p0) {
    Byte.valueOf(p0);
  }

  @Test
  public void valueOf_test_1977(String p0, int p1) {
    Byte.valueOf(p0, p1);
  }

  @Test
  public void valueOf_test_1978(byte p0) {
    Byte.valueOf(p0);
  }

  @Test
  public void decode_test_1979(String p0) {
    Byte.decode(p0);
  }

  @Test
  public void describeConstable_test_1980(byte c0) {
    Byte instance = new Byte(c0);
    instance.describeConstable();
  }

  @Test
  public void toUnsignedLong_test_1981(byte p0) {
    Byte.toUnsignedLong(p0);
  }

  @Test
  public void toUnsignedInt_test_1982(byte p0) {
    Byte.toUnsignedInt(p0);
  }

  @Test
  public void parseByte_test_1983(String p0) {
    Byte.parseByte(p0);
  }

  @Test
  public void parseByte_test_1984(String p0, int p1) {
    Byte.parseByte(p0, p1);
  }
}
