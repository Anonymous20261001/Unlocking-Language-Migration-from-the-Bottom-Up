package generated.test;

import java.util.List;
import jdk.jfr.EventFactory;
import org.junit.jupiter.api.Test;

public class jdk_jfr_EventFactoryAutoTest {
  @Test
  public void create_test_4573(List p0, List p1) {
    EventFactory.create(p0, p1);
  }
}
