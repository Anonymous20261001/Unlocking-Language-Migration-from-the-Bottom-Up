package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.ByteVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_ByteVectorAutoTest {
  @Test
  public void fromBooleanArray_test_2008(VectorSpecies p0, boolean[] p1, int p2, VectorMask p3) {
    ByteVector.fromBooleanArray(p0, p1, p2, p3);
  }

  @Test
  public void fromBooleanArray_test_2009(VectorSpecies p0, boolean[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    ByteVector.fromBooleanArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromBooleanArray_test_2010(VectorSpecies p0, boolean[] p1, int p2, int[] p3, int p4) {
    ByteVector.fromBooleanArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromBooleanArray_test_2011(VectorSpecies p0, boolean[] p1, int p2) {
    ByteVector.fromBooleanArray(p0, p1, p2);
  }

  @Test
  public void fromMemorySegment_test_2012(VectorSpecies p0, MemorySegment p1, long p2, ByteOrder p3,
      VectorMask p4) {
    ByteVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromMemorySegment_test_2013(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    ByteVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_2014(VectorSpecies p0, byte[] p1, int p2, VectorMask p3) {
    ByteVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_2015(VectorSpecies p0, byte[] p1, int p2, int[] p3, int p4) {
    ByteVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_2016(VectorSpecies p0, byte[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    ByteVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromArray_test_2017(VectorSpecies p0, byte[] p1, int p2) {
    ByteVector.fromArray(p0, p1, p2);
  }

  @Test
  public void zero_test_2018(VectorSpecies p0) {
    ByteVector.zero(p0);
  }

  @Test
  public void broadcast_test_2019(VectorSpecies p0, long p1) {
    ByteVector.broadcast(p0, p1);
  }

  @Test
  public void broadcast_test_2020(VectorSpecies p0, byte p1) {
    ByteVector.broadcast(p0, p1);
  }
}
