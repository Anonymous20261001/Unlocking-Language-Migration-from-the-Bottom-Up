package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_PaletteCloseIconAutoTest {
  @Test
  public void getIconWidth_test_8728() {
    MetalIconFactory.PaletteCloseIcon instance = new MetalIconFactory.PaletteCloseIcon();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_8729() {
    MetalIconFactory.PaletteCloseIcon instance = new MetalIconFactory.PaletteCloseIcon();
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_8730(Component p0, Graphics p1, int p2, int p3) {
    MetalIconFactory.PaletteCloseIcon instance = new MetalIconFactory.PaletteCloseIcon();
    instance.paintIcon(p0, p1, p2, p3);
  }
}
