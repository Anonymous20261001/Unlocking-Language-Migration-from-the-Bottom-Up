package generated.test;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.String;
import java.sql.DriverManager;
import org.junit.jupiter.api.Test;

public class java_sql_DriverManagerAutoTest {
  @Test
  public void setLogStream_test_4342(PrintStream p0) {
    DriverManager.setLogStream(p0);
  }

  @Test
  public void println_test_4343(String p0) {
    DriverManager.println(p0);
  }

  @Test
  public void getLogWriter_test_4344() {
    DriverManager.getLogWriter();
  }

  @Test
  public void getDrivers_test_4345() {
    DriverManager.getDrivers();
  }

  @Test
  public void setLogWriter_test_4346(PrintWriter p0) {
    DriverManager.setLogWriter(p0);
  }

  @Test
  public void drivers_test_4347() {
    DriverManager.drivers();
  }

  @Test
  public void setLoginTimeout_test_4348(int p0) {
    DriverManager.setLoginTimeout(p0);
  }

  @Test
  public void getLoginTimeout_test_4349() {
    DriverManager.getLoginTimeout();
  }

  @Test
  public void getLogStream_test_4350() {
    DriverManager.getLogStream();
  }
}
