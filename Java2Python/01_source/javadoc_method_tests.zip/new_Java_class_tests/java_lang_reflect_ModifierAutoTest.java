package generated.test;

import java.lang.reflect.Modifier;
import org.junit.jupiter.api.Test;

public class java_lang_reflect_ModifierAutoTest {
  @Test
  public void isInterface_test_8971(int p0) {
    Modifier.isInterface(p0);
  }

  @Test
  public void classModifiers_test_8972() {
    Modifier.classModifiers();
  }

  @Test
  public void isFinal_test_8973(int p0) {
    Modifier.isFinal(p0);
  }

  @Test
  public void isPublic_test_8974(int p0) {
    Modifier.isPublic(p0);
  }

  @Test
  public void isStatic_test_8975(int p0) {
    Modifier.isStatic(p0);
  }

  @Test
  public void isProtected_test_8976(int p0) {
    Modifier.isProtected(p0);
  }

  @Test
  public void methodModifiers_test_8977() {
    Modifier.methodModifiers();
  }

  @Test
  public void constructorModifiers_test_8978() {
    Modifier.constructorModifiers();
  }

  @Test
  public void isAbstract_test_8979(int p0) {
    Modifier.isAbstract(p0);
  }

  @Test
  public void isVolatile_test_8980(int p0) {
    Modifier.isVolatile(p0);
  }

  @Test
  public void isPrivate_test_8981(int p0) {
    Modifier.isPrivate(p0);
  }

  @Test
  public void isNative_test_8982(int p0) {
    Modifier.isNative(p0);
  }

  @Test
  public void isSynchronized_test_8983(int p0) {
    Modifier.isSynchronized(p0);
  }

  @Test
  public void isTransient_test_8984(int p0) {
    Modifier.isTransient(p0);
  }

  @Test
  public void isStrict_test_8985(int p0) {
    Modifier.isStrict(p0);
  }

  @Test
  public void interfaceModifiers_test_8986() {
    Modifier.interfaceModifiers();
  }

  @Test
  public void fieldModifiers_test_8987() {
    Modifier.fieldModifiers();
  }

  @Test
  public void parameterModifiers_test_8988() {
    Modifier.parameterModifiers();
  }
}
