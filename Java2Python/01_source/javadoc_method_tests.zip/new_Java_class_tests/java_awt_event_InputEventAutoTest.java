package generated.test;

import java.awt.event.InputEvent;
import org.junit.jupiter.api.Test;

public class java_awt_event_InputEventAutoTest {
  @Test
  public void getModifiersExText_test_5831(int p0) {
    InputEvent.getModifiersExText(p0);
  }

  @Test
  public void getMaskForButton_test_5832(int p0) {
    InputEvent.getMaskForButton(p0);
  }
}
