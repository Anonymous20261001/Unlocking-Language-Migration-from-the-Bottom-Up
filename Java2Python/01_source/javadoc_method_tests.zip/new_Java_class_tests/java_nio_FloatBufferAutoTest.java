package generated.test;

import java.nio.FloatBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_FloatBufferAutoTest {
  @Test
  public void wrap_test_4883(float[] p0) {
    FloatBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_4884(float[] p0, int p1, int p2) {
    FloatBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_4885(int p0) {
    FloatBuffer.allocate(p0);
  }
}
