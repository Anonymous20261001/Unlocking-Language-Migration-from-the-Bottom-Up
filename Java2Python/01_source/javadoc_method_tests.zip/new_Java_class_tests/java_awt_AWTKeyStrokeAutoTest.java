package generated.test;

import java.awt.AWTKeyStroke;
import java.awt.event.KeyEvent;
import java.lang.Character;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_AWTKeyStrokeAutoTest {
  @Test
  public void getAWTKeyStroke_test_946(char p0) {
    AWTKeyStroke.getAWTKeyStroke(p0);
  }

  @Test
  public void getAWTKeyStroke_test_947(String p0) {
    AWTKeyStroke.getAWTKeyStroke(p0);
  }

  @Test
  public void getAWTKeyStroke_test_948(int p0, int p1) {
    AWTKeyStroke.getAWTKeyStroke(p0, p1);
  }

  @Test
  public void getAWTKeyStroke_test_949(int p0, int p1, boolean p2) {
    AWTKeyStroke.getAWTKeyStroke(p0, p1, p2);
  }

  @Test
  public void getAWTKeyStroke_test_950(Character p0, int p1) {
    AWTKeyStroke.getAWTKeyStroke(p0, p1);
  }

  @Test
  public void getAWTKeyStrokeForEvent_test_951(KeyEvent p0) {
    AWTKeyStroke.getAWTKeyStrokeForEvent(p0);
  }
}
