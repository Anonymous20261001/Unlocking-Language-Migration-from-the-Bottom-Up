package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthInternalFrameUI;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_synth_SynthInternalFrameUIAutoTest {
  @Test
  public void createUI_test_12212(JComponent p0) {
    SynthInternalFrameUI.createUI(p0);
  }
}
