package generated.test;

import java.net.http.HttpHeaders;
import java.util.Map;
import java.util.function.BiPredicate;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpHeadersAutoTest {
  @Test
  public void of_test_5437(Map p0, BiPredicate p1) {
    HttpHeaders.of(p0, p1);
  }
}
