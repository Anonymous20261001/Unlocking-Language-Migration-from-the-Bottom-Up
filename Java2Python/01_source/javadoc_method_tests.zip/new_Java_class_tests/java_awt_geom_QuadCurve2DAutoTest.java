package generated.test;

import java.awt.geom.QuadCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_QuadCurve2DAutoTest {
  @Test
  public void getFlatnessSq_test_10235(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    QuadCurve2D.getFlatnessSq(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getFlatnessSq_test_10236(double[] p0, int p1) {
    QuadCurve2D.getFlatnessSq(p0, p1);
  }

  @Test
  public void getFlatness_test_10237(double[] p0, int p1) {
    QuadCurve2D.getFlatness(p0, p1);
  }

  @Test
  public void getFlatness_test_10238(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    QuadCurve2D.getFlatness(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void subdivide_test_10239(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5) {
    QuadCurve2D.subdivide(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void subdivide_test_10240(QuadCurve2D p0, QuadCurve2D p1, QuadCurve2D p2) {
    QuadCurve2D.subdivide(p0, p1, p2);
  }

  @Test
  public void solveQuadratic_test_10241(double[] p0, double[] p1) {
    QuadCurve2D.solveQuadratic(p0, p1);
  }

  @Test
  public void solveQuadratic_test_10242(double[] p0) {
    QuadCurve2D.solveQuadratic(p0);
  }
}
