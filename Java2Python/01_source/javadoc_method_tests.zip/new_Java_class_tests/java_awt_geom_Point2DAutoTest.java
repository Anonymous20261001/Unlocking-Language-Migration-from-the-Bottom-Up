package generated.test;

import java.awt.geom.Point2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Point2DAutoTest {
  @Test
  public void distanceSq_test_9956(double p0, double p1, double p2, double p3) {
    Point2D.distanceSq(p0, p1, p2, p3);
  }

  @Test
  public void distance_test_9957(double p0, double p1, double p2, double p3) {
    Point2D.distance(p0, p1, p2, p3);
  }
}
