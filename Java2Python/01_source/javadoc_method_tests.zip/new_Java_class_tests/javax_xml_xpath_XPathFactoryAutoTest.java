package generated.test;

import javax.xml.xpath.XPathFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_xpath_XPathFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_13657() {
    XPathFactory.newDefaultInstance();
  }

  @Test
  public void newInstance_test_13658() {
    XPathFactory.newInstance();
  }
}
