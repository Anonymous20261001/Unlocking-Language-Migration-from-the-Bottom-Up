package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_FileIcon16AutoTest {
  @Test
  public void getShift_test_8718() {
    MetalIconFactory.FileIcon16 instance = new MetalIconFactory.FileIcon16();
    instance.getShift();
  }

  @Test
  public void getAdditionalHeight_test_8719() {
    MetalIconFactory.FileIcon16 instance = new MetalIconFactory.FileIcon16();
    instance.getAdditionalHeight();
  }

  @Test
  public void getIconWidth_test_8720() {
    MetalIconFactory.FileIcon16 instance = new MetalIconFactory.FileIcon16();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_8721() {
    MetalIconFactory.FileIcon16 instance = new MetalIconFactory.FileIcon16();
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_8722(Component p0, Graphics p1, int p2, int p3) {
    MetalIconFactory.FileIcon16 instance = new MetalIconFactory.FileIcon16();
    instance.paintIcon(p0, p1, p2, p3);
  }
}
