package generated.test;

import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Rectangle2DAutoTest {
  @Test
  public void intersect_test_10435(Rectangle2D p0, Rectangle2D p1, Rectangle2D p2) {
    Rectangle2D.intersect(p0, p1, p2);
  }

  @Test
  public void union_test_10436(Rectangle2D p0, Rectangle2D p1, Rectangle2D p2) {
    Rectangle2D.union(p0, p1, p2);
  }
}
