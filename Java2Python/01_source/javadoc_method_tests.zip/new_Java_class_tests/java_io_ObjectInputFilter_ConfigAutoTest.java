package generated.test;

import java.io.ObjectInputFilter;
import java.lang.String;
import java.util.function.BinaryOperator;
import org.junit.jupiter.api.Test;

public class java_io_ObjectInputFilter_ConfigAutoTest {
  @Test
  public void createFilter_test_9589(String p0) {
    ObjectInputFilter.Config.createFilter(p0);
  }

  @Test
  public void setSerialFilter_test_9590(ObjectInputFilter p0) {
    ObjectInputFilter.Config.setSerialFilter(p0);
  }

  @Test
  public void setSerialFilterFactory_test_9591(BinaryOperator p0) {
    ObjectInputFilter.Config.setSerialFilterFactory(p0);
  }

  @Test
  public void getSerialFilter_test_9592() {
    ObjectInputFilter.Config.getSerialFilter();
  }

  @Test
  public void getSerialFilterFactory_test_9593() {
    ObjectInputFilter.Config.getSerialFilterFactory();
  }
}
