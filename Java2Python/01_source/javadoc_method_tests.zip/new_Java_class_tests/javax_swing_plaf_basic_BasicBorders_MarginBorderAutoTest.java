package generated.test;

import java.awt.Component;
import java.awt.Insets;
import javax.swing.plaf.basic.BasicBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_basic_BasicBorders_MarginBorderAutoTest {
  @Test
  public void getBorderInsets_test_1026(Component p0, Insets p1) {
    BasicBorders.MarginBorder instance = new BasicBorders.MarginBorder();
    instance.getBorderInsets(p0, p1);
  }
}
