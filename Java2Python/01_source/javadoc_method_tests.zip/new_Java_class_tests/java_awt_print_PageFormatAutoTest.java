package generated.test;

import java.awt.print.PageFormat;
import java.awt.print.Paper;
import org.junit.jupiter.api.Test;

public class java_awt_print_PageFormatAutoTest {
  @Test
  public void getWidth_test_9735() {
    PageFormat instance = new PageFormat();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_9736() {
    PageFormat instance = new PageFormat();
    instance.getHeight();
  }

  @Test
  public void getOrientation_test_9737() {
    PageFormat instance = new PageFormat();
    instance.getOrientation();
  }

  @Test
  public void getMatrix_test_9738() {
    PageFormat instance = new PageFormat();
    instance.getMatrix();
  }

  @Test
  public void setOrientation_test_9739(int p0) {
    PageFormat instance = new PageFormat();
    instance.setOrientation(p0);
  }

  @Test
  public void getImageableY_test_9740() {
    PageFormat instance = new PageFormat();
    instance.getImageableY();
  }

  @Test
  public void getImageableHeight_test_9741() {
    PageFormat instance = new PageFormat();
    instance.getImageableHeight();
  }

  @Test
  public void getImageableX_test_9742() {
    PageFormat instance = new PageFormat();
    instance.getImageableX();
  }

  @Test
  public void getImageableWidth_test_9743() {
    PageFormat instance = new PageFormat();
    instance.getImageableWidth();
  }

  @Test
  public void getPaper_test_9744() {
    PageFormat instance = new PageFormat();
    instance.getPaper();
  }

  @Test
  public void setPaper_test_9745(Paper p0) {
    PageFormat instance = new PageFormat();
    instance.setPaper(p0);
  }
}
