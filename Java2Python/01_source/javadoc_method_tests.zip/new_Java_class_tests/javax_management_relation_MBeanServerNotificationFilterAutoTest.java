package generated.test;

import javax.management.Notification;
import javax.management.ObjectName;
import javax.management.relation.MBeanServerNotificationFilter;
import org.junit.jupiter.api.Test;

public class javax_management_relation_MBeanServerNotificationFilterAutoTest {
  @Test
  public void disableAllObjectNames_test_8454() {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.disableAllObjectNames();
  }

  @Test
  public void disableObjectName_test_8455(ObjectName p0) {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.disableObjectName(p0);
  }

  @Test
  public void enableAllObjectNames_test_8456() {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.enableAllObjectNames();
  }

  @Test
  public void enableObjectName_test_8457(ObjectName p0) {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.enableObjectName(p0);
  }

  @Test
  public void getEnabledObjectNames_test_8458() {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.getEnabledObjectNames();
  }

  @Test
  public void getDisabledObjectNames_test_8459() {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.getDisabledObjectNames();
  }

  @Test
  public void isNotificationEnabled_test_8460(Notification p0) {
    MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
    instance.isNotificationEnabled(p0);
  }
}
