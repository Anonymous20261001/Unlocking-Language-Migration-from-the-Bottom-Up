package generated.test;

import java.nio.ShortBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_ShortBufferAutoTest {
  @Test
  public void wrap_test_11098(short[] p0) {
    ShortBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_11099(short[] p0, int p1, int p2) {
    ShortBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_11100(int p0) {
    ShortBuffer.allocate(p0);
  }
}
