package generated.test;

import java.awt.Component;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import javax.swing.TransferHandler;
import org.junit.jupiter.api.Test;

public class javax_swing_TransferHandler_TransferSupportAutoTest {
  @Test
  public void getTransferable_test_12948(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getTransferable();
  }

  @Test
  public void getDataFlavors_test_12949(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getDataFlavors();
  }

  @Test
  public void getDropLocation_test_12950(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getDropLocation();
  }

  @Test
  public void isDrop_test_12951(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.isDrop();
  }

  @Test
  public void getDropAction_test_12952(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getDropAction();
  }

  @Test
  public void getSourceDropActions_test_12953(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getSourceDropActions();
  }

  @Test
  public void getUserDropAction_test_12954(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getUserDropAction();
  }

  @Test
  public void setShowDropLocation_test_12955(boolean p0, Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.setShowDropLocation(p0);
  }

  @Test
  public void setDropAction_test_12956(int p0, Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.setDropAction(p0);
  }

  @Test
  public void isDataFlavorSupported_test_12957(DataFlavor p0, Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.isDataFlavorSupported(p0);
  }

  @Test
  public void getComponent_test_12958(Component c0, Transferable c1) {
    TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
    instance.getComponent();
  }
}
