package generated.test;

import java.lang.String;
import java.net.Authenticator;
import java.net.InetAddress;
import java.net.URL;
import org.junit.jupiter.api.Test;

public class java_net_AuthenticatorAutoTest {
  @Test
  public void requestPasswordAuthentication_test_897(InetAddress p0, int p1, String p2, String p3,
      String p4) {
    Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4);
  }

  @Test
  public void requestPasswordAuthentication_test_898(String p0, InetAddress p1, int p2, String p3,
      String p4, String p5) {
    Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void requestPasswordAuthentication_test_899(Authenticator p0, String p1, InetAddress p2,
      int p3, String p4, String p5, String p6, URL p7, Authenticator.RequestorType p8) {
    Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7, p8);
  }

  @Test
  public void requestPasswordAuthentication_test_900(String p0, InetAddress p1, int p2, String p3,
      String p4, String p5, URL p6, Authenticator.RequestorType p7) {
    Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void getDefault_test_901() {
    Authenticator.getDefault();
  }

  @Test
  public void setDefault_test_902(Authenticator p0) {
    Authenticator.setDefault(p0);
  }
}
