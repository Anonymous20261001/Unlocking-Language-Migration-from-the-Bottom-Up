package generated.test;

import java.awt.KeyboardFocusManager;
import org.junit.jupiter.api.Test;

public class java_awt_KeyboardFocusManagerAutoTest {
  @Test
  public void setCurrentKeyboardFocusManager_test_7611(KeyboardFocusManager p0) {
    KeyboardFocusManager.setCurrentKeyboardFocusManager(p0);
  }

  @Test
  public void getCurrentKeyboardFocusManager_test_7612() {
    KeyboardFocusManager.getCurrentKeyboardFocusManager();
  }
}
