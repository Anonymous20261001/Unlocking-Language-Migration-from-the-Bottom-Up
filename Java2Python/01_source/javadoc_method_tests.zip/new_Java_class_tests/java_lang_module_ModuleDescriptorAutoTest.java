package generated.test;

import java.lang.String;
import java.lang.module.ModuleDescriptor;
import java.nio.ByteBuffer;
import java.util.Set;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;

public class java_lang_module_ModuleDescriptorAutoTest {
  @Test
  public void read_test_8989(ByteBuffer p0, Supplier p1) {
    ModuleDescriptor.read(p0, p1);
  }

  @Test
  public void read_test_8990(ByteBuffer p0) {
    ModuleDescriptor.read(p0);
  }

  @Test
  public void newModule_test_8991(String p0, Set p1) {
    ModuleDescriptor.newModule(p0, p1);
  }

  @Test
  public void newModule_test_8992(String p0) {
    ModuleDescriptor.newModule(p0);
  }

  @Test
  public void newOpenModule_test_8993(String p0) {
    ModuleDescriptor.newOpenModule(p0);
  }

  @Test
  public void newAutomaticModule_test_8994(String p0) {
    ModuleDescriptor.newAutomaticModule(p0);
  }
}
