package generated.test;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.lang.String;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.border.Border;
import org.junit.jupiter.api.Test;

public class javax_swing_BorderFactoryAutoTest {
  @Test
  public void createLoweredBevelBorder_test_1780() {
    BorderFactory.createLoweredBevelBorder();
  }

  @Test
  public void createBevelBorder_test_1781(int p0) {
    BorderFactory.createBevelBorder(p0);
  }

  @Test
  public void createBevelBorder_test_1782(int p0, Color p1, Color p2) {
    BorderFactory.createBevelBorder(p0, p1, p2);
  }

  @Test
  public void createBevelBorder_test_1783(int p0, Color p1, Color p2, Color p3, Color p4) {
    BorderFactory.createBevelBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createSoftBevelBorder_test_1784(int p0) {
    BorderFactory.createSoftBevelBorder(p0);
  }

  @Test
  public void createSoftBevelBorder_test_1785(int p0, Color p1, Color p2) {
    BorderFactory.createSoftBevelBorder(p0, p1, p2);
  }

  @Test
  public void createSoftBevelBorder_test_1786(int p0, Color p1, Color p2, Color p3, Color p4) {
    BorderFactory.createSoftBevelBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createEtchedBorder_test_1787(Color p0, Color p1) {
    BorderFactory.createEtchedBorder(p0, p1);
  }

  @Test
  public void createEtchedBorder_test_1788(int p0) {
    BorderFactory.createEtchedBorder(p0);
  }

  @Test
  public void createEtchedBorder_test_1789() {
    BorderFactory.createEtchedBorder();
  }

  @Test
  public void createEtchedBorder_test_1790(int p0, Color p1, Color p2) {
    BorderFactory.createEtchedBorder(p0, p1, p2);
  }

  @Test
  public void createTitledBorder_test_1791(Border p0, String p1, int p2, int p3, Font p4) {
    BorderFactory.createTitledBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createTitledBorder_test_1792(Border p0, String p1, int p2, int p3, Font p4,
      Color p5) {
    BorderFactory.createTitledBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createTitledBorder_test_1793(String p0) {
    BorderFactory.createTitledBorder(p0);
  }

  @Test
  public void createTitledBorder_test_1794(Border p0) {
    BorderFactory.createTitledBorder(p0);
  }

  @Test
  public void createTitledBorder_test_1795(Border p0, String p1) {
    BorderFactory.createTitledBorder(p0, p1);
  }

  @Test
  public void createTitledBorder_test_1796(Border p0, String p1, int p2, int p3) {
    BorderFactory.createTitledBorder(p0, p1, p2, p3);
  }

  @Test
  public void createCompoundBorder_test_1797() {
    BorderFactory.createCompoundBorder();
  }

  @Test
  public void createCompoundBorder_test_1798(Border p0, Border p1) {
    BorderFactory.createCompoundBorder(p0, p1);
  }

  @Test
  public void createMatteBorder_test_1799(int p0, int p1, int p2, int p3, Color p4) {
    BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createMatteBorder_test_1800(int p0, int p1, int p2, int p3, Icon p4) {
    BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createRaisedBevelBorder_test_1801() {
    BorderFactory.createRaisedBevelBorder();
  }

  @Test
  public void createRaisedSoftBevelBorder_test_1802() {
    BorderFactory.createRaisedSoftBevelBorder();
  }

  @Test
  public void createLoweredSoftBevelBorder_test_1803() {
    BorderFactory.createLoweredSoftBevelBorder();
  }

  @Test
  public void createDashedBorder_test_1804(Paint p0) {
    BorderFactory.createDashedBorder(p0);
  }

  @Test
  public void createDashedBorder_test_1805(Paint p0, float p1, float p2) {
    BorderFactory.createDashedBorder(p0, p1, p2);
  }

  @Test
  public void createDashedBorder_test_1806(Paint p0, float p1, float p2, float p3, boolean p4) {
    BorderFactory.createDashedBorder(p0, p1, p2, p3, p4);
  }

  @Test
  public void createStrokeBorder_test_1807(BasicStroke p0, Paint p1) {
    BorderFactory.createStrokeBorder(p0, p1);
  }

  @Test
  public void createStrokeBorder_test_1808(BasicStroke p0) {
    BorderFactory.createStrokeBorder(p0);
  }

  @Test
  public void createEmptyBorder_test_1809() {
    BorderFactory.createEmptyBorder();
  }

  @Test
  public void createEmptyBorder_test_1810(int p0, int p1, int p2, int p3) {
    BorderFactory.createEmptyBorder(p0, p1, p2, p3);
  }

  @Test
  public void createLineBorder_test_1811(Color p0, int p1, boolean p2) {
    BorderFactory.createLineBorder(p0, p1, p2);
  }

  @Test
  public void createLineBorder_test_1812(Color p0) {
    BorderFactory.createLineBorder(p0);
  }

  @Test
  public void createLineBorder_test_1813(Color p0, int p1) {
    BorderFactory.createLineBorder(p0, p1);
  }
}
