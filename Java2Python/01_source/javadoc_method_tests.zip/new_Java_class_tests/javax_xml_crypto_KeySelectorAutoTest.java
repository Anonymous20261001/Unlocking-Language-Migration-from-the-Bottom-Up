package generated.test;

import java.security.Key;
import javax.xml.crypto.KeySelector;
import org.junit.jupiter.api.Test;

public class javax_xml_crypto_KeySelectorAutoTest {
  @Test
  public void singletonKeySelector_test_7631(Key p0) {
    KeySelector.singletonKeySelector(p0);
  }
}
