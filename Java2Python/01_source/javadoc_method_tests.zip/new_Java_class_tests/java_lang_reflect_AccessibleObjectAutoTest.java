package generated.test;

import java.lang.reflect.AccessibleObject;
import org.junit.jupiter.api.Test;

public class java_lang_reflect_AccessibleObjectAutoTest {
  @Test
  public void setAccessible_test_35(AccessibleObject[] p0, boolean p1) {
    AccessibleObject.setAccessible(p0, p1);
  }
}
