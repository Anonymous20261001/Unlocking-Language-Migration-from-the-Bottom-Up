package generated.test;

import java.lang.ClassLoader;
import java.lang.Module;
import java.lang.String;
import java.util.Locale;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class java_util_ResourceBundleAutoTest {
  @Test
  public void getBundle_test_10610(String p0, Locale p1) {
    ResourceBundle.getBundle(p0, p1);
  }

  @Test
  public void getBundle_test_10611(String p0, Module p1) {
    ResourceBundle.getBundle(p0, p1);
  }

  @Test
  public void getBundle_test_10612(String p0, ResourceBundle.Control p1) {
    ResourceBundle.getBundle(p0, p1);
  }

  @Test
  public void getBundle_test_10613(String p0) {
    ResourceBundle.getBundle(p0);
  }

  @Test
  public void getBundle_test_10614(String p0, Locale p1, ClassLoader p2) {
    ResourceBundle.getBundle(p0, p1, p2);
  }

  @Test
  public void getBundle_test_10615(String p0, Locale p1, ClassLoader p2,
      ResourceBundle.Control p3) {
    ResourceBundle.getBundle(p0, p1, p2, p3);
  }

  @Test
  public void getBundle_test_10616(String p0, Locale p1, ResourceBundle.Control p2) {
    ResourceBundle.getBundle(p0, p1, p2);
  }

  @Test
  public void getBundle_test_10617(String p0, Locale p1, Module p2) {
    ResourceBundle.getBundle(p0, p1, p2);
  }

  @Test
  public void clearCache_test_10618(ClassLoader p0) {
    ResourceBundle.clearCache(p0);
  }

  @Test
  public void clearCache_test_10619() {
    ResourceBundle.clearCache();
  }
}
