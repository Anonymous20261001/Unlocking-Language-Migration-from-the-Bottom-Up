package generated.test;

import javax.swing.text.Element;
import javax.swing.text.html.HTMLEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_HTMLEditorKit_HTMLFactoryAutoTest {
  @Test
  public void create_test_5396(Element p0) {
    HTMLEditorKit.HTMLFactory instance = new HTMLEditorKit.HTMLFactory();
    instance.create(p0);
  }
}
