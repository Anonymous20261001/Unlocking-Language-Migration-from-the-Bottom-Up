package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandleProxies;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_MethodHandleProxiesAutoTest {
  @Test
  public void isWrapperInstance_test_8870(Object p0) {
    MethodHandleProxies.isWrapperInstance(p0);
  }

  @Test
  public void asInterfaceInstance_test_8871(Class p0, MethodHandle p1) {
    MethodHandleProxies.asInterfaceInstance(p0, p1);
  }

  @Test
  public void wrapperInstanceTarget_test_8872(Object p0) {
    MethodHandleProxies.wrapperInstanceTarget(p0);
  }

  @Test
  public void wrapperInstanceType_test_8873(Object p0) {
    MethodHandleProxies.wrapperInstanceType(p0);
  }
}
