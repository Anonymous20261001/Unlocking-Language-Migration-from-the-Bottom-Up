package generated.test;

import java.lang.String;
import java.time.zone.ZoneRulesProvider;
import org.junit.jupiter.api.Test;

public class java_time_zone_ZoneRulesProviderAutoTest {
  @Test
  public void refresh_test_13738() {
    ZoneRulesProvider.refresh();
  }

  @Test
  public void getVersions_test_13739(String p0) {
    ZoneRulesProvider.getVersions(p0);
  }

  @Test
  public void getRules_test_13740(String p0, boolean p1) {
    ZoneRulesProvider.getRules(p0, p1);
  }

  @Test
  public void getAvailableZoneIds_test_13741() {
    ZoneRulesProvider.getAvailableZoneIds();
  }

  @Test
  public void registerProvider_test_13742(ZoneRulesProvider p0) {
    ZoneRulesProvider.registerProvider(p0);
  }
}
