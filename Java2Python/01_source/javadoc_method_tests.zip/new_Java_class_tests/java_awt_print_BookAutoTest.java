package generated.test;

import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import org.junit.jupiter.api.Test;

public class java_awt_print_BookAutoTest {
  @Test
  public void getPrintable_test_1763(int p0) {
    Book instance = new Book();
    instance.getPrintable(p0);
  }

  @Test
  public void getPageFormat_test_1764(int p0) {
    Book instance = new Book();
    instance.getPageFormat(p0);
  }

  @Test
  public void getNumberOfPages_test_1765() {
    Book instance = new Book();
    instance.getNumberOfPages();
  }

  @Test
  public void setPage_test_1766(int p0, Printable p1, PageFormat p2) {
    Book instance = new Book();
    instance.setPage(p0, p1, p2);
  }

  @Test
  public void append_test_1767(Printable p0, PageFormat p1, int p2) {
    Book instance = new Book();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_1768(Printable p0, PageFormat p1) {
    Book instance = new Book();
    instance.append(p0, p1);
  }
}
