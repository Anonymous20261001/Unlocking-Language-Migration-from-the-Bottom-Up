package generated.test;

import java.time.Clock;
import java.time.ZoneId;
import java.time.chrono.MinguoDate;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_chrono_MinguoDateAutoTest {
  @Test
  public void of_test_8947(int p0, int p1, int p2) {
    MinguoDate.of(p0, p1, p2);
  }

  @Test
  public void from_test_8948(TemporalAccessor p0) {
    MinguoDate.from(p0);
  }

  @Test
  public void now_test_8949() {
    MinguoDate.now();
  }

  @Test
  public void now_test_8950(ZoneId p0) {
    MinguoDate.now(p0);
  }

  @Test
  public void now_test_8951(Clock p0) {
    MinguoDate.now(p0);
  }
}
