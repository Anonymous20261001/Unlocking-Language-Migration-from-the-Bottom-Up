package generated.test;

import javax.swing.colorchooser.ColorChooserComponentFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_colorchooser_ColorChooserComponentFactoryAutoTest {
  @Test
  public void getPreviewPanel_test_2491() {
    ColorChooserComponentFactory.getPreviewPanel();
  }

  @Test
  public void getDefaultChooserPanels_test_2492() {
    ColorChooserComponentFactory.getDefaultChooserPanels();
  }
}
