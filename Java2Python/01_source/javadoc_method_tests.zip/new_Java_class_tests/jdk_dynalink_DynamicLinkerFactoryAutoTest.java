package generated.test;

import java.lang.ClassLoader;
import java.util.List;
import jdk.dynalink.DynamicLinkerFactory;
import jdk.dynalink.linker.GuardedInvocationTransformer;
import jdk.dynalink.linker.GuardingDynamicLinker;
import jdk.dynalink.linker.MethodHandleTransformer;
import jdk.dynalink.linker.MethodTypeConversionStrategy;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_DynamicLinkerFactoryAutoTest {
  @Test
  public void setFallbackLinkers_test_4425(List p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setFallbackLinkers(p0);
  }

  @Test
  public void setFallbackLinkers_test_4426(GuardingDynamicLinker[] p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setFallbackLinkers(p0);
  }

  @Test
  public void setClassLoader_test_4427(ClassLoader p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setClassLoader(p0);
  }

  @Test
  public void setSyncOnRelink_test_4428(boolean p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setSyncOnRelink(p0);
  }

  @Test
  public void createLinker_test_4429() {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.createLinker();
  }

  @Test
  public void setPrioritizedLinkers_test_4430(List p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setPrioritizedLinkers(p0);
  }

  @Test
  public void setPrioritizedLinkers_test_4431(GuardingDynamicLinker[] p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setPrioritizedLinkers(p0);
  }

  @Test
  public void setPrioritizedLinker_test_4432(GuardingDynamicLinker p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setPrioritizedLinker(p0);
  }

  @Test
  public void setUnstableRelinkThreshold_test_4433(int p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setUnstableRelinkThreshold(p0);
  }

  @Test
  public void setPrelinkTransformer_test_4434(GuardedInvocationTransformer p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setPrelinkTransformer(p0);
  }

  @Test
  public void setAutoConversionStrategy_test_4435(MethodTypeConversionStrategy p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setAutoConversionStrategy(p0);
  }

  @Test
  public void setInternalObjectsFilter_test_4436(MethodHandleTransformer p0) {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.setInternalObjectsFilter(p0);
  }

  @Test
  public void getAutoLoadingErrors_test_4437() {
    DynamicLinkerFactory instance = new DynamicLinkerFactory();
    instance.getAutoLoadingErrors();
  }
}
