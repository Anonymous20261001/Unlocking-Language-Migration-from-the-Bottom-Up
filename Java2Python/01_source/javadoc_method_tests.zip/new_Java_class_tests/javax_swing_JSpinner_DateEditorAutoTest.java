package generated.test;

import javax.swing.JSpinner;
import org.junit.jupiter.api.Test;

public class javax_swing_JSpinner_DateEditorAutoTest {
  @Test
  public void getModel_test_7001(JSpinner c0) {
    JSpinner.DateEditor instance = new JSpinner.DateEditor(c0);
    instance.getModel();
  }

  @Test
  public void getFormat_test_7002(JSpinner c0) {
    JSpinner.DateEditor instance = new JSpinner.DateEditor(c0);
    instance.getFormat();
  }
}
