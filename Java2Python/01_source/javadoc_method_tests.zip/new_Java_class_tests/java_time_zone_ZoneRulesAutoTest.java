package generated.test;

import java.time.ZoneOffset;
import java.time.zone.ZoneRules;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_time_zone_ZoneRulesAutoTest {
  @Test
  public void of_test_13736(ZoneOffset p0, ZoneOffset p1, List p2, List p3, List p4) {
    ZoneRules.of(p0, p1, p2, p3, p4);
  }

  @Test
  public void of_test_13737(ZoneOffset p0) {
    ZoneRules.of(p0);
  }
}
