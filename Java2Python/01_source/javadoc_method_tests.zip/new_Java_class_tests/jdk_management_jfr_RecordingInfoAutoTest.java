package generated.test;

import javax.management.openmbean.CompositeData;
import jdk.management.jfr.RecordingInfo;
import org.junit.jupiter.api.Test;

public class jdk_management_jfr_RecordingInfoAutoTest {
  @Test
  public void from_test_10377(CompositeData p0) {
    RecordingInfo.from(p0);
  }
}
