package generated.test;

import java.util.concurrent.Flow;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_FlowAutoTest {
  @Test
  public void defaultBufferSize_test_4895() {
    Flow.defaultBufferSize();
  }
}
