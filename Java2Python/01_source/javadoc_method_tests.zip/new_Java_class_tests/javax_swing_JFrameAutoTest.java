package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.LayoutManager;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.TransferHandler;
import org.junit.jupiter.api.Test;

public class javax_swing_JFrameAutoTest {
  @Test
  public void getContentPane_test_6253() {
    JFrame instance = new JFrame();
    instance.getContentPane();
  }

  @Test
  public void isDefaultLookAndFeelDecorated_test_6254() {
    JFrame.isDefaultLookAndFeelDecorated();
  }

  @Test
  public void getJMenuBar_test_6255() {
    JFrame instance = new JFrame();
    instance.getJMenuBar();
  }

  @Test
  public void setJMenuBar_test_6256(JMenuBar p0) {
    JFrame instance = new JFrame();
    instance.setJMenuBar(p0);
  }

  @Test
  public void setContentPane_test_6257(Container p0) {
    JFrame instance = new JFrame();
    instance.setContentPane(p0);
  }

  @Test
  public void getLayeredPane_test_6258() {
    JFrame instance = new JFrame();
    instance.getLayeredPane();
  }

  @Test
  public void setLayeredPane_test_6259(JLayeredPane p0) {
    JFrame instance = new JFrame();
    instance.setLayeredPane(p0);
  }

  @Test
  public void getGlassPane_test_6260() {
    JFrame instance = new JFrame();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_6261(Component p0) {
    JFrame instance = new JFrame();
    instance.setGlassPane(p0);
  }

  @Test
  public void setDefaultCloseOperation_test_6262(int p0) {
    JFrame instance = new JFrame();
    instance.setDefaultCloseOperation(p0);
  }

  @Test
  public void getDefaultCloseOperation_test_6263() {
    JFrame instance = new JFrame();
    instance.getDefaultCloseOperation();
  }

  @Test
  public void setIconImage_test_6264(Image p0) {
    JFrame instance = new JFrame();
    instance.setIconImage(p0);
  }

  @Test
  public void setDefaultLookAndFeelDecorated_test_6265(boolean p0) {
    JFrame.setDefaultLookAndFeelDecorated(p0);
  }

  @Test
  public void getGraphics_test_6266() {
    JFrame instance = new JFrame();
    instance.getGraphics();
  }

  @Test
  public void getRootPane_test_6267() {
    JFrame instance = new JFrame();
    instance.getRootPane();
  }

  @Test
  public void repaint_test_6268(long p0, int p1, int p2, int p3, int p4) {
    JFrame instance = new JFrame();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void setTransferHandler_test_6269(TransferHandler p0) {
    JFrame instance = new JFrame();
    instance.setTransferHandler(p0);
  }

  @Test
  public void getTransferHandler_test_6270() {
    JFrame instance = new JFrame();
    instance.getTransferHandler();
  }

  @Test
  public void getAccessibleContext_test_6271() {
    JFrame instance = new JFrame();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_6272(LayoutManager p0) {
    JFrame instance = new JFrame();
    instance.setLayout(p0);
  }

  @Test
  public void remove_test_6273(Component p0) {
    JFrame instance = new JFrame();
    instance.remove(p0);
  }

  @Test
  public void update_test_6274(Graphics p0) {
    JFrame instance = new JFrame();
    instance.update(p0);
  }
}
