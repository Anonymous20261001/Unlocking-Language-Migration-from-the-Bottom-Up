package generated.test;

import java.net.URI;
import javax.xml.catalog.Catalog;
import javax.xml.catalog.CatalogFeatures;
import javax.xml.catalog.CatalogManager;
import javax.xml.catalog.CatalogResolver;
import org.junit.jupiter.api.Test;

public class javax_xml_catalog_CatalogManagerAutoTest {
  @Test
  public void catalogResolver_test_2082(Catalog p0, CatalogResolver.NotFoundAction p1) {
    CatalogManager.catalogResolver(p0, p1);
  }

  @Test
  public void catalogResolver_test_2083(CatalogFeatures p0, URI[] p1) {
    CatalogManager.catalogResolver(p0, p1);
  }

  @Test
  public void catalogResolver_test_2084(Catalog p0) {
    CatalogManager.catalogResolver(p0);
  }

  @Test
  public void catalog_test_2085(CatalogFeatures p0, URI[] p1) {
    CatalogManager.catalog(p0, p1);
  }
}
