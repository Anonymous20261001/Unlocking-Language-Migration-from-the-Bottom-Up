package generated.test;

import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Rectangle2D_DoubleAutoTest {
  @Test
  public void getWidth_test_10437() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_10438() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.getHeight();
  }

  @Test
  public void getX_test_10439() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.getX();
  }

  @Test
  public void getY_test_10440() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.getY();
  }

  @Test
  public void getBounds2D_test_10441() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.getBounds2D();
  }

  @Test
  public void setRect_test_10442(Rectangle2D p0) {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.setRect(p0);
  }

  @Test
  public void setRect_test_10443(double p0, double p1, double p2, double p3) {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.setRect(p0, p1, p2, p3);
  }

  @Test
  public void outcode_test_10444(double p0, double p1) {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.outcode(p0, p1);
  }

  @Test
  public void createIntersection_test_10445(Rectangle2D p0) {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.createIntersection(p0);
  }

  @Test
  public void createUnion_test_10446(Rectangle2D p0) {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.createUnion(p0);
  }

  @Test
  public void isEmpty_test_10447() {
    Rectangle2D.Double instance = new Rectangle2D.Double();
    instance.isEmpty();
  }
}
