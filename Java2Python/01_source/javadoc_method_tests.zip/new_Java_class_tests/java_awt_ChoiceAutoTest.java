package generated.test;

import java.awt.Choice;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ChoiceAutoTest {
  @Test
  public void getListeners_test_2269(Class p0) {
    Choice instance = new Choice();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_2270() {
    Choice instance = new Choice();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_2271() {
    Choice instance = new Choice();
    instance.getAccessibleContext();
  }

  @Test
  public void removeItemListener_test_2272(ItemListener p0) {
    Choice instance = new Choice();
    instance.removeItemListener(p0);
  }

  @Test
  public void addItemListener_test_2273(ItemListener p0) {
    Choice instance = new Choice();
    instance.addItemListener(p0);
  }

  @Test
  public void getItemListeners_test_2274() {
    Choice instance = new Choice();
    instance.getItemListeners();
  }

  @Test
  public void getSelectedObjects_test_2275() {
    Choice instance = new Choice();
    instance.getSelectedObjects();
  }

  @Test
  public void getItem_test_2276(int p0) {
    Choice instance = new Choice();
    instance.getItem(p0);
  }

  @Test
  public void select_test_2277(String p0) {
    Choice instance = new Choice();
    instance.select(p0);
  }

  @Test
  public void select_test_2278(int p0) {
    Choice instance = new Choice();
    instance.select(p0);
  }

  @Test
  public void countItems_test_2279() {
    Choice instance = new Choice();
    instance.countItems();
  }

  @Test
  public void getSelectedIndex_test_2280() {
    Choice instance = new Choice();
    instance.getSelectedIndex();
  }

  @Test
  public void getSelectedItem_test_2281() {
    Choice instance = new Choice();
    instance.getSelectedItem();
  }

  @Test
  public void addItem_test_2282(String p0) {
    Choice instance = new Choice();
    instance.addItem(p0);
  }

  @Test
  public void getItemCount_test_2283() {
    Choice instance = new Choice();
    instance.getItemCount();
  }

  @Test
  public void remove_test_2284(int p0) {
    Choice instance = new Choice();
    instance.remove(p0);
  }

  @Test
  public void remove_test_2285(String p0) {
    Choice instance = new Choice();
    instance.remove(p0);
  }

  @Test
  public void insert_test_2286(String p0, int p1) {
    Choice instance = new Choice();
    instance.insert(p0, p1);
  }

  @Test
  public void add_test_2287(String p0) {
    Choice instance = new Choice();
    instance.add(p0);
  }

  @Test
  public void removeAll_test_2288() {
    Choice instance = new Choice();
    instance.removeAll();
  }
}
