package generated.test;

import java.lang.String;
import java.net.Inet4Address;
import org.junit.jupiter.api.Test;

public class java_net_Inet4AddressAutoTest {
  @Test
  public void ofLiteral_test_5792(String p0) {
    Inet4Address.ofLiteral(p0);
  }

  @Test
  public void ofPosixLiteral_test_5793(String p0) {
    Inet4Address.ofPosixLiteral(p0);
  }
}
