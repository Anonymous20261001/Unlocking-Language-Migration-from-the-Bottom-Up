package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.beans.PropertyChangeEvent;
import java.lang.String;
import javax.swing.JSpinner;
import javax.swing.event.ChangeEvent;
import org.junit.jupiter.api.Test;

public class javax_swing_JSpinner_DefaultEditorAutoTest {
  @Test
  public void getTextField_test_7003(JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.getTextField();
  }

  @Test
  public void dismiss_test_7004(JSpinner p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.dismiss(p0);
  }

  @Test
  public void getSpinner_test_7005(JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.getSpinner();
  }

  @Test
  public void propertyChange_test_7006(PropertyChangeEvent p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.propertyChange(p0);
  }

  @Test
  public void getBaseline_test_7007(int p0, int p1, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.getBaseline(p0, p1);
  }

  @Test
  public void getBaselineResizeBehavior_test_7008(JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.getBaselineResizeBehavior();
  }

  @Test
  public void removeLayoutComponent_test_7009(Component p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_7010(String p0, Component p1, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_7011(Container p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.layoutContainer(p0);
  }

  @Test
  public void preferredLayoutSize_test_7012(Container p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_7013(Container p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void stateChanged_test_7014(ChangeEvent p0, JSpinner c0) {
    JSpinner.DefaultEditor instance = new JSpinner.DefaultEditor(c0);
    instance.stateChanged(p0);
  }
}
