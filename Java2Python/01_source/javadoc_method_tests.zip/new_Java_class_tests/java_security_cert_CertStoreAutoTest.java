package generated.test;

import java.security.cert.CertStore;
import org.junit.jupiter.api.Test;

public class java_security_cert_CertStoreAutoTest {
  @Test
  public void getDefaultType_test_2105() {
    CertStore.getDefaultType();
  }
}
