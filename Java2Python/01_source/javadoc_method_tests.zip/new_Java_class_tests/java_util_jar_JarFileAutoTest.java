package generated.test;

import java.util.jar.JarFile;
import org.junit.jupiter.api.Test;

public class java_util_jar_JarFileAutoTest {
  @Test
  public void runtimeVersion_test_5997() {
    JarFile.runtimeVersion();
  }

  @Test
  public void baseVersion_test_5998() {
    JarFile.baseVersion();
  }
}
