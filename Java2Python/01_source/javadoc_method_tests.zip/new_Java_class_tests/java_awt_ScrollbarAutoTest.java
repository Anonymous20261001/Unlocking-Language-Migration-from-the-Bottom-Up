package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
  @Test
  public void getAdjustmentListeners_test_10876() {
    Scrollbar instance = new Scrollbar();
    instance.getAdjustmentListeners();
  }

  @Test
  public void setValueIsAdjusting_test_10877(boolean p0) {
    Scrollbar instance = new Scrollbar();
    instance.setValueIsAdjusting(p0);
  }

  @Test
  public void getVisible_test_10878() {
    Scrollbar instance = new Scrollbar();
    instance.getVisible();
  }

  @Test
  public void setLineIncrement_test_10879(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setLineIncrement(p0);
  }

  @Test
  public void getLineIncrement_test_10880() {
    Scrollbar instance = new Scrollbar();
    instance.getLineIncrement();
  }

  @Test
  public void setPageIncrement_test_10881(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setPageIncrement(p0);
  }

  @Test
  public void getPageIncrement_test_10882() {
    Scrollbar instance = new Scrollbar();
    instance.getPageIncrement();
  }

  @Test
  public void getListeners_test_10883(Class p0) {
    Scrollbar instance = new Scrollbar();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_10884() {
    Scrollbar instance = new Scrollbar();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_10885() {
    Scrollbar instance = new Scrollbar();
    instance.getAccessibleContext();
  }

  @Test
  public void getValueIsAdjusting_test_10886() {
    Scrollbar instance = new Scrollbar();
    instance.getValueIsAdjusting();
  }

  @Test
  public void getOrientation_test_10887() {
    Scrollbar instance = new Scrollbar();
    instance.getOrientation();
  }

  @Test
  public void setMinimum_test_10888(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setMinimum(p0);
  }

  @Test
  public void setMaximum_test_10889(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setMaximum(p0);
  }

  @Test
  public void setUnitIncrement_test_10890(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setUnitIncrement(p0);
  }

  @Test
  public void getUnitIncrement_test_10891() {
    Scrollbar instance = new Scrollbar();
    instance.getUnitIncrement();
  }

  @Test
  public void setBlockIncrement_test_10892(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setBlockIncrement(p0);
  }

  @Test
  public void getBlockIncrement_test_10893() {
    Scrollbar instance = new Scrollbar();
    instance.getBlockIncrement();
  }

  @Test
  public void setVisibleAmount_test_10894(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setVisibleAmount(p0);
  }

  @Test
  public void getVisibleAmount_test_10895() {
    Scrollbar instance = new Scrollbar();
    instance.getVisibleAmount();
  }

  @Test
  public void addAdjustmentListener_test_10896(AdjustmentListener p0) {
    Scrollbar instance = new Scrollbar();
    instance.addAdjustmentListener(p0);
  }

  @Test
  public void removeAdjustmentListener_test_10897(AdjustmentListener p0) {
    Scrollbar instance = new Scrollbar();
    instance.removeAdjustmentListener(p0);
  }

  @Test
  public void setOrientation_test_10898(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setOrientation(p0);
  }

  @Test
  public void setValues_test_10899(int p0, int p1, int p2, int p3) {
    Scrollbar instance = new Scrollbar();
    instance.setValues(p0, p1, p2, p3);
  }

  @Test
  public void getValue_test_10900() {
    Scrollbar instance = new Scrollbar();
    instance.getValue();
  }

  @Test
  public void setValue_test_10901(int p0) {
    Scrollbar instance = new Scrollbar();
    instance.setValue(p0);
  }

  @Test
  public void getMaximum_test_10902() {
    Scrollbar instance = new Scrollbar();
    instance.getMaximum();
  }

  @Test
  public void getMinimum_test_10903() {
    Scrollbar instance = new Scrollbar();
    instance.getMinimum();
  }
}
