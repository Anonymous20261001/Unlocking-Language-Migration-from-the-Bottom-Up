package generated.test;

import java.lang.Object;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.SwitchBootstraps;
import org.junit.jupiter.api.Test;

public class java_lang_runtime_SwitchBootstrapsAutoTest {
  @Test
  public void typeSwitch_test_12118(MethodHandles.Lookup p0, String p1, MethodType p2,
      Object[] p3) {
    SwitchBootstraps.typeSwitch(p0, p1, p2, p3);
  }

  @Test
  public void enumSwitch_test_12119(MethodHandles.Lookup p0, String p1, MethodType p2,
      Object[] p3) {
    SwitchBootstraps.enumSwitch(p0, p1, p2, p3);
  }
}
