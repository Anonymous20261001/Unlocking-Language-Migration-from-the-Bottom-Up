package generated.test;

import java.lang.Class;
import java.lang.String;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_atomic_AtomicReferenceFieldUpdaterAutoTest {
  @Test
  public void newUpdater_test_746(Class p0, Class p1, String p2) {
    AtomicReferenceFieldUpdater.newUpdater(p0, p1, p2);
  }
}
