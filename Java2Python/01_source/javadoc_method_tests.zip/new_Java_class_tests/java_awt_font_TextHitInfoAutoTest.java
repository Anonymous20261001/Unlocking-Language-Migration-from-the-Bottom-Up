package generated.test;

import java.awt.font.TextHitInfo;
import org.junit.jupiter.api.Test;

public class java_awt_font_TextHitInfoAutoTest {
  @Test
  public void trailing_test_12587(int p0) {
    TextHitInfo.trailing(p0);
  }

  @Test
  public void leading_test_12588(int p0) {
    TextHitInfo.leading(p0);
  }

  @Test
  public void beforeOffset_test_12589(int p0) {
    TextHitInfo.beforeOffset(p0);
  }

  @Test
  public void afterOffset_test_12590(int p0) {
    TextHitInfo.afterOffset(p0);
  }
}
