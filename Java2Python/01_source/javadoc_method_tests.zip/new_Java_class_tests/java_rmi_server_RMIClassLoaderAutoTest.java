package generated.test;

import java.lang.Class;
import java.lang.ClassLoader;
import java.rmi.server.RMIClassLoader;
import org.junit.jupiter.api.Test;

public class java_rmi_server_RMIClassLoaderAutoTest {
  @Test
  public void getClassAnnotation_test_10630(Class p0) {
    RMIClassLoader.getClassAnnotation(p0);
  }

  @Test
  public void getDefaultProviderInstance_test_10631() {
    RMIClassLoader.getDefaultProviderInstance();
  }

  @Test
  public void getSecurityContext_test_10632(ClassLoader p0) {
    RMIClassLoader.getSecurityContext(p0);
  }
}
