package generated.test;

import java.lang.String;
import javax.swing.UIDefaults;
import org.junit.jupiter.api.Test;

public class javax_swing_UIDefaults_ProxyLazyValueAutoTest {
  @Test
  public void createValue_test_13143(UIDefaults p0, String c0) {
    UIDefaults.ProxyLazyValue instance = new UIDefaults.ProxyLazyValue(c0);
    instance.createValue(p0);
  }
}
