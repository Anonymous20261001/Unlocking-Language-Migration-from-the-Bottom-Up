package generated.test;

import javax.imageio.plugins.tiff.ExifTIFFTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_ExifTIFFTagSetAutoTest {
  @Test
  public void getInstance_test_4664() {
    ExifTIFFTagSet.getInstance();
  }
}
