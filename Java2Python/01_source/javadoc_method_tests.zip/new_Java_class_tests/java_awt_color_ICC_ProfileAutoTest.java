package generated.test;

import java.awt.color.ICC_Profile;
import org.junit.jupiter.api.Test;

public class java_awt_color_ICC_ProfileAutoTest {
  @Test
  public void getInstance_test_5507(int p0) {
    ICC_Profile.getInstance(p0);
  }

  @Test
  public void getInstance_test_5508(byte[] p0) {
    ICC_Profile.getInstance(p0);
  }
}
