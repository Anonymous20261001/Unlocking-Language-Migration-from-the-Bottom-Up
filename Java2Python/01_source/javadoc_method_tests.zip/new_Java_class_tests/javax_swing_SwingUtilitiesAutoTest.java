package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.lang.Class;
import java.lang.Object;
import java.lang.Runnable;
import java.lang.String;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.Icon;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import org.junit.jupiter.api.Test;

public class javax_swing_SwingUtilitiesAutoTest {
  @Test
  public void getUnwrappedParent_test_12073(Component p0) {
    SwingUtilities.getUnwrappedParent(p0);
  }

  @Test
  public void isEventDispatchThread_test_12074() {
    SwingUtilities.isEventDispatchThread();
  }

  @Test
  public void updateComponentTreeUI_test_12075(Component p0) {
    SwingUtilities.updateComponentTreeUI(p0);
  }

  @Test
  public void isDescendingFrom_test_12076(Component p0, Component p1) {
    SwingUtilities.isDescendingFrom(p0, p1);
  }

  @Test
  public void getUIActionMap_test_12077(JComponent p0) {
    SwingUtilities.getUIActionMap(p0);
  }

  @Test
  public void getRootPane_test_12078(Component p0) {
    SwingUtilities.getRootPane(p0);
  }

  @Test
  public void getWindowAncestor_test_12079(Component p0) {
    SwingUtilities.getWindowAncestor(p0);
  }

  @Test
  public void computeIntersection_test_12080(int p0, int p1, int p2, int p3, Rectangle p4) {
    SwingUtilities.computeIntersection(p0, p1, p2, p3, p4);
  }

  @Test
  public void paintComponent_test_12081(Graphics p0, Component p1, Container p2, Rectangle p3) {
    SwingUtilities.paintComponent(p0, p1, p2, p3);
  }

  @Test
  public void paintComponent_test_12082(Graphics p0, Component p1, Container p2, int p3, int p4,
      int p5, int p6) {
    SwingUtilities.paintComponent(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void processKeyBindings_test_12083(KeyEvent p0) {
    SwingUtilities.processKeyBindings(p0);
  }

  @Test
  public void notifyAction_test_12084(Action p0, KeyStroke p1, KeyEvent p2, Object p3, int p4) {
    SwingUtilities.notifyAction(p0, p1, p2, p3, p4);
  }

  @Test
  public void convertRectangle_test_12085(Component p0, Rectangle p1, Component p2) {
    SwingUtilities.convertRectangle(p0, p1, p2);
  }

  @Test
  public void invokeLater_test_12086(Runnable p0) {
    SwingUtilities.invokeLater(p0);
  }

  @Test
  public void getAccessibleChildrenCount_test_12087(Component p0) {
    SwingUtilities.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_12088(Component p0, int p1) {
    SwingUtilities.getAccessibleChild(p0, p1);
  }

  @Test
  public void getAccessibleAt_test_12089(Component p0, Point p1) {
    SwingUtilities.getAccessibleAt(p0, p1);
  }

  @Test
  public void getAccessibleIndexInParent_test_12090(Component p0) {
    SwingUtilities.getAccessibleIndexInParent(p0);
  }

  @Test
  public void getAccessibleStateSet_test_12091(Component p0) {
    SwingUtilities.getAccessibleStateSet(p0);
  }

  @Test
  public void convertPoint_test_12092(Component p0, Point p1, Component p2) {
    SwingUtilities.convertPoint(p0, p1, p2);
  }

  @Test
  public void convertPoint_test_12093(Component p0, int p1, int p2, Component p3) {
    SwingUtilities.convertPoint(p0, p1, p2, p3);
  }

  @Test
  public void convertMouseEvent_test_12094(Component p0, MouseEvent p1, Component p2) {
    SwingUtilities.convertMouseEvent(p0, p1, p2);
  }

  @Test
  public void replaceUIInputMap_test_12095(JComponent p0, int p1, InputMap p2) {
    SwingUtilities.replaceUIInputMap(p0, p1, p2);
  }

  @Test
  public void replaceUIActionMap_test_12096(JComponent p0, ActionMap p1) {
    SwingUtilities.replaceUIActionMap(p0, p1);
  }

  @Test
  public void getUIInputMap_test_12097(JComponent p0, int p1) {
    SwingUtilities.getUIInputMap(p0, p1);
  }

  @Test
  public void isLeftMouseButton_test_12098(MouseEvent p0) {
    SwingUtilities.isLeftMouseButton(p0);
  }

  @Test
  public void layoutCompoundLabel_test_12099(FontMetrics p0, String p1, Icon p2, int p3, int p4,
      int p5, int p6, Rectangle p7, Rectangle p8, Rectangle p9, int p10) {
    SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
  }

  @Test
  public void layoutCompoundLabel_test_12100(JComponent p0, FontMetrics p1, String p2, Icon p3,
      int p4, int p5, int p6, int p7, Rectangle p8, Rectangle p9, Rectangle p10, int p11) {
    SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11);
  }

  @Test
  public void getAncestorOfClass_test_12101(Class p0, Component p1) {
    SwingUtilities.getAncestorOfClass(p0, p1);
  }

  @Test
  public void convertPointToScreen_test_12102(Point p0, Component p1) {
    SwingUtilities.convertPointToScreen(p0, p1);
  }

  @Test
  public void convertPointFromScreen_test_12103(Point p0, Component p1) {
    SwingUtilities.convertPointFromScreen(p0, p1);
  }

  @Test
  public void getDeepestComponentAt_test_12104(Component p0, int p1, int p2) {
    SwingUtilities.getDeepestComponentAt(p0, p1, p2);
  }

  @Test
  public void isRectangleContainingRectangle_test_12105(Rectangle p0, Rectangle p1) {
    SwingUtilities.isRectangleContainingRectangle(p0, p1);
  }

  @Test
  public void getLocalBounds_test_12106(Component p0) {
    SwingUtilities.getLocalBounds(p0);
  }

  @Test
  public void getAncestorNamed_test_12107(String p0, Component p1) {
    SwingUtilities.getAncestorNamed(p0, p1);
  }

  @Test
  public void windowForComponent_test_12108(Component p0) {
    SwingUtilities.windowForComponent(p0);
  }

  @Test
  public void computeUnion_test_12109(int p0, int p1, int p2, int p3, Rectangle p4) {
    SwingUtilities.computeUnion(p0, p1, p2, p3, p4);
  }

  @Test
  public void computeDifference_test_12110(Rectangle p0, Rectangle p1) {
    SwingUtilities.computeDifference(p0, p1);
  }

  @Test
  public void isMiddleMouseButton_test_12111(MouseEvent p0) {
    SwingUtilities.isMiddleMouseButton(p0);
  }

  @Test
  public void isRightMouseButton_test_12112(MouseEvent p0) {
    SwingUtilities.isRightMouseButton(p0);
  }

  @Test
  public void computeStringWidth_test_12113(FontMetrics p0, String p1) {
    SwingUtilities.computeStringWidth(p0, p1);
  }

  @Test
  public void findFocusOwner_test_12114(Component p0) {
    SwingUtilities.findFocusOwner(p0);
  }

  @Test
  public void calculateInnerArea_test_12115(JComponent p0, Rectangle p1) {
    SwingUtilities.calculateInnerArea(p0, p1);
  }

  @Test
  public void getUnwrappedView_test_12116(JViewport p0) {
    SwingUtilities.getUnwrappedView(p0);
  }

  @Test
  public void getRoot_test_12117(Component p0) {
    SwingUtilities.getRoot(p0);
  }
}
