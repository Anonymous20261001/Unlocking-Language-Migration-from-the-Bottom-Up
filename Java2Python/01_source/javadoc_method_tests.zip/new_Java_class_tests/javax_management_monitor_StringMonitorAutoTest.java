package generated.test;

import java.lang.String;
import javax.management.ObjectName;
import javax.management.monitor.StringMonitor;
import org.junit.jupiter.api.Test;

public class javax_management_monitor_StringMonitorAutoTest {
  @Test
  public void getNotificationInfo_test_11889() {
    StringMonitor instance = new StringMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_11890() {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGauge_test_11891(ObjectName p0) {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_11892(ObjectName p0) {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_11893() {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getStringToCompare_test_11894() {
    StringMonitor instance = new StringMonitor();
    instance.getStringToCompare();
  }

  @Test
  public void setStringToCompare_test_11895(String p0) {
    StringMonitor instance = new StringMonitor();
    instance.setStringToCompare(p0);
  }

  @Test
  public void getNotifyMatch_test_11896() {
    StringMonitor instance = new StringMonitor();
    instance.getNotifyMatch();
  }

  @Test
  public void setNotifyMatch_test_11897(boolean p0) {
    StringMonitor instance = new StringMonitor();
    instance.setNotifyMatch(p0);
  }

  @Test
  public void getNotifyDiffer_test_11898() {
    StringMonitor instance = new StringMonitor();
    instance.getNotifyDiffer();
  }

  @Test
  public void setNotifyDiffer_test_11899(boolean p0) {
    StringMonitor instance = new StringMonitor();
    instance.setNotifyDiffer(p0);
  }

  @Test
  public void start_test_11900() {
    StringMonitor instance = new StringMonitor();
    instance.start();
  }

  @Test
  public void stop_test_11901() {
    StringMonitor instance = new StringMonitor();
    instance.stop();
  }
}
