package generated.test;

import java.awt.geom.CubicCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_CubicCurve2D_DoubleAutoTest {
  @Test
  public void setCurve_test_3134(double p0, double p1, double p2, double p3, double p4, double p5,
      double p6, double p7) {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.setCurve(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void getCtrlX1_test_3135() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlX1();
  }

  @Test
  public void getCtrlY1_test_3136() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlY1();
  }

  @Test
  public void getCtrlX2_test_3137() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlX2();
  }

  @Test
  public void getCtrlY2_test_3138() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlY2();
  }

  @Test
  public void getCtrlP1_test_3139() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlP1();
  }

  @Test
  public void getCtrlP2_test_3140() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getCtrlP2();
  }

  @Test
  public void getX1_test_3141() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getX1();
  }

  @Test
  public void getY1_test_3142() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getY1();
  }

  @Test
  public void getX2_test_3143() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getX2();
  }

  @Test
  public void getY2_test_3144() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getY2();
  }

  @Test
  public void getP1_test_3145() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getP1();
  }

  @Test
  public void getP2_test_3146() {
    CubicCurve2D.Double instance = new CubicCurve2D.Double();
    instance.getP2();
  }
}
