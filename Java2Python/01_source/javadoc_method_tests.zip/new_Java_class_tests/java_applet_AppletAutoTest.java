package generated.test;

import java.applet.Applet;
import java.applet.AppletStub;
import java.awt.Dimension;
import java.lang.String;
import java.net.URL;
import org.junit.jupiter.api.Test;

public class java_applet_AppletAutoTest {
  @Test
  public void getDocumentBase_test_163() {
    Applet instance = new Applet();
    instance.getDocumentBase();
  }

  @Test
  public void getCodeBase_test_164() {
    Applet instance = new Applet();
    instance.getCodeBase();
  }

  @Test
  public void getAppletContext_test_165() {
    Applet instance = new Applet();
    instance.getAppletContext();
  }

  @Test
  public void showStatus_test_166(String p0) {
    Applet instance = new Applet();
    instance.showStatus(p0);
  }

  @Test
  public void getAudioClip_test_167(URL p0, String p1) {
    Applet instance = new Applet();
    instance.getAudioClip(p0, p1);
  }

  @Test
  public void getAudioClip_test_168(URL p0) {
    Applet instance = new Applet();
    instance.getAudioClip(p0);
  }

  @Test
  public void play_test_169(URL p0) {
    Applet instance = new Applet();
    instance.play(p0);
  }

  @Test
  public void play_test_170(URL p0, String p1) {
    Applet instance = new Applet();
    instance.play(p0, p1);
  }

  @Test
  public void setStub_test_171(AppletStub p0) {
    Applet instance = new Applet();
    instance.setStub(p0);
  }

  @Test
  public void newAudioClip_test_172(URL p0) {
    Applet.newAudioClip(p0);
  }

  @Test
  public void getAppletInfo_test_173() {
    Applet instance = new Applet();
    instance.getAppletInfo();
  }

  @Test
  public void getParameterInfo_test_174() {
    Applet instance = new Applet();
    instance.getParameterInfo();
  }

  @Test
  public void isValidateRoot_test_175() {
    Applet instance = new Applet();
    instance.isValidateRoot();
  }

  @Test
  public void getAccessibleContext_test_176() {
    Applet instance = new Applet();
    instance.getAccessibleContext();
  }

  @Test
  public void getImage_test_177(URL p0, String p1) {
    Applet instance = new Applet();
    instance.getImage(p0, p1);
  }

  @Test
  public void getImage_test_178(URL p0) {
    Applet instance = new Applet();
    instance.getImage(p0);
  }

  @Test
  public void init_test_179() {
    Applet instance = new Applet();
    instance.init();
  }

  @Test
  public void start_test_180() {
    Applet instance = new Applet();
    instance.start();
  }

  @Test
  public void stop_test_181() {
    Applet instance = new Applet();
    instance.stop();
  }

  @Test
  public void destroy_test_182() {
    Applet instance = new Applet();
    instance.destroy();
  }

  @Test
  public void isActive_test_183() {
    Applet instance = new Applet();
    instance.isActive();
  }

  @Test
  public void resize_test_184(int p0, int p1) {
    Applet instance = new Applet();
    instance.resize(p0, p1);
  }

  @Test
  public void resize_test_185(Dimension p0) {
    Applet instance = new Applet();
    instance.resize(p0);
  }

  @Test
  public void getLocale_test_186() {
    Applet instance = new Applet();
    instance.getLocale();
  }

  @Test
  public void getParameter_test_187(String p0) {
    Applet instance = new Applet();
    instance.getParameter(p0);
  }
}
