package generated.test;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ButtonAutoTest {
  @Test
  public void getListeners_test_1949(Class p0) {
    Button instance = new Button();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_1950() {
    Button instance = new Button();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_1951() {
    Button instance = new Button();
    instance.getAccessibleContext();
  }

  @Test
  public void setActionCommand_test_1952(String p0) {
    Button instance = new Button();
    instance.setActionCommand(p0);
  }

  @Test
  public void getActionCommand_test_1953() {
    Button instance = new Button();
    instance.getActionCommand();
  }

  @Test
  public void removeActionListener_test_1954(ActionListener p0) {
    Button instance = new Button();
    instance.removeActionListener(p0);
  }

  @Test
  public void addActionListener_test_1955(ActionListener p0) {
    Button instance = new Button();
    instance.addActionListener(p0);
  }

  @Test
  public void getActionListeners_test_1956() {
    Button instance = new Button();
    instance.getActionListeners();
  }

  @Test
  public void setLabel_test_1957(String p0) {
    Button instance = new Button();
    instance.setLabel(p0);
  }

  @Test
  public void getLabel_test_1958() {
    Button instance = new Button();
    instance.getLabel();
  }
}
