package generated.test;

import java.io.Reader;
import java.lang.CharSequence;
import org.junit.jupiter.api.Test;

public class java_io_ReaderAutoTest {
  @Test
  public void nullReader_test_10346() {
    Reader.nullReader();
  }

  @Test
  public void of_test_10347(CharSequence p0) {
    Reader.of(p0);
  }
}
