package generated.test;

import java.lang.Object;
import java.lang.Runnable;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ExecutorsAutoTest {
  @Test
  public void newSingleThreadScheduledExecutor_test_4637() {
    Executors.newSingleThreadScheduledExecutor();
  }

  @Test
  public void newSingleThreadScheduledExecutor_test_4638(ThreadFactory p0) {
    Executors.newSingleThreadScheduledExecutor(p0);
  }

  @Test
  public void defaultThreadFactory_test_4639() {
    Executors.defaultThreadFactory();
  }

  @Test
  public void newSingleThreadExecutor_test_4640(ThreadFactory p0) {
    Executors.newSingleThreadExecutor(p0);
  }

  @Test
  public void newSingleThreadExecutor_test_4641() {
    Executors.newSingleThreadExecutor();
  }

  @Test
  public void newThreadPerTaskExecutor_test_4642(ThreadFactory p0) {
    Executors.newThreadPerTaskExecutor(p0);
  }

  @Test
  public void newFixedThreadPool_test_4643(int p0) {
    Executors.newFixedThreadPool(p0);
  }

  @Test
  public void newFixedThreadPool_test_4644(int p0, ThreadFactory p1) {
    Executors.newFixedThreadPool(p0, p1);
  }

  @Test
  public void newWorkStealingPool_test_4645() {
    Executors.newWorkStealingPool();
  }

  @Test
  public void newWorkStealingPool_test_4646(int p0) {
    Executors.newWorkStealingPool(p0);
  }

  @Test
  public void newCachedThreadPool_test_4647() {
    Executors.newCachedThreadPool();
  }

  @Test
  public void newCachedThreadPool_test_4648(ThreadFactory p0) {
    Executors.newCachedThreadPool(p0);
  }

  @Test
  public void newVirtualThreadPerTaskExecutor_test_4649() {
    Executors.newVirtualThreadPerTaskExecutor();
  }

  @Test
  public void newScheduledThreadPool_test_4650(int p0, ThreadFactory p1) {
    Executors.newScheduledThreadPool(p0, p1);
  }

  @Test
  public void newScheduledThreadPool_test_4651(int p0) {
    Executors.newScheduledThreadPool(p0);
  }

  @Test
  public void unconfigurableExecutorService_test_4652(ExecutorService p0) {
    Executors.unconfigurableExecutorService(p0);
  }

  @Test
  public void unconfigurableScheduledExecutorService_test_4653(ScheduledExecutorService p0) {
    Executors.unconfigurableScheduledExecutorService(p0);
  }

  @Test
  public void privilegedThreadFactory_test_4654() {
    Executors.privilegedThreadFactory();
  }

  @Test
  public void privilegedCallable_test_4655(Callable p0) {
    Executors.privilegedCallable(p0);
  }

  @Test
  public void privilegedCallableUsingCurrentClassLoader_test_4656(Callable p0) {
    Executors.privilegedCallableUsingCurrentClassLoader(p0);
  }

  @Test
  public void callable_test_4657(Runnable p0) {
    Executors.callable(p0);
  }

  @Test
  public void callable_test_4658(Runnable p0, Object p1) {
    Executors.callable(p0, p1);
  }

  @Test
  public void callable_test_4659(PrivilegedAction p0) {
    Executors.callable(p0);
  }

  @Test
  public void callable_test_4660(PrivilegedExceptionAction p0) {
    Executors.callable(p0);
  }
}
