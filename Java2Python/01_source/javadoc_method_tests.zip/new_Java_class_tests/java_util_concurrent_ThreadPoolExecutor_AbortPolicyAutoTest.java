package generated.test;

import java.lang.Runnable;
import java.util.concurrent.ThreadPoolExecutor;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ThreadPoolExecutor_AbortPolicyAutoTest {
  @Test
  public void rejectedExecution_test_12742(Runnable p0, ThreadPoolExecutor p1) {
    ThreadPoolExecutor.AbortPolicy instance = new ThreadPoolExecutor.AbortPolicy();
    instance.rejectedExecution(p0, p1);
  }
}
