package generated.test;

import java.lang.String;
import javax.swing.UIManager;
import org.junit.jupiter.api.Test;

public class javax_swing_UIManager_LookAndFeelInfoAutoTest {
  @Test
  public void getName_test_13181(String c0, String c1) {
    UIManager.LookAndFeelInfo instance = new UIManager.LookAndFeelInfo(c0, c1);
    instance.getName();
  }

  @Test
  public void getClassName_test_13182(String c0, String c1) {
    UIManager.LookAndFeelInfo instance = new UIManager.LookAndFeelInfo(c0, c1);
    instance.getClassName();
  }
}
