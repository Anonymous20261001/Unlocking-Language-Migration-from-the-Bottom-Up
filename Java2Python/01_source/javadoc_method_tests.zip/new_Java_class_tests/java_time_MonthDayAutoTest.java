package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Month;
import java.time.MonthDay;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_MonthDayAutoTest {
  @Test
  public void of_test_9004(int p0, int p1) {
    MonthDay.of(p0, p1);
  }

  @Test
  public void of_test_9005(Month p0, int p1) {
    MonthDay.of(p0, p1);
  }

  @Test
  public void from_test_9006(TemporalAccessor p0) {
    MonthDay.from(p0);
  }

  @Test
  public void parse_test_9007(CharSequence p0, DateTimeFormatter p1) {
    MonthDay.parse(p0, p1);
  }

  @Test
  public void parse_test_9008(CharSequence p0) {
    MonthDay.parse(p0);
  }

  @Test
  public void now_test_9009(ZoneId p0) {
    MonthDay.now(p0);
  }

  @Test
  public void now_test_9010() {
    MonthDay.now();
  }

  @Test
  public void now_test_9011(Clock p0) {
    MonthDay.now(p0);
  }
}
