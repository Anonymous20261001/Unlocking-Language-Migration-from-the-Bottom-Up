package generated.test;

import java.security.DrbgParameters;
import org.junit.jupiter.api.Test;

public class java_security_DrbgParametersAutoTest {
  @Test
  public void reseed_test_4339(boolean p0, byte[] p1) {
    DrbgParameters.reseed(p0, p1);
  }

  @Test
  public void instantiation_test_4340(int p0, DrbgParameters.Capability p1, byte[] p2) {
    DrbgParameters.instantiation(p0, p1, p2);
  }

  @Test
  public void nextBytes_test_4341(int p0, boolean p1, byte[] p2) {
    DrbgParameters.nextBytes(p0, p1, p2);
  }
}
