package generated.test;

import javax.swing.ToolTipManager;
import org.junit.jupiter.api.Test;

public class javax_swing_ToolTipManagerAutoTest {
  @Test
  public void sharedInstance_test_12932() {
    ToolTipManager.sharedInstance();
  }
}
