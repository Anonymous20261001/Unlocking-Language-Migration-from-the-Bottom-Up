package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_CopyActionAutoTest {
  @Test
  public void actionPerformed_test_3670(ActionEvent p0) {
    DefaultEditorKit.CopyAction instance = new DefaultEditorKit.CopyAction();
    instance.actionPerformed(p0);
  }
}
