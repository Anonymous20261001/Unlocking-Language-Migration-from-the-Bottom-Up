package generated.test;

import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEdit;
import org.junit.jupiter.api.Test;

public class javax_swing_undo_UndoManagerAutoTest {
  @Test
  public void undoableEditHappened_test_13193(UndoableEditEvent p0) {
    UndoManager instance = new UndoManager();
    instance.undoableEditHappened(p0);
  }

  @Test
  public void addEdit_test_13194(UndoableEdit p0) {
    UndoManager instance = new UndoManager();
    instance.addEdit(p0);
  }

  @Test
  public void redo_test_13195() {
    UndoManager instance = new UndoManager();
    instance.redo();
  }

  @Test
  public void undo_test_13196() {
    UndoManager instance = new UndoManager();
    instance.undo();
  }

  @Test
  public void getUndoPresentationName_test_13197() {
    UndoManager instance = new UndoManager();
    instance.getUndoPresentationName();
  }

  @Test
  public void getRedoPresentationName_test_13198() {
    UndoManager instance = new UndoManager();
    instance.getRedoPresentationName();
  }

  @Test
  public void canUndo_test_13199() {
    UndoManager instance = new UndoManager();
    instance.canUndo();
  }

  @Test
  public void canRedo_test_13200() {
    UndoManager instance = new UndoManager();
    instance.canRedo();
  }

  @Test
  public void getLimit_test_13201() {
    UndoManager instance = new UndoManager();
    instance.getLimit();
  }

  @Test
  public void discardAllEdits_test_13202() {
    UndoManager instance = new UndoManager();
    instance.discardAllEdits();
  }

  @Test
  public void setLimit_test_13203(int p0) {
    UndoManager instance = new UndoManager();
    instance.setLimit(p0);
  }

  @Test
  public void undoOrRedo_test_13204() {
    UndoManager instance = new UndoManager();
    instance.undoOrRedo();
  }

  @Test
  public void canUndoOrRedo_test_13205() {
    UndoManager instance = new UndoManager();
    instance.canUndoOrRedo();
  }

  @Test
  public void getUndoOrRedoPresentationName_test_13206() {
    UndoManager instance = new UndoManager();
    instance.getUndoOrRedoPresentationName();
  }

  @Test
  public void end_test_13207() {
    UndoManager instance = new UndoManager();
    instance.end();
  }
}
