package generated.test;

import java.lang.invoke.MethodHandle;
import jdk.dynalink.CallSiteDescriptor;
import jdk.dynalink.linker.GuardedInvocation;
import jdk.dynalink.support.ChainedCallSite;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_support_ChainedCallSiteAutoTest {
  @Test
  public void relink_test_2108(GuardedInvocation p0, MethodHandle p1, CallSiteDescriptor c0) {
    ChainedCallSite instance = new ChainedCallSite(c0);
    instance.relink(p0, p1);
  }

  @Test
  public void resetAndRelink_test_2109(GuardedInvocation p0, MethodHandle p1,
      CallSiteDescriptor c0) {
    ChainedCallSite instance = new ChainedCallSite(c0);
    instance.resetAndRelink(p0, p1);
  }
}
