package generated.test;

import java.awt.color.ColorSpace;
import org.junit.jupiter.api.Test;

public class java_awt_color_ColorSpaceAutoTest {
  @Test
  public void getInstance_test_2503(int p0) {
    ColorSpace.getInstance(p0);
  }
}
