package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.plaf.basic.BasicBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_basic_BasicBorders_ButtonBorderAutoTest {
  @Test
  public void paintBorder_test_1022(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
      Color c0, Color c1, Color c2, Color c3) {
    BasicBorders.ButtonBorder instance = new BasicBorders.ButtonBorder(c0, c1, c2, c3);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_1023(Component p0, Insets p1, Color c0, Color c1, Color c2,
      Color c3) {
    BasicBorders.ButtonBorder instance = new BasicBorders.ButtonBorder(c0, c1, c2, c3);
    instance.getBorderInsets(p0, p1);
  }
}
