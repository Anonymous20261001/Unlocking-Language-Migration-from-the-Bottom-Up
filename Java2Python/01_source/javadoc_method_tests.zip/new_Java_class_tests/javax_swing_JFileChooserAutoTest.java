package generated.test;

import java.awt.Component;
import java.awt.event.ActionListener;
import java.io.File;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;
import org.junit.jupiter.api.Test;

public class javax_swing_JFileChooserAutoTest {
  @Test
  public void getDescription_test_6176(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getDescription(p0);
  }

  @Test
  public void getFileSystemView_test_6177() {
    JFileChooser instance = new JFileChooser();
    instance.getFileSystemView();
  }

  @Test
  public void getCurrentDirectory_test_6178() {
    JFileChooser instance = new JFileChooser();
    instance.getCurrentDirectory();
  }

  @Test
  public void isTraversable_test_6179(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.isTraversable(p0);
  }

  @Test
  public void setCurrentDirectory_test_6180(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.setCurrentDirectory(p0);
  }

  @Test
  public void setFileSystemView_test_6181(FileSystemView p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileSystemView(p0);
  }

  @Test
  public void isAcceptAllFileFilterUsed_test_6182() {
    JFileChooser instance = new JFileChooser();
    instance.isAcceptAllFileFilterUsed();
  }

  @Test
  public void getAcceptAllFileFilter_test_6183() {
    JFileChooser instance = new JFileChooser();
    instance.getAcceptAllFileFilter();
  }

  @Test
  public void setFileFilter_test_6184(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileFilter(p0);
  }

  @Test
  public void isMultiSelectionEnabled_test_6185() {
    JFileChooser instance = new JFileChooser();
    instance.isMultiSelectionEnabled();
  }

  @Test
  public void ensureFileIsVisible_test_6186(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.ensureFileIsVisible(p0);
  }

  @Test
  public void setSelectedFile_test_6187(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.setSelectedFile(p0);
  }

  @Test
  public void rescanCurrentDirectory_test_6188() {
    JFileChooser instance = new JFileChooser();
    instance.rescanCurrentDirectory();
  }

  @Test
  public void setDialogType_test_6189(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDialogType(p0);
  }

  @Test
  public void setApproveButtonText_test_6190(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonText(p0);
  }

  @Test
  public void getDialogTitle_test_6191() {
    JFileChooser instance = new JFileChooser();
    instance.getDialogTitle();
  }

  @Test
  public void setApproveButtonMnemonic_test_6192(char p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonMnemonic(p0);
  }

  @Test
  public void setApproveButtonMnemonic_test_6193(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonMnemonic(p0);
  }

  @Test
  public void getChoosableFileFilters_test_6194() {
    JFileChooser instance = new JFileChooser();
    instance.getChoosableFileFilters();
  }

  @Test
  public void getFileFilter_test_6195() {
    JFileChooser instance = new JFileChooser();
    instance.getFileFilter();
  }

  @Test
  public void addChoosableFileFilter_test_6196(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.addChoosableFileFilter(p0);
  }

  @Test
  public void removeChoosableFileFilter_test_6197(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.removeChoosableFileFilter(p0);
  }

  @Test
  public void setSelectedFiles_test_6198(File[] p0) {
    JFileChooser instance = new JFileChooser();
    instance.setSelectedFiles(p0);
  }

  @Test
  public void getFileView_test_6199() {
    JFileChooser instance = new JFileChooser();
    instance.getFileView();
  }

  @Test
  public void getSelectedFile_test_6200() {
    JFileChooser instance = new JFileChooser();
    instance.getSelectedFile();
  }

  @Test
  public void getSelectedFiles_test_6201() {
    JFileChooser instance = new JFileChooser();
    instance.getSelectedFiles();
  }

  @Test
  public void changeToParentDirectory_test_6202() {
    JFileChooser instance = new JFileChooser();
    instance.changeToParentDirectory();
  }

  @Test
  public void showOpenDialog_test_6203(Component p0) {
    JFileChooser instance = new JFileChooser();
    instance.showOpenDialog(p0);
  }

  @Test
  public void showSaveDialog_test_6204(Component p0) {
    JFileChooser instance = new JFileChooser();
    instance.showSaveDialog(p0);
  }

  @Test
  public void getControlButtonsAreShown_test_6205() {
    JFileChooser instance = new JFileChooser();
    instance.getControlButtonsAreShown();
  }

  @Test
  public void setControlButtonsAreShown_test_6206(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setControlButtonsAreShown(p0);
  }

  @Test
  public void getDialogType_test_6207() {
    JFileChooser instance = new JFileChooser();
    instance.getDialogType();
  }

  @Test
  public void setDialogTitle_test_6208(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDialogTitle(p0);
  }

  @Test
  public void setApproveButtonToolTipText_test_6209(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonToolTipText(p0);
  }

  @Test
  public void getApproveButtonToolTipText_test_6210() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonToolTipText();
  }

  @Test
  public void getApproveButtonMnemonic_test_6211() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonMnemonic();
  }

  @Test
  public void getApproveButtonText_test_6212() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonText();
  }

  @Test
  public void resetChoosableFileFilters_test_6213() {
    JFileChooser instance = new JFileChooser();
    instance.resetChoosableFileFilters();
  }

  @Test
  public void setAcceptAllFileFilterUsed_test_6214(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setAcceptAllFileFilterUsed(p0);
  }

  @Test
  public void getAccessory_test_6215() {
    JFileChooser instance = new JFileChooser();
    instance.getAccessory();
  }

  @Test
  public void setAccessory_test_6216(JComponent p0) {
    JFileChooser instance = new JFileChooser();
    instance.setAccessory(p0);
  }

  @Test
  public void setFileSelectionMode_test_6217(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileSelectionMode(p0);
  }

  @Test
  public void getFileSelectionMode_test_6218() {
    JFileChooser instance = new JFileChooser();
    instance.getFileSelectionMode();
  }

  @Test
  public void isFileSelectionEnabled_test_6219() {
    JFileChooser instance = new JFileChooser();
    instance.isFileSelectionEnabled();
  }

  @Test
  public void isDirectorySelectionEnabled_test_6220() {
    JFileChooser instance = new JFileChooser();
    instance.isDirectorySelectionEnabled();
  }

  @Test
  public void setMultiSelectionEnabled_test_6221(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setMultiSelectionEnabled(p0);
  }

  @Test
  public void isFileHidingEnabled_test_6222() {
    JFileChooser instance = new JFileChooser();
    instance.isFileHidingEnabled();
  }

  @Test
  public void setFileHidingEnabled_test_6223(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileHidingEnabled(p0);
  }

  @Test
  public void setFileView_test_6224(FileView p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileView(p0);
  }

  @Test
  public void approveSelection_test_6225() {
    JFileChooser instance = new JFileChooser();
    instance.approveSelection();
  }

  @Test
  public void cancelSelection_test_6226() {
    JFileChooser instance = new JFileChooser();
    instance.cancelSelection();
  }

  @Test
  public void setEnabled_test_6227(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setEnabled(p0);
  }

  @Test
  public void getUIClassID_test_6228() {
    JFileChooser instance = new JFileChooser();
    instance.getUIClassID();
  }

  @Test
  public void updateUI_test_6229() {
    JFileChooser instance = new JFileChooser();
    instance.updateUI();
  }

  @Test
  public void getUI_test_6230() {
    JFileChooser instance = new JFileChooser();
    instance.getUI();
  }

  @Test
  public void getAccessibleContext_test_6231() {
    JFileChooser instance = new JFileChooser();
    instance.getAccessibleContext();
  }

  @Test
  public void getIcon_test_6232(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getIcon(p0);
  }

  @Test
  public void removeActionListener_test_6233(ActionListener p0) {
    JFileChooser instance = new JFileChooser();
    instance.removeActionListener(p0);
  }

  @Test
  public void addActionListener_test_6234(ActionListener p0) {
    JFileChooser instance = new JFileChooser();
    instance.addActionListener(p0);
  }

  @Test
  public void getActionListeners_test_6235() {
    JFileChooser instance = new JFileChooser();
    instance.getActionListeners();
  }

  @Test
  public void showDialog_test_6236(Component p0, String p1) {
    JFileChooser instance = new JFileChooser();
    instance.showDialog(p0, p1);
  }

  @Test
  public void setDragEnabled_test_6237(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDragEnabled(p0);
  }

  @Test
  public void getDragEnabled_test_6238() {
    JFileChooser instance = new JFileChooser();
    instance.getDragEnabled();
  }

  @Test
  public void getName_test_6239(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getName(p0);
  }

  @Test
  public void accept_test_6240(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.accept(p0);
  }

  @Test
  public void getTypeDescription_test_6241(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getTypeDescription(p0);
  }
}
