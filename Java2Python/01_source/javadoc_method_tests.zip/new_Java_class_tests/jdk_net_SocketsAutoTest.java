package generated.test;

import java.lang.Class;
import jdk.net.Sockets;
import org.junit.jupiter.api.Test;

public class jdk_net_SocketsAutoTest {
  @Test
  public void supportedOptions_test_11266(Class p0) {
    Sockets.supportedOptions(p0);
  }
}
