package generated.test;

import jdk.jshell.execution.DirectExecutionControl;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_DirectExecutionControlAutoTest {
  @Test
  public void close_test_4181() {
    DirectExecutionControl instance = new DirectExecutionControl();
    instance.close();
  }
}
