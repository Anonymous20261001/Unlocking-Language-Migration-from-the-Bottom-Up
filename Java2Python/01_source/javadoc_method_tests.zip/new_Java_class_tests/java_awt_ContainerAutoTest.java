package generated.test;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Event;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.ContainerListener;
import java.beans.PropertyChangeListener;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.Class;
import java.lang.Object;
import java.lang.String;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class java_awt_ContainerAutoTest {
  @Test
  public void addPropertyChangeListener_test_2934(PropertyChangeListener p0) {
    Container instance = new Container();
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void addPropertyChangeListener_test_2935(String p0, PropertyChangeListener p1) {
    Container instance = new Container();
    instance.addPropertyChangeListener(p0, p1);
  }

  @Test
  public void setFont_test_2936(Font p0) {
    Container instance = new Container();
    instance.setFont(p0);
  }

  @Test
  public void getComponentCount_test_2937() {
    Container instance = new Container();
    instance.getComponentCount();
  }

  @Test
  public void paint_test_2938(Graphics p0) {
    Container instance = new Container();
    instance.paint(p0);
  }

  @Test
  public void isFocusCycleRoot_test_2939() {
    Container instance = new Container();
    instance.isFocusCycleRoot();
  }

  @Test
  public void isFocusCycleRoot_test_2940(Container p0) {
    Container instance = new Container();
    instance.isFocusCycleRoot(p0);
  }

  @Test
  public void getFocusTraversalPolicy_test_2941() {
    Container instance = new Container();
    instance.getFocusTraversalPolicy();
  }

  @Test
  public void setFocusTraversalPolicy_test_2942(FocusTraversalPolicy p0) {
    Container instance = new Container();
    instance.setFocusTraversalPolicy(p0);
  }

  @Test
  public void getPreferredSize_test_2943() {
    Container instance = new Container();
    instance.getPreferredSize();
  }

  @Test
  public void getMaximumSize_test_2944() {
    Container instance = new Container();
    instance.getMaximumSize();
  }

  @Test
  public void getMinimumSize_test_2945() {
    Container instance = new Container();
    instance.getMinimumSize();
  }

  @Test
  public void getInsets_test_2946() {
    Container instance = new Container();
    instance.getInsets();
  }

  @Test
  public void getAlignmentY_test_2947() {
    Container instance = new Container();
    instance.getAlignmentY();
  }

  @Test
  public void getAlignmentX_test_2948() {
    Container instance = new Container();
    instance.getAlignmentX();
  }

  @Test
  public void setFocusTraversalKeys_test_2949(int p0, Set p1) {
    Container instance = new Container();
    instance.setFocusTraversalKeys(p0, p1);
  }

  @Test
  public void getListeners_test_2950(Class p0) {
    Container instance = new Container();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_2951() {
    Container instance = new Container();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_2952() {
    Container instance = new Container();
    instance.removeNotify();
  }

  @Test
  public void getComponents_test_2953() {
    Container instance = new Container();
    instance.getComponents();
  }

  @Test
  public void preferredSize_test_2954() {
    Container instance = new Container();
    instance.preferredSize();
  }

  @Test
  public void minimumSize_test_2955() {
    Container instance = new Container();
    instance.minimumSize();
  }

  @Test
  public void insets_test_2956() {
    Container instance = new Container();
    instance.insets();
  }

  @Test
  public void isValidateRoot_test_2957() {
    Container instance = new Container();
    instance.isValidateRoot();
  }

  @Test
  public void countComponents_test_2958() {
    Container instance = new Container();
    instance.countComponents();
  }

  @Test
  public void getComponentZOrder_test_2959(Component p0) {
    Container instance = new Container();
    instance.getComponentZOrder(p0);
  }

  @Test
  public void layout_test_2960() {
    Container instance = new Container();
    instance.layout();
  }

  @Test
  public void doLayout_test_2961() {
    Container instance = new Container();
    instance.doLayout();
  }

  @Test
  public void getComponentAt_test_2962(Point p0) {
    Container instance = new Container();
    instance.getComponentAt(p0);
  }

  @Test
  public void getComponentAt_test_2963(int p0, int p1) {
    Container instance = new Container();
    instance.getComponentAt(p0, p1);
  }

  @Test
  public void deliverEvent_test_2964(Event p0) {
    Container instance = new Container();
    instance.deliverEvent(p0);
  }

  @Test
  public void locate_test_2965(int p0, int p1) {
    Container instance = new Container();
    instance.locate(p0, p1);
  }

  @Test
  public void findComponentAt_test_2966(int p0, int p1) {
    Container instance = new Container();
    instance.findComponentAt(p0, p1);
  }

  @Test
  public void findComponentAt_test_2967(Point p0) {
    Container instance = new Container();
    instance.findComponentAt(p0);
  }

  @Test
  public void isFocusTraversalPolicyProvider_test_2968() {
    Container instance = new Container();
    instance.isFocusTraversalPolicyProvider();
  }

  @Test
  public void applyComponentOrientation_test_2969(ComponentOrientation p0) {
    Container instance = new Container();
    instance.applyComponentOrientation(p0);
  }

  @Test
  public void addContainerListener_test_2970(ContainerListener p0) {
    Container instance = new Container();
    instance.addContainerListener(p0);
  }

  @Test
  public void getLayout_test_2971() {
    Container instance = new Container();
    instance.getLayout();
  }

  @Test
  public void setComponentZOrder_test_2972(Component p0, int p1) {
    Container instance = new Container();
    instance.setComponentZOrder(p0, p1);
  }

  @Test
  public void setLayout_test_2973(LayoutManager p0) {
    Container instance = new Container();
    instance.setLayout(p0);
  }

  @Test
  public void paintComponents_test_2974(Graphics p0) {
    Container instance = new Container();
    instance.paintComponents(p0);
  }

  @Test
  public void printComponents_test_2975(Graphics p0) {
    Container instance = new Container();
    instance.printComponents(p0);
  }

  @Test
  public void removeContainerListener_test_2976(ContainerListener p0) {
    Container instance = new Container();
    instance.removeContainerListener(p0);
  }

  @Test
  public void getContainerListeners_test_2977() {
    Container instance = new Container();
    instance.getContainerListeners();
  }

  @Test
  public void getMousePosition_test_2978(boolean p0) {
    Container instance = new Container();
    instance.getMousePosition(p0);
  }

  @Test
  public void isAncestorOf_test_2979(Component p0) {
    Container instance = new Container();
    instance.isAncestorOf(p0);
  }

  @Test
  public void getFocusTraversalKeys_test_2980(int p0) {
    Container instance = new Container();
    instance.getFocusTraversalKeys(p0);
  }

  @Test
  public void areFocusTraversalKeysSet_test_2981(int p0) {
    Container instance = new Container();
    instance.areFocusTraversalKeysSet(p0);
  }

  @Test
  public void isFocusTraversalPolicySet_test_2982() {
    Container instance = new Container();
    instance.isFocusTraversalPolicySet();
  }

  @Test
  public void setFocusCycleRoot_test_2983(boolean p0) {
    Container instance = new Container();
    instance.setFocusCycleRoot(p0);
  }

  @Test
  public void setFocusTraversalPolicyProvider_test_2984(boolean p0) {
    Container instance = new Container();
    instance.setFocusTraversalPolicyProvider(p0);
  }

  @Test
  public void transferFocusDownCycle_test_2985() {
    Container instance = new Container();
    instance.transferFocusDownCycle();
  }

  @Test
  public void remove_test_2986(int p0) {
    Container instance = new Container();
    instance.remove(p0);
  }

  @Test
  public void remove_test_2987(Component p0) {
    Container instance = new Container();
    instance.remove(p0);
  }

  @Test
  public void update_test_2988(Graphics p0) {
    Container instance = new Container();
    instance.update(p0);
  }

  @Test
  public void add_test_2989(Component p0) {
    Container instance = new Container();
    instance.add(p0);
  }

  @Test
  public void add_test_2990(String p0, Component p1) {
    Container instance = new Container();
    instance.add(p0, p1);
  }

  @Test
  public void add_test_2991(Component p0, Object p1) {
    Container instance = new Container();
    instance.add(p0, p1);
  }

  @Test
  public void add_test_2992(Component p0, Object p1, int p2) {
    Container instance = new Container();
    instance.add(p0, p1, p2);
  }

  @Test
  public void add_test_2993(Component p0, int p1) {
    Container instance = new Container();
    instance.add(p0, p1);
  }

  @Test
  public void list_test_2994(PrintWriter p0, int p1) {
    Container instance = new Container();
    instance.list(p0, p1);
  }

  @Test
  public void list_test_2995(PrintStream p0, int p1) {
    Container instance = new Container();
    instance.list(p0, p1);
  }

  @Test
  public void validate_test_2996() {
    Container instance = new Container();
    instance.validate();
  }

  @Test
  public void print_test_2997(Graphics p0) {
    Container instance = new Container();
    instance.print(p0);
  }

  @Test
  public void removeAll_test_2998() {
    Container instance = new Container();
    instance.removeAll();
  }

  @Test
  public void getComponent_test_2999(int p0) {
    Container instance = new Container();
    instance.getComponent(p0);
  }

  @Test
  public void invalidate_test_3000() {
    Container instance = new Container();
    instance.invalidate();
  }
}
