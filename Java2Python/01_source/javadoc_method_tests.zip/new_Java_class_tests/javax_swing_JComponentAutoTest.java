package generated.test;

import java.awt.Component;
import java.util.Locale;
import javax.swing.JComponent;
import org.junit.jupiter.api.Test;

public class javax_swing_JComponentAutoTest {
  @Test
  public void getDefaultLocale_test_6106() {
    JComponent.getDefaultLocale();
  }

  @Test
  public void isLightweightComponent_test_6107(Component p0) {
    JComponent.isLightweightComponent(p0);
  }

  @Test
  public void setDefaultLocale_test_6108(Locale p0) {
    JComponent.setDefaultLocale(p0);
  }
}
