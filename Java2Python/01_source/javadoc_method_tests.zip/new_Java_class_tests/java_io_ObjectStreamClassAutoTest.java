package generated.test;

import java.io.ObjectStreamClass;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_io_ObjectStreamClassAutoTest {
  @Test
  public void lookup_test_9614(Class p0) {
    ObjectStreamClass.lookup(p0);
  }

  @Test
  public void lookupAny_test_9615(Class p0) {
    ObjectStreamClass.lookupAny(p0);
  }
}
