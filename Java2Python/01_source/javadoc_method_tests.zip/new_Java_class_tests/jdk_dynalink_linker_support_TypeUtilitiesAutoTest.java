package generated.test;

import java.lang.Class;
import java.lang.String;
import jdk.dynalink.linker.support.TypeUtilities;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_TypeUtilitiesAutoTest {
  @Test
  public void isWrapperType_test_13103(Class p0) {
    TypeUtilities.isWrapperType(p0);
  }

  @Test
  public void getPrimitiveType_test_13104(Class p0) {
    TypeUtilities.getPrimitiveType(p0);
  }

  @Test
  public void isSubtype_test_13105(Class p0, Class p1) {
    TypeUtilities.isSubtype(p0, p1);
  }

  @Test
  public void getWrapperType_test_13106(Class p0) {
    TypeUtilities.getWrapperType(p0);
  }

  @Test
  public void isConvertibleWithoutLoss_test_13107(Class p0, Class p1) {
    TypeUtilities.isConvertibleWithoutLoss(p0, p1);
  }

  @Test
  public void isMethodInvocationConvertible_test_13108(Class p0, Class p1) {
    TypeUtilities.isMethodInvocationConvertible(p0, p1);
  }

  @Test
  public void getPrimitiveTypeByName_test_13109(String p0) {
    TypeUtilities.getPrimitiveTypeByName(p0);
  }
}
