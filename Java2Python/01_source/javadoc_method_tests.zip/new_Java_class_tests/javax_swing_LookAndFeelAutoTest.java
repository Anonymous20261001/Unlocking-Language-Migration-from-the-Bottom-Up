package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.String;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.LookAndFeel;
import org.junit.jupiter.api.Test;

public class javax_swing_LookAndFeelAutoTest {
  @Test
  public void makeIcon_test_8226(Class p0, String p1) {
    LookAndFeel.makeIcon(p0, p1);
  }

  @Test
  public void makeComponentInputMap_test_8227(JComponent p0, Object[] p1) {
    LookAndFeel.makeComponentInputMap(p0, p1);
  }

  @Test
  public void installProperty_test_8228(JComponent p0, String p1, Object p2) {
    LookAndFeel.installProperty(p0, p1, p2);
  }

  @Test
  public void installColors_test_8229(JComponent p0, String p1, String p2) {
    LookAndFeel.installColors(p0, p1, p2);
  }

  @Test
  public void loadKeyBindings_test_8230(InputMap p0, Object[] p1) {
    LookAndFeel.loadKeyBindings(p0, p1);
  }

  @Test
  public void makeKeyBindings_test_8231(Object[] p0) {
    LookAndFeel.makeKeyBindings(p0);
  }

  @Test
  public void makeInputMap_test_8232(Object[] p0) {
    LookAndFeel.makeInputMap(p0);
  }

  @Test
  public void getDesktopPropertyValue_test_8233(String p0, Object p1) {
    LookAndFeel.getDesktopPropertyValue(p0, p1);
  }

  @Test
  public void installColorsAndFont_test_8234(JComponent p0, String p1, String p2, String p3) {
    LookAndFeel.installColorsAndFont(p0, p1, p2, p3);
  }

  @Test
  public void installBorder_test_8235(JComponent p0, String p1) {
    LookAndFeel.installBorder(p0, p1);
  }

  @Test
  public void uninstallBorder_test_8236(JComponent p0) {
    LookAndFeel.uninstallBorder(p0);
  }
}
