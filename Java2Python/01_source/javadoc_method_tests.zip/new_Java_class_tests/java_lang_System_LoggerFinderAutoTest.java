package generated.test;

import java.lang.System;
import org.junit.jupiter.api.Test;

public class java_lang_System_LoggerFinderAutoTest {
  @Test
  public void getLoggerFinder_test_12437() {
    System.LoggerFinder.getLoggerFinder();
  }
}
