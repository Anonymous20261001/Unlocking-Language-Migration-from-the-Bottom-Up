package generated.test;

import java.lang.Boolean;
import java.lang.Integer;
import java.lang.Object;
import java.lang.String;
import java.util.Date;
import javax.management.timer.Timer;
import org.junit.jupiter.api.Test;

public class javax_management_timer_TimerAutoTest {
  @Test
  public void getNotificationInfo_test_12841() {
    Timer instance = new Timer();
    instance.getNotificationInfo();
  }

  @Test
  public void postRegister_test_12842(Boolean p0) {
    Timer instance = new Timer();
    instance.postRegister(p0);
  }

  @Test
  public void postDeregister_test_12843() {
    Timer instance = new Timer();
    instance.postDeregister();
  }

  @Test
  public void getPeriod_test_12844(Integer p0) {
    Timer instance = new Timer();
    instance.getPeriod(p0);
  }

  @Test
  public void addNotification_test_12845(String p0, String p1, Object p2, Date p3) {
    Timer instance = new Timer();
    instance.addNotification(p0, p1, p2, p3);
  }

  @Test
  public void addNotification_test_12846(String p0, String p1, Object p2, Date p3, long p4) {
    Timer instance = new Timer();
    instance.addNotification(p0, p1, p2, p3, p4);
  }

  @Test
  public void addNotification_test_12847(String p0, String p1, Object p2, Date p3, long p4,
      long p5) {
    Timer instance = new Timer();
    instance.addNotification(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void addNotification_test_12848(String p0, String p1, Object p2, Date p3, long p4, long p5,
      boolean p6) {
    Timer instance = new Timer();
    instance.addNotification(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getNotificationIDs_test_12849(String p0) {
    Timer instance = new Timer();
    instance.getNotificationIDs(p0);
  }

  @Test
  public void removeAllNotifications_test_12850() {
    Timer instance = new Timer();
    instance.removeAllNotifications();
  }

  @Test
  public void getNbNotifications_test_12851() {
    Timer instance = new Timer();
    instance.getNbNotifications();
  }

  @Test
  public void getAllNotificationIDs_test_12852() {
    Timer instance = new Timer();
    instance.getAllNotificationIDs();
  }

  @Test
  public void getNotificationType_test_12853(Integer p0) {
    Timer instance = new Timer();
    instance.getNotificationType(p0);
  }

  @Test
  public void getNotificationMessage_test_12854(Integer p0) {
    Timer instance = new Timer();
    instance.getNotificationMessage(p0);
  }

  @Test
  public void getNotificationUserData_test_12855(Integer p0) {
    Timer instance = new Timer();
    instance.getNotificationUserData(p0);
  }

  @Test
  public void getNbOccurences_test_12856(Integer p0) {
    Timer instance = new Timer();
    instance.getNbOccurences(p0);
  }

  @Test
  public void getFixedRate_test_12857(Integer p0) {
    Timer instance = new Timer();
    instance.getFixedRate(p0);
  }

  @Test
  public void getSendPastNotifications_test_12858() {
    Timer instance = new Timer();
    instance.getSendPastNotifications();
  }

  @Test
  public void setSendPastNotifications_test_12859(boolean p0) {
    Timer instance = new Timer();
    instance.setSendPastNotifications(p0);
  }

  @Test
  public void isEmpty_test_12860() {
    Timer instance = new Timer();
    instance.isEmpty();
  }

  @Test
  public void start_test_12861() {
    Timer instance = new Timer();
    instance.start();
  }

  @Test
  public void stop_test_12862() {
    Timer instance = new Timer();
    instance.stop();
  }

  @Test
  public void isActive_test_12863() {
    Timer instance = new Timer();
    instance.isActive();
  }

  @Test
  public void getDate_test_12864(Integer p0) {
    Timer instance = new Timer();
    instance.getDate(p0);
  }
}
