package generated.test;

import java.lang.String;
import java.util.regex.Matcher;
import org.junit.jupiter.api.Test;

public class java_util_regex_MatcherAutoTest {
  @Test
  public void quoteReplacement_test_8295(String p0) {
    Matcher.quoteReplacement(p0);
  }
}
