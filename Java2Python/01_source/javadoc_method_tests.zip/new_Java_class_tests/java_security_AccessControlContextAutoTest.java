package generated.test;

import java.security.AccessControlContext;
import java.security.Permission;
import java.security.ProtectionDomain;
import org.junit.jupiter.api.Test;

public class java_security_AccessControlContextAutoTest {
  @Test
  public void getDomainCombiner_test_25(ProtectionDomain[] c0) {
    AccessControlContext instance = new AccessControlContext(c0);
    instance.getDomainCombiner();
  }

  @Test
  public void checkPermission_test_26(Permission p0, ProtectionDomain[] c0) {
    AccessControlContext instance = new AccessControlContext(c0);
    instance.checkPermission(p0);
  }
}
