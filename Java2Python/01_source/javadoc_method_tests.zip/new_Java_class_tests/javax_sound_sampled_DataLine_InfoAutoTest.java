package generated.test;

import java.lang.Class;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import org.junit.jupiter.api.Test;

public class javax_sound_sampled_DataLine_InfoAutoTest {
  @Test
  public void getMaxBufferSize_test_3269(Class c0, AudioFormat c1) {
    DataLine.Info instance = new DataLine.Info(c0, c1);
    instance.getMaxBufferSize();
  }

  @Test
  public void getMinBufferSize_test_3270(Class c0, AudioFormat c1) {
    DataLine.Info instance = new DataLine.Info(c0, c1);
    instance.getMinBufferSize();
  }

  @Test
  public void isFormatSupported_test_3271(AudioFormat p0, Class c0, AudioFormat c1) {
    DataLine.Info instance = new DataLine.Info(c0, c1);
    instance.isFormatSupported(p0);
  }

  @Test
  public void matches_test_3272(Line.Info p0, Class c0, AudioFormat c1) {
    DataLine.Info instance = new DataLine.Info(c0, c1);
    instance.matches(p0);
  }

  @Test
  public void getFormats_test_3273(Class c0, AudioFormat c1) {
    DataLine.Info instance = new DataLine.Info(c0, c1);
    instance.getFormats();
  }
}
