package generated.test;

import java.awt.event.MouseEvent;
import javax.swing.text.html.HTMLEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_HTMLEditorKit_LinkControllerAutoTest {
  @Test
  public void mouseClicked_test_5398(MouseEvent p0) {
    HTMLEditorKit.LinkController instance = new HTMLEditorKit.LinkController();
    instance.mouseClicked(p0);
  }

  @Test
  public void mouseMoved_test_5399(MouseEvent p0) {
    HTMLEditorKit.LinkController instance = new HTMLEditorKit.LinkController();
    instance.mouseMoved(p0);
  }

  @Test
  public void mouseDragged_test_5400(MouseEvent p0) {
    HTMLEditorKit.LinkController instance = new HTMLEditorKit.LinkController();
    instance.mouseDragged(p0);
  }
}
