package generated.test;

import javax.management.relation.RoleInfo;
import org.junit.jupiter.api.Test;

public class javax_management_relation_RoleInfoAutoTest {
  @Test
  public void getDescription_test_10645(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.getDescription();
  }

  @Test
  public void getMinDegree_test_10646(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.getMinDegree();
  }

  @Test
  public void getMaxDegree_test_10647(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.getMaxDegree();
  }

  @Test
  public void checkMinDegree_test_10648(int p0, RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.checkMinDegree(p0);
  }

  @Test
  public void checkMaxDegree_test_10649(int p0, RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.checkMaxDegree(p0);
  }

  @Test
  public void getRefMBeanClassName_test_10650(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.getRefMBeanClassName();
  }

  @Test
  public void getName_test_10651(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.getName();
  }

  @Test
  public void isWritable_test_10652(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.isWritable();
  }

  @Test
  public void isReadable_test_10653(RoleInfo c0) {
    RoleInfo instance = new RoleInfo(c0);
    instance.isReadable();
  }
}
