package generated.test;

import java.io.File;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.kerberos.KeyTab;
import org.junit.jupiter.api.Test;

public class javax_security_auth_kerberos_KeyTabAutoTest {
  @Test
  public void getInstance_test_7662(KerberosPrincipal p0) {
    KeyTab.getInstance(p0);
  }

  @Test
  public void getInstance_test_7663(File p0) {
    KeyTab.getInstance(p0);
  }

  @Test
  public void getInstance_test_7664() {
    KeyTab.getInstance();
  }

  @Test
  public void getInstance_test_7665(KerberosPrincipal p0, File p1) {
    KeyTab.getInstance(p0, p1);
  }

  @Test
  public void getUnboundInstance_test_7666() {
    KeyTab.getUnboundInstance();
  }

  @Test
  public void getUnboundInstance_test_7667(File p0) {
    KeyTab.getUnboundInstance(p0);
  }
}
