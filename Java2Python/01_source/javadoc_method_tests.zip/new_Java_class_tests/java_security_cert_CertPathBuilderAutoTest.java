package generated.test;

import java.security.cert.CertPathBuilder;
import org.junit.jupiter.api.Test;

public class java_security_cert_CertPathBuilderAutoTest {
  @Test
  public void getDefaultType_test_2099() {
    CertPathBuilder.getDefaultType();
  }
}
