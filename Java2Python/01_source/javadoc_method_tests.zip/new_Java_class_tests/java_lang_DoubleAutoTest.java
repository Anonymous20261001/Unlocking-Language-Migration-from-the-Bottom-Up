package generated.test;

import java.lang.Double;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class java_lang_DoubleAutoTest {
  @Test
  public void min_test_4224(double p0, double p1) {
    Double.min(p0, p1);
  }

  @Test
  public void max_test_4225(double p0, double p1) {
    Double.max(p0, p1);
  }

  @Test
  public void isInfinite_test_4226(double c0) {
    Double instance = new Double(c0);
    instance.isInfinite();
  }

  @Test
  public void isInfinite_test_4227(double p0) {
    Double.isInfinite(p0);
  }

  @Test
  public void isFinite_test_4228(double p0) {
    Double.isFinite(p0);
  }

  @Test
  public void doubleToRawLongBits_test_4229(double p0) {
    Double.doubleToRawLongBits(p0);
  }

  @Test
  public void doubleToLongBits_test_4230(double p0) {
    Double.doubleToLongBits(p0);
  }

  @Test
  public void longBitsToDouble_test_4231(long p0) {
    Double.longBitsToDouble(p0);
  }

  @Test
  public void compareTo_test_4232(Double p0, double c0) {
    Double instance = new Double(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_4233(double p0, double p1) {
    Double.compare(p0, p1);
  }

  @Test
  public void byteValue_test_4234(double c0) {
    Double instance = new Double(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_4235(double c0) {
    Double instance = new Double(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_4236(double c0) {
    Double instance = new Double(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_4237(double c0) {
    Double instance = new Double(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_4238(double c0) {
    Double instance = new Double(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_4239(double c0) {
    Double instance = new Double(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_4240(String p0) {
    Double.valueOf(p0);
  }

  @Test
  public void valueOf_test_4241(double p0) {
    Double.valueOf(p0);
  }

  @Test
  public void toHexString_test_4242(double p0) {
    Double.toHexString(p0);
  }

  @Test
  public void resolveConstantDesc_test_4243(MethodHandles.Lookup p0, double c0) {
    Double instance = new Double(c0);
    instance.resolveConstantDesc(p0);
  }

  @Test
  public void describeConstable_test_4244(double c0) {
    Double instance = new Double(c0);
    instance.describeConstable();
  }

  @Test
  public void isNaN_test_4245(double c0) {
    Double instance = new Double(c0);
    instance.isNaN();
  }

  @Test
  public void isNaN_test_4246(double p0) {
    Double.isNaN(p0);
  }

  @Test
  public void sum_test_4247(double p0, double p1) {
    Double.sum(p0, p1);
  }

  @Test
  public void parseDouble_test_4248(String p0) {
    Double.parseDouble(p0);
  }
}
