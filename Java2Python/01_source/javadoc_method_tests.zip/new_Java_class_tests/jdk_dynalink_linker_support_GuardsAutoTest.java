package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import jdk.dynalink.linker.LinkerServices;
import jdk.dynalink.linker.support.Guards;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_GuardsAutoTest {
  @Test
  public void isInstance_test_5248(Class p0, MethodType p1) {
    Guards.isInstance(p0, p1);
  }

  @Test
  public void isInstance_test_5249(Class p0, int p1, MethodType p2) {
    Guards.isInstance(p0, p1, p2);
  }

  @Test
  public void isArray_test_5250(int p0, MethodType p1) {
    Guards.isArray(p0, p1);
  }

  @Test
  public void asType_test_5251(LinkerServices p0, MethodHandle p1, MethodType p2) {
    Guards.asType(p0, p1, p2);
  }

  @Test
  public void asType_test_5252(MethodHandle p0, MethodType p1) {
    Guards.asType(p0, p1);
  }

  @Test
  public void isNull_test_5253() {
    Guards.isNull();
  }

  @Test
  public void isOfClass_test_5254(Class p0, MethodType p1) {
    Guards.isOfClass(p0, p1);
  }

  @Test
  public void isNotNull_test_5255() {
    Guards.isNotNull();
  }

  @Test
  public void getClassGuard_test_5256(Class p0) {
    Guards.getClassGuard(p0);
  }

  @Test
  public void getInstanceOfGuard_test_5257(Class p0) {
    Guards.getInstanceOfGuard(p0);
  }

  @Test
  public void getIdentityGuard_test_5258(Object p0) {
    Guards.getIdentityGuard(p0);
  }
}
