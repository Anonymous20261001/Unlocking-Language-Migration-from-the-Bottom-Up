package generated.test;

import javax.swing.text.AttributeSet;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Element;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultStyledDocument_AttributeUndoableEditAutoTest {
  @Test
  public void redo_test_3876(Element c0, AttributeSet c1, boolean c2) {
    DefaultStyledDocument.AttributeUndoableEdit instance = new DefaultStyledDocument.AttributeUndoableEdit(c0, c1, c2);
    instance.redo();
  }

  @Test
  public void undo_test_3877(Element c0, AttributeSet c1, boolean c2) {
    DefaultStyledDocument.AttributeUndoableEdit instance = new DefaultStyledDocument.AttributeUndoableEdit(c0, c1, c2);
    instance.undo();
  }
}
