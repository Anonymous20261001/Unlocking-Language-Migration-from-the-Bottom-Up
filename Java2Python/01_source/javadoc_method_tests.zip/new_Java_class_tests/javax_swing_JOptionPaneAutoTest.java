package generated.test;

import java.awt.Component;
import java.awt.Frame;
import java.lang.Object;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.plaf.OptionPaneUI;
import org.junit.jupiter.api.Test;

public class javax_swing_JOptionPaneAutoTest {
  @Test
  public void getUIClassID_test_6663() {
    JOptionPane instance = new JOptionPane();
    instance.getUIClassID();
  }

  @Test
  public void updateUI_test_6664() {
    JOptionPane instance = new JOptionPane();
    instance.updateUI();
  }

  @Test
  public void getUI_test_6665() {
    JOptionPane instance = new JOptionPane();
    instance.getUI();
  }

  @Test
  public void setUI_test_6666(OptionPaneUI p0) {
    JOptionPane instance = new JOptionPane();
    instance.setUI(p0);
  }

  @Test
  public void getAccessibleContext_test_6667() {
    JOptionPane instance = new JOptionPane();
    instance.getAccessibleContext();
  }

  @Test
  public void getIcon_test_6668() {
    JOptionPane instance = new JOptionPane();
    instance.getIcon();
  }

  @Test
  public void setIcon_test_6669(Icon p0) {
    JOptionPane instance = new JOptionPane();
    instance.setIcon(p0);
  }

  @Test
  public void createDialog_test_6670(Component p0, String p1) {
    JOptionPane instance = new JOptionPane();
    instance.createDialog(p0, p1);
  }

  @Test
  public void createDialog_test_6671(String p0) {
    JOptionPane instance = new JOptionPane();
    instance.createDialog(p0);
  }

  @Test
  public void getMaxCharactersPerLineCount_test_6672() {
    JOptionPane instance = new JOptionPane();
    instance.getMaxCharactersPerLineCount();
  }

  @Test
  public void getWantsInput_test_6673() {
    JOptionPane instance = new JOptionPane();
    instance.getWantsInput();
  }

  @Test
  public void getSelectionValues_test_6674() {
    JOptionPane instance = new JOptionPane();
    instance.getSelectionValues();
  }

  @Test
  public void getInitialSelectionValue_test_6675() {
    JOptionPane instance = new JOptionPane();
    instance.getInitialSelectionValue();
  }

  @Test
  public void getMessageType_test_6676() {
    JOptionPane instance = new JOptionPane();
    instance.getMessageType();
  }

  @Test
  public void getOptionType_test_6677() {
    JOptionPane instance = new JOptionPane();
    instance.getOptionType();
  }

  @Test
  public void getInitialValue_test_6678() {
    JOptionPane instance = new JOptionPane();
    instance.getInitialValue();
  }

  @Test
  public void setInputValue_test_6679(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInputValue(p0);
  }

  @Test
  public void selectInitialValue_test_6680() {
    JOptionPane instance = new JOptionPane();
    instance.selectInitialValue();
  }

  @Test
  public void showInputDialog_test_6681(Object p0) {
    JOptionPane.showInputDialog(p0);
  }

  @Test
  public void showInputDialog_test_6682(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showInputDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInputDialog_test_6683(Component p0, Object p1, String p2, int p3, Icon p4,
      Object[] p5, Object p6) {
    JOptionPane.showInputDialog(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void showInputDialog_test_6684(Component p0, Object p1) {
    JOptionPane.showInputDialog(p0, p1);
  }

  @Test
  public void showInputDialog_test_6685(Object p0, Object p1) {
    JOptionPane.showInputDialog(p0, p1);
  }

  @Test
  public void showInputDialog_test_6686(Component p0, Object p1, Object p2) {
    JOptionPane.showInputDialog(p0, p1, p2);
  }

  @Test
  public void setWantsInput_test_6687(boolean p0) {
    JOptionPane instance = new JOptionPane();
    instance.setWantsInput(p0);
  }

  @Test
  public void setSelectionValues_test_6688(Object[] p0) {
    JOptionPane instance = new JOptionPane();
    instance.setSelectionValues(p0);
  }

  @Test
  public void setInitialSelectionValue_test_6689(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInitialSelectionValue(p0);
  }

  @Test
  public void getRootFrame_test_6690() {
    JOptionPane.getRootFrame();
  }

  @Test
  public void getInputValue_test_6691() {
    JOptionPane instance = new JOptionPane();
    instance.getInputValue();
  }

  @Test
  public void showMessageDialog_test_6692(Component p0, Object p1, String p2, int p3, Icon p4) {
    JOptionPane.showMessageDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showMessageDialog_test_6693(Component p0, Object p1) {
    JOptionPane.showMessageDialog(p0, p1);
  }

  @Test
  public void showMessageDialog_test_6694(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showMessageDialog(p0, p1, p2, p3);
  }

  @Test
  public void showOptionDialog_test_6695(Component p0, Object p1, String p2, int p3, int p4,
      Icon p5, Object[] p6, Object p7) {
    JOptionPane.showOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void showConfirmDialog_test_6696(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showConfirmDialog(p0, p1, p2, p3);
  }

  @Test
  public void showConfirmDialog_test_6697(Component p0, Object p1) {
    JOptionPane.showConfirmDialog(p0, p1);
  }

  @Test
  public void showConfirmDialog_test_6698(Component p0, Object p1, String p2, int p3, int p4,
      Icon p5) {
    JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void showConfirmDialog_test_6699(Component p0, Object p1, String p2, int p3, int p4) {
    JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showInternalMessageDialog_test_6700(Component p0, Object p1, String p2, int p3,
      Icon p4) {
    JOptionPane.showInternalMessageDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showInternalMessageDialog_test_6701(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showInternalMessageDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInternalMessageDialog_test_6702(Component p0, Object p1) {
    JOptionPane.showInternalMessageDialog(p0, p1);
  }

  @Test
  public void showInternalOptionDialog_test_6703(Component p0, Object p1, String p2, int p3, int p4,
      Icon p5, Object[] p6, Object p7) {
    JOptionPane.showInternalOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void showInternalConfirmDialog_test_6704(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInternalConfirmDialog_test_6705(Component p0, Object p1, String p2, int p3,
      int p4, Icon p5) {
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void showInternalConfirmDialog_test_6706(Component p0, Object p1, String p2, int p3,
      int p4) {
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showInternalConfirmDialog_test_6707(Component p0, Object p1) {
    JOptionPane.showInternalConfirmDialog(p0, p1);
  }

  @Test
  public void createInternalFrame_test_6708(Component p0, String p1) {
    JOptionPane instance = new JOptionPane();
    instance.createInternalFrame(p0, p1);
  }

  @Test
  public void showInternalInputDialog_test_6709(Component p0, Object p1) {
    JOptionPane.showInternalInputDialog(p0, p1);
  }

  @Test
  public void showInternalInputDialog_test_6710(Component p0, Object p1, String p2, int p3) {
    JOptionPane.showInternalInputDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInternalInputDialog_test_6711(Component p0, Object p1, String p2, int p3, Icon p4,
      Object[] p5, Object p6) {
    JOptionPane.showInternalInputDialog(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getDesktopPaneForComponent_test_6712(Component p0) {
    JOptionPane.getDesktopPaneForComponent(p0);
  }

  @Test
  public void getFrameForComponent_test_6713(Component p0) {
    JOptionPane.getFrameForComponent(p0);
  }

  @Test
  public void setMessageType_test_6714(int p0) {
    JOptionPane instance = new JOptionPane();
    instance.setMessageType(p0);
  }

  @Test
  public void setOptionType_test_6715(int p0) {
    JOptionPane instance = new JOptionPane();
    instance.setOptionType(p0);
  }

  @Test
  public void setRootFrame_test_6716(Frame p0) {
    JOptionPane.setRootFrame(p0);
  }

  @Test
  public void setMessage_test_6717(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setMessage(p0);
  }

  @Test
  public void setOptions_test_6718(Object[] p0) {
    JOptionPane instance = new JOptionPane();
    instance.setOptions(p0);
  }

  @Test
  public void getValue_test_6719() {
    JOptionPane instance = new JOptionPane();
    instance.getValue();
  }

  @Test
  public void getMessage_test_6720() {
    JOptionPane instance = new JOptionPane();
    instance.getMessage();
  }

  @Test
  public void setValue_test_6721(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setValue(p0);
  }

  @Test
  public void setInitialValue_test_6722(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInitialValue(p0);
  }

  @Test
  public void getOptions_test_6723() {
    JOptionPane instance = new JOptionPane();
    instance.getOptions();
  }
}
