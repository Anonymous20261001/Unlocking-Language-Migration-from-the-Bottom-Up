package generated.test;

import java.time.format.DecimalStyle;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_time_format_DecimalStyleAutoTest {
  @Test
  public void of_test_3542(Locale p0) {
    DecimalStyle.of(p0);
  }

  @Test
  public void getAvailableLocales_test_3543() {
    DecimalStyle.getAvailableLocales();
  }

  @Test
  public void ofDefaultLocale_test_3544() {
    DecimalStyle.ofDefaultLocale();
  }
}
