package generated.test;

import java.security.KeyStore;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_PasswordProtectionAutoTest {
  @Test
  public void getProtectionAlgorithm_test_7642(char[] c0) {
    KeyStore.PasswordProtection instance = new KeyStore.PasswordProtection(c0);
    instance.getProtectionAlgorithm();
  }

  @Test
  public void getProtectionParameters_test_7643(char[] c0) {
    KeyStore.PasswordProtection instance = new KeyStore.PasswordProtection(c0);
    instance.getProtectionParameters();
  }

  @Test
  public void getPassword_test_7644(char[] c0) {
    KeyStore.PasswordProtection instance = new KeyStore.PasswordProtection(c0);
    instance.getPassword();
  }

  @Test
  public void isDestroyed_test_7645(char[] c0) {
    KeyStore.PasswordProtection instance = new KeyStore.PasswordProtection(c0);
    instance.isDestroyed();
  }
}
