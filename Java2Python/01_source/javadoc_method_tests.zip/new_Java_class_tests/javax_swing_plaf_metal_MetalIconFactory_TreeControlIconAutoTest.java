package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_TreeControlIconAutoTest {
  @Test
  public void paintMe_test_8731(Component p0, Graphics p1, int p2, int p3, boolean c0) {
    MetalIconFactory.TreeControlIcon instance = new MetalIconFactory.TreeControlIcon(c0);
    instance.paintMe(p0, p1, p2, p3);
  }

  @Test
  public void getIconWidth_test_8732(boolean c0) {
    MetalIconFactory.TreeControlIcon instance = new MetalIconFactory.TreeControlIcon(c0);
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_8733(boolean c0) {
    MetalIconFactory.TreeControlIcon instance = new MetalIconFactory.TreeControlIcon(c0);
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_8734(Component p0, Graphics p1, int p2, int p3, boolean c0) {
    MetalIconFactory.TreeControlIcon instance = new MetalIconFactory.TreeControlIcon(c0);
    instance.paintIcon(p0, p1, p2, p3);
  }
}
