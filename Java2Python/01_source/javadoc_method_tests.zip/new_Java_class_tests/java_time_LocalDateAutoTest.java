package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_LocalDateAutoTest {
  @Test
  public void of_test_7988(int p0, int p1, int p2) {
    LocalDate.of(p0, p1, p2);
  }

  @Test
  public void of_test_7989(int p0, Month p1, int p2) {
    LocalDate.of(p0, p1, p2);
  }

  @Test
  public void from_test_7990(TemporalAccessor p0) {
    LocalDate.from(p0);
  }

  @Test
  public void parse_test_7991(CharSequence p0) {
    LocalDate.parse(p0);
  }

  @Test
  public void parse_test_7992(CharSequence p0, DateTimeFormatter p1) {
    LocalDate.parse(p0, p1);
  }

  @Test
  public void now_test_7993() {
    LocalDate.now();
  }

  @Test
  public void now_test_7994(Clock p0) {
    LocalDate.now(p0);
  }

  @Test
  public void now_test_7995(ZoneId p0) {
    LocalDate.now(p0);
  }

  @Test
  public void ofInstant_test_7996(Instant p0, ZoneId p1) {
    LocalDate.ofInstant(p0, p1);
  }

  @Test
  public void ofEpochDay_test_7997(long p0) {
    LocalDate.ofEpochDay(p0);
  }

  @Test
  public void ofYearDay_test_7998(int p0, int p1) {
    LocalDate.ofYearDay(p0, p1);
  }
}
