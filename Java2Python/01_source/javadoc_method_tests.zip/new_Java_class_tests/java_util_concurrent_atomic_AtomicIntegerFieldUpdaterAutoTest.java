package generated.test;

import java.lang.Class;
import java.lang.String;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_atomic_AtomicIntegerFieldUpdaterAutoTest {
  @Test
  public void newUpdater_test_627(Class p0, String p1) {
    AtomicIntegerFieldUpdater.newUpdater(p0, p1);
  }
}
