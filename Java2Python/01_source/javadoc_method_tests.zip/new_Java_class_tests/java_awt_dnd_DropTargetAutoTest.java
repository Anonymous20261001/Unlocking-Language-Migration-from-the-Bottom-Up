package generated.test;

import java.awt.Component;
import java.awt.datatransfer.FlavorMap;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DropTargetAutoTest {
  @Test
  public void drop_test_4351(DropTargetDropEvent p0) {
    DropTarget instance = new DropTarget();
    instance.drop(p0);
  }

  @Test
  public void setComponent_test_4352(Component p0) {
    DropTarget instance = new DropTarget();
    instance.setComponent(p0);
  }

  @Test
  public void addNotify_test_4353() {
    DropTarget instance = new DropTarget();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_4354() {
    DropTarget instance = new DropTarget();
    instance.removeNotify();
  }

  @Test
  public void setActive_test_4355(boolean p0) {
    DropTarget instance = new DropTarget();
    instance.setActive(p0);
  }

  @Test
  public void setDefaultActions_test_4356(int p0) {
    DropTarget instance = new DropTarget();
    instance.setDefaultActions(p0);
  }

  @Test
  public void getDropTargetContext_test_4357() {
    DropTarget instance = new DropTarget();
    instance.getDropTargetContext();
  }

  @Test
  public void dragEnter_test_4358(DropTargetDragEvent p0) {
    DropTarget instance = new DropTarget();
    instance.dragEnter(p0);
  }

  @Test
  public void dragOver_test_4359(DropTargetDragEvent p0) {
    DropTarget instance = new DropTarget();
    instance.dragOver(p0);
  }

  @Test
  public void dropActionChanged_test_4360(DropTargetDragEvent p0) {
    DropTarget instance = new DropTarget();
    instance.dropActionChanged(p0);
  }

  @Test
  public void dragExit_test_4361(DropTargetEvent p0) {
    DropTarget instance = new DropTarget();
    instance.dragExit(p0);
  }

  @Test
  public void getDefaultActions_test_4362() {
    DropTarget instance = new DropTarget();
    instance.getDefaultActions();
  }

  @Test
  public void removeDropTargetListener_test_4363(DropTargetListener p0) {
    DropTarget instance = new DropTarget();
    instance.removeDropTargetListener(p0);
  }

  @Test
  public void getFlavorMap_test_4364() {
    DropTarget instance = new DropTarget();
    instance.getFlavorMap();
  }

  @Test
  public void setFlavorMap_test_4365(FlavorMap p0) {
    DropTarget instance = new DropTarget();
    instance.setFlavorMap(p0);
  }

  @Test
  public void isActive_test_4366() {
    DropTarget instance = new DropTarget();
    instance.isActive();
  }

  @Test
  public void getComponent_test_4367() {
    DropTarget instance = new DropTarget();
    instance.getComponent();
  }
}
