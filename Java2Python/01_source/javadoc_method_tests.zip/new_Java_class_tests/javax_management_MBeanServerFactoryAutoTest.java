package generated.test;

import java.lang.String;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import org.junit.jupiter.api.Test;

public class javax_management_MBeanServerFactoryAutoTest {
  @Test
  public void createMBeanServer_test_8442() {
    MBeanServerFactory.createMBeanServer();
  }

  @Test
  public void createMBeanServer_test_8443(String p0) {
    MBeanServerFactory.createMBeanServer(p0);
  }

  @Test
  public void newMBeanServer_test_8444(String p0) {
    MBeanServerFactory.newMBeanServer(p0);
  }

  @Test
  public void newMBeanServer_test_8445() {
    MBeanServerFactory.newMBeanServer();
  }

  @Test
  public void releaseMBeanServer_test_8446(MBeanServer p0) {
    MBeanServerFactory.releaseMBeanServer(p0);
  }

  @Test
  public void findMBeanServer_test_8447(String p0) {
    MBeanServerFactory.findMBeanServer(p0);
  }

  @Test
  public void getClassLoaderRepository_test_8448(MBeanServer p0) {
    MBeanServerFactory.getClassLoaderRepository(p0);
  }
}
