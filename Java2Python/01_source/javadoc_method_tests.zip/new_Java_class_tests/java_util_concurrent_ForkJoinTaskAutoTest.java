package generated.test;

import java.lang.Object;
import java.lang.Runnable;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinTask;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ForkJoinTaskAutoTest {
  @Test
  public void adapt_test_5019(Runnable p0, Object p1) {
    ForkJoinTask.adapt(p0, p1);
  }

  @Test
  public void adapt_test_5020(Callable p0) {
    ForkJoinTask.adapt(p0);
  }

  @Test
  public void adapt_test_5021(Runnable p0) {
    ForkJoinTask.adapt(p0);
  }

  @Test
  public void getQueuedTaskCount_test_5022() {
    ForkJoinTask.getQueuedTaskCount();
  }

  @Test
  public void getPool_test_5023() {
    ForkJoinTask.getPool();
  }

  @Test
  public void invokeAll_test_5024(Collection p0) {
    ForkJoinTask.invokeAll(p0);
  }

  @Test
  public void invokeAll_test_5025(ForkJoinTask p0, ForkJoinTask p1) {
    ForkJoinTask.invokeAll(p0, p1);
  }

  @Test
  public void invokeAll_test_5026(ForkJoinTask[] p0) {
    ForkJoinTask.invokeAll(p0);
  }

  @Test
  public void getSurplusQueuedTaskCount_test_5027() {
    ForkJoinTask.getSurplusQueuedTaskCount();
  }

  @Test
  public void helpQuiesce_test_5028() {
    ForkJoinTask.helpQuiesce();
  }

  @Test
  public void inForkJoinPool_test_5029() {
    ForkJoinTask.inForkJoinPool();
  }

  @Test
  public void adaptInterruptible_test_5030(Runnable p0) {
    ForkJoinTask.adaptInterruptible(p0);
  }

  @Test
  public void adaptInterruptible_test_5031(Runnable p0, Object p1) {
    ForkJoinTask.adaptInterruptible(p0, p1);
  }

  @Test
  public void adaptInterruptible_test_5032(Callable p0) {
    ForkJoinTask.adaptInterruptible(p0);
  }
}
