package generated.test;

import javax.swing.Action;
import javax.swing.text.TextAction;
import org.junit.jupiter.api.Test;

public class javax_swing_text_TextActionAutoTest {
  @Test
  public void augmentList_test_12543(Action[] p0, Action[] p1) {
    TextAction.augmentList(p0, p1);
  }
}
