package generated.test;

import java.lang.Class;
import javax.management.JMX;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import org.junit.jupiter.api.Test;

public class javax_management_JMXAutoTest {
  @Test
  public void newMBeanProxy_test_6591(MBeanServerConnection p0, ObjectName p1, Class p2,
      boolean p3) {
    JMX.newMBeanProxy(p0, p1, p2, p3);
  }

  @Test
  public void newMBeanProxy_test_6592(MBeanServerConnection p0, ObjectName p1, Class p2) {
    JMX.newMBeanProxy(p0, p1, p2);
  }

  @Test
  public void newMXBeanProxy_test_6593(MBeanServerConnection p0, ObjectName p1, Class p2) {
    JMX.newMXBeanProxy(p0, p1, p2);
  }

  @Test
  public void newMXBeanProxy_test_6594(MBeanServerConnection p0, ObjectName p1, Class p2,
      boolean p3) {
    JMX.newMXBeanProxy(p0, p1, p2, p3);
  }

  @Test
  public void isMXBeanInterface_test_6595(Class p0) {
    JMX.isMXBeanInterface(p0);
  }
}
