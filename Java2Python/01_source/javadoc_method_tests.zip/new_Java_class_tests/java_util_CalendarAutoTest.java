package generated.test;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import org.junit.jupiter.api.Test;

public class java_util_CalendarAutoTest {
  @Test
  public void getInstance_test_2021() {
    Calendar.getInstance();
  }

  @Test
  public void getInstance_test_2022(Locale p0) {
    Calendar.getInstance(p0);
  }

  @Test
  public void getInstance_test_2023(TimeZone p0) {
    Calendar.getInstance(p0);
  }

  @Test
  public void getInstance_test_2024(TimeZone p0, Locale p1) {
    Calendar.getInstance(p0, p1);
  }

  @Test
  public void getAvailableLocales_test_2025() {
    Calendar.getAvailableLocales();
  }

  @Test
  public void getAvailableCalendarTypes_test_2026() {
    Calendar.getAvailableCalendarTypes();
  }
}
