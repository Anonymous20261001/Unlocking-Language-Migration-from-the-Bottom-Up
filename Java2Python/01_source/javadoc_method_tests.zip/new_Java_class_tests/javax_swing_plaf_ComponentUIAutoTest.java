package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_ComponentUIAutoTest {
  @Test
  public void createUI_test_2673(JComponent p0) {
    ComponentUI.createUI(p0);
  }
}
