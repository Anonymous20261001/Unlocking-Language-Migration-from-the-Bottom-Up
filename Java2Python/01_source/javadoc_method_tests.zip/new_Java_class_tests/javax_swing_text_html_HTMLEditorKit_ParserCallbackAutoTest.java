package generated.test;

import java.lang.String;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_HTMLEditorKit_ParserCallbackAutoTest {
  @Test
  public void handleEndOfLineString_test_5401(String p0) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleEndOfLineString(p0);
  }

  @Test
  public void handleStartTag_test_5402(HTML.Tag p0, MutableAttributeSet p1, int p2) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleStartTag(p0, p1, p2);
  }

  @Test
  public void handleComment_test_5403(char[] p0, int p1) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleComment(p0, p1);
  }

  @Test
  public void handleSimpleTag_test_5404(HTML.Tag p0, MutableAttributeSet p1, int p2) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleSimpleTag(p0, p1, p2);
  }

  @Test
  public void handleEndTag_test_5405(HTML.Tag p0, int p1) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleEndTag(p0, p1);
  }

  @Test
  public void handleText_test_5406(char[] p0, int p1) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleText(p0, p1);
  }

  @Test
  public void handleError_test_5407(String p0, int p1) {
    HTMLEditorKit.ParserCallback instance = new HTMLEditorKit.ParserCallback();
    instance.handleError(p0, p1);
  }
}
