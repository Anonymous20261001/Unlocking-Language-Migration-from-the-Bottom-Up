package generated.test;

import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_TreeLeafIconAutoTest {
  @Test
  public void getShift_test_8737() {
    MetalIconFactory.TreeLeafIcon instance = new MetalIconFactory.TreeLeafIcon();
    instance.getShift();
  }

  @Test
  public void getAdditionalHeight_test_8738() {
    MetalIconFactory.TreeLeafIcon instance = new MetalIconFactory.TreeLeafIcon();
    instance.getAdditionalHeight();
  }
}
