package generated.test;

import java.lang.CharSequence;
import java.nio.CharBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_CharBufferAutoTest {
  @Test
  public void wrap_test_2230(CharSequence p0, int p1, int p2) {
    CharBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void wrap_test_2231(char[] p0) {
    CharBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_2232(CharSequence p0) {
    CharBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_2233(char[] p0, int p1, int p2) {
    CharBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_2234(int p0) {
    CharBuffer.allocate(p0);
  }
}
