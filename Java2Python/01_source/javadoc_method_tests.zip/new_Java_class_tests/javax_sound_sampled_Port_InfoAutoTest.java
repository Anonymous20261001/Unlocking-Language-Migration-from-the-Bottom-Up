package generated.test;

import java.lang.Class;
import java.lang.String;
import javax.sound.sampled.Line;
import javax.sound.sampled.Port;
import org.junit.jupiter.api.Test;

public class javax_sound_sampled_Port_InfoAutoTest {
  @Test
  public void isSource_test_9992(Class c0, String c1, boolean c2) {
    Port.Info instance = new Port.Info(c0, c1, c2);
    instance.isSource();
  }

  @Test
  public void getName_test_9993(Class c0, String c1, boolean c2) {
    Port.Info instance = new Port.Info(c0, c1, c2);
    instance.getName();
  }

  @Test
  public void matches_test_9994(Line.Info p0, Class c0, String c1, boolean c2) {
    Port.Info instance = new Port.Info(c0, c1, c2);
    instance.matches(p0);
  }
}
