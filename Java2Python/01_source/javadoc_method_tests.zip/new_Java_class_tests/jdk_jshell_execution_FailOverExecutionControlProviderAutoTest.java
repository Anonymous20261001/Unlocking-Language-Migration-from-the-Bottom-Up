package generated.test;

import jdk.jshell.execution.FailOverExecutionControlProvider;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_FailOverExecutionControlProviderAutoTest {
  @Test
  public void name_test_4672() {
    FailOverExecutionControlProvider instance = new FailOverExecutionControlProvider();
    instance.name();
  }

  @Test
  public void defaultParameters_test_4673() {
    FailOverExecutionControlProvider instance = new FailOverExecutionControlProvider();
    instance.defaultParameters();
  }
}
