package generated.test;

import javax.naming.spi.NamingManager;
import org.junit.jupiter.api.Test;

public class javax_naming_spi_NamingManagerAutoTest {
  @Test
  public void hasInitialContextFactoryBuilder_test_9513() {
    NamingManager.hasInitialContextFactoryBuilder();
  }
}
