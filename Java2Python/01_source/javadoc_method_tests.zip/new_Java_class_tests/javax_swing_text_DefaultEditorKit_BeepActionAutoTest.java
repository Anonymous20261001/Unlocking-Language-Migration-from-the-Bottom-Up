package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_BeepActionAutoTest {
  @Test
  public void actionPerformed_test_3669(ActionEvent p0) {
    DefaultEditorKit.BeepAction instance = new DefaultEditorKit.BeepAction();
    instance.actionPerformed(p0);
  }
}
