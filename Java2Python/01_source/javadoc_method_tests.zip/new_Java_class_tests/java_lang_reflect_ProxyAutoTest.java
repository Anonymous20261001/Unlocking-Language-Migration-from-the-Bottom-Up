package generated.test;

import java.lang.Class;
import java.lang.ClassLoader;
import java.lang.Object;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.junit.jupiter.api.Test;

public class java_lang_reflect_ProxyAutoTest {
  @Test
  public void getProxyClass_test_10213(ClassLoader p0, Class[] p1) {
    Proxy.getProxyClass(p0, p1);
  }

  @Test
  public void getInvocationHandler_test_10214(Object p0) {
    Proxy.getInvocationHandler(p0);
  }

  @Test
  public void isProxyClass_test_10215(Class p0) {
    Proxy.isProxyClass(p0);
  }

  @Test
  public void newProxyInstance_test_10216(ClassLoader p0, Class[] p1, InvocationHandler p2) {
    Proxy.newProxyInstance(p0, p1, p2);
  }
}
