package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.reflect.Array;
import org.junit.jupiter.api.Test;

public class java_lang_reflect_ArrayAutoTest {
  @Test
  public void get_test_232(Object p0, int p1) {
    Array.get(p0, p1);
  }

  @Test
  public void getLength_test_233(Object p0) {
    Array.getLength(p0);
  }

  @Test
  public void getBoolean_test_234(Object p0, int p1) {
    Array.getBoolean(p0, p1);
  }

  @Test
  public void getByte_test_235(Object p0, int p1) {
    Array.getByte(p0, p1);
  }

  @Test
  public void getShort_test_236(Object p0, int p1) {
    Array.getShort(p0, p1);
  }

  @Test
  public void getChar_test_237(Object p0, int p1) {
    Array.getChar(p0, p1);
  }

  @Test
  public void getInt_test_238(Object p0, int p1) {
    Array.getInt(p0, p1);
  }

  @Test
  public void getLong_test_239(Object p0, int p1) {
    Array.getLong(p0, p1);
  }

  @Test
  public void getFloat_test_240(Object p0, int p1) {
    Array.getFloat(p0, p1);
  }

  @Test
  public void getDouble_test_241(Object p0, int p1) {
    Array.getDouble(p0, p1);
  }

  @Test
  public void newInstance_test_242(Class p0, int p1) {
    Array.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_243(Class p0, int[] p1) {
    Array.newInstance(p0, p1);
  }

  @Test
  public void set_test_244(Object p0, int p1, Object p2) {
    Array.set(p0, p1, p2);
  }

  @Test
  public void setBoolean_test_245(Object p0, int p1, boolean p2) {
    Array.setBoolean(p0, p1, p2);
  }

  @Test
  public void setByte_test_246(Object p0, int p1, byte p2) {
    Array.setByte(p0, p1, p2);
  }

  @Test
  public void setChar_test_247(Object p0, int p1, char p2) {
    Array.setChar(p0, p1, p2);
  }

  @Test
  public void setShort_test_248(Object p0, int p1, short p2) {
    Array.setShort(p0, p1, p2);
  }

  @Test
  public void setInt_test_249(Object p0, int p1, int p2) {
    Array.setInt(p0, p1, p2);
  }

  @Test
  public void setLong_test_250(Object p0, int p1, long p2) {
    Array.setLong(p0, p1, p2);
  }

  @Test
  public void setFloat_test_251(Object p0, int p1, float p2) {
    Array.setFloat(p0, p1, p2);
  }

  @Test
  public void setDouble_test_252(Object p0, int p1, double p2) {
    Array.setDouble(p0, p1, p2);
  }
}
