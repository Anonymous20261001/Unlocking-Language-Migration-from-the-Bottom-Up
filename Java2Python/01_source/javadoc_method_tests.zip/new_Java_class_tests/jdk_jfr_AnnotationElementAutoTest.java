package generated.test;

import java.lang.Class;
import java.lang.String;
import jdk.jfr.AnnotationElement;
import org.junit.jupiter.api.Test;

public class jdk_jfr_AnnotationElementAutoTest {
  @Test
  public void getAnnotationElements_test_150(Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getAnnotationElements();
  }

  @Test
  public void getValues_test_151(Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getValues();
  }

  @Test
  public void getValueDescriptors_test_152(Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getValueDescriptors();
  }

  @Test
  public void getValue_test_153(String p0, Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getValue(p0);
  }

  @Test
  public void getTypeName_test_154(Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getTypeName();
  }

  @Test
  public void getAnnotation_test_155(Class p0, Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getAnnotation(p0);
  }

  @Test
  public void hasValue_test_156(String p0, Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.hasValue(p0);
  }

  @Test
  public void getTypeId_test_157(Class c0) {
    AnnotationElement instance = new AnnotationElement(c0);
    instance.getTypeId();
  }
}
