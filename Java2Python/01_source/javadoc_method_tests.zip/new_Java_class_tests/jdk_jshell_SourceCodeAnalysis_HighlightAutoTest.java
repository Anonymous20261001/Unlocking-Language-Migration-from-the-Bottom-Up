package generated.test;

import java.util.Set;
import jdk.jshell.SourceCodeAnalysis;
import org.junit.jupiter.api.Test;

public class jdk_jshell_SourceCodeAnalysis_HighlightAutoTest {
  @Test
  public void end_test_11281(int c0, int c1, Set c2) {
    SourceCodeAnalysis.Highlight instance = new SourceCodeAnalysis.Highlight(c0, c1, c2);
    instance.end();
  }

  @Test
  public void start_test_11282(int c0, int c1, Set c2) {
    SourceCodeAnalysis.Highlight instance = new SourceCodeAnalysis.Highlight(c0, c1, c2);
    instance.start();
  }

  @Test
  public void attributes_test_11283(int c0, int c1, Set c2) {
    SourceCodeAnalysis.Highlight instance = new SourceCodeAnalysis.Highlight(c0, c1, c2);
    instance.attributes();
  }
}
