package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_DefaultKeyTypedActionAutoTest {
  @Test
  public void actionPerformed_test_3672(ActionEvent p0) {
    DefaultEditorKit.DefaultKeyTypedAction instance = new DefaultEditorKit.DefaultKeyTypedAction();
    instance.actionPerformed(p0);
  }
}
