package generated.test;

import java.io.FileDescriptor;
import jdk.nio.Channels;
import org.junit.jupiter.api.Test;

public class jdk_nio_ChannelsAutoTest {
  @Test
  public void readWriteSelectableChannel_test_2124(FileDescriptor p0,
      Channels.SelectableChannelCloser p1) {
    Channels.readWriteSelectableChannel(p0, p1);
  }
}
