package generated.test;

import java.awt.Dimension;
import javax.swing.JToolBar;
import org.junit.jupiter.api.Test;

public class javax_swing_JToolBar_SeparatorAutoTest {
  @Test
  public void getSeparatorSize_test_7383() {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.getSeparatorSize();
  }

  @Test
  public void setSeparatorSize_test_7384(Dimension p0) {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.setSeparatorSize(p0);
  }

  @Test
  public void getPreferredSize_test_7385() {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.getPreferredSize();
  }

  @Test
  public void getMaximumSize_test_7386() {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.getMaximumSize();
  }

  @Test
  public void getMinimumSize_test_7387() {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.getMinimumSize();
  }

  @Test
  public void getUIClassID_test_7388() {
    JToolBar.Separator instance = new JToolBar.Separator();
    instance.getUIClassID();
  }
}
