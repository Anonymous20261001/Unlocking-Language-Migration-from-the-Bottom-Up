package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import java.util.function.IntUnaryOperator;
import jdk.incubator.vector.VectorShuffle;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_VectorShuffleAutoTest {
  @Test
  public void fromMemorySegment_test_13411(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    VectorShuffle.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromValues_test_13412(VectorSpecies p0, int[] p1) {
    VectorShuffle.fromValues(p0, p1);
  }

  @Test
  public void fromArray_test_13413(VectorSpecies p0, int[] p1, int p2) {
    VectorShuffle.fromArray(p0, p1, p2);
  }

  @Test
  public void iota_test_13414(VectorSpecies p0, int p1, int p2, boolean p3) {
    VectorShuffle.iota(p0, p1, p2, p3);
  }

  @Test
  public void fromOp_test_13415(VectorSpecies p0, IntUnaryOperator p1) {
    VectorShuffle.fromOp(p0, p1);
  }

  @Test
  public void makeZip_test_13416(VectorSpecies p0, int p1) {
    VectorShuffle.makeZip(p0, p1);
  }

  @Test
  public void makeUnzip_test_13417(VectorSpecies p0, int p1) {
    VectorShuffle.makeUnzip(p0, p1);
  }
}
