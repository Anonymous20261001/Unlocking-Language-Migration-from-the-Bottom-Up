package generated.test;

import java.lang.StackTraceElement;
import java.lang.String;
import jdk.jshell.spi.ExecutionControl;
import org.junit.jupiter.api.Test;

public class jdk_jshell_spi_ExecutionControl_UserExceptionAutoTest {
  @Test
  public void causeExceptionClass_test_4633(String c0, String c1, StackTraceElement[] c2) {
    ExecutionControl.UserException instance = new ExecutionControl.UserException(c0, c1, c2);
    instance.causeExceptionClass();
  }
}
