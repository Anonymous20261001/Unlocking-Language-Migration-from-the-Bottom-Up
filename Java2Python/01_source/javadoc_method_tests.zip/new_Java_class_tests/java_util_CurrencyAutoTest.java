package generated.test;

import java.lang.String;
import java.util.Currency;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_util_CurrencyAutoTest {
  @Test
  public void getAvailableCurrencies_test_3161() {
    Currency.getAvailableCurrencies();
  }

  @Test
  public void availableCurrencies_test_3162() {
    Currency.availableCurrencies();
  }

  @Test
  public void getInstance_test_3163(Locale p0) {
    Currency.getInstance(p0);
  }

  @Test
  public void getInstance_test_3164(String p0) {
    Currency.getInstance(p0);
  }
}
