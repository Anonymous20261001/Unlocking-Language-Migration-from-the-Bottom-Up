package generated.test;

import java.beans.Introspector;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_beans_IntrospectorAutoTest {
  @Test
  public void getBeanInfoSearchPath_test_5924() {
    Introspector.getBeanInfoSearchPath();
  }

  @Test
  public void setBeanInfoSearchPath_test_5925(String[] p0) {
    Introspector.setBeanInfoSearchPath(p0);
  }

  @Test
  public void flushCaches_test_5926() {
    Introspector.flushCaches();
  }

  @Test
  public void flushFromCaches_test_5927(Class p0) {
    Introspector.flushFromCaches(p0);
  }

  @Test
  public void decapitalize_test_5928(String p0) {
    Introspector.decapitalize(p0);
  }
}
