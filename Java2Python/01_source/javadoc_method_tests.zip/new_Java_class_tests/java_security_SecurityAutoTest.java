package generated.test;

import java.lang.String;
import java.security.Provider;
import java.security.Security;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_security_SecurityAutoTest {
  @Test
  public void getProperty_test_10968(String p0) {
    Security.getProperty(p0);
  }

  @Test
  public void setProperty_test_10969(String p0, String p1) {
    Security.setProperty(p0, p1);
  }

  @Test
  public void addProvider_test_10970(Provider p0) {
    Security.addProvider(p0);
  }

  @Test
  public void insertProviderAt_test_10971(Provider p0, int p1) {
    Security.insertProviderAt(p0, p1);
  }

  @Test
  public void getProvider_test_10972(String p0) {
    Security.getProvider(p0);
  }

  @Test
  public void getProviders_test_10973() {
    Security.getProviders();
  }

  @Test
  public void getProviders_test_10974(Map p0) {
    Security.getProviders(p0);
  }

  @Test
  public void getProviders_test_10975(String p0) {
    Security.getProviders(p0);
  }

  @Test
  public void getAlgorithmProperty_test_10976(String p0, String p1) {
    Security.getAlgorithmProperty(p0, p1);
  }

  @Test
  public void removeProvider_test_10977(String p0) {
    Security.removeProvider(p0);
  }

  @Test
  public void getAlgorithms_test_10978(String p0) {
    Security.getAlgorithms(p0);
  }
}
