package generated.test;

import javax.swing.RowSorter;
import javax.swing.SortOrder;
import org.junit.jupiter.api.Test;

public class javax_swing_RowSorter_SortKeyAutoTest {
  @Test
  public void getColumn_test_10716(int c0, SortOrder c1) {
    RowSorter.SortKey instance = new RowSorter.SortKey(c0, c1);
    instance.getColumn();
  }

  @Test
  public void getSortOrder_test_10717(int c0, SortOrder c1) {
    RowSorter.SortKey instance = new RowSorter.SortKey(c0, c1);
    instance.getSortOrder();
  }
}
