package generated.test;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneOffset;
import java.time.zone.ZoneOffsetTransitionRule;
import org.junit.jupiter.api.Test;

public class java_time_zone_ZoneOffsetTransitionRuleAutoTest {
  @Test
  public void of_test_13735(Month p0, int p1, DayOfWeek p2, LocalTime p3, boolean p4,
      ZoneOffsetTransitionRule.TimeDefinition p5, ZoneOffset p6, ZoneOffset p7, ZoneOffset p8) {
    ZoneOffsetTransitionRule.of(p0, p1, p2, p3, p4, p5, p6, p7, p8);
  }
}
