package generated.test;

import jdk.jfr.Configuration;
import org.junit.jupiter.api.Test;

public class jdk_jfr_ConfigurationAutoTest {
  @Test
  public void getConfigurations_test_2908() {
    Configuration.getConfigurations();
  }
}
