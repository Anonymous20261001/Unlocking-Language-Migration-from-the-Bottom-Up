package generated.test;

import java.lang.String;
import java.util.logging.Level;
import org.junit.jupiter.api.Test;

public class java_util_logging_LevelAutoTest {
  @Test
  public void parse_test_7719(String p0) {
    Level.parse(p0);
  }
}
