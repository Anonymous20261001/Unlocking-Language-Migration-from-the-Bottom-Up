package generated.test;

import javax.imageio.plugins.tiff.ExifParentTIFFTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_ExifParentTIFFTagSetAutoTest {
  @Test
  public void getInstance_test_4663() {
    ExifParentTIFFTagSet.getInstance();
  }
}
