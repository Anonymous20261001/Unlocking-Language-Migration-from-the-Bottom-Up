package generated.test;

import javax.swing.JInternalFrame;
import javax.swing.plaf.DesktopIconUI;
import org.junit.jupiter.api.Test;

public class javax_swing_JInternalFrame_JDesktopIconAutoTest {
  @Test
  public void getUIClassID_test_6341(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.getUIClassID();
  }

  @Test
  public void updateUI_test_6342(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.updateUI();
  }

  @Test
  public void getUI_test_6343(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.getUI();
  }

  @Test
  public void setUI_test_6344(DesktopIconUI p0, JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.setUI(p0);
  }

  @Test
  public void getAccessibleContext_test_6345(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.getAccessibleContext();
  }

  @Test
  public void getInternalFrame_test_6346(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.getInternalFrame();
  }

  @Test
  public void getDesktopPane_test_6347(JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.getDesktopPane();
  }

  @Test
  public void setInternalFrame_test_6348(JInternalFrame p0, JInternalFrame c0) {
    JInternalFrame.JDesktopIcon instance = new JInternalFrame.JDesktopIcon(c0);
    instance.setInternalFrame(p0);
  }
}
