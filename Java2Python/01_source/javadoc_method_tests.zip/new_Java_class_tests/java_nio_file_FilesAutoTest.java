package generated.test;

import java.lang.Class;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

public class java_nio_file_FilesAutoTest {
  @Test
  public void exists_test_4765(Path p0, LinkOption[] p1) {
    Files.exists(p0, p1);
  }

  @Test
  public void isDirectory_test_4766(Path p0, LinkOption[] p1) {
    Files.isDirectory(p0, p1);
  }

  @Test
  public void isRegularFile_test_4767(Path p0, LinkOption[] p1) {
    Files.isRegularFile(p0, p1);
  }

  @Test
  public void notExists_test_4768(Path p0, LinkOption[] p1) {
    Files.notExists(p0, p1);
  }

  @Test
  public void isWritable_test_4769(Path p0) {
    Files.isWritable(p0);
  }

  @Test
  public void getFileAttributeView_test_4770(Path p0, Class p1, LinkOption[] p2) {
    Files.getFileAttributeView(p0, p1, p2);
  }

  @Test
  public void isSymbolicLink_test_4771(Path p0) {
    Files.isSymbolicLink(p0);
  }

  @Test
  public void isReadable_test_4772(Path p0) {
    Files.isReadable(p0);
  }

  @Test
  public void isExecutable_test_4773(Path p0) {
    Files.isExecutable(p0);
  }
}
