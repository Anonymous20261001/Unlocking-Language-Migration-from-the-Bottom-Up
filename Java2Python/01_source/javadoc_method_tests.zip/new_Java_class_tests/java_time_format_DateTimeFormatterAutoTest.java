package generated.test;

import java.lang.String;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_time_format_DateTimeFormatterAutoTest {
  @Test
  public void ofPattern_test_3355(String p0) {
    DateTimeFormatter.ofPattern(p0);
  }

  @Test
  public void ofPattern_test_3356(String p0, Locale p1) {
    DateTimeFormatter.ofPattern(p0, p1);
  }

  @Test
  public void ofLocalizedDate_test_3357(FormatStyle p0) {
    DateTimeFormatter.ofLocalizedDate(p0);
  }

  @Test
  public void ofLocalizedTime_test_3358(FormatStyle p0) {
    DateTimeFormatter.ofLocalizedTime(p0);
  }

  @Test
  public void ofLocalizedDateTime_test_3359(FormatStyle p0) {
    DateTimeFormatter.ofLocalizedDateTime(p0);
  }

  @Test
  public void ofLocalizedDateTime_test_3360(FormatStyle p0, FormatStyle p1) {
    DateTimeFormatter.ofLocalizedDateTime(p0, p1);
  }

  @Test
  public void ofLocalizedPattern_test_3361(String p0) {
    DateTimeFormatter.ofLocalizedPattern(p0);
  }

  @Test
  public void parsedExcessDays_test_3362() {
    DateTimeFormatter.parsedExcessDays();
  }

  @Test
  public void parsedLeapSecond_test_3363() {
    DateTimeFormatter.parsedLeapSecond();
  }
}
