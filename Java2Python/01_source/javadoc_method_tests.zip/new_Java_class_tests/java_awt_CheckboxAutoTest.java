package generated.test;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxAutoTest {
  @Test
  public void getListeners_test_2240(Class p0) {
    Checkbox instance = new Checkbox();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_2241() {
    Checkbox instance = new Checkbox();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_2242() {
    Checkbox instance = new Checkbox();
    instance.getAccessibleContext();
  }

  @Test
  public void removeItemListener_test_2243(ItemListener p0) {
    Checkbox instance = new Checkbox();
    instance.removeItemListener(p0);
  }

  @Test
  public void addItemListener_test_2244(ItemListener p0) {
    Checkbox instance = new Checkbox();
    instance.addItemListener(p0);
  }

  @Test
  public void setLabel_test_2245(String p0) {
    Checkbox instance = new Checkbox();
    instance.setLabel(p0);
  }

  @Test
  public void getItemListeners_test_2246() {
    Checkbox instance = new Checkbox();
    instance.getItemListeners();
  }

  @Test
  public void getSelectedObjects_test_2247() {
    Checkbox instance = new Checkbox();
    instance.getSelectedObjects();
  }

  @Test
  public void setCheckboxGroup_test_2248(CheckboxGroup p0) {
    Checkbox instance = new Checkbox();
    instance.setCheckboxGroup(p0);
  }

  @Test
  public void getCheckboxGroup_test_2249() {
    Checkbox instance = new Checkbox();
    instance.getCheckboxGroup();
  }

  @Test
  public void getState_test_2250() {
    Checkbox instance = new Checkbox();
    instance.getState();
  }

  @Test
  public void setState_test_2251(boolean p0) {
    Checkbox instance = new Checkbox();
    instance.setState(p0);
  }

  @Test
  public void getLabel_test_2252() {
    Checkbox instance = new Checkbox();
    instance.getLabel();
  }
}
