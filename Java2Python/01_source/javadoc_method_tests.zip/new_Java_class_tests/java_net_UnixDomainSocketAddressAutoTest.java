package generated.test;

import java.lang.String;
import java.net.UnixDomainSocketAddress;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

public class java_net_UnixDomainSocketAddressAutoTest {
  @Test
  public void of_test_13210(Path p0) {
    UnixDomainSocketAddress.of(p0);
  }

  @Test
  public void of_test_13211(String p0) {
    UnixDomainSocketAddress.of(p0);
  }
}
