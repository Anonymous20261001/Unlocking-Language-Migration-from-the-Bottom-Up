package generated.test;

import jdk.jshell.JShell;
import org.junit.jupiter.api.Test;

public class jdk_jshell_JShellAutoTest {
  @Test
  public void builder_test_6941() {
    JShell.builder();
  }

  @Test
  public void create_test_6942() {
    JShell.create();
  }
}
