package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.modelmbean.DescriptorSupport;
import org.junit.jupiter.api.Test;

public class javax_management_modelmbean_DescriptorSupportAutoTest {
  @Test
  public void getFieldNames_test_4099() {
    DescriptorSupport instance = new DescriptorSupport();
    instance.getFieldNames();
  }

  @Test
  public void getFieldValues_test_4100(String[] p0) {
    DescriptorSupport instance = new DescriptorSupport();
    instance.getFieldValues(p0);
  }

  @Test
  public void setField_test_4101(String p0, Object p1) {
    DescriptorSupport instance = new DescriptorSupport();
    instance.setField(p0, p1);
  }

  @Test
  public void getFieldValue_test_4102(String p0) {
    DescriptorSupport instance = new DescriptorSupport();
    instance.getFieldValue(p0);
  }

  @Test
  public void removeField_test_4103(String p0) {
    DescriptorSupport instance = new DescriptorSupport();
    instance.removeField(p0);
  }

  @Test
  public void toXMLString_test_4104() {
    DescriptorSupport instance = new DescriptorSupport();
    instance.toXMLString();
  }

  @Test
  public void getFields_test_4105() {
    DescriptorSupport instance = new DescriptorSupport();
    instance.getFields();
  }

  @Test
  public void isValid_test_4106() {
    DescriptorSupport instance = new DescriptorSupport();
    instance.isValid();
  }

  @Test
  public void setFields_test_4107(String[] p0, Object[] p1) {
    DescriptorSupport instance = new DescriptorSupport();
    instance.setFields(p0, p1);
  }
}
