package generated.test;

import java.awt.event.ActionEvent;
import java.lang.String;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_FontSizeActionAutoTest {
  @Test
  public void actionPerformed_test_12004(ActionEvent p0, String c0, int c1) {
    StyledEditorKit.FontSizeAction instance = new StyledEditorKit.FontSizeAction(c0, c1);
    instance.actionPerformed(p0);
  }
}
