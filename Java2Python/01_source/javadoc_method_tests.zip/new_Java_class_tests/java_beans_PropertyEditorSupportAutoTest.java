package generated.test;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.beans.PropertyChangeListener;
import java.beans.PropertyEditorSupport;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_beans_PropertyEditorSupportAutoTest {
  @Test
  public void firePropertyChange_test_10182() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.firePropertyChange();
  }

  @Test
  public void addPropertyChangeListener_test_10183(PropertyChangeListener p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void removePropertyChangeListener_test_10184(PropertyChangeListener p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.removePropertyChangeListener(p0);
  }

  @Test
  public void setSource_test_10185(Object p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.setSource(p0);
  }

  @Test
  public void isPaintable_test_10186() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.isPaintable();
  }

  @Test
  public void paintValue_test_10187(Graphics p0, Rectangle p1) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.paintValue(p0, p1);
  }

  @Test
  public void getJavaInitializationString_test_10188() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getJavaInitializationString();
  }

  @Test
  public void getAsText_test_10189() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getAsText();
  }

  @Test
  public void setAsText_test_10190(String p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.setAsText(p0);
  }

  @Test
  public void getTags_test_10191() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getTags();
  }

  @Test
  public void getCustomEditor_test_10192() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getCustomEditor();
  }

  @Test
  public void supportsCustomEditor_test_10193() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.supportsCustomEditor();
  }

  @Test
  public void getValue_test_10194() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getValue();
  }

  @Test
  public void setValue_test_10195(Object p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.setValue(p0);
  }

  @Test
  public void getSource_test_10196() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getSource();
  }
}
