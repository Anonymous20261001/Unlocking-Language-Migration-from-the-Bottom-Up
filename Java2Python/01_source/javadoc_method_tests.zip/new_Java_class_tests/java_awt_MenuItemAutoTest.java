package generated.test;

import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuItemAutoTest {
  @Test
  public void setEnabled_test_8558(boolean p0) {
    MenuItem instance = new MenuItem();
    instance.setEnabled(p0);
  }

  @Test
  public void getListeners_test_8559(Class p0) {
    MenuItem instance = new MenuItem();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_8560() {
    MenuItem instance = new MenuItem();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_8561() {
    MenuItem instance = new MenuItem();
    instance.getAccessibleContext();
  }

  @Test
  public void setActionCommand_test_8562(String p0) {
    MenuItem instance = new MenuItem();
    instance.setActionCommand(p0);
  }

  @Test
  public void getActionCommand_test_8563() {
    MenuItem instance = new MenuItem();
    instance.getActionCommand();
  }

  @Test
  public void removeActionListener_test_8564(ActionListener p0) {
    MenuItem instance = new MenuItem();
    instance.removeActionListener(p0);
  }

  @Test
  public void addActionListener_test_8565(ActionListener p0) {
    MenuItem instance = new MenuItem();
    instance.addActionListener(p0);
  }

  @Test
  public void getActionListeners_test_8566() {
    MenuItem instance = new MenuItem();
    instance.getActionListeners();
  }

  @Test
  public void setLabel_test_8567(String p0) {
    MenuItem instance = new MenuItem();
    instance.setLabel(p0);
  }

  @Test
  public void getShortcut_test_8568() {
    MenuItem instance = new MenuItem();
    instance.getShortcut();
  }

  @Test
  public void setShortcut_test_8569(MenuShortcut p0) {
    MenuItem instance = new MenuItem();
    instance.setShortcut(p0);
  }

  @Test
  public void deleteShortcut_test_8570() {
    MenuItem instance = new MenuItem();
    instance.deleteShortcut();
  }

  @Test
  public void isEnabled_test_8571() {
    MenuItem instance = new MenuItem();
    instance.isEnabled();
  }

  @Test
  public void paramString_test_8572() {
    MenuItem instance = new MenuItem();
    instance.paramString();
  }

  @Test
  public void enable_test_8573() {
    MenuItem instance = new MenuItem();
    instance.enable();
  }

  @Test
  public void enable_test_8574(boolean p0) {
    MenuItem instance = new MenuItem();
    instance.enable(p0);
  }

  @Test
  public void getLabel_test_8575() {
    MenuItem instance = new MenuItem();
    instance.getLabel();
  }

  @Test
  public void disable_test_8576() {
    MenuItem instance = new MenuItem();
    instance.disable();
  }
}
