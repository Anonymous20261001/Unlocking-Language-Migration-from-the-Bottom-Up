package generated.test;

import java.nio.IntBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_IntBufferAutoTest {
  @Test
  public void wrap_test_5864(int[] p0) {
    IntBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_5865(int[] p0, int p1, int p2) {
    IntBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_5866(int p0) {
    IntBuffer.allocate(p0);
  }
}
