package generated.test;

import java.lang.Enum;
import java.lang.String;
import java.lang.constant.ClassDesc;
import org.junit.jupiter.api.Test;

public class java_lang_Enum_EnumDescAutoTest {
  @Test
  public void of_test_4534(ClassDesc p0, String p1) {
    Enum.EnumDesc.of(p0, p1);
  }
}
