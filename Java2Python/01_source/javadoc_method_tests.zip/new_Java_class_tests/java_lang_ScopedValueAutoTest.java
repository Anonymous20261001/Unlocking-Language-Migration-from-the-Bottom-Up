package generated.test;

import java.lang.Object;
import java.lang.ScopedValue;
import org.junit.jupiter.api.Test;

public class java_lang_ScopedValueAutoTest {
  @Test
  public void newInstance_test_10859() {
    ScopedValue.newInstance();
  }

  @Test
  public void where_test_10860(ScopedValue p0, Object p1) {
    ScopedValue.where(p0, p1);
  }
}
