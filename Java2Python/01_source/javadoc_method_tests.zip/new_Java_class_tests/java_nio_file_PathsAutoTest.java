package generated.test;

import java.lang.String;
import java.net.URI;
import java.nio.file.Paths;
import org.junit.jupiter.api.Test;

public class java_nio_file_PathsAutoTest {
  @Test
  public void get_test_9863(String p0, String[] p1) {
    Paths.get(p0, p1);
  }

  @Test
  public void get_test_9864(URI p0) {
    Paths.get(p0);
  }
}
