package generated.test;

import java.lang.classfile.Attributes;
import org.junit.jupiter.api.Test;

public class java_lang_classfile_AttributesAutoTest {
  @Test
  public void signature_test_794() {
    Attributes.signature();
  }

  @Test
  public void annotationDefault_test_795() {
    Attributes.annotationDefault();
  }

  @Test
  public void code_test_796() {
    Attributes.code();
  }

  @Test
  public void record_test_797() {
    Attributes.record();
  }

  @Test
  public void module_test_798() {
    Attributes.module();
  }

  @Test
  public void moduleTarget_test_799() {
    Attributes.moduleTarget();
  }

  @Test
  public void moduleResolution_test_800() {
    Attributes.moduleResolution();
  }

  @Test
  public void moduleHashes_test_801() {
    Attributes.moduleHashes();
  }

  @Test
  public void synthetic_test_802() {
    Attributes.synthetic();
  }

  @Test
  public void constantValue_test_803() {
    Attributes.constantValue();
  }

  @Test
  public void runtimeVisibleAnnotations_test_804() {
    Attributes.runtimeVisibleAnnotations();
  }

  @Test
  public void bootstrapMethods_test_805() {
    Attributes.bootstrapMethods();
  }

  @Test
  public void characterRangeTable_test_806() {
    Attributes.characterRangeTable();
  }

  @Test
  public void compilationId_test_807() {
    Attributes.compilationId();
  }

  @Test
  public void deprecated_test_808() {
    Attributes.deprecated();
  }

  @Test
  public void enclosingMethod_test_809() {
    Attributes.enclosingMethod();
  }

  @Test
  public void exceptions_test_810() {
    Attributes.exceptions();
  }

  @Test
  public void innerClasses_test_811() {
    Attributes.innerClasses();
  }

  @Test
  public void lineNumberTable_test_812() {
    Attributes.lineNumberTable();
  }

  @Test
  public void localVariableTable_test_813() {
    Attributes.localVariableTable();
  }

  @Test
  public void localVariableTypeTable_test_814() {
    Attributes.localVariableTypeTable();
  }

  @Test
  public void methodParameters_test_815() {
    Attributes.methodParameters();
  }

  @Test
  public void moduleMainClass_test_816() {
    Attributes.moduleMainClass();
  }

  @Test
  public void modulePackages_test_817() {
    Attributes.modulePackages();
  }

  @Test
  public void nestHost_test_818() {
    Attributes.nestHost();
  }

  @Test
  public void nestMembers_test_819() {
    Attributes.nestMembers();
  }

  @Test
  public void permittedSubclasses_test_820() {
    Attributes.permittedSubclasses();
  }

  @Test
  public void runtimeInvisibleAnnotations_test_821() {
    Attributes.runtimeInvisibleAnnotations();
  }

  @Test
  public void runtimeInvisibleParameterAnnotations_test_822() {
    Attributes.runtimeInvisibleParameterAnnotations();
  }

  @Test
  public void runtimeInvisibleTypeAnnotations_test_823() {
    Attributes.runtimeInvisibleTypeAnnotations();
  }

  @Test
  public void runtimeVisibleParameterAnnotations_test_824() {
    Attributes.runtimeVisibleParameterAnnotations();
  }

  @Test
  public void runtimeVisibleTypeAnnotations_test_825() {
    Attributes.runtimeVisibleTypeAnnotations();
  }

  @Test
  public void sourceDebugExtension_test_826() {
    Attributes.sourceDebugExtension();
  }

  @Test
  public void sourceFile_test_827() {
    Attributes.sourceFile();
  }

  @Test
  public void sourceId_test_828() {
    Attributes.sourceId();
  }

  @Test
  public void stackMapTable_test_829() {
    Attributes.stackMapTable();
  }
}
