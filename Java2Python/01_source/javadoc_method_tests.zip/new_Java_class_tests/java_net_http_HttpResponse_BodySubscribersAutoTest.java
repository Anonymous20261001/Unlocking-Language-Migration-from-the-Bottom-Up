package generated.test;

import java.lang.Object;
import java.lang.String;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.concurrent.Flow;
import java.util.function.Consumer;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpResponse_BodySubscribersAutoTest {
  @Test
  public void ofString_test_5469(Charset p0) {
    HttpResponse.BodySubscribers.ofString(p0);
  }

  @Test
  public void mapping_test_5470(HttpResponse.BodySubscriber p0, Function p1) {
    HttpResponse.BodySubscribers.mapping(p0, p1);
  }

  @Test
  public void ofInputStream_test_5471() {
    HttpResponse.BodySubscribers.ofInputStream();
  }

  @Test
  public void ofByteArray_test_5472() {
    HttpResponse.BodySubscribers.ofByteArray();
  }

  @Test
  public void ofFile_test_5473(Path p0, OpenOption[] p1) {
    HttpResponse.BodySubscribers.ofFile(p0, p1);
  }

  @Test
  public void ofFile_test_5474(Path p0) {
    HttpResponse.BodySubscribers.ofFile(p0);
  }

  @Test
  public void limiting_test_5475(HttpResponse.BodySubscriber p0, long p1) {
    HttpResponse.BodySubscribers.limiting(p0, p1);
  }

  @Test
  public void buffering_test_5476(HttpResponse.BodySubscriber p0, int p1) {
    HttpResponse.BodySubscribers.buffering(p0, p1);
  }

  @Test
  public void ofPublisher_test_5477() {
    HttpResponse.BodySubscribers.ofPublisher();
  }

  @Test
  public void ofLines_test_5478(Charset p0) {
    HttpResponse.BodySubscribers.ofLines(p0);
  }

  @Test
  public void replacing_test_5479(Object p0) {
    HttpResponse.BodySubscribers.replacing(p0);
  }

  @Test
  public void discarding_test_5480() {
    HttpResponse.BodySubscribers.discarding();
  }

  @Test
  public void fromLineSubscriber_test_5481(Flow.Subscriber p0) {
    HttpResponse.BodySubscribers.fromLineSubscriber(p0);
  }

  @Test
  public void fromLineSubscriber_test_5482(Flow.Subscriber p0, Function p1, Charset p2, String p3) {
    HttpResponse.BodySubscribers.fromLineSubscriber(p0, p1, p2, p3);
  }

  @Test
  public void fromSubscriber_test_5483(Flow.Subscriber p0, Function p1) {
    HttpResponse.BodySubscribers.fromSubscriber(p0, p1);
  }

  @Test
  public void fromSubscriber_test_5484(Flow.Subscriber p0) {
    HttpResponse.BodySubscribers.fromSubscriber(p0);
  }

  @Test
  public void ofByteArrayConsumer_test_5485(Consumer p0) {
    HttpResponse.BodySubscribers.ofByteArrayConsumer(p0);
  }
}
