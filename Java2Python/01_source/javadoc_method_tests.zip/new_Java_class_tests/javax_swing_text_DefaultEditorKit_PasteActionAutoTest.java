package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_PasteActionAutoTest {
  @Test
  public void actionPerformed_test_3676(ActionEvent p0) {
    DefaultEditorKit.PasteAction instance = new DefaultEditorKit.PasteAction();
    instance.actionPerformed(p0);
  }
}
