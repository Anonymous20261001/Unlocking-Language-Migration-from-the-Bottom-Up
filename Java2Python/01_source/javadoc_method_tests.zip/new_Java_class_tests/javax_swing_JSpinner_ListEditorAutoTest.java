package generated.test;

import javax.swing.JSpinner;
import org.junit.jupiter.api.Test;

public class javax_swing_JSpinner_ListEditorAutoTest {
  @Test
  public void getModel_test_7015(JSpinner c0) {
    JSpinner.ListEditor instance = new JSpinner.ListEditor(c0);
    instance.getModel();
  }
}
