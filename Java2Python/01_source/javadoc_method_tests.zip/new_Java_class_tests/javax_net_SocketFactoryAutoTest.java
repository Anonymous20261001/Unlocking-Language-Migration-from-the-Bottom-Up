package generated.test;

import javax.net.SocketFactory;
import org.junit.jupiter.api.Test;

public class javax_net_SocketFactoryAutoTest {
  @Test
  public void getDefault_test_11262() {
    SocketFactory.getDefault();
  }
}
