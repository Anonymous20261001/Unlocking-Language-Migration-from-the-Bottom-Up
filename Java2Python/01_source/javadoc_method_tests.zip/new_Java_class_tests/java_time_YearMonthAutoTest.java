package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Month;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_YearMonthAutoTest {
  @Test
  public void of_test_13674(int p0, int p1) {
    YearMonth.of(p0, p1);
  }

  @Test
  public void of_test_13675(int p0, Month p1) {
    YearMonth.of(p0, p1);
  }

  @Test
  public void from_test_13676(TemporalAccessor p0) {
    YearMonth.from(p0);
  }

  @Test
  public void parse_test_13677(CharSequence p0, DateTimeFormatter p1) {
    YearMonth.parse(p0, p1);
  }

  @Test
  public void parse_test_13678(CharSequence p0) {
    YearMonth.parse(p0);
  }

  @Test
  public void now_test_13679() {
    YearMonth.now();
  }

  @Test
  public void now_test_13680(ZoneId p0) {
    YearMonth.now(p0);
  }

  @Test
  public void now_test_13681(Clock p0) {
    YearMonth.now(p0);
  }
}
