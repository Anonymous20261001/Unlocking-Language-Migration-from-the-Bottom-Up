package generated.test;

import java.awt.geom.Line2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Line2D_DoubleAutoTest {
  @Test
  public void setLine_test_7728(double p0, double p1, double p2, double p3) {
    Line2D.Double instance = new Line2D.Double();
    instance.setLine(p0, p1, p2, p3);
  }

  @Test
  public void getBounds2D_test_7729() {
    Line2D.Double instance = new Line2D.Double();
    instance.getBounds2D();
  }

  @Test
  public void getX1_test_7730() {
    Line2D.Double instance = new Line2D.Double();
    instance.getX1();
  }

  @Test
  public void getY1_test_7731() {
    Line2D.Double instance = new Line2D.Double();
    instance.getY1();
  }

  @Test
  public void getX2_test_7732() {
    Line2D.Double instance = new Line2D.Double();
    instance.getX2();
  }

  @Test
  public void getY2_test_7733() {
    Line2D.Double instance = new Line2D.Double();
    instance.getY2();
  }

  @Test
  public void getP1_test_7734() {
    Line2D.Double instance = new Line2D.Double();
    instance.getP1();
  }

  @Test
  public void getP2_test_7735() {
    Line2D.Double instance = new Line2D.Double();
    instance.getP2();
  }
}
