package generated.test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.ScrollPane;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollPaneAutoTest {
  @Test
  public void getHScrollbarHeight_test_10904() {
    ScrollPane instance = new ScrollPane();
    instance.getHScrollbarHeight();
  }

  @Test
  public void getVScrollbarWidth_test_10905() {
    ScrollPane instance = new ScrollPane();
    instance.getVScrollbarWidth();
  }

  @Test
  public void setScrollPosition_test_10906(Point p0) {
    ScrollPane instance = new ScrollPane();
    instance.setScrollPosition(p0);
  }

  @Test
  public void setScrollPosition_test_10907(int p0, int p1) {
    ScrollPane instance = new ScrollPane();
    instance.setScrollPosition(p0, p1);
  }

  @Test
  public void getScrollPosition_test_10908() {
    ScrollPane instance = new ScrollPane();
    instance.getScrollPosition();
  }

  @Test
  public void getViewportSize_test_10909() {
    ScrollPane instance = new ScrollPane();
    instance.getViewportSize();
  }

  @Test
  public void getScrollbarDisplayPolicy_test_10910() {
    ScrollPane instance = new ScrollPane();
    instance.getScrollbarDisplayPolicy();
  }

  @Test
  public void getVAdjustable_test_10911() {
    ScrollPane instance = new ScrollPane();
    instance.getVAdjustable();
  }

  @Test
  public void getHAdjustable_test_10912() {
    ScrollPane instance = new ScrollPane();
    instance.getHAdjustable();
  }

  @Test
  public void addNotify_test_10913() {
    ScrollPane instance = new ScrollPane();
    instance.addNotify();
  }

  @Test
  public void layout_test_10914() {
    ScrollPane instance = new ScrollPane();
    instance.layout();
  }

  @Test
  public void doLayout_test_10915() {
    ScrollPane instance = new ScrollPane();
    instance.doLayout();
  }

  @Test
  public void getAccessibleContext_test_10916() {
    ScrollPane instance = new ScrollPane();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_10917(LayoutManager p0) {
    ScrollPane instance = new ScrollPane();
    instance.setLayout(p0);
  }

  @Test
  public void printComponents_test_10918(Graphics p0) {
    ScrollPane instance = new ScrollPane();
    instance.printComponents(p0);
  }

  @Test
  public void isWheelScrollingEnabled_test_10919() {
    ScrollPane instance = new ScrollPane();
    instance.isWheelScrollingEnabled();
  }

  @Test
  public void setWheelScrollingEnabled_test_10920(boolean p0) {
    ScrollPane instance = new ScrollPane();
    instance.setWheelScrollingEnabled(p0);
  }

  @Test
  public void paramString_test_10921() {
    ScrollPane instance = new ScrollPane();
    instance.paramString();
  }
}
