package generated.test;

import java.lang.Class;
import javax.sound.sampled.Line;
import org.junit.jupiter.api.Test;

public class javax_sound_sampled_Line_InfoAutoTest {
  @Test
  public void getLineClass_test_7720(Class c0) {
    Line.Info instance = new Line.Info(c0);
    instance.getLineClass();
  }

  @Test
  public void matches_test_7721(Line.Info p0, Class c0) {
    Line.Info instance = new Line.Info(c0);
    instance.matches(p0);
  }
}
