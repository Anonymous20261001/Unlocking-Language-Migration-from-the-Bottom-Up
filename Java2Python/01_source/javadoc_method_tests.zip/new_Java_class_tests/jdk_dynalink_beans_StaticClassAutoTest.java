package generated.test;

import java.lang.Class;
import jdk.dynalink.beans.StaticClass;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_beans_StaticClassAutoTest {
  @Test
  public void forClass_test_11503(Class p0) {
    StaticClass.forClass(p0);
  }
}
