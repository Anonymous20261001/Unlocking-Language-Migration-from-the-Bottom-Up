package generated.test;

import javax.security.auth.login.Configuration;
import org.junit.jupiter.api.Test;

public class javax_security_auth_login_ConfigurationAutoTest {
  @Test
  public void setConfiguration_test_2906(Configuration p0) {
    Configuration.setConfiguration(p0);
  }

  @Test
  public void getConfiguration_test_2907() {
    Configuration.getConfiguration();
  }
}
