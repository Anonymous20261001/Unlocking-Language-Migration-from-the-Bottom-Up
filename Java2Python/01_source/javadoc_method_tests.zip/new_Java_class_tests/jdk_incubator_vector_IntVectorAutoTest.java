package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.IntVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_IntVectorAutoTest {
  @Test
  public void fromMemorySegment_test_5936(VectorSpecies p0, MemorySegment p1, long p2, ByteOrder p3,
      VectorMask p4) {
    IntVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromMemorySegment_test_5937(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    IntVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_5938(VectorSpecies p0, int[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    IntVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromArray_test_5939(VectorSpecies p0, int[] p1, int p2) {
    IntVector.fromArray(p0, p1, p2);
  }

  @Test
  public void fromArray_test_5940(VectorSpecies p0, int[] p1, int p2, VectorMask p3) {
    IntVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_5941(VectorSpecies p0, int[] p1, int p2, int[] p3, int p4) {
    IntVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void zero_test_5942(VectorSpecies p0) {
    IntVector.zero(p0);
  }

  @Test
  public void broadcast_test_5943(VectorSpecies p0, int p1) {
    IntVector.broadcast(p0, p1);
  }

  @Test
  public void broadcast_test_5944(VectorSpecies p0, long p1) {
    IntVector.broadcast(p0, p1);
  }
}
