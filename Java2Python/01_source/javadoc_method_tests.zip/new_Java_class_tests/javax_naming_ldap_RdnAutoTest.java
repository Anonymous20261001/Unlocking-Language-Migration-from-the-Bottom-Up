package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.naming.ldap.Rdn;
import org.junit.jupiter.api.Test;

public class javax_naming_ldap_RdnAutoTest {
  @Test
  public void escapeValue_test_10344(Object p0) {
    Rdn.escapeValue(p0);
  }

  @Test
  public void unescapeValue_test_10345(String p0) {
    Rdn.unescapeValue(p0);
  }
}
