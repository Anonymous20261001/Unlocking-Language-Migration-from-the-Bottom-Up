package generated.test;

import java.awt.TextField;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextFieldAutoTest {
  @Test
  public void setEchoCharacter_test_12566(char p0) {
    TextField instance = new TextField();
    instance.setEchoCharacter(p0);
  }

  @Test
  public void getColumns_test_12567() {
    TextField instance = new TextField();
    instance.getColumns();
  }

  @Test
  public void setColumns_test_12568(int p0) {
    TextField instance = new TextField();
    instance.setColumns(p0);
  }

  @Test
  public void setEchoChar_test_12569(char p0) {
    TextField instance = new TextField();
    instance.setEchoChar(p0);
  }

  @Test
  public void echoCharIsSet_test_12570() {
    TextField instance = new TextField();
    instance.echoCharIsSet();
  }

  @Test
  public void getEchoChar_test_12571() {
    TextField instance = new TextField();
    instance.getEchoChar();
  }

  @Test
  public void getPreferredSize_test_12572() {
    TextField instance = new TextField();
    instance.getPreferredSize();
  }

  @Test
  public void getPreferredSize_test_12573(int p0) {
    TextField instance = new TextField();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_12574() {
    TextField instance = new TextField();
    instance.getMinimumSize();
  }

  @Test
  public void getMinimumSize_test_12575(int p0) {
    TextField instance = new TextField();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getListeners_test_12576(Class p0) {
    TextField instance = new TextField();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_12577() {
    TextField instance = new TextField();
    instance.addNotify();
  }

  @Test
  public void preferredSize_test_12578(int p0) {
    TextField instance = new TextField();
    instance.preferredSize(p0);
  }

  @Test
  public void preferredSize_test_12579() {
    TextField instance = new TextField();
    instance.preferredSize();
  }

  @Test
  public void minimumSize_test_12580(int p0) {
    TextField instance = new TextField();
    instance.minimumSize(p0);
  }

  @Test
  public void minimumSize_test_12581() {
    TextField instance = new TextField();
    instance.minimumSize();
  }

  @Test
  public void getAccessibleContext_test_12582() {
    TextField instance = new TextField();
    instance.getAccessibleContext();
  }

  @Test
  public void removeActionListener_test_12583(ActionListener p0) {
    TextField instance = new TextField();
    instance.removeActionListener(p0);
  }

  @Test
  public void addActionListener_test_12584(ActionListener p0) {
    TextField instance = new TextField();
    instance.addActionListener(p0);
  }

  @Test
  public void setText_test_12585(String p0) {
    TextField instance = new TextField();
    instance.setText(p0);
  }

  @Test
  public void getActionListeners_test_12586() {
    TextField instance = new TextField();
    instance.getActionListeners();
  }
}
