package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_ClassLoaderAutoTest {
  @Test
  public void getPlatformClassLoader_test_2314() {
    ClassLoader.getPlatformClassLoader();
  }

  @Test
  public void getSystemClassLoader_test_2315() {
    ClassLoader.getSystemClassLoader();
  }

  @Test
  public void getSystemResourceAsStream_test_2316(String p0) {
    ClassLoader.getSystemResourceAsStream(p0);
  }

  @Test
  public void getSystemResource_test_2317(String p0) {
    ClassLoader.getSystemResource(p0);
  }
}
