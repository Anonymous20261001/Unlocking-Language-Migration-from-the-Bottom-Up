package generated.test;

import java.awt.im.InputContext;
import org.junit.jupiter.api.Test;

public class java_awt_im_InputContextAutoTest {
  @Test
  public void getInstance_test_5830() {
    InputContext.getInstance();
  }
}
