package generated.test;

import java.lang.String;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAccessor;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_time_ZoneIdAutoTest {
  @Test
  public void of_test_13722(String p0, Map p1) {
    ZoneId.of(p0, p1);
  }

  @Test
  public void of_test_13723(String p0) {
    ZoneId.of(p0);
  }

  @Test
  public void from_test_13724(TemporalAccessor p0) {
    ZoneId.from(p0);
  }

  @Test
  public void systemDefault_test_13725() {
    ZoneId.systemDefault();
  }

  @Test
  public void getAvailableZoneIds_test_13726() {
    ZoneId.getAvailableZoneIds();
  }

  @Test
  public void ofOffset_test_13727(String p0, ZoneOffset p1) {
    ZoneId.ofOffset(p0, p1);
  }
}
