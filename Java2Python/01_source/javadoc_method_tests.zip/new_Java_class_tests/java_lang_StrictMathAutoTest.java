package generated.test;

import java.lang.StrictMath;
import org.junit.jupiter.api.Test;

public class java_lang_StrictMathAutoTest {
  @Test
  public void abs_test_11593(float p0) {
    StrictMath.abs(p0);
  }

  @Test
  public void abs_test_11594(long p0) {
    StrictMath.abs(p0);
  }

  @Test
  public void abs_test_11595(int p0) {
    StrictMath.abs(p0);
  }

  @Test
  public void abs_test_11596(double p0) {
    StrictMath.abs(p0);
  }

  @Test
  public void sin_test_11597(double p0) {
    StrictMath.sin(p0);
  }

  @Test
  public void cos_test_11598(double p0) {
    StrictMath.cos(p0);
  }

  @Test
  public void tan_test_11599(double p0) {
    StrictMath.tan(p0);
  }

  @Test
  public void atan2_test_11600(double p0, double p1) {
    StrictMath.atan2(p0, p1);
  }

  @Test
  public void sqrt_test_11601(double p0) {
    StrictMath.sqrt(p0);
  }

  @Test
  public void log_test_11602(double p0) {
    StrictMath.log(p0);
  }

  @Test
  public void log10_test_11603(double p0) {
    StrictMath.log10(p0);
  }

  @Test
  public void pow_test_11604(double p0, double p1) {
    StrictMath.pow(p0, p1);
  }

  @Test
  public void exp_test_11605(double p0) {
    StrictMath.exp(p0);
  }

  @Test
  public void min_test_11606(double p0, double p1) {
    StrictMath.min(p0, p1);
  }

  @Test
  public void min_test_11607(float p0, float p1) {
    StrictMath.min(p0, p1);
  }

  @Test
  public void min_test_11608(int p0, int p1) {
    StrictMath.min(p0, p1);
  }

  @Test
  public void min_test_11609(long p0, long p1) {
    StrictMath.min(p0, p1);
  }

  @Test
  public void max_test_11610(float p0, float p1) {
    StrictMath.max(p0, p1);
  }

  @Test
  public void max_test_11611(long p0, long p1) {
    StrictMath.max(p0, p1);
  }

  @Test
  public void max_test_11612(int p0, int p1) {
    StrictMath.max(p0, p1);
  }

  @Test
  public void max_test_11613(double p0, double p1) {
    StrictMath.max(p0, p1);
  }

  @Test
  public void floor_test_11614(double p0) {
    StrictMath.floor(p0);
  }

  @Test
  public void ceil_test_11615(double p0) {
    StrictMath.ceil(p0);
  }

  @Test
  public void rint_test_11616(double p0) {
    StrictMath.rint(p0);
  }

  @Test
  public void round_test_11617(double p0) {
    StrictMath.round(p0);
  }

  @Test
  public void round_test_11618(float p0) {
    StrictMath.round(p0);
  }

  @Test
  public void tanh_test_11619(double p0) {
    StrictMath.tanh(p0);
  }

  @Test
  public void cbrt_test_11620(double p0) {
    StrictMath.cbrt(p0);
  }

  @Test
  public void addExact_test_11621(int p0, int p1) {
    StrictMath.addExact(p0, p1);
  }

  @Test
  public void addExact_test_11622(long p0, long p1) {
    StrictMath.addExact(p0, p1);
  }

  @Test
  public void decrementExact_test_11623(long p0) {
    StrictMath.decrementExact(p0);
  }

  @Test
  public void decrementExact_test_11624(int p0) {
    StrictMath.decrementExact(p0);
  }

  @Test
  public void incrementExact_test_11625(int p0) {
    StrictMath.incrementExact(p0);
  }

  @Test
  public void incrementExact_test_11626(long p0) {
    StrictMath.incrementExact(p0);
  }

  @Test
  public void multiplyExact_test_11627(int p0, int p1) {
    StrictMath.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyExact_test_11628(long p0, int p1) {
    StrictMath.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyExact_test_11629(long p0, long p1) {
    StrictMath.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyHigh_test_11630(long p0, long p1) {
    StrictMath.multiplyHigh(p0, p1);
  }

  @Test
  public void unsignedMultiplyHigh_test_11631(long p0, long p1) {
    StrictMath.unsignedMultiplyHigh(p0, p1);
  }

  @Test
  public void negateExact_test_11632(long p0) {
    StrictMath.negateExact(p0);
  }

  @Test
  public void negateExact_test_11633(int p0) {
    StrictMath.negateExact(p0);
  }

  @Test
  public void subtractExact_test_11634(long p0, long p1) {
    StrictMath.subtractExact(p0, p1);
  }

  @Test
  public void subtractExact_test_11635(int p0, int p1) {
    StrictMath.subtractExact(p0, p1);
  }

  @Test
  public void fma_test_11636(double p0, double p1, double p2) {
    StrictMath.fma(p0, p1, p2);
  }

  @Test
  public void fma_test_11637(float p0, float p1, float p2) {
    StrictMath.fma(p0, p1, p2);
  }

  @Test
  public void copySign_test_11638(double p0, double p1) {
    StrictMath.copySign(p0, p1);
  }

  @Test
  public void copySign_test_11639(float p0, float p1) {
    StrictMath.copySign(p0, p1);
  }

  @Test
  public void signum_test_11640(double p0) {
    StrictMath.signum(p0);
  }

  @Test
  public void signum_test_11641(float p0) {
    StrictMath.signum(p0);
  }

  @Test
  public void clamp_test_11642(double p0, double p1, double p2) {
    StrictMath.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_11643(long p0, long p1, long p2) {
    StrictMath.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_11644(float p0, float p1, float p2) {
    StrictMath.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_11645(long p0, int p1, int p2) {
    StrictMath.clamp(p0, p1, p2);
  }

  @Test
  public void scalb_test_11646(double p0, int p1) {
    StrictMath.scalb(p0, p1);
  }

  @Test
  public void scalb_test_11647(float p0, int p1) {
    StrictMath.scalb(p0, p1);
  }

  @Test
  public void getExponent_test_11648(float p0) {
    StrictMath.getExponent(p0);
  }

  @Test
  public void getExponent_test_11649(double p0) {
    StrictMath.getExponent(p0);
  }

  @Test
  public void floorMod_test_11650(int p0, int p1) {
    StrictMath.floorMod(p0, p1);
  }

  @Test
  public void floorMod_test_11651(long p0, long p1) {
    StrictMath.floorMod(p0, p1);
  }

  @Test
  public void floorMod_test_11652(long p0, int p1) {
    StrictMath.floorMod(p0, p1);
  }

  @Test
  public void asin_test_11653(double p0) {
    StrictMath.asin(p0);
  }

  @Test
  public void acos_test_11654(double p0) {
    StrictMath.acos(p0);
  }

  @Test
  public void atan_test_11655(double p0) {
    StrictMath.atan(p0);
  }

  @Test
  public void IEEEremainder_test_11656(double p0, double p1) {
    StrictMath.IEEEremainder(p0, p1);
  }

  @Test
  public void floorDiv_test_11657(long p0, long p1) {
    StrictMath.floorDiv(p0, p1);
  }

  @Test
  public void floorDiv_test_11658(long p0, int p1) {
    StrictMath.floorDiv(p0, p1);
  }

  @Test
  public void floorDiv_test_11659(int p0, int p1) {
    StrictMath.floorDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_11660(long p0, int p1) {
    StrictMath.ceilDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_11661(long p0, long p1) {
    StrictMath.ceilDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_11662(int p0, int p1) {
    StrictMath.ceilDiv(p0, p1);
  }

  @Test
  public void ceilMod_test_11663(int p0, int p1) {
    StrictMath.ceilMod(p0, p1);
  }

  @Test
  public void ceilMod_test_11664(long p0, int p1) {
    StrictMath.ceilMod(p0, p1);
  }

  @Test
  public void ceilMod_test_11665(long p0, long p1) {
    StrictMath.ceilMod(p0, p1);
  }

  @Test
  public void sinh_test_11666(double p0) {
    StrictMath.sinh(p0);
  }

  @Test
  public void cosh_test_11667(double p0) {
    StrictMath.cosh(p0);
  }

  @Test
  public void hypot_test_11668(double p0, double p1) {
    StrictMath.hypot(p0, p1);
  }

  @Test
  public void expm1_test_11669(double p0) {
    StrictMath.expm1(p0);
  }

  @Test
  public void log1p_test_11670(double p0) {
    StrictMath.log1p(p0);
  }

  @Test
  public void unsignedMultiplyExact_test_11671(int p0, int p1) {
    StrictMath.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void unsignedMultiplyExact_test_11672(long p0, int p1) {
    StrictMath.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void unsignedMultiplyExact_test_11673(long p0, long p1) {
    StrictMath.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void toRadians_test_11674(double p0) {
    StrictMath.toRadians(p0);
  }

  @Test
  public void toDegrees_test_11675(double p0) {
    StrictMath.toDegrees(p0);
  }

  @Test
  public void random_test_11676() {
    StrictMath.random();
  }

  @Test
  public void divideExact_test_11677(int p0, int p1) {
    StrictMath.divideExact(p0, p1);
  }

  @Test
  public void divideExact_test_11678(long p0, long p1) {
    StrictMath.divideExact(p0, p1);
  }

  @Test
  public void floorDivExact_test_11679(int p0, int p1) {
    StrictMath.floorDivExact(p0, p1);
  }

  @Test
  public void floorDivExact_test_11680(long p0, long p1) {
    StrictMath.floorDivExact(p0, p1);
  }

  @Test
  public void ceilDivExact_test_11681(long p0, long p1) {
    StrictMath.ceilDivExact(p0, p1);
  }

  @Test
  public void ceilDivExact_test_11682(int p0, int p1) {
    StrictMath.ceilDivExact(p0, p1);
  }

  @Test
  public void toIntExact_test_11683(long p0) {
    StrictMath.toIntExact(p0);
  }

  @Test
  public void multiplyFull_test_11684(int p0, int p1) {
    StrictMath.multiplyFull(p0, p1);
  }

  @Test
  public void absExact_test_11685(long p0) {
    StrictMath.absExact(p0);
  }

  @Test
  public void absExact_test_11686(int p0) {
    StrictMath.absExact(p0);
  }

  @Test
  public void ulp_test_11687(double p0) {
    StrictMath.ulp(p0);
  }

  @Test
  public void ulp_test_11688(float p0) {
    StrictMath.ulp(p0);
  }

  @Test
  public void nextAfter_test_11689(float p0, double p1) {
    StrictMath.nextAfter(p0, p1);
  }

  @Test
  public void nextAfter_test_11690(double p0, double p1) {
    StrictMath.nextAfter(p0, p1);
  }

  @Test
  public void nextUp_test_11691(float p0) {
    StrictMath.nextUp(p0);
  }

  @Test
  public void nextUp_test_11692(double p0) {
    StrictMath.nextUp(p0);
  }

  @Test
  public void nextDown_test_11693(double p0) {
    StrictMath.nextDown(p0);
  }

  @Test
  public void nextDown_test_11694(float p0) {
    StrictMath.nextDown(p0);
  }

  @Test
  public void powExact_test_11695(long p0, int p1) {
    StrictMath.powExact(p0, p1);
  }

  @Test
  public void powExact_test_11696(int p0, int p1) {
    StrictMath.powExact(p0, p1);
  }

  @Test
  public void unsignedPowExact_test_11697(long p0, int p1) {
    StrictMath.unsignedPowExact(p0, p1);
  }

  @Test
  public void unsignedPowExact_test_11698(int p0, int p1) {
    StrictMath.unsignedPowExact(p0, p1);
  }
}
