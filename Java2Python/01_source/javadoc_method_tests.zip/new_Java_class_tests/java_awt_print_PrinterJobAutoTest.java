package generated.test;

import java.awt.print.PrinterJob;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_print_PrinterJobAutoTest {
  @Test
  public void getPrinterJob_test_10008() {
    PrinterJob.getPrinterJob();
  }

  @Test
  public void lookupPrintServices_test_10009() {
    PrinterJob.lookupPrintServices();
  }

  @Test
  public void lookupStreamPrintServices_test_10010(String p0) {
    PrinterJob.lookupStreamPrintServices(p0);
  }
}
