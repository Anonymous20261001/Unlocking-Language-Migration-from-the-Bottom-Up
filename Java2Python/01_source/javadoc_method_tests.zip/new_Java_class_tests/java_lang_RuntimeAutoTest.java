package generated.test;

import java.lang.Runtime;
import org.junit.jupiter.api.Test;

public class java_lang_RuntimeAutoTest {
  @Test
  public void getRuntime_test_10749() {
    Runtime.getRuntime();
  }

  @Test
  public void version_test_10750() {
    Runtime.version();
  }
}
