package generated.test;

import java.lang.String;
import javax.management.Notification;
import javax.management.NotificationFilterSupport;
import org.junit.jupiter.api.Test;

public class javax_management_NotificationFilterSupportAutoTest {
  @Test
  public void enableType_test_9547(String p0) {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.enableType(p0);
  }

  @Test
  public void getEnabledTypes_test_9548() {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.getEnabledTypes();
  }

  @Test
  public void disableType_test_9549(String p0) {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.disableType(p0);
  }

  @Test
  public void disableAllTypes_test_9550() {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.disableAllTypes();
  }

  @Test
  public void isNotificationEnabled_test_9551(Notification p0) {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.isNotificationEnabled(p0);
  }
}
