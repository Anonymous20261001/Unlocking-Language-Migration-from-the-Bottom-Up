package generated.test;

import java.awt.event.ActionEvent;
import java.lang.String;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_HTMLEditorKit_InsertHTMLTextActionAutoTest {
  @Test
  public void actionPerformed_test_5397(ActionEvent p0, String c0, String c1, HTML.Tag c2,
      HTML.Tag c3) {
    HTMLEditorKit.InsertHTMLTextAction instance = new HTMLEditorKit.InsertHTMLTextAction(c0, c1, c2, c3);
    instance.actionPerformed(p0);
  }
}
