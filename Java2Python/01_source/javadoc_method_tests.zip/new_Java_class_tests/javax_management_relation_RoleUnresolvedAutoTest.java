package generated.test;

import java.lang.String;
import java.util.List;
import javax.management.relation.RoleUnresolved;
import org.junit.jupiter.api.Test;

public class javax_management_relation_RoleUnresolvedAutoTest {
  @Test
  public void setRoleName_test_10670(String p0, String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.setRoleName(p0);
  }

  @Test
  public void setRoleValue_test_10671(List p0, String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.setRoleValue(p0);
  }

  @Test
  public void setProblemType_test_10672(int p0, String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.setProblemType(p0);
  }

  @Test
  public void getProblemType_test_10673(String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.getProblemType();
  }

  @Test
  public void getRoleName_test_10674(String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.getRoleName();
  }

  @Test
  public void getRoleValue_test_10675(String c0, List c1, int c2) {
    RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
    instance.getRoleValue();
  }
}
