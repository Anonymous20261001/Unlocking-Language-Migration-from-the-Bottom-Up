package generated.test;

import javax.imageio.plugins.tiff.GeoTIFFTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_GeoTIFFTagSetAutoTest {
  @Test
  public void getInstance_test_5102() {
    GeoTIFFTagSet.getInstance();
  }
}
