package generated.test;

import java.lang.String;
import java.net.ContentHandlerFactory;
import java.net.FileNameMap;
import java.net.URLConnection;
import org.junit.jupiter.api.Test;

public class java_net_URLConnectionAutoTest {
  @Test
  public void getDefaultUseCaches_test_13255(String p0) {
    URLConnection.getDefaultUseCaches(p0);
  }

  @Test
  public void getFileNameMap_test_13256() {
    URLConnection.getFileNameMap();
  }

  @Test
  public void setFileNameMap_test_13257(FileNameMap p0) {
    URLConnection.setFileNameMap(p0);
  }

  @Test
  public void setDefaultAllowUserInteraction_test_13258(boolean p0) {
    URLConnection.setDefaultAllowUserInteraction(p0);
  }

  @Test
  public void getDefaultAllowUserInteraction_test_13259() {
    URLConnection.getDefaultAllowUserInteraction();
  }

  @Test
  public void setDefaultUseCaches_test_13260(String p0, boolean p1) {
    URLConnection.setDefaultUseCaches(p0, p1);
  }

  @Test
  public void setDefaultRequestProperty_test_13261(String p0, String p1) {
    URLConnection.setDefaultRequestProperty(p0, p1);
  }

  @Test
  public void getDefaultRequestProperty_test_13262(String p0) {
    URLConnection.getDefaultRequestProperty(p0);
  }

  @Test
  public void setContentHandlerFactory_test_13263(ContentHandlerFactory p0) {
    URLConnection.setContentHandlerFactory(p0);
  }

  @Test
  public void guessContentTypeFromName_test_13264(String p0) {
    URLConnection.guessContentTypeFromName(p0);
  }
}
