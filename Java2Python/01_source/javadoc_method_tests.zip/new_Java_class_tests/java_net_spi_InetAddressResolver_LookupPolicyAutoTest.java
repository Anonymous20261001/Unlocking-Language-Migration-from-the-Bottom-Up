package generated.test;

import java.net.spi.InetAddressResolver;
import org.junit.jupiter.api.Test;

public class java_net_spi_InetAddressResolver_LookupPolicyAutoTest {
  @Test
  public void of_test_5797(int p0) {
    InetAddressResolver.LookupPolicy.of(p0);
  }
}
