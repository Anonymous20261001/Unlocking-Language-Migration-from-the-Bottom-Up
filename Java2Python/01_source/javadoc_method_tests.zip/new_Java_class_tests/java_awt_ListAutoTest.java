package generated.test;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ListAutoTest {
  @Test
  public void getRows_test_7927() {
    List instance = new List();
    instance.getRows();
  }

  @Test
  public void makeVisible_test_7928(int p0) {
    List instance = new List();
    instance.makeVisible(p0);
  }

  @Test
  public void isSelected_test_7929(int p0) {
    List instance = new List();
    instance.isSelected(p0);
  }

  @Test
  public void getPreferredSize_test_7930() {
    List instance = new List();
    instance.getPreferredSize();
  }

  @Test
  public void getPreferredSize_test_7931(int p0) {
    List instance = new List();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_7932() {
    List instance = new List();
    instance.getMinimumSize();
  }

  @Test
  public void getMinimumSize_test_7933(int p0) {
    List instance = new List();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getListeners_test_7934(Class p0) {
    List instance = new List();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_7935() {
    List instance = new List();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_7936() {
    List instance = new List();
    instance.removeNotify();
  }

  @Test
  public void preferredSize_test_7937(int p0) {
    List instance = new List();
    instance.preferredSize(p0);
  }

  @Test
  public void preferredSize_test_7938() {
    List instance = new List();
    instance.preferredSize();
  }

  @Test
  public void minimumSize_test_7939(int p0) {
    List instance = new List();
    instance.minimumSize(p0);
  }

  @Test
  public void minimumSize_test_7940() {
    List instance = new List();
    instance.minimumSize();
  }

  @Test
  public void getAccessibleContext_test_7941() {
    List instance = new List();
    instance.getAccessibleContext();
  }

  @Test
  public void removeActionListener_test_7942(ActionListener p0) {
    List instance = new List();
    instance.removeActionListener(p0);
  }

  @Test
  public void addActionListener_test_7943(ActionListener p0) {
    List instance = new List();
    instance.addActionListener(p0);
  }

  @Test
  public void removeItemListener_test_7944(ItemListener p0) {
    List instance = new List();
    instance.removeItemListener(p0);
  }

  @Test
  public void addItemListener_test_7945(ItemListener p0) {
    List instance = new List();
    instance.addItemListener(p0);
  }

  @Test
  public void getActionListeners_test_7946() {
    List instance = new List();
    instance.getActionListeners();
  }

  @Test
  public void getItemListeners_test_7947() {
    List instance = new List();
    instance.getItemListeners();
  }

  @Test
  public void getSelectedObjects_test_7948() {
    List instance = new List();
    instance.getSelectedObjects();
  }

  @Test
  public void getItem_test_7949(int p0) {
    List instance = new List();
    instance.getItem(p0);
  }

  @Test
  public void select_test_7950(int p0) {
    List instance = new List();
    instance.select(p0);
  }

  @Test
  public void countItems_test_7951() {
    List instance = new List();
    instance.countItems();
  }

  @Test
  public void getSelectedIndexes_test_7952() {
    List instance = new List();
    instance.getSelectedIndexes();
  }

  @Test
  public void delItems_test_7953(int p0, int p1) {
    List instance = new List();
    instance.delItems(p0, p1);
  }

  @Test
  public void getSelectedItems_test_7954() {
    List instance = new List();
    instance.getSelectedItems();
  }

  @Test
  public void deselect_test_7955(int p0) {
    List instance = new List();
    instance.deselect(p0);
  }

  @Test
  public void allowsMultipleSelections_test_7956() {
    List instance = new List();
    instance.allowsMultipleSelections();
  }

  @Test
  public void setMultipleSelections_test_7957(boolean p0) {
    List instance = new List();
    instance.setMultipleSelections(p0);
  }

  @Test
  public void getItems_test_7958() {
    List instance = new List();
    instance.getItems();
  }

  @Test
  public void replaceItem_test_7959(String p0, int p1) {
    List instance = new List();
    instance.replaceItem(p0, p1);
  }

  @Test
  public void isIndexSelected_test_7960(int p0) {
    List instance = new List();
    instance.isIndexSelected(p0);
  }

  @Test
  public void getVisibleIndex_test_7961() {
    List instance = new List();
    instance.getVisibleIndex();
  }

  @Test
  public void setMultipleMode_test_7962(boolean p0) {
    List instance = new List();
    instance.setMultipleMode(p0);
  }

  @Test
  public void isMultipleMode_test_7963() {
    List instance = new List();
    instance.isMultipleMode();
  }

  @Test
  public void getSelectedIndex_test_7964() {
    List instance = new List();
    instance.getSelectedIndex();
  }

  @Test
  public void getSelectedItem_test_7965() {
    List instance = new List();
    instance.getSelectedItem();
  }

  @Test
  public void addItem_test_7966(String p0, int p1) {
    List instance = new List();
    instance.addItem(p0, p1);
  }

  @Test
  public void addItem_test_7967(String p0) {
    List instance = new List();
    instance.addItem(p0);
  }

  @Test
  public void getItemCount_test_7968() {
    List instance = new List();
    instance.getItemCount();
  }

  @Test
  public void delItem_test_7969(int p0) {
    List instance = new List();
    instance.delItem(p0);
  }

  @Test
  public void remove_test_7970(String p0) {
    List instance = new List();
    instance.remove(p0);
  }

  @Test
  public void remove_test_7971(int p0) {
    List instance = new List();
    instance.remove(p0);
  }

  @Test
  public void clear_test_7972() {
    List instance = new List();
    instance.clear();
  }

  @Test
  public void add_test_7973(String p0) {
    List instance = new List();
    instance.add(p0);
  }

  @Test
  public void add_test_7974(String p0, int p1) {
    List instance = new List();
    instance.add(p0, p1);
  }

  @Test
  public void removeAll_test_7975() {
    List instance = new List();
    instance.removeAll();
  }
}
