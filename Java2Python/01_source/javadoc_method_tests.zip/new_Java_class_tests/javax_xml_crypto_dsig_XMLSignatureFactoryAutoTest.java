package generated.test;

import java.lang.String;
import java.security.Provider;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_crypto_dsig_XMLSignatureFactoryAutoTest {
  @Test
  public void getInstance_test_13648(String p0) {
    XMLSignatureFactory.getInstance(p0);
  }

  @Test
  public void getInstance_test_13649(String p0, Provider p1) {
    XMLSignatureFactory.getInstance(p0, p1);
  }

  @Test
  public void getInstance_test_13650() {
    XMLSignatureFactory.getInstance();
  }
}
