package generated.test;

import javax.management.openmbean.CompositeData;
import jdk.management.jfr.EventTypeInfo;
import org.junit.jupiter.api.Test;

public class jdk_management_jfr_EventTypeInfoAutoTest {
  @Test
  public void from_test_4605(CompositeData p0) {
    EventTypeInfo.from(p0);
  }
}
