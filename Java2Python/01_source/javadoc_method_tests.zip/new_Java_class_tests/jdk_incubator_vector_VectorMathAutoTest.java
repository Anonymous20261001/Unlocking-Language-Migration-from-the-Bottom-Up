package generated.test;

import jdk.incubator.vector.VectorMath;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_VectorMathAutoTest {
  @Test
  public void maxUnsigned_test_13387(int p0, int p1) {
    VectorMath.maxUnsigned(p0, p1);
  }

  @Test
  public void maxUnsigned_test_13388(short p0, short p1) {
    VectorMath.maxUnsigned(p0, p1);
  }

  @Test
  public void maxUnsigned_test_13389(long p0, long p1) {
    VectorMath.maxUnsigned(p0, p1);
  }

  @Test
  public void maxUnsigned_test_13390(byte p0, byte p1) {
    VectorMath.maxUnsigned(p0, p1);
  }

  @Test
  public void minUnsigned_test_13391(int p0, int p1) {
    VectorMath.minUnsigned(p0, p1);
  }

  @Test
  public void minUnsigned_test_13392(short p0, short p1) {
    VectorMath.minUnsigned(p0, p1);
  }

  @Test
  public void minUnsigned_test_13393(byte p0, byte p1) {
    VectorMath.minUnsigned(p0, p1);
  }

  @Test
  public void minUnsigned_test_13394(long p0, long p1) {
    VectorMath.minUnsigned(p0, p1);
  }

  @Test
  public void subSaturatingUnsigned_test_13395(short p0, short p1) {
    VectorMath.subSaturatingUnsigned(p0, p1);
  }

  @Test
  public void subSaturatingUnsigned_test_13396(byte p0, byte p1) {
    VectorMath.subSaturatingUnsigned(p0, p1);
  }

  @Test
  public void subSaturatingUnsigned_test_13397(int p0, int p1) {
    VectorMath.subSaturatingUnsigned(p0, p1);
  }

  @Test
  public void subSaturatingUnsigned_test_13398(long p0, long p1) {
    VectorMath.subSaturatingUnsigned(p0, p1);
  }

  @Test
  public void addSaturatingUnsigned_test_13399(long p0, long p1) {
    VectorMath.addSaturatingUnsigned(p0, p1);
  }

  @Test
  public void addSaturatingUnsigned_test_13400(short p0, short p1) {
    VectorMath.addSaturatingUnsigned(p0, p1);
  }

  @Test
  public void addSaturatingUnsigned_test_13401(int p0, int p1) {
    VectorMath.addSaturatingUnsigned(p0, p1);
  }

  @Test
  public void addSaturatingUnsigned_test_13402(byte p0, byte p1) {
    VectorMath.addSaturatingUnsigned(p0, p1);
  }

  @Test
  public void subSaturating_test_13403(long p0, long p1) {
    VectorMath.subSaturating(p0, p1);
  }

  @Test
  public void subSaturating_test_13404(byte p0, byte p1) {
    VectorMath.subSaturating(p0, p1);
  }

  @Test
  public void subSaturating_test_13405(short p0, short p1) {
    VectorMath.subSaturating(p0, p1);
  }

  @Test
  public void subSaturating_test_13406(int p0, int p1) {
    VectorMath.subSaturating(p0, p1);
  }

  @Test
  public void addSaturating_test_13407(int p0, int p1) {
    VectorMath.addSaturating(p0, p1);
  }

  @Test
  public void addSaturating_test_13408(short p0, short p1) {
    VectorMath.addSaturating(p0, p1);
  }

  @Test
  public void addSaturating_test_13409(byte p0, byte p1) {
    VectorMath.addSaturating(p0, p1);
  }

  @Test
  public void addSaturating_test_13410(long p0, long p1) {
    VectorMath.addSaturating(p0, p1);
  }
}
