package generated.test;

import java.awt.AWTEventMulticaster;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerListener;
import java.awt.event.FocusListener;
import java.awt.event.HierarchyBoundsListener;
import java.awt.event.HierarchyListener;
import java.awt.event.InputMethodListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;
import java.awt.event.TextListener;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.lang.Class;
import java.util.EventListener;
import org.junit.jupiter.api.Test;

public class java_awt_AWTEventMulticasterAutoTest {
  @Test
  public void getListeners_test_911(EventListener p0, Class p1) {
    AWTEventMulticaster.getListeners(p0, p1);
  }

  @Test
  public void remove_test_912(MouseMotionListener p0, MouseMotionListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_913(HierarchyListener p0, HierarchyListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_914(WindowListener p0, WindowListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_915(MouseListener p0, MouseListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_916(KeyListener p0, KeyListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_917(FocusListener p0, FocusListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_918(InputMethodListener p0, InputMethodListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_919(TextListener p0, TextListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_920(AdjustmentListener p0, AdjustmentListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_921(ItemListener p0, ItemListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_922(ActionListener p0, ActionListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_923(WindowFocusListener p0, WindowFocusListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_924(WindowStateListener p0, WindowStateListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_925(MouseWheelListener p0, MouseWheelListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_926(ContainerListener p0, ContainerListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_927(ComponentListener p0, ComponentListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void remove_test_928(HierarchyBoundsListener p0, HierarchyBoundsListener p1) {
    AWTEventMulticaster.remove(p0, p1);
  }

  @Test
  public void add_test_929(ComponentListener p0, ComponentListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_930(ContainerListener p0, ContainerListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_931(KeyListener p0, KeyListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_932(FocusListener p0, FocusListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_933(MouseListener p0, MouseListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_934(MouseMotionListener p0, MouseMotionListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_935(TextListener p0, TextListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_936(AdjustmentListener p0, AdjustmentListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_937(ItemListener p0, ItemListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_938(ActionListener p0, ActionListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_939(WindowFocusListener p0, WindowFocusListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_940(WindowStateListener p0, WindowStateListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_941(WindowListener p0, WindowListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_942(MouseWheelListener p0, MouseWheelListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_943(HierarchyBoundsListener p0, HierarchyBoundsListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_944(HierarchyListener p0, HierarchyListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }

  @Test
  public void add_test_945(InputMethodListener p0, InputMethodListener p1) {
    AWTEventMulticaster.add(p0, p1);
  }
}
