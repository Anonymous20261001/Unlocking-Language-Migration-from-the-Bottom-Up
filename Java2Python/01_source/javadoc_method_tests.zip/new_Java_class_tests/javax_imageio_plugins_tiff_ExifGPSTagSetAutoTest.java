package generated.test;

import javax.imageio.plugins.tiff.ExifGPSTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_ExifGPSTagSetAutoTest {
  @Test
  public void getInstance_test_4661() {
    ExifGPSTagSet.getInstance();
  }
}
