package generated.test;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ColorAutoTest {
  @Test
  public void getComponents_test_2468(ColorSpace p0, float[] p1, int c0) {
    Color instance = new Color(c0);
    instance.getComponents(p0, p1);
  }

  @Test
  public void getComponents_test_2469(float[] p0, int c0) {
    Color instance = new Color(c0);
    instance.getComponents(p0);
  }

  @Test
  public void getColor_test_2470(String p0, Color p1) {
    Color.getColor(p0, p1);
  }

  @Test
  public void getColor_test_2471(String p0) {
    Color.getColor(p0);
  }

  @Test
  public void getColor_test_2472(String p0, int p1) {
    Color.getColor(p0, p1);
  }

  @Test
  public void brighter_test_2473(int c0) {
    Color instance = new Color(c0);
    instance.brighter();
  }

  @Test
  public void darker_test_2474(int c0) {
    Color instance = new Color(c0);
    instance.darker();
  }

  @Test
  public void getRGB_test_2475(int c0) {
    Color instance = new Color(c0);
    instance.getRGB();
  }

  @Test
  public void getRed_test_2476(int c0) {
    Color instance = new Color(c0);
    instance.getRed();
  }

  @Test
  public void getGreen_test_2477(int c0) {
    Color instance = new Color(c0);
    instance.getGreen();
  }

  @Test
  public void getBlue_test_2478(int c0) {
    Color instance = new Color(c0);
    instance.getBlue();
  }

  @Test
  public void getAlpha_test_2479(int c0) {
    Color instance = new Color(c0);
    instance.getAlpha();
  }

  @Test
  public void HSBtoRGB_test_2480(float p0, float p1, float p2) {
    Color.HSBtoRGB(p0, p1, p2);
  }

  @Test
  public void getRGBComponents_test_2481(float[] p0, int c0) {
    Color instance = new Color(c0);
    instance.getRGBComponents(p0);
  }

  @Test
  public void getRGBColorComponents_test_2482(float[] p0, int c0) {
    Color instance = new Color(c0);
    instance.getRGBColorComponents(p0);
  }

  @Test
  public void RGBtoHSB_test_2483(int p0, int p1, int p2, float[] p3) {
    Color.RGBtoHSB(p0, p1, p2, p3);
  }

  @Test
  public void getHSBColor_test_2484(float p0, float p1, float p2) {
    Color.getHSBColor(p0, p1, p2);
  }

  @Test
  public void getColorComponents_test_2485(float[] p0, int c0) {
    Color instance = new Color(c0);
    instance.getColorComponents(p0);
  }

  @Test
  public void getColorComponents_test_2486(ColorSpace p0, float[] p1, int c0) {
    Color instance = new Color(c0);
    instance.getColorComponents(p0, p1);
  }

  @Test
  public void getColorSpace_test_2487(int c0) {
    Color instance = new Color(c0);
    instance.getColorSpace();
  }

  @Test
  public void createContext_test_2488(ColorModel p0, Rectangle p1, Rectangle2D p2,
      AffineTransform p3, RenderingHints p4, int c0) {
    Color instance = new Color(c0);
    instance.createContext(p0, p1, p2, p3, p4);
  }

  @Test
  public void getTransparency_test_2489(int c0) {
    Color instance = new Color(c0);
    instance.getTransparency();
  }

  @Test
  public void decode_test_2490(String p0) {
    Color.decode(p0);
  }
}
