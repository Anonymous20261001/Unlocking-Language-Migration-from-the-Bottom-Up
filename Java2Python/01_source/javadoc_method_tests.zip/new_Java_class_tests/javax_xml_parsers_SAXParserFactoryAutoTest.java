package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.parsers.SAXParserFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_parsers_SAXParserFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_10762() {
    SAXParserFactory.newDefaultInstance();
  }

  @Test
  public void newDefaultNSInstance_test_10763() {
    SAXParserFactory.newDefaultNSInstance();
  }

  @Test
  public void newNSInstance_test_10764() {
    SAXParserFactory.newNSInstance();
  }

  @Test
  public void newNSInstance_test_10765(String p0, ClassLoader p1) {
    SAXParserFactory.newNSInstance(p0, p1);
  }

  @Test
  public void newInstance_test_10766(String p0, ClassLoader p1) {
    SAXParserFactory.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_10767() {
    SAXParserFactory.newInstance();
  }
}
