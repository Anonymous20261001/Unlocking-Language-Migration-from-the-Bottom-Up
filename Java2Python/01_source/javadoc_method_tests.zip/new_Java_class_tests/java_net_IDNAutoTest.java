package generated.test;

import java.lang.String;
import java.net.IDN;
import org.junit.jupiter.api.Test;

public class java_net_IDNAutoTest {
  @Test
  public void toASCII_test_5533(String p0, int p1) {
    IDN.toASCII(p0, p1);
  }

  @Test
  public void toASCII_test_5534(String p0) {
    IDN.toASCII(p0);
  }

  @Test
  public void toUnicode_test_5535(String p0) {
    IDN.toUnicode(p0);
  }

  @Test
  public void toUnicode_test_5536(String p0, int p1) {
    IDN.toUnicode(p0, p1);
  }
}
