package generated.test;

import java.lang.Class;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.invoke.SwitchPoint;
import java.util.List;
import jdk.dynalink.CallSiteDescriptor;
import jdk.dynalink.linker.GuardedInvocation;
import jdk.dynalink.linker.LinkerServices;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_GuardedInvocationAutoTest {
  @Test
  public void getException_test_5231(MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.getException();
  }

  @Test
  public void asType_test_5232(LinkerServices p0, MethodType p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.asType(p0, p1);
  }

  @Test
  public void asType_test_5233(MethodType p0, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.asType(p0);
  }

  @Test
  public void asType_test_5234(CallSiteDescriptor p0, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.asType(p0);
  }

  @Test
  public void compose_test_5235(MethodHandle p0, MethodHandle p1, MethodHandle p2,
      MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.compose(p0, p1, p2);
  }

  @Test
  public void compose_test_5236(MethodHandle p0, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.compose(p0);
  }

  @Test
  public void dropArguments_test_5237(int p0, Class[] p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.dropArguments(p0, p1);
  }

  @Test
  public void dropArguments_test_5238(int p0, List p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.dropArguments(p0, p1);
  }

  @Test
  public void filterArguments_test_5239(int p0, MethodHandle[] p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.filterArguments(p0, p1);
  }

  @Test
  public void hasBeenInvalidated_test_5240(MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.hasBeenInvalidated();
  }

  @Test
  public void replaceMethods_test_5241(MethodHandle p0, MethodHandle p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.replaceMethods(p0, p1);
  }

  @Test
  public void getInvocation_test_5242(MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.getInvocation();
  }

  @Test
  public void getGuard_test_5243(MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.getGuard();
  }

  @Test
  public void getSwitchPoints_test_5244(MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.getSwitchPoints();
  }

  @Test
  public void addSwitchPoint_test_5245(SwitchPoint p0, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.addSwitchPoint(p0);
  }

  @Test
  public void asTypeSafeReturn_test_5246(LinkerServices p0, MethodType p1, MethodHandle c0) {
    GuardedInvocation instance = new GuardedInvocation(c0);
    instance.asTypeSafeReturn(p0, p1);
  }
}
