package generated.test;

import javax.net.ssl.SSLContext;
import org.junit.jupiter.api.Test;

public class javax_net_ssl_SSLContextAutoTest {
  @Test
  public void setDefault_test_11400(SSLContext p0) {
    SSLContext.setDefault(p0);
  }
}
