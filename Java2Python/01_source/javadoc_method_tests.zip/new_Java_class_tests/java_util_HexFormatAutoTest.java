package generated.test;

import java.lang.CharSequence;
import java.lang.String;
import java.util.HexFormat;
import org.junit.jupiter.api.Test;

public class java_util_HexFormatAutoTest {
  @Test
  public void of_test_5337() {
    HexFormat.of();
  }

  @Test
  public void fromHexDigits_test_5338(CharSequence p0) {
    HexFormat.fromHexDigits(p0);
  }

  @Test
  public void fromHexDigits_test_5339(CharSequence p0, int p1, int p2) {
    HexFormat.fromHexDigits(p0, p1, p2);
  }

  @Test
  public void fromHexDigit_test_5340(int p0) {
    HexFormat.fromHexDigit(p0);
  }

  @Test
  public void fromHexDigitsToLong_test_5341(CharSequence p0, int p1, int p2) {
    HexFormat.fromHexDigitsToLong(p0, p1, p2);
  }

  @Test
  public void fromHexDigitsToLong_test_5342(CharSequence p0) {
    HexFormat.fromHexDigitsToLong(p0);
  }

  @Test
  public void ofDelimiter_test_5343(String p0) {
    HexFormat.ofDelimiter(p0);
  }

  @Test
  public void isHexDigit_test_5344(int p0) {
    HexFormat.isHexDigit(p0);
  }
}
