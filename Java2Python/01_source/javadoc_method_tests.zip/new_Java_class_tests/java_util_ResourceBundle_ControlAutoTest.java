package generated.test;

import java.util.List;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class java_util_ResourceBundle_ControlAutoTest {
  @Test
  public void getControl_test_10620(List p0) {
    ResourceBundle.Control.getControl(p0);
  }

  @Test
  public void getNoFallbackControl_test_10621(List p0) {
    ResourceBundle.Control.getNoFallbackControl(p0);
  }
}
