package generated.test;

import java.util.logging.LogManager;
import org.junit.jupiter.api.Test;

public class java_util_logging_LogManagerAutoTest {
  @Test
  public void getLogManager_test_8109() {
    LogManager.getLogManager();
  }

  @Test
  public void getLoggingMXBean_test_8110() {
    LogManager.getLoggingMXBean();
  }
}
