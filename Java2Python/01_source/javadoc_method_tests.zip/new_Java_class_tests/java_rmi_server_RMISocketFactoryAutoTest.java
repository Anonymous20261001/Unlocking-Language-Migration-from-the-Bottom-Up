package generated.test;

import java.rmi.server.RMIFailureHandler;
import java.rmi.server.RMISocketFactory;
import org.junit.jupiter.api.Test;

public class java_rmi_server_RMISocketFactoryAutoTest {
  @Test
  public void getSocketFactory_test_10636() {
    RMISocketFactory.getSocketFactory();
  }

  @Test
  public void getDefaultSocketFactory_test_10637() {
    RMISocketFactory.getDefaultSocketFactory();
  }

  @Test
  public void setFailureHandler_test_10638(RMIFailureHandler p0) {
    RMISocketFactory.setFailureHandler(p0);
  }

  @Test
  public void getFailureHandler_test_10639() {
    RMISocketFactory.getFailureHandler();
  }
}
