package generated.test;

import java.lang.Object;
import java.lang.Thread;
import java.util.concurrent.locks.LockSupport;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_locks_LockSupportAutoTest {
  @Test
  public void park_test_8095() {
    LockSupport.park();
  }

  @Test
  public void park_test_8096(Object p0) {
    LockSupport.park(p0);
  }

  @Test
  public void unpark_test_8097(Thread p0) {
    LockSupport.unpark(p0);
  }

  @Test
  public void parkNanos_test_8098(long p0) {
    LockSupport.parkNanos(p0);
  }

  @Test
  public void parkNanos_test_8099(Object p0, long p1) {
    LockSupport.parkNanos(p0, p1);
  }

  @Test
  public void parkUntil_test_8100(long p0) {
    LockSupport.parkUntil(p0);
  }

  @Test
  public void parkUntil_test_8101(Object p0, long p1) {
    LockSupport.parkUntil(p0, p1);
  }

  @Test
  public void setCurrentBlocker_test_8102(Object p0) {
    LockSupport.setCurrentBlocker(p0);
  }

  @Test
  public void getBlocker_test_8103(Thread p0) {
    LockSupport.getBlocker(p0);
  }
}
