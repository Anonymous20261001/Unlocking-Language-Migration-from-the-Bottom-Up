package generated.test;

import java.lang.String;
import java.net.InetAddress;
import org.junit.jupiter.api.Test;

public class java_net_InetAddressAutoTest {
  @Test
  public void ofLiteral_test_5795(String p0) {
    InetAddress.ofLiteral(p0);
  }

  @Test
  public void getLoopbackAddress_test_5796() {
    InetAddress.getLoopbackAddress();
  }
}
