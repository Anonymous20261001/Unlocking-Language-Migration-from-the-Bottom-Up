package generated.test;

import java.nio.file.attribute.AclEntry;
import org.junit.jupiter.api.Test;

public class java_nio_file_attribute_AclEntryAutoTest {
  @Test
  public void newBuilder_test_55(AclEntry p0) {
    AclEntry.newBuilder(p0);
  }

  @Test
  public void newBuilder_test_56() {
    AclEntry.newBuilder();
  }
}
