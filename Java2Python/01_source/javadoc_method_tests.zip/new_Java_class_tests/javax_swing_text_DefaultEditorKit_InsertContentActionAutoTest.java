package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_InsertContentActionAutoTest {
  @Test
  public void actionPerformed_test_3674(ActionEvent p0) {
    DefaultEditorKit.InsertContentAction instance = new DefaultEditorKit.InsertContentAction();
    instance.actionPerformed(p0);
  }
}
