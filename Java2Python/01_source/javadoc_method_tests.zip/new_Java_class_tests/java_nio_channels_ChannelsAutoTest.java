package generated.test;

import java.io.InputStream;
import java.io.OutputStream;
import java.lang.String;
import java.nio.channels.AsynchronousByteChannel;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import org.junit.jupiter.api.Test;

public class java_nio_channels_ChannelsAutoTest {
  @Test
  public void newReader_test_2112(ReadableByteChannel p0, CharsetDecoder p1, int p2) {
    Channels.newReader(p0, p1, p2);
  }

  @Test
  public void newReader_test_2113(ReadableByteChannel p0, Charset p1) {
    Channels.newReader(p0, p1);
  }

  @Test
  public void newReader_test_2114(ReadableByteChannel p0, String p1) {
    Channels.newReader(p0, p1);
  }

  @Test
  public void newOutputStream_test_2115(AsynchronousByteChannel p0) {
    Channels.newOutputStream(p0);
  }

  @Test
  public void newOutputStream_test_2116(WritableByteChannel p0) {
    Channels.newOutputStream(p0);
  }

  @Test
  public void newWriter_test_2117(WritableByteChannel p0, CharsetEncoder p1, int p2) {
    Channels.newWriter(p0, p1, p2);
  }

  @Test
  public void newWriter_test_2118(WritableByteChannel p0, String p1) {
    Channels.newWriter(p0, p1);
  }

  @Test
  public void newWriter_test_2119(WritableByteChannel p0, Charset p1) {
    Channels.newWriter(p0, p1);
  }

  @Test
  public void newInputStream_test_2120(ReadableByteChannel p0) {
    Channels.newInputStream(p0);
  }

  @Test
  public void newInputStream_test_2121(AsynchronousByteChannel p0) {
    Channels.newInputStream(p0);
  }

  @Test
  public void newChannel_test_2122(InputStream p0) {
    Channels.newChannel(p0);
  }

  @Test
  public void newChannel_test_2123(OutputStream p0) {
    Channels.newChannel(p0);
  }
}
