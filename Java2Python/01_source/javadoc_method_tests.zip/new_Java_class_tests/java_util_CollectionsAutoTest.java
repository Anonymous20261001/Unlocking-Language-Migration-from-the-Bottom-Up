package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Queue;
import java.util.Random;
import java.util.SequencedCollection;
import java.util.SequencedMap;
import java.util.SequencedSet;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.random.RandomGenerator;
import org.junit.jupiter.api.Test;

public class java_util_CollectionsAutoTest {
  @Test
  public void min_test_2353(Collection p0, Comparator p1) {
    Collections.min(p0, p1);
  }

  @Test
  public void min_test_2354(Collection p0) {
    Collections.min(p0);
  }

  @Test
  public void max_test_2355(Collection p0) {
    Collections.max(p0);
  }

  @Test
  public void max_test_2356(Collection p0, Comparator p1) {
    Collections.max(p0, p1);
  }

  @Test
  public void reverse_test_2357(List p0) {
    Collections.reverse(p0);
  }

  @Test
  public void sort_test_2358(List p0) {
    Collections.sort(p0);
  }

  @Test
  public void sort_test_2359(List p0, Comparator p1) {
    Collections.sort(p0, p1);
  }

  @Test
  public void copy_test_2360(List p0, List p1) {
    Collections.copy(p0, p1);
  }

  @Test
  public void replaceAll_test_2361(List p0, Object p1, Object p2) {
    Collections.replaceAll(p0, p1, p2);
  }

  @Test
  public void fill_test_2362(List p0, Object p1) {
    Collections.fill(p0, p1);
  }

  @Test
  public void list_test_2363(Enumeration p0) {
    Collections.list(p0);
  }

  @Test
  public void addAll_test_2364(Collection p0, Object[] p1) {
    Collections.addAll(p0, p1);
  }

  @Test
  public void emptyEnumeration_test_2365() {
    Collections.emptyEnumeration();
  }

  @Test
  public void newSetFromMap_test_2366(Map p0) {
    Collections.newSetFromMap(p0);
  }

  @Test
  public void emptyList_test_2367() {
    Collections.emptyList();
  }

  @Test
  public void unmodifiableSet_test_2368(Set p0) {
    Collections.unmodifiableSet(p0);
  }

  @Test
  public void enumeration_test_2369(Collection p0) {
    Collections.enumeration(p0);
  }

  @Test
  public void synchronizedSet_test_2370(Set p0) {
    Collections.synchronizedSet(p0);
  }

  @Test
  public void synchronizedCollection_test_2371(Collection p0) {
    Collections.synchronizedCollection(p0);
  }

  @Test
  public void emptyIterator_test_2372() {
    Collections.emptyIterator();
  }

  @Test
  public void nCopies_test_2373(int p0, Object p1) {
    Collections.nCopies(p0, p1);
  }

  @Test
  public void reverseOrder_test_2374(Comparator p0) {
    Collections.reverseOrder(p0);
  }

  @Test
  public void reverseOrder_test_2375() {
    Collections.reverseOrder();
  }

  @Test
  public void unmodifiableMap_test_2376(Map p0) {
    Collections.unmodifiableMap(p0);
  }

  @Test
  public void unmodifiableSortedMap_test_2377(SortedMap p0) {
    Collections.unmodifiableSortedMap(p0);
  }

  @Test
  public void swap_test_2378(List p0, int p1, int p2) {
    Collections.swap(p0, p1, p2);
  }

  @Test
  public void binarySearch_test_2379(List p0, Object p1, Comparator p2) {
    Collections.binarySearch(p0, p1, p2);
  }

  @Test
  public void binarySearch_test_2380(List p0, Object p1) {
    Collections.binarySearch(p0, p1);
  }

  @Test
  public void shuffle_test_2381(List p0, Random p1) {
    Collections.shuffle(p0, p1);
  }

  @Test
  public void shuffle_test_2382(List p0) {
    Collections.shuffle(p0);
  }

  @Test
  public void shuffle_test_2383(List p0, RandomGenerator p1) {
    Collections.shuffle(p0, p1);
  }

  @Test
  public void rotate_test_2384(List p0, int p1) {
    Collections.rotate(p0, p1);
  }

  @Test
  public void indexOfSubList_test_2385(List p0, List p1) {
    Collections.indexOfSubList(p0, p1);
  }

  @Test
  public void lastIndexOfSubList_test_2386(List p0, List p1) {
    Collections.lastIndexOfSubList(p0, p1);
  }

  @Test
  public void unmodifiableCollection_test_2387(Collection p0) {
    Collections.unmodifiableCollection(p0);
  }

  @Test
  public void unmodifiableSequencedCollection_test_2388(SequencedCollection p0) {
    Collections.unmodifiableSequencedCollection(p0);
  }

  @Test
  public void unmodifiableSequencedSet_test_2389(SequencedSet p0) {
    Collections.unmodifiableSequencedSet(p0);
  }

  @Test
  public void unmodifiableSortedSet_test_2390(SortedSet p0) {
    Collections.unmodifiableSortedSet(p0);
  }

  @Test
  public void unmodifiableNavigableSet_test_2391(NavigableSet p0) {
    Collections.unmodifiableNavigableSet(p0);
  }

  @Test
  public void unmodifiableList_test_2392(List p0) {
    Collections.unmodifiableList(p0);
  }

  @Test
  public void unmodifiableSequencedMap_test_2393(SequencedMap p0) {
    Collections.unmodifiableSequencedMap(p0);
  }

  @Test
  public void unmodifiableNavigableMap_test_2394(NavigableMap p0) {
    Collections.unmodifiableNavigableMap(p0);
  }

  @Test
  public void synchronizedSortedSet_test_2395(SortedSet p0) {
    Collections.synchronizedSortedSet(p0);
  }

  @Test
  public void synchronizedNavigableSet_test_2396(NavigableSet p0) {
    Collections.synchronizedNavigableSet(p0);
  }

  @Test
  public void synchronizedList_test_2397(List p0) {
    Collections.synchronizedList(p0);
  }

  @Test
  public void synchronizedMap_test_2398(Map p0) {
    Collections.synchronizedMap(p0);
  }

  @Test
  public void synchronizedSortedMap_test_2399(SortedMap p0) {
    Collections.synchronizedSortedMap(p0);
  }

  @Test
  public void synchronizedNavigableMap_test_2400(NavigableMap p0) {
    Collections.synchronizedNavigableMap(p0);
  }

  @Test
  public void checkedCollection_test_2401(Collection p0, Class p1) {
    Collections.checkedCollection(p0, p1);
  }

  @Test
  public void checkedQueue_test_2402(Queue p0, Class p1) {
    Collections.checkedQueue(p0, p1);
  }

  @Test
  public void checkedSet_test_2403(Set p0, Class p1) {
    Collections.checkedSet(p0, p1);
  }

  @Test
  public void checkedSortedSet_test_2404(SortedSet p0, Class p1) {
    Collections.checkedSortedSet(p0, p1);
  }

  @Test
  public void checkedNavigableSet_test_2405(NavigableSet p0, Class p1) {
    Collections.checkedNavigableSet(p0, p1);
  }

  @Test
  public void checkedList_test_2406(List p0, Class p1) {
    Collections.checkedList(p0, p1);
  }

  @Test
  public void checkedMap_test_2407(Map p0, Class p1, Class p2) {
    Collections.checkedMap(p0, p1, p2);
  }

  @Test
  public void checkedSortedMap_test_2408(SortedMap p0, Class p1, Class p2) {
    Collections.checkedSortedMap(p0, p1, p2);
  }

  @Test
  public void checkedNavigableMap_test_2409(NavigableMap p0, Class p1, Class p2) {
    Collections.checkedNavigableMap(p0, p1, p2);
  }

  @Test
  public void emptyListIterator_test_2410() {
    Collections.emptyListIterator();
  }

  @Test
  public void emptySet_test_2411() {
    Collections.emptySet();
  }

  @Test
  public void emptySortedSet_test_2412() {
    Collections.emptySortedSet();
  }

  @Test
  public void emptyNavigableSet_test_2413() {
    Collections.emptyNavigableSet();
  }

  @Test
  public void emptyMap_test_2414() {
    Collections.emptyMap();
  }

  @Test
  public void emptySortedMap_test_2415() {
    Collections.emptySortedMap();
  }

  @Test
  public void emptyNavigableMap_test_2416() {
    Collections.emptyNavigableMap();
  }

  @Test
  public void singleton_test_2417(Object p0) {
    Collections.singleton(p0);
  }

  @Test
  public void singletonList_test_2418(Object p0) {
    Collections.singletonList(p0);
  }

  @Test
  public void singletonMap_test_2419(Object p0, Object p1) {
    Collections.singletonMap(p0, p1);
  }

  @Test
  public void frequency_test_2420(Collection p0, Object p1) {
    Collections.frequency(p0, p1);
  }

  @Test
  public void disjoint_test_2421(Collection p0, Collection p1) {
    Collections.disjoint(p0, p1);
  }

  @Test
  public void newSequencedSetFromMap_test_2422(SequencedMap p0) {
    Collections.newSequencedSetFromMap(p0);
  }

  @Test
  public void asLifoQueue_test_2423(Deque p0) {
    Collections.asLifoQueue(p0);
  }
}
