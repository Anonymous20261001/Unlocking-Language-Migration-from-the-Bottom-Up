package generated.test;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageTypeSpecifier;
import org.junit.jupiter.api.Test;

public class javax_imageio_ImageReadParamAutoTest {
  @Test
  public void getDestinationBands_test_5680() {
    ImageReadParam instance = new ImageReadParam();
    instance.getDestinationBands();
  }

  @Test
  public void getDestination_test_5681() {
    ImageReadParam instance = new ImageReadParam();
    instance.getDestination();
  }

  @Test
  public void setDestination_test_5682(BufferedImage p0) {
    ImageReadParam instance = new ImageReadParam();
    instance.setDestination(p0);
  }

  @Test
  public void canSetSourceRenderSize_test_5683() {
    ImageReadParam instance = new ImageReadParam();
    instance.canSetSourceRenderSize();
  }

  @Test
  public void setDestinationBands_test_5684(int[] p0) {
    ImageReadParam instance = new ImageReadParam();
    instance.setDestinationBands(p0);
  }

  @Test
  public void setSourceRenderSize_test_5685(Dimension p0) {
    ImageReadParam instance = new ImageReadParam();
    instance.setSourceRenderSize(p0);
  }

  @Test
  public void getSourceRenderSize_test_5686() {
    ImageReadParam instance = new ImageReadParam();
    instance.getSourceRenderSize();
  }

  @Test
  public void setSourceProgressivePasses_test_5687(int p0, int p1) {
    ImageReadParam instance = new ImageReadParam();
    instance.setSourceProgressivePasses(p0, p1);
  }

  @Test
  public void getSourceMinProgressivePass_test_5688() {
    ImageReadParam instance = new ImageReadParam();
    instance.getSourceMinProgressivePass();
  }

  @Test
  public void getSourceMaxProgressivePass_test_5689() {
    ImageReadParam instance = new ImageReadParam();
    instance.getSourceMaxProgressivePass();
  }

  @Test
  public void getSourceNumProgressivePasses_test_5690() {
    ImageReadParam instance = new ImageReadParam();
    instance.getSourceNumProgressivePasses();
  }

  @Test
  public void setDestinationType_test_5691(ImageTypeSpecifier p0) {
    ImageReadParam instance = new ImageReadParam();
    instance.setDestinationType(p0);
  }
}
