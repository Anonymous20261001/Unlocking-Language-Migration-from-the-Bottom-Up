package generated.test;

import java.security.PEMEncoder;
import org.junit.jupiter.api.Test;

public class java_security_PEMEncoderAutoTest {
  @Test
  public void of_test_9882() {
    PEMEncoder.of();
  }
}
