package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.Iterator;
import java.util.PrimitiveIterator;
import java.util.Spliterator;
import java.util.Spliterators;
import org.junit.jupiter.api.Test;

public class java_util_SpliteratorsAutoTest {
  @Test
  public void iterator_test_11314(Spliterator.OfDouble p0) {
    Spliterators.iterator(p0);
  }

  @Test
  public void iterator_test_11315(Spliterator p0) {
    Spliterators.iterator(p0);
  }

  @Test
  public void iterator_test_11316(Spliterator.OfInt p0) {
    Spliterators.iterator(p0);
  }

  @Test
  public void iterator_test_11317(Spliterator.OfLong p0) {
    Spliterators.iterator(p0);
  }

  @Test
  public void spliteratorUnknownSize_test_11318(PrimitiveIterator.OfInt p0, int p1) {
    Spliterators.spliteratorUnknownSize(p0, p1);
  }

  @Test
  public void spliteratorUnknownSize_test_11319(PrimitiveIterator.OfLong p0, int p1) {
    Spliterators.spliteratorUnknownSize(p0, p1);
  }

  @Test
  public void spliteratorUnknownSize_test_11320(PrimitiveIterator.OfDouble p0, int p1) {
    Spliterators.spliteratorUnknownSize(p0, p1);
  }

  @Test
  public void spliteratorUnknownSize_test_11321(Iterator p0, int p1) {
    Spliterators.spliteratorUnknownSize(p0, p1);
  }

  @Test
  public void spliterator_test_11322(Object[] p0, int p1) {
    Spliterators.spliterator(p0, p1);
  }

  @Test
  public void spliterator_test_11323(Iterator p0, long p1, int p2) {
    Spliterators.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_11324(Collection p0, int p1) {
    Spliterators.spliterator(p0, p1);
  }

  @Test
  public void spliterator_test_11325(PrimitiveIterator.OfInt p0, long p1, int p2) {
    Spliterators.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_11326(PrimitiveIterator.OfLong p0, long p1, int p2) {
    Spliterators.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_11327(PrimitiveIterator.OfDouble p0, long p1, int p2) {
    Spliterators.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_11328(long[] p0, int p1, int p2, int p3) {
    Spliterators.spliterator(p0, p1, p2, p3);
  }

  @Test
  public void spliterator_test_11329(long[] p0, int p1) {
    Spliterators.spliterator(p0, p1);
  }

  @Test
  public void spliterator_test_11330(int[] p0, int p1, int p2, int p3) {
    Spliterators.spliterator(p0, p1, p2, p3);
  }

  @Test
  public void spliterator_test_11331(Object[] p0, int p1, int p2, int p3) {
    Spliterators.spliterator(p0, p1, p2, p3);
  }

  @Test
  public void spliterator_test_11332(int[] p0, int p1) {
    Spliterators.spliterator(p0, p1);
  }

  @Test
  public void spliterator_test_11333(double[] p0, int p1, int p2, int p3) {
    Spliterators.spliterator(p0, p1, p2, p3);
  }

  @Test
  public void spliterator_test_11334(double[] p0, int p1) {
    Spliterators.spliterator(p0, p1);
  }

  @Test
  public void emptySpliterator_test_11335() {
    Spliterators.emptySpliterator();
  }

  @Test
  public void emptyIntSpliterator_test_11336() {
    Spliterators.emptyIntSpliterator();
  }

  @Test
  public void emptyLongSpliterator_test_11337() {
    Spliterators.emptyLongSpliterator();
  }

  @Test
  public void emptyDoubleSpliterator_test_11338() {
    Spliterators.emptyDoubleSpliterator();
  }
}
