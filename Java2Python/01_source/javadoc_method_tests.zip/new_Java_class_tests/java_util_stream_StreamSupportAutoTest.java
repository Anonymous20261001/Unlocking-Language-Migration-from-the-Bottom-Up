package generated.test;

import java.util.Spliterator;
import java.util.function.Supplier;
import java.util.stream.StreamSupport;
import org.junit.jupiter.api.Test;

public class java_util_stream_StreamSupportAutoTest {
  @Test
  public void stream_test_11571(Supplier p0, int p1, boolean p2) {
    StreamSupport.stream(p0, p1, p2);
  }

  @Test
  public void stream_test_11572(Spliterator p0, boolean p1) {
    StreamSupport.stream(p0, p1);
  }

  @Test
  public void intStream_test_11573(Supplier p0, int p1, boolean p2) {
    StreamSupport.intStream(p0, p1, p2);
  }

  @Test
  public void intStream_test_11574(Spliterator.OfInt p0, boolean p1) {
    StreamSupport.intStream(p0, p1);
  }

  @Test
  public void longStream_test_11575(Supplier p0, int p1, boolean p2) {
    StreamSupport.longStream(p0, p1, p2);
  }

  @Test
  public void longStream_test_11576(Spliterator.OfLong p0, boolean p1) {
    StreamSupport.longStream(p0, p1);
  }

  @Test
  public void doubleStream_test_11577(Spliterator.OfDouble p0, boolean p1) {
    StreamSupport.doubleStream(p0, p1);
  }

  @Test
  public void doubleStream_test_11578(Supplier p0, int p1, boolean p2) {
    StreamSupport.doubleStream(p0, p1, p2);
  }
}
