package generated.test;

import java.awt.Component;
import javax.swing.PopupFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_PopupFactoryAutoTest {
  @Test
  public void setSharedInstance_test_9985(PopupFactory p0) {
    PopupFactory.setSharedInstance(p0);
  }

  @Test
  public void getSharedInstance_test_9986() {
    PopupFactory.getSharedInstance();
  }

  @Test
  public void getPopup_test_9987(Component p0, Component p1, int p2, int p3) {
    PopupFactory instance = new PopupFactory();
    instance.getPopup(p0, p1, p2, p3);
  }
}
