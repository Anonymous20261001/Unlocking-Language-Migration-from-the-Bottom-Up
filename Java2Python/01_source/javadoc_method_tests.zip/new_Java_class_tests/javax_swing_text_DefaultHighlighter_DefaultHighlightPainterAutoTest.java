package generated.test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.JTextComponent;
import javax.swing.text.View;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultHighlighter_DefaultHighlightPainterAutoTest {
  @Test
  public void paintLayer_test_3709(Graphics p0, int p1, int p2, Shape p3, JTextComponent p4,
      View p5, Color c0) {
    DefaultHighlighter.DefaultHighlightPainter instance = new DefaultHighlighter.DefaultHighlightPainter(c0);
    instance.paintLayer(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void paint_test_3710(Graphics p0, int p1, int p2, Shape p3, JTextComponent p4, Color c0) {
    DefaultHighlighter.DefaultHighlightPainter instance = new DefaultHighlighter.DefaultHighlightPainter(c0);
    instance.paint(p0, p1, p2, p3, p4);
  }

  @Test
  public void getColor_test_3711(Color c0) {
    DefaultHighlighter.DefaultHighlightPainter instance = new DefaultHighlighter.DefaultHighlightPainter(c0);
    instance.getColor();
  }
}
