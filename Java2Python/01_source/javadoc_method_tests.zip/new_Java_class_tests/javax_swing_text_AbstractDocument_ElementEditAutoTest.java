package generated.test;

import javax.swing.text.AbstractDocument;
import javax.swing.text.Element;
import org.junit.jupiter.api.Test;

public class javax_swing_text_AbstractDocument_ElementEditAutoTest {
  @Test
  public void redo_test_2(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.redo();
  }

  @Test
  public void undo_test_3(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.undo();
  }

  @Test
  public void getChildrenRemoved_test_4(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.getChildrenRemoved();
  }

  @Test
  public void getChildrenAdded_test_5(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.getChildrenAdded();
  }

  @Test
  public void getIndex_test_6(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.getIndex();
  }

  @Test
  public void getElement_test_7(Element c0, int c1, Element[] c2, Element[] c3) {
    AbstractDocument.ElementEdit instance = new AbstractDocument.ElementEdit(c0, c1, c2, c3);
    instance.getElement();
  }
}
