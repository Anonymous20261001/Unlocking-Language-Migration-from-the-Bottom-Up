package generated.test;

import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.UndoableEdit;
import org.junit.jupiter.api.Test;

public class javax_swing_undo_AbstractUndoableEditAutoTest {
  @Test
  public void addEdit_test_14(UndoableEdit p0) {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.addEdit(p0);
  }

  @Test
  public void redo_test_15() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.redo();
  }

  @Test
  public void undo_test_16() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.undo();
  }

  @Test
  public void getPresentationName_test_17() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.getPresentationName();
  }

  @Test
  public void isSignificant_test_18() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.isSignificant();
  }

  @Test
  public void getUndoPresentationName_test_19() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.getUndoPresentationName();
  }

  @Test
  public void getRedoPresentationName_test_20() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.getRedoPresentationName();
  }

  @Test
  public void die_test_21() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.die();
  }

  @Test
  public void replaceEdit_test_22(UndoableEdit p0) {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.replaceEdit(p0);
  }

  @Test
  public void canUndo_test_23() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.canUndo();
  }

  @Test
  public void canRedo_test_24() {
    AbstractUndoableEdit instance = new AbstractUndoableEdit();
    instance.canRedo();
  }
}
