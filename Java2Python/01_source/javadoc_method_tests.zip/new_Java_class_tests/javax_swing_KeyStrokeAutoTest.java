package generated.test;

import java.awt.event.KeyEvent;
import java.lang.Character;
import java.lang.String;
import javax.swing.KeyStroke;
import org.junit.jupiter.api.Test;

public class javax_swing_KeyStrokeAutoTest {
  @Test
  public void getKeyStrokeForEvent_test_7655(KeyEvent p0) {
    KeyStroke.getKeyStrokeForEvent(p0);
  }

  @Test
  public void getKeyStroke_test_7656(char p0, boolean p1) {
    KeyStroke.getKeyStroke(p0, p1);
  }

  @Test
  public void getKeyStroke_test_7657(Character p0, int p1) {
    KeyStroke.getKeyStroke(p0, p1);
  }

  @Test
  public void getKeyStroke_test_7658(int p0, int p1) {
    KeyStroke.getKeyStroke(p0, p1);
  }

  @Test
  public void getKeyStroke_test_7659(char p0) {
    KeyStroke.getKeyStroke(p0);
  }

  @Test
  public void getKeyStroke_test_7660(String p0) {
    KeyStroke.getKeyStroke(p0);
  }

  @Test
  public void getKeyStroke_test_7661(int p0, int p1, boolean p2) {
    KeyStroke.getKeyStroke(p0, p1, p2);
  }
}
