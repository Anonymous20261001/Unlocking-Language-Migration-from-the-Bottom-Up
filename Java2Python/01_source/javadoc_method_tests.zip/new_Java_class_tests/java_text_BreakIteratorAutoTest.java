package generated.test;

import java.text.BreakIterator;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_text_BreakIteratorAutoTest {
  @Test
  public void getAvailableLocales_test_1878() {
    BreakIterator.getAvailableLocales();
  }

  @Test
  public void getWordInstance_test_1879() {
    BreakIterator.getWordInstance();
  }

  @Test
  public void getWordInstance_test_1880(Locale p0) {
    BreakIterator.getWordInstance(p0);
  }

  @Test
  public void getLineInstance_test_1881(Locale p0) {
    BreakIterator.getLineInstance(p0);
  }

  @Test
  public void getLineInstance_test_1882() {
    BreakIterator.getLineInstance();
  }

  @Test
  public void getCharacterInstance_test_1883(Locale p0) {
    BreakIterator.getCharacterInstance(p0);
  }

  @Test
  public void getCharacterInstance_test_1884() {
    BreakIterator.getCharacterInstance();
  }

  @Test
  public void getSentenceInstance_test_1885(Locale p0) {
    BreakIterator.getSentenceInstance(p0);
  }

  @Test
  public void getSentenceInstance_test_1886() {
    BreakIterator.getSentenceInstance();
  }
}
