package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.parsers.DocumentBuilderFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_parsers_DocumentBuilderFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_4194() {
    DocumentBuilderFactory.newDefaultInstance();
  }

  @Test
  public void newDefaultNSInstance_test_4195() {
    DocumentBuilderFactory.newDefaultNSInstance();
  }

  @Test
  public void newNSInstance_test_4196() {
    DocumentBuilderFactory.newNSInstance();
  }

  @Test
  public void newNSInstance_test_4197(String p0, ClassLoader p1) {
    DocumentBuilderFactory.newNSInstance(p0, p1);
  }

  @Test
  public void newInstance_test_4198(String p0, ClassLoader p1) {
    DocumentBuilderFactory.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_4199() {
    DocumentBuilderFactory.newInstance();
  }
}
