package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalIconFactory_FolderIcon16AutoTest {
  @Test
  public void getShift_test_8723() {
    MetalIconFactory.FolderIcon16 instance = new MetalIconFactory.FolderIcon16();
    instance.getShift();
  }

  @Test
  public void getAdditionalHeight_test_8724() {
    MetalIconFactory.FolderIcon16 instance = new MetalIconFactory.FolderIcon16();
    instance.getAdditionalHeight();
  }

  @Test
  public void getIconWidth_test_8725() {
    MetalIconFactory.FolderIcon16 instance = new MetalIconFactory.FolderIcon16();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_8726() {
    MetalIconFactory.FolderIcon16 instance = new MetalIconFactory.FolderIcon16();
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_8727(Component p0, Graphics p1, int p2, int p3) {
    MetalIconFactory.FolderIcon16 instance = new MetalIconFactory.FolderIcon16();
    instance.paintIcon(p0, p1, p2, p3);
  }
}
