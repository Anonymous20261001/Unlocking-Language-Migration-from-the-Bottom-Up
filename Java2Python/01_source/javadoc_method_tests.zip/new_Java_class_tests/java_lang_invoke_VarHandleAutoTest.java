package generated.test;

import java.lang.invoke.VarHandle;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_VarHandleAutoTest {
  @Test
  public void storeStoreFence_test_13309() {
    VarHandle.storeStoreFence();
  }

  @Test
  public void fullFence_test_13310() {
    VarHandle.fullFence();
  }

  @Test
  public void loadLoadFence_test_13311() {
    VarHandle.loadLoadFence();
  }

  @Test
  public void acquireFence_test_13312() {
    VarHandle.acquireFence();
  }

  @Test
  public void releaseFence_test_13313() {
    VarHandle.releaseFence();
  }
}
