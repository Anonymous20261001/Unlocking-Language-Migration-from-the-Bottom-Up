package generated.test;

import java.lang.Float;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class java_lang_FloatAutoTest {
  @Test
  public void min_test_4825(float p0, float p1) {
    Float.min(p0, p1);
  }

  @Test
  public void max_test_4826(float p0, float p1) {
    Float.max(p0, p1);
  }

  @Test
  public void isInfinite_test_4827(float p0) {
    Float.isInfinite(p0);
  }

  @Test
  public void isInfinite_test_4828(String c0) {
    Float instance = new Float(c0);
    instance.isInfinite();
  }

  @Test
  public void isFinite_test_4829(float p0) {
    Float.isFinite(p0);
  }

  @Test
  public void floatToRawIntBits_test_4830(float p0) {
    Float.floatToRawIntBits(p0);
  }

  @Test
  public void floatToIntBits_test_4831(float p0) {
    Float.floatToIntBits(p0);
  }

  @Test
  public void intBitsToFloat_test_4832(int p0) {
    Float.intBitsToFloat(p0);
  }

  @Test
  public void float16ToFloat_test_4833(short p0) {
    Float.float16ToFloat(p0);
  }

  @Test
  public void floatToFloat16_test_4834(float p0) {
    Float.floatToFloat16(p0);
  }

  @Test
  public void compareTo_test_4835(Float p0, String c0) {
    Float instance = new Float(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_4836(float p0, float p1) {
    Float.compare(p0, p1);
  }

  @Test
  public void byteValue_test_4837(String c0) {
    Float instance = new Float(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_4838(String c0) {
    Float instance = new Float(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_4839(String c0) {
    Float instance = new Float(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_4840(String c0) {
    Float instance = new Float(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_4841(String c0) {
    Float instance = new Float(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_4842(String c0) {
    Float instance = new Float(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_4843(float p0) {
    Float.valueOf(p0);
  }

  @Test
  public void valueOf_test_4844(String p0) {
    Float.valueOf(p0);
  }

  @Test
  public void toHexString_test_4845(float p0) {
    Float.toHexString(p0);
  }

  @Test
  public void resolveConstantDesc_test_4846(MethodHandles.Lookup p0, String c0) {
    Float instance = new Float(c0);
    instance.resolveConstantDesc(p0);
  }

  @Test
  public void describeConstable_test_4847(String c0) {
    Float instance = new Float(c0);
    instance.describeConstable();
  }

  @Test
  public void isNaN_test_4848(float p0) {
    Float.isNaN(p0);
  }

  @Test
  public void isNaN_test_4849(String c0) {
    Float instance = new Float(c0);
    instance.isNaN();
  }

  @Test
  public void sum_test_4850(float p0, float p1) {
    Float.sum(p0, p1);
  }

  @Test
  public void parseFloat_test_4851(String p0) {
    Float.parseFloat(p0);
  }
}
