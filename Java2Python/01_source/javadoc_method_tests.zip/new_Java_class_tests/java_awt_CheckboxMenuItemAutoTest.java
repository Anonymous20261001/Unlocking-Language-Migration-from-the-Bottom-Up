package generated.test;

import java.awt.CheckboxMenuItem;
import java.awt.event.ItemListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxMenuItemAutoTest {
  @Test
  public void getListeners_test_2257(Class p0) {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.getListeners(p0);
  }

  @Test
  public void addNotify_test_2258() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_2259() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.getAccessibleContext();
  }

  @Test
  public void removeItemListener_test_2260(ItemListener p0) {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.removeItemListener(p0);
  }

  @Test
  public void addItemListener_test_2261(ItemListener p0) {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.addItemListener(p0);
  }

  @Test
  public void getItemListeners_test_2262() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.getItemListeners();
  }

  @Test
  public void getSelectedObjects_test_2263() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.getSelectedObjects();
  }

  @Test
  public void getState_test_2264() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.getState();
  }

  @Test
  public void setState_test_2265(boolean p0) {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.setState(p0);
  }

  @Test
  public void paramString_test_2266() {
    CheckboxMenuItem instance = new CheckboxMenuItem();
    instance.paramString();
  }
}
