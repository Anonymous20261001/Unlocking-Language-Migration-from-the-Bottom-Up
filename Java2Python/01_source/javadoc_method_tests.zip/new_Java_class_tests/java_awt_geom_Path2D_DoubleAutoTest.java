package generated.test;

import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Path2D_DoubleAutoTest {
  @Test
  public void getBounds2D_test_9841() {
    Path2D.Double instance = new Path2D.Double();
    instance.getBounds2D();
  }

  @Test
  public void getPathIterator_test_9842(AffineTransform p0) {
    Path2D.Double instance = new Path2D.Double();
    instance.getPathIterator(p0);
  }

  @Test
  public void moveTo_test_9843(double p0, double p1) {
    Path2D.Double instance = new Path2D.Double();
    instance.moveTo(p0, p1);
  }

  @Test
  public void lineTo_test_9844(double p0, double p1) {
    Path2D.Double instance = new Path2D.Double();
    instance.lineTo(p0, p1);
  }

  @Test
  public void quadTo_test_9845(double p0, double p1, double p2, double p3) {
    Path2D.Double instance = new Path2D.Double();
    instance.quadTo(p0, p1, p2, p3);
  }

  @Test
  public void curveTo_test_9846(double p0, double p1, double p2, double p3, double p4, double p5) {
    Path2D.Double instance = new Path2D.Double();
    instance.curveTo(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void append_test_9847(PathIterator p0, boolean p1) {
    Path2D.Double instance = new Path2D.Double();
    instance.append(p0, p1);
  }

  @Test
  public void transform_test_9848(AffineTransform p0) {
    Path2D.Double instance = new Path2D.Double();
    instance.transform(p0);
  }

  @Test
  public void trimToSize_test_9849() {
    Path2D.Double instance = new Path2D.Double();
    instance.trimToSize();
  }
}
