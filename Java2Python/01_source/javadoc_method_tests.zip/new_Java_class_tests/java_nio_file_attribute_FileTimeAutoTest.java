package generated.test;

import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;

public class java_nio_file_attribute_FileTimeAutoTest {
  @Test
  public void from_test_4782(Instant p0) {
    FileTime.from(p0);
  }

  @Test
  public void from_test_4783(long p0, TimeUnit p1) {
    FileTime.from(p0, p1);
  }

  @Test
  public void fromMillis_test_4784(long p0) {
    FileTime.fromMillis(p0);
  }
}
