package generated.test;

import java.lang.Class;
import java.lang.Enum;
import java.util.Collection;
import java.util.EnumSet;
import org.junit.jupiter.api.Test;

public class java_util_EnumSetAutoTest {
  @Test
  public void copyOf_test_4548(Collection p0) {
    EnumSet.copyOf(p0);
  }

  @Test
  public void copyOf_test_4549(EnumSet p0) {
    EnumSet.copyOf(p0);
  }

  @Test
  public void of_test_4550(Enum p0, Enum p1, Enum p2) {
    EnumSet.of(p0, p1, p2);
  }

  @Test
  public void of_test_4551(Enum p0, Enum p1) {
    EnumSet.of(p0, p1);
  }

  @Test
  public void of_test_4552(Enum p0, Enum p1, Enum p2, Enum p3) {
    EnumSet.of(p0, p1, p2, p3);
  }

  @Test
  public void of_test_4553(Enum p0, Enum[] p1) {
    EnumSet.of(p0, p1);
  }

  @Test
  public void of_test_4554(Enum p0) {
    EnumSet.of(p0);
  }

  @Test
  public void of_test_4555(Enum p0, Enum p1, Enum p2, Enum p3, Enum p4) {
    EnumSet.of(p0, p1, p2, p3, p4);
  }

  @Test
  public void noneOf_test_4556(Class p0) {
    EnumSet.noneOf(p0);
  }

  @Test
  public void range_test_4557(Enum p0, Enum p1) {
    EnumSet.range(p0, p1);
  }

  @Test
  public void allOf_test_4558(Class p0) {
    EnumSet.allOf(p0);
  }

  @Test
  public void complementOf_test_4559(EnumSet p0) {
    EnumSet.complementOf(p0);
  }
}
