package generated.test;

import java.lang.Class;
import java.lang.ClassLoader;
import java.lang.String;
import java.lang.invoke.MethodType;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_MethodTypeAutoTest {
  @Test
  public void methodType_test_8922(Class p0, List p1) {
    MethodType.methodType(p0, p1);
  }

  @Test
  public void methodType_test_8923(Class p0) {
    MethodType.methodType(p0);
  }

  @Test
  public void methodType_test_8924(Class p0, Class p1, Class[] p2) {
    MethodType.methodType(p0, p1, p2);
  }

  @Test
  public void methodType_test_8925(Class p0, Class[] p1) {
    MethodType.methodType(p0, p1);
  }

  @Test
  public void methodType_test_8926(Class p0, Class p1) {
    MethodType.methodType(p0, p1);
  }

  @Test
  public void methodType_test_8927(Class p0, MethodType p1) {
    MethodType.methodType(p0, p1);
  }

  @Test
  public void genericMethodType_test_8928(int p0, boolean p1) {
    MethodType.genericMethodType(p0, p1);
  }

  @Test
  public void genericMethodType_test_8929(int p0) {
    MethodType.genericMethodType(p0);
  }

  @Test
  public void fromMethodDescriptorString_test_8930(String p0, ClassLoader p1) {
    MethodType.fromMethodDescriptorString(p0, p1);
  }
}
