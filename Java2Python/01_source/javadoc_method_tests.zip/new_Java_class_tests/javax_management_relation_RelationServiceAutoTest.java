package generated.test;

import java.lang.Boolean;
import java.lang.Object;
import java.lang.String;
import javax.management.Notification;
import javax.management.ObjectName;
import javax.management.relation.RelationService;
import org.junit.jupiter.api.Test;

public class javax_management_relation_RelationServiceAutoTest {
  @Test
  public void getNotificationInfo_test_10508(boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.getNotificationInfo();
  }

  @Test
  public void postRegister_test_10509(Boolean p0, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.postRegister(p0);
  }

  @Test
  public void postDeregister_test_10510(boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.postDeregister();
  }

  @Test
  public void handleNotification_test_10511(Notification p0, Object p1, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.handleNotification(p0, p1);
  }

  @Test
  public void getAllRelationTypeNames_test_10512(boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.getAllRelationTypeNames();
  }

  @Test
  public void isRelation_test_10513(ObjectName p0, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.isRelation(p0);
  }

  @Test
  public void hasRelation_test_10514(String p0, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.hasRelation(p0);
  }

  @Test
  public void getAllRelationIds_test_10515(boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.getAllRelationIds();
  }

  @Test
  public void findAssociatedMBeans_test_10516(ObjectName p0, String p1, String p2, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.findAssociatedMBeans(p0, p1, p2);
  }

  @Test
  public void setPurgeFlag_test_10517(boolean p0, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.setPurgeFlag(p0);
  }

  @Test
  public void findReferencingRelations_test_10518(ObjectName p0, String p1, String p2, boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.findReferencingRelations(p0, p1, p2);
  }

  @Test
  public void getPurgeFlag_test_10519(boolean c0) {
    RelationService instance = new RelationService(c0);
    instance.getPurgeFlag();
  }
}
