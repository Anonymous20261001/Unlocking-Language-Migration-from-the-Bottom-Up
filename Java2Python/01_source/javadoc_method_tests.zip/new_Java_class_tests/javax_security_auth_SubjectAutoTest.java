package generated.test;

import java.lang.Class;
import java.security.AccessControlContext;
import java.security.PrivilegedAction;
import java.util.concurrent.Callable;
import javax.security.auth.Subject;
import org.junit.jupiter.api.Test;

public class javax_security_auth_SubjectAutoTest {
  @Test
  public void callAs_test_12039(Subject p0, Callable p1) {
    Subject.callAs(p0, p1);
  }

  @Test
  public void getSubject_test_12040(AccessControlContext p0) {
    Subject.getSubject(p0);
  }

  @Test
  public void doAs_test_12041(Subject p0, PrivilegedAction p1) {
    Subject.doAs(p0, p1);
  }

  @Test
  public void doAsPrivileged_test_12042(Subject p0, PrivilegedAction p1, AccessControlContext p2) {
    Subject.doAsPrivileged(p0, p1, p2);
  }

  @Test
  public void getPublicCredentials_test_12043(Class p0) {
    Subject instance = new Subject();
    instance.getPublicCredentials(p0);
  }

  @Test
  public void getPublicCredentials_test_12044() {
    Subject instance = new Subject();
    instance.getPublicCredentials();
  }

  @Test
  public void getPrivateCredentials_test_12045() {
    Subject instance = new Subject();
    instance.getPrivateCredentials();
  }

  @Test
  public void getPrivateCredentials_test_12046(Class p0) {
    Subject instance = new Subject();
    instance.getPrivateCredentials(p0);
  }

  @Test
  public void current_test_12047() {
    Subject.current();
  }

  @Test
  public void setReadOnly_test_12048() {
    Subject instance = new Subject();
    instance.setReadOnly();
  }

  @Test
  public void getPrincipals_test_12049(Class p0) {
    Subject instance = new Subject();
    instance.getPrincipals(p0);
  }

  @Test
  public void getPrincipals_test_12050() {
    Subject instance = new Subject();
    instance.getPrincipals();
  }

  @Test
  public void isReadOnly_test_12051() {
    Subject instance = new Subject();
    instance.isReadOnly();
  }
}
