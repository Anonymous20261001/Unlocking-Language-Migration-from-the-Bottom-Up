package generated.test;

import java.lang.String;
import java.text.ListFormat;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_text_ListFormatAutoTest {
  @Test
  public void getInstance_test_7979() {
    ListFormat.getInstance();
  }

  @Test
  public void getInstance_test_7980(String[] p0) {
    ListFormat.getInstance(p0);
  }

  @Test
  public void getInstance_test_7981(Locale p0, ListFormat.Type p1, ListFormat.Style p2) {
    ListFormat.getInstance(p0, p1, p2);
  }

  @Test
  public void getAvailableLocales_test_7982() {
    ListFormat.getAvailableLocales();
  }
}
