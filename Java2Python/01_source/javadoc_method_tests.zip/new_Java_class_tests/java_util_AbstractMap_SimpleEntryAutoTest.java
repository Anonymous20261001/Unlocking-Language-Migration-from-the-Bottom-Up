package generated.test;

import java.lang.Object;
import java.util.AbstractMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_util_AbstractMap_SimpleEntryAutoTest {
  @Test
  public void getValue_test_8(Map.Entry c0) {
    AbstractMap.SimpleEntry instance = new AbstractMap.SimpleEntry(c0);
    instance.getValue();
  }

  @Test
  public void getKey_test_9(Map.Entry c0) {
    AbstractMap.SimpleEntry instance = new AbstractMap.SimpleEntry(c0);
    instance.getKey();
  }

  @Test
  public void setValue_test_10(Object p0, Map.Entry c0) {
    AbstractMap.SimpleEntry instance = new AbstractMap.SimpleEntry(c0);
    instance.setValue(p0);
  }
}
