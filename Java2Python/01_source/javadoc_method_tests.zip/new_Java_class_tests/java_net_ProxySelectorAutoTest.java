package generated.test;

import java.net.InetSocketAddress;
import java.net.ProxySelector;
import org.junit.jupiter.api.Test;

public class java_net_ProxySelectorAutoTest {
  @Test
  public void of_test_10219(InetSocketAddress p0) {
    ProxySelector.of(p0);
  }

  @Test
  public void getDefault_test_10220() {
    ProxySelector.getDefault();
  }

  @Test
  public void setDefault_test_10221(ProxySelector p0) {
    ProxySelector.setDefault(p0);
  }
}
