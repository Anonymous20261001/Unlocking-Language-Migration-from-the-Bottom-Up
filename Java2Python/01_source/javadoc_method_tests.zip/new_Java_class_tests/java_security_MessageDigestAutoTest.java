package generated.test;

import java.security.MessageDigest;
import org.junit.jupiter.api.Test;

public class java_security_MessageDigestAutoTest {
  @Test
  public void isEqual_test_8592(byte[] p0, byte[] p1) {
    MessageDigest.isEqual(p0, p1);
  }
}
