package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.transform.TransformerFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_transform_TransformerFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_12971() {
    TransformerFactory.newDefaultInstance();
  }

  @Test
  public void newInstance_test_12972(String p0, ClassLoader p1) {
    TransformerFactory.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_12973() {
    TransformerFactory.newInstance();
  }
}
