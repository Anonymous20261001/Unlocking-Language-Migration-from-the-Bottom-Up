package generated.test;

import java.io.InputStream;
import java.io.PrintStream;
import java.lang.Object;
import java.lang.SecurityManager;
import java.lang.String;
import java.lang.System;
import java.util.Properties;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class java_lang_SystemAutoTest {
  @Test
  public void exit_test_12410(int p0) {
    System.exit(p0);
  }

  @Test
  public void runFinalization_test_12411() {
    System.runFinalization();
  }

  @Test
  public void getProperty_test_12412(String p0) {
    System.getProperty(p0);
  }

  @Test
  public void getProperty_test_12413(String p0, String p1) {
    System.getProperty(p0, p1);
  }

  @Test
  public void identityHashCode_test_12414(Object p0) {
    System.identityHashCode(p0);
  }

  @Test
  public void currentTimeMillis_test_12415() {
    System.currentTimeMillis();
  }

  @Test
  public void nanoTime_test_12416() {
    System.nanoTime();
  }

  @Test
  public void arraycopy_test_12417(Object p0, int p1, Object p2, int p3, int p4) {
    System.arraycopy(p0, p1, p2, p3, p4);
  }

  @Test
  public void load_test_12418(String p0) {
    System.load(p0);
  }

  @Test
  public void loadLibrary_test_12419(String p0) {
    System.loadLibrary(p0);
  }

  @Test
  public void console_test_12420() {
    System.console();
  }

  @Test
  public void lineSeparator_test_12421() {
    System.lineSeparator();
  }

  @Test
  public void setProperty_test_12422(String p0, String p1) {
    System.setProperty(p0, p1);
  }

  @Test
  public void getenv_test_12423(String p0) {
    System.getenv(p0);
  }

  @Test
  public void getenv_test_12424() {
    System.getenv();
  }

  @Test
  public void getLogger_test_12425(String p0) {
    System.getLogger(p0);
  }

  @Test
  public void getLogger_test_12426(String p0, ResourceBundle p1) {
    System.getLogger(p0, p1);
  }

  @Test
  public void gc_test_12427() {
    System.gc();
  }

  @Test
  public void setIn_test_12428(InputStream p0) {
    System.setIn(p0);
  }

  @Test
  public void setOut_test_12429(PrintStream p0) {
    System.setOut(p0);
  }

  @Test
  public void setErr_test_12430(PrintStream p0) {
    System.setErr(p0);
  }

  @Test
  public void setSecurityManager_test_12431(SecurityManager p0) {
    System.setSecurityManager(p0);
  }

  @Test
  public void getSecurityManager_test_12432() {
    System.getSecurityManager();
  }

  @Test
  public void getProperties_test_12433() {
    System.getProperties();
  }

  @Test
  public void setProperties_test_12434(Properties p0) {
    System.setProperties(p0);
  }

  @Test
  public void clearProperty_test_12435(String p0) {
    System.clearProperty(p0);
  }

  @Test
  public void mapLibraryName_test_12436(String p0) {
    System.mapLibraryName(p0);
  }
}
