package generated.test;

import java.net.CookieHandler;
import org.junit.jupiter.api.Test;

public class java_net_CookieHandlerAutoTest {
  @Test
  public void getDefault_test_3025() {
    CookieHandler.getDefault();
  }

  @Test
  public void setDefault_test_3026(CookieHandler p0) {
    CookieHandler.setDefault(p0);
  }
}
