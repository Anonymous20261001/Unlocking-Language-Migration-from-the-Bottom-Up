package generated.test;

import java.security.IdentityScope;
import org.junit.jupiter.api.Test;

public class java_security_IdentityScopeAutoTest {
  @Test
  public void getSystemScope_test_5532() {
    IdentityScope.getSystemScope();
  }
}
