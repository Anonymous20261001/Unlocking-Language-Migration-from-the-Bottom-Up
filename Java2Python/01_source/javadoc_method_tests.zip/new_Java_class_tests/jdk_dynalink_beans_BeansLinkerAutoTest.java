package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.String;
import jdk.dynalink.beans.BeansLinker;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_beans_BeansLinkerAutoTest {
  @Test
  public void getLinkerForClass_test_1576(Class p0) {
    BeansLinker instance = new BeansLinker();
    instance.getLinkerForClass(p0);
  }

  @Test
  public void isDynamicMethod_test_1577(Object p0) {
    BeansLinker.isDynamicMethod(p0);
  }

  @Test
  public void getConstructorMethod_test_1578(Class p0, String p1) {
    BeansLinker.getConstructorMethod(p0, p1);
  }

  @Test
  public void getReadableStaticPropertyNames_test_1579(Class p0) {
    BeansLinker.getReadableStaticPropertyNames(p0);
  }

  @Test
  public void getWritableStaticPropertyNames_test_1580(Class p0) {
    BeansLinker.getWritableStaticPropertyNames(p0);
  }

  @Test
  public void getStaticMethodNames_test_1581(Class p0) {
    BeansLinker.getStaticMethodNames(p0);
  }

  @Test
  public void isDynamicConstructor_test_1582(Object p0) {
    BeansLinker.isDynamicConstructor(p0);
  }

  @Test
  public void getReadableInstancePropertyNames_test_1583(Class p0) {
    BeansLinker.getReadableInstancePropertyNames(p0);
  }

  @Test
  public void getWritableInstancePropertyNames_test_1584(Class p0) {
    BeansLinker.getWritableInstancePropertyNames(p0);
  }

  @Test
  public void getInstanceMethodNames_test_1585(Class p0) {
    BeansLinker.getInstanceMethodNames(p0);
  }
}
