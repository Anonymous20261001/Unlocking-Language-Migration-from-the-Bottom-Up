package generated.test;

import javax.imageio.plugins.tiff.ExifInteroperabilityTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_ExifInteroperabilityTagSetAutoTest {
  @Test
  public void getInstance_test_4662() {
    ExifInteroperabilityTagSet.getInstance();
  }
}
