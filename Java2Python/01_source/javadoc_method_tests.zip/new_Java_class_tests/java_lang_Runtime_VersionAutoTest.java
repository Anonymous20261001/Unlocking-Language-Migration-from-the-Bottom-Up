package generated.test;

import java.lang.Runtime;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_Runtime_VersionAutoTest {
  @Test
  public void parse_test_10751(String p0) {
    Runtime.Version.parse(p0);
  }
}
