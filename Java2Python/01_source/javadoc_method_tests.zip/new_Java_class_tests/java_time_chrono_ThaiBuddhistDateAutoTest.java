package generated.test;

import java.time.Clock;
import java.time.ZoneId;
import java.time.chrono.ThaiBuddhistDate;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_chrono_ThaiBuddhistDateAutoTest {
  @Test
  public void of_test_12647(int p0, int p1, int p2) {
    ThaiBuddhistDate.of(p0, p1, p2);
  }

  @Test
  public void from_test_12648(TemporalAccessor p0) {
    ThaiBuddhistDate.from(p0);
  }

  @Test
  public void now_test_12649() {
    ThaiBuddhistDate.now();
  }

  @Test
  public void now_test_12650(ZoneId p0) {
    ThaiBuddhistDate.now(p0);
  }

  @Test
  public void now_test_12651(Clock p0) {
    ThaiBuddhistDate.now(p0);
  }
}
