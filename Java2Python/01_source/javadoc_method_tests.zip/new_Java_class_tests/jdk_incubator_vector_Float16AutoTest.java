package generated.test;

import java.lang.String;
import java.math.BigDecimal;
import jdk.incubator.vector.Float16;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_Float16AutoTest {
  @Test
  public void float16ToRawShortBits_test_4852(Float16 p0) {
    Float16.float16ToRawShortBits(p0);
  }

  @Test
  public void float16ToShortBits_test_4853(Float16 p0) {
    Float16.float16ToShortBits(p0);
  }

  @Test
  public void shortBitsToFloat16_test_4854(short p0) {
    Float16.shortBitsToFloat16(p0);
  }

  @Test
  public void abs_test_4855(Float16 p0) {
    Float16.abs(p0);
  }

  @Test
  public void sqrt_test_4856(Float16 p0) {
    Float16.sqrt(p0);
  }

  @Test
  public void min_test_4857(Float16 p0, Float16 p1) {
    Float16.min(p0, p1);
  }

  @Test
  public void max_test_4858(Float16 p0, Float16 p1) {
    Float16.max(p0, p1);
  }

  @Test
  public void fma_test_4859(Float16 p0, Float16 p1, Float16 p2) {
    Float16.fma(p0, p1, p2);
  }

  @Test
  public void copySign_test_4860(Float16 p0, Float16 p1) {
    Float16.copySign(p0, p1);
  }

  @Test
  public void signum_test_4861(Float16 p0) {
    Float16.signum(p0);
  }

  @Test
  public void isInfinite_test_4862(Float16 p0) {
    Float16.isInfinite(p0);
  }

  @Test
  public void isFinite_test_4863(Float16 p0) {
    Float16.isFinite(p0);
  }

  @Test
  public void compare_test_4864(Float16 p0, Float16 p1) {
    Float16.compare(p0, p1);
  }

  @Test
  public void valueOf_test_4865(BigDecimal p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void valueOf_test_4866(int p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void valueOf_test_4867(float p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void valueOf_test_4868(long p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void valueOf_test_4869(double p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void valueOf_test_4870(String p0) {
    Float16.valueOf(p0);
  }

  @Test
  public void toHexString_test_4871(Float16 p0) {
    Float16.toHexString(p0);
  }

  @Test
  public void add_test_4872(Float16 p0, Float16 p1) {
    Float16.add(p0, p1);
  }

  @Test
  public void isNaN_test_4873(Float16 p0) {
    Float16.isNaN(p0);
  }

  @Test
  public void scalb_test_4874(Float16 p0, int p1) {
    Float16.scalb(p0, p1);
  }

  @Test
  public void getExponent_test_4875(Float16 p0) {
    Float16.getExponent(p0);
  }

  @Test
  public void multiply_test_4876(Float16 p0, Float16 p1) {
    Float16.multiply(p0, p1);
  }

  @Test
  public void ulp_test_4877(Float16 p0) {
    Float16.ulp(p0);
  }

  @Test
  public void nextUp_test_4878(Float16 p0) {
    Float16.nextUp(p0);
  }

  @Test
  public void nextDown_test_4879(Float16 p0) {
    Float16.nextDown(p0);
  }

  @Test
  public void negate_test_4880(Float16 p0) {
    Float16.negate(p0);
  }

  @Test
  public void subtract_test_4881(Float16 p0, Float16 p1) {
    Float16.subtract(p0, p1);
  }

  @Test
  public void divide_test_4882(Float16 p0, Float16 p1) {
    Float16.divide(p0, p1);
  }
}
