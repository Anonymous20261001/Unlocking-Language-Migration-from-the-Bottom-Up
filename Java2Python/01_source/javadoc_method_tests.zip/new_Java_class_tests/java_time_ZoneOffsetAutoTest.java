package generated.test;

import java.lang.String;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_ZoneOffsetAutoTest {
  @Test
  public void of_test_13728(String p0) {
    ZoneOffset.of(p0);
  }

  @Test
  public void from_test_13729(TemporalAccessor p0) {
    ZoneOffset.from(p0);
  }

  @Test
  public void ofHours_test_13730(int p0) {
    ZoneOffset.ofHours(p0);
  }

  @Test
  public void ofHoursMinutesSeconds_test_13731(int p0, int p1, int p2) {
    ZoneOffset.ofHoursMinutesSeconds(p0, p1, p2);
  }

  @Test
  public void ofTotalSeconds_test_13732(int p0) {
    ZoneOffset.ofTotalSeconds(p0);
  }

  @Test
  public void ofHoursMinutes_test_13733(int p0, int p1) {
    ZoneOffset.ofHoursMinutes(p0, p1);
  }
}
