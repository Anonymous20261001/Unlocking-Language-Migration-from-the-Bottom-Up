package generated.test;

import java.time.Clock;
import java.time.ZoneId;
import java.time.chrono.HijrahDate;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_chrono_HijrahDateAutoTest {
  @Test
  public void of_test_5350(int p0, int p1, int p2) {
    HijrahDate.of(p0, p1, p2);
  }

  @Test
  public void from_test_5351(TemporalAccessor p0) {
    HijrahDate.from(p0);
  }

  @Test
  public void now_test_5352(ZoneId p0) {
    HijrahDate.now(p0);
  }

  @Test
  public void now_test_5353(Clock p0) {
    HijrahDate.now(p0);
  }

  @Test
  public void now_test_5354() {
    HijrahDate.now();
  }
}
