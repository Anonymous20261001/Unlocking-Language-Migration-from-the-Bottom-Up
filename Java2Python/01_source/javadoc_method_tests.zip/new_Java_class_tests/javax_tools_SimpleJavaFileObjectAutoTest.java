package generated.test;

import java.lang.String;
import java.net.URI;
import javax.tools.SimpleJavaFileObject;
import org.junit.jupiter.api.Test;

public class javax_tools_SimpleJavaFileObjectAutoTest {
  @Test
  public void forSource_test_11172(URI p0, String p1) {
    SimpleJavaFileObject.forSource(p0, p1);
  }
}
