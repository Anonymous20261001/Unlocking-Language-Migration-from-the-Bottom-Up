package generated.test;

import javax.net.ServerSocketFactory;
import org.junit.jupiter.api.Test;

public class javax_net_ServerSocketFactoryAutoTest {
  @Test
  public void getDefault_test_11047() {
    ServerSocketFactory.getDefault();
  }
}
