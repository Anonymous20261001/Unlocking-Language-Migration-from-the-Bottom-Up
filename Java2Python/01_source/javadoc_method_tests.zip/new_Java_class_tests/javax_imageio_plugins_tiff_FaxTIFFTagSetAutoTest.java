package generated.test;

import javax.imageio.plugins.tiff.FaxTIFFTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_FaxTIFFTagSetAutoTest {
  @Test
  public void getInstance_test_4674() {
    FaxTIFFTagSet.getInstance();
  }
}
