package generated.test;

import java.lang.Short;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_ShortAutoTest {
  @Test
  public void compareUnsigned_test_11079(short p0, short p1) {
    Short.compareUnsigned(p0, p1);
  }

  @Test
  public void reverseBytes_test_11080(short p0) {
    Short.reverseBytes(p0);
  }

  @Test
  public void compareTo_test_11081(Short p0, short c0) {
    Short instance = new Short(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_11082(short p0, short p1) {
    Short.compare(p0, p1);
  }

  @Test
  public void byteValue_test_11083(short c0) {
    Short instance = new Short(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_11084(short c0) {
    Short instance = new Short(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_11085(short c0) {
    Short instance = new Short(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_11086(short c0) {
    Short instance = new Short(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_11087(short c0) {
    Short instance = new Short(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_11088(short c0) {
    Short instance = new Short(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_11089(String p0, int p1) {
    Short.valueOf(p0, p1);
  }

  @Test
  public void valueOf_test_11090(String p0) {
    Short.valueOf(p0);
  }

  @Test
  public void valueOf_test_11091(short p0) {
    Short.valueOf(p0);
  }

  @Test
  public void decode_test_11092(String p0) {
    Short.decode(p0);
  }

  @Test
  public void describeConstable_test_11093(short c0) {
    Short instance = new Short(c0);
    instance.describeConstable();
  }

  @Test
  public void toUnsignedLong_test_11094(short p0) {
    Short.toUnsignedLong(p0);
  }

  @Test
  public void toUnsignedInt_test_11095(short p0) {
    Short.toUnsignedInt(p0);
  }

  @Test
  public void parseShort_test_11096(String p0) {
    Short.parseShort(p0);
  }

  @Test
  public void parseShort_test_11097(String p0, int p1) {
    Short.parseShort(p0, p1);
  }
}
