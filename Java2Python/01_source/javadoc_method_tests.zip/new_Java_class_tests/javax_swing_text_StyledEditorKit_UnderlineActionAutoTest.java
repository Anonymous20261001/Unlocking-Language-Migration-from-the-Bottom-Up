package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_UnderlineActionAutoTest {
  @Test
  public void actionPerformed_test_12007(ActionEvent p0) {
    StyledEditorKit.UnderlineAction instance = new StyledEditorKit.UnderlineAction();
    instance.actionPerformed(p0);
  }
}
