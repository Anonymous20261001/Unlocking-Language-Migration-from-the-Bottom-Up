package generated.test;

import javax.xml.datatype.DatatypeFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_datatype_DatatypeFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_3280() {
    DatatypeFactory.newDefaultInstance();
  }
}
