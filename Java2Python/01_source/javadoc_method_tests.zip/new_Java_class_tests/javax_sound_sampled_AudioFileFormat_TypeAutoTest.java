package generated.test;

import java.lang.String;
import javax.sound.sampled.AudioFileFormat;
import org.junit.jupiter.api.Test;

public class javax_sound_sampled_AudioFileFormat_TypeAutoTest {
  @Test
  public void getExtension_test_866(String c0, String c1) {
    AudioFileFormat.Type instance = new AudioFileFormat.Type(c0, c1);
    instance.getExtension();
  }
}
