package generated.test;

import javax.xml.catalog.CatalogFeatures;
import org.junit.jupiter.api.Test;

public class javax_xml_catalog_CatalogFeaturesAutoTest {
  @Test
  public void builder_test_2080() {
    CatalogFeatures.builder();
  }

  @Test
  public void defaults_test_2081() {
    CatalogFeatures.defaults();
  }
}
