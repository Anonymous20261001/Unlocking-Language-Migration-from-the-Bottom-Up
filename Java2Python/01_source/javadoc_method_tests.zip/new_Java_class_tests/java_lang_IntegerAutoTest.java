package generated.test;

import java.lang.CharSequence;
import java.lang.Integer;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class java_lang_IntegerAutoTest {
  @Test
  public void numberOfLeadingZeros_test_5867(int p0) {
    Integer.numberOfLeadingZeros(p0);
  }

  @Test
  public void numberOfTrailingZeros_test_5868(int p0) {
    Integer.numberOfTrailingZeros(p0);
  }

  @Test
  public void bitCount_test_5869(int p0) {
    Integer.bitCount(p0);
  }

  @Test
  public void min_test_5870(int p0, int p1) {
    Integer.min(p0, p1);
  }

  @Test
  public void max_test_5871(int p0, int p1) {
    Integer.max(p0, p1);
  }

  @Test
  public void signum_test_5872(int p0) {
    Integer.signum(p0);
  }

  @Test
  public void expand_test_5873(int p0, int p1) {
    Integer.expand(p0, p1);
  }

  @Test
  public void compareUnsigned_test_5874(int p0, int p1) {
    Integer.compareUnsigned(p0, p1);
  }

  @Test
  public void divideUnsigned_test_5875(int p0, int p1) {
    Integer.divideUnsigned(p0, p1);
  }

  @Test
  public void remainderUnsigned_test_5876(int p0, int p1) {
    Integer.remainderUnsigned(p0, p1);
  }

  @Test
  public void reverse_test_5877(int p0) {
    Integer.reverse(p0);
  }

  @Test
  public void reverseBytes_test_5878(int p0) {
    Integer.reverseBytes(p0);
  }

  @Test
  public void compress_test_5879(int p0, int p1) {
    Integer.compress(p0, p1);
  }

  @Test
  public void compareTo_test_5880(Integer p0, int c0) {
    Integer instance = new Integer(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_5881(int p0, int p1) {
    Integer.compare(p0, p1);
  }

  @Test
  public void byteValue_test_5882(int c0) {
    Integer instance = new Integer(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_5883(int c0) {
    Integer instance = new Integer(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_5884(int c0) {
    Integer instance = new Integer(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_5885(int c0) {
    Integer instance = new Integer(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_5886(int c0) {
    Integer instance = new Integer(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_5887(int c0) {
    Integer instance = new Integer(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_5888(String p0) {
    Integer.valueOf(p0);
  }

  @Test
  public void valueOf_test_5889(int p0) {
    Integer.valueOf(p0);
  }

  @Test
  public void valueOf_test_5890(String p0, int p1) {
    Integer.valueOf(p0, p1);
  }

  @Test
  public void toHexString_test_5891(int p0) {
    Integer.toHexString(p0);
  }

  @Test
  public void decode_test_5892(String p0) {
    Integer.decode(p0);
  }

  @Test
  public void resolveConstantDesc_test_5893(MethodHandles.Lookup p0, int c0) {
    Integer instance = new Integer(c0);
    instance.resolveConstantDesc(p0);
  }

  @Test
  public void describeConstable_test_5894(int c0) {
    Integer instance = new Integer(c0);
    instance.describeConstable();
  }

  @Test
  public void parseInt_test_5895(CharSequence p0, int p1, int p2, int p3) {
    Integer.parseInt(p0, p1, p2, p3);
  }

  @Test
  public void parseInt_test_5896(String p0) {
    Integer.parseInt(p0);
  }

  @Test
  public void parseInt_test_5897(String p0, int p1) {
    Integer.parseInt(p0, p1);
  }

  @Test
  public void toUnsignedLong_test_5898(int p0) {
    Integer.toUnsignedLong(p0);
  }

  @Test
  public void sum_test_5899(int p0, int p1) {
    Integer.sum(p0, p1);
  }

  @Test
  public void toUnsignedString_test_5900(int p0) {
    Integer.toUnsignedString(p0);
  }

  @Test
  public void toUnsignedString_test_5901(int p0, int p1) {
    Integer.toUnsignedString(p0, p1);
  }

  @Test
  public void parseUnsignedInt_test_5902(String p0, int p1) {
    Integer.parseUnsignedInt(p0, p1);
  }

  @Test
  public void parseUnsignedInt_test_5903(String p0) {
    Integer.parseUnsignedInt(p0);
  }

  @Test
  public void parseUnsignedInt_test_5904(CharSequence p0, int p1, int p2, int p3) {
    Integer.parseUnsignedInt(p0, p1, p2, p3);
  }

  @Test
  public void getInteger_test_5905(String p0, Integer p1) {
    Integer.getInteger(p0, p1);
  }

  @Test
  public void getInteger_test_5906(String p0) {
    Integer.getInteger(p0);
  }

  @Test
  public void getInteger_test_5907(String p0, int p1) {
    Integer.getInteger(p0, p1);
  }

  @Test
  public void toOctalString_test_5908(int p0) {
    Integer.toOctalString(p0);
  }

  @Test
  public void toBinaryString_test_5909(int p0) {
    Integer.toBinaryString(p0);
  }

  @Test
  public void highestOneBit_test_5910(int p0) {
    Integer.highestOneBit(p0);
  }

  @Test
  public void lowestOneBit_test_5911(int p0) {
    Integer.lowestOneBit(p0);
  }

  @Test
  public void rotateLeft_test_5912(int p0, int p1) {
    Integer.rotateLeft(p0, p1);
  }

  @Test
  public void rotateRight_test_5913(int p0, int p1) {
    Integer.rotateRight(p0, p1);
  }
}
