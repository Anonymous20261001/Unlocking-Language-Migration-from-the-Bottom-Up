package generated.test;

import java.lang.String;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import org.junit.jupiter.api.Test;

public class java_util_Calendar_BuilderAutoTest {
  @Test
  public void set_test_2027(int p0, int p1) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.set(p0, p1);
  }

  @Test
  public void build_test_2028() {
    Calendar.Builder instance = new Calendar.Builder();
    instance.build();
  }

  @Test
  public void setTimeZone_test_2029(TimeZone p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setTimeZone(p0);
  }

  @Test
  public void setLenient_test_2030(boolean p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setLenient(p0);
  }

  @Test
  public void setWeekDate_test_2031(int p0, int p1, int p2) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setWeekDate(p0, p1, p2);
  }

  @Test
  public void setInstant_test_2032(long p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setInstant(p0);
  }

  @Test
  public void setInstant_test_2033(Date p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setInstant(p0);
  }

  @Test
  public void setFields_test_2034(int[] p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setFields(p0);
  }

  @Test
  public void setTimeOfDay_test_2035(int p0, int p1, int p2) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setTimeOfDay(p0, p1, p2);
  }

  @Test
  public void setTimeOfDay_test_2036(int p0, int p1, int p2, int p3) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setTimeOfDay(p0, p1, p2, p3);
  }

  @Test
  public void setWeekDefinition_test_2037(int p0, int p1) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setWeekDefinition(p0, p1);
  }

  @Test
  public void setDate_test_2038(int p0, int p1, int p2) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setDate(p0, p1, p2);
  }

  @Test
  public void setCalendarType_test_2039(String p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setCalendarType(p0);
  }

  @Test
  public void setLocale_test_2040(Locale p0) {
    Calendar.Builder instance = new Calendar.Builder();
    instance.setLocale(p0);
  }
}
