package generated.test;

import java.lang.Class;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import jdk.dynalink.linker.support.Lookup;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_LookupAutoTest {
  @Test
  public void findVirtual_test_8237(Class p0, String p1, MethodType p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findVirtual(p0, p1, p2);
  }

  @Test
  public void findStatic_test_8238(Class p0, String p1, MethodType p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findStatic(p0, p1, p2);
  }

  @Test
  public void unreflect_test_8239(Method p0, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.unreflect(p0);
  }

  @Test
  public void unreflect_test_8240(MethodHandles.Lookup p0, Method p1) {
    Lookup.unreflect(p0, p1);
  }

  @Test
  public void unreflectConstructor_test_8241(MethodHandles.Lookup p0, Constructor p1) {
    Lookup.unreflectConstructor(p0, p1);
  }

  @Test
  public void unreflectConstructor_test_8242(Constructor p0, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.unreflectConstructor(p0);
  }

  @Test
  public void findSpecial_test_8243(Class p0, String p1, MethodType p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findSpecial(p0, p1, p2);
  }

  @Test
  public void findGetter_test_8244(Class p0, String p1, Class p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findGetter(p0, p1, p2);
  }

  @Test
  public void unreflectGetter_test_8245(Field p0, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.unreflectGetter(p0);
  }

  @Test
  public void unreflectSetter_test_8246(Field p0, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.unreflectSetter(p0);
  }

  @Test
  public void findOwnSpecial_test_8247(String p0, Class p1, Class[] p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findOwnSpecial(p0, p1, p2);
  }

  @Test
  public void findOwnSpecial_test_8248(MethodHandles.Lookup p0, String p1, Class p2, Class[] p3) {
    Lookup.findOwnSpecial(p0, p1, p2, p3);
  }

  @Test
  public void findOwnStatic_test_8249(MethodHandles.Lookup p0, String p1, Class p2, Class[] p3) {
    Lookup.findOwnStatic(p0, p1, p2, p3);
  }

  @Test
  public void findOwnStatic_test_8250(String p0, Class p1, Class[] p2, MethodHandles.Lookup c0) {
    Lookup instance = new Lookup(c0);
    instance.findOwnStatic(p0, p1, p2);
  }
}
