package generated.test;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import org.junit.jupiter.api.Test;

public class javax_sound_sampled_AudioSystemAutoTest {
  @Test
  public void getAudioInputStream_test_881(AudioFormat.Encoding p0, AudioInputStream p1) {
    AudioSystem.getAudioInputStream(p0, p1);
  }

  @Test
  public void getAudioInputStream_test_882(AudioFormat p0, AudioInputStream p1) {
    AudioSystem.getAudioInputStream(p0, p1);
  }

  @Test
  public void getAudioFileTypes_test_883(AudioInputStream p0) {
    AudioSystem.getAudioFileTypes(p0);
  }

  @Test
  public void getAudioFileTypes_test_884() {
    AudioSystem.getAudioFileTypes();
  }

  @Test
  public void isFileTypeSupported_test_885(AudioFileFormat.Type p0) {
    AudioSystem.isFileTypeSupported(p0);
  }

  @Test
  public void isFileTypeSupported_test_886(AudioFileFormat.Type p0, AudioInputStream p1) {
    AudioSystem.isFileTypeSupported(p0, p1);
  }

  @Test
  public void getMixer_test_887(Mixer.Info p0) {
    AudioSystem.getMixer(p0);
  }

  @Test
  public void getMixerInfo_test_888() {
    AudioSystem.getMixerInfo();
  }

  @Test
  public void getSourceLineInfo_test_889(Line.Info p0) {
    AudioSystem.getSourceLineInfo(p0);
  }

  @Test
  public void getTargetLineInfo_test_890(Line.Info p0) {
    AudioSystem.getTargetLineInfo(p0);
  }

  @Test
  public void isLineSupported_test_891(Line.Info p0) {
    AudioSystem.isLineSupported(p0);
  }

  @Test
  public void getTargetEncodings_test_892(AudioFormat.Encoding p0) {
    AudioSystem.getTargetEncodings(p0);
  }

  @Test
  public void getTargetEncodings_test_893(AudioFormat p0) {
    AudioSystem.getTargetEncodings(p0);
  }

  @Test
  public void isConversionSupported_test_894(AudioFormat p0, AudioFormat p1) {
    AudioSystem.isConversionSupported(p0, p1);
  }

  @Test
  public void isConversionSupported_test_895(AudioFormat.Encoding p0, AudioFormat p1) {
    AudioSystem.isConversionSupported(p0, p1);
  }

  @Test
  public void getTargetFormats_test_896(AudioFormat.Encoding p0, AudioFormat p1) {
    AudioSystem.getTargetFormats(p0, p1);
  }
}
