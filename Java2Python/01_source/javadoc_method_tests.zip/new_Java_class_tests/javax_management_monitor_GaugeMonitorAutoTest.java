package generated.test;

import java.lang.Number;
import javax.management.ObjectName;
import javax.management.monitor.GaugeMonitor;
import org.junit.jupiter.api.Test;

public class javax_management_monitor_GaugeMonitorAutoTest {
  @Test
  public void getDifferenceMode_test_5084() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDifferenceMode();
  }

  @Test
  public void setDifferenceMode_test_5085(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setDifferenceMode(p0);
  }

  @Test
  public void getNotificationInfo_test_5086() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_5087() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGauge_test_5088(ObjectName p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5089() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5090(ObjectName p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getHighThreshold_test_5091() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getHighThreshold();
  }

  @Test
  public void getLowThreshold_test_5092() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getLowThreshold();
  }

  @Test
  public void setThresholds_test_5093(Number p0, Number p1) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setThresholds(p0, p1);
  }

  @Test
  public void getNotifyHigh_test_5094() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotifyHigh();
  }

  @Test
  public void setNotifyHigh_test_5095(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setNotifyHigh(p0);
  }

  @Test
  public void getNotifyLow_test_5096() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotifyLow();
  }

  @Test
  public void setNotifyLow_test_5097(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setNotifyLow(p0);
  }

  @Test
  public void start_test_5098() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.start();
  }

  @Test
  public void stop_test_5099() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.stop();
  }
}
