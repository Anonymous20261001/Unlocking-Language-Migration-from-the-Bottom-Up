package generated.test;

import java.lang.Object;
import java.lang.String;
import jdk.dynalink.NamedOperation;
import jdk.dynalink.Operation;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_NamedOperationAutoTest {
  @Test
  public void getName_test_9477(Operation p0) {
    NamedOperation.getName(p0);
  }

  @Test
  public void getName_test_9478(Operation c0, Object c1) {
    NamedOperation instance = new NamedOperation(c0, c1);
    instance.getName();
  }

  @Test
  public void changeName_test_9479(String p0, Operation c0, Object c1) {
    NamedOperation instance = new NamedOperation(c0, c1);
    instance.changeName(p0);
  }

  @Test
  public void getBaseOperation_test_9480(Operation c0, Object c1) {
    NamedOperation instance = new NamedOperation(c0, c1);
    instance.getBaseOperation();
  }

  @Test
  public void getBaseOperation_test_9481(Operation p0) {
    NamedOperation.getBaseOperation(p0);
  }
}
