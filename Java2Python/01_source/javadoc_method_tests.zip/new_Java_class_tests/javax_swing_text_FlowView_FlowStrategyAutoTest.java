package generated.test;

import java.awt.Rectangle;
import javax.swing.event.DocumentEvent;
import javax.swing.text.FlowView;
import org.junit.jupiter.api.Test;

public class javax_swing_text_FlowView_FlowStrategyAutoTest {
  @Test
  public void layout_test_4909(FlowView p0) {
    FlowView.FlowStrategy instance = new FlowView.FlowStrategy();
    instance.layout(p0);
  }

  @Test
  public void insertUpdate_test_4910(FlowView p0, DocumentEvent p1, Rectangle p2) {
    FlowView.FlowStrategy instance = new FlowView.FlowStrategy();
    instance.insertUpdate(p0, p1, p2);
  }

  @Test
  public void changedUpdate_test_4911(FlowView p0, DocumentEvent p1, Rectangle p2) {
    FlowView.FlowStrategy instance = new FlowView.FlowStrategy();
    instance.changedUpdate(p0, p1, p2);
  }

  @Test
  public void removeUpdate_test_4912(FlowView p0, DocumentEvent p1, Rectangle p2) {
    FlowView.FlowStrategy instance = new FlowView.FlowStrategy();
    instance.removeUpdate(p0, p1, p2);
  }
}
