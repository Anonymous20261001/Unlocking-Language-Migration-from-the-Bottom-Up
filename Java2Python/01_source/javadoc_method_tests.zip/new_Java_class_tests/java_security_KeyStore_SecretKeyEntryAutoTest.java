package generated.test;

import java.security.KeyStore;
import javax.crypto.SecretKey;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_SecretKeyEntryAutoTest {
  @Test
  public void getSecretKey_test_7650(SecretKey c0) {
    KeyStore.SecretKeyEntry instance = new KeyStore.SecretKeyEntry(c0);
    instance.getSecretKey();
  }

  @Test
  public void getAttributes_test_7651(SecretKey c0) {
    KeyStore.SecretKeyEntry instance = new KeyStore.SecretKeyEntry(c0);
    instance.getAttributes();
  }
}
