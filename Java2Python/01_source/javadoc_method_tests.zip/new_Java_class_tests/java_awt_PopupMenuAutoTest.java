package generated.test;

import java.awt.Component;
import java.awt.PopupMenu;
import org.junit.jupiter.api.Test;

public class java_awt_PopupMenuAutoTest {
  @Test
  public void addNotify_test_9988() {
    PopupMenu instance = new PopupMenu();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_9989() {
    PopupMenu instance = new PopupMenu();
    instance.getAccessibleContext();
  }

  @Test
  public void show_test_9990(Component p0, int p1, int p2) {
    PopupMenu instance = new PopupMenu();
    instance.show(p0, p1, p2);
  }

  @Test
  public void getParent_test_9991() {
    PopupMenu instance = new PopupMenu();
    instance.getParent();
  }
}
