package generated.test;

import java.text.DateFormat;
import org.junit.jupiter.api.Test;

public class java_text_DateFormat_FieldAutoTest {
  @Test
  public void ofCalendarField_test_3328(int p0) {
    DateFormat.Field.ofCalendarField(p0);
  }
}
