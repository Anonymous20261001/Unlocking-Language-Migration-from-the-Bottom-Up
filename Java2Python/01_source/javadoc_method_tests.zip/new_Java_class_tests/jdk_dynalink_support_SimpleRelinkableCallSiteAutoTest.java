package generated.test;

import java.lang.invoke.MethodHandle;
import jdk.dynalink.CallSiteDescriptor;
import jdk.dynalink.linker.GuardedInvocation;
import jdk.dynalink.support.SimpleRelinkableCallSite;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_support_SimpleRelinkableCallSiteAutoTest {
  @Test
  public void relink_test_11178(GuardedInvocation p0, MethodHandle p1, CallSiteDescriptor c0) {
    SimpleRelinkableCallSite instance = new SimpleRelinkableCallSite(c0);
    instance.relink(p0, p1);
  }

  @Test
  public void resetAndRelink_test_11179(GuardedInvocation p0, MethodHandle p1,
      CallSiteDescriptor c0) {
    SimpleRelinkableCallSite instance = new SimpleRelinkableCallSite(c0);
    instance.resetAndRelink(p0, p1);
  }
}
