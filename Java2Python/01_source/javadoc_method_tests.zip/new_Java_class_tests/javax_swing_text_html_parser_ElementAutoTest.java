package generated.test;

import java.lang.String;
import javax.swing.text.html.parser.Element;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_parser_ElementAutoTest {
  @Test
  public void name2type_test_4462(String p0) {
    Element.name2type(p0);
  }
}
