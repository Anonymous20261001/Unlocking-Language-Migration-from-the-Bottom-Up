package generated.test;

import java.lang.invoke.MethodHandle;
import jdk.dynalink.linker.support.DefaultInternalObjectFilter;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_DefaultInternalObjectFilterAutoTest {
  @Test
  public void transform_test_3712(MethodHandle p0, MethodHandle c0, MethodHandle c1) {
    DefaultInternalObjectFilter instance = new DefaultInternalObjectFilter(c0, c1);
    instance.transform(p0);
  }
}
