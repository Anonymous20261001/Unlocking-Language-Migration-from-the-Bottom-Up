package generated.test;

import java.lang.Object;
import java.security.Guard;
import java.security.GuardedObject;
import org.junit.jupiter.api.Test;

public class java_security_GuardedObjectAutoTest {
  @Test
  public void getObject_test_5247(Object c0, Guard c1) {
    GuardedObject instance = new GuardedObject(c0, c1);
    instance.getObject();
  }
}
