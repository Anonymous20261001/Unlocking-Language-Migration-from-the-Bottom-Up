package generated.test;

import javax.net.ssl.SSLSocketFactory;
import org.junit.jupiter.api.Test;

public class javax_net_ssl_SSLSocketFactoryAutoTest {
  @Test
  public void getDefault_test_11440() {
    SSLSocketFactory.getDefault();
  }
}
