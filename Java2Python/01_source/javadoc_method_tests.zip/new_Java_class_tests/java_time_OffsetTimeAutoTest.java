package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalTime;
import java.time.OffsetTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_OffsetTimeAutoTest {
  @Test
  public void of_test_9651(LocalTime p0, ZoneOffset p1) {
    OffsetTime.of(p0, p1);
  }

  @Test
  public void of_test_9652(int p0, int p1, int p2, int p3, ZoneOffset p4) {
    OffsetTime.of(p0, p1, p2, p3, p4);
  }

  @Test
  public void from_test_9653(TemporalAccessor p0) {
    OffsetTime.from(p0);
  }

  @Test
  public void parse_test_9654(CharSequence p0) {
    OffsetTime.parse(p0);
  }

  @Test
  public void parse_test_9655(CharSequence p0, DateTimeFormatter p1) {
    OffsetTime.parse(p0, p1);
  }

  @Test
  public void now_test_9656() {
    OffsetTime.now();
  }

  @Test
  public void now_test_9657(Clock p0) {
    OffsetTime.now(p0);
  }

  @Test
  public void now_test_9658(ZoneId p0) {
    OffsetTime.now(p0);
  }

  @Test
  public void ofInstant_test_9659(Instant p0, ZoneId p1) {
    OffsetTime.ofInstant(p0, p1);
  }
}
