package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.lang.String;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.plaf.ColorChooserUI;
import org.junit.jupiter.api.Test;

public class javax_swing_JColorChooserAutoTest {
  @Test
  public void getUIClassID_test_6023() {
    JColorChooser instance = new JColorChooser();
    instance.getUIClassID();
  }

  @Test
  public void updateUI_test_6024() {
    JColorChooser instance = new JColorChooser();
    instance.updateUI();
  }

  @Test
  public void getUI_test_6025() {
    JColorChooser instance = new JColorChooser();
    instance.getUI();
  }

  @Test
  public void setUI_test_6026(ColorChooserUI p0) {
    JColorChooser instance = new JColorChooser();
    instance.setUI(p0);
  }

  @Test
  public void getAccessibleContext_test_6027() {
    JColorChooser instance = new JColorChooser();
    instance.getAccessibleContext();
  }

  @Test
  public void getColor_test_6028() {
    JColorChooser instance = new JColorChooser();
    instance.getColor();
  }

  @Test
  public void getSelectionModel_test_6029() {
    JColorChooser instance = new JColorChooser();
    instance.getSelectionModel();
  }

  @Test
  public void showDialog_test_6030(Component p0, String p1, Color p2) {
    JColorChooser.showDialog(p0, p1, p2);
  }

  @Test
  public void showDialog_test_6031(Component p0, String p1, Color p2, boolean p3) {
    JColorChooser.showDialog(p0, p1, p2, p3);
  }

  @Test
  public void getChooserPanels_test_6032() {
    JColorChooser instance = new JColorChooser();
    instance.getChooserPanels();
  }

  @Test
  public void createDialog_test_6033(Component p0, String p1, boolean p2, JColorChooser p3,
      ActionListener p4, ActionListener p5) {
    JColorChooser.createDialog(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getPreviewPanel_test_6034() {
    JColorChooser instance = new JColorChooser();
    instance.getPreviewPanel();
  }

  @Test
  public void setChooserPanels_test_6035(AbstractColorChooserPanel[] p0) {
    JColorChooser instance = new JColorChooser();
    instance.setChooserPanels(p0);
  }

  @Test
  public void setDragEnabled_test_6036(boolean p0) {
    JColorChooser instance = new JColorChooser();
    instance.setDragEnabled(p0);
  }

  @Test
  public void getDragEnabled_test_6037() {
    JColorChooser instance = new JColorChooser();
    instance.getDragEnabled();
  }

  @Test
  public void setPreviewPanel_test_6038(JComponent p0) {
    JColorChooser instance = new JColorChooser();
    instance.setPreviewPanel(p0);
  }

  @Test
  public void addChooserPanel_test_6039(AbstractColorChooserPanel p0) {
    JColorChooser instance = new JColorChooser();
    instance.addChooserPanel(p0);
  }

  @Test
  public void removeChooserPanel_test_6040(AbstractColorChooserPanel p0) {
    JColorChooser instance = new JColorChooser();
    instance.removeChooserPanel(p0);
  }

  @Test
  public void setSelectionModel_test_6041(ColorSelectionModel p0) {
    JColorChooser instance = new JColorChooser();
    instance.setSelectionModel(p0);
  }

  @Test
  public void setColor_test_6042(int p0, int p1, int p2) {
    JColorChooser instance = new JColorChooser();
    instance.setColor(p0, p1, p2);
  }

  @Test
  public void setColor_test_6043(int p0) {
    JColorChooser instance = new JColorChooser();
    instance.setColor(p0);
  }

  @Test
  public void setColor_test_6044(Color p0) {
    JColorChooser instance = new JColorChooser();
    instance.setColor(p0);
  }
}
