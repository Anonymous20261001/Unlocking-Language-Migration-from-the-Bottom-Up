package generated.test;

import java.awt.Component;
import java.awt.Image;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.plaf.LabelUI;
import org.junit.jupiter.api.Test;

public class javax_swing_JLabelAutoTest {
  @Test
  public void getDisplayedMnemonic_test_6349() {
    JLabel instance = new JLabel();
    instance.getDisplayedMnemonic();
  }

  @Test
  public void setDisplayedMnemonic_test_6350(int p0) {
    JLabel instance = new JLabel();
    instance.setDisplayedMnemonic(p0);
  }

  @Test
  public void setDisplayedMnemonic_test_6351(char p0) {
    JLabel instance = new JLabel();
    instance.setDisplayedMnemonic(p0);
  }

  @Test
  public void getLabelFor_test_6352() {
    JLabel instance = new JLabel();
    instance.getLabelFor();
  }

  @Test
  public void setLabelFor_test_6353(Component p0) {
    JLabel instance = new JLabel();
    instance.setLabelFor(p0);
  }

  @Test
  public void getUIClassID_test_6354() {
    JLabel instance = new JLabel();
    instance.getUIClassID();
  }

  @Test
  public void updateUI_test_6355() {
    JLabel instance = new JLabel();
    instance.updateUI();
  }

  @Test
  public void getUI_test_6356() {
    JLabel instance = new JLabel();
    instance.getUI();
  }

  @Test
  public void setUI_test_6357(LabelUI p0) {
    JLabel instance = new JLabel();
    instance.setUI(p0);
  }

  @Test
  public void getAccessibleContext_test_6358() {
    JLabel instance = new JLabel();
    instance.getAccessibleContext();
  }

  @Test
  public void imageUpdate_test_6359(Image p0, int p1, int p2, int p3, int p4, int p5) {
    JLabel instance = new JLabel();
    instance.imageUpdate(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getIcon_test_6360() {
    JLabel instance = new JLabel();
    instance.getIcon();
  }

  @Test
  public void getDisabledIcon_test_6361() {
    JLabel instance = new JLabel();
    instance.getDisabledIcon();
  }

  @Test
  public void setDisplayedMnemonicIndex_test_6362(int p0) {
    JLabel instance = new JLabel();
    instance.setDisplayedMnemonicIndex(p0);
  }

  @Test
  public void setText_test_6363(String p0) {
    JLabel instance = new JLabel();
    instance.setText(p0);
  }

  @Test
  public void setIcon_test_6364(Icon p0) {
    JLabel instance = new JLabel();
    instance.setIcon(p0);
  }

  @Test
  public void setDisabledIcon_test_6365(Icon p0) {
    JLabel instance = new JLabel();
    instance.setDisabledIcon(p0);
  }

  @Test
  public void setIconTextGap_test_6366(int p0) {
    JLabel instance = new JLabel();
    instance.setIconTextGap(p0);
  }

  @Test
  public void getVerticalAlignment_test_6367() {
    JLabel instance = new JLabel();
    instance.getVerticalAlignment();
  }

  @Test
  public void setVerticalAlignment_test_6368(int p0) {
    JLabel instance = new JLabel();
    instance.setVerticalAlignment(p0);
  }

  @Test
  public void getHorizontalAlignment_test_6369() {
    JLabel instance = new JLabel();
    instance.getHorizontalAlignment();
  }

  @Test
  public void setHorizontalAlignment_test_6370(int p0) {
    JLabel instance = new JLabel();
    instance.setHorizontalAlignment(p0);
  }

  @Test
  public void getVerticalTextPosition_test_6371() {
    JLabel instance = new JLabel();
    instance.getVerticalTextPosition();
  }

  @Test
  public void setVerticalTextPosition_test_6372(int p0) {
    JLabel instance = new JLabel();
    instance.setVerticalTextPosition(p0);
  }

  @Test
  public void getHorizontalTextPosition_test_6373() {
    JLabel instance = new JLabel();
    instance.getHorizontalTextPosition();
  }

  @Test
  public void setHorizontalTextPosition_test_6374(int p0) {
    JLabel instance = new JLabel();
    instance.setHorizontalTextPosition(p0);
  }

  @Test
  public void getIconTextGap_test_6375() {
    JLabel instance = new JLabel();
    instance.getIconTextGap();
  }

  @Test
  public void getDisplayedMnemonicIndex_test_6376() {
    JLabel instance = new JLabel();
    instance.getDisplayedMnemonicIndex();
  }

  @Test
  public void getText_test_6377() {
    JLabel instance = new JLabel();
    instance.getText();
  }
}
