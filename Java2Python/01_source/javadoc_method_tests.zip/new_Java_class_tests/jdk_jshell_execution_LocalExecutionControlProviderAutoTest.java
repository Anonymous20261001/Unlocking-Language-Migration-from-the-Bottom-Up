package generated.test;

import java.util.Map;
import jdk.jshell.execution.LocalExecutionControlProvider;
import jdk.jshell.spi.ExecutionEnv;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_LocalExecutionControlProviderAutoTest {
  @Test
  public void name_test_8076() {
    LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
    instance.name();
  }

  @Test
  public void generate_test_8077(ExecutionEnv p0, Map p1) {
    LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
    instance.generate(p0, p1);
  }

  @Test
  public void defaultParameters_test_8078() {
    LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
    instance.defaultParameters();
  }

  @Test
  public void createExecutionControl_test_8079(ExecutionEnv p0, Map p1) {
    LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
    instance.createExecutionControl(p0, p1);
  }
}
