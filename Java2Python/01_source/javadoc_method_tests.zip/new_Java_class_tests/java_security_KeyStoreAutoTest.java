package generated.test;

import java.security.KeyStore;
import org.junit.jupiter.api.Test;

public class java_security_KeyStoreAutoTest {
  @Test
  public void getDefaultType_test_7636() {
    KeyStore.getDefaultType();
  }
}
