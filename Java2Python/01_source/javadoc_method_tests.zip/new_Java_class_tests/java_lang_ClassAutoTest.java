package generated.test;

import java.lang.Class;
import java.lang.Module;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_ClassAutoTest {
  @Test
  public void forName_test_2310(Module p0, String p1) {
    Class.forName(p0, p1);
  }

  @Test
  public void forPrimitiveName_test_2311(String p0) {
    Class.forPrimitiveName(p0);
  }
}
