package generated.test;

import java.lang.CharSequence;
import java.lang.String;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;

public class java_util_regex_PatternAutoTest {
  @Test
  public void matches_test_9865(String p0, CharSequence p1) {
    Pattern.matches(p0, p1);
  }

  @Test
  public void compile_test_9866(String p0) {
    Pattern.compile(p0);
  }

  @Test
  public void compile_test_9867(String p0, int p1) {
    Pattern.compile(p0, p1);
  }

  @Test
  public void quote_test_9868(String p0) {
    Pattern.quote(p0);
  }
}
