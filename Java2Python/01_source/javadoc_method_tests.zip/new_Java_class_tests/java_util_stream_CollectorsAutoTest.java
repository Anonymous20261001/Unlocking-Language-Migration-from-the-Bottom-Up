package generated.test;

import java.lang.CharSequence;
import java.lang.Object;
import java.util.Comparator;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;

public class java_util_stream_CollectorsAutoTest {
  @Test
  public void joining_test_2424(CharSequence p0, CharSequence p1, CharSequence p2) {
    Collectors.joining(p0, p1, p2);
  }

  @Test
  public void joining_test_2425() {
    Collectors.joining();
  }

  @Test
  public void joining_test_2426(CharSequence p0) {
    Collectors.joining(p0);
  }

  @Test
  public void toList_test_2427() {
    Collectors.toList();
  }

  @Test
  public void toMap_test_2428(Function p0, Function p1, BinaryOperator p2) {
    Collectors.toMap(p0, p1, p2);
  }

  @Test
  public void toMap_test_2429(Function p0, Function p1) {
    Collectors.toMap(p0, p1);
  }

  @Test
  public void toMap_test_2430(Function p0, Function p1, BinaryOperator p2, Supplier p3) {
    Collectors.toMap(p0, p1, p2, p3);
  }

  @Test
  public void toSet_test_2431() {
    Collectors.toSet();
  }

  @Test
  public void maxBy_test_2432(Comparator p0) {
    Collectors.maxBy(p0);
  }

  @Test
  public void minBy_test_2433(Comparator p0) {
    Collectors.minBy(p0);
  }

  @Test
  public void mapping_test_2434(Function p0, Collector p1) {
    Collectors.mapping(p0, p1);
  }

  @Test
  public void groupingBy_test_2435(Function p0) {
    Collectors.groupingBy(p0);
  }

  @Test
  public void groupingBy_test_2436(Function p0, Supplier p1, Collector p2) {
    Collectors.groupingBy(p0, p1, p2);
  }

  @Test
  public void groupingBy_test_2437(Function p0, Collector p1) {
    Collectors.groupingBy(p0, p1);
  }

  @Test
  public void toCollection_test_2438(Supplier p0) {
    Collectors.toCollection(p0);
  }

  @Test
  public void summingLong_test_2439(ToLongFunction p0) {
    Collectors.summingLong(p0);
  }

  @Test
  public void reducing_test_2440(BinaryOperator p0) {
    Collectors.reducing(p0);
  }

  @Test
  public void reducing_test_2441(Object p0, Function p1, BinaryOperator p2) {
    Collectors.reducing(p0, p1, p2);
  }

  @Test
  public void reducing_test_2442(Object p0, BinaryOperator p1) {
    Collectors.reducing(p0, p1);
  }

  @Test
  public void groupingByConcurrent_test_2443(Function p0, Collector p1) {
    Collectors.groupingByConcurrent(p0, p1);
  }

  @Test
  public void groupingByConcurrent_test_2444(Function p0, Supplier p1, Collector p2) {
    Collectors.groupingByConcurrent(p0, p1, p2);
  }

  @Test
  public void groupingByConcurrent_test_2445(Function p0) {
    Collectors.groupingByConcurrent(p0);
  }

  @Test
  public void partitioningBy_test_2446(Predicate p0) {
    Collectors.partitioningBy(p0);
  }

  @Test
  public void partitioningBy_test_2447(Predicate p0, Collector p1) {
    Collectors.partitioningBy(p0, p1);
  }

  @Test
  public void collectingAndThen_test_2448(Collector p0, Function p1) {
    Collectors.collectingAndThen(p0, p1);
  }

  @Test
  public void toConcurrentMap_test_2449(Function p0, Function p1) {
    Collectors.toConcurrentMap(p0, p1);
  }

  @Test
  public void toConcurrentMap_test_2450(Function p0, Function p1, BinaryOperator p2, Supplier p3) {
    Collectors.toConcurrentMap(p0, p1, p2, p3);
  }

  @Test
  public void toConcurrentMap_test_2451(Function p0, Function p1, BinaryOperator p2) {
    Collectors.toConcurrentMap(p0, p1, p2);
  }

  @Test
  public void toUnmodifiableList_test_2452() {
    Collectors.toUnmodifiableList();
  }

  @Test
  public void toUnmodifiableSet_test_2453() {
    Collectors.toUnmodifiableSet();
  }

  @Test
  public void flatMapping_test_2454(Function p0, Collector p1) {
    Collectors.flatMapping(p0, p1);
  }

  @Test
  public void filtering_test_2455(Predicate p0, Collector p1) {
    Collectors.filtering(p0, p1);
  }

  @Test
  public void counting_test_2456() {
    Collectors.counting();
  }

  @Test
  public void summingInt_test_2457(ToIntFunction p0) {
    Collectors.summingInt(p0);
  }

  @Test
  public void summingDouble_test_2458(ToDoubleFunction p0) {
    Collectors.summingDouble(p0);
  }

  @Test
  public void averagingInt_test_2459(ToIntFunction p0) {
    Collectors.averagingInt(p0);
  }

  @Test
  public void averagingLong_test_2460(ToLongFunction p0) {
    Collectors.averagingLong(p0);
  }

  @Test
  public void averagingDouble_test_2461(ToDoubleFunction p0) {
    Collectors.averagingDouble(p0);
  }

  @Test
  public void toUnmodifiableMap_test_2462(Function p0, Function p1) {
    Collectors.toUnmodifiableMap(p0, p1);
  }

  @Test
  public void toUnmodifiableMap_test_2463(Function p0, Function p1, BinaryOperator p2) {
    Collectors.toUnmodifiableMap(p0, p1, p2);
  }

  @Test
  public void summarizingInt_test_2464(ToIntFunction p0) {
    Collectors.summarizingInt(p0);
  }

  @Test
  public void summarizingLong_test_2465(ToLongFunction p0) {
    Collectors.summarizingLong(p0);
  }

  @Test
  public void summarizingDouble_test_2466(ToDoubleFunction p0) {
    Collectors.summarizingDouble(p0);
  }

  @Test
  public void teeing_test_2467(Collector p0, Collector p1, BiFunction p2) {
    Collectors.teeing(p0, p1, p2);
  }
}
