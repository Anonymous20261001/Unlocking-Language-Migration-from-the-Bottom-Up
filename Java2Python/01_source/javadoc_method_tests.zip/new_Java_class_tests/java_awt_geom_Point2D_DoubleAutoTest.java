package generated.test;

import java.awt.geom.Point2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Point2D_DoubleAutoTest {
  @Test
  public void getX_test_9958() {
    Point2D.Double instance = new Point2D.Double();
    instance.getX();
  }

  @Test
  public void getY_test_9959() {
    Point2D.Double instance = new Point2D.Double();
    instance.getY();
  }

  @Test
  public void setLocation_test_9960(double p0, double p1) {
    Point2D.Double instance = new Point2D.Double();
    instance.setLocation(p0, p1);
  }
}
