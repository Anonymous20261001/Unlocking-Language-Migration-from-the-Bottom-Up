package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.stream.XMLOutputFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_stream_XMLOutputFactoryAutoTest {
  @Test
  public void newDefaultFactory_test_13639() {
    XMLOutputFactory.newDefaultFactory();
  }

  @Test
  public void newInstance_test_13640(String p0, ClassLoader p1) {
    XMLOutputFactory.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_13641() {
    XMLOutputFactory.newInstance();
  }

  @Test
  public void newFactory_test_13642() {
    XMLOutputFactory.newFactory();
  }

  @Test
  public void newFactory_test_13643(String p0, ClassLoader p1) {
    XMLOutputFactory.newFactory(p0, p1);
  }
}
