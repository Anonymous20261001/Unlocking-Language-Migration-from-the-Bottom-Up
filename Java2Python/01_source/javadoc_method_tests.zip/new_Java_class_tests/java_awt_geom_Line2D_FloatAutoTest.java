package generated.test;

import java.awt.geom.Line2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Line2D_FloatAutoTest {
  @Test
  public void setLine_test_7736(double p0, double p1, double p2, double p3) {
    Line2D.Float instance = new Line2D.Float();
    instance.setLine(p0, p1, p2, p3);
  }

  @Test
  public void setLine_test_7737(float p0, float p1, float p2, float p3) {
    Line2D.Float instance = new Line2D.Float();
    instance.setLine(p0, p1, p2, p3);
  }

  @Test
  public void getBounds2D_test_7738() {
    Line2D.Float instance = new Line2D.Float();
    instance.getBounds2D();
  }

  @Test
  public void getX1_test_7739() {
    Line2D.Float instance = new Line2D.Float();
    instance.getX1();
  }

  @Test
  public void getY1_test_7740() {
    Line2D.Float instance = new Line2D.Float();
    instance.getY1();
  }

  @Test
  public void getX2_test_7741() {
    Line2D.Float instance = new Line2D.Float();
    instance.getX2();
  }

  @Test
  public void getY2_test_7742() {
    Line2D.Float instance = new Line2D.Float();
    instance.getY2();
  }

  @Test
  public void getP1_test_7743() {
    Line2D.Float instance = new Line2D.Float();
    instance.getP1();
  }

  @Test
  public void getP2_test_7744() {
    Line2D.Float instance = new Line2D.Float();
    instance.getP2();
  }
}
