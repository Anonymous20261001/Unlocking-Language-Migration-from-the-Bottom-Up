package generated.test;

import java.lang.String;
import javax.swing.Action;
import javax.swing.text.JTextComponent;
import javax.swing.text.Keymap;
import org.junit.jupiter.api.Test;

public class javax_swing_text_JTextComponentAutoTest {
  @Test
  public void addKeymap_test_7310(String p0, Keymap p1) {
    JTextComponent.addKeymap(p0, p1);
  }

  @Test
  public void getKeymap_test_7311(String p0) {
    JTextComponent.getKeymap(p0);
  }

  @Test
  public void removeKeymap_test_7312(String p0) {
    JTextComponent.removeKeymap(p0);
  }

  @Test
  public void loadKeymap_test_7313(Keymap p0, JTextComponent.KeyBinding[] p1, Action[] p2) {
    JTextComponent.loadKeymap(p0, p1, p2);
  }
}
