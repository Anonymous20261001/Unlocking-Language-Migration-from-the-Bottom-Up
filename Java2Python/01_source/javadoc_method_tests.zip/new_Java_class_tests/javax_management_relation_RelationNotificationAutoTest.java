package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.List;
import javax.management.ObjectName;
import javax.management.relation.RelationNotification;
import org.junit.jupiter.api.Test;

public class javax_management_relation_RelationNotificationAutoTest {
  @Test
  public void getObjectName_test_10501(String c0, Object c1, long c2, long c3, String c4, String c5,
      String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getObjectName();
  }

  @Test
  public void getRelationId_test_10502(String c0, Object c1, long c2, long c3, String c4, String c5,
      String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getRelationId();
  }

  @Test
  public void getRelationTypeName_test_10503(String c0, Object c1, long c2, long c3, String c4,
      String c5, String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getRelationTypeName();
  }

  @Test
  public void getMBeansToUnregister_test_10504(String c0, Object c1, long c2, long c3, String c4,
      String c5, String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getMBeansToUnregister();
  }

  @Test
  public void getRoleName_test_10505(String c0, Object c1, long c2, long c3, String c4, String c5,
      String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getRoleName();
  }

  @Test
  public void getOldRoleValue_test_10506(String c0, Object c1, long c2, long c3, String c4,
      String c5, String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getOldRoleValue();
  }

  @Test
  public void getNewRoleValue_test_10507(String c0, Object c1, long c2, long c3, String c4,
      String c5, String c6, ObjectName c7, List c8) {
    RelationNotification instance = new RelationNotification(c0, c1, c2, c3, c4, c5, c6, c7, c8);
    instance.getNewRoleValue();
  }
}
