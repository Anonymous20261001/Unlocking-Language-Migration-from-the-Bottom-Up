package generated.test;

import java.awt.ComponentOrientation;
import javax.swing.JSpinner;
import org.junit.jupiter.api.Test;

public class javax_swing_JSpinner_NumberEditorAutoTest {
  @Test
  public void setComponentOrientation_test_7016(ComponentOrientation p0, JSpinner c0) {
    JSpinner.NumberEditor instance = new JSpinner.NumberEditor(c0);
    instance.setComponentOrientation(p0);
  }

  @Test
  public void getModel_test_7017(JSpinner c0) {
    JSpinner.NumberEditor instance = new JSpinner.NumberEditor(c0);
    instance.getModel();
  }

  @Test
  public void getFormat_test_7018(JSpinner c0) {
    JSpinner.NumberEditor instance = new JSpinner.NumberEditor(c0);
    instance.getFormat();
  }
}
