package generated.test;

import java.lang.String;
import javax.swing.Spring;
import javax.swing.SpringLayout;
import org.junit.jupiter.api.Test;

public class javax_swing_SpringLayout_ConstraintsAutoTest {
  @Test
  public void setWidth_test_11382(Spring p0) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.setWidth(p0);
  }

  @Test
  public void getWidth_test_11383() {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_11384() {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.getHeight();
  }

  @Test
  public void getX_test_11385() {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.getX();
  }

  @Test
  public void getY_test_11386() {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.getY();
  }

  @Test
  public void setX_test_11387(Spring p0) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.setX(p0);
  }

  @Test
  public void setY_test_11388(Spring p0) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.setY(p0);
  }

  @Test
  public void setHeight_test_11389(Spring p0) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.setHeight(p0);
  }

  @Test
  public void getConstraint_test_11390(String p0) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.getConstraint(p0);
  }

  @Test
  public void setConstraint_test_11391(String p0, Spring p1) {
    SpringLayout.Constraints instance = new SpringLayout.Constraints();
    instance.setConstraint(p0, p1);
  }
}
