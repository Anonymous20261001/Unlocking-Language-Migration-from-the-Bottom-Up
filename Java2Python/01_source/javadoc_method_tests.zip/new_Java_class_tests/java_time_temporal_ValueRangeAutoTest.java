package generated.test;

import java.time.temporal.ValueRange;
import org.junit.jupiter.api.Test;

public class java_time_temporal_ValueRangeAutoTest {
  @Test
  public void of_test_13306(long p0, long p1) {
    ValueRange.of(p0, p1);
  }

  @Test
  public void of_test_13307(long p0, long p1, long p2, long p3) {
    ValueRange.of(p0, p1, p2, p3);
  }

  @Test
  public void of_test_13308(long p0, long p1, long p2) {
    ValueRange.of(p0, p1, p2);
  }
}
