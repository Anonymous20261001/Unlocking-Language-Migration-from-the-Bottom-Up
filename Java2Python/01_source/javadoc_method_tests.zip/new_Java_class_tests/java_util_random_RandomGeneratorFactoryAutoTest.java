package generated.test;

import java.lang.String;
import java.util.random.RandomGeneratorFactory;
import org.junit.jupiter.api.Test;

public class java_util_random_RandomGeneratorFactoryAutoTest {
  @Test
  public void of_test_10322(String p0) {
    RandomGeneratorFactory.of(p0);
  }

  @Test
  public void getDefault_test_10323() {
    RandomGeneratorFactory.getDefault();
  }

  @Test
  public void all_test_10324() {
    RandomGeneratorFactory.all();
  }
}
