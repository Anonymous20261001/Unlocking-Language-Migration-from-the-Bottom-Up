package generated.test;

import java.io.File;
import java.lang.String;
import java.security.KeyStore;
import java.security.Provider;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_BuilderAutoTest {
  @Test
  public void newInstance_test_7637(String p0, Provider p1, KeyStore.ProtectionParameter p2) {
    KeyStore.Builder.newInstance(p0, p1, p2);
  }

  @Test
  public void newInstance_test_7638(File p0, KeyStore.ProtectionParameter p1) {
    KeyStore.Builder.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_7639(String p0, Provider p1, File p2,
      KeyStore.ProtectionParameter p3) {
    KeyStore.Builder.newInstance(p0, p1, p2, p3);
  }

  @Test
  public void newInstance_test_7640(KeyStore p0, KeyStore.ProtectionParameter p1) {
    KeyStore.Builder.newInstance(p0, p1);
  }
}
