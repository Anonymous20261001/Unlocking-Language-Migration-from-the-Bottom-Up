package generated.test;

import java.lang.Class;
import java.lang.Iterable;
import jdk.dynalink.linker.support.CompositeTypeBasedGuardingDynamicLinker;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_CompositeTypeBasedGuardingDynamicLinkerAutoTest {
  @Test
  public void optimize_test_2692(Iterable p0) {
    CompositeTypeBasedGuardingDynamicLinker.optimize(p0);
  }

  @Test
  public void canLinkType_test_2693(Class p0, Iterable c0) {
    CompositeTypeBasedGuardingDynamicLinker instance = new CompositeTypeBasedGuardingDynamicLinker(c0);
    instance.canLinkType(p0);
  }
}
