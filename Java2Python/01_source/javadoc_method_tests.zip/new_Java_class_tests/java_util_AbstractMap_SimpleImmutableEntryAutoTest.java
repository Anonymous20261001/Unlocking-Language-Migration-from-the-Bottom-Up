package generated.test;

import java.lang.Object;
import java.util.AbstractMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_util_AbstractMap_SimpleImmutableEntryAutoTest {
  @Test
  public void getValue_test_11(Map.Entry c0) {
    AbstractMap.SimpleImmutableEntry instance = new AbstractMap.SimpleImmutableEntry(c0);
    instance.getValue();
  }

  @Test
  public void getKey_test_12(Map.Entry c0) {
    AbstractMap.SimpleImmutableEntry instance = new AbstractMap.SimpleImmutableEntry(c0);
    instance.getKey();
  }

  @Test
  public void setValue_test_13(Object p0, Map.Entry c0) {
    AbstractMap.SimpleImmutableEntry instance = new AbstractMap.SimpleImmutableEntry(c0);
    instance.setValue(p0);
  }
}
