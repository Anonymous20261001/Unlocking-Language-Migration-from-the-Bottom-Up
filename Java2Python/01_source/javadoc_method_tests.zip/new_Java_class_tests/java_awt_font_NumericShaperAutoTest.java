package generated.test;

import java.awt.font.NumericShaper;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class java_awt_font_NumericShaperAutoTest {
  @Test
  public void getShaper_test_9579(int p0) {
    NumericShaper.getShaper(p0);
  }

  @Test
  public void getShaper_test_9580(NumericShaper.Range p0) {
    NumericShaper.getShaper(p0);
  }

  @Test
  public void getContextualShaper_test_9581(Set p0) {
    NumericShaper.getContextualShaper(p0);
  }

  @Test
  public void getContextualShaper_test_9582(int p0) {
    NumericShaper.getContextualShaper(p0);
  }

  @Test
  public void getContextualShaper_test_9583(int p0, int p1) {
    NumericShaper.getContextualShaper(p0, p1);
  }

  @Test
  public void getContextualShaper_test_9584(Set p0, NumericShaper.Range p1) {
    NumericShaper.getContextualShaper(p0, p1);
  }
}
