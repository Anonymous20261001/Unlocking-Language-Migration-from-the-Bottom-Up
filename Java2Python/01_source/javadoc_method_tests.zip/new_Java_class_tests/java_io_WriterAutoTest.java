package generated.test;

import java.io.Writer;
import org.junit.jupiter.api.Test;

public class java_io_WriterAutoTest {
  @Test
  public void nullWriter_test_13550() {
    Writer.nullWriter();
  }
}
