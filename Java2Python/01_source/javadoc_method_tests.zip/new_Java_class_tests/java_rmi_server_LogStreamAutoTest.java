package generated.test;

import java.io.PrintStream;
import java.lang.String;
import java.rmi.server.LogStream;
import org.junit.jupiter.api.Test;

public class java_rmi_server_LogStreamAutoTest {
  @Test
  public void getDefaultStream_test_8139() {
    LogStream.getDefaultStream();
  }

  @Test
  public void setDefaultStream_test_8140(PrintStream p0) {
    LogStream.setDefaultStream(p0);
  }

  @Test
  public void parseLevel_test_8141(String p0) {
    LogStream.parseLevel(p0);
  }

  @Test
  public void log_test_8142(String p0) {
    LogStream.log(p0);
  }
}
