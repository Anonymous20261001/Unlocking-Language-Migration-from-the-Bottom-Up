package generated.test;

import java.lang.Class;
import java.lang.ClassLoader;
import java.lang.ModuleLayer;
import java.util.ServiceLoader;
import org.junit.jupiter.api.Test;

public class java_util_ServiceLoaderAutoTest {
  @Test
  public void load_test_11048(Class p0) {
    ServiceLoader.load(p0);
  }

  @Test
  public void load_test_11049(ModuleLayer p0, Class p1) {
    ServiceLoader.load(p0, p1);
  }

  @Test
  public void load_test_11050(Class p0, ClassLoader p1) {
    ServiceLoader.load(p0, p1);
  }

  @Test
  public void loadInstalled_test_11051(Class p0) {
    ServiceLoader.loadInstalled(p0);
  }
}
