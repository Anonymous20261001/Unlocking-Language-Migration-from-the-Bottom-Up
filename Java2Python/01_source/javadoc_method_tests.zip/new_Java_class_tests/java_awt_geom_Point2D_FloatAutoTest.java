package generated.test;

import java.awt.geom.Point2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Point2D_FloatAutoTest {
  @Test
  public void getX_test_9961() {
    Point2D.Float instance = new Point2D.Float();
    instance.getX();
  }

  @Test
  public void getY_test_9962() {
    Point2D.Float instance = new Point2D.Float();
    instance.getY();
  }

  @Test
  public void setLocation_test_9963(double p0, double p1) {
    Point2D.Float instance = new Point2D.Float();
    instance.setLocation(p0, p1);
  }

  @Test
  public void setLocation_test_9964(float p0, float p1) {
    Point2D.Float instance = new Point2D.Float();
    instance.setLocation(p0, p1);
  }
}
