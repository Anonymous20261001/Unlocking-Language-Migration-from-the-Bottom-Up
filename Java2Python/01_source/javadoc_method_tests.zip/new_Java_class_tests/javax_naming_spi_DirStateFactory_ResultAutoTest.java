package generated.test;

import java.lang.Object;
import javax.naming.directory.Attributes;
import javax.naming.spi.DirStateFactory;
import org.junit.jupiter.api.Test;

public class javax_naming_spi_DirStateFactory_ResultAutoTest {
  @Test
  public void getAttributes_test_4183(Object c0, Attributes c1) {
    DirStateFactory.Result instance = new DirStateFactory.Result(c0, c1);
    instance.getAttributes();
  }

  @Test
  public void getObject_test_4184(Object c0, Attributes c1) {
    DirStateFactory.Result instance = new DirStateFactory.Result(c0, c1);
    instance.getObject();
  }
}
