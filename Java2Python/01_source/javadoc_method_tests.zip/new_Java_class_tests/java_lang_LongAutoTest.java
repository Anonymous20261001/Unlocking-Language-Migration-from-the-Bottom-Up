package generated.test;

import java.lang.CharSequence;
import java.lang.Long;
import java.lang.String;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class java_lang_LongAutoTest {
  @Test
  public void numberOfLeadingZeros_test_8143(long p0) {
    Long.numberOfLeadingZeros(p0);
  }

  @Test
  public void numberOfTrailingZeros_test_8144(long p0) {
    Long.numberOfTrailingZeros(p0);
  }

  @Test
  public void bitCount_test_8145(long p0) {
    Long.bitCount(p0);
  }

  @Test
  public void min_test_8146(long p0, long p1) {
    Long.min(p0, p1);
  }

  @Test
  public void max_test_8147(long p0, long p1) {
    Long.max(p0, p1);
  }

  @Test
  public void signum_test_8148(long p0) {
    Long.signum(p0);
  }

  @Test
  public void expand_test_8149(long p0, long p1) {
    Long.expand(p0, p1);
  }

  @Test
  public void compareUnsigned_test_8150(long p0, long p1) {
    Long.compareUnsigned(p0, p1);
  }

  @Test
  public void divideUnsigned_test_8151(long p0, long p1) {
    Long.divideUnsigned(p0, p1);
  }

  @Test
  public void remainderUnsigned_test_8152(long p0, long p1) {
    Long.remainderUnsigned(p0, p1);
  }

  @Test
  public void reverse_test_8153(long p0) {
    Long.reverse(p0);
  }

  @Test
  public void reverseBytes_test_8154(long p0) {
    Long.reverseBytes(p0);
  }

  @Test
  public void compress_test_8155(long p0, long p1) {
    Long.compress(p0, p1);
  }

  @Test
  public void compareTo_test_8156(Long p0, String c0) {
    Long instance = new Long(c0);
    instance.compareTo(p0);
  }

  @Test
  public void getLong_test_8157(String p0, Long p1) {
    Long.getLong(p0, p1);
  }

  @Test
  public void getLong_test_8158(String p0) {
    Long.getLong(p0);
  }

  @Test
  public void getLong_test_8159(String p0, long p1) {
    Long.getLong(p0, p1);
  }

  @Test
  public void compare_test_8160(long p0, long p1) {
    Long.compare(p0, p1);
  }

  @Test
  public void byteValue_test_8161(String c0) {
    Long instance = new Long(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_8162(String c0) {
    Long instance = new Long(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_8163(String c0) {
    Long instance = new Long(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_8164(String c0) {
    Long instance = new Long(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_8165(String c0) {
    Long instance = new Long(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_8166(String c0) {
    Long instance = new Long(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_8167(long p0) {
    Long.valueOf(p0);
  }

  @Test
  public void valueOf_test_8168(String p0) {
    Long.valueOf(p0);
  }

  @Test
  public void valueOf_test_8169(String p0, int p1) {
    Long.valueOf(p0, p1);
  }

  @Test
  public void toHexString_test_8170(long p0) {
    Long.toHexString(p0);
  }

  @Test
  public void decode_test_8171(String p0) {
    Long.decode(p0);
  }

  @Test
  public void resolveConstantDesc_test_8172(MethodHandles.Lookup p0, String c0) {
    Long instance = new Long(c0);
    instance.resolveConstantDesc(p0);
  }

  @Test
  public void describeConstable_test_8173(String c0) {
    Long instance = new Long(c0);
    instance.describeConstable();
  }

  @Test
  public void sum_test_8174(long p0, long p1) {
    Long.sum(p0, p1);
  }

  @Test
  public void toUnsignedString_test_8175(long p0) {
    Long.toUnsignedString(p0);
  }

  @Test
  public void toUnsignedString_test_8176(long p0, int p1) {
    Long.toUnsignedString(p0, p1);
  }

  @Test
  public void toOctalString_test_8177(long p0) {
    Long.toOctalString(p0);
  }

  @Test
  public void toBinaryString_test_8178(long p0) {
    Long.toBinaryString(p0);
  }

  @Test
  public void highestOneBit_test_8179(long p0) {
    Long.highestOneBit(p0);
  }

  @Test
  public void lowestOneBit_test_8180(long p0) {
    Long.lowestOneBit(p0);
  }

  @Test
  public void rotateLeft_test_8181(long p0, int p1) {
    Long.rotateLeft(p0, p1);
  }

  @Test
  public void rotateRight_test_8182(long p0, int p1) {
    Long.rotateRight(p0, p1);
  }

  @Test
  public void parseLong_test_8183(String p0) {
    Long.parseLong(p0);
  }

  @Test
  public void parseLong_test_8184(String p0, int p1) {
    Long.parseLong(p0, p1);
  }

  @Test
  public void parseLong_test_8185(CharSequence p0, int p1, int p2, int p3) {
    Long.parseLong(p0, p1, p2, p3);
  }

  @Test
  public void parseUnsignedLong_test_8186(String p0) {
    Long.parseUnsignedLong(p0);
  }

  @Test
  public void parseUnsignedLong_test_8187(String p0, int p1) {
    Long.parseUnsignedLong(p0, p1);
  }

  @Test
  public void parseUnsignedLong_test_8188(CharSequence p0, int p1, int p2, int p3) {
    Long.parseUnsignedLong(p0, p1, p2, p3);
  }
}
