package generated.test;

import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Path2DAutoTest {
  @Test
  public void contains_test_9835(PathIterator p0, double p1, double p2, double p3, double p4) {
    Path2D.contains(p0, p1, p2, p3, p4);
  }

  @Test
  public void contains_test_9836(PathIterator p0, Rectangle2D p1) {
    Path2D.contains(p0, p1);
  }

  @Test
  public void contains_test_9837(PathIterator p0, double p1, double p2) {
    Path2D.contains(p0, p1, p2);
  }

  @Test
  public void contains_test_9838(PathIterator p0, Point2D p1) {
    Path2D.contains(p0, p1);
  }

  @Test
  public void intersects_test_9839(PathIterator p0, double p1, double p2, double p3, double p4) {
    Path2D.intersects(p0, p1, p2, p3, p4);
  }

  @Test
  public void intersects_test_9840(PathIterator p0, Rectangle2D p1) {
    Path2D.intersects(p0, p1);
  }
}
