package generated.test;

import java.awt.geom.QuadCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_QuadCurve2D_DoubleAutoTest {
  @Test
  public void setCurve_test_10243(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.setCurve(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getCtrlX_test_10244() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getCtrlX();
  }

  @Test
  public void getCtrlY_test_10245() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getCtrlY();
  }

  @Test
  public void getCtrlPt_test_10246() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getCtrlPt();
  }

  @Test
  public void getX1_test_10247() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getX1();
  }

  @Test
  public void getY1_test_10248() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getY1();
  }

  @Test
  public void getX2_test_10249() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getX2();
  }

  @Test
  public void getY2_test_10250() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getY2();
  }

  @Test
  public void getP1_test_10251() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getP1();
  }

  @Test
  public void getP2_test_10252() {
    QuadCurve2D.Double instance = new QuadCurve2D.Double();
    instance.getP2();
  }
}
