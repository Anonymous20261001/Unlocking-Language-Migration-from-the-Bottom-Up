package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.stream.XMLEventFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_stream_XMLEventFactoryAutoTest {
  @Test
  public void newDefaultFactory_test_13626() {
    XMLEventFactory.newDefaultFactory();
  }

  @Test
  public void newInstance_test_13627(String p0, ClassLoader p1) {
    XMLEventFactory.newInstance(p0, p1);
  }

  @Test
  public void newInstance_test_13628() {
    XMLEventFactory.newInstance();
  }

  @Test
  public void newFactory_test_13629(String p0, ClassLoader p1) {
    XMLEventFactory.newFactory(p0, p1);
  }

  @Test
  public void newFactory_test_13630() {
    XMLEventFactory.newFactory();
  }
}
