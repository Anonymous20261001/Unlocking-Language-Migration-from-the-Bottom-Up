package generated.test;

import java.time.Clock;
import java.time.ZoneId;
import java.time.chrono.JapaneseDate;
import java.time.chrono.JapaneseEra;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_chrono_JapaneseDateAutoTest {
  @Test
  public void of_test_5968(int p0, int p1, int p2) {
    JapaneseDate.of(p0, p1, p2);
  }

  @Test
  public void of_test_5969(JapaneseEra p0, int p1, int p2, int p3) {
    JapaneseDate.of(p0, p1, p2, p3);
  }

  @Test
  public void from_test_5970(TemporalAccessor p0) {
    JapaneseDate.from(p0);
  }

  @Test
  public void now_test_5971() {
    JapaneseDate.now();
  }

  @Test
  public void now_test_5972(ZoneId p0) {
    JapaneseDate.now(p0);
  }

  @Test
  public void now_test_5973(Clock p0) {
    JapaneseDate.now(p0);
  }
}
