package generated.test;

import java.awt.Taskbar;
import org.junit.jupiter.api.Test;

public class java_awt_TaskbarAutoTest {
  @Test
  public void getTaskbar_test_12518() {
    Taskbar.getTaskbar();
  }

  @Test
  public void isTaskbarSupported_test_12519() {
    Taskbar.isTaskbarSupported();
  }
}
