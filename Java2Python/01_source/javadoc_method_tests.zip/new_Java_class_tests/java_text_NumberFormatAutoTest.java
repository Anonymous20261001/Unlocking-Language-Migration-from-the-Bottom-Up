package generated.test;

import java.text.NumberFormat;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_text_NumberFormatAutoTest {
  @Test
  public void getInstance_test_9557(Locale p0) {
    NumberFormat.getInstance(p0);
  }

  @Test
  public void getInstance_test_9558() {
    NumberFormat.getInstance();
  }

  @Test
  public void getAvailableLocales_test_9559() {
    NumberFormat.getAvailableLocales();
  }

  @Test
  public void getCurrencyInstance_test_9560(Locale p0) {
    NumberFormat.getCurrencyInstance(p0);
  }

  @Test
  public void getCurrencyInstance_test_9561() {
    NumberFormat.getCurrencyInstance();
  }

  @Test
  public void getPercentInstance_test_9562() {
    NumberFormat.getPercentInstance();
  }

  @Test
  public void getPercentInstance_test_9563(Locale p0) {
    NumberFormat.getPercentInstance(p0);
  }

  @Test
  public void getIntegerInstance_test_9564(Locale p0) {
    NumberFormat.getIntegerInstance(p0);
  }

  @Test
  public void getIntegerInstance_test_9565() {
    NumberFormat.getIntegerInstance();
  }

  @Test
  public void getCompactNumberInstance_test_9566(Locale p0, NumberFormat.Style p1) {
    NumberFormat.getCompactNumberInstance(p0, p1);
  }

  @Test
  public void getCompactNumberInstance_test_9567() {
    NumberFormat.getCompactNumberInstance();
  }

  @Test
  public void getNumberInstance_test_9568() {
    NumberFormat.getNumberInstance();
  }

  @Test
  public void getNumberInstance_test_9569(Locale p0) {
    NumberFormat.getNumberInstance(p0);
  }
}
