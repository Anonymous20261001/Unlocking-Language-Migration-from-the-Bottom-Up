package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_ItalicActionAutoTest {
  @Test
  public void actionPerformed_test_12006(ActionEvent p0) {
    StyledEditorKit.ItalicAction instance = new StyledEditorKit.ItalicAction();
    instance.actionPerformed(p0);
  }
}
