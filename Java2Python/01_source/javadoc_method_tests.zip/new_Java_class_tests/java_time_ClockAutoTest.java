package generated.test;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import org.junit.jupiter.api.Test;

public class java_time_ClockAutoTest {
  @Test
  public void offset_test_2329(Clock p0, Duration p1) {
    Clock.offset(p0, p1);
  }

  @Test
  public void system_test_2330(ZoneId p0) {
    Clock.system(p0);
  }

  @Test
  public void fixed_test_2331(Instant p0, ZoneId p1) {
    Clock.fixed(p0, p1);
  }

  @Test
  public void systemUTC_test_2332() {
    Clock.systemUTC();
  }

  @Test
  public void systemDefaultZone_test_2333() {
    Clock.systemDefaultZone();
  }

  @Test
  public void tickMillis_test_2334(ZoneId p0) {
    Clock.tickMillis(p0);
  }

  @Test
  public void tickSeconds_test_2335(ZoneId p0) {
    Clock.tickSeconds(p0);
  }

  @Test
  public void tickMinutes_test_2336(ZoneId p0) {
    Clock.tickMinutes(p0);
  }

  @Test
  public void tick_test_2337(Clock p0, Duration p1) {
    Clock.tick(p0, p1);
  }
}
