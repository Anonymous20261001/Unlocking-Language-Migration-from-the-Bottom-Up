package generated.test;

import java.security.cert.CertPathValidator;
import org.junit.jupiter.api.Test;

public class java_security_cert_CertPathValidatorAutoTest {
  @Test
  public void getDefaultType_test_2101() {
    CertPathValidator.getDefaultType();
  }
}
