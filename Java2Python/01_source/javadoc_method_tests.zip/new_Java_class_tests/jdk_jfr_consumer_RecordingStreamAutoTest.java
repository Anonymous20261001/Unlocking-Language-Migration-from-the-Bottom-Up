package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.Runnable;
import java.lang.String;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.function.Consumer;
import jdk.jfr.consumer.RecordingStream;
import org.junit.jupiter.api.Test;

public class jdk_jfr_consumer_RecordingStreamAutoTest {
  @Test
  public void onError_test_10378(Consumer p0) {
    RecordingStream instance = new RecordingStream();
    instance.onError(p0);
  }

  @Test
  public void setMaxAge_test_10379(Duration p0) {
    RecordingStream instance = new RecordingStream();
    instance.setMaxAge(p0);
  }

  @Test
  public void setSettings_test_10380(Map p0) {
    RecordingStream instance = new RecordingStream();
    instance.setSettings(p0);
  }

  @Test
  public void setStartTime_test_10381(Instant p0) {
    RecordingStream instance = new RecordingStream();
    instance.setStartTime(p0);
  }

  @Test
  public void setMaxSize_test_10382(long p0) {
    RecordingStream instance = new RecordingStream();
    instance.setMaxSize(p0);
  }

  @Test
  public void setOrdered_test_10383(boolean p0) {
    RecordingStream instance = new RecordingStream();
    instance.setOrdered(p0);
  }

  @Test
  public void setReuse_test_10384(boolean p0) {
    RecordingStream instance = new RecordingStream();
    instance.setReuse(p0);
  }

  @Test
  public void setEndTime_test_10385(Instant p0) {
    RecordingStream instance = new RecordingStream();
    instance.setEndTime(p0);
  }

  @Test
  public void onEvent_test_10386(Consumer p0) {
    RecordingStream instance = new RecordingStream();
    instance.onEvent(p0);
  }

  @Test
  public void onEvent_test_10387(String p0, Consumer p1) {
    RecordingStream instance = new RecordingStream();
    instance.onEvent(p0, p1);
  }

  @Test
  public void onFlush_test_10388(Runnable p0) {
    RecordingStream instance = new RecordingStream();
    instance.onFlush(p0);
  }

  @Test
  public void startAsync_test_10389() {
    RecordingStream instance = new RecordingStream();
    instance.startAsync();
  }

  @Test
  public void onMetadata_test_10390(Consumer p0) {
    RecordingStream instance = new RecordingStream();
    instance.onMetadata(p0);
  }

  @Test
  public void remove_test_10391(Object p0) {
    RecordingStream instance = new RecordingStream();
    instance.remove(p0);
  }

  @Test
  public void start_test_10392() {
    RecordingStream instance = new RecordingStream();
    instance.start();
  }

  @Test
  public void stop_test_10393() {
    RecordingStream instance = new RecordingStream();
    instance.stop();
  }

  @Test
  public void close_test_10394() {
    RecordingStream instance = new RecordingStream();
    instance.close();
  }

  @Test
  public void enable_test_10395(Class p0) {
    RecordingStream instance = new RecordingStream();
    instance.enable(p0);
  }

  @Test
  public void enable_test_10396(String p0) {
    RecordingStream instance = new RecordingStream();
    instance.enable(p0);
  }

  @Test
  public void onClose_test_10397(Runnable p0) {
    RecordingStream instance = new RecordingStream();
    instance.onClose(p0);
  }

  @Test
  public void disable_test_10398(Class p0) {
    RecordingStream instance = new RecordingStream();
    instance.disable(p0);
  }

  @Test
  public void disable_test_10399(String p0) {
    RecordingStream instance = new RecordingStream();
    instance.disable(p0);
  }
}
