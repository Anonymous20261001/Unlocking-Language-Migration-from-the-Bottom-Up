package generated.test;

import java.security.KeyStore;
import java.security.cert.Certificate;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_TrustedCertificateEntryAutoTest {
  @Test
  public void getTrustedCertificate_test_7652(Certificate c0) {
    KeyStore.TrustedCertificateEntry instance = new KeyStore.TrustedCertificateEntry(c0);
    instance.getTrustedCertificate();
  }

  @Test
  public void getAttributes_test_7653(Certificate c0) {
    KeyStore.TrustedCertificateEntry instance = new KeyStore.TrustedCertificateEntry(c0);
    instance.getAttributes();
  }
}
