package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.text.AttributeSet;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.TabSet;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyleConstantsAutoTest {
  @Test
  public void setFontFamily_test_11929(MutableAttributeSet p0, String p1) {
    StyleConstants.setFontFamily(p0, p1);
  }

  @Test
  public void setFontSize_test_11930(MutableAttributeSet p0, int p1) {
    StyleConstants.setFontSize(p0, p1);
  }

  @Test
  public void isBold_test_11931(AttributeSet p0) {
    StyleConstants.isBold(p0);
  }

  @Test
  public void setBold_test_11932(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setBold(p0, p1);
  }

  @Test
  public void isItalic_test_11933(AttributeSet p0) {
    StyleConstants.isItalic(p0);
  }

  @Test
  public void setItalic_test_11934(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setItalic(p0, p1);
  }

  @Test
  public void setBidiLevel_test_11935(MutableAttributeSet p0, int p1) {
    StyleConstants.setBidiLevel(p0, p1);
  }

  @Test
  public void isUnderline_test_11936(AttributeSet p0) {
    StyleConstants.isUnderline(p0);
  }

  @Test
  public void isStrikeThrough_test_11937(AttributeSet p0) {
    StyleConstants.isStrikeThrough(p0);
  }

  @Test
  public void setStrikeThrough_test_11938(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setStrikeThrough(p0, p1);
  }

  @Test
  public void setSubscript_test_11939(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setSubscript(p0, p1);
  }

  @Test
  public void getFirstLineIndent_test_11940(AttributeSet p0) {
    StyleConstants.getFirstLineIndent(p0);
  }

  @Test
  public void setFirstLineIndent_test_11941(MutableAttributeSet p0, float p1) {
    StyleConstants.setFirstLineIndent(p0, p1);
  }

  @Test
  public void setRightIndent_test_11942(MutableAttributeSet p0, float p1) {
    StyleConstants.setRightIndent(p0, p1);
  }

  @Test
  public void setLeftIndent_test_11943(MutableAttributeSet p0, float p1) {
    StyleConstants.setLeftIndent(p0, p1);
  }

  @Test
  public void getLineSpacing_test_11944(AttributeSet p0) {
    StyleConstants.getLineSpacing(p0);
  }

  @Test
  public void setLineSpacing_test_11945(MutableAttributeSet p0, float p1) {
    StyleConstants.setLineSpacing(p0, p1);
  }

  @Test
  public void setSpaceAbove_test_11946(MutableAttributeSet p0, float p1) {
    StyleConstants.setSpaceAbove(p0, p1);
  }

  @Test
  public void setSpaceBelow_test_11947(MutableAttributeSet p0, float p1) {
    StyleConstants.setSpaceBelow(p0, p1);
  }

  @Test
  public void setAlignment_test_11948(MutableAttributeSet p0, int p1) {
    StyleConstants.setAlignment(p0, p1);
  }

  @Test
  public void getTabSet_test_11949(AttributeSet p0) {
    StyleConstants.getTabSet(p0);
  }

  @Test
  public void setTabSet_test_11950(MutableAttributeSet p0, TabSet p1) {
    StyleConstants.setTabSet(p0, p1);
  }

  @Test
  public void setSuperscript_test_11951(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setSuperscript(p0, p1);
  }

  @Test
  public void setUnderline_test_11952(MutableAttributeSet p0, boolean p1) {
    StyleConstants.setUnderline(p0, p1);
  }

  @Test
  public void getSpaceAbove_test_11953(AttributeSet p0) {
    StyleConstants.getSpaceAbove(p0);
  }

  @Test
  public void getLeftIndent_test_11954(AttributeSet p0) {
    StyleConstants.getLeftIndent(p0);
  }

  @Test
  public void getSpaceBelow_test_11955(AttributeSet p0) {
    StyleConstants.getSpaceBelow(p0);
  }

  @Test
  public void getRightIndent_test_11956(AttributeSet p0) {
    StyleConstants.getRightIndent(p0);
  }

  @Test
  public void getForeground_test_11957(AttributeSet p0) {
    StyleConstants.getForeground(p0);
  }

  @Test
  public void setForeground_test_11958(MutableAttributeSet p0, Color p1) {
    StyleConstants.setForeground(p0, p1);
  }

  @Test
  public void getBackground_test_11959(AttributeSet p0) {
    StyleConstants.getBackground(p0);
  }

  @Test
  public void setBackground_test_11960(MutableAttributeSet p0, Color p1) {
    StyleConstants.setBackground(p0, p1);
  }

  @Test
  public void setComponent_test_11961(MutableAttributeSet p0, Component p1) {
    StyleConstants.setComponent(p0, p1);
  }

  @Test
  public void getIcon_test_11962(AttributeSet p0) {
    StyleConstants.getIcon(p0);
  }

  @Test
  public void setIcon_test_11963(MutableAttributeSet p0, Icon p1) {
    StyleConstants.setIcon(p0, p1);
  }

  @Test
  public void getBidiLevel_test_11964(AttributeSet p0) {
    StyleConstants.getBidiLevel(p0);
  }

  @Test
  public void getAlignment_test_11965(AttributeSet p0) {
    StyleConstants.getAlignment(p0);
  }

  @Test
  public void getFontFamily_test_11966(AttributeSet p0) {
    StyleConstants.getFontFamily(p0);
  }

  @Test
  public void getFontSize_test_11967(AttributeSet p0) {
    StyleConstants.getFontSize(p0);
  }

  @Test
  public void isSuperscript_test_11968(AttributeSet p0) {
    StyleConstants.isSuperscript(p0);
  }

  @Test
  public void isSubscript_test_11969(AttributeSet p0) {
    StyleConstants.isSubscript(p0);
  }

  @Test
  public void getComponent_test_11970(AttributeSet p0) {
    StyleConstants.getComponent(p0);
  }
}
