package generated.test;

import java.lang.IO;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_IOAutoTest {
  @Test
  public void readln_test_5958() {
    IO.readln();
  }

  @Test
  public void readln_test_5959(String p0) {
    IO.readln(p0);
  }

  @Test
  public void println_test_5960(Object p0) {
    IO.println(p0);
  }

  @Test
  public void println_test_5961() {
    IO.println();
  }

  @Test
  public void print_test_5962(Object p0) {
    IO.print(p0);
  }
}
