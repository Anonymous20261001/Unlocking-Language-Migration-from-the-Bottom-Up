package generated.test;

import java.io.File;
import java.lang.Object;
import java.lang.String;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import org.junit.jupiter.api.Test;

public class javax_imageio_ImageIOAutoTest {
  @Test
  public void setUseCache_test_5658(boolean p0) {
    ImageIO.setUseCache(p0);
  }

  @Test
  public void getUseCache_test_5659() {
    ImageIO.getUseCache();
  }

  @Test
  public void setCacheDirectory_test_5660(File p0) {
    ImageIO.setCacheDirectory(p0);
  }

  @Test
  public void getCacheDirectory_test_5661() {
    ImageIO.getCacheDirectory();
  }

  @Test
  public void getImageReaders_test_5662(Object p0) {
    ImageIO.getImageReaders(p0);
  }

  @Test
  public void getImageWriters_test_5663(ImageTypeSpecifier p0, String p1) {
    ImageIO.getImageWriters(p0, p1);
  }

  @Test
  public void scanForPlugins_test_5664() {
    ImageIO.scanForPlugins();
  }

  @Test
  public void getReaderFormatNames_test_5665() {
    ImageIO.getReaderFormatNames();
  }

  @Test
  public void getReaderMIMETypes_test_5666() {
    ImageIO.getReaderMIMETypes();
  }

  @Test
  public void getReaderFileSuffixes_test_5667() {
    ImageIO.getReaderFileSuffixes();
  }

  @Test
  public void getImageReadersByFormatName_test_5668(String p0) {
    ImageIO.getImageReadersByFormatName(p0);
  }

  @Test
  public void getImageReadersBySuffix_test_5669(String p0) {
    ImageIO.getImageReadersBySuffix(p0);
  }

  @Test
  public void getImageReadersByMIMEType_test_5670(String p0) {
    ImageIO.getImageReadersByMIMEType(p0);
  }

  @Test
  public void getWriterFormatNames_test_5671() {
    ImageIO.getWriterFormatNames();
  }

  @Test
  public void getWriterMIMETypes_test_5672() {
    ImageIO.getWriterMIMETypes();
  }

  @Test
  public void getWriterFileSuffixes_test_5673() {
    ImageIO.getWriterFileSuffixes();
  }

  @Test
  public void getImageWritersByFormatName_test_5674(String p0) {
    ImageIO.getImageWritersByFormatName(p0);
  }

  @Test
  public void getImageWritersBySuffix_test_5675(String p0) {
    ImageIO.getImageWritersBySuffix(p0);
  }

  @Test
  public void getImageWritersByMIMEType_test_5676(String p0) {
    ImageIO.getImageWritersByMIMEType(p0);
  }

  @Test
  public void getImageWriter_test_5677(ImageReader p0) {
    ImageIO.getImageWriter(p0);
  }

  @Test
  public void getImageTranscoders_test_5678(ImageReader p0, ImageWriter p1) {
    ImageIO.getImageTranscoders(p0, p1);
  }

  @Test
  public void getImageReader_test_5679(ImageWriter p0) {
    ImageIO.getImageReader(p0);
  }
}
