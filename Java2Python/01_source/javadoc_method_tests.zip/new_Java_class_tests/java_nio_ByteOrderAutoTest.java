package generated.test;

import java.nio.ByteOrder;
import org.junit.jupiter.api.Test;

public class java_nio_ByteOrderAutoTest {
  @Test
  public void nativeOrder_test_2007() {
    ByteOrder.nativeOrder();
  }
}
