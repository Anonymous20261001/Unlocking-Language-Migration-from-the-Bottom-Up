package generated.test;

import java.lang.Class;
import jdk.jfr.EventType;
import org.junit.jupiter.api.Test;

public class jdk_jfr_EventTypeAutoTest {
  @Test
  public void getEventType_test_4604(Class p0) {
    EventType.getEventType(p0);
  }
}
