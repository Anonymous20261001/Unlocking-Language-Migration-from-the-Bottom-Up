package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Comparator;
import java.util.Objects;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;

public class java_util_ObjectsAutoTest {
  @Test
  public void checkIndex_test_9597(int p0, int p1) {
    Objects.checkIndex(p0, p1);
  }

  @Test
  public void checkIndex_test_9598(long p0, long p1) {
    Objects.checkIndex(p0, p1);
  }

  @Test
  public void compare_test_9599(Object p0, Object p1, Comparator p2) {
    Objects.compare(p0, p1, p2);
  }

  @Test
  public void hash_test_9600(Object[] p0) {
    Objects.hash(p0);
  }

  @Test
  public void requireNonNull_test_9601(Object p0, Supplier p1) {
    Objects.requireNonNull(p0, p1);
  }

  @Test
  public void requireNonNull_test_9602(Object p0, String p1) {
    Objects.requireNonNull(p0, p1);
  }

  @Test
  public void requireNonNull_test_9603(Object p0) {
    Objects.requireNonNull(p0);
  }

  @Test
  public void checkFromToIndex_test_9604(long p0, long p1, long p2) {
    Objects.checkFromToIndex(p0, p1, p2);
  }

  @Test
  public void checkFromToIndex_test_9605(int p0, int p1, int p2) {
    Objects.checkFromToIndex(p0, p1, p2);
  }

  @Test
  public void checkFromIndexSize_test_9606(int p0, int p1, int p2) {
    Objects.checkFromIndexSize(p0, p1, p2);
  }

  @Test
  public void checkFromIndexSize_test_9607(long p0, long p1, long p2) {
    Objects.checkFromIndexSize(p0, p1, p2);
  }

  @Test
  public void deepEquals_test_9608(Object p0, Object p1) {
    Objects.deepEquals(p0, p1);
  }

  @Test
  public void toIdentityString_test_9609(Object p0) {
    Objects.toIdentityString(p0);
  }

  @Test
  public void isNull_test_9610(Object p0) {
    Objects.isNull(p0);
  }

  @Test
  public void nonNull_test_9611(Object p0) {
    Objects.nonNull(p0);
  }

  @Test
  public void requireNonNullElse_test_9612(Object p0, Object p1) {
    Objects.requireNonNullElse(p0, p1);
  }

  @Test
  public void requireNonNullElseGet_test_9613(Object p0, Supplier p1) {
    Objects.requireNonNullElseGet(p0, p1);
  }
}
