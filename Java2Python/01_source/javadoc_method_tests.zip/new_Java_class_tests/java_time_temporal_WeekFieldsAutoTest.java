package generated.test;

import java.time.DayOfWeek;
import java.time.temporal.WeekFields;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_time_temporal_WeekFieldsAutoTest {
  @Test
  public void of_test_13452(Locale p0) {
    WeekFields.of(p0);
  }

  @Test
  public void of_test_13453(DayOfWeek p0, int p1) {
    WeekFields.of(p0, p1);
  }
}
