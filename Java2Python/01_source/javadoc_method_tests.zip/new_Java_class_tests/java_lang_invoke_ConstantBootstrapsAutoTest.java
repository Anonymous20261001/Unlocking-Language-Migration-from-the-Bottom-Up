package generated.test;

import java.lang.Class;
import java.lang.Object;
import java.lang.String;
import java.lang.invoke.ConstantBootstraps;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_ConstantBootstrapsAutoTest {
  @Test
  public void primitiveClass_test_2920(MethodHandles.Lookup p0, String p1, Class p2) {
    ConstantBootstraps.primitiveClass(p0, p1, p2);
  }

  @Test
  public void enumConstant_test_2921(MethodHandles.Lookup p0, String p1, Class p2) {
    ConstantBootstraps.enumConstant(p0, p1, p2);
  }

  @Test
  public void getStaticFinal_test_2922(MethodHandles.Lookup p0, String p1, Class p2) {
    ConstantBootstraps.getStaticFinal(p0, p1, p2);
  }

  @Test
  public void getStaticFinal_test_2923(MethodHandles.Lookup p0, String p1, Class p2, Class p3) {
    ConstantBootstraps.getStaticFinal(p0, p1, p2, p3);
  }

  @Test
  public void nullConstant_test_2924(MethodHandles.Lookup p0, String p1, Class p2) {
    ConstantBootstraps.nullConstant(p0, p1, p2);
  }

  @Test
  public void fieldVarHandle_test_2925(MethodHandles.Lookup p0, String p1, Class p2, Class p3,
      Class p4) {
    ConstantBootstraps.fieldVarHandle(p0, p1, p2, p3, p4);
  }

  @Test
  public void staticFieldVarHandle_test_2926(MethodHandles.Lookup p0, String p1, Class p2, Class p3,
      Class p4) {
    ConstantBootstraps.staticFieldVarHandle(p0, p1, p2, p3, p4);
  }

  @Test
  public void arrayVarHandle_test_2927(MethodHandles.Lookup p0, String p1, Class p2, Class p3) {
    ConstantBootstraps.arrayVarHandle(p0, p1, p2, p3);
  }

  @Test
  public void explicitCast_test_2928(MethodHandles.Lookup p0, String p1, Class p2, Object p3) {
    ConstantBootstraps.explicitCast(p0, p1, p2, p3);
  }
}
