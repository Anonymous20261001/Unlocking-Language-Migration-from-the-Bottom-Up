package generated.test;

import java.awt.geom.Arc2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Arc2D_FloatAutoTest {
  @Test
  public void getAngleStart_test_198() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getAngleStart();
  }

  @Test
  public void getAngleExtent_test_199() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getAngleExtent();
  }

  @Test
  public void setArc_test_200(double p0, double p1, double p2, double p3, double p4, double p5,
      int p6) {
    Arc2D.Float instance = new Arc2D.Float();
    instance.setArc(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void setAngleStart_test_201(double p0) {
    Arc2D.Float instance = new Arc2D.Float();
    instance.setAngleStart(p0);
  }

  @Test
  public void setAngleExtent_test_202(double p0) {
    Arc2D.Float instance = new Arc2D.Float();
    instance.setAngleExtent(p0);
  }

  @Test
  public void getWidth_test_203() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_204() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getHeight();
  }

  @Test
  public void getX_test_205() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getX();
  }

  @Test
  public void getY_test_206() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.getY();
  }

  @Test
  public void isEmpty_test_207() {
    Arc2D.Float instance = new Arc2D.Float();
    instance.isEmpty();
  }
}
