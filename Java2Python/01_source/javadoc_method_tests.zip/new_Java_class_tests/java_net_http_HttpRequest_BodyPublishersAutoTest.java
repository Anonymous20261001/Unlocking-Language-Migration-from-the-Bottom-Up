package generated.test;

import java.lang.Iterable;
import java.lang.String;
import java.net.http.HttpRequest;
import java.nio.charset.Charset;
import java.util.concurrent.Flow;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpRequest_BodyPublishersAutoTest {
  @Test
  public void concat_test_5441(HttpRequest.BodyPublisher[] p0) {
    HttpRequest.BodyPublishers.concat(p0);
  }

  @Test
  public void ofString_test_5442(String p0, Charset p1) {
    HttpRequest.BodyPublishers.ofString(p0, p1);
  }

  @Test
  public void ofString_test_5443(String p0) {
    HttpRequest.BodyPublishers.ofString(p0);
  }

  @Test
  public void noBody_test_5444() {
    HttpRequest.BodyPublishers.noBody();
  }

  @Test
  public void fromPublisher_test_5445(Flow.Publisher p0) {
    HttpRequest.BodyPublishers.fromPublisher(p0);
  }

  @Test
  public void fromPublisher_test_5446(Flow.Publisher p0, long p1) {
    HttpRequest.BodyPublishers.fromPublisher(p0, p1);
  }

  @Test
  public void ofInputStream_test_5447(Supplier p0) {
    HttpRequest.BodyPublishers.ofInputStream(p0);
  }

  @Test
  public void ofByteArray_test_5448(byte[] p0) {
    HttpRequest.BodyPublishers.ofByteArray(p0);
  }

  @Test
  public void ofByteArray_test_5449(byte[] p0, int p1, int p2) {
    HttpRequest.BodyPublishers.ofByteArray(p0, p1, p2);
  }

  @Test
  public void ofByteArrays_test_5450(Iterable p0) {
    HttpRequest.BodyPublishers.ofByteArrays(p0);
  }
}
