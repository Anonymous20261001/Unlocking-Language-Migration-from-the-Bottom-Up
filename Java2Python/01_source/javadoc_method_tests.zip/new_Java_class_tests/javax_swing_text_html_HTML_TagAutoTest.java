package generated.test;

import javax.swing.text.html.HTML;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_HTML_TagAutoTest {
  @Test
  public void isBlock_test_5361() {
    HTML.Tag instance = new HTML.Tag();
    instance.isBlock();
  }

  @Test
  public void breaksFlow_test_5362() {
    HTML.Tag instance = new HTML.Tag();
    instance.breaksFlow();
  }

  @Test
  public void isPreformatted_test_5363() {
    HTML.Tag instance = new HTML.Tag();
    instance.isPreformatted();
  }
}
