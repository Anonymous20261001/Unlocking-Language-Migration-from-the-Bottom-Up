package generated.test;

import java.lang.Class;
import java.lang.Comparable;
import java.lang.Object;
import java.util.Arrays;
import java.util.Comparator;
import java.util.function.BinaryOperator;
import java.util.function.DoubleBinaryOperator;
import java.util.function.IntBinaryOperator;
import java.util.function.IntFunction;
import java.util.function.IntToDoubleFunction;
import java.util.function.IntToLongFunction;
import java.util.function.IntUnaryOperator;
import java.util.function.LongBinaryOperator;
import org.junit.jupiter.api.Test;

public class java_util_ArraysAutoTest {
  @Test
  public void compareUnsigned_test_344(byte[] p0, byte[] p1) {
    Arrays.compareUnsigned(p0, p1);
  }

  @Test
  public void compareUnsigned_test_345(short[] p0, short[] p1) {
    Arrays.compareUnsigned(p0, p1);
  }

  @Test
  public void compareUnsigned_test_346(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5) {
    Arrays.compareUnsigned(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compareUnsigned_test_347(long[] p0, int p1, int p2, long[] p3, int p4, int p5) {
    Arrays.compareUnsigned(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compareUnsigned_test_348(short[] p0, int p1, int p2, short[] p3, int p4, int p5) {
    Arrays.compareUnsigned(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compareUnsigned_test_349(long[] p0, long[] p1) {
    Arrays.compareUnsigned(p0, p1);
  }

  @Test
  public void compareUnsigned_test_350(int[] p0, int p1, int p2, int[] p3, int p4, int p5) {
    Arrays.compareUnsigned(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compareUnsigned_test_351(int[] p0, int[] p1) {
    Arrays.compareUnsigned(p0, p1);
  }

  @Test
  public void copyOf_test_352(double[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_353(int[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_354(byte[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_355(Object[] p0, int p1, Class p2) {
    Arrays.copyOf(p0, p1, p2);
  }

  @Test
  public void copyOf_test_356(Object[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_357(boolean[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_358(float[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_359(char[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_360(long[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void copyOf_test_361(short[] p0, int p1) {
    Arrays.copyOf(p0, p1);
  }

  @Test
  public void sort_test_362(Object[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_363(long[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_364(long[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_365(short[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_366(Object[] p0, int p1, int p2, Comparator p3) {
    Arrays.sort(p0, p1, p2, p3);
  }

  @Test
  public void sort_test_367(Object[] p0, Comparator p1) {
    Arrays.sort(p0, p1);
  }

  @Test
  public void sort_test_368(Object[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_369(int[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_370(double[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_371(double[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_372(float[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_373(float[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_374(byte[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_375(short[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_376(char[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_377(char[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void sort_test_378(byte[] p0) {
    Arrays.sort(p0);
  }

  @Test
  public void sort_test_379(int[] p0, int p1, int p2) {
    Arrays.sort(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_380(boolean[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_381(char[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_382(long[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_383(float[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_384(double[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_385(Object[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_386(Object[] p0, int p1, int p2, Class p3) {
    Arrays.copyOfRange(p0, p1, p2, p3);
  }

  @Test
  public void copyOfRange_test_387(byte[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_388(short[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void copyOfRange_test_389(int[] p0, int p1, int p2) {
    Arrays.copyOfRange(p0, p1, p2);
  }

  @Test
  public void compare_test_390(char[] p0, int p1, int p2, char[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_391(int[] p0, int[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_392(char[] p0, char[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_393(int[] p0, int p1, int p2, int[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_394(long[] p0, long[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_395(long[] p0, int p1, int p2, long[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_396(double[] p0, double[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_397(float[] p0, int p1, int p2, float[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_398(short[] p0, short[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_399(short[] p0, int p1, int p2, short[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_400(boolean[] p0, boolean[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_401(boolean[] p0, int p1, int p2, boolean[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_402(byte[] p0, byte[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_403(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_404(Comparable[] p0, int p1, int p2, Comparable[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_405(Comparable[] p0, Comparable[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void compare_test_406(Object[] p0, Object[] p1, Comparator p2) {
    Arrays.compare(p0, p1, p2);
  }

  @Test
  public void compare_test_407(double[] p0, int p1, int p2, double[] p3, int p4, int p5) {
    Arrays.compare(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void compare_test_408(Object[] p0, int p1, int p2, Object[] p3, int p4, int p5,
      Comparator p6) {
    Arrays.compare(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void compare_test_409(float[] p0, float[] p1) {
    Arrays.compare(p0, p1);
  }

  @Test
  public void mismatch_test_410(long[] p0, long[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_411(float[] p0, float[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_412(long[] p0, int p1, int p2, long[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_413(Object[] p0, Object[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_414(Object[] p0, int p1, int p2, Object[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_415(Object[] p0, Object[] p1, Comparator p2) {
    Arrays.mismatch(p0, p1, p2);
  }

  @Test
  public void mismatch_test_416(Object[] p0, int p1, int p2, Object[] p3, int p4, int p5,
      Comparator p6) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void mismatch_test_417(double[] p0, int p1, int p2, double[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_418(double[] p0, double[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_419(float[] p0, int p1, int p2, float[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_420(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_421(char[] p0, char[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_422(char[] p0, int p1, int p2, char[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_423(int[] p0, int[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_424(short[] p0, int p1, int p2, short[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_425(short[] p0, short[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_426(int[] p0, int p1, int p2, int[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_427(boolean[] p0, boolean[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void mismatch_test_428(boolean[] p0, int p1, int p2, boolean[] p3, int p4, int p5) {
    Arrays.mismatch(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void mismatch_test_429(byte[] p0, byte[] p1) {
    Arrays.mismatch(p0, p1);
  }

  @Test
  public void stream_test_430(Object[] p0) {
    Arrays.stream(p0);
  }

  @Test
  public void stream_test_431(long[] p0) {
    Arrays.stream(p0);
  }

  @Test
  public void stream_test_432(int[] p0, int p1, int p2) {
    Arrays.stream(p0, p1, p2);
  }

  @Test
  public void stream_test_433(int[] p0) {
    Arrays.stream(p0);
  }

  @Test
  public void stream_test_434(Object[] p0, int p1, int p2) {
    Arrays.stream(p0, p1, p2);
  }

  @Test
  public void stream_test_435(double[] p0, int p1, int p2) {
    Arrays.stream(p0, p1, p2);
  }

  @Test
  public void stream_test_436(double[] p0) {
    Arrays.stream(p0);
  }

  @Test
  public void stream_test_437(long[] p0, int p1, int p2) {
    Arrays.stream(p0, p1, p2);
  }

  @Test
  public void fill_test_438(Object[] p0, int p1, int p2, Object p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_439(long[] p0, long p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_440(boolean[] p0, boolean p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_441(short[] p0, short p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_442(int[] p0, int p1, int p2, int p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_443(int[] p0, int p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_444(boolean[] p0, int p1, int p2, boolean p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_445(byte[] p0, byte p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_446(char[] p0, char p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_447(short[] p0, int p1, int p2, short p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_448(byte[] p0, int p1, int p2, byte p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_449(double[] p0, int p1, int p2, double p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_450(float[] p0, float p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_451(float[] p0, int p1, int p2, float p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_452(Object[] p0, Object p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void fill_test_453(char[] p0, int p1, int p2, char p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_454(long[] p0, int p1, int p2, long p3) {
    Arrays.fill(p0, p1, p2, p3);
  }

  @Test
  public void fill_test_455(double[] p0, double p1) {
    Arrays.fill(p0, p1);
  }

  @Test
  public void spliterator_test_456(int[] p0) {
    Arrays.spliterator(p0);
  }

  @Test
  public void spliterator_test_457(long[] p0) {
    Arrays.spliterator(p0);
  }

  @Test
  public void spliterator_test_458(int[] p0, int p1, int p2) {
    Arrays.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_459(Object[] p0, int p1, int p2) {
    Arrays.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_460(double[] p0, int p1, int p2) {
    Arrays.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_461(Object[] p0) {
    Arrays.spliterator(p0);
  }

  @Test
  public void spliterator_test_462(long[] p0, int p1, int p2) {
    Arrays.spliterator(p0, p1, p2);
  }

  @Test
  public void spliterator_test_463(double[] p0) {
    Arrays.spliterator(p0);
  }

  @Test
  public void asList_test_464(Object[] p0) {
    Arrays.asList(p0);
  }

  @Test
  public void deepEquals_test_465(Object[] p0, Object[] p1) {
    Arrays.deepEquals(p0, p1);
  }

  @Test
  public void deepHashCode_test_466(Object[] p0) {
    Arrays.deepHashCode(p0);
  }

  @Test
  public void deepToString_test_467(Object[] p0) {
    Arrays.deepToString(p0);
  }

  @Test
  public void parallelSort_test_468(int[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_469(int[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_470(long[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_471(Object[] p0, int p1, int p2, Comparator p3) {
    Arrays.parallelSort(p0, p1, p2, p3);
  }

  @Test
  public void parallelSort_test_472(short[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_473(Object[] p0, Comparator p1) {
    Arrays.parallelSort(p0, p1);
  }

  @Test
  public void parallelSort_test_474(short[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_475(double[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_476(double[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_477(float[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_478(float[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_479(Comparable[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_480(Comparable[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_481(byte[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_482(byte[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_483(char[] p0) {
    Arrays.parallelSort(p0);
  }

  @Test
  public void parallelSort_test_484(char[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelSort_test_485(long[] p0, int p1, int p2) {
    Arrays.parallelSort(p0, p1, p2);
  }

  @Test
  public void parallelPrefix_test_486(double[] p0, int p1, int p2, DoubleBinaryOperator p3) {
    Arrays.parallelPrefix(p0, p1, p2, p3);
  }

  @Test
  public void parallelPrefix_test_487(double[] p0, DoubleBinaryOperator p1) {
    Arrays.parallelPrefix(p0, p1);
  }

  @Test
  public void parallelPrefix_test_488(int[] p0, IntBinaryOperator p1) {
    Arrays.parallelPrefix(p0, p1);
  }

  @Test
  public void parallelPrefix_test_489(int[] p0, int p1, int p2, IntBinaryOperator p3) {
    Arrays.parallelPrefix(p0, p1, p2, p3);
  }

  @Test
  public void parallelPrefix_test_490(long[] p0, int p1, int p2, LongBinaryOperator p3) {
    Arrays.parallelPrefix(p0, p1, p2, p3);
  }

  @Test
  public void parallelPrefix_test_491(long[] p0, LongBinaryOperator p1) {
    Arrays.parallelPrefix(p0, p1);
  }

  @Test
  public void parallelPrefix_test_492(Object[] p0, int p1, int p2, BinaryOperator p3) {
    Arrays.parallelPrefix(p0, p1, p2, p3);
  }

  @Test
  public void parallelPrefix_test_493(Object[] p0, BinaryOperator p1) {
    Arrays.parallelPrefix(p0, p1);
  }

  @Test
  public void binarySearch_test_494(float[] p0, int p1, int p2, float p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_495(float[] p0, float p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_496(short[] p0, short p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_497(short[] p0, int p1, int p2, short p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_498(Object[] p0, Object p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_499(Object[] p0, int p1, int p2, Object p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_500(Object[] p0, Object p1, Comparator p2) {
    Arrays.binarySearch(p0, p1, p2);
  }

  @Test
  public void binarySearch_test_501(double[] p0, int p1, int p2, double p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_502(double[] p0, double p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_503(byte[] p0, int p1, int p2, byte p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_504(byte[] p0, byte p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_505(char[] p0, int p1, int p2, char p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_506(char[] p0, char p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_507(int[] p0, int p1, int p2, int p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_508(long[] p0, long p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_509(long[] p0, int p1, int p2, long p3) {
    Arrays.binarySearch(p0, p1, p2, p3);
  }

  @Test
  public void binarySearch_test_510(int[] p0, int p1) {
    Arrays.binarySearch(p0, p1);
  }

  @Test
  public void binarySearch_test_511(Object[] p0, int p1, int p2, Object p3, Comparator p4) {
    Arrays.binarySearch(p0, p1, p2, p3, p4);
  }

  @Test
  public void setAll_test_512(double[] p0, IntToDoubleFunction p1) {
    Arrays.setAll(p0, p1);
  }

  @Test
  public void setAll_test_513(int[] p0, IntUnaryOperator p1) {
    Arrays.setAll(p0, p1);
  }

  @Test
  public void setAll_test_514(long[] p0, IntToLongFunction p1) {
    Arrays.setAll(p0, p1);
  }

  @Test
  public void setAll_test_515(Object[] p0, IntFunction p1) {
    Arrays.setAll(p0, p1);
  }

  @Test
  public void parallelSetAll_test_516(double[] p0, IntToDoubleFunction p1) {
    Arrays.parallelSetAll(p0, p1);
  }

  @Test
  public void parallelSetAll_test_517(long[] p0, IntToLongFunction p1) {
    Arrays.parallelSetAll(p0, p1);
  }

  @Test
  public void parallelSetAll_test_518(Object[] p0, IntFunction p1) {
    Arrays.parallelSetAll(p0, p1);
  }

  @Test
  public void parallelSetAll_test_519(int[] p0, IntUnaryOperator p1) {
    Arrays.parallelSetAll(p0, p1);
  }
}
