package generated.test;

import java.lang.management.ThreadInfo;
import javax.management.openmbean.CompositeData;
import org.junit.jupiter.api.Test;

public class java_lang_management_ThreadInfoAutoTest {
  @Test
  public void from_test_12708(CompositeData p0) {
    ThreadInfo.from(p0);
  }
}
