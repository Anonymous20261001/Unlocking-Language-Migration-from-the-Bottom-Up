package generated.test;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.rowset.spi.SyncFactory;
import org.junit.jupiter.api.Test;

public class javax_sql_rowset_spi_SyncFactoryAutoTest {
  @Test
  public void getSyncFactory_test_12123() {
    SyncFactory.getSyncFactory();
  }

  @Test
  public void setLogger_test_12124(Logger p0) {
    SyncFactory.setLogger(p0);
  }

  @Test
  public void setLogger_test_12125(Logger p0, Level p1) {
    SyncFactory.setLogger(p0, p1);
  }
}
