package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthSliderUI;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_synth_SynthSliderUIAutoTest {
  @Test
  public void createUI_test_12334(JComponent p0) {
    SynthSliderUI.createUI(p0);
  }
}
