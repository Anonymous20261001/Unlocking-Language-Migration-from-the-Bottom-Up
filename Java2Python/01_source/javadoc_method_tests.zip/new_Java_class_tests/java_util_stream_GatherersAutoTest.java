package generated.test;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Gatherers;
import org.junit.jupiter.api.Test;

public class java_util_stream_GatherersAutoTest {
  @Test
  public void windowFixed_test_5079(int p0) {
    Gatherers.windowFixed(p0);
  }

  @Test
  public void windowSliding_test_5080(int p0) {
    Gatherers.windowSliding(p0);
  }

  @Test
  public void fold_test_5081(Supplier p0, BiFunction p1) {
    Gatherers.fold(p0, p1);
  }

  @Test
  public void mapConcurrent_test_5082(int p0, Function p1) {
    Gatherers.mapConcurrent(p0, p1);
  }

  @Test
  public void scan_test_5083(Supplier p0, BiFunction p1) {
    Gatherers.scan(p0, p1);
  }
}
