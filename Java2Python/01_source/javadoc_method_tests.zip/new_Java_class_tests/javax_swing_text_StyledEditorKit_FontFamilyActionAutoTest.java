package generated.test;

import java.awt.event.ActionEvent;
import java.lang.String;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_FontFamilyActionAutoTest {
  @Test
  public void actionPerformed_test_12003(ActionEvent p0, String c0, String c1) {
    StyledEditorKit.FontFamilyAction instance = new StyledEditorKit.FontFamilyAction(c0, c1);
    instance.actionPerformed(p0);
  }
}
