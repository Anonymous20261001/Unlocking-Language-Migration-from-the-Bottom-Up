package generated.test;

import javax.crypto.KEM;
import javax.crypto.SecretKey;
import org.junit.jupiter.api.Test;

public class javax_crypto_KEM_EncapsulatedAutoTest {
  @Test
  public void encapsulation_test_7568(SecretKey c0, byte[] c1, byte[] c2) {
    KEM.Encapsulated instance = new KEM.Encapsulated(c0, c1, c2);
    instance.encapsulation();
  }

  @Test
  public void key_test_7569(SecretKey c0, byte[] c1, byte[] c2) {
    KEM.Encapsulated instance = new KEM.Encapsulated(c0, c1, c2);
    instance.key();
  }

  @Test
  public void params_test_7570(SecretKey c0, byte[] c1, byte[] c2) {
    KEM.Encapsulated instance = new KEM.Encapsulated(c0, c1, c2);
    instance.params();
  }
}
