package generated.test;

import java.nio.ByteBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_ByteBufferAutoTest {
  @Test
  public void wrap_test_2000(byte[] p0, int p1, int p2) {
    ByteBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void wrap_test_2001(byte[] p0) {
    ByteBuffer.wrap(p0);
  }

  @Test
  public void allocate_test_2002(int p0) {
    ByteBuffer.allocate(p0);
  }

  @Test
  public void allocateDirect_test_2003(int p0) {
    ByteBuffer.allocateDirect(p0);
  }
}
