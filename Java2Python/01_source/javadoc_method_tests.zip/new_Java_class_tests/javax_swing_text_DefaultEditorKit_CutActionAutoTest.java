package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_CutActionAutoTest {
  @Test
  public void actionPerformed_test_3671(ActionEvent p0) {
    DefaultEditorKit.CutAction instance = new DefaultEditorKit.CutAction();
    instance.actionPerformed(p0);
  }
}
