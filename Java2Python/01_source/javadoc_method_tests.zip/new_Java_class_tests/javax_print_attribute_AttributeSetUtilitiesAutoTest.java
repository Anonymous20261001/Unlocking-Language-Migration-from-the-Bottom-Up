package generated.test;

import java.lang.Class;
import java.lang.Object;
import javax.print.attribute.Attribute;
import javax.print.attribute.AttributeSet;
import javax.print.attribute.AttributeSetUtilities;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.PrintJobAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import org.junit.jupiter.api.Test;

public class javax_print_attribute_AttributeSetUtilitiesAutoTest {
  @Test
  public void unmodifiableView_test_845(PrintServiceAttributeSet p0) {
    AttributeSetUtilities.unmodifiableView(p0);
  }

  @Test
  public void unmodifiableView_test_846(PrintRequestAttributeSet p0) {
    AttributeSetUtilities.unmodifiableView(p0);
  }

  @Test
  public void unmodifiableView_test_847(DocAttributeSet p0) {
    AttributeSetUtilities.unmodifiableView(p0);
  }

  @Test
  public void unmodifiableView_test_848(PrintJobAttributeSet p0) {
    AttributeSetUtilities.unmodifiableView(p0);
  }

  @Test
  public void unmodifiableView_test_849(AttributeSet p0) {
    AttributeSetUtilities.unmodifiableView(p0);
  }

  @Test
  public void synchronizedView_test_850(PrintRequestAttributeSet p0) {
    AttributeSetUtilities.synchronizedView(p0);
  }

  @Test
  public void synchronizedView_test_851(PrintJobAttributeSet p0) {
    AttributeSetUtilities.synchronizedView(p0);
  }

  @Test
  public void synchronizedView_test_852(PrintServiceAttributeSet p0) {
    AttributeSetUtilities.synchronizedView(p0);
  }

  @Test
  public void synchronizedView_test_853(DocAttributeSet p0) {
    AttributeSetUtilities.synchronizedView(p0);
  }

  @Test
  public void synchronizedView_test_854(AttributeSet p0) {
    AttributeSetUtilities.synchronizedView(p0);
  }

  @Test
  public void verifyAttributeCategory_test_855(Object p0, Class p1) {
    AttributeSetUtilities.verifyAttributeCategory(p0, p1);
  }

  @Test
  public void verifyAttributeValue_test_856(Object p0, Class p1) {
    AttributeSetUtilities.verifyAttributeValue(p0, p1);
  }

  @Test
  public void verifyCategoryForValue_test_857(Class p0, Attribute p1) {
    AttributeSetUtilities.verifyCategoryForValue(p0, p1);
  }
}
