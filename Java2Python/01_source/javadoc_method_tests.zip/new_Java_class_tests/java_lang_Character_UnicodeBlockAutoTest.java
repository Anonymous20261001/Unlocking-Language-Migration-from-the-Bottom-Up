package generated.test;

import java.lang.Character;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_Character_UnicodeBlockAutoTest {
  @Test
  public void forName_test_2214(String p0) {
    Character.UnicodeBlock.forName(p0);
  }

  @Test
  public void of_test_2215(int p0) {
    Character.UnicodeBlock.of(p0);
  }

  @Test
  public void of_test_2216(char p0) {
    Character.UnicodeBlock.of(p0);
  }
}
