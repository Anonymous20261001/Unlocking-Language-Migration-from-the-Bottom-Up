package generated.test;

import java.lang.Runnable;
import java.util.concurrent.ThreadPoolExecutor;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ThreadPoolExecutor_DiscardPolicyAutoTest {
  @Test
  public void rejectedExecution_test_12745(Runnable p0, ThreadPoolExecutor p1) {
    ThreadPoolExecutor.DiscardPolicy instance = new ThreadPoolExecutor.DiscardPolicy();
    instance.rejectedExecution(p0, p1);
  }
}
