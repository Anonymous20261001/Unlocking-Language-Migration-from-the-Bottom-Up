package generated.test;

import java.lang.String;
import java.time.ZoneId;
import java.util.TimeZone;
import org.junit.jupiter.api.Test;

public class java_util_TimeZoneAutoTest {
  @Test
  public void getDefault_test_12901() {
    TimeZone.getDefault();
  }

  @Test
  public void getTimeZone_test_12902(String p0) {
    TimeZone.getTimeZone(p0);
  }

  @Test
  public void getTimeZone_test_12903(ZoneId p0) {
    TimeZone.getTimeZone(p0);
  }

  @Test
  public void setDefault_test_12904(TimeZone p0) {
    TimeZone.setDefault(p0);
  }

  @Test
  public void getAvailableIDs_test_12905() {
    TimeZone.getAvailableIDs();
  }

  @Test
  public void getAvailableIDs_test_12906(int p0) {
    TimeZone.getAvailableIDs(p0);
  }

  @Test
  public void availableIDs_test_12907(int p0) {
    TimeZone.availableIDs(p0);
  }

  @Test
  public void availableIDs_test_12908() {
    TimeZone.availableIDs();
  }
}
