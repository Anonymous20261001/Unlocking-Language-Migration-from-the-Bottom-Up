package generated.test;

import java.util.concurrent.ThreadLocalRandom;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ThreadLocalRandomAutoTest {
  @Test
  public void current_test_12713() {
    ThreadLocalRandom.current();
  }
}
