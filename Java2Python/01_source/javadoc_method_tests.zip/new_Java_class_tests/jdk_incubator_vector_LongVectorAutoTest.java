package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.LongVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_LongVectorAutoTest {
  @Test
  public void fromMemorySegment_test_8218(VectorSpecies p0, MemorySegment p1, long p2, ByteOrder p3,
      VectorMask p4) {
    LongVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromMemorySegment_test_8219(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    LongVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_8220(VectorSpecies p0, long[] p1, int p2, int[] p3, int p4) {
    LongVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_8221(VectorSpecies p0, long[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    LongVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromArray_test_8222(VectorSpecies p0, long[] p1, int p2, VectorMask p3) {
    LongVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_8223(VectorSpecies p0, long[] p1, int p2) {
    LongVector.fromArray(p0, p1, p2);
  }

  @Test
  public void zero_test_8224(VectorSpecies p0) {
    LongVector.zero(p0);
  }

  @Test
  public void broadcast_test_8225(VectorSpecies p0, long p1) {
    LongVector.broadcast(p0, p1);
  }
}
