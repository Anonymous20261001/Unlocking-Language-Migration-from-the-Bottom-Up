package generated.test;

import java.lang.String;
import javax.management.AttributeChangeNotificationFilter;
import javax.management.Notification;
import org.junit.jupiter.api.Test;

public class javax_management_AttributeChangeNotificationFilterAutoTest {
  @Test
  public void isNotificationEnabled_test_762(Notification p0) {
    AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
    instance.isNotificationEnabled(p0);
  }

  @Test
  public void enableAttribute_test_763(String p0) {
    AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
    instance.enableAttribute(p0);
  }

  @Test
  public void disableAttribute_test_764(String p0) {
    AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
    instance.disableAttribute(p0);
  }

  @Test
  public void disableAllAttributes_test_765() {
    AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
    instance.disableAllAttributes();
  }

  @Test
  public void getEnabledAttributes_test_766() {
    AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
    instance.getEnabledAttributes();
  }
}
