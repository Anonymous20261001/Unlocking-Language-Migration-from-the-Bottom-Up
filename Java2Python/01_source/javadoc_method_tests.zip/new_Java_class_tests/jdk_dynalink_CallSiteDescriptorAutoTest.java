package generated.test;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import jdk.dynalink.CallSiteDescriptor;
import jdk.dynalink.Operation;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_CallSiteDescriptorAutoTest {
  @Test
  public void getMethodType_test_2041(MethodHandles.Lookup c0, Operation c1, MethodType c2) {
    CallSiteDescriptor instance = new CallSiteDescriptor(c0, c1, c2);
    instance.getMethodType();
  }

  @Test
  public void getOperation_test_2042(MethodHandles.Lookup c0, Operation c1, MethodType c2) {
    CallSiteDescriptor instance = new CallSiteDescriptor(c0, c1, c2);
    instance.getOperation();
  }

  @Test
  public void changeMethodType_test_2043(MethodType p0, MethodHandles.Lookup c0, Operation c1,
      MethodType c2) {
    CallSiteDescriptor instance = new CallSiteDescriptor(c0, c1, c2);
    instance.changeMethodType(p0);
  }

  @Test
  public void changeOperation_test_2044(Operation p0, MethodHandles.Lookup c0, Operation c1,
      MethodType c2) {
    CallSiteDescriptor instance = new CallSiteDescriptor(c0, c1, c2);
    instance.changeOperation(p0);
  }
}
