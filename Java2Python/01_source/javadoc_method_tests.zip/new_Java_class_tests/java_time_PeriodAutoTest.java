package generated.test;

import java.lang.CharSequence;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.TemporalAmount;
import org.junit.jupiter.api.Test;

public class java_time_PeriodAutoTest {
  @Test
  public void of_test_9886(int p0, int p1, int p2) {
    Period.of(p0, p1, p2);
  }

  @Test
  public void from_test_9887(TemporalAmount p0) {
    Period.from(p0);
  }

  @Test
  public void parse_test_9888(CharSequence p0) {
    Period.parse(p0);
  }

  @Test
  public void between_test_9889(LocalDate p0, LocalDate p1) {
    Period.between(p0, p1);
  }

  @Test
  public void ofDays_test_9890(int p0) {
    Period.ofDays(p0);
  }

  @Test
  public void ofYears_test_9891(int p0) {
    Period.ofYears(p0);
  }

  @Test
  public void ofMonths_test_9892(int p0) {
    Period.ofMonths(p0);
  }

  @Test
  public void ofWeeks_test_9893(int p0) {
    Period.ofWeeks(p0);
  }
}
