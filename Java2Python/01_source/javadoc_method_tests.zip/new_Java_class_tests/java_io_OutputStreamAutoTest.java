package generated.test;

import java.io.OutputStream;
import org.junit.jupiter.api.Test;

public class java_io_OutputStreamAutoTest {
  @Test
  public void nullOutputStream_test_9700() {
    OutputStream.nullOutputStream();
  }
}
