package generated.test;

import javax.tools.ToolProvider;
import org.junit.jupiter.api.Test;

public class javax_tools_ToolProviderAutoTest {
  @Test
  public void getSystemJavaCompiler_test_12929() {
    ToolProvider.getSystemJavaCompiler();
  }

  @Test
  public void getSystemDocumentationTool_test_12930() {
    ToolProvider.getSystemDocumentationTool();
  }

  @Test
  public void getSystemToolClassLoader_test_12931() {
    ToolProvider.getSystemToolClassLoader();
  }
}
