package generated.test;

import java.util.OptionalLong;
import org.junit.jupiter.api.Test;

public class java_util_OptionalLongAutoTest {
  @Test
  public void of_test_9696(long p0) {
    OptionalLong.of(p0);
  }

  @Test
  public void empty_test_9697() {
    OptionalLong.empty();
  }
}
