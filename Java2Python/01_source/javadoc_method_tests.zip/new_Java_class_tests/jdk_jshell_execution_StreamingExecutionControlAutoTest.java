package generated.test;

import java.io.ObjectInput;
import java.io.ObjectOutput;
import jdk.jshell.execution.StreamingExecutionControl;
import org.junit.jupiter.api.Test;

public class jdk_jshell_execution_StreamingExecutionControlAutoTest {
  @Test
  public void close_test_11512(ObjectOutput c0, ObjectInput c1) {
    StreamingExecutionControl instance = new StreamingExecutionControl(c0, c1);
    instance.close();
  }
}
