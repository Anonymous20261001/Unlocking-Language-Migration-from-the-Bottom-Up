package generated.test;

import javax.management.openmbean.CompositeData;
import jdk.management.jfr.ConfigurationInfo;
import org.junit.jupiter.api.Test;

public class jdk_management_jfr_ConfigurationInfoAutoTest {
  @Test
  public void from_test_2909(CompositeData p0) {
    ConfigurationInfo.from(p0);
  }
}
