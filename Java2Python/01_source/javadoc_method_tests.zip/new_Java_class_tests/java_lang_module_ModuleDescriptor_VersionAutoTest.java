package generated.test;

import java.lang.String;
import java.lang.module.ModuleDescriptor;
import org.junit.jupiter.api.Test;

public class java_lang_module_ModuleDescriptor_VersionAutoTest {
  @Test
  public void parse_test_8995(String p0) {
    ModuleDescriptor.Version.parse(p0);
  }
}
