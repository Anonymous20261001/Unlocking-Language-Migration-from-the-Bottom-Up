package generated.test;

import javax.swing.JToggleButton;
import org.junit.jupiter.api.Test;

public class javax_swing_JToggleButton_ToggleButtonModelAutoTest {
  @Test
  public void isSelected_test_7359() {
    JToggleButton.ToggleButtonModel instance = new JToggleButton.ToggleButtonModel();
    instance.isSelected();
  }

  @Test
  public void setSelected_test_7360(boolean p0) {
    JToggleButton.ToggleButtonModel instance = new JToggleButton.ToggleButtonModel();
    instance.setSelected(p0);
  }

  @Test
  public void setPressed_test_7361(boolean p0) {
    JToggleButton.ToggleButtonModel instance = new JToggleButton.ToggleButtonModel();
    instance.setPressed(p0);
  }
}
