package generated.test;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.lang.String;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_ForegroundActionAutoTest {
  @Test
  public void actionPerformed_test_12005(ActionEvent p0, String c0, Color c1) {
    StyledEditorKit.ForegroundAction instance = new StyledEditorKit.ForegroundAction(c0, c1);
    instance.actionPerformed(p0);
  }
}
