package generated.test;

import java.lang.String;
import java.security.Key;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.EncryptedPrivateKeyInfo;
import org.junit.jupiter.api.Test;

public class javax_crypto_EncryptedPrivateKeyInfoAutoTest {
  @Test
  public void encryptKey_test_4518(PrivateKey p0, char[] p1, String p2, AlgorithmParameterSpec p3,
      Provider p4) {
    EncryptedPrivateKeyInfo.encryptKey(p0, p1, p2, p3, p4);
  }

  @Test
  public void encryptKey_test_4519(PrivateKey p0, char[] p1) {
    EncryptedPrivateKeyInfo.encryptKey(p0, p1);
  }

  @Test
  public void encryptKey_test_4520(PrivateKey p0, Key p1, String p2, AlgorithmParameterSpec p3,
      Provider p4, SecureRandom p5) {
    EncryptedPrivateKeyInfo.encryptKey(p0, p1, p2, p3, p4, p5);
  }
}
