package generated.test;

import javax.swing.filechooser.FileSystemView;
import org.junit.jupiter.api.Test;

public class javax_swing_filechooser_FileSystemViewAutoTest {
  @Test
  public void getFileSystemView_test_4781() {
    FileSystemView.getFileSystemView();
  }
}
