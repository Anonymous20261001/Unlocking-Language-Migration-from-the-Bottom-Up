package generated.test;

import java.lang.Class;
import java.lang.management.ManagementFactory;
import org.junit.jupiter.api.Test;

public class java_lang_management_ManagementFactoryAutoTest {
  @Test
  public void getPlatformMXBean_test_8262(Class p0) {
    ManagementFactory.getPlatformMXBean(p0);
  }

  @Test
  public void getPlatformMXBeans_test_8263(Class p0) {
    ManagementFactory.getPlatformMXBeans(p0);
  }

  @Test
  public void getClassLoadingMXBean_test_8264() {
    ManagementFactory.getClassLoadingMXBean();
  }

  @Test
  public void getMemoryMXBean_test_8265() {
    ManagementFactory.getMemoryMXBean();
  }

  @Test
  public void getThreadMXBean_test_8266() {
    ManagementFactory.getThreadMXBean();
  }

  @Test
  public void getRuntimeMXBean_test_8267() {
    ManagementFactory.getRuntimeMXBean();
  }

  @Test
  public void getCompilationMXBean_test_8268() {
    ManagementFactory.getCompilationMXBean();
  }

  @Test
  public void getOperatingSystemMXBean_test_8269() {
    ManagementFactory.getOperatingSystemMXBean();
  }

  @Test
  public void getMemoryPoolMXBeans_test_8270() {
    ManagementFactory.getMemoryPoolMXBeans();
  }

  @Test
  public void getMemoryManagerMXBeans_test_8271() {
    ManagementFactory.getMemoryManagerMXBeans();
  }

  @Test
  public void getGarbageCollectorMXBeans_test_8272() {
    ManagementFactory.getGarbageCollectorMXBeans();
  }

  @Test
  public void getPlatformMBeanServer_test_8273() {
    ManagementFactory.getPlatformMBeanServer();
  }

  @Test
  public void getPlatformManagementInterfaces_test_8274() {
    ManagementFactory.getPlatformManagementInterfaces();
  }
}
