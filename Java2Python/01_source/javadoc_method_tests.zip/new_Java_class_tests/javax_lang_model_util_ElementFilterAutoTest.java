package generated.test;

import java.lang.Iterable;
import java.util.Set;
import javax.lang.model.util.ElementFilter;
import org.junit.jupiter.api.Test;

public class javax_lang_model_util_ElementFilterAutoTest {
  @Test
  public void typesIn_test_4463(Set p0) {
    ElementFilter.typesIn(p0);
  }

  @Test
  public void typesIn_test_4464(Iterable p0) {
    ElementFilter.typesIn(p0);
  }

  @Test
  public void fieldsIn_test_4465(Iterable p0) {
    ElementFilter.fieldsIn(p0);
  }

  @Test
  public void fieldsIn_test_4466(Set p0) {
    ElementFilter.fieldsIn(p0);
  }

  @Test
  public void recordComponentsIn_test_4467(Iterable p0) {
    ElementFilter.recordComponentsIn(p0);
  }

  @Test
  public void recordComponentsIn_test_4468(Set p0) {
    ElementFilter.recordComponentsIn(p0);
  }

  @Test
  public void constructorsIn_test_4469(Iterable p0) {
    ElementFilter.constructorsIn(p0);
  }

  @Test
  public void constructorsIn_test_4470(Set p0) {
    ElementFilter.constructorsIn(p0);
  }

  @Test
  public void methodsIn_test_4471(Set p0) {
    ElementFilter.methodsIn(p0);
  }

  @Test
  public void methodsIn_test_4472(Iterable p0) {
    ElementFilter.methodsIn(p0);
  }

  @Test
  public void packagesIn_test_4473(Iterable p0) {
    ElementFilter.packagesIn(p0);
  }

  @Test
  public void packagesIn_test_4474(Set p0) {
    ElementFilter.packagesIn(p0);
  }

  @Test
  public void modulesIn_test_4475(Iterable p0) {
    ElementFilter.modulesIn(p0);
  }

  @Test
  public void modulesIn_test_4476(Set p0) {
    ElementFilter.modulesIn(p0);
  }

  @Test
  public void exportsIn_test_4477(Iterable p0) {
    ElementFilter.exportsIn(p0);
  }

  @Test
  public void opensIn_test_4478(Iterable p0) {
    ElementFilter.opensIn(p0);
  }

  @Test
  public void providesIn_test_4479(Iterable p0) {
    ElementFilter.providesIn(p0);
  }

  @Test
  public void requiresIn_test_4480(Iterable p0) {
    ElementFilter.requiresIn(p0);
  }

  @Test
  public void usesIn_test_4481(Iterable p0) {
    ElementFilter.usesIn(p0);
  }
}
