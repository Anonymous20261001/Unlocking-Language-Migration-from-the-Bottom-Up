package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.LayoutManager;
import javax.swing.JApplet;
import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.TransferHandler;
import org.junit.jupiter.api.Test;

public class javax_swing_JAppletAutoTest {
  @Test
  public void getContentPane_test_5977() {
    JApplet instance = new JApplet();
    instance.getContentPane();
  }

  @Test
  public void getJMenuBar_test_5978() {
    JApplet instance = new JApplet();
    instance.getJMenuBar();
  }

  @Test
  public void setJMenuBar_test_5979(JMenuBar p0) {
    JApplet instance = new JApplet();
    instance.setJMenuBar(p0);
  }

  @Test
  public void setContentPane_test_5980(Container p0) {
    JApplet instance = new JApplet();
    instance.setContentPane(p0);
  }

  @Test
  public void getLayeredPane_test_5981() {
    JApplet instance = new JApplet();
    instance.getLayeredPane();
  }

  @Test
  public void setLayeredPane_test_5982(JLayeredPane p0) {
    JApplet instance = new JApplet();
    instance.setLayeredPane(p0);
  }

  @Test
  public void getGlassPane_test_5983() {
    JApplet instance = new JApplet();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_5984(Component p0) {
    JApplet instance = new JApplet();
    instance.setGlassPane(p0);
  }

  @Test
  public void getGraphics_test_5985() {
    JApplet instance = new JApplet();
    instance.getGraphics();
  }

  @Test
  public void getRootPane_test_5986() {
    JApplet instance = new JApplet();
    instance.getRootPane();
  }

  @Test
  public void repaint_test_5987(long p0, int p1, int p2, int p3, int p4) {
    JApplet instance = new JApplet();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void setTransferHandler_test_5988(TransferHandler p0) {
    JApplet instance = new JApplet();
    instance.setTransferHandler(p0);
  }

  @Test
  public void getTransferHandler_test_5989() {
    JApplet instance = new JApplet();
    instance.getTransferHandler();
  }

  @Test
  public void getAccessibleContext_test_5990() {
    JApplet instance = new JApplet();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_5991(LayoutManager p0) {
    JApplet instance = new JApplet();
    instance.setLayout(p0);
  }

  @Test
  public void remove_test_5992(Component p0) {
    JApplet instance = new JApplet();
    instance.remove(p0);
  }

  @Test
  public void update_test_5993(Graphics p0) {
    JApplet instance = new JApplet();
    instance.update(p0);
  }
}
