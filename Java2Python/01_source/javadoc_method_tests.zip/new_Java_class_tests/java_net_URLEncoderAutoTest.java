package generated.test;

import java.lang.String;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import org.junit.jupiter.api.Test;

public class java_net_URLEncoderAutoTest {
  @Test
  public void encode_test_13267(String p0) {
    URLEncoder.encode(p0);
  }

  @Test
  public void encode_test_13268(String p0, Charset p1) {
    URLEncoder.encode(p0, p1);
  }
}
