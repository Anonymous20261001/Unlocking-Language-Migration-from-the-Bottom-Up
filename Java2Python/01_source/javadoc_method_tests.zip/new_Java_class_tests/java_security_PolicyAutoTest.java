package generated.test;

import java.security.Policy;
import org.junit.jupiter.api.Test;

public class java_security_PolicyAutoTest {
  @Test
  public void setPolicy_test_9965(Policy p0) {
    Policy.setPolicy(p0);
  }

  @Test
  public void getPolicy_test_9966() {
    Policy.getPolicy();
  }
}
