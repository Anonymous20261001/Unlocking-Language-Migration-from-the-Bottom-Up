package generated.test;

import java.nio.channels.spi.SelectorProvider;
import org.junit.jupiter.api.Test;

public class java_nio_channels_spi_SelectorProviderAutoTest {
  @Test
  public void provider_test_11022() {
    SelectorProvider.provider();
  }
}
