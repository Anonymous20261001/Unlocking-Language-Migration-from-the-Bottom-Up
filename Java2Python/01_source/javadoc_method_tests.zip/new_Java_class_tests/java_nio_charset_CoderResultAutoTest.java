package generated.test;

import java.nio.charset.CoderResult;
import org.junit.jupiter.api.Test;

public class java_nio_charset_CoderResultAutoTest {
  @Test
  public void malformedForLength_test_2338(int p0) {
    CoderResult.malformedForLength(p0);
  }

  @Test
  public void unmappableForLength_test_2339(int p0) {
    CoderResult.unmappableForLength(p0);
  }
}
