package generated.test;

import java.nio.file.spi.FileSystemProvider;
import org.junit.jupiter.api.Test;

public class java_nio_file_spi_FileSystemProviderAutoTest {
  @Test
  public void installedProviders_test_4778() {
    FileSystemProvider.installedProviders();
  }
}
