package generated.test;

import java.lang.String;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_util_LocaleAutoTest {
  @Test
  public void of_test_8014(String p0, String p1) {
    Locale.of(p0, p1);
  }

  @Test
  public void of_test_8015(String p0, String p1, String p2) {
    Locale.of(p0, p1, p2);
  }

  @Test
  public void of_test_8016(String p0) {
    Locale.of(p0);
  }

  @Test
  public void getDefault_test_8017(Locale.Category p0) {
    Locale.getDefault(p0);
  }

  @Test
  public void getDefault_test_8018() {
    Locale.getDefault();
  }

  @Test
  public void lookup_test_8019(List p0, Collection p1) {
    Locale.lookup(p0, p1);
  }

  @Test
  public void filter_test_8020(List p0, Collection p1, Locale.FilteringMode p2) {
    Locale.filter(p0, p1, p2);
  }

  @Test
  public void filter_test_8021(List p0, Collection p1) {
    Locale.filter(p0, p1);
  }

  @Test
  public void getLanguage_test_8022(String c0) {
    Locale instance = new Locale(c0);
    instance.getLanguage();
  }

  @Test
  public void getDisplayName_test_8023(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayName();
  }

  @Test
  public void getDisplayName_test_8024(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayName(p0);
  }

  @Test
  public void getAvailableLocales_test_8025() {
    Locale.getAvailableLocales();
  }

  @Test
  public void getUnicodeLocaleType_test_8026(String p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleType(p0);
  }

  @Test
  public void getCountry_test_8027(String c0) {
    Locale instance = new Locale(c0);
    instance.getCountry();
  }

  @Test
  public void stripExtensions_test_8028(String c0) {
    Locale instance = new Locale(c0);
    instance.stripExtensions();
  }

  @Test
  public void hasExtensions_test_8029(String c0) {
    Locale instance = new Locale(c0);
    instance.hasExtensions();
  }

  @Test
  public void getVariant_test_8030(String c0) {
    Locale instance = new Locale(c0);
    instance.getVariant();
  }

  @Test
  public void setDefault_test_8031(Locale.Category p0, Locale p1) {
    Locale.setDefault(p0, p1);
  }

  @Test
  public void setDefault_test_8032(Locale p0) {
    Locale.setDefault(p0);
  }

  @Test
  public void getScript_test_8033(String c0) {
    Locale instance = new Locale(c0);
    instance.getScript();
  }

  @Test
  public void getUnicodeLocaleAttributes_test_8034(String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleAttributes();
  }

  @Test
  public void getUnicodeLocaleKeys_test_8035(String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleKeys();
  }

  @Test
  public void getDisplayLanguage_test_8036(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayLanguage();
  }

  @Test
  public void getDisplayLanguage_test_8037(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayLanguage(p0);
  }

  @Test
  public void getDisplayScript_test_8038(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayScript(p0);
  }

  @Test
  public void getDisplayScript_test_8039(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayScript();
  }

  @Test
  public void getDisplayCountry_test_8040(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayCountry(p0);
  }

  @Test
  public void getDisplayCountry_test_8041(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayCountry();
  }

  @Test
  public void getDisplayVariant_test_8042(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayVariant(p0);
  }

  @Test
  public void getDisplayVariant_test_8043(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayVariant();
  }

  @Test
  public void filterTags_test_8044(List p0, Collection p1) {
    Locale.filterTags(p0, p1);
  }

  @Test
  public void filterTags_test_8045(List p0, Collection p1, Locale.FilteringMode p2) {
    Locale.filterTags(p0, p1, p2);
  }

  @Test
  public void lookupTag_test_8046(List p0, Collection p1) {
    Locale.lookupTag(p0, p1);
  }

  @Test
  public void availableLocales_test_8047() {
    Locale.availableLocales();
  }

  @Test
  public void getISOCountries_test_8048(Locale.IsoCountryCode p0) {
    Locale.getISOCountries(p0);
  }

  @Test
  public void getISOCountries_test_8049() {
    Locale.getISOCountries();
  }

  @Test
  public void getISOLanguages_test_8050() {
    Locale.getISOLanguages();
  }

  @Test
  public void getExtension_test_8051(char p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getExtension(p0);
  }

  @Test
  public void getExtensionKeys_test_8052(String c0) {
    Locale instance = new Locale(c0);
    instance.getExtensionKeys();
  }

  @Test
  public void toLanguageTag_test_8053(String c0) {
    Locale instance = new Locale(c0);
    instance.toLanguageTag();
  }

  @Test
  public void caseFoldLanguageTag_test_8054(String p0) {
    Locale.caseFoldLanguageTag(p0);
  }

  @Test
  public void forLanguageTag_test_8055(String p0) {
    Locale.forLanguageTag(p0);
  }

  @Test
  public void getISO3Language_test_8056(String c0) {
    Locale instance = new Locale(c0);
    instance.getISO3Language();
  }

  @Test
  public void getISO3Country_test_8057(String c0) {
    Locale instance = new Locale(c0);
    instance.getISO3Country();
  }
}
