package generated.test;

import java.lang.Object;
import java.lang.ref.Reference;
import org.junit.jupiter.api.Test;

public class java_lang_ref_ReferenceAutoTest {
  @Test
  public void reachabilityFence_test_10486(Object p0) {
    Reference.reachabilityFence(p0);
  }
}
