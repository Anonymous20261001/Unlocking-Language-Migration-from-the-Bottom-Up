package generated.test;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.SystemFlavorMap;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {
  @Test
  public void isJavaMIMEType_test_12438(String p0) {
    SystemFlavorMap.isJavaMIMEType(p0);
  }

  @Test
  public void decodeJavaMIMEType_test_12439(String p0) {
    SystemFlavorMap.decodeJavaMIMEType(p0);
  }

  @Test
  public void encodeDataFlavor_test_12440(DataFlavor p0) {
    SystemFlavorMap.encodeDataFlavor(p0);
  }

  @Test
  public void encodeJavaMIMEType_test_12441(String p0) {
    SystemFlavorMap.encodeJavaMIMEType(p0);
  }

  @Test
  public void getDefaultFlavorMap_test_12442() {
    SystemFlavorMap.getDefaultFlavorMap();
  }
}
