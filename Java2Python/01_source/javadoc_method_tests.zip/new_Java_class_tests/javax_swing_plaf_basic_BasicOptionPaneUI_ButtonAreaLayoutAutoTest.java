package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.lang.String;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_basic_BasicOptionPaneUI_ButtonAreaLayoutAutoTest {
  @Test
  public void removeLayoutComponent_test_1261(Component p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_1262(String p0, Component p1, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_1263(Container p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.layoutContainer(p0);
  }

  @Test
  public void preferredLayoutSize_test_1264(Container p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_1265(Container p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void setSyncAllWidths_test_1266(boolean p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.setSyncAllWidths(p0);
  }

  @Test
  public void getSyncAllWidths_test_1267(boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.getSyncAllWidths();
  }

  @Test
  public void getCentersChildren_test_1268(boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.getCentersChildren();
  }

  @Test
  public void setPadding_test_1269(int p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.setPadding(p0);
  }

  @Test
  public void getPadding_test_1270(boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.getPadding();
  }

  @Test
  public void setCentersChildren_test_1271(boolean p0, boolean c0, int c1) {
    BasicOptionPaneUI.ButtonAreaLayout instance = new BasicOptionPaneUI.ButtonAreaLayout(c0, c1);
    instance.setCentersChildren(p0);
  }
}
