package generated.test;

import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.InputEvent;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.TransferHandler;
import org.junit.jupiter.api.Test;

public class javax_swing_TransferHandlerAutoTest {
  @Test
  public void importData_test_12933(TransferHandler.TransferSupport p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.importData(p0);
  }

  @Test
  public void importData_test_12934(JComponent p0, Transferable p1, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.importData(p0, p1);
  }

  @Test
  public void canImport_test_12935(TransferHandler.TransferSupport p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.canImport(p0);
  }

  @Test
  public void canImport_test_12936(JComponent p0, DataFlavor[] p1, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.canImport(p0, p1);
  }

  @Test
  public void getCutAction_test_12937() {
    TransferHandler.getCutAction();
  }

  @Test
  public void getCopyAction_test_12938() {
    TransferHandler.getCopyAction();
  }

  @Test
  public void getPasteAction_test_12939() {
    TransferHandler.getPasteAction();
  }

  @Test
  public void setDragImage_test_12940(Image p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.setDragImage(p0);
  }

  @Test
  public void getDragImage_test_12941(String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.getDragImage();
  }

  @Test
  public void setDragImageOffset_test_12942(Point p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.setDragImageOffset(p0);
  }

  @Test
  public void getDragImageOffset_test_12943(String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.getDragImageOffset();
  }

  @Test
  public void exportAsDrag_test_12944(JComponent p0, InputEvent p1, int p2, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.exportAsDrag(p0, p1, p2);
  }

  @Test
  public void exportToClipboard_test_12945(JComponent p0, Clipboard p1, int p2, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.exportToClipboard(p0, p1, p2);
  }

  @Test
  public void getVisualRepresentation_test_12946(Transferable p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.getVisualRepresentation(p0);
  }

  @Test
  public void getSourceActions_test_12947(JComponent p0, String c0) {
    TransferHandler instance = new TransferHandler(c0);
    instance.getSourceActions(p0);
  }
}
