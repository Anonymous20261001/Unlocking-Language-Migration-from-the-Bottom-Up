package generated.test;

import jdk.jshell.spi.SPIResolutionException;
import org.junit.jupiter.api.Test;

public class jdk_jshell_spi_SPIResolutionExceptionAutoTest {
  @Test
  public void id_test_11312(int c0) {
    SPIResolutionException instance = new SPIResolutionException(c0);
    instance.id();
  }
}
