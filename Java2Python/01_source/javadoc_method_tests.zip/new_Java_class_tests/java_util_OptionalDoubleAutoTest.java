package generated.test;

import java.util.OptionalDouble;
import org.junit.jupiter.api.Test;

public class java_util_OptionalDoubleAutoTest {
  @Test
  public void of_test_9692(double p0) {
    OptionalDouble.of(p0);
  }

  @Test
  public void empty_test_9693() {
    OptionalDouble.empty();
  }
}
