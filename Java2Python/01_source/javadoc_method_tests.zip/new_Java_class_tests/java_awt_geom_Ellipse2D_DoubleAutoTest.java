package generated.test;

import java.awt.geom.Ellipse2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Ellipse2D_DoubleAutoTest {
  @Test
  public void getWidth_test_4487() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_4488() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.getHeight();
  }

  @Test
  public void getX_test_4489() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.getX();
  }

  @Test
  public void getY_test_4490() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.getY();
  }

  @Test
  public void getBounds2D_test_4491() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.getBounds2D();
  }

  @Test
  public void setFrame_test_4492(double p0, double p1, double p2, double p3) {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.setFrame(p0, p1, p2, p3);
  }

  @Test
  public void isEmpty_test_4493() {
    Ellipse2D.Double instance = new Ellipse2D.Double();
    instance.isEmpty();
  }
}
