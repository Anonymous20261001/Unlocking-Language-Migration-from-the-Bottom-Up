package generated.test;

import java.awt.Label;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_LabelAutoTest {
  @Test
  public void setAlignment_test_7668(int p0) {
    Label instance = new Label();
    instance.setAlignment(p0);
  }

  @Test
  public void addNotify_test_7669() {
    Label instance = new Label();
    instance.addNotify();
  }

  @Test
  public void getAccessibleContext_test_7670() {
    Label instance = new Label();
    instance.getAccessibleContext();
  }

  @Test
  public void setText_test_7671(String p0) {
    Label instance = new Label();
    instance.setText(p0);
  }

  @Test
  public void getAlignment_test_7672() {
    Label instance = new Label();
    instance.getAlignment();
  }

  @Test
  public void getText_test_7673() {
    Label instance = new Label();
    instance.getText();
  }
}
