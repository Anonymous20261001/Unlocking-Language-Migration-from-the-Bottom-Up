package generated.test;

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.MenuShortcut;
import org.junit.jupiter.api.Test;

public class java_awt_MenuBarAutoTest {
  @Test
  public void getMenu_test_8542(int p0) {
    MenuBar instance = new MenuBar();
    instance.getMenu(p0);
  }

  @Test
  public void getMenuCount_test_8543() {
    MenuBar instance = new MenuBar();
    instance.getMenuCount();
  }

  @Test
  public void setHelpMenu_test_8544(Menu p0) {
    MenuBar instance = new MenuBar();
    instance.setHelpMenu(p0);
  }

  @Test
  public void getHelpMenu_test_8545() {
    MenuBar instance = new MenuBar();
    instance.getHelpMenu();
  }

  @Test
  public void addNotify_test_8546() {
    MenuBar instance = new MenuBar();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_8547() {
    MenuBar instance = new MenuBar();
    instance.removeNotify();
  }

  @Test
  public void getAccessibleContext_test_8548() {
    MenuBar instance = new MenuBar();
    instance.getAccessibleContext();
  }

  @Test
  public void deleteShortcut_test_8549(MenuShortcut p0) {
    MenuBar instance = new MenuBar();
    instance.deleteShortcut(p0);
  }

  @Test
  public void getShortcutMenuItem_test_8550(MenuShortcut p0) {
    MenuBar instance = new MenuBar();
    instance.getShortcutMenuItem(p0);
  }

  @Test
  public void countMenus_test_8551() {
    MenuBar instance = new MenuBar();
    instance.countMenus();
  }

  @Test
  public void shortcuts_test_8552() {
    MenuBar instance = new MenuBar();
    instance.shortcuts();
  }

  @Test
  public void remove_test_8553(MenuComponent p0) {
    MenuBar instance = new MenuBar();
    instance.remove(p0);
  }

  @Test
  public void remove_test_8554(int p0) {
    MenuBar instance = new MenuBar();
    instance.remove(p0);
  }

  @Test
  public void add_test_8555(Menu p0) {
    MenuBar instance = new MenuBar();
    instance.add(p0);
  }
}
