package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.plaf.metal.MetalBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalBorders_ToolBarBorderAutoTest {
  @Test
  public void paintBorder_test_8637(Component p0, Graphics p1, int p2, int p3, int p4, int p5) {
    MetalBorders.ToolBarBorder instance = new MetalBorders.ToolBarBorder();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8638(Component p0, Insets p1) {
    MetalBorders.ToolBarBorder instance = new MetalBorders.ToolBarBorder();
    instance.getBorderInsets(p0, p1);
  }
}
