package generated.test;

import java.lang.String;
import java.lang.constant.ConstantDesc;
import java.lang.constant.DirectMethodHandleDesc;
import java.lang.constant.DynamicCallSiteDesc;
import java.lang.constant.MethodTypeDesc;
import org.junit.jupiter.api.Test;

public class java_lang_constant_DynamicCallSiteDescAutoTest {
  @Test
  public void of_test_4417(DirectMethodHandleDesc p0, String p1, MethodTypeDesc p2,
      ConstantDesc[] p3) {
    DynamicCallSiteDesc.of(p0, p1, p2, p3);
  }

  @Test
  public void of_test_4418(DirectMethodHandleDesc p0, MethodTypeDesc p1) {
    DynamicCallSiteDesc.of(p0, p1);
  }

  @Test
  public void of_test_4419(DirectMethodHandleDesc p0, String p1, MethodTypeDesc p2) {
    DynamicCallSiteDesc.of(p0, p1, p2);
  }
}
