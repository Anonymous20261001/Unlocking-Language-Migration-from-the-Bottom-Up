package generated.test;

import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_VectorMaskAutoTest {
  @Test
  public void fromValues_test_13384(VectorSpecies p0, boolean[] p1) {
    VectorMask.fromValues(p0, p1);
  }

  @Test
  public void fromArray_test_13385(VectorSpecies p0, boolean[] p1, int p2) {
    VectorMask.fromArray(p0, p1, p2);
  }

  @Test
  public void fromLong_test_13386(VectorSpecies p0, long p1) {
    VectorMask.fromLong(p0, p1);
  }
}
