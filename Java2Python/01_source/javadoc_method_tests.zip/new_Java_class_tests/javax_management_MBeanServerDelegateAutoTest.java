package generated.test;

import java.lang.Object;
import javax.management.MBeanServerDelegate;
import javax.management.Notification;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import org.junit.jupiter.api.Test;

public class javax_management_MBeanServerDelegateAutoTest {
  @Test
  public void getNotificationInfo_test_8432() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getNotificationInfo();
  }

  @Test
  public void sendNotification_test_8433(Notification p0) {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.sendNotification(p0);
  }

  @Test
  public void getMBeanServerId_test_8434() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getMBeanServerId();
  }

  @Test
  public void getSpecificationName_test_8435() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getSpecificationName();
  }

  @Test
  public void getImplementationName_test_8436() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getImplementationName();
  }

  @Test
  public void addNotificationListener_test_8437(NotificationListener p0, NotificationFilter p1,
      Object p2) {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.addNotificationListener(p0, p1, p2);
  }

  @Test
  public void getSpecificationVersion_test_8438() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getSpecificationVersion();
  }

  @Test
  public void getSpecificationVendor_test_8439() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getSpecificationVendor();
  }

  @Test
  public void getImplementationVersion_test_8440() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getImplementationVersion();
  }

  @Test
  public void getImplementationVendor_test_8441() {
    MBeanServerDelegate instance = new MBeanServerDelegate();
    instance.getImplementationVendor();
  }
}
