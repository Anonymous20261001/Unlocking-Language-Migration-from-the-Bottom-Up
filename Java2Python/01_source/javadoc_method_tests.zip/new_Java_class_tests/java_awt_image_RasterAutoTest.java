package generated.test;

import java.awt.Point;
import java.awt.image.DataBuffer;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import org.junit.jupiter.api.Test;

public class java_awt_image_RasterAutoTest {
  @Test
  public void createInterleavedRaster_test_10325(int p0, int p1, int p2, int p3, int p4, int[] p5,
      Point p6) {
    Raster.createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void createInterleavedRaster_test_10326(int p0, int p1, int p2, int p3, Point p4) {
    Raster.createInterleavedRaster(p0, p1, p2, p3, p4);
  }

  @Test
  public void createInterleavedRaster_test_10327(DataBuffer p0, int p1, int p2, int p3, int p4,
      int[] p5, Point p6) {
    Raster.createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void createPackedRaster_test_10328(int p0, int p1, int p2, int[] p3, Point p4) {
    Raster.createPackedRaster(p0, p1, p2, p3, p4);
  }

  @Test
  public void createPackedRaster_test_10329(int p0, int p1, int p2, int p3, int p4, Point p5) {
    Raster.createPackedRaster(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createPackedRaster_test_10330(DataBuffer p0, int p1, int p2, int p3, int[] p4,
      Point p5) {
    Raster.createPackedRaster(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createPackedRaster_test_10331(DataBuffer p0, int p1, int p2, int p3, Point p4) {
    Raster.createPackedRaster(p0, p1, p2, p3, p4);
  }

  @Test
  public void createWritableRaster_test_10332(SampleModel p0, Point p1) {
    Raster.createWritableRaster(p0, p1);
  }

  @Test
  public void createWritableRaster_test_10333(SampleModel p0, DataBuffer p1, Point p2) {
    Raster.createWritableRaster(p0, p1, p2);
  }

  @Test
  public void createBandedRaster_test_10334(DataBuffer p0, int p1, int p2, int p3, int[] p4,
      int[] p5, Point p6) {
    Raster.createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void createBandedRaster_test_10335(int p0, int p1, int p2, int p3, Point p4) {
    Raster.createBandedRaster(p0, p1, p2, p3, p4);
  }

  @Test
  public void createBandedRaster_test_10336(int p0, int p1, int p2, int p3, int[] p4, int[] p5,
      Point p6) {
    Raster.createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void createRaster_test_10337(SampleModel p0, DataBuffer p1, Point p2) {
    Raster.createRaster(p0, p1, p2);
  }
}
