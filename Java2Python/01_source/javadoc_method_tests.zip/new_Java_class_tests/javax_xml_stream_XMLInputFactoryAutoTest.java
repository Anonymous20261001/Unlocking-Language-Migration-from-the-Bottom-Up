package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.stream.XMLInputFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_stream_XMLInputFactoryAutoTest {
  @Test
  public void newDefaultFactory_test_13634() {
    XMLInputFactory.newDefaultFactory();
  }

  @Test
  public void newInstance_test_13635() {
    XMLInputFactory.newInstance();
  }

  @Test
  public void newInstance_test_13636(String p0, ClassLoader p1) {
    XMLInputFactory.newInstance(p0, p1);
  }

  @Test
  public void newFactory_test_13637(String p0, ClassLoader p1) {
    XMLInputFactory.newFactory(p0, p1);
  }

  @Test
  public void newFactory_test_13638() {
    XMLInputFactory.newFactory();
  }
}
