package generated.test;

import java.security.KeyStore;
import javax.security.auth.callback.CallbackHandler;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_CallbackHandlerProtectionAutoTest {
  @Test
  public void getCallbackHandler_test_7641(CallbackHandler c0) {
    KeyStore.CallbackHandlerProtection instance = new KeyStore.CallbackHandlerProtection(c0);
    instance.getCallbackHandler();
  }
}
