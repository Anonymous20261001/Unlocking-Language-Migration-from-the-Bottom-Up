package generated.test;

import java.awt.geom.RoundRectangle2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_RoundRectangle2D_DoubleAutoTest {
  @Test
  public void getWidth_test_10687() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_10688() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getHeight();
  }

  @Test
  public void getX_test_10689() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getX();
  }

  @Test
  public void getY_test_10690() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getY();
  }

  @Test
  public void getBounds2D_test_10691() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getBounds2D();
  }

  @Test
  public void getArcWidth_test_10692() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getArcWidth();
  }

  @Test
  public void getArcHeight_test_10693() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.getArcHeight();
  }

  @Test
  public void setRoundRect_test_10694(RoundRectangle2D p0) {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.setRoundRect(p0);
  }

  @Test
  public void setRoundRect_test_10695(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.setRoundRect(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void isEmpty_test_10696() {
    RoundRectangle2D.Double instance = new RoundRectangle2D.Double();
    instance.isEmpty();
  }
}
