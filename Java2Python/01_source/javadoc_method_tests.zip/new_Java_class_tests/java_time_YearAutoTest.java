package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Year;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_YearAutoTest {
  @Test
  public void of_test_13666(int p0) {
    Year.of(p0);
  }

  @Test
  public void from_test_13667(TemporalAccessor p0) {
    Year.from(p0);
  }

  @Test
  public void parse_test_13668(CharSequence p0, DateTimeFormatter p1) {
    Year.parse(p0, p1);
  }

  @Test
  public void parse_test_13669(CharSequence p0) {
    Year.parse(p0);
  }

  @Test
  public void now_test_13670() {
    Year.now();
  }

  @Test
  public void now_test_13671(Clock p0) {
    Year.now(p0);
  }

  @Test
  public void now_test_13672(ZoneId p0) {
    Year.now(p0);
  }

  @Test
  public void isLeap_test_13673(long p0) {
    Year.isLeap(p0);
  }
}
