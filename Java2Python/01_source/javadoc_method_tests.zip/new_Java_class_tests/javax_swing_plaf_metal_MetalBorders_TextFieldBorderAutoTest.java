package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_metal_MetalBorders_TextFieldBorderAutoTest {
  @Test
  public void paintBorder_test_8635(Component p0, Graphics p1, int p2, int p3, int p4, int p5) {
    MetalBorders.TextFieldBorder instance = new MetalBorders.TextFieldBorder();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }
}
