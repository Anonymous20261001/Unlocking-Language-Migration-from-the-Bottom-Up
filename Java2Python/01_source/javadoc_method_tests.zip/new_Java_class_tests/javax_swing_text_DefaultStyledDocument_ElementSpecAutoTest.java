package generated.test;

import javax.swing.text.AttributeSet;
import javax.swing.text.DefaultStyledDocument;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultStyledDocument_ElementSpecAutoTest {
  @Test
  public void setType_test_3878(short p0, AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.setType(p0);
  }

  @Test
  public void setDirection_test_3879(short p0, AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.setDirection(p0);
  }

  @Test
  public void getDirection_test_3880(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getDirection();
  }

  @Test
  public void getLength_test_3881(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getLength();
  }

  @Test
  public void getType_test_3882(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getType();
  }

  @Test
  public void getAttributes_test_3883(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getAttributes();
  }

  @Test
  public void getOffset_test_3884(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getOffset();
  }

  @Test
  public void getArray_test_3885(AttributeSet c0, short c1) {
    DefaultStyledDocument.ElementSpec instance = new DefaultStyledDocument.ElementSpec(c0, c1);
    instance.getArray();
  }
}
