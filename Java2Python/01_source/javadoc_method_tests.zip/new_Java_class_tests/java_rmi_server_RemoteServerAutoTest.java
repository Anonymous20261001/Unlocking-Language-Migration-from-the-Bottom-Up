package generated.test;

import java.io.OutputStream;
import java.rmi.server.RemoteServer;
import org.junit.jupiter.api.Test;

public class java_rmi_server_RemoteServerAutoTest {
  @Test
  public void setLog_test_10522(OutputStream p0) {
    RemoteServer.setLog(p0);
  }

  @Test
  public void getLog_test_10523() {
    RemoteServer.getLog();
  }
}
