package generated.test;

import java.lang.Math;
import org.junit.jupiter.api.Test;

public class java_lang_MathAutoTest {
  @Test
  public void abs_test_8296(float p0) {
    Math.abs(p0);
  }

  @Test
  public void abs_test_8297(long p0) {
    Math.abs(p0);
  }

  @Test
  public void abs_test_8298(int p0) {
    Math.abs(p0);
  }

  @Test
  public void abs_test_8299(double p0) {
    Math.abs(p0);
  }

  @Test
  public void sin_test_8300(double p0) {
    Math.sin(p0);
  }

  @Test
  public void cos_test_8301(double p0) {
    Math.cos(p0);
  }

  @Test
  public void tan_test_8302(double p0) {
    Math.tan(p0);
  }

  @Test
  public void atan2_test_8303(double p0, double p1) {
    Math.atan2(p0, p1);
  }

  @Test
  public void sqrt_test_8304(double p0) {
    Math.sqrt(p0);
  }

  @Test
  public void log_test_8305(double p0) {
    Math.log(p0);
  }

  @Test
  public void log10_test_8306(double p0) {
    Math.log10(p0);
  }

  @Test
  public void pow_test_8307(double p0, double p1) {
    Math.pow(p0, p1);
  }

  @Test
  public void exp_test_8308(double p0) {
    Math.exp(p0);
  }

  @Test
  public void min_test_8309(int p0, int p1) {
    Math.min(p0, p1);
  }

  @Test
  public void min_test_8310(long p0, long p1) {
    Math.min(p0, p1);
  }

  @Test
  public void min_test_8311(double p0, double p1) {
    Math.min(p0, p1);
  }

  @Test
  public void min_test_8312(float p0, float p1) {
    Math.min(p0, p1);
  }

  @Test
  public void max_test_8313(long p0, long p1) {
    Math.max(p0, p1);
  }

  @Test
  public void max_test_8314(int p0, int p1) {
    Math.max(p0, p1);
  }

  @Test
  public void max_test_8315(double p0, double p1) {
    Math.max(p0, p1);
  }

  @Test
  public void max_test_8316(float p0, float p1) {
    Math.max(p0, p1);
  }

  @Test
  public void floor_test_8317(double p0) {
    Math.floor(p0);
  }

  @Test
  public void ceil_test_8318(double p0) {
    Math.ceil(p0);
  }

  @Test
  public void rint_test_8319(double p0) {
    Math.rint(p0);
  }

  @Test
  public void round_test_8320(double p0) {
    Math.round(p0);
  }

  @Test
  public void round_test_8321(float p0) {
    Math.round(p0);
  }

  @Test
  public void tanh_test_8322(double p0) {
    Math.tanh(p0);
  }

  @Test
  public void cbrt_test_8323(double p0) {
    Math.cbrt(p0);
  }

  @Test
  public void addExact_test_8324(int p0, int p1) {
    Math.addExact(p0, p1);
  }

  @Test
  public void addExact_test_8325(long p0, long p1) {
    Math.addExact(p0, p1);
  }

  @Test
  public void decrementExact_test_8326(int p0) {
    Math.decrementExact(p0);
  }

  @Test
  public void decrementExact_test_8327(long p0) {
    Math.decrementExact(p0);
  }

  @Test
  public void incrementExact_test_8328(long p0) {
    Math.incrementExact(p0);
  }

  @Test
  public void incrementExact_test_8329(int p0) {
    Math.incrementExact(p0);
  }

  @Test
  public void multiplyExact_test_8330(long p0, long p1) {
    Math.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyExact_test_8331(int p0, int p1) {
    Math.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyExact_test_8332(long p0, int p1) {
    Math.multiplyExact(p0, p1);
  }

  @Test
  public void multiplyHigh_test_8333(long p0, long p1) {
    Math.multiplyHigh(p0, p1);
  }

  @Test
  public void unsignedMultiplyHigh_test_8334(long p0, long p1) {
    Math.unsignedMultiplyHigh(p0, p1);
  }

  @Test
  public void negateExact_test_8335(long p0) {
    Math.negateExact(p0);
  }

  @Test
  public void negateExact_test_8336(int p0) {
    Math.negateExact(p0);
  }

  @Test
  public void subtractExact_test_8337(int p0, int p1) {
    Math.subtractExact(p0, p1);
  }

  @Test
  public void subtractExact_test_8338(long p0, long p1) {
    Math.subtractExact(p0, p1);
  }

  @Test
  public void fma_test_8339(double p0, double p1, double p2) {
    Math.fma(p0, p1, p2);
  }

  @Test
  public void fma_test_8340(float p0, float p1, float p2) {
    Math.fma(p0, p1, p2);
  }

  @Test
  public void copySign_test_8341(double p0, double p1) {
    Math.copySign(p0, p1);
  }

  @Test
  public void copySign_test_8342(float p0, float p1) {
    Math.copySign(p0, p1);
  }

  @Test
  public void signum_test_8343(float p0) {
    Math.signum(p0);
  }

  @Test
  public void signum_test_8344(double p0) {
    Math.signum(p0);
  }

  @Test
  public void clamp_test_8345(float p0, float p1, float p2) {
    Math.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_8346(long p0, int p1, int p2) {
    Math.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_8347(double p0, double p1, double p2) {
    Math.clamp(p0, p1, p2);
  }

  @Test
  public void clamp_test_8348(long p0, long p1, long p2) {
    Math.clamp(p0, p1, p2);
  }

  @Test
  public void scalb_test_8349(float p0, int p1) {
    Math.scalb(p0, p1);
  }

  @Test
  public void scalb_test_8350(double p0, int p1) {
    Math.scalb(p0, p1);
  }

  @Test
  public void getExponent_test_8351(float p0) {
    Math.getExponent(p0);
  }

  @Test
  public void getExponent_test_8352(double p0) {
    Math.getExponent(p0);
  }

  @Test
  public void floorMod_test_8353(long p0, long p1) {
    Math.floorMod(p0, p1);
  }

  @Test
  public void floorMod_test_8354(int p0, int p1) {
    Math.floorMod(p0, p1);
  }

  @Test
  public void floorMod_test_8355(long p0, int p1) {
    Math.floorMod(p0, p1);
  }

  @Test
  public void asin_test_8356(double p0) {
    Math.asin(p0);
  }

  @Test
  public void acos_test_8357(double p0) {
    Math.acos(p0);
  }

  @Test
  public void atan_test_8358(double p0) {
    Math.atan(p0);
  }

  @Test
  public void IEEEremainder_test_8359(double p0, double p1) {
    Math.IEEEremainder(p0, p1);
  }

  @Test
  public void floorDiv_test_8360(long p0, long p1) {
    Math.floorDiv(p0, p1);
  }

  @Test
  public void floorDiv_test_8361(long p0, int p1) {
    Math.floorDiv(p0, p1);
  }

  @Test
  public void floorDiv_test_8362(int p0, int p1) {
    Math.floorDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_8363(long p0, long p1) {
    Math.ceilDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_8364(long p0, int p1) {
    Math.ceilDiv(p0, p1);
  }

  @Test
  public void ceilDiv_test_8365(int p0, int p1) {
    Math.ceilDiv(p0, p1);
  }

  @Test
  public void ceilMod_test_8366(int p0, int p1) {
    Math.ceilMod(p0, p1);
  }

  @Test
  public void ceilMod_test_8367(long p0, long p1) {
    Math.ceilMod(p0, p1);
  }

  @Test
  public void ceilMod_test_8368(long p0, int p1) {
    Math.ceilMod(p0, p1);
  }

  @Test
  public void sinh_test_8369(double p0) {
    Math.sinh(p0);
  }

  @Test
  public void cosh_test_8370(double p0) {
    Math.cosh(p0);
  }

  @Test
  public void hypot_test_8371(double p0, double p1) {
    Math.hypot(p0, p1);
  }

  @Test
  public void expm1_test_8372(double p0) {
    Math.expm1(p0);
  }

  @Test
  public void log1p_test_8373(double p0) {
    Math.log1p(p0);
  }

  @Test
  public void unsignedMultiplyExact_test_8374(int p0, int p1) {
    Math.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void unsignedMultiplyExact_test_8375(long p0, long p1) {
    Math.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void unsignedMultiplyExact_test_8376(long p0, int p1) {
    Math.unsignedMultiplyExact(p0, p1);
  }

  @Test
  public void toRadians_test_8377(double p0) {
    Math.toRadians(p0);
  }

  @Test
  public void toDegrees_test_8378(double p0) {
    Math.toDegrees(p0);
  }

  @Test
  public void random_test_8379() {
    Math.random();
  }

  @Test
  public void divideExact_test_8380(int p0, int p1) {
    Math.divideExact(p0, p1);
  }

  @Test
  public void divideExact_test_8381(long p0, long p1) {
    Math.divideExact(p0, p1);
  }

  @Test
  public void floorDivExact_test_8382(int p0, int p1) {
    Math.floorDivExact(p0, p1);
  }

  @Test
  public void floorDivExact_test_8383(long p0, long p1) {
    Math.floorDivExact(p0, p1);
  }

  @Test
  public void ceilDivExact_test_8384(long p0, long p1) {
    Math.ceilDivExact(p0, p1);
  }

  @Test
  public void ceilDivExact_test_8385(int p0, int p1) {
    Math.ceilDivExact(p0, p1);
  }

  @Test
  public void toIntExact_test_8386(long p0) {
    Math.toIntExact(p0);
  }

  @Test
  public void multiplyFull_test_8387(int p0, int p1) {
    Math.multiplyFull(p0, p1);
  }

  @Test
  public void absExact_test_8388(long p0) {
    Math.absExact(p0);
  }

  @Test
  public void absExact_test_8389(int p0) {
    Math.absExact(p0);
  }

  @Test
  public void ulp_test_8390(float p0) {
    Math.ulp(p0);
  }

  @Test
  public void ulp_test_8391(double p0) {
    Math.ulp(p0);
  }

  @Test
  public void nextAfter_test_8392(double p0, double p1) {
    Math.nextAfter(p0, p1);
  }

  @Test
  public void nextAfter_test_8393(float p0, double p1) {
    Math.nextAfter(p0, p1);
  }

  @Test
  public void nextUp_test_8394(float p0) {
    Math.nextUp(p0);
  }

  @Test
  public void nextUp_test_8395(double p0) {
    Math.nextUp(p0);
  }

  @Test
  public void nextDown_test_8396(float p0) {
    Math.nextDown(p0);
  }

  @Test
  public void nextDown_test_8397(double p0) {
    Math.nextDown(p0);
  }

  @Test
  public void powExact_test_8398(int p0, int p1) {
    Math.powExact(p0, p1);
  }

  @Test
  public void powExact_test_8399(long p0, int p1) {
    Math.powExact(p0, p1);
  }

  @Test
  public void unsignedPowExact_test_8400(long p0, int p1) {
    Math.unsignedPowExact(p0, p1);
  }

  @Test
  public void unsignedPowExact_test_8401(int p0, int p1) {
    Math.unsignedPowExact(p0, p1);
  }
}
