package generated.test;

import java.lang.Class;
import java.util.prefs.Preferences;
import org.junit.jupiter.api.Test;

public class java_util_prefs_PreferencesAutoTest {
  @Test
  public void userRoot_test_10000() {
    Preferences.userRoot();
  }

  @Test
  public void systemRoot_test_10001() {
    Preferences.systemRoot();
  }

  @Test
  public void userNodeForPackage_test_10002(Class p0) {
    Preferences.userNodeForPackage(p0);
  }

  @Test
  public void systemNodeForPackage_test_10003(Class p0) {
    Preferences.systemNodeForPackage(p0);
  }
}
