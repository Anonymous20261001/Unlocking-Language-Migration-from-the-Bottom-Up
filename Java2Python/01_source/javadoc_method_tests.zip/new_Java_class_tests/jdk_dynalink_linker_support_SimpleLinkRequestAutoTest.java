package generated.test;

import java.lang.Object;
import jdk.dynalink.CallSiteDescriptor;
import jdk.dynalink.linker.support.SimpleLinkRequest;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_linker_support_SimpleLinkRequestAutoTest {
  @Test
  public void getReceiver_test_11173(CallSiteDescriptor c0, boolean c1, Object[] c2) {
    SimpleLinkRequest instance = new SimpleLinkRequest(c0, c1, c2);
    instance.getReceiver();
  }

  @Test
  public void getArguments_test_11174(CallSiteDescriptor c0, boolean c1, Object[] c2) {
    SimpleLinkRequest instance = new SimpleLinkRequest(c0, c1, c2);
    instance.getArguments();
  }

  @Test
  public void isCallSiteUnstable_test_11175(CallSiteDescriptor c0, boolean c1, Object[] c2) {
    SimpleLinkRequest instance = new SimpleLinkRequest(c0, c1, c2);
    instance.isCallSiteUnstable();
  }

  @Test
  public void replaceArguments_test_11176(CallSiteDescriptor p0, Object[] p1, CallSiteDescriptor c0,
      boolean c1, Object[] c2) {
    SimpleLinkRequest instance = new SimpleLinkRequest(c0, c1, c2);
    instance.replaceArguments(p0, p1);
  }

  @Test
  public void getCallSiteDescriptor_test_11177(CallSiteDescriptor c0, boolean c1, Object[] c2) {
    SimpleLinkRequest instance = new SimpleLinkRequest(c0, c1, c2);
    instance.getCallSiteDescriptor();
  }
}
