package generated.test;

import javax.swing.LayoutStyle;
import org.junit.jupiter.api.Test;

public class javax_swing_LayoutStyleAutoTest {
  @Test
  public void setInstance_test_7711(LayoutStyle p0) {
    LayoutStyle.setInstance(p0);
  }

  @Test
  public void getInstance_test_7712() {
    LayoutStyle.getInstance();
  }
}
