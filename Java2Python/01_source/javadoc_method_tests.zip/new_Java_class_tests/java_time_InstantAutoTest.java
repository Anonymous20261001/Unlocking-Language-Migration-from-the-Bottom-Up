package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_InstantAutoTest {
  @Test
  public void from_test_5857(TemporalAccessor p0) {
    Instant.from(p0);
  }

  @Test
  public void parse_test_5858(CharSequence p0) {
    Instant.parse(p0);
  }

  @Test
  public void now_test_5859() {
    Instant.now();
  }

  @Test
  public void now_test_5860(Clock p0) {
    Instant.now(p0);
  }

  @Test
  public void ofEpochSecond_test_5861(long p0, long p1) {
    Instant.ofEpochSecond(p0, p1);
  }

  @Test
  public void ofEpochSecond_test_5862(long p0) {
    Instant.ofEpochSecond(p0);
  }

  @Test
  public void ofEpochMilli_test_5863(long p0) {
    Instant.ofEpochMilli(p0);
  }
}
