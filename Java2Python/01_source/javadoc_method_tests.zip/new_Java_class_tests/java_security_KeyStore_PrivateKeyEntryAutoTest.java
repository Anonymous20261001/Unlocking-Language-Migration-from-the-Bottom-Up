package generated.test;

import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import org.junit.jupiter.api.Test;

public class java_security_KeyStore_PrivateKeyEntryAutoTest {
  @Test
  public void getCertificate_test_7646(PrivateKey c0, Certificate[] c1) {
    KeyStore.PrivateKeyEntry instance = new KeyStore.PrivateKeyEntry(c0, c1);
    instance.getCertificate();
  }

  @Test
  public void getAttributes_test_7647(PrivateKey c0, Certificate[] c1) {
    KeyStore.PrivateKeyEntry instance = new KeyStore.PrivateKeyEntry(c0, c1);
    instance.getAttributes();
  }

  @Test
  public void getCertificateChain_test_7648(PrivateKey c0, Certificate[] c1) {
    KeyStore.PrivateKeyEntry instance = new KeyStore.PrivateKeyEntry(c0, c1);
    instance.getCertificateChain();
  }

  @Test
  public void getPrivateKey_test_7649(PrivateKey c0, Certificate[] c1) {
    KeyStore.PrivateKeyEntry instance = new KeyStore.PrivateKeyEntry(c0, c1);
    instance.getPrivateKey();
  }
}
