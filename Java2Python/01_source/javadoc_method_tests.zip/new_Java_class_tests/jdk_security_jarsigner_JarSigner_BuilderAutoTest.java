package generated.test;

import java.lang.String;
import java.net.URI;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.util.function.BiConsumer;
import jdk.security.jarsigner.JarSigner;
import org.junit.jupiter.api.Test;

public class jdk_security_jarsigner_JarSigner_BuilderAutoTest {
  @Test
  public void setProperty_test_5999(String p0, String p1, KeyStore.PrivateKeyEntry c0) {
    JarSigner.Builder instance = new JarSigner.Builder(c0);
    instance.setProperty(p0, p1);
  }

  @Test
  public void build_test_6000(KeyStore.PrivateKeyEntry c0) {
    JarSigner.Builder instance = new JarSigner.Builder(c0);
    instance.build();
  }

  @Test
  public void tsa_test_6001(URI p0, KeyStore.PrivateKeyEntry c0) {
    JarSigner.Builder instance = new JarSigner.Builder(c0);
    instance.tsa(p0);
  }

  @Test
  public void eventHandler_test_6002(BiConsumer p0, KeyStore.PrivateKeyEntry c0) {
    JarSigner.Builder instance = new JarSigner.Builder(c0);
    instance.eventHandler(p0);
  }

  @Test
  public void signerName_test_6003(String p0, KeyStore.PrivateKeyEntry c0) {
    JarSigner.Builder instance = new JarSigner.Builder(c0);
    instance.signerName(p0);
  }

  @Test
  public void getDefaultSignatureAlgorithm_test_6004(PrivateKey p0) {
    JarSigner.Builder.getDefaultSignatureAlgorithm(p0);
  }

  @Test
  public void getDefaultDigestAlgorithm_test_6005() {
    JarSigner.Builder.getDefaultDigestAlgorithm();
  }
}
