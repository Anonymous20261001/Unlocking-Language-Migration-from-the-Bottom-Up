package generated.test;

import java.lang.module.Configuration;
import java.lang.module.ModuleFinder;
import java.util.Collection;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_lang_module_ConfigurationAutoTest {
  @Test
  public void empty_test_2903() {
    Configuration.empty();
  }

  @Test
  public void resolve_test_2904(ModuleFinder p0, List p1, ModuleFinder p2, Collection p3) {
    Configuration.resolve(p0, p1, p2, p3);
  }

  @Test
  public void resolveAndBind_test_2905(ModuleFinder p0, List p1, ModuleFinder p2, Collection p3) {
    Configuration.resolveAndBind(p0, p1, p2, p3);
  }
}
