package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.basic.BasicBorders;
import org.junit.jupiter.api.Test;

public class javax_swing_plaf_basic_BasicBorders_SplitPaneBorderAutoTest {
  @Test
  public void paintBorder_test_1032(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
      Color c0, Color c1) {
    BasicBorders.SplitPaneBorder instance = new BasicBorders.SplitPaneBorder(c0, c1);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_1033(Component p0, Color c0, Color c1) {
    BasicBorders.SplitPaneBorder instance = new BasicBorders.SplitPaneBorder(c0, c1);
    instance.getBorderInsets(p0);
  }

  @Test
  public void isBorderOpaque_test_1034(Color c0, Color c1) {
    BasicBorders.SplitPaneBorder instance = new BasicBorders.SplitPaneBorder(c0, c1);
    instance.isBorderOpaque();
  }
}
