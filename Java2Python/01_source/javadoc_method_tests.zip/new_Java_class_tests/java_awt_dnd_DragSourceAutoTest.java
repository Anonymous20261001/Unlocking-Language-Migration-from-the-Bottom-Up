package generated.test;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.FlavorMap;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DragSourceMotionListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragSourceAutoTest {
  @Test
  public void addDragSourceListener_test_4296(DragSourceListener p0) {
    DragSource instance = new DragSource();
    instance.addDragSourceListener(p0);
  }

  @Test
  public void addDragSourceMotionListener_test_4297(DragSourceMotionListener p0) {
    DragSource instance = new DragSource();
    instance.addDragSourceMotionListener(p0);
  }

  @Test
  public void getDefaultDragSource_test_4298() {
    DragSource.getDefaultDragSource();
  }

  @Test
  public void isDragImageSupported_test_4299() {
    DragSource.isDragImageSupported();
  }

  @Test
  public void createDefaultDragGestureRecognizer_test_4300(Component p0, int p1,
      DragGestureListener p2) {
    DragSource instance = new DragSource();
    instance.createDefaultDragGestureRecognizer(p0, p1, p2);
  }

  @Test
  public void removeDragSourceListener_test_4301(DragSourceListener p0) {
    DragSource instance = new DragSource();
    instance.removeDragSourceListener(p0);
  }

  @Test
  public void getDragSourceListeners_test_4302() {
    DragSource instance = new DragSource();
    instance.getDragSourceListeners();
  }

  @Test
  public void removeDragSourceMotionListener_test_4303(DragSourceMotionListener p0) {
    DragSource instance = new DragSource();
    instance.removeDragSourceMotionListener(p0);
  }

  @Test
  public void getDragSourceMotionListeners_test_4304() {
    DragSource instance = new DragSource();
    instance.getDragSourceMotionListeners();
  }

  @Test
  public void getDragThreshold_test_4305() {
    DragSource.getDragThreshold();
  }

  @Test
  public void getListeners_test_4306(Class p0) {
    DragSource instance = new DragSource();
    instance.getListeners(p0);
  }

  @Test
  public void createDragGestureRecognizer_test_4307(Class p0, Component p1, int p2,
      DragGestureListener p3) {
    DragSource instance = new DragSource();
    instance.createDragGestureRecognizer(p0, p1, p2, p3);
  }

  @Test
  public void startDrag_test_4308(DragGestureEvent p0, Cursor p1, Image p2, Point p3,
      Transferable p4, DragSourceListener p5) {
    DragSource instance = new DragSource();
    instance.startDrag(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void startDrag_test_4309(DragGestureEvent p0, Cursor p1, Transferable p2,
      DragSourceListener p3) {
    DragSource instance = new DragSource();
    instance.startDrag(p0, p1, p2, p3);
  }

  @Test
  public void startDrag_test_4310(DragGestureEvent p0, Cursor p1, Image p2, Point p3,
      Transferable p4, DragSourceListener p5, FlavorMap p6) {
    DragSource instance = new DragSource();
    instance.startDrag(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void startDrag_test_4311(DragGestureEvent p0, Cursor p1, Transferable p2,
      DragSourceListener p3, FlavorMap p4) {
    DragSource instance = new DragSource();
    instance.startDrag(p0, p1, p2, p3, p4);
  }

  @Test
  public void getFlavorMap_test_4312() {
    DragSource instance = new DragSource();
    instance.getFlavorMap();
  }
}
