package generated.test;

import java.awt.GraphicsEnvironment;
import org.junit.jupiter.api.Test;

public class java_awt_GraphicsEnvironmentAutoTest {
  @Test
  public void isHeadless_test_5148() {
    GraphicsEnvironment.isHeadless();
  }

  @Test
  public void getLocalGraphicsEnvironment_test_5149() {
    GraphicsEnvironment.getLocalGraphicsEnvironment();
  }
}
