package generated.test;

import java.awt.geom.CubicCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_CubicCurve2DAutoTest {
  @Test
  public void getFlatnessSq_test_3126(double p0, double p1, double p2, double p3, double p4,
      double p5, double p6, double p7) {
    CubicCurve2D.getFlatnessSq(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void getFlatnessSq_test_3127(double[] p0, int p1) {
    CubicCurve2D.getFlatnessSq(p0, p1);
  }

  @Test
  public void getFlatness_test_3128(double[] p0, int p1) {
    CubicCurve2D.getFlatness(p0, p1);
  }

  @Test
  public void getFlatness_test_3129(double p0, double p1, double p2, double p3, double p4,
      double p5, double p6, double p7) {
    CubicCurve2D.getFlatness(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void subdivide_test_3130(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5) {
    CubicCurve2D.subdivide(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void subdivide_test_3131(CubicCurve2D p0, CubicCurve2D p1, CubicCurve2D p2) {
    CubicCurve2D.subdivide(p0, p1, p2);
  }

  @Test
  public void solveCubic_test_3132(double[] p0, double[] p1) {
    CubicCurve2D.solveCubic(p0, p1);
  }

  @Test
  public void solveCubic_test_3133(double[] p0) {
    CubicCurve2D.solveCubic(p0);
  }
}
