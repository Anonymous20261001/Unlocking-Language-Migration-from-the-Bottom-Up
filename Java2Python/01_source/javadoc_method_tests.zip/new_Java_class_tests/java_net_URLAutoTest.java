package generated.test;

import java.net.URL;
import java.net.URLStreamHandlerFactory;
import org.junit.jupiter.api.Test;

public class java_net_URLAutoTest {
  @Test
  public void setURLStreamHandlerFactory_test_13249(URLStreamHandlerFactory p0) {
    URL.setURLStreamHandlerFactory(p0);
  }
}
