package generated.test;

import java.nio.DoubleBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_DoubleBufferAutoTest {
  @Test
  public void wrap_test_4265(double[] p0) {
    DoubleBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_4266(double[] p0, int p1, int p2) {
    DoubleBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_4267(int p0) {
    DoubleBuffer.allocate(p0);
  }
}
