package generated.test;

import java.lang.Class;
import java.lang.Runnable;
import jdk.jfr.FlightRecorder;
import jdk.jfr.FlightRecorderListener;
import org.junit.jupiter.api.Test;

public class jdk_jfr_FlightRecorderAutoTest {
  @Test
  public void addListener_test_4816(FlightRecorderListener p0) {
    FlightRecorder.addListener(p0);
  }

  @Test
  public void removeListener_test_4817(FlightRecorderListener p0) {
    FlightRecorder.removeListener(p0);
  }

  @Test
  public void isAvailable_test_4818() {
    FlightRecorder.isAvailable();
  }

  @Test
  public void getFlightRecorder_test_4819() {
    FlightRecorder.getFlightRecorder();
  }

  @Test
  public void addPeriodicEvent_test_4820(Class p0, Runnable p1) {
    FlightRecorder.addPeriodicEvent(p0, p1);
  }

  @Test
  public void removePeriodicEvent_test_4821(Runnable p0) {
    FlightRecorder.removePeriodicEvent(p0);
  }

  @Test
  public void register_test_4822(Class p0) {
    FlightRecorder.register(p0);
  }

  @Test
  public void unregister_test_4823(Class p0) {
    FlightRecorder.unregister(p0);
  }

  @Test
  public void isInitialized_test_4824() {
    FlightRecorder.isInitialized();
  }
}
