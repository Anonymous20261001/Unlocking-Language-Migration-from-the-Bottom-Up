package generated.test;

import java.lang.Number;
import javax.management.ObjectName;
import javax.management.monitor.CounterMonitor;
import org.junit.jupiter.api.Test;

public class javax_management_monitor_CounterMonitorAutoTest {
  @Test
  public void getInitThreshold_test_3090() {
    CounterMonitor instance = new CounterMonitor();
    instance.getInitThreshold();
  }

  @Test
  public void getModulus_test_3091() {
    CounterMonitor instance = new CounterMonitor();
    instance.getModulus();
  }

  @Test
  public void setModulus_test_3092(Number p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setModulus(p0);
  }

  @Test
  public void getNotify_test_3093() {
    CounterMonitor instance = new CounterMonitor();
    instance.getNotify();
  }

  @Test
  public void setNotify_test_3094(boolean p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setNotify(p0);
  }

  @Test
  public void getDifferenceMode_test_3095() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDifferenceMode();
  }

  @Test
  public void setDifferenceMode_test_3096(boolean p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setDifferenceMode(p0);
  }

  @Test
  public void getNotificationInfo_test_3097() {
    CounterMonitor instance = new CounterMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_3098(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGauge_test_3099() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_3100(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_3101() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getThreshold_test_3102(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getThreshold(p0);
  }

  @Test
  public void getThreshold_test_3103() {
    CounterMonitor instance = new CounterMonitor();
    instance.getThreshold();
  }

  @Test
  public void setInitThreshold_test_3104(Number p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setInitThreshold(p0);
  }

  @Test
  public void start_test_3105() {
    CounterMonitor instance = new CounterMonitor();
    instance.start();
  }

  @Test
  public void stop_test_3106() {
    CounterMonitor instance = new CounterMonitor();
    instance.stop();
  }

  @Test
  public void getOffset_test_3107() {
    CounterMonitor instance = new CounterMonitor();
    instance.getOffset();
  }

  @Test
  public void setOffset_test_3108(Number p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setOffset(p0);
  }

  @Test
  public void setThreshold_test_3109(Number p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setThreshold(p0);
  }
}
