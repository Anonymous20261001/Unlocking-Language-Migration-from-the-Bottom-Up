package generated.test;

import javax.security.sasl.Sasl;
import org.junit.jupiter.api.Test;

public class javax_security_sasl_SaslAutoTest {
  @Test
  public void getSaslClientFactories_test_10758() {
    Sasl.getSaslClientFactories();
  }

  @Test
  public void getSaslServerFactories_test_10759() {
    Sasl.getSaslServerFactories();
  }
}
