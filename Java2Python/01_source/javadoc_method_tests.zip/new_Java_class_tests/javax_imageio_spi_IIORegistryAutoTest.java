package generated.test;

import javax.imageio.spi.IIORegistry;
import org.junit.jupiter.api.Test;

public class javax_imageio_spi_IIORegistryAutoTest {
  @Test
  public void getDefaultInstance_test_5617() {
    IIORegistry.getDefaultInstance();
  }
}
