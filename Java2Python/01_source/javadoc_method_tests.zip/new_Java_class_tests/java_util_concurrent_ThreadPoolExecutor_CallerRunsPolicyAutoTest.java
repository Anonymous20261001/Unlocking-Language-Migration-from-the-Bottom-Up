package generated.test;

import java.lang.Runnable;
import java.util.concurrent.ThreadPoolExecutor;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_ThreadPoolExecutor_CallerRunsPolicyAutoTest {
  @Test
  public void rejectedExecution_test_12743(Runnable p0, ThreadPoolExecutor p1) {
    ThreadPoolExecutor.CallerRunsPolicy instance = new ThreadPoolExecutor.CallerRunsPolicy();
    instance.rejectedExecution(p0, p1);
  }
}
