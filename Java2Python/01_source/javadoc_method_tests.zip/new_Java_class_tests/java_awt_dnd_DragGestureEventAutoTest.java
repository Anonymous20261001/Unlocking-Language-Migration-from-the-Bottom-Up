package generated.test;

import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSourceListener;
import java.lang.Object;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragGestureEventAutoTest {
  @Test
  public void getDragOrigin_test_4284(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragOrigin();
  }

  @Test
  public void getDragAction_test_4285(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragAction();
  }

  @Test
  public void getDragSource_test_4286(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragSource();
  }

  @Test
  public void getSourceAsDragGestureRecognizer_test_4287(DragGestureRecognizer c0, int c1, Point c2,
      List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getSourceAsDragGestureRecognizer();
  }

  @Test
  public void getTriggerEvent_test_4288(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getTriggerEvent();
  }

  @Test
  public void startDrag_test_4289(Cursor p0, Transferable p1, DragGestureRecognizer c0, int c1,
      Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.startDrag(p0, p1);
  }

  @Test
  public void startDrag_test_4290(Cursor p0, Transferable p1, DragSourceListener p2,
      DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.startDrag(p0, p1, p2);
  }

  @Test
  public void startDrag_test_4291(Cursor p0, Image p1, Point p2, Transferable p3,
      DragSourceListener p4, DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.startDrag(p0, p1, p2, p3, p4);
  }

  @Test
  public void toArray_test_4292(Object[] p0, DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4293(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.toArray();
  }

  @Test
  public void iterator_test_4294(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.iterator();
  }

  @Test
  public void getComponent_test_4295(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getComponent();
  }
}
