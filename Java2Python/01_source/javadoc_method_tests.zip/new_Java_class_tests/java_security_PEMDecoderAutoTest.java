package generated.test;

import java.security.PEMDecoder;
import org.junit.jupiter.api.Test;

public class java_security_PEMDecoderAutoTest {
  @Test
  public void of_test_9881() {
    PEMDecoder.of();
  }
}
