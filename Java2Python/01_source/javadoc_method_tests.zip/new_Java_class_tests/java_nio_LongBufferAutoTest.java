package generated.test;

import java.nio.LongBuffer;
import org.junit.jupiter.api.Test;

public class java_nio_LongBufferAutoTest {
  @Test
  public void wrap_test_8207(long[] p0) {
    LongBuffer.wrap(p0);
  }

  @Test
  public void wrap_test_8208(long[] p0, int p1, int p2) {
    LongBuffer.wrap(p0, p1, p2);
  }

  @Test
  public void allocate_test_8209(int p0) {
    LongBuffer.allocate(p0);
  }
}
