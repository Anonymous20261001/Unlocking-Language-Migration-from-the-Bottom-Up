package generated.test;

import javax.print.DocFlavor;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.AttributeSet;
import org.junit.jupiter.api.Test;

public class javax_print_PrintServiceLookupAutoTest {
  @Test
  public void lookupPrintServices_test_10037(DocFlavor p0, AttributeSet p1) {
    PrintServiceLookup.lookupPrintServices(p0, p1);
  }

  @Test
  public void lookupMultiDocPrintServices_test_10038(DocFlavor[] p0, AttributeSet p1) {
    PrintServiceLookup.lookupMultiDocPrintServices(p0, p1);
  }

  @Test
  public void lookupDefaultPrintService_test_10039() {
    PrintServiceLookup.lookupDefaultPrintService();
  }

  @Test
  public void registerService_test_10040(PrintService p0) {
    PrintServiceLookup.registerService(p0);
  }

  @Test
  public void registerServiceProvider_test_10041(PrintServiceLookup p0) {
    PrintServiceLookup.registerServiceProvider(p0);
  }
}
