package generated.test;

import java.lang.String;
import java.lang.constant.ClassDesc;
import java.lang.constant.ConstantDescs;
import org.junit.jupiter.api.Test;

public class java_lang_constant_ConstantDescsAutoTest {
  @Test
  public void ofConstantBootstrap_test_2932(ClassDesc p0, String p1, ClassDesc p2, ClassDesc[] p3) {
    ConstantDescs.ofConstantBootstrap(p0, p1, p2, p3);
  }

  @Test
  public void ofCallsiteBootstrap_test_2933(ClassDesc p0, String p1, ClassDesc p2, ClassDesc[] p3) {
    ConstantDescs.ofCallsiteBootstrap(p0, p1, p2, p3);
  }
}
