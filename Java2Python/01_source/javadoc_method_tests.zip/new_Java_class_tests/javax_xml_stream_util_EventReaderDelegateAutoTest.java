package generated.test;

import java.lang.String;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.util.EventReaderDelegate;
import org.junit.jupiter.api.Test;

public class javax_xml_stream_util_EventReaderDelegateAutoTest {
  @Test
  public void remove_test_4598() {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.remove();
  }

  @Test
  public void getProperty_test_4599(String p0) {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.getProperty(p0);
  }

  @Test
  public void hasNext_test_4600() {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.hasNext();
  }

  @Test
  public void next_test_4601() {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.next();
  }

  @Test
  public void getParent_test_4602() {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.getParent();
  }

  @Test
  public void setParent_test_4603(XMLEventReader p0) {
    EventReaderDelegate instance = new EventReaderDelegate();
    instance.setParent(p0);
  }
}
