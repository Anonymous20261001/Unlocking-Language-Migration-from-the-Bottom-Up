package generated.test;

import java.lang.String;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_util_Locale_LanguageRangeAutoTest {
  @Test
  public void getWeight_test_8071(String c0) {
    Locale.LanguageRange instance = new Locale.LanguageRange(c0);
    instance.getWeight();
  }

  @Test
  public void getRange_test_8072(String c0) {
    Locale.LanguageRange instance = new Locale.LanguageRange(c0);
    instance.getRange();
  }

  @Test
  public void mapEquivalents_test_8073(List p0, Map p1) {
    Locale.LanguageRange.mapEquivalents(p0, p1);
  }

  @Test
  public void parse_test_8074(String p0) {
    Locale.LanguageRange.parse(p0);
  }

  @Test
  public void parse_test_8075(String p0, Map p1) {
    Locale.LanguageRange.parse(p0, p1);
  }
}
