package generated.test;

import javax.smartcardio.TerminalFactory;
import org.junit.jupiter.api.Test;

public class javax_smartcardio_TerminalFactoryAutoTest {
  @Test
  public void getDefaultType_test_12541() {
    TerminalFactory.getDefaultType();
  }

  @Test
  public void getDefault_test_12542() {
    TerminalFactory.getDefault();
  }
}
