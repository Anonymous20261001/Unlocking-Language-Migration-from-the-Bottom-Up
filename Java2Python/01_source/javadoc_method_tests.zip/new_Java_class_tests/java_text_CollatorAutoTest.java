package generated.test;

import java.text.Collator;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_text_CollatorAutoTest {
  @Test
  public void getInstance_test_2349(Locale p0) {
    Collator.getInstance(p0);
  }

  @Test
  public void getInstance_test_2350() {
    Collator.getInstance();
  }

  @Test
  public void getAvailableLocales_test_2351() {
    Collator.getAvailableLocales();
  }
}
