package generated.test;

import java.text.CollationElementIterator;
import org.junit.jupiter.api.Test;

public class java_text_CollationElementIteratorAutoTest {
  @Test
  public void primaryOrder_test_2346(int p0) {
    CollationElementIterator.primaryOrder(p0);
  }

  @Test
  public void secondaryOrder_test_2347(int p0) {
    CollationElementIterator.secondaryOrder(p0);
  }

  @Test
  public void tertiaryOrder_test_2348(int p0) {
    CollationElementIterator.tertiaryOrder(p0);
  }
}
