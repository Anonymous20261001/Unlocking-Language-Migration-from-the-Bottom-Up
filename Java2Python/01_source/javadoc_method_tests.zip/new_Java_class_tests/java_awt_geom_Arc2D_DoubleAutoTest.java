package generated.test;

import java.awt.geom.Arc2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_Arc2D_DoubleAutoTest {
  @Test
  public void getAngleStart_test_188() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getAngleStart();
  }

  @Test
  public void getAngleExtent_test_189() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getAngleExtent();
  }

  @Test
  public void setArc_test_190(double p0, double p1, double p2, double p3, double p4, double p5,
      int p6) {
    Arc2D.Double instance = new Arc2D.Double();
    instance.setArc(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void setAngleStart_test_191(double p0) {
    Arc2D.Double instance = new Arc2D.Double();
    instance.setAngleStart(p0);
  }

  @Test
  public void setAngleExtent_test_192(double p0) {
    Arc2D.Double instance = new Arc2D.Double();
    instance.setAngleExtent(p0);
  }

  @Test
  public void getWidth_test_193() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_194() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getHeight();
  }

  @Test
  public void getX_test_195() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getX();
  }

  @Test
  public void getY_test_196() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.getY();
  }

  @Test
  public void isEmpty_test_197() {
    Arc2D.Double instance = new Arc2D.Double();
    instance.isEmpty();
  }
}
