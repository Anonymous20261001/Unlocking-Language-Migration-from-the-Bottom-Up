package generated.test;

import java.lang.Object;
import java.util.Optional;
import org.junit.jupiter.api.Test;

public class java_util_OptionalAutoTest {
  @Test
  public void of_test_9689(Object p0) {
    Optional.of(p0);
  }

  @Test
  public void empty_test_9690() {
    Optional.empty();
  }

  @Test
  public void ofNullable_test_9691(Object p0) {
    Optional.ofNullable(p0);
  }
}
