package generated.test;

import java.lang.String;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_util_Locale_BuilderAutoTest {
  @Test
  public void clear_test_8058() {
    Locale.Builder instance = new Locale.Builder();
    instance.clear();
  }

  @Test
  public void build_test_8059() {
    Locale.Builder instance = new Locale.Builder();
    instance.build();
  }

  @Test
  public void setLocale_test_8060(Locale p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setLocale(p0);
  }

  @Test
  public void setLanguageTag_test_8061(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setLanguageTag(p0);
  }

  @Test
  public void setLanguage_test_8062(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setLanguage(p0);
  }

  @Test
  public void setScript_test_8063(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setScript(p0);
  }

  @Test
  public void setRegion_test_8064(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setRegion(p0);
  }

  @Test
  public void setVariant_test_8065(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.setVariant(p0);
  }

  @Test
  public void setExtension_test_8066(char p0, String p1) {
    Locale.Builder instance = new Locale.Builder();
    instance.setExtension(p0, p1);
  }

  @Test
  public void setUnicodeLocaleKeyword_test_8067(String p0, String p1) {
    Locale.Builder instance = new Locale.Builder();
    instance.setUnicodeLocaleKeyword(p0, p1);
  }

  @Test
  public void addUnicodeLocaleAttribute_test_8068(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.addUnicodeLocaleAttribute(p0);
  }

  @Test
  public void removeUnicodeLocaleAttribute_test_8069(String p0) {
    Locale.Builder instance = new Locale.Builder();
    instance.removeUnicodeLocaleAttribute(p0);
  }

  @Test
  public void clearExtensions_test_8070() {
    Locale.Builder instance = new Locale.Builder();
    instance.clearExtensions();
  }
}
