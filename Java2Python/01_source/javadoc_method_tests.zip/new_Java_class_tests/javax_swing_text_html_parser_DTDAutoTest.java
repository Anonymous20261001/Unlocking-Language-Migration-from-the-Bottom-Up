package generated.test;

import java.lang.String;
import javax.swing.text.html.parser.DTD;
import org.junit.jupiter.api.Test;

public class javax_swing_text_html_parser_DTDAutoTest {
  @Test
  public void putDTDHash_test_4403(String p0, DTD p1) {
    DTD.putDTDHash(p0, p1);
  }
}
