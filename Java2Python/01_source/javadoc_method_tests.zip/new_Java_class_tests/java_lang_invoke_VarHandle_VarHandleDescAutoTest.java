package generated.test;

import java.lang.String;
import java.lang.constant.ClassDesc;
import java.lang.invoke.VarHandle;
import org.junit.jupiter.api.Test;

public class java_lang_invoke_VarHandle_VarHandleDescAutoTest {
  @Test
  public void ofField_test_13314(ClassDesc p0, String p1, ClassDesc p2) {
    VarHandle.VarHandleDesc.ofField(p0, p1, p2);
  }

  @Test
  public void ofStaticField_test_13315(ClassDesc p0, String p1, ClassDesc p2) {
    VarHandle.VarHandleDesc.ofStaticField(p0, p1, p2);
  }

  @Test
  public void ofArray_test_13316(ClassDesc p0) {
    VarHandle.VarHandleDesc.ofArray(p0);
  }
}
