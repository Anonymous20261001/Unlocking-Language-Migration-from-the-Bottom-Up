package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.FloatVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_FloatVectorAutoTest {
  @Test
  public void fromMemorySegment_test_4886(VectorSpecies p0, MemorySegment p1, long p2, ByteOrder p3,
      VectorMask p4) {
    FloatVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromMemorySegment_test_4887(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    FloatVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_4888(VectorSpecies p0, float[] p1, int p2, int[] p3, int p4) {
    FloatVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_4889(VectorSpecies p0, float[] p1, int p2, VectorMask p3) {
    FloatVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_4890(VectorSpecies p0, float[] p1, int p2) {
    FloatVector.fromArray(p0, p1, p2);
  }

  @Test
  public void fromArray_test_4891(VectorSpecies p0, float[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    FloatVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void zero_test_4892(VectorSpecies p0) {
    FloatVector.zero(p0);
  }

  @Test
  public void broadcast_test_4893(VectorSpecies p0, float p1) {
    FloatVector.broadcast(p0, p1);
  }

  @Test
  public void broadcast_test_4894(VectorSpecies p0, long p1) {
    FloatVector.broadcast(p0, p1);
  }
}
