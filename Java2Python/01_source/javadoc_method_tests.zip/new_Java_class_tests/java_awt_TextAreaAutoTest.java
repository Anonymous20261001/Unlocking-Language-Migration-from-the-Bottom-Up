package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
  @Test
  public void insertText_test_12544(String p0, int p1) {
    TextArea instance = new TextArea();
    instance.insertText(p0, p1);
  }

  @Test
  public void getScrollbarVisibility_test_12545() {
    TextArea instance = new TextArea();
    instance.getScrollbarVisibility();
  }

  @Test
  public void setRows_test_12546(int p0) {
    TextArea instance = new TextArea();
    instance.setRows(p0);
  }

  @Test
  public void getColumns_test_12547() {
    TextArea instance = new TextArea();
    instance.getColumns();
  }

  @Test
  public void setColumns_test_12548(int p0) {
    TextArea instance = new TextArea();
    instance.setColumns(p0);
  }

  @Test
  public void getRows_test_12549() {
    TextArea instance = new TextArea();
    instance.getRows();
  }

  @Test
  public void getPreferredSize_test_12550(int p0, int p1) {
    TextArea instance = new TextArea();
    instance.getPreferredSize(p0, p1);
  }

  @Test
  public void getPreferredSize_test_12551() {
    TextArea instance = new TextArea();
    instance.getPreferredSize();
  }

  @Test
  public void getMinimumSize_test_12552(int p0, int p1) {
    TextArea instance = new TextArea();
    instance.getMinimumSize(p0, p1);
  }

  @Test
  public void getMinimumSize_test_12553() {
    TextArea instance = new TextArea();
    instance.getMinimumSize();
  }

  @Test
  public void addNotify_test_12554() {
    TextArea instance = new TextArea();
    instance.addNotify();
  }

  @Test
  public void preferredSize_test_12555(int p0, int p1) {
    TextArea instance = new TextArea();
    instance.preferredSize(p0, p1);
  }

  @Test
  public void preferredSize_test_12556() {
    TextArea instance = new TextArea();
    instance.preferredSize();
  }

  @Test
  public void minimumSize_test_12557(int p0, int p1) {
    TextArea instance = new TextArea();
    instance.minimumSize(p0, p1);
  }

  @Test
  public void minimumSize_test_12558() {
    TextArea instance = new TextArea();
    instance.minimumSize();
  }

  @Test
  public void getAccessibleContext_test_12559() {
    TextArea instance = new TextArea();
    instance.getAccessibleContext();
  }

  @Test
  public void replaceText_test_12560(String p0, int p1, int p2) {
    TextArea instance = new TextArea();
    instance.replaceText(p0, p1, p2);
  }

  @Test
  public void replaceRange_test_12561(String p0, int p1, int p2) {
    TextArea instance = new TextArea();
    instance.replaceRange(p0, p1, p2);
  }

  @Test
  public void append_test_12562(String p0) {
    TextArea instance = new TextArea();
    instance.append(p0);
  }

  @Test
  public void insert_test_12563(String p0, int p1) {
    TextArea instance = new TextArea();
    instance.insert(p0, p1);
  }

  @Test
  public void appendText_test_12564(String p0) {
    TextArea instance = new TextArea();
    instance.appendText(p0);
  }
}
