package generated.test;

import java.net.URI;
import java.net.http.HttpRequest;
import java.util.function.BiPredicate;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpRequestAutoTest {
  @Test
  public void newBuilder_test_5438(HttpRequest p0, BiPredicate p1) {
    HttpRequest.newBuilder(p0, p1);
  }

  @Test
  public void newBuilder_test_5439(URI p0) {
    HttpRequest.newBuilder(p0);
  }

  @Test
  public void newBuilder_test_5440() {
    HttpRequest.newBuilder();
  }
}
