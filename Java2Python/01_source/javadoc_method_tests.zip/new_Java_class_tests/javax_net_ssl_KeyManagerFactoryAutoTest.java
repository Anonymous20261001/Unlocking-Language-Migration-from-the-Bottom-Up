package generated.test;

import javax.net.ssl.KeyManagerFactory;
import org.junit.jupiter.api.Test;

public class javax_net_ssl_KeyManagerFactoryAutoTest {
  @Test
  public void getDefaultAlgorithm_test_7628() {
    KeyManagerFactory.getDefaultAlgorithm();
  }
}
