package generated.test;

import java.lang.ClassLoader;
import java.lang.String;
import javax.xml.validation.SchemaFactory;
import org.junit.jupiter.api.Test;

public class javax_xml_validation_SchemaFactoryAutoTest {
  @Test
  public void newDefaultInstance_test_10856() {
    SchemaFactory.newDefaultInstance();
  }

  @Test
  public void newInstance_test_10857(String p0, String p1, ClassLoader p2) {
    SchemaFactory.newInstance(p0, p1, p2);
  }

  @Test
  public void newInstance_test_10858(String p0) {
    SchemaFactory.newInstance(p0);
  }
}
