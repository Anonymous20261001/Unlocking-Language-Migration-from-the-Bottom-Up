package generated.test;

import java.net.ResponseCache;
import org.junit.jupiter.api.Test;

public class java_net_ResponseCacheAutoTest {
  @Test
  public void getDefault_test_10628() {
    ResponseCache.getDefault();
  }

  @Test
  public void setDefault_test_10629(ResponseCache p0) {
    ResponseCache.setDefault(p0);
  }
}
