package generated.test;

import javax.swing.JPopupMenu;
import org.junit.jupiter.api.Test;

public class javax_swing_JPopupMenu_SeparatorAutoTest {
  @Test
  public void getUIClassID_test_6809() {
    JPopupMenu.Separator instance = new JPopupMenu.Separator();
    instance.getUIClassID();
  }
}
