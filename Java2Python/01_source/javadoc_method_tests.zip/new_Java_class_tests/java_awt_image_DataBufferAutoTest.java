package generated.test;

import java.awt.image.DataBuffer;
import org.junit.jupiter.api.Test;

public class java_awt_image_DataBufferAutoTest {
  @Test
  public void getDataTypeSize_test_3173(int p0) {
    DataBuffer.getDataTypeSize(p0);
  }
}
