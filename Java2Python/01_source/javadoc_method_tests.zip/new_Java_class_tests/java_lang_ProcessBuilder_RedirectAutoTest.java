package generated.test;

import java.io.File;
import java.lang.ProcessBuilder;
import org.junit.jupiter.api.Test;

public class java_lang_ProcessBuilder_RedirectAutoTest {
  @Test
  public void appendTo_test_10105(File p0) {
    ProcessBuilder.Redirect.appendTo(p0);
  }

  @Test
  public void from_test_10106(File p0) {
    ProcessBuilder.Redirect.from(p0);
  }

  @Test
  public void to_test_10107(File p0) {
    ProcessBuilder.Redirect.to(p0);
  }
}
