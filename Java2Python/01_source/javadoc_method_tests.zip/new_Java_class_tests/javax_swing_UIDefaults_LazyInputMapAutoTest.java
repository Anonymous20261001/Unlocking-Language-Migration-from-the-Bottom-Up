package generated.test;

import java.lang.Object;
import javax.swing.UIDefaults;
import org.junit.jupiter.api.Test;

public class javax_swing_UIDefaults_LazyInputMapAutoTest {
  @Test
  public void createValue_test_13142(UIDefaults p0, Object[] c0) {
    UIDefaults.LazyInputMap instance = new UIDefaults.LazyInputMap(c0);
    instance.createValue(p0);
  }
}
