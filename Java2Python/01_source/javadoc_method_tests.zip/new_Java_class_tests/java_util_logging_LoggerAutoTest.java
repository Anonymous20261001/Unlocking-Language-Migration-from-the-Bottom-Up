package generated.test;

import java.lang.String;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;

public class java_util_logging_LoggerAutoTest {
  @Test
  public void getLogger_test_8104(String p0) {
    Logger.getLogger(p0);
  }

  @Test
  public void getLogger_test_8105(String p0, String p1) {
    Logger.getLogger(p0, p1);
  }

  @Test
  public void getAnonymousLogger_test_8106() {
    Logger.getAnonymousLogger();
  }

  @Test
  public void getAnonymousLogger_test_8107(String p0) {
    Logger.getAnonymousLogger(p0);
  }

  @Test
  public void getGlobal_test_8108() {
    Logger.getGlobal();
  }
}
