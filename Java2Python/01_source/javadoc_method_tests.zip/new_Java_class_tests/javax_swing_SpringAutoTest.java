package generated.test;

import java.awt.Component;
import javax.swing.Spring;
import org.junit.jupiter.api.Test;

public class javax_swing_SpringAutoTest {
  @Test
  public void height_test_11360(Component p0) {
    Spring.height(p0);
  }

  @Test
  public void max_test_11361(Spring p0, Spring p1) {
    Spring.max(p0, p1);
  }

  @Test
  public void scale_test_11362(Spring p0, float p1) {
    Spring.scale(p0, p1);
  }

  @Test
  public void constant_test_11363(int p0) {
    Spring.constant(p0);
  }

  @Test
  public void constant_test_11364(int p0, int p1, int p2) {
    Spring.constant(p0, p1, p2);
  }

  @Test
  public void sum_test_11365(Spring p0, Spring p1) {
    Spring.sum(p0, p1);
  }

  @Test
  public void width_test_11366(Component p0) {
    Spring.width(p0);
  }

  @Test
  public void minus_test_11367(Spring p0) {
    Spring.minus(p0);
  }
}
