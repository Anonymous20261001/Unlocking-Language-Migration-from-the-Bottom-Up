package generated.test;

import java.lang.String;
import java.lang.constant.ClassDesc;
import java.lang.constant.ConstantDesc;
import java.lang.constant.DirectMethodHandleDesc;
import java.lang.constant.DynamicConstantDesc;
import org.junit.jupiter.api.Test;

public class java_lang_constant_DynamicConstantDescAutoTest {
  @Test
  public void of_test_4420(DirectMethodHandleDesc p0, ConstantDesc[] p1) {
    DynamicConstantDesc.of(p0, p1);
  }

  @Test
  public void of_test_4421(DirectMethodHandleDesc p0) {
    DynamicConstantDesc.of(p0);
  }

  @Test
  public void ofNamed_test_4422(DirectMethodHandleDesc p0, String p1, ClassDesc p2,
      ConstantDesc[] p3) {
    DynamicConstantDesc.ofNamed(p0, p1, p2, p3);
  }

  @Test
  public void ofCanonical_test_4423(DirectMethodHandleDesc p0, String p1, ClassDesc p2,
      ConstantDesc[] p3) {
    DynamicConstantDesc.ofCanonical(p0, p1, p2, p3);
  }
}
