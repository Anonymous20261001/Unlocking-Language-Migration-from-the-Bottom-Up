package generated.test;

import java.awt.Menu;
import java.awt.MenuComponent;
import java.awt.MenuItem;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuAutoTest {
  @Test
  public void insertSeparator_test_8525(int p0) {
    Menu instance = new Menu();
    instance.insertSeparator(p0);
  }

  @Test
  public void isTearOff_test_8526() {
    Menu instance = new Menu();
    instance.isTearOff();
  }

  @Test
  public void addNotify_test_8527() {
    Menu instance = new Menu();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_8528() {
    Menu instance = new Menu();
    instance.removeNotify();
  }

  @Test
  public void getAccessibleContext_test_8529() {
    Menu instance = new Menu();
    instance.getAccessibleContext();
  }

  @Test
  public void getItem_test_8530(int p0) {
    Menu instance = new Menu();
    instance.getItem(p0);
  }

  @Test
  public void countItems_test_8531() {
    Menu instance = new Menu();
    instance.countItems();
  }

  @Test
  public void getItemCount_test_8532() {
    Menu instance = new Menu();
    instance.getItemCount();
  }

  @Test
  public void addSeparator_test_8533() {
    Menu instance = new Menu();
    instance.addSeparator();
  }

  @Test
  public void remove_test_8534(int p0) {
    Menu instance = new Menu();
    instance.remove(p0);
  }

  @Test
  public void remove_test_8535(MenuComponent p0) {
    Menu instance = new Menu();
    instance.remove(p0);
  }

  @Test
  public void insert_test_8536(String p0, int p1) {
    Menu instance = new Menu();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_8537(MenuItem p0, int p1) {
    Menu instance = new Menu();
    instance.insert(p0, p1);
  }

  @Test
  public void add_test_8538(MenuItem p0) {
    Menu instance = new Menu();
    instance.add(p0);
  }

  @Test
  public void add_test_8539(String p0) {
    Menu instance = new Menu();
    instance.add(p0);
  }

  @Test
  public void paramString_test_8540() {
    Menu instance = new Menu();
    instance.paramString();
  }

  @Test
  public void removeAll_test_8541() {
    Menu instance = new Menu();
    instance.removeAll();
  }
}
