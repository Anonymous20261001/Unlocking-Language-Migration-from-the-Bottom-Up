package generated.test;

import java.lang.String;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanInfo;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanOperationInfo;
import org.junit.jupiter.api.Test;

public class javax_management_MBeanInfoAutoTest {
  @Test
  public void getDescription_test_8416(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getDescription();
  }

  @Test
  public void getOperations_test_8417(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getOperations();
  }

  @Test
  public void getNotifications_test_8418(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getNotifications();
  }

  @Test
  public void getDescriptor_test_8419(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getDescriptor();
  }

  @Test
  public void getConstructors_test_8420(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getConstructors();
  }

  @Test
  public void getClassName_test_8421(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getClassName();
  }

  @Test
  public void getAttributes_test_8422(String c0, String c1, MBeanAttributeInfo[] c2,
      MBeanConstructorInfo[] c3, MBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    MBeanInfo instance = new MBeanInfo(c0, c1, c2, c3, c4, c5);
    instance.getAttributes();
  }
}
