package generated.test;

import java.util.Locale;
import jdk.javadoc.doclet.DocletEnvironment;
import jdk.javadoc.doclet.Reporter;
import jdk.javadoc.doclet.StandardDoclet;
import org.junit.jupiter.api.Test;

public class jdk_javadoc_doclet_StandardDocletAutoTest {
  @Test
  public void getName_test_11482() {
    StandardDoclet instance = new StandardDoclet();
    instance.getName();
  }

  @Test
  public void run_test_11483(DocletEnvironment p0) {
    StandardDoclet instance = new StandardDoclet();
    instance.run(p0);
  }

  @Test
  public void init_test_11484(Locale p0, Reporter p1) {
    StandardDoclet instance = new StandardDoclet();
    instance.init(p0, p1);
  }

  @Test
  public void getLocale_test_11485() {
    StandardDoclet instance = new StandardDoclet();
    instance.getLocale();
  }

  @Test
  public void getReporter_test_11486() {
    StandardDoclet instance = new StandardDoclet();
    instance.getReporter();
  }

  @Test
  public void getSupportedOptions_test_11487() {
    StandardDoclet instance = new StandardDoclet();
    instance.getSupportedOptions();
  }

  @Test
  public void getSupportedSourceVersion_test_11488() {
    StandardDoclet instance = new StandardDoclet();
    instance.getSupportedSourceVersion();
  }
}
