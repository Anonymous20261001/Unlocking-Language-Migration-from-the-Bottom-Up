package generated.test;

import java.awt.geom.CubicCurve2D;
import org.junit.jupiter.api.Test;

public class java_awt_geom_CubicCurve2D_FloatAutoTest {
  @Test
  public void setCurve_test_3147(float p0, float p1, float p2, float p3, float p4, float p5,
      float p6, float p7) {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.setCurve(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setCurve_test_3148(double p0, double p1, double p2, double p3, double p4, double p5,
      double p6, double p7) {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.setCurve(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void getCtrlX1_test_3149() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlX1();
  }

  @Test
  public void getCtrlY1_test_3150() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlY1();
  }

  @Test
  public void getCtrlX2_test_3151() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlX2();
  }

  @Test
  public void getCtrlY2_test_3152() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlY2();
  }

  @Test
  public void getCtrlP1_test_3153() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlP1();
  }

  @Test
  public void getCtrlP2_test_3154() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getCtrlP2();
  }

  @Test
  public void getX1_test_3155() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getX1();
  }

  @Test
  public void getY1_test_3156() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getY1();
  }

  @Test
  public void getX2_test_3157() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getX2();
  }

  @Test
  public void getY2_test_3158() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getY2();
  }

  @Test
  public void getP1_test_3159() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getP1();
  }

  @Test
  public void getP2_test_3160() {
    CubicCurve2D.Float instance = new CubicCurve2D.Float();
    instance.getP2();
  }
}
