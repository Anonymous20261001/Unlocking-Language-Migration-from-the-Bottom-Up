package generated.test;

import java.lang.CharSequence;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.junit.jupiter.api.Test;

public class java_time_LocalTimeAutoTest {
  @Test
  public void of_test_8080(int p0, int p1, int p2, int p3) {
    LocalTime.of(p0, p1, p2, p3);
  }

  @Test
  public void of_test_8081(int p0, int p1) {
    LocalTime.of(p0, p1);
  }

  @Test
  public void of_test_8082(int p0, int p1, int p2) {
    LocalTime.of(p0, p1, p2);
  }

  @Test
  public void from_test_8083(TemporalAccessor p0) {
    LocalTime.from(p0);
  }

  @Test
  public void parse_test_8084(CharSequence p0) {
    LocalTime.parse(p0);
  }

  @Test
  public void parse_test_8085(CharSequence p0, DateTimeFormatter p1) {
    LocalTime.parse(p0, p1);
  }

  @Test
  public void now_test_8086() {
    LocalTime.now();
  }

  @Test
  public void now_test_8087(Clock p0) {
    LocalTime.now(p0);
  }

  @Test
  public void now_test_8088(ZoneId p0) {
    LocalTime.now(p0);
  }

  @Test
  public void ofInstant_test_8089(Instant p0, ZoneId p1) {
    LocalTime.ofInstant(p0, p1);
  }

  @Test
  public void ofNanoOfDay_test_8090(long p0) {
    LocalTime.ofNanoOfDay(p0);
  }

  @Test
  public void ofSecondOfDay_test_8091(long p0) {
    LocalTime.ofSecondOfDay(p0);
  }
}
