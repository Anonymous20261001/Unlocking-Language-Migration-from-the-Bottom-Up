package generated.test;

import java.lang.Object;
import java.lang.String;
import java.security.Provider;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class java_security_Provider_ServiceAutoTest {
  @Test
  public void supportsParameter_test_10207(Object p0, Provider c0, String c1, String c2, String c3,
      List c4, Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.supportsParameter(p0);
  }

  @Test
  public void getType_test_10208(Provider c0, String c1, String c2, String c3, List c4, Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.getType();
  }

  @Test
  public void getClassName_test_10209(Provider c0, String c1, String c2, String c3, List c4,
      Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.getClassName();
  }

  @Test
  public void getAttribute_test_10210(String p0, Provider c0, String c1, String c2, String c3,
      List c4, Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.getAttribute(p0);
  }

  @Test
  public void getProvider_test_10211(Provider c0, String c1, String c2, String c3, List c4,
      Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.getProvider();
  }

  @Test
  public void getAlgorithm_test_10212(Provider c0, String c1, String c2, String c3, List c4,
      Map c5) {
    Provider.Service instance = new Provider.Service(c0, c1, c2, c3, c4, c5);
    instance.getAlgorithm();
  }
}
