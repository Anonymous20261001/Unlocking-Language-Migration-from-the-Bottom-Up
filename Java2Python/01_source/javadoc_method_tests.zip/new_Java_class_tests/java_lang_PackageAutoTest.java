package generated.test;

import java.lang.Package;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_lang_PackageAutoTest {
  @Test
  public void getPackage_test_9713(String p0) {
    Package.getPackage(p0);
  }

  @Test
  public void getPackages_test_9714() {
    Package.getPackages();
  }
}
