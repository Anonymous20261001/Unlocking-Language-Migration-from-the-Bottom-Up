package generated.test;

import jdk.dynalink.DynamicLinker;
import org.junit.jupiter.api.Test;

public class jdk_dynalink_DynamicLinkerAutoTest {
  @Test
  public void getLinkedCallSiteLocation_test_4424() {
    DynamicLinker.getLinkedCallSiteLocation();
  }
}
