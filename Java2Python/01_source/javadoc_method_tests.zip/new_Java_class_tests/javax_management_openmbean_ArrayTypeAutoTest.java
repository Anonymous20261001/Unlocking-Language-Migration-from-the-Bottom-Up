package generated.test;

import java.lang.Class;
import javax.management.openmbean.ArrayType;
import org.junit.jupiter.api.Test;

public class javax_management_openmbean_ArrayTypeAutoTest {
  @Test
  public void getPrimitiveArrayType_test_520(Class p0) {
    ArrayType.getPrimitiveArrayType(p0);
  }
}
