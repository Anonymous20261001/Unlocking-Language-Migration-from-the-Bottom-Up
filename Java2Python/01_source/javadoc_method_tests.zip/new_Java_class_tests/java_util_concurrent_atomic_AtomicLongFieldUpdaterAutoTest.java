package generated.test;

import java.lang.Class;
import java.lang.String;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import org.junit.jupiter.api.Test;

public class java_util_concurrent_atomic_AtomicLongFieldUpdaterAutoTest {
  @Test
  public void newUpdater_test_691(Class p0, String p1) {
    AtomicLongFieldUpdater.newUpdater(p0, p1);
  }
}
