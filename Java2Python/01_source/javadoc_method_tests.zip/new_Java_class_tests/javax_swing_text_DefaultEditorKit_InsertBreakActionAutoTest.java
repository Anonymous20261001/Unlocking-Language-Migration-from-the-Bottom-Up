package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_InsertBreakActionAutoTest {
  @Test
  public void actionPerformed_test_3673(ActionEvent p0) {
    DefaultEditorKit.InsertBreakAction instance = new DefaultEditorKit.InsertBreakAction();
    instance.actionPerformed(p0);
  }
}
