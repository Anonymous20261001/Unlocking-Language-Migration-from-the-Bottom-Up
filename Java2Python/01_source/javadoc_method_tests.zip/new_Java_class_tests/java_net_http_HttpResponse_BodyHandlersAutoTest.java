package generated.test;

import java.lang.Object;
import java.lang.String;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.concurrent.Flow;
import java.util.function.Consumer;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpResponse_BodyHandlersAutoTest {
  @Test
  public void ofString_test_5451(Charset p0) {
    HttpResponse.BodyHandlers.ofString(p0);
  }

  @Test
  public void ofString_test_5452() {
    HttpResponse.BodyHandlers.ofString();
  }

  @Test
  public void ofInputStream_test_5453() {
    HttpResponse.BodyHandlers.ofInputStream();
  }

  @Test
  public void ofByteArray_test_5454() {
    HttpResponse.BodyHandlers.ofByteArray();
  }

  @Test
  public void ofFile_test_5455(Path p0, OpenOption[] p1) {
    HttpResponse.BodyHandlers.ofFile(p0, p1);
  }

  @Test
  public void ofFile_test_5456(Path p0) {
    HttpResponse.BodyHandlers.ofFile(p0);
  }

  @Test
  public void limiting_test_5457(HttpResponse.BodyHandler p0, long p1) {
    HttpResponse.BodyHandlers.limiting(p0, p1);
  }

  @Test
  public void buffering_test_5458(HttpResponse.BodyHandler p0, int p1) {
    HttpResponse.BodyHandlers.buffering(p0, p1);
  }

  @Test
  public void ofPublisher_test_5459() {
    HttpResponse.BodyHandlers.ofPublisher();
  }

  @Test
  public void ofLines_test_5460() {
    HttpResponse.BodyHandlers.ofLines();
  }

  @Test
  public void replacing_test_5461(Object p0) {
    HttpResponse.BodyHandlers.replacing(p0);
  }

  @Test
  public void discarding_test_5462() {
    HttpResponse.BodyHandlers.discarding();
  }

  @Test
  public void fromLineSubscriber_test_5463(Flow.Subscriber p0) {
    HttpResponse.BodyHandlers.fromLineSubscriber(p0);
  }

  @Test
  public void fromLineSubscriber_test_5464(Flow.Subscriber p0, Function p1, String p2) {
    HttpResponse.BodyHandlers.fromLineSubscriber(p0, p1, p2);
  }

  @Test
  public void fromSubscriber_test_5465(Flow.Subscriber p0) {
    HttpResponse.BodyHandlers.fromSubscriber(p0);
  }

  @Test
  public void fromSubscriber_test_5466(Flow.Subscriber p0, Function p1) {
    HttpResponse.BodyHandlers.fromSubscriber(p0, p1);
  }

  @Test
  public void ofFileDownload_test_5467(Path p0, OpenOption[] p1) {
    HttpResponse.BodyHandlers.ofFileDownload(p0, p1);
  }

  @Test
  public void ofByteArrayConsumer_test_5468(Consumer p0) {
    HttpResponse.BodyHandlers.ofByteArrayConsumer(p0);
  }
}
