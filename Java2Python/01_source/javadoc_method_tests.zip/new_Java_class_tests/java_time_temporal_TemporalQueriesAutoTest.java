package generated.test;

import java.time.temporal.TemporalQueries;
import org.junit.jupiter.api.Test;

public class java_time_temporal_TemporalQueriesAutoTest {
  @Test
  public void offset_test_12534() {
    TemporalQueries.offset();
  }

  @Test
  public void zone_test_12535() {
    TemporalQueries.zone();
  }

  @Test
  public void precision_test_12536() {
    TemporalQueries.precision();
  }

  @Test
  public void chronology_test_12537() {
    TemporalQueries.chronology();
  }

  @Test
  public void zoneId_test_12538() {
    TemporalQueries.zoneId();
  }

  @Test
  public void localDate_test_12539() {
    TemporalQueries.localDate();
  }

  @Test
  public void localTime_test_12540() {
    TemporalQueries.localTime();
  }
}
