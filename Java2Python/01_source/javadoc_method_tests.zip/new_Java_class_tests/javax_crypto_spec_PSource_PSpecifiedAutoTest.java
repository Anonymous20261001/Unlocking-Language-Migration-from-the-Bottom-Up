package generated.test;

import javax.crypto.spec.PSource;
import org.junit.jupiter.api.Test;

public class javax_crypto_spec_PSource_PSpecifiedAutoTest {
  @Test
  public void getValue_test_10222(byte[] c0) {
    PSource.PSpecified instance = new PSource.PSpecified(c0);
    instance.getValue();
  }
}
