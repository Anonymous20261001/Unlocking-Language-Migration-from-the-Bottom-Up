package generated.test;

import javax.swing.undo.CompoundEdit;
import javax.swing.undo.UndoableEdit;
import org.junit.jupiter.api.Test;

public class javax_swing_undo_CompoundEditAutoTest {
  @Test
  public void addEdit_test_2699(UndoableEdit p0) {
    CompoundEdit instance = new CompoundEdit();
    instance.addEdit(p0);
  }

  @Test
  public void redo_test_2700() {
    CompoundEdit instance = new CompoundEdit();
    instance.redo();
  }

  @Test
  public void undo_test_2701() {
    CompoundEdit instance = new CompoundEdit();
    instance.undo();
  }

  @Test
  public void getPresentationName_test_2702() {
    CompoundEdit instance = new CompoundEdit();
    instance.getPresentationName();
  }

  @Test
  public void isSignificant_test_2703() {
    CompoundEdit instance = new CompoundEdit();
    instance.isSignificant();
  }

  @Test
  public void getUndoPresentationName_test_2704() {
    CompoundEdit instance = new CompoundEdit();
    instance.getUndoPresentationName();
  }

  @Test
  public void getRedoPresentationName_test_2705() {
    CompoundEdit instance = new CompoundEdit();
    instance.getRedoPresentationName();
  }

  @Test
  public void die_test_2706() {
    CompoundEdit instance = new CompoundEdit();
    instance.die();
  }

  @Test
  public void isInProgress_test_2707() {
    CompoundEdit instance = new CompoundEdit();
    instance.isInProgress();
  }

  @Test
  public void canUndo_test_2708() {
    CompoundEdit instance = new CompoundEdit();
    instance.canUndo();
  }

  @Test
  public void canRedo_test_2709() {
    CompoundEdit instance = new CompoundEdit();
    instance.canRedo();
  }

  @Test
  public void end_test_2710() {
    CompoundEdit instance = new CompoundEdit();
    instance.end();
  }
}
