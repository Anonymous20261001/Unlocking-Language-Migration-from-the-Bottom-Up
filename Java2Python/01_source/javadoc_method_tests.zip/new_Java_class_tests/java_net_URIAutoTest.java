package generated.test;

import java.lang.String;
import java.net.URI;
import org.junit.jupiter.api.Test;

public class java_net_URIAutoTest {
  @Test
  public void create_test_13237(String p0) {
    URI.create(p0);
  }
}
