package generated.test;

import java.text.DateFormat;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class java_text_DateFormatAutoTest {
  @Test
  public void getInstance_test_3317() {
    DateFormat.getInstance();
  }

  @Test
  public void getDateTimeInstance_test_3318(int p0, int p1, Locale p2) {
    DateFormat.getDateTimeInstance(p0, p1, p2);
  }

  @Test
  public void getDateTimeInstance_test_3319(int p0, int p1) {
    DateFormat.getDateTimeInstance(p0, p1);
  }

  @Test
  public void getDateTimeInstance_test_3320() {
    DateFormat.getDateTimeInstance();
  }

  @Test
  public void getAvailableLocales_test_3321() {
    DateFormat.getAvailableLocales();
  }

  @Test
  public void getDateInstance_test_3322(int p0) {
    DateFormat.getDateInstance(p0);
  }

  @Test
  public void getDateInstance_test_3323(int p0, Locale p1) {
    DateFormat.getDateInstance(p0, p1);
  }

  @Test
  public void getDateInstance_test_3324() {
    DateFormat.getDateInstance();
  }

  @Test
  public void getTimeInstance_test_3325(int p0) {
    DateFormat.getTimeInstance(p0);
  }

  @Test
  public void getTimeInstance_test_3326() {
    DateFormat.getTimeInstance();
  }

  @Test
  public void getTimeInstance_test_3327(int p0, Locale p1) {
    DateFormat.getTimeInstance(p0, p1);
  }
}
