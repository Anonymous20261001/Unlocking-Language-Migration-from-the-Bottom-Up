package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.ShortVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_ShortVectorAutoTest {
  @Test
  public void fromMemorySegment_test_11108(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    ShortVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromMemorySegment_test_11109(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3, VectorMask p4) {
    ShortVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_11110(VectorSpecies p0, short[] p1, int p2, int[] p3, int p4) {
    ShortVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_11111(VectorSpecies p0, short[] p1, int p2, VectorMask p3) {
    ShortVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_11112(VectorSpecies p0, short[] p1, int p2) {
    ShortVector.fromArray(p0, p1, p2);
  }

  @Test
  public void fromArray_test_11113(VectorSpecies p0, short[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    ShortVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromCharArray_test_11114(VectorSpecies p0, char[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    ShortVector.fromCharArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void fromCharArray_test_11115(VectorSpecies p0, char[] p1, int p2) {
    ShortVector.fromCharArray(p0, p1, p2);
  }

  @Test
  public void fromCharArray_test_11116(VectorSpecies p0, char[] p1, int p2, VectorMask p3) {
    ShortVector.fromCharArray(p0, p1, p2, p3);
  }

  @Test
  public void fromCharArray_test_11117(VectorSpecies p0, char[] p1, int p2, int[] p3, int p4) {
    ShortVector.fromCharArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void zero_test_11118(VectorSpecies p0) {
    ShortVector.zero(p0);
  }

  @Test
  public void broadcast_test_11119(VectorSpecies p0, long p1) {
    ShortVector.broadcast(p0, p1);
  }

  @Test
  public void broadcast_test_11120(VectorSpecies p0, short p1) {
    ShortVector.broadcast(p0, p1);
  }
}
