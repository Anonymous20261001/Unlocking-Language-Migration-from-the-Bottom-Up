package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.imageio.metadata.IIOMetadataNode;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;
import org.w3c.dom.UserDataHandler;

public class javax_imageio_metadata_IIOMetadataNodeAutoTest {
  @Test
  public void getTagName_test_5556() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getTagName();
  }

  @Test
  public void getAttributeNode_test_5557(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getAttributeNode(p0);
  }

  @Test
  public void setAttributeNode_test_5558(Attr p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setAttributeNode(p0);
  }

  @Test
  public void removeAttributeNode_test_5559(Attr p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.removeAttributeNode(p0);
  }

  @Test
  public void setAttributeNS_test_5560(String p0, String p1, String p2) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setAttributeNS(p0, p1, p2);
  }

  @Test
  public void removeAttributeNS_test_5561(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.removeAttributeNS(p0, p1);
  }

  @Test
  public void getAttributeNodeNS_test_5562(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getAttributeNodeNS(p0, p1);
  }

  @Test
  public void setAttributeNodeNS_test_5563(Attr p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setAttributeNodeNS(p0);
  }

  @Test
  public void hasAttribute_test_5564(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.hasAttribute(p0);
  }

  @Test
  public void hasAttributeNS_test_5565(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.hasAttributeNS(p0, p1);
  }

  @Test
  public void getSchemaTypeInfo_test_5566() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getSchemaTypeInfo();
  }

  @Test
  public void setIdAttribute_test_5567(String p0, boolean p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setIdAttribute(p0, p1);
  }

  @Test
  public void setIdAttributeNode_test_5568(Attr p0, boolean p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setIdAttributeNode(p0, p1);
  }

  @Test
  public void getNamespaceURI_test_5569() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getNamespaceURI();
  }

  @Test
  public void removeAttribute_test_5570(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.removeAttribute(p0);
  }

  @Test
  public void getUserObject_test_5571() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getUserObject();
  }

  @Test
  public void getNextSibling_test_5572() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getNextSibling();
  }

  @Test
  public void getPreviousSibling_test_5573() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getPreviousSibling();
  }

  @Test
  public void getFirstChild_test_5574() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getFirstChild();
  }

  @Test
  public void getLastChild_test_5575() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getLastChild();
  }

  @Test
  public void setUserObject_test_5576(Object p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setUserObject(p0);
  }

  @Test
  public void getUserData_test_5577(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getUserData(p0);
  }

  @Test
  public void setUserData_test_5578(String p0, Object p1, UserDataHandler p2) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setUserData(p0, p1, p2);
  }

  @Test
  public void getPrefix_test_5579() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getPrefix();
  }

  @Test
  public void getElementsByTagName_test_5580(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getElementsByTagName(p0);
  }

  @Test
  public void getElementsByTagNameNS_test_5581(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getElementsByTagNameNS(p0, p1);
  }

  @Test
  public void getNodeName_test_5582() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getNodeName();
  }

  @Test
  public void getNodeValue_test_5583() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getNodeValue();
  }

  @Test
  public void setNodeValue_test_5584(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setNodeValue(p0);
  }

  @Test
  public void getParentNode_test_5585() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getParentNode();
  }

  @Test
  public void getChildNodes_test_5586() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getChildNodes();
  }

  @Test
  public void getOwnerDocument_test_5587() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getOwnerDocument();
  }

  @Test
  public void insertBefore_test_5588(Node p0, Node p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.insertBefore(p0, p1);
  }

  @Test
  public void replaceChild_test_5589(Node p0, Node p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.replaceChild(p0, p1);
  }

  @Test
  public void removeChild_test_5590(Node p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.removeChild(p0);
  }

  @Test
  public void appendChild_test_5591(Node p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.appendChild(p0);
  }

  @Test
  public void hasChildNodes_test_5592() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.hasChildNodes();
  }

  @Test
  public void cloneNode_test_5593(boolean p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.cloneNode(p0);
  }

  @Test
  public void setPrefix_test_5594(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setPrefix(p0);
  }

  @Test
  public void getLocalName_test_5595() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getLocalName();
  }

  @Test
  public void hasAttributes_test_5596() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.hasAttributes();
  }

  @Test
  public void getBaseURI_test_5597() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getBaseURI();
  }

  @Test
  public void compareDocumentPosition_test_5598(Node p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.compareDocumentPosition(p0);
  }

  @Test
  public void getTextContent_test_5599() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getTextContent();
  }

  @Test
  public void setTextContent_test_5600(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setTextContent(p0);
  }

  @Test
  public void isSameNode_test_5601(Node p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.isSameNode(p0);
  }

  @Test
  public void lookupPrefix_test_5602(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.lookupPrefix(p0);
  }

  @Test
  public void isDefaultNamespace_test_5603(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.isDefaultNamespace(p0);
  }

  @Test
  public void lookupNamespaceURI_test_5604(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.lookupNamespaceURI(p0);
  }

  @Test
  public void isEqualNode_test_5605(Node p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.isEqualNode(p0);
  }

  @Test
  public void getLength_test_5606() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getLength();
  }

  @Test
  public void isSupported_test_5607(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.isSupported(p0, p1);
  }

  @Test
  public void getAttributes_test_5608() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getAttributes();
  }

  @Test
  public void normalize_test_5609() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.normalize();
  }

  @Test
  public void setAttribute_test_5610(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setAttribute(p0, p1);
  }

  @Test
  public void getAttribute_test_5611(String p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getAttribute(p0);
  }

  @Test
  public void item_test_5612(int p0) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.item(p0);
  }

  @Test
  public void getNodeType_test_5613() {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getNodeType();
  }

  @Test
  public void getFeature_test_5614(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getFeature(p0, p1);
  }

  @Test
  public void getAttributeNS_test_5615(String p0, String p1) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.getAttributeNS(p0, p1);
  }

  @Test
  public void setIdAttributeNS_test_5616(String p0, String p1, boolean p2) {
    IIOMetadataNode instance = new IIOMetadataNode();
    instance.setIdAttributeNS(p0, p1, p2);
  }
}
