package generated.test;

import java.lang.foreign.MemorySegment;
import java.nio.ByteOrder;
import jdk.incubator.vector.DoubleVector;
import jdk.incubator.vector.VectorMask;
import jdk.incubator.vector.VectorSpecies;
import org.junit.jupiter.api.Test;

public class jdk_incubator_vector_DoubleVectorAutoTest {
  @Test
  public void fromMemorySegment_test_4275(VectorSpecies p0, MemorySegment p1, long p2, ByteOrder p3,
      VectorMask p4) {
    DoubleVector.fromMemorySegment(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromMemorySegment_test_4276(VectorSpecies p0, MemorySegment p1, long p2,
      ByteOrder p3) {
    DoubleVector.fromMemorySegment(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_4277(VectorSpecies p0, double[] p1, int p2, int[] p3, int p4) {
    DoubleVector.fromArray(p0, p1, p2, p3, p4);
  }

  @Test
  public void fromArray_test_4278(VectorSpecies p0, double[] p1, int p2, VectorMask p3) {
    DoubleVector.fromArray(p0, p1, p2, p3);
  }

  @Test
  public void fromArray_test_4279(VectorSpecies p0, double[] p1, int p2) {
    DoubleVector.fromArray(p0, p1, p2);
  }

  @Test
  public void fromArray_test_4280(VectorSpecies p0, double[] p1, int p2, int[] p3, int p4,
      VectorMask p5) {
    DoubleVector.fromArray(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void zero_test_4281(VectorSpecies p0) {
    DoubleVector.zero(p0);
  }

  @Test
  public void broadcast_test_4282(VectorSpecies p0, double p1) {
    DoubleVector.broadcast(p0, p1);
  }

  @Test
  public void broadcast_test_4283(VectorSpecies p0, long p1) {
    DoubleVector.broadcast(p0, p1);
  }
}
