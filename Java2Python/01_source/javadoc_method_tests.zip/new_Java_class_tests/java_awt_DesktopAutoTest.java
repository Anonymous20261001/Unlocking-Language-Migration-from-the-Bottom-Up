package generated.test;

import java.awt.Desktop;
import org.junit.jupiter.api.Test;

public class java_awt_DesktopAutoTest {
  @Test
  public void getDesktop_test_4108() {
    Desktop.getDesktop();
  }

  @Test
  public void isDesktopSupported_test_4109() {
    Desktop.isDesktopSupported();
  }
}
