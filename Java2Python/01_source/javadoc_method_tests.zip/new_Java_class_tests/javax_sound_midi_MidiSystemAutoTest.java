package generated.test;

import javax.sound.midi.MidiSystem;
import javax.sound.midi.Sequence;
import org.junit.jupiter.api.Test;

public class javax_sound_midi_MidiSystemAutoTest {
  @Test
  public void isFileTypeSupported_test_8942(int p0) {
    MidiSystem.isFileTypeSupported(p0);
  }

  @Test
  public void isFileTypeSupported_test_8943(int p0, Sequence p1) {
    MidiSystem.isFileTypeSupported(p0, p1);
  }

  @Test
  public void getMidiFileTypes_test_8944(Sequence p0) {
    MidiSystem.getMidiFileTypes(p0);
  }

  @Test
  public void getMidiFileTypes_test_8945() {
    MidiSystem.getMidiFileTypes();
  }

  @Test
  public void getMidiDeviceInfo_test_8946() {
    MidiSystem.getMidiDeviceInfo();
  }
}
