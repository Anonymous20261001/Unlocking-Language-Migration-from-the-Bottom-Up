package generated.test;

import java.nio.file.attribute.GroupPrincipal;
import java.nio.file.attribute.UserPrincipal;
import jdk.net.UnixDomainPrincipal;
import org.junit.jupiter.api.Test;

public class jdk_net_UnixDomainPrincipalAutoTest {
  @Test
  public void group_test_13208(UserPrincipal c0, GroupPrincipal c1) {
    UnixDomainPrincipal instance = new UnixDomainPrincipal(c0, c1);
    instance.group();
  }

  @Test
  public void user_test_13209(UserPrincipal c0, GroupPrincipal c1) {
    UnixDomainPrincipal instance = new UnixDomainPrincipal(c0, c1);
    instance.user();
  }
}
