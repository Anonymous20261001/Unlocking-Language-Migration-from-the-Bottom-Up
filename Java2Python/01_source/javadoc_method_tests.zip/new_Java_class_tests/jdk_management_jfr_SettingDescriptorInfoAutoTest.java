package generated.test;

import javax.management.openmbean.CompositeData;
import jdk.management.jfr.SettingDescriptorInfo;
import org.junit.jupiter.api.Test;

public class jdk_management_jfr_SettingDescriptorInfoAutoTest {
  @Test
  public void from_test_11072(CompositeData p0) {
    SettingDescriptorInfo.from(p0);
  }
}
