package generated.test;

import java.lang.String;
import jdk.jshell.spi.ExecutionControl;
import org.junit.jupiter.api.Test;

public class jdk_jshell_spi_ExecutionControl_ClassInstallExceptionAutoTest {
  @Test
  public void installed_test_4631(String c0, boolean[] c1) {
    ExecutionControl.ClassInstallException instance = new ExecutionControl.ClassInstallException(c0, c1);
    instance.installed();
  }
}
