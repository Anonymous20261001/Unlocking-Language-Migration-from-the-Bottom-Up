package generated.test;

import java.awt.image.ColorModel;
import org.junit.jupiter.api.Test;

public class java_awt_image_ColorModelAutoTest {
  @Test
  public void getRGBdefault_test_2502() {
    ColorModel.getRGBdefault();
  }
}
