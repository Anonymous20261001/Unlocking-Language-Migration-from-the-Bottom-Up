package generated.test;

import java.net.http.HttpClient;
import org.junit.jupiter.api.Test;

public class java_net_http_HttpClientAutoTest {
  @Test
  public void newBuilder_test_5409() {
    HttpClient.newBuilder();
  }

  @Test
  public void newHttpClient_test_5410() {
    HttpClient.newHttpClient();
  }
}
