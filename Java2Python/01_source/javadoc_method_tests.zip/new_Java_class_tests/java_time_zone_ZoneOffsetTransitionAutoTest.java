package generated.test;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.zone.ZoneOffsetTransition;
import org.junit.jupiter.api.Test;

public class java_time_zone_ZoneOffsetTransitionAutoTest {
  @Test
  public void of_test_13734(LocalDateTime p0, ZoneOffset p1, ZoneOffset p2) {
    ZoneOffsetTransition.of(p0, p1, p2);
  }
}
