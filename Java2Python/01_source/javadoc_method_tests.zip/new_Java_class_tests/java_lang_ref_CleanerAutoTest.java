package generated.test;

import java.lang.ref.Cleaner;
import java.util.concurrent.ThreadFactory;
import org.junit.jupiter.api.Test;

public class java_lang_ref_CleanerAutoTest {
  @Test
  public void create_test_2319() {
    Cleaner.create();
  }

  @Test
  public void create_test_2320(ThreadFactory p0) {
    Cleaner.create(p0);
  }
}
