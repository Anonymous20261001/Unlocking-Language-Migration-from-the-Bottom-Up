package generated.test;

import java.awt.Dimension;
import javax.swing.Box;
import org.junit.jupiter.api.Test;

public class javax_swing_Box_FillerAutoTest {
  @Test
  public void getAccessibleContext_test_1848(Dimension c0, Dimension c1, Dimension c2) {
    Box.Filler instance = new Box.Filler(c0, c1, c2);
    instance.getAccessibleContext();
  }

  @Test
  public void changeShape_test_1849(Dimension p0, Dimension p1, Dimension p2, Dimension c0,
      Dimension c1, Dimension c2) {
    Box.Filler instance = new Box.Filler(c0, c1, c2);
    instance.changeShape(p0, p1, p2);
  }
}
