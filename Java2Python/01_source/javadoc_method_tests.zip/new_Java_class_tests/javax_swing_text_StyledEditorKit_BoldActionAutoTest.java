package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_StyledEditorKit_BoldActionAutoTest {
  @Test
  public void actionPerformed_test_12002(ActionEvent p0) {
    StyledEditorKit.BoldAction instance = new StyledEditorKit.BoldAction();
    instance.actionPerformed(p0);
  }
}
