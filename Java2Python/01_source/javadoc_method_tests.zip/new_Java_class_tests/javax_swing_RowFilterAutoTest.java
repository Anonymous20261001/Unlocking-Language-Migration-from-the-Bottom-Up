package generated.test;

import java.lang.Iterable;
import java.lang.Number;
import java.lang.String;
import java.util.Date;
import javax.swing.RowFilter;
import org.junit.jupiter.api.Test;

public class javax_swing_RowFilterAutoTest {
  @Test
  public void regexFilter_test_10708(String p0, int[] p1) {
    RowFilter.regexFilter(p0, p1);
  }

  @Test
  public void dateFilter_test_10709(RowFilter.ComparisonType p0, Date p1, int[] p2) {
    RowFilter.dateFilter(p0, p1, p2);
  }

  @Test
  public void numberFilter_test_10710(RowFilter.ComparisonType p0, Number p1, int[] p2) {
    RowFilter.numberFilter(p0, p1, p2);
  }

  @Test
  public void orFilter_test_10711(Iterable p0) {
    RowFilter.orFilter(p0);
  }

  @Test
  public void andFilter_test_10712(Iterable p0) {
    RowFilter.andFilter(p0);
  }

  @Test
  public void notFilter_test_10713(RowFilter p0) {
    RowFilter.notFilter(p0);
  }
}
