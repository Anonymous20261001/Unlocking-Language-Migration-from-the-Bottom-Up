package generated.test;

import javax.imageio.plugins.tiff.BaselineTIFFTagSet;
import org.junit.jupiter.api.Test;

public class javax_imageio_plugins_tiff_BaselineTIFFTagSetAutoTest {
  @Test
  public void getInstance_test_984() {
    BaselineTIFFTagSet.getInstance();
  }
}
