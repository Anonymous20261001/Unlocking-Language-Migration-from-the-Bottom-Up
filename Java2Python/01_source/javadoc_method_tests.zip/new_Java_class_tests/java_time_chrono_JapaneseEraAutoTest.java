package generated.test;

import java.lang.String;
import java.time.chrono.JapaneseEra;
import org.junit.jupiter.api.Test;

public class java_time_chrono_JapaneseEraAutoTest {
  @Test
  public void values_test_5974() {
    JapaneseEra.values();
  }

  @Test
  public void valueOf_test_5975(String p0) {
    JapaneseEra.valueOf(p0);
  }

  @Test
  public void of_test_5976(int p0) {
    JapaneseEra.of(p0);
  }
}
