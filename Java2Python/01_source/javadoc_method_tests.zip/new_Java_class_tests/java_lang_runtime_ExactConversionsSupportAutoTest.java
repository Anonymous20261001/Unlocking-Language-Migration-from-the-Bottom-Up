package generated.test;

import java.lang.runtime.ExactConversionsSupport;
import org.junit.jupiter.api.Test;

public class java_lang_runtime_ExactConversionsSupportAutoTest {
  @Test
  public void isIntToByteExact_test_4606(int p0) {
    ExactConversionsSupport.isIntToByteExact(p0);
  }

  @Test
  public void isIntToShortExact_test_4607(int p0) {
    ExactConversionsSupport.isIntToShortExact(p0);
  }

  @Test
  public void isIntToCharExact_test_4608(int p0) {
    ExactConversionsSupport.isIntToCharExact(p0);
  }

  @Test
  public void isIntToFloatExact_test_4609(int p0) {
    ExactConversionsSupport.isIntToFloatExact(p0);
  }

  @Test
  public void isLongToByteExact_test_4610(long p0) {
    ExactConversionsSupport.isLongToByteExact(p0);
  }

  @Test
  public void isLongToShortExact_test_4611(long p0) {
    ExactConversionsSupport.isLongToShortExact(p0);
  }

  @Test
  public void isLongToCharExact_test_4612(long p0) {
    ExactConversionsSupport.isLongToCharExact(p0);
  }

  @Test
  public void isLongToIntExact_test_4613(long p0) {
    ExactConversionsSupport.isLongToIntExact(p0);
  }

  @Test
  public void isLongToFloatExact_test_4614(long p0) {
    ExactConversionsSupport.isLongToFloatExact(p0);
  }

  @Test
  public void isLongToDoubleExact_test_4615(long p0) {
    ExactConversionsSupport.isLongToDoubleExact(p0);
  }

  @Test
  public void isFloatToByteExact_test_4616(float p0) {
    ExactConversionsSupport.isFloatToByteExact(p0);
  }

  @Test
  public void isFloatToShortExact_test_4617(float p0) {
    ExactConversionsSupport.isFloatToShortExact(p0);
  }

  @Test
  public void isFloatToCharExact_test_4618(float p0) {
    ExactConversionsSupport.isFloatToCharExact(p0);
  }

  @Test
  public void isFloatToIntExact_test_4619(float p0) {
    ExactConversionsSupport.isFloatToIntExact(p0);
  }

  @Test
  public void isFloatToLongExact_test_4620(float p0) {
    ExactConversionsSupport.isFloatToLongExact(p0);
  }

  @Test
  public void isDoubleToByteExact_test_4621(double p0) {
    ExactConversionsSupport.isDoubleToByteExact(p0);
  }

  @Test
  public void isDoubleToShortExact_test_4622(double p0) {
    ExactConversionsSupport.isDoubleToShortExact(p0);
  }

  @Test
  public void isDoubleToCharExact_test_4623(double p0) {
    ExactConversionsSupport.isDoubleToCharExact(p0);
  }

  @Test
  public void isDoubleToIntExact_test_4624(double p0) {
    ExactConversionsSupport.isDoubleToIntExact(p0);
  }

  @Test
  public void isDoubleToLongExact_test_4625(double p0) {
    ExactConversionsSupport.isDoubleToLongExact(p0);
  }

  @Test
  public void isDoubleToFloatExact_test_4626(double p0) {
    ExactConversionsSupport.isDoubleToFloatExact(p0);
  }
}
