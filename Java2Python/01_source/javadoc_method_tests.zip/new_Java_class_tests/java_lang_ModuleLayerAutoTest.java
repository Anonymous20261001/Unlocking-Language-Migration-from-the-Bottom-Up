package generated.test;

import java.lang.ClassLoader;
import java.lang.ModuleLayer;
import java.lang.module.Configuration;
import java.util.List;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

public class java_lang_ModuleLayerAutoTest {
  @Test
  public void empty_test_8996() {
    ModuleLayer.empty();
  }

  @Test
  public void boot_test_8997() {
    ModuleLayer.boot();
  }

  @Test
  public void defineModules_test_8998(Configuration p0, List p1, Function p2) {
    ModuleLayer.defineModules(p0, p1, p2);
  }

  @Test
  public void defineModulesWithOneLoader_test_8999(Configuration p0, List p1, ClassLoader p2) {
    ModuleLayer.defineModulesWithOneLoader(p0, p1, p2);
  }

  @Test
  public void defineModulesWithManyLoaders_test_9000(Configuration p0, List p1, ClassLoader p2) {
    ModuleLayer.defineModulesWithManyLoaders(p0, p1, p2);
  }
}
