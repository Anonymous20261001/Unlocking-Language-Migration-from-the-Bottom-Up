package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.DefaultEditorKit;
import org.junit.jupiter.api.Test;

public class javax_swing_text_DefaultEditorKit_InsertTabActionAutoTest {
  @Test
  public void actionPerformed_test_3675(ActionEvent p0) {
    DefaultEditorKit.InsertTabAction instance = new DefaultEditorKit.InsertTabAction();
    instance.actionPerformed(p0);
  }
}
