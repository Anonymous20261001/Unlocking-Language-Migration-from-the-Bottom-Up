package generated.test;

import java.text.DateFormat;
import javax.swing.text.DateFormatter;
import org.junit.jupiter.api.Test;

public class DateFormatterAutoTest {
  @Test
  public void setFormat_test_10156(DateFormat p0) {
    DateFormatter instance = new DateFormatter();
    instance.setFormat(p0);
  }
}
