package generated.test;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.beans.PropertyChangeListener;
import java.beans.PropertyEditorSupport;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class PropertyEditorSupportAutoTest {
  @Test
  public void isPaintable_test_1581() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.isPaintable();
  }

  @Test
  public void paintValue_test_1582(Graphics p0, Rectangle p1) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.paintValue(p0, p1);
  }

  @Test
  public void getJavaInitializationString_test_1583() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getJavaInitializationString();
  }

  @Test
  public void getAsText_test_1584() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getAsText();
  }

  @Test
  public void getTags_test_1585() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getTags();
  }

  @Test
  public void getCustomEditor_test_1586() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getCustomEditor();
  }

  @Test
  public void supportsCustomEditor_test_1587() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.supportsCustomEditor();
  }

  @Test
  public void firePropertyChange_test_1588() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.firePropertyChange();
  }

  @Test
  public void addPropertyChangeListener_test_1589(PropertyChangeListener p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void getSource_test_1590() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getSource();
  }

  @Test
  public void removePropertyChangeListener_test_1591(PropertyChangeListener p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.removePropertyChangeListener(p0);
  }

  @Test
  public void setSource_test_1592(Object p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.setSource(p0);
  }

  @Test
  public void getValue_test_1593() {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.getValue();
  }

  @Test
  public void setValue_test_1594(Object p0) {
    PropertyEditorSupport instance = new PropertyEditorSupport();
    instance.setValue(p0);
  }
}
