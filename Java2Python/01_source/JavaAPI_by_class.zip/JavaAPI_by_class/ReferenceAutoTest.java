package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.naming.RefAddr;
import javax.naming.Reference;
import org.junit.jupiter.api.Test;

public class ReferenceAutoTest {
  @Test
  public void getFactoryClassName_test_5936(String c0) {
    Reference instance = new Reference(c0);
    instance.getFactoryClassName();
  }

  @Test
  public void getFactoryClassLocation_test_5937(String c0) {
    Reference instance = new Reference(c0);
    instance.getFactoryClassLocation();
  }

  @Test
  public void remove_test_5938(int p0, String c0) {
    Reference instance = new Reference(c0);
    instance.remove(p0);
  }

  @Test
  public void size_test_5939(String c0) {
    Reference instance = new Reference(c0);
    instance.size();
  }

  @Test
  public void get_test_5940(int p0, String c0) {
    Reference instance = new Reference(c0);
    instance.get(p0);
  }

  @Test
  public void get_test_5941(String p0, String c0) {
    Reference instance = new Reference(c0);
    instance.get(p0);
  }

  @Test
  public void equals_test_5942(Object p0, String c0) {
    Reference instance = new Reference(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5943(String c0) {
    Reference instance = new Reference(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_5944(String c0) {
    Reference instance = new Reference(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_5945(String c0) {
    Reference instance = new Reference(c0);
    instance.clone();
  }

  @Test
  public void clear_test_5946(String c0) {
    Reference instance = new Reference(c0);
    instance.clear();
  }

  @Test
  public void add_test_5947(int p0, RefAddr p1, String c0) {
    Reference instance = new Reference(c0);
    instance.add(p0, p1);
  }

  @Test
  public void add_test_5948(RefAddr p0, String c0) {
    Reference instance = new Reference(c0);
    instance.add(p0);
  }

  @Test
  public void getClassName_test_5949(String c0) {
    Reference instance = new Reference(c0);
    instance.getClassName();
  }

  @Test
  public void getAll_test_5950(String c0) {
    Reference instance = new Reference(c0);
    instance.getAll();
  }
}
