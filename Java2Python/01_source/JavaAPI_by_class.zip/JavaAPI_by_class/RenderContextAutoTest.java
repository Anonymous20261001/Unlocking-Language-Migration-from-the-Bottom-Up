package generated.test;

import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.image.renderable.RenderContext;
import org.junit.jupiter.api.Test;

public class RenderContextAutoTest {
  @Test
  public void preConcetenateTransform_test_1454(AffineTransform p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.preConcetenateTransform(p0);
  }

  @Test
  public void concetenateTransform_test_1455(AffineTransform p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.concetenateTransform(p0);
  }

  @Test
  public void setRenderingHints_test_1456(RenderingHints p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.setRenderingHints(p0);
  }

  @Test
  public void preConcatenateTransform_test_1457(AffineTransform p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.preConcatenateTransform(p0);
  }

  @Test
  public void concatenateTransform_test_1458(AffineTransform p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.concatenateTransform(p0);
  }

  @Test
  public void setAreaOfInterest_test_1459(Shape p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.setAreaOfInterest(p0);
  }

  @Test
  public void getAreaOfInterest_test_1460(AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.getAreaOfInterest();
  }

  @Test
  public void getRenderingHints_test_1461(AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.getRenderingHints();
  }

  @Test
  public void getTransform_test_1462(AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.getTransform();
  }

  @Test
  public void setTransform_test_1463(AffineTransform p0, AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.setTransform(p0);
  }

  @Test
  public void clone_test_1464(AffineTransform c0) {
    RenderContext instance = new RenderContext(c0);
    instance.clone();
  }
}
