package generated.test;

import java.beans.SimpleBeanInfo;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class SimpleBeanInfoAutoTest {
  @Test
  public void getPropertyDescriptors_test_1596() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getPropertyDescriptors();
  }

  @Test
  public void getEventSetDescriptors_test_1597() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getEventSetDescriptors();
  }

  @Test
  public void getAdditionalBeanInfo_test_1598() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getAdditionalBeanInfo();
  }

  @Test
  public void getDefaultPropertyIndex_test_1599() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getDefaultPropertyIndex();
  }

  @Test
  public void getDefaultEventIndex_test_1600() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getDefaultEventIndex();
  }

  @Test
  public void getMethodDescriptors_test_1601() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getMethodDescriptors();
  }

  @Test
  public void getBeanDescriptor_test_1602() {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getBeanDescriptor();
  }

  @Test
  public void loadImage_test_1603(String p0) {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.loadImage(p0);
  }

  @Test
  public void getIcon_test_1604(int p0) {
    SimpleBeanInfo instance = new SimpleBeanInfo();
    instance.getIcon(p0);
  }
}
