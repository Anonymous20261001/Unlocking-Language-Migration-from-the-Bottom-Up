package generated.test;

import javax.accessibility.AccessibleState;
import javax.accessibility.AccessibleStateSet;
import org.junit.jupiter.api.Test;

public class AccessibleStateSetAutoTest {
  @Test
  public void remove_test_5226(AccessibleState p0) {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.remove(p0);
  }

  @Test
  public void toString_test_5227() {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.toString();
  }

  @Test
  public void clear_test_5228() {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.clear();
  }

  @Test
  public void add_test_5229(AccessibleState p0) {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.add(p0);
  }

  @Test
  public void toArray_test_5230() {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.toArray();
  }

  @Test
  public void contains_test_5231(AccessibleState p0) {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.contains(p0);
  }

  @Test
  public void addAll_test_5232(AccessibleState[] p0) {
    AccessibleStateSet instance = new AccessibleStateSet();
    instance.addAll(p0);
  }
}
