package generated.test;

import javax.crypto.spec.GCMParameterSpec;
import org.junit.jupiter.api.Test;

public class GCMParameterSpecAutoTest {
  @Test
  public void getIV_test_5247(int c0, byte[] c1) {
    GCMParameterSpec instance = new GCMParameterSpec(c0, c1);
    instance.getIV();
  }

  @Test
  public void getTLen_test_5248(int c0, byte[] c1) {
    GCMParameterSpec instance = new GCMParameterSpec(c0, c1);
    instance.getTLen();
  }
}
