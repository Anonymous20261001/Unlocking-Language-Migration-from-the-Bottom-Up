package generated.test;

import java.lang.Double;
import java.lang.Object;
import java.lang.invoke.MethodHandles;
import org.junit.jupiter.api.Test;

public class DoubleAutoTest {
  @Test
  public void equals_test_1967(Object p0, double c0) {
    Double instance = new Double(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_1968(double p0, double c0) {
    Double instance = new Double(c0);
    Double.toString(p0);
  }

  @Test
  public void toString_test_1969(double c0) {
    Double instance = new Double(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_1970(double c0) {
    Double instance = new Double(c0);
    instance.hashCode();
  }

  @Test
  public void hashCode_test_1971(double p0, double c0) {
    Double instance = new Double(c0);
    Double.hashCode(p0);
  }

  @Test
  public void min_test_1972(double p0, double p1, double c0) {
    Double instance = new Double(c0);
    Double.min(p0, p1);
  }

  @Test
  public void max_test_1973(double p0, double p1, double c0) {
    Double instance = new Double(c0);
    Double.max(p0, p1);
  }

  @Test
  public void isInfinite_test_1974(double c0) {
    Double instance = new Double(c0);
    instance.isInfinite();
  }

  @Test
  public void isInfinite_test_1975(double p0, double c0) {
    Double instance = new Double(c0);
    Double.isInfinite(p0);
  }

  @Test
  public void isFinite_test_1976(double p0, double c0) {
    Double instance = new Double(c0);
    Double.isFinite(p0);
  }

  @Test
  public void doubleToRawLongBits_test_1977(double p0, double c0) {
    Double instance = new Double(c0);
    Double.doubleToRawLongBits(p0);
  }

  @Test
  public void doubleToLongBits_test_1978(double p0, double c0) {
    Double instance = new Double(c0);
    Double.doubleToLongBits(p0);
  }

  @Test
  public void longBitsToDouble_test_1979(long p0, double c0) {
    Double instance = new Double(c0);
    Double.longBitsToDouble(p0);
  }

  @Test
  public void compareTo_test_1980(Double p0, double c0) {
    Double instance = new Double(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_1981(double p0, double p1, double c0) {
    Double instance = new Double(c0);
    Double.compare(p0, p1);
  }

  @Test
  public void byteValue_test_1982(double c0) {
    Double instance = new Double(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_1983(double c0) {
    Double instance = new Double(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_1984(double c0) {
    Double instance = new Double(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_1985(double c0) {
    Double instance = new Double(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_1986(double c0) {
    Double instance = new Double(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_1987(double c0) {
    Double instance = new Double(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_1988(double p0, double c0) {
    Double instance = new Double(c0);
    Double.valueOf(p0);
  }

  @Test
  public void toHexString_test_1989(double p0, double c0) {
    Double instance = new Double(c0);
    Double.toHexString(p0);
  }

  @Test
  public void resolveConstantDesc_test_1990(MethodHandles.Lookup p0, double c0) {
    Double instance = new Double(c0);
    instance.resolveConstantDesc(p0);
  }

  @Test
  public void describeConstable_test_1991(double c0) {
    Double instance = new Double(c0);
    instance.describeConstable();
  }

  @Test
  public void isNaN_test_1992(double c0) {
    Double instance = new Double(c0);
    instance.isNaN();
  }

  @Test
  public void isNaN_test_1993(double p0, double c0) {
    Double instance = new Double(c0);
    Double.isNaN(p0);
  }

  @Test
  public void sum_test_1994(double p0, double p1, double c0) {
    Double instance = new Double(c0);
    Double.sum(p0, p1);
  }
}
