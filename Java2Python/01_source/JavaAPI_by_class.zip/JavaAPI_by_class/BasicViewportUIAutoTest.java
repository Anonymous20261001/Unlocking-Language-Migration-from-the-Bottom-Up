package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicViewportUI;
import org.junit.jupiter.api.Test;

public class BasicViewportUIAutoTest {
  @Test
  public void installUI_test_9070(JComponent p0) {
    BasicViewportUI instance = new BasicViewportUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9071(JComponent p0) {
    BasicViewportUI instance = new BasicViewportUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_9072(JComponent p0) {
    BasicViewportUI instance = new BasicViewportUI();
    BasicViewportUI.createUI(p0);
  }
}
