package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthDesktopPaneUI;
import org.junit.jupiter.api.Test;

public class SynthDesktopPaneUIAutoTest {
  @Test
  public void propertyChange_test_9759(PropertyChangeEvent p0) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9760(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9761(JComponent p0) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    SynthDesktopPaneUI.createUI(p0);
  }

  @Test
  public void paint_test_9762(Graphics p0, JComponent p1) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9763(Graphics p0, JComponent p1) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9764(JComponent p0) {
    SynthDesktopPaneUI instance = new SynthDesktopPaneUI();
    instance.getContext(p0);
  }
}
