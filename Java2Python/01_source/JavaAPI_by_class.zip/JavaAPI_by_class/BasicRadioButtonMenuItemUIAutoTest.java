package generated.test;

import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.plaf.basic.BasicRadioButtonMenuItemUI;
import org.junit.jupiter.api.Test;

public class BasicRadioButtonMenuItemUIAutoTest {
  @Test
  public void createUI_test_8872(JComponent p0) {
    BasicRadioButtonMenuItemUI instance = new BasicRadioButtonMenuItemUI();
    BasicRadioButtonMenuItemUI.createUI(p0);
  }

  @Test
  public void processMouseEvent_test_8873(JMenuItem p0, MouseEvent p1, MenuElement[] p2,
      MenuSelectionManager p3) {
    BasicRadioButtonMenuItemUI instance = new BasicRadioButtonMenuItemUI();
    instance.processMouseEvent(p0, p1, p2, p3);
  }
}
