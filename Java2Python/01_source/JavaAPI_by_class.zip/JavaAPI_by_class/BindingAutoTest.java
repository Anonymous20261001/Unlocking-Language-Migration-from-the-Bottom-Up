package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.naming.Binding;
import org.junit.jupiter.api.Test;

public class BindingAutoTest {
  @Test
  public void setObject_test_5877(Object p0, String c0, Object c1) {
    Binding instance = new Binding(c0, c1);
    instance.setObject(p0);
  }

  @Test
  public void toString_test_5878(String c0, Object c1) {
    Binding instance = new Binding(c0, c1);
    instance.toString();
  }

  @Test
  public void getClassName_test_5879(String c0, Object c1) {
    Binding instance = new Binding(c0, c1);
    instance.getClassName();
  }

  @Test
  public void getObject_test_5880(String c0, Object c1) {
    Binding instance = new Binding(c0, c1);
    instance.getObject();
  }
}
