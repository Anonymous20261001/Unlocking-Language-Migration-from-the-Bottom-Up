package generated.test;

import java.math.BigInteger;
import java.security.spec.DSAParameterSpec;
import org.junit.jupiter.api.Test;

public class DSAParameterSpecAutoTest {
  @Test
  public void getP_test_2848(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance = new DSAParameterSpec(c0, c1, c2);
    instance.getP();
  }

  @Test
  public void getQ_test_2849(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance = new DSAParameterSpec(c0, c1, c2);
    instance.getQ();
  }

  @Test
  public void getG_test_2850(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance = new DSAParameterSpec(c0, c1, c2);
    instance.getG();
  }
}
