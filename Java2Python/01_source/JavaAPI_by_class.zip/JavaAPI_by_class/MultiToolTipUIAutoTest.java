package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolTipUI;
import org.junit.jupiter.api.Test;

public class MultiToolTipUIAutoTest {
  @Test
  public void installUI_test_9662(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9663(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9664() {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9665(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    MultiToolTipUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9666(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9667(Graphics p0, JComponent p1) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9668(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9669(JComponent p0, int p1) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9670(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9671(JComponent p0) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9672(Graphics p0, JComponent p1) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9673(JComponent p0, int p1, int p2) {
    MultiToolTipUI instance = new MultiToolTipUI();
    instance.contains(p0, p1, p2);
  }
}
