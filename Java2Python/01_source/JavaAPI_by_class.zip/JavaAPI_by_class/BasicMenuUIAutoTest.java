package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicMenuUI;
import org.junit.jupiter.api.Test;

public class BasicMenuUIAutoTest {
  @Test
  public void createUI_test_8838(JComponent p0) {
    BasicMenuUI instance = new BasicMenuUI();
    BasicMenuUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_8839(JComponent p0) {
    BasicMenuUI instance = new BasicMenuUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void getMinimumSize_test_8840(JComponent p0) {
    BasicMenuUI instance = new BasicMenuUI();
    instance.getMinimumSize(p0);
  }
}
