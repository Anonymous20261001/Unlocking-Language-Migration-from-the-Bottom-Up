package generated.test;

import java.lang.Object;
import javax.print.event.PrintEvent;
import org.junit.jupiter.api.Test;

public class PrintEventAutoTest {
  @Test
  public void toString_test_6247(Object c0) {
    PrintEvent instance = new PrintEvent(c0);
    instance.toString();
  }
}
