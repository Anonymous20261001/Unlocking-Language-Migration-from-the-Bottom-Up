package generated.test;

import java.awt.Insets;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class InsetsAutoTest {
  @Test
  public void equals_test_352(Object p0, int c0, int c1, int c2, int c3) {
    Insets instance = new Insets(c0, c1, c2, c3);
    instance.equals(p0);
  }

  @Test
  public void toString_test_353(int c0, int c1, int c2, int c3) {
    Insets instance = new Insets(c0, c1, c2, c3);
    instance.toString();
  }

  @Test
  public void hashCode_test_354(int c0, int c1, int c2, int c3) {
    Insets instance = new Insets(c0, c1, c2, c3);
    instance.hashCode();
  }

  @Test
  public void clone_test_355(int c0, int c1, int c2, int c3) {
    Insets instance = new Insets(c0, c1, c2, c3);
    instance.clone();
  }

  @Test
  public void set_test_356(int p0, int p1, int p2, int p3, int c0, int c1, int c2, int c3) {
    Insets instance = new Insets(c0, c1, c2, c3);
    instance.set(p0, p1, p2, p3);
  }
}
