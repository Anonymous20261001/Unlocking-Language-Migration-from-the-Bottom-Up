package generated.test;

import javax.print.PrintService;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.event.PrintServiceAttributeEvent;
import org.junit.jupiter.api.Test;

public class PrintServiceAttributeEventAutoTest {
  @Test
  public void getPrintService_test_6252(PrintService c0, PrintServiceAttributeSet c1) {
    PrintServiceAttributeEvent instance = new PrintServiceAttributeEvent(c0, c1);
    instance.getPrintService();
  }

  @Test
  public void getAttributes_test_6253(PrintService c0, PrintServiceAttributeSet c1) {
    PrintServiceAttributeEvent instance = new PrintServiceAttributeEvent(c0, c1);
    instance.getAttributes();
  }
}
