package generated.test;

import javax.management.ObjectName;
import javax.management.monitor.StringMonitor;
import org.junit.jupiter.api.Test;

public class StringMonitorAutoTest {
  @Test
  public void getNotificationInfo_test_5731() {
    StringMonitor instance = new StringMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_5732(ObjectName p0) {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGauge_test_5733() {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5734() {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5735(ObjectName p0) {
    StringMonitor instance = new StringMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getStringToCompare_test_5736() {
    StringMonitor instance = new StringMonitor();
    instance.getStringToCompare();
  }

  @Test
  public void getNotifyMatch_test_5737() {
    StringMonitor instance = new StringMonitor();
    instance.getNotifyMatch();
  }

  @Test
  public void setNotifyMatch_test_5738(boolean p0) {
    StringMonitor instance = new StringMonitor();
    instance.setNotifyMatch(p0);
  }

  @Test
  public void getNotifyDiffer_test_5739() {
    StringMonitor instance = new StringMonitor();
    instance.getNotifyDiffer();
  }

  @Test
  public void setNotifyDiffer_test_5740(boolean p0) {
    StringMonitor instance = new StringMonitor();
    instance.setNotifyDiffer(p0);
  }

  @Test
  public void start_test_5741() {
    StringMonitor instance = new StringMonitor();
    instance.start();
  }

  @Test
  public void stop_test_5742() {
    StringMonitor instance = new StringMonitor();
    instance.stop();
  }
}
