package generated.test;

import java.io.OutputStream;
import java.lang.String;
import java.util.zip.ZipOutputStream;
import org.junit.jupiter.api.Test;

public class ZipOutputStreamAutoTest {
  @Test
  public void setMethod_test_5209(int p0, OutputStream c0) {
    ZipOutputStream instance = new ZipOutputStream(c0);
    instance.setMethod(p0);
  }

  @Test
  public void setComment_test_5210(String p0, OutputStream c0) {
    ZipOutputStream instance = new ZipOutputStream(c0);
    instance.setComment(p0);
  }

  @Test
  public void setLevel_test_5211(int p0, OutputStream c0) {
    ZipOutputStream instance = new ZipOutputStream(c0);
    instance.setLevel(p0);
  }
}
