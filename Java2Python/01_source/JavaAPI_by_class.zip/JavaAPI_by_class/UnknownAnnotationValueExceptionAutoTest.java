package generated.test;

import java.lang.Object;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.UnknownAnnotationValueException;
import org.junit.jupiter.api.Test;

public class UnknownAnnotationValueExceptionAutoTest {
  @Test
  public void getUnknownAnnotationValue_test_5508(AnnotationValue c0, Object c1) {
    UnknownAnnotationValueException instance = new UnknownAnnotationValueException(c0, c1);
    instance.getUnknownAnnotationValue();
  }

  @Test
  public void getArgument_test_5509(AnnotationValue c0, Object c1) {
    UnknownAnnotationValueException instance = new UnknownAnnotationValueException(c0, c1);
    instance.getArgument();
  }
}
