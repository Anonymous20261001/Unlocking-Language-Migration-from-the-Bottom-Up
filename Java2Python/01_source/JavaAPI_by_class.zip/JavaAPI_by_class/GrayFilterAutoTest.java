package generated.test;

import java.awt.Image;
import javax.swing.GrayFilter;
import org.junit.jupiter.api.Test;

public class GrayFilterAutoTest {
  @Test
  public void createDisabledImage_test_6804(Image p0, boolean c0, int c1) {
    GrayFilter instance = new GrayFilter(c0, c1);
    GrayFilter.createDisabledImage(p0);
  }

  @Test
  public void filterRGB_test_6805(int p0, int p1, int p2, boolean c0, int c1) {
    GrayFilter instance = new GrayFilter(c0, c1);
    instance.filterRGB(p0, p1, p2);
  }
}
