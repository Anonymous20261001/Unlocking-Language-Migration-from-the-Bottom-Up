package generated.test;

import java.io.InputStream;
import java.io.InputStreamReader;
import org.junit.jupiter.api.Test;

public class InputStreamReaderAutoTest {
  @Test
  public void getEncoding_test_1782(InputStream c0) {
    InputStreamReader instance = new InputStreamReader(c0);
    instance.getEncoding();
  }
}
