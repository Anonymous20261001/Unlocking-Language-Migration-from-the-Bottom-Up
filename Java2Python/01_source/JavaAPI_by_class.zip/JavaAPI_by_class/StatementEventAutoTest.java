package generated.test;

import java.sql.PreparedStatement;
import javax.sql.PooledConnection;
import javax.sql.StatementEvent;
import org.junit.jupiter.api.Test;

public class StatementEventAutoTest {
  @Test
  public void getSQLException_test_6524(PooledConnection c0, PreparedStatement c1) {
    StatementEvent instance = new StatementEvent(c0, c1);
    instance.getSQLException();
  }

  @Test
  public void getStatement_test_6525(PooledConnection c0, PreparedStatement c1) {
    StatementEvent instance = new StatementEvent(c0, c1);
    instance.getStatement();
  }
}
