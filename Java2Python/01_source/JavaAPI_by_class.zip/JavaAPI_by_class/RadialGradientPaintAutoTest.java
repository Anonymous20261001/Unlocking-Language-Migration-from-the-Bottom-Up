package generated.test;

import java.awt.Color;
import java.awt.MultipleGradientPaint;
import java.awt.RadialGradientPaint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import org.junit.jupiter.api.Test;

public class RadialGradientPaintAutoTest {
  @Test
  public void createContext_test_469(ColorModel p0, Rectangle p1, Rectangle2D p2,
      AffineTransform p3, RenderingHints p4, Rectangle2D c0, float[] c1, Color[] c2,
      MultipleGradientPaint.CycleMethod c3) {
    RadialGradientPaint instance = new RadialGradientPaint(c0, c1, c2, c3);
    instance.createContext(p0, p1, p2, p3, p4);
  }

  @Test
  public void getCenterPoint_test_470(Rectangle2D c0, float[] c1, Color[] c2,
      MultipleGradientPaint.CycleMethod c3) {
    RadialGradientPaint instance = new RadialGradientPaint(c0, c1, c2, c3);
    instance.getCenterPoint();
  }

  @Test
  public void getFocusPoint_test_471(Rectangle2D c0, float[] c1, Color[] c2,
      MultipleGradientPaint.CycleMethod c3) {
    RadialGradientPaint instance = new RadialGradientPaint(c0, c1, c2, c3);
    instance.getFocusPoint();
  }

  @Test
  public void getRadius_test_472(Rectangle2D c0, float[] c1, Color[] c2,
      MultipleGradientPaint.CycleMethod c3) {
    RadialGradientPaint instance = new RadialGradientPaint(c0, c1, c2, c3);
    instance.getRadius();
  }
}
