package generated.test;

import java.lang.Object;
import java.lang.ThreadLocal;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;

public class ThreadLocalAutoTest {
  @Test
  public void remove_test_2354() {
    ThreadLocal instance = new ThreadLocal();
    instance.remove();
  }

  @Test
  public void get_test_2355() {
    ThreadLocal instance = new ThreadLocal();
    instance.get();
  }

  @Test
  public void set_test_2356(Object p0) {
    ThreadLocal instance = new ThreadLocal();
    instance.set(p0);
  }

  @Test
  public void withInitial_test_2357(Supplier p0) {
    ThreadLocal instance = new ThreadLocal();
    ThreadLocal.withInitial(p0);
  }
}
