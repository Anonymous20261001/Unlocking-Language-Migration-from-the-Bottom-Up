package generated.test;

import java.awt.Color;
import javax.swing.colorchooser.DefaultColorSelectionModel;
import javax.swing.event.ChangeListener;
import org.junit.jupiter.api.Test;

public class DefaultColorSelectionModelAutoTest {
  @Test
  public void addChangeListener_test_8515(ChangeListener p0) {
    DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
    instance.addChangeListener(p0);
  }

  @Test
  public void removeChangeListener_test_8516(ChangeListener p0) {
    DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
    instance.removeChangeListener(p0);
  }

  @Test
  public void getChangeListeners_test_8517() {
    DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
    instance.getChangeListeners();
  }

  @Test
  public void getSelectedColor_test_8518() {
    DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
    instance.getSelectedColor();
  }

  @Test
  public void setSelectedColor_test_8519(Color p0) {
    DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
    instance.setSelectedColor(p0);
  }
}
