package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {
  @Test
  public void installUI_test_9561(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9562(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9563() {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9564(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    MultiSpinnerUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9565(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9566(Graphics p0, JComponent p1) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9567(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9568(JComponent p0, int p1) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9569(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9570(JComponent p0) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9571(Graphics p0, JComponent p1) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9572(JComponent p0, int p1, int p2) {
    MultiSpinnerUI instance = new MultiSpinnerUI();
    instance.contains(p0, p1, p2);
  }
}
