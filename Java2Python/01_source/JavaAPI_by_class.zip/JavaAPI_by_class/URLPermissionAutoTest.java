package generated.test;

import java.lang.Object;
import java.lang.String;
import java.net.URLPermission;
import java.security.Permission;
import org.junit.jupiter.api.Test;

public class URLPermissionAutoTest {
  @Test
  public void getActions_test_2635(String c0) {
    URLPermission instance = new URLPermission(c0);
    instance.getActions();
  }

  @Test
  public void equals_test_2636(Object p0, String c0) {
    URLPermission instance = new URLPermission(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_2637(String c0) {
    URLPermission instance = new URLPermission(c0);
    instance.hashCode();
  }

  @Test
  public void implies_test_2638(Permission p0, String c0) {
    URLPermission instance = new URLPermission(c0);
    instance.implies(p0);
  }
}
