package generated.test;

import java.math.BigInteger;
import java.security.cert.CRL;
import java.security.cert.X509CRLSelector;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Date;
import javax.security.auth.x500.X500Principal;
import org.junit.jupiter.api.Test;

public class X509CRLSelectorAutoTest {
  @Test
  public void setIssuers_test_2795(Collection p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.setIssuers(p0);
  }

  @Test
  public void addIssuer_test_2796(X500Principal p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.addIssuer(p0);
  }

  @Test
  public void setMinCRLNumber_test_2797(BigInteger p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.setMinCRLNumber(p0);
  }

  @Test
  public void setMaxCRLNumber_test_2798(BigInteger p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.setMaxCRLNumber(p0);
  }

  @Test
  public void setDateAndTime_test_2799(Date p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.setDateAndTime(p0);
  }

  @Test
  public void setCertificateChecking_test_2800(X509Certificate p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.setCertificateChecking(p0);
  }

  @Test
  public void getIssuers_test_2801() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getIssuers();
  }

  @Test
  public void getIssuerNames_test_2802() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getIssuerNames();
  }

  @Test
  public void getMinCRL_test_2803() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getMinCRL();
  }

  @Test
  public void getMaxCRL_test_2804() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getMaxCRL();
  }

  @Test
  public void getDateAndTime_test_2805() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getDateAndTime();
  }

  @Test
  public void getCertificateChecking_test_2806() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.getCertificateChecking();
  }

  @Test
  public void toString_test_2807() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.toString();
  }

  @Test
  public void clone_test_2808() {
    X509CRLSelector instance = new X509CRLSelector();
    instance.clone();
  }

  @Test
  public void match_test_2809(CRL p0) {
    X509CRLSelector instance = new X509CRLSelector();
    instance.match(p0);
  }
}
