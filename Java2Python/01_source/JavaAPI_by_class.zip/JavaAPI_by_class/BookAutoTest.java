package generated.test;

import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import org.junit.jupiter.api.Test;

public class BookAutoTest {
  @Test
  public void getNumberOfPages_test_1485() {
    Book instance = new Book();
    instance.getNumberOfPages();
  }

  @Test
  public void append_test_1486(Printable p0, PageFormat p1, int p2) {
    Book instance = new Book();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_1487(Printable p0, PageFormat p1) {
    Book instance = new Book();
    instance.append(p0, p1);
  }
}
