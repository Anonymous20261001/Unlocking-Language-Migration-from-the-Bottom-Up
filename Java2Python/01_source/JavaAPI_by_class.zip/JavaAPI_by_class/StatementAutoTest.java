package generated.test;

import java.beans.Statement;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class StatementAutoTest {
  @Test
  public void getArguments_test_1605(Object c0, String c1, Object[] c2) {
    Statement instance = new Statement(c0, c1, c2);
    instance.getArguments();
  }

  @Test
  public void toString_test_1606(Object c0, String c1, Object[] c2) {
    Statement instance = new Statement(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void getTarget_test_1607(Object c0, String c1, Object[] c2) {
    Statement instance = new Statement(c0, c1, c2);
    instance.getTarget();
  }

  @Test
  public void getMethodName_test_1608(Object c0, String c1, Object[] c2) {
    Statement instance = new Statement(c0, c1, c2);
    instance.getMethodName();
  }
}
