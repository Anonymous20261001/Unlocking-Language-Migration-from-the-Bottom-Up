package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Locale;
import javax.print.attribute.standard.PrinterName;
import org.junit.jupiter.api.Test;

public class PrinterNameAutoTest {
  @Test
  public void getCategory_test_6228(String c0, Locale c1) {
    PrinterName instance = new PrinterName(c0, c1);
    instance.getCategory();
  }

  @Test
  public void getName_test_6229(String c0, Locale c1) {
    PrinterName instance = new PrinterName(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_6230(Object p0, String c0, Locale c1) {
    PrinterName instance = new PrinterName(c0, c1);
    instance.equals(p0);
  }
}
