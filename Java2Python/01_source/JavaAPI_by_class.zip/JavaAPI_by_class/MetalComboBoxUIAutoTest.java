package generated.test;

import java.awt.Container;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalComboBoxUI;
import org.junit.jupiter.api.Test;

public class MetalComboBoxUIAutoTest {
  @Test
  public void unconfigureEditor_test_9109() {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.unconfigureEditor();
  }

  @Test
  public void paintCurrentValueBackground_test_9110(Graphics p0, Rectangle p1, boolean p2) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.paintCurrentValueBackground(p0, p1, p2);
  }

  @Test
  public void paintCurrentValue_test_9111(Graphics p0, Rectangle p1, boolean p2) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.paintCurrentValue(p0, p1, p2);
  }

  @Test
  public void configureEditor_test_9112() {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.configureEditor();
  }

  @Test
  public void layoutComboBox_test_9113(Container p0,
      MetalComboBoxUI.MetalComboBoxLayoutManager p1) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.layoutComboBox(p0, p1);
  }

  @Test
  public void createUI_test_9114(JComponent p0) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    MetalComboBoxUI.createUI(p0);
  }

  @Test
  public void createPropertyChangeListener_test_9115() {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.createPropertyChangeListener();
  }

  @Test
  public void paint_test_9116(Graphics p0, JComponent p1) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getMinimumSize_test_9117(JComponent p0) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getBaseline_test_9118(JComponent p0, int p1, int p2) {
    MetalComboBoxUI instance = new MetalComboBoxUI();
    instance.getBaseline(p0, p1, p2);
  }
}
