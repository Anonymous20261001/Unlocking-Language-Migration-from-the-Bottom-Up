package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobMediaSheets;
import org.junit.jupiter.api.Test;

public class JobMediaSheetsAutoTest {
  @Test
  public void getCategory_test_6142(int c0) {
    JobMediaSheets instance = new JobMediaSheets(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6143(int c0) {
    JobMediaSheets instance = new JobMediaSheets(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6144(Object p0, int c0) {
    JobMediaSheets instance = new JobMediaSheets(c0);
    instance.equals(p0);
  }
}
