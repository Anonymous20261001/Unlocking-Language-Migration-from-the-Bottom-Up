package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicPopupMenuSeparatorUI;
import org.junit.jupiter.api.Test;

public class BasicPopupMenuSeparatorUIAutoTest {
  @Test
  public void createUI_test_8855(JComponent p0) {
    BasicPopupMenuSeparatorUI instance = new BasicPopupMenuSeparatorUI();
    BasicPopupMenuSeparatorUI.createUI(p0);
  }

  @Test
  public void paint_test_8856(Graphics p0, JComponent p1) {
    BasicPopupMenuSeparatorUI instance = new BasicPopupMenuSeparatorUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_8857(JComponent p0) {
    BasicPopupMenuSeparatorUI instance = new BasicPopupMenuSeparatorUI();
    instance.getPreferredSize(p0);
  }
}
