package generated.test;

import java.lang.Object;
import java.util.LinkedHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import org.junit.jupiter.api.Test;

public class LinkedHashMapAutoTest {
  @Test
  public void get_test_3584(Object p0) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.get(p0);
  }

  @Test
  public void values_test_3585() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.values();
  }

  @Test
  public void clear_test_3586() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.clear();
  }

  @Test
  public void replaceAll_test_3587(BiFunction p0) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.replaceAll(p0);
  }

  @Test
  public void entrySet_test_3588() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.entrySet();
  }

  @Test
  public void newLinkedHashMap_test_3589(int p0) {
    LinkedHashMap instance = new LinkedHashMap();
    LinkedHashMap.newLinkedHashMap(p0);
  }

  @Test
  public void forEach_test_3590(BiConsumer p0) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.forEach(p0);
  }

  @Test
  public void keySet_test_3591() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.keySet();
  }

  @Test
  public void containsValue_test_3592(Object p0) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.containsValue(p0);
  }

  @Test
  public void getOrDefault_test_3593(Object p0, Object p1) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.getOrDefault(p0, p1);
  }

  @Test
  public void reversed_test_3594() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.reversed();
  }

  @Test
  public void sequencedKeySet_test_3595() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.sequencedKeySet();
  }

  @Test
  public void sequencedValues_test_3596() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.sequencedValues();
  }

  @Test
  public void sequencedEntrySet_test_3597() {
    LinkedHashMap instance = new LinkedHashMap();
    instance.sequencedEntrySet();
  }

  @Test
  public void putFirst_test_3598(Object p0, Object p1) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.putFirst(p0, p1);
  }

  @Test
  public void putLast_test_3599(Object p0, Object p1) {
    LinkedHashMap instance = new LinkedHashMap();
    instance.putLast(p0, p1);
  }
}
