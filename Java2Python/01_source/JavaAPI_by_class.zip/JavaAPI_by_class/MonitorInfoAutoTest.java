package generated.test;

import java.lang.StackTraceElement;
import java.lang.String;
import java.lang.management.MonitorInfo;
import javax.management.openmbean.CompositeData;
import org.junit.jupiter.api.Test;

public class MonitorInfoAutoTest {
  @Test
  public void getLockedStackDepth_test_2417(String c0, int c1, int c2, StackTraceElement c3) {
    MonitorInfo instance = new MonitorInfo(c0, c1, c2, c3);
    instance.getLockedStackDepth();
  }

  @Test
  public void getLockedStackFrame_test_2418(String c0, int c1, int c2, StackTraceElement c3) {
    MonitorInfo instance = new MonitorInfo(c0, c1, c2, c3);
    instance.getLockedStackFrame();
  }

  @Test
  public void from_test_2419(CompositeData p0, String c0, int c1, int c2, StackTraceElement c3) {
    MonitorInfo instance = new MonitorInfo(c0, c1, c2, c3);
    MonitorInfo.from(p0);
  }
}
