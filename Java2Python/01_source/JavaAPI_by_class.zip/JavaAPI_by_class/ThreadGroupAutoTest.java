package generated.test;

import java.lang.String;
import java.lang.Thread;
import java.lang.ThreadGroup;
import java.lang.Throwable;
import org.junit.jupiter.api.Test;

public class ThreadGroupAutoTest {
  @Test
  public void getName_test_2334(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.getName();
  }

  @Test
  public void interrupt_test_2335(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.interrupt();
  }

  @Test
  public void toString_test_2336(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.toString();
  }

  @Test
  public void list_test_2337(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.list();
  }

  @Test
  public void getParent_test_2338(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.getParent();
  }

  @Test
  public void setDaemon_test_2339(boolean p0, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.setDaemon(p0);
  }

  @Test
  public void getMaxPriority_test_2340(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.getMaxPriority();
  }

  @Test
  public void isDaemon_test_2341(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.isDaemon();
  }

  @Test
  public void activeCount_test_2342(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.activeCount();
  }

  @Test
  public void enumerate_test_2343(ThreadGroup[] p0, boolean p1, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.enumerate(p0, p1);
  }

  @Test
  public void enumerate_test_2344(ThreadGroup[] p0, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.enumerate(p0);
  }

  @Test
  public void enumerate_test_2345(Thread[] p0, boolean p1, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.enumerate(p0, p1);
  }

  @Test
  public void enumerate_test_2346(Thread[] p0, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.enumerate(p0);
  }

  @Test
  public void uncaughtException_test_2347(Thread p0, Throwable p1, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.uncaughtException(p0, p1);
  }

  @Test
  public void checkAccess_test_2348(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.checkAccess();
  }

  @Test
  public void parentOf_test_2349(ThreadGroup p0, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.parentOf(p0);
  }

  @Test
  public void activeGroupCount_test_2350(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.activeGroupCount();
  }

  @Test
  public void setMaxPriority_test_2351(int p0, String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.setMaxPriority(p0);
  }

  @Test
  public void isDestroyed_test_2352(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.isDestroyed();
  }

  @Test
  public void destroy_test_2353(String c0) {
    ThreadGroup instance = new ThreadGroup(c0);
    instance.destroy();
  }
}
