package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {
  @Test
  public void installUI_test_9310(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9311(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9312() {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9313(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    MultiColorChooserUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9314(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9315(Graphics p0, JComponent p1) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9316(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9317(JComponent p0, int p1) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9318(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9319(JComponent p0) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9320(Graphics p0, JComponent p1) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9321(JComponent p0, int p1, int p2) {
    MultiColorChooserUI instance = new MultiColorChooserUI();
    instance.contains(p0, p1, p2);
  }
}
