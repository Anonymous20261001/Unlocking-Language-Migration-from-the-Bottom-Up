package generated.test;

import java.awt.event.ActionEvent;
import javax.swing.text.Element;
import javax.swing.text.html.FormView;
import org.junit.jupiter.api.Test;

public class FormViewAutoTest {
  @Test
  public void getMaximumSpan_test_10459(int p0, Element c0) {
    FormView instance = new FormView(c0);
    instance.getMaximumSpan(p0);
  }

  @Test
  public void actionPerformed_test_10460(ActionEvent p0, Element c0) {
    FormView instance = new FormView(c0);
    instance.actionPerformed(p0);
  }
}
