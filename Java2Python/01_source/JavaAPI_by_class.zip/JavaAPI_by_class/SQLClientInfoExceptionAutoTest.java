package generated.test;

import java.sql.SQLClientInfoException;
import org.junit.jupiter.api.Test;

public class SQLClientInfoExceptionAutoTest {
  @Test
  public void getFailedProperties_test_2956() {
    SQLClientInfoException instance = new SQLClientInfoException();
    instance.getFailedProperties();
  }
}
