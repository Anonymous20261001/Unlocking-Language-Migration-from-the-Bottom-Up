package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.net.ssl.SNIHostName;
import org.junit.jupiter.api.Test;

public class SNIHostNameAutoTest {
  @Test
  public void getAsciiName_test_6033(String c0) {
    SNIHostName instance = new SNIHostName(c0);
    instance.getAsciiName();
  }

  @Test
  public void createSNIMatcher_test_6034(String p0, String c0) {
    SNIHostName instance = new SNIHostName(c0);
    SNIHostName.createSNIMatcher(p0);
  }

  @Test
  public void equals_test_6035(Object p0, String c0) {
    SNIHostName instance = new SNIHostName(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6036(String c0) {
    SNIHostName instance = new SNIHostName(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_6037(String c0) {
    SNIHostName instance = new SNIHostName(c0);
    instance.hashCode();
  }
}
