package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.text.Element;
import javax.swing.text.ViewFactory;
import javax.swing.text.WrappedPlainView;
import org.junit.jupiter.api.Test;

public class WrappedPlainViewAutoTest {
  @Test
  public void insertUpdate_test_10433(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.insertUpdate(p0, p1, p2);
  }

  @Test
  public void removeUpdate_test_10434(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.removeUpdate(p0, p1, p2);
  }

  @Test
  public void changedUpdate_test_10435(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.changedUpdate(p0, p1, p2);
  }

  @Test
  public void nextTabStop_test_10436(float p0, int p1, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.nextTabStop(p0, p1);
  }

  @Test
  public void getPreferredSpan_test_10437(int p0, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.getPreferredSpan(p0);
  }

  @Test
  public void getMinimumSpan_test_10438(int p0, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.getMinimumSpan(p0);
  }

  @Test
  public void getMaximumSpan_test_10439(int p0, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.getMaximumSpan(p0);
  }

  @Test
  public void paint_test_10440(Graphics p0, Shape p1, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.paint(p0, p1);
  }

  @Test
  public void setSize_test_10441(float p0, float p1, Element c0) {
    WrappedPlainView instance = new WrappedPlainView(c0);
    instance.setSize(p0, p1);
  }
}
