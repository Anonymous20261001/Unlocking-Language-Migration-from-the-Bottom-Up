package generated.test;

import java.lang.String;
import java.util.DuplicateFormatFlagsException;
import org.junit.jupiter.api.Test;

public class DuplicateFormatFlagsExceptionAutoTest {
  @Test
  public void getMessage_test_3425(String c0) {
    DuplicateFormatFlagsException instance = new DuplicateFormatFlagsException(c0);
    instance.getMessage();
  }

  @Test
  public void getFlags_test_3426(String c0) {
    DuplicateFormatFlagsException instance = new DuplicateFormatFlagsException(c0);
    instance.getFlags();
  }
}
