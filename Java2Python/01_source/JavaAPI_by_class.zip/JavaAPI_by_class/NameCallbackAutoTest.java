package generated.test;

import java.lang.String;
import javax.security.auth.callback.NameCallback;
import org.junit.jupiter.api.Test;

public class NameCallbackAutoTest {
  @Test
  public void getPrompt_test_6342(String c0) {
    NameCallback instance = new NameCallback(c0);
    instance.getPrompt();
  }

  @Test
  public void getDefaultName_test_6343(String c0) {
    NameCallback instance = new NameCallback(c0);
    instance.getDefaultName();
  }

  @Test
  public void getName_test_6344(String c0) {
    NameCallback instance = new NameCallback(c0);
    instance.getName();
  }

  @Test
  public void setName_test_6345(String p0, String c0) {
    NameCallback instance = new NameCallback(c0);
    instance.setName(p0);
  }
}
