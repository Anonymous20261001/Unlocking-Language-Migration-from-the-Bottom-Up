package generated.test;

import java.math.BigInteger;
import java.security.spec.RSAOtherPrimeInfo;
import org.junit.jupiter.api.Test;

public class RSAOtherPrimeInfoAutoTest {
  @Test
  public void getCrtCoefficient_test_2916(BigInteger c0, BigInteger c1, BigInteger c2) {
    RSAOtherPrimeInfo instance = new RSAOtherPrimeInfo(c0, c1, c2);
    instance.getCrtCoefficient();
  }

  @Test
  public void getPrime_test_2917(BigInteger c0, BigInteger c1, BigInteger c2) {
    RSAOtherPrimeInfo instance = new RSAOtherPrimeInfo(c0, c1, c2);
    instance.getPrime();
  }

  @Test
  public void getExponent_test_2918(BigInteger c0, BigInteger c1, BigInteger c2) {
    RSAOtherPrimeInfo instance = new RSAOtherPrimeInfo(c0, c1, c2);
    instance.getExponent();
  }
}
