package generated.test;

import java.lang.String;
import java.security.AlgorithmConstraints;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.SSLParameters;
import org.junit.jupiter.api.Test;

public class SSLParametersAutoTest {
  @Test
  public void getCipherSuites_test_6044() {
    SSLParameters instance = new SSLParameters();
    instance.getCipherSuites();
  }

  @Test
  public void getProtocols_test_6045() {
    SSLParameters instance = new SSLParameters();
    instance.getProtocols();
  }

  @Test
  public void getWantClientAuth_test_6046() {
    SSLParameters instance = new SSLParameters();
    instance.getWantClientAuth();
  }

  @Test
  public void setWantClientAuth_test_6047(boolean p0) {
    SSLParameters instance = new SSLParameters();
    instance.setWantClientAuth(p0);
  }

  @Test
  public void getNeedClientAuth_test_6048() {
    SSLParameters instance = new SSLParameters();
    instance.getNeedClientAuth();
  }

  @Test
  public void setNeedClientAuth_test_6049(boolean p0) {
    SSLParameters instance = new SSLParameters();
    instance.setNeedClientAuth(p0);
  }

  @Test
  public void getAlgorithmConstraints_test_6050() {
    SSLParameters instance = new SSLParameters();
    instance.getAlgorithmConstraints();
  }

  @Test
  public void setAlgorithmConstraints_test_6051(AlgorithmConstraints p0) {
    SSLParameters instance = new SSLParameters();
    instance.setAlgorithmConstraints(p0);
  }

  @Test
  public void getEndpointIdentificationAlgorithm_test_6052() {
    SSLParameters instance = new SSLParameters();
    instance.getEndpointIdentificationAlgorithm();
  }

  @Test
  public void setEndpointIdentificationAlgorithm_test_6053(String p0) {
    SSLParameters instance = new SSLParameters();
    instance.setEndpointIdentificationAlgorithm(p0);
  }

  @Test
  public void setServerNames_test_6054(List p0) {
    SSLParameters instance = new SSLParameters();
    instance.setServerNames(p0);
  }

  @Test
  public void getServerNames_test_6055() {
    SSLParameters instance = new SSLParameters();
    instance.getServerNames();
  }

  @Test
  public void setSNIMatchers_test_6056(Collection p0) {
    SSLParameters instance = new SSLParameters();
    instance.setSNIMatchers(p0);
  }

  @Test
  public void getSNIMatchers_test_6057() {
    SSLParameters instance = new SSLParameters();
    instance.getSNIMatchers();
  }

  @Test
  public void setUseCipherSuitesOrder_test_6058(boolean p0) {
    SSLParameters instance = new SSLParameters();
    instance.setUseCipherSuitesOrder(p0);
  }

  @Test
  public void getUseCipherSuitesOrder_test_6059() {
    SSLParameters instance = new SSLParameters();
    instance.getUseCipherSuitesOrder();
  }

  @Test
  public void setEnableRetransmissions_test_6060(boolean p0) {
    SSLParameters instance = new SSLParameters();
    instance.setEnableRetransmissions(p0);
  }

  @Test
  public void getEnableRetransmissions_test_6061() {
    SSLParameters instance = new SSLParameters();
    instance.getEnableRetransmissions();
  }

  @Test
  public void setMaximumPacketSize_test_6062(int p0) {
    SSLParameters instance = new SSLParameters();
    instance.setMaximumPacketSize(p0);
  }

  @Test
  public void getMaximumPacketSize_test_6063() {
    SSLParameters instance = new SSLParameters();
    instance.getMaximumPacketSize();
  }

  @Test
  public void getApplicationProtocols_test_6064() {
    SSLParameters instance = new SSLParameters();
    instance.getApplicationProtocols();
  }

  @Test
  public void setApplicationProtocols_test_6065(String[] p0) {
    SSLParameters instance = new SSLParameters();
    instance.setApplicationProtocols(p0);
  }

  @Test
  public void getSignatureSchemes_test_6066() {
    SSLParameters instance = new SSLParameters();
    instance.getSignatureSchemes();
  }

  @Test
  public void setSignatureSchemes_test_6067(String[] p0) {
    SSLParameters instance = new SSLParameters();
    instance.setSignatureSchemes(p0);
  }

  @Test
  public void getNamedGroups_test_6068() {
    SSLParameters instance = new SSLParameters();
    instance.getNamedGroups();
  }

  @Test
  public void setNamedGroups_test_6069(String[] p0) {
    SSLParameters instance = new SSLParameters();
    instance.setNamedGroups(p0);
  }

  @Test
  public void setCipherSuites_test_6070(String[] p0) {
    SSLParameters instance = new SSLParameters();
    instance.setCipherSuites(p0);
  }

  @Test
  public void setProtocols_test_6071(String[] p0) {
    SSLParameters instance = new SSLParameters();
    instance.setProtocols(p0);
  }
}
