package generated.test;

import javax.imageio.stream.IIOByteBuffer;
import org.junit.jupiter.api.Test;

public class IIOByteBufferAutoTest {
  @Test
  public void setData_test_5495(byte[] p0, byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.setData(p0);
  }

  @Test
  public void getLength_test_5496(byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.getLength();
  }

  @Test
  public void setLength_test_5497(int p0, byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.setLength(p0);
  }

  @Test
  public void getOffset_test_5498(byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.getOffset();
  }

  @Test
  public void setOffset_test_5499(int p0, byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.setOffset(p0);
  }

  @Test
  public void getData_test_5500(byte[] c0, int c1, int c2) {
    IIOByteBuffer instance = new IIOByteBuffer(c0, c1, c2);
    instance.getData();
  }
}
