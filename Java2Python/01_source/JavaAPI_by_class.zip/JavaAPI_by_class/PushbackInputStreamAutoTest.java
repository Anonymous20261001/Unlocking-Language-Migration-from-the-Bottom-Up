package generated.test;

import java.io.InputStream;
import java.io.PushbackInputStream;
import org.junit.jupiter.api.Test;

public class PushbackInputStreamAutoTest {
  @Test
  public void mark_test_1799(int p0, InputStream c0) {
    PushbackInputStream instance = new PushbackInputStream(c0);
    instance.mark(p0);
  }

  @Test
  public void markSupported_test_1800(InputStream c0) {
    PushbackInputStream instance = new PushbackInputStream(c0);
    instance.markSupported();
  }
}
