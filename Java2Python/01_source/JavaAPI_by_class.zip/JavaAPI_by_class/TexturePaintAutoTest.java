package generated.test;

import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.TexturePaint;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import org.junit.jupiter.api.Test;

public class TexturePaintAutoTest {
  @Test
  public void getImage_test_527(BufferedImage c0, Rectangle2D c1) {
    TexturePaint instance = new TexturePaint(c0, c1);
    instance.getImage();
  }

  @Test
  public void createContext_test_528(ColorModel p0, Rectangle p1, Rectangle2D p2,
      AffineTransform p3, RenderingHints p4, BufferedImage c0, Rectangle2D c1) {
    TexturePaint instance = new TexturePaint(c0, c1);
    instance.createContext(p0, p1, p2, p3, p4);
  }

  @Test
  public void getTransparency_test_529(BufferedImage c0, Rectangle2D c1) {
    TexturePaint instance = new TexturePaint(c0, c1);
    instance.getTransparency();
  }

  @Test
  public void getAnchorRect_test_530(BufferedImage c0, Rectangle2D c1) {
    TexturePaint instance = new TexturePaint(c0, c1);
    instance.getAnchorRect();
  }
}
