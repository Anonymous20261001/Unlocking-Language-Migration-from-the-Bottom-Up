package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobKOctetsProcessed;
import org.junit.jupiter.api.Test;

public class JobKOctetsProcessedAutoTest {
  @Test
  public void getCategory_test_6136(int c0) {
    JobKOctetsProcessed instance = new JobKOctetsProcessed(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6137(int c0) {
    JobKOctetsProcessed instance = new JobKOctetsProcessed(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6138(Object p0, int c0) {
    JobKOctetsProcessed instance = new JobKOctetsProcessed(c0);
    instance.equals(p0);
  }
}
