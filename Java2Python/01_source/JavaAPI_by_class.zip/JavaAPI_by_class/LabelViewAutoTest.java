package generated.test;

import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.text.Element;
import javax.swing.text.LabelView;
import javax.swing.text.ViewFactory;
import org.junit.jupiter.api.Test;

public class LabelViewAutoTest {
  @Test
  public void changedUpdate_test_10294(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    LabelView instance = new LabelView(c0);
    instance.changedUpdate(p0, p1, p2);
  }

  @Test
  public void isUnderline_test_10295(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.isUnderline();
  }

  @Test
  public void isStrikeThrough_test_10296(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.isStrikeThrough();
  }

  @Test
  public void isSubscript_test_10297(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.isSubscript();
  }

  @Test
  public void isSuperscript_test_10298(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.isSuperscript();
  }

  @Test
  public void getFont_test_10299(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.getFont();
  }

  @Test
  public void getForeground_test_10300(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.getForeground();
  }

  @Test
  public void getBackground_test_10301(Element c0) {
    LabelView instance = new LabelView(c0);
    instance.getBackground();
  }
}
