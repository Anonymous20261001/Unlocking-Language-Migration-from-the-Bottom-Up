package generated.test;

import java.sql.DataTruncation;
import org.junit.jupiter.api.Test;

public class DataTruncationAutoTest {
  @Test
  public void getParameter_test_2939(int c0, boolean c1, boolean c2, int c3, int c4) {
    DataTruncation instance = new DataTruncation(c0, c1, c2, c3, c4);
    instance.getParameter();
  }

  @Test
  public void getIndex_test_2940(int c0, boolean c1, boolean c2, int c3, int c4) {
    DataTruncation instance = new DataTruncation(c0, c1, c2, c3, c4);
    instance.getIndex();
  }

  @Test
  public void getRead_test_2941(int c0, boolean c1, boolean c2, int c3, int c4) {
    DataTruncation instance = new DataTruncation(c0, c1, c2, c3, c4);
    instance.getRead();
  }

  @Test
  public void getDataSize_test_2942(int c0, boolean c1, boolean c2, int c3, int c4) {
    DataTruncation instance = new DataTruncation(c0, c1, c2, c3, c4);
    instance.getDataSize();
  }

  @Test
  public void getTransferSize_test_2943(int c0, boolean c1, boolean c2, int c3, int c4) {
    DataTruncation instance = new DataTruncation(c0, c1, c2, c3, c4);
    instance.getTransferSize();
  }
}
