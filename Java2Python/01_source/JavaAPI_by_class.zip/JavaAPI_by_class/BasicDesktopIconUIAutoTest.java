package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicDesktopIconUI;
import org.junit.jupiter.api.Test;

public class BasicDesktopIconUIAutoTest {
  @Test
  public void deiconize_test_8696() {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.deiconize();
  }

  @Test
  public void installUI_test_8697(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8698(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8699(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    BasicDesktopIconUI.createUI(p0);
  }

  @Test
  public void getInsets_test_8700(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.getInsets(p0);
  }

  @Test
  public void getMaximumSize_test_8701(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void getPreferredSize_test_8702(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_8703(JComponent p0) {
    BasicDesktopIconUI instance = new BasicDesktopIconUI();
    instance.getMinimumSize(p0);
  }
}
