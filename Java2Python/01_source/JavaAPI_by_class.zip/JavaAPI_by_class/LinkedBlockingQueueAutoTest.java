package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class LinkedBlockingQueueAutoTest {
  @Test
  public void drainTo_test_4555(Collection p0, int p1) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.drainTo(p0, p1);
  }

  @Test
  public void drainTo_test_4556(Collection p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.drainTo(p0);
  }

  @Test
  public void remainingCapacity_test_4557() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4558(Object p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.remove(p0);
  }

  @Test
  public void size_test_4559() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.size();
  }

  @Test
  public void toString_test_4560() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.toString();
  }

  @Test
  public void clear_test_4561() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.clear();
  }

  @Test
  public void toArray_test_4562() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.toArray();
  }

  @Test
  public void toArray_test_4563(Object[] p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.toArray(p0);
  }

  @Test
  public void iterator_test_4564() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.iterator();
  }

  @Test
  public void contains_test_4565(Object p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4566() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.spliterator();
  }

  @Test
  public void forEach_test_4567(Consumer p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.forEach(p0);
  }

  @Test
  public void peek_test_4568() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.peek();
  }

  @Test
  public void removeIf_test_4569(Predicate p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.removeIf(p0);
  }

  @Test
  public void removeAll_test_4570(Collection p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4571(Collection p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.retainAll(p0);
  }

  @Test
  public void poll_test_4572() {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.poll();
  }

  @Test
  public void offer_test_4573(Object p0) {
    LinkedBlockingQueue instance = new LinkedBlockingQueue();
    instance.offer(p0);
  }
}
