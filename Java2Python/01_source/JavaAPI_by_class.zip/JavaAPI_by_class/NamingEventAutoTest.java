package generated.test;

import java.lang.Object;
import javax.naming.Binding;
import javax.naming.event.EventContext;
import javax.naming.event.NamingEvent;
import javax.naming.event.NamingListener;
import org.junit.jupiter.api.Test;

public class NamingEventAutoTest {
  @Test
  public void getEventContext_test_5999(EventContext c0, int c1, Binding c2, Binding c3,
      Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.getEventContext();
  }

  @Test
  public void getOldBinding_test_6000(EventContext c0, int c1, Binding c2, Binding c3, Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.getOldBinding();
  }

  @Test
  public void getNewBinding_test_6001(EventContext c0, int c1, Binding c2, Binding c3, Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.getNewBinding();
  }

  @Test
  public void getChangeInfo_test_6002(EventContext c0, int c1, Binding c2, Binding c3, Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.getChangeInfo();
  }

  @Test
  public void dispatch_test_6003(NamingListener p0, EventContext c0, int c1, Binding c2, Binding c3,
      Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.dispatch(p0);
  }

  @Test
  public void getType_test_6004(EventContext c0, int c1, Binding c2, Binding c3, Object c4) {
    NamingEvent instance = new NamingEvent(c0, c1, c2, c3, c4);
    instance.getType();
  }
}
