package generated.test;

import java.awt.event.ActionListener;
import java.io.File;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;
import org.junit.jupiter.api.Test;

public class JFileChooserAutoTest {
  @Test
  public void setCurrentDirectory_test_7017(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.setCurrentDirectory(p0);
  }

  @Test
  public void getFileSystemView_test_7018() {
    JFileChooser instance = new JFileChooser();
    instance.getFileSystemView();
  }

  @Test
  public void setFileSystemView_test_7019(FileSystemView p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileSystemView(p0);
  }

  @Test
  public void isAcceptAllFileFilterUsed_test_7020() {
    JFileChooser instance = new JFileChooser();
    instance.isAcceptAllFileFilterUsed();
  }

  @Test
  public void getAcceptAllFileFilter_test_7021() {
    JFileChooser instance = new JFileChooser();
    instance.getAcceptAllFileFilter();
  }

  @Test
  public void setFileFilter_test_7022(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileFilter(p0);
  }

  @Test
  public void getCurrentDirectory_test_7023() {
    JFileChooser instance = new JFileChooser();
    instance.getCurrentDirectory();
  }

  @Test
  public void isMultiSelectionEnabled_test_7024() {
    JFileChooser instance = new JFileChooser();
    instance.isMultiSelectionEnabled();
  }

  @Test
  public void ensureFileIsVisible_test_7025(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.ensureFileIsVisible(p0);
  }

  @Test
  public void setSelectedFile_test_7026(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.setSelectedFile(p0);
  }

  @Test
  public void isTraversable_test_7027(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.isTraversable(p0);
  }

  @Test
  public void rescanCurrentDirectory_test_7028() {
    JFileChooser instance = new JFileChooser();
    instance.rescanCurrentDirectory();
  }

  @Test
  public void setDialogType_test_7029(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDialogType(p0);
  }

  @Test
  public void setApproveButtonText_test_7030(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonText(p0);
  }

  @Test
  public void getDialogTitle_test_7031() {
    JFileChooser instance = new JFileChooser();
    instance.getDialogTitle();
  }

  @Test
  public void setApproveButtonMnemonic_test_7032(char p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonMnemonic(p0);
  }

  @Test
  public void setApproveButtonMnemonic_test_7033(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonMnemonic(p0);
  }

  @Test
  public void getChoosableFileFilters_test_7034() {
    JFileChooser instance = new JFileChooser();
    instance.getChoosableFileFilters();
  }

  @Test
  public void getFileFilter_test_7035() {
    JFileChooser instance = new JFileChooser();
    instance.getFileFilter();
  }

  @Test
  public void addChoosableFileFilter_test_7036(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.addChoosableFileFilter(p0);
  }

  @Test
  public void removeChoosableFileFilter_test_7037(FileFilter p0) {
    JFileChooser instance = new JFileChooser();
    instance.removeChoosableFileFilter(p0);
  }

  @Test
  public void setSelectedFiles_test_7038(File[] p0) {
    JFileChooser instance = new JFileChooser();
    instance.setSelectedFiles(p0);
  }

  @Test
  public void getFileView_test_7039() {
    JFileChooser instance = new JFileChooser();
    instance.getFileView();
  }

  @Test
  public void getTypeDescription_test_7040(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getTypeDescription(p0);
  }

  @Test
  public void getUIClassID_test_7041() {
    JFileChooser instance = new JFileChooser();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_7042() {
    JFileChooser instance = new JFileChooser();
    instance.getUI();
  }

  @Test
  public void getSelectedFile_test_7043() {
    JFileChooser instance = new JFileChooser();
    instance.getSelectedFile();
  }

  @Test
  public void getSelectedFiles_test_7044() {
    JFileChooser instance = new JFileChooser();
    instance.getSelectedFiles();
  }

  @Test
  public void changeToParentDirectory_test_7045() {
    JFileChooser instance = new JFileChooser();
    instance.changeToParentDirectory();
  }

  @Test
  public void getControlButtonsAreShown_test_7046() {
    JFileChooser instance = new JFileChooser();
    instance.getControlButtonsAreShown();
  }

  @Test
  public void setControlButtonsAreShown_test_7047(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setControlButtonsAreShown(p0);
  }

  @Test
  public void getDialogType_test_7048() {
    JFileChooser instance = new JFileChooser();
    instance.getDialogType();
  }

  @Test
  public void setDialogTitle_test_7049(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDialogTitle(p0);
  }

  @Test
  public void setApproveButtonToolTipText_test_7050(String p0) {
    JFileChooser instance = new JFileChooser();
    instance.setApproveButtonToolTipText(p0);
  }

  @Test
  public void getApproveButtonToolTipText_test_7051() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonToolTipText();
  }

  @Test
  public void getApproveButtonMnemonic_test_7052() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonMnemonic();
  }

  @Test
  public void getApproveButtonText_test_7053() {
    JFileChooser instance = new JFileChooser();
    instance.getApproveButtonText();
  }

  @Test
  public void resetChoosableFileFilters_test_7054() {
    JFileChooser instance = new JFileChooser();
    instance.resetChoosableFileFilters();
  }

  @Test
  public void setAcceptAllFileFilterUsed_test_7055(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setAcceptAllFileFilterUsed(p0);
  }

  @Test
  public void getAccessory_test_7056() {
    JFileChooser instance = new JFileChooser();
    instance.getAccessory();
  }

  @Test
  public void setAccessory_test_7057(JComponent p0) {
    JFileChooser instance = new JFileChooser();
    instance.setAccessory(p0);
  }

  @Test
  public void setFileSelectionMode_test_7058(int p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileSelectionMode(p0);
  }

  @Test
  public void getFileSelectionMode_test_7059() {
    JFileChooser instance = new JFileChooser();
    instance.getFileSelectionMode();
  }

  @Test
  public void isFileSelectionEnabled_test_7060() {
    JFileChooser instance = new JFileChooser();
    instance.isFileSelectionEnabled();
  }

  @Test
  public void isDirectorySelectionEnabled_test_7061() {
    JFileChooser instance = new JFileChooser();
    instance.isDirectorySelectionEnabled();
  }

  @Test
  public void setMultiSelectionEnabled_test_7062(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setMultiSelectionEnabled(p0);
  }

  @Test
  public void isFileHidingEnabled_test_7063() {
    JFileChooser instance = new JFileChooser();
    instance.isFileHidingEnabled();
  }

  @Test
  public void setFileHidingEnabled_test_7064(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileHidingEnabled(p0);
  }

  @Test
  public void setFileView_test_7065(FileView p0) {
    JFileChooser instance = new JFileChooser();
    instance.setFileView(p0);
  }

  @Test
  public void approveSelection_test_7066() {
    JFileChooser instance = new JFileChooser();
    instance.approveSelection();
  }

  @Test
  public void cancelSelection_test_7067() {
    JFileChooser instance = new JFileChooser();
    instance.cancelSelection();
  }

  @Test
  public void setDragEnabled_test_7068(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setDragEnabled(p0);
  }

  @Test
  public void getDragEnabled_test_7069() {
    JFileChooser instance = new JFileChooser();
    instance.getDragEnabled();
  }

  @Test
  public void getIcon_test_7070(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getIcon(p0);
  }

  @Test
  public void getDescription_test_7071(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getDescription(p0);
  }

  @Test
  public void getAccessibleContext_test_7072() {
    JFileChooser instance = new JFileChooser();
    instance.getAccessibleContext();
  }

  @Test
  public void setEnabled_test_7073(boolean p0) {
    JFileChooser instance = new JFileChooser();
    instance.setEnabled(p0);
  }

  @Test
  public void addActionListener_test_7074(ActionListener p0) {
    JFileChooser instance = new JFileChooser();
    instance.addActionListener(p0);
  }

  @Test
  public void removeActionListener_test_7075(ActionListener p0) {
    JFileChooser instance = new JFileChooser();
    instance.removeActionListener(p0);
  }

  @Test
  public void getActionListeners_test_7076() {
    JFileChooser instance = new JFileChooser();
    instance.getActionListeners();
  }

  @Test
  public void updateUI_test_7077() {
    JFileChooser instance = new JFileChooser();
    instance.updateUI();
  }

  @Test
  public void getName_test_7078(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.getName(p0);
  }

  @Test
  public void accept_test_7079(File p0) {
    JFileChooser instance = new JFileChooser();
    instance.accept(p0);
  }
}
