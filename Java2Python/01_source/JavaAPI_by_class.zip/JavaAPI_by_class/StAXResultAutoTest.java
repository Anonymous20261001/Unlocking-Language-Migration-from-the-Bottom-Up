package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.stax.StAXResult;
import org.junit.jupiter.api.Test;

public class StAXResultAutoTest {
  @Test
  public void getSystemId_test_10997(XMLStreamWriter c0) {
    StAXResult instance = new StAXResult(c0);
    instance.getSystemId();
  }

  @Test
  public void setSystemId_test_10998(String p0, XMLStreamWriter c0) {
    StAXResult instance = new StAXResult(c0);
    instance.setSystemId(p0);
  }

  @Test
  public void getXMLEventWriter_test_10999(XMLStreamWriter c0) {
    StAXResult instance = new StAXResult(c0);
    instance.getXMLEventWriter();
  }

  @Test
  public void getXMLStreamWriter_test_11000(XMLStreamWriter c0) {
    StAXResult instance = new StAXResult(c0);
    instance.getXMLStreamWriter();
  }
}
