package generated.test;

import java.lang.Class;
import java.lang.EnumConstantNotPresentException;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class EnumConstantNotPresentExceptionAutoTest {
  @Test
  public void enumType_test_1995(Class c0, String c1) {
    EnumConstantNotPresentException instance = new EnumConstantNotPresentException(c0, c1);
    instance.enumType();
  }

  @Test
  public void constantName_test_1996(Class c0, String c1) {
    EnumConstantNotPresentException instance = new EnumConstantNotPresentException(c0, c1);
    instance.constantName();
  }
}
