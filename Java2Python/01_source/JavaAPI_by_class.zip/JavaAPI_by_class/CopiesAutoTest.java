package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.Copies;
import org.junit.jupiter.api.Test;

public class CopiesAutoTest {
  @Test
  public void getCategory_test_6097(int c0) {
    Copies instance = new Copies(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6098(int c0) {
    Copies instance = new Copies(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6099(Object p0, int c0) {
    Copies instance = new Copies(c0);
    instance.equals(p0);
  }
}
