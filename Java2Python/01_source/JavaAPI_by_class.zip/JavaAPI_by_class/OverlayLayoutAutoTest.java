package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.lang.Object;
import java.lang.String;
import javax.swing.OverlayLayout;
import org.junit.jupiter.api.Test;

public class OverlayLayoutAutoTest {
  @Test
  public void removeLayoutComponent_test_8208(Component p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_8209(Component p0, Object p1, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void addLayoutComponent_test_8210(String p0, Component p1, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_8211(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.layoutContainer(p0);
  }

  @Test
  public void invalidateLayout_test_8212(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.invalidateLayout(p0);
  }

  @Test
  public void preferredLayoutSize_test_8213(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_8214(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void maximumLayoutSize_test_8215(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.maximumLayoutSize(p0);
  }

  @Test
  public void getLayoutAlignmentX_test_8216(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.getLayoutAlignmentX(p0);
  }

  @Test
  public void getLayoutAlignmentY_test_8217(Container p0, Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.getLayoutAlignmentY(p0);
  }

  @Test
  public void getTarget_test_8218(Container c0) {
    OverlayLayout instance = new OverlayLayout(c0);
    instance.getTarget();
  }
}
