package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthOptionPaneUI;
import org.junit.jupiter.api.Test;

public class SynthOptionPaneUIAutoTest {
  @Test
  public void propertyChange_test_9835(PropertyChangeEvent p0) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9836(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9837(JComponent p0) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    SynthOptionPaneUI.createUI(p0);
  }

  @Test
  public void paint_test_9838(Graphics p0, JComponent p1) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9839(Graphics p0, JComponent p1) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9840(JComponent p0) {
    SynthOptionPaneUI instance = new SynthOptionPaneUI();
    instance.getContext(p0);
  }
}
