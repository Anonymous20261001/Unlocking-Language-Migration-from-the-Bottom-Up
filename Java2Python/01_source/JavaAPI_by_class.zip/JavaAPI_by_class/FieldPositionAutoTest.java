package generated.test;

import java.lang.Object;
import java.text.FieldPosition;
import java.text.Format;
import org.junit.jupiter.api.Test;

public class FieldPositionAutoTest {
  @Test
  public void equals_test_3166(Object p0, Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_3167(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_3168(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.hashCode();
  }

  @Test
  public void getField_test_3169(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.getField();
  }

  @Test
  public void setBeginIndex_test_3170(int p0, Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.setBeginIndex(p0);
  }

  @Test
  public void setEndIndex_test_3171(int p0, Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.setEndIndex(p0);
  }

  @Test
  public void getFieldAttribute_test_3172(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.getFieldAttribute();
  }

  @Test
  public void getBeginIndex_test_3173(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.getBeginIndex();
  }

  @Test
  public void getEndIndex_test_3174(Format.Field c0) {
    FieldPosition instance = new FieldPosition(c0);
    instance.getEndIndex();
  }
}
