package generated.test;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.plaf.multi.MultiPopupMenuUI;
import org.junit.jupiter.api.Test;

public class MultiPopupMenuUIAutoTest {
  @Test
  public void installUI_test_9475(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9476(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getPopup_test_9477(JPopupMenu p0, int p1, int p2) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getPopup(p0, p1, p2);
  }

  @Test
  public void getUIs_test_9478() {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9479(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    MultiPopupMenuUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9480(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9481(Graphics p0, JComponent p1) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9482(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9483(JComponent p0, int p1) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9484(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9485(JComponent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void isPopupTrigger_test_9486(MouseEvent p0) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.isPopupTrigger(p0);
  }

  @Test
  public void update_test_9487(Graphics p0, JComponent p1) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9488(JComponent p0, int p1, int p2) {
    MultiPopupMenuUI instance = new MultiPopupMenuUI();
    instance.contains(p0, p1, p2);
  }
}
