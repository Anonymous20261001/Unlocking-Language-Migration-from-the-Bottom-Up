package generated.test;

import javax.net.ssl.HandshakeCompletedEvent;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import org.junit.jupiter.api.Test;

public class HandshakeCompletedEventAutoTest {
  @Test
  public void getCipherSuite_test_6027(SSLSocket c0, SSLSession c1) {
    HandshakeCompletedEvent instance = new HandshakeCompletedEvent(c0, c1);
    instance.getCipherSuite();
  }

  @Test
  public void getLocalCertificates_test_6028(SSLSocket c0, SSLSession c1) {
    HandshakeCompletedEvent instance = new HandshakeCompletedEvent(c0, c1);
    instance.getLocalCertificates();
  }

  @Test
  public void getLocalPrincipal_test_6029(SSLSocket c0, SSLSession c1) {
    HandshakeCompletedEvent instance = new HandshakeCompletedEvent(c0, c1);
    instance.getLocalPrincipal();
  }

  @Test
  public void getSession_test_6030(SSLSocket c0, SSLSession c1) {
    HandshakeCompletedEvent instance = new HandshakeCompletedEvent(c0, c1);
    instance.getSession();
  }

  @Test
  public void getSocket_test_6031(SSLSocket c0, SSLSession c1) {
    HandshakeCompletedEvent instance = new HandshakeCompletedEvent(c0, c1);
    instance.getSocket();
  }
}
