package generated.test;

import javax.swing.text.GapContent;
import org.junit.jupiter.api.Test;

public class GapContentAutoTest {
  @Test
  public void length_test_10255() {
    GapContent instance = new GapContent();
    instance.length();
  }
}
