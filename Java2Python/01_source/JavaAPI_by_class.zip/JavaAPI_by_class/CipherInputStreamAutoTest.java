package generated.test;

import java.io.InputStream;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import org.junit.jupiter.api.Test;

public class CipherInputStreamAutoTest {
  @Test
  public void markSupported_test_5233(InputStream c0, Cipher c1) {
    CipherInputStream instance = new CipherInputStream(c0, c1);
    instance.markSupported();
  }
}
