package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalTabbedPaneUI;
import org.junit.jupiter.api.Test;

public class MetalTabbedPaneUIAutoTest {
  @Test
  public void createUI_test_9270(JComponent p0) {
    MetalTabbedPaneUI instance = new MetalTabbedPaneUI();
    MetalTabbedPaneUI.createUI(p0);
  }

  @Test
  public void paint_test_9271(Graphics p0, JComponent p1) {
    MetalTabbedPaneUI instance = new MetalTabbedPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9272(Graphics p0, JComponent p1) {
    MetalTabbedPaneUI instance = new MetalTabbedPaneUI();
    instance.update(p0, p1);
  }
}
