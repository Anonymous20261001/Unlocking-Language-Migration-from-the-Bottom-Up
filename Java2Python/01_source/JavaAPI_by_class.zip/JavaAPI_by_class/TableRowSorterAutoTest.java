package generated.test;

import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.table.TableStringConverter;
import org.junit.jupiter.api.Test;

public class TableRowSorterAutoTest {
  @Test
  public void setModel_test_10102(TableModel p0) {
    TableRowSorter instance = new TableRowSorter();
    instance.setModel(p0);
  }

  @Test
  public void setStringConverter_test_10103(TableStringConverter p0) {
    TableRowSorter instance = new TableRowSorter();
    instance.setStringConverter(p0);
  }

  @Test
  public void getStringConverter_test_10104() {
    TableRowSorter instance = new TableRowSorter();
    instance.getStringConverter();
  }

  @Test
  public void getComparator_test_10105(int p0) {
    TableRowSorter instance = new TableRowSorter();
    instance.getComparator(p0);
  }
}
