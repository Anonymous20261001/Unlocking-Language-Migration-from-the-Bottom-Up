package generated.test;

import java.util.IllegalFormatWidthException;
import org.junit.jupiter.api.Test;

public class IllegalFormatWidthExceptionAutoTest {
  @Test
  public void getWidth_test_3573(int c0) {
    IllegalFormatWidthException instance = new IllegalFormatWidthException(c0);
    instance.getWidth();
  }

  @Test
  public void getMessage_test_3574(int c0) {
    IllegalFormatWidthException instance = new IllegalFormatWidthException(c0);
    instance.getMessage();
  }
}
