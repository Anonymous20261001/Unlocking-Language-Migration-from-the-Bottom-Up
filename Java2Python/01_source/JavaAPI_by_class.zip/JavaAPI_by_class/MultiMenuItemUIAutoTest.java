package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiMenuItemUI;
import org.junit.jupiter.api.Test;

public class MultiMenuItemUIAutoTest {
  @Test
  public void installUI_test_9437(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9438(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9439() {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9440(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    MultiMenuItemUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9441(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9442(Graphics p0, JComponent p1) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9443(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9444(JComponent p0, int p1) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9445(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9446(JComponent p0) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9447(Graphics p0, JComponent p1) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9448(JComponent p0, int p1, int p2) {
    MultiMenuItemUI instance = new MultiMenuItemUI();
    instance.contains(p0, p1, p2);
  }
}
