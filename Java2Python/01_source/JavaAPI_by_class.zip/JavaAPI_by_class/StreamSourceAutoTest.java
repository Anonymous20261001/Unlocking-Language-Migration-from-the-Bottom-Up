package generated.test;

import java.io.File;
import java.io.InputStream;
import java.io.Reader;
import java.lang.String;
import javax.xml.transform.stream.StreamSource;
import org.junit.jupiter.api.Test;

public class StreamSourceAutoTest {
  @Test
  public void getSystemId_test_11008() {
    StreamSource instance = new StreamSource();
    instance.getSystemId();
  }

  @Test
  public void setSystemId_test_11009(File p0) {
    StreamSource instance = new StreamSource();
    instance.setSystemId(p0);
  }

  @Test
  public void setSystemId_test_11010(String p0) {
    StreamSource instance = new StreamSource();
    instance.setSystemId(p0);
  }

  @Test
  public void getPublicId_test_11011() {
    StreamSource instance = new StreamSource();
    instance.getPublicId();
  }

  @Test
  public void setPublicId_test_11012(String p0) {
    StreamSource instance = new StreamSource();
    instance.setPublicId(p0);
  }

  @Test
  public void setInputStream_test_11013(InputStream p0) {
    StreamSource instance = new StreamSource();
    instance.setInputStream(p0);
  }

  @Test
  public void isEmpty_test_11014() {
    StreamSource instance = new StreamSource();
    instance.isEmpty();
  }

  @Test
  public void getInputStream_test_11015() {
    StreamSource instance = new StreamSource();
    instance.getInputStream();
  }

  @Test
  public void getReader_test_11016() {
    StreamSource instance = new StreamSource();
    instance.getReader();
  }

  @Test
  public void setReader_test_11017(Reader p0) {
    StreamSource instance = new StreamSource();
    instance.setReader(p0);
  }
}
