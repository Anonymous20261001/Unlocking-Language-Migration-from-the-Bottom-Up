package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import javax.swing.JLayer;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.plaf.LayerUI;
import org.junit.jupiter.api.Test;

public class JLayerAutoTest {
  @Test
  public void getScrollableTracksViewportWidth_test_7185() {
    JLayer instance = new JLayer();
    instance.getScrollableTracksViewportWidth();
  }

  @Test
  public void getScrollableTracksViewportHeight_test_7186() {
    JLayer instance = new JLayer();
    instance.getScrollableTracksViewportHeight();
  }

  @Test
  public void getPreferredScrollableViewportSize_test_7187() {
    JLayer instance = new JLayer();
    instance.getPreferredScrollableViewportSize();
  }

  @Test
  public void getScrollableUnitIncrement_test_7188(Rectangle p0, int p1, int p2) {
    JLayer instance = new JLayer();
    instance.getScrollableUnitIncrement(p0, p1, p2);
  }

  @Test
  public void getScrollableBlockIncrement_test_7189(Rectangle p0, int p1, int p2) {
    JLayer instance = new JLayer();
    instance.getScrollableBlockIncrement(p0, p1, p2);
  }

  @Test
  public void propertyChange_test_7190(PropertyChangeEvent p0) {
    JLayer instance = new JLayer();
    instance.propertyChange(p0);
  }

  @Test
  public void isOptimizedDrawingEnabled_test_7191() {
    JLayer instance = new JLayer();
    instance.isOptimizedDrawingEnabled();
  }

  @Test
  public void getBorder_test_7192() {
    JLayer instance = new JLayer();
    instance.getBorder();
  }

  @Test
  public void paintImmediately_test_7193(int p0, int p1, int p2, int p3) {
    JLayer instance = new JLayer();
    instance.paintImmediately(p0, p1, p2, p3);
  }

  @Test
  public void getUI_test_7194() {
    JLayer instance = new JLayer();
    instance.getUI();
  }

  @Test
  public void setUI_test_7195(LayerUI p0) {
    JLayer instance = new JLayer();
    instance.setUI(p0);
  }

  @Test
  public void setBorder_test_7196(Border p0) {
    JLayer instance = new JLayer();
    instance.setBorder(p0);
  }

  @Test
  public void createGlassPane_test_7197() {
    JLayer instance = new JLayer();
    instance.createGlassPane();
  }

  @Test
  public void setView_test_7198(Component p0) {
    JLayer instance = new JLayer();
    instance.setView(p0);
  }

  @Test
  public void getView_test_7199() {
    JLayer instance = new JLayer();
    instance.getView();
  }

  @Test
  public void getLayerEventMask_test_7200() {
    JLayer instance = new JLayer();
    instance.getLayerEventMask();
  }

  @Test
  public void setLayerEventMask_test_7201(long p0) {
    JLayer instance = new JLayer();
    instance.setLayerEventMask(p0);
  }

  @Test
  public void getGlassPane_test_7202() {
    JLayer instance = new JLayer();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_7203(JPanel p0) {
    JLayer instance = new JLayer();
    instance.setGlassPane(p0);
  }

  @Test
  public void getAccessibleContext_test_7204() {
    JLayer instance = new JLayer();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_7205(LayoutManager p0) {
    JLayer instance = new JLayer();
    instance.setLayout(p0);
  }

  @Test
  public void addNotify_test_7206() {
    JLayer instance = new JLayer();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_7207() {
    JLayer instance = new JLayer();
    instance.removeNotify();
  }

  @Test
  public void doLayout_test_7208() {
    JLayer instance = new JLayer();
    instance.doLayout();
  }

  @Test
  public void paint_test_7209(Graphics p0) {
    JLayer instance = new JLayer();
    instance.paint(p0);
  }

  @Test
  public void imageUpdate_test_7210(Image p0, int p1, int p2, int p3, int p4, int p5) {
    JLayer instance = new JLayer();
    instance.imageUpdate(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void updateUI_test_7211() {
    JLayer instance = new JLayer();
    instance.updateUI();
  }

  @Test
  public void remove_test_7212(Component p0) {
    JLayer instance = new JLayer();
    instance.remove(p0);
  }

  @Test
  public void removeAll_test_7213() {
    JLayer instance = new JLayer();
    instance.removeAll();
  }
}
