package generated.test;

import java.lang.NullPointerException;
import org.junit.jupiter.api.Test;

public class NullPointerExceptionAutoTest {
  @Test
  public void fillInStackTrace_test_2042() {
    NullPointerException instance = new NullPointerException();
    instance.fillInStackTrace();
  }

  @Test
  public void getMessage_test_2043() {
    NullPointerException instance = new NullPointerException();
    instance.getMessage();
  }
}
