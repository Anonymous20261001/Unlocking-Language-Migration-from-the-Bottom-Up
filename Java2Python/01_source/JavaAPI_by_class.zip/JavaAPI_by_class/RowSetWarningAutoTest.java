package generated.test;

import javax.sql.rowset.RowSetWarning;
import org.junit.jupiter.api.Test;

public class RowSetWarningAutoTest {
  @Test
  public void getNextWarning_test_6526() {
    RowSetWarning instance = new RowSetWarning();
    instance.getNextWarning();
  }

  @Test
  public void setNextWarning_test_6527(RowSetWarning p0) {
    RowSetWarning instance = new RowSetWarning();
    instance.setNextWarning(p0);
  }
}
