package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.NumberUpSupported;
import org.junit.jupiter.api.Test;

public class NumberUpSupportedAutoTest {
  @Test
  public void getCategory_test_6195(int[][] c0) {
    NumberUpSupported instance = new NumberUpSupported(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6196(int[][] c0) {
    NumberUpSupported instance = new NumberUpSupported(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6197(Object p0, int[][] c0) {
    NumberUpSupported instance = new NumberUpSupported(c0);
    instance.equals(p0);
  }
}
