package generated.test;

import javax.sound.sampled.Line;
import javax.sound.sampled.LineEvent;
import org.junit.jupiter.api.Test;

public class LineEventAutoTest {
  @Test
  public void getLine_test_6519(Line c0, LineEvent.Type c1, long c2) {
    LineEvent instance = new LineEvent(c0, c1, c2);
    instance.getLine();
  }

  @Test
  public void getFramePosition_test_6520(Line c0, LineEvent.Type c1, long c2) {
    LineEvent instance = new LineEvent(c0, c1, c2);
    instance.getFramePosition();
  }

  @Test
  public void toString_test_6521(Line c0, LineEvent.Type c1, long c2) {
    LineEvent instance = new LineEvent(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void getType_test_6522(Line c0, LineEvent.Type c1, long c2) {
    LineEvent instance = new LineEvent(c0, c1, c2);
    instance.getType();
  }
}
