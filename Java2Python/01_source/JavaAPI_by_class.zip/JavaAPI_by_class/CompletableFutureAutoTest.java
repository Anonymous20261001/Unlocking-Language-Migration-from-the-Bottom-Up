package generated.test;

import java.lang.Object;
import java.lang.Runnable;
import java.lang.Throwable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import org.junit.jupiter.api.Test;

public class CompletableFutureAutoTest {
  @Test
  public void newIncompleteFuture_test_4102() {
    CompletableFuture instance = new CompletableFuture();
    instance.newIncompleteFuture();
  }

  @Test
  public void toCompletableFuture_test_4103() {
    CompletableFuture instance = new CompletableFuture();
    instance.toCompletableFuture();
  }

  @Test
  public void getNow_test_4104(Object p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.getNow(p0);
  }

  @Test
  public void defaultExecutor_test_4105() {
    CompletableFuture instance = new CompletableFuture();
    instance.defaultExecutor();
  }

  @Test
  public void completeAsync_test_4106(Supplier p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.completeAsync(p0, p1);
  }

  @Test
  public void completeAsync_test_4107(Supplier p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.completeAsync(p0);
  }

  @Test
  public void whenComplete_test_4108(BiConsumer p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.whenComplete(p0);
  }

  @Test
  public void exceptionallyComposeAsync_test_4109(Function p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionallyComposeAsync(p0, p1);
  }

  @Test
  public void exceptionallyComposeAsync_test_4110(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionallyComposeAsync(p0);
  }

  @Test
  public void exceptionallyCompose_test_4111(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionallyCompose(p0);
  }

  @Test
  public void exceptionallyAsync_test_4112(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionallyAsync(p0);
  }

  @Test
  public void exceptionallyAsync_test_4113(Function p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionallyAsync(p0, p1);
  }

  @Test
  public void exceptionally_test_4114(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionally(p0);
  }

  @Test
  public void whenCompleteAsync_test_4115(BiConsumer p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.whenCompleteAsync(p0, p1);
  }

  @Test
  public void whenCompleteAsync_test_4116(BiConsumer p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.whenCompleteAsync(p0);
  }

  @Test
  public void handleAsync_test_4117(BiFunction p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.handleAsync(p0);
  }

  @Test
  public void handleAsync_test_4118(BiFunction p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.handleAsync(p0, p1);
  }

  @Test
  public void thenComposeAsync_test_4119(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenComposeAsync(p0);
  }

  @Test
  public void thenComposeAsync_test_4120(Function p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenComposeAsync(p0, p1);
  }

  @Test
  public void thenCompose_test_4121(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenCompose(p0);
  }

  @Test
  public void runAfterEitherAsync_test_4122(CompletionStage p0, Runnable p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterEitherAsync(p0, p1);
  }

  @Test
  public void runAfterEitherAsync_test_4123(CompletionStage p0, Runnable p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterEitherAsync(p0, p1, p2);
  }

  @Test
  public void runAfterEither_test_4124(CompletionStage p0, Runnable p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterEither(p0, p1);
  }

  @Test
  public void acceptEitherAsync_test_4125(CompletionStage p0, Consumer p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.acceptEitherAsync(p0, p1, p2);
  }

  @Test
  public void acceptEitherAsync_test_4126(CompletionStage p0, Consumer p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.acceptEitherAsync(p0, p1);
  }

  @Test
  public void acceptEither_test_4127(CompletionStage p0, Consumer p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.acceptEither(p0, p1);
  }

  @Test
  public void applyToEitherAsync_test_4128(CompletionStage p0, Function p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.applyToEitherAsync(p0, p1, p2);
  }

  @Test
  public void applyToEitherAsync_test_4129(CompletionStage p0, Function p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.applyToEitherAsync(p0, p1);
  }

  @Test
  public void applyToEither_test_4130(CompletionStage p0, Function p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.applyToEither(p0, p1);
  }

  @Test
  public void runAfterBothAsync_test_4131(CompletionStage p0, Runnable p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterBothAsync(p0, p1, p2);
  }

  @Test
  public void runAfterBothAsync_test_4132(CompletionStage p0, Runnable p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterBothAsync(p0, p1);
  }

  @Test
  public void runAfterBoth_test_4133(CompletionStage p0, Runnable p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.runAfterBoth(p0, p1);
  }

  @Test
  public void thenAcceptBothAsync_test_4134(CompletionStage p0, BiConsumer p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAcceptBothAsync(p0, p1, p2);
  }

  @Test
  public void thenAcceptBothAsync_test_4135(CompletionStage p0, BiConsumer p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAcceptBothAsync(p0, p1);
  }

  @Test
  public void thenAcceptBoth_test_4136(CompletionStage p0, BiConsumer p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAcceptBoth(p0, p1);
  }

  @Test
  public void thenCombineAsync_test_4137(CompletionStage p0, BiFunction p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenCombineAsync(p0, p1, p2);
  }

  @Test
  public void thenCombineAsync_test_4138(CompletionStage p0, BiFunction p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenCombineAsync(p0, p1);
  }

  @Test
  public void thenCombine_test_4139(CompletionStage p0, BiFunction p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenCombine(p0, p1);
  }

  @Test
  public void thenRunAsync_test_4140(Runnable p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenRunAsync(p0);
  }

  @Test
  public void thenRunAsync_test_4141(Runnable p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenRunAsync(p0, p1);
  }

  @Test
  public void thenRun_test_4142(Runnable p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenRun(p0);
  }

  @Test
  public void thenAcceptAsync_test_4143(Consumer p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAcceptAsync(p0, p1);
  }

  @Test
  public void thenAcceptAsync_test_4144(Consumer p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAcceptAsync(p0);
  }

  @Test
  public void thenAccept_test_4145(Consumer p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenAccept(p0);
  }

  @Test
  public void thenApplyAsync_test_4146(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenApplyAsync(p0);
  }

  @Test
  public void thenApplyAsync_test_4147(Function p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenApplyAsync(p0, p1);
  }

  @Test
  public void thenApply_test_4148(Function p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.thenApply(p0);
  }

  @Test
  public void supplyAsync_test_4149(Supplier p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.supplyAsync(p0);
  }

  @Test
  public void supplyAsync_test_4150(Supplier p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.supplyAsync(p0, p1);
  }

  @Test
  public void runAsync_test_4151(Runnable p0, Executor p1) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.runAsync(p0, p1);
  }

  @Test
  public void runAsync_test_4152(Runnable p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.runAsync(p0);
  }

  @Test
  public void completedFuture_test_4153(Object p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.completedFuture(p0);
  }

  @Test
  public void anyOf_test_4154(CompletableFuture[] p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.anyOf(p0);
  }

  @Test
  public void isCompletedExceptionally_test_4155() {
    CompletableFuture instance = new CompletableFuture();
    instance.isCompletedExceptionally();
  }

  @Test
  public void obtrudeValue_test_4156(Object p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.obtrudeValue(p0);
  }

  @Test
  public void obtrudeException_test_4157(Throwable p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.obtrudeException(p0);
  }

  @Test
  public void getNumberOfDependents_test_4158() {
    CompletableFuture instance = new CompletableFuture();
    instance.getNumberOfDependents();
  }

  @Test
  public void minimalCompletionStage_test_4159() {
    CompletableFuture instance = new CompletableFuture();
    instance.minimalCompletionStage();
  }

  @Test
  public void orTimeout_test_4160(long p0, TimeUnit p1) {
    CompletableFuture instance = new CompletableFuture();
    instance.orTimeout(p0, p1);
  }

  @Test
  public void completeOnTimeout_test_4161(Object p0, long p1, TimeUnit p2) {
    CompletableFuture instance = new CompletableFuture();
    instance.completeOnTimeout(p0, p1, p2);
  }

  @Test
  public void delayedExecutor_test_4162(long p0, TimeUnit p1, Executor p2) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.delayedExecutor(p0, p1, p2);
  }

  @Test
  public void delayedExecutor_test_4163(long p0, TimeUnit p1) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.delayedExecutor(p0, p1);
  }

  @Test
  public void completedStage_test_4164(Object p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.completedStage(p0);
  }

  @Test
  public void failedFuture_test_4165(Throwable p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.failedFuture(p0);
  }

  @Test
  public void failedStage_test_4166(Throwable p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.failedStage(p0);
  }

  @Test
  public void toString_test_4167() {
    CompletableFuture instance = new CompletableFuture();
    instance.toString();
  }

  @Test
  public void copy_test_4168() {
    CompletableFuture instance = new CompletableFuture();
    instance.copy();
  }

  @Test
  public void join_test_4169() {
    CompletableFuture instance = new CompletableFuture();
    instance.join();
  }

  @Test
  public void state_test_4170() {
    CompletableFuture instance = new CompletableFuture();
    instance.state();
  }

  @Test
  public void isDone_test_4171() {
    CompletableFuture instance = new CompletableFuture();
    instance.isDone();
  }

  @Test
  public void cancel_test_4172(boolean p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.cancel(p0);
  }

  @Test
  public void handle_test_4173(BiFunction p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.handle(p0);
  }

  @Test
  public void complete_test_4174(Object p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.complete(p0);
  }

  @Test
  public void allOf_test_4175(CompletableFuture[] p0) {
    CompletableFuture instance = new CompletableFuture();
    CompletableFuture.allOf(p0);
  }

  @Test
  public void isCancelled_test_4176() {
    CompletableFuture instance = new CompletableFuture();
    instance.isCancelled();
  }

  @Test
  public void resultNow_test_4177() {
    CompletableFuture instance = new CompletableFuture();
    instance.resultNow();
  }

  @Test
  public void exceptionNow_test_4178() {
    CompletableFuture instance = new CompletableFuture();
    instance.exceptionNow();
  }

  @Test
  public void completeExceptionally_test_4179(Throwable p0) {
    CompletableFuture instance = new CompletableFuture();
    instance.completeExceptionally(p0);
  }
}
