package generated.test;

import java.nio.ByteBuffer;
import java.util.zip.CRC32C;
import org.junit.jupiter.api.Test;

public class CRC32CAutoTest {
  @Test
  public void reset_test_5129() {
    CRC32C instance = new CRC32C();
    instance.reset();
  }

  @Test
  public void update_test_5130(byte[] p0, int p1, int p2) {
    CRC32C instance = new CRC32C();
    instance.update(p0, p1, p2);
  }

  @Test
  public void update_test_5131(int p0) {
    CRC32C instance = new CRC32C();
    instance.update(p0);
  }

  @Test
  public void update_test_5132(ByteBuffer p0) {
    CRC32C instance = new CRC32C();
    instance.update(p0);
  }

  @Test
  public void getValue_test_5133() {
    CRC32C instance = new CRC32C();
    instance.getValue();
  }
}
