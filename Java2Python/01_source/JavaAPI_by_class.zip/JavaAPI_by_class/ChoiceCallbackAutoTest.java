package generated.test;

import java.lang.String;
import javax.security.auth.callback.ChoiceCallback;
import org.junit.jupiter.api.Test;

public class ChoiceCallbackAutoTest {
  @Test
  public void getPrompt_test_6326(String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.getPrompt();
  }

  @Test
  public void getChoices_test_6327(String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.getChoices();
  }

  @Test
  public void getDefaultChoice_test_6328(String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.getDefaultChoice();
  }

  @Test
  public void allowMultipleSelections_test_6329(String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.allowMultipleSelections();
  }

  @Test
  public void setSelectedIndex_test_6330(int p0, String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.setSelectedIndex(p0);
  }

  @Test
  public void setSelectedIndexes_test_6331(int[] p0, String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.setSelectedIndexes(p0);
  }

  @Test
  public void getSelectedIndexes_test_6332(String c0, String[] c1, int c2, boolean c3) {
    ChoiceCallback instance = new ChoiceCallback(c0, c1, c2, c3);
    instance.getSelectedIndexes();
  }
}
