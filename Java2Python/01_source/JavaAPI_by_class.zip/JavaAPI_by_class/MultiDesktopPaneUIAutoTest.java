package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiDesktopPaneUI;
import org.junit.jupiter.api.Test;

public class MultiDesktopPaneUIAutoTest {
  @Test
  public void installUI_test_9349(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9350(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9351() {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9352(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    MultiDesktopPaneUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9353(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9354(Graphics p0, JComponent p1) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9355(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9356(JComponent p0, int p1) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9357(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9358(JComponent p0) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9359(Graphics p0, JComponent p1) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9360(JComponent p0, int p1, int p2) {
    MultiDesktopPaneUI instance = new MultiDesktopPaneUI();
    instance.contains(p0, p1, p2);
  }
}
