package generated.test;

import java.beans.PropertyEditorManager;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class PropertyEditorManagerAutoTest {
  @Test
  public void registerEditor_test_1577(Class p0, Class p1) {
    PropertyEditorManager instance = new PropertyEditorManager();
    PropertyEditorManager.registerEditor(p0, p1);
  }

  @Test
  public void findEditor_test_1578(Class p0) {
    PropertyEditorManager instance = new PropertyEditorManager();
    PropertyEditorManager.findEditor(p0);
  }

  @Test
  public void getEditorSearchPath_test_1579() {
    PropertyEditorManager instance = new PropertyEditorManager();
    PropertyEditorManager.getEditorSearchPath();
  }

  @Test
  public void setEditorSearchPath_test_1580(String[] p0) {
    PropertyEditorManager instance = new PropertyEditorManager();
    PropertyEditorManager.setEditorSearchPath(p0);
  }
}
