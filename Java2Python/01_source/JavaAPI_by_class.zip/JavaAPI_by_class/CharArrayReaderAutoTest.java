package generated.test;

import java.io.CharArrayReader;
import org.junit.jupiter.api.Test;

public class CharArrayReaderAutoTest {
  @Test
  public void close_test_1715(char[] c0) {
    CharArrayReader instance = new CharArrayReader(c0);
    instance.close();
  }

  @Test
  public void markSupported_test_1716(char[] c0) {
    CharArrayReader instance = new CharArrayReader(c0);
    instance.markSupported();
  }
}
