package generated.test;

import java.lang.Class;
import java.lang.ClassLoader;
import java.lang.Object;
import java.util.Iterator;
import javax.imageio.spi.ServiceRegistry;
import org.junit.jupiter.api.Test;

public class ServiceRegistryAutoTest {
  @Test
  public void getServiceProviderByClass_test_5479(Class p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.getServiceProviderByClass(p0);
  }

  @Test
  public void deregisterServiceProvider_test_5480(Object p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.deregisterServiceProvider(p0);
  }

  @Test
  public void deregisterServiceProvider_test_5481(Object p0, Class p1, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.deregisterServiceProvider(p0, p1);
  }

  @Test
  public void getServiceProviders_test_5482(Class p0, boolean p1, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.getServiceProviders(p0, p1);
  }

  @Test
  public void getServiceProviders_test_5483(Class p0, ServiceRegistry.Filter p1, boolean p2,
      Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.getServiceProviders(p0, p1, p2);
  }

  @Test
  public void registerServiceProvider_test_5484(Object p0, Class p1, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.registerServiceProvider(p0, p1);
  }

  @Test
  public void registerServiceProvider_test_5485(Object p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.registerServiceProvider(p0);
  }

  @Test
  public void getCategories_test_5486(Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.getCategories();
  }

  @Test
  public void setOrdering_test_5487(Class p0, Object p1, Object p2, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.setOrdering(p0, p1, p2);
  }

  @Test
  public void unsetOrdering_test_5488(Class p0, Object p1, Object p2, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.unsetOrdering(p0, p1, p2);
  }

  @Test
  public void deregisterAll_test_5489(Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.deregisterAll();
  }

  @Test
  public void deregisterAll_test_5490(Class p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.deregisterAll(p0);
  }

  @Test
  public void lookupProviders_test_5491(Class p0, ClassLoader p1, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    ServiceRegistry.lookupProviders(p0, p1);
  }

  @Test
  public void lookupProviders_test_5492(Class p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    ServiceRegistry.lookupProviders(p0);
  }

  @Test
  public void registerServiceProviders_test_5493(Iterator p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.registerServiceProviders(p0);
  }

  @Test
  public void contains_test_5494(Object p0, Iterator c0) {
    ServiceRegistry instance = new ServiceRegistry(c0);
    instance.contains(p0);
  }
}
