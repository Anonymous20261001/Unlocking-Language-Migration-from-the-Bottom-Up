package generated.test;

import java.lang.Object;
import java.security.CodeSigner;
import java.security.Timestamp;
import java.security.cert.CertPath;
import org.junit.jupiter.api.Test;

public class CodeSignerAutoTest {
  @Test
  public void equals_test_2684(Object p0, CertPath c0, Timestamp c1) {
    CodeSigner instance = new CodeSigner(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2685(CertPath c0, Timestamp c1) {
    CodeSigner instance = new CodeSigner(c0, c1);
    instance.toString();
  }

  @Test
  public void hashCode_test_2686(CertPath c0, Timestamp c1) {
    CodeSigner instance = new CodeSigner(c0, c1);
    instance.hashCode();
  }

  @Test
  public void getSignerCertPath_test_2687(CertPath c0, Timestamp c1) {
    CodeSigner instance = new CodeSigner(c0, c1);
    instance.getSignerCertPath();
  }

  @Test
  public void getTimestamp_test_2688(CertPath c0, Timestamp c1) {
    CodeSigner instance = new CodeSigner(c0, c1);
    instance.getTimestamp();
  }
}
