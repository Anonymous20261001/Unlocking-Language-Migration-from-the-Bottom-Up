package generated.test;

import java.io.InputStream;
import java.io.LineNumberInputStream;
import org.junit.jupiter.api.Test;

public class LineNumberInputStreamAutoTest {
  @Test
  public void mark_test_1784(int p0, InputStream c0) {
    LineNumberInputStream instance = new LineNumberInputStream(c0);
    instance.mark(p0);
  }

  @Test
  public void getLineNumber_test_1785(InputStream c0) {
    LineNumberInputStream instance = new LineNumberInputStream(c0);
    instance.getLineNumber();
  }

  @Test
  public void setLineNumber_test_1786(int p0, InputStream c0) {
    LineNumberInputStream instance = new LineNumberInputStream(c0);
    instance.setLineNumber(p0);
  }
}
