package generated.test;

import java.lang.Object;
import java.util.concurrent.atomic.AtomicMarkableReference;
import org.junit.jupiter.api.Test;

public class AtomicMarkableReferenceAutoTest {
  @Test
  public void isMarked_test_4882(Object c0, boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.isMarked();
  }

  @Test
  public void attemptMark_test_4883(Object p0, boolean p1, Object c0, boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.attemptMark(p0, p1);
  }

  @Test
  public void get_test_4884(boolean[] p0, Object c0, boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.get(p0);
  }

  @Test
  public void getReference_test_4885(Object c0, boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.getReference();
  }

  @Test
  public void set_test_4886(Object p0, boolean p1, Object c0, boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.set(p0, p1);
  }

  @Test
  public void compareAndSet_test_4887(Object p0, Object p1, boolean p2, boolean p3, Object c0,
      boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.compareAndSet(p0, p1, p2, p3);
  }

  @Test
  public void weakCompareAndSet_test_4888(Object p0, Object p1, boolean p2, boolean p3, Object c0,
      boolean c1) {
    AtomicMarkableReference instance = new AtomicMarkableReference(c0, c1);
    instance.weakCompareAndSet(p0, p1, p2, p3);
  }
}
