package generated.test;

import java.lang.Object;
import java.util.Observable;
import java.util.Observer;
import org.junit.jupiter.api.Test;

public class ObservableAutoTest {
  @Test
  public void notifyObservers_test_3711(Object p0) {
    Observable instance = new Observable();
    instance.notifyObservers(p0);
  }

  @Test
  public void notifyObservers_test_3712() {
    Observable instance = new Observable();
    instance.notifyObservers();
  }

  @Test
  public void addObserver_test_3713(Observer p0) {
    Observable instance = new Observable();
    instance.addObserver(p0);
  }

  @Test
  public void deleteObserver_test_3714(Observer p0) {
    Observable instance = new Observable();
    instance.deleteObserver(p0);
  }

  @Test
  public void deleteObservers_test_3715() {
    Observable instance = new Observable();
    instance.deleteObservers();
  }

  @Test
  public void hasChanged_test_3716() {
    Observable instance = new Observable();
    instance.hasChanged();
  }

  @Test
  public void countObservers_test_3717() {
    Observable instance = new Observable();
    instance.countObservers();
  }
}
