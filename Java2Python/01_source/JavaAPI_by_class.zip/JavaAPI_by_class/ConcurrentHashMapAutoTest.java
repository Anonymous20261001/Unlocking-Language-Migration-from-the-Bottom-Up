package generated.test;

import java.lang.Object;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.DoubleBinaryOperator;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.LongBinaryOperator;
import java.util.function.ToDoubleBiFunction;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntBiFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongBiFunction;
import java.util.function.ToLongFunction;
import org.junit.jupiter.api.Test;

public class ConcurrentHashMapAutoTest {
  @Test
  public void remove_test_4180(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.remove(p0);
  }

  @Test
  public void remove_test_4181(Object p0, Object p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.remove(p0, p1);
  }

  @Test
  public void size_test_4182() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.size();
  }

  @Test
  public void get_test_4183(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.get(p0);
  }

  @Test
  public void put_test_4184(Object p0, Object p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.put(p0, p1);
  }

  @Test
  public void equals_test_4185(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.equals(p0);
  }

  @Test
  public void toString_test_4186() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.toString();
  }

  @Test
  public void values_test_4187() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.values();
  }

  @Test
  public void hashCode_test_4188() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.hashCode();
  }

  @Test
  public void clear_test_4189() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.clear();
  }

  @Test
  public void isEmpty_test_4190() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.isEmpty();
  }

  @Test
  public void replace_test_4191(Object p0, Object p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.replace(p0, p1);
  }

  @Test
  public void replace_test_4192(Object p0, Object p1, Object p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.replace(p0, p1, p2);
  }

  @Test
  public void replaceAll_test_4193(BiFunction p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.replaceAll(p0);
  }

  @Test
  public void contains_test_4194(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.contains(p0);
  }

  @Test
  public void elements_test_4195() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.elements();
  }

  @Test
  public void merge_test_4196(Object p0, Object p1, BiFunction p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.merge(p0, p1, p2);
  }

  @Test
  public void entrySet_test_4197() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.entrySet();
  }

  @Test
  public void putAll_test_4198(Map p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.putAll(p0);
  }

  @Test
  public void putIfAbsent_test_4199(Object p0, Object p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.putIfAbsent(p0, p1);
  }

  @Test
  public void compute_test_4200(Object p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.compute(p0, p1);
  }

  @Test
  public void computeIfAbsent_test_4201(Object p0, Function p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.computeIfAbsent(p0, p1);
  }

  @Test
  public void forEach_test_4202(long p0, BiFunction p1, Consumer p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEach(p0, p1, p2);
  }

  @Test
  public void forEach_test_4203(long p0, BiConsumer p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEach(p0, p1);
  }

  @Test
  public void forEach_test_4204(BiConsumer p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEach(p0);
  }

  @Test
  public void keys_test_4205() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.keys();
  }

  @Test
  public void keySet_test_4206(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.keySet(p0);
  }

  @Test
  public void keySet_test_4207() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.keySet();
  }

  @Test
  public void containsValue_test_4208(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_4209(Object p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.containsKey(p0);
  }

  @Test
  public void getOrDefault_test_4210(Object p0, Object p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.getOrDefault(p0, p1);
  }

  @Test
  public void computeIfPresent_test_4211(Object p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.computeIfPresent(p0, p1);
  }

  @Test
  public void mappingCount_test_4212() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.mappingCount();
  }

  @Test
  public void newKeySet_test_4213(int p0) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    ConcurrentHashMap.newKeySet(p0);
  }

  @Test
  public void newKeySet_test_4214() {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    ConcurrentHashMap.newKeySet();
  }

  @Test
  public void search_test_4215(long p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.search(p0, p1);
  }

  @Test
  public void reduce_test_4216(long p0, BiFunction p1, BiFunction p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduce(p0, p1, p2);
  }

  @Test
  public void reduceToDouble_test_4217(long p0, ToDoubleBiFunction p1, double p2,
      DoubleBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceToDouble(p0, p1, p2, p3);
  }

  @Test
  public void reduceToLong_test_4218(long p0, ToLongBiFunction p1, long p2, LongBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceToLong(p0, p1, p2, p3);
  }

  @Test
  public void reduceToInt_test_4219(long p0, ToIntBiFunction p1, int p2, IntBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceToInt(p0, p1, p2, p3);
  }

  @Test
  public void forEachKey_test_4220(long p0, Consumer p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachKey(p0, p1);
  }

  @Test
  public void forEachKey_test_4221(long p0, Function p1, Consumer p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachKey(p0, p1, p2);
  }

  @Test
  public void searchKeys_test_4222(long p0, Function p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.searchKeys(p0, p1);
  }

  @Test
  public void reduceKeys_test_4223(long p0, Function p1, BiFunction p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceKeys(p0, p1, p2);
  }

  @Test
  public void reduceKeys_test_4224(long p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceKeys(p0, p1);
  }

  @Test
  public void reduceKeysToDouble_test_4225(long p0, ToDoubleFunction p1, double p2,
      DoubleBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceKeysToDouble(p0, p1, p2, p3);
  }

  @Test
  public void reduceKeysToLong_test_4226(long p0, ToLongFunction p1, long p2,
      LongBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceKeysToLong(p0, p1, p2, p3);
  }

  @Test
  public void reduceKeysToInt_test_4227(long p0, ToIntFunction p1, int p2, IntBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceKeysToInt(p0, p1, p2, p3);
  }

  @Test
  public void forEachValue_test_4228(long p0, Function p1, Consumer p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachValue(p0, p1, p2);
  }

  @Test
  public void forEachValue_test_4229(long p0, Consumer p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachValue(p0, p1);
  }

  @Test
  public void searchValues_test_4230(long p0, Function p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.searchValues(p0, p1);
  }

  @Test
  public void reduceValues_test_4231(long p0, Function p1, BiFunction p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceValues(p0, p1, p2);
  }

  @Test
  public void reduceValues_test_4232(long p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceValues(p0, p1);
  }

  @Test
  public void reduceValuesToDouble_test_4233(long p0, ToDoubleFunction p1, double p2,
      DoubleBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceValuesToDouble(p0, p1, p2, p3);
  }

  @Test
  public void reduceValuesToLong_test_4234(long p0, ToLongFunction p1, long p2,
      LongBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceValuesToLong(p0, p1, p2, p3);
  }

  @Test
  public void reduceValuesToInt_test_4235(long p0, ToIntFunction p1, int p2, IntBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceValuesToInt(p0, p1, p2, p3);
  }

  @Test
  public void forEachEntry_test_4236(long p0, Consumer p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachEntry(p0, p1);
  }

  @Test
  public void forEachEntry_test_4237(long p0, Function p1, Consumer p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.forEachEntry(p0, p1, p2);
  }

  @Test
  public void searchEntries_test_4238(long p0, Function p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.searchEntries(p0, p1);
  }

  @Test
  public void reduceEntries_test_4239(long p0, BiFunction p1) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceEntries(p0, p1);
  }

  @Test
  public void reduceEntries_test_4240(long p0, Function p1, BiFunction p2) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceEntries(p0, p1, p2);
  }

  @Test
  public void reduceEntriesToDouble_test_4241(long p0, ToDoubleFunction p1, double p2,
      DoubleBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceEntriesToDouble(p0, p1, p2, p3);
  }

  @Test
  public void reduceEntriesToLong_test_4242(long p0, ToLongFunction p1, long p2,
      LongBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceEntriesToLong(p0, p1, p2, p3);
  }

  @Test
  public void reduceEntriesToInt_test_4243(long p0, ToIntFunction p1, int p2,
      IntBinaryOperator p3) {
    ConcurrentHashMap instance = new ConcurrentHashMap();
    instance.reduceEntriesToInt(p0, p1, p2, p3);
  }
}
