package generated.test;

import java.lang.String;
import javax.management.BadStringOperationException;
import org.junit.jupiter.api.Test;

public class BadStringOperationExceptionAutoTest {
  @Test
  public void toString_test_5548(String c0) {
    BadStringOperationException instance = new BadStringOperationException(c0);
    instance.toString();
  }
}
