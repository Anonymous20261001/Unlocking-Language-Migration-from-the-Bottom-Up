package generated.test;

import java.lang.String;
import javax.swing.JPasswordField;
import org.junit.jupiter.api.Test;

public class JPasswordFieldAutoTest {
  @Test
  public void cut_test_7448() {
    JPasswordField instance = new JPasswordField();
    instance.cut();
  }

  @Test
  public void getUIClassID_test_7449() {
    JPasswordField instance = new JPasswordField();
    instance.getUIClassID();
  }

  @Test
  public void getPassword_test_7450() {
    JPasswordField instance = new JPasswordField();
    instance.getPassword();
  }

  @Test
  public void getAccessibleContext_test_7451() {
    JPasswordField instance = new JPasswordField();
    instance.getAccessibleContext();
  }

  @Test
  public void updateUI_test_7452() {
    JPasswordField instance = new JPasswordField();
    instance.updateUI();
  }

  @Test
  public void setText_test_7453(String p0) {
    JPasswordField instance = new JPasswordField();
    instance.setText(p0);
  }

  @Test
  public void setEchoChar_test_7454(char p0) {
    JPasswordField instance = new JPasswordField();
    instance.setEchoChar(p0);
  }

  @Test
  public void getEchoChar_test_7455() {
    JPasswordField instance = new JPasswordField();
    instance.getEchoChar();
  }

  @Test
  public void echoCharIsSet_test_7456() {
    JPasswordField instance = new JPasswordField();
    instance.echoCharIsSet();
  }

  @Test
  public void copy_test_7457() {
    JPasswordField instance = new JPasswordField();
    instance.copy();
  }

  @Test
  public void getText_test_7458() {
    JPasswordField instance = new JPasswordField();
    instance.getText();
  }
}
