package generated.test;

import javax.lang.model.type.MirroredTypeException;
import javax.lang.model.type.TypeMirror;
import org.junit.jupiter.api.Test;

public class MirroredTypeExceptionAutoTest {
  @Test
  public void getTypeMirror_test_5514(TypeMirror c0) {
    MirroredTypeException instance = new MirroredTypeException(c0);
    instance.getTypeMirror();
  }
}
