package generated.test;

import java.awt.RenderingHints;
import java.awt.image.renderable.ContextualRenderedImageFactory;
import java.awt.image.renderable.ParameterBlock;
import java.awt.image.renderable.RenderContext;
import java.awt.image.renderable.RenderableImageOp;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class RenderableImageOpAutoTest {
  @Test
  public void isDynamic_test_1465(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.isDynamic();
  }

  @Test
  public void createRendering_test_1466(RenderContext p0, ContextualRenderedImageFactory c0,
      ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.createRendering(p0);
  }

  @Test
  public void setParameterBlock_test_1467(ParameterBlock p0, ContextualRenderedImageFactory c0,
      ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.setParameterBlock(p0);
  }

  @Test
  public void getParameterBlock_test_1468(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getParameterBlock();
  }

  @Test
  public void createScaledRendering_test_1469(int p0, int p1, RenderingHints p2,
      ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.createScaledRendering(p0, p1, p2);
  }

  @Test
  public void createDefaultRendering_test_1470(ContextualRenderedImageFactory c0,
      ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.createDefaultRendering();
  }

  @Test
  public void getSources_test_1471(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getSources();
  }

  @Test
  public void getPropertyNames_test_1472(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getPropertyNames();
  }

  @Test
  public void getWidth_test_1473(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getWidth();
  }

  @Test
  public void getHeight_test_1474(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getHeight();
  }

  @Test
  public void getMinX_test_1475(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getMinX();
  }

  @Test
  public void getMinY_test_1476(ContextualRenderedImageFactory c0, ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getMinY();
  }

  @Test
  public void getProperty_test_1477(String p0, ContextualRenderedImageFactory c0,
      ParameterBlock c1) {
    RenderableImageOp instance = new RenderableImageOp(c0, c1);
    instance.getProperty(p0);
  }
}
