package generated.test;

import java.util.Locale;
import javax.security.auth.callback.LanguageCallback;
import org.junit.jupiter.api.Test;

public class LanguageCallbackAutoTest {
  @Test
  public void getLocale_test_6340() {
    LanguageCallback instance = new LanguageCallback();
    instance.getLocale();
  }

  @Test
  public void setLocale_test_6341(Locale p0) {
    LanguageCallback instance = new LanguageCallback();
    instance.setLocale(p0);
  }
}
