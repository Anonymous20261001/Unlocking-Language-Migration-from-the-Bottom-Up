package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalLabelUI;
import org.junit.jupiter.api.Test;

public class MetalLabelUIAutoTest {
  @Test
  public void createUI_test_9173(JComponent p0) {
    MetalLabelUI instance = new MetalLabelUI();
    MetalLabelUI.createUI(p0);
  }
}
