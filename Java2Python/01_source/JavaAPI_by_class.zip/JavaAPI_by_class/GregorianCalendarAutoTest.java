package generated.test;

import java.lang.Object;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import org.junit.jupiter.api.Test;

public class GregorianCalendarAutoTest {
  @Test
  public void equals_test_3454(Object p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_3455() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.hashCode();
  }

  @Test
  public void clone_test_3456() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.clone();
  }

  @Test
  public void add_test_3457(int p0, int p1) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.add(p0, p1);
  }

  @Test
  public void from_test_3458(ZonedDateTime p0) {
    GregorianCalendar instance = new GregorianCalendar();
    GregorianCalendar.from(p0);
  }

  @Test
  public void setTimeZone_test_3459(TimeZone p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.setTimeZone(p0);
  }

  @Test
  public void getTimeZone_test_3460() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getTimeZone();
  }

  @Test
  public void isWeekDateSupported_test_3461() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.isWeekDateSupported();
  }

  @Test
  public void getWeekYear_test_3462() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getWeekYear();
  }

  @Test
  public void getMaximum_test_3463(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getMaximum(p0);
  }

  @Test
  public void getLeastMaximum_test_3464(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getLeastMaximum(p0);
  }

  @Test
  public void isLeapYear_test_3465(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.isLeapYear(p0);
  }

  @Test
  public void getCalendarType_test_3466() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getCalendarType();
  }

  @Test
  public void getMinimum_test_3467(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getMinimum(p0);
  }

  @Test
  public void roll_test_3468(int p0, boolean p1) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.roll(p0, p1);
  }

  @Test
  public void roll_test_3469(int p0, int p1) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.roll(p0, p1);
  }

  @Test
  public void getGreatestMinimum_test_3470(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getGreatestMinimum(p0);
  }

  @Test
  public void setWeekDate_test_3471(int p0, int p1, int p2) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.setWeekDate(p0, p1, p2);
  }

  @Test
  public void getWeeksInWeekYear_test_3472() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getWeeksInWeekYear();
  }

  @Test
  public void getActualMinimum_test_3473(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getActualMinimum(p0);
  }

  @Test
  public void getActualMaximum_test_3474(int p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getActualMaximum(p0);
  }

  @Test
  public void setGregorianChange_test_3475(Date p0) {
    GregorianCalendar instance = new GregorianCalendar();
    instance.setGregorianChange(p0);
  }

  @Test
  public void getGregorianChange_test_3476() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.getGregorianChange();
  }

  @Test
  public void toZonedDateTime_test_3477() {
    GregorianCalendar instance = new GregorianCalendar();
    instance.toZonedDateTime();
  }
}
