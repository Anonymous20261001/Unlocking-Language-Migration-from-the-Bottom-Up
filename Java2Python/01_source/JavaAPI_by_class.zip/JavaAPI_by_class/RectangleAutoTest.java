package generated.test;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class RectangleAutoTest {
  @Test
  public void translate_test_473(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.translate(p0, p1);
  }

  @Test
  public void getX_test_474() {
    Rectangle instance = new Rectangle();
    instance.getX();
  }

  @Test
  public void getY_test_475() {
    Rectangle instance = new Rectangle();
    instance.getY();
  }

  @Test
  public void getWidth_test_476() {
    Rectangle instance = new Rectangle();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_477() {
    Rectangle instance = new Rectangle();
    instance.getHeight();
  }

  @Test
  public void setBounds_test_478(int p0, int p1, int p2, int p3) {
    Rectangle instance = new Rectangle();
    instance.setBounds(p0, p1, p2, p3);
  }

  @Test
  public void setBounds_test_479(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.setBounds(p0);
  }

  @Test
  public void setLocation_test_480(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.setLocation(p0, p1);
  }

  @Test
  public void setLocation_test_481(Point p0) {
    Rectangle instance = new Rectangle();
    instance.setLocation(p0);
  }

  @Test
  public void intersection_test_482(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.intersection(p0);
  }

  @Test
  public void reshape_test_483(int p0, int p1, int p2, int p3) {
    Rectangle instance = new Rectangle();
    instance.reshape(p0, p1, p2, p3);
  }

  @Test
  public void inside_test_484(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.inside(p0, p1);
  }

  @Test
  public void getBounds2D_test_485() {
    Rectangle instance = new Rectangle();
    instance.getBounds2D();
  }

  @Test
  public void setRect_test_486(double p0, double p1, double p2, double p3) {
    Rectangle instance = new Rectangle();
    instance.setRect(p0, p1, p2, p3);
  }

  @Test
  public void outcode_test_487(double p0, double p1) {
    Rectangle instance = new Rectangle();
    instance.outcode(p0, p1);
  }

  @Test
  public void createIntersection_test_488(Rectangle2D p0) {
    Rectangle instance = new Rectangle();
    instance.createIntersection(p0);
  }

  @Test
  public void createUnion_test_489(Rectangle2D p0) {
    Rectangle instance = new Rectangle();
    instance.createUnion(p0);
  }

  @Test
  public void equals_test_490(Object p0) {
    Rectangle instance = new Rectangle();
    instance.equals(p0);
  }

  @Test
  public void toString_test_491() {
    Rectangle instance = new Rectangle();
    instance.toString();
  }

  @Test
  public void isEmpty_test_492() {
    Rectangle instance = new Rectangle();
    instance.isEmpty();
  }

  @Test
  public void add_test_493(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.add(p0);
  }

  @Test
  public void add_test_494(Point p0) {
    Rectangle instance = new Rectangle();
    instance.add(p0);
  }

  @Test
  public void add_test_495(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.add(p0, p1);
  }

  @Test
  public void contains_test_496(Point p0) {
    Rectangle instance = new Rectangle();
    instance.contains(p0);
  }

  @Test
  public void contains_test_497(int p0, int p1, int p2, int p3) {
    Rectangle instance = new Rectangle();
    instance.contains(p0, p1, p2, p3);
  }

  @Test
  public void contains_test_498(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.contains(p0, p1);
  }

  @Test
  public void contains_test_499(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.contains(p0);
  }

  @Test
  public void getBounds_test_500() {
    Rectangle instance = new Rectangle();
    instance.getBounds();
  }

  @Test
  public void getLocation_test_501() {
    Rectangle instance = new Rectangle();
    instance.getLocation();
  }

  @Test
  public void getSize_test_502() {
    Rectangle instance = new Rectangle();
    instance.getSize();
  }

  @Test
  public void grow_test_503(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.grow(p0, p1);
  }

  @Test
  public void resize_test_504(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.resize(p0, p1);
  }

  @Test
  public void move_test_505(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.move(p0, p1);
  }

  @Test
  public void intersects_test_506(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.intersects(p0);
  }

  @Test
  public void setSize_test_507(Dimension p0) {
    Rectangle instance = new Rectangle();
    instance.setSize(p0);
  }

  @Test
  public void setSize_test_508(int p0, int p1) {
    Rectangle instance = new Rectangle();
    instance.setSize(p0, p1);
  }

  @Test
  public void union_test_509(Rectangle p0) {
    Rectangle instance = new Rectangle();
    instance.union(p0);
  }
}
