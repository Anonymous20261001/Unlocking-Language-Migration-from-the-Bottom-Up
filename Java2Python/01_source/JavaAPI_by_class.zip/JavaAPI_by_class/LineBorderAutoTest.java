package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.LineBorder;
import org.junit.jupiter.api.Test;

public class LineBorderAutoTest {
  @Test
  public void paintBorder_test_8476(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
      Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8477(Component p0, Insets p1, Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.getBorderInsets(p0, p1);
  }

  @Test
  public void isBorderOpaque_test_8478(Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.isBorderOpaque();
  }

  @Test
  public void createBlackLineBorder_test_8479(Color c0) {
    LineBorder instance = new LineBorder(c0);
    LineBorder.createBlackLineBorder();
  }

  @Test
  public void createGrayLineBorder_test_8480(Color c0) {
    LineBorder instance = new LineBorder(c0);
    LineBorder.createGrayLineBorder();
  }

  @Test
  public void getLineColor_test_8481(Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.getLineColor();
  }

  @Test
  public void getThickness_test_8482(Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.getThickness();
  }

  @Test
  public void getRoundedCorners_test_8483(Color c0) {
    LineBorder instance = new LineBorder(c0);
    instance.getRoundedCorners();
  }
}
