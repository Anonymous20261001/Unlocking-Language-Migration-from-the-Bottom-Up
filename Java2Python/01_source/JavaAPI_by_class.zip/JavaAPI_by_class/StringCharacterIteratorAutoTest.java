package generated.test;

import java.lang.Object;
import java.lang.String;
import java.text.StringCharacterIterator;
import org.junit.jupiter.api.Test;

public class StringCharacterIteratorAutoTest {
  @Test
  public void setText_test_3218(String p0, String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.setText(p0);
  }

  @Test
  public void equals_test_3219(Object p0, String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_3220(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_3221(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.clone();
  }

  @Test
  public void next_test_3222(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.next();
  }

  @Test
  public void last_test_3223(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.last();
  }

  @Test
  public void first_test_3224(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.first();
  }

  @Test
  public void current_test_3225(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.current();
  }

  @Test
  public void previous_test_3226(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.previous();
  }

  @Test
  public void getIndex_test_3227(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.getIndex();
  }

  @Test
  public void getBeginIndex_test_3228(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.getBeginIndex();
  }

  @Test
  public void getEndIndex_test_3229(String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.getEndIndex();
  }

  @Test
  public void setIndex_test_3230(int p0, String c0) {
    StringCharacterIterator instance = new StringCharacterIterator(c0);
    instance.setIndex(p0);
  }
}
