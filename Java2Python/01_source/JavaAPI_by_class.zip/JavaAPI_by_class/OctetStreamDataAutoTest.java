package generated.test;

import java.io.InputStream;
import javax.xml.crypto.OctetStreamData;
import org.junit.jupiter.api.Test;

public class OctetStreamDataAutoTest {
  @Test
  public void getMimeType_test_10865(InputStream c0) {
    OctetStreamData instance = new OctetStreamData(c0);
    instance.getMimeType();
  }

  @Test
  public void getOctetStream_test_10866(InputStream c0) {
    OctetStreamData instance = new OctetStreamData(c0);
    instance.getOctetStream();
  }

  @Test
  public void getURI_test_10867(InputStream c0) {
    OctetStreamData instance = new OctetStreamData(c0);
    instance.getURI();
  }
}
