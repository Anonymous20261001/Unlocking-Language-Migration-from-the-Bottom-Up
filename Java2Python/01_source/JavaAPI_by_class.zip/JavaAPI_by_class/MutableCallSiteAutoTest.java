package generated.test;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import org.junit.jupiter.api.Test;

public class MutableCallSiteAutoTest {
  @Test
  public void getTarget_test_2381(MethodType c0) {
    MutableCallSite instance = new MutableCallSite(c0);
    instance.getTarget();
  }

  @Test
  public void dynamicInvoker_test_2382(MethodType c0) {
    MutableCallSite instance = new MutableCallSite(c0);
    instance.dynamicInvoker();
  }

  @Test
  public void setTarget_test_2383(MethodHandle p0, MethodType c0) {
    MutableCallSite instance = new MutableCallSite(c0);
    instance.setTarget(p0);
  }

  @Test
  public void syncAll_test_2384(MutableCallSite[] p0, MethodType c0) {
    MutableCallSite instance = new MutableCallSite(c0);
    MutableCallSite.syncAll(p0);
  }
}
