package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class GridBagLayoutAutoTest {
  @Test
  public void removeLayoutComponent_test_317(Component p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_318(String p0, Component p1) {
    GridBagLayout instance = new GridBagLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void addLayoutComponent_test_319(Component p0, Object p1) {
    GridBagLayout instance = new GridBagLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_320(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.layoutContainer(p0);
  }

  @Test
  public void invalidateLayout_test_321(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.invalidateLayout(p0);
  }

  @Test
  public void preferredLayoutSize_test_322(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_323(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void maximumLayoutSize_test_324(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.maximumLayoutSize(p0);
  }

  @Test
  public void getLayoutAlignmentX_test_325(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.getLayoutAlignmentX(p0);
  }

  @Test
  public void getLayoutAlignmentY_test_326(Container p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.getLayoutAlignmentY(p0);
  }

  @Test
  public void getConstraints_test_327(Component p0) {
    GridBagLayout instance = new GridBagLayout();
    instance.getConstraints(p0);
  }

  @Test
  public void setConstraints_test_328(Component p0, GridBagConstraints p1) {
    GridBagLayout instance = new GridBagLayout();
    instance.setConstraints(p0, p1);
  }

  @Test
  public void getLayoutOrigin_test_329() {
    GridBagLayout instance = new GridBagLayout();
    instance.getLayoutOrigin();
  }

  @Test
  public void getLayoutDimensions_test_330() {
    GridBagLayout instance = new GridBagLayout();
    instance.getLayoutDimensions();
  }

  @Test
  public void getLayoutWeights_test_331() {
    GridBagLayout instance = new GridBagLayout();
    instance.getLayoutWeights();
  }

  @Test
  public void toString_test_332() {
    GridBagLayout instance = new GridBagLayout();
    instance.toString();
  }

  @Test
  public void location_test_333(int p0, int p1) {
    GridBagLayout instance = new GridBagLayout();
    instance.location(p0, p1);
  }
}
