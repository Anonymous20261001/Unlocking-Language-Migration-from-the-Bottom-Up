package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalComboBoxIcon;
import org.junit.jupiter.api.Test;

public class MetalComboBoxIconAutoTest {
  @Test
  public void getIconWidth_test_9106() {
    MetalComboBoxIcon instance = new MetalComboBoxIcon();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_9107() {
    MetalComboBoxIcon instance = new MetalComboBoxIcon();
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_9108(Component p0, Graphics p1, int p2, int p3) {
    MetalComboBoxIcon instance = new MetalComboBoxIcon();
    instance.paintIcon(p0, p1, p2, p3);
  }
}
