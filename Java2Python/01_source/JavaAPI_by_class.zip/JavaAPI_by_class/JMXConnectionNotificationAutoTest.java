package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.remote.JMXConnectionNotification;
import org.junit.jupiter.api.Test;

public class JMXConnectionNotificationAutoTest {
  @Test
  public void getConnectionId_test_5833(String c0, Object c1, String c2, long c3, String c4,
      Object c5) {
    JMXConnectionNotification instance = new JMXConnectionNotification(c0, c1, c2, c3, c4, c5);
    instance.getConnectionId();
  }
}
