package generated.test;

import java.awt.Point;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DropTargetContext;
import java.awt.dnd.DropTargetDragEvent;
import org.junit.jupiter.api.Test;

public class DropTargetDragEventAutoTest {
  @Test
  public void getSourceActions_test_718(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getSourceActions();
  }

  @Test
  public void getTransferable_test_719(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getTransferable();
  }

  @Test
  public void getDropAction_test_720(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getDropAction();
  }

  @Test
  public void acceptDrag_test_721(int p0, DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.acceptDrag(p0);
  }

  @Test
  public void rejectDrag_test_722(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.rejectDrag();
  }

  @Test
  public void getCurrentDataFlavors_test_723(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getCurrentDataFlavors();
  }

  @Test
  public void getCurrentDataFlavorsAsList_test_724(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getCurrentDataFlavorsAsList();
  }

  @Test
  public void isDataFlavorSupported_test_725(DataFlavor p0, DropTargetContext c0, Point c1, int c2,
      int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.isDataFlavorSupported(p0);
  }

  @Test
  public void getLocation_test_726(DropTargetContext c0, Point c1, int c2, int c3) {
    DropTargetDragEvent instance = new DropTargetDragEvent(c0, c1, c2, c3);
    instance.getLocation();
  }
}
