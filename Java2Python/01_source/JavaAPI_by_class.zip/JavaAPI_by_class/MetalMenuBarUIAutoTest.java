package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalMenuBarUI;
import org.junit.jupiter.api.Test;

public class MetalMenuBarUIAutoTest {
  @Test
  public void installUI_test_9229(JComponent p0) {
    MetalMenuBarUI instance = new MetalMenuBarUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9230(JComponent p0) {
    MetalMenuBarUI instance = new MetalMenuBarUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_9231(JComponent p0) {
    MetalMenuBarUI instance = new MetalMenuBarUI();
    MetalMenuBarUI.createUI(p0);
  }

  @Test
  public void update_test_9232(Graphics p0, JComponent p1) {
    MetalMenuBarUI instance = new MetalMenuBarUI();
    instance.update(p0, p1);
  }
}
