package generated.test;

import java.sql.BatchUpdateException;
import org.junit.jupiter.api.Test;

public class BatchUpdateExceptionAutoTest {
  @Test
  public void getLargeUpdateCounts_test_2937() {
    BatchUpdateException instance = new BatchUpdateException();
    instance.getLargeUpdateCounts();
  }

  @Test
  public void getUpdateCounts_test_2938() {
    BatchUpdateException instance = new BatchUpdateException();
    instance.getUpdateCounts();
  }
}
