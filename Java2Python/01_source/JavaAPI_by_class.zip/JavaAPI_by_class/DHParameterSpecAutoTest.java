package generated.test;

import java.math.BigInteger;
import javax.crypto.spec.DHParameterSpec;
import org.junit.jupiter.api.Test;

public class DHParameterSpecAutoTest {
  @Test
  public void getL_test_5238(BigInteger c0, BigInteger c1) {
    DHParameterSpec instance = new DHParameterSpec(c0, c1);
    instance.getL();
  }

  @Test
  public void getP_test_5239(BigInteger c0, BigInteger c1) {
    DHParameterSpec instance = new DHParameterSpec(c0, c1);
    instance.getP();
  }

  @Test
  public void getG_test_5240(BigInteger c0, BigInteger c1) {
    DHParameterSpec instance = new DHParameterSpec(c0, c1);
    instance.getG();
  }
}
