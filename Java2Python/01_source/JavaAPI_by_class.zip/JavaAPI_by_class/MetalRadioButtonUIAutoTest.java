package generated.test;

import java.awt.Graphics;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalRadioButtonUI;
import org.junit.jupiter.api.Test;

public class MetalRadioButtonUIAutoTest {
  @Test
  public void createUI_test_9239(JComponent p0) {
    MetalRadioButtonUI instance = new MetalRadioButtonUI();
    MetalRadioButtonUI.createUI(p0);
  }

  @Test
  public void installDefaults_test_9240(AbstractButton p0) {
    MetalRadioButtonUI instance = new MetalRadioButtonUI();
    instance.installDefaults(p0);
  }

  @Test
  public void paint_test_9241(Graphics p0, JComponent p1) {
    MetalRadioButtonUI instance = new MetalRadioButtonUI();
    instance.paint(p0, p1);
  }
}
