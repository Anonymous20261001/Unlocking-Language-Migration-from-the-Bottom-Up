package generated.test;

import javax.management.remote.NotificationResult;
import javax.management.remote.TargetedNotification;
import org.junit.jupiter.api.Test;

public class NotificationResultAutoTest {
  @Test
  public void getEarliestSequenceNumber_test_5840(long c0, long c1, TargetedNotification[] c2) {
    NotificationResult instance = new NotificationResult(c0, c1, c2);
    instance.getEarliestSequenceNumber();
  }

  @Test
  public void getNextSequenceNumber_test_5841(long c0, long c1, TargetedNotification[] c2) {
    NotificationResult instance = new NotificationResult(c0, c1, c2);
    instance.getNextSequenceNumber();
  }

  @Test
  public void getTargetedNotifications_test_5842(long c0, long c1, TargetedNotification[] c2) {
    NotificationResult instance = new NotificationResult(c0, c1, c2);
    instance.getTargetedNotifications();
  }

  @Test
  public void toString_test_5843(long c0, long c1, TargetedNotification[] c2) {
    NotificationResult instance = new NotificationResult(c0, c1, c2);
    instance.toString();
  }
}
