package generated.test;

import javax.xml.stream.FactoryConfigurationError;
import org.junit.jupiter.api.Test;

public class FactoryConfigurationErrorAutoTest {
  @Test
  public void getCause_test_10909() {
    FactoryConfigurationError instance = new FactoryConfigurationError();
    instance.getCause();
  }

  @Test
  public void getMessage_test_10910() {
    FactoryConfigurationError instance = new FactoryConfigurationError();
    instance.getMessage();
  }

  @Test
  public void getException_test_10911() {
    FactoryConfigurationError instance = new FactoryConfigurationError();
    instance.getException();
  }
}
