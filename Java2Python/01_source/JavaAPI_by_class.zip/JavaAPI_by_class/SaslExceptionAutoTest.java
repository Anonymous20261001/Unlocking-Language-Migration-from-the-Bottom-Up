package generated.test;

import java.lang.Throwable;
import javax.security.sasl.SaslException;
import org.junit.jupiter.api.Test;

public class SaslExceptionAutoTest {
  @Test
  public void getCause_test_6443() {
    SaslException instance = new SaslException();
    instance.getCause();
  }

  @Test
  public void initCause_test_6444(Throwable p0) {
    SaslException instance = new SaslException();
    instance.initCause(p0);
  }

  @Test
  public void toString_test_6445() {
    SaslException instance = new SaslException();
    instance.toString();
  }
}
