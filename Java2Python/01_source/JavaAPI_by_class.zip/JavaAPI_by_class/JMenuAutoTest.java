package generated.test;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.lang.String;
import javax.swing.Action;
import javax.swing.ButtonModel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.event.MenuListener;
import org.junit.jupiter.api.Test;

public class JMenuAutoTest {
  @Test
  public void getUIClassID_test_7304() {
    JMenu instance = new JMenu();
    instance.getUIClassID();
  }

  @Test
  public void setSelected_test_7305(boolean p0) {
    JMenu instance = new JMenu();
    instance.setSelected(p0);
  }

  @Test
  public void isPopupMenuVisible_test_7306() {
    JMenu instance = new JMenu();
    instance.isPopupMenuVisible();
  }

  @Test
  public void getMenuComponent_test_7307(int p0) {
    JMenu instance = new JMenu();
    instance.getMenuComponent(p0);
  }

  @Test
  public void getMenuComponentCount_test_7308() {
    JMenu instance = new JMenu();
    instance.getMenuComponentCount();
  }

  @Test
  public void getMenuComponents_test_7309() {
    JMenu instance = new JMenu();
    instance.getMenuComponents();
  }

  @Test
  public void isMenuComponent_test_7310(Component p0) {
    JMenu instance = new JMenu();
    instance.isMenuComponent(p0);
  }

  @Test
  public void setPopupMenuVisible_test_7311(boolean p0) {
    JMenu instance = new JMenu();
    instance.setPopupMenuVisible(p0);
  }

  @Test
  public void setDelay_test_7312(int p0) {
    JMenu instance = new JMenu();
    instance.setDelay(p0);
  }

  @Test
  public void setMenuLocation_test_7313(int p0, int p1) {
    JMenu instance = new JMenu();
    instance.setMenuLocation(p0, p1);
  }

  @Test
  public void isTopLevelMenu_test_7314() {
    JMenu instance = new JMenu();
    instance.isTopLevelMenu();
  }

  @Test
  public void addMenuListener_test_7315(MenuListener p0) {
    JMenu instance = new JMenu();
    instance.addMenuListener(p0);
  }

  @Test
  public void removeMenuListener_test_7316(MenuListener p0) {
    JMenu instance = new JMenu();
    instance.removeMenuListener(p0);
  }

  @Test
  public void getMenuListeners_test_7317() {
    JMenu instance = new JMenu();
    instance.getMenuListeners();
  }

  @Test
  public void setModel_test_7318(ButtonModel p0) {
    JMenu instance = new JMenu();
    instance.setModel(p0);
  }

  @Test
  public void doClick_test_7319(int p0) {
    JMenu instance = new JMenu();
    instance.doClick(p0);
  }

  @Test
  public void setAccelerator_test_7320(KeyStroke p0) {
    JMenu instance = new JMenu();
    instance.setAccelerator(p0);
  }

  @Test
  public void menuSelectionChanged_test_7321(boolean p0) {
    JMenu instance = new JMenu();
    instance.menuSelectionChanged(p0);
  }

  @Test
  public void getSubElements_test_7322() {
    JMenu instance = new JMenu();
    instance.getSubElements();
  }

  @Test
  public void getDelay_test_7323() {
    JMenu instance = new JMenu();
    instance.getDelay();
  }

  @Test
  public void getAccessibleContext_test_7324() {
    JMenu instance = new JMenu();
    instance.getAccessibleContext();
  }

  @Test
  public void applyComponentOrientation_test_7325(ComponentOrientation p0) {
    JMenu instance = new JMenu();
    instance.applyComponentOrientation(p0);
  }

  @Test
  public void setComponentOrientation_test_7326(ComponentOrientation p0) {
    JMenu instance = new JMenu();
    instance.setComponentOrientation(p0);
  }

  @Test
  public void getItem_test_7327(int p0) {
    JMenu instance = new JMenu();
    instance.getItem(p0);
  }

  @Test
  public void getItemCount_test_7328() {
    JMenu instance = new JMenu();
    instance.getItemCount();
  }

  @Test
  public void updateUI_test_7329() {
    JMenu instance = new JMenu();
    instance.updateUI();
  }

  @Test
  public void isSelected_test_7330() {
    JMenu instance = new JMenu();
    instance.isSelected();
  }

  @Test
  public void addSeparator_test_7331() {
    JMenu instance = new JMenu();
    instance.addSeparator();
  }

  @Test
  public void isTearOff_test_7332() {
    JMenu instance = new JMenu();
    instance.isTearOff();
  }

  @Test
  public void insertSeparator_test_7333(int p0) {
    JMenu instance = new JMenu();
    instance.insertSeparator(p0);
  }

  @Test
  public void getPopupMenu_test_7334() {
    JMenu instance = new JMenu();
    instance.getPopupMenu();
  }

  @Test
  public void remove_test_7335(JMenuItem p0) {
    JMenu instance = new JMenu();
    instance.remove(p0);
  }

  @Test
  public void remove_test_7336(int p0) {
    JMenu instance = new JMenu();
    instance.remove(p0);
  }

  @Test
  public void remove_test_7337(Component p0) {
    JMenu instance = new JMenu();
    instance.remove(p0);
  }

  @Test
  public void insert_test_7338(Action p0, int p1) {
    JMenu instance = new JMenu();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_7339(JMenuItem p0, int p1) {
    JMenu instance = new JMenu();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_7340(String p0, int p1) {
    JMenu instance = new JMenu();
    instance.insert(p0, p1);
  }

  @Test
  public void add_test_7341(JMenuItem p0) {
    JMenu instance = new JMenu();
    instance.add(p0);
  }

  @Test
  public void add_test_7342(Component p0) {
    JMenu instance = new JMenu();
    instance.add(p0);
  }

  @Test
  public void add_test_7343(Action p0) {
    JMenu instance = new JMenu();
    instance.add(p0);
  }

  @Test
  public void add_test_7344(String p0) {
    JMenu instance = new JMenu();
    instance.add(p0);
  }

  @Test
  public void add_test_7345(Component p0, int p1) {
    JMenu instance = new JMenu();
    instance.add(p0, p1);
  }

  @Test
  public void removeAll_test_7346() {
    JMenu instance = new JMenu();
    instance.removeAll();
  }

  @Test
  public void getComponent_test_7347() {
    JMenu instance = new JMenu();
    instance.getComponent();
  }
}
