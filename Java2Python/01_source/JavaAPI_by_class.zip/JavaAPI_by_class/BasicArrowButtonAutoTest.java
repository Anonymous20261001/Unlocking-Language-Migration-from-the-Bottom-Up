package generated.test;

import java.awt.Graphics;
import javax.swing.plaf.basic.BasicArrowButton;
import org.junit.jupiter.api.Test;

public class BasicArrowButtonAutoTest {
  @Test
  public void setDirection_test_8610(int p0, int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.setDirection(p0);
  }

  @Test
  public void paintTriangle_test_8611(Graphics p0, int p1, int p2, int p3, int p4, boolean p5,
      int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.paintTriangle(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getDirection_test_8612(int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.getDirection();
  }

  @Test
  public void getMaximumSize_test_8613(int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.getMaximumSize();
  }

  @Test
  public void paint_test_8614(Graphics p0, int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.paint(p0);
  }

  @Test
  public void getPreferredSize_test_8615(int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.getPreferredSize();
  }

  @Test
  public void getMinimumSize_test_8616(int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.getMinimumSize();
  }

  @Test
  public void isFocusTraversable_test_8617(int c0) {
    BasicArrowButton instance = new BasicArrowButton(c0);
    instance.isFocusTraversable();
  }
}
