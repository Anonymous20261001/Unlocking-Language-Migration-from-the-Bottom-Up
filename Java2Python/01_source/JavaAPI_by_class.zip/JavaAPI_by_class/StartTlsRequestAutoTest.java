package generated.test;

import javax.naming.ldap.StartTlsRequest;
import org.junit.jupiter.api.Test;

public class StartTlsRequestAutoTest {
  @Test
  public void getEncodedValue_test_6014() {
    StartTlsRequest instance = new StartTlsRequest();
    instance.getEncodedValue();
  }

  @Test
  public void getID_test_6015() {
    StartTlsRequest instance = new StartTlsRequest();
    instance.getID();
  }
}
