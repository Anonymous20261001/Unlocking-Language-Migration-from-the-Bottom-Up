package generated.test;

import java.lang.Object;
import javax.security.auth.kerberos.EncryptionKey;
import org.junit.jupiter.api.Test;

public class EncryptionKeyAutoTest {
  @Test
  public void equals_test_6362(Object p0, byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6363(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.toString();
  }

  @Test
  public void hashCode_test_6364(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.hashCode();
  }

  @Test
  public void isDestroyed_test_6365(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.isDestroyed();
  }

  @Test
  public void getEncoded_test_6366(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.getEncoded();
  }

  @Test
  public void getFormat_test_6367(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.getFormat();
  }

  @Test
  public void getAlgorithm_test_6368(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.getAlgorithm();
  }

  @Test
  public void getKeyType_test_6369(byte[] c0, int c1) {
    EncryptionKey instance = new EncryptionKey(c0, c1);
    instance.getKeyType();
  }
}
