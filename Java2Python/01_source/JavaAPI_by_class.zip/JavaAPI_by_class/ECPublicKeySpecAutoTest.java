package generated.test;

import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import org.junit.jupiter.api.Test;

public class ECPublicKeySpecAutoTest {
  @Test
  public void getParams_test_2879(ECPoint c0, ECParameterSpec c1) {
    ECPublicKeySpec instance = new ECPublicKeySpec(c0, c1);
    instance.getParams();
  }

  @Test
  public void getW_test_2880(ECPoint c0, ECParameterSpec c1) {
    ECPublicKeySpec instance = new ECPublicKeySpec(c0, c1);
    instance.getW();
  }
}
