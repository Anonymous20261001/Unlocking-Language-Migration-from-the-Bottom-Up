package generated.test;

import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import javax.swing.Timer;
import org.junit.jupiter.api.Test;

public class TimerAutoTest {
  @Test
  public void setRepeats_test_8339(boolean p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.setRepeats(p0);
  }

  @Test
  public void setDelay_test_8340(int p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.setDelay(p0);
  }

  @Test
  public void getInitialDelay_test_8341(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.getInitialDelay();
  }

  @Test
  public void setLogTimers_test_8342(boolean p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    Timer.setLogTimers(p0);
  }

  @Test
  public void getLogTimers_test_8343(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    Timer.getLogTimers();
  }

  @Test
  public void setInitialDelay_test_8344(int p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.setInitialDelay(p0);
  }

  @Test
  public void isRepeats_test_8345(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.isRepeats();
  }

  @Test
  public void setCoalesce_test_8346(boolean p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.setCoalesce(p0);
  }

  @Test
  public void isCoalesce_test_8347(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.isCoalesce();
  }

  @Test
  public void restart_test_8348(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.restart();
  }

  @Test
  public void getDelay_test_8349(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.getDelay();
  }

  @Test
  public void isRunning_test_8350(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.isRunning();
  }

  @Test
  public void getListeners_test_8351(Class p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.getListeners(p0);
  }

  @Test
  public void addActionListener_test_8352(ActionListener p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.addActionListener(p0);
  }

  @Test
  public void setActionCommand_test_8353(String p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.setActionCommand(p0);
  }

  @Test
  public void getActionCommand_test_8354(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.getActionCommand();
  }

  @Test
  public void removeActionListener_test_8355(ActionListener p0, int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.removeActionListener(p0);
  }

  @Test
  public void getActionListeners_test_8356(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.getActionListeners();
  }

  @Test
  public void start_test_8357(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.start();
  }

  @Test
  public void stop_test_8358(int c0, ActionListener c1) {
    Timer instance = new Timer(c0, c1);
    instance.stop();
  }
}
