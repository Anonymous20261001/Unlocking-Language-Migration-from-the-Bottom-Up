package generated.test;

import java.lang.Object;
import java.text.AttributedCharacterIterator;
import java.text.Bidi;
import org.junit.jupiter.api.Test;

public class BidiAutoTest {
  @Test
  public void getRunLimit_test_3002(int p0, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getRunLimit(p0);
  }

  @Test
  public void baseIsLeftToRight_test_3003(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.baseIsLeftToRight();
  }

  @Test
  public void createLineBidi_test_3004(int p0, int p1, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.createLineBidi(p0, p1);
  }

  @Test
  public void requiresBidi_test_3005(char[] p0, int p1, int p2, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    Bidi.requiresBidi(p0, p1, p2);
  }

  @Test
  public void getRunStart_test_3006(int p0, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getRunStart(p0);
  }

  @Test
  public void isMixed_test_3007(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.isMixed();
  }

  @Test
  public void isRightToLeft_test_3008(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.isRightToLeft();
  }

  @Test
  public void getLevelAt_test_3009(int p0, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getLevelAt(p0);
  }

  @Test
  public void getRunLevel_test_3010(int p0, AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getRunLevel(p0);
  }

  @Test
  public void reorderVisually_test_3011(byte[] p0, int p1, Object[] p2, int p3, int p4,
      AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    Bidi.reorderVisually(p0, p1, p2, p3, p4);
  }

  @Test
  public void getBaseLevel_test_3012(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getBaseLevel();
  }

  @Test
  public void getRunCount_test_3013(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getRunCount();
  }

  @Test
  public void isLeftToRight_test_3014(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.isLeftToRight();
  }

  @Test
  public void toString_test_3015(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.toString();
  }

  @Test
  public void getLength_test_3016(AttributedCharacterIterator c0) {
    Bidi instance = new Bidi(c0);
    instance.getLength();
  }
}
