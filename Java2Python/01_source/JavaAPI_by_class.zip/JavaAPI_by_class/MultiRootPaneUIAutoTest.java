package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiRootPaneUI;
import org.junit.jupiter.api.Test;

public class MultiRootPaneUIAutoTest {
  @Test
  public void installUI_test_9501(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9502(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9503() {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9504(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    MultiRootPaneUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9505(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9506(Graphics p0, JComponent p1) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9507(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9508(JComponent p0, int p1) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9509(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9510(JComponent p0) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9511(Graphics p0, JComponent p1) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9512(JComponent p0, int p1, int p2) {
    MultiRootPaneUI instance = new MultiRootPaneUI();
    instance.contains(p0, p1, p2);
  }
}
