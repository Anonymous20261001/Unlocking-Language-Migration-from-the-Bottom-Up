package generated.test;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.SwitchPoint;
import org.junit.jupiter.api.Test;

public class SwitchPointAutoTest {
  @Test
  public void hasBeenInvalidated_test_2397() {
    SwitchPoint instance = new SwitchPoint();
    instance.hasBeenInvalidated();
  }

  @Test
  public void invalidateAll_test_2398(SwitchPoint[] p0) {
    SwitchPoint instance = new SwitchPoint();
    SwitchPoint.invalidateAll(p0);
  }

  @Test
  public void guardWithTest_test_2399(MethodHandle p0, MethodHandle p1) {
    SwitchPoint instance = new SwitchPoint();
    instance.guardWithTest(p0, p1);
  }
}
