package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobMediaSheetsSupported;
import org.junit.jupiter.api.Test;

public class JobMediaSheetsSupportedAutoTest {
  @Test
  public void getCategory_test_6148(int c0, int c1) {
    JobMediaSheetsSupported instance = new JobMediaSheetsSupported(c0, c1);
    instance.getCategory();
  }

  @Test
  public void getName_test_6149(int c0, int c1) {
    JobMediaSheetsSupported instance = new JobMediaSheetsSupported(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_6150(Object p0, int c0, int c1) {
    JobMediaSheetsSupported instance = new JobMediaSheetsSupported(c0, c1);
    instance.equals(p0);
  }
}
