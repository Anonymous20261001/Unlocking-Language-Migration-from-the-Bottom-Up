package generated.test;

import java.lang.Object;
import java.math.BigInteger;
import java.security.spec.ECFieldFp;
import org.junit.jupiter.api.Test;

public class ECFieldFpAutoTest {
  @Test
  public void getP_test_2865(BigInteger c0) {
    ECFieldFp instance = new ECFieldFp(c0);
    instance.getP();
  }

  @Test
  public void getFieldSize_test_2866(BigInteger c0) {
    ECFieldFp instance = new ECFieldFp(c0);
    instance.getFieldSize();
  }

  @Test
  public void equals_test_2867(Object p0, BigInteger c0) {
    ECFieldFp instance = new ECFieldFp(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_2868(BigInteger c0) {
    ECFieldFp instance = new ECFieldFp(c0);
    instance.hashCode();
  }
}
