package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicMenuItemUI;
import org.junit.jupiter.api.Test;

public class BasicMenuItemUIAutoTest {
  @Test
  public void installUI_test_8829(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8830(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8831(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    BasicMenuItemUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_8832(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_8833(Graphics p0, JComponent p1) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_8834(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_8835(JComponent p0) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_8836(Graphics p0, JComponent p1) {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.update(p0, p1);
  }

  @Test
  public void getPath_test_8837() {
    BasicMenuItemUI instance = new BasicMenuItemUI();
    instance.getPath();
  }
}
