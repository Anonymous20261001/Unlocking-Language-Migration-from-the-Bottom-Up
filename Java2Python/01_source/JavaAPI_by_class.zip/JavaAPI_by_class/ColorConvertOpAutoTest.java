package generated.test;

import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.awt.image.ColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import org.junit.jupiter.api.Test;

public class ColorConvertOpAutoTest {
  @Test
  public void getICC_Profiles_test_1104(RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.getICC_Profiles();
  }

  @Test
  public void createCompatibleDestImage_test_1105(BufferedImage p0, ColorModel p1,
      RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.createCompatibleDestImage(p0, p1);
  }

  @Test
  public void createCompatibleDestRaster_test_1106(Raster p0, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.createCompatibleDestRaster(p0);
  }

  @Test
  public void getPoint2D_test_1107(Point2D p0, Point2D p1, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.getPoint2D(p0, p1);
  }

  @Test
  public void getRenderingHints_test_1108(RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.getRenderingHints();
  }

  @Test
  public void getBounds2D_test_1109(Raster p0, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.getBounds2D(p0);
  }

  @Test
  public void getBounds2D_test_1110(BufferedImage p0, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.getBounds2D(p0);
  }

  @Test
  public void filter_test_1111(BufferedImage p0, BufferedImage p1, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.filter(p0, p1);
  }

  @Test
  public void filter_test_1112(Raster p0, WritableRaster p1, RenderingHints c0) {
    ColorConvertOp instance = new ColorConvertOp(c0);
    instance.filter(p0, p1);
  }
}
