package generated.test;

import java.nio.ByteBuffer;
import java.util.zip.CRC32;
import org.junit.jupiter.api.Test;

public class CRC32AutoTest {
  @Test
  public void reset_test_5124() {
    CRC32 instance = new CRC32();
    instance.reset();
  }

  @Test
  public void update_test_5125(int p0) {
    CRC32 instance = new CRC32();
    instance.update(p0);
  }

  @Test
  public void update_test_5126(ByteBuffer p0) {
    CRC32 instance = new CRC32();
    instance.update(p0);
  }

  @Test
  public void update_test_5127(byte[] p0, int p1, int p2) {
    CRC32 instance = new CRC32();
    instance.update(p0, p1, p2);
  }

  @Test
  public void getValue_test_5128() {
    CRC32 instance = new CRC32();
    instance.getValue();
  }
}
