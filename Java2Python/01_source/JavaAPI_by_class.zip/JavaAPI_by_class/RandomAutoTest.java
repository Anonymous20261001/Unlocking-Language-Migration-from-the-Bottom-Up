package generated.test;

import java.util.Random;
import java.util.random.RandomGenerator;
import org.junit.jupiter.api.Test;

public class RandomAutoTest {
  @Test
  public void from_test_3778(RandomGenerator p0) {
    Random instance = new Random();
    Random.from(p0);
  }

  @Test
  public void nextDouble_test_3779() {
    Random instance = new Random();
    instance.nextDouble();
  }

  @Test
  public void nextInt_test_3780(int p0) {
    Random instance = new Random();
    instance.nextInt(p0);
  }

  @Test
  public void nextInt_test_3781() {
    Random instance = new Random();
    instance.nextInt();
  }

  @Test
  public void nextBytes_test_3782(byte[] p0) {
    Random instance = new Random();
    instance.nextBytes(p0);
  }

  @Test
  public void longs_test_3783(long p0) {
    Random instance = new Random();
    instance.longs(p0);
  }

  @Test
  public void longs_test_3784(long p0, long p1, long p2) {
    Random instance = new Random();
    instance.longs(p0, p1, p2);
  }

  @Test
  public void longs_test_3785(long p0, long p1) {
    Random instance = new Random();
    instance.longs(p0, p1);
  }

  @Test
  public void longs_test_3786() {
    Random instance = new Random();
    instance.longs();
  }

  @Test
  public void setSeed_test_3787(long p0) {
    Random instance = new Random();
    instance.setSeed(p0);
  }

  @Test
  public void ints_test_3788(long p0, int p1, int p2) {
    Random instance = new Random();
    instance.ints(p0, p1, p2);
  }

  @Test
  public void ints_test_3789(int p0, int p1) {
    Random instance = new Random();
    instance.ints(p0, p1);
  }

  @Test
  public void ints_test_3790(long p0) {
    Random instance = new Random();
    instance.ints(p0);
  }

  @Test
  public void ints_test_3791() {
    Random instance = new Random();
    instance.ints();
  }

  @Test
  public void doubles_test_3792(long p0) {
    Random instance = new Random();
    instance.doubles(p0);
  }

  @Test
  public void doubles_test_3793() {
    Random instance = new Random();
    instance.doubles();
  }

  @Test
  public void doubles_test_3794(long p0, double p1, double p2) {
    Random instance = new Random();
    instance.doubles(p0, p1, p2);
  }

  @Test
  public void doubles_test_3795(double p0, double p1) {
    Random instance = new Random();
    instance.doubles(p0, p1);
  }

  @Test
  public void nextLong_test_3796() {
    Random instance = new Random();
    instance.nextLong();
  }

  @Test
  public void nextBoolean_test_3797() {
    Random instance = new Random();
    instance.nextBoolean();
  }

  @Test
  public void nextFloat_test_3798() {
    Random instance = new Random();
    instance.nextFloat();
  }

  @Test
  public void nextGaussian_test_3799() {
    Random instance = new Random();
    instance.nextGaussian();
  }
}
