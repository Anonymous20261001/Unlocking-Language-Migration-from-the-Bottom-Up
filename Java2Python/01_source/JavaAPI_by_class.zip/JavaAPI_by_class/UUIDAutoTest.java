package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.UUID;
import org.junit.jupiter.api.Test;

public class UUIDAutoTest {
  @Test
  public void randomUUID_test_4000(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    UUID.randomUUID();
  }

  @Test
  public void nameUUIDFromBytes_test_4001(byte[] p0, long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    UUID.nameUUIDFromBytes(p0);
  }

  @Test
  public void getLeastSignificantBits_test_4002(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.getLeastSignificantBits();
  }

  @Test
  public void getMostSignificantBits_test_4003(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.getMostSignificantBits();
  }

  @Test
  public void clockSequence_test_4004(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.clockSequence();
  }

  @Test
  public void fromString_test_4005(String p0, long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    UUID.fromString(p0);
  }

  @Test
  public void equals_test_4006(Object p0, long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_4007(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.toString();
  }

  @Test
  public void version_test_4008(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.version();
  }

  @Test
  public void hashCode_test_4009(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.hashCode();
  }

  @Test
  public void compareTo_test_4010(UUID p0, long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.compareTo(p0);
  }

  @Test
  public void timestamp_test_4011(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.timestamp();
  }

  @Test
  public void node_test_4012(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.node();
  }

  @Test
  public void variant_test_4013(long c0, long c1) {
    UUID instance = new UUID(c0, c1);
    instance.variant();
  }
}
