package generated.test;

import java.lang.Byte;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class ByteAutoTest {
  @Test
  public void equals_test_1853(Object p0, byte c0) {
    Byte instance = new Byte(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_1854(byte c0) {
    Byte instance = new Byte(c0);
    instance.toString();
  }

  @Test
  public void toString_test_1855(byte p0, byte c0) {
    Byte instance = new Byte(c0);
    Byte.toString(p0);
  }

  @Test
  public void hashCode_test_1856(byte p0, byte c0) {
    Byte instance = new Byte(c0);
    Byte.hashCode(p0);
  }

  @Test
  public void hashCode_test_1857(byte c0) {
    Byte instance = new Byte(c0);
    instance.hashCode();
  }

  @Test
  public void compareUnsigned_test_1858(byte p0, byte p1, byte c0) {
    Byte instance = new Byte(c0);
    Byte.compareUnsigned(p0, p1);
  }

  @Test
  public void compareTo_test_1859(Byte p0, byte c0) {
    Byte instance = new Byte(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_1860(byte p0, byte p1, byte c0) {
    Byte instance = new Byte(c0);
    Byte.compare(p0, p1);
  }

  @Test
  public void byteValue_test_1861(byte c0) {
    Byte instance = new Byte(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_1862(byte c0) {
    Byte instance = new Byte(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_1863(byte c0) {
    Byte instance = new Byte(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_1864(byte c0) {
    Byte instance = new Byte(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_1865(byte c0) {
    Byte instance = new Byte(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_1866(byte c0) {
    Byte instance = new Byte(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_1867(byte p0, byte c0) {
    Byte instance = new Byte(c0);
    Byte.valueOf(p0);
  }

  @Test
  public void describeConstable_test_1868(byte c0) {
    Byte instance = new Byte(c0);
    instance.describeConstable();
  }

  @Test
  public void toUnsignedLong_test_1869(byte p0, byte c0) {
    Byte instance = new Byte(c0);
    Byte.toUnsignedLong(p0);
  }

  @Test
  public void toUnsignedInt_test_1870(byte p0, byte c0) {
    Byte instance = new Byte(c0);
    Byte.toUnsignedInt(p0);
  }
}
