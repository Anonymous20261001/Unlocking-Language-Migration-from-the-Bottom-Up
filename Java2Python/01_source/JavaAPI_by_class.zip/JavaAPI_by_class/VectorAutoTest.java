package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.Comparator;
import java.util.Vector;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import org.junit.jupiter.api.Test;

public class VectorAutoTest {
  @Test
  public void setElementAt_test_4018(Object p0, int p1) {
    Vector instance = new Vector();
    instance.setElementAt(p0, p1);
  }

  @Test
  public void firstElement_test_4019() {
    Vector instance = new Vector();
    instance.firstElement();
  }

  @Test
  public void lastElement_test_4020() {
    Vector instance = new Vector();
    instance.lastElement();
  }

  @Test
  public void addElement_test_4021(Object p0) {
    Vector instance = new Vector();
    instance.addElement(p0);
  }

  @Test
  public void removeElementAt_test_4022(int p0) {
    Vector instance = new Vector();
    instance.removeElementAt(p0);
  }

  @Test
  public void insertElementAt_test_4023(Object p0, int p1) {
    Vector instance = new Vector();
    instance.insertElementAt(p0, p1);
  }

  @Test
  public void removeAllElements_test_4024() {
    Vector instance = new Vector();
    instance.removeAllElements();
  }

  @Test
  public void removeElement_test_4025(Object p0) {
    Vector instance = new Vector();
    instance.removeElement(p0);
  }

  @Test
  public void remove_test_4026(Object p0) {
    Vector instance = new Vector();
    instance.remove(p0);
  }

  @Test
  public void remove_test_4027(int p0) {
    Vector instance = new Vector();
    instance.remove(p0);
  }

  @Test
  public void size_test_4028() {
    Vector instance = new Vector();
    instance.size();
  }

  @Test
  public void get_test_4029(int p0) {
    Vector instance = new Vector();
    instance.get(p0);
  }

  @Test
  public void equals_test_4030(Object p0) {
    Vector instance = new Vector();
    instance.equals(p0);
  }

  @Test
  public void toString_test_4031() {
    Vector instance = new Vector();
    instance.toString();
  }

  @Test
  public void hashCode_test_4032() {
    Vector instance = new Vector();
    instance.hashCode();
  }

  @Test
  public void clone_test_4033() {
    Vector instance = new Vector();
    instance.clone();
  }

  @Test
  public void sort_test_4034(Comparator p0) {
    Vector instance = new Vector();
    instance.sort(p0);
  }

  @Test
  public void indexOf_test_4035(Object p0, int p1) {
    Vector instance = new Vector();
    instance.indexOf(p0, p1);
  }

  @Test
  public void indexOf_test_4036(Object p0) {
    Vector instance = new Vector();
    instance.indexOf(p0);
  }

  @Test
  public void clear_test_4037() {
    Vector instance = new Vector();
    instance.clear();
  }

  @Test
  public void lastIndexOf_test_4038(Object p0, int p1) {
    Vector instance = new Vector();
    instance.lastIndexOf(p0, p1);
  }

  @Test
  public void lastIndexOf_test_4039(Object p0) {
    Vector instance = new Vector();
    instance.lastIndexOf(p0);
  }

  @Test
  public void isEmpty_test_4040() {
    Vector instance = new Vector();
    instance.isEmpty();
  }

  @Test
  public void replaceAll_test_4041(UnaryOperator p0) {
    Vector instance = new Vector();
    instance.replaceAll(p0);
  }

  @Test
  public void add_test_4042(int p0, Object p1) {
    Vector instance = new Vector();
    instance.add(p0, p1);
  }

  @Test
  public void add_test_4043(Object p0) {
    Vector instance = new Vector();
    instance.add(p0);
  }

  @Test
  public void subList_test_4044(int p0, int p1) {
    Vector instance = new Vector();
    instance.subList(p0, p1);
  }

  @Test
  public void toArray_test_4045(Object[] p0) {
    Vector instance = new Vector();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4046() {
    Vector instance = new Vector();
    instance.toArray();
  }

  @Test
  public void iterator_test_4047() {
    Vector instance = new Vector();
    instance.iterator();
  }

  @Test
  public void contains_test_4048(Object p0) {
    Vector instance = new Vector();
    instance.contains(p0);
  }

  @Test
  public void elements_test_4049() {
    Vector instance = new Vector();
    instance.elements();
  }

  @Test
  public void spliterator_test_4050() {
    Vector instance = new Vector();
    instance.spliterator();
  }

  @Test
  public void addAll_test_4051(int p0, Collection p1) {
    Vector instance = new Vector();
    instance.addAll(p0, p1);
  }

  @Test
  public void addAll_test_4052(Collection p0) {
    Vector instance = new Vector();
    instance.addAll(p0);
  }

  @Test
  public void trimToSize_test_4053() {
    Vector instance = new Vector();
    instance.trimToSize();
  }

  @Test
  public void set_test_4054(int p0, Object p1) {
    Vector instance = new Vector();
    instance.set(p0, p1);
  }

  @Test
  public void forEach_test_4055(Consumer p0) {
    Vector instance = new Vector();
    instance.forEach(p0);
  }

  @Test
  public void capacity_test_4056() {
    Vector instance = new Vector();
    instance.capacity();
  }

  @Test
  public void ensureCapacity_test_4057(int p0) {
    Vector instance = new Vector();
    instance.ensureCapacity(p0);
  }

  @Test
  public void elementAt_test_4058(int p0) {
    Vector instance = new Vector();
    instance.elementAt(p0);
  }

  @Test
  public void removeIf_test_4059(Predicate p0) {
    Vector instance = new Vector();
    instance.removeIf(p0);
  }

  @Test
  public void removeAll_test_4060(Collection p0) {
    Vector instance = new Vector();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4061(Collection p0) {
    Vector instance = new Vector();
    instance.retainAll(p0);
  }

  @Test
  public void listIterator_test_4062() {
    Vector instance = new Vector();
    instance.listIterator();
  }

  @Test
  public void listIterator_test_4063(int p0) {
    Vector instance = new Vector();
    instance.listIterator(p0);
  }

  @Test
  public void containsAll_test_4064(Collection p0) {
    Vector instance = new Vector();
    instance.containsAll(p0);
  }

  @Test
  public void copyInto_test_4065(Object[] p0) {
    Vector instance = new Vector();
    instance.copyInto(p0);
  }

  @Test
  public void setSize_test_4066(int p0) {
    Vector instance = new Vector();
    instance.setSize(p0);
  }
}
