package generated.test;

import java.lang.Integer;
import javax.management.Notification;
import javax.management.remote.TargetedNotification;
import org.junit.jupiter.api.Test;

public class TargetedNotificationAutoTest {
  @Test
  public void getListenerID_test_5844(Notification c0, Integer c1) {
    TargetedNotification instance = new TargetedNotification(c0, c1);
    instance.getListenerID();
  }

  @Test
  public void getNotification_test_5845(Notification c0, Integer c1) {
    TargetedNotification instance = new TargetedNotification(c0, c1);
    instance.getNotification();
  }

  @Test
  public void toString_test_5846(Notification c0, Integer c1) {
    TargetedNotification instance = new TargetedNotification(c0, c1);
    instance.toString();
  }
}
