package generated.test;

import java.lang.Object;
import javax.print.DocFlavor;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import org.junit.jupiter.api.Test;

public class SimpleDocAutoTest {
  @Test
  public void getDocFlavor_test_6082(Object c0, DocFlavor c1, DocAttributeSet c2) {
    SimpleDoc instance = new SimpleDoc(c0, c1, c2);
    instance.getDocFlavor();
  }

  @Test
  public void getAttributes_test_6083(Object c0, DocFlavor c1, DocAttributeSet c2) {
    SimpleDoc instance = new SimpleDoc(c0, c1, c2);
    instance.getAttributes();
  }
}
