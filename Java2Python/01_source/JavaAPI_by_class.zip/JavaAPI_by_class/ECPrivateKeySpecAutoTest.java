package generated.test;

import java.math.BigInteger;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPrivateKeySpec;
import org.junit.jupiter.api.Test;

public class ECPrivateKeySpecAutoTest {
  @Test
  public void getParams_test_2877(BigInteger c0, ECParameterSpec c1) {
    ECPrivateKeySpec instance = new ECPrivateKeySpec(c0, c1);
    instance.getParams();
  }

  @Test
  public void getS_test_2878(BigInteger c0, ECParameterSpec c1) {
    ECPrivateKeySpec instance = new ECPrivateKeySpec(c0, c1);
    instance.getS();
  }
}
