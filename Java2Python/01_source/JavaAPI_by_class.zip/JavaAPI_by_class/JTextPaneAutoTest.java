package generated.test;

import java.awt.Component;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.Document;
import javax.swing.text.EditorKit;
import javax.swing.text.Style;
import javax.swing.text.StyledDocument;
import org.junit.jupiter.api.Test;

public class JTextPaneAutoTest {
  @Test
  public void setDocument_test_7975(Document p0) {
    JTextPane instance = new JTextPane();
    instance.setDocument(p0);
  }

  @Test
  public void setEditorKit_test_7976(EditorKit p0) {
    JTextPane instance = new JTextPane();
    instance.setEditorKit(p0);
  }

  @Test
  public void getInputAttributes_test_7977() {
    JTextPane instance = new JTextPane();
    instance.getInputAttributes();
  }

  @Test
  public void replaceSelection_test_7978(String p0) {
    JTextPane instance = new JTextPane();
    instance.replaceSelection(p0);
  }

  @Test
  public void getUIClassID_test_7979() {
    JTextPane instance = new JTextPane();
    instance.getUIClassID();
  }

  @Test
  public void setStyledDocument_test_7980(StyledDocument p0) {
    JTextPane instance = new JTextPane();
    instance.setStyledDocument(p0);
  }

  @Test
  public void getStyledDocument_test_7981() {
    JTextPane instance = new JTextPane();
    instance.getStyledDocument();
  }

  @Test
  public void addStyle_test_7982(String p0, Style p1) {
    JTextPane instance = new JTextPane();
    instance.addStyle(p0, p1);
  }

  @Test
  public void removeStyle_test_7983(String p0) {
    JTextPane instance = new JTextPane();
    instance.removeStyle(p0);
  }

  @Test
  public void setLogicalStyle_test_7984(Style p0) {
    JTextPane instance = new JTextPane();
    instance.setLogicalStyle(p0);
  }

  @Test
  public void getLogicalStyle_test_7985() {
    JTextPane instance = new JTextPane();
    instance.getLogicalStyle();
  }

  @Test
  public void setCharacterAttributes_test_7986(AttributeSet p0, boolean p1) {
    JTextPane instance = new JTextPane();
    instance.setCharacterAttributes(p0, p1);
  }

  @Test
  public void setParagraphAttributes_test_7987(AttributeSet p0, boolean p1) {
    JTextPane instance = new JTextPane();
    instance.setParagraphAttributes(p0, p1);
  }

  @Test
  public void insertComponent_test_7988(Component p0) {
    JTextPane instance = new JTextPane();
    instance.insertComponent(p0);
  }

  @Test
  public void insertIcon_test_7989(Icon p0) {
    JTextPane instance = new JTextPane();
    instance.insertIcon(p0);
  }

  @Test
  public void getCharacterAttributes_test_7990() {
    JTextPane instance = new JTextPane();
    instance.getCharacterAttributes();
  }

  @Test
  public void getParagraphAttributes_test_7991() {
    JTextPane instance = new JTextPane();
    instance.getParagraphAttributes();
  }

  @Test
  public void getStyle_test_7992(String p0) {
    JTextPane instance = new JTextPane();
    instance.getStyle(p0);
  }
}
