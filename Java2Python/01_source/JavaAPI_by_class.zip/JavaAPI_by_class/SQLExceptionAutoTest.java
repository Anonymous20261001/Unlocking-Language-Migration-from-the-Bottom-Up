package generated.test;

import java.sql.SQLException;
import org.junit.jupiter.api.Test;

public class SQLExceptionAutoTest {
  @Test
  public void iterator_test_2957() {
    SQLException instance = new SQLException();
    instance.iterator();
  }

  @Test
  public void getSQLState_test_2958() {
    SQLException instance = new SQLException();
    instance.getSQLState();
  }

  @Test
  public void getErrorCode_test_2959() {
    SQLException instance = new SQLException();
    instance.getErrorCode();
  }

  @Test
  public void getNextException_test_2960() {
    SQLException instance = new SQLException();
    instance.getNextException();
  }

  @Test
  public void setNextException_test_2961(SQLException p0) {
    SQLException instance = new SQLException();
    instance.setNextException(p0);
  }
}
