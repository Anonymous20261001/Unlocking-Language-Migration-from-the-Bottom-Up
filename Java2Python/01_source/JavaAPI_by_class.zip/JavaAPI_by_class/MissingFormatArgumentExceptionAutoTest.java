package generated.test;

import java.lang.String;
import java.util.MissingFormatArgumentException;
import org.junit.jupiter.api.Test;

public class MissingFormatArgumentExceptionAutoTest {
  @Test
  public void getFormatSpecifier_test_3705(String c0) {
    MissingFormatArgumentException instance = new MissingFormatArgumentException(c0);
    instance.getFormatSpecifier();
  }

  @Test
  public void getMessage_test_3706(String c0) {
    MissingFormatArgumentException instance = new MissingFormatArgumentException(c0);
    instance.getMessage();
  }
}
