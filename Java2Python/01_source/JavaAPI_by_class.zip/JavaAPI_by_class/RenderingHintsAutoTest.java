package generated.test;

import java.awt.RenderingHints;
import java.lang.Object;
import java.util.Map;
import org.junit.jupiter.api.Test;

public class RenderingHintsAutoTest {
  @Test
  public void remove_test_510(Object p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.remove(p0);
  }

  @Test
  public void size_test_511(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.size();
  }

  @Test
  public void get_test_512(Object p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.get(p0);
  }

  @Test
  public void put_test_513(Object p0, Object p1, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.put(p0, p1);
  }

  @Test
  public void equals_test_514(Object p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_515(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.toString();
  }

  @Test
  public void values_test_516(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.values();
  }

  @Test
  public void hashCode_test_517(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_518(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.clone();
  }

  @Test
  public void clear_test_519(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.clear();
  }

  @Test
  public void isEmpty_test_520(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.isEmpty();
  }

  @Test
  public void add_test_521(RenderingHints p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.add(p0);
  }

  @Test
  public void entrySet_test_522(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.entrySet();
  }

  @Test
  public void putAll_test_523(Map p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.putAll(p0);
  }

  @Test
  public void keySet_test_524(Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.keySet();
  }

  @Test
  public void containsValue_test_525(Object p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_526(Object p0, Map c0) {
    RenderingHints instance = new RenderingHints(c0);
    instance.containsKey(p0);
  }
}
