package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthScrollBarUI;
import org.junit.jupiter.api.Test;

public class SynthScrollBarUIAutoTest {
  @Test
  public void propertyChange_test_9877(PropertyChangeEvent p0) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.propertyChange(p0);
  }

  @Test
  public void getSupportsAbsolutePositioning_test_9878() {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.getSupportsAbsolutePositioning();
  }

  @Test
  public void paintBorder_test_9879(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9880(JComponent p0) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    SynthScrollBarUI.createUI(p0);
  }

  @Test
  public void paint_test_9881(Graphics p0, JComponent p1) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9882(JComponent p0) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void update_test_9883(Graphics p0, JComponent p1) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9884(JComponent p0) {
    SynthScrollBarUI instance = new SynthScrollBarUI();
    instance.getContext(p0);
  }
}
