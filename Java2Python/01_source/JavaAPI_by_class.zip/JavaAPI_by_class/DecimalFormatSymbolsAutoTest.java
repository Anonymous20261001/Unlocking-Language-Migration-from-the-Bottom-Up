package generated.test;

import java.lang.Object;
import java.lang.String;
import java.text.DecimalFormatSymbols;
import java.util.Currency;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class DecimalFormatSymbolsAutoTest {
  @Test
  public void equals_test_3127(Object p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_3128() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.hashCode();
  }

  @Test
  public void clone_test_3129() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.clone();
  }

  @Test
  public void getInstance_test_3130(Locale p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    DecimalFormatSymbols.getInstance(p0);
  }

  @Test
  public void getInstance_test_3131() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    DecimalFormatSymbols.getInstance();
  }

  @Test
  public void getAvailableLocales_test_3132() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    DecimalFormatSymbols.getAvailableLocales();
  }

  @Test
  public void getNaN_test_3133() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getNaN();
  }

  @Test
  public void getInfinity_test_3134() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getInfinity();
  }

  @Test
  public void getZeroDigit_test_3135() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getZeroDigit();
  }

  @Test
  public void getMonetaryGroupingSeparator_test_3136() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getMonetaryGroupingSeparator();
  }

  @Test
  public void getGroupingSeparator_test_3137() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getGroupingSeparator();
  }

  @Test
  public void getMonetaryDecimalSeparator_test_3138() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getMonetaryDecimalSeparator();
  }

  @Test
  public void getDecimalSeparator_test_3139() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getDecimalSeparator();
  }

  @Test
  public void getExponentSeparator_test_3140() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getExponentSeparator();
  }

  @Test
  public void getLocale_test_3141() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getLocale();
  }

  @Test
  public void getInternationalCurrencySymbol_test_3142() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getInternationalCurrencySymbol();
  }

  @Test
  public void getCurrencySymbol_test_3143() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getCurrencySymbol();
  }

  @Test
  public void getDigit_test_3144() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getDigit();
  }

  @Test
  public void getPatternSeparator_test_3145() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getPatternSeparator();
  }

  @Test
  public void getPercent_test_3146() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getPercent();
  }

  @Test
  public void getPerMill_test_3147() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getPerMill();
  }

  @Test
  public void getMinusSign_test_3148() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getMinusSign();
  }

  @Test
  public void getCurrency_test_3149() {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.getCurrency();
  }

  @Test
  public void setCurrency_test_3150(Currency p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setCurrency(p0);
  }

  @Test
  public void setZeroDigit_test_3151(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setZeroDigit(p0);
  }

  @Test
  public void setGroupingSeparator_test_3152(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setGroupingSeparator(p0);
  }

  @Test
  public void setDecimalSeparator_test_3153(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setDecimalSeparator(p0);
  }

  @Test
  public void setPerMill_test_3154(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setPerMill(p0);
  }

  @Test
  public void setPercent_test_3155(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setPercent(p0);
  }

  @Test
  public void setDigit_test_3156(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setDigit(p0);
  }

  @Test
  public void setPatternSeparator_test_3157(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setPatternSeparator(p0);
  }

  @Test
  public void setInfinity_test_3158(String p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setInfinity(p0);
  }

  @Test
  public void setNaN_test_3159(String p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setNaN(p0);
  }

  @Test
  public void setMinusSign_test_3160(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setMinusSign(p0);
  }

  @Test
  public void setCurrencySymbol_test_3161(String p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setCurrencySymbol(p0);
  }

  @Test
  public void setInternationalCurrencySymbol_test_3162(String p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setInternationalCurrencySymbol(p0);
  }

  @Test
  public void setMonetaryDecimalSeparator_test_3163(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setMonetaryDecimalSeparator(p0);
  }

  @Test
  public void setExponentSeparator_test_3164(String p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setExponentSeparator(p0);
  }

  @Test
  public void setMonetaryGroupingSeparator_test_3165(char p0) {
    DecimalFormatSymbols instance = new DecimalFormatSymbols();
    instance.setMonetaryGroupingSeparator(p0);
  }
}
