package generated.test;

import java.awt.dnd.DropTargetContext;
import java.awt.dnd.DropTargetEvent;
import org.junit.jupiter.api.Test;

public class DropTargetEventAutoTest {
  @Test
  public void getDropTargetContext_test_738(DropTargetContext c0) {
    DropTargetEvent instance = new DropTargetEvent(c0);
    instance.getDropTargetContext();
  }
}
