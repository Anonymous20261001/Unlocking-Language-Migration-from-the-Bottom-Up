package generated.test;

import java.lang.Object;
import javax.smartcardio.ResponseAPDU;
import org.junit.jupiter.api.Test;

public class ResponseAPDUAutoTest {
  @Test
  public void equals_test_6466(Object p0, byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6467(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_6468(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.hashCode();
  }

  @Test
  public void getBytes_test_6469(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getBytes();
  }

  @Test
  public void getData_test_6470(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getData();
  }

  @Test
  public void getSW1_test_6471(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getSW1();
  }

  @Test
  public void getSW2_test_6472(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getSW2();
  }

  @Test
  public void getSW_test_6473(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getSW();
  }

  @Test
  public void getNr_test_6474(byte[] c0) {
    ResponseAPDU instance = new ResponseAPDU(c0);
    instance.getNr();
  }
}
