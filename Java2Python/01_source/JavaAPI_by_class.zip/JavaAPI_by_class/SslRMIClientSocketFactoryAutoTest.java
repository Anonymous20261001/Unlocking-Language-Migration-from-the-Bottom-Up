package generated.test;

import java.lang.Object;
import javax.rmi.ssl.SslRMIClientSocketFactory;
import org.junit.jupiter.api.Test;

public class SslRMIClientSocketFactoryAutoTest {
  @Test
  public void equals_test_6254(Object p0) {
    SslRMIClientSocketFactory instance = new SslRMIClientSocketFactory();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_6255() {
    SslRMIClientSocketFactory instance = new SslRMIClientSocketFactory();
    instance.hashCode();
  }
}
