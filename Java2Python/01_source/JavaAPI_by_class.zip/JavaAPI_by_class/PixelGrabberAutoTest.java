package generated.test;

import java.awt.Image;
import java.awt.image.ColorModel;
import java.awt.image.PixelGrabber;
import java.util.Hashtable;
import org.junit.jupiter.api.Test;

public class PixelGrabberAutoTest {
  @Test
  public void startGrabbing_test_1356(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.startGrabbing();
  }

  @Test
  public void abortGrabbing_test_1357(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.abortGrabbing();
  }

  @Test
  public void setHints_test_1358(int p0, Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setHints(p0);
  }

  @Test
  public void setPixels_test_1359(int p0, int p1, int p2, int p3, ColorModel p4, byte[] p5, int p6,
      int p7, Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setPixels_test_1360(int p0, int p1, int p2, int p3, ColorModel p4, int[] p5, int p6,
      int p7, Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setDimensions_test_1361(int p0, int p1, Image c0, int c1, int c2, int c3, int c4,
      boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setDimensions(p0, p1);
  }

  @Test
  public void setColorModel_test_1362(ColorModel p0, Image c0, int c1, int c2, int c3, int c4,
      boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setColorModel(p0);
  }

  @Test
  public void imageComplete_test_1363(int p0, Image c0, int c1, int c2, int c3, int c4,
      boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.imageComplete(p0);
  }

  @Test
  public void getPixels_test_1364(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.getPixels();
  }

  @Test
  public void getWidth_test_1365(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.getWidth();
  }

  @Test
  public void getHeight_test_1366(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.getHeight();
  }

  @Test
  public void getColorModel_test_1367(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.getColorModel();
  }

  @Test
  public void getStatus_test_1368(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.getStatus();
  }

  @Test
  public void setProperties_test_1369(Hashtable p0, Image c0, int c1, int c2, int c3, int c4,
      boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.setProperties(p0);
  }

  @Test
  public void status_test_1370(Image c0, int c1, int c2, int c3, int c4, boolean c5) {
    PixelGrabber instance = new PixelGrabber(c0, c1, c2, c3, c4, c5);
    instance.status();
  }
}
