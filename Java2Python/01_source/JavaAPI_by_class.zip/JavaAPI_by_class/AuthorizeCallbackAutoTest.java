package generated.test;

import java.lang.String;
import javax.security.sasl.AuthorizeCallback;
import org.junit.jupiter.api.Test;

public class AuthorizeCallbackAutoTest {
  @Test
  public void getAuthenticationID_test_6437(String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.getAuthenticationID();
  }

  @Test
  public void getAuthorizationID_test_6438(String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.getAuthorizationID();
  }

  @Test
  public void isAuthorized_test_6439(String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.isAuthorized();
  }

  @Test
  public void setAuthorized_test_6440(boolean p0, String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.setAuthorized(p0);
  }

  @Test
  public void getAuthorizedID_test_6441(String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.getAuthorizedID();
  }

  @Test
  public void setAuthorizedID_test_6442(String p0, String c0, String c1) {
    AuthorizeCallback instance = new AuthorizeCallback(c0, c1);
    instance.setAuthorizedID(p0);
  }
}
