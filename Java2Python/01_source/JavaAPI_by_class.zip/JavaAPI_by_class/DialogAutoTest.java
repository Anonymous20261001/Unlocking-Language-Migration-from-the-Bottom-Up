package generated.test;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.Shape;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class DialogAutoTest {
  @Test
  public void getAccessibleContext_test_177(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.getAccessibleContext();
  }

  @Test
  public void addNotify_test_178(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.addNotify();
  }

  @Test
  public void setVisible_test_179(boolean p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setVisible(p0);
  }

  @Test
  public void show_test_180(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.show();
  }

  @Test
  public void hide_test_181(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.hide();
  }

  @Test
  public void setBackground_test_182(Color p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setBackground(p0);
  }

  @Test
  public void setModalityType_test_183(Dialog.ModalityType p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setModalityType(p0);
  }

  @Test
  public void setTitle_test_184(String p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setTitle(p0);
  }

  @Test
  public void isModal_test_185(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.isModal();
  }

  @Test
  public void toBack_test_186(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.toBack();
  }

  @Test
  public void setResizable_test_187(boolean p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setResizable(p0);
  }

  @Test
  public void isUndecorated_test_188(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.isUndecorated();
  }

  @Test
  public void setOpacity_test_189(float p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setOpacity(p0);
  }

  @Test
  public void setShape_test_190(Shape p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setShape(p0);
  }

  @Test
  public void getModalityType_test_191(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.getModalityType();
  }

  @Test
  public void setModal_test_192(boolean p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setModal(p0);
  }

  @Test
  public void getTitle_test_193(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.getTitle();
  }

  @Test
  public void isResizable_test_194(Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.isResizable();
  }

  @Test
  public void setUndecorated_test_195(boolean p0, Dialog c0) {
    Dialog instance = new Dialog(c0);
    instance.setUndecorated(p0);
  }
}
