package generated.test;

import java.math.BigInteger;
import java.security.spec.RSAPrivateKeySpec;
import org.junit.jupiter.api.Test;

public class RSAPrivateKeySpecAutoTest {
  @Test
  public void getParams_test_2925(BigInteger c0, BigInteger c1) {
    RSAPrivateKeySpec instance = new RSAPrivateKeySpec(c0, c1);
    instance.getParams();
  }

  @Test
  public void getModulus_test_2926(BigInteger c0, BigInteger c1) {
    RSAPrivateKeySpec instance = new RSAPrivateKeySpec(c0, c1);
    instance.getModulus();
  }

  @Test
  public void getPrivateExponent_test_2927(BigInteger c0, BigInteger c1) {
    RSAPrivateKeySpec instance = new RSAPrivateKeySpec(c0, c1);
    instance.getPrivateExponent();
  }
}
