package generated.test;

import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.plaf.basic.BasicButtonListener;
import org.junit.jupiter.api.Test;

public class BasicButtonListenerAutoTest {
  @Test
  public void propertyChange_test_8627(PropertyChangeEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.propertyChange(p0);
  }

  @Test
  public void stateChanged_test_8628(ChangeEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.stateChanged(p0);
  }

  @Test
  public void installKeyboardActions_test_8629(JComponent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.installKeyboardActions(p0);
  }

  @Test
  public void uninstallKeyboardActions_test_8630(JComponent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.uninstallKeyboardActions(p0);
  }

  @Test
  public void focusGained_test_8631(FocusEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.focusGained(p0);
  }

  @Test
  public void focusLost_test_8632(FocusEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.focusLost(p0);
  }

  @Test
  public void mousePressed_test_8633(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mousePressed(p0);
  }

  @Test
  public void mouseReleased_test_8634(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseReleased(p0);
  }

  @Test
  public void mouseClicked_test_8635(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseClicked(p0);
  }

  @Test
  public void mouseExited_test_8636(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseExited(p0);
  }

  @Test
  public void mouseEntered_test_8637(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseEntered(p0);
  }

  @Test
  public void mouseMoved_test_8638(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseMoved(p0);
  }

  @Test
  public void mouseDragged_test_8639(MouseEvent p0, AbstractButton c0) {
    BasicButtonListener instance = new BasicButtonListener(c0);
    instance.mouseDragged(p0);
  }
}
