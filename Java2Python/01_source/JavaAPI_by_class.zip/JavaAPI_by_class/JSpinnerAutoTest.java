package generated.test;

import java.lang.Object;
import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.SpinnerUI;
import org.junit.jupiter.api.Test;

public class JSpinnerAutoTest {
  @Test
  public void getUIClassID_test_7679() {
    JSpinner instance = new JSpinner();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_7680() {
    JSpinner instance = new JSpinner();
    instance.getUI();
  }

  @Test
  public void setUI_test_7681(SpinnerUI p0) {
    JSpinner instance = new JSpinner();
    instance.setUI(p0);
  }

  @Test
  public void getModel_test_7682() {
    JSpinner instance = new JSpinner();
    instance.getModel();
  }

  @Test
  public void getNextValue_test_7683() {
    JSpinner instance = new JSpinner();
    instance.getNextValue();
  }

  @Test
  public void getPreviousValue_test_7684() {
    JSpinner instance = new JSpinner();
    instance.getPreviousValue();
  }

  @Test
  public void addChangeListener_test_7685(ChangeListener p0) {
    JSpinner instance = new JSpinner();
    instance.addChangeListener(p0);
  }

  @Test
  public void removeChangeListener_test_7686(ChangeListener p0) {
    JSpinner instance = new JSpinner();
    instance.removeChangeListener(p0);
  }

  @Test
  public void getChangeListeners_test_7687() {
    JSpinner instance = new JSpinner();
    instance.getChangeListeners();
  }

  @Test
  public void setModel_test_7688(SpinnerModel p0) {
    JSpinner instance = new JSpinner();
    instance.setModel(p0);
  }

  @Test
  public void getEditor_test_7689() {
    JSpinner instance = new JSpinner();
    instance.getEditor();
  }

  @Test
  public void setEditor_test_7690(JComponent p0) {
    JSpinner instance = new JSpinner();
    instance.setEditor(p0);
  }

  @Test
  public void getAccessibleContext_test_7691() {
    JSpinner instance = new JSpinner();
    instance.getAccessibleContext();
  }

  @Test
  public void updateUI_test_7692() {
    JSpinner instance = new JSpinner();
    instance.updateUI();
  }

  @Test
  public void getValue_test_7693() {
    JSpinner instance = new JSpinner();
    instance.getValue();
  }

  @Test
  public void setValue_test_7694(Object p0) {
    JSpinner instance = new JSpinner();
    instance.setValue(p0);
  }
}
