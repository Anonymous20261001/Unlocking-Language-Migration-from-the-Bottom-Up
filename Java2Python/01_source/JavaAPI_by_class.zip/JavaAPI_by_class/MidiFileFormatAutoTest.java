package generated.test;

import java.lang.String;
import javax.sound.midi.MidiFileFormat;
import org.junit.jupiter.api.Test;

public class MidiFileFormatAutoTest {
  @Test
  public void getDivisionType_test_6481(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getDivisionType();
  }

  @Test
  public void getByteLength_test_6482(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getByteLength();
  }

  @Test
  public void getMicrosecondLength_test_6483(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getMicrosecondLength();
  }

  @Test
  public void getResolution_test_6484(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getResolution();
  }

  @Test
  public void getProperty_test_6485(String p0, int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getProperty(p0);
  }

  @Test
  public void properties_test_6486(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.properties();
  }

  @Test
  public void getType_test_6487(int c0, float c1, int c2, int c3, long c4) {
    MidiFileFormat instance = new MidiFileFormat(c0, c1, c2, c3, c4);
    instance.getType();
  }
}
