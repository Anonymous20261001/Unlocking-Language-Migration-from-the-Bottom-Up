package generated.test;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Container;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class CardLayoutAutoTest {
  @Test
  public void removeLayoutComponent_test_41(Component p0) {
    CardLayout instance = new CardLayout();
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_42(String p0, Component p1) {
    CardLayout instance = new CardLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void addLayoutComponent_test_43(Component p0, Object p1) {
    CardLayout instance = new CardLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_44(Container p0) {
    CardLayout instance = new CardLayout();
    instance.layoutContainer(p0);
  }

  @Test
  public void invalidateLayout_test_45(Container p0) {
    CardLayout instance = new CardLayout();
    instance.invalidateLayout(p0);
  }

  @Test
  public void preferredLayoutSize_test_46(Container p0) {
    CardLayout instance = new CardLayout();
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_47(Container p0) {
    CardLayout instance = new CardLayout();
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void maximumLayoutSize_test_48(Container p0) {
    CardLayout instance = new CardLayout();
    instance.maximumLayoutSize(p0);
  }

  @Test
  public void getLayoutAlignmentX_test_49(Container p0) {
    CardLayout instance = new CardLayout();
    instance.getLayoutAlignmentX(p0);
  }

  @Test
  public void getLayoutAlignmentY_test_50(Container p0) {
    CardLayout instance = new CardLayout();
    instance.getLayoutAlignmentY(p0);
  }

  @Test
  public void show_test_51(Container p0, String p1) {
    CardLayout instance = new CardLayout();
    instance.show(p0, p1);
  }

  @Test
  public void getHgap_test_52() {
    CardLayout instance = new CardLayout();
    instance.getHgap();
  }

  @Test
  public void setHgap_test_53(int p0) {
    CardLayout instance = new CardLayout();
    instance.setHgap(p0);
  }

  @Test
  public void getVgap_test_54() {
    CardLayout instance = new CardLayout();
    instance.getVgap();
  }

  @Test
  public void setVgap_test_55(int p0) {
    CardLayout instance = new CardLayout();
    instance.setVgap(p0);
  }

  @Test
  public void toString_test_56() {
    CardLayout instance = new CardLayout();
    instance.toString();
  }

  @Test
  public void next_test_57(Container p0) {
    CardLayout instance = new CardLayout();
    instance.next(p0);
  }

  @Test
  public void last_test_58(Container p0) {
    CardLayout instance = new CardLayout();
    instance.last(p0);
  }

  @Test
  public void first_test_59(Container p0) {
    CardLayout instance = new CardLayout();
    instance.first(p0);
  }

  @Test
  public void previous_test_60(Container p0) {
    CardLayout instance = new CardLayout();
    instance.previous(p0);
  }
}
