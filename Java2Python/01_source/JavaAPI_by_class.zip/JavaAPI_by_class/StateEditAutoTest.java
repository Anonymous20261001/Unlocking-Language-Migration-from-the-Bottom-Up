package generated.test;

import javax.swing.undo.StateEdit;
import javax.swing.undo.StateEditable;
import org.junit.jupiter.api.Test;

public class StateEditAutoTest {
  @Test
  public void getPresentationName_test_10826(StateEditable c0) {
    StateEdit instance = new StateEdit(c0);
    instance.getPresentationName();
  }

  @Test
  public void undo_test_10827(StateEditable c0) {
    StateEdit instance = new StateEdit(c0);
    instance.undo();
  }

  @Test
  public void redo_test_10828(StateEditable c0) {
    StateEdit instance = new StateEdit(c0);
    instance.redo();
  }

  @Test
  public void end_test_10829(StateEditable c0) {
    StateEdit instance = new StateEdit(c0);
    instance.end();
  }
}
