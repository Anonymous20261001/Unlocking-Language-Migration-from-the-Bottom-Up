package generated.test;

import java.io.FileDescriptor;
import org.junit.jupiter.api.Test;

public class FileDescriptorAutoTest {
  @Test
  public void valid_test_1774() {
    FileDescriptor instance = new FileDescriptor();
    instance.valid();
  }
}
