package generated.test;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FileAutoTest {
  @Test
  public void getName_test_1730(String c0) {
    File instance = new File(c0);
    instance.getName();
  }

  @Test
  public void equals_test_1731(Object p0, String c0) {
    File instance = new File(c0);
    instance.equals(p0);
  }

  @Test
  public void length_test_1732(String c0) {
    File instance = new File(c0);
    instance.length();
  }

  @Test
  public void toString_test_1733(String c0) {
    File instance = new File(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_1734(String c0) {
    File instance = new File(c0);
    instance.hashCode();
  }

  @Test
  public void isHidden_test_1735(String c0) {
    File instance = new File(c0);
    instance.isHidden();
  }

  @Test
  public void compareTo_test_1736(File p0, String c0) {
    File instance = new File(c0);
    instance.compareTo(p0);
  }

  @Test
  public void list_test_1737(String c0) {
    File instance = new File(c0);
    instance.list();
  }

  @Test
  public void list_test_1738(FilenameFilter p0, String c0) {
    File instance = new File(c0);
    instance.list(p0);
  }

  @Test
  public void isAbsolute_test_1739(String c0) {
    File instance = new File(c0);
    instance.isAbsolute();
  }

  @Test
  public void getParent_test_1740(String c0) {
    File instance = new File(c0);
    instance.getParent();
  }

  @Test
  public void setReadOnly_test_1741(String c0) {
    File instance = new File(c0);
    instance.setReadOnly();
  }

  @Test
  public void canRead_test_1742(String c0) {
    File instance = new File(c0);
    instance.canRead();
  }

  @Test
  public void delete_test_1743(String c0) {
    File instance = new File(c0);
    instance.delete();
  }

  @Test
  public void getPath_test_1744(String c0) {
    File instance = new File(c0);
    instance.getPath();
  }

  @Test
  public void toURI_test_1745(String c0) {
    File instance = new File(c0);
    instance.toURI();
  }

  @Test
  public void getAbsolutePath_test_1746(String c0) {
    File instance = new File(c0);
    instance.getAbsolutePath();
  }

  @Test
  public void exists_test_1747(String c0) {
    File instance = new File(c0);
    instance.exists();
  }

  @Test
  public void renameTo_test_1748(File p0, String c0) {
    File instance = new File(c0);
    instance.renameTo(p0);
  }

  @Test
  public void isDirectory_test_1749(String c0) {
    File instance = new File(c0);
    instance.isDirectory();
  }

  @Test
  public void getAbsoluteFile_test_1750(String c0) {
    File instance = new File(c0);
    instance.getAbsoluteFile();
  }

  @Test
  public void mkdir_test_1751(String c0) {
    File instance = new File(c0);
    instance.mkdir();
  }

  @Test
  public void getParentFile_test_1752(String c0) {
    File instance = new File(c0);
    instance.getParentFile();
  }

  @Test
  public void mkdirs_test_1753(String c0) {
    File instance = new File(c0);
    instance.mkdirs();
  }

  @Test
  public void setWritable_test_1754(boolean p0, String c0) {
    File instance = new File(c0);
    instance.setWritable(p0);
  }

  @Test
  public void setWritable_test_1755(boolean p0, boolean p1, String c0) {
    File instance = new File(c0);
    instance.setWritable(p0, p1);
  }

  @Test
  public void setReadable_test_1756(boolean p0, boolean p1, String c0) {
    File instance = new File(c0);
    instance.setReadable(p0, p1);
  }

  @Test
  public void setReadable_test_1757(boolean p0, String c0) {
    File instance = new File(c0);
    instance.setReadable(p0);
  }

  @Test
  public void setExecutable_test_1758(boolean p0, boolean p1, String c0) {
    File instance = new File(c0);
    instance.setExecutable(p0, p1);
  }

  @Test
  public void setExecutable_test_1759(boolean p0, String c0) {
    File instance = new File(c0);
    instance.setExecutable(p0);
  }

  @Test
  public void listRoots_test_1760(String c0) {
    File instance = new File(c0);
    File.listRoots();
  }

  @Test
  public void canWrite_test_1761(String c0) {
    File instance = new File(c0);
    instance.canWrite();
  }

  @Test
  public void isFile_test_1762(String c0) {
    File instance = new File(c0);
    instance.isFile();
  }

  @Test
  public void lastModified_test_1763(String c0) {
    File instance = new File(c0);
    instance.lastModified();
  }

  @Test
  public void deleteOnExit_test_1764(String c0) {
    File instance = new File(c0);
    instance.deleteOnExit();
  }

  @Test
  public void listFiles_test_1765(FileFilter p0, String c0) {
    File instance = new File(c0);
    instance.listFiles(p0);
  }

  @Test
  public void listFiles_test_1766(FilenameFilter p0, String c0) {
    File instance = new File(c0);
    instance.listFiles(p0);
  }

  @Test
  public void listFiles_test_1767(String c0) {
    File instance = new File(c0);
    instance.listFiles();
  }

  @Test
  public void setLastModified_test_1768(long p0, String c0) {
    File instance = new File(c0);
    instance.setLastModified(p0);
  }

  @Test
  public void canExecute_test_1769(String c0) {
    File instance = new File(c0);
    instance.canExecute();
  }

  @Test
  public void getTotalSpace_test_1770(String c0) {
    File instance = new File(c0);
    instance.getTotalSpace();
  }

  @Test
  public void getFreeSpace_test_1771(String c0) {
    File instance = new File(c0);
    instance.getFreeSpace();
  }

  @Test
  public void getUsableSpace_test_1772(String c0) {
    File instance = new File(c0);
    instance.getUsableSpace();
  }

  @Test
  public void toPath_test_1773(String c0) {
    File instance = new File(c0);
    instance.toPath();
  }
}
