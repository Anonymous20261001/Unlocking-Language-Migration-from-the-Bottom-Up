package generated.test;

import java.lang.Object;
import javax.lang.model.element.ModuleElement;
import javax.lang.model.element.UnknownDirectiveException;
import org.junit.jupiter.api.Test;

public class UnknownDirectiveExceptionAutoTest {
  @Test
  public void getUnknownDirective_test_5510(ModuleElement.Directive c0, Object c1) {
    UnknownDirectiveException instance = new UnknownDirectiveException(c0, c1);
    instance.getUnknownDirective();
  }

  @Test
  public void getArgument_test_5511(ModuleElement.Directive c0, Object c1) {
    UnknownDirectiveException instance = new UnknownDirectiveException(c0, c1);
    instance.getArgument();
  }
}
