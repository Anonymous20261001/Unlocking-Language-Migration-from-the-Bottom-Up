package generated.test;

import java.awt.Component;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.event.MenuKeyEvent;
import org.junit.jupiter.api.Test;

public class MenuKeyEventAutoTest {
  @Test
  public void getMenuSelectionManager_test_8547(Component c0, int c1, long c2, int c3, int c4,
      char c5, MenuElement[] c6, MenuSelectionManager c7) {
    MenuKeyEvent instance = new MenuKeyEvent(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getMenuSelectionManager();
  }

  @Test
  public void getPath_test_8548(Component c0, int c1, long c2, int c3, int c4, char c5,
      MenuElement[] c6, MenuSelectionManager c7) {
    MenuKeyEvent instance = new MenuKeyEvent(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPath();
  }
}
