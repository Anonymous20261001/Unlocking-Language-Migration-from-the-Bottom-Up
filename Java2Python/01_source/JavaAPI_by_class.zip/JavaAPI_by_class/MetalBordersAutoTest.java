package generated.test;

import javax.swing.plaf.metal.MetalBorders;
import org.junit.jupiter.api.Test;

public class MetalBordersAutoTest {
  @Test
  public void getTextBorder_test_9081() {
    MetalBorders instance = new MetalBorders();
    MetalBorders.getTextBorder();
  }

  @Test
  public void getDesktopIconBorder_test_9082() {
    MetalBorders instance = new MetalBorders();
    MetalBorders.getDesktopIconBorder();
  }

  @Test
  public void getButtonBorder_test_9083() {
    MetalBorders instance = new MetalBorders();
    MetalBorders.getButtonBorder();
  }

  @Test
  public void getToggleButtonBorder_test_9084() {
    MetalBorders instance = new MetalBorders();
    MetalBorders.getToggleButtonBorder();
  }

  @Test
  public void getTextFieldBorder_test_9085() {
    MetalBorders instance = new MetalBorders();
    MetalBorders.getTextFieldBorder();
  }
}
