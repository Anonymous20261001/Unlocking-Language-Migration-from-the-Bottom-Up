package generated.test;

import javax.swing.text.NavigationFilter;
import javax.swing.text.Position;
import org.junit.jupiter.api.Test;

public class NavigationFilterAutoTest {
  @Test
  public void setDot_test_10317(NavigationFilter.FilterBypass p0, int p1, Position.Bias p2) {
    NavigationFilter instance = new NavigationFilter();
    instance.setDot(p0, p1, p2);
  }

  @Test
  public void moveDot_test_10318(NavigationFilter.FilterBypass p0, int p1, Position.Bias p2) {
    NavigationFilter instance = new NavigationFilter();
    instance.moveDot(p0, p1, p2);
  }
}
