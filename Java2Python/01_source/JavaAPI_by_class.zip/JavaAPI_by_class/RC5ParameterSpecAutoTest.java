package generated.test;

import java.lang.Object;
import javax.crypto.spec.RC5ParameterSpec;
import org.junit.jupiter.api.Test;

public class RC5ParameterSpecAutoTest {
  @Test
  public void getIV_test_5266(int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.getIV();
  }

  @Test
  public void getRounds_test_5267(int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.getRounds();
  }

  @Test
  public void getWordSize_test_5268(int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.getWordSize();
  }

  @Test
  public void equals_test_5269(Object p0, int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5270(int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.hashCode();
  }

  @Test
  public void getVersion_test_5271(int c0, int c1, int c2) {
    RC5ParameterSpec instance = new RC5ParameterSpec(c0, c1, c2);
    instance.getVersion();
  }
}
