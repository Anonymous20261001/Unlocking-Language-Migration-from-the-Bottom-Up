package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.LayoutManager;
import javax.swing.JDialog;
import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.TransferHandler;
import org.junit.jupiter.api.Test;

public class JDialogAutoTest {
  @Test
  public void isDefaultLookAndFeelDecorated_test_6972() {
    JDialog instance = new JDialog();
    JDialog.isDefaultLookAndFeelDecorated();
  }

  @Test
  public void setDefaultCloseOperation_test_6973(int p0) {
    JDialog instance = new JDialog();
    instance.setDefaultCloseOperation(p0);
  }

  @Test
  public void getDefaultCloseOperation_test_6974() {
    JDialog instance = new JDialog();
    instance.getDefaultCloseOperation();
  }

  @Test
  public void setDefaultLookAndFeelDecorated_test_6975(boolean p0) {
    JDialog instance = new JDialog();
    JDialog.setDefaultLookAndFeelDecorated(p0);
  }

  @Test
  public void setTransferHandler_test_6976(TransferHandler p0) {
    JDialog instance = new JDialog();
    instance.setTransferHandler(p0);
  }

  @Test
  public void getTransferHandler_test_6977() {
    JDialog instance = new JDialog();
    instance.getTransferHandler();
  }

  @Test
  public void setJMenuBar_test_6978(JMenuBar p0) {
    JDialog instance = new JDialog();
    instance.setJMenuBar(p0);
  }

  @Test
  public void getJMenuBar_test_6979() {
    JDialog instance = new JDialog();
    instance.getJMenuBar();
  }

  @Test
  public void setContentPane_test_6980(Container p0) {
    JDialog instance = new JDialog();
    instance.setContentPane(p0);
  }

  @Test
  public void setLayeredPane_test_6981(JLayeredPane p0) {
    JDialog instance = new JDialog();
    instance.setLayeredPane(p0);
  }

  @Test
  public void getGlassPane_test_6982() {
    JDialog instance = new JDialog();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_6983(Component p0) {
    JDialog instance = new JDialog();
    instance.setGlassPane(p0);
  }

  @Test
  public void getAccessibleContext_test_6984() {
    JDialog instance = new JDialog();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_6985(LayoutManager p0) {
    JDialog instance = new JDialog();
    instance.setLayout(p0);
  }

  @Test
  public void repaint_test_6986(long p0, int p1, int p2, int p3, int p4) {
    JDialog instance = new JDialog();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void getGraphics_test_6987() {
    JDialog instance = new JDialog();
    instance.getGraphics();
  }

  @Test
  public void getRootPane_test_6988() {
    JDialog instance = new JDialog();
    instance.getRootPane();
  }

  @Test
  public void getLayeredPane_test_6989() {
    JDialog instance = new JDialog();
    instance.getLayeredPane();
  }

  @Test
  public void getContentPane_test_6990() {
    JDialog instance = new JDialog();
    instance.getContentPane();
  }

  @Test
  public void remove_test_6991(Component p0) {
    JDialog instance = new JDialog();
    instance.remove(p0);
  }

  @Test
  public void update_test_6992(Graphics p0) {
    JDialog instance = new JDialog();
    instance.update(p0);
  }
}
