package generated.test;

import java.lang.Object;
import java.math.BigInteger;
import java.security.spec.ECField;
import java.security.spec.EllipticCurve;
import org.junit.jupiter.api.Test;

public class EllipticCurveAutoTest {
  @Test
  public void getA_test_2889(ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.getA();
  }

  @Test
  public void getB_test_2890(ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.getB();
  }

  @Test
  public void equals_test_2891(Object p0, ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_2892(ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.hashCode();
  }

  @Test
  public void getField_test_2893(ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.getField();
  }

  @Test
  public void getSeed_test_2894(ECField c0, BigInteger c1, BigInteger c2) {
    EllipticCurve instance = new EllipticCurve(c0, c1, c2);
    instance.getSeed();
  }
}
