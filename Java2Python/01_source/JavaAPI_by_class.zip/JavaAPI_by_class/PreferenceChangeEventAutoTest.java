package generated.test;

import java.lang.String;
import java.util.prefs.PreferenceChangeEvent;
import java.util.prefs.Preferences;
import org.junit.jupiter.api.Test;

public class PreferenceChangeEventAutoTest {
  @Test
  public void getNewValue_test_5112(Preferences c0, String c1, String c2) {
    PreferenceChangeEvent instance = new PreferenceChangeEvent(c0, c1, c2);
    instance.getNewValue();
  }

  @Test
  public void getKey_test_5113(Preferences c0, String c1, String c2) {
    PreferenceChangeEvent instance = new PreferenceChangeEvent(c0, c1, c2);
    instance.getKey();
  }

  @Test
  public void getNode_test_5114(Preferences c0, String c1, String c2) {
    PreferenceChangeEvent instance = new PreferenceChangeEvent(c0, c1, c2);
    instance.getNode();
  }
}
