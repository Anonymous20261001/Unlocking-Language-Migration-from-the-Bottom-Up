package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthTabbedPaneUI;
import org.junit.jupiter.api.Test;

public class SynthTabbedPaneUIAutoTest {
  @Test
  public void propertyChange_test_9920(PropertyChangeEvent p0) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9921(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9922(JComponent p0) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    SynthTabbedPaneUI.createUI(p0);
  }

  @Test
  public void paint_test_9923(Graphics p0, JComponent p1) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9924(Graphics p0, JComponent p1) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9925(JComponent p0) {
    SynthTabbedPaneUI instance = new SynthTabbedPaneUI();
    instance.getContext(p0);
  }
}
