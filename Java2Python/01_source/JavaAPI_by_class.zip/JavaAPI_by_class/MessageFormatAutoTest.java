package generated.test;

import java.lang.Object;
import java.lang.String;
import java.lang.StringBuffer;
import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class MessageFormatAutoTest {
  @Test
  public void setFormatsByArgumentIndex_test_3175(Format[] p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.setFormatsByArgumentIndex(p0);
  }

  @Test
  public void setFormats_test_3176(Format[] p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.setFormats(p0);
  }

  @Test
  public void setFormatByArgumentIndex_test_3177(int p0, Format p1, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.setFormatByArgumentIndex(p0, p1);
  }

  @Test
  public void getFormatsByArgumentIndex_test_3178(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.getFormatsByArgumentIndex();
  }

  @Test
  public void equals_test_3179(Object p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_3180(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_3181(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_3182(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.clone();
  }

  @Test
  public void format_test_3183(Object[] p0, StringBuffer p1, FieldPosition p2, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.format(p0, p1, p2);
  }

  @Test
  public void format_test_3184(String p0, Object[] p1, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    MessageFormat.format(p0, p1);
  }

  @Test
  public void format_test_3185(Object p0, StringBuffer p1, FieldPosition p2, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.format(p0, p1, p2);
  }

  @Test
  public void parse_test_3186(String p0, ParsePosition p1, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.parse(p0, p1);
  }

  @Test
  public void parseObject_test_3187(String p0, ParsePosition p1, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.parseObject(p0, p1);
  }

  @Test
  public void formatToCharacterIterator_test_3188(Object p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.formatToCharacterIterator(p0);
  }

  @Test
  public void applyPattern_test_3189(String p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.applyPattern(p0);
  }

  @Test
  public void getLocale_test_3190(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.getLocale();
  }

  @Test
  public void toPattern_test_3191(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.toPattern();
  }

  @Test
  public void setLocale_test_3192(Locale p0, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.setLocale(p0);
  }

  @Test
  public void getFormats_test_3193(String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.getFormats();
  }

  @Test
  public void setFormat_test_3194(int p0, Format p1, String c0) {
    MessageFormat instance = new MessageFormat(c0);
    instance.setFormat(p0, p1);
  }
}
