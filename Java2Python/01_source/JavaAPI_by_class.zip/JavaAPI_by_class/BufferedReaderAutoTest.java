package generated.test;

import java.io.BufferedReader;
import java.io.Reader;
import org.junit.jupiter.api.Test;

public class BufferedReaderAutoTest {
  @Test
  public void lines_test_1695(Reader c0) {
    BufferedReader instance = new BufferedReader(c0);
    instance.lines();
  }

  @Test
  public void markSupported_test_1696(Reader c0) {
    BufferedReader instance = new BufferedReader(c0);
    instance.markSupported();
  }
}
