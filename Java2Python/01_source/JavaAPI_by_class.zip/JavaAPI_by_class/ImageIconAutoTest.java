package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.lang.String;
import javax.swing.ImageIcon;
import org.junit.jupiter.api.Test;

public class ImageIconAutoTest {
  @Test
  public void getIconWidth_test_6836() {
    ImageIcon instance = new ImageIcon();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_6837() {
    ImageIcon instance = new ImageIcon();
    instance.getIconHeight();
  }

  @Test
  public void getImageLoadStatus_test_6838() {
    ImageIcon instance = new ImageIcon();
    instance.getImageLoadStatus();
  }

  @Test
  public void setDescription_test_6839(String p0) {
    ImageIcon instance = new ImageIcon();
    instance.setDescription(p0);
  }

  @Test
  public void paintIcon_test_6840(Component p0, Graphics p1, int p2, int p3) {
    ImageIcon instance = new ImageIcon();
    instance.paintIcon(p0, p1, p2, p3);
  }

  @Test
  public void setImageObserver_test_6841(ImageObserver p0) {
    ImageIcon instance = new ImageIcon();
    instance.setImageObserver(p0);
  }

  @Test
  public void getImageObserver_test_6842() {
    ImageIcon instance = new ImageIcon();
    instance.getImageObserver();
  }

  @Test
  public void getDescription_test_6843() {
    ImageIcon instance = new ImageIcon();
    instance.getDescription();
  }

  @Test
  public void getImage_test_6844() {
    ImageIcon instance = new ImageIcon();
    instance.getImage();
  }

  @Test
  public void getAccessibleContext_test_6845() {
    ImageIcon instance = new ImageIcon();
    instance.getAccessibleContext();
  }

  @Test
  public void setImage_test_6846(Image p0) {
    ImageIcon instance = new ImageIcon();
    instance.setImage(p0);
  }

  @Test
  public void toString_test_6847() {
    ImageIcon instance = new ImageIcon();
    instance.toString();
  }
}
