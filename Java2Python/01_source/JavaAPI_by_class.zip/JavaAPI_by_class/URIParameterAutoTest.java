package generated.test;

import java.net.URI;
import java.security.URIParameter;
import org.junit.jupiter.api.Test;

public class URIParameterAutoTest {
  @Test
  public void getURI_test_2750(URI c0) {
    URIParameter instance = new URIParameter(c0);
    instance.getURI();
  }
}
