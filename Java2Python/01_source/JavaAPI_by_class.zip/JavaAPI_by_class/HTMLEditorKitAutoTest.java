package generated.test;

import java.awt.Cursor;
import javax.swing.JEditorPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;
import org.junit.jupiter.api.Test;

public class HTMLEditorKitAutoTest {
  @Test
  public void createDefaultDocument_test_10482() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.createDefaultDocument();
  }

  @Test
  public void getContentType_test_10483() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getContentType();
  }

  @Test
  public void deinstall_test_10484(JEditorPane p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.deinstall(p0);
  }

  @Test
  public void install_test_10485(JEditorPane p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.install(p0);
  }

  @Test
  public void getInputAttributes_test_10486() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getInputAttributes();
  }

  @Test
  public void getStyleSheet_test_10487() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getStyleSheet();
  }

  @Test
  public void getViewFactory_test_10488() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getViewFactory();
  }

  @Test
  public void isAutoFormSubmission_test_10489() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.isAutoFormSubmission();
  }

  @Test
  public void setStyleSheet_test_10490(StyleSheet p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.setStyleSheet(p0);
  }

  @Test
  public void setDefaultCursor_test_10491(Cursor p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.setDefaultCursor(p0);
  }

  @Test
  public void setLinkCursor_test_10492(Cursor p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.setLinkCursor(p0);
  }

  @Test
  public void getLinkCursor_test_10493() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getLinkCursor();
  }

  @Test
  public void setAutoFormSubmission_test_10494(boolean p0) {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.setAutoFormSubmission(p0);
  }

  @Test
  public void getActions_test_10495() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getActions();
  }

  @Test
  public void getAccessibleContext_test_10496() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getAccessibleContext();
  }

  @Test
  public void getDefaultCursor_test_10497() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.getDefaultCursor();
  }

  @Test
  public void clone_test_10498() {
    HTMLEditorKit instance = new HTMLEditorKit();
    instance.clone();
  }
}
