package generated.test;

import java.awt.Graphics;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalButtonUI;
import org.junit.jupiter.api.Test;

public class MetalButtonUIAutoTest {
  @Test
  public void createUI_test_9086(JComponent p0) {
    MetalButtonUI instance = new MetalButtonUI();
    MetalButtonUI.createUI(p0);
  }

  @Test
  public void installDefaults_test_9087(AbstractButton p0) {
    MetalButtonUI instance = new MetalButtonUI();
    instance.installDefaults(p0);
  }

  @Test
  public void uninstallDefaults_test_9088(AbstractButton p0) {
    MetalButtonUI instance = new MetalButtonUI();
    instance.uninstallDefaults(p0);
  }

  @Test
  public void update_test_9089(Graphics p0, JComponent p1) {
    MetalButtonUI instance = new MetalButtonUI();
    instance.update(p0, p1);
  }
}
