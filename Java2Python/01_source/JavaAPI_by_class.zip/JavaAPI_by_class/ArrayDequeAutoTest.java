package generated.test;

import java.lang.Object;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class ArrayDequeAutoTest {
  @Test
  public void remove_test_3277() {
    ArrayDeque instance = new ArrayDeque();
    instance.remove();
  }

  @Test
  public void remove_test_3278(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.remove(p0);
  }

  @Test
  public void size_test_3279() {
    ArrayDeque instance = new ArrayDeque();
    instance.size();
  }

  @Test
  public void clone_test_3280() {
    ArrayDeque instance = new ArrayDeque();
    instance.clone();
  }

  @Test
  public void clear_test_3281() {
    ArrayDeque instance = new ArrayDeque();
    instance.clear();
  }

  @Test
  public void isEmpty_test_3282() {
    ArrayDeque instance = new ArrayDeque();
    instance.isEmpty();
  }

  @Test
  public void add_test_3283(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.add(p0);
  }

  @Test
  public void toArray_test_3284(Object[] p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_3285() {
    ArrayDeque instance = new ArrayDeque();
    instance.toArray();
  }

  @Test
  public void iterator_test_3286() {
    ArrayDeque instance = new ArrayDeque();
    instance.iterator();
  }

  @Test
  public void contains_test_3287(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_3288() {
    ArrayDeque instance = new ArrayDeque();
    instance.spliterator();
  }

  @Test
  public void addAll_test_3289(Collection p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.addAll(p0);
  }

  @Test
  public void forEach_test_3290(Consumer p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.forEach(p0);
  }

  @Test
  public void peek_test_3291() {
    ArrayDeque instance = new ArrayDeque();
    instance.peek();
  }

  @Test
  public void removeIf_test_3292(Predicate p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.removeIf(p0);
  }

  @Test
  public void getFirst_test_3293() {
    ArrayDeque instance = new ArrayDeque();
    instance.getFirst();
  }

  @Test
  public void getLast_test_3294() {
    ArrayDeque instance = new ArrayDeque();
    instance.getLast();
  }

  @Test
  public void element_test_3295() {
    ArrayDeque instance = new ArrayDeque();
    instance.element();
  }

  @Test
  public void addFirst_test_3296(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.addFirst(p0);
  }

  @Test
  public void addLast_test_3297(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.addLast(p0);
  }

  @Test
  public void removeFirst_test_3298() {
    ArrayDeque instance = new ArrayDeque();
    instance.removeFirst();
  }

  @Test
  public void removeLast_test_3299() {
    ArrayDeque instance = new ArrayDeque();
    instance.removeLast();
  }

  @Test
  public void removeAll_test_3300(Collection p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_3301(Collection p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.retainAll(p0);
  }

  @Test
  public void poll_test_3302() {
    ArrayDeque instance = new ArrayDeque();
    instance.poll();
  }

  @Test
  public void offer_test_3303(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.offer(p0);
  }

  @Test
  public void push_test_3304(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.push(p0);
  }

  @Test
  public void pop_test_3305() {
    ArrayDeque instance = new ArrayDeque();
    instance.pop();
  }

  @Test
  public void pollFirst_test_3306() {
    ArrayDeque instance = new ArrayDeque();
    instance.pollFirst();
  }

  @Test
  public void pollLast_test_3307() {
    ArrayDeque instance = new ArrayDeque();
    instance.pollLast();
  }

  @Test
  public void offerLast_test_3308(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.offerLast(p0);
  }

  @Test
  public void peekFirst_test_3309() {
    ArrayDeque instance = new ArrayDeque();
    instance.peekFirst();
  }

  @Test
  public void removeFirstOccurrence_test_3310(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.removeFirstOccurrence(p0);
  }

  @Test
  public void offerFirst_test_3311(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.offerFirst(p0);
  }

  @Test
  public void peekLast_test_3312() {
    ArrayDeque instance = new ArrayDeque();
    instance.peekLast();
  }

  @Test
  public void removeLastOccurrence_test_3313(Object p0) {
    ArrayDeque instance = new ArrayDeque();
    instance.removeLastOccurrence(p0);
  }

  @Test
  public void descendingIterator_test_3314() {
    ArrayDeque instance = new ArrayDeque();
    instance.descendingIterator();
  }
}
