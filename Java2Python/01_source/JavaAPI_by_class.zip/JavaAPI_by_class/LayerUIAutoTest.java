package generated.test;

import java.awt.AWTEvent;
import java.awt.Graphics;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JLayer;
import javax.swing.plaf.LayerUI;
import org.junit.jupiter.api.Test;

public class LayerUIAutoTest {
  @Test
  public void installUI_test_8590(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8591(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void paintImmediately_test_8592(int p0, int p1, int p2, int p3, JLayer p4) {
    LayerUI instance = new LayerUI();
    instance.paintImmediately(p0, p1, p2, p3, p4);
  }

  @Test
  public void applyPropertyChange_test_8593(PropertyChangeEvent p0, JLayer p1) {
    LayerUI instance = new LayerUI();
    instance.applyPropertyChange(p0, p1);
  }

  @Test
  public void eventDispatched_test_8594(AWTEvent p0, JLayer p1) {
    LayerUI instance = new LayerUI();
    instance.eventDispatched(p0, p1);
  }

  @Test
  public void doLayout_test_8595(JLayer p0) {
    LayerUI instance = new LayerUI();
    instance.doLayout(p0);
  }

  @Test
  public void getMaximumSize_test_8596(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_8597(Graphics p0, JComponent p1) {
    LayerUI instance = new LayerUI();
    instance.paint(p0, p1);
  }

  @Test
  public void addPropertyChangeListener_test_8598(PropertyChangeListener p0) {
    LayerUI instance = new LayerUI();
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void addPropertyChangeListener_test_8599(String p0, PropertyChangeListener p1) {
    LayerUI instance = new LayerUI();
    instance.addPropertyChangeListener(p0, p1);
  }

  @Test
  public void getPreferredSize_test_8600(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_8601(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getPropertyChangeListeners_test_8602() {
    LayerUI instance = new LayerUI();
    instance.getPropertyChangeListeners();
  }

  @Test
  public void getPropertyChangeListeners_test_8603(String p0) {
    LayerUI instance = new LayerUI();
    instance.getPropertyChangeListeners(p0);
  }

  @Test
  public void removePropertyChangeListener_test_8604(PropertyChangeListener p0) {
    LayerUI instance = new LayerUI();
    instance.removePropertyChangeListener(p0);
  }

  @Test
  public void removePropertyChangeListener_test_8605(String p0, PropertyChangeListener p1) {
    LayerUI instance = new LayerUI();
    instance.removePropertyChangeListener(p0, p1);
  }

  @Test
  public void getBaseline_test_8606(JComponent p0, int p1, int p2) {
    LayerUI instance = new LayerUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void getBaselineResizeBehavior_test_8607(JComponent p0) {
    LayerUI instance = new LayerUI();
    instance.getBaselineResizeBehavior(p0);
  }

  @Test
  public void imageUpdate_test_8608(Image p0, int p1, int p2, int p3, int p4, int p5, JLayer p6) {
    LayerUI instance = new LayerUI();
    instance.imageUpdate(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void updateUI_test_8609(JLayer p0) {
    LayerUI instance = new LayerUI();
    instance.updateUI(p0);
  }
}
