package generated.test;

import javax.management.remote.JMXProviderException;
import org.junit.jupiter.api.Test;

public class JMXProviderExceptionAutoTest {
  @Test
  public void getCause_test_5838() {
    JMXProviderException instance = new JMXProviderException();
    instance.getCause();
  }
}
