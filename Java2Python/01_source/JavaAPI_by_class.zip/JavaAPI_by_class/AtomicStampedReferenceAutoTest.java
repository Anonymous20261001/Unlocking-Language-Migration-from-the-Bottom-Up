package generated.test;

import java.lang.Object;
import java.util.concurrent.atomic.AtomicStampedReference;
import org.junit.jupiter.api.Test;

public class AtomicStampedReferenceAutoTest {
  @Test
  public void getStamp_test_4938(Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.getStamp();
  }

  @Test
  public void attemptStamp_test_4939(Object p0, int p1, Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.attemptStamp(p0, p1);
  }

  @Test
  public void get_test_4940(int[] p0, Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.get(p0);
  }

  @Test
  public void getReference_test_4941(Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.getReference();
  }

  @Test
  public void set_test_4942(Object p0, int p1, Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.set(p0, p1);
  }

  @Test
  public void compareAndSet_test_4943(Object p0, Object p1, int p2, int p3, Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.compareAndSet(p0, p1, p2, p3);
  }

  @Test
  public void weakCompareAndSet_test_4944(Object p0, Object p1, int p2, int p3, Object c0, int c1) {
    AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
    instance.weakCompareAndSet(p0, p1, p2, p3);
  }
}
