package generated.test;

import java.io.PushbackReader;
import java.io.Reader;
import org.junit.jupiter.api.Test;

public class PushbackReaderAutoTest {
  @Test
  public void markSupported_test_1801(Reader c0) {
    PushbackReader instance = new PushbackReader(c0);
    instance.markSupported();
  }
}
