package generated.test;

import javax.swing.undo.CompoundEdit;
import javax.swing.undo.UndoableEdit;
import org.junit.jupiter.api.Test;

public class CompoundEditAutoTest {
  @Test
  public void canUndo_test_10815() {
    CompoundEdit instance = new CompoundEdit();
    instance.canUndo();
  }

  @Test
  public void canRedo_test_10816() {
    CompoundEdit instance = new CompoundEdit();
    instance.canRedo();
  }

  @Test
  public void getPresentationName_test_10817() {
    CompoundEdit instance = new CompoundEdit();
    instance.getPresentationName();
  }

  @Test
  public void die_test_10818() {
    CompoundEdit instance = new CompoundEdit();
    instance.die();
  }

  @Test
  public void isSignificant_test_10819() {
    CompoundEdit instance = new CompoundEdit();
    instance.isSignificant();
  }

  @Test
  public void getUndoPresentationName_test_10820() {
    CompoundEdit instance = new CompoundEdit();
    instance.getUndoPresentationName();
  }

  @Test
  public void getRedoPresentationName_test_10821() {
    CompoundEdit instance = new CompoundEdit();
    instance.getRedoPresentationName();
  }

  @Test
  public void isInProgress_test_10822() {
    CompoundEdit instance = new CompoundEdit();
    instance.isInProgress();
  }

  @Test
  public void addEdit_test_10823(UndoableEdit p0) {
    CompoundEdit instance = new CompoundEdit();
    instance.addEdit(p0);
  }

  @Test
  public void toString_test_10824() {
    CompoundEdit instance = new CompoundEdit();
    instance.toString();
  }

  @Test
  public void end_test_10825() {
    CompoundEdit instance = new CompoundEdit();
    instance.end();
  }
}
