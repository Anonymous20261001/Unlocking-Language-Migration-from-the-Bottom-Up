package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.lang.Integer;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.event.InternalFrameListener;
import javax.swing.plaf.InternalFrameUI;
import org.junit.jupiter.api.Test;

public class JInternalFrameAutoTest {
  @Test
  public void setDefaultCloseOperation_test_7091(int p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setDefaultCloseOperation(p0);
  }

  @Test
  public void getDefaultCloseOperation_test_7092() {
    JInternalFrame instance = new JInternalFrame();
    instance.getDefaultCloseOperation();
  }

  @Test
  public void getUIClassID_test_7093() {
    JInternalFrame instance = new JInternalFrame();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_7094() {
    JInternalFrame instance = new JInternalFrame();
    instance.getUI();
  }

  @Test
  public void setUI_test_7095(InternalFrameUI p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setUI(p0);
  }

  @Test
  public void getDesktopIcon_test_7096() {
    JInternalFrame instance = new JInternalFrame();
    instance.getDesktopIcon();
  }

  @Test
  public void getDesktopPane_test_7097() {
    JInternalFrame instance = new JInternalFrame();
    instance.getDesktopPane();
  }

  @Test
  public void getNormalBounds_test_7098() {
    JInternalFrame instance = new JInternalFrame();
    instance.getNormalBounds();
  }

  @Test
  public void setNormalBounds_test_7099(Rectangle p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setNormalBounds(p0);
  }

  @Test
  public void isIcon_test_7100() {
    JInternalFrame instance = new JInternalFrame();
    instance.isIcon();
  }

  @Test
  public void restoreSubcomponentFocus_test_7101() {
    JInternalFrame instance = new JInternalFrame();
    instance.restoreSubcomponentFocus();
  }

  @Test
  public void isMaximum_test_7102() {
    JInternalFrame instance = new JInternalFrame();
    instance.isMaximum();
  }

  @Test
  public void setClosable_test_7103(boolean p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setClosable(p0);
  }

  @Test
  public void isClosable_test_7104() {
    JInternalFrame instance = new JInternalFrame();
    instance.isClosable();
  }

  @Test
  public void setIconifiable_test_7105(boolean p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setIconifiable(p0);
  }

  @Test
  public void isIconifiable_test_7106() {
    JInternalFrame instance = new JInternalFrame();
    instance.isIconifiable();
  }

  @Test
  public void setMaximizable_test_7107(boolean p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setMaximizable(p0);
  }

  @Test
  public void isMaximizable_test_7108() {
    JInternalFrame instance = new JInternalFrame();
    instance.isMaximizable();
  }

  @Test
  public void setFrameIcon_test_7109(Icon p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setFrameIcon(p0);
  }

  @Test
  public void getFrameIcon_test_7110() {
    JInternalFrame instance = new JInternalFrame();
    instance.getFrameIcon();
  }

  @Test
  public void getLastCursor_test_7111() {
    JInternalFrame instance = new JInternalFrame();
    instance.getLastCursor();
  }

  @Test
  public void setDesktopIcon_test_7112(JInternalFrame.JDesktopIcon p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setDesktopIcon(p0);
  }

  @Test
  public void addInternalFrameListener_test_7113(InternalFrameListener p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.addInternalFrameListener(p0);
  }

  @Test
  public void removeInternalFrameListener_test_7114(InternalFrameListener p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.removeInternalFrameListener(p0);
  }

  @Test
  public void getInternalFrameListeners_test_7115() {
    JInternalFrame instance = new JInternalFrame();
    instance.getInternalFrameListeners();
  }

  @Test
  public void doDefaultCloseAction_test_7116() {
    JInternalFrame instance = new JInternalFrame();
    instance.doDefaultCloseAction();
  }

  @Test
  public void setJMenuBar_test_7117(JMenuBar p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setJMenuBar(p0);
  }

  @Test
  public void getJMenuBar_test_7118() {
    JInternalFrame instance = new JInternalFrame();
    instance.getJMenuBar();
  }

  @Test
  public void setContentPane_test_7119(Container p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setContentPane(p0);
  }

  @Test
  public void setLayeredPane_test_7120(JLayeredPane p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setLayeredPane(p0);
  }

  @Test
  public void getGlassPane_test_7121() {
    JInternalFrame instance = new JInternalFrame();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_7122(Component p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setGlassPane(p0);
  }

  @Test
  public void moveToBack_test_7123() {
    JInternalFrame instance = new JInternalFrame();
    instance.moveToBack();
  }

  @Test
  public void setLayer_test_7124(Integer p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setLayer(p0);
  }

  @Test
  public void setLayer_test_7125(int p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setLayer(p0);
  }

  @Test
  public void getAccessibleContext_test_7126() {
    JInternalFrame instance = new JInternalFrame();
    instance.getAccessibleContext();
  }

  @Test
  public void setLayout_test_7127(LayoutManager p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setLayout(p0);
  }

  @Test
  public void isFocusCycleRoot_test_7128() {
    JInternalFrame instance = new JInternalFrame();
    instance.isFocusCycleRoot();
  }

  @Test
  public void getFocusOwner_test_7129() {
    JInternalFrame instance = new JInternalFrame();
    instance.getFocusOwner();
  }

  @Test
  public void getMostRecentFocusOwner_test_7130() {
    JInternalFrame instance = new JInternalFrame();
    instance.getMostRecentFocusOwner();
  }

  @Test
  public void getFocusCycleRootAncestor_test_7131() {
    JInternalFrame instance = new JInternalFrame();
    instance.getFocusCycleRootAncestor();
  }

  @Test
  public void setFocusCycleRoot_test_7132(boolean p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setFocusCycleRoot(p0);
  }

  @Test
  public void show_test_7133() {
    JInternalFrame instance = new JInternalFrame();
    instance.show();
  }

  @Test
  public void hide_test_7134() {
    JInternalFrame instance = new JInternalFrame();
    instance.hide();
  }

  @Test
  public void reshape_test_7135(int p0, int p1, int p2, int p3) {
    JInternalFrame instance = new JInternalFrame();
    instance.reshape(p0, p1, p2, p3);
  }

  @Test
  public void setCursor_test_7136(Cursor p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setCursor(p0);
  }

  @Test
  public void updateUI_test_7137() {
    JInternalFrame instance = new JInternalFrame();
    instance.updateUI();
  }

  @Test
  public void setTitle_test_7138(String p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setTitle(p0);
  }

  @Test
  public void toFront_test_7139() {
    JInternalFrame instance = new JInternalFrame();
    instance.toFront();
  }

  @Test
  public void toBack_test_7140() {
    JInternalFrame instance = new JInternalFrame();
    instance.toBack();
  }

  @Test
  public void setResizable_test_7141(boolean p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setResizable(p0);
  }

  @Test
  public void getTitle_test_7142() {
    JInternalFrame instance = new JInternalFrame();
    instance.getTitle();
  }

  @Test
  public void isResizable_test_7143() {
    JInternalFrame instance = new JInternalFrame();
    instance.isResizable();
  }

  @Test
  public void getRootPane_test_7144() {
    JInternalFrame instance = new JInternalFrame();
    instance.getRootPane();
  }

  @Test
  public void getLayeredPane_test_7145() {
    JInternalFrame instance = new JInternalFrame();
    instance.getLayeredPane();
  }

  @Test
  public void getContentPane_test_7146() {
    JInternalFrame instance = new JInternalFrame();
    instance.getContentPane();
  }

  @Test
  public void pack_test_7147() {
    JInternalFrame instance = new JInternalFrame();
    instance.pack();
  }

  @Test
  public void getWarningString_test_7148() {
    JInternalFrame instance = new JInternalFrame();
    instance.getWarningString();
  }

  @Test
  public void setMenuBar_test_7149(JMenuBar p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.setMenuBar(p0);
  }

  @Test
  public void getMenuBar_test_7150() {
    JInternalFrame instance = new JInternalFrame();
    instance.getMenuBar();
  }

  @Test
  public void isSelected_test_7151() {
    JInternalFrame instance = new JInternalFrame();
    instance.isSelected();
  }

  @Test
  public void remove_test_7152(Component p0) {
    JInternalFrame instance = new JInternalFrame();
    instance.remove(p0);
  }

  @Test
  public void getLayer_test_7153() {
    JInternalFrame instance = new JInternalFrame();
    instance.getLayer();
  }

  @Test
  public void dispose_test_7154() {
    JInternalFrame instance = new JInternalFrame();
    instance.dispose();
  }

  @Test
  public void moveToFront_test_7155() {
    JInternalFrame instance = new JInternalFrame();
    instance.moveToFront();
  }

  @Test
  public void isClosed_test_7156() {
    JInternalFrame instance = new JInternalFrame();
    instance.isClosed();
  }
}
