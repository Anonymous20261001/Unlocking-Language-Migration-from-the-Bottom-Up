package generated.test;

import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.text.JTextComponent;
import javax.swing.text.Segment;
import javax.swing.text.TabExpander;
import javax.swing.text.Utilities;
import org.junit.jupiter.api.Test;

public class UtilitiesAutoTest {
  @Test
  public void getParagraphElement_test_10423(JTextComponent p0, int p1) {
    Utilities instance = new Utilities();
    Utilities.getParagraphElement(p0, p1);
  }

  @Test
  public void getTabbedTextWidth_test_10424(Segment p0, FontMetrics p1, int p2, TabExpander p3,
      int p4) {
    Utilities instance = new Utilities();
    Utilities.getTabbedTextWidth(p0, p1, p2, p3, p4);
  }

  @Test
  public void getTabbedTextWidth_test_10425(Segment p0, FontMetrics p1, float p2, TabExpander p3,
      int p4) {
    Utilities instance = new Utilities();
    Utilities.getTabbedTextWidth(p0, p1, p2, p3, p4);
  }

  @Test
  public void drawTabbedText_test_10426(Segment p0, int p1, int p2, Graphics p3, TabExpander p4,
      int p5) {
    Utilities instance = new Utilities();
    Utilities.drawTabbedText(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void drawTabbedText_test_10427(Segment p0, float p1, float p2, Graphics2D p3,
      TabExpander p4, int p5) {
    Utilities instance = new Utilities();
    Utilities.drawTabbedText(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getTabbedTextOffset_test_10428(Segment p0, FontMetrics p1, int p2, int p3,
      TabExpander p4, int p5) {
    Utilities instance = new Utilities();
    Utilities.getTabbedTextOffset(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getTabbedTextOffset_test_10429(Segment p0, FontMetrics p1, float p2, float p3,
      TabExpander p4, int p5, boolean p6) {
    Utilities instance = new Utilities();
    Utilities.getTabbedTextOffset(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getTabbedTextOffset_test_10430(Segment p0, FontMetrics p1, int p2, int p3,
      TabExpander p4, int p5, boolean p6) {
    Utilities instance = new Utilities();
    Utilities.getTabbedTextOffset(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getBreakLocation_test_10431(Segment p0, FontMetrics p1, int p2, int p3,
      TabExpander p4, int p5) {
    Utilities instance = new Utilities();
    Utilities.getBreakLocation(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBreakLocation_test_10432(Segment p0, FontMetrics p1, float p2, float p3,
      TabExpander p4, int p5) {
    Utilities instance = new Utilities();
    Utilities.getBreakLocation(p0, p1, p2, p3, p4, p5);
  }
}
