package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiScrollBarUI;
import org.junit.jupiter.api.Test;

public class MultiScrollBarUIAutoTest {
  @Test
  public void installUI_test_9513(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9514(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9515() {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9516(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    MultiScrollBarUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9517(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9518(Graphics p0, JComponent p1) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9519(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9520(JComponent p0, int p1) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9521(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9522(JComponent p0) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9523(Graphics p0, JComponent p1) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9524(JComponent p0, int p1, int p2) {
    MultiScrollBarUI instance = new MultiScrollBarUI();
    instance.contains(p0, p1, p2);
  }
}
