package generated.test;

import java.lang.Object;
import java.text.ParsePosition;
import org.junit.jupiter.api.Test;

public class ParsePositionAutoTest {
  @Test
  public void equals_test_3196(Object p0, int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_3197(int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_3198(int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.hashCode();
  }

  @Test
  public void getIndex_test_3199(int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.getIndex();
  }

  @Test
  public void setIndex_test_3200(int p0, int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.setIndex(p0);
  }

  @Test
  public void setErrorIndex_test_3201(int p0, int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.setErrorIndex(p0);
  }

  @Test
  public void getErrorIndex_test_3202(int c0) {
    ParsePosition instance = new ParsePosition(c0);
    instance.getErrorIndex();
  }
}
