package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSeparatorUI;
import org.junit.jupiter.api.Test;

public class MultiSeparatorUIAutoTest {
  @Test
  public void installUI_test_9537(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9538(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9539() {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9540(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    MultiSeparatorUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9541(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9542(Graphics p0, JComponent p1) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9543(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9544(JComponent p0, int p1) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9545(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9546(JComponent p0) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9547(Graphics p0, JComponent p1) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9548(JComponent p0, int p1, int p2) {
    MultiSeparatorUI instance = new MultiSeparatorUI();
    instance.contains(p0, p1, p2);
  }
}
