package generated.test;

import java.awt.Window;
import java.awt.event.WindowEvent;
import org.junit.jupiter.api.Test;

public class WindowEventAutoTest {
  @Test
  public void getOldState_test_817(Window c0, int c1) {
    WindowEvent instance = new WindowEvent(c0, c1);
    instance.getOldState();
  }

  @Test
  public void getNewState_test_818(Window c0, int c1) {
    WindowEvent instance = new WindowEvent(c0, c1);
    instance.getNewState();
  }

  @Test
  public void getOppositeWindow_test_819(Window c0, int c1) {
    WindowEvent instance = new WindowEvent(c0, c1);
    instance.getOppositeWindow();
  }

  @Test
  public void getWindow_test_820(Window c0, int c1) {
    WindowEvent instance = new WindowEvent(c0, c1);
    instance.getWindow();
  }

  @Test
  public void paramString_test_821(Window c0, int c1) {
    WindowEvent instance = new WindowEvent(c0, c1);
    instance.paramString();
  }
}
