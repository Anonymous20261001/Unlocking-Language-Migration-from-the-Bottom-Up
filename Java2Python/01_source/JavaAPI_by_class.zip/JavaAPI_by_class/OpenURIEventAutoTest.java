package generated.test;

import java.awt.desktop.OpenURIEvent;
import java.net.URI;
import org.junit.jupiter.api.Test;

public class OpenURIEventAutoTest {
  @Test
  public void getURI_test_681(URI c0) {
    OpenURIEvent instance = new OpenURIEvent(c0);
    instance.getURI();
  }
}
