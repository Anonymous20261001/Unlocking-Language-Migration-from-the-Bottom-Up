package generated.test;

import javax.imageio.plugins.tiff.TIFFImageReadParam;
import javax.imageio.plugins.tiff.TIFFTagSet;
import org.junit.jupiter.api.Test;

public class TIFFImageReadParamAutoTest {
  @Test
  public void addAllowedTagSet_test_5459(TIFFTagSet p0) {
    TIFFImageReadParam instance = new TIFFImageReadParam();
    instance.addAllowedTagSet(p0);
  }

  @Test
  public void removeAllowedTagSet_test_5460(TIFFTagSet p0) {
    TIFFImageReadParam instance = new TIFFImageReadParam();
    instance.removeAllowedTagSet(p0);
  }

  @Test
  public void getAllowedTagSets_test_5461() {
    TIFFImageReadParam instance = new TIFFImageReadParam();
    instance.getAllowedTagSets();
  }

  @Test
  public void setReadUnknownTags_test_5462(boolean p0) {
    TIFFImageReadParam instance = new TIFFImageReadParam();
    instance.setReadUnknownTags(p0);
  }

  @Test
  public void getReadUnknownTags_test_5463() {
    TIFFImageReadParam instance = new TIFFImageReadParam();
    instance.getReadUnknownTags();
  }
}
