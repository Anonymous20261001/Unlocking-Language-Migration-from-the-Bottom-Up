package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthCheckBoxUI;
import javax.swing.plaf.synth.SynthContext;
import org.junit.jupiter.api.Test;

public class SynthCheckBoxUIAutoTest {
  @Test
  public void paintBorder_test_9731(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthCheckBoxUI instance = new SynthCheckBoxUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9732(JComponent p0) {
    SynthCheckBoxUI instance = new SynthCheckBoxUI();
    SynthCheckBoxUI.createUI(p0);
  }
}
