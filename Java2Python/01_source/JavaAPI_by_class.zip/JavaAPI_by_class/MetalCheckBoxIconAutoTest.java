package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.plaf.metal.MetalCheckBoxIcon;
import org.junit.jupiter.api.Test;

public class MetalCheckBoxIconAutoTest {
  @Test
  public void getIconWidth_test_9090() {
    MetalCheckBoxIcon instance = new MetalCheckBoxIcon();
    instance.getIconWidth();
  }

  @Test
  public void getIconHeight_test_9091() {
    MetalCheckBoxIcon instance = new MetalCheckBoxIcon();
    instance.getIconHeight();
  }

  @Test
  public void paintIcon_test_9092(Component p0, Graphics p1, int p2, int p3) {
    MetalCheckBoxIcon instance = new MetalCheckBoxIcon();
    instance.paintIcon(p0, p1, p2, p3);
  }
}
