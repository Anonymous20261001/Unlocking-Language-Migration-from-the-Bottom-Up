package generated.test;

import java.beans.BeanDescriptor;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class BeanDescriptorAutoTest {
  @Test
  public void getBeanClass_test_1510(Class c0) {
    BeanDescriptor instance = new BeanDescriptor(c0);
    instance.getBeanClass();
  }

  @Test
  public void getCustomizerClass_test_1511(Class c0) {
    BeanDescriptor instance = new BeanDescriptor(c0);
    instance.getCustomizerClass();
  }
}
