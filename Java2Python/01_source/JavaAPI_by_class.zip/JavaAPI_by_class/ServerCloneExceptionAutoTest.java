package generated.test;

import java.lang.String;
import java.rmi.server.ServerCloneException;
import org.junit.jupiter.api.Test;

public class ServerCloneExceptionAutoTest {
  @Test
  public void getCause_test_2670(String c0) {
    ServerCloneException instance = new ServerCloneException(c0);
    instance.getCause();
  }

  @Test
  public void getMessage_test_2671(String c0) {
    ServerCloneException instance = new ServerCloneException(c0);
    instance.getMessage();
  }
}
