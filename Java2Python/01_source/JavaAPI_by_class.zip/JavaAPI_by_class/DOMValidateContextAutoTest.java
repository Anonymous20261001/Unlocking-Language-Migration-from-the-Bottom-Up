package generated.test;

import javax.xml.crypto.KeySelector;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Node;

public class DOMValidateContextAutoTest {
  @Test
  public void getNode_test_10887(KeySelector c0, Node c1) {
    DOMValidateContext instance = new DOMValidateContext(c0, c1);
    instance.getNode();
  }

  @Test
  public void setNode_test_10888(Node p0, KeySelector c0, Node c1) {
    DOMValidateContext instance = new DOMValidateContext(c0, c1);
    instance.setNode(p0);
  }
}
