package generated.test;

import java.awt.Panel;
import org.junit.jupiter.api.Test;

public class PanelAutoTest {
  @Test
  public void getAccessibleContext_test_439() {
    Panel instance = new Panel();
    instance.getAccessibleContext();
  }

  @Test
  public void addNotify_test_440() {
    Panel instance = new Panel();
    instance.addNotify();
  }
}
