package generated.test;

import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.StrokeBorder;
import org.junit.jupiter.api.Test;

public class StrokeBorderAutoTest {
  @Test
  public void paintBorder_test_8493(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
      BasicStroke c0) {
    StrokeBorder instance = new StrokeBorder(c0);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8494(Component p0, Insets p1, BasicStroke c0) {
    StrokeBorder instance = new StrokeBorder(c0);
    instance.getBorderInsets(p0, p1);
  }

  @Test
  public void getStroke_test_8495(BasicStroke c0) {
    StrokeBorder instance = new StrokeBorder(c0);
    instance.getStroke();
  }

  @Test
  public void getPaint_test_8496(BasicStroke c0) {
    StrokeBorder instance = new StrokeBorder(c0);
    instance.getPaint();
  }
}
