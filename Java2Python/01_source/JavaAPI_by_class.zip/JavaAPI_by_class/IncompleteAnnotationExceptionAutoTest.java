package generated.test;

import java.lang.Class;
import java.lang.String;
import java.lang.annotation.IncompleteAnnotationException;
import org.junit.jupiter.api.Test;

public class IncompleteAnnotationExceptionAutoTest {
  @Test
  public void annotationType_test_2374(Class c0, String c1) {
    IncompleteAnnotationException instance = new IncompleteAnnotationException(c0, c1);
    instance.annotationType();
  }

  @Test
  public void elementName_test_2375(Class c0, String c1) {
    IncompleteAnnotationException instance = new IncompleteAnnotationException(c0, c1);
    instance.elementName();
  }
}
