package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.SoftBevelBorder;
import org.junit.jupiter.api.Test;

public class SoftBevelBorderAutoTest {
  @Test
  public void paintBorder_test_8490(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
      int c0) {
    SoftBevelBorder instance = new SoftBevelBorder(c0);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8491(Component p0, Insets p1, int c0) {
    SoftBevelBorder instance = new SoftBevelBorder(c0);
    instance.getBorderInsets(p0, p1);
  }

  @Test
  public void isBorderOpaque_test_8492(int c0) {
    SoftBevelBorder instance = new SoftBevelBorder(c0);
    instance.isBorderOpaque();
  }
}
