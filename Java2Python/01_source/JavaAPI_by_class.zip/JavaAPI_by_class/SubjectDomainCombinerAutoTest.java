package generated.test;

import java.security.ProtectionDomain;
import javax.security.auth.Subject;
import javax.security.auth.SubjectDomainCombiner;
import org.junit.jupiter.api.Test;

public class SubjectDomainCombinerAutoTest {
  @Test
  public void getSubject_test_6324(Subject c0) {
    SubjectDomainCombiner instance = new SubjectDomainCombiner(c0);
    instance.getSubject();
  }

  @Test
  public void combine_test_6325(ProtectionDomain[] p0, ProtectionDomain[] p1, Subject c0) {
    SubjectDomainCombiner instance = new SubjectDomainCombiner(c0);
    instance.combine(p0, p1);
  }
}
