package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthListUI;
import org.junit.jupiter.api.Test;

public class SynthListUIAutoTest {
  @Test
  public void propertyChange_test_9795(PropertyChangeEvent p0) {
    SynthListUI instance = new SynthListUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9796(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthListUI instance = new SynthListUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9797(JComponent p0) {
    SynthListUI instance = new SynthListUI();
    SynthListUI.createUI(p0);
  }

  @Test
  public void update_test_9798(Graphics p0, JComponent p1) {
    SynthListUI instance = new SynthListUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9799(JComponent p0) {
    SynthListUI instance = new SynthListUI();
    instance.getContext(p0);
  }
}
