package generated.test;

import java.lang.String;
import javax.naming.StringRefAddr;
import org.junit.jupiter.api.Test;

public class StringRefAddrAutoTest {
  @Test
  public void getContent_test_5951(String c0, String c1) {
    StringRefAddr instance = new StringRefAddr(c0, c1);
    instance.getContent();
  }
}
