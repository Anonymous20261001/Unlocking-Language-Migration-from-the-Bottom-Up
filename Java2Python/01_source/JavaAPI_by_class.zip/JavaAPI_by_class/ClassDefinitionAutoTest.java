package generated.test;

import java.lang.Class;
import java.lang.instrument.ClassDefinition;
import org.junit.jupiter.api.Test;

public class ClassDefinitionAutoTest {
  @Test
  public void getDefinitionClass_test_2376(Class c0, byte[] c1) {
    ClassDefinition instance = new ClassDefinition(c0, c1);
    instance.getDefinitionClass();
  }

  @Test
  public void getDefinitionClassFile_test_2377(Class c0, byte[] c1) {
    ClassDefinition instance = new ClassDefinition(c0, c1);
    instance.getDefinitionClassFile();
  }
}
