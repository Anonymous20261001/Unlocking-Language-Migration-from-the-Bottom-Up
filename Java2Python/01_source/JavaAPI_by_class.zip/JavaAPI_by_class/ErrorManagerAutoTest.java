package generated.test;

import java.lang.Exception;
import java.lang.String;
import java.util.logging.ErrorManager;
import org.junit.jupiter.api.Test;

public class ErrorManagerAutoTest {
  @Test
  public void error_test_5066(String p0, Exception p1, int p2) {
    ErrorManager instance = new ErrorManager();
    instance.error(p0, p1, p2);
  }
}
