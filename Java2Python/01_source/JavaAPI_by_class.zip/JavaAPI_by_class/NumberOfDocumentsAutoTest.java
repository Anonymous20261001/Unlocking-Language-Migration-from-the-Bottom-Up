package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.NumberOfDocuments;
import org.junit.jupiter.api.Test;

public class NumberOfDocumentsAutoTest {
  @Test
  public void getCategory_test_6186(int c0) {
    NumberOfDocuments instance = new NumberOfDocuments(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6187(int c0) {
    NumberOfDocuments instance = new NumberOfDocuments(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6188(Object p0, int c0) {
    NumberOfDocuments instance = new NumberOfDocuments(c0);
    instance.equals(p0);
  }
}
