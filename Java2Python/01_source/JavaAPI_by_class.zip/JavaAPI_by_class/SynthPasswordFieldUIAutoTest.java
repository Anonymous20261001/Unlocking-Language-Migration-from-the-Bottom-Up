package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPasswordFieldUI;
import javax.swing.text.Element;
import org.junit.jupiter.api.Test;

public class SynthPasswordFieldUIAutoTest {
  @Test
  public void paintBorder_test_9849(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthPasswordFieldUI instance = new SynthPasswordFieldUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9850(JComponent p0) {
    SynthPasswordFieldUI instance = new SynthPasswordFieldUI();
    SynthPasswordFieldUI.createUI(p0);
  }

  @Test
  public void create_test_9851(Element p0) {
    SynthPasswordFieldUI instance = new SynthPasswordFieldUI();
    instance.create(p0);
  }
}
