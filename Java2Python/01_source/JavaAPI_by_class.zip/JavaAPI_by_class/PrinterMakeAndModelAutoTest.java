package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Locale;
import javax.print.attribute.standard.PrinterMakeAndModel;
import org.junit.jupiter.api.Test;

public class PrinterMakeAndModelAutoTest {
  @Test
  public void getCategory_test_6216(String c0, Locale c1) {
    PrinterMakeAndModel instance = new PrinterMakeAndModel(c0, c1);
    instance.getCategory();
  }

  @Test
  public void getName_test_6217(String c0, Locale c1) {
    PrinterMakeAndModel instance = new PrinterMakeAndModel(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_6218(Object p0, String c0, Locale c1) {
    PrinterMakeAndModel instance = new PrinterMakeAndModel(c0, c1);
    instance.equals(p0);
  }
}
