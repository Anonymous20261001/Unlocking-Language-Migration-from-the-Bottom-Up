package generated.test;

import java.lang.CharSequence;
import java.lang.Object;
import java.lang.String;
import java.lang.StringBuffer;
import org.junit.jupiter.api.Test;

public class StringBufferAutoTest {
  @Test
  public void length_test_2205() {
    StringBuffer instance = new StringBuffer();
    instance.length();
  }

  @Test
  public void toString_test_2206() {
    StringBuffer instance = new StringBuffer();
    instance.toString();
  }

  @Test
  public void append_test_2207(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2208(long p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2209(float p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2210(char[] p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2211(char[] p0, int p1, int p2) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_2212(boolean p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2213(char p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2214(double p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2215(String p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2216(StringBuffer p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2217(CharSequence p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void append_test_2218(CharSequence p0, int p1, int p2) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_2219(Object p0) {
    StringBuffer instance = new StringBuffer();
    instance.append(p0);
  }

  @Test
  public void reverse_test_2220() {
    StringBuffer instance = new StringBuffer();
    instance.reverse();
  }

  @Test
  public void getChars_test_2221(int p0, int p1, char[] p2, int p3) {
    StringBuffer instance = new StringBuffer();
    instance.getChars(p0, p1, p2, p3);
  }

  @Test
  public void compareTo_test_2222(StringBuffer p0) {
    StringBuffer instance = new StringBuffer();
    instance.compareTo(p0);
  }

  @Test
  public void indexOf_test_2223(String p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.indexOf(p0, p1);
  }

  @Test
  public void indexOf_test_2224(String p0) {
    StringBuffer instance = new StringBuffer();
    instance.indexOf(p0);
  }

  @Test
  public void insert_test_2225(int p0, Object p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2226(int p0, char[] p1, int p2, int p3) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1, p2, p3);
  }

  @Test
  public void insert_test_2227(int p0, char[] p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2228(int p0, float p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2229(int p0, long p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2230(int p0, String p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2231(int p0, CharSequence p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2232(int p0, CharSequence p1, int p2, int p3) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1, p2, p3);
  }

  @Test
  public void insert_test_2233(int p0, boolean p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2234(int p0, double p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2235(int p0, char p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2236(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.insert(p0, p1);
  }

  @Test
  public void charAt_test_2237(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.charAt(p0);
  }

  @Test
  public void codePointAt_test_2238(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.codePointAt(p0);
  }

  @Test
  public void codePointBefore_test_2239(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.codePointBefore(p0);
  }

  @Test
  public void codePointCount_test_2240(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.codePointCount(p0, p1);
  }

  @Test
  public void offsetByCodePoints_test_2241(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.offsetByCodePoints(p0, p1);
  }

  @Test
  public void lastIndexOf_test_2242(String p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.lastIndexOf(p0, p1);
  }

  @Test
  public void lastIndexOf_test_2243(String p0) {
    StringBuffer instance = new StringBuffer();
    instance.lastIndexOf(p0);
  }

  @Test
  public void substring_test_2244(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.substring(p0);
  }

  @Test
  public void substring_test_2245(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.substring(p0, p1);
  }

  @Test
  public void replace_test_2246(int p0, int p1, String p2) {
    StringBuffer instance = new StringBuffer();
    instance.replace(p0, p1, p2);
  }

  @Test
  public void repeat_test_2247(CharSequence p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.repeat(p0, p1);
  }

  @Test
  public void repeat_test_2248(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.repeat(p0, p1);
  }

  @Test
  public void subSequence_test_2249(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.subSequence(p0, p1);
  }

  @Test
  public void trimToSize_test_2250() {
    StringBuffer instance = new StringBuffer();
    instance.trimToSize();
  }

  @Test
  public void setLength_test_2251(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.setLength(p0);
  }

  @Test
  public void capacity_test_2252() {
    StringBuffer instance = new StringBuffer();
    instance.capacity();
  }

  @Test
  public void ensureCapacity_test_2253(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.ensureCapacity(p0);
  }

  @Test
  public void setCharAt_test_2254(int p0, char p1) {
    StringBuffer instance = new StringBuffer();
    instance.setCharAt(p0, p1);
  }

  @Test
  public void appendCodePoint_test_2255(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.appendCodePoint(p0);
  }

  @Test
  public void delete_test_2256(int p0, int p1) {
    StringBuffer instance = new StringBuffer();
    instance.delete(p0, p1);
  }

  @Test
  public void deleteCharAt_test_2257(int p0) {
    StringBuffer instance = new StringBuffer();
    instance.deleteCharAt(p0);
  }
}
