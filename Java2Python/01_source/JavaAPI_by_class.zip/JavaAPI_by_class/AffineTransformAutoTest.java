package generated.test;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class AffineTransformAutoTest {
  @Test
  public void setToTranslation_test_920(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.setToTranslation(p0, p1);
  }

  @Test
  public void setToRotation_test_921(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.setToRotation(p0, p1);
  }

  @Test
  public void setToRotation_test_922(double p0, double p1, double p2, double p3) {
    AffineTransform instance = new AffineTransform();
    instance.setToRotation(p0, p1, p2, p3);
  }

  @Test
  public void setToRotation_test_923(double p0) {
    AffineTransform instance = new AffineTransform();
    instance.setToRotation(p0);
  }

  @Test
  public void setToRotation_test_924(double p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    instance.setToRotation(p0, p1, p2);
  }

  @Test
  public void setToQuadrantRotation_test_925(int p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    instance.setToQuadrantRotation(p0, p1, p2);
  }

  @Test
  public void setToQuadrantRotation_test_926(int p0) {
    AffineTransform instance = new AffineTransform();
    instance.setToQuadrantRotation(p0);
  }

  @Test
  public void setToScale_test_927(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.setToScale(p0, p1);
  }

  @Test
  public void setToShear_test_928(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.setToShear(p0, p1);
  }

  @Test
  public void getRotateInstance_test_929(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getRotateInstance(p0, p1);
  }

  @Test
  public void getRotateInstance_test_930(double p0) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getRotateInstance(p0);
  }

  @Test
  public void getRotateInstance_test_931(double p0, double p1, double p2, double p3) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getRotateInstance(p0, p1, p2, p3);
  }

  @Test
  public void getRotateInstance_test_932(double p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getRotateInstance(p0, p1, p2);
  }

  @Test
  public void getQuadrantRotateInstance_test_933(int p0) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getQuadrantRotateInstance(p0);
  }

  @Test
  public void getQuadrantRotateInstance_test_934(int p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getQuadrantRotateInstance(p0, p1, p2);
  }

  @Test
  public void getScaleInstance_test_935(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getScaleInstance(p0, p1);
  }

  @Test
  public void getShearInstance_test_936(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getShearInstance(p0, p1);
  }

  @Test
  public void getDeterminant_test_937() {
    AffineTransform instance = new AffineTransform();
    instance.getDeterminant();
  }

  @Test
  public void getShearX_test_938() {
    AffineTransform instance = new AffineTransform();
    instance.getShearX();
  }

  @Test
  public void getShearY_test_939() {
    AffineTransform instance = new AffineTransform();
    instance.getShearY();
  }

  @Test
  public void getTranslateX_test_940() {
    AffineTransform instance = new AffineTransform();
    instance.getTranslateX();
  }

  @Test
  public void quadrantRotate_test_941(int p0) {
    AffineTransform instance = new AffineTransform();
    instance.quadrantRotate(p0);
  }

  @Test
  public void quadrantRotate_test_942(int p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    instance.quadrantRotate(p0, p1, p2);
  }

  @Test
  public void shear_test_943(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.shear(p0, p1);
  }

  @Test
  public void setToIdentity_test_944() {
    AffineTransform instance = new AffineTransform();
    instance.setToIdentity();
  }

  @Test
  public void createTransformedShape_test_945(Shape p0) {
    AffineTransform instance = new AffineTransform();
    instance.createTransformedShape(p0);
  }

  @Test
  public void translate_test_946(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.translate(p0, p1);
  }

  @Test
  public void getTranslateInstance_test_947(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    AffineTransform.getTranslateInstance(p0, p1);
  }

  @Test
  public void preConcatenate_test_948(AffineTransform p0) {
    AffineTransform instance = new AffineTransform();
    instance.preConcatenate(p0);
  }

  @Test
  public void getTranslateY_test_949() {
    AffineTransform instance = new AffineTransform();
    instance.getTranslateY();
  }

  @Test
  public void deltaTransform_test_950(Point2D p0, Point2D p1) {
    AffineTransform instance = new AffineTransform();
    instance.deltaTransform(p0, p1);
  }

  @Test
  public void deltaTransform_test_951(double[] p0, int p1, double[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.deltaTransform(p0, p1, p2, p3, p4);
  }

  @Test
  public void setTransform_test_952(AffineTransform p0) {
    AffineTransform instance = new AffineTransform();
    instance.setTransform(p0);
  }

  @Test
  public void setTransform_test_953(double p0, double p1, double p2, double p3, double p4,
      double p5) {
    AffineTransform instance = new AffineTransform();
    instance.setTransform(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void concatenate_test_954(AffineTransform p0) {
    AffineTransform instance = new AffineTransform();
    instance.concatenate(p0);
  }

  @Test
  public void getScaleX_test_955() {
    AffineTransform instance = new AffineTransform();
    instance.getScaleX();
  }

  @Test
  public void getScaleY_test_956() {
    AffineTransform instance = new AffineTransform();
    instance.getScaleY();
  }

  @Test
  public void getMatrix_test_957(double[] p0) {
    AffineTransform instance = new AffineTransform();
    instance.getMatrix(p0);
  }

  @Test
  public void equals_test_958(Object p0) {
    AffineTransform instance = new AffineTransform();
    instance.equals(p0);
  }

  @Test
  public void toString_test_959() {
    AffineTransform instance = new AffineTransform();
    instance.toString();
  }

  @Test
  public void hashCode_test_960() {
    AffineTransform instance = new AffineTransform();
    instance.hashCode();
  }

  @Test
  public void clone_test_961() {
    AffineTransform instance = new AffineTransform();
    instance.clone();
  }

  @Test
  public void scale_test_962(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.scale(p0, p1);
  }

  @Test
  public void transform_test_963(double[] p0, int p1, float[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1, p2, p3, p4);
  }

  @Test
  public void transform_test_964(Point2D[] p0, int p1, Point2D[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1, p2, p3, p4);
  }

  @Test
  public void transform_test_965(float[] p0, int p1, double[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1, p2, p3, p4);
  }

  @Test
  public void transform_test_966(float[] p0, int p1, float[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1, p2, p3, p4);
  }

  @Test
  public void transform_test_967(double[] p0, int p1, double[] p2, int p3, int p4) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1, p2, p3, p4);
  }

  @Test
  public void transform_test_968(Point2D p0, Point2D p1) {
    AffineTransform instance = new AffineTransform();
    instance.transform(p0, p1);
  }

  @Test
  public void getType_test_969() {
    AffineTransform instance = new AffineTransform();
    instance.getType();
  }

  @Test
  public void isIdentity_test_970() {
    AffineTransform instance = new AffineTransform();
    instance.isIdentity();
  }

  @Test
  public void rotate_test_971(double p0, double p1, double p2, double p3) {
    AffineTransform instance = new AffineTransform();
    instance.rotate(p0, p1, p2, p3);
  }

  @Test
  public void rotate_test_972(double p0, double p1) {
    AffineTransform instance = new AffineTransform();
    instance.rotate(p0, p1);
  }

  @Test
  public void rotate_test_973(double p0, double p1, double p2) {
    AffineTransform instance = new AffineTransform();
    instance.rotate(p0, p1, p2);
  }

  @Test
  public void rotate_test_974(double p0) {
    AffineTransform instance = new AffineTransform();
    instance.rotate(p0);
  }
}
