package generated.test;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthComboBoxUI;
import javax.swing.plaf.synth.SynthContext;
import org.junit.jupiter.api.Test;

public class SynthComboBoxUIAutoTest {
  @Test
  public void propertyChange_test_9739(PropertyChangeEvent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintCurrentValue_test_9740(Graphics p0, Rectangle p1, boolean p2) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.paintCurrentValue(p0, p1, p2);
  }

  @Test
  public void installUI_test_9741(JComponent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9742(JComponent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void paintBorder_test_9743(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9744(JComponent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    SynthComboBoxUI.createUI(p0);
  }

  @Test
  public void paint_test_9745(Graphics p0, JComponent p1) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getMinimumSize_test_9746(JComponent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9747(Graphics p0, JComponent p1) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9748(JComponent p0) {
    SynthComboBoxUI instance = new SynthComboBoxUI();
    instance.getContext(p0);
  }
}
