package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.EtchedBorder;
import org.junit.jupiter.api.Test;

public class EtchedBorderAutoTest {
  @Test
  public void paintBorder_test_8468(Component p0, Graphics p1, int p2, int p3, int p4, int p5) {
    EtchedBorder instance = new EtchedBorder();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getBorderInsets_test_8469(Component p0, Insets p1) {
    EtchedBorder instance = new EtchedBorder();
    instance.getBorderInsets(p0, p1);
  }

  @Test
  public void isBorderOpaque_test_8470() {
    EtchedBorder instance = new EtchedBorder();
    instance.isBorderOpaque();
  }

  @Test
  public void getHighlightColor_test_8471(Component p0) {
    EtchedBorder instance = new EtchedBorder();
    instance.getHighlightColor(p0);
  }

  @Test
  public void getHighlightColor_test_8472() {
    EtchedBorder instance = new EtchedBorder();
    instance.getHighlightColor();
  }

  @Test
  public void getShadowColor_test_8473() {
    EtchedBorder instance = new EtchedBorder();
    instance.getShadowColor();
  }

  @Test
  public void getShadowColor_test_8474(Component p0) {
    EtchedBorder instance = new EtchedBorder();
    instance.getShadowColor(p0);
  }

  @Test
  public void getEtchType_test_8475() {
    EtchedBorder instance = new EtchedBorder();
    instance.getEtchType();
  }
}
