package generated.test;

import java.lang.Object;
import javax.swing.JList;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import org.junit.jupiter.api.Test;

public class BasicComboBoxRendererAutoTest {
  @Test
  public void getListCellRendererComponent_test_8665(JList p0, Object p1, int p2, boolean p3,
      boolean p4) {
    BasicComboBoxRenderer instance = new BasicComboBoxRenderer();
    instance.getListCellRendererComponent(p0, p1, p2, p3, p4);
  }

  @Test
  public void getPreferredSize_test_8666() {
    BasicComboBoxRenderer instance = new BasicComboBoxRenderer();
    instance.getPreferredSize();
  }
}
