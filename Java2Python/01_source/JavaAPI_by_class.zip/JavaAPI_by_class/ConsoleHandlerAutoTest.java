package generated.test;

import java.util.logging.ConsoleHandler;
import java.util.logging.LogRecord;
import org.junit.jupiter.api.Test;

public class ConsoleHandlerAutoTest {
  @Test
  public void close_test_5064() {
    ConsoleHandler instance = new ConsoleHandler();
    instance.close();
  }

  @Test
  public void publish_test_5065(LogRecord p0) {
    ConsoleHandler instance = new ConsoleHandler();
    instance.publish(p0);
  }
}
