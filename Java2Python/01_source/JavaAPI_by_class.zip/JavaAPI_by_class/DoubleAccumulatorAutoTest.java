package generated.test;

import java.util.concurrent.atomic.DoubleAccumulator;
import java.util.function.DoubleBinaryOperator;
import org.junit.jupiter.api.Test;

public class DoubleAccumulatorAutoTest {
  @Test
  public void accumulate_test_4945(double p0, DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.accumulate(p0);
  }

  @Test
  public void getThenReset_test_4946(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.getThenReset();
  }

  @Test
  public void reset_test_4947(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.reset();
  }

  @Test
  public void get_test_4948(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.get();
  }

  @Test
  public void toString_test_4949(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.toString();
  }

  @Test
  public void intValue_test_4950(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.intValue();
  }

  @Test
  public void longValue_test_4951(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.longValue();
  }

  @Test
  public void floatValue_test_4952(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_4953(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance = new DoubleAccumulator(c0, c1);
    instance.doubleValue();
  }
}
