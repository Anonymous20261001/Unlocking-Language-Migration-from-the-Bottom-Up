package generated.test;

import java.util.concurrent.Semaphore;
import org.junit.jupiter.api.Test;

public class SemaphoreAutoTest {
  @Test
  public void drainPermits_test_4655(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.drainPermits();
  }

  @Test
  public void acquireUninterruptibly_test_4656(int p0, int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.acquireUninterruptibly(p0);
  }

  @Test
  public void acquireUninterruptibly_test_4657(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.acquireUninterruptibly();
  }

  @Test
  public void availablePermits_test_4658(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.availablePermits();
  }

  @Test
  public void toString_test_4659(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.toString();
  }

  @Test
  public void release_test_4660(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.release();
  }

  @Test
  public void release_test_4661(int p0, int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.release(p0);
  }

  @Test
  public void hasQueuedThreads_test_4662(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.hasQueuedThreads();
  }

  @Test
  public void getQueueLength_test_4663(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.getQueueLength();
  }

  @Test
  public void isFair_test_4664(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.isFair();
  }

  @Test
  public void tryAcquire_test_4665(int p0, int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.tryAcquire(p0);
  }

  @Test
  public void tryAcquire_test_4666(int c0) {
    Semaphore instance = new Semaphore(c0);
    instance.tryAcquire();
  }
}
