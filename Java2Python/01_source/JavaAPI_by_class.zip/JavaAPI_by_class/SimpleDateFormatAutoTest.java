package generated.test;

import java.lang.Object;
import java.lang.String;
import java.lang.StringBuffer;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class SimpleDateFormatAutoTest {
  @Test
  public void equals_test_3203(Object p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.equals(p0);
  }

  @Test
  public void toString_test_3204() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.toString();
  }

  @Test
  public void hashCode_test_3205() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.hashCode();
  }

  @Test
  public void clone_test_3206() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.clone();
  }

  @Test
  public void format_test_3207(Date p0, StringBuffer p1, FieldPosition p2) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.format(p0, p1, p2);
  }

  @Test
  public void parse_test_3208(String p0, ParsePosition p1) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.parse(p0, p1);
  }

  @Test
  public void formatToCharacterIterator_test_3209(Object p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.formatToCharacterIterator(p0);
  }

  @Test
  public void applyPattern_test_3210(String p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.applyPattern(p0);
  }

  @Test
  public void toPattern_test_3211() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.toPattern();
  }

  @Test
  public void toLocalizedPattern_test_3212() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.toLocalizedPattern();
  }

  @Test
  public void applyLocalizedPattern_test_3213(String p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.applyLocalizedPattern(p0);
  }

  @Test
  public void set2DigitYearStart_test_3214(Date p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.set2DigitYearStart(p0);
  }

  @Test
  public void get2DigitYearStart_test_3215() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.get2DigitYearStart();
  }

  @Test
  public void getDateFormatSymbols_test_3216() {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.getDateFormatSymbols();
  }

  @Test
  public void setDateFormatSymbols_test_3217(DateFormatSymbols p0) {
    SimpleDateFormat instance = new SimpleDateFormat();
    instance.setDateFormatSymbols(p0);
  }
}
