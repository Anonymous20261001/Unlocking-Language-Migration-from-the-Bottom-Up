package generated.test;

import java.util.List;
import javax.xml.crypto.dsig.spec.XPathFilter2ParameterSpec;
import org.junit.jupiter.api.Test;

public class XPathFilter2ParameterSpecAutoTest {
  @Test
  public void getXPathList_test_10892(List c0) {
    XPathFilter2ParameterSpec instance = new XPathFilter2ParameterSpec(c0);
    instance.getXPathList();
  }
}
