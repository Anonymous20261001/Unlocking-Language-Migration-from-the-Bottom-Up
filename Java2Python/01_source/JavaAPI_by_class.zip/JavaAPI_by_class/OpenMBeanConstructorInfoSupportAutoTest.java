package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.openmbean.OpenMBeanConstructorInfoSupport;
import javax.management.openmbean.OpenMBeanParameterInfo;
import org.junit.jupiter.api.Test;

public class OpenMBeanConstructorInfoSupportAutoTest {
  @Test
  public void equals_test_5757(Object p0, String c0, String c1, OpenMBeanParameterInfo[] c2) {
    OpenMBeanConstructorInfoSupport instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5758(String c0, String c1, OpenMBeanParameterInfo[] c2) {
    OpenMBeanConstructorInfoSupport instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void hashCode_test_5759(String c0, String c1, OpenMBeanParameterInfo[] c2) {
    OpenMBeanConstructorInfoSupport instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
    instance.hashCode();
  }
}
