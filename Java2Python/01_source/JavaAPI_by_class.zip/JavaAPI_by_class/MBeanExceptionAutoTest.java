package generated.test;

import java.lang.Exception;
import javax.management.MBeanException;
import org.junit.jupiter.api.Test;

public class MBeanExceptionAutoTest {
  @Test
  public void getCause_test_5565(Exception c0) {
    MBeanException instance = new MBeanException(c0);
    instance.getCause();
  }

  @Test
  public void getTargetException_test_5566(Exception c0) {
    MBeanException instance = new MBeanException(c0);
    instance.getTargetException();
  }
}
