package generated.test;

import java.lang.Object;
import java.lang.Short;
import org.junit.jupiter.api.Test;

public class ShortAutoTest {
  @Test
  public void equals_test_2091(Object p0, short c0) {
    Short instance = new Short(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2092(short c0) {
    Short instance = new Short(c0);
    instance.toString();
  }

  @Test
  public void toString_test_2093(short p0, short c0) {
    Short instance = new Short(c0);
    Short.toString(p0);
  }

  @Test
  public void hashCode_test_2094(short p0, short c0) {
    Short instance = new Short(c0);
    Short.hashCode(p0);
  }

  @Test
  public void hashCode_test_2095(short c0) {
    Short instance = new Short(c0);
    instance.hashCode();
  }

  @Test
  public void compareUnsigned_test_2096(short p0, short p1, short c0) {
    Short instance = new Short(c0);
    Short.compareUnsigned(p0, p1);
  }

  @Test
  public void reverseBytes_test_2097(short p0, short c0) {
    Short instance = new Short(c0);
    Short.reverseBytes(p0);
  }

  @Test
  public void compareTo_test_2098(Short p0, short c0) {
    Short instance = new Short(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compare_test_2099(short p0, short p1, short c0) {
    Short instance = new Short(c0);
    Short.compare(p0, p1);
  }

  @Test
  public void byteValue_test_2100(short c0) {
    Short instance = new Short(c0);
    instance.byteValue();
  }

  @Test
  public void shortValue_test_2101(short c0) {
    Short instance = new Short(c0);
    instance.shortValue();
  }

  @Test
  public void intValue_test_2102(short c0) {
    Short instance = new Short(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_2103(short c0) {
    Short instance = new Short(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_2104(short c0) {
    Short instance = new Short(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_2105(short c0) {
    Short instance = new Short(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_2106(short p0, short c0) {
    Short instance = new Short(c0);
    Short.valueOf(p0);
  }

  @Test
  public void describeConstable_test_2107(short c0) {
    Short instance = new Short(c0);
    instance.describeConstable();
  }

  @Test
  public void toUnsignedLong_test_2108(short p0, short c0) {
    Short instance = new Short(c0);
    Short.toUnsignedLong(p0);
  }

  @Test
  public void toUnsignedInt_test_2109(short p0, short c0) {
    Short instance = new Short(c0);
    Short.toUnsignedInt(p0);
  }
}
