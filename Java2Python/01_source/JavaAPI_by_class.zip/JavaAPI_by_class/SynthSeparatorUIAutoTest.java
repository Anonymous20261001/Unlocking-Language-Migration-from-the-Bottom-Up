package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.JSeparator;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthSeparatorUI;
import org.junit.jupiter.api.Test;

public class SynthSeparatorUIAutoTest {
  @Test
  public void propertyChange_test_9891(PropertyChangeEvent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.propertyChange(p0);
  }

  @Test
  public void installUI_test_9892(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9893(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void paintBorder_test_9894(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9895(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    SynthSeparatorUI.createUI(p0);
  }

  @Test
  public void installDefaults_test_9896(JSeparator p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.installDefaults(p0);
  }

  @Test
  public void installListeners_test_9897(JSeparator p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.installListeners(p0);
  }

  @Test
  public void uninstallListeners_test_9898(JSeparator p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.uninstallListeners(p0);
  }

  @Test
  public void uninstallDefaults_test_9899(JSeparator p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.uninstallDefaults(p0);
  }

  @Test
  public void getMaximumSize_test_9900(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9901(Graphics p0, JComponent p1) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9902(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9903(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9904(Graphics p0, JComponent p1) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9905(JComponent p0) {
    SynthSeparatorUI instance = new SynthSeparatorUI();
    instance.getContext(p0);
  }
}
