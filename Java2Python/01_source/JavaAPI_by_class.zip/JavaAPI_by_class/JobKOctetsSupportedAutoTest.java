package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobKOctetsSupported;
import org.junit.jupiter.api.Test;

public class JobKOctetsSupportedAutoTest {
  @Test
  public void getCategory_test_6139(int c0, int c1) {
    JobKOctetsSupported instance = new JobKOctetsSupported(c0, c1);
    instance.getCategory();
  }

  @Test
  public void getName_test_6140(int c0, int c1) {
    JobKOctetsSupported instance = new JobKOctetsSupported(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_6141(Object p0, int c0, int c1) {
    JobKOctetsSupported instance = new JobKOctetsSupported(c0, c1);
    instance.equals(p0);
  }
}
