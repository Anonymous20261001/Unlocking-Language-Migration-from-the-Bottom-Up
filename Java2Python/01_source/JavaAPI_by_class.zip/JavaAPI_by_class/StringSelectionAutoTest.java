package generated.test;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class StringSelectionAutoTest {
  @Test
  public void getTransferDataFlavors_test_677(String c0) {
    StringSelection instance = new StringSelection(c0);
    instance.getTransferDataFlavors();
  }

  @Test
  public void isDataFlavorSupported_test_678(DataFlavor p0, String c0) {
    StringSelection instance = new StringSelection(c0);
    instance.isDataFlavorSupported(p0);
  }

  @Test
  public void lostOwnership_test_679(Clipboard p0, Transferable p1, String c0) {
    StringSelection instance = new StringSelection(c0);
    instance.lostOwnership(p0, p1);
  }
}
