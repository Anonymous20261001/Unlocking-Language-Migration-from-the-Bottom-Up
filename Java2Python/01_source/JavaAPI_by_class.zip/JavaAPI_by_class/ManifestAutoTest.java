package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.jar.Manifest;
import org.junit.jupiter.api.Test;

public class ManifestAutoTest {
  @Test
  public void equals_test_5057(Object p0) {
    Manifest instance = new Manifest();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5058() {
    Manifest instance = new Manifest();
    instance.hashCode();
  }

  @Test
  public void clone_test_5059() {
    Manifest instance = new Manifest();
    instance.clone();
  }

  @Test
  public void clear_test_5060() {
    Manifest instance = new Manifest();
    instance.clear();
  }

  @Test
  public void getMainAttributes_test_5061() {
    Manifest instance = new Manifest();
    instance.getMainAttributes();
  }

  @Test
  public void getEntries_test_5062() {
    Manifest instance = new Manifest();
    instance.getEntries();
  }

  @Test
  public void getAttributes_test_5063(String p0) {
    Manifest instance = new Manifest();
    instance.getAttributes(p0);
  }
}
