package generated.test;

import java.awt.image.DataBuffer;
import java.awt.image.MultiPixelPackedSampleModel;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class MultiPixelPackedSampleModelAutoTest {
  @Test
  public void getBitOffset_test_1336(int p0, int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getBitOffset(p0);
  }

  @Test
  public void getPixelBitStride_test_1337(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getPixelBitStride();
  }

  @Test
  public void getDataBitOffset_test_1338(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getDataBitOffset();
  }

  @Test
  public void getPixel_test_1339(int p0, int p1, int[] p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getPixel(p0, p1, p2, p3);
  }

  @Test
  public void setPixel_test_1340(int p0, int p1, int[] p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.setPixel(p0, p1, p2, p3);
  }

  @Test
  public void getTransferType_test_1341(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getTransferType();
  }

  @Test
  public void getNumDataElements_test_1342(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getNumDataElements();
  }

  @Test
  public void createCompatibleSampleModel_test_1343(int p0, int p1, int c0, int c1, int c2,
      int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.createCompatibleSampleModel(p0, p1);
  }

  @Test
  public void createSubsetSampleModel_test_1344(int[] p0, int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.createSubsetSampleModel(p0);
  }

  @Test
  public void createDataBuffer_test_1345(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.createDataBuffer();
  }

  @Test
  public void getDataElements_test_1346(int p0, int p1, Object p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getDataElements(p0, p1, p2, p3);
  }

  @Test
  public void getSample_test_1347(int p0, int p1, int p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getSample(p0, p1, p2, p3);
  }

  @Test
  public void setDataElements_test_1348(int p0, int p1, Object p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.setDataElements(p0, p1, p2, p3);
  }

  @Test
  public void setSample_test_1349(int p0, int p1, int p2, int p3, DataBuffer p4, int c0, int c1,
      int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.setSample(p0, p1, p2, p3, p4);
  }

  @Test
  public void getSampleSize_test_1350(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getSampleSize();
  }

  @Test
  public void getSampleSize_test_1351(int p0, int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getSampleSize(p0);
  }

  @Test
  public void getScanlineStride_test_1352(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getScanlineStride();
  }

  @Test
  public void equals_test_1353(Object p0, int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_1354(int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.hashCode();
  }

  @Test
  public void getOffset_test_1355(int p0, int p1, int c0, int c1, int c2, int c3) {
    MultiPixelPackedSampleModel instance = new MultiPixelPackedSampleModel(c0, c1, c2, c3);
    instance.getOffset(p0, p1);
  }
}
