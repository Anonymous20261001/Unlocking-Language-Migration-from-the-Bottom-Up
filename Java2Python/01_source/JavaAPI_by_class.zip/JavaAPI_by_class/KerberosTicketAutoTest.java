package generated.test;

import java.lang.Object;
import java.net.InetAddress;
import java.util.Date;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.kerberos.KerberosTicket;
import org.junit.jupiter.api.Test;

public class KerberosTicketAutoTest {
  @Test
  public void equals_test_6394(Object p0, byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6395(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.toString();
  }

  @Test
  public void hashCode_test_6396(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.hashCode();
  }

  @Test
  public void isDestroyed_test_6397(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isDestroyed();
  }

  @Test
  public void getEncoded_test_6398(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getEncoded();
  }

  @Test
  public void isProxy_test_6399(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isProxy();
  }

  @Test
  public void getFlags_test_6400(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getFlags();
  }

  @Test
  public void isRenewable_test_6401(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isRenewable();
  }

  @Test
  public void getRenewTill_test_6402(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getRenewTill();
  }

  @Test
  public void getClient_test_6403(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getClient();
  }

  @Test
  public void getServer_test_6404(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getServer();
  }

  @Test
  public void getSessionKey_test_6405(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getSessionKey();
  }

  @Test
  public void getAuthTime_test_6406(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getAuthTime();
  }

  @Test
  public void getStartTime_test_6407(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getStartTime();
  }

  @Test
  public void getEndTime_test_6408(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getEndTime();
  }

  @Test
  public void getClientAddresses_test_6409(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getClientAddresses();
  }

  @Test
  public void getSessionKeyType_test_6410(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.getSessionKeyType();
  }

  @Test
  public void isForwardable_test_6411(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isForwardable();
  }

  @Test
  public void isForwarded_test_6412(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isForwarded();
  }

  @Test
  public void isProxiable_test_6413(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isProxiable();
  }

  @Test
  public void isPostdated_test_6414(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2,
      byte[] c3, int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isPostdated();
  }

  @Test
  public void isInitial_test_6415(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isInitial();
  }

  @Test
  public void isCurrent_test_6416(byte[] c0, KerberosPrincipal c1, KerberosPrincipal c2, byte[] c3,
      int c4, boolean[] c5, Date c6, Date c7, Date c8, Date c9, InetAddress[] c10) {
    KerberosTicket instance = new KerberosTicket(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10);
    instance.isCurrent();
  }
}
