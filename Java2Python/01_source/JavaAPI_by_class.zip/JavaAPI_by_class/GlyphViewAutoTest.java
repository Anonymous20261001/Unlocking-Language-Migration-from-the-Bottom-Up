package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.text.Element;
import javax.swing.text.GlyphView;
import javax.swing.text.Position;
import javax.swing.text.TabExpander;
import javax.swing.text.ViewFactory;
import org.junit.jupiter.api.Test;

public class GlyphViewAutoTest {
  @Test
  public void getStartOffset_test_10256(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getStartOffset();
  }

  @Test
  public void viewToModel_test_10257(float p0, float p1, Shape p2, Position.Bias[] p3, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.viewToModel(p0, p1, p2, p3);
  }

  @Test
  public void getEndOffset_test_10258(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getEndOffset();
  }

  @Test
  public void insertUpdate_test_10259(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.insertUpdate(p0, p1, p2);
  }

  @Test
  public void removeUpdate_test_10260(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.removeUpdate(p0, p1, p2);
  }

  @Test
  public void changedUpdate_test_10261(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.changedUpdate(p0, p1, p2);
  }

  @Test
  public void breakView_test_10262(int p0, int p1, float p2, float p3, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.breakView(p0, p1, p2, p3);
  }

  @Test
  public void createFragment_test_10263(int p0, int p1, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.createFragment(p0, p1);
  }

  @Test
  public void getBreakWeight_test_10264(int p0, float p1, float p2, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getBreakWeight(p0, p1, p2);
  }

  @Test
  public void isUnderline_test_10265(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.isUnderline();
  }

  @Test
  public void isStrikeThrough_test_10266(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.isStrikeThrough();
  }

  @Test
  public void isSubscript_test_10267(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.isSubscript();
  }

  @Test
  public void isSuperscript_test_10268(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.isSuperscript();
  }

  @Test
  public void setGlyphPainter_test_10269(GlyphView.GlyphPainter p0, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.setGlyphPainter(p0);
  }

  @Test
  public void getTabExpander_test_10270(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getTabExpander();
  }

  @Test
  public void getPartialSpan_test_10271(int p0, int p1, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getPartialSpan(p0, p1);
  }

  @Test
  public void getGlyphPainter_test_10272(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getGlyphPainter();
  }

  @Test
  public void getTabbedSpan_test_10273(float p0, TabExpander p1, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getTabbedSpan(p0, p1);
  }

  @Test
  public void getPreferredSpan_test_10274(int p0, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getPreferredSpan(p0);
  }

  @Test
  public void getMinimumSpan_test_10275(int p0, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getMinimumSpan(p0);
  }

  @Test
  public void getFont_test_10276(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getFont();
  }

  @Test
  public void paint_test_10277(Graphics p0, Shape p1, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.paint(p0, p1);
  }

  @Test
  public void getForeground_test_10278(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getForeground();
  }

  @Test
  public void getBackground_test_10279(Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getBackground();
  }

  @Test
  public void getAlignment_test_10280(int p0, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getAlignment(p0);
  }

  @Test
  public void getText_test_10281(int p0, int p1, Element c0) {
    GlyphView instance = new GlyphView(c0);
    instance.getText(p0, p1);
  }
}
