package generated.test;

import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import org.junit.jupiter.api.Test;

public class ConstantCallSiteAutoTest {
  @Test
  public void getTarget_test_2378(MethodHandle c0) {
    ConstantCallSite instance = new ConstantCallSite(c0);
    instance.getTarget();
  }

  @Test
  public void dynamicInvoker_test_2379(MethodHandle c0) {
    ConstantCallSite instance = new ConstantCallSite(c0);
    instance.dynamicInvoker();
  }

  @Test
  public void setTarget_test_2380(MethodHandle p0, MethodHandle c0) {
    ConstantCallSite instance = new ConstantCallSite(c0);
    instance.setTarget(p0);
  }
}
