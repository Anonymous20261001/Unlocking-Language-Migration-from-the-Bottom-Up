package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicLabelUI;
import org.junit.jupiter.api.Test;

public class BasicLabelUIAutoTest {
  @Test
  public void propertyChange_test_8804(PropertyChangeEvent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.propertyChange(p0);
  }

  @Test
  public void installUI_test_8805(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8806(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8807(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    BasicLabelUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_8808(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_8809(Graphics p0, JComponent p1) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_8810(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_8811(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getBaseline_test_8812(JComponent p0, int p1, int p2) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void getBaselineResizeBehavior_test_8813(JComponent p0) {
    BasicLabelUI instance = new BasicLabelUI();
    instance.getBaselineResizeBehavior(p0);
  }
}
