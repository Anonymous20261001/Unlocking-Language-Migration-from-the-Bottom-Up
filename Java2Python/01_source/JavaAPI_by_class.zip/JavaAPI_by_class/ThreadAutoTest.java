package generated.test;

import java.lang.ClassLoader;
import java.lang.Object;
import java.lang.Runnable;
import java.lang.String;
import java.lang.Thread;
import org.junit.jupiter.api.Test;

public class ThreadAutoTest {
  @Test
  public void getName_test_2296() {
    Thread instance = new Thread();
    instance.getName();
  }

  @Test
  public void getStackTrace_test_2297() {
    Thread instance = new Thread();
    instance.getStackTrace();
  }

  @Test
  public void run_test_2298() {
    Thread instance = new Thread();
    instance.run();
  }

  @Test
  public void interrupt_test_2299() {
    Thread instance = new Thread();
    instance.interrupt();
  }

  @Test
  public void toString_test_2300() {
    Thread instance = new Thread();
    instance.toString();
  }

  @Test
  public void currentThread_test_2301() {
    Thread instance = new Thread();
    Thread.currentThread();
  }

  @Test
  public void onSpinWait_test_2302() {
    Thread instance = new Thread();
    Thread.onSpinWait();
  }

  @Test
  public void setContextClassLoader_test_2303(ClassLoader p0) {
    Thread instance = new Thread();
    instance.setContextClassLoader(p0);
  }

  @Test
  public void holdsLock_test_2304(Object p0) {
    Thread instance = new Thread();
    Thread.holdsLock(p0);
  }

  @Test
  public void setPriority_test_2305(int p0) {
    Thread instance = new Thread();
    instance.setPriority(p0);
  }

  @Test
  public void setDaemon_test_2306(boolean p0) {
    Thread instance = new Thread();
    instance.setDaemon(p0);
  }

  @Test
  public void start_test_2307() {
    Thread instance = new Thread();
    instance.start();
  }

  @Test
  public void getThreadGroup_test_2308() {
    Thread instance = new Thread();
    instance.getThreadGroup();
  }

  @Test
  public void getPriority_test_2309() {
    Thread instance = new Thread();
    instance.getPriority();
  }

  @Test
  public void isDaemon_test_2310() {
    Thread instance = new Thread();
    instance.isDaemon();
  }

  @Test
  public void getContextClassLoader_test_2311() {
    Thread instance = new Thread();
    instance.getContextClassLoader();
  }

  @Test
  public void interrupted_test_2312() {
    Thread instance = new Thread();
    Thread.interrupted();
  }

  @Test
  public void isVirtual_test_2313() {
    Thread instance = new Thread();
    instance.isVirtual();
  }

  @Test
  public void activeCount_test_2314() {
    Thread instance = new Thread();
    Thread.activeCount();
  }

  @Test
  public void enumerate_test_2315(Thread[] p0) {
    Thread instance = new Thread();
    Thread.enumerate(p0);
  }

  @Test
  public void isAlive_test_2316() {
    Thread instance = new Thread();
    instance.isAlive();
  }

  @Test
  public void threadId_test_2317() {
    Thread instance = new Thread();
    instance.threadId();
  }

  @Test
  public void getUncaughtExceptionHandler_test_2318() {
    Thread instance = new Thread();
    instance.getUncaughtExceptionHandler();
  }

  @Test
  public void yield_test_2319() {
    Thread instance = new Thread();
    Thread.yield();
  }

  @Test
  public void ofPlatform_test_2320() {
    Thread instance = new Thread();
    Thread.ofPlatform();
  }

  @Test
  public void ofVirtual_test_2321() {
    Thread instance = new Thread();
    Thread.ofVirtual();
  }

  @Test
  public void startVirtualThread_test_2322(Runnable p0) {
    Thread instance = new Thread();
    Thread.startVirtualThread(p0);
  }

  @Test
  public void stop_test_2323() {
    Thread instance = new Thread();
    instance.stop();
  }

  @Test
  public void isInterrupted_test_2324() {
    Thread instance = new Thread();
    instance.isInterrupted();
  }

  @Test
  public void setName_test_2325(String p0) {
    Thread instance = new Thread();
    instance.setName(p0);
  }

  @Test
  public void dumpStack_test_2326() {
    Thread instance = new Thread();
    Thread.dumpStack();
  }

  @Test
  public void checkAccess_test_2327() {
    Thread instance = new Thread();
    instance.checkAccess();
  }

  @Test
  public void getAllStackTraces_test_2328() {
    Thread instance = new Thread();
    Thread.getAllStackTraces();
  }

  @Test
  public void getId_test_2329() {
    Thread instance = new Thread();
    instance.getId();
  }

  @Test
  public void getState_test_2330() {
    Thread instance = new Thread();
    instance.getState();
  }

  @Test
  public void setDefaultUncaughtExceptionHandler_test_2331(Thread.UncaughtExceptionHandler p0) {
    Thread instance = new Thread();
    Thread.setDefaultUncaughtExceptionHandler(p0);
  }

  @Test
  public void getDefaultUncaughtExceptionHandler_test_2332() {
    Thread instance = new Thread();
    Thread.getDefaultUncaughtExceptionHandler();
  }

  @Test
  public void setUncaughtExceptionHandler_test_2333(Thread.UncaughtExceptionHandler p0) {
    Thread instance = new Thread();
    instance.setUncaughtExceptionHandler(p0);
  }
}
