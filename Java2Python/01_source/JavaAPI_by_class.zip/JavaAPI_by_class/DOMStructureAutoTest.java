package generated.test;

import java.lang.String;
import javax.xml.crypto.dom.DOMStructure;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Node;

public class DOMStructureAutoTest {
  @Test
  public void getNode_test_10873(Node c0) {
    DOMStructure instance = new DOMStructure(c0);
    instance.getNode();
  }

  @Test
  public void isFeatureSupported_test_10874(String p0, Node c0) {
    DOMStructure instance = new DOMStructure(c0);
    instance.isFeatureSupported(p0);
  }
}
