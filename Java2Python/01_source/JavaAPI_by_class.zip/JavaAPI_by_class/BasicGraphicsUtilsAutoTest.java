package generated.test;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.lang.String;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicGraphicsUtils;
import org.junit.jupiter.api.Test;

public class BasicGraphicsUtilsAutoTest {
  @Test
  public void drawString_test_8762(JComponent p0, Graphics2D p1, String p2, float p3, float p4) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawString(p0, p1, p2, p3, p4);
  }

  @Test
  public void drawString_test_8763(Graphics p0, String p1, int p2, int p3, int p4) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawString(p0, p1, p2, p3, p4);
  }

  @Test
  public void drawLoweredBezel_test_8764(Graphics p0, int p1, int p2, int p3, int p4, Color p5,
      Color p6, Color p7, Color p8) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawLoweredBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8);
  }

  @Test
  public void drawEtchedRect_test_8765(Graphics p0, int p1, int p2, int p3, int p4, Color p5,
      Color p6, Color p7, Color p8) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawEtchedRect(p0, p1, p2, p3, p4, p5, p6, p7, p8);
  }

  @Test
  public void getEtchedInsets_test_8766() {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.getEtchedInsets();
  }

  @Test
  public void drawGroove_test_8767(Graphics p0, int p1, int p2, int p3, int p4, Color p5,
      Color p6) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawGroove(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getGrooveInsets_test_8768() {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.getGrooveInsets();
  }

  @Test
  public void drawBezel_test_8769(Graphics p0, int p1, int p2, int p3, int p4, boolean p5,
      boolean p6, Color p7, Color p8, Color p9, Color p10) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
  }

  @Test
  public void drawDashedRect_test_8770(Graphics p0, int p1, int p2, int p3, int p4) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawDashedRect(p0, p1, p2, p3, p4);
  }

  @Test
  public void getClippedString_test_8771(JComponent p0, FontMetrics p1, String p2, int p3) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.getClippedString(p0, p1, p2, p3);
  }

  @Test
  public void getStringWidth_test_8772(JComponent p0, FontMetrics p1, String p2) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.getStringWidth(p0, p1, p2);
  }

  @Test
  public void drawStringUnderlineCharAt_test_8773(JComponent p0, Graphics2D p1, String p2, int p3,
      float p4, float p5) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawStringUnderlineCharAt(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void drawStringUnderlineCharAt_test_8774(Graphics p0, String p1, int p2, int p3, int p4) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.drawStringUnderlineCharAt(p0, p1, p2, p3, p4);
  }

  @Test
  public void getPreferredButtonSize_test_8775(AbstractButton p0, int p1) {
    BasicGraphicsUtils instance = new BasicGraphicsUtils();
    BasicGraphicsUtils.getPreferredButtonSize(p0, p1);
  }
}
