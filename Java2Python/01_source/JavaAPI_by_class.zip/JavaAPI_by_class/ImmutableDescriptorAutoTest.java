package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.management.Descriptor;
import javax.management.ImmutableDescriptor;
import org.junit.jupiter.api.Test;

public class ImmutableDescriptorAutoTest {
  @Test
  public void getFieldNames_test_5549(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.getFieldNames();
  }

  @Test
  public void getFieldValues_test_5550(String[] p0, Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.getFieldValues(p0);
  }

  @Test
  public void removeField_test_5551(String p0, Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.removeField(p0);
  }

  @Test
  public void equals_test_5552(Object p0, Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5553(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_5554(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_5555(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.clone();
  }

  @Test
  public void getFields_test_5556(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.getFields();
  }

  @Test
  public void isValid_test_5557(Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.isValid();
  }

  @Test
  public void union_test_5558(Descriptor[] p0, Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    ImmutableDescriptor.union(p0);
  }

  @Test
  public void getFieldValue_test_5559(String p0, Map c0) {
    ImmutableDescriptor instance = new ImmutableDescriptor(c0);
    instance.getFieldValue(p0);
  }
}
