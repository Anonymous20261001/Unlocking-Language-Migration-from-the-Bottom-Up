package generated.test;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import org.junit.jupiter.api.Test;

public class DiagnosticCollectorAutoTest {
  @Test
  public void report_test_10851(Diagnostic p0) {
    DiagnosticCollector instance = new DiagnosticCollector();
    instance.report(p0);
  }

  @Test
  public void getDiagnostics_test_10852() {
    DiagnosticCollector instance = new DiagnosticCollector();
    instance.getDiagnostics();
  }
}
