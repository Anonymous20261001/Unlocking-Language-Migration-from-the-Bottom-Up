package generated.test;

import javax.sound.midi.SysexMessage;
import org.junit.jupiter.api.Test;

public class SysexMessageAutoTest {
  @Test
  public void clone_test_6495() {
    SysexMessage instance = new SysexMessage();
    instance.clone();
  }

  @Test
  public void getData_test_6496() {
    SysexMessage instance = new SysexMessage();
    instance.getData();
  }
}
