package generated.test;

import java.lang.Object;
import java.lang.String;
import java.security.Permission;
import javax.security.auth.kerberos.DelegationPermission;
import org.junit.jupiter.api.Test;

public class DelegationPermissionAutoTest {
  @Test
  public void equals_test_6358(Object p0, String c0) {
    DelegationPermission instance = new DelegationPermission(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_6359(String c0) {
    DelegationPermission instance = new DelegationPermission(c0);
    instance.hashCode();
  }

  @Test
  public void implies_test_6360(Permission p0, String c0) {
    DelegationPermission instance = new DelegationPermission(c0);
    instance.implies(p0);
  }

  @Test
  public void newPermissionCollection_test_6361(String c0) {
    DelegationPermission instance = new DelegationPermission(c0);
    instance.newPermissionCollection();
  }
}
