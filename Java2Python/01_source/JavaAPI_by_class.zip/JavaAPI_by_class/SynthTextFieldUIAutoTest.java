package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthTextFieldUI;
import org.junit.jupiter.api.Test;

public class SynthTextFieldUIAutoTest {
  @Test
  public void paintBorder_test_9942(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthTextFieldUI instance = new SynthTextFieldUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9943(JComponent p0) {
    SynthTextFieldUI instance = new SynthTextFieldUI();
    SynthTextFieldUI.createUI(p0);
  }

  @Test
  public void update_test_9944(Graphics p0, JComponent p1) {
    SynthTextFieldUI instance = new SynthTextFieldUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9945(JComponent p0) {
    SynthTextFieldUI instance = new SynthTextFieldUI();
    instance.getContext(p0);
  }
}
