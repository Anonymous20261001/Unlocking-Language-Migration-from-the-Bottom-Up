package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {
  @Test
  public void spliterator_test_3600() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.spliterator();
  }

  @Test
  public void getFirst_test_3601() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.getFirst();
  }

  @Test
  public void getLast_test_3602() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.getLast();
  }

  @Test
  public void addFirst_test_3603(Object p0) {
    LinkedHashSet instance = new LinkedHashSet();
    instance.addFirst(p0);
  }

  @Test
  public void addLast_test_3604(Object p0) {
    LinkedHashSet instance = new LinkedHashSet();
    instance.addLast(p0);
  }

  @Test
  public void removeFirst_test_3605() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.removeFirst();
  }

  @Test
  public void removeLast_test_3606() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.removeLast();
  }

  @Test
  public void reversed_test_3607() {
    LinkedHashSet instance = new LinkedHashSet();
    instance.reversed();
  }

  @Test
  public void newLinkedHashSet_test_3608(int p0) {
    LinkedHashSet instance = new LinkedHashSet();
    LinkedHashSet.newLinkedHashSet(p0);
  }
}
