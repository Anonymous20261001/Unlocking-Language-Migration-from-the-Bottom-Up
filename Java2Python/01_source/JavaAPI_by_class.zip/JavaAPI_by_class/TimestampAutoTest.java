package generated.test;

import java.lang.Object;
import java.lang.String;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class TimestampAutoTest {
  @Test
  public void equals_test_2977(Timestamp p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.equals(p0);
  }

  @Test
  public void equals_test_2978(Object p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2979(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_2980(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.hashCode();
  }

  @Test
  public void compareTo_test_2981(Timestamp p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.compareTo(p0);
  }

  @Test
  public void compareTo_test_2982(Date p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.compareTo(p0);
  }

  @Test
  public void valueOf_test_2983(LocalDateTime p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    Timestamp.valueOf(p0);
  }

  @Test
  public void valueOf_test_2984(String p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    Timestamp.valueOf(p0);
  }

  @Test
  public void from_test_2985(Instant p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    Timestamp.from(p0);
  }

  @Test
  public void before_test_2986(Timestamp p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.before(p0);
  }

  @Test
  public void after_test_2987(Timestamp p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.after(p0);
  }

  @Test
  public void toInstant_test_2988(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.toInstant();
  }

  @Test
  public void getTime_test_2989(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.getTime();
  }

  @Test
  public void setTime_test_2990(long p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.setTime(p0);
  }

  @Test
  public void toLocalDateTime_test_2991(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.toLocalDateTime();
  }

  @Test
  public void getNanos_test_2992(long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.getNanos();
  }

  @Test
  public void setNanos_test_2993(int p0, long c0) {
    Timestamp instance = new Timestamp(c0);
    instance.setNanos(p0);
  }
}
