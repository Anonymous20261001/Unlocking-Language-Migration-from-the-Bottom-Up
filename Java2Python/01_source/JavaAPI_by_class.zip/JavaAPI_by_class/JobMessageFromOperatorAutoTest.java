package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Locale;
import javax.print.attribute.standard.JobMessageFromOperator;
import org.junit.jupiter.api.Test;

public class JobMessageFromOperatorAutoTest {
  @Test
  public void getCategory_test_6151(String c0, Locale c1) {
    JobMessageFromOperator instance = new JobMessageFromOperator(c0, c1);
    instance.getCategory();
  }

  @Test
  public void getName_test_6152(String c0, Locale c1) {
    JobMessageFromOperator instance = new JobMessageFromOperator(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_6153(Object p0, String c0, Locale c1) {
    JobMessageFromOperator instance = new JobMessageFromOperator(c0, c1);
    instance.equals(p0);
  }
}
