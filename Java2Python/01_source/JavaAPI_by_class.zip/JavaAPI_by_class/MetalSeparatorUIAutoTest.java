package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalSeparatorUI;
import org.junit.jupiter.api.Test;

public class MetalSeparatorUIAutoTest {
  @Test
  public void createUI_test_9259(JComponent p0) {
    MetalSeparatorUI instance = new MetalSeparatorUI();
    MetalSeparatorUI.createUI(p0);
  }

  @Test
  public void paint_test_9260(Graphics p0, JComponent p1) {
    MetalSeparatorUI instance = new MetalSeparatorUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9261(JComponent p0) {
    MetalSeparatorUI instance = new MetalSeparatorUI();
    instance.getPreferredSize(p0);
  }
}
