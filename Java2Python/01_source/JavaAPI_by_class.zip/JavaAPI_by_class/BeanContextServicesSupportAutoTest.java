package generated.test;

import java.beans.beancontext.BeanContextChild;
import java.beans.beancontext.BeanContextServiceAvailableEvent;
import java.beans.beancontext.BeanContextServiceProvider;
import java.beans.beancontext.BeanContextServiceRevokedEvent;
import java.beans.beancontext.BeanContextServicesListener;
import java.beans.beancontext.BeanContextServicesSupport;
import java.lang.Class;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class BeanContextServicesSupportAutoTest {
  @Test
  public void serviceRevoked_test_1653(BeanContextServiceRevokedEvent p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.serviceRevoked(p0);
  }

  @Test
  public void serviceAvailable_test_1654(BeanContextServiceAvailableEvent p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.serviceAvailable(p0);
  }

  @Test
  public void getCurrentServiceSelectors_test_1655(Class p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.getCurrentServiceSelectors(p0);
  }

  @Test
  public void addService_test_1656(Class p0, BeanContextServiceProvider p1) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.addService(p0, p1);
  }

  @Test
  public void getBeanContextServicesPeer_test_1657() {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.getBeanContextServicesPeer();
  }

  @Test
  public void revokeService_test_1658(Class p0, BeanContextServiceProvider p1, boolean p2) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.revokeService(p0, p1, p2);
  }

  @Test
  public void hasService_test_1659(Class p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.hasService(p0);
  }

  @Test
  public void releaseService_test_1660(BeanContextChild p0, Object p1, Object p2) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.releaseService(p0, p1, p2);
  }

  @Test
  public void addBeanContextServicesListener_test_1661(BeanContextServicesListener p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.addBeanContextServicesListener(p0);
  }

  @Test
  public void removeBeanContextServicesListener_test_1662(BeanContextServicesListener p0) {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.removeBeanContextServicesListener(p0);
  }

  @Test
  public void getCurrentServiceClasses_test_1663() {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.getCurrentServiceClasses();
  }

  @Test
  public void initialize_test_1664() {
    BeanContextServicesSupport instance = new BeanContextServicesSupport();
    instance.initialize();
  }
}
