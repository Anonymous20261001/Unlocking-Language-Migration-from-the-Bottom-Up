package generated.test;

import java.util.Hashtable;
import javax.naming.CannotProceedException;
import javax.naming.Context;
import javax.naming.Name;
import org.junit.jupiter.api.Test;

public class CannotProceedExceptionAutoTest {
  @Test
  public void getEnvironment_test_5881() {
    CannotProceedException instance = new CannotProceedException();
    instance.getEnvironment();
  }

  @Test
  public void setEnvironment_test_5882(Hashtable p0) {
    CannotProceedException instance = new CannotProceedException();
    instance.setEnvironment(p0);
  }

  @Test
  public void getRemainingNewName_test_5883() {
    CannotProceedException instance = new CannotProceedException();
    instance.getRemainingNewName();
  }

  @Test
  public void setRemainingNewName_test_5884(Name p0) {
    CannotProceedException instance = new CannotProceedException();
    instance.setRemainingNewName(p0);
  }

  @Test
  public void getAltName_test_5885() {
    CannotProceedException instance = new CannotProceedException();
    instance.getAltName();
  }

  @Test
  public void setAltName_test_5886(Name p0) {
    CannotProceedException instance = new CannotProceedException();
    instance.setAltName(p0);
  }

  @Test
  public void getAltNameCtx_test_5887() {
    CannotProceedException instance = new CannotProceedException();
    instance.getAltNameCtx();
  }

  @Test
  public void setAltNameCtx_test_5888(Context p0) {
    CannotProceedException instance = new CannotProceedException();
    instance.setAltNameCtx(p0);
  }
}
