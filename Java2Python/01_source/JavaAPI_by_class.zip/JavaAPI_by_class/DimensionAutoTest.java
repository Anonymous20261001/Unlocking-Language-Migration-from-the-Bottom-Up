package generated.test;

import java.awt.Dimension;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class DimensionAutoTest {
  @Test
  public void getWidth_test_196() {
    Dimension instance = new Dimension();
    instance.getWidth();
  }

  @Test
  public void getHeight_test_197() {
    Dimension instance = new Dimension();
    instance.getHeight();
  }

  @Test
  public void equals_test_198(Object p0) {
    Dimension instance = new Dimension();
    instance.equals(p0);
  }

  @Test
  public void toString_test_199() {
    Dimension instance = new Dimension();
    instance.toString();
  }

  @Test
  public void hashCode_test_200() {
    Dimension instance = new Dimension();
    instance.hashCode();
  }

  @Test
  public void getSize_test_201() {
    Dimension instance = new Dimension();
    instance.getSize();
  }

  @Test
  public void setSize_test_202(Dimension p0) {
    Dimension instance = new Dimension();
    instance.setSize(p0);
  }

  @Test
  public void setSize_test_203(double p0, double p1) {
    Dimension instance = new Dimension();
    instance.setSize(p0, p1);
  }

  @Test
  public void setSize_test_204(int p0, int p1) {
    Dimension instance = new Dimension();
    instance.setSize(p0, p1);
  }
}
