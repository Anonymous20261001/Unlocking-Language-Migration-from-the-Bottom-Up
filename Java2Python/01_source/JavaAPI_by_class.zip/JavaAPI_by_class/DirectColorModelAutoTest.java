package generated.test;

import java.awt.image.DirectColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class DirectColorModelAutoTest {
  @Test
  public void getDataElement_test_1241(int[] p0, int p1, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getDataElement(p0, p1);
  }

  @Test
  public void createCompatibleWritableRaster_test_1242(int p0, int p1, int c0, int c1, int c2,
      int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.createCompatibleWritableRaster(p0, p1);
  }

  @Test
  public void getDataElements_test_1243(int[] p0, int p1, Object p2, int c0, int c1, int c2,
      int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getDataElements(p0, p1, p2);
  }

  @Test
  public void getDataElements_test_1244(int p0, Object p1, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getDataElements(p0, p1);
  }

  @Test
  public void isCompatibleRaster_test_1245(Raster p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.isCompatibleRaster(p0);
  }

  @Test
  public void coerceData_test_1246(WritableRaster p0, boolean p1, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.coerceData(p0, p1);
  }

  @Test
  public void getAlphaMask_test_1247(int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getAlphaMask();
  }

  @Test
  public void getComponents_test_1248(Object p0, int[] p1, int p2, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getComponents(p0, p1, p2);
  }

  @Test
  public void getComponents_test_1249(int p0, int[] p1, int p2, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getComponents(p0, p1, p2);
  }

  @Test
  public void getAlpha_test_1250(int p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getAlpha(p0);
  }

  @Test
  public void getAlpha_test_1251(Object p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getAlpha(p0);
  }

  @Test
  public void getRGB_test_1252(int p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getRGB(p0);
  }

  @Test
  public void getRGB_test_1253(Object p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getRGB(p0);
  }

  @Test
  public void getRed_test_1254(Object p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getRed(p0);
  }

  @Test
  public void getRed_test_1255(int p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getRed(p0);
  }

  @Test
  public void getGreen_test_1256(Object p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getGreen(p0);
  }

  @Test
  public void getGreen_test_1257(int p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getGreen(p0);
  }

  @Test
  public void getBlue_test_1258(int p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getBlue(p0);
  }

  @Test
  public void getBlue_test_1259(Object p0, int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getBlue(p0);
  }

  @Test
  public void getRedMask_test_1260(int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getRedMask();
  }

  @Test
  public void getGreenMask_test_1261(int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getGreenMask();
  }

  @Test
  public void getBlueMask_test_1262(int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.getBlueMask();
  }

  @Test
  public void toString_test_1263(int c0, int c1, int c2, int c3) {
    DirectColorModel instance = new DirectColorModel(c0, c1, c2, c3);
    instance.toString();
  }
}
