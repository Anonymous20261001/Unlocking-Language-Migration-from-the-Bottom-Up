package generated.test;

import java.lang.Object;
import java.rmi.server.UID;
import org.junit.jupiter.api.Test;

public class UIDAutoTest {
  @Test
  public void equals_test_2672(Object p0) {
    UID instance = new UID();
    instance.equals(p0);
  }

  @Test
  public void toString_test_2673() {
    UID instance = new UID();
    instance.toString();
  }

  @Test
  public void hashCode_test_2674() {
    UID instance = new UID();
    instance.hashCode();
  }
}
