package generated.test;

import java.security.spec.DSAGenParameterSpec;
import org.junit.jupiter.api.Test;

public class DSAGenParameterSpecAutoTest {
  @Test
  public void getPrimePLength_test_2845(int c0, int c1) {
    DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
    instance.getPrimePLength();
  }

  @Test
  public void getSubprimeQLength_test_2846(int c0, int c1) {
    DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
    instance.getSubprimeQLength();
  }

  @Test
  public void getSeedLength_test_2847(int c0, int c1) {
    DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
    instance.getSeedLength();
  }
}
