package generated.test;

import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JToolTip;
import org.junit.jupiter.api.Test;

public class JToolTipAutoTest {
  @Test
  public void getUIClassID_test_8019() {
    JToolTip instance = new JToolTip();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_8020() {
    JToolTip instance = new JToolTip();
    instance.getUI();
  }

  @Test
  public void setTipText_test_8021(String p0) {
    JToolTip instance = new JToolTip();
    instance.setTipText(p0);
  }

  @Test
  public void getTipText_test_8022() {
    JToolTip instance = new JToolTip();
    instance.getTipText();
  }

  @Test
  public void getAccessibleContext_test_8023() {
    JToolTip instance = new JToolTip();
    instance.getAccessibleContext();
  }

  @Test
  public void setComponent_test_8024(JComponent p0) {
    JToolTip instance = new JToolTip();
    instance.setComponent(p0);
  }

  @Test
  public void updateUI_test_8025() {
    JToolTip instance = new JToolTip();
    instance.updateUI();
  }

  @Test
  public void getComponent_test_8026() {
    JToolTip instance = new JToolTip();
    instance.getComponent();
  }
}
