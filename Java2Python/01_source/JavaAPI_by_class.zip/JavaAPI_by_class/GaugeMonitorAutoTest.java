package generated.test;

import javax.management.ObjectName;
import javax.management.monitor.GaugeMonitor;
import org.junit.jupiter.api.Test;

public class GaugeMonitorAutoTest {
  @Test
  public void getNotificationInfo_test_5716() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_5717(ObjectName p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGauge_test_5718() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5719() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5720(ObjectName p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getDifferenceMode_test_5721() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getDifferenceMode();
  }

  @Test
  public void setDifferenceMode_test_5722(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setDifferenceMode(p0);
  }

  @Test
  public void getHighThreshold_test_5723() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getHighThreshold();
  }

  @Test
  public void getLowThreshold_test_5724() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getLowThreshold();
  }

  @Test
  public void getNotifyHigh_test_5725() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotifyHigh();
  }

  @Test
  public void setNotifyHigh_test_5726(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setNotifyHigh(p0);
  }

  @Test
  public void getNotifyLow_test_5727() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.getNotifyLow();
  }

  @Test
  public void setNotifyLow_test_5728(boolean p0) {
    GaugeMonitor instance = new GaugeMonitor();
    instance.setNotifyLow(p0);
  }

  @Test
  public void start_test_5729() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.start();
  }

  @Test
  public void stop_test_5730() {
    GaugeMonitor instance = new GaugeMonitor();
    instance.stop();
  }
}
