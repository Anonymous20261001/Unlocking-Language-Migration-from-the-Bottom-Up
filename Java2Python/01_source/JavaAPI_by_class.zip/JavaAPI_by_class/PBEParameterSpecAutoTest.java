package generated.test;

import javax.crypto.spec.PBEParameterSpec;
import org.junit.jupiter.api.Test;

public class PBEParameterSpecAutoTest {
  @Test
  public void getSalt_test_5259(byte[] c0, int c1) {
    PBEParameterSpec instance = new PBEParameterSpec(c0, c1);
    instance.getSalt();
  }

  @Test
  public void getIterationCount_test_5260(byte[] c0, int c1) {
    PBEParameterSpec instance = new PBEParameterSpec(c0, c1);
    instance.getIterationCount();
  }

  @Test
  public void getParameterSpec_test_5261(byte[] c0, int c1) {
    PBEParameterSpec instance = new PBEParameterSpec(c0, c1);
    instance.getParameterSpec();
  }
}
