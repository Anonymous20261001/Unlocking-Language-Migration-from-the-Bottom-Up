package generated.test;

import java.io.DataOutputStream;
import java.io.OutputStream;
import org.junit.jupiter.api.Test;

public class DataOutputStreamAutoTest {
  @Test
  public void size_test_1729(OutputStream c0) {
    DataOutputStream instance = new DataOutputStream(c0);
    instance.size();
  }
}
