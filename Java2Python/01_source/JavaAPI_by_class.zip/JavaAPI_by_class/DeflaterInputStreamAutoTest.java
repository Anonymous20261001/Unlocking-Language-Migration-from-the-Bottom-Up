package generated.test;

import java.io.InputStream;
import java.util.zip.DeflaterInputStream;
import org.junit.jupiter.api.Test;

public class DeflaterInputStreamAutoTest {
  @Test
  public void mark_test_5160(int p0, InputStream c0) {
    DeflaterInputStream instance = new DeflaterInputStream(c0);
    instance.mark(p0);
  }

  @Test
  public void markSupported_test_5161(InputStream c0) {
    DeflaterInputStream instance = new DeflaterInputStream(c0);
    instance.markSupported();
  }
}
