package generated.test;

import java.awt.Event;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class EventAutoTest {
  @Test
  public void translate_test_213(int p0, int p1, Object c0, int c1, Object c2) {
    Event instance = new Event(c0, c1, c2);
    instance.translate(p0, p1);
  }

  @Test
  public void shiftDown_test_214(Object c0, int c1, Object c2) {
    Event instance = new Event(c0, c1, c2);
    instance.shiftDown();
  }

  @Test
  public void controlDown_test_215(Object c0, int c1, Object c2) {
    Event instance = new Event(c0, c1, c2);
    instance.controlDown();
  }

  @Test
  public void metaDown_test_216(Object c0, int c1, Object c2) {
    Event instance = new Event(c0, c1, c2);
    instance.metaDown();
  }

  @Test
  public void toString_test_217(Object c0, int c1, Object c2) {
    Event instance = new Event(c0, c1, c2);
    instance.toString();
  }
}
