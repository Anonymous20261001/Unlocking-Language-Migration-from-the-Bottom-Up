package generated.test;

import java.awt.datatransfer.DataFlavor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class DataFlavorAutoTest {
  @Test
  public void getParameter_test_647(String p0) {
    DataFlavor instance = new DataFlavor();
    instance.getParameter(p0);
  }

  @Test
  public void getPrimaryType_test_648() {
    DataFlavor instance = new DataFlavor();
    instance.getPrimaryType();
  }

  @Test
  public void getSubType_test_649() {
    DataFlavor instance = new DataFlavor();
    instance.getSubType();
  }

  @Test
  public void isRepresentationClassInputStream_test_650() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassInputStream();
  }

  @Test
  public void isRepresentationClassByteBuffer_test_651() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassByteBuffer();
  }

  @Test
  public void isFlavorTextType_test_652() {
    DataFlavor instance = new DataFlavor();
    instance.isFlavorTextType();
  }

  @Test
  public void getRepresentationClass_test_653() {
    DataFlavor instance = new DataFlavor();
    instance.getRepresentationClass();
  }

  @Test
  public void isMimeTypeEqual_test_654(String p0) {
    DataFlavor instance = new DataFlavor();
    instance.isMimeTypeEqual(p0);
  }

  @Test
  public void isMimeTypeEqual_test_655(DataFlavor p0) {
    DataFlavor instance = new DataFlavor();
    instance.isMimeTypeEqual(p0);
  }

  @Test
  public void isRepresentationClassReader_test_656() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassReader();
  }

  @Test
  public void isRepresentationClassCharBuffer_test_657() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassCharBuffer();
  }

  @Test
  public void getDefaultRepresentationClass_test_658() {
    DataFlavor instance = new DataFlavor();
    instance.getDefaultRepresentationClass();
  }

  @Test
  public void isRepresentationClassSerializable_test_659() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassSerializable();
  }

  @Test
  public void isRepresentationClassRemote_test_660() {
    DataFlavor instance = new DataFlavor();
    instance.isRepresentationClassRemote();
  }

  @Test
  public void getTextPlainUnicodeFlavor_test_661() {
    DataFlavor instance = new DataFlavor();
    DataFlavor.getTextPlainUnicodeFlavor();
  }

  @Test
  public void selectBestTextFlavor_test_662(DataFlavor[] p0) {
    DataFlavor instance = new DataFlavor();
    DataFlavor.selectBestTextFlavor(p0);
  }

  @Test
  public void getMimeType_test_663() {
    DataFlavor instance = new DataFlavor();
    instance.getMimeType();
  }

  @Test
  public void getHumanPresentableName_test_664() {
    DataFlavor instance = new DataFlavor();
    instance.getHumanPresentableName();
  }

  @Test
  public void setHumanPresentableName_test_665(String p0) {
    DataFlavor instance = new DataFlavor();
    instance.setHumanPresentableName(p0);
  }

  @Test
  public void isMimeTypeSerializedObject_test_666() {
    DataFlavor instance = new DataFlavor();
    instance.isMimeTypeSerializedObject();
  }

  @Test
  public void getDefaultRepresentationClassAsString_test_667() {
    DataFlavor instance = new DataFlavor();
    instance.getDefaultRepresentationClassAsString();
  }

  @Test
  public void isFlavorSerializedObjectType_test_668() {
    DataFlavor instance = new DataFlavor();
    instance.isFlavorSerializedObjectType();
  }

  @Test
  public void isFlavorRemoteObjectType_test_669() {
    DataFlavor instance = new DataFlavor();
    instance.isFlavorRemoteObjectType();
  }

  @Test
  public void isFlavorJavaFileListType_test_670() {
    DataFlavor instance = new DataFlavor();
    instance.isFlavorJavaFileListType();
  }

  @Test
  public void equals_test_671(DataFlavor p0) {
    DataFlavor instance = new DataFlavor();
    instance.equals(p0);
  }

  @Test
  public void equals_test_672(Object p0) {
    DataFlavor instance = new DataFlavor();
    instance.equals(p0);
  }

  @Test
  public void equals_test_673(String p0) {
    DataFlavor instance = new DataFlavor();
    instance.equals(p0);
  }

  @Test
  public void toString_test_674() {
    DataFlavor instance = new DataFlavor();
    instance.toString();
  }

  @Test
  public void hashCode_test_675() {
    DataFlavor instance = new DataFlavor();
    instance.hashCode();
  }

  @Test
  public void match_test_676(DataFlavor p0) {
    DataFlavor instance = new DataFlavor();
    instance.match(p0);
  }
}
