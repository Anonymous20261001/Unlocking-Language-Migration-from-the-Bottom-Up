package generated.test;

import java.lang.Object;
import java.lang.String;
import java.lang.StringBuffer;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.util.Currency;
import org.junit.jupiter.api.Test;

public class DecimalFormatAutoTest {
  @Test
  public void equals_test_3081(Object p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.equals(p0);
  }

  @Test
  public void toString_test_3082() {
    DecimalFormat instance = new DecimalFormat();
    instance.toString();
  }

  @Test
  public void hashCode_test_3083() {
    DecimalFormat instance = new DecimalFormat();
    instance.hashCode();
  }

  @Test
  public void clone_test_3084() {
    DecimalFormat instance = new DecimalFormat();
    instance.clone();
  }

  @Test
  public void format_test_3085(Object p0, StringBuffer p1, FieldPosition p2) {
    DecimalFormat instance = new DecimalFormat();
    instance.format(p0, p1, p2);
  }

  @Test
  public void format_test_3086(double p0, StringBuffer p1, FieldPosition p2) {
    DecimalFormat instance = new DecimalFormat();
    instance.format(p0, p1, p2);
  }

  @Test
  public void format_test_3087(long p0, StringBuffer p1, FieldPosition p2) {
    DecimalFormat instance = new DecimalFormat();
    instance.format(p0, p1, p2);
  }

  @Test
  public void parse_test_3088(String p0, ParsePosition p1) {
    DecimalFormat instance = new DecimalFormat();
    instance.parse(p0, p1);
  }

  @Test
  public void isStrict_test_3089() {
    DecimalFormat instance = new DecimalFormat();
    instance.isStrict();
  }

  @Test
  public void formatToCharacterIterator_test_3090(Object p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.formatToCharacterIterator(p0);
  }

  @Test
  public void getMaximumIntegerDigits_test_3091() {
    DecimalFormat instance = new DecimalFormat();
    instance.getMaximumIntegerDigits();
  }

  @Test
  public void getMinimumIntegerDigits_test_3092() {
    DecimalFormat instance = new DecimalFormat();
    instance.getMinimumIntegerDigits();
  }

  @Test
  public void getMaximumFractionDigits_test_3093() {
    DecimalFormat instance = new DecimalFormat();
    instance.getMaximumFractionDigits();
  }

  @Test
  public void getMinimumFractionDigits_test_3094() {
    DecimalFormat instance = new DecimalFormat();
    instance.getMinimumFractionDigits();
  }

  @Test
  public void applyPattern_test_3095(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.applyPattern(p0);
  }

  @Test
  public void isParseBigDecimal_test_3096() {
    DecimalFormat instance = new DecimalFormat();
    instance.isParseBigDecimal();
  }

  @Test
  public void setGroupingUsed_test_3097(boolean p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setGroupingUsed(p0);
  }

  @Test
  public void toPattern_test_3098() {
    DecimalFormat instance = new DecimalFormat();
    instance.toPattern();
  }

  @Test
  public void setMinimumIntegerDigits_test_3099(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setMinimumIntegerDigits(p0);
  }

  @Test
  public void setMaximumIntegerDigits_test_3100(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setMaximumIntegerDigits(p0);
  }

  @Test
  public void setMaximumFractionDigits_test_3101(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setMaximumFractionDigits(p0);
  }

  @Test
  public void setMinimumFractionDigits_test_3102(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setMinimumFractionDigits(p0);
  }

  @Test
  public void setDecimalSeparatorAlwaysShown_test_3103(boolean p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setDecimalSeparatorAlwaysShown(p0);
  }

  @Test
  public void getCurrency_test_3104() {
    DecimalFormat instance = new DecimalFormat();
    instance.getCurrency();
  }

  @Test
  public void setCurrency_test_3105(Currency p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setCurrency(p0);
  }

  @Test
  public void setRoundingMode_test_3106(RoundingMode p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setRoundingMode(p0);
  }

  @Test
  public void getRoundingMode_test_3107() {
    DecimalFormat instance = new DecimalFormat();
    instance.getRoundingMode();
  }

  @Test
  public void getDecimalFormatSymbols_test_3108() {
    DecimalFormat instance = new DecimalFormat();
    instance.getDecimalFormatSymbols();
  }

  @Test
  public void setDecimalFormatSymbols_test_3109(DecimalFormatSymbols p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setDecimalFormatSymbols(p0);
  }

  @Test
  public void getPositivePrefix_test_3110() {
    DecimalFormat instance = new DecimalFormat();
    instance.getPositivePrefix();
  }

  @Test
  public void setPositivePrefix_test_3111(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setPositivePrefix(p0);
  }

  @Test
  public void getNegativePrefix_test_3112() {
    DecimalFormat instance = new DecimalFormat();
    instance.getNegativePrefix();
  }

  @Test
  public void setNegativePrefix_test_3113(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setNegativePrefix(p0);
  }

  @Test
  public void getPositiveSuffix_test_3114() {
    DecimalFormat instance = new DecimalFormat();
    instance.getPositiveSuffix();
  }

  @Test
  public void setPositiveSuffix_test_3115(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setPositiveSuffix(p0);
  }

  @Test
  public void getNegativeSuffix_test_3116() {
    DecimalFormat instance = new DecimalFormat();
    instance.getNegativeSuffix();
  }

  @Test
  public void setNegativeSuffix_test_3117(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setNegativeSuffix(p0);
  }

  @Test
  public void getMultiplier_test_3118() {
    DecimalFormat instance = new DecimalFormat();
    instance.getMultiplier();
  }

  @Test
  public void setMultiplier_test_3119(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setMultiplier(p0);
  }

  @Test
  public void getGroupingSize_test_3120() {
    DecimalFormat instance = new DecimalFormat();
    instance.getGroupingSize();
  }

  @Test
  public void setGroupingSize_test_3121(int p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setGroupingSize(p0);
  }

  @Test
  public void isDecimalSeparatorAlwaysShown_test_3122() {
    DecimalFormat instance = new DecimalFormat();
    instance.isDecimalSeparatorAlwaysShown();
  }

  @Test
  public void setStrict_test_3123(boolean p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setStrict(p0);
  }

  @Test
  public void setParseBigDecimal_test_3124(boolean p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.setParseBigDecimal(p0);
  }

  @Test
  public void toLocalizedPattern_test_3125() {
    DecimalFormat instance = new DecimalFormat();
    instance.toLocalizedPattern();
  }

  @Test
  public void applyLocalizedPattern_test_3126(String p0) {
    DecimalFormat instance = new DecimalFormat();
    instance.applyLocalizedPattern(p0);
  }
}
