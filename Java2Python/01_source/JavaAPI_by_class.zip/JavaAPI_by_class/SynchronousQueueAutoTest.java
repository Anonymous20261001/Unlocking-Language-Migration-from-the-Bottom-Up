package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.SynchronousQueue;
import org.junit.jupiter.api.Test;

public class SynchronousQueueAutoTest {
  @Test
  public void drainTo_test_4684(Collection p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.drainTo(p0);
  }

  @Test
  public void drainTo_test_4685(Collection p0, int p1) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.drainTo(p0, p1);
  }

  @Test
  public void remainingCapacity_test_4686() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4687(Object p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.remove(p0);
  }

  @Test
  public void size_test_4688() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.size();
  }

  @Test
  public void toString_test_4689() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.toString();
  }

  @Test
  public void clear_test_4690() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.clear();
  }

  @Test
  public void isEmpty_test_4691() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.isEmpty();
  }

  @Test
  public void toArray_test_4692() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.toArray();
  }

  @Test
  public void toArray_test_4693(Object[] p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.toArray(p0);
  }

  @Test
  public void iterator_test_4694() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.iterator();
  }

  @Test
  public void contains_test_4695(Object p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4696() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.spliterator();
  }

  @Test
  public void peek_test_4697() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.peek();
  }

  @Test
  public void removeAll_test_4698(Collection p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4699(Collection p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.retainAll(p0);
  }

  @Test
  public void containsAll_test_4700(Collection p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.containsAll(p0);
  }

  @Test
  public void poll_test_4701() {
    SynchronousQueue instance = new SynchronousQueue();
    instance.poll();
  }

  @Test
  public void offer_test_4702(Object p0) {
    SynchronousQueue instance = new SynchronousQueue();
    instance.offer(p0);
  }
}
