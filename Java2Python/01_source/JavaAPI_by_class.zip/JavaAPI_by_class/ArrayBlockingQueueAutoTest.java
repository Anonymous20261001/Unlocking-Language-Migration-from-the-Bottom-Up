package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class ArrayBlockingQueueAutoTest {
  @Test
  public void drainTo_test_4082(Collection p0, int p1, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.drainTo(p0, p1);
  }

  @Test
  public void drainTo_test_4083(Collection p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.drainTo(p0);
  }

  @Test
  public void remainingCapacity_test_4084(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4085(Object p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.remove(p0);
  }

  @Test
  public void size_test_4086(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.size();
  }

  @Test
  public void toString_test_4087(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.toString();
  }

  @Test
  public void clear_test_4088(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.clear();
  }

  @Test
  public void add_test_4089(Object p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.add(p0);
  }

  @Test
  public void toArray_test_4090(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.toArray();
  }

  @Test
  public void toArray_test_4091(Object[] p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.toArray(p0);
  }

  @Test
  public void iterator_test_4092(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.iterator();
  }

  @Test
  public void contains_test_4093(Object p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4094(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.spliterator();
  }

  @Test
  public void forEach_test_4095(Consumer p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.forEach(p0);
  }

  @Test
  public void peek_test_4096(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.peek();
  }

  @Test
  public void removeIf_test_4097(Predicate p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.removeIf(p0);
  }

  @Test
  public void removeAll_test_4098(Collection p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4099(Collection p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.retainAll(p0);
  }

  @Test
  public void poll_test_4100(int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.poll();
  }

  @Test
  public void offer_test_4101(Object p0, int c0) {
    ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
    instance.offer(p0);
  }
}
