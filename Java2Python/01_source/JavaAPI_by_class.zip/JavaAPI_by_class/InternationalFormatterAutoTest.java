package generated.test;

import java.lang.Comparable;
import java.text.Format;
import javax.swing.JFormattedTextField;
import javax.swing.text.InternationalFormatter;
import org.junit.jupiter.api.Test;

public class InternationalFormatterAutoTest {
  @Test
  public void install_test_10286(JFormattedTextField p0) {
    InternationalFormatter instance = new InternationalFormatter();
    instance.install(p0);
  }

  @Test
  public void setMinimum_test_10287(Comparable p0) {
    InternationalFormatter instance = new InternationalFormatter();
    instance.setMinimum(p0);
  }

  @Test
  public void setMaximum_test_10288(Comparable p0) {
    InternationalFormatter instance = new InternationalFormatter();
    instance.setMaximum(p0);
  }

  @Test
  public void getFields_test_10289(int p0) {
    InternationalFormatter instance = new InternationalFormatter();
    instance.getFields(p0);
  }

  @Test
  public void getMaximum_test_10290() {
    InternationalFormatter instance = new InternationalFormatter();
    instance.getMaximum();
  }

  @Test
  public void getMinimum_test_10291() {
    InternationalFormatter instance = new InternationalFormatter();
    instance.getMinimum();
  }

  @Test
  public void setFormat_test_10292(Format p0) {
    InternationalFormatter instance = new InternationalFormatter();
    instance.setFormat(p0);
  }

  @Test
  public void getFormat_test_10293() {
    InternationalFormatter instance = new InternationalFormatter();
    instance.getFormat();
  }
}
