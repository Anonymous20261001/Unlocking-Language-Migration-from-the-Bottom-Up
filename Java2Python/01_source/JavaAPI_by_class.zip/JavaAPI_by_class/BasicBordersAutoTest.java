package generated.test;

import javax.swing.plaf.basic.BasicBorders;
import org.junit.jupiter.api.Test;

public class BasicBordersAutoTest {
  @Test
  public void getButtonBorder_test_8618() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getButtonBorder();
  }

  @Test
  public void getRadioButtonBorder_test_8619() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getRadioButtonBorder();
  }

  @Test
  public void getToggleButtonBorder_test_8620() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getToggleButtonBorder();
  }

  @Test
  public void getMenuBarBorder_test_8621() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getMenuBarBorder();
  }

  @Test
  public void getSplitPaneBorder_test_8622() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getSplitPaneBorder();
  }

  @Test
  public void getSplitPaneDividerBorder_test_8623() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getSplitPaneDividerBorder();
  }

  @Test
  public void getTextFieldBorder_test_8624() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getTextFieldBorder();
  }

  @Test
  public void getProgressBarBorder_test_8625() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getProgressBarBorder();
  }

  @Test
  public void getInternalFrameBorder_test_8626() {
    BasicBorders instance = new BasicBorders();
    BasicBorders.getInternalFrameBorder();
  }
}
