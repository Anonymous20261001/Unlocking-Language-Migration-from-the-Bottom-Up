package generated.test;

import java.lang.Object;
import java.lang.String;
import java.net.SocketPermission;
import java.security.Permission;
import org.junit.jupiter.api.Test;

public class SocketPermissionAutoTest {
  @Test
  public void getActions_test_2621(String c0, String c1) {
    SocketPermission instance = new SocketPermission(c0, c1);
    instance.getActions();
  }

  @Test
  public void equals_test_2622(Object p0, String c0, String c1) {
    SocketPermission instance = new SocketPermission(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_2623(String c0, String c1) {
    SocketPermission instance = new SocketPermission(c0, c1);
    instance.hashCode();
  }

  @Test
  public void implies_test_2624(Permission p0, String c0, String c1) {
    SocketPermission instance = new SocketPermission(c0, c1);
    instance.implies(p0);
  }

  @Test
  public void newPermissionCollection_test_2625(String c0, String c1) {
    SocketPermission instance = new SocketPermission(c0, c1);
    instance.newPermissionCollection();
  }
}
