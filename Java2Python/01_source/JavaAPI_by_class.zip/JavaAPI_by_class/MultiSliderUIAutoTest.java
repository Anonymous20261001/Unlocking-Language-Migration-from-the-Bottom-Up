package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSliderUI;
import org.junit.jupiter.api.Test;

public class MultiSliderUIAutoTest {
  @Test
  public void installUI_test_9549(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9550(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9551() {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9552(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    MultiSliderUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9553(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9554(Graphics p0, JComponent p1) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9555(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9556(JComponent p0, int p1) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9557(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9558(JComponent p0) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9559(Graphics p0, JComponent p1) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9560(JComponent p0, int p1, int p2) {
    MultiSliderUI instance = new MultiSliderUI();
    instance.contains(p0, p1, p2);
  }
}
