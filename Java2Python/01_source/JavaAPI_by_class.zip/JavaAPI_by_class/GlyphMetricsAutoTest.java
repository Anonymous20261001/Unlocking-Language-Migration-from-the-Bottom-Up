package generated.test;

import java.awt.font.GlyphMetrics;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;

public class GlyphMetricsAutoTest {
  @Test
  public void getAdvanceX_test_832(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getAdvanceX();
  }

  @Test
  public void getAdvanceY_test_833(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getAdvanceY();
  }

  @Test
  public void getLSB_test_834(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getLSB();
  }

  @Test
  public void getRSB_test_835(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getRSB();
  }

  @Test
  public void isStandard_test_836(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.isStandard();
  }

  @Test
  public void isLigature_test_837(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.isLigature();
  }

  @Test
  public void isCombining_test_838(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.isCombining();
  }

  @Test
  public void isComponent_test_839(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.isComponent();
  }

  @Test
  public void getAdvance_test_840(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getAdvance();
  }

  @Test
  public void getBounds2D_test_841(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getBounds2D();
  }

  @Test
  public void isWhitespace_test_842(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.isWhitespace();
  }

  @Test
  public void getType_test_843(float c0, Rectangle2D c1, byte c2) {
    GlyphMetrics instance = new GlyphMetrics(c0, c1, c2);
    instance.getType();
  }
}
