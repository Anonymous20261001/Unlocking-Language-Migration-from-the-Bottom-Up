package generated.test;

import java.security.spec.PSSParameterSpec;
import org.junit.jupiter.api.Test;

public class PSSParameterSpecAutoTest {
  @Test
  public void getDigestAlgorithm_test_2900(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.getDigestAlgorithm();
  }

  @Test
  public void getMGFAlgorithm_test_2901(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.getMGFAlgorithm();
  }

  @Test
  public void getMGFParameters_test_2902(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.getMGFParameters();
  }

  @Test
  public void getSaltLength_test_2903(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.getSaltLength();
  }

  @Test
  public void getTrailerField_test_2904(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.getTrailerField();
  }

  @Test
  public void toString_test_2905(int c0) {
    PSSParameterSpec instance = new PSSParameterSpec(c0);
    instance.toString();
  }
}
