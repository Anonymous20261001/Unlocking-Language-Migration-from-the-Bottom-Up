package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.AttributeChangeNotification;
import org.junit.jupiter.api.Test;

public class AttributeChangeNotificationAutoTest {
  @Test
  public void getOldValue_test_5523(Object c0, long c1, long c2, String c3, String c4, String c5,
      Object c6, Object c7) {
    AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getOldValue();
  }

  @Test
  public void getNewValue_test_5524(Object c0, long c1, long c2, String c3, String c4, String c5,
      Object c6, Object c7) {
    AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getNewValue();
  }

  @Test
  public void getAttributeName_test_5525(Object c0, long c1, long c2, String c3, String c4,
      String c5, Object c6, Object c7) {
    AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getAttributeName();
  }

  @Test
  public void getAttributeType_test_5526(Object c0, long c1, long c2, String c3, String c4,
      String c5, Object c6, Object c7) {
    AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getAttributeType();
  }
}
