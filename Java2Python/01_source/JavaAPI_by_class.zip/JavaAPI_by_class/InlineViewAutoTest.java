package generated.test;

import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.text.Element;
import javax.swing.text.ViewFactory;
import javax.swing.text.html.InlineView;
import org.junit.jupiter.api.Test;

public class InlineViewAutoTest {
  @Test
  public void insertUpdate_test_10516(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    InlineView instance = new InlineView(c0);
    instance.insertUpdate(p0, p1, p2);
  }

  @Test
  public void removeUpdate_test_10517(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    InlineView instance = new InlineView(c0);
    instance.removeUpdate(p0, p1, p2);
  }

  @Test
  public void changedUpdate_test_10518(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
    InlineView instance = new InlineView(c0);
    instance.changedUpdate(p0, p1, p2);
  }

  @Test
  public void breakView_test_10519(int p0, int p1, float p2, float p3, Element c0) {
    InlineView instance = new InlineView(c0);
    instance.breakView(p0, p1, p2, p3);
  }

  @Test
  public void getBreakWeight_test_10520(int p0, float p1, float p2, Element c0) {
    InlineView instance = new InlineView(c0);
    instance.getBreakWeight(p0, p1, p2);
  }

  @Test
  public void getAttributes_test_10521(Element c0) {
    InlineView instance = new InlineView(c0);
    instance.getAttributes();
  }
}
