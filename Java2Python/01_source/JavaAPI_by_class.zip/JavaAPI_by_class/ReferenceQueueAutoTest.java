package generated.test;

import java.lang.ref.ReferenceQueue;
import org.junit.jupiter.api.Test;

public class ReferenceQueueAutoTest {
  @Test
  public void poll_test_2421() {
    ReferenceQueue instance = new ReferenceQueue();
    instance.poll();
  }
}
