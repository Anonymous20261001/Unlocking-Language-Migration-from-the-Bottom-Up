package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.QueuedJobCount;
import org.junit.jupiter.api.Test;

public class QueuedJobCountAutoTest {
  @Test
  public void getCategory_test_6241(int c0) {
    QueuedJobCount instance = new QueuedJobCount(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6242(int c0) {
    QueuedJobCount instance = new QueuedJobCount(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6243(Object p0, int c0) {
    QueuedJobCount instance = new QueuedJobCount(c0);
    instance.equals(p0);
  }
}
