package generated.test;

import java.awt.Component;
import javax.swing.DesktopManager;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.plaf.DesktopPaneUI;
import org.junit.jupiter.api.Test;

public class JDesktopPaneAutoTest {
  @Test
  public void getUIClassID_test_6954() {
    JDesktopPane instance = new JDesktopPane();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_6955() {
    JDesktopPane instance = new JDesktopPane();
    instance.getUI();
  }

  @Test
  public void setUI_test_6956(DesktopPaneUI p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.setUI(p0);
  }

  @Test
  public void selectFrame_test_6957(boolean p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.selectFrame(p0);
  }

  @Test
  public void getSelectedFrame_test_6958() {
    JDesktopPane instance = new JDesktopPane();
    instance.getSelectedFrame();
  }

  @Test
  public void setSelectedFrame_test_6959(JInternalFrame p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.setSelectedFrame(p0);
  }

  @Test
  public void getDragMode_test_6960() {
    JDesktopPane instance = new JDesktopPane();
    instance.getDragMode();
  }

  @Test
  public void getAllFrames_test_6961() {
    JDesktopPane instance = new JDesktopPane();
    instance.getAllFrames();
  }

  @Test
  public void setDragMode_test_6962(int p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.setDragMode(p0);
  }

  @Test
  public void getDesktopManager_test_6963() {
    JDesktopPane instance = new JDesktopPane();
    instance.getDesktopManager();
  }

  @Test
  public void setDesktopManager_test_6964(DesktopManager p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.setDesktopManager(p0);
  }

  @Test
  public void getAllFramesInLayer_test_6965(int p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.getAllFramesInLayer(p0);
  }

  @Test
  public void getAccessibleContext_test_6966() {
    JDesktopPane instance = new JDesktopPane();
    instance.getAccessibleContext();
  }

  @Test
  public void setComponentZOrder_test_6967(Component p0, int p1) {
    JDesktopPane instance = new JDesktopPane();
    instance.setComponentZOrder(p0, p1);
  }

  @Test
  public void updateUI_test_6968() {
    JDesktopPane instance = new JDesktopPane();
    instance.updateUI();
  }

  @Test
  public void remove_test_6969(Component p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.remove(p0);
  }

  @Test
  public void remove_test_6970(int p0) {
    JDesktopPane instance = new JDesktopPane();
    instance.remove(p0);
  }

  @Test
  public void removeAll_test_6971() {
    JDesktopPane instance = new JDesktopPane();
    instance.removeAll();
  }
}
