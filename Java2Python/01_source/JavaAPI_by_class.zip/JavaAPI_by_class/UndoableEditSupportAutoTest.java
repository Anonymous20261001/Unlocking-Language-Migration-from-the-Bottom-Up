package generated.test;

import javax.swing.event.UndoableEditListener;
import javax.swing.undo.UndoableEdit;
import javax.swing.undo.UndoableEditSupport;
import org.junit.jupiter.api.Test;

public class UndoableEditSupportAutoTest {
  @Test
  public void postEdit_test_10843(UndoableEdit p0) {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.postEdit(p0);
  }

  @Test
  public void getUpdateLevel_test_10844() {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.getUpdateLevel();
  }

  @Test
  public void beginUpdate_test_10845() {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.beginUpdate();
  }

  @Test
  public void endUpdate_test_10846() {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.endUpdate();
  }

  @Test
  public void addUndoableEditListener_test_10847(UndoableEditListener p0) {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.addUndoableEditListener(p0);
  }

  @Test
  public void removeUndoableEditListener_test_10848(UndoableEditListener p0) {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.removeUndoableEditListener(p0);
  }

  @Test
  public void getUndoableEditListeners_test_10849() {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.getUndoableEditListeners();
  }

  @Test
  public void toString_test_10850() {
    UndoableEditSupport instance = new UndoableEditSupport();
    instance.toString();
  }
}
