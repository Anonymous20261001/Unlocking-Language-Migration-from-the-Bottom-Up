package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.crypto.spec.SecretKeySpec;
import org.junit.jupiter.api.Test;

public class SecretKeySpecAutoTest {
  @Test
  public void equals_test_5272(Object p0, byte[] c0, String c1) {
    SecretKeySpec instance = new SecretKeySpec(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5273(byte[] c0, String c1) {
    SecretKeySpec instance = new SecretKeySpec(c0, c1);
    instance.hashCode();
  }

  @Test
  public void getEncoded_test_5274(byte[] c0, String c1) {
    SecretKeySpec instance = new SecretKeySpec(c0, c1);
    instance.getEncoded();
  }

  @Test
  public void getFormat_test_5275(byte[] c0, String c1) {
    SecretKeySpec instance = new SecretKeySpec(c0, c1);
    instance.getFormat();
  }

  @Test
  public void getAlgorithm_test_5276(byte[] c0, String c1) {
    SecretKeySpec instance = new SecretKeySpec(c0, c1);
    instance.getAlgorithm();
  }
}
