package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicTextPaneUI;
import org.junit.jupiter.api.Test;

public class BasicTextPaneUIAutoTest {
  @Test
  public void installUI_test_9012(JComponent p0) {
    BasicTextPaneUI instance = new BasicTextPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void createUI_test_9013(JComponent p0) {
    BasicTextPaneUI instance = new BasicTextPaneUI();
    BasicTextPaneUI.createUI(p0);
  }
}
