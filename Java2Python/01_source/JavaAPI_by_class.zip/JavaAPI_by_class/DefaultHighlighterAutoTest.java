package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import java.lang.Object;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.JTextComponent;
import javax.swing.text.View;
import org.junit.jupiter.api.Test;

public class DefaultHighlighterAutoTest {
  @Test
  public void deinstall_test_10217(JTextComponent p0) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.deinstall(p0);
  }

  @Test
  public void install_test_10218(JTextComponent p0) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.install(p0);
  }

  @Test
  public void removeHighlight_test_10219(Object p0) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.removeHighlight(p0);
  }

  @Test
  public void removeAllHighlights_test_10220() {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.removeAllHighlights();
  }

  @Test
  public void getDrawsLayeredHighlights_test_10221() {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.getDrawsLayeredHighlights();
  }

  @Test
  public void paintLayeredHighlights_test_10222(Graphics p0, int p1, int p2, Shape p3,
      JTextComponent p4, View p5) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.paintLayeredHighlights(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getHighlights_test_10223() {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.getHighlights();
  }

  @Test
  public void setDrawsLayeredHighlights_test_10224(boolean p0) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.setDrawsLayeredHighlights(p0);
  }

  @Test
  public void paint_test_10225(Graphics p0) {
    DefaultHighlighter instance = new DefaultHighlighter();
    instance.paint(p0);
  }
}
