package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.naming.directory.BasicAttribute;
import org.junit.jupiter.api.Test;

public class BasicAttributeAutoTest {
  @Test
  public void remove_test_5955(int p0, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.remove(p0);
  }

  @Test
  public void remove_test_5956(Object p0, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.remove(p0);
  }

  @Test
  public void size_test_5957(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.size();
  }

  @Test
  public void equals_test_5958(Object p0, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5959(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_5960(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_5961(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.clone();
  }

  @Test
  public void clear_test_5962(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.clear();
  }

  @Test
  public void add_test_5963(int p0, Object p1, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.add(p0, p1);
  }

  @Test
  public void add_test_5964(Object p0, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.add(p0);
  }

  @Test
  public void contains_test_5965(Object p0, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.contains(p0);
  }

  @Test
  public void set_test_5966(int p0, Object p1, String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.set(p0, p1);
  }

  @Test
  public void isOrdered_test_5967(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.isOrdered();
  }

  @Test
  public void getID_test_5968(String c0) {
    BasicAttribute instance = new BasicAttribute(c0);
    instance.getID();
  }
}
