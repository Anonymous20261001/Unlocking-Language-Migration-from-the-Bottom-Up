package generated.test;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.lang.Object;
import java.lang.String;
import javax.swing.DropMode;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.plaf.TreeUI;
import javax.swing.text.Position;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import org.junit.jupiter.api.Test;

public class JTreeAutoTest {
  @Test
  public void getScrollableTracksViewportWidth_test_8027() {
    JTree instance = new JTree();
    instance.getScrollableTracksViewportWidth();
  }

  @Test
  public void getScrollableTracksViewportHeight_test_8028() {
    JTree instance = new JTree();
    instance.getScrollableTracksViewportHeight();
  }

  @Test
  public void setDropMode_test_8029(DropMode p0) {
    JTree instance = new JTree();
    instance.setDropMode(p0);
  }

  @Test
  public void getDropMode_test_8030() {
    JTree instance = new JTree();
    instance.getDropMode();
  }

  @Test
  public void getPreferredScrollableViewportSize_test_8031() {
    JTree instance = new JTree();
    instance.getPreferredScrollableViewportSize();
  }

  @Test
  public void getScrollableUnitIncrement_test_8032(Rectangle p0, int p1, int p2) {
    JTree instance = new JTree();
    instance.getScrollableUnitIncrement(p0, p1, p2);
  }

  @Test
  public void getScrollableBlockIncrement_test_8033(Rectangle p0, int p1, int p2) {
    JTree instance = new JTree();
    instance.getScrollableBlockIncrement(p0, p1, p2);
  }

  @Test
  public void setRowHeight_test_8034(int p0) {
    JTree instance = new JTree();
    instance.setRowHeight(p0);
  }

  @Test
  public void getRowCount_test_8035() {
    JTree instance = new JTree();
    instance.getRowCount();
  }

  @Test
  public void getRowHeight_test_8036() {
    JTree instance = new JTree();
    instance.getRowHeight();
  }

  @Test
  public void isEditing_test_8037() {
    JTree instance = new JTree();
    instance.isEditing();
  }

  @Test
  public void isRowSelected_test_8038(int p0) {
    JTree instance = new JTree();
    instance.isRowSelected(p0);
  }

  @Test
  public void getCellEditor_test_8039() {
    JTree instance = new JTree();
    instance.getCellEditor();
  }

  @Test
  public void setCellEditor_test_8040(TreeCellEditor p0) {
    JTree instance = new JTree();
    instance.setCellEditor(p0);
  }

  @Test
  public void getToolTipText_test_8041(MouseEvent p0) {
    JTree instance = new JTree();
    instance.getToolTipText(p0);
  }

  @Test
  public void getUIClassID_test_8042() {
    JTree instance = new JTree();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_8043() {
    JTree instance = new JTree();
    instance.getUI();
  }

  @Test
  public void setUI_test_8044(TreeUI p0) {
    JTree instance = new JTree();
    instance.setUI(p0);
  }

  @Test
  public void getModel_test_8045() {
    JTree instance = new JTree();
    instance.getModel();
  }

  @Test
  public void clearSelection_test_8046() {
    JTree instance = new JTree();
    instance.clearSelection();
  }

  @Test
  public void setRootVisible_test_8047(boolean p0) {
    JTree instance = new JTree();
    instance.setRootVisible(p0);
  }

  @Test
  public void setShowsRootHandles_test_8048(boolean p0) {
    JTree instance = new JTree();
    instance.setShowsRootHandles(p0);
  }

  @Test
  public void expandRow_test_8049(int p0) {
    JTree instance = new JTree();
    instance.expandRow(p0);
  }

  @Test
  public void getClosestRowForLocation_test_8050(int p0, int p1) {
    JTree instance = new JTree();
    instance.getClosestRowForLocation(p0, p1);
  }

  @Test
  public void getRowBounds_test_8051(int p0) {
    JTree instance = new JTree();
    instance.getRowBounds(p0);
  }

  @Test
  public void getPathForRow_test_8052(int p0) {
    JTree instance = new JTree();
    instance.getPathForRow(p0);
  }

  @Test
  public void isCollapsed_test_8053(int p0) {
    JTree instance = new JTree();
    instance.isCollapsed(p0);
  }

  @Test
  public void isCollapsed_test_8054(TreePath p0) {
    JTree instance = new JTree();
    instance.isCollapsed(p0);
  }

  @Test
  public void setSelectionPaths_test_8055(TreePath[] p0) {
    JTree instance = new JTree();
    instance.setSelectionPaths(p0);
  }

  @Test
  public void setAnchorSelectionPath_test_8056(TreePath p0) {
    JTree instance = new JTree();
    instance.setAnchorSelectionPath(p0);
  }

  @Test
  public void setLeadSelectionPath_test_8057(TreePath p0) {
    JTree instance = new JTree();
    instance.setLeadSelectionPath(p0);
  }

  @Test
  public void getSelectionPaths_test_8058() {
    JTree instance = new JTree();
    instance.getSelectionPaths();
  }

  @Test
  public void getAnchorSelectionPath_test_8059() {
    JTree instance = new JTree();
    instance.getAnchorSelectionPath();
  }

  @Test
  public void getLeadSelectionPath_test_8060() {
    JTree instance = new JTree();
    instance.getLeadSelectionPath();
  }

  @Test
  public void setSelectionPath_test_8061(TreePath p0) {
    JTree instance = new JTree();
    instance.setSelectionPath(p0);
  }

  @Test
  public void getRowForLocation_test_8062(int p0, int p1) {
    JTree instance = new JTree();
    instance.getRowForLocation(p0, p1);
  }

  @Test
  public void getPathBounds_test_8063(TreePath p0) {
    JTree instance = new JTree();
    instance.getPathBounds(p0);
  }

  @Test
  public void setSelectionRows_test_8064(int[] p0) {
    JTree instance = new JTree();
    instance.setSelectionRows(p0);
  }

  @Test
  public void addSelectionPath_test_8065(TreePath p0) {
    JTree instance = new JTree();
    instance.addSelectionPath(p0);
  }

  @Test
  public void addSelectionPaths_test_8066(TreePath[] p0) {
    JTree instance = new JTree();
    instance.addSelectionPaths(p0);
  }

  @Test
  public void addSelectionRows_test_8067(int[] p0) {
    JTree instance = new JTree();
    instance.addSelectionRows(p0);
  }

  @Test
  public void getSelectionPath_test_8068() {
    JTree instance = new JTree();
    instance.getSelectionPath();
  }

  @Test
  public void getSelectionRows_test_8069() {
    JTree instance = new JTree();
    instance.getSelectionRows();
  }

  @Test
  public void getSelectionCount_test_8070() {
    JTree instance = new JTree();
    instance.getSelectionCount();
  }

  @Test
  public void getMinSelectionRow_test_8071() {
    JTree instance = new JTree();
    instance.getMinSelectionRow();
  }

  @Test
  public void getMaxSelectionRow_test_8072() {
    JTree instance = new JTree();
    instance.getMaxSelectionRow();
  }

  @Test
  public void getRowForPath_test_8073(TreePath p0) {
    JTree instance = new JTree();
    instance.getRowForPath(p0);
  }

  @Test
  public void isPathSelected_test_8074(TreePath p0) {
    JTree instance = new JTree();
    instance.isPathSelected(p0);
  }

  @Test
  public void expandPath_test_8075(TreePath p0) {
    JTree instance = new JTree();
    instance.expandPath(p0);
  }

  @Test
  public void scrollPathToVisible_test_8076(TreePath p0) {
    JTree instance = new JTree();
    instance.scrollPathToVisible(p0);
  }

  @Test
  public void collapsePath_test_8077(TreePath p0) {
    JTree instance = new JTree();
    instance.collapsePath(p0);
  }

  @Test
  public void getClosestPathForLocation_test_8078(int p0, int p1) {
    JTree instance = new JTree();
    instance.getClosestPathForLocation(p0, p1);
  }

  @Test
  public void getPathForLocation_test_8079(int p0, int p1) {
    JTree instance = new JTree();
    instance.getPathForLocation(p0, p1);
  }

  @Test
  public void stopEditing_test_8080() {
    JTree instance = new JTree();
    instance.stopEditing();
  }

  @Test
  public void cancelEditing_test_8081() {
    JTree instance = new JTree();
    instance.cancelEditing();
  }

  @Test
  public void startEditingAtPath_test_8082(TreePath p0) {
    JTree instance = new JTree();
    instance.startEditingAtPath(p0);
  }

  @Test
  public void getEditingPath_test_8083() {
    JTree instance = new JTree();
    instance.getEditingPath();
  }

  @Test
  public void removeTreeSelectionListener_test_8084(TreeSelectionListener p0) {
    JTree instance = new JTree();
    instance.removeTreeSelectionListener(p0);
  }

  @Test
  public void addTreeSelectionListener_test_8085(TreeSelectionListener p0) {
    JTree instance = new JTree();
    instance.addTreeSelectionListener(p0);
  }

  @Test
  public void removeSelectionPaths_test_8086(TreePath[] p0) {
    JTree instance = new JTree();
    instance.removeSelectionPaths(p0);
  }

  @Test
  public void removeSelectionPath_test_8087(TreePath p0) {
    JTree instance = new JTree();
    instance.removeSelectionPath(p0);
  }

  @Test
  public void removeSelectionRows_test_8088(int[] p0) {
    JTree instance = new JTree();
    instance.removeSelectionRows(p0);
  }

  @Test
  public void isFixedRowHeight_test_8089() {
    JTree instance = new JTree();
    instance.isFixedRowHeight();
  }

  @Test
  public void fireTreeExpanded_test_8090(TreePath p0) {
    JTree instance = new JTree();
    instance.fireTreeExpanded(p0);
  }

  @Test
  public void fireTreeCollapsed_test_8091(TreePath p0) {
    JTree instance = new JTree();
    instance.fireTreeCollapsed(p0);
  }

  @Test
  public void setScrollsOnExpand_test_8092(boolean p0) {
    JTree instance = new JTree();
    instance.setScrollsOnExpand(p0);
  }

  @Test
  public void isRootVisible_test_8093() {
    JTree instance = new JTree();
    instance.isRootVisible();
  }

  @Test
  public void getShowsRootHandles_test_8094() {
    JTree instance = new JTree();
    instance.getShowsRootHandles();
  }

  @Test
  public void setLargeModel_test_8095(boolean p0) {
    JTree instance = new JTree();
    instance.setLargeModel(p0);
  }

  @Test
  public void isLargeModel_test_8096() {
    JTree instance = new JTree();
    instance.isLargeModel();
  }

  @Test
  public void setInvokesStopCellEditing_test_8097(boolean p0) {
    JTree instance = new JTree();
    instance.setInvokesStopCellEditing(p0);
  }

  @Test
  public void getInvokesStopCellEditing_test_8098() {
    JTree instance = new JTree();
    instance.getInvokesStopCellEditing();
  }

  @Test
  public void getScrollsOnExpand_test_8099() {
    JTree instance = new JTree();
    instance.getScrollsOnExpand();
  }

  @Test
  public void setToggleClickCount_test_8100(int p0) {
    JTree instance = new JTree();
    instance.setToggleClickCount(p0);
  }

  @Test
  public void getToggleClickCount_test_8101() {
    JTree instance = new JTree();
    instance.getToggleClickCount();
  }

  @Test
  public void setExpandsSelectedPaths_test_8102(boolean p0) {
    JTree instance = new JTree();
    instance.setExpandsSelectedPaths(p0);
  }

  @Test
  public void getExpandsSelectedPaths_test_8103() {
    JTree instance = new JTree();
    instance.getExpandsSelectedPaths();
  }

  @Test
  public void isPathEditable_test_8104(TreePath p0) {
    JTree instance = new JTree();
    instance.isPathEditable(p0);
  }

  @Test
  public void setSelectionRow_test_8105(int p0) {
    JTree instance = new JTree();
    instance.setSelectionRow(p0);
  }

  @Test
  public void addSelectionRow_test_8106(int p0) {
    JTree instance = new JTree();
    instance.addSelectionRow(p0);
  }

  @Test
  public void getLastSelectedPathComponent_test_8107() {
    JTree instance = new JTree();
    instance.getLastSelectedPathComponent();
  }

  @Test
  public void getLeadSelectionRow_test_8108() {
    JTree instance = new JTree();
    instance.getLeadSelectionRow();
  }

  @Test
  public void getExpandedDescendants_test_8109(TreePath p0) {
    JTree instance = new JTree();
    instance.getExpandedDescendants(p0);
  }

  @Test
  public void hasBeenExpanded_test_8110(TreePath p0) {
    JTree instance = new JTree();
    instance.hasBeenExpanded(p0);
  }

  @Test
  public void scrollRowToVisible_test_8111(int p0) {
    JTree instance = new JTree();
    instance.scrollRowToVisible(p0);
  }

  @Test
  public void collapseRow_test_8112(int p0) {
    JTree instance = new JTree();
    instance.collapseRow(p0);
  }

  @Test
  public void removeSelectionRow_test_8113(int p0) {
    JTree instance = new JTree();
    instance.removeSelectionRow(p0);
  }

  @Test
  public void addTreeExpansionListener_test_8114(TreeExpansionListener p0) {
    JTree instance = new JTree();
    instance.addTreeExpansionListener(p0);
  }

  @Test
  public void removeTreeExpansionListener_test_8115(TreeExpansionListener p0) {
    JTree instance = new JTree();
    instance.removeTreeExpansionListener(p0);
  }

  @Test
  public void getTreeExpansionListeners_test_8116() {
    JTree instance = new JTree();
    instance.getTreeExpansionListeners();
  }

  @Test
  public void addTreeWillExpandListener_test_8117(TreeWillExpandListener p0) {
    JTree instance = new JTree();
    instance.addTreeWillExpandListener(p0);
  }

  @Test
  public void removeTreeWillExpandListener_test_8118(TreeWillExpandListener p0) {
    JTree instance = new JTree();
    instance.removeTreeWillExpandListener(p0);
  }

  @Test
  public void getTreeWillExpandListeners_test_8119() {
    JTree instance = new JTree();
    instance.getTreeWillExpandListeners();
  }

  @Test
  public void getTreeSelectionListeners_test_8120() {
    JTree instance = new JTree();
    instance.getTreeSelectionListeners();
  }

  @Test
  public void treeDidChange_test_8121() {
    JTree instance = new JTree();
    instance.treeDidChange();
  }

  @Test
  public void convertValueToText_test_8122(Object p0, boolean p1, boolean p2, boolean p3, int p4,
      boolean p5) {
    JTree instance = new JTree();
    instance.convertValueToText(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getCellRenderer_test_8123() {
    JTree instance = new JTree();
    instance.getCellRenderer();
  }

  @Test
  public void getDropLocation_test_8124() {
    JTree instance = new JTree();
    instance.getDropLocation();
  }

  @Test
  public void isSelectionEmpty_test_8125() {
    JTree instance = new JTree();
    instance.isSelectionEmpty();
  }

  @Test
  public void setSelectionInterval_test_8126(int p0, int p1) {
    JTree instance = new JTree();
    instance.setSelectionInterval(p0, p1);
  }

  @Test
  public void addSelectionInterval_test_8127(int p0, int p1) {
    JTree instance = new JTree();
    instance.addSelectionInterval(p0, p1);
  }

  @Test
  public void removeSelectionInterval_test_8128(int p0, int p1) {
    JTree instance = new JTree();
    instance.removeSelectionInterval(p0, p1);
  }

  @Test
  public void getVisibleRowCount_test_8129() {
    JTree instance = new JTree();
    instance.getVisibleRowCount();
  }

  @Test
  public void setCellRenderer_test_8130(TreeCellRenderer p0) {
    JTree instance = new JTree();
    instance.setCellRenderer(p0);
  }

  @Test
  public void setVisibleRowCount_test_8131(int p0) {
    JTree instance = new JTree();
    instance.setVisibleRowCount(p0);
  }

  @Test
  public void getNextMatch_test_8132(String p0, int p1, Position.Bias p2) {
    JTree instance = new JTree();
    instance.getNextMatch(p0, p1, p2);
  }

  @Test
  public void setModel_test_8133(TreeModel p0) {
    JTree instance = new JTree();
    instance.setModel(p0);
  }

  @Test
  public void setDragEnabled_test_8134(boolean p0) {
    JTree instance = new JTree();
    instance.setDragEnabled(p0);
  }

  @Test
  public void getDragEnabled_test_8135() {
    JTree instance = new JTree();
    instance.getDragEnabled();
  }

  @Test
  public void getSelectionModel_test_8136() {
    JTree instance = new JTree();
    instance.getSelectionModel();
  }

  @Test
  public void setSelectionModel_test_8137(TreeSelectionModel p0) {
    JTree instance = new JTree();
    instance.setSelectionModel(p0);
  }

  @Test
  public void isExpanded_test_8138(int p0) {
    JTree instance = new JTree();
    instance.isExpanded(p0);
  }

  @Test
  public void isExpanded_test_8139(TreePath p0) {
    JTree instance = new JTree();
    instance.isExpanded(p0);
  }

  @Test
  public void getAccessibleContext_test_8140() {
    JTree instance = new JTree();
    instance.getAccessibleContext();
  }

  @Test
  public void isVisible_test_8141(TreePath p0) {
    JTree instance = new JTree();
    instance.isVisible(p0);
  }

  @Test
  public void updateUI_test_8142() {
    JTree instance = new JTree();
    instance.updateUI();
  }

  @Test
  public void makeVisible_test_8143(TreePath p0) {
    JTree instance = new JTree();
    instance.makeVisible(p0);
  }

  @Test
  public void setEditable_test_8144(boolean p0) {
    JTree instance = new JTree();
    instance.setEditable(p0);
  }

  @Test
  public void isEditable_test_8145() {
    JTree instance = new JTree();
    instance.isEditable();
  }
}
