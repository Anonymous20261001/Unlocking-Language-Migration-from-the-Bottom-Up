package generated.test;

import java.lang.Comparable;
import java.lang.Object;
import javax.swing.SpinnerDateModel;
import org.junit.jupiter.api.Test;

public class SpinnerDateModelAutoTest {
  @Test
  public void getStart_test_8297() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getStart();
  }

  @Test
  public void getEnd_test_8298() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getEnd();
  }

  @Test
  public void getNextValue_test_8299() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getNextValue();
  }

  @Test
  public void getPreviousValue_test_8300() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getPreviousValue();
  }

  @Test
  public void setEnd_test_8301(Comparable p0) {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.setEnd(p0);
  }

  @Test
  public void setCalendarField_test_8302(int p0) {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.setCalendarField(p0);
  }

  @Test
  public void getValue_test_8303() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getValue();
  }

  @Test
  public void setValue_test_8304(Object p0) {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.setValue(p0);
  }

  @Test
  public void getCalendarField_test_8305() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getCalendarField();
  }

  @Test
  public void getDate_test_8306() {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.getDate();
  }

  @Test
  public void setStart_test_8307(Comparable p0) {
    SpinnerDateModel instance = new SpinnerDateModel();
    instance.setStart(p0);
  }
}
