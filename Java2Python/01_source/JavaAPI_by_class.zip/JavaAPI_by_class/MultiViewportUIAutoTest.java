package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiViewportUI;
import org.junit.jupiter.api.Test;

public class MultiViewportUIAutoTest {
  @Test
  public void installUI_test_9696(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9697(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9698() {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9699(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    MultiViewportUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9700(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9701(Graphics p0, JComponent p1) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9702(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9703(JComponent p0, int p1) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9704(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9705(JComponent p0) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9706(Graphics p0, JComponent p1) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9707(JComponent p0, int p1, int p2) {
    MultiViewportUI instance = new MultiViewportUI();
    instance.contains(p0, p1, p2);
  }
}
