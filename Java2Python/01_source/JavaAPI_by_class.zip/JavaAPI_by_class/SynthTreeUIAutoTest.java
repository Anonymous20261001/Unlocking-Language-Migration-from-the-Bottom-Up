package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthTreeUI;
import org.junit.jupiter.api.Test;

public class SynthTreeUIAutoTest {
  @Test
  public void propertyChange_test_9964(PropertyChangeEvent p0) {
    SynthTreeUI instance = new SynthTreeUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9965(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthTreeUI instance = new SynthTreeUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getExpandedIcon_test_9966() {
    SynthTreeUI instance = new SynthTreeUI();
    instance.getExpandedIcon();
  }

  @Test
  public void getCollapsedIcon_test_9967() {
    SynthTreeUI instance = new SynthTreeUI();
    instance.getCollapsedIcon();
  }

  @Test
  public void createUI_test_9968(JComponent p0) {
    SynthTreeUI instance = new SynthTreeUI();
    SynthTreeUI.createUI(p0);
  }

  @Test
  public void paint_test_9969(Graphics p0, JComponent p1) {
    SynthTreeUI instance = new SynthTreeUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9970(Graphics p0, JComponent p1) {
    SynthTreeUI instance = new SynthTreeUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9971(JComponent p0) {
    SynthTreeUI instance = new SynthTreeUI();
    instance.getContext(p0);
  }
}
