package generated.test;

import java.lang.Object;
import javax.swing.event.UndoableEditEvent;
import javax.swing.undo.UndoableEdit;
import org.junit.jupiter.api.Test;

public class UndoableEditEventAutoTest {
  @Test
  public void getEdit_test_8575(Object c0, UndoableEdit c1) {
    UndoableEditEvent instance = new UndoableEditEvent(c0, c1);
    instance.getEdit();
  }
}
