package generated.test;

import javax.swing.RowSorter;
import javax.swing.event.RowSorterEvent;
import org.junit.jupiter.api.Test;

public class RowSorterEventAutoTest {
  @Test
  public void getPreviousRowCount_test_8549(RowSorter c0) {
    RowSorterEvent instance = new RowSorterEvent(c0);
    instance.getPreviousRowCount();
  }

  @Test
  public void convertPreviousRowIndexToModel_test_8550(int p0, RowSorter c0) {
    RowSorterEvent instance = new RowSorterEvent(c0);
    instance.convertPreviousRowIndexToModel(p0);
  }

  @Test
  public void getSource_test_8551(RowSorter c0) {
    RowSorterEvent instance = new RowSorterEvent(c0);
    instance.getSource();
  }

  @Test
  public void getType_test_8552(RowSorter c0) {
    RowSorterEvent instance = new RowSorterEvent(c0);
    instance.getType();
  }
}
