package generated.test;

import java.lang.Object;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreePath;
import org.junit.jupiter.api.Test;

public class TreeSelectionEventAutoTest {
  @Test
  public void isAddedPath_test_8567(Object c0, TreePath[] c1, boolean[] c2, TreePath c3,
      TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.isAddedPath();
  }

  @Test
  public void isAddedPath_test_8568(int p0, Object c0, TreePath[] c1, boolean[] c2, TreePath c3,
      TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.isAddedPath(p0);
  }

  @Test
  public void isAddedPath_test_8569(TreePath p0, Object c0, TreePath[] c1, boolean[] c2,
      TreePath c3, TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.isAddedPath(p0);
  }

  @Test
  public void getOldLeadSelectionPath_test_8570(Object c0, TreePath[] c1, boolean[] c2, TreePath c3,
      TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.getOldLeadSelectionPath();
  }

  @Test
  public void getNewLeadSelectionPath_test_8571(Object c0, TreePath[] c1, boolean[] c2, TreePath c3,
      TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.getNewLeadSelectionPath();
  }

  @Test
  public void cloneWithSource_test_8572(Object p0, Object c0, TreePath[] c1, boolean[] c2,
      TreePath c3, TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.cloneWithSource(p0);
  }

  @Test
  public void getPath_test_8573(Object c0, TreePath[] c1, boolean[] c2, TreePath c3, TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.getPath();
  }

  @Test
  public void getPaths_test_8574(Object c0, TreePath[] c1, boolean[] c2, TreePath c3, TreePath c4) {
    TreeSelectionEvent instance = new TreeSelectionEvent(c0, c1, c2, c3, c4);
    instance.getPaths();
  }
}
