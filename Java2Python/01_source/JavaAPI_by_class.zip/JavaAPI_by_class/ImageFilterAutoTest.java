package generated.test;

import java.awt.image.ColorModel;
import java.awt.image.ImageConsumer;
import java.awt.image.ImageFilter;
import java.awt.image.ImageProducer;
import java.util.Hashtable;
import org.junit.jupiter.api.Test;

public class ImageFilterAutoTest {
  @Test
  public void setHints_test_1269(int p0) {
    ImageFilter instance = new ImageFilter();
    instance.setHints(p0);
  }

  @Test
  public void setPixels_test_1270(int p0, int p1, int p2, int p3, ColorModel p4, byte[] p5, int p6,
      int p7) {
    ImageFilter instance = new ImageFilter();
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setPixels_test_1271(int p0, int p1, int p2, int p3, ColorModel p4, int[] p5, int p6,
      int p7) {
    ImageFilter instance = new ImageFilter();
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setDimensions_test_1272(int p0, int p1) {
    ImageFilter instance = new ImageFilter();
    instance.setDimensions(p0, p1);
  }

  @Test
  public void setColorModel_test_1273(ColorModel p0) {
    ImageFilter instance = new ImageFilter();
    instance.setColorModel(p0);
  }

  @Test
  public void imageComplete_test_1274(int p0) {
    ImageFilter instance = new ImageFilter();
    instance.imageComplete(p0);
  }

  @Test
  public void getFilterInstance_test_1275(ImageConsumer p0) {
    ImageFilter instance = new ImageFilter();
    instance.getFilterInstance(p0);
  }

  @Test
  public void resendTopDownLeftRight_test_1276(ImageProducer p0) {
    ImageFilter instance = new ImageFilter();
    instance.resendTopDownLeftRight(p0);
  }

  @Test
  public void clone_test_1277() {
    ImageFilter instance = new ImageFilter();
    instance.clone();
  }

  @Test
  public void setProperties_test_1278(Hashtable p0) {
    ImageFilter instance = new ImageFilter();
    instance.setProperties(p0);
  }
}
