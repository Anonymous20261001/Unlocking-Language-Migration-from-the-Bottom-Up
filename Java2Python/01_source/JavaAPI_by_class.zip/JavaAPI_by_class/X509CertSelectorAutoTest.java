package generated.test;

import java.math.BigInteger;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.Date;
import javax.security.auth.x500.X500Principal;
import org.junit.jupiter.api.Test;

public class X509CertSelectorAutoTest {
  @Test
  public void getCertificate_test_2810() {
    X509CertSelector instance = new X509CertSelector();
    instance.getCertificate();
  }

  @Test
  public void getNameConstraints_test_2811() {
    X509CertSelector instance = new X509CertSelector();
    instance.getNameConstraints();
  }

  @Test
  public void getIssuerAsString_test_2812() {
    X509CertSelector instance = new X509CertSelector();
    instance.getIssuerAsString();
  }

  @Test
  public void getSubjectAsString_test_2813() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubjectAsString();
  }

  @Test
  public void getSerialNumber_test_2814() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSerialNumber();
  }

  @Test
  public void getKeyUsage_test_2815() {
    X509CertSelector instance = new X509CertSelector();
    instance.getKeyUsage();
  }

  @Test
  public void setCertificate_test_2816(X509Certificate p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setCertificate(p0);
  }

  @Test
  public void setSerialNumber_test_2817(BigInteger p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setSerialNumber(p0);
  }

  @Test
  public void setIssuer_test_2818(X500Principal p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setIssuer(p0);
  }

  @Test
  public void setSubject_test_2819(X500Principal p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setSubject(p0);
  }

  @Test
  public void setSubjectKeyIdentifier_test_2820(byte[] p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setSubjectKeyIdentifier(p0);
  }

  @Test
  public void setAuthorityKeyIdentifier_test_2821(byte[] p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setAuthorityKeyIdentifier(p0);
  }

  @Test
  public void setCertificateValid_test_2822(Date p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setCertificateValid(p0);
  }

  @Test
  public void setPrivateKeyValid_test_2823(Date p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setPrivateKeyValid(p0);
  }

  @Test
  public void setSubjectPublicKey_test_2824(PublicKey p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setSubjectPublicKey(p0);
  }

  @Test
  public void setKeyUsage_test_2825(boolean[] p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setKeyUsage(p0);
  }

  @Test
  public void setMatchAllSubjectAltNames_test_2826(boolean p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setMatchAllSubjectAltNames(p0);
  }

  @Test
  public void setBasicConstraints_test_2827(int p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.setBasicConstraints(p0);
  }

  @Test
  public void getIssuer_test_2828() {
    X509CertSelector instance = new X509CertSelector();
    instance.getIssuer();
  }

  @Test
  public void getSubject_test_2829() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubject();
  }

  @Test
  public void getSubjectKeyIdentifier_test_2830() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubjectKeyIdentifier();
  }

  @Test
  public void getAuthorityKeyIdentifier_test_2831() {
    X509CertSelector instance = new X509CertSelector();
    instance.getAuthorityKeyIdentifier();
  }

  @Test
  public void getCertificateValid_test_2832() {
    X509CertSelector instance = new X509CertSelector();
    instance.getCertificateValid();
  }

  @Test
  public void getPrivateKeyValid_test_2833() {
    X509CertSelector instance = new X509CertSelector();
    instance.getPrivateKeyValid();
  }

  @Test
  public void getSubjectPublicKeyAlgID_test_2834() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubjectPublicKeyAlgID();
  }

  @Test
  public void getSubjectPublicKey_test_2835() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubjectPublicKey();
  }

  @Test
  public void getExtendedKeyUsage_test_2836() {
    X509CertSelector instance = new X509CertSelector();
    instance.getExtendedKeyUsage();
  }

  @Test
  public void getMatchAllSubjectAltNames_test_2837() {
    X509CertSelector instance = new X509CertSelector();
    instance.getMatchAllSubjectAltNames();
  }

  @Test
  public void getSubjectAlternativeNames_test_2838() {
    X509CertSelector instance = new X509CertSelector();
    instance.getSubjectAlternativeNames();
  }

  @Test
  public void getPathToNames_test_2839() {
    X509CertSelector instance = new X509CertSelector();
    instance.getPathToNames();
  }

  @Test
  public void toString_test_2840() {
    X509CertSelector instance = new X509CertSelector();
    instance.toString();
  }

  @Test
  public void clone_test_2841() {
    X509CertSelector instance = new X509CertSelector();
    instance.clone();
  }

  @Test
  public void match_test_2842(Certificate p0) {
    X509CertSelector instance = new X509CertSelector();
    instance.match(p0);
  }

  @Test
  public void getPolicy_test_2843() {
    X509CertSelector instance = new X509CertSelector();
    instance.getPolicy();
  }

  @Test
  public void getBasicConstraints_test_2844() {
    X509CertSelector instance = new X509CertSelector();
    instance.getBasicConstraints();
  }
}
