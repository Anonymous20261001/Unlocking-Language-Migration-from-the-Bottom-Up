package generated.test;

import javax.management.ObjectName;
import javax.management.monitor.CounterMonitor;
import org.junit.jupiter.api.Test;

public class CounterMonitorAutoTest {
  @Test
  public void getNotificationInfo_test_5700() {
    CounterMonitor instance = new CounterMonitor();
    instance.getNotificationInfo();
  }

  @Test
  public void getDerivedGauge_test_5701(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGauge(p0);
  }

  @Test
  public void getDerivedGauge_test_5702() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGauge();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5703() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGaugeTimeStamp();
  }

  @Test
  public void getDerivedGaugeTimeStamp_test_5704(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getDerivedGaugeTimeStamp(p0);
  }

  @Test
  public void getThreshold_test_5705() {
    CounterMonitor instance = new CounterMonitor();
    instance.getThreshold();
  }

  @Test
  public void getThreshold_test_5706(ObjectName p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.getThreshold(p0);
  }

  @Test
  public void getInitThreshold_test_5707() {
    CounterMonitor instance = new CounterMonitor();
    instance.getInitThreshold();
  }

  @Test
  public void getNotify_test_5708() {
    CounterMonitor instance = new CounterMonitor();
    instance.getNotify();
  }

  @Test
  public void setNotify_test_5709(boolean p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setNotify(p0);
  }

  @Test
  public void getDifferenceMode_test_5710() {
    CounterMonitor instance = new CounterMonitor();
    instance.getDifferenceMode();
  }

  @Test
  public void setDifferenceMode_test_5711(boolean p0) {
    CounterMonitor instance = new CounterMonitor();
    instance.setDifferenceMode(p0);
  }

  @Test
  public void getModulus_test_5712() {
    CounterMonitor instance = new CounterMonitor();
    instance.getModulus();
  }

  @Test
  public void start_test_5713() {
    CounterMonitor instance = new CounterMonitor();
    instance.start();
  }

  @Test
  public void stop_test_5714() {
    CounterMonitor instance = new CounterMonitor();
    instance.stop();
  }

  @Test
  public void getOffset_test_5715() {
    CounterMonitor instance = new CounterMonitor();
    instance.getOffset();
  }
}
