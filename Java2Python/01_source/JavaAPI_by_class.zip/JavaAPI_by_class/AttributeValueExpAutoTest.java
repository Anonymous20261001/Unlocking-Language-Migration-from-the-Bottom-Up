package generated.test;

import javax.management.AttributeValueExp;
import javax.management.MBeanServer;
import org.junit.jupiter.api.Test;

public class AttributeValueExpAutoTest {
  @Test
  public void getAttributeName_test_5542() {
    AttributeValueExp instance = new AttributeValueExp();
    instance.getAttributeName();
  }

  @Test
  public void setMBeanServer_test_5543(MBeanServer p0) {
    AttributeValueExp instance = new AttributeValueExp();
    instance.setMBeanServer(p0);
  }

  @Test
  public void toString_test_5544() {
    AttributeValueExp instance = new AttributeValueExp();
    instance.toString();
  }
}
