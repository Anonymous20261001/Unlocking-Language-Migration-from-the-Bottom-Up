package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthRadioButtonUI;
import org.junit.jupiter.api.Test;

public class SynthRadioButtonUIAutoTest {
  @Test
  public void paintBorder_test_9869(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthRadioButtonUI instance = new SynthRadioButtonUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9870(JComponent p0) {
    SynthRadioButtonUI instance = new SynthRadioButtonUI();
    SynthRadioButtonUI.createUI(p0);
  }
}
