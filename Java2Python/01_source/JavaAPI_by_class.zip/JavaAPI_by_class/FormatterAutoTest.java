package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Formatter;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class FormatterAutoTest {
  @Test
  public void toString_test_3446() {
    Formatter instance = new Formatter();
    instance.toString();
  }

  @Test
  public void flush_test_3447() {
    Formatter instance = new Formatter();
    instance.flush();
  }

  @Test
  public void format_test_3448(String p0, Object[] p1) {
    Formatter instance = new Formatter();
    instance.format(p0, p1);
  }

  @Test
  public void format_test_3449(Locale p0, String p1, Object[] p2) {
    Formatter instance = new Formatter();
    instance.format(p0, p1, p2);
  }

  @Test
  public void locale_test_3450() {
    Formatter instance = new Formatter();
    instance.locale();
  }

  @Test
  public void out_test_3451() {
    Formatter instance = new Formatter();
    instance.out();
  }

  @Test
  public void close_test_3452() {
    Formatter instance = new Formatter();
    instance.close();
  }

  @Test
  public void ioException_test_3453() {
    Formatter instance = new Formatter();
    instance.ioException();
  }
}
