package generated.test;

import java.lang.String;
import javax.security.auth.callback.TextInputCallback;
import org.junit.jupiter.api.Test;

public class TextInputCallbackAutoTest {
  @Test
  public void getPrompt_test_6351(String c0) {
    TextInputCallback instance = new TextInputCallback(c0);
    instance.getPrompt();
  }

  @Test
  public void getDefaultText_test_6352(String c0) {
    TextInputCallback instance = new TextInputCallback(c0);
    instance.getDefaultText();
  }

  @Test
  public void setText_test_6353(String p0, String c0) {
    TextInputCallback instance = new TextInputCallback(c0);
    instance.setText(p0);
  }

  @Test
  public void getText_test_6354(String c0) {
    TextInputCallback instance = new TextInputCallback(c0);
    instance.getText();
  }
}
