package generated.test;

import javax.swing.plaf.metal.DefaultMetalTheme;
import org.junit.jupiter.api.Test;

public class DefaultMetalThemeAutoTest {
  @Test
  public void getControlTextFont_test_9074() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getControlTextFont();
  }

  @Test
  public void getSystemTextFont_test_9075() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getSystemTextFont();
  }

  @Test
  public void getUserTextFont_test_9076() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getUserTextFont();
  }

  @Test
  public void getMenuTextFont_test_9077() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getMenuTextFont();
  }

  @Test
  public void getWindowTitleFont_test_9078() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getWindowTitleFont();
  }

  @Test
  public void getSubTextFont_test_9079() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getSubTextFont();
  }

  @Test
  public void getName_test_9080() {
    DefaultMetalTheme instance = new DefaultMetalTheme();
    instance.getName();
  }
}
