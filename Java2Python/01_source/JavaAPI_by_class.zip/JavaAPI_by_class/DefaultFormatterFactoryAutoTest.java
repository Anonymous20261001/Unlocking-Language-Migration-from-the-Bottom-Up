package generated.test;

import javax.swing.JFormattedTextField;
import javax.swing.text.DefaultFormatterFactory;
import org.junit.jupiter.api.Test;

public class DefaultFormatterFactoryAutoTest {
  @Test
  public void getNullFormatter_test_10208() {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.getNullFormatter();
  }

  @Test
  public void getEditFormatter_test_10209() {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.getEditFormatter();
  }

  @Test
  public void getDisplayFormatter_test_10210() {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.getDisplayFormatter();
  }

  @Test
  public void getDefaultFormatter_test_10211() {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.getDefaultFormatter();
  }

  @Test
  public void setDefaultFormatter_test_10212(JFormattedTextField.AbstractFormatter p0) {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.setDefaultFormatter(p0);
  }

  @Test
  public void setDisplayFormatter_test_10213(JFormattedTextField.AbstractFormatter p0) {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.setDisplayFormatter(p0);
  }

  @Test
  public void setEditFormatter_test_10214(JFormattedTextField.AbstractFormatter p0) {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.setEditFormatter(p0);
  }

  @Test
  public void setNullFormatter_test_10215(JFormattedTextField.AbstractFormatter p0) {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.setNullFormatter(p0);
  }

  @Test
  public void getFormatter_test_10216(JFormattedTextField p0) {
    DefaultFormatterFactory instance = new DefaultFormatterFactory();
    instance.getFormatter(p0);
  }
}
