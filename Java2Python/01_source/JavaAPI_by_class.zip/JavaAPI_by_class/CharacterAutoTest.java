package generated.test;

import java.lang.CharSequence;
import java.lang.Character;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class CharacterAutoTest {
  @Test
  public void getName_test_1871(int p0, char c0) {
    Character instance = new Character(c0);
    Character.getName(p0);
  }

  @Test
  public void isJavaIdentifierStart_test_1872(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaIdentifierStart(p0);
  }

  @Test
  public void isJavaIdentifierStart_test_1873(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaIdentifierStart(p0);
  }

  @Test
  public void isJavaIdentifierPart_test_1874(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaIdentifierPart(p0);
  }

  @Test
  public void isJavaIdentifierPart_test_1875(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaIdentifierPart(p0);
  }

  @Test
  public void equals_test_1876(Object p0, char c0) {
    Character instance = new Character(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_1877(char c0) {
    Character instance = new Character(c0);
    instance.toString();
  }

  @Test
  public void toString_test_1878(int p0, char c0) {
    Character instance = new Character(c0);
    Character.toString(p0);
  }

  @Test
  public void toString_test_1879(char p0, char c0) {
    Character instance = new Character(c0);
    Character.toString(p0);
  }

  @Test
  public void hashCode_test_1880(char c0) {
    Character instance = new Character(c0);
    instance.hashCode();
  }

  @Test
  public void hashCode_test_1881(char p0, char c0) {
    Character instance = new Character(c0);
    Character.hashCode(p0);
  }

  @Test
  public void reverseBytes_test_1882(char p0, char c0) {
    Character instance = new Character(c0);
    Character.reverseBytes(p0);
  }

  @Test
  public void compareTo_test_1883(Character p0, char c0) {
    Character instance = new Character(c0);
    instance.compareTo(p0);
  }

  @Test
  public void isDigit_test_1884(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isDigit(p0);
  }

  @Test
  public void isDigit_test_1885(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isDigit(p0);
  }

  @Test
  public void isLowerCase_test_1886(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isLowerCase(p0);
  }

  @Test
  public void isLowerCase_test_1887(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isLowerCase(p0);
  }

  @Test
  public void isUpperCase_test_1888(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isUpperCase(p0);
  }

  @Test
  public void isUpperCase_test_1889(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isUpperCase(p0);
  }

  @Test
  public void isWhitespace_test_1890(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isWhitespace(p0);
  }

  @Test
  public void isWhitespace_test_1891(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isWhitespace(p0);
  }

  @Test
  public void compare_test_1892(char p0, char p1, char c0) {
    Character instance = new Character(c0);
    Character.compare(p0, p1);
  }

  @Test
  public void charValue_test_1893(char c0) {
    Character instance = new Character(c0);
    instance.charValue();
  }

  @Test
  public void valueOf_test_1894(char p0, char c0) {
    Character instance = new Character(c0);
    Character.valueOf(p0);
  }

  @Test
  public void toChars_test_1895(int p0, char c0) {
    Character instance = new Character(c0);
    Character.toChars(p0);
  }

  @Test
  public void toChars_test_1896(int p0, char[] p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.toChars(p0, p1, p2);
  }

  @Test
  public void isHighSurrogate_test_1897(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isHighSurrogate(p0);
  }

  @Test
  public void isLowSurrogate_test_1898(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isLowSurrogate(p0);
  }

  @Test
  public void isSurrogate_test_1899(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isSurrogate(p0);
  }

  @Test
  public void isSupplementaryCodePoint_test_1900(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isSupplementaryCodePoint(p0);
  }

  @Test
  public void highSurrogate_test_1901(int p0, char c0) {
    Character instance = new Character(c0);
    Character.highSurrogate(p0);
  }

  @Test
  public void lowSurrogate_test_1902(int p0, char c0) {
    Character instance = new Character(c0);
    Character.lowSurrogate(p0);
  }

  @Test
  public void toCodePoint_test_1903(char p0, char p1, char c0) {
    Character instance = new Character(c0);
    Character.toCodePoint(p0, p1);
  }

  @Test
  public void codePointAt_test_1904(CharSequence p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.codePointAt(p0, p1);
  }

  @Test
  public void codePointAt_test_1905(char[] p0, int p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.codePointAt(p0, p1, p2);
  }

  @Test
  public void codePointAt_test_1906(char[] p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.codePointAt(p0, p1);
  }

  @Test
  public void codePointBefore_test_1907(CharSequence p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.codePointBefore(p0, p1);
  }

  @Test
  public void codePointBefore_test_1908(char[] p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.codePointBefore(p0, p1);
  }

  @Test
  public void codePointBefore_test_1909(char[] p0, int p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.codePointBefore(p0, p1, p2);
  }

  @Test
  public void codePointCount_test_1910(CharSequence p0, int p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.codePointCount(p0, p1, p2);
  }

  @Test
  public void codePointCount_test_1911(char[] p0, int p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.codePointCount(p0, p1, p2);
  }

  @Test
  public void offsetByCodePoints_test_1912(char[] p0, int p1, int p2, int p3, int p4, char c0) {
    Character instance = new Character(c0);
    Character.offsetByCodePoints(p0, p1, p2, p3, p4);
  }

  @Test
  public void offsetByCodePoints_test_1913(CharSequence p0, int p1, int p2, char c0) {
    Character instance = new Character(c0);
    Character.offsetByCodePoints(p0, p1, p2);
  }

  @Test
  public void toLowerCase_test_1914(char p0, char c0) {
    Character instance = new Character(c0);
    Character.toLowerCase(p0);
  }

  @Test
  public void toLowerCase_test_1915(int p0, char c0) {
    Character instance = new Character(c0);
    Character.toLowerCase(p0);
  }

  @Test
  public void toUpperCase_test_1916(int p0, char c0) {
    Character instance = new Character(c0);
    Character.toUpperCase(p0);
  }

  @Test
  public void toUpperCase_test_1917(char p0, char c0) {
    Character instance = new Character(c0);
    Character.toUpperCase(p0);
  }

  @Test
  public void isBmpCodePoint_test_1918(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isBmpCodePoint(p0);
  }

  @Test
  public void describeConstable_test_1919(char c0) {
    Character instance = new Character(c0);
    instance.describeConstable();
  }

  @Test
  public void getType_test_1920(char p0, char c0) {
    Character instance = new Character(c0);
    Character.getType(p0);
  }

  @Test
  public void getType_test_1921(int p0, char c0) {
    Character instance = new Character(c0);
    Character.getType(p0);
  }

  @Test
  public void isLetter_test_1922(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isLetter(p0);
  }

  @Test
  public void isLetter_test_1923(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isLetter(p0);
  }

  @Test
  public void isLetterOrDigit_test_1924(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isLetterOrDigit(p0);
  }

  @Test
  public void isLetterOrDigit_test_1925(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isLetterOrDigit(p0);
  }

  @Test
  public void isValidCodePoint_test_1926(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isValidCodePoint(p0);
  }

  @Test
  public void isTitleCase_test_1927(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isTitleCase(p0);
  }

  @Test
  public void isTitleCase_test_1928(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isTitleCase(p0);
  }

  @Test
  public void isDefined_test_1929(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isDefined(p0);
  }

  @Test
  public void isDefined_test_1930(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isDefined(p0);
  }

  @Test
  public void isIdeographic_test_1931(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isIdeographic(p0);
  }

  @Test
  public void isUnicodeIdentifierStart_test_1932(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isUnicodeIdentifierStart(p0);
  }

  @Test
  public void isUnicodeIdentifierStart_test_1933(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isUnicodeIdentifierStart(p0);
  }

  @Test
  public void isUnicodeIdentifierPart_test_1934(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isUnicodeIdentifierPart(p0);
  }

  @Test
  public void isUnicodeIdentifierPart_test_1935(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isUnicodeIdentifierPart(p0);
  }

  @Test
  public void isIdentifierIgnorable_test_1936(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isIdentifierIgnorable(p0);
  }

  @Test
  public void isIdentifierIgnorable_test_1937(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isIdentifierIgnorable(p0);
  }

  @Test
  public void isEmoji_test_1938(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isEmoji(p0);
  }

  @Test
  public void isEmojiPresentation_test_1939(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isEmojiPresentation(p0);
  }

  @Test
  public void isEmojiModifier_test_1940(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isEmojiModifier(p0);
  }

  @Test
  public void isEmojiModifierBase_test_1941(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isEmojiModifierBase(p0);
  }

  @Test
  public void isEmojiComponent_test_1942(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isEmojiComponent(p0);
  }

  @Test
  public void isExtendedPictographic_test_1943(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isExtendedPictographic(p0);
  }

  @Test
  public void toTitleCase_test_1944(char p0, char c0) {
    Character instance = new Character(c0);
    Character.toTitleCase(p0);
  }

  @Test
  public void toTitleCase_test_1945(int p0, char c0) {
    Character instance = new Character(c0);
    Character.toTitleCase(p0);
  }

  @Test
  public void digit_test_1946(char p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.digit(p0, p1);
  }

  @Test
  public void digit_test_1947(int p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.digit(p0, p1);
  }

  @Test
  public void getNumericValue_test_1948(int p0, char c0) {
    Character instance = new Character(c0);
    Character.getNumericValue(p0);
  }

  @Test
  public void getNumericValue_test_1949(char p0, char c0) {
    Character instance = new Character(c0);
    Character.getNumericValue(p0);
  }

  @Test
  public void isSpaceChar_test_1950(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isSpaceChar(p0);
  }

  @Test
  public void isSpaceChar_test_1951(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isSpaceChar(p0);
  }

  @Test
  public void isISOControl_test_1952(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isISOControl(p0);
  }

  @Test
  public void isISOControl_test_1953(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isISOControl(p0);
  }

  @Test
  public void getDirectionality_test_1954(char p0, char c0) {
    Character instance = new Character(c0);
    Character.getDirectionality(p0);
  }

  @Test
  public void getDirectionality_test_1955(int p0, char c0) {
    Character instance = new Character(c0);
    Character.getDirectionality(p0);
  }

  @Test
  public void isMirrored_test_1956(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isMirrored(p0);
  }

  @Test
  public void isMirrored_test_1957(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isMirrored(p0);
  }

  @Test
  public void isSurrogatePair_test_1958(char p0, char p1, char c0) {
    Character instance = new Character(c0);
    Character.isSurrogatePair(p0, p1);
  }

  @Test
  public void charCount_test_1959(int p0, char c0) {
    Character instance = new Character(c0);
    Character.charCount(p0);
  }

  @Test
  public void isJavaLetter_test_1960(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaLetter(p0);
  }

  @Test
  public void isJavaLetterOrDigit_test_1961(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isJavaLetterOrDigit(p0);
  }

  @Test
  public void isAlphabetic_test_1962(int p0, char c0) {
    Character instance = new Character(c0);
    Character.isAlphabetic(p0);
  }

  @Test
  public void isSpace_test_1963(char p0, char c0) {
    Character instance = new Character(c0);
    Character.isSpace(p0);
  }

  @Test
  public void forDigit_test_1964(int p0, int p1, char c0) {
    Character instance = new Character(c0);
    Character.forDigit(p0, p1);
  }

  @Test
  public void codePointOf_test_1965(String p0, char c0) {
    Character instance = new Character(c0);
    Character.codePointOf(p0);
  }
}
