package generated.test;

import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.spec.XSLTTransformParameterSpec;
import org.junit.jupiter.api.Test;

public class XSLTTransformParameterSpecAutoTest {
  @Test
  public void getStylesheet_test_10898(XMLStructure c0) {
    XSLTTransformParameterSpec instance = new XSLTTransformParameterSpec(c0);
    instance.getStylesheet();
  }
}
