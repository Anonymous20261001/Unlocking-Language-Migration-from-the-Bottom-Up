package generated.test;

import java.awt.Rectangle;
import javax.swing.event.TreeModelEvent;
import javax.swing.tree.AbstractLayoutCache;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.VariableHeightLayoutCache;
import org.junit.jupiter.api.Test;

public class VariableHeightLayoutCacheAutoTest {
  @Test
  public void treeNodesChanged_test_10783(TreeModelEvent p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.treeNodesChanged(p0);
  }

  @Test
  public void treeNodesInserted_test_10784(TreeModelEvent p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.treeNodesInserted(p0);
  }

  @Test
  public void treeNodesRemoved_test_10785(TreeModelEvent p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.treeNodesRemoved(p0);
  }

  @Test
  public void treeStructureChanged_test_10786(TreeModelEvent p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.treeStructureChanged(p0);
  }

  @Test
  public void setRowHeight_test_10787(int p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.setRowHeight(p0);
  }

  @Test
  public void getRowCount_test_10788() {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getRowCount();
  }

  @Test
  public void setRootVisible_test_10789(boolean p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.setRootVisible(p0);
  }

  @Test
  public void getPathForRow_test_10790(int p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getPathForRow(p0);
  }

  @Test
  public void getRowForPath_test_10791(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getRowForPath(p0);
  }

  @Test
  public void setExpandedState_test_10792(TreePath p0, boolean p1) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.setExpandedState(p0, p1);
  }

  @Test
  public void setModel_test_10793(TreeModel p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.setModel(p0);
  }

  @Test
  public void getPreferredWidth_test_10794(Rectangle p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getPreferredWidth(p0);
  }

  @Test
  public void invalidateSizes_test_10795() {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.invalidateSizes();
  }

  @Test
  public void getPathClosestTo_test_10796(int p0, int p1) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getPathClosestTo(p0, p1);
  }

  @Test
  public void getVisiblePathsFrom_test_10797(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getVisiblePathsFrom(p0);
  }

  @Test
  public void getExpandedState_test_10798(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getExpandedState(p0);
  }

  @Test
  public void setNodeDimensions_test_10799(AbstractLayoutCache.NodeDimensions p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.setNodeDimensions(p0);
  }

  @Test
  public void getPreferredHeight_test_10800() {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getPreferredHeight();
  }

  @Test
  public void invalidatePathBounds_test_10801(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.invalidatePathBounds(p0);
  }

  @Test
  public void getVisibleChildCount_test_10802(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getVisibleChildCount(p0);
  }

  @Test
  public void isExpanded_test_10803(TreePath p0) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.isExpanded(p0);
  }

  @Test
  public void getBounds_test_10804(TreePath p0, Rectangle p1) {
    VariableHeightLayoutCache instance = new VariableHeightLayoutCache();
    instance.getBounds(p0, p1);
  }
}
