package generated.test;

import java.lang.Object;
import java.util.Map;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.rmi.RMIConnector;
import org.junit.jupiter.api.Test;

public class RMIConnectorAutoTest {
  @Test
  public void addConnectionNotificationListener_test_5849(NotificationListener p0,
      NotificationFilter p1, Object p2, JMXServiceURL c0, Map c1) {
    RMIConnector instance = new RMIConnector(c0, c1);
    instance.addConnectionNotificationListener(p0, p1, p2);
  }

  @Test
  public void toString_test_5850(JMXServiceURL c0, Map c1) {
    RMIConnector instance = new RMIConnector(c0, c1);
    instance.toString();
  }

  @Test
  public void getAddress_test_5851(JMXServiceURL c0, Map c1) {
    RMIConnector instance = new RMIConnector(c0, c1);
    instance.getAddress();
  }
}
