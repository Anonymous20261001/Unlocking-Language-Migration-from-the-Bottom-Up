package generated.test;

import javax.swing.text.StringContent;
import org.junit.jupiter.api.Test;

public class StringContentAutoTest {
  @Test
  public void length_test_10376() {
    StringContent instance = new StringContent();
    instance.length();
  }
}
