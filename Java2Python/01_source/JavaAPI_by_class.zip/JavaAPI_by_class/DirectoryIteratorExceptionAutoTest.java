package generated.test;

import java.io.IOException;
import java.nio.file.DirectoryIteratorException;
import org.junit.jupiter.api.Test;

public class DirectoryIteratorExceptionAutoTest {
  @Test
  public void getCause_test_2647(IOException c0) {
    DirectoryIteratorException instance = new DirectoryIteratorException(c0);
    instance.getCause();
  }
}
