package generated.test;

import java.awt.Point;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureRecognizer;
import java.lang.Object;
import java.util.List;
import org.junit.jupiter.api.Test;

public class DragGestureEventAutoTest {
  @Test
  public void getDragSource_test_683(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragSource();
  }

  @Test
  public void getSourceAsDragGestureRecognizer_test_684(DragGestureRecognizer c0, int c1, Point c2,
      List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getSourceAsDragGestureRecognizer();
  }

  @Test
  public void getTriggerEvent_test_685(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getTriggerEvent();
  }

  @Test
  public void getDragOrigin_test_686(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragOrigin();
  }

  @Test
  public void getDragAction_test_687(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getDragAction();
  }

  @Test
  public void toArray_test_688(Object[] p0, DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_689(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.toArray();
  }

  @Test
  public void iterator_test_690(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.iterator();
  }

  @Test
  public void getComponent_test_691(DragGestureRecognizer c0, int c1, Point c2, List c3) {
    DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
    instance.getComponent();
  }
}
