package generated.test;

import java.beans.PropertyChangeListener;
import java.lang.ClassLoader;
import java.lang.Object;
import java.lang.String;
import java.util.Locale;
import javax.swing.JComponent;
import javax.swing.UIDefaults;
import org.junit.jupiter.api.Test;

public class UIDefaultsAutoTest {
  @Test
  public void getDefaultLocale_test_8373() {
    UIDefaults instance = new UIDefaults();
    instance.getDefaultLocale();
  }

  @Test
  public void getBorder_test_8374(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getBorder(p0);
  }

  @Test
  public void getBorder_test_8375(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getBorder(p0, p1);
  }

  @Test
  public void setDefaultLocale_test_8376(Locale p0) {
    UIDefaults instance = new UIDefaults();
    instance.setDefaultLocale(p0);
  }

  @Test
  public void getUI_test_8377(JComponent p0) {
    UIDefaults instance = new UIDefaults();
    instance.getUI(p0);
  }

  @Test
  public void getIcon_test_8378(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getIcon(p0, p1);
  }

  @Test
  public void getIcon_test_8379(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getIcon(p0);
  }

  @Test
  public void getDimension_test_8380(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getDimension(p0, p1);
  }

  @Test
  public void getDimension_test_8381(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getDimension(p0);
  }

  @Test
  public void getUIClass_test_8382(String p0, ClassLoader p1) {
    UIDefaults instance = new UIDefaults();
    instance.getUIClass(p0, p1);
  }

  @Test
  public void getUIClass_test_8383(String p0) {
    UIDefaults instance = new UIDefaults();
    instance.getUIClass(p0);
  }

  @Test
  public void putDefaults_test_8384(Object[] p0) {
    UIDefaults instance = new UIDefaults();
    instance.putDefaults(p0);
  }

  @Test
  public void addResourceBundle_test_8385(String p0) {
    UIDefaults instance = new UIDefaults();
    instance.addResourceBundle(p0);
  }

  @Test
  public void removeResourceBundle_test_8386(String p0) {
    UIDefaults instance = new UIDefaults();
    instance.removeResourceBundle(p0);
  }

  @Test
  public void getInsets_test_8387(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getInsets(p0);
  }

  @Test
  public void getInsets_test_8388(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getInsets(p0, p1);
  }

  @Test
  public void getFont_test_8389(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getFont(p0, p1);
  }

  @Test
  public void getFont_test_8390(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getFont(p0);
  }

  @Test
  public void addPropertyChangeListener_test_8391(PropertyChangeListener p0) {
    UIDefaults instance = new UIDefaults();
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void getPropertyChangeListeners_test_8392() {
    UIDefaults instance = new UIDefaults();
    instance.getPropertyChangeListeners();
  }

  @Test
  public void removePropertyChangeListener_test_8393(PropertyChangeListener p0) {
    UIDefaults instance = new UIDefaults();
    instance.removePropertyChangeListener(p0);
  }

  @Test
  public void getColor_test_8394(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getColor(p0, p1);
  }

  @Test
  public void getColor_test_8395(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getColor(p0);
  }

  @Test
  public void get_test_8396(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.get(p0);
  }

  @Test
  public void get_test_8397(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.get(p0, p1);
  }

  @Test
  public void put_test_8398(Object p0, Object p1) {
    UIDefaults instance = new UIDefaults();
    instance.put(p0, p1);
  }

  @Test
  public void getBoolean_test_8399(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getBoolean(p0);
  }

  @Test
  public void getBoolean_test_8400(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getBoolean(p0, p1);
  }

  @Test
  public void getInt_test_8401(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getInt(p0, p1);
  }

  @Test
  public void getInt_test_8402(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getInt(p0);
  }

  @Test
  public void getString_test_8403(Object p0, Locale p1) {
    UIDefaults instance = new UIDefaults();
    instance.getString(p0, p1);
  }

  @Test
  public void getString_test_8404(Object p0) {
    UIDefaults instance = new UIDefaults();
    instance.getString(p0);
  }
}
