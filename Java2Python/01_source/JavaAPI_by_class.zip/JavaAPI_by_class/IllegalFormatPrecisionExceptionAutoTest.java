package generated.test;

import java.util.IllegalFormatPrecisionException;
import org.junit.jupiter.api.Test;

public class IllegalFormatPrecisionExceptionAutoTest {
  @Test
  public void getPrecision_test_3571(int c0) {
    IllegalFormatPrecisionException instance = new IllegalFormatPrecisionException(c0);
    instance.getPrecision();
  }

  @Test
  public void getMessage_test_3572(int c0) {
    IllegalFormatPrecisionException instance = new IllegalFormatPrecisionException(c0);
    instance.getMessage();
  }
}
