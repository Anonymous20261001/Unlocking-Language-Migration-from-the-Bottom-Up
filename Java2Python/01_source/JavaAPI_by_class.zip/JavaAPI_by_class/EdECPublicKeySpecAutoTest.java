package generated.test;

import java.security.spec.EdECPoint;
import java.security.spec.EdECPublicKeySpec;
import java.security.spec.NamedParameterSpec;
import org.junit.jupiter.api.Test;

public class EdECPublicKeySpecAutoTest {
  @Test
  public void getPoint_test_2887(NamedParameterSpec c0, EdECPoint c1) {
    EdECPublicKeySpec instance = new EdECPublicKeySpec(c0, c1);
    instance.getPoint();
  }

  @Test
  public void getParams_test_2888(NamedParameterSpec c0, EdECPoint c1) {
    EdECPublicKeySpec instance = new EdECPublicKeySpec(c0, c1);
    instance.getParams();
  }
}
