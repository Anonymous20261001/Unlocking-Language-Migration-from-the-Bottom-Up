package generated.test;

import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class IndexColorModelAutoTest {
  @Test
  public void convertToIntDiscrete_test_1279(Raster p0, boolean p1, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.convertToIntDiscrete(p0, p1);
  }

  @Test
  public void getDataElement_test_1280(int[] p0, int p1, int c0, int c1, byte[] c2, byte[] c3,
      byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getDataElement(p0, p1);
  }

  @Test
  public void isCompatibleSampleModel_test_1281(SampleModel p0, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.isCompatibleSampleModel(p0);
  }

  @Test
  public void getTransparentPixel_test_1282(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getTransparentPixel();
  }

  @Test
  public void getReds_test_1283(byte[] p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getReds(p0);
  }

  @Test
  public void getGreens_test_1284(byte[] p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getGreens(p0);
  }

  @Test
  public void getBlues_test_1285(byte[] p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getBlues(p0);
  }

  @Test
  public void getAlphas_test_1286(byte[] p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getAlphas(p0);
  }

  @Test
  public void getRGBs_test_1287(int[] p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getRGBs(p0);
  }

  @Test
  public void getValidPixels_test_1288(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getValidPixels();
  }

  @Test
  public void createCompatibleWritableRaster_test_1289(int p0, int p1, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.createCompatibleWritableRaster(p0, p1);
  }

  @Test
  public void createCompatibleSampleModel_test_1290(int p0, int p1, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.createCompatibleSampleModel(p0, p1);
  }

  @Test
  public void getDataElements_test_1291(int[] p0, int p1, Object p2, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getDataElements(p0, p1, p2);
  }

  @Test
  public void getDataElements_test_1292(int p0, Object p1, int c0, int c1, byte[] c2, byte[] c3,
      byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getDataElements(p0, p1);
  }

  @Test
  public void getMapSize_test_1293(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getMapSize();
  }

  @Test
  public void isCompatibleRaster_test_1294(Raster p0, int c0, int c1, byte[] c2, byte[] c3,
      byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.isCompatibleRaster(p0);
  }

  @Test
  public void getComponentSize_test_1295(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getComponentSize();
  }

  @Test
  public void getComponents_test_1296(Object p0, int[] p1, int p2, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getComponents(p0, p1, p2);
  }

  @Test
  public void getComponents_test_1297(int p0, int[] p1, int p2, int c0, int c1, byte[] c2,
      byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getComponents(p0, p1, p2);
  }

  @Test
  public void getAlpha_test_1298(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getAlpha(p0);
  }

  @Test
  public void getRGB_test_1299(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getRGB(p0);
  }

  @Test
  public void getRed_test_1300(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getRed(p0);
  }

  @Test
  public void getGreen_test_1301(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getGreen(p0);
  }

  @Test
  public void getBlue_test_1302(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getBlue(p0);
  }

  @Test
  public void getTransparency_test_1303(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.getTransparency();
  }

  @Test
  public void equals_test_1304(Object p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.equals(p0);
  }

  @Test
  public void toString_test_1305(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.toString();
  }

  @Test
  public void hashCode_test_1306(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.hashCode();
  }

  @Test
  public void isValid_test_1307(int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.isValid();
  }

  @Test
  public void isValid_test_1308(int p0, int c0, int c1, byte[] c2, byte[] c3, byte[] c4) {
    IndexColorModel instance = new IndexColorModel(c0, c1, c2, c3, c4);
    instance.isValid(p0);
  }
}
