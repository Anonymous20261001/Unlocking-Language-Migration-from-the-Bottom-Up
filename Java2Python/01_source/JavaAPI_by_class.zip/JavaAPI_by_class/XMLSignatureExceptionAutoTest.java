package generated.test;

import java.io.PrintStream;
import java.io.PrintWriter;
import javax.xml.crypto.dsig.XMLSignatureException;
import org.junit.jupiter.api.Test;

public class XMLSignatureExceptionAutoTest {
  @Test
  public void printStackTrace_test_10879() {
    XMLSignatureException instance = new XMLSignatureException();
    instance.printStackTrace();
  }

  @Test
  public void printStackTrace_test_10880(PrintStream p0) {
    XMLSignatureException instance = new XMLSignatureException();
    instance.printStackTrace(p0);
  }

  @Test
  public void printStackTrace_test_10881(PrintWriter p0) {
    XMLSignatureException instance = new XMLSignatureException();
    instance.printStackTrace(p0);
  }

  @Test
  public void getCause_test_10882() {
    XMLSignatureException instance = new XMLSignatureException();
    instance.getCause();
  }
}
