package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicToolTipUI;
import org.junit.jupiter.api.Test;

public class BasicToolTipUIAutoTest {
  @Test
  public void installUI_test_9033(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9034(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_9035(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    BasicToolTipUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9036(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9037(Graphics p0, JComponent p1) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9038(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9039(JComponent p0) {
    BasicToolTipUI instance = new BasicToolTipUI();
    instance.getMinimumSize(p0);
  }
}
