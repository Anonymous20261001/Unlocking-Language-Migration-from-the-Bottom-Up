package generated.test;

import java.security.KeyStore;
import javax.net.ssl.KeyStoreBuilderParameters;
import org.junit.jupiter.api.Test;

public class KeyStoreBuilderParametersAutoTest {
  @Test
  public void getParameters_test_6032(KeyStore.Builder c0) {
    KeyStoreBuilderParameters instance = new KeyStoreBuilderParameters(c0);
    instance.getParameters();
  }
}
