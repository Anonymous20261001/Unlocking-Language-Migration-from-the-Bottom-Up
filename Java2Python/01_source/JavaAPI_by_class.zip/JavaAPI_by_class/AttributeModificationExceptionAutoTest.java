package generated.test;

import javax.naming.directory.AttributeModificationException;
import javax.naming.directory.ModificationItem;
import org.junit.jupiter.api.Test;

public class AttributeModificationExceptionAutoTest {
  @Test
  public void setUnexecutedModifications_test_5952(ModificationItem[] p0) {
    AttributeModificationException instance = new AttributeModificationException();
    instance.setUnexecutedModifications(p0);
  }

  @Test
  public void getUnexecutedModifications_test_5953() {
    AttributeModificationException instance = new AttributeModificationException();
    instance.getUnexecutedModifications();
  }

  @Test
  public void toString_test_5954() {
    AttributeModificationException instance = new AttributeModificationException();
    instance.toString();
  }
}
