package generated.test;

import java.awt.image.ImageConsumer;
import java.awt.image.renderable.RenderContext;
import java.awt.image.renderable.RenderableImage;
import java.awt.image.renderable.RenderableImageProducer;
import org.junit.jupiter.api.Test;

public class RenderableImageProducerAutoTest {
  @Test
  public void setRenderContext_test_1478(RenderContext p0, RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.setRenderContext(p0);
  }

  @Test
  public void addConsumer_test_1479(ImageConsumer p0, RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.addConsumer(p0);
  }

  @Test
  public void removeConsumer_test_1480(ImageConsumer p0, RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.removeConsumer(p0);
  }

  @Test
  public void startProduction_test_1481(ImageConsumer p0, RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.startProduction(p0);
  }

  @Test
  public void isConsumer_test_1482(ImageConsumer p0, RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.isConsumer(p0);
  }

  @Test
  public void requestTopDownLeftRightResend_test_1483(ImageConsumer p0, RenderableImage c0,
      RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.requestTopDownLeftRightResend(p0);
  }

  @Test
  public void run_test_1484(RenderableImage c0, RenderContext c1) {
    RenderableImageProducer instance = new RenderableImageProducer(c0, c1);
    instance.run();
  }
}
