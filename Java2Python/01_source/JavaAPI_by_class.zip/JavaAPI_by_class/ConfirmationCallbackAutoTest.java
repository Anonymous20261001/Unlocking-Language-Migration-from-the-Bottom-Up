package generated.test;

import java.lang.String;
import javax.security.auth.callback.ConfirmationCallback;
import org.junit.jupiter.api.Test;

public class ConfirmationCallbackAutoTest {
  @Test
  public void getPrompt_test_6333(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getPrompt();
  }

  @Test
  public void setSelectedIndex_test_6334(int p0, int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.setSelectedIndex(p0);
  }

  @Test
  public void getMessageType_test_6335(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getMessageType();
  }

  @Test
  public void getOptionType_test_6336(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getOptionType();
  }

  @Test
  public void getOptions_test_6337(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getOptions();
  }

  @Test
  public void getDefaultOption_test_6338(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getDefaultOption();
  }

  @Test
  public void getSelectedIndex_test_6339(int c0, String[] c1, int c2) {
    ConfirmationCallback instance = new ConfirmationCallback(c0, c1, c2);
    instance.getSelectedIndex();
  }
}
