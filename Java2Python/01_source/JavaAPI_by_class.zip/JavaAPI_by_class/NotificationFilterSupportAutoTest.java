package generated.test;

import java.lang.String;
import javax.management.Notification;
import javax.management.NotificationFilterSupport;
import org.junit.jupiter.api.Test;

public class NotificationFilterSupportAutoTest {
  @Test
  public void disableType_test_5627(String p0) {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.disableType(p0);
  }

  @Test
  public void disableAllTypes_test_5628() {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.disableAllTypes();
  }

  @Test
  public void getEnabledTypes_test_5629() {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.getEnabledTypes();
  }

  @Test
  public void isNotificationEnabled_test_5630(Notification p0) {
    NotificationFilterSupport instance = new NotificationFilterSupport();
    instance.isNotificationEnabled(p0);
  }
}
