package generated.test;

import java.awt.Component;
import javax.swing.JComponent;
import javax.swing.plaf.synth.Region;
import javax.swing.plaf.synth.SynthLookAndFeel;
import javax.swing.plaf.synth.SynthStyleFactory;
import org.junit.jupiter.api.Test;

public class SynthLookAndFeelAutoTest {
  @Test
  public void getDefaults_test_9800() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.getDefaults();
  }

  @Test
  public void isNativeLookAndFeel_test_9801() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.isNativeLookAndFeel();
  }

  @Test
  public void getDescription_test_9802() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.getDescription();
  }

  @Test
  public void setStyleFactory_test_9803(SynthStyleFactory p0) {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.setStyleFactory(p0);
  }

  @Test
  public void shouldUpdateStyleOnAncestorChanged_test_9804() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.shouldUpdateStyleOnAncestorChanged();
  }

  @Test
  public void getStyleFactory_test_9805() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.getStyleFactory();
  }

  @Test
  public void updateStyles_test_9806(Component p0) {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.updateStyles(p0);
  }

  @Test
  public void createUI_test_9807(JComponent p0) {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.createUI(p0);
  }

  @Test
  public void isSupportedLookAndFeel_test_9808() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.isSupportedLookAndFeel();
  }

  @Test
  public void uninitialize_test_9809() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.uninitialize();
  }

  @Test
  public void getStyle_test_9810(JComponent p0, Region p1) {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.getStyle(p0, p1);
  }

  @Test
  public void getName_test_9811() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.getName();
  }

  @Test
  public void initialize_test_9812() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.initialize();
  }

  @Test
  public void getID_test_9813() {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    instance.getID();
  }

  @Test
  public void getRegion_test_9814(JComponent p0) {
    SynthLookAndFeel instance = new SynthLookAndFeel();
    SynthLookAndFeel.getRegion(p0);
  }
}
