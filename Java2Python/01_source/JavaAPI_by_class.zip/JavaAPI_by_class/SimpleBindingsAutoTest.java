package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.script.SimpleBindings;
import org.junit.jupiter.api.Test;

public class SimpleBindingsAutoTest {
  @Test
  public void remove_test_6276(Object p0) {
    SimpleBindings instance = new SimpleBindings();
    instance.remove(p0);
  }

  @Test
  public void size_test_6277() {
    SimpleBindings instance = new SimpleBindings();
    instance.size();
  }

  @Test
  public void get_test_6278(Object p0) {
    SimpleBindings instance = new SimpleBindings();
    instance.get(p0);
  }

  @Test
  public void put_test_6279(String p0, Object p1) {
    SimpleBindings instance = new SimpleBindings();
    instance.put(p0, p1);
  }

  @Test
  public void values_test_6280() {
    SimpleBindings instance = new SimpleBindings();
    instance.values();
  }

  @Test
  public void clear_test_6281() {
    SimpleBindings instance = new SimpleBindings();
    instance.clear();
  }

  @Test
  public void isEmpty_test_6282() {
    SimpleBindings instance = new SimpleBindings();
    instance.isEmpty();
  }

  @Test
  public void entrySet_test_6283() {
    SimpleBindings instance = new SimpleBindings();
    instance.entrySet();
  }

  @Test
  public void putAll_test_6284(Map p0) {
    SimpleBindings instance = new SimpleBindings();
    instance.putAll(p0);
  }

  @Test
  public void keySet_test_6285() {
    SimpleBindings instance = new SimpleBindings();
    instance.keySet();
  }

  @Test
  public void containsValue_test_6286(Object p0) {
    SimpleBindings instance = new SimpleBindings();
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_6287(Object p0) {
    SimpleBindings instance = new SimpleBindings();
    instance.containsKey(p0);
  }
}
