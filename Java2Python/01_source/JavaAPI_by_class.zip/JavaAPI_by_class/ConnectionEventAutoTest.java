package generated.test;

import javax.sql.ConnectionEvent;
import javax.sql.PooledConnection;
import org.junit.jupiter.api.Test;

public class ConnectionEventAutoTest {
  @Test
  public void getSQLException_test_6523(PooledConnection c0) {
    ConnectionEvent instance = new ConnectionEvent(c0);
    instance.getSQLException();
  }
}
