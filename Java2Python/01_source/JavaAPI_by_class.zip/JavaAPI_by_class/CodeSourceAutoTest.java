package generated.test;

import java.lang.Object;
import java.net.URL;
import java.security.CodeSource;
import java.security.cert.Certificate;
import org.junit.jupiter.api.Test;

public class CodeSourceAutoTest {
  @Test
  public void equals_test_2689(Object p0, URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2690(URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.toString();
  }

  @Test
  public void hashCode_test_2691(URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.hashCode();
  }

  @Test
  public void getLocation_test_2692(URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.getLocation();
  }

  @Test
  public void getCertificates_test_2693(URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.getCertificates();
  }

  @Test
  public void implies_test_2694(CodeSource p0, URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.implies(p0);
  }

  @Test
  public void getCodeSigners_test_2695(URL c0, Certificate[] c1) {
    CodeSource instance = new CodeSource(c0, c1);
    instance.getCodeSigners();
  }
}
