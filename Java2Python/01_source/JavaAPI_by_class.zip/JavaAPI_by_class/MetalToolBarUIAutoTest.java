package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalToolBarUI;
import org.junit.jupiter.api.Test;

public class MetalToolBarUIAutoTest {
  @Test
  public void installUI_test_9278(JComponent p0) {
    MetalToolBarUI instance = new MetalToolBarUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9279(JComponent p0) {
    MetalToolBarUI instance = new MetalToolBarUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_9280(JComponent p0) {
    MetalToolBarUI instance = new MetalToolBarUI();
    MetalToolBarUI.createUI(p0);
  }

  @Test
  public void update_test_9281(Graphics p0, JComponent p1) {
    MetalToolBarUI instance = new MetalToolBarUI();
    instance.update(p0, p1);
  }
}
