package generated.test;

import java.util.concurrent.Phaser;
import org.junit.jupiter.api.Test;

public class PhaserAutoTest {
  @Test
  public void getPhase_test_4600() {
    Phaser instance = new Phaser();
    instance.getPhase();
  }

  @Test
  public void arriveAndAwaitAdvance_test_4601() {
    Phaser instance = new Phaser();
    instance.arriveAndAwaitAdvance();
  }

  @Test
  public void bulkRegister_test_4602(int p0) {
    Phaser instance = new Phaser();
    instance.bulkRegister(p0);
  }

  @Test
  public void arrive_test_4603() {
    Phaser instance = new Phaser();
    instance.arrive();
  }

  @Test
  public void arriveAndDeregister_test_4604() {
    Phaser instance = new Phaser();
    instance.arriveAndDeregister();
  }

  @Test
  public void awaitAdvance_test_4605(int p0) {
    Phaser instance = new Phaser();
    instance.awaitAdvance(p0);
  }

  @Test
  public void forceTermination_test_4606() {
    Phaser instance = new Phaser();
    instance.forceTermination();
  }

  @Test
  public void getRegisteredParties_test_4607() {
    Phaser instance = new Phaser();
    instance.getRegisteredParties();
  }

  @Test
  public void getArrivedParties_test_4608() {
    Phaser instance = new Phaser();
    instance.getArrivedParties();
  }

  @Test
  public void getUnarrivedParties_test_4609() {
    Phaser instance = new Phaser();
    instance.getUnarrivedParties();
  }

  @Test
  public void toString_test_4610() {
    Phaser instance = new Phaser();
    instance.toString();
  }

  @Test
  public void register_test_4611() {
    Phaser instance = new Phaser();
    instance.register();
  }

  @Test
  public void getParent_test_4612() {
    Phaser instance = new Phaser();
    instance.getParent();
  }

  @Test
  public void isTerminated_test_4613() {
    Phaser instance = new Phaser();
    instance.isTerminated();
  }

  @Test
  public void getRoot_test_4614() {
    Phaser instance = new Phaser();
    instance.getRoot();
  }
}
