package generated.test;

import java.lang.Object;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;
import org.junit.jupiter.api.Test;

public class AtomicReferenceArrayAutoTest {
  @Test
  public void get_test_4913(int p0, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.get(p0);
  }

  @Test
  public void length_test_4914(int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.length();
  }

  @Test
  public void toString_test_4915(int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.toString();
  }

  @Test
  public void set_test_4916(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.set(p0, p1);
  }

  @Test
  public void getOpaque_test_4917(int p0, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getOpaque(p0);
  }

  @Test
  public void setOpaque_test_4918(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.setOpaque(p0, p1);
  }

  @Test
  public void getAcquire_test_4919(int p0, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getAcquire(p0);
  }

  @Test
  public void setRelease_test_4920(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.setRelease(p0, p1);
  }

  @Test
  public void compareAndSet_test_4921(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.compareAndSet(p0, p1, p2);
  }

  @Test
  public void compareAndExchange_test_4922(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.compareAndExchange(p0, p1, p2);
  }

  @Test
  public void compareAndExchangeAcquire_test_4923(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.compareAndExchangeAcquire(p0, p1, p2);
  }

  @Test
  public void compareAndExchangeRelease_test_4924(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.compareAndExchangeRelease(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetPlain_test_4925(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.weakCompareAndSetPlain(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSet_test_4926(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.weakCompareAndSet(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetAcquire_test_4927(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.weakCompareAndSetAcquire(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetRelease_test_4928(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.weakCompareAndSetRelease(p0, p1, p2);
  }

  @Test
  public void getAndSet_test_4929(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getAndSet(p0, p1);
  }

  @Test
  public void weakCompareAndSetVolatile_test_4930(int p0, Object p1, Object p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.weakCompareAndSetVolatile(p0, p1, p2);
  }

  @Test
  public void lazySet_test_4931(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.lazySet(p0, p1);
  }

  @Test
  public void getAndUpdate_test_4932(int p0, UnaryOperator p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getAndUpdate(p0, p1);
  }

  @Test
  public void updateAndGet_test_4933(int p0, UnaryOperator p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.updateAndGet(p0, p1);
  }

  @Test
  public void getAndAccumulate_test_4934(int p0, Object p1, BinaryOperator p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getAndAccumulate(p0, p1, p2);
  }

  @Test
  public void accumulateAndGet_test_4935(int p0, Object p1, BinaryOperator p2, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.accumulateAndGet(p0, p1, p2);
  }

  @Test
  public void getPlain_test_4936(int p0, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.getPlain(p0);
  }

  @Test
  public void setPlain_test_4937(int p0, Object p1, int c0) {
    AtomicReferenceArray instance = new AtomicReferenceArray(c0);
    instance.setPlain(p0, p1);
  }
}
