package generated.test;

import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.XECPrivateKeySpec;
import org.junit.jupiter.api.Test;

public class XECPrivateKeySpecAutoTest {
  @Test
  public void getParams_test_2933(AlgorithmParameterSpec c0, byte[] c1) {
    XECPrivateKeySpec instance = new XECPrivateKeySpec(c0, c1);
    instance.getParams();
  }

  @Test
  public void getScalar_test_2934(AlgorithmParameterSpec c0, byte[] c1) {
    XECPrivateKeySpec instance = new XECPrivateKeySpec(c0, c1);
    instance.getScalar();
  }
}
