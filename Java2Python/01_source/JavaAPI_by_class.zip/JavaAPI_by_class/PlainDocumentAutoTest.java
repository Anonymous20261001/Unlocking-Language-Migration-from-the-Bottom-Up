package generated.test;

import javax.swing.text.PlainDocument;
import org.junit.jupiter.api.Test;

public class PlainDocumentAutoTest {
  @Test
  public void getDefaultRootElement_test_10330() {
    PlainDocument instance = new PlainDocument();
    instance.getDefaultRootElement();
  }

  @Test
  public void getParagraphElement_test_10331(int p0) {
    PlainDocument instance = new PlainDocument();
    instance.getParagraphElement(p0);
  }
}
