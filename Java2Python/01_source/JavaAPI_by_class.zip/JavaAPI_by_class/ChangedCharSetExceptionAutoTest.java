package generated.test;

import java.lang.String;
import javax.swing.text.ChangedCharSetException;
import org.junit.jupiter.api.Test;

public class ChangedCharSetExceptionAutoTest {
  @Test
  public void getCharSetSpec_test_10146(String c0, boolean c1) {
    ChangedCharSetException instance = new ChangedCharSetException(c0, c1);
    instance.getCharSetSpec();
  }

  @Test
  public void keyEqualsCharSet_test_10147(String c0, boolean c1) {
    ChangedCharSetException instance = new ChangedCharSetException(c0, c1);
    instance.keyEqualsCharSet();
  }
}
