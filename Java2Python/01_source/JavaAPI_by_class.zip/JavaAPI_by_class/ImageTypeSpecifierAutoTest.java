package generated.test;

import java.awt.color.ColorSpace;
import java.awt.image.RenderedImage;
import java.lang.Object;
import javax.imageio.ImageTypeSpecifier;
import org.junit.jupiter.api.Test;

public class ImageTypeSpecifierAutoTest {
  @Test
  public void createFromRenderedImage_test_5299(RenderedImage p0, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createFromRenderedImage(p0);
  }

  @Test
  public void createBufferedImage_test_5300(int p0, int p1, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.createBufferedImage(p0, p1);
  }

  @Test
  public void createPacked_test_5301(ColorSpace p0, int p1, int p2, int p3, int p4, int p5,
      boolean p6, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createPacked(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void createInterleaved_test_5302(ColorSpace p0, int[] p1, int p2, boolean p3, boolean p4,
      RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createInterleaved(p0, p1, p2, p3, p4);
  }

  @Test
  public void createGrayscale_test_5303(int p0, int p1, boolean p2, boolean p3, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createGrayscale(p0, p1, p2, p3);
  }

  @Test
  public void createGrayscale_test_5304(int p0, int p1, boolean p2, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createGrayscale(p0, p1, p2);
  }

  @Test
  public void createIndexed_test_5305(byte[] p0, byte[] p1, byte[] p2, byte[] p3, int p4, int p5,
      RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createIndexed(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createBanded_test_5306(ColorSpace p0, int[] p1, int[] p2, int p3, boolean p4,
      boolean p5, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createBanded(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createFromBufferedImageType_test_5307(int p0, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    ImageTypeSpecifier.createFromBufferedImageType(p0);
  }

  @Test
  public void getBufferedImageType_test_5308(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getBufferedImageType();
  }

  @Test
  public void getBitsPerBand_test_5309(int p0, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getBitsPerBand(p0);
  }

  @Test
  public void getNumBands_test_5310(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getNumBands();
  }

  @Test
  public void getColorModel_test_5311(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getColorModel();
  }

  @Test
  public void getNumComponents_test_5312(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getNumComponents();
  }

  @Test
  public void getSampleModel_test_5313(int p0, int p1, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getSampleModel(p0, p1);
  }

  @Test
  public void getSampleModel_test_5314(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.getSampleModel();
  }

  @Test
  public void equals_test_5315(Object p0, RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5316(RenderedImage c0) {
    ImageTypeSpecifier instance = new ImageTypeSpecifier(c0);
    instance.hashCode();
  }
}
