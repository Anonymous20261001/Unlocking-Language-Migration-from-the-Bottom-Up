package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalSliderUI;
import org.junit.jupiter.api.Test;

public class MetalSliderUIAutoTest {
  @Test
  public void paintThumb_test_9262(Graphics p0) {
    MetalSliderUI instance = new MetalSliderUI();
    instance.paintThumb(p0);
  }

  @Test
  public void installUI_test_9263(JComponent p0) {
    MetalSliderUI instance = new MetalSliderUI();
    instance.installUI(p0);
  }

  @Test
  public void paintTrack_test_9264(Graphics p0) {
    MetalSliderUI instance = new MetalSliderUI();
    instance.paintTrack(p0);
  }

  @Test
  public void getTickLength_test_9265() {
    MetalSliderUI instance = new MetalSliderUI();
    instance.getTickLength();
  }

  @Test
  public void paintFocus_test_9266(Graphics p0) {
    MetalSliderUI instance = new MetalSliderUI();
    instance.paintFocus(p0);
  }

  @Test
  public void createUI_test_9267(JComponent p0) {
    MetalSliderUI instance = new MetalSliderUI();
    MetalSliderUI.createUI(p0);
  }
}
