package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.NumberOfInterveningJobs;
import org.junit.jupiter.api.Test;

public class NumberOfInterveningJobsAutoTest {
  @Test
  public void getCategory_test_6189(int c0) {
    NumberOfInterveningJobs instance = new NumberOfInterveningJobs(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6190(int c0) {
    NumberOfInterveningJobs instance = new NumberOfInterveningJobs(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6191(Object p0, int c0) {
    NumberOfInterveningJobs instance = new NumberOfInterveningJobs(c0);
    instance.equals(p0);
  }
}
