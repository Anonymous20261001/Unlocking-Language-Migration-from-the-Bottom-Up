package generated.test;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.TargetDataLine;
import org.junit.jupiter.api.Test;

public class AudioInputStreamAutoTest {
  @Test
  public void getFrameLength_test_6515(TargetDataLine c0) {
    AudioInputStream instance = new AudioInputStream(c0);
    instance.getFrameLength();
  }

  @Test
  public void mark_test_6516(int p0, TargetDataLine c0) {
    AudioInputStream instance = new AudioInputStream(c0);
    instance.mark(p0);
  }

  @Test
  public void markSupported_test_6517(TargetDataLine c0) {
    AudioInputStream instance = new AudioInputStream(c0);
    instance.markSupported();
  }

  @Test
  public void getFormat_test_6518(TargetDataLine c0) {
    AudioInputStream instance = new AudioInputStream(c0);
    instance.getFormat();
  }
}
