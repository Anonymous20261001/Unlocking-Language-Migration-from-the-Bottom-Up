package generated.test;

import java.lang.Object;
import javax.swing.event.ListSelectionEvent;
import org.junit.jupiter.api.Test;

public class ListSelectionEventAutoTest {
  @Test
  public void getFirstIndex_test_8541(Object c0, int c1, int c2, boolean c3) {
    ListSelectionEvent instance = new ListSelectionEvent(c0, c1, c2, c3);
    instance.getFirstIndex();
  }

  @Test
  public void getLastIndex_test_8542(Object c0, int c1, int c2, boolean c3) {
    ListSelectionEvent instance = new ListSelectionEvent(c0, c1, c2, c3);
    instance.getLastIndex();
  }

  @Test
  public void getValueIsAdjusting_test_8543(Object c0, int c1, int c2, boolean c3) {
    ListSelectionEvent instance = new ListSelectionEvent(c0, c1, c2, c3);
    instance.getValueIsAdjusting();
  }

  @Test
  public void toString_test_8544(Object c0, int c1, int c2, boolean c3) {
    ListSelectionEvent instance = new ListSelectionEvent(c0, c1, c2, c3);
    instance.toString();
  }
}
