package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.accessibility.AccessibleRelation;
import org.junit.jupiter.api.Test;

public class AccessibleRelationAutoTest {
  @Test
  public void getKey_test_5212(String c0) {
    AccessibleRelation instance = new AccessibleRelation(c0);
    instance.getKey();
  }

  @Test
  public void getTarget_test_5213(String c0) {
    AccessibleRelation instance = new AccessibleRelation(c0);
    instance.getTarget();
  }

  @Test
  public void setTarget_test_5214(Object p0, String c0) {
    AccessibleRelation instance = new AccessibleRelation(c0);
    instance.setTarget(p0);
  }

  @Test
  public void setTarget_test_5215(Object[] p0, String c0) {
    AccessibleRelation instance = new AccessibleRelation(c0);
    instance.setTarget(p0);
  }
}
