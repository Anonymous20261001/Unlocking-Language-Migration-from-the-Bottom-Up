package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthScrollPaneUI;
import org.junit.jupiter.api.Test;

public class SynthScrollPaneUIAutoTest {
  @Test
  public void propertyChange_test_9885(PropertyChangeEvent p0) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9886(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9887(JComponent p0) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    SynthScrollPaneUI.createUI(p0);
  }

  @Test
  public void paint_test_9888(Graphics p0, JComponent p1) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void update_test_9889(Graphics p0, JComponent p1) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9890(JComponent p0) {
    SynthScrollPaneUI instance = new SynthScrollPaneUI();
    instance.getContext(p0);
  }
}
