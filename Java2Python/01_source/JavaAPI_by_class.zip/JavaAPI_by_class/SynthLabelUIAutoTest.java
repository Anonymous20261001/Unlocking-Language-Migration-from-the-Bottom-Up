package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthLabelUI;
import org.junit.jupiter.api.Test;

public class SynthLabelUIAutoTest {
  @Test
  public void propertyChange_test_9785(PropertyChangeEvent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9786(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9787(JComponent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    SynthLabelUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9788(JComponent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9789(Graphics p0, JComponent p1) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9790(JComponent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9791(JComponent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getBaseline_test_9792(JComponent p0, int p1, int p2) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void update_test_9793(Graphics p0, JComponent p1) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9794(JComponent p0) {
    SynthLabelUI instance = new SynthLabelUI();
    instance.getContext(p0);
  }
}
