package generated.test;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.MemoryHandler;
import org.junit.jupiter.api.Test;

public class MemoryHandlerAutoTest {
  @Test
  public void setPushLevel_test_5095(Level p0) {
    MemoryHandler instance = new MemoryHandler();
    instance.setPushLevel(p0);
  }

  @Test
  public void getPushLevel_test_5096() {
    MemoryHandler instance = new MemoryHandler();
    instance.getPushLevel();
  }

  @Test
  public void flush_test_5097() {
    MemoryHandler instance = new MemoryHandler();
    instance.flush();
  }

  @Test
  public void close_test_5098() {
    MemoryHandler instance = new MemoryHandler();
    instance.close();
  }

  @Test
  public void publish_test_5099(LogRecord p0) {
    MemoryHandler instance = new MemoryHandler();
    instance.publish(p0);
  }

  @Test
  public void push_test_5100() {
    MemoryHandler instance = new MemoryHandler();
    instance.push();
  }

  @Test
  public void isLoggable_test_5101(LogRecord p0) {
    MemoryHandler instance = new MemoryHandler();
    instance.isLoggable(p0);
  }
}
