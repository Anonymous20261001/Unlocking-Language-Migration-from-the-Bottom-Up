package generated.test;

import java.beans.PropertyChangeEvent;
import java.beans.beancontext.BeanContextChild;
import java.beans.beancontext.BeanContextMembershipListener;
import java.beans.beancontext.BeanContextSupport;
import java.lang.Object;
import java.lang.String;
import java.util.Collection;
import org.junit.jupiter.api.Test;

public class BeanContextSupportAutoTest {
  @Test
  public void isDesignTime_test_1665() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.isDesignTime();
  }

  @Test
  public void setDesignTime_test_1666(boolean p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.setDesignTime(p0);
  }

  @Test
  public void propertyChange_test_1667(PropertyChangeEvent p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.propertyChange(p0);
  }

  @Test
  public void addBeanContextMembershipListener_test_1668(BeanContextMembershipListener p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.addBeanContextMembershipListener(p0);
  }

  @Test
  public void removeBeanContextMembershipListener_test_1669(BeanContextMembershipListener p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.removeBeanContextMembershipListener(p0);
  }

  @Test
  public void needsGui_test_1670() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.needsGui();
  }

  @Test
  public void dontUseGui_test_1671() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.dontUseGui();
  }

  @Test
  public void okToUseGui_test_1672() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.okToUseGui();
  }

  @Test
  public void avoidingGui_test_1673() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.avoidingGui();
  }

  @Test
  public void getBeanContextPeer_test_1674() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.getBeanContextPeer();
  }

  @Test
  public void isSerializing_test_1675() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.isSerializing();
  }

  @Test
  public void remove_test_1676(Object p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.remove(p0);
  }

  @Test
  public void size_test_1677() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.size();
  }

  @Test
  public void clear_test_1678() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.clear();
  }

  @Test
  public void isEmpty_test_1679() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.isEmpty();
  }

  @Test
  public void add_test_1680(Object p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.add(p0);
  }

  @Test
  public void toArray_test_1681() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.toArray();
  }

  @Test
  public void toArray_test_1682(Object[] p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.toArray(p0);
  }

  @Test
  public void iterator_test_1683() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.iterator();
  }

  @Test
  public void contains_test_1684(Object p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.contains(p0);
  }

  @Test
  public void getResourceAsStream_test_1685(String p0, BeanContextChild p1) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.getResourceAsStream(p0, p1);
  }

  @Test
  public void getResource_test_1686(String p0, BeanContextChild p1) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.getResource(p0, p1);
  }

  @Test
  public void addAll_test_1687(Collection p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.addAll(p0);
  }

  @Test
  public void containsKey_test_1688(Object p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.containsKey(p0);
  }

  @Test
  public void removeAll_test_1689(Collection p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_1690(Collection p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.retainAll(p0);
  }

  @Test
  public void containsAll_test_1691(Collection p0) {
    BeanContextSupport instance = new BeanContextSupport();
    instance.containsAll(p0);
  }

  @Test
  public void getLocale_test_1692() {
    BeanContextSupport instance = new BeanContextSupport();
    instance.getLocale();
  }
}
