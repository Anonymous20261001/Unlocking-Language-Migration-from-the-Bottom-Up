package generated.test;

import java.awt.AWTEvent;
import java.awt.EventQueue;
import java.lang.Runnable;
import org.junit.jupiter.api.Test;

public class EventQueueAutoTest {
  @Test
  public void postEvent_test_218(AWTEvent p0) {
    EventQueue instance = new EventQueue();
    instance.postEvent(p0);
  }

  @Test
  public void isDispatchThread_test_219() {
    EventQueue instance = new EventQueue();
    EventQueue.isDispatchThread();
  }

  @Test
  public void invokeLater_test_220(Runnable p0) {
    EventQueue instance = new EventQueue();
    EventQueue.invokeLater(p0);
  }

  @Test
  public void getCurrentEvent_test_221() {
    EventQueue instance = new EventQueue();
    EventQueue.getCurrentEvent();
  }

  @Test
  public void createSecondaryLoop_test_222() {
    EventQueue instance = new EventQueue();
    instance.createSecondaryLoop();
  }

  @Test
  public void peekEvent_test_223() {
    EventQueue instance = new EventQueue();
    instance.peekEvent();
  }

  @Test
  public void peekEvent_test_224(int p0) {
    EventQueue instance = new EventQueue();
    instance.peekEvent(p0);
  }

  @Test
  public void getMostRecentEventTime_test_225() {
    EventQueue instance = new EventQueue();
    EventQueue.getMostRecentEventTime();
  }

  @Test
  public void push_test_226(EventQueue p0) {
    EventQueue instance = new EventQueue();
    instance.push(p0);
  }
}
