package generated.test;

import java.awt.image.ShortLookupTable;
import org.junit.jupiter.api.Test;

public class ShortLookupTableAutoTest {
  @Test
  public void lookupPixel_test_1389(short[] p0, short[] p1, int c0, short[][] c1) {
    ShortLookupTable instance = new ShortLookupTable(c0, c1);
    instance.lookupPixel(p0, p1);
  }

  @Test
  public void lookupPixel_test_1390(int[] p0, int[] p1, int c0, short[][] c1) {
    ShortLookupTable instance = new ShortLookupTable(c0, c1);
    instance.lookupPixel(p0, p1);
  }

  @Test
  public void getTable_test_1391(int c0, short[][] c1) {
    ShortLookupTable instance = new ShortLookupTable(c0, c1);
    instance.getTable();
  }
}
