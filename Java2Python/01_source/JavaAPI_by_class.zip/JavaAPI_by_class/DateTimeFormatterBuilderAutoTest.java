package generated.test;

import java.lang.String;
import java.time.chrono.ChronoLocalDate;
import java.time.chrono.Chronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.FormatStyle;
import java.time.format.SignStyle;
import java.time.format.TextStyle;
import java.time.temporal.TemporalField;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class DateTimeFormatterBuilderAutoTest {
  @Test
  public void append_test_3231(DateTimeFormatter p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.append(p0);
  }

  @Test
  public void parseStrict_test_3232() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.parseStrict();
  }

  @Test
  public void appendZoneText_test_3233(TextStyle p0, Set p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendZoneText(p0, p1);
  }

  @Test
  public void appendZoneText_test_3234(TextStyle p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendZoneText(p0);
  }

  @Test
  public void toFormatter_test_3235(Locale p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.toFormatter(p0);
  }

  @Test
  public void toFormatter_test_3236() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.toFormatter();
  }

  @Test
  public void appendChronologyText_test_3237(TextStyle p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendChronologyText(p0);
  }

  @Test
  public void appendPattern_test_3238(String p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendPattern(p0);
  }

  @Test
  public void appendLocalized_test_3239(String p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendLocalized(p0);
  }

  @Test
  public void appendLocalized_test_3240(FormatStyle p0, FormatStyle p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendLocalized(p0, p1);
  }

  @Test
  public void appendValue_test_3241(TemporalField p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendValue(p0);
  }

  @Test
  public void appendValue_test_3242(TemporalField p0, int p1, int p2, SignStyle p3) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendValue(p0, p1, p2, p3);
  }

  @Test
  public void appendValue_test_3243(TemporalField p0, int p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendValue(p0, p1);
  }

  @Test
  public void appendLiteral_test_3244(String p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendLiteral(p0);
  }

  @Test
  public void appendLiteral_test_3245(char p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendLiteral(p0);
  }

  @Test
  public void parseCaseInsensitive_test_3246() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.parseCaseInsensitive();
  }

  @Test
  public void appendOffsetId_test_3247() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendOffsetId();
  }

  @Test
  public void optionalStart_test_3248() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.optionalStart();
  }

  @Test
  public void appendFraction_test_3249(TemporalField p0, int p1, int p2, boolean p3) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendFraction(p0, p1, p2, p3);
  }

  @Test
  public void parseLenient_test_3250() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.parseLenient();
  }

  @Test
  public void parseCaseSensitive_test_3251() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.parseCaseSensitive();
  }

  @Test
  public void appendZoneRegionId_test_3252() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendZoneRegionId();
  }

  @Test
  public void appendInstant_test_3253() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendInstant();
  }

  @Test
  public void appendInstant_test_3254(int p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendInstant(p0);
  }

  @Test
  public void appendOffset_test_3255(String p0, String p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendOffset(p0, p1);
  }

  @Test
  public void appendText_test_3256(TemporalField p0, TextStyle p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendText(p0, p1);
  }

  @Test
  public void appendText_test_3257(TemporalField p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendText(p0);
  }

  @Test
  public void appendText_test_3258(TemporalField p0, Map p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendText(p0, p1);
  }

  @Test
  public void optionalEnd_test_3259() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.optionalEnd();
  }

  @Test
  public void padNext_test_3260(int p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.padNext(p0);
  }

  @Test
  public void padNext_test_3261(int p0, char p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.padNext(p0, p1);
  }

  @Test
  public void appendZoneId_test_3262() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendZoneId();
  }

  @Test
  public void appendGenericZoneText_test_3263(TextStyle p0, Set p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendGenericZoneText(p0, p1);
  }

  @Test
  public void appendGenericZoneText_test_3264(TextStyle p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendGenericZoneText(p0);
  }

  @Test
  public void appendLocalizedOffset_test_3265(TextStyle p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendLocalizedOffset(p0);
  }

  @Test
  public void appendDayPeriodText_test_3266(TextStyle p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendDayPeriodText(p0);
  }

  @Test
  public void appendValueReduced_test_3267(TemporalField p0, int p1, int p2, int p3) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendValueReduced(p0, p1, p2, p3);
  }

  @Test
  public void appendValueReduced_test_3268(TemporalField p0, int p1, int p2, ChronoLocalDate p3) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendValueReduced(p0, p1, p2, p3);
  }

  @Test
  public void getLocalizedDateTimePattern_test_3269(FormatStyle p0, FormatStyle p1, Chronology p2,
      Locale p3) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    DateTimeFormatterBuilder.getLocalizedDateTimePattern(p0, p1, p2, p3);
  }

  @Test
  public void getLocalizedDateTimePattern_test_3270(String p0, Chronology p1, Locale p2) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    DateTimeFormatterBuilder.getLocalizedDateTimePattern(p0, p1, p2);
  }

  @Test
  public void parseDefaulting_test_3271(TemporalField p0, long p1) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.parseDefaulting(p0, p1);
  }

  @Test
  public void appendZoneOrOffsetId_test_3272() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendZoneOrOffsetId();
  }

  @Test
  public void appendChronologyId_test_3273() {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendChronologyId();
  }

  @Test
  public void appendOptional_test_3274(DateTimeFormatter p0) {
    DateTimeFormatterBuilder instance = new DateTimeFormatterBuilder();
    instance.appendOptional(p0);
  }
}
