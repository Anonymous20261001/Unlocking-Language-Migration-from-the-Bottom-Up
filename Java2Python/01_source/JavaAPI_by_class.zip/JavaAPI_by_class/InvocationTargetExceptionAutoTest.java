package generated.test;

import java.lang.Throwable;
import java.lang.reflect.InvocationTargetException;
import org.junit.jupiter.api.Test;

public class InvocationTargetExceptionAutoTest {
  @Test
  public void getCause_test_2423(Throwable c0) {
    InvocationTargetException instance = new InvocationTargetException(c0);
    instance.getCause();
  }

  @Test
  public void getTargetException_test_2424(Throwable c0) {
    InvocationTargetException instance = new InvocationTargetException(c0);
    instance.getTargetException();
  }
}
