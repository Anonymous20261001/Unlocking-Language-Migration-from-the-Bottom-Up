package generated.test;

import java.lang.Object;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import org.junit.jupiter.api.Test;

public class WeakHashMapAutoTest {
  @Test
  public void remove_test_4067(Object p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.remove(p0);
  }

  @Test
  public void size_test_4068() {
    WeakHashMap instance = new WeakHashMap();
    instance.size();
  }

  @Test
  public void get_test_4069(Object p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.get(p0);
  }

  @Test
  public void put_test_4070(Object p0, Object p1) {
    WeakHashMap instance = new WeakHashMap();
    instance.put(p0, p1);
  }

  @Test
  public void values_test_4071() {
    WeakHashMap instance = new WeakHashMap();
    instance.values();
  }

  @Test
  public void clear_test_4072() {
    WeakHashMap instance = new WeakHashMap();
    instance.clear();
  }

  @Test
  public void isEmpty_test_4073() {
    WeakHashMap instance = new WeakHashMap();
    instance.isEmpty();
  }

  @Test
  public void replaceAll_test_4074(BiFunction p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.replaceAll(p0);
  }

  @Test
  public void entrySet_test_4075() {
    WeakHashMap instance = new WeakHashMap();
    instance.entrySet();
  }

  @Test
  public void putAll_test_4076(Map p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.putAll(p0);
  }

  @Test
  public void forEach_test_4077(BiConsumer p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.forEach(p0);
  }

  @Test
  public void keySet_test_4078() {
    WeakHashMap instance = new WeakHashMap();
    instance.keySet();
  }

  @Test
  public void containsValue_test_4079(Object p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_4080(Object p0) {
    WeakHashMap instance = new WeakHashMap();
    instance.containsKey(p0);
  }

  @Test
  public void newWeakHashMap_test_4081(int p0) {
    WeakHashMap instance = new WeakHashMap();
    WeakHashMap.newWeakHashMap(p0);
  }
}
