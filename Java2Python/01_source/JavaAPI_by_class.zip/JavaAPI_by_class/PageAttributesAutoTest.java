package generated.test;

import java.awt.PageAttributes;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class PageAttributesAutoTest {
  @Test
  public void getColor_test_415() {
    PageAttributes instance = new PageAttributes();
    instance.getColor();
  }

  @Test
  public void getMedia_test_416() {
    PageAttributes instance = new PageAttributes();
    instance.getMedia();
  }

  @Test
  public void setMediaToDefault_test_417() {
    PageAttributes instance = new PageAttributes();
    instance.setMediaToDefault();
  }

  @Test
  public void setOrientationRequestedToDefault_test_418() {
    PageAttributes instance = new PageAttributes();
    instance.setOrientationRequestedToDefault();
  }

  @Test
  public void setOrigin_test_419(PageAttributes.OriginType p0) {
    PageAttributes instance = new PageAttributes();
    instance.setOrigin(p0);
  }

  @Test
  public void setPrintQualityToDefault_test_420() {
    PageAttributes instance = new PageAttributes();
    instance.setPrintQualityToDefault();
  }

  @Test
  public void setPrinterResolutionToDefault_test_421() {
    PageAttributes instance = new PageAttributes();
    instance.setPrinterResolutionToDefault();
  }

  @Test
  public void setMedia_test_422(PageAttributes.MediaType p0) {
    PageAttributes instance = new PageAttributes();
    instance.setMedia(p0);
  }

  @Test
  public void setOrientationRequested_test_423(int p0) {
    PageAttributes instance = new PageAttributes();
    instance.setOrientationRequested(p0);
  }

  @Test
  public void setOrientationRequested_test_424(PageAttributes.OrientationRequestedType p0) {
    PageAttributes instance = new PageAttributes();
    instance.setOrientationRequested(p0);
  }

  @Test
  public void setPrintQuality_test_425(int p0) {
    PageAttributes instance = new PageAttributes();
    instance.setPrintQuality(p0);
  }

  @Test
  public void setPrintQuality_test_426(PageAttributes.PrintQualityType p0) {
    PageAttributes instance = new PageAttributes();
    instance.setPrintQuality(p0);
  }

  @Test
  public void setPrinterResolution_test_427(int[] p0) {
    PageAttributes instance = new PageAttributes();
    instance.setPrinterResolution(p0);
  }

  @Test
  public void setPrinterResolution_test_428(int p0) {
    PageAttributes instance = new PageAttributes();
    instance.setPrinterResolution(p0);
  }

  @Test
  public void getOrientationRequested_test_429() {
    PageAttributes instance = new PageAttributes();
    instance.getOrientationRequested();
  }

  @Test
  public void getOrigin_test_430() {
    PageAttributes instance = new PageAttributes();
    instance.getOrigin();
  }

  @Test
  public void getPrintQuality_test_431() {
    PageAttributes instance = new PageAttributes();
    instance.getPrintQuality();
  }

  @Test
  public void getPrinterResolution_test_432() {
    PageAttributes instance = new PageAttributes();
    instance.getPrinterResolution();
  }

  @Test
  public void equals_test_433(Object p0) {
    PageAttributes instance = new PageAttributes();
    instance.equals(p0);
  }

  @Test
  public void toString_test_434() {
    PageAttributes instance = new PageAttributes();
    instance.toString();
  }

  @Test
  public void hashCode_test_435() {
    PageAttributes instance = new PageAttributes();
    instance.hashCode();
  }

  @Test
  public void clone_test_436() {
    PageAttributes instance = new PageAttributes();
    instance.clone();
  }

  @Test
  public void set_test_437(PageAttributes p0) {
    PageAttributes instance = new PageAttributes();
    instance.set(p0);
  }

  @Test
  public void setColor_test_438(PageAttributes.ColorType p0) {
    PageAttributes instance = new PageAttributes();
    instance.setColor(p0);
  }
}
