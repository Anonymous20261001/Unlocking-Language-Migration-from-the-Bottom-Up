package generated.test;

import java.lang.Object;
import javax.naming.CompositeName;
import javax.naming.Name;
import org.junit.jupiter.api.Test;

public class CompositeNameAutoTest {
  @Test
  public void getSuffix_test_5889(int p0) {
    CompositeName instance = new CompositeName();
    instance.getSuffix(p0);
  }

  @Test
  public void getPrefix_test_5890(int p0) {
    CompositeName instance = new CompositeName();
    instance.getPrefix(p0);
  }

  @Test
  public void size_test_5891() {
    CompositeName instance = new CompositeName();
    instance.size();
  }

  @Test
  public void get_test_5892(int p0) {
    CompositeName instance = new CompositeName();
    instance.get(p0);
  }

  @Test
  public void equals_test_5893(Object p0) {
    CompositeName instance = new CompositeName();
    instance.equals(p0);
  }

  @Test
  public void toString_test_5894() {
    CompositeName instance = new CompositeName();
    instance.toString();
  }

  @Test
  public void hashCode_test_5895() {
    CompositeName instance = new CompositeName();
    instance.hashCode();
  }

  @Test
  public void clone_test_5896() {
    CompositeName instance = new CompositeName();
    instance.clone();
  }

  @Test
  public void compareTo_test_5897(Object p0) {
    CompositeName instance = new CompositeName();
    instance.compareTo(p0);
  }

  @Test
  public void startsWith_test_5898(Name p0) {
    CompositeName instance = new CompositeName();
    instance.startsWith(p0);
  }

  @Test
  public void isEmpty_test_5899() {
    CompositeName instance = new CompositeName();
    instance.isEmpty();
  }

  @Test
  public void endsWith_test_5900(Name p0) {
    CompositeName instance = new CompositeName();
    instance.endsWith(p0);
  }

  @Test
  public void getAll_test_5901() {
    CompositeName instance = new CompositeName();
    instance.getAll();
  }
}
