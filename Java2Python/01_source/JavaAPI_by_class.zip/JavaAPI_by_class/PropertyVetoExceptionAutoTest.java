package generated.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class PropertyVetoExceptionAutoTest {
  @Test
  public void getPropertyChangeEvent_test_1595(String c0, PropertyChangeEvent c1) {
    PropertyVetoException instance = new PropertyVetoException(c0, c1);
    instance.getPropertyChangeEvent();
  }
}
