package generated.test;

import java.io.InputStream;
import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.security.auth.x500.X500Principal;
import org.junit.jupiter.api.Test;

public class X500PrincipalAutoTest {
  @Test
  public void getName_test_6425(InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.getName();
  }

  @Test
  public void getName_test_6426(String p0, InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.getName(p0);
  }

  @Test
  public void getName_test_6427(String p0, Map p1, InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.getName(p0, p1);
  }

  @Test
  public void equals_test_6428(Object p0, InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6429(InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_6430(InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.hashCode();
  }

  @Test
  public void getEncoded_test_6431(InputStream c0) {
    X500Principal instance = new X500Principal(c0);
    instance.getEncoded();
  }
}
