package generated.test;

import java.io.File;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.String;
import javax.xml.transform.stream.StreamResult;
import org.junit.jupiter.api.Test;

public class StreamResultAutoTest {
  @Test
  public void getWriter_test_11001() {
    StreamResult instance = new StreamResult();
    instance.getWriter();
  }

  @Test
  public void getSystemId_test_11002() {
    StreamResult instance = new StreamResult();
    instance.getSystemId();
  }

  @Test
  public void setSystemId_test_11003(String p0) {
    StreamResult instance = new StreamResult();
    instance.setSystemId(p0);
  }

  @Test
  public void setSystemId_test_11004(File p0) {
    StreamResult instance = new StreamResult();
    instance.setSystemId(p0);
  }

  @Test
  public void setOutputStream_test_11005(OutputStream p0) {
    StreamResult instance = new StreamResult();
    instance.setOutputStream(p0);
  }

  @Test
  public void getOutputStream_test_11006() {
    StreamResult instance = new StreamResult();
    instance.getOutputStream();
  }

  @Test
  public void setWriter_test_11007(Writer p0) {
    StreamResult instance = new StreamResult();
    instance.setWriter(p0);
  }
}
