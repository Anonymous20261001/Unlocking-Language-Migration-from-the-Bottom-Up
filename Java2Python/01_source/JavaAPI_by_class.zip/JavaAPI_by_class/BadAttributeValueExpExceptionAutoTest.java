package generated.test;

import java.lang.Object;
import javax.management.BadAttributeValueExpException;
import org.junit.jupiter.api.Test;

public class BadAttributeValueExpExceptionAutoTest {
  @Test
  public void toString_test_5545(Object c0) {
    BadAttributeValueExpException instance = new BadAttributeValueExpException(c0);
    instance.toString();
  }
}
