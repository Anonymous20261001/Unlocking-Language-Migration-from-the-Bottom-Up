package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthToolTipUI;
import org.junit.jupiter.api.Test;

public class SynthToolTipUIAutoTest {
  @Test
  public void propertyChange_test_9957(PropertyChangeEvent p0) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.propertyChange(p0);
  }

  @Test
  public void paintBorder_test_9958(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createUI_test_9959(JComponent p0) {
    SynthToolTipUI instance = new SynthToolTipUI();
    SynthToolTipUI.createUI(p0);
  }

  @Test
  public void paint_test_9960(Graphics p0, JComponent p1) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9961(JComponent p0) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void update_test_9962(Graphics p0, JComponent p1) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.update(p0, p1);
  }

  @Test
  public void getContext_test_9963(JComponent p0) {
    SynthToolTipUI instance = new SynthToolTipUI();
    instance.getContext(p0);
  }
}
