package generated.test;

import java.lang.Object;
import java.util.EventObject;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTree;
import org.junit.jupiter.api.Test;

public class DefaultCellEditorAutoTest {
  @Test
  public void getCellEditorValue_test_6678(JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.getCellEditorValue();
  }

  @Test
  public void isCellEditable_test_6679(EventObject p0, JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.isCellEditable(p0);
  }

  @Test
  public void shouldSelectCell_test_6680(EventObject p0, JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.shouldSelectCell(p0);
  }

  @Test
  public void stopCellEditing_test_6681(JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.stopCellEditing();
  }

  @Test
  public void cancelCellEditing_test_6682(JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.cancelCellEditing();
  }

  @Test
  public void setClickCountToStart_test_6683(int p0, JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.setClickCountToStart(p0);
  }

  @Test
  public void getClickCountToStart_test_6684(JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.getClickCountToStart();
  }

  @Test
  public void getTreeCellEditorComponent_test_6685(JTree p0, Object p1, boolean p2, boolean p3,
      boolean p4, int p5, JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.getTreeCellEditorComponent(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getTableCellEditorComponent_test_6686(JTable p0, Object p1, boolean p2, int p3,
      int p4, JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.getTableCellEditorComponent(p0, p1, p2, p3, p4);
  }

  @Test
  public void getComponent_test_6687(JTextField c0) {
    DefaultCellEditor instance = new DefaultCellEditor(c0);
    instance.getComponent();
  }
}
