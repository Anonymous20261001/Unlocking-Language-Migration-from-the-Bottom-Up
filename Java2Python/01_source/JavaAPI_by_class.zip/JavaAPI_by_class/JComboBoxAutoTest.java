package generated.test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.lang.Object;
import java.lang.String;
import javax.swing.Action;
import javax.swing.ComboBoxEditor;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.ListCellRenderer;
import javax.swing.event.ListDataEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.plaf.ComboBoxUI;
import org.junit.jupiter.api.Test;

public class JComboBoxAutoTest {
  @Test
  public void getAction_test_6893() {
    JComboBox instance = new JComboBox();
    instance.getAction();
  }

  @Test
  public void getUIClassID_test_6894() {
    JComboBox instance = new JComboBox();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_6895() {
    JComboBox instance = new JComboBox();
    instance.getUI();
  }

  @Test
  public void setUI_test_6896(ComboBoxUI p0) {
    JComboBox instance = new JComboBox();
    instance.setUI(p0);
  }

  @Test
  public void getModel_test_6897() {
    JComboBox instance = new JComboBox();
    instance.getModel();
  }

  @Test
  public void setSelectedItem_test_6898(Object p0) {
    JComboBox instance = new JComboBox();
    instance.setSelectedItem(p0);
  }

  @Test
  public void contentsChanged_test_6899(ListDataEvent p0) {
    JComboBox instance = new JComboBox();
    instance.contentsChanged(p0);
  }

  @Test
  public void intervalAdded_test_6900(ListDataEvent p0) {
    JComboBox instance = new JComboBox();
    instance.intervalAdded(p0);
  }

  @Test
  public void intervalRemoved_test_6901(ListDataEvent p0) {
    JComboBox instance = new JComboBox();
    instance.intervalRemoved(p0);
  }

  @Test
  public void setAction_test_6902(Action p0) {
    JComboBox instance = new JComboBox();
    instance.setAction(p0);
  }

  @Test
  public void setModel_test_6903(ComboBoxModel p0) {
    JComboBox instance = new JComboBox();
    instance.setModel(p0);
  }

  @Test
  public void getRenderer_test_6904() {
    JComboBox instance = new JComboBox();
    instance.getRenderer();
  }

  @Test
  public void getEditor_test_6905() {
    JComboBox instance = new JComboBox();
    instance.getEditor();
  }

  @Test
  public void setPopupVisible_test_6906(boolean p0) {
    JComboBox instance = new JComboBox();
    instance.setPopupVisible(p0);
  }

  @Test
  public void isPopupVisible_test_6907() {
    JComboBox instance = new JComboBox();
    instance.isPopupVisible();
  }

  @Test
  public void hidePopup_test_6908() {
    JComboBox instance = new JComboBox();
    instance.hidePopup();
  }

  @Test
  public void setLightWeightPopupEnabled_test_6909(boolean p0) {
    JComboBox instance = new JComboBox();
    instance.setLightWeightPopupEnabled(p0);
  }

  @Test
  public void isLightWeightPopupEnabled_test_6910() {
    JComboBox instance = new JComboBox();
    instance.isLightWeightPopupEnabled();
  }

  @Test
  public void setMaximumRowCount_test_6911(int p0) {
    JComboBox instance = new JComboBox();
    instance.setMaximumRowCount(p0);
  }

  @Test
  public void getMaximumRowCount_test_6912() {
    JComboBox instance = new JComboBox();
    instance.getMaximumRowCount();
  }

  @Test
  public void setRenderer_test_6913(ListCellRenderer p0) {
    JComboBox instance = new JComboBox();
    instance.setRenderer(p0);
  }

  @Test
  public void setEditor_test_6914(ComboBoxEditor p0) {
    JComboBox instance = new JComboBox();
    instance.setEditor(p0);
  }

  @Test
  public void getPrototypeDisplayValue_test_6915() {
    JComboBox instance = new JComboBox();
    instance.getPrototypeDisplayValue();
  }

  @Test
  public void setPrototypeDisplayValue_test_6916(Object p0) {
    JComboBox instance = new JComboBox();
    instance.setPrototypeDisplayValue(p0);
  }

  @Test
  public void insertItemAt_test_6917(Object p0, int p1) {
    JComboBox instance = new JComboBox();
    instance.insertItemAt(p0, p1);
  }

  @Test
  public void removeItem_test_6918(Object p0) {
    JComboBox instance = new JComboBox();
    instance.removeItem(p0);
  }

  @Test
  public void removeItemAt_test_6919(int p0) {
    JComboBox instance = new JComboBox();
    instance.removeItemAt(p0);
  }

  @Test
  public void removeAllItems_test_6920() {
    JComboBox instance = new JComboBox();
    instance.removeAllItems();
  }

  @Test
  public void showPopup_test_6921() {
    JComboBox instance = new JComboBox();
    instance.showPopup();
  }

  @Test
  public void addPopupMenuListener_test_6922(PopupMenuListener p0) {
    JComboBox instance = new JComboBox();
    instance.addPopupMenuListener(p0);
  }

  @Test
  public void removePopupMenuListener_test_6923(PopupMenuListener p0) {
    JComboBox instance = new JComboBox();
    instance.removePopupMenuListener(p0);
  }

  @Test
  public void getPopupMenuListeners_test_6924() {
    JComboBox instance = new JComboBox();
    instance.getPopupMenuListeners();
  }

  @Test
  public void firePopupMenuWillBecomeVisible_test_6925() {
    JComboBox instance = new JComboBox();
    instance.firePopupMenuWillBecomeVisible();
  }

  @Test
  public void firePopupMenuWillBecomeInvisible_test_6926() {
    JComboBox instance = new JComboBox();
    instance.firePopupMenuWillBecomeInvisible();
  }

  @Test
  public void firePopupMenuCanceled_test_6927() {
    JComboBox instance = new JComboBox();
    instance.firePopupMenuCanceled();
  }

  @Test
  public void selectWithKeyChar_test_6928(char p0) {
    JComboBox instance = new JComboBox();
    instance.selectWithKeyChar(p0);
  }

  @Test
  public void configureEditor_test_6929(ComboBoxEditor p0, Object p1) {
    JComboBox instance = new JComboBox();
    instance.configureEditor(p0, p1);
  }

  @Test
  public void setKeySelectionManager_test_6930(JComboBox.KeySelectionManager p0) {
    JComboBox instance = new JComboBox();
    instance.setKeySelectionManager(p0);
  }

  @Test
  public void getKeySelectionManager_test_6931() {
    JComboBox instance = new JComboBox();
    instance.getKeySelectionManager();
  }

  @Test
  public void getItemAt_test_6932(int p0) {
    JComboBox instance = new JComboBox();
    instance.getItemAt(p0);
  }

  @Test
  public void setSelectedIndex_test_6933(int p0) {
    JComboBox instance = new JComboBox();
    instance.setSelectedIndex(p0);
  }

  @Test
  public void getAccessibleContext_test_6934() {
    JComboBox instance = new JComboBox();
    instance.getAccessibleContext();
  }

  @Test
  public void setEnabled_test_6935(boolean p0) {
    JComboBox instance = new JComboBox();
    instance.setEnabled(p0);
  }

  @Test
  public void processKeyEvent_test_6936(KeyEvent p0) {
    JComboBox instance = new JComboBox();
    instance.processKeyEvent(p0);
  }

  @Test
  public void actionPerformed_test_6937(ActionEvent p0) {
    JComboBox instance = new JComboBox();
    instance.actionPerformed(p0);
  }

  @Test
  public void addActionListener_test_6938(ActionListener p0) {
    JComboBox instance = new JComboBox();
    instance.addActionListener(p0);
  }

  @Test
  public void setActionCommand_test_6939(String p0) {
    JComboBox instance = new JComboBox();
    instance.setActionCommand(p0);
  }

  @Test
  public void getActionCommand_test_6940() {
    JComboBox instance = new JComboBox();
    instance.getActionCommand();
  }

  @Test
  public void removeActionListener_test_6941(ActionListener p0) {
    JComboBox instance = new JComboBox();
    instance.removeActionListener(p0);
  }

  @Test
  public void getActionListeners_test_6942() {
    JComboBox instance = new JComboBox();
    instance.getActionListeners();
  }

  @Test
  public void addItemListener_test_6943(ItemListener p0) {
    JComboBox instance = new JComboBox();
    instance.addItemListener(p0);
  }

  @Test
  public void getSelectedObjects_test_6944() {
    JComboBox instance = new JComboBox();
    instance.getSelectedObjects();
  }

  @Test
  public void removeItemListener_test_6945(ItemListener p0) {
    JComboBox instance = new JComboBox();
    instance.removeItemListener(p0);
  }

  @Test
  public void getItemListeners_test_6946() {
    JComboBox instance = new JComboBox();
    instance.getItemListeners();
  }

  @Test
  public void addItem_test_6947(Object p0) {
    JComboBox instance = new JComboBox();
    instance.addItem(p0);
  }

  @Test
  public void getSelectedItem_test_6948() {
    JComboBox instance = new JComboBox();
    instance.getSelectedItem();
  }

  @Test
  public void getItemCount_test_6949() {
    JComboBox instance = new JComboBox();
    instance.getItemCount();
  }

  @Test
  public void getSelectedIndex_test_6950() {
    JComboBox instance = new JComboBox();
    instance.getSelectedIndex();
  }

  @Test
  public void updateUI_test_6951() {
    JComboBox instance = new JComboBox();
    instance.updateUI();
  }

  @Test
  public void setEditable_test_6952(boolean p0) {
    JComboBox instance = new JComboBox();
    instance.setEditable(p0);
  }

  @Test
  public void isEditable_test_6953() {
    JComboBox instance = new JComboBox();
    instance.isEditable();
  }
}
