package generated.test;

import javax.crypto.spec.IvParameterSpec;
import org.junit.jupiter.api.Test;

public class IvParameterSpecAutoTest {
  @Test
  public void getIV_test_5249(byte[] c0) {
    IvParameterSpec instance = new IvParameterSpec(c0);
    instance.getIV();
  }
}
