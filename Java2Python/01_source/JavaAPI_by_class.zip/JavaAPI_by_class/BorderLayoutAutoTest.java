package generated.test;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class BorderLayoutAutoTest {
  @Test
  public void removeLayoutComponent_test_10(Component p0) {
    BorderLayout instance = new BorderLayout();
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_11(Component p0, Object p1) {
    BorderLayout instance = new BorderLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void addLayoutComponent_test_12(String p0, Component p1) {
    BorderLayout instance = new BorderLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_13(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.layoutContainer(p0);
  }

  @Test
  public void invalidateLayout_test_14(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.invalidateLayout(p0);
  }

  @Test
  public void preferredLayoutSize_test_15(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_16(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.minimumLayoutSize(p0);
  }

  @Test
  public void maximumLayoutSize_test_17(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.maximumLayoutSize(p0);
  }

  @Test
  public void getLayoutAlignmentX_test_18(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.getLayoutAlignmentX(p0);
  }

  @Test
  public void getLayoutAlignmentY_test_19(Container p0) {
    BorderLayout instance = new BorderLayout();
    instance.getLayoutAlignmentY(p0);
  }

  @Test
  public void getHgap_test_20() {
    BorderLayout instance = new BorderLayout();
    instance.getHgap();
  }

  @Test
  public void setHgap_test_21(int p0) {
    BorderLayout instance = new BorderLayout();
    instance.setHgap(p0);
  }

  @Test
  public void getVgap_test_22() {
    BorderLayout instance = new BorderLayout();
    instance.getVgap();
  }

  @Test
  public void setVgap_test_23(int p0) {
    BorderLayout instance = new BorderLayout();
    instance.setVgap(p0);
  }

  @Test
  public void getLayoutComponent_test_24(Container p0, Object p1) {
    BorderLayout instance = new BorderLayout();
    instance.getLayoutComponent(p0, p1);
  }

  @Test
  public void getLayoutComponent_test_25(Object p0) {
    BorderLayout instance = new BorderLayout();
    instance.getLayoutComponent(p0);
  }

  @Test
  public void getConstraints_test_26(Component p0) {
    BorderLayout instance = new BorderLayout();
    instance.getConstraints(p0);
  }

  @Test
  public void toString_test_27() {
    BorderLayout instance = new BorderLayout();
    instance.toString();
  }
}
