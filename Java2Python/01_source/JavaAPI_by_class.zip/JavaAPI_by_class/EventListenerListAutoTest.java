package generated.test;

import java.lang.Class;
import java.util.EventListener;
import javax.swing.event.EventListenerList;
import org.junit.jupiter.api.Test;

public class EventListenerListAutoTest {
  @Test
  public void getListenerList_test_8523() {
    EventListenerList instance = new EventListenerList();
    instance.getListenerList();
  }

  @Test
  public void getListeners_test_8524(Class p0) {
    EventListenerList instance = new EventListenerList();
    instance.getListeners(p0);
  }

  @Test
  public void getListenerCount_test_8525(Class p0) {
    EventListenerList instance = new EventListenerList();
    instance.getListenerCount(p0);
  }

  @Test
  public void getListenerCount_test_8526() {
    EventListenerList instance = new EventListenerList();
    instance.getListenerCount();
  }

  @Test
  public void remove_test_8527(Class p0, EventListener p1) {
    EventListenerList instance = new EventListenerList();
    instance.remove(p0, p1);
  }

  @Test
  public void toString_test_8528() {
    EventListenerList instance = new EventListenerList();
    instance.toString();
  }

  @Test
  public void add_test_8529(Class p0, EventListener p1) {
    EventListenerList instance = new EventListenerList();
    instance.add(p0, p1);
  }
}
