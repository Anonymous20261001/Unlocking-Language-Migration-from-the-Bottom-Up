package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobImpressionsCompleted;
import org.junit.jupiter.api.Test;

public class JobImpressionsCompletedAutoTest {
  @Test
  public void getCategory_test_6127(int c0) {
    JobImpressionsCompleted instance = new JobImpressionsCompleted(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6128(int c0) {
    JobImpressionsCompleted instance = new JobImpressionsCompleted(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6129(Object p0, int c0) {
    JobImpressionsCompleted instance = new JobImpressionsCompleted(c0);
    instance.equals(p0);
  }
}
