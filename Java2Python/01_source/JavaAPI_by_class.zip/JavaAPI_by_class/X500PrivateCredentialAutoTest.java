package generated.test;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import javax.security.auth.x500.X500PrivateCredential;
import org.junit.jupiter.api.Test;

public class X500PrivateCredentialAutoTest {
  @Test
  public void getPrivateKey_test_6432(X509Certificate c0, PrivateKey c1) {
    X500PrivateCredential instance = new X500PrivateCredential(c0, c1);
    instance.getPrivateKey();
  }

  @Test
  public void getAlias_test_6433(X509Certificate c0, PrivateKey c1) {
    X500PrivateCredential instance = new X500PrivateCredential(c0, c1);
    instance.getAlias();
  }

  @Test
  public void getCertificate_test_6434(X509Certificate c0, PrivateKey c1) {
    X500PrivateCredential instance = new X500PrivateCredential(c0, c1);
    instance.getCertificate();
  }

  @Test
  public void isDestroyed_test_6435(X509Certificate c0, PrivateKey c1) {
    X500PrivateCredential instance = new X500PrivateCredential(c0, c1);
    instance.isDestroyed();
  }

  @Test
  public void destroy_test_6436(X509Certificate c0, PrivateKey c1) {
    X500PrivateCredential instance = new X500PrivateCredential(c0, c1);
    instance.destroy();
  }
}
