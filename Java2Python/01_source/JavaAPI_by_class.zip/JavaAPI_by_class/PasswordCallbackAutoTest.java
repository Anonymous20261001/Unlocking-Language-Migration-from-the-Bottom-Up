package generated.test;

import java.lang.String;
import javax.security.auth.callback.PasswordCallback;
import org.junit.jupiter.api.Test;

public class PasswordCallbackAutoTest {
  @Test
  public void getPassword_test_6346(String c0, boolean c1) {
    PasswordCallback instance = new PasswordCallback(c0, c1);
    instance.getPassword();
  }

  @Test
  public void clearPassword_test_6347(String c0, boolean c1) {
    PasswordCallback instance = new PasswordCallback(c0, c1);
    instance.clearPassword();
  }

  @Test
  public void getPrompt_test_6348(String c0, boolean c1) {
    PasswordCallback instance = new PasswordCallback(c0, c1);
    instance.getPrompt();
  }

  @Test
  public void isEchoOn_test_6349(String c0, boolean c1) {
    PasswordCallback instance = new PasswordCallback(c0, c1);
    instance.isEchoOn();
  }

  @Test
  public void setPassword_test_6350(char[] p0, String c0, boolean c1) {
    PasswordCallback instance = new PasswordCallback(c0, c1);
    instance.setPassword(p0);
  }
}
