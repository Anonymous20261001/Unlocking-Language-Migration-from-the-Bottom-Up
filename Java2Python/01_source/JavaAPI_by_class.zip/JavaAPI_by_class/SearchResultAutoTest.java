package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;
import org.junit.jupiter.api.Test;

public class SearchResultAutoTest {
  @Test
  public void setAttributes_test_5996(Attributes p0, String c0, Object c1, Attributes c2) {
    SearchResult instance = new SearchResult(c0, c1, c2);
    instance.setAttributes(p0);
  }

  @Test
  public void toString_test_5997(String c0, Object c1, Attributes c2) {
    SearchResult instance = new SearchResult(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void getAttributes_test_5998(String c0, Object c1, Attributes c2) {
    SearchResult instance = new SearchResult(c0, c1, c2);
    instance.getAttributes();
  }
}
