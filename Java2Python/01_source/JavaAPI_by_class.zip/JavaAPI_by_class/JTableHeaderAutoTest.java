package generated.test;

import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelEvent;
import javax.swing.plaf.TableHeaderUI;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import org.junit.jupiter.api.Test;

public class JTableHeaderAutoTest {
  @Test
  public void setColumnModel_test_10041(TableColumnModel p0) {
    JTableHeader instance = new JTableHeader();
    instance.setColumnModel(p0);
  }

  @Test
  public void setTable_test_10042(JTable p0) {
    JTableHeader instance = new JTableHeader();
    instance.setTable(p0);
  }

  @Test
  public void resizeAndRepaint_test_10043() {
    JTableHeader instance = new JTableHeader();
    instance.resizeAndRepaint();
  }

  @Test
  public void getColumnModel_test_10044() {
    JTableHeader instance = new JTableHeader();
    instance.getColumnModel();
  }

  @Test
  public void setResizingColumn_test_10045(TableColumn p0) {
    JTableHeader instance = new JTableHeader();
    instance.setResizingColumn(p0);
  }

  @Test
  public void getDefaultRenderer_test_10046() {
    JTableHeader instance = new JTableHeader();
    instance.getDefaultRenderer();
  }

  @Test
  public void columnAtPoint_test_10047(Point p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnAtPoint(p0);
  }

  @Test
  public void getResizingColumn_test_10048() {
    JTableHeader instance = new JTableHeader();
    instance.getResizingColumn();
  }

  @Test
  public void setDefaultRenderer_test_10049(TableCellRenderer p0) {
    JTableHeader instance = new JTableHeader();
    instance.setDefaultRenderer(p0);
  }

  @Test
  public void columnAdded_test_10050(TableColumnModelEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnAdded(p0);
  }

  @Test
  public void columnRemoved_test_10051(TableColumnModelEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnRemoved(p0);
  }

  @Test
  public void columnMoved_test_10052(TableColumnModelEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnMoved(p0);
  }

  @Test
  public void columnMarginChanged_test_10053(ChangeEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnMarginChanged(p0);
  }

  @Test
  public void columnSelectionChanged_test_10054(ListSelectionEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.columnSelectionChanged(p0);
  }

  @Test
  public void getToolTipText_test_10055(MouseEvent p0) {
    JTableHeader instance = new JTableHeader();
    instance.getToolTipText(p0);
  }

  @Test
  public void getUIClassID_test_10056() {
    JTableHeader instance = new JTableHeader();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_10057() {
    JTableHeader instance = new JTableHeader();
    instance.getUI();
  }

  @Test
  public void setUI_test_10058(TableHeaderUI p0) {
    JTableHeader instance = new JTableHeader();
    instance.setUI(p0);
  }

  @Test
  public void getDraggedColumn_test_10059() {
    JTableHeader instance = new JTableHeader();
    instance.getDraggedColumn();
  }

  @Test
  public void getHeaderRect_test_10060(int p0) {
    JTableHeader instance = new JTableHeader();
    instance.getHeaderRect(p0);
  }

  @Test
  public void getResizingAllowed_test_10061() {
    JTableHeader instance = new JTableHeader();
    instance.getResizingAllowed();
  }

  @Test
  public void getDraggedDistance_test_10062() {
    JTableHeader instance = new JTableHeader();
    instance.getDraggedDistance();
  }

  @Test
  public void setReorderingAllowed_test_10063(boolean p0) {
    JTableHeader instance = new JTableHeader();
    instance.setReorderingAllowed(p0);
  }

  @Test
  public void getReorderingAllowed_test_10064() {
    JTableHeader instance = new JTableHeader();
    instance.getReorderingAllowed();
  }

  @Test
  public void setResizingAllowed_test_10065(boolean p0) {
    JTableHeader instance = new JTableHeader();
    instance.setResizingAllowed(p0);
  }

  @Test
  public void setUpdateTableInRealTime_test_10066(boolean p0) {
    JTableHeader instance = new JTableHeader();
    instance.setUpdateTableInRealTime(p0);
  }

  @Test
  public void getUpdateTableInRealTime_test_10067() {
    JTableHeader instance = new JTableHeader();
    instance.getUpdateTableInRealTime();
  }

  @Test
  public void setDraggedColumn_test_10068(TableColumn p0) {
    JTableHeader instance = new JTableHeader();
    instance.setDraggedColumn(p0);
  }

  @Test
  public void setDraggedDistance_test_10069(int p0) {
    JTableHeader instance = new JTableHeader();
    instance.setDraggedDistance(p0);
  }

  @Test
  public void getAccessibleContext_test_10070() {
    JTableHeader instance = new JTableHeader();
    instance.getAccessibleContext();
  }

  @Test
  public void getPreferredSize_test_10071() {
    JTableHeader instance = new JTableHeader();
    instance.getPreferredSize();
  }

  @Test
  public void updateUI_test_10072() {
    JTableHeader instance = new JTableHeader();
    instance.updateUI();
  }

  @Test
  public void getTable_test_10073() {
    JTableHeader instance = new JTableHeader();
    instance.getTable();
  }
}
