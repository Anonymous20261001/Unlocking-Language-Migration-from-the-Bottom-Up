package generated.test;

import java.awt.image.ColorModel;
import java.awt.image.ImageConsumer;
import java.awt.image.MemoryImageSource;
import org.junit.jupiter.api.Test;

public class MemoryImageSourceAutoTest {
  @Test
  public void addConsumer_test_1324(ImageConsumer p0, int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.addConsumer(p0);
  }

  @Test
  public void removeConsumer_test_1325(ImageConsumer p0, int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.removeConsumer(p0);
  }

  @Test
  public void startProduction_test_1326(ImageConsumer p0, int c0, int c1, int[] c2, int c3,
      int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.startProduction(p0);
  }

  @Test
  public void isConsumer_test_1327(ImageConsumer p0, int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.isConsumer(p0);
  }

  @Test
  public void newPixels_test_1328(byte[] p0, ColorModel p1, int p2, int p3, int c0, int c1,
      int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.newPixels(p0, p1, p2, p3);
  }

  @Test
  public void newPixels_test_1329(int[] p0, ColorModel p1, int p2, int p3, int c0, int c1, int[] c2,
      int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.newPixels(p0, p1, p2, p3);
  }

  @Test
  public void newPixels_test_1330(int p0, int p1, int p2, int p3, boolean p4, int c0, int c1,
      int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.newPixels(p0, p1, p2, p3, p4);
  }

  @Test
  public void newPixels_test_1331(int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.newPixels();
  }

  @Test
  public void newPixels_test_1332(int p0, int p1, int p2, int p3, int c0, int c1, int[] c2, int c3,
      int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.newPixels(p0, p1, p2, p3);
  }

  @Test
  public void setAnimated_test_1333(boolean p0, int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.setAnimated(p0);
  }

  @Test
  public void setFullBufferUpdates_test_1334(boolean p0, int c0, int c1, int[] c2, int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.setFullBufferUpdates(p0);
  }

  @Test
  public void requestTopDownLeftRightResend_test_1335(ImageConsumer p0, int c0, int c1, int[] c2,
      int c3, int c4) {
    MemoryImageSource instance = new MemoryImageSource(c0, c1, c2, c3, c4);
    instance.requestTopDownLeftRightResend(p0);
  }
}
