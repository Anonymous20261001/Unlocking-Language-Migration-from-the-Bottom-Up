package generated.test;

import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicRootPaneUI;
import org.junit.jupiter.api.Test;

public class BasicRootPaneUIAutoTest {
  @Test
  public void propertyChange_test_8878(PropertyChangeEvent p0) {
    BasicRootPaneUI instance = new BasicRootPaneUI();
    instance.propertyChange(p0);
  }

  @Test
  public void installUI_test_8879(JComponent p0) {
    BasicRootPaneUI instance = new BasicRootPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8880(JComponent p0) {
    BasicRootPaneUI instance = new BasicRootPaneUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8881(JComponent p0) {
    BasicRootPaneUI instance = new BasicRootPaneUI();
    BasicRootPaneUI.createUI(p0);
  }
}
