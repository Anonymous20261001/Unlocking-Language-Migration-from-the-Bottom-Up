package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JTabbedPane;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import org.junit.jupiter.api.Test;

public class BasicTabbedPaneUIAutoTest {
  @Test
  public void getTabRunCount_test_8974(JTabbedPane p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getTabRunCount(p0);
  }

  @Test
  public void getTabBounds_test_8975(JTabbedPane p0, int p1) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getTabBounds(p0, p1);
  }

  @Test
  public void tabForCoordinate_test_8976(JTabbedPane p0, int p1, int p2) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.tabForCoordinate(p0, p1, p2);
  }

  @Test
  public void installUI_test_8977(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8978(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8979(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    BasicTabbedPaneUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_8980(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_8981(Graphics p0, JComponent p1) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getMinimumSize_test_8982(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void getBaseline_test_8983(JComponent p0, int p1, int p2) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void getBaselineResizeBehavior_test_8984(JComponent p0) {
    BasicTabbedPaneUI instance = new BasicTabbedPaneUI();
    instance.getBaselineResizeBehavior(p0);
  }
}
