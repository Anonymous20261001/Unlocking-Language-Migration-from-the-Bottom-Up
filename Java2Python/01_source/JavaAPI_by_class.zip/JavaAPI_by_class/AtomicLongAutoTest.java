package generated.test;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongBinaryOperator;
import java.util.function.LongUnaryOperator;
import org.junit.jupiter.api.Test;

public class AtomicLongAutoTest {
  @Test
  public void get_test_4817() {
    AtomicLong instance = new AtomicLong();
    instance.get();
  }

  @Test
  public void toString_test_4818() {
    AtomicLong instance = new AtomicLong();
    instance.toString();
  }

  @Test
  public void intValue_test_4819() {
    AtomicLong instance = new AtomicLong();
    instance.intValue();
  }

  @Test
  public void longValue_test_4820() {
    AtomicLong instance = new AtomicLong();
    instance.longValue();
  }

  @Test
  public void floatValue_test_4821() {
    AtomicLong instance = new AtomicLong();
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_4822() {
    AtomicLong instance = new AtomicLong();
    instance.doubleValue();
  }

  @Test
  public void set_test_4823(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.set(p0);
  }

  @Test
  public void getOpaque_test_4824() {
    AtomicLong instance = new AtomicLong();
    instance.getOpaque();
  }

  @Test
  public void setOpaque_test_4825(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.setOpaque(p0);
  }

  @Test
  public void getAcquire_test_4826() {
    AtomicLong instance = new AtomicLong();
    instance.getAcquire();
  }

  @Test
  public void setRelease_test_4827(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.setRelease(p0);
  }

  @Test
  public void compareAndSet_test_4828(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.compareAndSet(p0, p1);
  }

  @Test
  public void compareAndExchange_test_4829(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.compareAndExchange(p0, p1);
  }

  @Test
  public void compareAndExchangeAcquire_test_4830(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.compareAndExchangeAcquire(p0, p1);
  }

  @Test
  public void compareAndExchangeRelease_test_4831(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.compareAndExchangeRelease(p0, p1);
  }

  @Test
  public void weakCompareAndSetPlain_test_4832(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.weakCompareAndSetPlain(p0, p1);
  }

  @Test
  public void weakCompareAndSet_test_4833(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.weakCompareAndSet(p0, p1);
  }

  @Test
  public void weakCompareAndSetAcquire_test_4834(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.weakCompareAndSetAcquire(p0, p1);
  }

  @Test
  public void weakCompareAndSetRelease_test_4835(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.weakCompareAndSetRelease(p0, p1);
  }

  @Test
  public void getAndSet_test_4836(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.getAndSet(p0);
  }

  @Test
  public void getAndAdd_test_4837(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.getAndAdd(p0);
  }

  @Test
  public void incrementAndGet_test_4838() {
    AtomicLong instance = new AtomicLong();
    instance.incrementAndGet();
  }

  @Test
  public void weakCompareAndSetVolatile_test_4839(long p0, long p1) {
    AtomicLong instance = new AtomicLong();
    instance.weakCompareAndSetVolatile(p0, p1);
  }

  @Test
  public void lazySet_test_4840(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.lazySet(p0);
  }

  @Test
  public void getAndIncrement_test_4841() {
    AtomicLong instance = new AtomicLong();
    instance.getAndIncrement();
  }

  @Test
  public void getAndDecrement_test_4842() {
    AtomicLong instance = new AtomicLong();
    instance.getAndDecrement();
  }

  @Test
  public void decrementAndGet_test_4843() {
    AtomicLong instance = new AtomicLong();
    instance.decrementAndGet();
  }

  @Test
  public void addAndGet_test_4844(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.addAndGet(p0);
  }

  @Test
  public void getAndUpdate_test_4845(LongUnaryOperator p0) {
    AtomicLong instance = new AtomicLong();
    instance.getAndUpdate(p0);
  }

  @Test
  public void updateAndGet_test_4846(LongUnaryOperator p0) {
    AtomicLong instance = new AtomicLong();
    instance.updateAndGet(p0);
  }

  @Test
  public void getAndAccumulate_test_4847(long p0, LongBinaryOperator p1) {
    AtomicLong instance = new AtomicLong();
    instance.getAndAccumulate(p0, p1);
  }

  @Test
  public void accumulateAndGet_test_4848(long p0, LongBinaryOperator p1) {
    AtomicLong instance = new AtomicLong();
    instance.accumulateAndGet(p0, p1);
  }

  @Test
  public void getPlain_test_4849() {
    AtomicLong instance = new AtomicLong();
    instance.getPlain();
  }

  @Test
  public void setPlain_test_4850(long p0) {
    AtomicLong instance = new AtomicLong();
    instance.setPlain(p0);
  }
}
