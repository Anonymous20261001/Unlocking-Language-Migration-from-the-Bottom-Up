package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiTableHeaderUI;
import org.junit.jupiter.api.Test;

public class MultiTableHeaderUIAutoTest {
  @Test
  public void installUI_test_9606(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9607(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9608() {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9609(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    MultiTableHeaderUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9610(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9611(Graphics p0, JComponent p1) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9612(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9613(JComponent p0, int p1) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9614(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9615(JComponent p0) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9616(Graphics p0, JComponent p1) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9617(JComponent p0, int p1, int p2) {
    MultiTableHeaderUI instance = new MultiTableHeaderUI();
    instance.contains(p0, p1, p2);
  }
}
