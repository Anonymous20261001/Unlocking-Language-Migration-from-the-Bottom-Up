package generated.test;

import java.awt.event.MouseEvent;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.plaf.basic.BasicCheckBoxMenuItemUI;
import org.junit.jupiter.api.Test;

public class BasicCheckBoxMenuItemUIAutoTest {
  @Test
  public void createUI_test_8650(JComponent p0) {
    BasicCheckBoxMenuItemUI instance = new BasicCheckBoxMenuItemUI();
    BasicCheckBoxMenuItemUI.createUI(p0);
  }

  @Test
  public void processMouseEvent_test_8651(JMenuItem p0, MouseEvent p1, MenuElement[] p2,
      MenuSelectionManager p3) {
    BasicCheckBoxMenuItemUI instance = new BasicCheckBoxMenuItemUI();
    instance.processMouseEvent(p0, p1, p2, p3);
  }
}
