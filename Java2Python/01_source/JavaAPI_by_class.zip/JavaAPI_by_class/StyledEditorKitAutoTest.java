package generated.test;

import javax.swing.JEditorPane;
import javax.swing.text.StyledEditorKit;
import org.junit.jupiter.api.Test;

public class StyledEditorKitAutoTest {
  @Test
  public void createDefaultDocument_test_10401() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.createDefaultDocument();
  }

  @Test
  public void deinstall_test_10402(JEditorPane p0) {
    StyledEditorKit instance = new StyledEditorKit();
    instance.deinstall(p0);
  }

  @Test
  public void install_test_10403(JEditorPane p0) {
    StyledEditorKit instance = new StyledEditorKit();
    instance.install(p0);
  }

  @Test
  public void getInputAttributes_test_10404() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.getInputAttributes();
  }

  @Test
  public void getViewFactory_test_10405() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.getViewFactory();
  }

  @Test
  public void getCharacterAttributeRun_test_10406() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.getCharacterAttributeRun();
  }

  @Test
  public void getActions_test_10407() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.getActions();
  }

  @Test
  public void clone_test_10408() {
    StyledEditorKit instance = new StyledEditorKit();
    instance.clone();
  }
}
