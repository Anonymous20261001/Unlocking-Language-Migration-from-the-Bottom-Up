package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollPaneUI;
import org.junit.jupiter.api.Test;

public class BasicScrollPaneUIAutoTest {
  @Test
  public void installUI_test_8895(JComponent p0) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8896(JComponent p0) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8897(JComponent p0) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    BasicScrollPaneUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_8898(JComponent p0) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_8899(Graphics p0, JComponent p1) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getBaseline_test_8900(JComponent p0, int p1, int p2) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void getBaselineResizeBehavior_test_8901(JComponent p0) {
    BasicScrollPaneUI instance = new BasicScrollPaneUI();
    instance.getBaselineResizeBehavior(p0);
  }
}
