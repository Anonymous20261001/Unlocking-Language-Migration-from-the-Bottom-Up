package generated.test;

import java.lang.Object;
import java.lang.String;
import java.security.Permission;
import javax.smartcardio.CardPermission;
import org.junit.jupiter.api.Test;

public class CardPermissionAutoTest {
  @Test
  public void getActions_test_6451(String c0, String c1) {
    CardPermission instance = new CardPermission(c0, c1);
    instance.getActions();
  }

  @Test
  public void equals_test_6452(Object p0, String c0, String c1) {
    CardPermission instance = new CardPermission(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_6453(String c0, String c1) {
    CardPermission instance = new CardPermission(c0, c1);
    instance.hashCode();
  }

  @Test
  public void implies_test_6454(Permission p0, String c0, String c1) {
    CardPermission instance = new CardPermission(c0, c1);
    instance.implies(p0);
  }
}
