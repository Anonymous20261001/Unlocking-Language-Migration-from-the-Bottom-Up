package generated.test;

import java.lang.String;
import javax.accessibility.AccessibleRelation;
import javax.accessibility.AccessibleRelationSet;
import org.junit.jupiter.api.Test;

public class AccessibleRelationSetAutoTest {
  @Test
  public void remove_test_5216(AccessibleRelation p0) {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.remove(p0);
  }

  @Test
  public void size_test_5217() {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.size();
  }

  @Test
  public void get_test_5218(String p0) {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.get(p0);
  }

  @Test
  public void toString_test_5219() {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.toString();
  }

  @Test
  public void clear_test_5220() {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.clear();
  }

  @Test
  public void add_test_5221(AccessibleRelation p0) {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.add(p0);
  }

  @Test
  public void toArray_test_5222() {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.toArray();
  }

  @Test
  public void contains_test_5223(String p0) {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.contains(p0);
  }

  @Test
  public void addAll_test_5224(AccessibleRelation[] p0) {
    AccessibleRelationSet instance = new AccessibleRelationSet();
    instance.addAll(p0);
  }
}
