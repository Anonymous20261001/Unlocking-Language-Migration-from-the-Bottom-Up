package generated.test;

import java.io.InputStream;
import java.util.zip.CheckedInputStream;
import java.util.zip.Checksum;
import org.junit.jupiter.api.Test;

public class CheckedInputStreamAutoTest {
  @Test
  public void getChecksum_test_5134(InputStream c0, Checksum c1) {
    CheckedInputStream instance = new CheckedInputStream(c0, c1);
    instance.getChecksum();
  }
}
