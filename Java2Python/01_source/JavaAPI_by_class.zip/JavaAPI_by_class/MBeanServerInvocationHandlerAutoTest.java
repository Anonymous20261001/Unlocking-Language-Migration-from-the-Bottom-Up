package generated.test;

import java.lang.Class;
import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import org.junit.jupiter.api.Test;

public class MBeanServerInvocationHandlerAutoTest {
  @Test
  public void getMBeanServerConnection_test_5604(MBeanServerConnection c0, ObjectName c1) {
    MBeanServerInvocationHandler instance = new MBeanServerInvocationHandler(c0, c1);
    instance.getMBeanServerConnection();
  }

  @Test
  public void getObjectName_test_5605(MBeanServerConnection c0, ObjectName c1) {
    MBeanServerInvocationHandler instance = new MBeanServerInvocationHandler(c0, c1);
    instance.getObjectName();
  }

  @Test
  public void isMXBean_test_5606(MBeanServerConnection c0, ObjectName c1) {
    MBeanServerInvocationHandler instance = new MBeanServerInvocationHandler(c0, c1);
    instance.isMXBean();
  }

  @Test
  public void newProxyInstance_test_5607(MBeanServerConnection p0, ObjectName p1, Class p2,
      boolean p3, MBeanServerConnection c0, ObjectName c1) {
    MBeanServerInvocationHandler instance = new MBeanServerInvocationHandler(c0, c1);
    MBeanServerInvocationHandler.newProxyInstance(p0, p1, p2, p3);
  }
}
