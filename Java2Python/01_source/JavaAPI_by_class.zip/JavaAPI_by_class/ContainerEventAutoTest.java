package generated.test;

import java.awt.Component;
import java.awt.event.ContainerEvent;
import org.junit.jupiter.api.Test;

public class ContainerEventAutoTest {
  @Test
  public void getContainer_test_752(Component c0, int c1, Component c2) {
    ContainerEvent instance = new ContainerEvent(c0, c1, c2);
    instance.getContainer();
  }

  @Test
  public void paramString_test_753(Component c0, int c1, Component c2) {
    ContainerEvent instance = new ContainerEvent(c0, c1, c2);
    instance.paramString();
  }

  @Test
  public void getChild_test_754(Component c0, int c1, Component c2) {
    ContainerEvent instance = new ContainerEvent(c0, c1, c2);
    instance.getChild();
  }
}
