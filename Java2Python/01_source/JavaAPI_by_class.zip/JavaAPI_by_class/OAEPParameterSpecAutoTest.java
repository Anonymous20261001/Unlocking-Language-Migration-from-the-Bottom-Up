package generated.test;

import java.lang.String;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import org.junit.jupiter.api.Test;

public class OAEPParameterSpecAutoTest {
  @Test
  public void getPSource_test_5250(String c0, String c1, AlgorithmParameterSpec c2, PSource c3) {
    OAEPParameterSpec instance = new OAEPParameterSpec(c0, c1, c2, c3);
    instance.getPSource();
  }

  @Test
  public void getDigestAlgorithm_test_5251(String c0, String c1, AlgorithmParameterSpec c2,
      PSource c3) {
    OAEPParameterSpec instance = new OAEPParameterSpec(c0, c1, c2, c3);
    instance.getDigestAlgorithm();
  }

  @Test
  public void getMGFAlgorithm_test_5252(String c0, String c1, AlgorithmParameterSpec c2,
      PSource c3) {
    OAEPParameterSpec instance = new OAEPParameterSpec(c0, c1, c2, c3);
    instance.getMGFAlgorithm();
  }

  @Test
  public void getMGFParameters_test_5253(String c0, String c1, AlgorithmParameterSpec c2,
      PSource c3) {
    OAEPParameterSpec instance = new OAEPParameterSpec(c0, c1, c2, c3);
    instance.getMGFParameters();
  }
}
