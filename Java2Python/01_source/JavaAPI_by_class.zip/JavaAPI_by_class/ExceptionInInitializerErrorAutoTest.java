package generated.test;

import java.lang.ExceptionInInitializerError;
import org.junit.jupiter.api.Test;

public class ExceptionInInitializerErrorAutoTest {
  @Test
  public void getException_test_1997() {
    ExceptionInInitializerError instance = new ExceptionInInitializerError();
    instance.getException();
  }
}
