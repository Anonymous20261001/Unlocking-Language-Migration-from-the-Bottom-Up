package generated.test;

import java.lang.Object;
import java.lang.String;
import java.security.Permission;
import java.util.PropertyPermission;
import org.junit.jupiter.api.Test;

public class PropertyPermissionAutoTest {
  @Test
  public void getActions_test_3773(String c0, String c1) {
    PropertyPermission instance = new PropertyPermission(c0, c1);
    instance.getActions();
  }

  @Test
  public void equals_test_3774(Object p0, String c0, String c1) {
    PropertyPermission instance = new PropertyPermission(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_3775(String c0, String c1) {
    PropertyPermission instance = new PropertyPermission(c0, c1);
    instance.hashCode();
  }

  @Test
  public void implies_test_3776(Permission p0, String c0, String c1) {
    PropertyPermission instance = new PropertyPermission(c0, c1);
    instance.implies(p0);
  }

  @Test
  public void newPermissionCollection_test_3777(String c0, String c1) {
    PropertyPermission instance = new PropertyPermission(c0, c1);
    instance.newPermissionCollection();
  }
}
