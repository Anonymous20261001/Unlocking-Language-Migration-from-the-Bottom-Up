package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.CellRendererPane;
import org.junit.jupiter.api.Test;

public class CellRendererPaneAutoTest {
  @Test
  public void paintComponent_test_6569(Graphics p0, Component p1, Container p2, int p3, int p4,
      int p5, int p6) {
    CellRendererPane instance = new CellRendererPane();
    instance.paintComponent(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void paintComponent_test_6570(Graphics p0, Component p1, Container p2, Rectangle p3) {
    CellRendererPane instance = new CellRendererPane();
    instance.paintComponent(p0, p1, p2, p3);
  }

  @Test
  public void paintComponent_test_6571(Graphics p0, Component p1, Container p2, int p3, int p4,
      int p5, int p6, boolean p7) {
    CellRendererPane instance = new CellRendererPane();
    instance.paintComponent(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void getAccessibleContext_test_6572() {
    CellRendererPane instance = new CellRendererPane();
    instance.getAccessibleContext();
  }

  @Test
  public void paint_test_6573(Graphics p0) {
    CellRendererPane instance = new CellRendererPane();
    instance.paint(p0);
  }

  @Test
  public void update_test_6574(Graphics p0) {
    CellRendererPane instance = new CellRendererPane();
    instance.update(p0);
  }

  @Test
  public void invalidate_test_6575() {
    CellRendererPane instance = new CellRendererPane();
    instance.invalidate();
  }
}
