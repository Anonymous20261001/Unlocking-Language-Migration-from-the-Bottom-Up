package generated.test;

import java.lang.Runnable;
import javax.swing.text.LayoutQueue;
import org.junit.jupiter.api.Test;

public class LayoutQueueAutoTest {
  @Test
  public void getDefaultQueue_test_10302() {
    LayoutQueue instance = new LayoutQueue();
    LayoutQueue.getDefaultQueue();
  }

  @Test
  public void addTask_test_10303(Runnable p0) {
    LayoutQueue instance = new LayoutQueue();
    instance.addTask(p0);
  }

  @Test
  public void setDefaultQueue_test_10304(LayoutQueue p0) {
    LayoutQueue instance = new LayoutQueue();
    LayoutQueue.setDefaultQueue(p0);
  }
}
