package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.NumberUp;
import org.junit.jupiter.api.Test;

public class NumberUpAutoTest {
  @Test
  public void getCategory_test_6192(int c0) {
    NumberUp instance = new NumberUp(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6193(int c0) {
    NumberUp instance = new NumberUp(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6194(Object p0, int c0) {
    NumberUp instance = new NumberUp(c0);
    instance.equals(p0);
  }
}
