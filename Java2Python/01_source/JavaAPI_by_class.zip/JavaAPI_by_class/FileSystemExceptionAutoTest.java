package generated.test;

import java.lang.String;
import java.nio.file.FileSystemException;
import org.junit.jupiter.api.Test;

public class FileSystemExceptionAutoTest {
  @Test
  public void getMessage_test_2648(String c0) {
    FileSystemException instance = new FileSystemException(c0);
    instance.getMessage();
  }

  @Test
  public void getFile_test_2649(String c0) {
    FileSystemException instance = new FileSystemException(c0);
    instance.getFile();
  }

  @Test
  public void getReason_test_2650(String c0) {
    FileSystemException instance = new FileSystemException(c0);
    instance.getReason();
  }

  @Test
  public void getOtherFile_test_2651(String c0) {
    FileSystemException instance = new FileSystemException(c0);
    instance.getOtherFile();
  }
}
