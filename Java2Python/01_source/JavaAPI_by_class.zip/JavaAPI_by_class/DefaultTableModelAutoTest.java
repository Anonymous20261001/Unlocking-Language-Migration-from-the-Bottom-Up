package generated.test;

import java.lang.Object;
import java.util.Vector;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import org.junit.jupiter.api.Test;

public class DefaultTableModelAutoTest {
  @Test
  public void getRowCount_test_10015() {
    DefaultTableModel instance = new DefaultTableModel();
    instance.getRowCount();
  }

  @Test
  public void addColumn_test_10016(Object p0, Vector p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.addColumn(p0, p1);
  }

  @Test
  public void addColumn_test_10017(Object p0, Object[] p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.addColumn(p0, p1);
  }

  @Test
  public void addColumn_test_10018(Object p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.addColumn(p0);
  }

  @Test
  public void getValueAt_test_10019(int p0, int p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.getValueAt(p0, p1);
  }

  @Test
  public void setValueAt_test_10020(Object p0, int p1, int p2) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setValueAt(p0, p1, p2);
  }

  @Test
  public void isCellEditable_test_10021(int p0, int p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.isCellEditable(p0, p1);
  }

  @Test
  public void setDataVector_test_10022(Object[][] p0, Object[] p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setDataVector(p0, p1);
  }

  @Test
  public void setDataVector_test_10023(Vector p0, Vector p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setDataVector(p0, p1);
  }

  @Test
  public void setNumRows_test_10024(int p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setNumRows(p0);
  }

  @Test
  public void insertRow_test_10025(int p0, Vector p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.insertRow(p0, p1);
  }

  @Test
  public void insertRow_test_10026(int p0, Object[] p1) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.insertRow(p0, p1);
  }

  @Test
  public void addRow_test_10027(Vector p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.addRow(p0);
  }

  @Test
  public void addRow_test_10028(Object[] p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.addRow(p0);
  }

  @Test
  public void setColumnIdentifiers_test_10029(Vector p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setColumnIdentifiers(p0);
  }

  @Test
  public void setColumnIdentifiers_test_10030(Object[] p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setColumnIdentifiers(p0);
  }

  @Test
  public void getDataVector_test_10031() {
    DefaultTableModel instance = new DefaultTableModel();
    instance.getDataVector();
  }

  @Test
  public void newDataAvailable_test_10032(TableModelEvent p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.newDataAvailable(p0);
  }

  @Test
  public void newRowsAdded_test_10033(TableModelEvent p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.newRowsAdded(p0);
  }

  @Test
  public void rowsRemoved_test_10034(TableModelEvent p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.rowsRemoved(p0);
  }

  @Test
  public void setRowCount_test_10035(int p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setRowCount(p0);
  }

  @Test
  public void moveRow_test_10036(int p0, int p1, int p2) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.moveRow(p0, p1, p2);
  }

  @Test
  public void removeRow_test_10037(int p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.removeRow(p0);
  }

  @Test
  public void setColumnCount_test_10038(int p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.setColumnCount(p0);
  }

  @Test
  public void getColumnCount_test_10039() {
    DefaultTableModel instance = new DefaultTableModel();
    instance.getColumnCount();
  }

  @Test
  public void getColumnName_test_10040(int p0) {
    DefaultTableModel instance = new DefaultTableModel();
    instance.getColumnName(p0);
  }
}
