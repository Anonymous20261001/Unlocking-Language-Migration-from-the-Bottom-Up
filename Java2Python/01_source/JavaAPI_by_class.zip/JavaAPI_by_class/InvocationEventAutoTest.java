package generated.test;

import java.awt.event.InvocationEvent;
import java.lang.Object;
import java.lang.Runnable;
import org.junit.jupiter.api.Test;

public class InvocationEventAutoTest {
  @Test
  public void getWhen_test_772(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.getWhen();
  }

  @Test
  public void isDispatched_test_773(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.isDispatched();
  }

  @Test
  public void getThrowable_test_774(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.getThrowable();
  }

  @Test
  public void dispatch_test_775(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.dispatch();
  }

  @Test
  public void getException_test_776(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.getException();
  }

  @Test
  public void paramString_test_777(Object c0, Runnable c1) {
    InvocationEvent instance = new InvocationEvent(c0, c1);
    instance.paramString();
  }
}
