package generated.test;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.String;
import java.lang.Throwable;
import javax.xml.transform.SourceLocator;
import javax.xml.transform.TransformerException;
import org.junit.jupiter.api.Test;

public class TransformerExceptionAutoTest {
  @Test
  public void getLocationAsString_test_10959(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.getLocationAsString();
  }

  @Test
  public void getLocator_test_10960(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.getLocator();
  }

  @Test
  public void setLocator_test_10961(SourceLocator p0, String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.setLocator(p0);
  }

  @Test
  public void getMessageAndLocation_test_10962(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.getMessageAndLocation();
  }

  @Test
  public void printStackTrace_test_10963(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.printStackTrace();
  }

  @Test
  public void printStackTrace_test_10964(PrintStream p0, String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.printStackTrace(p0);
  }

  @Test
  public void printStackTrace_test_10965(PrintWriter p0, String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.printStackTrace(p0);
  }

  @Test
  public void getCause_test_10966(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.getCause();
  }

  @Test
  public void initCause_test_10967(Throwable p0, String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.initCause(p0);
  }

  @Test
  public void getException_test_10968(String c0) {
    TransformerException instance = new TransformerException(c0);
    instance.getException();
  }
}
