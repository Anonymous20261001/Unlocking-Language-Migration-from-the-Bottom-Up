package generated.test;

import java.lang.String;
import javax.security.auth.callback.TextOutputCallback;
import org.junit.jupiter.api.Test;

public class TextOutputCallbackAutoTest {
  @Test
  public void getMessageType_test_6355(int c0, String c1) {
    TextOutputCallback instance = new TextOutputCallback(c0, c1);
    instance.getMessageType();
  }

  @Test
  public void getMessage_test_6356(int c0, String c1) {
    TextOutputCallback instance = new TextOutputCallback(c0, c1);
    instance.getMessage();
  }
}
