package generated.test;

import java.math.BigInteger;
import java.security.spec.EdECPoint;
import org.junit.jupiter.api.Test;

public class EdECPointAutoTest {
  @Test
  public void isXOdd_test_2883(boolean c0, BigInteger c1) {
    EdECPoint instance = new EdECPoint(c0, c1);
    instance.isXOdd();
  }

  @Test
  public void getY_test_2884(boolean c0, BigInteger c1) {
    EdECPoint instance = new EdECPoint(c0, c1);
    instance.getY();
  }
}
