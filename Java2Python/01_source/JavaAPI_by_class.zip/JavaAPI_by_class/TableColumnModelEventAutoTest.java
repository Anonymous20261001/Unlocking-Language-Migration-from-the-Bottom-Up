package generated.test;

import javax.swing.event.TableColumnModelEvent;
import javax.swing.table.TableColumnModel;
import org.junit.jupiter.api.Test;

public class TableColumnModelEventAutoTest {
  @Test
  public void getFromIndex_test_8555(TableColumnModel c0, int c1, int c2) {
    TableColumnModelEvent instance = new TableColumnModelEvent(c0, c1, c2);
    instance.getFromIndex();
  }

  @Test
  public void getToIndex_test_8556(TableColumnModel c0, int c1, int c2) {
    TableColumnModelEvent instance = new TableColumnModelEvent(c0, c1, c2);
    instance.getToIndex();
  }
}
