package generated.test;

import java.util.IntSummaryStatistics;
import org.junit.jupiter.api.Test;

public class IntSummaryStatisticsAutoTest {
  @Test
  public void toString_test_3576() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.toString();
  }

  @Test
  public void accept_test_3577(int p0) {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.accept(p0);
  }

  @Test
  public void getCount_test_3578() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.getCount();
  }

  @Test
  public void combine_test_3579(IntSummaryStatistics p0) {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.combine(p0);
  }

  @Test
  public void getSum_test_3580() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.getSum();
  }

  @Test
  public void getMin_test_3581() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.getMin();
  }

  @Test
  public void getAverage_test_3582() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.getAverage();
  }

  @Test
  public void getMax_test_3583() {
    IntSummaryStatistics instance = new IntSummaryStatistics();
    instance.getMax();
  }
}
