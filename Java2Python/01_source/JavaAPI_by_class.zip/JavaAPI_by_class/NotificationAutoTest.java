package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.Notification;
import org.junit.jupiter.api.Test;

public class NotificationAutoTest {
  @Test
  public void setUserData_test_5614(Object p0, String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.setUserData(p0);
  }

  @Test
  public void getUserData_test_5615(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.getUserData();
  }

  @Test
  public void getSequenceNumber_test_5616(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.getSequenceNumber();
  }

  @Test
  public void setSequenceNumber_test_5617(long p0, String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.setSequenceNumber(p0);
  }

  @Test
  public void getTimeStamp_test_5618(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.getTimeStamp();
  }

  @Test
  public void setTimeStamp_test_5619(long p0, String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.setTimeStamp(p0);
  }

  @Test
  public void setSource_test_5620(Object p0, String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.setSource(p0);
  }

  @Test
  public void toString_test_5621(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void getMessage_test_5622(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.getMessage();
  }

  @Test
  public void getType_test_5623(String c0, Object c1, long c2) {
    Notification instance = new Notification(c0, c1, c2);
    instance.getType();
  }
}
