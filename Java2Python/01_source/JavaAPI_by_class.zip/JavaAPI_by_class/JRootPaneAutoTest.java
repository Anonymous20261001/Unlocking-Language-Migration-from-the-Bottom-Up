package generated.test;

import java.awt.Component;
import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.JRootPane;
import javax.swing.plaf.RootPaneUI;
import org.junit.jupiter.api.Test;

public class JRootPaneAutoTest {
  @Test
  public void setWindowDecorationStyle_test_7538(int p0) {
    JRootPane instance = new JRootPane();
    instance.setWindowDecorationStyle(p0);
  }

  @Test
  public void isOptimizedDrawingEnabled_test_7539() {
    JRootPane instance = new JRootPane();
    instance.isOptimizedDrawingEnabled();
  }

  @Test
  public void getUIClassID_test_7540() {
    JRootPane instance = new JRootPane();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_7541() {
    JRootPane instance = new JRootPane();
    instance.getUI();
  }

  @Test
  public void setUI_test_7542(RootPaneUI p0) {
    JRootPane instance = new JRootPane();
    instance.setUI(p0);
  }

  @Test
  public void setDoubleBuffered_test_7543(boolean p0) {
    JRootPane instance = new JRootPane();
    instance.setDoubleBuffered(p0);
  }

  @Test
  public void getWindowDecorationStyle_test_7544() {
    JRootPane instance = new JRootPane();
    instance.getWindowDecorationStyle();
  }

  @Test
  public void setJMenuBar_test_7545(JMenuBar p0) {
    JRootPane instance = new JRootPane();
    instance.setJMenuBar(p0);
  }

  @Test
  public void getJMenuBar_test_7546() {
    JRootPane instance = new JRootPane();
    instance.getJMenuBar();
  }

  @Test
  public void setContentPane_test_7547(Container p0) {
    JRootPane instance = new JRootPane();
    instance.setContentPane(p0);
  }

  @Test
  public void setLayeredPane_test_7548(JLayeredPane p0) {
    JRootPane instance = new JRootPane();
    instance.setLayeredPane(p0);
  }

  @Test
  public void getGlassPane_test_7549() {
    JRootPane instance = new JRootPane();
    instance.getGlassPane();
  }

  @Test
  public void setGlassPane_test_7550(Component p0) {
    JRootPane instance = new JRootPane();
    instance.setGlassPane(p0);
  }

  @Test
  public void getDefaultButton_test_7551() {
    JRootPane instance = new JRootPane();
    instance.getDefaultButton();
  }

  @Test
  public void setDefaultButton_test_7552(JButton p0) {
    JRootPane instance = new JRootPane();
    instance.setDefaultButton(p0);
  }

  @Test
  public void isValidateRoot_test_7553() {
    JRootPane instance = new JRootPane();
    instance.isValidateRoot();
  }

  @Test
  public void getAccessibleContext_test_7554() {
    JRootPane instance = new JRootPane();
    instance.getAccessibleContext();
  }

  @Test
  public void addNotify_test_7555() {
    JRootPane instance = new JRootPane();
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_7556() {
    JRootPane instance = new JRootPane();
    instance.removeNotify();
  }

  @Test
  public void updateUI_test_7557() {
    JRootPane instance = new JRootPane();
    instance.updateUI();
  }

  @Test
  public void getLayeredPane_test_7558() {
    JRootPane instance = new JRootPane();
    instance.getLayeredPane();
  }

  @Test
  public void getContentPane_test_7559() {
    JRootPane instance = new JRootPane();
    instance.getContentPane();
  }

  @Test
  public void setMenuBar_test_7560(JMenuBar p0) {
    JRootPane instance = new JRootPane();
    instance.setMenuBar(p0);
  }

  @Test
  public void getMenuBar_test_7561() {
    JRootPane instance = new JRootPane();
    instance.getMenuBar();
  }
}
