package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class LinkedBlockingDequeAutoTest {
  @Test
  public void drainTo_test_4515(Collection p0, int p1) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.drainTo(p0, p1);
  }

  @Test
  public void drainTo_test_4516(Collection p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.drainTo(p0);
  }

  @Test
  public void remainingCapacity_test_4517() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4518(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.remove(p0);
  }

  @Test
  public void remove_test_4519() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.remove();
  }

  @Test
  public void size_test_4520() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.size();
  }

  @Test
  public void toString_test_4521() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.toString();
  }

  @Test
  public void clear_test_4522() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.clear();
  }

  @Test
  public void add_test_4523(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.add(p0);
  }

  @Test
  public void toArray_test_4524(Object[] p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4525() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.toArray();
  }

  @Test
  public void iterator_test_4526() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.iterator();
  }

  @Test
  public void contains_test_4527(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4528() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.spliterator();
  }

  @Test
  public void addAll_test_4529(Collection p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.addAll(p0);
  }

  @Test
  public void forEach_test_4530(Consumer p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.forEach(p0);
  }

  @Test
  public void peek_test_4531() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.peek();
  }

  @Test
  public void removeIf_test_4532(Predicate p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeIf(p0);
  }

  @Test
  public void getFirst_test_4533() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.getFirst();
  }

  @Test
  public void getLast_test_4534() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.getLast();
  }

  @Test
  public void element_test_4535() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.element();
  }

  @Test
  public void addFirst_test_4536(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.addFirst(p0);
  }

  @Test
  public void addLast_test_4537(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.addLast(p0);
  }

  @Test
  public void removeFirst_test_4538() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeFirst();
  }

  @Test
  public void removeLast_test_4539() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeLast();
  }

  @Test
  public void removeAll_test_4540(Collection p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4541(Collection p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.retainAll(p0);
  }

  @Test
  public void poll_test_4542() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.poll();
  }

  @Test
  public void offer_test_4543(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.offer(p0);
  }

  @Test
  public void push_test_4544(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.push(p0);
  }

  @Test
  public void pop_test_4545() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.pop();
  }

  @Test
  public void pollFirst_test_4546() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.pollFirst();
  }

  @Test
  public void pollLast_test_4547() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.pollLast();
  }

  @Test
  public void offerLast_test_4548(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.offerLast(p0);
  }

  @Test
  public void peekFirst_test_4549() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.peekFirst();
  }

  @Test
  public void removeFirstOccurrence_test_4550(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeFirstOccurrence(p0);
  }

  @Test
  public void offerFirst_test_4551(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.offerFirst(p0);
  }

  @Test
  public void peekLast_test_4552() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.peekLast();
  }

  @Test
  public void removeLastOccurrence_test_4553(Object p0) {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.removeLastOccurrence(p0);
  }

  @Test
  public void descendingIterator_test_4554() {
    LinkedBlockingDeque instance = new LinkedBlockingDeque();
    instance.descendingIterator();
  }
}
