package generated.test;

import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalTheme;
import org.junit.jupiter.api.Test;

public class MetalLookAndFeelAutoTest {
  @Test
  public void getSupportsWindowDecorations_test_9174() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getSupportsWindowDecorations();
  }

  @Test
  public void provideErrorFeedback_test_9175(Component p0) {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.provideErrorFeedback(p0);
  }

  @Test
  public void getFocusColor_test_9176() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getFocusColor();
  }

  @Test
  public void getDefaults_test_9177() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getDefaults();
  }

  @Test
  public void setCurrentTheme_test_9178(MetalTheme p0) {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.setCurrentTheme(p0);
  }

  @Test
  public void isNativeLookAndFeel_test_9179() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.isNativeLookAndFeel();
  }

  @Test
  public void getDisabledIcon_test_9180(JComponent p0, Icon p1) {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getDisabledIcon(p0, p1);
  }

  @Test
  public void getLayoutStyle_test_9181() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getLayoutStyle();
  }

  @Test
  public void getDisabledSelectedIcon_test_9182(JComponent p0, Icon p1) {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getDisabledSelectedIcon(p0, p1);
  }

  @Test
  public void getControlTextFont_test_9183() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlTextFont();
  }

  @Test
  public void getSystemTextFont_test_9184() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getSystemTextFont();
  }

  @Test
  public void getUserTextFont_test_9185() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getUserTextFont();
  }

  @Test
  public void getMenuTextFont_test_9186() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuTextFont();
  }

  @Test
  public void getWindowTitleFont_test_9187() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowTitleFont();
  }

  @Test
  public void getSubTextFont_test_9188() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getSubTextFont();
  }

  @Test
  public void getBlack_test_9189() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getBlack();
  }

  @Test
  public void getWhite_test_9190() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWhite();
  }

  @Test
  public void getControlInfo_test_9191() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlInfo();
  }

  @Test
  public void getControlDisabled_test_9192() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlDisabled();
  }

  @Test
  public void getControlTextColor_test_9193() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlTextColor();
  }

  @Test
  public void getDesktopColor_test_9194() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getDesktopColor();
  }

  @Test
  public void getControlShadow_test_9195() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlShadow();
  }

  @Test
  public void getControlDarkShadow_test_9196() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlDarkShadow();
  }

  @Test
  public void getControlHighlight_test_9197() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControlHighlight();
  }

  @Test
  public void getPrimaryControl_test_9198() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getPrimaryControl();
  }

  @Test
  public void getPrimaryControlShadow_test_9199() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getPrimaryControlShadow();
  }

  @Test
  public void getPrimaryControlDarkShadow_test_9200() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getPrimaryControlDarkShadow();
  }

  @Test
  public void getPrimaryControlInfo_test_9201() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getPrimaryControlInfo();
  }

  @Test
  public void getPrimaryControlHighlight_test_9202() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getPrimaryControlHighlight();
  }

  @Test
  public void getSystemTextColor_test_9203() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getSystemTextColor();
  }

  @Test
  public void getInactiveControlTextColor_test_9204() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getInactiveControlTextColor();
  }

  @Test
  public void getInactiveSystemTextColor_test_9205() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getInactiveSystemTextColor();
  }

  @Test
  public void getUserTextColor_test_9206() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getUserTextColor();
  }

  @Test
  public void getTextHighlightColor_test_9207() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getTextHighlightColor();
  }

  @Test
  public void getHighlightedTextColor_test_9208() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getHighlightedTextColor();
  }

  @Test
  public void getWindowBackground_test_9209() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowBackground();
  }

  @Test
  public void getWindowTitleBackground_test_9210() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowTitleBackground();
  }

  @Test
  public void getWindowTitleForeground_test_9211() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowTitleForeground();
  }

  @Test
  public void getWindowTitleInactiveBackground_test_9212() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowTitleInactiveBackground();
  }

  @Test
  public void getWindowTitleInactiveForeground_test_9213() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getWindowTitleInactiveForeground();
  }

  @Test
  public void getMenuBackground_test_9214() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuBackground();
  }

  @Test
  public void getMenuForeground_test_9215() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuForeground();
  }

  @Test
  public void getMenuSelectedBackground_test_9216() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuSelectedBackground();
  }

  @Test
  public void getMenuSelectedForeground_test_9217() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuSelectedForeground();
  }

  @Test
  public void getMenuDisabledForeground_test_9218() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getMenuDisabledForeground();
  }

  @Test
  public void getSeparatorBackground_test_9219() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getSeparatorBackground();
  }

  @Test
  public void getSeparatorForeground_test_9220() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getSeparatorForeground();
  }

  @Test
  public void getAcceleratorForeground_test_9221() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getAcceleratorForeground();
  }

  @Test
  public void getAcceleratorSelectedForeground_test_9222() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getAcceleratorSelectedForeground();
  }

  @Test
  public void getDescription_test_9223() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getDescription();
  }

  @Test
  public void getCurrentTheme_test_9224() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getCurrentTheme();
  }

  @Test
  public void isSupportedLookAndFeel_test_9225() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.isSupportedLookAndFeel();
  }

  @Test
  public void getName_test_9226() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getName();
  }

  @Test
  public void getID_test_9227() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    instance.getID();
  }

  @Test
  public void getControl_test_9228() {
    MetalLookAndFeel instance = new MetalLookAndFeel();
    MetalLookAndFeel.getControl();
  }
}
