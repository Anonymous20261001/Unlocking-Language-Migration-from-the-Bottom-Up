package generated.test;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;
import org.junit.jupiter.api.Test;

public class AtomicIntegerAutoTest {
  @Test
  public void get_test_4752() {
    AtomicInteger instance = new AtomicInteger();
    instance.get();
  }

  @Test
  public void toString_test_4753() {
    AtomicInteger instance = new AtomicInteger();
    instance.toString();
  }

  @Test
  public void intValue_test_4754() {
    AtomicInteger instance = new AtomicInteger();
    instance.intValue();
  }

  @Test
  public void longValue_test_4755() {
    AtomicInteger instance = new AtomicInteger();
    instance.longValue();
  }

  @Test
  public void floatValue_test_4756() {
    AtomicInteger instance = new AtomicInteger();
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_4757() {
    AtomicInteger instance = new AtomicInteger();
    instance.doubleValue();
  }

  @Test
  public void set_test_4758(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.set(p0);
  }

  @Test
  public void getOpaque_test_4759() {
    AtomicInteger instance = new AtomicInteger();
    instance.getOpaque();
  }

  @Test
  public void setOpaque_test_4760(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.setOpaque(p0);
  }

  @Test
  public void getAcquire_test_4761() {
    AtomicInteger instance = new AtomicInteger();
    instance.getAcquire();
  }

  @Test
  public void setRelease_test_4762(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.setRelease(p0);
  }

  @Test
  public void compareAndSet_test_4763(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.compareAndSet(p0, p1);
  }

  @Test
  public void compareAndExchange_test_4764(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.compareAndExchange(p0, p1);
  }

  @Test
  public void compareAndExchangeAcquire_test_4765(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.compareAndExchangeAcquire(p0, p1);
  }

  @Test
  public void compareAndExchangeRelease_test_4766(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.compareAndExchangeRelease(p0, p1);
  }

  @Test
  public void weakCompareAndSetPlain_test_4767(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.weakCompareAndSetPlain(p0, p1);
  }

  @Test
  public void weakCompareAndSet_test_4768(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.weakCompareAndSet(p0, p1);
  }

  @Test
  public void weakCompareAndSetAcquire_test_4769(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.weakCompareAndSetAcquire(p0, p1);
  }

  @Test
  public void weakCompareAndSetRelease_test_4770(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.weakCompareAndSetRelease(p0, p1);
  }

  @Test
  public void getAndSet_test_4771(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndSet(p0);
  }

  @Test
  public void getAndAdd_test_4772(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndAdd(p0);
  }

  @Test
  public void incrementAndGet_test_4773() {
    AtomicInteger instance = new AtomicInteger();
    instance.incrementAndGet();
  }

  @Test
  public void weakCompareAndSetVolatile_test_4774(int p0, int p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.weakCompareAndSetVolatile(p0, p1);
  }

  @Test
  public void lazySet_test_4775(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.lazySet(p0);
  }

  @Test
  public void getAndIncrement_test_4776() {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndIncrement();
  }

  @Test
  public void getAndDecrement_test_4777() {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndDecrement();
  }

  @Test
  public void decrementAndGet_test_4778() {
    AtomicInteger instance = new AtomicInteger();
    instance.decrementAndGet();
  }

  @Test
  public void addAndGet_test_4779(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.addAndGet(p0);
  }

  @Test
  public void getAndUpdate_test_4780(IntUnaryOperator p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndUpdate(p0);
  }

  @Test
  public void updateAndGet_test_4781(IntUnaryOperator p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.updateAndGet(p0);
  }

  @Test
  public void getAndAccumulate_test_4782(int p0, IntBinaryOperator p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.getAndAccumulate(p0, p1);
  }

  @Test
  public void accumulateAndGet_test_4783(int p0, IntBinaryOperator p1) {
    AtomicInteger instance = new AtomicInteger();
    instance.accumulateAndGet(p0, p1);
  }

  @Test
  public void getPlain_test_4784() {
    AtomicInteger instance = new AtomicInteger();
    instance.getPlain();
  }

  @Test
  public void setPlain_test_4785(int p0) {
    AtomicInteger instance = new AtomicInteger();
    instance.setPlain(p0);
  }
}
