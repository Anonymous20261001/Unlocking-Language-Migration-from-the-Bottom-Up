package generated.test;

import java.awt.Graphics;
import java.io.File;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.plaf.multi.MultiFileChooserUI;
import org.junit.jupiter.api.Test;

public class MultiFileChooserUIAutoTest {
  @Test
  public void getAcceptAllFileFilter_test_9361(JFileChooser p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getAcceptAllFileFilter(p0);
  }

  @Test
  public void ensureFileIsVisible_test_9362(JFileChooser p0, File p1) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.ensureFileIsVisible(p0, p1);
  }

  @Test
  public void rescanCurrentDirectory_test_9363(JFileChooser p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.rescanCurrentDirectory(p0);
  }

  @Test
  public void getDialogTitle_test_9364(JFileChooser p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getDialogTitle(p0);
  }

  @Test
  public void getFileView_test_9365(JFileChooser p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getFileView(p0);
  }

  @Test
  public void installUI_test_9366(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9367(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getApproveButtonText_test_9368(JFileChooser p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getApproveButtonText(p0);
  }

  @Test
  public void getUIs_test_9369() {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9370(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    MultiFileChooserUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9371(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9372(Graphics p0, JComponent p1) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9373(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9374(JComponent p0, int p1) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9375(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9376(JComponent p0) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9377(Graphics p0, JComponent p1) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9378(JComponent p0, int p1, int p2) {
    MultiFileChooserUI instance = new MultiFileChooserUI();
    instance.contains(p0, p1, p2);
  }
}
