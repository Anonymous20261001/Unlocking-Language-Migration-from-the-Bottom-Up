package generated.test;

import java.lang.Object;
import javax.smartcardio.CommandAPDU;
import org.junit.jupiter.api.Test;

public class CommandAPDUAutoTest {
  @Test
  public void equals_test_6455(Object p0, byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6456(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_6457(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.hashCode();
  }

  @Test
  public void getBytes_test_6458(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getBytes();
  }

  @Test
  public void getData_test_6459(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getData();
  }

  @Test
  public void getCLA_test_6460(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getCLA();
  }

  @Test
  public void getINS_test_6461(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getINS();
  }

  @Test
  public void getP1_test_6462(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getP1();
  }

  @Test
  public void getP2_test_6463(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getP2();
  }

  @Test
  public void getNc_test_6464(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getNc();
  }

  @Test
  public void getNe_test_6465(byte[] c0) {
    CommandAPDU instance = new CommandAPDU(c0);
    instance.getNe();
  }
}
