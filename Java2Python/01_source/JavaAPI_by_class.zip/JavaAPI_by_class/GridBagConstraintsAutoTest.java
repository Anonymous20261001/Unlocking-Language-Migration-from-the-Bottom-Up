package generated.test;

import java.awt.GridBagConstraints;
import org.junit.jupiter.api.Test;

public class GridBagConstraintsAutoTest {
  @Test
  public void clone_test_316() {
    GridBagConstraints instance = new GridBagConstraints();
    instance.clone();
  }
}
