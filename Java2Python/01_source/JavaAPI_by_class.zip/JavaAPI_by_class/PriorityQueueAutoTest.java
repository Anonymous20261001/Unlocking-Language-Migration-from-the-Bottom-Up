package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.PriorityQueue;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class PriorityQueueAutoTest {
  @Test
  public void remove_test_3718(Object p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.remove(p0);
  }

  @Test
  public void size_test_3719() {
    PriorityQueue instance = new PriorityQueue();
    instance.size();
  }

  @Test
  public void clear_test_3720() {
    PriorityQueue instance = new PriorityQueue();
    instance.clear();
  }

  @Test
  public void add_test_3721(Object p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.add(p0);
  }

  @Test
  public void toArray_test_3722(Object[] p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_3723() {
    PriorityQueue instance = new PriorityQueue();
    instance.toArray();
  }

  @Test
  public void iterator_test_3724() {
    PriorityQueue instance = new PriorityQueue();
    instance.iterator();
  }

  @Test
  public void contains_test_3725(Object p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_3726() {
    PriorityQueue instance = new PriorityQueue();
    instance.spliterator();
  }

  @Test
  public void forEach_test_3727(Consumer p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.forEach(p0);
  }

  @Test
  public void peek_test_3728() {
    PriorityQueue instance = new PriorityQueue();
    instance.peek();
  }

  @Test
  public void removeIf_test_3729(Predicate p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.removeIf(p0);
  }

  @Test
  public void removeAll_test_3730(Collection p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_3731(Collection p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.retainAll(p0);
  }

  @Test
  public void comparator_test_3732() {
    PriorityQueue instance = new PriorityQueue();
    instance.comparator();
  }

  @Test
  public void poll_test_3733() {
    PriorityQueue instance = new PriorityQueue();
    instance.poll();
  }

  @Test
  public void offer_test_3734(Object p0) {
    PriorityQueue instance = new PriorityQueue();
    instance.offer(p0);
  }
}
