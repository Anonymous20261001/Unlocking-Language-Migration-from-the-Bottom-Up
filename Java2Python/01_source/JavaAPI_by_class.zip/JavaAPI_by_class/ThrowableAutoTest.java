package generated.test;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.StackTraceElement;
import java.lang.Throwable;
import org.junit.jupiter.api.Test;

public class ThrowableAutoTest {
  @Test
  public void printStackTrace_test_2358() {
    Throwable instance = new Throwable();
    instance.printStackTrace();
  }

  @Test
  public void printStackTrace_test_2359(PrintWriter p0) {
    Throwable instance = new Throwable();
    instance.printStackTrace(p0);
  }

  @Test
  public void printStackTrace_test_2360(PrintStream p0) {
    Throwable instance = new Throwable();
    instance.printStackTrace(p0);
  }

  @Test
  public void getStackTrace_test_2361() {
    Throwable instance = new Throwable();
    instance.getStackTrace();
  }

  @Test
  public void fillInStackTrace_test_2362() {
    Throwable instance = new Throwable();
    instance.fillInStackTrace();
  }

  @Test
  public void getCause_test_2363() {
    Throwable instance = new Throwable();
    instance.getCause();
  }

  @Test
  public void initCause_test_2364(Throwable p0) {
    Throwable instance = new Throwable();
    instance.initCause(p0);
  }

  @Test
  public void toString_test_2365() {
    Throwable instance = new Throwable();
    instance.toString();
  }

  @Test
  public void getMessage_test_2366() {
    Throwable instance = new Throwable();
    instance.getMessage();
  }

  @Test
  public void getSuppressed_test_2367() {
    Throwable instance = new Throwable();
    instance.getSuppressed();
  }

  @Test
  public void getLocalizedMessage_test_2368() {
    Throwable instance = new Throwable();
    instance.getLocalizedMessage();
  }

  @Test
  public void setStackTrace_test_2369(StackTraceElement[] p0) {
    Throwable instance = new Throwable();
    instance.setStackTrace(p0);
  }

  @Test
  public void addSuppressed_test_2370(Throwable p0) {
    Throwable instance = new Throwable();
    instance.addSuppressed(p0);
  }
}
