package generated.test;

import java.applet.Applet;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.RepaintManager;
import org.junit.jupiter.api.Test;

public class RepaintManagerAutoTest {
  @Test
  public void currentManager_test_8236(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    RepaintManager.currentManager(p0);
  }

  @Test
  public void currentManager_test_8237(Component p0) {
    RepaintManager instance = new RepaintManager();
    RepaintManager.currentManager(p0);
  }

  @Test
  public void isDoubleBufferingEnabled_test_8238() {
    RepaintManager instance = new RepaintManager();
    instance.isDoubleBufferingEnabled();
  }

  @Test
  public void addDirtyRegion_test_8239(Window p0, int p1, int p2, int p3, int p4) {
    RepaintManager instance = new RepaintManager();
    instance.addDirtyRegion(p0, p1, p2, p3, p4);
  }

  @Test
  public void addDirtyRegion_test_8240(JComponent p0, int p1, int p2, int p3, int p4) {
    RepaintManager instance = new RepaintManager();
    instance.addDirtyRegion(p0, p1, p2, p3, p4);
  }

  @Test
  public void addDirtyRegion_test_8241(Applet p0, int p1, int p2, int p3, int p4) {
    RepaintManager instance = new RepaintManager();
    instance.addDirtyRegion(p0, p1, p2, p3, p4);
  }

  @Test
  public void addInvalidComponent_test_8242(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.addInvalidComponent(p0);
  }

  @Test
  public void removeInvalidComponent_test_8243(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.removeInvalidComponent(p0);
  }

  @Test
  public void getDirtyRegion_test_8244(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.getDirtyRegion(p0);
  }

  @Test
  public void markCompletelyClean_test_8245(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.markCompletelyClean(p0);
  }

  @Test
  public void setCurrentManager_test_8246(RepaintManager p0) {
    RepaintManager instance = new RepaintManager();
    RepaintManager.setCurrentManager(p0);
  }

  @Test
  public void setDoubleBufferMaximumSize_test_8247(Dimension p0) {
    RepaintManager instance = new RepaintManager();
    instance.setDoubleBufferMaximumSize(p0);
  }

  @Test
  public void markCompletelyDirty_test_8248(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.markCompletelyDirty(p0);
  }

  @Test
  public void isCompletelyDirty_test_8249(JComponent p0) {
    RepaintManager instance = new RepaintManager();
    instance.isCompletelyDirty(p0);
  }

  @Test
  public void paintDirtyRegions_test_8250() {
    RepaintManager instance = new RepaintManager();
    instance.paintDirtyRegions();
  }

  @Test
  public void getOffscreenBuffer_test_8251(Component p0, int p1, int p2) {
    RepaintManager instance = new RepaintManager();
    instance.getOffscreenBuffer(p0, p1, p2);
  }

  @Test
  public void getVolatileOffscreenBuffer_test_8252(Component p0, int p1, int p2) {
    RepaintManager instance = new RepaintManager();
    instance.getVolatileOffscreenBuffer(p0, p1, p2);
  }

  @Test
  public void getDoubleBufferMaximumSize_test_8253() {
    RepaintManager instance = new RepaintManager();
    instance.getDoubleBufferMaximumSize();
  }

  @Test
  public void validateInvalidComponents_test_8254() {
    RepaintManager instance = new RepaintManager();
    instance.validateInvalidComponents();
  }

  @Test
  public void setDoubleBufferingEnabled_test_8255(boolean p0) {
    RepaintManager instance = new RepaintManager();
    instance.setDoubleBufferingEnabled(p0);
  }

  @Test
  public void toString_test_8256() {
    RepaintManager instance = new RepaintManager();
    instance.toString();
  }
}
