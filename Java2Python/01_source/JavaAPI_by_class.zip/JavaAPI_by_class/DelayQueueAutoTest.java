package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;

public class DelayQueueAutoTest {
  @Test
  public void drainTo_test_4448(Collection p0) {
    DelayQueue instance = new DelayQueue();
    instance.drainTo(p0);
  }

  @Test
  public void drainTo_test_4449(Collection p0, int p1) {
    DelayQueue instance = new DelayQueue();
    instance.drainTo(p0, p1);
  }

  @Test
  public void remainingCapacity_test_4450() {
    DelayQueue instance = new DelayQueue();
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4451() {
    DelayQueue instance = new DelayQueue();
    instance.remove();
  }

  @Test
  public void remove_test_4452(Object p0) {
    DelayQueue instance = new DelayQueue();
    instance.remove(p0);
  }

  @Test
  public void size_test_4453() {
    DelayQueue instance = new DelayQueue();
    instance.size();
  }

  @Test
  public void put_test_4454(Delayed p0) {
    DelayQueue instance = new DelayQueue();
    instance.put(p0);
  }

  @Test
  public void clear_test_4455() {
    DelayQueue instance = new DelayQueue();
    instance.clear();
  }

  @Test
  public void add_test_4456(Delayed p0) {
    DelayQueue instance = new DelayQueue();
    instance.add(p0);
  }

  @Test
  public void toArray_test_4457(Object[] p0) {
    DelayQueue instance = new DelayQueue();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4458() {
    DelayQueue instance = new DelayQueue();
    instance.toArray();
  }

  @Test
  public void iterator_test_4459() {
    DelayQueue instance = new DelayQueue();
    instance.iterator();
  }

  @Test
  public void peek_test_4460() {
    DelayQueue instance = new DelayQueue();
    instance.peek();
  }

  @Test
  public void poll_test_4461() {
    DelayQueue instance = new DelayQueue();
    instance.poll();
  }

  @Test
  public void offer_test_4462(Delayed p0, long p1, TimeUnit p2) {
    DelayQueue instance = new DelayQueue();
    instance.offer(p0, p1, p2);
  }

  @Test
  public void offer_test_4463(Delayed p0) {
    DelayQueue instance = new DelayQueue();
    instance.offer(p0);
  }
}
