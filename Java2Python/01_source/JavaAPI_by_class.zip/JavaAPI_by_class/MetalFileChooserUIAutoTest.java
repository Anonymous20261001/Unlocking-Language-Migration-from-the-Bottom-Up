package generated.test;

import java.io.File;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.event.ListSelectionEvent;
import javax.swing.plaf.metal.MetalFileChooserUI;
import org.junit.jupiter.api.Test;

public class MetalFileChooserUIAutoTest {
  @Test
  public void ensureFileIsVisible_test_9123(JFileChooser p0, File p1, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.ensureFileIsVisible(p0, p1);
  }

  @Test
  public void rescanCurrentDirectory_test_9124(JFileChooser p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.rescanCurrentDirectory(p0);
  }

  @Test
  public void createListSelectionListener_test_9125(JFileChooser p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.createListSelectionListener(p0);
  }

  @Test
  public void getDirectoryName_test_9126(JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.getDirectoryName();
  }

  @Test
  public void setDirectoryName_test_9127(String p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.setDirectoryName(p0);
  }

  @Test
  public void installUI_test_9128(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9129(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.uninstallUI(p0);
  }

  @Test
  public void valueChanged_test_9130(ListSelectionEvent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.valueChanged(p0);
  }

  @Test
  public void createUI_test_9131(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    MetalFileChooserUI.createUI(p0);
  }

  @Test
  public void installComponents_test_9132(JFileChooser p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.installComponents(p0);
  }

  @Test
  public void createPropertyChangeListener_test_9133(JFileChooser p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.createPropertyChangeListener(p0);
  }

  @Test
  public void uninstallComponents_test_9134(JFileChooser p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.uninstallComponents(p0);
  }

  @Test
  public void getMaximumSize_test_9135(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.getMaximumSize(p0);
  }

  @Test
  public void getPreferredSize_test_9136(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9137(JComponent p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.getMinimumSize(p0);
  }

  @Test
  public void setFileName_test_9138(String p0, JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.setFileName(p0);
  }

  @Test
  public void getFileName_test_9139(JFileChooser c0) {
    MetalFileChooserUI instance = new MetalFileChooserUI(c0);
    instance.getFileName();
  }
}
