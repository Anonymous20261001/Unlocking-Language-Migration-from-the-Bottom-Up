package generated.test;

import java.beans.Encoder;
import java.beans.ExceptionListener;
import java.beans.Expression;
import java.beans.PersistenceDelegate;
import java.beans.Statement;
import java.lang.Class;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class EncoderAutoTest {
  @Test
  public void getExceptionListener_test_1518() {
    Encoder instance = new Encoder();
    instance.getExceptionListener();
  }

  @Test
  public void writeExpression_test_1519(Expression p0) {
    Encoder instance = new Encoder();
    instance.writeExpression(p0);
  }

  @Test
  public void writeStatement_test_1520(Statement p0) {
    Encoder instance = new Encoder();
    instance.writeStatement(p0);
  }

  @Test
  public void getPersistenceDelegate_test_1521(Class p0) {
    Encoder instance = new Encoder();
    instance.getPersistenceDelegate(p0);
  }

  @Test
  public void setExceptionListener_test_1522(ExceptionListener p0) {
    Encoder instance = new Encoder();
    instance.setExceptionListener(p0);
  }

  @Test
  public void setPersistenceDelegate_test_1523(Class p0, PersistenceDelegate p1) {
    Encoder instance = new Encoder();
    instance.setPersistenceDelegate(p0, p1);
  }

  @Test
  public void remove_test_1524(Object p0) {
    Encoder instance = new Encoder();
    instance.remove(p0);
  }

  @Test
  public void get_test_1525(Object p0) {
    Encoder instance = new Encoder();
    instance.get(p0);
  }
}
