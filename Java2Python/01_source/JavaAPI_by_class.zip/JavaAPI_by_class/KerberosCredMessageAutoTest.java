package generated.test;

import java.lang.Object;
import javax.security.auth.kerberos.KerberosCredMessage;
import javax.security.auth.kerberos.KerberosPrincipal;
import org.junit.jupiter.api.Test;

public class KerberosCredMessageAutoTest {
  @Test
  public void equals_test_6370(Object p0, KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6371(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void hashCode_test_6372(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.hashCode();
  }

  @Test
  public void isDestroyed_test_6373(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.isDestroyed();
  }

  @Test
  public void destroy_test_6374(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.destroy();
  }

  @Test
  public void getEncoded_test_6375(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.getEncoded();
  }

  @Test
  public void getSender_test_6376(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.getSender();
  }

  @Test
  public void getRecipient_test_6377(KerberosPrincipal c0, KerberosPrincipal c1, byte[] c2) {
    KerberosCredMessage instance = new KerberosCredMessage(c0, c1, c2);
    instance.getRecipient();
  }
}
