package generated.test;

import java.security.spec.X509EncodedKeySpec;
import org.junit.jupiter.api.Test;

public class X509EncodedKeySpecAutoTest {
  @Test
  public void getEncoded_test_2931(byte[] c0) {
    X509EncodedKeySpec instance = new X509EncodedKeySpec(c0);
    instance.getEncoded();
  }

  @Test
  public void getFormat_test_2932(byte[] c0) {
    X509EncodedKeySpec instance = new X509EncodedKeySpec(c0);
    instance.getFormat();
  }
}
