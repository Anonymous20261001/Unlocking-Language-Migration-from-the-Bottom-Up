package generated.test;

import java.awt.Component;
import java.awt.Container;
import javax.swing.DefaultFocusManager;
import org.junit.jupiter.api.Test;

public class DefaultFocusManagerAutoTest {
  @Test
  public void compareTabOrder_test_6715(Component p0, Component p1) {
    DefaultFocusManager instance = new DefaultFocusManager();
    instance.compareTabOrder(p0, p1);
  }

  @Test
  public void getComponentAfter_test_6716(Container p0, Component p1) {
    DefaultFocusManager instance = new DefaultFocusManager();
    instance.getComponentAfter(p0, p1);
  }

  @Test
  public void getComponentBefore_test_6717(Container p0, Component p1) {
    DefaultFocusManager instance = new DefaultFocusManager();
    instance.getComponentBefore(p0, p1);
  }

  @Test
  public void getLastComponent_test_6718(Container p0) {
    DefaultFocusManager instance = new DefaultFocusManager();
    instance.getLastComponent(p0);
  }

  @Test
  public void getFirstComponent_test_6719(Container p0) {
    DefaultFocusManager instance = new DefaultFocusManager();
    instance.getFirstComponent(p0);
  }
}
