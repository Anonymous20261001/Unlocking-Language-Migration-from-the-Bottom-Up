package generated.test;

import javax.swing.JCheckBoxMenuItem;
import org.junit.jupiter.api.Test;

public class JCheckBoxMenuItemAutoTest {
  @Test
  public void getUIClassID_test_6869() {
    JCheckBoxMenuItem instance = new JCheckBoxMenuItem();
    instance.getUIClassID();
  }

  @Test
  public void getAccessibleContext_test_6870() {
    JCheckBoxMenuItem instance = new JCheckBoxMenuItem();
    instance.getAccessibleContext();
  }

  @Test
  public void getSelectedObjects_test_6871() {
    JCheckBoxMenuItem instance = new JCheckBoxMenuItem();
    instance.getSelectedObjects();
  }

  @Test
  public void getState_test_6872() {
    JCheckBoxMenuItem instance = new JCheckBoxMenuItem();
    instance.getState();
  }

  @Test
  public void setState_test_6873(boolean p0) {
    JCheckBoxMenuItem instance = new JCheckBoxMenuItem();
    instance.setState(p0);
  }
}
