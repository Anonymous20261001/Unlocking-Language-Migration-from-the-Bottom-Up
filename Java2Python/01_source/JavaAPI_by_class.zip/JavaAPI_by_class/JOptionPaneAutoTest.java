package generated.test;

import java.awt.Component;
import java.awt.Frame;
import java.lang.Object;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.plaf.OptionPaneUI;
import org.junit.jupiter.api.Test;

public class JOptionPaneAutoTest {
  @Test
  public void getUIClassID_test_7398() {
    JOptionPane instance = new JOptionPane();
    instance.getUIClassID();
  }

  @Test
  public void getUI_test_7399() {
    JOptionPane instance = new JOptionPane();
    instance.getUI();
  }

  @Test
  public void setUI_test_7400(OptionPaneUI p0) {
    JOptionPane instance = new JOptionPane();
    instance.setUI(p0);
  }

  @Test
  public void showInternalMessageDialog_test_7401(Component p0, Object p1, String p2, int p3) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalMessageDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInternalMessageDialog_test_7402(Component p0, Object p1) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalMessageDialog(p0, p1);
  }

  @Test
  public void showInternalMessageDialog_test_7403(Component p0, Object p1, String p2, int p3,
      Icon p4) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalMessageDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showInternalOptionDialog_test_7404(Component p0, Object p1, String p2, int p3, int p4,
      Icon p5, Object[] p6, Object p7) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void showInternalConfirmDialog_test_7405(Component p0, Object p1) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalConfirmDialog(p0, p1);
  }

  @Test
  public void showInternalConfirmDialog_test_7406(Component p0, Object p1, String p2, int p3) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3);
  }

  @Test
  public void showInternalConfirmDialog_test_7407(Component p0, Object p1, String p2, int p3,
      int p4) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4);
  }

  @Test
  public void showInternalConfirmDialog_test_7408(Component p0, Object p1, String p2, int p3,
      int p4, Icon p5) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void createInternalFrame_test_7409(Component p0, String p1) {
    JOptionPane instance = new JOptionPane();
    instance.createInternalFrame(p0, p1);
  }

  @Test
  public void showInternalInputDialog_test_7410(Component p0, Object p1, String p2, int p3, Icon p4,
      Object[] p5, Object p6) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalInputDialog(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void showInternalInputDialog_test_7411(Component p0, Object p1) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalInputDialog(p0, p1);
  }

  @Test
  public void showInternalInputDialog_test_7412(Component p0, Object p1, String p2, int p3) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInternalInputDialog(p0, p1, p2, p3);
  }

  @Test
  public void getDesktopPaneForComponent_test_7413(Component p0) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.getDesktopPaneForComponent(p0);
  }

  @Test
  public void setMessageType_test_7414(int p0) {
    JOptionPane instance = new JOptionPane();
    instance.setMessageType(p0);
  }

  @Test
  public void setOptionType_test_7415(int p0) {
    JOptionPane instance = new JOptionPane();
    instance.setOptionType(p0);
  }

  @Test
  public void setRootFrame_test_7416(Frame p0) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.setRootFrame(p0);
  }

  @Test
  public void setOptions_test_7417(Object[] p0) {
    JOptionPane instance = new JOptionPane();
    instance.setOptions(p0);
  }

  @Test
  public void getInitialValue_test_7418() {
    JOptionPane instance = new JOptionPane();
    instance.getInitialValue();
  }

  @Test
  public void getSelectionValues_test_7419() {
    JOptionPane instance = new JOptionPane();
    instance.getSelectionValues();
  }

  @Test
  public void getInitialSelectionValue_test_7420() {
    JOptionPane instance = new JOptionPane();
    instance.getInitialSelectionValue();
  }

  @Test
  public void setInputValue_test_7421(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInputValue(p0);
  }

  @Test
  public void getMaxCharactersPerLineCount_test_7422() {
    JOptionPane instance = new JOptionPane();
    instance.getMaxCharactersPerLineCount();
  }

  @Test
  public void getWantsInput_test_7423() {
    JOptionPane instance = new JOptionPane();
    instance.getWantsInput();
  }

  @Test
  public void setIcon_test_7424(Icon p0) {
    JOptionPane instance = new JOptionPane();
    instance.setIcon(p0);
  }

  @Test
  public void showInputDialog_test_7425(Object p0, Object p1) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInputDialog(p0, p1);
  }

  @Test
  public void showInputDialog_test_7426(Component p0, Object p1, Object p2) {
    JOptionPane instance = new JOptionPane();
    JOptionPane.showInputDialog(p0, p1, p2);
  }

  @Test
  public void setWantsInput_test_7427(boolean p0) {
    JOptionPane instance = new JOptionPane();
    instance.setWantsInput(p0);
  }

  @Test
  public void setSelectionValues_test_7428(Object[] p0) {
    JOptionPane instance = new JOptionPane();
    instance.setSelectionValues(p0);
  }

  @Test
  public void setInitialSelectionValue_test_7429(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInitialSelectionValue(p0);
  }

  @Test
  public void selectInitialValue_test_7430() {
    JOptionPane instance = new JOptionPane();
    instance.selectInitialValue();
  }

  @Test
  public void getInputValue_test_7431() {
    JOptionPane instance = new JOptionPane();
    instance.getInputValue();
  }

  @Test
  public void getIcon_test_7432() {
    JOptionPane instance = new JOptionPane();
    instance.getIcon();
  }

  @Test
  public void setMessage_test_7433(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setMessage(p0);
  }

  @Test
  public void getMessageType_test_7434() {
    JOptionPane instance = new JOptionPane();
    instance.getMessageType();
  }

  @Test
  public void getOptionType_test_7435() {
    JOptionPane instance = new JOptionPane();
    instance.getOptionType();
  }

  @Test
  public void getOptions_test_7436() {
    JOptionPane instance = new JOptionPane();
    instance.getOptions();
  }

  @Test
  public void getAccessibleContext_test_7437() {
    JOptionPane instance = new JOptionPane();
    instance.getAccessibleContext();
  }

  @Test
  public void updateUI_test_7438() {
    JOptionPane instance = new JOptionPane();
    instance.updateUI();
  }

  @Test
  public void getValue_test_7439() {
    JOptionPane instance = new JOptionPane();
    instance.getValue();
  }

  @Test
  public void getMessage_test_7440() {
    JOptionPane instance = new JOptionPane();
    instance.getMessage();
  }

  @Test
  public void setValue_test_7441(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setValue(p0);
  }

  @Test
  public void setInitialValue_test_7442(Object p0) {
    JOptionPane instance = new JOptionPane();
    instance.setInitialValue(p0);
  }
}
