package generated.test;

import java.lang.Object;
import java.net.URI;
import javax.print.attribute.standard.PrinterMoreInfo;
import org.junit.jupiter.api.Test;

public class PrinterMoreInfoAutoTest {
  @Test
  public void getCategory_test_6222(URI c0) {
    PrinterMoreInfo instance = new PrinterMoreInfo(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6223(URI c0) {
    PrinterMoreInfo instance = new PrinterMoreInfo(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6224(Object p0, URI c0) {
    PrinterMoreInfo instance = new PrinterMoreInfo(c0);
    instance.equals(p0);
  }
}
