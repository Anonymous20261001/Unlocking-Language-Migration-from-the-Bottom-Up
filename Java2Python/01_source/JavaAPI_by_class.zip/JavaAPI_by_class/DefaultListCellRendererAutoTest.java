package generated.test;

import java.awt.Rectangle;
import java.lang.Object;
import java.lang.String;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import org.junit.jupiter.api.Test;

public class DefaultListCellRendererAutoTest {
  @Test
  public void getListCellRendererComponent_test_6720(JList p0, Object p1, int p2, boolean p3,
      boolean p4) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.getListCellRendererComponent(p0, p1, p2, p3, p4);
  }

  @Test
  public void firePropertyChange_test_6721(String p0, long p1, long p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6722(String p0, byte p1, byte p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6723(String p0, int p1, int p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6724(String p0, char p1, char p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6725(String p0, short p1, short p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6726(String p0, float p1, float p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6727(String p0, boolean p1, boolean p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_6728(String p0, double p1, double p2) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void repaint_test_6729() {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.repaint();
  }

  @Test
  public void repaint_test_6730(Rectangle p0) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.repaint(p0);
  }

  @Test
  public void repaint_test_6731(long p0, int p1, int p2, int p3, int p4) {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void revalidate_test_6732() {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.revalidate();
  }

  @Test
  public void validate_test_6733() {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.validate();
  }

  @Test
  public void isOpaque_test_6734() {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.isOpaque();
  }

  @Test
  public void invalidate_test_6735() {
    DefaultListCellRenderer instance = new DefaultListCellRenderer();
    instance.invalidate();
  }
}
