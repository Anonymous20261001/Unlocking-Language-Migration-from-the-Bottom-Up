package generated.test;

import java.awt.BufferCapabilities;
import java.awt.ImageCapabilities;
import org.junit.jupiter.api.Test;

public class BufferCapabilitiesAutoTest {
  @Test
  public void isPageFlipping_test_28(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.isPageFlipping();
  }

  @Test
  public void getFlipContents_test_29(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.getFlipContents();
  }

  @Test
  public void getFrontBufferCapabilities_test_30(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.getFrontBufferCapabilities();
  }

  @Test
  public void getBackBufferCapabilities_test_31(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.getBackBufferCapabilities();
  }

  @Test
  public void isFullScreenRequired_test_32(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.isFullScreenRequired();
  }

  @Test
  public void isMultiBufferAvailable_test_33(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.isMultiBufferAvailable();
  }

  @Test
  public void clone_test_34(ImageCapabilities c0, ImageCapabilities c1,
      BufferCapabilities.FlipContents c2) {
    BufferCapabilities instance = new BufferCapabilities(c0, c1, c2);
    instance.clone();
  }
}
