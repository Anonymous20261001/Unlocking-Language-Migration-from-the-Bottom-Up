package generated.test;

import java.lang.Object;
import javax.crypto.spec.RC2ParameterSpec;
import org.junit.jupiter.api.Test;

public class RC2ParameterSpecAutoTest {
  @Test
  public void getIV_test_5262(int c0) {
    RC2ParameterSpec instance = new RC2ParameterSpec(c0);
    instance.getIV();
  }

  @Test
  public void getEffectiveKeyBits_test_5263(int c0) {
    RC2ParameterSpec instance = new RC2ParameterSpec(c0);
    instance.getEffectiveKeyBits();
  }

  @Test
  public void equals_test_5264(Object p0, int c0) {
    RC2ParameterSpec instance = new RC2ParameterSpec(c0);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5265(int c0) {
    RC2ParameterSpec instance = new RC2ParameterSpec(c0);
    instance.hashCode();
  }
}
