package generated.test;

import java.lang.String;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Element;
import javax.swing.text.Style;
import org.junit.jupiter.api.Test;

public class DefaultStyledDocumentAutoTest {
  @Test
  public void removeDocumentListener_test_10226(DocumentListener p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.removeDocumentListener(p0);
  }

  @Test
  public void addDocumentListener_test_10227(DocumentListener p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.addDocumentListener(p0);
  }

  @Test
  public void getDefaultRootElement_test_10228() {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getDefaultRootElement();
  }

  @Test
  public void addStyle_test_10229(String p0, Style p1) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.addStyle(p0, p1);
  }

  @Test
  public void removeStyle_test_10230(String p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.removeStyle(p0);
  }

  @Test
  public void setLogicalStyle_test_10231(int p0, Style p1) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.setLogicalStyle(p0, p1);
  }

  @Test
  public void getLogicalStyle_test_10232(int p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getLogicalStyle(p0);
  }

  @Test
  public void getCharacterElement_test_10233(int p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getCharacterElement(p0);
  }

  @Test
  public void setCharacterAttributes_test_10234(int p0, int p1, AttributeSet p2, boolean p3) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.setCharacterAttributes(p0, p1, p2, p3);
  }

  @Test
  public void getParagraphElement_test_10235(int p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getParagraphElement(p0);
  }

  @Test
  public void setParagraphAttributes_test_10236(int p0, int p1, AttributeSet p2, boolean p3) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.setParagraphAttributes(p0, p1, p2, p3);
  }

  @Test
  public void getStyleNames_test_10237() {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getStyleNames();
  }

  @Test
  public void getFont_test_10238(AttributeSet p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getFont(p0);
  }

  @Test
  public void getForeground_test_10239(AttributeSet p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getForeground(p0);
  }

  @Test
  public void getBackground_test_10240(AttributeSet p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getBackground(p0);
  }

  @Test
  public void removeElement_test_10241(Element p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.removeElement(p0);
  }

  @Test
  public void getStyle_test_10242(String p0) {
    DefaultStyledDocument instance = new DefaultStyledDocument();
    instance.getStyle(p0);
  }
}
