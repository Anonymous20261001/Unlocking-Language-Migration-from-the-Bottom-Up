package generated.test;

import java.lang.Object;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import org.junit.jupiter.api.Test;

public class HashMapAutoTest {
  @Test
  public void remove_test_3478(Object p0) {
    HashMap instance = new HashMap();
    instance.remove(p0);
  }

  @Test
  public void remove_test_3479(Object p0, Object p1) {
    HashMap instance = new HashMap();
    instance.remove(p0, p1);
  }

  @Test
  public void size_test_3480() {
    HashMap instance = new HashMap();
    instance.size();
  }

  @Test
  public void get_test_3481(Object p0) {
    HashMap instance = new HashMap();
    instance.get(p0);
  }

  @Test
  public void put_test_3482(Object p0, Object p1) {
    HashMap instance = new HashMap();
    instance.put(p0, p1);
  }

  @Test
  public void values_test_3483() {
    HashMap instance = new HashMap();
    instance.values();
  }

  @Test
  public void clone_test_3484() {
    HashMap instance = new HashMap();
    instance.clone();
  }

  @Test
  public void clear_test_3485() {
    HashMap instance = new HashMap();
    instance.clear();
  }

  @Test
  public void isEmpty_test_3486() {
    HashMap instance = new HashMap();
    instance.isEmpty();
  }

  @Test
  public void replace_test_3487(Object p0, Object p1) {
    HashMap instance = new HashMap();
    instance.replace(p0, p1);
  }

  @Test
  public void replace_test_3488(Object p0, Object p1, Object p2) {
    HashMap instance = new HashMap();
    instance.replace(p0, p1, p2);
  }

  @Test
  public void replaceAll_test_3489(BiFunction p0) {
    HashMap instance = new HashMap();
    instance.replaceAll(p0);
  }

  @Test
  public void merge_test_3490(Object p0, Object p1, BiFunction p2) {
    HashMap instance = new HashMap();
    instance.merge(p0, p1, p2);
  }

  @Test
  public void newHashMap_test_3491(int p0) {
    HashMap instance = new HashMap();
    HashMap.newHashMap(p0);
  }

  @Test
  public void entrySet_test_3492() {
    HashMap instance = new HashMap();
    instance.entrySet();
  }

  @Test
  public void putAll_test_3493(Map p0) {
    HashMap instance = new HashMap();
    instance.putAll(p0);
  }

  @Test
  public void putIfAbsent_test_3494(Object p0, Object p1) {
    HashMap instance = new HashMap();
    instance.putIfAbsent(p0, p1);
  }

  @Test
  public void compute_test_3495(Object p0, BiFunction p1) {
    HashMap instance = new HashMap();
    instance.compute(p0, p1);
  }

  @Test
  public void computeIfAbsent_test_3496(Object p0, Function p1) {
    HashMap instance = new HashMap();
    instance.computeIfAbsent(p0, p1);
  }

  @Test
  public void forEach_test_3497(BiConsumer p0) {
    HashMap instance = new HashMap();
    instance.forEach(p0);
  }

  @Test
  public void keySet_test_3498() {
    HashMap instance = new HashMap();
    instance.keySet();
  }

  @Test
  public void containsValue_test_3499(Object p0) {
    HashMap instance = new HashMap();
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_3500(Object p0) {
    HashMap instance = new HashMap();
    instance.containsKey(p0);
  }

  @Test
  public void getOrDefault_test_3501(Object p0, Object p1) {
    HashMap instance = new HashMap();
    instance.getOrDefault(p0, p1);
  }

  @Test
  public void computeIfPresent_test_3502(Object p0, BiFunction p1) {
    HashMap instance = new HashMap();
    instance.computeIfPresent(p0, p1);
  }
}
