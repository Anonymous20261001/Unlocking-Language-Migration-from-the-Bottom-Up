package generated.test;

import java.awt.image.ColorModel;
import java.awt.image.CropImageFilter;
import java.util.Hashtable;
import org.junit.jupiter.api.Test;

public class CropImageFilterAutoTest {
  @Test
  public void setPixels_test_1179(int p0, int p1, int p2, int p3, ColorModel p4, int[] p5, int p6,
      int p7, int c0, int c1, int c2, int c3) {
    CropImageFilter instance = new CropImageFilter(c0, c1, c2, c3);
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setPixels_test_1180(int p0, int p1, int p2, int p3, ColorModel p4, byte[] p5, int p6,
      int p7, int c0, int c1, int c2, int c3) {
    CropImageFilter instance = new CropImageFilter(c0, c1, c2, c3);
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
  }

  @Test
  public void setDimensions_test_1181(int p0, int p1, int c0, int c1, int c2, int c3) {
    CropImageFilter instance = new CropImageFilter(c0, c1, c2, c3);
    instance.setDimensions(p0, p1);
  }

  @Test
  public void setProperties_test_1182(Hashtable p0, int c0, int c1, int c2, int c3) {
    CropImageFilter instance = new CropImageFilter(c0, c1, c2, c3);
    instance.setProperties(p0);
  }
}
