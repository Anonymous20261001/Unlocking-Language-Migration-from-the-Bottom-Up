package generated.test;

import java.lang.CharSequence;
import java.lang.String;
import java.time.format.DateTimeParseException;
import org.junit.jupiter.api.Test;

public class DateTimeParseExceptionAutoTest {
  @Test
  public void getParsedString_test_3275(String c0, CharSequence c1, int c2) {
    DateTimeParseException instance = new DateTimeParseException(c0, c1, c2);
    instance.getParsedString();
  }

  @Test
  public void getErrorIndex_test_3276(String c0, CharSequence c1, int c2) {
    DateTimeParseException instance = new DateTimeParseException(c0, c1, c2);
    instance.getErrorIndex();
  }
}
