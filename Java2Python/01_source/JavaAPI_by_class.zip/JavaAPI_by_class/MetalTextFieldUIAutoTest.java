package generated.test;

import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalTextFieldUI;
import org.junit.jupiter.api.Test;

public class MetalTextFieldUIAutoTest {
  @Test
  public void propertyChange_test_9273(PropertyChangeEvent p0) {
    MetalTextFieldUI instance = new MetalTextFieldUI();
    instance.propertyChange(p0);
  }

  @Test
  public void createUI_test_9274(JComponent p0) {
    MetalTextFieldUI instance = new MetalTextFieldUI();
    MetalTextFieldUI.createUI(p0);
  }
}
