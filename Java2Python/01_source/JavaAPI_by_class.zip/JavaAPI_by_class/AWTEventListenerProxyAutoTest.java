package generated.test;

import java.awt.AWTEvent;
import java.awt.event.AWTEventListener;
import java.awt.event.AWTEventListenerProxy;
import org.junit.jupiter.api.Test;

public class AWTEventListenerProxyAutoTest {
  @Test
  public void eventDispatched_test_739(AWTEvent p0, long c0, AWTEventListener c1) {
    AWTEventListenerProxy instance = new AWTEventListenerProxy(c0, c1);
    instance.eventDispatched(p0);
  }

  @Test
  public void getEventMask_test_740(long c0, AWTEventListener c1) {
    AWTEventListenerProxy instance = new AWTEventListenerProxy(c0, c1);
    instance.getEventMask();
  }
}
