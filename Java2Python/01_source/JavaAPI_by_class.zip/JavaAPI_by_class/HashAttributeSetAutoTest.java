package generated.test;

import java.lang.Class;
import java.lang.Object;
import javax.print.attribute.Attribute;
import javax.print.attribute.AttributeSet;
import javax.print.attribute.HashAttributeSet;
import org.junit.jupiter.api.Test;

public class HashAttributeSetAutoTest {
  @Test
  public void remove_test_6084(Class p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.remove(p0);
  }

  @Test
  public void remove_test_6085(Attribute p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.remove(p0);
  }

  @Test
  public void size_test_6086() {
    HashAttributeSet instance = new HashAttributeSet();
    instance.size();
  }

  @Test
  public void get_test_6087(Class p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.get(p0);
  }

  @Test
  public void equals_test_6088(Object p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_6089() {
    HashAttributeSet instance = new HashAttributeSet();
    instance.hashCode();
  }

  @Test
  public void clear_test_6090() {
    HashAttributeSet instance = new HashAttributeSet();
    instance.clear();
  }

  @Test
  public void isEmpty_test_6091() {
    HashAttributeSet instance = new HashAttributeSet();
    instance.isEmpty();
  }

  @Test
  public void add_test_6092(Attribute p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.add(p0);
  }

  @Test
  public void toArray_test_6093() {
    HashAttributeSet instance = new HashAttributeSet();
    instance.toArray();
  }

  @Test
  public void addAll_test_6094(AttributeSet p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.addAll(p0);
  }

  @Test
  public void containsValue_test_6095(Attribute p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.containsValue(p0);
  }

  @Test
  public void containsKey_test_6096(Class p0) {
    HashAttributeSet instance = new HashAttributeSet();
    instance.containsKey(p0);
  }
}
