package generated.test;

import java.awt.event.FocusEvent;
import javax.swing.JToggleButton;
import org.junit.jupiter.api.Test;

public class JToggleButtonAutoTest {
  @Test
  public void getUIClassID_test_7993() {
    JToggleButton instance = new JToggleButton();
    instance.getUIClassID();
  }

  @Test
  public void getAccessibleContext_test_7994() {
    JToggleButton instance = new JToggleButton();
    instance.getAccessibleContext();
  }

  @Test
  public void requestFocus_test_7995(FocusEvent.Cause p0) {
    JToggleButton instance = new JToggleButton();
    instance.requestFocus(p0);
  }

  @Test
  public void requestFocusInWindow_test_7996(FocusEvent.Cause p0) {
    JToggleButton instance = new JToggleButton();
    instance.requestFocusInWindow(p0);
  }

  @Test
  public void updateUI_test_7997() {
    JToggleButton instance = new JToggleButton();
    instance.updateUI();
  }
}
