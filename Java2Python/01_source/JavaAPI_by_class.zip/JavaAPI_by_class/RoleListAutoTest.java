package generated.test;

import java.lang.Object;
import java.util.Collection;
import javax.management.relation.RoleList;
import org.junit.jupiter.api.Test;

public class RoleListAutoTest {
  @Test
  public void add_test_5816(int p0, Object p1) {
    RoleList instance = new RoleList();
    instance.add(p0, p1);
  }

  @Test
  public void add_test_5817(Object p0) {
    RoleList instance = new RoleList();
    instance.add(p0);
  }

  @Test
  public void addAll_test_5818(Collection p0) {
    RoleList instance = new RoleList();
    instance.addAll(p0);
  }

  @Test
  public void addAll_test_5819(int p0, Collection p1) {
    RoleList instance = new RoleList();
    instance.addAll(p0, p1);
  }

  @Test
  public void set_test_5820(int p0, Object p1) {
    RoleList instance = new RoleList();
    instance.set(p0, p1);
  }

  @Test
  public void asList_test_5821() {
    RoleList instance = new RoleList();
    instance.asList();
  }
}
