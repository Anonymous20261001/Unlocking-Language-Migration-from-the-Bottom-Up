package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.text.AsyncBoxView;
import javax.swing.text.Element;
import javax.swing.text.Position;
import javax.swing.text.View;
import org.junit.jupiter.api.Test;

public class AsyncBoxViewAutoTest {
  @Test
  public void viewToModel_test_10106(float p0, float p1, Shape p2, Position.Bias[] p3, Element c0,
      int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.viewToModel(p0, p1, p2, p3);
  }

  @Test
  public void getViewCount_test_10107(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getViewCount();
  }

  @Test
  public void getLeftInset_test_10108(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getLeftInset();
  }

  @Test
  public void getRightInset_test_10109(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getRightInset();
  }

  @Test
  public void getTopInset_test_10110(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getTopInset();
  }

  @Test
  public void getBottomInset_test_10111(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getBottomInset();
  }

  @Test
  public void preferenceChanged_test_10112(View p0, boolean p1, boolean p2, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.preferenceChanged(p0, p1, p2);
  }

  @Test
  public void getViewIndex_test_10113(int p0, Position.Bias p1, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getViewIndex(p0, p1);
  }

  @Test
  public void getMajorAxis_test_10114(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getMajorAxis();
  }

  @Test
  public void getMinorAxis_test_10115(Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getMinorAxis();
  }

  @Test
  public void setTopInset_test_10116(float p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setTopInset(p0);
  }

  @Test
  public void setBottomInset_test_10117(float p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setBottomInset(p0);
  }

  @Test
  public void setLeftInset_test_10118(float p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setLeftInset(p0);
  }

  @Test
  public void setRightInset_test_10119(float p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setRightInset(p0);
  }

  @Test
  public void getChildAllocation_test_10120(int p0, Shape p1, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getChildAllocation(p0, p1);
  }

  @Test
  public void getView_test_10121(int p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getView(p0);
  }

  @Test
  public void getPreferredSpan_test_10122(int p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getPreferredSpan(p0);
  }

  @Test
  public void getMinimumSpan_test_10123(int p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getMinimumSpan(p0);
  }

  @Test
  public void getMaximumSpan_test_10124(int p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.getMaximumSpan(p0);
  }

  @Test
  public void paint_test_10125(Graphics p0, Shape p1, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.paint(p0, p1);
  }

  @Test
  public void replace_test_10126(int p0, int p1, View[] p2, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.replace(p0, p1, p2);
  }

  @Test
  public void setParent_test_10127(View p0, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setParent(p0);
  }

  @Test
  public void setSize_test_10128(float p0, float p1, Element c0, int c1) {
    AsyncBoxView instance = new AsyncBoxView(c0, c1);
    instance.setSize(p0, p1);
  }
}
