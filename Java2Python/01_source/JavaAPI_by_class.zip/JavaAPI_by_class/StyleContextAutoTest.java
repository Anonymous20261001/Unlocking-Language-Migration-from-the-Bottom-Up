package generated.test;

import java.awt.Font;
import java.lang.Object;
import java.lang.String;
import java.util.Enumeration;
import javax.swing.event.ChangeListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleContext;
import org.junit.jupiter.api.Test;

public class StyleContextAutoTest {
  @Test
  public void removeAttributes_test_10377(AttributeSet p0, Enumeration p1) {
    StyleContext instance = new StyleContext();
    instance.removeAttributes(p0, p1);
  }

  @Test
  public void removeAttributes_test_10378(AttributeSet p0, AttributeSet p1) {
    StyleContext instance = new StyleContext();
    instance.removeAttributes(p0, p1);
  }

  @Test
  public void addStyle_test_10379(String p0, Style p1) {
    StyleContext instance = new StyleContext();
    instance.addStyle(p0, p1);
  }

  @Test
  public void removeStyle_test_10380(String p0) {
    StyleContext instance = new StyleContext();
    instance.removeStyle(p0);
  }

  @Test
  public void removeAttribute_test_10381(AttributeSet p0, Object p1) {
    StyleContext instance = new StyleContext();
    instance.removeAttribute(p0, p1);
  }

  @Test
  public void getStyleNames_test_10382() {
    StyleContext instance = new StyleContext();
    instance.getStyleNames();
  }

  @Test
  public void getDefaultStyleContext_test_10383() {
    StyleContext instance = new StyleContext();
    StyleContext.getDefaultStyleContext();
  }

  @Test
  public void addChangeListener_test_10384(ChangeListener p0) {
    StyleContext instance = new StyleContext();
    instance.addChangeListener(p0);
  }

  @Test
  public void removeChangeListener_test_10385(ChangeListener p0) {
    StyleContext instance = new StyleContext();
    instance.removeChangeListener(p0);
  }

  @Test
  public void getChangeListeners_test_10386() {
    StyleContext instance = new StyleContext();
    instance.getChangeListeners();
  }

  @Test
  public void reclaim_test_10387(AttributeSet p0) {
    StyleContext instance = new StyleContext();
    instance.reclaim(p0);
  }

  @Test
  public void registerStaticAttributeKey_test_10388(Object p0) {
    StyleContext instance = new StyleContext();
    StyleContext.registerStaticAttributeKey(p0);
  }

  @Test
  public void getEmptySet_test_10389() {
    StyleContext instance = new StyleContext();
    instance.getEmptySet();
  }

  @Test
  public void getStaticAttribute_test_10390(Object p0) {
    StyleContext instance = new StyleContext();
    StyleContext.getStaticAttribute(p0);
  }

  @Test
  public void getStaticAttributeKey_test_10391(Object p0) {
    StyleContext instance = new StyleContext();
    StyleContext.getStaticAttributeKey(p0);
  }

  @Test
  public void addAttributes_test_10392(AttributeSet p0, AttributeSet p1) {
    StyleContext instance = new StyleContext();
    instance.addAttributes(p0, p1);
  }

  @Test
  public void getFont_test_10393(AttributeSet p0) {
    StyleContext instance = new StyleContext();
    instance.getFont(p0);
  }

  @Test
  public void getFont_test_10394(String p0, int p1, int p2) {
    StyleContext instance = new StyleContext();
    instance.getFont(p0, p1, p2);
  }

  @Test
  public void getForeground_test_10395(AttributeSet p0) {
    StyleContext instance = new StyleContext();
    instance.getForeground(p0);
  }

  @Test
  public void getBackground_test_10396(AttributeSet p0) {
    StyleContext instance = new StyleContext();
    instance.getBackground(p0);
  }

  @Test
  public void getFontMetrics_test_10397(Font p0) {
    StyleContext instance = new StyleContext();
    instance.getFontMetrics(p0);
  }

  @Test
  public void getStyle_test_10398(String p0) {
    StyleContext instance = new StyleContext();
    instance.getStyle(p0);
  }

  @Test
  public void toString_test_10399() {
    StyleContext instance = new StyleContext();
    instance.toString();
  }

  @Test
  public void addAttribute_test_10400(AttributeSet p0, Object p1, Object p2) {
    StyleContext instance = new StyleContext();
    instance.addAttribute(p0, p1, p2);
  }
}
