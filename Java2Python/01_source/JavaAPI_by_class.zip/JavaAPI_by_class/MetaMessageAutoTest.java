package generated.test;

import javax.sound.midi.MetaMessage;
import org.junit.jupiter.api.Test;

public class MetaMessageAutoTest {
  @Test
  public void clone_test_6475() {
    MetaMessage instance = new MetaMessage();
    instance.clone();
  }

  @Test
  public void getType_test_6476() {
    MetaMessage instance = new MetaMessage();
    instance.getType();
  }

  @Test
  public void getData_test_6477() {
    MetaMessage instance = new MetaMessage();
    instance.getData();
  }
}
