package generated.test;

import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;
import org.junit.jupiter.api.Test;

public class AtomicIntegerArrayAutoTest {
  @Test
  public void get_test_4786(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.get(p0);
  }

  @Test
  public void length_test_4787(int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.length();
  }

  @Test
  public void toString_test_4788(int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.toString();
  }

  @Test
  public void set_test_4789(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.set(p0, p1);
  }

  @Test
  public void getOpaque_test_4790(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getOpaque(p0);
  }

  @Test
  public void setOpaque_test_4791(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.setOpaque(p0, p1);
  }

  @Test
  public void getAcquire_test_4792(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAcquire(p0);
  }

  @Test
  public void setRelease_test_4793(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.setRelease(p0, p1);
  }

  @Test
  public void compareAndSet_test_4794(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.compareAndSet(p0, p1, p2);
  }

  @Test
  public void compareAndExchange_test_4795(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.compareAndExchange(p0, p1, p2);
  }

  @Test
  public void compareAndExchangeAcquire_test_4796(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.compareAndExchangeAcquire(p0, p1, p2);
  }

  @Test
  public void compareAndExchangeRelease_test_4797(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.compareAndExchangeRelease(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetPlain_test_4798(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.weakCompareAndSetPlain(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSet_test_4799(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.weakCompareAndSet(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetAcquire_test_4800(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.weakCompareAndSetAcquire(p0, p1, p2);
  }

  @Test
  public void weakCompareAndSetRelease_test_4801(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.weakCompareAndSetRelease(p0, p1, p2);
  }

  @Test
  public void getAndSet_test_4802(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndSet(p0, p1);
  }

  @Test
  public void getAndAdd_test_4803(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndAdd(p0, p1);
  }

  @Test
  public void incrementAndGet_test_4804(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.incrementAndGet(p0);
  }

  @Test
  public void weakCompareAndSetVolatile_test_4805(int p0, int p1, int p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.weakCompareAndSetVolatile(p0, p1, p2);
  }

  @Test
  public void lazySet_test_4806(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.lazySet(p0, p1);
  }

  @Test
  public void getAndIncrement_test_4807(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndIncrement(p0);
  }

  @Test
  public void getAndDecrement_test_4808(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndDecrement(p0);
  }

  @Test
  public void decrementAndGet_test_4809(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.decrementAndGet(p0);
  }

  @Test
  public void addAndGet_test_4810(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.addAndGet(p0, p1);
  }

  @Test
  public void getAndUpdate_test_4811(int p0, IntUnaryOperator p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndUpdate(p0, p1);
  }

  @Test
  public void updateAndGet_test_4812(int p0, IntUnaryOperator p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.updateAndGet(p0, p1);
  }

  @Test
  public void getAndAccumulate_test_4813(int p0, int p1, IntBinaryOperator p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getAndAccumulate(p0, p1, p2);
  }

  @Test
  public void accumulateAndGet_test_4814(int p0, int p1, IntBinaryOperator p2, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.accumulateAndGet(p0, p1, p2);
  }

  @Test
  public void getPlain_test_4815(int p0, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.getPlain(p0);
  }

  @Test
  public void setPlain_test_4816(int p0, int p1, int c0) {
    AtomicIntegerArray instance = new AtomicIntegerArray(c0);
    instance.setPlain(p0, p1);
  }
}
