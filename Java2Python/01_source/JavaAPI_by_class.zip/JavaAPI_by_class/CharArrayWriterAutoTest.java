package generated.test;

import java.io.CharArrayWriter;
import java.lang.CharSequence;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class CharArrayWriterAutoTest {
  @Test
  public void size_test_1717() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.size();
  }

  @Test
  public void reset_test_1718() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.reset();
  }

  @Test
  public void toString_test_1719() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.toString();
  }

  @Test
  public void append_test_1720(CharSequence p0) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.append(p0);
  }

  @Test
  public void append_test_1721(CharSequence p0, int p1, int p2) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_1722(char p0) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.append(p0);
  }

  @Test
  public void flush_test_1723() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.flush();
  }

  @Test
  public void toCharArray_test_1724() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.toCharArray();
  }

  @Test
  public void write_test_1725(char[] p0, int p1, int p2) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.write(p0, p1, p2);
  }

  @Test
  public void write_test_1726(String p0, int p1, int p2) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.write(p0, p1, p2);
  }

  @Test
  public void write_test_1727(int p0) {
    CharArrayWriter instance = new CharArrayWriter();
    instance.write(p0);
  }

  @Test
  public void close_test_1728() {
    CharArrayWriter instance = new CharArrayWriter();
    instance.close();
  }
}
