package generated.test;

import javax.imageio.plugins.jpeg.JPEGQTable;
import org.junit.jupiter.api.Test;

public class JPEGQTableAutoTest {
  @Test
  public void getScaledInstance_test_5413(float p0, boolean p1, int[] c0) {
    JPEGQTable instance = new JPEGQTable(c0);
    instance.getScaledInstance(p0, p1);
  }

  @Test
  public void toString_test_5414(int[] c0) {
    JPEGQTable instance = new JPEGQTable(c0);
    instance.toString();
  }

  @Test
  public void getTable_test_5415(int[] c0) {
    JPEGQTable instance = new JPEGQTable(c0);
    instance.getTable();
  }
}
