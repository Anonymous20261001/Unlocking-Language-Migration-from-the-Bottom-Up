package generated.test;

import java.lang.String;
import java.util.MissingFormatWidthException;
import org.junit.jupiter.api.Test;

public class MissingFormatWidthExceptionAutoTest {
  @Test
  public void getFormatSpecifier_test_3707(String c0) {
    MissingFormatWidthException instance = new MissingFormatWidthException(c0);
    instance.getFormatSpecifier();
  }

  @Test
  public void getMessage_test_3708(String c0) {
    MissingFormatWidthException instance = new MissingFormatWidthException(c0);
    instance.getMessage();
  }
}
