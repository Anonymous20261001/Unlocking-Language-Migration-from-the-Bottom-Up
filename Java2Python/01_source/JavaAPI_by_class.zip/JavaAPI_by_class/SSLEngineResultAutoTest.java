package generated.test;

import javax.net.ssl.SSLEngineResult;
import org.junit.jupiter.api.Test;

public class SSLEngineResultAutoTest {
  @Test
  public void sequenceNumber_test_6038(SSLEngineResult.Status c0,
      SSLEngineResult.HandshakeStatus c1, int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.sequenceNumber();
  }

  @Test
  public void bytesConsumed_test_6039(SSLEngineResult.Status c0, SSLEngineResult.HandshakeStatus c1,
      int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.bytesConsumed();
  }

  @Test
  public void bytesProduced_test_6040(SSLEngineResult.Status c0, SSLEngineResult.HandshakeStatus c1,
      int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.bytesProduced();
  }

  @Test
  public void getHandshakeStatus_test_6041(SSLEngineResult.Status c0,
      SSLEngineResult.HandshakeStatus c1, int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.getHandshakeStatus();
  }

  @Test
  public void getStatus_test_6042(SSLEngineResult.Status c0, SSLEngineResult.HandshakeStatus c1,
      int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.getStatus();
  }

  @Test
  public void toString_test_6043(SSLEngineResult.Status c0, SSLEngineResult.HandshakeStatus c1,
      int c2, int c3) {
    SSLEngineResult instance = new SSLEngineResult(c0, c1, c2, c3);
    instance.toString();
  }
}
