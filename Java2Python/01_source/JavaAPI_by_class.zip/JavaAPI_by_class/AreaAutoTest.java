package generated.test;

import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import org.junit.jupiter.api.Test;

public class AreaAutoTest {
  @Test
  public void exclusiveOr_test_975(Area p0) {
    Area instance = new Area();
    instance.exclusiveOr(p0);
  }

  @Test
  public void isPolygonal_test_976() {
    Area instance = new Area();
    instance.isPolygonal();
  }

  @Test
  public void isRectangular_test_977() {
    Area instance = new Area();
    instance.isRectangular();
  }

  @Test
  public void isSingular_test_978() {
    Area instance = new Area();
    instance.isSingular();
  }

  @Test
  public void createTransformedArea_test_979(AffineTransform p0) {
    Area instance = new Area();
    instance.createTransformedArea(p0);
  }

  @Test
  public void getPathIterator_test_980(AffineTransform p0) {
    Area instance = new Area();
    instance.getPathIterator(p0);
  }

  @Test
  public void getPathIterator_test_981(AffineTransform p0, double p1) {
    Area instance = new Area();
    instance.getPathIterator(p0, p1);
  }

  @Test
  public void getBounds2D_test_982() {
    Area instance = new Area();
    instance.getBounds2D();
  }

  @Test
  public void reset_test_983() {
    Area instance = new Area();
    instance.reset();
  }

  @Test
  public void equals_test_984(Area p0) {
    Area instance = new Area();
    instance.equals(p0);
  }

  @Test
  public void clone_test_985() {
    Area instance = new Area();
    instance.clone();
  }

  @Test
  public void isEmpty_test_986() {
    Area instance = new Area();
    instance.isEmpty();
  }

  @Test
  public void add_test_987(Area p0) {
    Area instance = new Area();
    instance.add(p0);
  }

  @Test
  public void contains_test_988(Point2D p0) {
    Area instance = new Area();
    instance.contains(p0);
  }

  @Test
  public void contains_test_989(double p0, double p1, double p2, double p3) {
    Area instance = new Area();
    instance.contains(p0, p1, p2, p3);
  }

  @Test
  public void contains_test_990(double p0, double p1) {
    Area instance = new Area();
    instance.contains(p0, p1);
  }

  @Test
  public void contains_test_991(Rectangle2D p0) {
    Area instance = new Area();
    instance.contains(p0);
  }

  @Test
  public void transform_test_992(AffineTransform p0) {
    Area instance = new Area();
    instance.transform(p0);
  }

  @Test
  public void getBounds_test_993() {
    Area instance = new Area();
    instance.getBounds();
  }

  @Test
  public void subtract_test_994(Area p0) {
    Area instance = new Area();
    instance.subtract(p0);
  }

  @Test
  public void intersects_test_995(Rectangle2D p0) {
    Area instance = new Area();
    instance.intersects(p0);
  }

  @Test
  public void intersects_test_996(double p0, double p1, double p2, double p3) {
    Area instance = new Area();
    instance.intersects(p0, p1, p2, p3);
  }

  @Test
  public void intersect_test_997(Area p0) {
    Area instance = new Area();
    instance.intersect(p0);
  }
}
