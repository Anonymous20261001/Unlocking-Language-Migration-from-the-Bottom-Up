package generated.test;

import java.awt.Font;
import java.awt.Rectangle;
import java.lang.String;
import javax.swing.JTextArea;
import org.junit.jupiter.api.Test;

public class JTextAreaAutoTest {
  @Test
  public void getScrollableTracksViewportWidth_test_7932() {
    JTextArea instance = new JTextArea();
    instance.getScrollableTracksViewportWidth();
  }

  @Test
  public void getPreferredScrollableViewportSize_test_7933() {
    JTextArea instance = new JTextArea();
    instance.getPreferredScrollableViewportSize();
  }

  @Test
  public void getScrollableUnitIncrement_test_7934(Rectangle p0, int p1, int p2) {
    JTextArea instance = new JTextArea();
    instance.getScrollableUnitIncrement(p0, p1, p2);
  }

  @Test
  public void getUIClassID_test_7935() {
    JTextArea instance = new JTextArea();
    instance.getUIClassID();
  }

  @Test
  public void getTabSize_test_7936() {
    JTextArea instance = new JTextArea();
    instance.getTabSize();
  }

  @Test
  public void getLineCount_test_7937() {
    JTextArea instance = new JTextArea();
    instance.getLineCount();
  }

  @Test
  public void setTabSize_test_7938(int p0) {
    JTextArea instance = new JTextArea();
    instance.setTabSize(p0);
  }

  @Test
  public void setLineWrap_test_7939(boolean p0) {
    JTextArea instance = new JTextArea();
    instance.setLineWrap(p0);
  }

  @Test
  public void getLineWrap_test_7940() {
    JTextArea instance = new JTextArea();
    instance.getLineWrap();
  }

  @Test
  public void setWrapStyleWord_test_7941(boolean p0) {
    JTextArea instance = new JTextArea();
    instance.setWrapStyleWord(p0);
  }

  @Test
  public void getWrapStyleWord_test_7942() {
    JTextArea instance = new JTextArea();
    instance.getWrapStyleWord();
  }

  @Test
  public void getAccessibleContext_test_7943() {
    JTextArea instance = new JTextArea();
    instance.getAccessibleContext();
  }

  @Test
  public void setFont_test_7944(Font p0) {
    JTextArea instance = new JTextArea();
    instance.setFont(p0);
  }

  @Test
  public void getPreferredSize_test_7945() {
    JTextArea instance = new JTextArea();
    instance.getPreferredSize();
  }

  @Test
  public void getRows_test_7946() {
    JTextArea instance = new JTextArea();
    instance.getRows();
  }

  @Test
  public void setRows_test_7947(int p0) {
    JTextArea instance = new JTextArea();
    instance.setRows(p0);
  }

  @Test
  public void getColumns_test_7948() {
    JTextArea instance = new JTextArea();
    instance.getColumns();
  }

  @Test
  public void setColumns_test_7949(int p0) {
    JTextArea instance = new JTextArea();
    instance.setColumns(p0);
  }

  @Test
  public void replaceRange_test_7950(String p0, int p1, int p2) {
    JTextArea instance = new JTextArea();
    instance.replaceRange(p0, p1, p2);
  }

  @Test
  public void append_test_7951(String p0) {
    JTextArea instance = new JTextArea();
    instance.append(p0);
  }

  @Test
  public void insert_test_7952(String p0, int p1) {
    JTextArea instance = new JTextArea();
    instance.insert(p0, p1);
  }
}
