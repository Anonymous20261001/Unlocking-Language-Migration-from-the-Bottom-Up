package generated.test;

import java.security.cert.CertPathParameters;
import javax.net.ssl.CertPathTrustManagerParameters;
import org.junit.jupiter.api.Test;

public class CertPathTrustManagerParametersAutoTest {
  @Test
  public void getParameters_test_6026(CertPathParameters c0) {
    CertPathTrustManagerParameters instance = new CertPathTrustManagerParameters(c0);
    instance.getParameters();
  }
}
