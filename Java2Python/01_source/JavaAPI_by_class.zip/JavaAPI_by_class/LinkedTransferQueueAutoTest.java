package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class LinkedTransferQueueAutoTest {
  @Test
  public void tryTransfer_test_4574(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.tryTransfer(p0);
  }

  @Test
  public void hasWaitingConsumer_test_4575() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.hasWaitingConsumer();
  }

  @Test
  public void getWaitingConsumerCount_test_4576() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.getWaitingConsumerCount();
  }

  @Test
  public void drainTo_test_4577(Collection p0, int p1) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.drainTo(p0, p1);
  }

  @Test
  public void drainTo_test_4578(Collection p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.drainTo(p0);
  }

  @Test
  public void remainingCapacity_test_4579() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.remainingCapacity();
  }

  @Test
  public void remove_test_4580(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.remove(p0);
  }

  @Test
  public void size_test_4581() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.size();
  }

  @Test
  public void put_test_4582(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.put(p0);
  }

  @Test
  public void toString_test_4583() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.toString();
  }

  @Test
  public void clear_test_4584() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.clear();
  }

  @Test
  public void isEmpty_test_4585() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.isEmpty();
  }

  @Test
  public void add_test_4586(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.add(p0);
  }

  @Test
  public void toArray_test_4587(Object[] p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4588() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.toArray();
  }

  @Test
  public void iterator_test_4589() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.iterator();
  }

  @Test
  public void contains_test_4590(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4591() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.spliterator();
  }

  @Test
  public void forEach_test_4592(Consumer p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.forEach(p0);
  }

  @Test
  public void peek_test_4593() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.peek();
  }

  @Test
  public void removeIf_test_4594(Predicate p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.removeIf(p0);
  }

  @Test
  public void removeAll_test_4595(Collection p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4596(Collection p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.retainAll(p0);
  }

  @Test
  public void poll_test_4597() {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.poll();
  }

  @Test
  public void offer_test_4598(Object p0) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.offer(p0);
  }

  @Test
  public void offer_test_4599(Object p0, long p1, TimeUnit p2) {
    LinkedTransferQueue instance = new LinkedTransferQueue();
    instance.offer(p0, p1, p2);
  }
}
