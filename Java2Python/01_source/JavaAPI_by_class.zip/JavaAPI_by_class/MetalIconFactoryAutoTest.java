package generated.test;

import javax.swing.plaf.metal.MetalIconFactory;
import org.junit.jupiter.api.Test;

public class MetalIconFactoryAutoTest {
  @Test
  public void getMenuItemCheckIcon_test_9140() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getMenuItemCheckIcon();
  }

  @Test
  public void getMenuItemArrowIcon_test_9141() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getMenuItemArrowIcon();
  }

  @Test
  public void getMenuArrowIcon_test_9142() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getMenuArrowIcon();
  }

  @Test
  public void getCheckBoxIcon_test_9143() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getCheckBoxIcon();
  }

  @Test
  public void getRadioButtonIcon_test_9144() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getRadioButtonIcon();
  }

  @Test
  public void getCheckBoxMenuItemIcon_test_9145() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getCheckBoxMenuItemIcon();
  }

  @Test
  public void getRadioButtonMenuItemIcon_test_9146() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getRadioButtonMenuItemIcon();
  }

  @Test
  public void getFileChooserDetailViewIcon_test_9147() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getFileChooserDetailViewIcon();
  }

  @Test
  public void getFileChooserHomeFolderIcon_test_9148() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getFileChooserHomeFolderIcon();
  }

  @Test
  public void getFileChooserListViewIcon_test_9149() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getFileChooserListViewIcon();
  }

  @Test
  public void getFileChooserNewFolderIcon_test_9150() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getFileChooserNewFolderIcon();
  }

  @Test
  public void getFileChooserUpFolderIcon_test_9151() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getFileChooserUpFolderIcon();
  }

  @Test
  public void getInternalFrameAltMaximizeIcon_test_9152(int p0) {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getInternalFrameAltMaximizeIcon(p0);
  }

  @Test
  public void getInternalFrameCloseIcon_test_9153(int p0) {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getInternalFrameCloseIcon(p0);
  }

  @Test
  public void getInternalFrameDefaultMenuIcon_test_9154() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getInternalFrameDefaultMenuIcon();
  }

  @Test
  public void getInternalFrameMaximizeIcon_test_9155(int p0) {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getInternalFrameMaximizeIcon(p0);
  }

  @Test
  public void getInternalFrameMinimizeIcon_test_9156(int p0) {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getInternalFrameMinimizeIcon(p0);
  }

  @Test
  public void getTreeComputerIcon_test_9157() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeComputerIcon();
  }

  @Test
  public void getTreeFloppyDriveIcon_test_9158() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeFloppyDriveIcon();
  }

  @Test
  public void getTreeFolderIcon_test_9159() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeFolderIcon();
  }

  @Test
  public void getTreeHardDriveIcon_test_9160() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeHardDriveIcon();
  }

  @Test
  public void getTreeLeafIcon_test_9161() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeLeafIcon();
  }

  @Test
  public void getTreeControlIcon_test_9162(boolean p0) {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getTreeControlIcon(p0);
  }

  @Test
  public void getHorizontalSliderThumbIcon_test_9163() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getHorizontalSliderThumbIcon();
  }

  @Test
  public void getVerticalSliderThumbIcon_test_9164() {
    MetalIconFactory instance = new MetalIconFactory();
    MetalIconFactory.getVerticalSliderThumbIcon();
  }
}
