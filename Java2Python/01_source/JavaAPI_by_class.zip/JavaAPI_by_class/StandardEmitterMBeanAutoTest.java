package generated.test;

import java.lang.Class;
import java.lang.Object;
import javax.management.Notification;
import javax.management.NotificationEmitter;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;
import javax.management.StandardEmitterMBean;
import org.junit.jupiter.api.Test;

public class StandardEmitterMBeanAutoTest {
  @Test
  public void getNotificationInfo_test_5668(Object c0, Class c1, NotificationEmitter c2) {
    StandardEmitterMBean instance = new StandardEmitterMBean(c0, c1, c2);
    instance.getNotificationInfo();
  }

  @Test
  public void addNotificationListener_test_5669(NotificationListener p0, NotificationFilter p1,
      Object p2, Object c0, Class c1, NotificationEmitter c2) {
    StandardEmitterMBean instance = new StandardEmitterMBean(c0, c1, c2);
    instance.addNotificationListener(p0, p1, p2);
  }

  @Test
  public void sendNotification_test_5670(Notification p0, Object c0, Class c1,
      NotificationEmitter c2) {
    StandardEmitterMBean instance = new StandardEmitterMBean(c0, c1, c2);
    instance.sendNotification(p0);
  }
}
