package generated.test;

import java.lang.Object;
import java.lang.String;
import java.net.HttpCookie;
import org.junit.jupiter.api.Test;

public class HttpCookieAutoTest {
  @Test
  public void getSecure_test_2557(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getSecure();
  }

  @Test
  public void isHttpOnly_test_2558(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.isHttpOnly();
  }

  @Test
  public void getPortlist_test_2559(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getPortlist();
  }

  @Test
  public void setPath_test_2560(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setPath(p0);
  }

  @Test
  public void getDomain_test_2561(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getDomain();
  }

  @Test
  public void setDomain_test_2562(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setDomain(p0);
  }

  @Test
  public void setPortlist_test_2563(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setPortlist(p0);
  }

  @Test
  public void hasExpired_test_2564(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.hasExpired();
  }

  @Test
  public void setCommentURL_test_2565(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setCommentURL(p0);
  }

  @Test
  public void getCommentURL_test_2566(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getCommentURL();
  }

  @Test
  public void setDiscard_test_2567(boolean p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setDiscard(p0);
  }

  @Test
  public void getDiscard_test_2568(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getDiscard();
  }

  @Test
  public void setMaxAge_test_2569(long p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setMaxAge(p0);
  }

  @Test
  public void getMaxAge_test_2570(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getMaxAge();
  }

  @Test
  public void setSecure_test_2571(boolean p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setSecure(p0);
  }

  @Test
  public void setHttpOnly_test_2572(boolean p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setHttpOnly(p0);
  }

  @Test
  public void domainMatches_test_2573(String p0, String p1, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    HttpCookie.domainMatches(p0, p1);
  }

  @Test
  public void getName_test_2574(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_2575(Object p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2576(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.toString();
  }

  @Test
  public void hashCode_test_2577(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.hashCode();
  }

  @Test
  public void clone_test_2578(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.clone();
  }

  @Test
  public void getValue_test_2579(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getValue();
  }

  @Test
  public void setValue_test_2580(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setValue(p0);
  }

  @Test
  public void parse_test_2581(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    HttpCookie.parse(p0);
  }

  @Test
  public void getPath_test_2582(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getPath();
  }

  @Test
  public void setVersion_test_2583(int p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setVersion(p0);
  }

  @Test
  public void setComment_test_2584(String p0, String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.setComment(p0);
  }

  @Test
  public void getComment_test_2585(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getComment();
  }

  @Test
  public void getVersion_test_2586(String c0, String c1) {
    HttpCookie instance = new HttpCookie(c0, c1);
    instance.getVersion();
  }
}
