package generated.test;

import java.lang.String;
import java.nio.file.attribute.UserPrincipalNotFoundException;
import org.junit.jupiter.api.Test;

public class UserPrincipalNotFoundExceptionAutoTest {
  @Test
  public void getName_test_2656(String c0) {
    UserPrincipalNotFoundException instance = new UserPrincipalNotFoundException(c0);
    instance.getName();
  }
}
