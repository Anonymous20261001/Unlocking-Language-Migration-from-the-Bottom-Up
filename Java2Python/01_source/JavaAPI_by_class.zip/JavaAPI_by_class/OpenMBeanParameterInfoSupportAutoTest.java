package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.openmbean.OpenMBeanParameterInfoSupport;
import javax.management.openmbean.OpenType;
import org.junit.jupiter.api.Test;

public class OpenMBeanParameterInfoSupportAutoTest {
  @Test
  public void getOpenType_test_5767(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.getOpenType();
  }

  @Test
  public void isValue_test_5768(Object p0, String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.isValue(p0);
  }

  @Test
  public void hasDefaultValue_test_5769(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.hasDefaultValue();
  }

  @Test
  public void hasLegalValues_test_5770(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.hasLegalValues();
  }

  @Test
  public void hasMinValue_test_5771(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.hasMinValue();
  }

  @Test
  public void hasMaxValue_test_5772(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.hasMaxValue();
  }

  @Test
  public void getLegalValues_test_5773(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.getLegalValues();
  }

  @Test
  public void getMinValue_test_5774(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.getMinValue();
  }

  @Test
  public void getMaxValue_test_5775(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.getMaxValue();
  }

  @Test
  public void equals_test_5776(Object p0, String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5777(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void hashCode_test_5778(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.hashCode();
  }

  @Test
  public void getDefaultValue_test_5779(String c0, String c1, OpenType c2) {
    OpenMBeanParameterInfoSupport instance = new OpenMBeanParameterInfoSupport(c0, c1, c2);
    instance.getDefaultValue();
  }
}
