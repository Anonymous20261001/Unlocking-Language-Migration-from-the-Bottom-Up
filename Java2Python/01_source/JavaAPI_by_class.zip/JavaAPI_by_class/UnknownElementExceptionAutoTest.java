package generated.test;

import java.lang.Object;
import javax.lang.model.element.Element;
import javax.lang.model.element.UnknownElementException;
import org.junit.jupiter.api.Test;

public class UnknownElementExceptionAutoTest {
  @Test
  public void getArgument_test_5512(Element c0, Object c1) {
    UnknownElementException instance = new UnknownElementException(c0, c1);
    instance.getArgument();
  }

  @Test
  public void getUnknownElement_test_5513(Element c0, Object c1) {
    UnknownElementException instance = new UnknownElementException(c0, c1);
    instance.getUnknownElement();
  }
}
