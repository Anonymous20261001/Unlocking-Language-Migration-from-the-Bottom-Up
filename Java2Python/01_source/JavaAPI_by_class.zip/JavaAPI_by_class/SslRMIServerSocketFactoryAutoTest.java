package generated.test;

import java.lang.Object;
import javax.rmi.ssl.SslRMIServerSocketFactory;
import org.junit.jupiter.api.Test;

public class SslRMIServerSocketFactoryAutoTest {
  @Test
  public void getNeedClientAuth_test_6256() {
    SslRMIServerSocketFactory instance = new SslRMIServerSocketFactory();
    instance.getNeedClientAuth();
  }

  @Test
  public void getEnabledCipherSuites_test_6257() {
    SslRMIServerSocketFactory instance = new SslRMIServerSocketFactory();
    instance.getEnabledCipherSuites();
  }

  @Test
  public void getEnabledProtocols_test_6258() {
    SslRMIServerSocketFactory instance = new SslRMIServerSocketFactory();
    instance.getEnabledProtocols();
  }

  @Test
  public void equals_test_6259(Object p0) {
    SslRMIServerSocketFactory instance = new SslRMIServerSocketFactory();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_6260() {
    SslRMIServerSocketFactory instance = new SslRMIServerSocketFactory();
    instance.hashCode();
  }
}
