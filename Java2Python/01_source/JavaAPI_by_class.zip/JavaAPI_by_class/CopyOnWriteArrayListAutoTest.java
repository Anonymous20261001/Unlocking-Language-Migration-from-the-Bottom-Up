package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.Comparator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import org.junit.jupiter.api.Test;

public class CopyOnWriteArrayListAutoTest {
  @Test
  public void remove_test_4381(int p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.remove(p0);
  }

  @Test
  public void remove_test_4382(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.remove(p0);
  }

  @Test
  public void size_test_4383() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.size();
  }

  @Test
  public void get_test_4384(int p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.get(p0);
  }

  @Test
  public void equals_test_4385(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.equals(p0);
  }

  @Test
  public void toString_test_4386() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.toString();
  }

  @Test
  public void hashCode_test_4387() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.hashCode();
  }

  @Test
  public void clone_test_4388() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.clone();
  }

  @Test
  public void sort_test_4389(Comparator p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.sort(p0);
  }

  @Test
  public void indexOf_test_4390(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.indexOf(p0);
  }

  @Test
  public void indexOf_test_4391(Object p0, int p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.indexOf(p0, p1);
  }

  @Test
  public void clear_test_4392() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.clear();
  }

  @Test
  public void lastIndexOf_test_4393(Object p0, int p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.lastIndexOf(p0, p1);
  }

  @Test
  public void lastIndexOf_test_4394(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.lastIndexOf(p0);
  }

  @Test
  public void isEmpty_test_4395() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.isEmpty();
  }

  @Test
  public void replaceAll_test_4396(UnaryOperator p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.replaceAll(p0);
  }

  @Test
  public void add_test_4397(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.add(p0);
  }

  @Test
  public void add_test_4398(int p0, Object p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.add(p0, p1);
  }

  @Test
  public void subList_test_4399(int p0, int p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.subList(p0, p1);
  }

  @Test
  public void toArray_test_4400(Object[] p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_4401() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.toArray();
  }

  @Test
  public void iterator_test_4402() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.iterator();
  }

  @Test
  public void contains_test_4403(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_4404() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.spliterator();
  }

  @Test
  public void addAll_test_4405(Collection p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addAll(p0);
  }

  @Test
  public void addAll_test_4406(int p0, Collection p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addAll(p0, p1);
  }

  @Test
  public void set_test_4407(int p0, Object p1) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.set(p0, p1);
  }

  @Test
  public void forEach_test_4408(Consumer p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.forEach(p0);
  }

  @Test
  public void removeIf_test_4409(Predicate p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.removeIf(p0);
  }

  @Test
  public void getFirst_test_4410() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.getFirst();
  }

  @Test
  public void getLast_test_4411() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.getLast();
  }

  @Test
  public void addFirst_test_4412(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addFirst(p0);
  }

  @Test
  public void addLast_test_4413(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addLast(p0);
  }

  @Test
  public void removeFirst_test_4414() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.removeFirst();
  }

  @Test
  public void removeLast_test_4415() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.removeLast();
  }

  @Test
  public void removeAll_test_4416(Collection p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.removeAll(p0);
  }

  @Test
  public void retainAll_test_4417(Collection p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.retainAll(p0);
  }

  @Test
  public void listIterator_test_4418() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.listIterator();
  }

  @Test
  public void listIterator_test_4419(int p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.listIterator(p0);
  }

  @Test
  public void reversed_test_4420() {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.reversed();
  }

  @Test
  public void containsAll_test_4421(Collection p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.containsAll(p0);
  }

  @Test
  public void addIfAbsent_test_4422(Object p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addIfAbsent(p0);
  }

  @Test
  public void addAllAbsent_test_4423(Collection p0) {
    CopyOnWriteArrayList instance = new CopyOnWriteArrayList();
    instance.addAllAbsent(p0);
  }
}
