package generated.test;

import java.lang.management.MemoryUsage;
import javax.management.openmbean.CompositeData;
import org.junit.jupiter.api.Test;

public class MemoryUsageAutoTest {
  @Test
  public void getInit_test_2411(long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    instance.getInit();
  }

  @Test
  public void getUsed_test_2412(long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    instance.getUsed();
  }

  @Test
  public void getCommitted_test_2413(long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    instance.getCommitted();
  }

  @Test
  public void toString_test_2414(long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    instance.toString();
  }

  @Test
  public void from_test_2415(CompositeData p0, long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    MemoryUsage.from(p0);
  }

  @Test
  public void getMax_test_2416(long c0, long c1, long c2, long c3) {
    MemoryUsage instance = new MemoryUsage(c0, c1, c2, c3);
    instance.getMax();
  }
}
