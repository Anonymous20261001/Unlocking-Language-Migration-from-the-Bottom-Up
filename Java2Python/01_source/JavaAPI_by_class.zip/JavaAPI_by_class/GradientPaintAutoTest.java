package generated.test;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import org.junit.jupiter.api.Test;

public class GradientPaintAutoTest {
  @Test
  public void createContext_test_309(ColorModel p0, Rectangle p1, Rectangle2D p2,
      AffineTransform p3, RenderingHints p4, Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.createContext(p0, p1, p2, p3, p4);
  }

  @Test
  public void getTransparency_test_310(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.getTransparency();
  }

  @Test
  public void getPoint1_test_311(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.getPoint1();
  }

  @Test
  public void getColor1_test_312(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.getColor1();
  }

  @Test
  public void getPoint2_test_313(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.getPoint2();
  }

  @Test
  public void getColor2_test_314(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.getColor2();
  }

  @Test
  public void isCyclic_test_315(Point2D c0, Color c1, Point2D c2, Color c3) {
    GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
    instance.isCyclic();
  }
}
