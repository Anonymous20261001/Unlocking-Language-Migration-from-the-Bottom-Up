package generated.test;

import java.math.BigInteger;
import java.security.spec.RSAPrivateCrtKeySpec;
import org.junit.jupiter.api.Test;

public class RSAPrivateCrtKeySpecAutoTest {
  @Test
  public void getPublicExponent_test_2919(BigInteger c0, BigInteger c1, BigInteger c2,
      BigInteger c3, BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPublicExponent();
  }

  @Test
  public void getPrimeP_test_2920(BigInteger c0, BigInteger c1, BigInteger c2, BigInteger c3,
      BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPrimeP();
  }

  @Test
  public void getPrimeQ_test_2921(BigInteger c0, BigInteger c1, BigInteger c2, BigInteger c3,
      BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPrimeQ();
  }

  @Test
  public void getPrimeExponentP_test_2922(BigInteger c0, BigInteger c1, BigInteger c2,
      BigInteger c3, BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPrimeExponentP();
  }

  @Test
  public void getPrimeExponentQ_test_2923(BigInteger c0, BigInteger c1, BigInteger c2,
      BigInteger c3, BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getPrimeExponentQ();
  }

  @Test
  public void getCrtCoefficient_test_2924(BigInteger c0, BigInteger c1, BigInteger c2,
      BigInteger c3, BigInteger c4, BigInteger c5, BigInteger c6, BigInteger c7) {
    RSAPrivateCrtKeySpec instance = new RSAPrivateCrtKeySpec(c0, c1, c2, c3, c4, c5, c6, c7);
    instance.getCrtCoefficient();
  }
}
