package generated.test;

import java.awt.Color;
import java.awt.Rectangle;
import java.lang.Object;
import java.lang.String;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import org.junit.jupiter.api.Test;

public class DefaultTableCellRendererAutoTest {
  @Test
  public void getTableCellRendererComponent_test_9980(JTable p0, Object p1, boolean p2, boolean p3,
      int p4, int p5) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.getTableCellRendererComponent(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void firePropertyChange_test_9981(String p0, boolean p1, boolean p2) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void repaint_test_9982(Rectangle p0) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.repaint(p0);
  }

  @Test
  public void repaint_test_9983() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.repaint();
  }

  @Test
  public void repaint_test_9984(long p0, int p1, int p2, int p3, int p4) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void setForeground_test_9985(Color p0) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.setForeground(p0);
  }

  @Test
  public void setBackground_test_9986(Color p0) {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.setBackground(p0);
  }

  @Test
  public void revalidate_test_9987() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.revalidate();
  }

  @Test
  public void updateUI_test_9988() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.updateUI();
  }

  @Test
  public void validate_test_9989() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.validate();
  }

  @Test
  public void isOpaque_test_9990() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.isOpaque();
  }

  @Test
  public void invalidate_test_9991() {
    DefaultTableCellRenderer instance = new DefaultTableCellRenderer();
    instance.invalidate();
  }
}
