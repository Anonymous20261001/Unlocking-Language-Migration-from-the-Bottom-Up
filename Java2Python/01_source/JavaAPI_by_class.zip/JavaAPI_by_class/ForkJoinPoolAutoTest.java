package generated.test;

import java.lang.Object;
import java.lang.Runnable;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import org.junit.jupiter.api.Test;

public class ForkJoinPoolAutoTest {
  @Test
  public void invoke_test_4467(ForkJoinTask p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.invoke(p0);
  }

  @Test
  public void shutdown_test_4468() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.shutdown();
  }

  @Test
  public void toString_test_4469() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.toString();
  }

  @Test
  public void getFactory_test_4470() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getFactory();
  }

  @Test
  public void isTerminated_test_4471() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.isTerminated();
  }

  @Test
  public void getUncaughtExceptionHandler_test_4472() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getUncaughtExceptionHandler();
  }

  @Test
  public void execute_test_4473(ForkJoinTask p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.execute(p0);
  }

  @Test
  public void execute_test_4474(Runnable p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.execute(p0);
  }

  @Test
  public void externalSubmit_test_4475(ForkJoinTask p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.externalSubmit(p0);
  }

  @Test
  public void getQueuedTaskCount_test_4476() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getQueuedTaskCount();
  }

  @Test
  public void lazySubmit_test_4477(ForkJoinTask p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.lazySubmit(p0);
  }

  @Test
  public void schedule_test_4478(Callable p0, long p1, TimeUnit p2) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.schedule(p0, p1, p2);
  }

  @Test
  public void schedule_test_4479(Runnable p0, long p1, TimeUnit p2) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.schedule(p0, p1, p2);
  }

  @Test
  public void close_test_4480() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.close();
  }

  @Test
  public void getCommonPoolParallelism_test_4481() {
    ForkJoinPool instance = new ForkJoinPool();
    ForkJoinPool.getCommonPoolParallelism();
  }

  @Test
  public void isShutdown_test_4482() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.isShutdown();
  }

  @Test
  public void submit_test_4483(Runnable p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.submit(p0);
  }

  @Test
  public void submit_test_4484(Callable p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.submit(p0);
  }

  @Test
  public void submit_test_4485(Runnable p0, Object p1) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.submit(p0, p1);
  }

  @Test
  public void submit_test_4486(ForkJoinTask p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.submit(p0);
  }

  @Test
  public void shutdownNow_test_4487() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.shutdownNow();
  }

  @Test
  public void cancelDelayedTasksOnShutdown_test_4488() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.cancelDelayedTasksOnShutdown();
  }

  @Test
  public void getParallelism_test_4489() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getParallelism();
  }

  @Test
  public void commonPool_test_4490() {
    ForkJoinPool instance = new ForkJoinPool();
    ForkJoinPool.commonPool();
  }

  @Test
  public void setParallelism_test_4491(int p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.setParallelism(p0);
  }

  @Test
  public void invokeAllUninterruptibly_test_4492(Collection p0) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.invokeAllUninterruptibly(p0);
  }

  @Test
  public void scheduleAtFixedRate_test_4493(Runnable p0, long p1, long p2, TimeUnit p3) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.scheduleAtFixedRate(p0, p1, p2, p3);
  }

  @Test
  public void scheduleWithFixedDelay_test_4494(Runnable p0, long p1, long p2, TimeUnit p3) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.scheduleWithFixedDelay(p0, p1, p2, p3);
  }

  @Test
  public void submitWithTimeout_test_4495(Callable p0, long p1, TimeUnit p2, Consumer p3) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.submitWithTimeout(p0, p1, p2, p3);
  }

  @Test
  public void getPoolSize_test_4496() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getPoolSize();
  }

  @Test
  public void getAsyncMode_test_4497() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getAsyncMode();
  }

  @Test
  public void getRunningThreadCount_test_4498() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getRunningThreadCount();
  }

  @Test
  public void getActiveThreadCount_test_4499() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getActiveThreadCount();
  }

  @Test
  public void isQuiescent_test_4500() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.isQuiescent();
  }

  @Test
  public void getStealCount_test_4501() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getStealCount();
  }

  @Test
  public void getQueuedSubmissionCount_test_4502() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getQueuedSubmissionCount();
  }

  @Test
  public void getDelayedTaskCount_test_4503() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.getDelayedTaskCount();
  }

  @Test
  public void hasQueuedSubmissions_test_4504() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.hasQueuedSubmissions();
  }

  @Test
  public void isTerminating_test_4505() {
    ForkJoinPool instance = new ForkJoinPool();
    instance.isTerminating();
  }

  @Test
  public void awaitQuiescence_test_4506(long p0, TimeUnit p1) {
    ForkJoinPool instance = new ForkJoinPool();
    instance.awaitQuiescence(p0, p1);
  }
}
