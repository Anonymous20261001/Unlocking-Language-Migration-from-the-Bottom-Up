package generated.test;

import java.io.FileDescriptor;
import java.lang.Object;
import java.lang.SecurityManager;
import java.lang.String;
import java.lang.Thread;
import java.lang.ThreadGroup;
import java.net.InetAddress;
import java.security.Permission;
import org.junit.jupiter.api.Test;

public class SecurityManagerAutoTest {
  @Test
  public void getSecurityContext_test_2062() {
    SecurityManager instance = new SecurityManager();
    instance.getSecurityContext();
  }

  @Test
  public void checkExec_test_2063(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkExec(p0);
  }

  @Test
  public void checkLink_test_2064(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkLink(p0);
  }

  @Test
  public void checkRead_test_2065(FileDescriptor p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkRead(p0);
  }

  @Test
  public void checkRead_test_2066(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkRead(p0);
  }

  @Test
  public void checkRead_test_2067(String p0, Object p1) {
    SecurityManager instance = new SecurityManager();
    instance.checkRead(p0, p1);
  }

  @Test
  public void checkWrite_test_2068(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkWrite(p0);
  }

  @Test
  public void checkWrite_test_2069(FileDescriptor p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkWrite(p0);
  }

  @Test
  public void checkDelete_test_2070(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkDelete(p0);
  }

  @Test
  public void checkConnect_test_2071(String p0, int p1, Object p2) {
    SecurityManager instance = new SecurityManager();
    instance.checkConnect(p0, p1, p2);
  }

  @Test
  public void checkConnect_test_2072(String p0, int p1) {
    SecurityManager instance = new SecurityManager();
    instance.checkConnect(p0, p1);
  }

  @Test
  public void checkListen_test_2073(int p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkListen(p0);
  }

  @Test
  public void checkAccept_test_2074(String p0, int p1) {
    SecurityManager instance = new SecurityManager();
    instance.checkAccept(p0, p1);
  }

  @Test
  public void checkMulticast_test_2075(InetAddress p0, byte p1) {
    SecurityManager instance = new SecurityManager();
    instance.checkMulticast(p0, p1);
  }

  @Test
  public void checkMulticast_test_2076(InetAddress p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkMulticast(p0);
  }

  @Test
  public void checkPropertiesAccess_test_2077() {
    SecurityManager instance = new SecurityManager();
    instance.checkPropertiesAccess();
  }

  @Test
  public void checkPropertyAccess_test_2078(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkPropertyAccess(p0);
  }

  @Test
  public void checkPrintJobAccess_test_2079() {
    SecurityManager instance = new SecurityManager();
    instance.checkPrintJobAccess();
  }

  @Test
  public void checkPackageAccess_test_2080(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkPackageAccess(p0);
  }

  @Test
  public void checkPackageDefinition_test_2081(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkPackageDefinition(p0);
  }

  @Test
  public void checkSetFactory_test_2082() {
    SecurityManager instance = new SecurityManager();
    instance.checkSetFactory();
  }

  @Test
  public void checkSecurityAccess_test_2083(String p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkSecurityAccess(p0);
  }

  @Test
  public void checkCreateClassLoader_test_2084() {
    SecurityManager instance = new SecurityManager();
    instance.checkCreateClassLoader();
  }

  @Test
  public void getThreadGroup_test_2085() {
    SecurityManager instance = new SecurityManager();
    instance.getThreadGroup();
  }

  @Test
  public void checkAccess_test_2086(ThreadGroup p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkAccess(p0);
  }

  @Test
  public void checkAccess_test_2087(Thread p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkAccess(p0);
  }

  @Test
  public void checkExit_test_2088(int p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkExit(p0);
  }

  @Test
  public void checkPermission_test_2089(Permission p0, Object p1) {
    SecurityManager instance = new SecurityManager();
    instance.checkPermission(p0, p1);
  }

  @Test
  public void checkPermission_test_2090(Permission p0) {
    SecurityManager instance = new SecurityManager();
    instance.checkPermission(p0);
  }
}
