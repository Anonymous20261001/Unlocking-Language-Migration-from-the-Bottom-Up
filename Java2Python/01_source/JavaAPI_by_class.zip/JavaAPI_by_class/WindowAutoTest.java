package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Window;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.beans.PropertyChangeListener;
import java.lang.Class;
import java.lang.String;
import java.util.List;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class WindowAutoTest {
  @Test
  public void setType_test_552(Window.Type p0, Window c0) {
    Window instance = new Window(c0);
    instance.setType(p0);
  }

  @Test
  public void isValidateRoot_test_553(Window c0) {
    Window instance = new Window(c0);
    instance.isValidateRoot();
  }

  @Test
  public void getAccessibleContext_test_554(Window c0) {
    Window instance = new Window(c0);
    instance.getAccessibleContext();
  }

  @Test
  public void addNotify_test_555(Window c0) {
    Window instance = new Window(c0);
    instance.addNotify();
  }

  @Test
  public void removeNotify_test_556(Window c0) {
    Window instance = new Window(c0);
    instance.removeNotify();
  }

  @Test
  public void isFocusCycleRoot_test_557(Window c0) {
    Window instance = new Window(c0);
    instance.isFocusCycleRoot();
  }

  @Test
  public void getFocusOwner_test_558(Window c0) {
    Window instance = new Window(c0);
    instance.getFocusOwner();
  }

  @Test
  public void isShowing_test_559(Window c0) {
    Window instance = new Window(c0);
    instance.isShowing();
  }

  @Test
  public void paint_test_560(Graphics p0, Window c0) {
    Window instance = new Window(c0);
    instance.paint(p0);
  }

  @Test
  public void getListeners_test_561(Class p0, Window c0) {
    Window instance = new Window(c0);
    instance.getListeners(p0);
  }

  @Test
  public void postEvent_test_562(Event p0, Window c0) {
    Window instance = new Window(c0);
    instance.postEvent(p0);
  }

  @Test
  public void getMostRecentFocusOwner_test_563(Window c0) {
    Window instance = new Window(c0);
    instance.getMostRecentFocusOwner();
  }

  @Test
  public void getFocusCycleRootAncestor_test_564(Window c0) {
    Window instance = new Window(c0);
    instance.getFocusCycleRootAncestor();
  }

  @Test
  public void addPropertyChangeListener_test_565(PropertyChangeListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.addPropertyChangeListener(p0);
  }

  @Test
  public void addPropertyChangeListener_test_566(String p0, PropertyChangeListener p1, Window c0) {
    Window instance = new Window(c0);
    instance.addPropertyChangeListener(p0, p1);
  }

  @Test
  public void setVisible_test_567(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setVisible(p0);
  }

  @Test
  public void setBounds_test_568(int p0, int p1, int p2, int p3, Window c0) {
    Window instance = new Window(c0);
    instance.setBounds(p0, p1, p2, p3);
  }

  @Test
  public void setBounds_test_569(Rectangle p0, Window c0) {
    Window instance = new Window(c0);
    instance.setBounds(p0);
  }

  @Test
  public void getFocusTraversalKeys_test_570(int p0, Window c0) {
    Window instance = new Window(c0);
    instance.getFocusTraversalKeys(p0);
  }

  @Test
  public void setFocusCycleRoot_test_571(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setFocusCycleRoot(p0);
  }

  @Test
  public void getToolkit_test_572(Window c0) {
    Window instance = new Window(c0);
    instance.getToolkit();
  }

  @Test
  public void setLocation_test_573(int p0, int p1, Window c0) {
    Window instance = new Window(c0);
    instance.setLocation(p0, p1);
  }

  @Test
  public void setLocation_test_574(Point p0, Window c0) {
    Window instance = new Window(c0);
    instance.setLocation(p0);
  }

  @Test
  public void getInputContext_test_575(Window c0) {
    Window instance = new Window(c0);
    instance.getInputContext();
  }

  @Test
  public void show_test_576(Window c0) {
    Window instance = new Window(c0);
    instance.show();
  }

  @Test
  public void hide_test_577(Window c0) {
    Window instance = new Window(c0);
    instance.hide();
  }

  @Test
  public void getBackground_test_578(Window c0) {
    Window instance = new Window(c0);
    instance.getBackground();
  }

  @Test
  public void setBackground_test_579(Color p0, Window c0) {
    Window instance = new Window(c0);
    instance.setBackground(p0);
  }

  @Test
  public void reshape_test_580(int p0, int p1, int p2, int p3, Window c0) {
    Window instance = new Window(c0);
    instance.reshape(p0, p1, p2, p3);
  }

  @Test
  public void createBufferStrategy_test_581(int p0, Window c0) {
    Window instance = new Window(c0);
    instance.createBufferStrategy(p0);
  }

  @Test
  public void isFocusableWindow_test_582(Window c0) {
    Window instance = new Window(c0);
    instance.isFocusableWindow();
  }

  @Test
  public void setMinimumSize_test_583(Dimension p0, Window c0) {
    Window instance = new Window(c0);
    instance.setMinimumSize(p0);
  }

  @Test
  public void setCursor_test_584(Cursor p0, Window c0) {
    Window instance = new Window(c0);
    instance.setCursor(p0);
  }

  @Test
  public void getBufferStrategy_test_585(Window c0) {
    Window instance = new Window(c0);
    instance.getBufferStrategy();
  }

  @Test
  public void isFocused_test_586(Window c0) {
    Window instance = new Window(c0);
    instance.isFocused();
  }

  @Test
  public void toFront_test_587(Window c0) {
    Window instance = new Window(c0);
    instance.toFront();
  }

  @Test
  public void setLocationByPlatform_test_588(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setLocationByPlatform(p0);
  }

  @Test
  public void toBack_test_589(Window c0) {
    Window instance = new Window(c0);
    instance.toBack();
  }

  @Test
  public void getOpacity_test_590(Window c0) {
    Window instance = new Window(c0);
    instance.getOpacity();
  }

  @Test
  public void setOpacity_test_591(float p0, Window c0) {
    Window instance = new Window(c0);
    instance.setOpacity(p0);
  }

  @Test
  public void setShape_test_592(Shape p0, Window c0) {
    Window instance = new Window(c0);
    instance.setShape(p0);
  }

  @Test
  public void isAlwaysOnTop_test_593(Window c0) {
    Window instance = new Window(c0);
    instance.isAlwaysOnTop();
  }

  @Test
  public void setAlwaysOnTop_test_594(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setAlwaysOnTop(p0);
  }

  @Test
  public void setIconImages_test_595(List p0, Window c0) {
    Window instance = new Window(c0);
    instance.setIconImages(p0);
  }

  @Test
  public void getWindows_test_596(Window c0) {
    Window instance = new Window(c0);
    Window.getWindows();
  }

  @Test
  public void getOwnedWindows_test_597(Window c0) {
    Window instance = new Window(c0);
    instance.getOwnedWindows();
  }

  @Test
  public void isAlwaysOnTopSupported_test_598(Window c0) {
    Window instance = new Window(c0);
    instance.isAlwaysOnTopSupported();
  }

  @Test
  public void getFocusableWindowState_test_599(Window c0) {
    Window instance = new Window(c0);
    instance.getFocusableWindowState();
  }

  @Test
  public void applyResourceBundle_test_600(String p0, Window c0) {
    Window instance = new Window(c0);
    instance.applyResourceBundle(p0);
  }

  @Test
  public void applyResourceBundle_test_601(ResourceBundle p0, Window c0) {
    Window instance = new Window(c0);
    instance.applyResourceBundle(p0);
  }

  @Test
  public void addWindowListener_test_602(WindowListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.addWindowListener(p0);
  }

  @Test
  public void addWindowFocusListener_test_603(WindowFocusListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.addWindowFocusListener(p0);
  }

  @Test
  public void addWindowStateListener_test_604(WindowStateListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.addWindowStateListener(p0);
  }

  @Test
  public void setModalExclusionType_test_605(Dialog.ModalExclusionType p0, Window c0) {
    Window instance = new Window(c0);
    instance.setModalExclusionType(p0);
  }

  @Test
  public void getIconImages_test_606(Window c0) {
    Window instance = new Window(c0);
    instance.getIconImages();
  }

  @Test
  public void setIconImage_test_607(Image p0, Window c0) {
    Window instance = new Window(c0);
    instance.setIconImage(p0);
  }

  @Test
  public void pack_test_608(Window c0) {
    Window instance = new Window(c0);
    instance.pack();
  }

  @Test
  public void getWarningString_test_609(Window c0) {
    Window instance = new Window(c0);
    instance.getWarningString();
  }

  @Test
  public void getOwnerlessWindows_test_610(Window c0) {
    Window instance = new Window(c0);
    Window.getOwnerlessWindows();
  }

  @Test
  public void getModalExclusionType_test_611(Window c0) {
    Window instance = new Window(c0);
    instance.getModalExclusionType();
  }

  @Test
  public void removeWindowListener_test_612(WindowListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.removeWindowListener(p0);
  }

  @Test
  public void removeWindowStateListener_test_613(WindowStateListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.removeWindowStateListener(p0);
  }

  @Test
  public void removeWindowFocusListener_test_614(WindowFocusListener p0, Window c0) {
    Window instance = new Window(c0);
    instance.removeWindowFocusListener(p0);
  }

  @Test
  public void getWindowListeners_test_615(Window c0) {
    Window instance = new Window(c0);
    instance.getWindowListeners();
  }

  @Test
  public void getWindowFocusListeners_test_616(Window c0) {
    Window instance = new Window(c0);
    instance.getWindowFocusListeners();
  }

  @Test
  public void getWindowStateListeners_test_617(Window c0) {
    Window instance = new Window(c0);
    instance.getWindowStateListeners();
  }

  @Test
  public void setFocusableWindowState_test_618(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setFocusableWindowState(p0);
  }

  @Test
  public void setAutoRequestFocus_test_619(boolean p0, Window c0) {
    Window instance = new Window(c0);
    instance.setAutoRequestFocus(p0);
  }

  @Test
  public void isAutoRequestFocus_test_620(Window c0) {
    Window instance = new Window(c0);
    instance.isAutoRequestFocus();
  }

  @Test
  public void setLocationRelativeTo_test_621(Component p0, Window c0) {
    Window instance = new Window(c0);
    instance.setLocationRelativeTo(p0);
  }

  @Test
  public void isLocationByPlatform_test_622(Window c0) {
    Window instance = new Window(c0);
    instance.isLocationByPlatform();
  }

  @Test
  public void getType_test_623(Window c0) {
    Window instance = new Window(c0);
    instance.getType();
  }

  @Test
  public void isOpaque_test_624(Window c0) {
    Window instance = new Window(c0);
    instance.isOpaque();
  }

  @Test
  public void isActive_test_625(Window c0) {
    Window instance = new Window(c0);
    instance.isActive();
  }

  @Test
  public void getOwner_test_626(Window c0) {
    Window instance = new Window(c0);
    instance.getOwner();
  }

  @Test
  public void getLocale_test_627(Window c0) {
    Window instance = new Window(c0);
    instance.getLocale();
  }

  @Test
  public void setSize_test_628(int p0, int p1, Window c0) {
    Window instance = new Window(c0);
    instance.setSize(p0, p1);
  }

  @Test
  public void setSize_test_629(Dimension p0, Window c0) {
    Window instance = new Window(c0);
    instance.setSize(p0);
  }

  @Test
  public void dispose_test_630(Window c0) {
    Window instance = new Window(c0);
    instance.dispose();
  }

  @Test
  public void getShape_test_631(Window c0) {
    Window instance = new Window(c0);
    instance.getShape();
  }
}
