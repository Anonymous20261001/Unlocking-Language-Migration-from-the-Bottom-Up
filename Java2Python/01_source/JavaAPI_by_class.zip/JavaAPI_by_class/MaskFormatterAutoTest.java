package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {
  @Test
  public void install_test_10305(JFormattedTextField p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.install(p0);
  }

  @Test
  public void getPlaceholder_test_10306() {
    MaskFormatter instance = new MaskFormatter();
    instance.getPlaceholder();
  }

  @Test
  public void getValueContainsLiteralCharacters_test_10307() {
    MaskFormatter instance = new MaskFormatter();
    instance.getValueContainsLiteralCharacters();
  }

  @Test
  public void getPlaceholderCharacter_test_10308() {
    MaskFormatter instance = new MaskFormatter();
    instance.getPlaceholderCharacter();
  }

  @Test
  public void setValidCharacters_test_10309(String p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.setValidCharacters(p0);
  }

  @Test
  public void getValidCharacters_test_10310() {
    MaskFormatter instance = new MaskFormatter();
    instance.getValidCharacters();
  }

  @Test
  public void setInvalidCharacters_test_10311(String p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.setInvalidCharacters(p0);
  }

  @Test
  public void getInvalidCharacters_test_10312() {
    MaskFormatter instance = new MaskFormatter();
    instance.getInvalidCharacters();
  }

  @Test
  public void setPlaceholder_test_10313(String p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.setPlaceholder(p0);
  }

  @Test
  public void setPlaceholderCharacter_test_10314(char p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.setPlaceholderCharacter(p0);
  }

  @Test
  public void setValueContainsLiteralCharacters_test_10315(boolean p0) {
    MaskFormatter instance = new MaskFormatter();
    instance.setValueContainsLiteralCharacters(p0);
  }

  @Test
  public void getMask_test_10316() {
    MaskFormatter instance = new MaskFormatter();
    instance.getMask();
  }
}
