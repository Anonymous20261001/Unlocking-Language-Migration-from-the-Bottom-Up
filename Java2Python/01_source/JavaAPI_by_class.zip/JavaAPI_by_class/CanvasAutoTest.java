package generated.test;

import java.awt.Canvas;
import java.awt.Graphics;
import org.junit.jupiter.api.Test;

public class CanvasAutoTest {
  @Test
  public void getAccessibleContext_test_35() {
    Canvas instance = new Canvas();
    instance.getAccessibleContext();
  }

  @Test
  public void addNotify_test_36() {
    Canvas instance = new Canvas();
    instance.addNotify();
  }

  @Test
  public void paint_test_37(Graphics p0) {
    Canvas instance = new Canvas();
    instance.paint(p0);
  }

  @Test
  public void createBufferStrategy_test_38(int p0) {
    Canvas instance = new Canvas();
    instance.createBufferStrategy(p0);
  }

  @Test
  public void getBufferStrategy_test_39() {
    Canvas instance = new Canvas();
    instance.getBufferStrategy();
  }

  @Test
  public void update_test_40(Graphics p0) {
    Canvas instance = new Canvas();
    instance.update(p0);
  }
}
