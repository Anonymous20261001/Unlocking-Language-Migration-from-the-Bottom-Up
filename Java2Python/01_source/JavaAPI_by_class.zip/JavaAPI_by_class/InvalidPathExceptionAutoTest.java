package generated.test;

import java.lang.String;
import java.nio.file.InvalidPathException;
import org.junit.jupiter.api.Test;

public class InvalidPathExceptionAutoTest {
  @Test
  public void getMessage_test_2652(String c0, String c1) {
    InvalidPathException instance = new InvalidPathException(c0, c1);
    instance.getMessage();
  }

  @Test
  public void getIndex_test_2653(String c0, String c1) {
    InvalidPathException instance = new InvalidPathException(c0, c1);
    instance.getIndex();
  }

  @Test
  public void getReason_test_2654(String c0, String c1) {
    InvalidPathException instance = new InvalidPathException(c0, c1);
    instance.getReason();
  }

  @Test
  public void getInput_test_2655(String c0, String c1) {
    InvalidPathException instance = new InvalidPathException(c0, c1);
    instance.getInput();
  }
}
