package generated.test;

import java.awt.Adjustable;
import java.awt.event.AdjustmentEvent;
import org.junit.jupiter.api.Test;

public class AdjustmentEventAutoTest {
  @Test
  public void getAdjustmentType_test_745(Adjustable c0, int c1, int c2, int c3) {
    AdjustmentEvent instance = new AdjustmentEvent(c0, c1, c2, c3);
    instance.getAdjustmentType();
  }

  @Test
  public void getAdjustable_test_746(Adjustable c0, int c1, int c2, int c3) {
    AdjustmentEvent instance = new AdjustmentEvent(c0, c1, c2, c3);
    instance.getAdjustable();
  }

  @Test
  public void getValueIsAdjusting_test_747(Adjustable c0, int c1, int c2, int c3) {
    AdjustmentEvent instance = new AdjustmentEvent(c0, c1, c2, c3);
    instance.getValueIsAdjusting();
  }

  @Test
  public void getValue_test_748(Adjustable c0, int c1, int c2, int c3) {
    AdjustmentEvent instance = new AdjustmentEvent(c0, c1, c2, c3);
    instance.getValue();
  }

  @Test
  public void paramString_test_749(Adjustable c0, int c1, int c2, int c3) {
    AdjustmentEvent instance = new AdjustmentEvent(c0, c1, c2, c3);
    instance.paramString();
  }
}
