package generated.test;

import java.io.IOException;
import java.io.UncheckedIOException;
import org.junit.jupiter.api.Test;

public class UncheckedIOExceptionAutoTest {
  @Test
  public void getCause_test_1834(IOException c0) {
    UncheckedIOException instance = new UncheckedIOException(c0);
    instance.getCause();
  }
}
