package generated.test;

import java.lang.Object;
import java.util.HashSet;
import org.junit.jupiter.api.Test;

public class HashSetAutoTest {
  @Test
  public void remove_test_3503(Object p0) {
    HashSet instance = new HashSet();
    instance.remove(p0);
  }

  @Test
  public void size_test_3504() {
    HashSet instance = new HashSet();
    instance.size();
  }

  @Test
  public void clone_test_3505() {
    HashSet instance = new HashSet();
    instance.clone();
  }

  @Test
  public void clear_test_3506() {
    HashSet instance = new HashSet();
    instance.clear();
  }

  @Test
  public void isEmpty_test_3507() {
    HashSet instance = new HashSet();
    instance.isEmpty();
  }

  @Test
  public void add_test_3508(Object p0) {
    HashSet instance = new HashSet();
    instance.add(p0);
  }

  @Test
  public void toArray_test_3509(Object[] p0) {
    HashSet instance = new HashSet();
    instance.toArray(p0);
  }

  @Test
  public void toArray_test_3510() {
    HashSet instance = new HashSet();
    instance.toArray();
  }

  @Test
  public void iterator_test_3511() {
    HashSet instance = new HashSet();
    instance.iterator();
  }

  @Test
  public void contains_test_3512(Object p0) {
    HashSet instance = new HashSet();
    instance.contains(p0);
  }

  @Test
  public void spliterator_test_3513() {
    HashSet instance = new HashSet();
    instance.spliterator();
  }

  @Test
  public void newHashSet_test_3514(int p0) {
    HashSet instance = new HashSet();
    HashSet.newHashSet(p0);
  }
}
