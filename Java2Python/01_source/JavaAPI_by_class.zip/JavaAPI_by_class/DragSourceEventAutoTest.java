package generated.test;

import java.awt.dnd.DragSourceContext;
import java.awt.dnd.DragSourceEvent;
import org.junit.jupiter.api.Test;

public class DragSourceEventAutoTest {
  @Test
  public void getDragSourceContext_test_714(DragSourceContext c0) {
    DragSourceEvent instance = new DragSourceEvent(c0);
    instance.getDragSourceContext();
  }

  @Test
  public void getX_test_715(DragSourceContext c0) {
    DragSourceEvent instance = new DragSourceEvent(c0);
    instance.getX();
  }

  @Test
  public void getY_test_716(DragSourceContext c0) {
    DragSourceEvent instance = new DragSourceEvent(c0);
    instance.getY();
  }

  @Test
  public void getLocation_test_717(DragSourceContext c0) {
    DragSourceEvent instance = new DragSourceEvent(c0);
    instance.getLocation();
  }
}
