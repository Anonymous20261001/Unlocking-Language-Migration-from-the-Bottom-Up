package generated.test;

import javax.swing.JRadioButtonMenuItem;
import org.junit.jupiter.api.Test;

public class JRadioButtonMenuItemAutoTest {
  @Test
  public void getUIClassID_test_7536() {
    JRadioButtonMenuItem instance = new JRadioButtonMenuItem();
    instance.getUIClassID();
  }

  @Test
  public void getAccessibleContext_test_7537() {
    JRadioButtonMenuItem instance = new JRadioButtonMenuItem();
    instance.getAccessibleContext();
  }
}
