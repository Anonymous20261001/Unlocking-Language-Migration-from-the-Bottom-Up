package generated.test;

import java.lang.CharSequence;
import java.lang.Object;
import java.lang.String;
import java.lang.StringBuffer;
import java.lang.StringBuilder;
import org.junit.jupiter.api.Test;

public class StringBuilderAutoTest {
  @Test
  public void toString_test_2258() {
    StringBuilder instance = new StringBuilder();
    instance.toString();
  }

  @Test
  public void append_test_2259(CharSequence p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2260(CharSequence p0, int p1, int p2) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_2261(char[] p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2262(char[] p0, int p1, int p2) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0, p1, p2);
  }

  @Test
  public void append_test_2263(Object p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2264(String p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2265(StringBuffer p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2266(long p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2267(float p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2268(double p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2269(boolean p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2270(char p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void append_test_2271(int p0) {
    StringBuilder instance = new StringBuilder();
    instance.append(p0);
  }

  @Test
  public void reverse_test_2272() {
    StringBuilder instance = new StringBuilder();
    instance.reverse();
  }

  @Test
  public void compareTo_test_2273(StringBuilder p0) {
    StringBuilder instance = new StringBuilder();
    instance.compareTo(p0);
  }

  @Test
  public void indexOf_test_2274(String p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.indexOf(p0, p1);
  }

  @Test
  public void indexOf_test_2275(String p0) {
    StringBuilder instance = new StringBuilder();
    instance.indexOf(p0);
  }

  @Test
  public void insert_test_2276(int p0, CharSequence p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2277(int p0, String p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2278(int p0, char[] p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2279(int p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2280(int p0, double p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2281(int p0, float p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2282(int p0, long p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2283(int p0, char p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2284(int p0, boolean p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2285(int p0, CharSequence p1, int p2, int p3) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1, p2, p3);
  }

  @Test
  public void insert_test_2286(int p0, Object p1) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1);
  }

  @Test
  public void insert_test_2287(int p0, char[] p1, int p2, int p3) {
    StringBuilder instance = new StringBuilder();
    instance.insert(p0, p1, p2, p3);
  }

  @Test
  public void lastIndexOf_test_2288(String p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.lastIndexOf(p0, p1);
  }

  @Test
  public void lastIndexOf_test_2289(String p0) {
    StringBuilder instance = new StringBuilder();
    instance.lastIndexOf(p0);
  }

  @Test
  public void replace_test_2290(int p0, int p1, String p2) {
    StringBuilder instance = new StringBuilder();
    instance.replace(p0, p1, p2);
  }

  @Test
  public void repeat_test_2291(int p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.repeat(p0, p1);
  }

  @Test
  public void repeat_test_2292(CharSequence p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.repeat(p0, p1);
  }

  @Test
  public void appendCodePoint_test_2293(int p0) {
    StringBuilder instance = new StringBuilder();
    instance.appendCodePoint(p0);
  }

  @Test
  public void delete_test_2294(int p0, int p1) {
    StringBuilder instance = new StringBuilder();
    instance.delete(p0, p1);
  }

  @Test
  public void deleteCharAt_test_2295(int p0) {
    StringBuilder instance = new StringBuilder();
    instance.deleteCharAt(p0);
  }
}
