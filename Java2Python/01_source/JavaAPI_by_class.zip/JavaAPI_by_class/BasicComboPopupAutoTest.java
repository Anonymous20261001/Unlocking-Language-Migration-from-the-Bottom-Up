package generated.test;

import javax.swing.JComboBox;
import javax.swing.plaf.basic.BasicComboPopup;
import org.junit.jupiter.api.Test;

public class BasicComboPopupAutoTest {
  @Test
  public void uninstallingUI_test_8687(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.uninstallingUI();
  }

  @Test
  public void getMouseListener_test_8688(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.getMouseListener();
  }

  @Test
  public void getMouseMotionListener_test_8689(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.getMouseMotionListener();
  }

  @Test
  public void getKeyListener_test_8690(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.getKeyListener();
  }

  @Test
  public void getList_test_8691(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.getList();
  }

  @Test
  public void getAccessibleContext_test_8692(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.getAccessibleContext();
  }

  @Test
  public void show_test_8693(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.show();
  }

  @Test
  public void hide_test_8694(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.hide();
  }

  @Test
  public void isFocusTraversable_test_8695(JComboBox c0) {
    BasicComboPopup instance = new BasicComboPopup(c0);
    instance.isFocusTraversable();
  }
}
