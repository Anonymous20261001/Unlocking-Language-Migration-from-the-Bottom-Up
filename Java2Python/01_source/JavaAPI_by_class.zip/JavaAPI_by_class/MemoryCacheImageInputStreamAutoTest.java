package generated.test;

import java.io.InputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import org.junit.jupiter.api.Test;

public class MemoryCacheImageInputStreamAutoTest {
  @Test
  public void isCachedFile_test_5501(InputStream c0) {
    MemoryCacheImageInputStream instance = new MemoryCacheImageInputStream(c0);
    instance.isCachedFile();
  }

  @Test
  public void isCachedMemory_test_5502(InputStream c0) {
    MemoryCacheImageInputStream instance = new MemoryCacheImageInputStream(c0);
    instance.isCachedMemory();
  }

  @Test
  public void isCached_test_5503(InputStream c0) {
    MemoryCacheImageInputStream instance = new MemoryCacheImageInputStream(c0);
    instance.isCached();
  }
}
