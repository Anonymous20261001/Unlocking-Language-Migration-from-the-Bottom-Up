package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalScrollBarUI;
import org.junit.jupiter.api.Test;

public class MetalScrollBarUIAutoTest {
  @Test
  public void createUI_test_9246(JComponent p0) {
    MetalScrollBarUI instance = new MetalScrollBarUI();
    MetalScrollBarUI.createUI(p0);
  }

  @Test
  public void getPreferredSize_test_9247(JComponent p0) {
    MetalScrollBarUI instance = new MetalScrollBarUI();
    instance.getPreferredSize(p0);
  }
}
