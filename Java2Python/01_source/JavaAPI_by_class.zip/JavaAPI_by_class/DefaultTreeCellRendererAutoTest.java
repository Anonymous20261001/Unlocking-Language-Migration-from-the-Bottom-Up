package generated.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.lang.Object;
import java.lang.String;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import org.junit.jupiter.api.Test;

public class DefaultTreeCellRendererAutoTest {
  @Test
  public void getLeafIcon_test_10660() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getLeafIcon();
  }

  @Test
  public void getOpenIcon_test_10661() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getOpenIcon();
  }

  @Test
  public void getClosedIcon_test_10662() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getClosedIcon();
  }

  @Test
  public void setLeafIcon_test_10663(Icon p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setLeafIcon(p0);
  }

  @Test
  public void setClosedIcon_test_10664(Icon p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setClosedIcon(p0);
  }

  @Test
  public void setOpenIcon_test_10665(Icon p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setOpenIcon(p0);
  }

  @Test
  public void getDefaultOpenIcon_test_10666() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getDefaultOpenIcon();
  }

  @Test
  public void getDefaultClosedIcon_test_10667() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getDefaultClosedIcon();
  }

  @Test
  public void getDefaultLeafIcon_test_10668() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getDefaultLeafIcon();
  }

  @Test
  public void getTreeCellRendererComponent_test_10669(JTree p0, Object p1, boolean p2, boolean p3,
      boolean p4, int p5, boolean p6) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getTreeCellRendererComponent(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void getTextSelectionColor_test_10670() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getTextSelectionColor();
  }

  @Test
  public void setTextSelectionColor_test_10671(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setTextSelectionColor(p0);
  }

  @Test
  public void getBackgroundSelectionColor_test_10672() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getBackgroundSelectionColor();
  }

  @Test
  public void setBackgroundSelectionColor_test_10673(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setBackgroundSelectionColor(p0);
  }

  @Test
  public void getTextNonSelectionColor_test_10674() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getTextNonSelectionColor();
  }

  @Test
  public void setTextNonSelectionColor_test_10675(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setTextNonSelectionColor(p0);
  }

  @Test
  public void getBackgroundNonSelectionColor_test_10676() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getBackgroundNonSelectionColor();
  }

  @Test
  public void setBackgroundNonSelectionColor_test_10677(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setBackgroundNonSelectionColor(p0);
  }

  @Test
  public void getBorderSelectionColor_test_10678() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getBorderSelectionColor();
  }

  @Test
  public void setBorderSelectionColor_test_10679(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setBorderSelectionColor(p0);
  }

  @Test
  public void getFont_test_10680() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getFont();
  }

  @Test
  public void setFont_test_10681(Font p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setFont(p0);
  }

  @Test
  public void paint_test_10682(Graphics p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.paint(p0);
  }

  @Test
  public void firePropertyChange_test_10683(String p0, char p1, char p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10684(String p0, short p1, short p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10685(String p0, byte p1, byte p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10686(String p0, float p1, float p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10687(String p0, long p1, long p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10688(String p0, double p1, double p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10689(String p0, int p1, int p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void firePropertyChange_test_10690(String p0, boolean p1, boolean p2) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.firePropertyChange(p0, p1, p2);
  }

  @Test
  public void getPreferredSize_test_10691() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.getPreferredSize();
  }

  @Test
  public void repaint_test_10692(Rectangle p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.repaint(p0);
  }

  @Test
  public void repaint_test_10693(long p0, int p1, int p2, int p3, int p4) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.repaint(p0, p1, p2, p3, p4);
  }

  @Test
  public void repaint_test_10694() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.repaint();
  }

  @Test
  public void setBackground_test_10695(Color p0) {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.setBackground(p0);
  }

  @Test
  public void revalidate_test_10696() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.revalidate();
  }

  @Test
  public void updateUI_test_10697() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.updateUI();
  }

  @Test
  public void validate_test_10698() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.validate();
  }

  @Test
  public void invalidate_test_10699() {
    DefaultTreeCellRenderer instance = new DefaultTreeCellRenderer();
    instance.invalidate();
  }
}
