package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.lang.String;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;
import org.junit.jupiter.api.Test;

public class ScrollPaneLayoutAutoTest {
  @Test
  public void setVerticalScrollBarPolicy_test_8257(int p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.setVerticalScrollBarPolicy(p0);
  }

  @Test
  public void setHorizontalScrollBarPolicy_test_8258(int p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.setHorizontalScrollBarPolicy(p0);
  }

  @Test
  public void syncWithScrollPane_test_8259(JScrollPane p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.syncWithScrollPane(p0);
  }

  @Test
  public void getColumnHeader_test_8260() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getColumnHeader();
  }

  @Test
  public void getRowHeader_test_8261() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getRowHeader();
  }

  @Test
  public void getVerticalScrollBar_test_8262() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getVerticalScrollBar();
  }

  @Test
  public void getHorizontalScrollBar_test_8263() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getHorizontalScrollBar();
  }

  @Test
  public void getViewport_test_8264() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getViewport();
  }

  @Test
  public void getVerticalScrollBarPolicy_test_8265() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getVerticalScrollBarPolicy();
  }

  @Test
  public void getHorizontalScrollBarPolicy_test_8266() {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getHorizontalScrollBarPolicy();
  }

  @Test
  public void getViewportBorderBounds_test_8267(JScrollPane p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getViewportBorderBounds(p0);
  }

  @Test
  public void getCorner_test_8268(String p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.getCorner(p0);
  }

  @Test
  public void removeLayoutComponent_test_8269(Component p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.removeLayoutComponent(p0);
  }

  @Test
  public void addLayoutComponent_test_8270(String p0, Component p1) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.addLayoutComponent(p0, p1);
  }

  @Test
  public void layoutContainer_test_8271(Container p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.layoutContainer(p0);
  }

  @Test
  public void preferredLayoutSize_test_8272(Container p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.preferredLayoutSize(p0);
  }

  @Test
  public void minimumLayoutSize_test_8273(Container p0) {
    ScrollPaneLayout instance = new ScrollPaneLayout();
    instance.minimumLayoutSize(p0);
  }
}
