package generated.test;

import java.nio.charset.MalformedInputException;
import org.junit.jupiter.api.Test;

public class MalformedInputExceptionAutoTest {
  @Test
  public void getInputLength_test_2642(int c0) {
    MalformedInputException instance = new MalformedInputException(c0);
    instance.getInputLength();
  }

  @Test
  public void getMessage_test_2643(int c0) {
    MalformedInputException instance = new MalformedInputException(c0);
    instance.getMessage();
  }
}
