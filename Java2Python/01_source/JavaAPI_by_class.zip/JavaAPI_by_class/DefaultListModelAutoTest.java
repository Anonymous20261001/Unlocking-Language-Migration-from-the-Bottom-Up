package generated.test;

import java.lang.Object;
import java.util.Collection;
import javax.swing.DefaultListModel;
import org.junit.jupiter.api.Test;

public class DefaultListModelAutoTest {
  @Test
  public void setElementAt_test_6736(Object p0, int p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.setElementAt(p0, p1);
  }

  @Test
  public void getElementAt_test_6737(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.getElementAt(p0);
  }

  @Test
  public void firstElement_test_6738() {
    DefaultListModel instance = new DefaultListModel();
    instance.firstElement();
  }

  @Test
  public void lastElement_test_6739() {
    DefaultListModel instance = new DefaultListModel();
    instance.lastElement();
  }

  @Test
  public void addElement_test_6740(Object p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.addElement(p0);
  }

  @Test
  public void removeElementAt_test_6741(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.removeElementAt(p0);
  }

  @Test
  public void insertElementAt_test_6742(Object p0, int p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.insertElementAt(p0, p1);
  }

  @Test
  public void removeAllElements_test_6743() {
    DefaultListModel instance = new DefaultListModel();
    instance.removeAllElements();
  }

  @Test
  public void removeElement_test_6744(Object p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.removeElement(p0);
  }

  @Test
  public void remove_test_6745(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.remove(p0);
  }

  @Test
  public void size_test_6746() {
    DefaultListModel instance = new DefaultListModel();
    instance.size();
  }

  @Test
  public void get_test_6747(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.get(p0);
  }

  @Test
  public void toString_test_6748() {
    DefaultListModel instance = new DefaultListModel();
    instance.toString();
  }

  @Test
  public void indexOf_test_6749(Object p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.indexOf(p0);
  }

  @Test
  public void indexOf_test_6750(Object p0, int p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.indexOf(p0, p1);
  }

  @Test
  public void clear_test_6751() {
    DefaultListModel instance = new DefaultListModel();
    instance.clear();
  }

  @Test
  public void lastIndexOf_test_6752(Object p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.lastIndexOf(p0);
  }

  @Test
  public void lastIndexOf_test_6753(Object p0, int p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.lastIndexOf(p0, p1);
  }

  @Test
  public void isEmpty_test_6754() {
    DefaultListModel instance = new DefaultListModel();
    instance.isEmpty();
  }

  @Test
  public void add_test_6755(int p0, Object p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.add(p0, p1);
  }

  @Test
  public void toArray_test_6756() {
    DefaultListModel instance = new DefaultListModel();
    instance.toArray();
  }

  @Test
  public void contains_test_6757(Object p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.contains(p0);
  }

  @Test
  public void elements_test_6758() {
    DefaultListModel instance = new DefaultListModel();
    instance.elements();
  }

  @Test
  public void addAll_test_6759(Collection p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.addAll(p0);
  }

  @Test
  public void addAll_test_6760(int p0, Collection p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.addAll(p0, p1);
  }

  @Test
  public void trimToSize_test_6761() {
    DefaultListModel instance = new DefaultListModel();
    instance.trimToSize();
  }

  @Test
  public void set_test_6762(int p0, Object p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.set(p0, p1);
  }

  @Test
  public void getSize_test_6763() {
    DefaultListModel instance = new DefaultListModel();
    instance.getSize();
  }

  @Test
  public void capacity_test_6764() {
    DefaultListModel instance = new DefaultListModel();
    instance.capacity();
  }

  @Test
  public void ensureCapacity_test_6765(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.ensureCapacity(p0);
  }

  @Test
  public void elementAt_test_6766(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.elementAt(p0);
  }

  @Test
  public void removeRange_test_6767(int p0, int p1) {
    DefaultListModel instance = new DefaultListModel();
    instance.removeRange(p0, p1);
  }

  @Test
  public void copyInto_test_6768(Object[] p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.copyInto(p0);
  }

  @Test
  public void setSize_test_6769(int p0) {
    DefaultListModel instance = new DefaultListModel();
    instance.setSize(p0);
  }
}
