package generated.test;

import java.lang.String;
import java.net.URISyntaxException;
import org.junit.jupiter.api.Test;

public class URISyntaxExceptionAutoTest {
  @Test
  public void getMessage_test_2626(String c0, String c1) {
    URISyntaxException instance = new URISyntaxException(c0, c1);
    instance.getMessage();
  }

  @Test
  public void getIndex_test_2627(String c0, String c1) {
    URISyntaxException instance = new URISyntaxException(c0, c1);
    instance.getIndex();
  }

  @Test
  public void getReason_test_2628(String c0, String c1) {
    URISyntaxException instance = new URISyntaxException(c0, c1);
    instance.getReason();
  }

  @Test
  public void getInput_test_2629(String c0, String c1) {
    URISyntaxException instance = new URISyntaxException(c0, c1);
    instance.getInput();
  }
}
