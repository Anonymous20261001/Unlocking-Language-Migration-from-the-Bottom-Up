package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.MBeanNotificationInfo;
import org.junit.jupiter.api.Test;

public class MBeanNotificationInfoAutoTest {
  @Test
  public void getNotifTypes_test_5572(String[] c0, String c1, String c2) {
    MBeanNotificationInfo instance = new MBeanNotificationInfo(c0, c1, c2);
    instance.getNotifTypes();
  }

  @Test
  public void equals_test_5573(Object p0, String[] c0, String c1, String c2) {
    MBeanNotificationInfo instance = new MBeanNotificationInfo(c0, c1, c2);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5574(String[] c0, String c1, String c2) {
    MBeanNotificationInfo instance = new MBeanNotificationInfo(c0, c1, c2);
    instance.toString();
  }

  @Test
  public void hashCode_test_5575(String[] c0, String c1, String c2) {
    MBeanNotificationInfo instance = new MBeanNotificationInfo(c0, c1, c2);
    instance.hashCode();
  }

  @Test
  public void clone_test_5576(String[] c0, String c1, String c2) {
    MBeanNotificationInfo instance = new MBeanNotificationInfo(c0, c1, c2);
    instance.clone();
  }
}
