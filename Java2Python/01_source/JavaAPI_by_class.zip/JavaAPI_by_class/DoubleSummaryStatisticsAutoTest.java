package generated.test;

import java.util.DoubleSummaryStatistics;
import org.junit.jupiter.api.Test;

public class DoubleSummaryStatisticsAutoTest {
  @Test
  public void toString_test_3417() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.toString();
  }

  @Test
  public void accept_test_3418(double p0) {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.accept(p0);
  }

  @Test
  public void getCount_test_3419() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.getCount();
  }

  @Test
  public void combine_test_3420(DoubleSummaryStatistics p0) {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.combine(p0);
  }

  @Test
  public void getSum_test_3421() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.getSum();
  }

  @Test
  public void getMin_test_3422() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.getMin();
  }

  @Test
  public void getAverage_test_3423() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.getAverage();
  }

  @Test
  public void getMax_test_3424() {
    DoubleSummaryStatistics instance = new DoubleSummaryStatistics();
    instance.getMax();
  }
}
