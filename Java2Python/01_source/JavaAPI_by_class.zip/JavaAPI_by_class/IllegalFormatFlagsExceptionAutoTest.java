package generated.test;

import java.lang.String;
import java.util.IllegalFormatFlagsException;
import org.junit.jupiter.api.Test;

public class IllegalFormatFlagsExceptionAutoTest {
  @Test
  public void getMessage_test_3569(String c0) {
    IllegalFormatFlagsException instance = new IllegalFormatFlagsException(c0);
    instance.getMessage();
  }

  @Test
  public void getFlags_test_3570(String c0) {
    IllegalFormatFlagsException instance = new IllegalFormatFlagsException(c0);
    instance.getFlags();
  }
}
