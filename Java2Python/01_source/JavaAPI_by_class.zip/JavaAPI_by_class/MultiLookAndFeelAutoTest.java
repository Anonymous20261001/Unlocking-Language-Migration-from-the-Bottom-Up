package generated.test;

import java.util.Vector;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.multi.MultiLookAndFeel;
import org.junit.jupiter.api.Test;

public class MultiLookAndFeelAutoTest {
  @Test
  public void getDefaults_test_9418() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.getDefaults();
  }

  @Test
  public void isNativeLookAndFeel_test_9419() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.isNativeLookAndFeel();
  }

  @Test
  public void getDescription_test_9420() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.getDescription();
  }

  @Test
  public void createUIs_test_9421(ComponentUI p0, Vector p1, JComponent p2) {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    MultiLookAndFeel.createUIs(p0, p1, p2);
  }

  @Test
  public void isSupportedLookAndFeel_test_9422() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.isSupportedLookAndFeel();
  }

  @Test
  public void getName_test_9423() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.getName();
  }

  @Test
  public void getID_test_9424() {
    MultiLookAndFeel instance = new MultiLookAndFeel();
    instance.getID();
  }
}
