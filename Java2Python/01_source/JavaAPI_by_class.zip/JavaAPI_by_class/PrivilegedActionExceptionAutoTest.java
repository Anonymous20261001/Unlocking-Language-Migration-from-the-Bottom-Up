package generated.test;

import java.lang.Exception;
import java.security.PrivilegedActionException;
import org.junit.jupiter.api.Test;

public class PrivilegedActionExceptionAutoTest {
  @Test
  public void toString_test_2724(Exception c0) {
    PrivilegedActionException instance = new PrivilegedActionException(c0);
    instance.toString();
  }

  @Test
  public void getException_test_2725(Exception c0) {
    PrivilegedActionException instance = new PrivilegedActionException(c0);
    instance.getException();
  }
}
