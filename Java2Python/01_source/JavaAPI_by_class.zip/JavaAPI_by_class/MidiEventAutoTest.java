package generated.test;

import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiMessage;
import org.junit.jupiter.api.Test;

public class MidiEventAutoTest {
  @Test
  public void setTick_test_6478(long p0, MidiMessage c0, long c1) {
    MidiEvent instance = new MidiEvent(c0, c1);
    instance.setTick(p0);
  }

  @Test
  public void getTick_test_6479(MidiMessage c0, long c1) {
    MidiEvent instance = new MidiEvent(c0, c1);
    instance.getTick();
  }

  @Test
  public void getMessage_test_6480(MidiMessage c0, long c1) {
    MidiEvent instance = new MidiEvent(c0, c1);
    instance.getMessage();
  }
}
