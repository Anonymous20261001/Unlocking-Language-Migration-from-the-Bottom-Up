package generated.test;

import java.lang.Object;
import java.lang.Runnable;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorCompletionService;
import org.junit.jupiter.api.Test;

public class ExecutorCompletionServiceAutoTest {
  @Test
  public void poll_test_4464(Executor c0) {
    ExecutorCompletionService instance = new ExecutorCompletionService(c0);
    instance.poll();
  }

  @Test
  public void submit_test_4465(Callable p0, Executor c0) {
    ExecutorCompletionService instance = new ExecutorCompletionService(c0);
    instance.submit(p0);
  }

  @Test
  public void submit_test_4466(Runnable p0, Object p1, Executor c0) {
    ExecutorCompletionService instance = new ExecutorCompletionService(c0);
    instance.submit(p0, p1);
  }
}
