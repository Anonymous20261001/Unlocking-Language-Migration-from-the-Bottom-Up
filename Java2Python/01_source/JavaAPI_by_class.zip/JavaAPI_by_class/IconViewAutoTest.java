package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.text.Element;
import javax.swing.text.IconView;
import javax.swing.text.Position;
import org.junit.jupiter.api.Test;

public class IconViewAutoTest {
  @Test
  public void viewToModel_test_10282(float p0, float p1, Shape p2, Position.Bias[] p3, Element c0) {
    IconView instance = new IconView(c0);
    instance.viewToModel(p0, p1, p2, p3);
  }

  @Test
  public void getPreferredSpan_test_10283(int p0, Element c0) {
    IconView instance = new IconView(c0);
    instance.getPreferredSpan(p0);
  }

  @Test
  public void paint_test_10284(Graphics p0, Shape p1, Element c0) {
    IconView instance = new IconView(c0);
    instance.paint(p0, p1);
  }

  @Test
  public void getAlignment_test_10285(int p0, Element c0) {
    IconView instance = new IconView(c0);
    instance.getAlignment(p0);
  }
}
