package generated.test;

import java.awt.Cursor;
import org.junit.jupiter.api.Test;

public class CursorAutoTest {
  @Test
  public void getPredefinedCursor_test_164(int p0, int c0) {
    Cursor instance = new Cursor(c0);
    Cursor.getPredefinedCursor(p0);
  }

  @Test
  public void getDefaultCursor_test_165(int c0) {
    Cursor instance = new Cursor(c0);
    Cursor.getDefaultCursor();
  }

  @Test
  public void getName_test_166(int c0) {
    Cursor instance = new Cursor(c0);
    instance.getName();
  }

  @Test
  public void toString_test_167(int c0) {
    Cursor instance = new Cursor(c0);
    instance.toString();
  }

  @Test
  public void getType_test_168(int c0) {
    Cursor instance = new Cursor(c0);
    instance.getType();
  }
}
