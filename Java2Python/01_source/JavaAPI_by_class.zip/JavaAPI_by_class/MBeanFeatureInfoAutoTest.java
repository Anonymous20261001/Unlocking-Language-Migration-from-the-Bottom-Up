package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.MBeanFeatureInfo;
import org.junit.jupiter.api.Test;

public class MBeanFeatureInfoAutoTest {
  @Test
  public void getDescription_test_5567(String c0, String c1) {
    MBeanFeatureInfo instance = new MBeanFeatureInfo(c0, c1);
    instance.getDescription();
  }

  @Test
  public void getName_test_5568(String c0, String c1) {
    MBeanFeatureInfo instance = new MBeanFeatureInfo(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_5569(Object p0, String c0, String c1) {
    MBeanFeatureInfo instance = new MBeanFeatureInfo(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_5570(String c0, String c1) {
    MBeanFeatureInfo instance = new MBeanFeatureInfo(c0, c1);
    instance.hashCode();
  }

  @Test
  public void getDescriptor_test_5571(String c0, String c1) {
    MBeanFeatureInfo instance = new MBeanFeatureInfo(c0, c1);
    instance.getDescriptor();
  }
}
