package generated.test;

import java.awt.HeadlessException;
import org.junit.jupiter.api.Test;

public class HeadlessExceptionAutoTest {
  @Test
  public void getMessage_test_348() {
    HeadlessException instance = new HeadlessException();
    instance.getMessage();
  }
}
