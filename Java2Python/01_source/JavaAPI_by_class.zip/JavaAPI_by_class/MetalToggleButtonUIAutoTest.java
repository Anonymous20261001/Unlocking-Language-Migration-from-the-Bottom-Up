package generated.test;

import java.awt.Graphics;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalToggleButtonUI;
import org.junit.jupiter.api.Test;

public class MetalToggleButtonUIAutoTest {
  @Test
  public void createUI_test_9275(JComponent p0) {
    MetalToggleButtonUI instance = new MetalToggleButtonUI();
    MetalToggleButtonUI.createUI(p0);
  }

  @Test
  public void installDefaults_test_9276(AbstractButton p0) {
    MetalToggleButtonUI instance = new MetalToggleButtonUI();
    instance.installDefaults(p0);
  }

  @Test
  public void update_test_9277(Graphics p0, JComponent p1) {
    MetalToggleButtonUI instance = new MetalToggleButtonUI();
    instance.update(p0, p1);
  }
}
