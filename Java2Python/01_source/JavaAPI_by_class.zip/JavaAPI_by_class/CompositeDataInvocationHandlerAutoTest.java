package generated.test;

import javax.management.openmbean.CompositeData;
import javax.management.openmbean.CompositeDataInvocationHandler;
import org.junit.jupiter.api.Test;

public class CompositeDataInvocationHandlerAutoTest {
  @Test
  public void getCompositeData_test_5743(CompositeData c0) {
    CompositeDataInvocationHandler instance = new CompositeDataInvocationHandler(c0);
    instance.getCompositeData();
  }
}
