package generated.test;

import java.lang.String;
import java.util.Map;
import javax.security.auth.login.AppConfigurationEntry;
import org.junit.jupiter.api.Test;

public class AppConfigurationEntryAutoTest {
  @Test
  public void getOptions_test_6422(String c0, AppConfigurationEntry.LoginModuleControlFlag c1,
      Map c2) {
    AppConfigurationEntry instance = new AppConfigurationEntry(c0, c1, c2);
    instance.getOptions();
  }

  @Test
  public void getLoginModuleName_test_6423(String c0,
      AppConfigurationEntry.LoginModuleControlFlag c1, Map c2) {
    AppConfigurationEntry instance = new AppConfigurationEntry(c0, c1, c2);
    instance.getLoginModuleName();
  }

  @Test
  public void getControlFlag_test_6424(String c0, AppConfigurationEntry.LoginModuleControlFlag c1,
      Map c2) {
    AppConfigurationEntry instance = new AppConfigurationEntry(c0, c1, c2);
    instance.getControlFlag();
  }
}
