package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.junit.jupiter.api.Test;

public class LocaleAutoTest {
  @Test
  public void equals_test_3650(Object p0, String c0) {
    Locale instance = new Locale(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_3651(String c0) {
    Locale instance = new Locale(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_3652(String c0) {
    Locale instance = new Locale(c0);
    instance.hashCode();
  }

  @Test
  public void clone_test_3653(String c0) {
    Locale instance = new Locale(c0);
    instance.clone();
  }

  @Test
  public void of_test_3654(String p0, String p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.of(p0, p1);
  }

  @Test
  public void of_test_3655(String p0, String p1, String p2, String c0) {
    Locale instance = new Locale(c0);
    Locale.of(p0, p1, p2);
  }

  @Test
  public void of_test_3656(String p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.of(p0);
  }

  @Test
  public void getDefault_test_3657(Locale.Category p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.getDefault(p0);
  }

  @Test
  public void getDefault_test_3658(String c0) {
    Locale instance = new Locale(c0);
    Locale.getDefault();
  }

  @Test
  public void lookup_test_3659(List p0, Collection p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.lookup(p0, p1);
  }

  @Test
  public void filter_test_3660(List p0, Collection p1, Locale.FilteringMode p2, String c0) {
    Locale instance = new Locale(c0);
    Locale.filter(p0, p1, p2);
  }

  @Test
  public void filter_test_3661(List p0, Collection p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.filter(p0, p1);
  }

  @Test
  public void getLanguage_test_3662(String c0) {
    Locale instance = new Locale(c0);
    instance.getLanguage();
  }

  @Test
  public void getDisplayName_test_3663(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayName();
  }

  @Test
  public void getDisplayName_test_3664(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayName(p0);
  }

  @Test
  public void getAvailableLocales_test_3665(String c0) {
    Locale instance = new Locale(c0);
    Locale.getAvailableLocales();
  }

  @Test
  public void getUnicodeLocaleType_test_3666(String p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleType(p0);
  }

  @Test
  public void getCountry_test_3667(String c0) {
    Locale instance = new Locale(c0);
    instance.getCountry();
  }

  @Test
  public void stripExtensions_test_3668(String c0) {
    Locale instance = new Locale(c0);
    instance.stripExtensions();
  }

  @Test
  public void hasExtensions_test_3669(String c0) {
    Locale instance = new Locale(c0);
    instance.hasExtensions();
  }

  @Test
  public void getVariant_test_3670(String c0) {
    Locale instance = new Locale(c0);
    instance.getVariant();
  }

  @Test
  public void setDefault_test_3671(Locale.Category p0, Locale p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.setDefault(p0, p1);
  }

  @Test
  public void setDefault_test_3672(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.setDefault(p0);
  }

  @Test
  public void getScript_test_3673(String c0) {
    Locale instance = new Locale(c0);
    instance.getScript();
  }

  @Test
  public void getUnicodeLocaleAttributes_test_3674(String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleAttributes();
  }

  @Test
  public void getUnicodeLocaleKeys_test_3675(String c0) {
    Locale instance = new Locale(c0);
    instance.getUnicodeLocaleKeys();
  }

  @Test
  public void getDisplayLanguage_test_3676(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayLanguage();
  }

  @Test
  public void getDisplayLanguage_test_3677(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayLanguage(p0);
  }

  @Test
  public void getDisplayScript_test_3678(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayScript(p0);
  }

  @Test
  public void getDisplayScript_test_3679(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayScript();
  }

  @Test
  public void getDisplayCountry_test_3680(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayCountry(p0);
  }

  @Test
  public void getDisplayCountry_test_3681(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayCountry();
  }

  @Test
  public void getDisplayVariant_test_3682(Locale p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayVariant(p0);
  }

  @Test
  public void getDisplayVariant_test_3683(String c0) {
    Locale instance = new Locale(c0);
    instance.getDisplayVariant();
  }

  @Test
  public void filterTags_test_3684(List p0, Collection p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.filterTags(p0, p1);
  }

  @Test
  public void filterTags_test_3685(List p0, Collection p1, Locale.FilteringMode p2, String c0) {
    Locale instance = new Locale(c0);
    Locale.filterTags(p0, p1, p2);
  }

  @Test
  public void lookupTag_test_3686(List p0, Collection p1, String c0) {
    Locale instance = new Locale(c0);
    Locale.lookupTag(p0, p1);
  }

  @Test
  public void availableLocales_test_3687(String c0) {
    Locale instance = new Locale(c0);
    Locale.availableLocales();
  }

  @Test
  public void getISOCountries_test_3688(Locale.IsoCountryCode p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.getISOCountries(p0);
  }

  @Test
  public void getISOCountries_test_3689(String c0) {
    Locale instance = new Locale(c0);
    Locale.getISOCountries();
  }

  @Test
  public void getISOLanguages_test_3690(String c0) {
    Locale instance = new Locale(c0);
    Locale.getISOLanguages();
  }

  @Test
  public void getExtension_test_3691(char p0, String c0) {
    Locale instance = new Locale(c0);
    instance.getExtension(p0);
  }

  @Test
  public void getExtensionKeys_test_3692(String c0) {
    Locale instance = new Locale(c0);
    instance.getExtensionKeys();
  }

  @Test
  public void toLanguageTag_test_3693(String c0) {
    Locale instance = new Locale(c0);
    instance.toLanguageTag();
  }

  @Test
  public void caseFoldLanguageTag_test_3694(String p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.caseFoldLanguageTag(p0);
  }

  @Test
  public void forLanguageTag_test_3695(String p0, String c0) {
    Locale instance = new Locale(c0);
    Locale.forLanguageTag(p0);
  }
}
