package generated.test;

import java.awt.BasicStroke;
import java.awt.Shape;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class BasicStrokeAutoTest {
  @Test
  public void createStrokedShape_test_1(Shape p0) {
    BasicStroke instance = new BasicStroke();
    instance.createStrokedShape(p0);
  }

  @Test
  public void getLineWidth_test_2() {
    BasicStroke instance = new BasicStroke();
    instance.getLineWidth();
  }

  @Test
  public void getEndCap_test_3() {
    BasicStroke instance = new BasicStroke();
    instance.getEndCap();
  }

  @Test
  public void getLineJoin_test_4() {
    BasicStroke instance = new BasicStroke();
    instance.getLineJoin();
  }

  @Test
  public void getMiterLimit_test_5() {
    BasicStroke instance = new BasicStroke();
    instance.getMiterLimit();
  }

  @Test
  public void getDashArray_test_6() {
    BasicStroke instance = new BasicStroke();
    instance.getDashArray();
  }

  @Test
  public void getDashPhase_test_7() {
    BasicStroke instance = new BasicStroke();
    instance.getDashPhase();
  }

  @Test
  public void equals_test_8(Object p0) {
    BasicStroke instance = new BasicStroke();
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_9() {
    BasicStroke instance = new BasicStroke();
    instance.hashCode();
  }
}
