package generated.test;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicSpinnerUI;
import org.junit.jupiter.api.Test;

public class BasicSpinnerUIAutoTest {
  @Test
  public void installUI_test_8932(JComponent p0) {
    BasicSpinnerUI instance = new BasicSpinnerUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_8933(JComponent p0) {
    BasicSpinnerUI instance = new BasicSpinnerUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void createUI_test_8934(JComponent p0) {
    BasicSpinnerUI instance = new BasicSpinnerUI();
    BasicSpinnerUI.createUI(p0);
  }

  @Test
  public void getBaseline_test_8935(JComponent p0, int p1, int p2) {
    BasicSpinnerUI instance = new BasicSpinnerUI();
    instance.getBaseline(p0, p1, p2);
  }

  @Test
  public void getBaselineResizeBehavior_test_8936(JComponent p0) {
    BasicSpinnerUI instance = new BasicSpinnerUI();
    instance.getBaselineResizeBehavior(p0);
  }
}
