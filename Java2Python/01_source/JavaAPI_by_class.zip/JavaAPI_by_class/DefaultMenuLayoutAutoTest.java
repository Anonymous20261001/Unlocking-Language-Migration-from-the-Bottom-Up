package generated.test;

import java.awt.Container;
import javax.swing.plaf.basic.DefaultMenuLayout;
import org.junit.jupiter.api.Test;

public class DefaultMenuLayoutAutoTest {
  @Test
  public void preferredLayoutSize_test_9073(Container p0, Container c0, int c1) {
    DefaultMenuLayout instance = new DefaultMenuLayout(c0, c1);
    instance.preferredLayoutSize(p0);
  }
}
