package generated.test;

import java.io.PrintStream;
import java.io.PrintWriter;
import javax.xml.crypto.URIReferenceException;
import org.junit.jupiter.api.Test;

public class URIReferenceExceptionAutoTest {
  @Test
  public void printStackTrace_test_10868() {
    URIReferenceException instance = new URIReferenceException();
    instance.printStackTrace();
  }

  @Test
  public void printStackTrace_test_10869(PrintStream p0) {
    URIReferenceException instance = new URIReferenceException();
    instance.printStackTrace(p0);
  }

  @Test
  public void printStackTrace_test_10870(PrintWriter p0) {
    URIReferenceException instance = new URIReferenceException();
    instance.printStackTrace(p0);
  }

  @Test
  public void getCause_test_10871() {
    URIReferenceException instance = new URIReferenceException();
    instance.getCause();
  }

  @Test
  public void getURIReference_test_10872() {
    URIReferenceException instance = new URIReferenceException();
    instance.getURIReference();
  }
}
