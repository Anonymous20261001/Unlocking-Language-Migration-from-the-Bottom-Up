package generated.test;

import java.io.FilePermission;
import java.lang.Object;
import java.lang.String;
import java.security.Permission;
import org.junit.jupiter.api.Test;

public class FilePermissionAutoTest {
  @Test
  public void getActions_test_1777(String c0, String c1) {
    FilePermission instance = new FilePermission(c0, c1);
    instance.getActions();
  }

  @Test
  public void equals_test_1778(Object p0, String c0, String c1) {
    FilePermission instance = new FilePermission(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void hashCode_test_1779(String c0, String c1) {
    FilePermission instance = new FilePermission(c0, c1);
    instance.hashCode();
  }

  @Test
  public void implies_test_1780(Permission p0, String c0, String c1) {
    FilePermission instance = new FilePermission(c0, c1);
    instance.implies(p0);
  }

  @Test
  public void newPermissionCollection_test_1781(String c0, String c1) {
    FilePermission instance = new FilePermission(c0, c1);
    instance.newPermissionCollection();
  }
}
