package generated.test;

import javax.management.relation.RoleList;
import javax.management.relation.RoleResult;
import javax.management.relation.RoleUnresolvedList;
import org.junit.jupiter.api.Test;

public class RoleResultAutoTest {
  @Test
  public void getRoles_test_5822(RoleList c0, RoleUnresolvedList c1) {
    RoleResult instance = new RoleResult(c0, c1);
    instance.getRoles();
  }

  @Test
  public void setRoles_test_5823(RoleList p0, RoleList c0, RoleUnresolvedList c1) {
    RoleResult instance = new RoleResult(c0, c1);
    instance.setRoles(p0);
  }

  @Test
  public void setRolesUnresolved_test_5824(RoleUnresolvedList p0, RoleList c0,
      RoleUnresolvedList c1) {
    RoleResult instance = new RoleResult(c0, c1);
    instance.setRolesUnresolved(p0);
  }

  @Test
  public void getRolesUnresolved_test_5825(RoleList c0, RoleUnresolvedList c1) {
    RoleResult instance = new RoleResult(c0, c1);
    instance.getRolesUnresolved();
  }
}
