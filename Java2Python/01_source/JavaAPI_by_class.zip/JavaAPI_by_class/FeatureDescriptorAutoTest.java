package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {
  @Test
  public void setPreferred_test_1536(boolean p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setPreferred(p0);
  }

  @Test
  public void setShortDescription_test_1537(String p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setShortDescription(p0);
  }

  @Test
  public void setDisplayName_test_1538(String p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setDisplayName(p0);
  }

  @Test
  public void isExpert_test_1539() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.isExpert();
  }

  @Test
  public void setExpert_test_1540(boolean p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setExpert(p0);
  }

  @Test
  public void setHidden_test_1541(boolean p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setHidden(p0);
  }

  @Test
  public void isPreferred_test_1542() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.isPreferred();
  }

  @Test
  public void getShortDescription_test_1543() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.getShortDescription();
  }

  @Test
  public void attributeNames_test_1544() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.attributeNames();
  }

  @Test
  public void getName_test_1545() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.getName();
  }

  @Test
  public void toString_test_1546() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.toString();
  }

  @Test
  public void isHidden_test_1547() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.isHidden();
  }

  @Test
  public void getValue_test_1548(String p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.getValue(p0);
  }

  @Test
  public void setName_test_1549(String p0) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setName(p0);
  }

  @Test
  public void setValue_test_1550(String p0, Object p1) {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.setValue(p0, p1);
  }

  @Test
  public void getDisplayName_test_1551() {
    FeatureDescriptor instance = new FeatureDescriptor();
    instance.getDisplayName();
  }
}
