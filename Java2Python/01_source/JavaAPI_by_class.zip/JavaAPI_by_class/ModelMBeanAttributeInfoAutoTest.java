package generated.test;

import javax.management.Descriptor;
import javax.management.modelmbean.ModelMBeanAttributeInfo;
import org.junit.jupiter.api.Test;

public class ModelMBeanAttributeInfoAutoTest {
  @Test
  public void setDescriptor_test_5682(Descriptor p0, ModelMBeanAttributeInfo c0) {
    ModelMBeanAttributeInfo instance = new ModelMBeanAttributeInfo(c0);
    instance.setDescriptor(p0);
  }

  @Test
  public void toString_test_5683(ModelMBeanAttributeInfo c0) {
    ModelMBeanAttributeInfo instance = new ModelMBeanAttributeInfo(c0);
    instance.toString();
  }

  @Test
  public void clone_test_5684(ModelMBeanAttributeInfo c0) {
    ModelMBeanAttributeInfo instance = new ModelMBeanAttributeInfo(c0);
    instance.clone();
  }

  @Test
  public void getDescriptor_test_5685(ModelMBeanAttributeInfo c0) {
    ModelMBeanAttributeInfo instance = new ModelMBeanAttributeInfo(c0);
    instance.getDescriptor();
  }
}
