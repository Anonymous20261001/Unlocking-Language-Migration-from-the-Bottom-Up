package generated.test;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.invoke.VolatileCallSite;
import org.junit.jupiter.api.Test;

public class VolatileCallSiteAutoTest {
  @Test
  public void getTarget_test_2400(MethodType c0) {
    VolatileCallSite instance = new VolatileCallSite(c0);
    instance.getTarget();
  }

  @Test
  public void dynamicInvoker_test_2401(MethodType c0) {
    VolatileCallSite instance = new VolatileCallSite(c0);
    instance.dynamicInvoker();
  }

  @Test
  public void setTarget_test_2402(MethodHandle p0, MethodType c0) {
    VolatileCallSite instance = new VolatileCallSite(c0);
    instance.setTarget(p0);
  }
}
