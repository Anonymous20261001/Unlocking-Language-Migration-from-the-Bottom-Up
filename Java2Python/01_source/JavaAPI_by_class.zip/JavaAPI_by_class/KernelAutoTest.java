package generated.test;

import java.awt.image.Kernel;
import org.junit.jupiter.api.Test;

public class KernelAutoTest {
  @Test
  public void getXOrigin_test_1309(int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.getXOrigin();
  }

  @Test
  public void getYOrigin_test_1310(int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.getYOrigin();
  }

  @Test
  public void getKernelData_test_1311(float[] p0, int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.getKernelData(p0);
  }

  @Test
  public void getWidth_test_1312(int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.getWidth();
  }

  @Test
  public void getHeight_test_1313(int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.getHeight();
  }

  @Test
  public void clone_test_1314(int c0, int c1, float[] c2) {
    Kernel instance = new Kernel(c0, c1, c2);
    instance.clone();
  }
}
