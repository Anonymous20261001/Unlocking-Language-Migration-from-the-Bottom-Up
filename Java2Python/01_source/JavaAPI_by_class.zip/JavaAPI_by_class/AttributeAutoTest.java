package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.Attribute;
import org.junit.jupiter.api.Test;

public class AttributeAutoTest {
  @Test
  public void getName_test_5518(String c0, Object c1) {
    Attribute instance = new Attribute(c0, c1);
    instance.getName();
  }

  @Test
  public void equals_test_5519(Object p0, String c0, Object c1) {
    Attribute instance = new Attribute(c0, c1);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5520(String c0, Object c1) {
    Attribute instance = new Attribute(c0, c1);
    instance.toString();
  }

  @Test
  public void hashCode_test_5521(String c0, Object c1) {
    Attribute instance = new Attribute(c0, c1);
    instance.hashCode();
  }

  @Test
  public void getValue_test_5522(String c0, Object c1) {
    Attribute instance = new Attribute(c0, c1);
    instance.getValue();
  }
}
