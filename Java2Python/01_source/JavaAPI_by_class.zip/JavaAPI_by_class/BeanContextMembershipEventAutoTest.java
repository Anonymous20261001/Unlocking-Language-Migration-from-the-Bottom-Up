package generated.test;

import java.beans.beancontext.BeanContext;
import java.beans.beancontext.BeanContextMembershipEvent;
import java.lang.Object;
import java.util.Collection;
import org.junit.jupiter.api.Test;

public class BeanContextMembershipEventAutoTest {
  @Test
  public void size_test_1642(BeanContext c0, Collection c1) {
    BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
    instance.size();
  }

  @Test
  public void toArray_test_1643(BeanContext c0, Collection c1) {
    BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
    instance.toArray();
  }

  @Test
  public void iterator_test_1644(BeanContext c0, Collection c1) {
    BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
    instance.iterator();
  }

  @Test
  public void contains_test_1645(Object p0, BeanContext c0, Collection c1) {
    BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
    instance.contains(p0);
  }
}
