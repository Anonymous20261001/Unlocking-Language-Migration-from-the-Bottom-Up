package generated.test;

import java.awt.dnd.DragSourceContext;
import java.awt.dnd.DragSourceDragEvent;
import org.junit.jupiter.api.Test;

public class DragSourceDragEventAutoTest {
  @Test
  public void getTargetActions_test_707(DragSourceContext c0, int c1, int c2, int c3) {
    DragSourceDragEvent instance = new DragSourceDragEvent(c0, c1, c2, c3);
    instance.getTargetActions();
  }

  @Test
  public void getGestureModifiers_test_708(DragSourceContext c0, int c1, int c2, int c3) {
    DragSourceDragEvent instance = new DragSourceDragEvent(c0, c1, c2, c3);
    instance.getGestureModifiers();
  }

  @Test
  public void getGestureModifiersEx_test_709(DragSourceContext c0, int c1, int c2, int c3) {
    DragSourceDragEvent instance = new DragSourceDragEvent(c0, c1, c2, c3);
    instance.getGestureModifiersEx();
  }

  @Test
  public void getUserAction_test_710(DragSourceContext c0, int c1, int c2, int c3) {
    DragSourceDragEvent instance = new DragSourceDragEvent(c0, c1, c2, c3);
    instance.getUserAction();
  }

  @Test
  public void getDropAction_test_711(DragSourceContext c0, int c1, int c2, int c3) {
    DragSourceDragEvent instance = new DragSourceDragEvent(c0, c1, c2, c3);
    instance.getDropAction();
  }
}
