package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiLabelUI;
import org.junit.jupiter.api.Test;

public class MultiLabelUIAutoTest {
  @Test
  public void installUI_test_9391(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9392(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9393() {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9394(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    MultiLabelUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9395(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9396(Graphics p0, JComponent p1) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9397(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9398(JComponent p0, int p1) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9399(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9400(JComponent p0) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9401(Graphics p0, JComponent p1) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9402(JComponent p0, int p1, int p2) {
    MultiLabelUI instance = new MultiLabelUI();
    instance.contains(p0, p1, p2);
  }
}
