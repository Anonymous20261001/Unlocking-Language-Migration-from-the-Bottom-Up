package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiButtonUI;
import org.junit.jupiter.api.Test;

public class MultiButtonUIAutoTest {
  @Test
  public void installUI_test_9298(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.installUI(p0);
  }

  @Test
  public void uninstallUI_test_9299(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.uninstallUI(p0);
  }

  @Test
  public void getUIs_test_9300() {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getUIs();
  }

  @Test
  public void createUI_test_9301(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    MultiButtonUI.createUI(p0);
  }

  @Test
  public void getMaximumSize_test_9302(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getMaximumSize(p0);
  }

  @Test
  public void paint_test_9303(Graphics p0, JComponent p1) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.paint(p0, p1);
  }

  @Test
  public void getAccessibleChildrenCount_test_9304(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getAccessibleChildrenCount(p0);
  }

  @Test
  public void getAccessibleChild_test_9305(JComponent p0, int p1) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getAccessibleChild(p0, p1);
  }

  @Test
  public void getPreferredSize_test_9306(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getPreferredSize(p0);
  }

  @Test
  public void getMinimumSize_test_9307(JComponent p0) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.getMinimumSize(p0);
  }

  @Test
  public void update_test_9308(Graphics p0, JComponent p1) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.update(p0, p1);
  }

  @Test
  public void contains_test_9309(JComponent p0, int p1, int p2) {
    MultiButtonUI instance = new MultiButtonUI();
    instance.contains(p0, p1, p2);
  }
}
