package generated.test;

import java.lang.Object;
import java.rmi.dgc.VMID;
import org.junit.jupiter.api.Test;

public class VMIDAutoTest {
  @Test
  public void isUnique_test_2661() {
    VMID instance = new VMID();
    VMID.isUnique();
  }

  @Test
  public void equals_test_2662(Object p0) {
    VMID instance = new VMID();
    instance.equals(p0);
  }

  @Test
  public void toString_test_2663() {
    VMID instance = new VMID();
    instance.toString();
  }

  @Test
  public void hashCode_test_2664() {
    VMID instance = new VMID();
    instance.hashCode();
  }
}
