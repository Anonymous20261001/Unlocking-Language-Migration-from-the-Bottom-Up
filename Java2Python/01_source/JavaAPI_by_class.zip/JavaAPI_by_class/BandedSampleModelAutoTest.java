package generated.test;

import java.awt.image.BandedSampleModel;
import java.awt.image.DataBuffer;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class BandedSampleModelAutoTest {
  @Test
  public void setPixels_test_1028(int p0, int p1, int p2, int p3, int[] p4, DataBuffer p5, int c0,
      int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setPixels(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getPixel_test_1029(int p0, int p1, int[] p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getPixel(p0, p1, p2, p3);
  }

  @Test
  public void setPixel_test_1030(int p0, int p1, int[] p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setPixel(p0, p1, p2, p3);
  }

  @Test
  public void createCompatibleSampleModel_test_1031(int p0, int p1, int c0, int c1, int c2,
      int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.createCompatibleSampleModel(p0, p1);
  }

  @Test
  public void createSubsetSampleModel_test_1032(int[] p0, int c0, int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.createSubsetSampleModel(p0);
  }

  @Test
  public void createDataBuffer_test_1033(int c0, int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.createDataBuffer();
  }

  @Test
  public void getDataElements_test_1034(int p0, int p1, Object p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getDataElements(p0, p1, p2, p3);
  }

  @Test
  public void getPixels_test_1035(int p0, int p1, int p2, int p3, int[] p4, DataBuffer p5, int c0,
      int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getPixels(p0, p1, p2, p3, p4, p5);
  }

  @Test
  public void getSample_test_1036(int p0, int p1, int p2, DataBuffer p3, int c0, int c1, int c2,
      int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getSample(p0, p1, p2, p3);
  }

  @Test
  public void getSampleFloat_test_1037(int p0, int p1, int p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getSampleFloat(p0, p1, p2, p3);
  }

  @Test
  public void getSampleDouble_test_1038(int p0, int p1, int p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getSampleDouble(p0, p1, p2, p3);
  }

  @Test
  public void getSamples_test_1039(int p0, int p1, int p2, int p3, int p4, int[] p5, DataBuffer p6,
      int c0, int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.getSamples(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void setDataElements_test_1040(int p0, int p1, Object p2, DataBuffer p3, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setDataElements(p0, p1, p2, p3);
  }

  @Test
  public void setSample_test_1041(int p0, int p1, int p2, float p3, DataBuffer p4, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setSample(p0, p1, p2, p3, p4);
  }

  @Test
  public void setSample_test_1042(int p0, int p1, int p2, double p3, DataBuffer p4, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setSample(p0, p1, p2, p3, p4);
  }

  @Test
  public void setSample_test_1043(int p0, int p1, int p2, int p3, DataBuffer p4, int c0, int c1,
      int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setSample(p0, p1, p2, p3, p4);
  }

  @Test
  public void setSamples_test_1044(int p0, int p1, int p2, int p3, int p4, int[] p5, DataBuffer p6,
      int c0, int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.setSamples(p0, p1, p2, p3, p4, p5, p6);
  }

  @Test
  public void hashCode_test_1045(int c0, int c1, int c2, int c3) {
    BandedSampleModel instance = new BandedSampleModel(c0, c1, c2, c3);
    instance.hashCode();
  }
}
