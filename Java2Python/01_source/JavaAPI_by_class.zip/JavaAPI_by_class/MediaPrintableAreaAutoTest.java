package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.print.attribute.standard.MediaPrintableArea;
import org.junit.jupiter.api.Test;

public class MediaPrintableAreaAutoTest {
  @Test
  public void getCategory_test_6169(float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getCategory();
  }

  @Test
  public void getPrintableArea_test_6170(int p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getPrintableArea(p0);
  }

  @Test
  public void getX_test_6171(int p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getX(p0);
  }

  @Test
  public void getY_test_6172(int p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getY(p0);
  }

  @Test
  public void getWidth_test_6173(int p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getWidth(p0);
  }

  @Test
  public void getHeight_test_6174(int p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getHeight(p0);
  }

  @Test
  public void getName_test_6175(float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.getName();
  }

  @Test
  public void equals_test_6176(Object p0, float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.equals(p0);
  }

  @Test
  public void toString_test_6177(int p0, String p1, float c0, float c1, float c2, float c3,
      int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.toString(p0, p1);
  }

  @Test
  public void toString_test_6178(float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.toString();
  }

  @Test
  public void hashCode_test_6179(float c0, float c1, float c2, float c3, int c4) {
    MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
    instance.hashCode();
  }
}
