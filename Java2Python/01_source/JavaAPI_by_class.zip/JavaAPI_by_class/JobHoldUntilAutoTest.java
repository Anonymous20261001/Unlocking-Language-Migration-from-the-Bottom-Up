package generated.test;

import java.lang.Object;
import java.util.Date;
import javax.print.attribute.standard.JobHoldUntil;
import org.junit.jupiter.api.Test;

public class JobHoldUntilAutoTest {
  @Test
  public void getCategory_test_6121(Date c0) {
    JobHoldUntil instance = new JobHoldUntil(c0);
    instance.getCategory();
  }

  @Test
  public void getName_test_6122(Date c0) {
    JobHoldUntil instance = new JobHoldUntil(c0);
    instance.getName();
  }

  @Test
  public void equals_test_6123(Object p0, Date c0) {
    JobHoldUntil instance = new JobHoldUntil(c0);
    instance.equals(p0);
  }
}
