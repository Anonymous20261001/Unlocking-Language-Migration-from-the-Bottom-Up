package generated.test;

import java.lang.Object;
import java.util.Stack;
import org.junit.jupiter.api.Test;

public class StackAutoTest {
  @Test
  public void empty_test_3900() {
    Stack instance = new Stack();
    instance.empty();
  }

  @Test
  public void peek_test_3901() {
    Stack instance = new Stack();
    instance.peek();
  }

  @Test
  public void search_test_3902(Object p0) {
    Stack instance = new Stack();
    instance.search(p0);
  }

  @Test
  public void push_test_3903(Object p0) {
    Stack instance = new Stack();
    instance.push(p0);
  }

  @Test
  public void pop_test_3904() {
    Stack instance = new Stack();
    instance.pop();
  }
}
