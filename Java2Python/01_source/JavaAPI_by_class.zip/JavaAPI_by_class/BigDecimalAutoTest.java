package generated.test;

import java.lang.Object;
import java.lang.String;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import org.junit.jupiter.api.Test;

public class BigDecimalAutoTest {
  @Test
  public void stripTrailingZeros_test_2426(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.stripTrailingZeros();
  }

  @Test
  public void movePointLeft_test_2427(int p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.movePointLeft(p0);
  }

  @Test
  public void toEngineeringString_test_2428(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.toEngineeringString();
  }

  @Test
  public void toPlainString_test_2429(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.toPlainString();
  }

  @Test
  public void equals_test_2430(Object p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_2431(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.toString();
  }

  @Test
  public void hashCode_test_2432(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.hashCode();
  }

  @Test
  public void abs_test_2433(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.abs();
  }

  @Test
  public void abs_test_2434(MathContext p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.abs(p0);
  }

  @Test
  public void sqrt_test_2435(MathContext p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.sqrt(p0);
  }

  @Test
  public void pow_test_2436(int p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.pow(p0, p1);
  }

  @Test
  public void pow_test_2437(int p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.pow(p0);
  }

  @Test
  public void min_test_2438(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.min(p0);
  }

  @Test
  public void max_test_2439(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.max(p0);
  }

  @Test
  public void round_test_2440(MathContext p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.round(p0);
  }

  @Test
  public void signum_test_2441(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.signum();
  }

  @Test
  public void compareTo_test_2442(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.compareTo(p0);
  }

  @Test
  public void intValue_test_2443(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.intValue();
  }

  @Test
  public void longValue_test_2444(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.longValue();
  }

  @Test
  public void floatValue_test_2445(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.floatValue();
  }

  @Test
  public void doubleValue_test_2446(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.doubleValue();
  }

  @Test
  public void valueOf_test_2447(long p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    BigDecimal.valueOf(p0);
  }

  @Test
  public void valueOf_test_2448(double p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    BigDecimal.valueOf(p0);
  }

  @Test
  public void valueOf_test_2449(long p0, int p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    BigDecimal.valueOf(p0, p1);
  }

  @Test
  public void scale_test_2450(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.scale();
  }

  @Test
  public void add_test_2451(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.add(p0);
  }

  @Test
  public void add_test_2452(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.add(p0, p1);
  }

  @Test
  public void multiply_test_2453(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.multiply(p0);
  }

  @Test
  public void multiply_test_2454(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.multiply(p0, p1);
  }

  @Test
  public void ulp_test_2455(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.ulp();
  }

  @Test
  public void negate_test_2456(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.negate();
  }

  @Test
  public void negate_test_2457(MathContext p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.negate(p0);
  }

  @Test
  public void remainder_test_2458(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.remainder(p0);
  }

  @Test
  public void remainder_test_2459(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.remainder(p0, p1);
  }

  @Test
  public void subtract_test_2460(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.subtract(p0, p1);
  }

  @Test
  public void subtract_test_2461(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.subtract(p0);
  }

  @Test
  public void toBigInteger_test_2462(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.toBigInteger();
  }

  @Test
  public void divide_test_2463(BigDecimal p0, RoundingMode p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0, p1);
  }

  @Test
  public void divide_test_2464(BigDecimal p0, int p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0, p1);
  }

  @Test
  public void divide_test_2465(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0);
  }

  @Test
  public void divide_test_2466(BigDecimal p0, int p1, RoundingMode p2, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0, p1, p2);
  }

  @Test
  public void divide_test_2467(BigDecimal p0, int p1, int p2, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0, p1, p2);
  }

  @Test
  public void divide_test_2468(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divide(p0, p1);
  }

  @Test
  public void divideAndRemainder_test_2469(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divideAndRemainder(p0);
  }

  @Test
  public void divideAndRemainder_test_2470(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divideAndRemainder(p0, p1);
  }

  @Test
  public void longValueExact_test_2471(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.longValueExact();
  }

  @Test
  public void intValueExact_test_2472(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.intValueExact();
  }

  @Test
  public void shortValueExact_test_2473(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.shortValueExact();
  }

  @Test
  public void byteValueExact_test_2474(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.byteValueExact();
  }

  @Test
  public void scaleByPowerOfTen_test_2475(int p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.scaleByPowerOfTen(p0);
  }

  @Test
  public void plus_test_2476(MathContext p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.plus(p0);
  }

  @Test
  public void plus_test_2477(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.plus();
  }

  @Test
  public void divideToIntegralValue_test_2478(BigDecimal p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divideToIntegralValue(p0);
  }

  @Test
  public void divideToIntegralValue_test_2479(BigDecimal p0, MathContext p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.divideToIntegralValue(p0, p1);
  }

  @Test
  public void movePointRight_test_2480(int p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.movePointRight(p0);
  }

  @Test
  public void toBigIntegerExact_test_2481(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.toBigIntegerExact();
  }

  @Test
  public void precision_test_2482(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.precision();
  }

  @Test
  public void unscaledValue_test_2483(String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.unscaledValue();
  }

  @Test
  public void setScale_test_2484(int p0, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.setScale(p0);
  }

  @Test
  public void setScale_test_2485(int p0, RoundingMode p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.setScale(p0, p1);
  }

  @Test
  public void setScale_test_2486(int p0, int p1, String c0) {
    BigDecimal instance = new BigDecimal(c0);
    instance.setScale(p0, p1);
  }
}
