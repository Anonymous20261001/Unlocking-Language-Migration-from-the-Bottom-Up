package generated.test;

import java.awt.ImageCapabilities;
import org.junit.jupiter.api.Test;

public class ImageCapabilitiesAutoTest {
  @Test
  public void isAccelerated_test_349(boolean c0) {
    ImageCapabilities instance = new ImageCapabilities(c0);
    instance.isAccelerated();
  }

  @Test
  public void isTrueVolatile_test_350(boolean c0) {
    ImageCapabilities instance = new ImageCapabilities(c0);
    instance.isTrueVolatile();
  }

  @Test
  public void clone_test_351(boolean c0) {
    ImageCapabilities instance = new ImageCapabilities(c0);
    instance.clone();
  }
}
