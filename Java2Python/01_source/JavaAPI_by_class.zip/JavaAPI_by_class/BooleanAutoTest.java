package generated.test;

import java.lang.Boolean;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class BooleanAutoTest {
  @Test
  public void equals_test_1837(Object p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.equals(p0);
  }

  @Test
  public void toString_test_1838(boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.toString();
  }

  @Test
  public void toString_test_1839(boolean p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.toString(p0);
  }

  @Test
  public void hashCode_test_1840(boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.hashCode();
  }

  @Test
  public void hashCode_test_1841(boolean p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.hashCode(p0);
  }

  @Test
  public void compareTo_test_1842(Boolean p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.compareTo(p0);
  }

  @Test
  public void getBoolean_test_1843(String p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.getBoolean(p0);
  }

  @Test
  public void compare_test_1844(boolean p0, boolean p1, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.compare(p0, p1);
  }

  @Test
  public void booleanValue_test_1845(boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.booleanValue();
  }

  @Test
  public void valueOf_test_1846(String p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.valueOf(p0);
  }

  @Test
  public void valueOf_test_1847(boolean p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.valueOf(p0);
  }

  @Test
  public void describeConstable_test_1848(boolean c0) {
    Boolean instance = new Boolean(c0);
    instance.describeConstable();
  }

  @Test
  public void parseBoolean_test_1849(String p0, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.parseBoolean(p0);
  }

  @Test
  public void logicalAnd_test_1850(boolean p0, boolean p1, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.logicalAnd(p0, p1);
  }

  @Test
  public void logicalOr_test_1851(boolean p0, boolean p1, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.logicalOr(p0, p1);
  }

  @Test
  public void logicalXor_test_1852(boolean p0, boolean p1, boolean c0) {
    Boolean instance = new Boolean(c0);
    Boolean.logicalXor(p0, p1);
  }
}
