package generated.test;

import java.lang.Thread;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.junit.jupiter.api.Test;

public class ReentrantLockAutoTest {
  @Test
  public void toString_test_4983() {
    ReentrantLock instance = new ReentrantLock();
    instance.toString();
  }

  @Test
  public void lock_test_4984() {
    ReentrantLock instance = new ReentrantLock();
    instance.lock();
  }

  @Test
  public void tryLock_test_4985() {
    ReentrantLock instance = new ReentrantLock();
    instance.tryLock();
  }

  @Test
  public void newCondition_test_4986() {
    ReentrantLock instance = new ReentrantLock();
    instance.newCondition();
  }

  @Test
  public void getHoldCount_test_4987() {
    ReentrantLock instance = new ReentrantLock();
    instance.getHoldCount();
  }

  @Test
  public void isLocked_test_4988() {
    ReentrantLock instance = new ReentrantLock();
    instance.isLocked();
  }

  @Test
  public void hasQueuedThreads_test_4989() {
    ReentrantLock instance = new ReentrantLock();
    instance.hasQueuedThreads();
  }

  @Test
  public void getQueueLength_test_4990() {
    ReentrantLock instance = new ReentrantLock();
    instance.getQueueLength();
  }

  @Test
  public void hasWaiters_test_4991(Condition p0) {
    ReentrantLock instance = new ReentrantLock();
    instance.hasWaiters(p0);
  }

  @Test
  public void getWaitQueueLength_test_4992(Condition p0) {
    ReentrantLock instance = new ReentrantLock();
    instance.getWaitQueueLength(p0);
  }

  @Test
  public void unlock_test_4993() {
    ReentrantLock instance = new ReentrantLock();
    instance.unlock();
  }

  @Test
  public void isHeldByCurrentThread_test_4994() {
    ReentrantLock instance = new ReentrantLock();
    instance.isHeldByCurrentThread();
  }

  @Test
  public void isFair_test_4995() {
    ReentrantLock instance = new ReentrantLock();
    instance.isFair();
  }

  @Test
  public void hasQueuedThread_test_4996(Thread p0) {
    ReentrantLock instance = new ReentrantLock();
    instance.hasQueuedThread(p0);
  }
}
