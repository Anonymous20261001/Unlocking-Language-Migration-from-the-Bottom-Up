package generated.test;

import java.security.SecureRandom;
import java.security.SecureRandomParameters;
import org.junit.jupiter.api.Test;

public class SecureRandomAutoTest {
  @Test
  public void reseed_test_2733(SecureRandomParameters p0) {
    SecureRandom instance = new SecureRandom();
    instance.reseed(p0);
  }

  @Test
  public void reseed_test_2734() {
    SecureRandom instance = new SecureRandom();
    instance.reseed();
  }

  @Test
  public void generateSeed_test_2735(int p0) {
    SecureRandom instance = new SecureRandom();
    instance.generateSeed(p0);
  }

  @Test
  public void toString_test_2736() {
    SecureRandom instance = new SecureRandom();
    instance.toString();
  }

  @Test
  public void getParameters_test_2737() {
    SecureRandom instance = new SecureRandom();
    instance.getParameters();
  }

  @Test
  public void nextBytes_test_2738(byte[] p0) {
    SecureRandom instance = new SecureRandom();
    instance.nextBytes(p0);
  }

  @Test
  public void nextBytes_test_2739(byte[] p0, SecureRandomParameters p1) {
    SecureRandom instance = new SecureRandom();
    instance.nextBytes(p0, p1);
  }

  @Test
  public void getProvider_test_2740() {
    SecureRandom instance = new SecureRandom();
    instance.getProvider();
  }

  @Test
  public void setSeed_test_2741(long p0) {
    SecureRandom instance = new SecureRandom();
    instance.setSeed(p0);
  }

  @Test
  public void setSeed_test_2742(byte[] p0) {
    SecureRandom instance = new SecureRandom();
    instance.setSeed(p0);
  }

  @Test
  public void getSeed_test_2743(int p0) {
    SecureRandom instance = new SecureRandom();
    SecureRandom.getSeed(p0);
  }

  @Test
  public void getAlgorithm_test_2744() {
    SecureRandom instance = new SecureRandom();
    instance.getAlgorithm();
  }
}
