package generated.test;

import java.beans.PropertyChangeEvent;
import java.lang.Class;
import java.lang.Object;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelListener;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumn;
import org.junit.jupiter.api.Test;

public class DefaultTableColumnModelAutoTest {
  @Test
  public void propertyChange_test_9992(PropertyChangeEvent p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.propertyChange(p0);
  }

  @Test
  public void setColumnMargin_test_9993(int p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.setColumnMargin(p0);
  }

  @Test
  public void getColumnMargin_test_9994() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnMargin();
  }

  @Test
  public void getColumn_test_9995(int p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumn(p0);
  }

  @Test
  public void removeColumn_test_9996(TableColumn p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.removeColumn(p0);
  }

  @Test
  public void addColumn_test_9997(TableColumn p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.addColumn(p0);
  }

  @Test
  public void getSelectedColumns_test_9998() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getSelectedColumns();
  }

  @Test
  public void getColumnSelectionAllowed_test_9999() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnSelectionAllowed();
  }

  @Test
  public void setColumnSelectionAllowed_test_10000(boolean p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.setColumnSelectionAllowed(p0);
  }

  @Test
  public void getSelectedColumnCount_test_10001() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getSelectedColumnCount();
  }

  @Test
  public void getColumnIndex_test_10002(Object p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnIndex(p0);
  }

  @Test
  public void moveColumn_test_10003(int p0, int p1) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.moveColumn(p0, p1);
  }

  @Test
  public void getColumnIndexAtX_test_10004(int p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnIndexAtX(p0);
  }

  @Test
  public void getTotalColumnWidth_test_10005() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getTotalColumnWidth();
  }

  @Test
  public void removeColumnModelListener_test_10006(TableColumnModelListener p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.removeColumnModelListener(p0);
  }

  @Test
  public void addColumnModelListener_test_10007(TableColumnModelListener p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.addColumnModelListener(p0);
  }

  @Test
  public void valueChanged_test_10008(ListSelectionEvent p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.valueChanged(p0);
  }

  @Test
  public void getSelectionModel_test_10009() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getSelectionModel();
  }

  @Test
  public void setSelectionModel_test_10010(ListSelectionModel p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.setSelectionModel(p0);
  }

  @Test
  public void getColumnModelListeners_test_10011() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnModelListeners();
  }

  @Test
  public void getListeners_test_10012(Class p0) {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getListeners(p0);
  }

  @Test
  public void getColumns_test_10013() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumns();
  }

  @Test
  public void getColumnCount_test_10014() {
    DefaultTableColumnModel instance = new DefaultTableColumnModel();
    instance.getColumnCount();
  }
}
