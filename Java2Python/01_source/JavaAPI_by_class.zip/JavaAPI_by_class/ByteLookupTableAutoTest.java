package generated.test;

import java.awt.image.ByteLookupTable;
import org.junit.jupiter.api.Test;

public class ByteLookupTableAutoTest {
  @Test
  public void lookupPixel_test_1101(byte[] p0, byte[] p1, int c0, byte[][] c1) {
    ByteLookupTable instance = new ByteLookupTable(c0, c1);
    instance.lookupPixel(p0, p1);
  }

  @Test
  public void lookupPixel_test_1102(int[] p0, int[] p1, int c0, byte[][] c1) {
    ByteLookupTable instance = new ByteLookupTable(c0, c1);
    instance.lookupPixel(p0, p1);
  }

  @Test
  public void getTable_test_1103(int c0, byte[][] c1) {
    ByteLookupTable instance = new ByteLookupTable(c0, c1);
    instance.getTable();
  }
}
