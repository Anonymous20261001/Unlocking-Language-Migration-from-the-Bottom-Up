package generated.test;

import java.util.IllegalFormatCodePointException;
import org.junit.jupiter.api.Test;

public class IllegalFormatCodePointExceptionAutoTest {
  @Test
  public void getMessage_test_3564(int c0) {
    IllegalFormatCodePointException instance = new IllegalFormatCodePointException(c0);
    instance.getMessage();
  }

  @Test
  public void getCodePoint_test_3565(int c0) {
    IllegalFormatCodePointException instance = new IllegalFormatCodePointException(c0);
    instance.getCodePoint();
  }
}
