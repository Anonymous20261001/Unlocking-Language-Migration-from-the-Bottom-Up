package generated.test;

import java.beans.IndexedPropertyChangeEvent;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class IndexedPropertyChangeEventAutoTest {
  @Test
  public void getIndex_test_1552(Object c0, String c1, Object c2, Object c3, int c4) {
    IndexedPropertyChangeEvent instance = new IndexedPropertyChangeEvent(c0, c1, c2, c3, c4);
    instance.getIndex();
  }
}
