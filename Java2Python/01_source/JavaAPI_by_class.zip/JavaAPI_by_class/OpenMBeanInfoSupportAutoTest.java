package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.MBeanNotificationInfo;
import javax.management.openmbean.OpenMBeanAttributeInfo;
import javax.management.openmbean.OpenMBeanConstructorInfo;
import javax.management.openmbean.OpenMBeanInfoSupport;
import javax.management.openmbean.OpenMBeanOperationInfo;
import org.junit.jupiter.api.Test;

public class OpenMBeanInfoSupportAutoTest {
  @Test
  public void equals_test_5760(Object p0, String c0, String c1, OpenMBeanAttributeInfo[] c2,
      OpenMBeanConstructorInfo[] c3, OpenMBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    OpenMBeanInfoSupport instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
    instance.equals(p0);
  }

  @Test
  public void toString_test_5761(String c0, String c1, OpenMBeanAttributeInfo[] c2,
      OpenMBeanConstructorInfo[] c3, OpenMBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    OpenMBeanInfoSupport instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
    instance.toString();
  }

  @Test
  public void hashCode_test_5762(String c0, String c1, OpenMBeanAttributeInfo[] c2,
      OpenMBeanConstructorInfo[] c3, OpenMBeanOperationInfo[] c4, MBeanNotificationInfo[] c5) {
    OpenMBeanInfoSupport instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
    instance.hashCode();
  }
}
