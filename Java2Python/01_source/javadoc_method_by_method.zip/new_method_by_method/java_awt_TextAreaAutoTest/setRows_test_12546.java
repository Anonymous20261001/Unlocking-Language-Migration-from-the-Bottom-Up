package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void setRows_test_12546(int p0) {
      TextArea instance = new TextArea();
      instance.setRows(p0);
    }
}
