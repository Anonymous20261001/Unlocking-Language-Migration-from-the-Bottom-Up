package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getRows_test_12549() {
      TextArea instance = new TextArea();
      instance.getRows();
    }
}
