package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void appendText_test_12564(String p0) {
      TextArea instance = new TextArea();
      instance.appendText(p0);
    }
}
