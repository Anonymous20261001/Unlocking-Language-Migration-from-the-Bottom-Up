package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void addNotify_test_12554() {
      TextArea instance = new TextArea();
      instance.addNotify();
    }
}
