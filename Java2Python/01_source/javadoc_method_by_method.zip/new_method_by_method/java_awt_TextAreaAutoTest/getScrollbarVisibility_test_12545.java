package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getScrollbarVisibility_test_12545() {
      TextArea instance = new TextArea();
      instance.getScrollbarVisibility();
    }
}
