package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void preferredSize_test_12555(int p0, int p1) {
      TextArea instance = new TextArea();
      instance.preferredSize(p0, p1);
    }
}
