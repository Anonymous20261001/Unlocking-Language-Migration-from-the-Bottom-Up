package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getAccessibleContext_test_12559() {
      TextArea instance = new TextArea();
      instance.getAccessibleContext();
    }
}
