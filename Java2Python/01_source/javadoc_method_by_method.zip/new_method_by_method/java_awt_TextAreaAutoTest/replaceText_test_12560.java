package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void replaceText_test_12560(String p0, int p1, int p2) {
      TextArea instance = new TextArea();
      instance.replaceText(p0, p1, p2);
    }
}
