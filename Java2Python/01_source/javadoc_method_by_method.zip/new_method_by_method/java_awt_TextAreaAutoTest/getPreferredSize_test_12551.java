package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getPreferredSize_test_12551() {
      TextArea instance = new TextArea();
      instance.getPreferredSize();
    }
}
