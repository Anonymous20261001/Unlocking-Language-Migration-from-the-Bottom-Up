package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void append_test_12562(String p0) {
      TextArea instance = new TextArea();
      instance.append(p0);
    }
}
