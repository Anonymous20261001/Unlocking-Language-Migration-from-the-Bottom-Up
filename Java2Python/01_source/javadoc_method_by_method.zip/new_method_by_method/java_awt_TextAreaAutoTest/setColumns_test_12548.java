package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void setColumns_test_12548(int p0) {
      TextArea instance = new TextArea();
      instance.setColumns(p0);
    }
}
