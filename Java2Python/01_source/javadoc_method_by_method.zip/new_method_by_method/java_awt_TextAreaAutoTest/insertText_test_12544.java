package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void insertText_test_12544(String p0, int p1) {
      TextArea instance = new TextArea();
      instance.insertText(p0, p1);
    }
}
