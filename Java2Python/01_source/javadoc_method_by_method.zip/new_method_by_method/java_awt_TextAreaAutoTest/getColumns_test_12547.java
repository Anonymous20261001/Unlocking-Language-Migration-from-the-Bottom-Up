package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getColumns_test_12547() {
      TextArea instance = new TextArea();
      instance.getColumns();
    }
}
