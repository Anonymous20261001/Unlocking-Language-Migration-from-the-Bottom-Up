package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void replaceRange_test_12561(String p0, int p1, int p2) {
      TextArea instance = new TextArea();
      instance.replaceRange(p0, p1, p2);
    }
}
