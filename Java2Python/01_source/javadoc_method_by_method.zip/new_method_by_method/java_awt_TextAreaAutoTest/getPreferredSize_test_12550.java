package generated.test;

import java.awt.TextArea;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextAreaAutoTest {
    @Test
    public void getPreferredSize_test_12550(int p0, int p1) {
      TextArea instance = new TextArea();
      instance.getPreferredSize(p0, p1);
    }
}
