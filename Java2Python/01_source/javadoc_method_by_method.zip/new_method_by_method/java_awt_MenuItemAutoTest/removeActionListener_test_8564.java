package generated.test;

import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuItemAutoTest {
    @Test
    public void removeActionListener_test_8564(ActionListener p0) {
      MenuItem instance = new MenuItem();
      instance.removeActionListener(p0);
    }
}
