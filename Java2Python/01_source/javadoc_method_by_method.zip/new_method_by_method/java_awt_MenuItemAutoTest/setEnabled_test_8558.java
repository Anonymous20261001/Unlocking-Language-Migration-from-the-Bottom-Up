package generated.test;

import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuItemAutoTest {
    @Test
    public void setEnabled_test_8558(boolean p0) {
      MenuItem instance = new MenuItem();
      instance.setEnabled(p0);
    }
}
