package generated.test;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.SystemFlavorMap;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {
    @Test
    public void encodeDataFlavor_test_12440(DataFlavor p0) {
      SystemFlavorMap.encodeDataFlavor(p0);
    }
}
