package generated.test;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.SystemFlavorMap;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {
    @Test
    public void isJavaMIMEType_test_12438(String p0) {
      SystemFlavorMap.isJavaMIMEType(p0);
    }
}
