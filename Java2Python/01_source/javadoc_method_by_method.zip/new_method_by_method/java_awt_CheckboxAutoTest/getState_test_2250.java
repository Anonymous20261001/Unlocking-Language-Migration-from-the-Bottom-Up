package generated.test;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxAutoTest {
    @Test
    public void getState_test_2250() {
      Checkbox instance = new Checkbox();
      instance.getState();
    }
}
