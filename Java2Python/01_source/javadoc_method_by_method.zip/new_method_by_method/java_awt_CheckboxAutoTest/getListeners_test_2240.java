package generated.test;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxAutoTest {
    @Test
    public void getListeners_test_2240(Class p0) {
      Checkbox instance = new Checkbox();
      instance.getListeners(p0);
    }
}
