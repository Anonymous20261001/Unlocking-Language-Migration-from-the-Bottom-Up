package generated.test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.ScrollPane;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollPaneAutoTest {
    @Test
    public void setWheelScrollingEnabled_test_10920(boolean p0) {
      ScrollPane instance = new ScrollPane();
      instance.setWheelScrollingEnabled(p0);
    }
}
