package generated.test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.ScrollPane;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollPaneAutoTest {
    @Test
    public void getAccessibleContext_test_10916() {
      ScrollPane instance = new ScrollPane();
      instance.getAccessibleContext();
    }
}
