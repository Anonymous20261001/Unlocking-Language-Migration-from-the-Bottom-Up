package generated.test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.ScrollPane;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollPaneAutoTest {
    @Test
    public void printComponents_test_10918(Graphics p0) {
      ScrollPane instance = new ScrollPane();
      instance.printComponents(p0);
    }
}
