package generated.test;

import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.ScrollPane;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollPaneAutoTest {
    @Test
    public void setScrollPosition_test_10907(int p0, int p1) {
      ScrollPane instance = new ScrollPane();
      instance.setScrollPosition(p0, p1);
    }
}
