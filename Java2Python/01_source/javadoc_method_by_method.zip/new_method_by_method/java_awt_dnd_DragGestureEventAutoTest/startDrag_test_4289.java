package generated.test;

import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSourceListener;
import java.lang.Object;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragGestureEventAutoTest {
    @Test
    public void startDrag_test_4289(Cursor p0, Transferable p1, DragGestureRecognizer c0, int c1,
        Point c2, List c3) {
      DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
      instance.startDrag(p0, p1);
    }
}
