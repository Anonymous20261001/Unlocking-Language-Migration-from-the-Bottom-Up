package generated.test;

import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureRecognizer;
import java.awt.dnd.DragSourceListener;
import java.lang.Object;
import java.util.List;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragGestureEventAutoTest {
    @Test
    public void getSourceAsDragGestureRecognizer_test_4287(DragGestureRecognizer c0, int c1, Point c2,
        List c3) {
      DragGestureEvent instance = new DragGestureEvent(c0, c1, c2, c3);
      instance.getSourceAsDragGestureRecognizer();
    }
}
