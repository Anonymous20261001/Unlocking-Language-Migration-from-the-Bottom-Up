package generated.test;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.FlavorMap;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DragSourceMotionListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragSourceAutoTest {
    @Test
    public void removeDragSourceListener_test_4301(DragSourceListener p0) {
      DragSource instance = new DragSource();
      instance.removeDragSourceListener(p0);
    }
}
