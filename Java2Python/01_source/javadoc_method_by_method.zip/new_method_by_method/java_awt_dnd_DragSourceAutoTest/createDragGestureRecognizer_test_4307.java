package generated.test;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.FlavorMap;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DragSourceMotionListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragSourceAutoTest {
    @Test
    public void createDragGestureRecognizer_test_4307(Class p0, Component p1, int p2,
        DragGestureListener p3) {
      DragSource instance = new DragSource();
      instance.createDragGestureRecognizer(p0, p1, p2, p3);
    }
}
