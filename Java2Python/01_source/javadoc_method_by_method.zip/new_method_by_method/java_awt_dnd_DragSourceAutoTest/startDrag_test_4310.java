package generated.test;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.datatransfer.FlavorMap;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DragSourceMotionListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DragSourceAutoTest {
    @Test
    public void startDrag_test_4310(DragGestureEvent p0, Cursor p1, Image p2, Point p3,
        Transferable p4, DragSourceListener p5, FlavorMap p6) {
      DragSource instance = new DragSource();
      instance.startDrag(p0, p1, p2, p3, p4, p5, p6);
    }
}
