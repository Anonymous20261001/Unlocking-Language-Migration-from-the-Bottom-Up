package generated.test;

import java.awt.Component;
import java.awt.datatransfer.FlavorMap;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import org.junit.jupiter.api.Test;

public class java_awt_dnd_DropTargetAutoTest {
    @Test
    public void setDefaultActions_test_4356(int p0) {
      DropTarget instance = new DropTarget();
      instance.setDefaultActions(p0);
    }
}
