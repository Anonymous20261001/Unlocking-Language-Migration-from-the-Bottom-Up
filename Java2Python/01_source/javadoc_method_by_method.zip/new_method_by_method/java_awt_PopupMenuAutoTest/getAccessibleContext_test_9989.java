package generated.test;

import java.awt.Component;
import java.awt.PopupMenu;
import org.junit.jupiter.api.Test;

public class java_awt_PopupMenuAutoTest {
    @Test
    public void getAccessibleContext_test_9989() {
      PopupMenu instance = new PopupMenu();
      instance.getAccessibleContext();
    }
}
