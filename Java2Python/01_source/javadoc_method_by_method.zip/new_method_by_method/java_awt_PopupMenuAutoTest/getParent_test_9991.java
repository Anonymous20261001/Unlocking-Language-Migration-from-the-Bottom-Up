package generated.test;

import java.awt.Component;
import java.awt.PopupMenu;
import org.junit.jupiter.api.Test;

public class java_awt_PopupMenuAutoTest {
    @Test
    public void getParent_test_9991() {
      PopupMenu instance = new PopupMenu();
      instance.getParent();
    }
}
