package generated.test;

import java.awt.SystemTray;
import org.junit.jupiter.api.Test;

public class java_awt_SystemTrayAutoTest {
    @Test
    public void isSupported_test_12444() {
      SystemTray.isSupported();
    }
}
