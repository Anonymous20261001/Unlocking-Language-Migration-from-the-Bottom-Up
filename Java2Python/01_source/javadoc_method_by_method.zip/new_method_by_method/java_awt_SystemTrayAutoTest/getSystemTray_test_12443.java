package generated.test;

import java.awt.SystemTray;
import org.junit.jupiter.api.Test;

public class java_awt_SystemTrayAutoTest {
    @Test
    public void getSystemTray_test_12443() {
      SystemTray.getSystemTray();
    }
}
