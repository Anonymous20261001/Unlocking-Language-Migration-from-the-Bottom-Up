package generated.test;

import java.awt.AWTKeyStroke;
import java.awt.event.KeyEvent;
import java.lang.Character;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_AWTKeyStrokeAutoTest {
    @Test
    public void getAWTKeyStrokeForEvent_test_951(KeyEvent p0) {
      AWTKeyStroke.getAWTKeyStrokeForEvent(p0);
    }
}
