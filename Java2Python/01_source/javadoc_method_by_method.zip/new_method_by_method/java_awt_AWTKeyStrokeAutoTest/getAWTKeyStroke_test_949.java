package generated.test;

import java.awt.AWTKeyStroke;
import java.awt.event.KeyEvent;
import java.lang.Character;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_AWTKeyStrokeAutoTest {
    @Test
    public void getAWTKeyStroke_test_949(int p0, int p1, boolean p2) {
      AWTKeyStroke.getAWTKeyStroke(p0, p1, p2);
    }
}
