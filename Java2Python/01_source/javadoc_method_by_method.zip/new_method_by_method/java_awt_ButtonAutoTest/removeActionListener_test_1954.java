package generated.test;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ButtonAutoTest {
    @Test
    public void removeActionListener_test_1954(ActionListener p0) {
      Button instance = new Button();
      instance.removeActionListener(p0);
    }
}
