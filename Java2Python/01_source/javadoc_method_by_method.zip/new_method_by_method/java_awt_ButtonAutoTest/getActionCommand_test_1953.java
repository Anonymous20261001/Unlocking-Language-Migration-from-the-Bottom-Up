package generated.test;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ButtonAutoTest {
    @Test
    public void getActionCommand_test_1953() {
      Button instance = new Button();
      instance.getActionCommand();
    }
}
