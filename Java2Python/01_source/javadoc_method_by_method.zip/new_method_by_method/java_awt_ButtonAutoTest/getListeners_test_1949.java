package generated.test;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ButtonAutoTest {
    @Test
    public void getListeners_test_1949(Class p0) {
      Button instance = new Button();
      instance.getListeners(p0);
    }
}
