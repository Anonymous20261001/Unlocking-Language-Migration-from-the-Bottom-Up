package generated.test;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ButtonAutoTest {
    @Test
    public void setLabel_test_1957(String p0) {
      Button instance = new Button();
      instance.setLabel(p0);
    }
}
