package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setVisibleAmount_test_10894(int p0) {
      Scrollbar instance = new Scrollbar();
      instance.setVisibleAmount(p0);
    }
}
