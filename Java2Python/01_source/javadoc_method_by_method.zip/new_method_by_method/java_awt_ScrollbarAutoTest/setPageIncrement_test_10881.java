package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setPageIncrement_test_10881(int p0) {
      Scrollbar instance = new Scrollbar();
      instance.setPageIncrement(p0);
    }
}
