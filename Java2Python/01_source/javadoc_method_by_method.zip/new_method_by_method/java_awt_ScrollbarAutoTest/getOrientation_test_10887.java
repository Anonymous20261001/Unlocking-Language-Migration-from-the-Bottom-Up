package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void getOrientation_test_10887() {
      Scrollbar instance = new Scrollbar();
      instance.getOrientation();
    }
}
