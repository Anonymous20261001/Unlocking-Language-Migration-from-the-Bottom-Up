package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setOrientation_test_10898(int p0) {
      Scrollbar instance = new Scrollbar();
      instance.setOrientation(p0);
    }
}
