package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setValues_test_10899(int p0, int p1, int p2, int p3) {
      Scrollbar instance = new Scrollbar();
      instance.setValues(p0, p1, p2, p3);
    }
}
