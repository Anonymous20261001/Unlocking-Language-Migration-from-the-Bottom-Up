package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setUnitIncrement_test_10890(int p0) {
      Scrollbar instance = new Scrollbar();
      instance.setUnitIncrement(p0);
    }
}
