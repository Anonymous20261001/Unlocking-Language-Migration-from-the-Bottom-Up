package generated.test;

import java.awt.Scrollbar;
import java.awt.event.AdjustmentListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_ScrollbarAutoTest {
    @Test
    public void setMaximum_test_10889(int p0) {
      Scrollbar instance = new Scrollbar();
      instance.setMaximum(p0);
    }
}
