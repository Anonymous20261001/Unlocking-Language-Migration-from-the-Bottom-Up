package generated.test;

import java.awt.TextField;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextFieldAutoTest {
    @Test
    public void minimumSize_test_12580(int p0) {
      TextField instance = new TextField();
      instance.minimumSize(p0);
    }
}
