package generated.test;

import java.awt.TextField;
import java.awt.event.ActionListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_TextFieldAutoTest {
    @Test
    public void setEchoCharacter_test_12566(char p0) {
      TextField instance = new TextField();
      instance.setEchoCharacter(p0);
    }
}
