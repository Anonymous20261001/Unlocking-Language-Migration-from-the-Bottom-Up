package generated.test;

import java.awt.CheckboxMenuItem;
import java.awt.event.ItemListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxMenuItemAutoTest {
    @Test
    public void getListeners_test_2257(Class p0) {
      CheckboxMenuItem instance = new CheckboxMenuItem();
      instance.getListeners(p0);
    }
}
