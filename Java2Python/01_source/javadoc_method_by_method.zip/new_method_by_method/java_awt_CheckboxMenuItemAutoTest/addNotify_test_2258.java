package generated.test;

import java.awt.CheckboxMenuItem;
import java.awt.event.ItemListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxMenuItemAutoTest {
    @Test
    public void addNotify_test_2258() {
      CheckboxMenuItem instance = new CheckboxMenuItem();
      instance.addNotify();
    }
}
