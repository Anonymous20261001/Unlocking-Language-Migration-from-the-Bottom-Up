package generated.test;

import java.awt.CheckboxMenuItem;
import java.awt.event.ItemListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxMenuItemAutoTest {
    @Test
    public void setState_test_2265(boolean p0) {
      CheckboxMenuItem instance = new CheckboxMenuItem();
      instance.setState(p0);
    }
}
