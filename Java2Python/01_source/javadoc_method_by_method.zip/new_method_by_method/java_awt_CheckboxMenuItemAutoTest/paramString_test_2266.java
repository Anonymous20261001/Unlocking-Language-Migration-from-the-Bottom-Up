package generated.test;

import java.awt.CheckboxMenuItem;
import java.awt.event.ItemListener;
import java.lang.Class;
import org.junit.jupiter.api.Test;

public class java_awt_CheckboxMenuItemAutoTest {
    @Test
    public void paramString_test_2266() {
      CheckboxMenuItem instance = new CheckboxMenuItem();
      instance.paramString();
    }
}
