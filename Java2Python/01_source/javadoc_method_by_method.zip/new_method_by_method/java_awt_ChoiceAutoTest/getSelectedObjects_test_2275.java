package generated.test;

import java.awt.Choice;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ChoiceAutoTest {
    @Test
    public void getSelectedObjects_test_2275() {
      Choice instance = new Choice();
      instance.getSelectedObjects();
    }
}
