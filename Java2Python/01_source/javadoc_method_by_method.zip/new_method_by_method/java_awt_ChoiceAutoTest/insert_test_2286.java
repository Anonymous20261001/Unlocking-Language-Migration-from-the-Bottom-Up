package generated.test;

import java.awt.Choice;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ChoiceAutoTest {
    @Test
    public void insert_test_2286(String p0, int p1) {
      Choice instance = new Choice();
      instance.insert(p0, p1);
    }
}
