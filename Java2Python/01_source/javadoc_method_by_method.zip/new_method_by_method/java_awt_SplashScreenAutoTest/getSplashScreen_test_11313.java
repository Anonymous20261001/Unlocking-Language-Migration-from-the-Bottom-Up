package generated.test;

import java.awt.SplashScreen;
import org.junit.jupiter.api.Test;

public class java_awt_SplashScreenAutoTest {
    @Test
    public void getSplashScreen_test_11313() {
      SplashScreen.getSplashScreen();
    }
}
