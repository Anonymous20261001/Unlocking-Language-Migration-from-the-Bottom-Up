package generated.test;

import java.awt.MouseInfo;
import org.junit.jupiter.api.Test;

public class java_awt_MouseInfoAutoTest {
    @Test
    public void getNumberOfButtons_test_9025() {
      MouseInfo.getNumberOfButtons();
    }
}
