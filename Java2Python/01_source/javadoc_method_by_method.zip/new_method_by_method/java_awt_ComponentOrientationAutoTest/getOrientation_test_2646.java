package generated.test;

import java.awt.ComponentOrientation;
import java.util.Locale;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class java_awt_ComponentOrientationAutoTest {
    @Test
    public void getOrientation_test_2646(ResourceBundle p0) {
      ComponentOrientation.getOrientation(p0);
    }
}
