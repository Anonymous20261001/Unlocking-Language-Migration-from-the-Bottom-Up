package generated.test;

import java.awt.AlphaComposite;
import org.junit.jupiter.api.Test;

public class java_awt_AlphaCompositeAutoTest {
    @Test
    public void getInstance_test_145(int p0, float p1) {
      AlphaComposite.getInstance(p0, p1);
    }
}
