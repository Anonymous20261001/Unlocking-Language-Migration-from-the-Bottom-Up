package generated.test;

import java.awt.AlphaComposite;
import org.junit.jupiter.api.Test;

public class java_awt_AlphaCompositeAutoTest {
    @Test
    public void getInstance_test_144(int p0) {
      AlphaComposite.getInstance(p0);
    }
}
