package generated.test;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Event;
import java.awt.FocusTraversalPolicy;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.ContainerListener;
import java.beans.PropertyChangeListener;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.Class;
import java.lang.Object;
import java.lang.String;
import java.util.Set;
import org.junit.jupiter.api.Test;

public class java_awt_ContainerAutoTest {
    @Test
    public void getFocusTraversalPolicy_test_2941() {
      Container instance = new Container();
      instance.getFocusTraversalPolicy();
    }
}
