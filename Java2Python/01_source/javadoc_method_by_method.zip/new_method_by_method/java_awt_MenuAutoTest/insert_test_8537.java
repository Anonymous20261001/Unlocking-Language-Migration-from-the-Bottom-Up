package generated.test;

import java.awt.Menu;
import java.awt.MenuComponent;
import java.awt.MenuItem;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuAutoTest {
    @Test
    public void insert_test_8537(MenuItem p0, int p1) {
      Menu instance = new Menu();
      instance.insert(p0, p1);
    }
}
