package generated.test;

import java.awt.Menu;
import java.awt.MenuComponent;
import java.awt.MenuItem;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_MenuAutoTest {
    @Test
    public void paramString_test_8540() {
      Menu instance = new Menu();
      instance.paramString();
    }
}
