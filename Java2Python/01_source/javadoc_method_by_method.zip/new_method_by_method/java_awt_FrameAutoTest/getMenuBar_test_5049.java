package generated.test;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.Rectangle;
import java.awt.Shape;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_FrameAutoTest {
    @Test
    public void getMenuBar_test_5049() {
      Frame instance = new Frame();
      instance.getMenuBar();
    }
}
