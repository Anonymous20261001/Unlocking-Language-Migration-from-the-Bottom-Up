package generated.test;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.Rectangle;
import java.awt.Shape;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_FrameAutoTest {
    @Test
    public void setState_test_5070(int p0) {
      Frame instance = new Frame();
      instance.setState(p0);
    }
}
