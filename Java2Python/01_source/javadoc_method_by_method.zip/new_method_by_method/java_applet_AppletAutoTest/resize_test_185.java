package generated.test;

import java.applet.Applet;
import java.applet.AppletStub;
import java.awt.Dimension;
import java.lang.String;
import java.net.URL;
import org.junit.jupiter.api.Test;

public class java_applet_AppletAutoTest {
    @Test
    public void resize_test_185(Dimension p0) {
      Applet instance = new Applet();
      instance.resize(p0);
    }
}
