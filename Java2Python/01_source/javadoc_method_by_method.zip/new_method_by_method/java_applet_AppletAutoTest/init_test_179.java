package generated.test;

import java.applet.Applet;
import java.applet.AppletStub;
import java.awt.Dimension;
import java.lang.String;
import java.net.URL;
import org.junit.jupiter.api.Test;

public class java_applet_AppletAutoTest {
    @Test
    public void init_test_179() {
      Applet instance = new Applet();
      instance.init();
    }
}
