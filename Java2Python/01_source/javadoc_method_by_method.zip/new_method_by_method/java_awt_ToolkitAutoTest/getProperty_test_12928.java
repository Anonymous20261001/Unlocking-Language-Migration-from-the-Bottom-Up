package generated.test;

import java.awt.Toolkit;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ToolkitAutoTest {
    @Test
    public void getProperty_test_12928(String p0, String p1) {
      Toolkit.getProperty(p0, p1);
    }
}
