package generated.test;

import java.awt.Toolkit;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ToolkitAutoTest {
    @Test
    public void getDefaultToolkit_test_12927() {
      Toolkit.getDefaultToolkit();
    }
}
