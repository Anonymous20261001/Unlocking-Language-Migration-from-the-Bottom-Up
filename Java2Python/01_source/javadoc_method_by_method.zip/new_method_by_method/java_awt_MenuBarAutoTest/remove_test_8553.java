package generated.test;

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.MenuShortcut;
import org.junit.jupiter.api.Test;

public class java_awt_MenuBarAutoTest {
    @Test
    public void remove_test_8553(MenuComponent p0) {
      MenuBar instance = new MenuBar();
      instance.remove(p0);
    }
}
