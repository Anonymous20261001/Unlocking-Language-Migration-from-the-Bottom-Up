package generated.test;

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuComponent;
import java.awt.MenuShortcut;
import org.junit.jupiter.api.Test;

public class java_awt_MenuBarAutoTest {
    @Test
    public void getMenuCount_test_8543() {
      MenuBar instance = new MenuBar();
      instance.getMenuCount();
    }
}
