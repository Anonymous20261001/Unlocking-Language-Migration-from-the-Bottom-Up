package generated.test;

import java.awt.AWTEventMulticaster;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerListener;
import java.awt.event.FocusListener;
import java.awt.event.HierarchyBoundsListener;
import java.awt.event.HierarchyListener;
import java.awt.event.InputMethodListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;
import java.awt.event.TextListener;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.lang.Class;
import java.util.EventListener;
import org.junit.jupiter.api.Test;

public class java_awt_AWTEventMulticasterAutoTest {
    @Test
    public void add_test_933(MouseListener p0, MouseListener p1) {
      AWTEventMulticaster.add(p0, p1);
    }
}
