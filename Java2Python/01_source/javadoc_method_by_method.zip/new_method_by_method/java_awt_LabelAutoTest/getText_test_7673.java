package generated.test;

import java.awt.Label;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_LabelAutoTest {
    @Test
    public void getText_test_7673() {
      Label instance = new Label();
      instance.getText();
    }
}
