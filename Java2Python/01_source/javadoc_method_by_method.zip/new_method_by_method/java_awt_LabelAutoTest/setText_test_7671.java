package generated.test;

import java.awt.Label;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_LabelAutoTest {
    @Test
    public void setText_test_7671(String p0) {
      Label instance = new Label();
      instance.setText(p0);
    }
}
