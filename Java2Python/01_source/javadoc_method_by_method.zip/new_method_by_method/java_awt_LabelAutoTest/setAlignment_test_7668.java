package generated.test;

import java.awt.Label;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_LabelAutoTest {
    @Test
    public void setAlignment_test_7668(int p0) {
      Label instance = new Label();
      instance.setAlignment(p0);
    }
}
