package generated.test;

import java.awt.Label;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_LabelAutoTest {
    @Test
    public void addNotify_test_7669() {
      Label instance = new Label();
      instance.addNotify();
    }
}
