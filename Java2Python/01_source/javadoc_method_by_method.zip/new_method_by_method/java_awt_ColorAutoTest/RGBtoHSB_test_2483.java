package generated.test;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ColorAutoTest {
    @Test
    public void RGBtoHSB_test_2483(int p0, int p1, int p2, float[] p3) {
      Color.RGBtoHSB(p0, p1, p2, p3);
    }
}
