package generated.test;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ColorAutoTest {
    @Test
    public void getColorComponents_test_2486(ColorSpace p0, float[] p1, int c0) {
      Color instance = new Color(c0);
      instance.getColorComponents(p0, p1);
    }
}
