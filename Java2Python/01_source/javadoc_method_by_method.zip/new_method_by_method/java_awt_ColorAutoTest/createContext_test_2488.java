package generated.test;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ColorAutoTest {
    @Test
    public void createContext_test_2488(ColorModel p0, Rectangle p1, Rectangle2D p2,
        AffineTransform p3, RenderingHints p4, int c0) {
      Color instance = new Color(c0);
      instance.createContext(p0, p1, p2, p3, p4);
    }
}
