package generated.test;

import java.awt.KeyboardFocusManager;
import org.junit.jupiter.api.Test;

public class java_awt_KeyboardFocusManagerAutoTest {
    @Test
    public void getCurrentKeyboardFocusManager_test_7612() {
      KeyboardFocusManager.getCurrentKeyboardFocusManager();
    }
}
