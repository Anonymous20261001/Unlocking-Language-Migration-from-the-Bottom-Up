package generated.test;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ListAutoTest {
    @Test
    public void delItems_test_7953(int p0, int p1) {
      List instance = new List();
      instance.delItems(p0, p1);
    }
}
