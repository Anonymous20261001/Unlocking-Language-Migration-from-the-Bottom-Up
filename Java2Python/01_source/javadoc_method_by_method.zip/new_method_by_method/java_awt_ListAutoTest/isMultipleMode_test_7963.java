package generated.test;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ListAutoTest {
    @Test
    public void isMultipleMode_test_7963() {
      List instance = new List();
      instance.isMultipleMode();
    }
}
