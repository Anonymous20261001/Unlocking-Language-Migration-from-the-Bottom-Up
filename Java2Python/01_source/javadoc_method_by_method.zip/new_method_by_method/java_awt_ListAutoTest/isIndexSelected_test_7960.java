package generated.test;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.lang.Class;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class java_awt_ListAutoTest {
    @Test
    public void isIndexSelected_test_7960(int p0) {
      List instance = new List();
      instance.isIndexSelected(p0);
    }
}
