package generated.test;

import org.junit.Test;

public class java_awt_AWTKeyStrokeAutoTest {

    /** Randoop-generated regression test for java.awt.AWTKeyStroke.getAWTKeyStroke(). */
    @Test
    public void getAWTKeyStroke_test_948() throws Throwable {
        java.awt.AWTKeyStroke aWTKeyStroke2 = java.awt.AWTKeyStroke.getAWTKeyStroke((int) ' ', (int) (short) 0);
        java.lang.String str3 = aWTKeyStroke2.toString();
        java.lang.Class<?> wildcardClass4 = aWTKeyStroke2.getClass();
        org.junit.Assert.assertNotNull(aWTKeyStroke2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "pressed SPACE" + "'", str3, "pressed SPACE");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
