package generated.test;

import org.junit.Test;

public class java_awt_AWTKeyStrokeAutoTest {

    /** Randoop-generated regression test for java.awt.AWTKeyStroke.getAWTKeyStrokeForEvent(). */
    @Test
    public void getAWTKeyStrokeForEvent_test_951() throws Throwable {
        java.awt.event.KeyEvent keyEvent0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.awt.AWTKeyStroke aWTKeyStroke1 = java.awt.AWTKeyStroke.getAWTKeyStrokeForEvent(keyEvent0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.event.KeyEvent.getID()\" because \"anEvent\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
