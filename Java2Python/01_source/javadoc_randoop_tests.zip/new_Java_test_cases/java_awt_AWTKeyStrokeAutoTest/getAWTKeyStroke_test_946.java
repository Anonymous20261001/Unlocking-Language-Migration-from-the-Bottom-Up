package generated.test;

import org.junit.Test;

public class java_awt_AWTKeyStrokeAutoTest {

    /** Randoop-generated regression test for java.awt.AWTKeyStroke.getAWTKeyStroke(). */
    @Test
    public void getAWTKeyStroke_test_946() throws Throwable {
        java.awt.AWTKeyStroke aWTKeyStroke1 = java.awt.AWTKeyStroke.getAWTKeyStroke('a');
        java.lang.String str2 = aWTKeyStroke1.toString();
        java.lang.Class<?> wildcardClass3 = aWTKeyStroke1.getClass();
        org.junit.Assert.assertNotNull(aWTKeyStroke1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "typed a" + "'", str2, "typed a");
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
