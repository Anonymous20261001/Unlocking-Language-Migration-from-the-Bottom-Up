package generated.test;

import org.junit.Test;

public class java_awt_AWTKeyStrokeAutoTest {

    /** Randoop-generated regression test for java.awt.AWTKeyStroke.getAWTKeyStroke(). */
    @Test
    public void getAWTKeyStroke_test_949() throws Throwable {
        java.awt.AWTKeyStroke aWTKeyStroke3 = java.awt.AWTKeyStroke.getAWTKeyStroke(0, 100, true);
        java.lang.Class<?> wildcardClass4 = aWTKeyStroke3.getClass();
        org.junit.Assert.assertNotNull(aWTKeyStroke3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
