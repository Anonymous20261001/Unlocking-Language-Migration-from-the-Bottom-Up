package generated.test;

import org.junit.Test;

public class java_awt_geom_Path2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Path2D.contains(). */
    @Test
    public void contains_test_9838() throws Throwable {
        java.awt.geom.Path2D.Float float0 = new java.awt.geom.Path2D.Float();
        java.awt.geom.AffineTransform affineTransform1 = null;
        java.awt.geom.PathIterator pathIterator2 = float0.getPathIterator(affineTransform1);
        java.awt.geom.Point2D point2D3 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = java.awt.geom.Path2D.contains(pathIterator2, point2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.geom.Point2D.getX()\" because \"p\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(pathIterator2);
    }
}
