package generated.test;

import org.junit.Test;

public class java_awt_geom_Path2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Path2D.contains(). */
    @Test
    public void contains_test_9837() throws Throwable {
        java.awt.geom.PathIterator pathIterator0 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean3 = java.awt.geom.Path2D.contains(pathIterator0, (double) 0L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.geom.PathIterator.getWindingRule()\" because \"pi\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
