package generated.test;

import org.junit.Test;

public class java_awt_geom_Path2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Path2D.intersects(). */
    @Test
    public void intersects_test_9840() throws Throwable {
        java.awt.geom.PathIterator pathIterator0 = null;
        java.awt.geom.Rectangle2D.Float float1 = new java.awt.geom.Rectangle2D.Float();
        java.lang.String str2 = float1.toString();
        double double3 = float1.getY();
        boolean boolean4 = java.awt.geom.Path2D.intersects(pathIterator0, (java.awt.geom.Rectangle2D) float1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "java.awt.geom.Rectangle2D$Float[x=0.0,y=0.0,w=0.0,h=0.0]" + "'", str2, "java.awt.geom.Rectangle2D$Float[x=0.0,y=0.0,w=0.0,h=0.0]");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
