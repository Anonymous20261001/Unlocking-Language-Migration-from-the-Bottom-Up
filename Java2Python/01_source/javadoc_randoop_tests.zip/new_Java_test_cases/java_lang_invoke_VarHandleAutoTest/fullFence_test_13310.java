package generated.test;

import org.junit.Test;

public class java_lang_invoke_VarHandleAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.VarHandle.fullFence(). */
    @Test
    public void fullFence_test_13310() throws Throwable {
        java.lang.invoke.VarHandle.fullFence();
    }
}
