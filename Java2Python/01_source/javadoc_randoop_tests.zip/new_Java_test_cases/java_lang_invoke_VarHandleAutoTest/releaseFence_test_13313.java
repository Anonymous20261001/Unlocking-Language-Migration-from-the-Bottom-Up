package generated.test;

import org.junit.Test;

public class java_lang_invoke_VarHandleAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.VarHandle.releaseFence(). */
    @Test
    public void releaseFence_test_13313() throws Throwable {
        java.lang.invoke.VarHandle.releaseFence();
    }
}
