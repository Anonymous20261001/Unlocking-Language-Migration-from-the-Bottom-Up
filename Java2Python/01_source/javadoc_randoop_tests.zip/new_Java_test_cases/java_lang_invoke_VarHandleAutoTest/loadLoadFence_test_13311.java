package generated.test;

import org.junit.Test;

public class java_lang_invoke_VarHandleAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.VarHandle.loadLoadFence(). */
    @Test
    public void loadLoadFence_test_13311() throws Throwable {
        java.lang.invoke.VarHandle.loadLoadFence();
    }
}
