package generated.test;

import org.junit.Test;

public class java_lang_invoke_VarHandleAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.VarHandle.acquireFence(). */
    @Test
    public void acquireFence_test_13312() throws Throwable {
        java.lang.invoke.VarHandle.acquireFence();
    }
}
