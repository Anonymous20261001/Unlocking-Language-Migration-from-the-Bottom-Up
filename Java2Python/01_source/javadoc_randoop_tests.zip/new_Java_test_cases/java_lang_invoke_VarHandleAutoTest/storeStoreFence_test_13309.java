package generated.test;

import org.junit.Test;

public class java_lang_invoke_VarHandleAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.VarHandle.storeStoreFence(). */
    @Test
    public void storeStoreFence_test_13309() throws Throwable {
        java.lang.invoke.VarHandle.storeStoreFence();
    }
}
