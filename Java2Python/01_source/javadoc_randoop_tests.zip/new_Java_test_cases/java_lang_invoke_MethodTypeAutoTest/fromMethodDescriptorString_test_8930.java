package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodTypeAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodType.fromMethodDescriptorString(). */
    @Test
    public void fromMethodDescriptorString_test_8930() throws Throwable {
        java.lang.ClassLoader classLoader1 = null;
        java.lang.invoke.MethodType methodType2 = java.lang.invoke.MethodType.fromMethodDescriptorString("(Ljava/lang/Object;)Ljava/lang/Object;", classLoader1);
        java.lang.Class<?> wildcardClass3 = methodType2.getClass();
        org.junit.Assert.assertNotNull(methodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
