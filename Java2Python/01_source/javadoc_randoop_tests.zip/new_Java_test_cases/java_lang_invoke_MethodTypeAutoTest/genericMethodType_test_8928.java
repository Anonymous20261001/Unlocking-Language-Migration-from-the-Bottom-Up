package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodTypeAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodType.genericMethodType(). */
    @Test
    public void genericMethodType_test_8928() throws Throwable {
        java.lang.invoke.MethodType methodType2 = java.lang.invoke.MethodType.genericMethodType(10, true);
        java.lang.Class<?> wildcardClass3 = methodType2.getClass();
        org.junit.Assert.assertNotNull(methodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
