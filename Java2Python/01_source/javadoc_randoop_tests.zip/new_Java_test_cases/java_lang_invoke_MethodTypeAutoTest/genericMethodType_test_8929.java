package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodTypeAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodType.genericMethodType(). */
    @Test
    public void genericMethodType_test_8929() throws Throwable {
        java.lang.invoke.MethodType methodType1 = java.lang.invoke.MethodType.genericMethodType((int) (byte) 0);
        boolean boolean3 = methodType1.equals((java.lang.Object) 100);
        java.lang.String str4 = methodType1.toString();
        org.junit.Assert.assertNotNull(methodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "()Object" + "'", str4, "()Object");
    }
}
