package generated.test;

import org.junit.Test;

public class java_awt_font_TextHitInfoAutoTest {

    /** Randoop-generated regression test for java.awt.font.TextHitInfo.beforeOffset(). */
    @Test
    public void beforeOffset_test_12589() throws Throwable {
        java.awt.font.TextHitInfo textHitInfo1 = java.awt.font.TextHitInfo.beforeOffset((int) (short) 1);
        java.lang.Class<?> wildcardClass2 = textHitInfo1.getClass();
        org.junit.Assert.assertNotNull(textHitInfo1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
