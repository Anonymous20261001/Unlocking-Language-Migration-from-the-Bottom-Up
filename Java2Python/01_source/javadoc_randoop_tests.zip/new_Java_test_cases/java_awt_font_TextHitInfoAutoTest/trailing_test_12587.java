package generated.test;

import org.junit.Test;

public class java_awt_font_TextHitInfoAutoTest {

    /** Randoop-generated regression test for java.awt.font.TextHitInfo.trailing(). */
    @Test
    public void trailing_test_12587() throws Throwable {
        java.awt.font.TextHitInfo textHitInfo1 = java.awt.font.TextHitInfo.trailing(0);
        java.lang.Class<?> wildcardClass2 = textHitInfo1.getClass();
        org.junit.Assert.assertNotNull(textHitInfo1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
