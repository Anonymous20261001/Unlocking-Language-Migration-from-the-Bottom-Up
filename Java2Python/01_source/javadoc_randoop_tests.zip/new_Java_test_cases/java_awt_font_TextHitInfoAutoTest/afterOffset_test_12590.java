package generated.test;

import org.junit.Test;

public class java_awt_font_TextHitInfoAutoTest {

    /** Randoop-generated regression test for java.awt.font.TextHitInfo.afterOffset(). */
    @Test
    public void afterOffset_test_12590() throws Throwable {
        java.awt.font.TextHitInfo textHitInfo1 = java.awt.font.TextHitInfo.afterOffset((int) '#');
        java.lang.Class<?> wildcardClass2 = textHitInfo1.getClass();
        org.junit.Assert.assertNotNull(textHitInfo1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
