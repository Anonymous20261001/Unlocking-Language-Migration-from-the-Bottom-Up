package generated.test;

import org.junit.Test;

public class java_awt_font_TextHitInfoAutoTest {

    /** Randoop-generated regression test for java.awt.font.TextHitInfo.leading(). */
    @Test
    public void leading_test_12588() throws Throwable {
        java.awt.font.TextHitInfo textHitInfo1 = java.awt.font.TextHitInfo.leading((int) (byte) 0);
        java.lang.Object obj2 = null;
        boolean boolean3 = textHitInfo1.equals(obj2);
        java.lang.String str4 = textHitInfo1.toString();
        org.junit.Assert.assertNotNull(textHitInfo1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "TextHitInfo[0L]" + "'", str4, "TextHitInfo[0L]");
    }
}
