package generated.test;

import org.junit.Test;

public class java_lang_ClassAutoTest {

    /** Randoop-generated regression test for java.lang.Class.forName(). */
    @Test
    public void forName_test_2310() throws Throwable {
        java.lang.Module module0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass2 = java.lang.Class.forName(module0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
