package generated.test;

import org.junit.Test;

public class java_awt_ColorAutoTest {

    /** Randoop-generated regression test for java.awt.Color.decode(). */
    @Test
    public void decode_test_2490() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
            // Expected exception.
        }
    }
}
