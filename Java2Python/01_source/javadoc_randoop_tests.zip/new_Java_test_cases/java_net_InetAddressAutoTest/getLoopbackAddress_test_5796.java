package generated.test;

import org.junit.Test;

public class java_net_InetAddressAutoTest {

    /** Randoop-generated regression test for java.net.InetAddress.getLoopbackAddress(). */
    @Test
    public void getLoopbackAddress_test_5796() throws Throwable {
        java.net.InetAddress inetAddress0 = java.net.InetAddress.getLoopbackAddress();
        boolean boolean1 = inetAddress0.isMCSiteLocal();
        java.lang.String str2 = inetAddress0.toString();
        java.lang.Class<?> wildcardClass3 = inetAddress0.getClass();
        org.junit.Assert.assertNotNull(inetAddress0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "localhost/127.0.0.1" + "'", str2, "localhost/127.0.0.1");
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
