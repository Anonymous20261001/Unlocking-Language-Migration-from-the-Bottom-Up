package generated.test;

import org.junit.Test;

public class java_awt_AlphaCompositeAutoTest {

    /** Randoop-generated regression test for java.awt.AlphaComposite.getInstance(). */
    @Test
    public void getInstance_test_144() throws Throwable {
        java.awt.AlphaComposite alphaComposite1 = java.awt.AlphaComposite.getInstance(11);
        java.lang.Object obj2 = null;
        boolean boolean3 = alphaComposite1.equals(obj2);
        java.lang.Class<?> wildcardClass4 = alphaComposite1.getClass();
        org.junit.Assert.assertNotNull(alphaComposite1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
