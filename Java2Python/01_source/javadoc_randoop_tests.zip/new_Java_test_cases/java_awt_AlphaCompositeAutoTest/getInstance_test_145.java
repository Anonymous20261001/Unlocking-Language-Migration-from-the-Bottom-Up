package generated.test;

import org.junit.Test;

public class java_awt_AlphaCompositeAutoTest {

    /** Randoop-generated regression test for java.awt.AlphaComposite.getInstance(). */
    @Test
    public void getInstance_test_145() throws Throwable {
        java.awt.AlphaComposite alphaComposite2 = java.awt.AlphaComposite.getInstance((int) (byte) 10, (float) (short) 1);
        java.awt.AlphaComposite alphaComposite3 = java.awt.AlphaComposite.SrcIn;
        boolean boolean4 = alphaComposite2.equals((java.lang.Object) alphaComposite3);
        org.junit.Assert.assertNotNull(alphaComposite2);
        org.junit.Assert.assertNotNull(alphaComposite3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
