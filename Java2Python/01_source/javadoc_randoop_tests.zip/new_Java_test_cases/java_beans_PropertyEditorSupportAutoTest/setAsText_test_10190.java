package generated.test;

import org.junit.Test;

public class java_beans_PropertyEditorSupportAutoTest {

    /** Randoop-generated regression test for java.beans.PropertyEditorSupport.setAsText(). */
    @Test
    public void setAsText_test_10190() throws Throwable {
        java.beans.PropertyEditorSupport propertyEditorSupport0 = new java.beans.PropertyEditorSupport();
        java.lang.Object obj1 = propertyEditorSupport0.getValue();
        java.lang.Object obj2 = propertyEditorSupport0.getValue();
        // The following exception was thrown during execution in test generation
        try {
            propertyEditorSupport0.setAsText("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: hi!");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNull(obj1);
        org.junit.Assert.assertNull(obj2);
    }
}
