package generated.test;

import org.junit.Test;

public class java_lang_constant_ConstantDescsAutoTest {

    /** Randoop-generated regression test for java.lang.constant.ConstantDescs.ofConstantBootstrap(). */
    @Test
    public void ofConstantBootstrap_test_2932() throws Throwable {
        java.lang.constant.ClassDesc classDesc0 = java.lang.constant.ConstantDescs.CD_Map;
        java.lang.constant.ClassDesc classDesc2 = java.lang.constant.ConstantDescs.CD_Byte;
        java.lang.constant.ClassDesc[] classDescArray3 = new java.lang.constant.ClassDesc[] {};
        java.lang.constant.DirectMethodHandleDesc directMethodHandleDesc4 = java.lang.constant.ConstantDescs.ofConstantBootstrap(classDesc0, "hi!", classDesc2, classDescArray3);
        org.junit.Assert.assertNotNull(classDesc0);
        org.junit.Assert.assertNotNull(classDesc2);
        org.junit.Assert.assertNotNull(classDescArray3);
        org.junit.Assert.assertArrayEquals(classDescArray3, new java.lang.constant.ClassDesc[] {});
        org.junit.Assert.assertNotNull(directMethodHandleDesc4);
    }
}
