package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.parseFloat(). */
    @Test
    public void parseFloat_test_4851() throws Throwable {
        float float1 = java.lang.Float.parseFloat("52.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }
}
