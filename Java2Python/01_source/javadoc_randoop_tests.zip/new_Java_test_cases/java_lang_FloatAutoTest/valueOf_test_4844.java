package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.valueOf(). */
    @Test
    public void valueOf_test_4844() throws Throwable {
        java.lang.Float float1 = java.lang.Float.valueOf(31.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 31.0f + "'", float1 == 31.0f);
    }
}
