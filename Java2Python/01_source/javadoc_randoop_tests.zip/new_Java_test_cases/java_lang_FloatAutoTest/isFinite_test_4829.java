package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.isFinite(). */
    @Test
    public void isFinite_test_4829() throws Throwable {
        boolean boolean1 = java.lang.Float.isFinite(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
