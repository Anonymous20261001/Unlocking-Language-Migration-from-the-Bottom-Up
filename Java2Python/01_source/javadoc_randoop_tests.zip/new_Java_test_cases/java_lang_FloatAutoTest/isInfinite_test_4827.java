package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.isInfinite(). */
    @Test
    public void isInfinite_test_4827() throws Throwable {
        boolean boolean1 = java.lang.Float.isInfinite(0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
