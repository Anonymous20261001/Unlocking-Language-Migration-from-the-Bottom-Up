package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.max(). */
    @Test
    public void max_test_4826() throws Throwable {
        float float2 = java.lang.Float.max((float) (byte) -1, Float.NaN);
        org.junit.Assert.assertTrue(Float.isNaN(float2));
    }
}
