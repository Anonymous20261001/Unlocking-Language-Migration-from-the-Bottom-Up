package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.isNaN(). */
    @Test
    public void isNaN_test_4849() throws Throwable {
        boolean boolean1 = java.lang.Float.isNaN(132.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
