package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.floatToRawIntBits(). */
    @Test
    public void floatToRawIntBits_test_4830() throws Throwable {
        int int1 = java.lang.Float.floatToRawIntBits(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
