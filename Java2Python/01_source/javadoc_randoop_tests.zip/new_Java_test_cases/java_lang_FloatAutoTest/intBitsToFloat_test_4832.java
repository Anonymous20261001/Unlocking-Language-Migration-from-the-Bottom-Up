package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.intBitsToFloat(). */
    @Test
    public void intBitsToFloat_test_4832() throws Throwable {
        float float1 = java.lang.Float.intBitsToFloat((int) (byte) -1);
        org.junit.Assert.assertTrue(Float.isNaN(float1));
    }
}
