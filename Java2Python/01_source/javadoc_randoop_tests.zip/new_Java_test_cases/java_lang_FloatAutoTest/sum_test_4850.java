package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.sum(). */
    @Test
    public void sum_test_4850() throws Throwable {
        float float2 = java.lang.Float.sum(4.5E-44f, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }
}
