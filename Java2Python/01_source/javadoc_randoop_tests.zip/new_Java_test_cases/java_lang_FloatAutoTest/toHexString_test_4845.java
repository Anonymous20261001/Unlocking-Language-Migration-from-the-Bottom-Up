package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.toHexString(). */
    @Test
    public void toHexString_test_4845() throws Throwable {
        java.lang.String str1 = java.lang.Float.toHexString(0.0f);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "0x0.0p0" + "'", str1, "0x0.0p0");
    }
}
