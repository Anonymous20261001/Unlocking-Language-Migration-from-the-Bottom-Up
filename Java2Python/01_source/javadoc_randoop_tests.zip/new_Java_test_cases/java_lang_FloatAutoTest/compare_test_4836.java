package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.compare(). */
    @Test
    public void compare_test_4836() throws Throwable {
        int int2 = java.lang.Float.compare(33.0f, 32.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }
}
