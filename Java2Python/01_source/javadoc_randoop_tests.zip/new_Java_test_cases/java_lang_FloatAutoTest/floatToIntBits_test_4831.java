package generated.test;

import org.junit.Test;

public class java_lang_FloatAutoTest {

    /** Randoop-generated regression test for java.lang.Float.floatToIntBits(). */
    @Test
    public void floatToIntBits_test_4831() throws Throwable {
        int int1 = java.lang.Float.floatToIntBits(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
