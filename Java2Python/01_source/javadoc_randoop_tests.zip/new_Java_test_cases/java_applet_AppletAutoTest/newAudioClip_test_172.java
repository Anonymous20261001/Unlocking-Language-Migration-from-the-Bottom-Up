package generated.test;

import org.junit.Test;

public class java_applet_AppletAutoTest {

    /** Randoop-generated regression test for java.applet.Applet.newAudioClip(). */
    @Test
    public void newAudioClip_test_172() throws Throwable {
        java.net.URL uRL0 = null;
        java.applet.AudioClip audioClip1 = java.applet.Applet.newAudioClip(uRL0);
        java.lang.Class<?> wildcardClass2 = audioClip1.getClass();
        org.junit.Assert.assertNotNull(audioClip1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
