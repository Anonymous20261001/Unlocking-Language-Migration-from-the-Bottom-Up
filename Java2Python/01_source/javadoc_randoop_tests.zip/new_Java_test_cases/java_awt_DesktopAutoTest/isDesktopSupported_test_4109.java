package generated.test;

import org.junit.Test;

public class java_awt_DesktopAutoTest {

    /** Randoop-generated regression test for java.awt.Desktop.isDesktopSupported(). */
    @Test
    public void isDesktopSupported_test_4109() throws Throwable {
        boolean boolean0 = java.awt.Desktop.isDesktopSupported();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }
}
