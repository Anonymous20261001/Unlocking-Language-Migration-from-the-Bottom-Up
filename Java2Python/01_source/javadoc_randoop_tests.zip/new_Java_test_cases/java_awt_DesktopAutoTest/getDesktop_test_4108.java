package generated.test;

import org.junit.Test;

public class java_awt_DesktopAutoTest {

    /** Randoop-generated regression test for java.awt.Desktop.getDesktop(). */
    @Test
    public void getDesktop_test_4108() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.Desktop desktop0 = java.awt.Desktop.getDesktop();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
