package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.compareUnsigned(). */
    @Test
    public void compareUnsigned_test_8150() throws Throwable {
        int int2 = java.lang.Long.compareUnsigned(27L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }
}
