package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.toHexString(). */
    @Test
    public void toHexString_test_8170() throws Throwable {
        java.lang.String str1 = java.lang.Long.toHexString(35L);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "23" + "'", str1, "23");
    }
}
