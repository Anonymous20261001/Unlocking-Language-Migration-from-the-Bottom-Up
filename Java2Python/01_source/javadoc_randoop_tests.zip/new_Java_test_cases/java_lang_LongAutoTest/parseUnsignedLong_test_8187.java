package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseUnsignedLong(). */
    @Test
    public void parseUnsignedLong_test_8187() throws Throwable {
        long long2 = java.lang.Long.parseUnsignedLong("10", 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }
}
