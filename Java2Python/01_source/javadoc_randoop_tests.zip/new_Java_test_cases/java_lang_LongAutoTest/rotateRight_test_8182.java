package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.rotateRight(). */
    @Test
    public void rotateRight_test_8182() throws Throwable {
        long long2 = java.lang.Long.rotateRight((long) 100, 58);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6400L + "'", long2 == 6400L);
    }
}
