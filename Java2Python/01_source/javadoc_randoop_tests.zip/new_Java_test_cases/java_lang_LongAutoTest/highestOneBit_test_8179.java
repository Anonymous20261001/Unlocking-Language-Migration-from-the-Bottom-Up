package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.highestOneBit(). */
    @Test
    public void highestOneBit_test_8179() throws Throwable {
        long long1 = java.lang.Long.highestOneBit(199L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 128L + "'", long1 == 128L);
    }
}
