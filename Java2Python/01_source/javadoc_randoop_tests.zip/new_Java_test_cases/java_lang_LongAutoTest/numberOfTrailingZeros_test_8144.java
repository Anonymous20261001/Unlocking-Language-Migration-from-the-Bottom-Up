package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.numberOfTrailingZeros(). */
    @Test
    public void numberOfTrailingZeros_test_8144() throws Throwable {
        int int1 = java.lang.Long.numberOfTrailingZeros(27L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
