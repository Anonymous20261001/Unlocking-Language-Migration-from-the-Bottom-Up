package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.getLong(). */
    @Test
    public void getLong_test_8157() throws Throwable {
        java.lang.Long long2 = java.lang.Long.getLong("", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}
