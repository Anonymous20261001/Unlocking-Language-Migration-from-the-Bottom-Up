package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.sum(). */
    @Test
    public void sum_test_8174() throws Throwable {
        long long2 = java.lang.Long.sum(0L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }
}
