package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseLong(). */
    @Test
    public void parseLong_test_8185() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            long long4 = java.lang.Long.parseLong((java.lang.CharSequence) "17", 1, 3, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
