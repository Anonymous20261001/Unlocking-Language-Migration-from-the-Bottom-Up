package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseLong(). */
    @Test
    public void parseLong_test_8184() throws Throwable {
        long long2 = java.lang.Long.parseLong("1", 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}
