package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.reverseBytes(). */
    @Test
    public void reverseBytes_test_8154() throws Throwable {
        long long1 = java.lang.Long.reverseBytes(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }
}
