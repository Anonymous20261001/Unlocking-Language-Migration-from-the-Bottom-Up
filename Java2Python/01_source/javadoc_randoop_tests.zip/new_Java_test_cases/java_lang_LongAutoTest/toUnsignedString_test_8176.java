package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.toUnsignedString(). */
    @Test
    public void toUnsignedString_test_8176() throws Throwable {
        java.lang.String str2 = java.lang.Long.toUnsignedString(8L, 57);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "8" + "'", str2, "8");
    }
}
