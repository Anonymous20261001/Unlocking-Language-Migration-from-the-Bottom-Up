package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.toBinaryString(). */
    @Test
    public void toBinaryString_test_8178() throws Throwable {
        java.lang.String str1 = java.lang.Long.toBinaryString(0L);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "0" + "'", str1, "0");
    }
}
