package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseLong(). */
    @Test
    public void parseLong_test_8183() throws Throwable {
        long long1 = java.lang.Long.parseLong("17");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 17L + "'", long1 == 17L);
    }
}
