package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.toOctalString(). */
    @Test
    public void toOctalString_test_8177() throws Throwable {
        java.lang.String str1 = java.lang.Long.toOctalString(52L);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "64" + "'", str1, "64");
    }
}
