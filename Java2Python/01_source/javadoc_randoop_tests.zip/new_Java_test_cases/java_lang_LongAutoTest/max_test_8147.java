package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.max(). */
    @Test
    public void max_test_8147() throws Throwable {
        long long2 = java.lang.Long.max((long) 100, 64L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }
}
