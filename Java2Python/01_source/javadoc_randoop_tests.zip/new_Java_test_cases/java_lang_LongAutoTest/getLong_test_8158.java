package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.getLong(). */
    @Test
    public void getLong_test_8158() throws Throwable {
        java.lang.Long long1 = java.lang.Long.getLong("");
        org.junit.Assert.assertNull(long1);
    }
}
