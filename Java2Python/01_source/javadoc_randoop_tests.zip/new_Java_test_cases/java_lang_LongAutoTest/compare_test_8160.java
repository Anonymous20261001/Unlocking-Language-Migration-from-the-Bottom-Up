package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.compare(). */
    @Test
    public void compare_test_8160() throws Throwable {
        int int2 = java.lang.Long.compare(64L, 64L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
