package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.valueOf(). */
    @Test
    public void valueOf_test_8169() throws Throwable {
        java.lang.Long long2 = java.lang.Long.valueOf("34", 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }
}
