package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.signum(). */
    @Test
    public void signum_test_8148() throws Throwable {
        int int1 = java.lang.Long.signum(100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }
}
