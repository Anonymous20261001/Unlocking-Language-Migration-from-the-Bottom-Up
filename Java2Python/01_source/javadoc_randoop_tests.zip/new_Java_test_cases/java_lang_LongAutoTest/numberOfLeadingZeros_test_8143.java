package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.numberOfLeadingZeros(). */
    @Test
    public void numberOfLeadingZeros_test_8143() throws Throwable {
        int int1 = java.lang.Long.numberOfLeadingZeros(3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 62 + "'", int1 == 62);
    }
}
