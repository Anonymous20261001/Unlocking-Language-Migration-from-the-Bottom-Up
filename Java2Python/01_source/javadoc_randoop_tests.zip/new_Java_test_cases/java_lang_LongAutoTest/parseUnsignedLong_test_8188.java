package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseUnsignedLong(). */
    @Test
    public void parseUnsignedLong_test_8188() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            long long4 = java.lang.Long.parseUnsignedLong((java.lang.CharSequence) "0", 64, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
