package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.min(). */
    @Test
    public void min_test_8146() throws Throwable {
        long long2 = java.lang.Long.min((long) '#', 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}
