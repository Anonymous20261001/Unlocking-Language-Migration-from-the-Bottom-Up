package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.parseUnsignedLong(). */
    @Test
    public void parseUnsignedLong_test_8186() throws Throwable {
        long long1 = java.lang.Long.parseUnsignedLong("0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }
}
