package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.decode(). */
    @Test
    public void decode_test_8171() throws Throwable {
        java.lang.Long long1 = java.lang.Long.decode("10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }
}
