package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.toUnsignedString(). */
    @Test
    public void toUnsignedString_test_8175() throws Throwable {
        java.lang.String str1 = java.lang.Long.toUnsignedString(1L);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "1" + "'", str1, "1");
    }
}
