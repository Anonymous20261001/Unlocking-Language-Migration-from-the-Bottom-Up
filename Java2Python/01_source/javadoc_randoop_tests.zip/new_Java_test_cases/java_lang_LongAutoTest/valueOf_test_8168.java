package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.valueOf(). */
    @Test
    public void valueOf_test_8168() throws Throwable {
        java.lang.Long long1 = java.lang.Long.valueOf(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }
}
