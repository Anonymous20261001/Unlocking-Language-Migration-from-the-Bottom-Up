package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.bitCount(). */
    @Test
    public void bitCount_test_8145() throws Throwable {
        int int1 = java.lang.Long.bitCount(34L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }
}
