package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.reverse(). */
    @Test
    public void reverse_test_8153() throws Throwable {
        long long1 = java.lang.Long.reverse(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }
}
