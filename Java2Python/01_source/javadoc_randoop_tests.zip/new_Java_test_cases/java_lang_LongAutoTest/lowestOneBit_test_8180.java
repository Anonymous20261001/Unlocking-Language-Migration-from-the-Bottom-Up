package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.lowestOneBit(). */
    @Test
    public void lowestOneBit_test_8180() throws Throwable {
        long long1 = java.lang.Long.lowestOneBit(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }
}
