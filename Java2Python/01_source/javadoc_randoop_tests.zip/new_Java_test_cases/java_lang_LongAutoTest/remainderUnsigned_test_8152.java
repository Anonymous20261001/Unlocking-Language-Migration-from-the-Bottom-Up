package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.remainderUnsigned(). */
    @Test
    public void remainderUnsigned_test_8152() throws Throwable {
        long long2 = java.lang.Long.remainderUnsigned(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
