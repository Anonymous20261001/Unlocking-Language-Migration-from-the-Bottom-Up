package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.divideUnsigned(). */
    @Test
    public void divideUnsigned_test_8151() throws Throwable {
        long long2 = java.lang.Long.divideUnsigned((long) 8, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }
}
