package generated.test;

import org.junit.Test;

public class java_lang_LongAutoTest {

    /** Randoop-generated regression test for java.lang.Long.rotateLeft(). */
    @Test
    public void rotateLeft_test_8181() throws Throwable {
        long long2 = java.lang.Long.rotateLeft(34L, 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8704L + "'", long2 == 8704L);
    }
}
