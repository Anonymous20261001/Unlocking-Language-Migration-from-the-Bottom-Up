package generated.test;

import org.junit.Test;

public class java_awt_ContainerAutoTest {

    /** Randoop-generated regression test for java.awt.Container.getMousePosition(). */
    @Test
    public void getMousePosition_test_2978() throws Throwable {
        java.awt.Container container0 = new java.awt.Container();
        // The following exception was thrown during execution in test generation
        try {
            java.awt.Point point1 = container0.getMousePosition();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
