package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.getLong(). */
    @Test
    public void getLong_test_239() throws Throwable {
        java.lang.Object obj0 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long2 = java.lang.reflect.Array.getLong(obj0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
