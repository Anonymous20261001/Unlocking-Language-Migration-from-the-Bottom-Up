package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.setBoolean(). */
    @Test
    public void setBoolean_test_245() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Array.setBoolean((java.lang.Object) ' ', 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
