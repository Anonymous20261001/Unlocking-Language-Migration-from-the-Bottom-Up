package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.getBoolean(). */
    @Test
    public void getBoolean_test_234() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean2 = java.lang.reflect.Array.getBoolean((java.lang.Object) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
