package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.getInt(). */
    @Test
    public void getInt_test_238() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            int int2 = java.lang.reflect.Array.getInt((java.lang.Object) 1.0d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
