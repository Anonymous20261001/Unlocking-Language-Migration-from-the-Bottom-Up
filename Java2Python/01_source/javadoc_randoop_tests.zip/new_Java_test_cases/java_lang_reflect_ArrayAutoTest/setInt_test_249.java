package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.setInt(). */
    @Test
    public void setInt_test_249() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Array.setInt((java.lang.Object) 1, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
