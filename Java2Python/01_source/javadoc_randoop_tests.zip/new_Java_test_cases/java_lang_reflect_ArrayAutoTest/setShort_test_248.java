package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.setShort(). */
    @Test
    public void setShort_test_248() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.Array.setShort((java.lang.Object) ' ', 0, (short) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
