package generated.test;

import org.junit.Test;

public class java_lang_reflect_ArrayAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Array.getDouble(). */
    @Test
    public void getDouble_test_241() throws Throwable {
        java.lang.Object obj0 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double2 = java.lang.reflect.Array.getDouble(obj0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
