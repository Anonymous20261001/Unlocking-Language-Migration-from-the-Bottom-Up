package generated.test;

import org.junit.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {

    /** Randoop-generated regression test for java.awt.datatransfer.SystemFlavorMap.encodeJavaMIMEType(). */
    @Test
    public void encodeJavaMIMEType_test_12441() throws Throwable {
        java.lang.String str1 = java.awt.datatransfer.SystemFlavorMap.encodeJavaMIMEType("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "JAVA_DATAFLAVOR:" + "'", str1, "JAVA_DATAFLAVOR:");
    }
}
