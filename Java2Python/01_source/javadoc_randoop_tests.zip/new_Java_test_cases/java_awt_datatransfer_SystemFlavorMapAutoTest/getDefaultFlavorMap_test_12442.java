package generated.test;

import org.junit.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {

    /** Randoop-generated regression test for java.awt.datatransfer.SystemFlavorMap.getDefaultFlavorMap(). */
    @Test
    public void getDefaultFlavorMap_test_12442() throws Throwable {
        java.awt.datatransfer.FlavorMap flavorMap0 = java.awt.datatransfer.SystemFlavorMap.getDefaultFlavorMap();
        java.lang.Class<?> wildcardClass1 = flavorMap0.getClass();
        org.junit.Assert.assertNotNull(flavorMap0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
