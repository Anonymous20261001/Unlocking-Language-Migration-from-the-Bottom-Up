package generated.test;

import org.junit.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {

    /** Randoop-generated regression test for java.awt.datatransfer.SystemFlavorMap.encodeDataFlavor(). */
    @Test
    public void encodeDataFlavor_test_12440() throws Throwable {
        java.awt.datatransfer.DataFlavor dataFlavor0 = java.awt.datatransfer.DataFlavor.getTextPlainUnicodeFlavor();
        boolean boolean1 = dataFlavor0.isRepresentationClassSerializable();
        java.lang.Object obj2 = dataFlavor0.clone();
        java.lang.String str3 = java.awt.datatransfer.SystemFlavorMap.encodeDataFlavor(dataFlavor0);
        boolean boolean4 = dataFlavor0.isRepresentationClassReader();
        org.junit.Assert.assertNotNull(dataFlavor0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "java.awt.datatransfer.DataFlavor[mimetype=text/plain;representationclass=java.io.InputStream]");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "JAVA_DATAFLAVOR:text/plain; class=java.io.InputStream; charset=null" + "'", str3, "JAVA_DATAFLAVOR:text/plain; class=java.io.InputStream; charset=null");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
