package generated.test;

import org.junit.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {

    /** Randoop-generated regression test for java.awt.datatransfer.SystemFlavorMap.isJavaMIMEType(). */
    @Test
    public void isJavaMIMEType_test_12438() throws Throwable {
        boolean boolean1 = java.awt.datatransfer.SystemFlavorMap.isJavaMIMEType("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
