package generated.test;

import org.junit.Test;

public class java_awt_datatransfer_SystemFlavorMapAutoTest {

    /** Randoop-generated regression test for java.awt.datatransfer.SystemFlavorMap.decodeJavaMIMEType(). */
    @Test
    public void decodeJavaMIMEType_test_12439() throws Throwable {
        java.lang.String str1 = java.awt.datatransfer.SystemFlavorMap.decodeJavaMIMEType("");
        org.junit.Assert.assertNull(str1);
    }
}
