package generated.test;

import org.junit.Test;

public class java_awt_print_PageFormatAutoTest {

    /** Randoop-generated regression test for java.awt.print.PageFormat.setOrientation(). */
    @Test
    public void setOrientation_test_9739() throws Throwable {
        java.awt.print.PageFormat pageFormat0 = new java.awt.print.PageFormat();
        pageFormat0.setOrientation(1);
        java.lang.Class<?> wildcardClass3 = pageFormat0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
