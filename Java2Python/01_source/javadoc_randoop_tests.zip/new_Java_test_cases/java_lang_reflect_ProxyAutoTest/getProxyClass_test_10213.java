package generated.test;

import org.junit.Test;

public class java_lang_reflect_ProxyAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Proxy.getProxyClass(). */
    @Test
    public void getProxyClass_test_10213() throws Throwable {
        java.lang.ClassLoader classLoader0 = null;
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        java.lang.Class<?> wildcardClass4 = java.lang.reflect.Proxy.getProxyClass(classLoader0, wildcardClassArray3);
        org.junit.Assert.assertNotNull(classArray2);
        org.junit.Assert.assertArrayEquals(classArray2, new java.lang.Class[] {});
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        org.junit.Assert.assertArrayEquals(wildcardClassArray3, new java.lang.Class[] {});
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
