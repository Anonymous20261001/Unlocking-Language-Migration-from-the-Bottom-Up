package generated.test;

import org.junit.Test;

public class java_lang_reflect_ProxyAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Proxy.newProxyInstance(). */
    @Test
    public void newProxyInstance_test_10216() throws Throwable {
        java.lang.ClassLoader classLoader0 = null;
        java.lang.Class<?>[] wildcardClassArray1 = null;
        java.lang.reflect.InvocationHandler invocationHandler2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = java.lang.reflect.Proxy.newProxyInstance(classLoader0, wildcardClassArray1, invocationHandler2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
