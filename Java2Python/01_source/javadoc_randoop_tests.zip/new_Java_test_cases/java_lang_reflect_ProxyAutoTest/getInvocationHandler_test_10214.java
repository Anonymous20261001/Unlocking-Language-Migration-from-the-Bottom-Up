package generated.test;

import org.junit.Test;

public class java_lang_reflect_ProxyAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Proxy.getInvocationHandler(). */
    @Test
    public void getInvocationHandler_test_10214() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.reflect.InvocationHandler invocationHandler2 = java.lang.reflect.Proxy.getInvocationHandler(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: not a proxy instance");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
