package generated.test;

import org.junit.Test;

public class java_net_ProxySelectorAutoTest {

    /** Randoop-generated regression test for java.net.ProxySelector.of(). */
    @Test
    public void of_test_10219() throws Throwable {
        java.net.InetSocketAddress inetSocketAddress2 = java.net.InetSocketAddress.createUnresolved("hi!", 10);
        int int3 = inetSocketAddress2.getPort();
        java.net.ProxySelector proxySelector4 = java.net.ProxySelector.of(inetSocketAddress2);
        org.junit.Assert.assertNotNull(inetSocketAddress2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(proxySelector4);
    }
}
