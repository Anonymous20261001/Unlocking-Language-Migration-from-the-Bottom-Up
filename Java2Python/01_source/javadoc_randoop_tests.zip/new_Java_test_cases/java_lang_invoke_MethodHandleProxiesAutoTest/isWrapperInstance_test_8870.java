package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandleProxiesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandleProxies.isWrapperInstance(). */
    @Test
    public void isWrapperInstance_test_8870() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        boolean boolean2 = java.lang.invoke.MethodHandleProxies.isWrapperInstance(obj0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
