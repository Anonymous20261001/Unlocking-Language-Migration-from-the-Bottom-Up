package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandleProxiesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandleProxies.wrapperInstanceTarget(). */
    @Test
    public void wrapperInstanceTarget_test_8872() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle2 = java.lang.invoke.MethodHandleProxies.wrapperInstanceTarget(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: not a wrapper instance");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
