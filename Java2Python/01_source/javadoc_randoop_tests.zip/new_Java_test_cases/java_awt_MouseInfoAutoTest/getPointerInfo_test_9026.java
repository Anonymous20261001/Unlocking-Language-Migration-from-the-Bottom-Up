package generated.test;

import org.junit.Test;

public class java_awt_MouseInfoAutoTest {

    /** Randoop-generated regression test for java.awt.MouseInfo.getPointerInfo(). */
    @Test
    public void getPointerInfo_test_9026() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.PointerInfo pointerInfo0 = java.awt.MouseInfo.getPointerInfo();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
