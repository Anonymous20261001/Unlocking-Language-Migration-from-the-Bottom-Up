package generated.test;

import org.junit.Test;

public class java_awt_MouseInfoAutoTest {

    /** Randoop-generated regression test for java.awt.MouseInfo.getNumberOfButtons(). */
    @Test
    public void getNumberOfButtons_test_9025() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            int int0 = java.awt.MouseInfo.getNumberOfButtons();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
