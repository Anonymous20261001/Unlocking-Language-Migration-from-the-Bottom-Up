package generated.test;

import org.junit.Test;

public class java_awt_print_BookAutoTest {

    /** Randoop-generated regression test for java.awt.print.Book.setPage(). */
    @Test
    public void setPage_test_1766() throws Throwable {
        java.awt.print.Book book0 = new java.awt.print.Book();
        java.awt.print.Printable printable2 = null;
        java.awt.print.PageFormat pageFormat3 = null;
        // The following exception was thrown during execution in test generation
        try {
            book0.setPage(0, printable2, pageFormat3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: painter is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
