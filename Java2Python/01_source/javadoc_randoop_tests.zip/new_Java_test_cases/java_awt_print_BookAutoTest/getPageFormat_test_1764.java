package generated.test;

import org.junit.Test;

public class java_awt_print_BookAutoTest {

    /** Randoop-generated regression test for java.awt.print.Book.getPageFormat(). */
    @Test
    public void getPageFormat_test_1764() throws Throwable {
        java.awt.print.Book book0 = new java.awt.print.Book();
        int int1 = book0.getNumberOfPages();
        int int2 = book0.getNumberOfPages();
        // The following exception was thrown during execution in test generation
        try {
            java.awt.print.PageFormat pageFormat4 = book0.getPageFormat(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0 >= 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
