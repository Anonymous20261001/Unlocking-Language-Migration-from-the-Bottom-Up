package generated.test;

import org.junit.Test;

public class java_awt_print_BookAutoTest {

    /** Randoop-generated regression test for java.awt.print.Book.getPrintable(). */
    @Test
    public void getPrintable_test_1763() throws Throwable {
        java.awt.print.Book book0 = new java.awt.print.Book();
        int int1 = book0.getNumberOfPages();
        int int2 = book0.getNumberOfPages();
        // The following exception was thrown during execution in test generation
        try {
            java.awt.print.Printable printable4 = book0.getPrintable(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1 >= 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
