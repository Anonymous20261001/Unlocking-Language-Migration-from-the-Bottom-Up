package generated.test;

import org.junit.Test;

public class java_awt_AWTEventMulticasterAutoTest {

    /** Randoop-generated regression test for java.awt.AWTEventMulticaster.add(). */
    @Test
    public void add_test_941() throws Throwable {
        java.awt.event.KeyListener keyListener0 = null;
        java.awt.event.KeyListener keyListener1 = null;
        java.awt.event.KeyListener keyListener2 = java.awt.AWTEventMulticaster.add(keyListener0, keyListener1);
        org.junit.Assert.assertNull(keyListener2);
    }
}
