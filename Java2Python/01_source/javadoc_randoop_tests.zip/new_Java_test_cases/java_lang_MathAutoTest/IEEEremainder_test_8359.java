package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.IEEEremainder(). */
    @Test
    public void IEEEremainder_test_8359() throws Throwable {
        double double2 = java.lang.Math.IEEEremainder((double) (byte) 100, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }
}
