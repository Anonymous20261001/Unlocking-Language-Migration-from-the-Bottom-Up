package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.max(). */
    @Test
    public void max_test_8313() throws Throwable {
        int int2 = java.lang.Math.max(35, (-2704));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }
}
