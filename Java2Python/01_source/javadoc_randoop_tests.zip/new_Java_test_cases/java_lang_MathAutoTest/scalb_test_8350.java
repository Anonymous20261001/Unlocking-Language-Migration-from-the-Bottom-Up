package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.scalb(). */
    @Test
    public void scalb_test_8350() throws Throwable {
        float float2 = java.lang.Math.scalb(0.0f, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }
}
