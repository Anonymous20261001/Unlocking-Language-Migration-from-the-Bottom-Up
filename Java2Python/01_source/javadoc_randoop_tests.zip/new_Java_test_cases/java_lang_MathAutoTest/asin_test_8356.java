package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.asin(). */
    @Test
    public void asin_test_8356() throws Throwable {
        double double1 = java.lang.Math.asin((double) 110);
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
