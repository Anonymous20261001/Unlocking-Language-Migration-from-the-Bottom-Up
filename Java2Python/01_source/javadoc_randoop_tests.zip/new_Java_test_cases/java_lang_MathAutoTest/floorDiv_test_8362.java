package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.floorDiv(). */
    @Test
    public void floorDiv_test_8362() throws Throwable {
        long long2 = java.lang.Math.floorDiv(35L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}
