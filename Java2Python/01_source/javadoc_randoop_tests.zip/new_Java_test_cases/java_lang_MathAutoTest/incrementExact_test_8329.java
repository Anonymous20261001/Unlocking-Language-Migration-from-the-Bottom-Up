package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.incrementExact(). */
    @Test
    public void incrementExact_test_8329() throws Throwable {
        int int1 = java.lang.Math.incrementExact(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }
}
