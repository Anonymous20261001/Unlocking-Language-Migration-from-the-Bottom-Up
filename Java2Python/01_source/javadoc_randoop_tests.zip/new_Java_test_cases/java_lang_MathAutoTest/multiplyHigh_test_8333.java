package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.multiplyHigh(). */
    @Test
    public void multiplyHigh_test_8333() throws Throwable {
        long long2 = java.lang.Math.multiplyHigh((long) (-100), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
