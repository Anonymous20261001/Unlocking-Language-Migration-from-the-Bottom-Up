package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.multiplyFull(). */
    @Test
    public void multiplyFull_test_8387() throws Throwable {
        long long2 = java.lang.Math.multiplyFull(0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
