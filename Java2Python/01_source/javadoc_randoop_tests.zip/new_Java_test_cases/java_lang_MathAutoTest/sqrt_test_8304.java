package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.sqrt(). */
    @Test
    public void sqrt_test_8304() throws Throwable {
        double double1 = java.lang.Math.sqrt((double) (-1.0f));
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
