package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.round(). */
    @Test
    public void round_test_8320() throws Throwable {
        int int1 = java.lang.Math.round(4.9E-44f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
