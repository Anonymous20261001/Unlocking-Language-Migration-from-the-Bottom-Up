package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.nextAfter(). */
    @Test
    public void nextAfter_test_8392() throws Throwable {
        float float2 = java.lang.Math.nextAfter(0.0f, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }
}
