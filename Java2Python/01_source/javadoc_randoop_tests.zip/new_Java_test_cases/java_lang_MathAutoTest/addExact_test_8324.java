package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.addExact(). */
    @Test
    public void addExact_test_8324() throws Throwable {
        int int2 = java.lang.Math.addExact(6, 101);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }
}
