package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.log(). */
    @Test
    public void log_test_8305() throws Throwable {
        double double1 = java.lang.Math.log((double) (-10L));
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
