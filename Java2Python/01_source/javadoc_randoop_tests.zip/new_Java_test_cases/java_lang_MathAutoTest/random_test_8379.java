package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.random(). */
    @Test
    public void random_test_8379() throws Throwable {
        double double0 = java.lang.Math.random();
        // flaky "1) test005(Test0)":         org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.1534848187599681d + "'", double0 == 0.1534848187599681d);
    }
}
