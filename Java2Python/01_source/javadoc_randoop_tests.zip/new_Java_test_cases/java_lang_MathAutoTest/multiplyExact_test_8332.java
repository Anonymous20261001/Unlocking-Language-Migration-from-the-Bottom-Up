package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.multiplyExact(). */
    @Test
    public void multiplyExact_test_8332() throws Throwable {
        int int2 = java.lang.Math.multiplyExact((int) '#', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }
}
