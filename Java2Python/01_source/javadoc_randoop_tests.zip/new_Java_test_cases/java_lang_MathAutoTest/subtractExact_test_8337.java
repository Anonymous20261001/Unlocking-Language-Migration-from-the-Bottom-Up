package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.subtractExact(). */
    @Test
    public void subtractExact_test_8337() throws Throwable {
        long long2 = java.lang.Math.subtractExact(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }
}
