package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.decrementExact(). */
    @Test
    public void decrementExact_test_8327() throws Throwable {
        int int1 = java.lang.Math.decrementExact(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }
}
