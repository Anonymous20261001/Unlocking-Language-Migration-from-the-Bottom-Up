package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.negateExact(). */
    @Test
    public void negateExact_test_8335() throws Throwable {
        int int1 = java.lang.Math.negateExact(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
