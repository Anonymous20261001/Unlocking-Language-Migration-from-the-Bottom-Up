package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.atan(). */
    @Test
    public void atan_test_8358() throws Throwable {
        double double1 = java.lang.Math.atan((-4.9E-324d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.9E-324d) + "'", double1 == (-4.9E-324d));
    }
}
