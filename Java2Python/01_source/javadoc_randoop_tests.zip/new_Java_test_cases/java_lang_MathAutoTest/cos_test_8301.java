package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.cos(). */
    @Test
    public void cos_test_8301() throws Throwable {
        double double1 = java.lang.Math.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }
}
