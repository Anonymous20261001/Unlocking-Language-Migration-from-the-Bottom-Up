package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.nextDown(). */
    @Test
    public void nextDown_test_8396() throws Throwable {
        float float1 = java.lang.Math.nextDown(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.99999994f + "'", float1 == 0.99999994f);
    }
}
