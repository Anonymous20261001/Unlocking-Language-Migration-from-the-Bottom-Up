package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.copySign(). */
    @Test
    public void copySign_test_8342() throws Throwable {
        double double2 = java.lang.Math.copySign(53.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.0d + "'", double2 == 53.0d);
    }
}
