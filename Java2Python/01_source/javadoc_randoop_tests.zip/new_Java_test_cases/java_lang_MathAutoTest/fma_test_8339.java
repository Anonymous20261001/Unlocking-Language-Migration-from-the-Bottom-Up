package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.fma(). */
    @Test
    public void fma_test_8339() throws Throwable {
        float float3 = java.lang.Math.fma((-1.0f), (float) 0L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }
}
