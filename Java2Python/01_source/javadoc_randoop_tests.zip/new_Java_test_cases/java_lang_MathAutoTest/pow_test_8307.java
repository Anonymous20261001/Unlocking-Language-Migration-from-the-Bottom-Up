package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.pow(). */
    @Test
    public void pow_test_8307() throws Throwable {
        double double2 = java.lang.Math.pow((double) (-2604L), 0.15348481875996808d);
        org.junit.Assert.assertTrue(Double.isNaN(double2));
    }
}
