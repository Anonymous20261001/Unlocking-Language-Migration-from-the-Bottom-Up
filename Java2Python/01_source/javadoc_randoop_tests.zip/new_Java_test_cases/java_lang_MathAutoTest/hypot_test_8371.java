package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.hypot(). */
    @Test
    public void hypot_test_8371() throws Throwable {
        double double2 = java.lang.Math.hypot(22026.465794806718d, Double.NaN);
        org.junit.Assert.assertTrue(Double.isNaN(double2));
    }
}
