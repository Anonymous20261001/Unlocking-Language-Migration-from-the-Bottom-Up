package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.toIntExact(). */
    @Test
    public void toIntExact_test_8386() throws Throwable {
        int int1 = java.lang.Math.toIntExact(99L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }
}
