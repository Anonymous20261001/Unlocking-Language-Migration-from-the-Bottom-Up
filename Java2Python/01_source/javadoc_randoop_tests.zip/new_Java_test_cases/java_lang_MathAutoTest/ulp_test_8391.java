package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.ulp(). */
    @Test
    public void ulp_test_8391() throws Throwable {
        float float1 = java.lang.Math.ulp(110.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }
}
