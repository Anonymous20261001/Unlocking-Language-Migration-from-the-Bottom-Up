package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.toRadians(). */
    @Test
    public void toRadians_test_8377() throws Throwable {
        double double1 = java.lang.Math.toRadians(Double.NaN);
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
