package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.floorMod(). */
    @Test
    public void floorMod_test_8354() throws Throwable {
        int int2 = java.lang.Math.floorMod((-100L), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }
}
