package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.absExact(). */
    @Test
    public void absExact_test_8389() throws Throwable {
        int int1 = java.lang.Math.absExact(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }
}
