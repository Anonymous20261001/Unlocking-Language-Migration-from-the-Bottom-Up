package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.atan2(). */
    @Test
    public void atan2_test_8303() throws Throwable {
        double double2 = java.lang.Math.atan2(0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }
}
