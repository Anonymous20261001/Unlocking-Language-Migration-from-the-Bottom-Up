package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.acos(). */
    @Test
    public void acos_test_8357() throws Throwable {
        double double1 = java.lang.Math.acos((double) '4');
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
