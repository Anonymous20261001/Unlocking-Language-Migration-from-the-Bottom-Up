package generated.test;

import org.junit.Test;

public class java_lang_MathAutoTest {

    /** Randoop-generated regression test for java.lang.Math.nextUp(). */
    @Test
    public void nextUp_test_8395() throws Throwable {
        float float1 = java.lang.Math.nextUp(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.8E-45f + "'", float1 == 2.8E-45f);
    }
}
