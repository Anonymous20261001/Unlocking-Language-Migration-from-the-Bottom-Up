package generated.test;

import org.junit.Test;

public class java_io_InputStreamAutoTest {

    /** Randoop-generated regression test for java.io.InputStream.nullInputStream(). */
    @Test
    public void nullInputStream_test_5854() throws Throwable {
        java.io.InputStream inputStream0 = java.io.InputStream.nullInputStream();
        java.lang.Class<?> wildcardClass1 = inputStream0.getClass();
        org.junit.Assert.assertNotNull(inputStream0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
