package generated.test;

import org.junit.Test;

public class java_lang_management_ThreadInfoAutoTest {

    /** Randoop-generated regression test for java.lang.management.ThreadInfo.from(). */
    @Test
    public void from_test_12708() throws Throwable {
        javax.management.openmbean.CompositeData compositeData0 = null;
        java.lang.management.ThreadInfo threadInfo1 = java.lang.management.ThreadInfo.from(compositeData0);
        org.junit.Assert.assertNull(threadInfo1);
    }
}
