package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseUnsignedInt(). */
    @Test
    public void parseUnsignedInt_test_5903() throws Throwable {
        int int1 = java.lang.Integer.parseUnsignedInt("31");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }
}
