package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.decode(). */
    @Test
    public void decode_test_5892() throws Throwable {
        java.lang.Integer int1 = java.lang.Integer.decode("0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
