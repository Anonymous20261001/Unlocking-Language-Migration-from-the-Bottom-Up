package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseInt(). */
    @Test
    public void parseInt_test_5897() throws Throwable {
        int int2 = java.lang.Integer.parseInt("1100001", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 973 + "'", int2 == 973);
    }
}
