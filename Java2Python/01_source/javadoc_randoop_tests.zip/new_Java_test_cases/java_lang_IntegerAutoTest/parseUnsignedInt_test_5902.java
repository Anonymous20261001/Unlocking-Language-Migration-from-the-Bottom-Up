package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseUnsignedInt(). */
    @Test
    public void parseUnsignedInt_test_5902() throws Throwable {
        int int2 = java.lang.Integer.parseUnsignedInt("35", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }
}
