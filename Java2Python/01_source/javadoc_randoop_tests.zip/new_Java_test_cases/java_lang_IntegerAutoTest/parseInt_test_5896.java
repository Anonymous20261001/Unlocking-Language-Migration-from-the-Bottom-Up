package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseInt(). */
    @Test
    public void parseInt_test_5896() throws Throwable {
        int int1 = java.lang.Integer.parseInt("0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
