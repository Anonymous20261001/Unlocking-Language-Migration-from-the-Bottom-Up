package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseInt(). */
    @Test
    public void parseInt_test_5895() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            int int4 = java.lang.Integer.parseInt((java.lang.CharSequence) "35", 43, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
