package generated.test;

import org.junit.Test;

public class java_lang_IntegerAutoTest {

    /** Randoop-generated regression test for java.lang.Integer.parseUnsignedInt(). */
    @Test
    public void parseUnsignedInt_test_5904() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            int int4 = java.lang.Integer.parseUnsignedInt((java.lang.CharSequence) "43", 1, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
