package generated.test;

import org.junit.Test;

public class java_awt_dnd_DragSourceAutoTest {

    /** Randoop-generated regression test for java.awt.dnd.DragSource.isDragImageSupported(). */
    @Test
    public void isDragImageSupported_test_4299() throws Throwable {
        boolean boolean0 = java.awt.dnd.DragSource.isDragImageSupported();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }
}
