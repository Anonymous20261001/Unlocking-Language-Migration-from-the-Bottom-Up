package generated.test;

import org.junit.Test;

public class java_awt_dnd_DragSourceAutoTest {

    /** Randoop-generated regression test for java.awt.dnd.DragSource.getDragThreshold(). */
    @Test
    public void getDragThreshold_test_4305() throws Throwable {
        int int0 = java.awt.dnd.DragSource.getDragThreshold();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }
}
