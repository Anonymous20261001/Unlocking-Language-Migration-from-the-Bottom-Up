package generated.test;

import org.junit.Test;

public class java_awt_dnd_DragSourceAutoTest {

    /** Randoop-generated regression test for java.awt.dnd.DragSource.getDefaultDragSource(). */
    @Test
    public void getDefaultDragSource_test_4298() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.dnd.DragSource dragSource0 = java.awt.dnd.DragSource.getDefaultDragSource();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
