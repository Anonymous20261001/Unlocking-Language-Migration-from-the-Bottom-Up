package generated.test;

import org.junit.Test;

public class java_lang_ref_ReferenceAutoTest {

    /** Randoop-generated regression test for java.lang.ref.Reference.reachabilityFence(). */
    @Test
    public void reachabilityFence_test_10486() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.ref.Reference.reachabilityFence(obj0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
