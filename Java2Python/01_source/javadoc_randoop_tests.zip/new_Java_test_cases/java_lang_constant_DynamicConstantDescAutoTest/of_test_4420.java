package generated.test;

import org.junit.Test;

public class java_lang_constant_DynamicConstantDescAutoTest {

    /** Randoop-generated regression test for java.lang.constant.DynamicConstantDesc.of(). */
    @Test
    public void of_test_4420() throws Throwable {
        java.lang.constant.DirectMethodHandleDesc directMethodHandleDesc0 = null;
        java.lang.constant.ConstantDesc[] constantDescArray1 = new java.lang.constant.ConstantDesc[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.constant.DynamicConstantDesc<java.lang.Object> objDynamicConstantDesc2 = java.lang.constant.DynamicConstantDesc.of(directMethodHandleDesc0, constantDescArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.constant.DirectMethodHandleDesc.invocationType()\" because \"bootstrapMethod\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(constantDescArray1);
        org.junit.Assert.assertArrayEquals(constantDescArray1, new java.lang.constant.ConstantDesc[] {});
    }
}
