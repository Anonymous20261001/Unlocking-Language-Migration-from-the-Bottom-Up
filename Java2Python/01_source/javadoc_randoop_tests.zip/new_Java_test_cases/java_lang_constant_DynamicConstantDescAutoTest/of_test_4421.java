package generated.test;

import org.junit.Test;

public class java_lang_constant_DynamicConstantDescAutoTest {

    /** Randoop-generated regression test for java.lang.constant.DynamicConstantDesc.of(). */
    @Test
    public void of_test_4421() throws Throwable {
        java.lang.constant.DirectMethodHandleDesc directMethodHandleDesc0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.constant.DynamicConstantDesc<java.lang.String> strDynamicConstantDesc1 = java.lang.constant.DynamicConstantDesc.of(directMethodHandleDesc0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.constant.DirectMethodHandleDesc.invocationType()\" because \"bootstrapMethod\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
