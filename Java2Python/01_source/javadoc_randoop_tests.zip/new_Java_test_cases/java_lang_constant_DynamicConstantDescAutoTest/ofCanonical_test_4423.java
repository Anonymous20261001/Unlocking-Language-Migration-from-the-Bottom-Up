package generated.test;

import org.junit.Test;

public class java_lang_constant_DynamicConstantDescAutoTest {

    /** Randoop-generated regression test for java.lang.constant.DynamicConstantDesc.ofCanonical(). */
    @Test
    public void ofCanonical_test_4423() throws Throwable {
        java.lang.constant.DirectMethodHandleDesc directMethodHandleDesc0 = null;
        java.lang.constant.ClassDesc classDesc2 = null;
        java.lang.constant.ConstantDesc[] constantDescArray3 = new java.lang.constant.ConstantDesc[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.constant.ConstantDesc constantDesc4 = java.lang.constant.DynamicConstantDesc.ofCanonical(directMethodHandleDesc0, "", classDesc2, constantDescArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(constantDescArray3);
        org.junit.Assert.assertArrayEquals(constantDescArray3, new java.lang.constant.ConstantDesc[] {});
    }
}
