package generated.test;

import org.junit.Test;

public class java_awt_image_RasterAutoTest {

    /** Randoop-generated regression test for java.awt.image.Raster.createWritableRaster(). */
    @Test
    public void createWritableRaster_test_10332() throws Throwable {
        java.awt.image.SampleModel sampleModel0 = null;
        java.awt.Point point1 = new java.awt.Point();
        java.lang.String str2 = point1.toString();
        // The following exception was thrown during execution in test generation
        try {
            java.awt.image.WritableRaster writableRaster3 = java.awt.image.Raster.createWritableRaster(sampleModel0, point1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.image.SampleModel.createDataBuffer()\" because \"sm\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "java.awt.Point[x=0,y=0]" + "'", str2, "java.awt.Point[x=0,y=0]");
    }
}
