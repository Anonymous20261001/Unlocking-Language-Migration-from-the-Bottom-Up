package generated.test;

import org.junit.Test;

public class java_awt_image_RasterAutoTest {

    /** Randoop-generated regression test for java.awt.image.Raster.createWritableRaster(). */
    @Test
    public void createWritableRaster_test_10333() throws Throwable {
        java.awt.image.SampleModel sampleModel0 = null;
        java.awt.image.DataBuffer dataBuffer1 = null;
        java.awt.Point point2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.awt.image.WritableRaster writableRaster3 = java.awt.image.Raster.createWritableRaster(sampleModel0, dataBuffer1, point2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: SampleModel and DataBuffer cannot be null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
