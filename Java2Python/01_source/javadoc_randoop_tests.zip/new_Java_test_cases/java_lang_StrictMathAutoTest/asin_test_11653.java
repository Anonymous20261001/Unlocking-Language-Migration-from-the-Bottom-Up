package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.asin(). */
    @Test
    public void asin_test_11653() throws Throwable {
        double double1 = java.lang.StrictMath.asin((double) 101);
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
