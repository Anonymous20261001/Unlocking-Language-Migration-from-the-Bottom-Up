package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.toIntExact(). */
    @Test
    public void toIntExact_test_11683() throws Throwable {
        int int1 = java.lang.StrictMath.toIntExact((long) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }
}
