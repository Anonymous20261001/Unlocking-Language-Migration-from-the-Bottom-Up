package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.nextUp(). */
    @Test
    public void nextUp_test_11691() throws Throwable {
        float float1 = java.lang.StrictMath.nextUp((-1.0000001f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }
}
