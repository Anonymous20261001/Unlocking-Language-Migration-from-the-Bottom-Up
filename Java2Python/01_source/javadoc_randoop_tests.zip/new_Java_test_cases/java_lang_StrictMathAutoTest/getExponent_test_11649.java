package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.getExponent(). */
    @Test
    public void getExponent_test_11649() throws Throwable {
        int int1 = java.lang.StrictMath.getExponent(10.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }
}
