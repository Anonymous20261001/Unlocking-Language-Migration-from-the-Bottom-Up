package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.multiplyExact(). */
    @Test
    public void multiplyExact_test_11629() throws Throwable {
        long long2 = java.lang.StrictMath.multiplyExact(0L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
