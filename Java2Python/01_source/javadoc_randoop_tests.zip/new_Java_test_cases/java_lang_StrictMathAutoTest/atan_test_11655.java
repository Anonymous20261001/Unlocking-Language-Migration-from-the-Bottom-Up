package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.atan(). */
    @Test
    public void atan_test_11655() throws Throwable {
        double double1 = java.lang.StrictMath.atan(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5657963684609384d + "'", double1 == 1.5657963684609384d);
    }
}
