package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.ceil(). */
    @Test
    public void ceil_test_11615() throws Throwable {
        double double1 = java.lang.StrictMath.ceil(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 200.0d + "'", double1 == 200.0d);
    }
}
