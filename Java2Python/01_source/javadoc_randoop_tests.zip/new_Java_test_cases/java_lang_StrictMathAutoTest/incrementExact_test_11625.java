package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.incrementExact(). */
    @Test
    public void incrementExact_test_11625() throws Throwable {
        int int1 = java.lang.StrictMath.incrementExact(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }
}
