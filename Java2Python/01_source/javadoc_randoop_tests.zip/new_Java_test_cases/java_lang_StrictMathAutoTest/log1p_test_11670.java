package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.log1p(). */
    @Test
    public void log1p_test_11670() throws Throwable {
        double double1 = java.lang.StrictMath.log1p(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }
}
