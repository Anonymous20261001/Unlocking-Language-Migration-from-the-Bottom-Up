package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.floorDiv(). */
    @Test
    public void floorDiv_test_11658() throws Throwable {
        long long2 = java.lang.StrictMath.floorDiv(2L, 200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
