package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.subtractExact(). */
    @Test
    public void subtractExact_test_11634() throws Throwable {
        int int2 = java.lang.StrictMath.subtractExact(1, (-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }
}
