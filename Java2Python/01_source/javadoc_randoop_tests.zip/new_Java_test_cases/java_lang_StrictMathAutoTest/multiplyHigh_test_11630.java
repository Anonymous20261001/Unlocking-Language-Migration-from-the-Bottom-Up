package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.multiplyHigh(). */
    @Test
    public void multiplyHigh_test_11630() throws Throwable {
        long long2 = java.lang.StrictMath.multiplyHigh(1L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }
}
