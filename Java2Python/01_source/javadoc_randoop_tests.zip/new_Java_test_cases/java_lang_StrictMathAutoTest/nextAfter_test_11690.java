package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.nextAfter(). */
    @Test
    public void nextAfter_test_11690() throws Throwable {
        double double2 = java.lang.StrictMath.nextAfter(Double.NaN, (double) 200);
        org.junit.Assert.assertTrue(Double.isNaN(double2));
    }
}
