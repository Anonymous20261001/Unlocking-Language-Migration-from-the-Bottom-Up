package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.sin(). */
    @Test
    public void sin_test_11597() throws Throwable {
        double double1 = java.lang.StrictMath.sin((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9835877454343449d + "'", double1 == 0.9835877454343449d);
    }
}
