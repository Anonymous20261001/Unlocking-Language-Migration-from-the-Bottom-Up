package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.negateExact(). */
    @Test
    public void negateExact_test_11632() throws Throwable {
        int int1 = java.lang.StrictMath.negateExact(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
