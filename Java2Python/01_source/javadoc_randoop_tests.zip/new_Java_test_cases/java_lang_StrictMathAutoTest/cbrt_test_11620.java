package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.cbrt(). */
    @Test
    public void cbrt_test_11620() throws Throwable {
        double double1 = java.lang.StrictMath.cbrt(Double.NaN);
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
