package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.fma(). */
    @Test
    public void fma_test_11636() throws Throwable {
        double double3 = java.lang.StrictMath.fma((double) 35L, 0.19334632705655574d, Double.NaN);
        org.junit.Assert.assertTrue(Double.isNaN(double3));
    }
}
