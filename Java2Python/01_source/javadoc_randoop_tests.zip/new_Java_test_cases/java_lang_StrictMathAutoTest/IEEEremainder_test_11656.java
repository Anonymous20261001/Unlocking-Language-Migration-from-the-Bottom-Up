package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.IEEEremainder(). */
    @Test
    public void IEEEremainder_test_11656() throws Throwable {
        double double2 = java.lang.StrictMath.IEEEremainder(0.9002435474900727d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9002435474900727d + "'", double2 == 0.9002435474900727d);
    }
}
