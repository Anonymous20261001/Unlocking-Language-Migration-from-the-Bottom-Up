package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.min(). */
    @Test
    public void min_test_11606() throws Throwable {
        int int2 = java.lang.StrictMath.min((-1), 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }
}
