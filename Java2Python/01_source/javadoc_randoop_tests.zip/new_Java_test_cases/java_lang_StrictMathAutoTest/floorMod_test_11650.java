package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.floorMod(). */
    @Test
    public void floorMod_test_11650() throws Throwable {
        int int2 = java.lang.StrictMath.floorMod(35L, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
