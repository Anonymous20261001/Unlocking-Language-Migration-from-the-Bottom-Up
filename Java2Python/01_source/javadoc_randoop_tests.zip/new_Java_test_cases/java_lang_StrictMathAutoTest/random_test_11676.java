package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.random(). */
    @Test
    public void random_test_11676() throws Throwable {
        double double0 = java.lang.StrictMath.random();
        // flaky "1) test003(Test0)":         org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.9002435474900726d + "'", double0 == 0.9002435474900726d);
    }
}
