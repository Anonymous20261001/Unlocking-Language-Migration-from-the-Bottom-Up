package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.multiplyFull(). */
    @Test
    public void multiplyFull_test_11684() throws Throwable {
        long long2 = java.lang.StrictMath.multiplyFull(6, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }
}
