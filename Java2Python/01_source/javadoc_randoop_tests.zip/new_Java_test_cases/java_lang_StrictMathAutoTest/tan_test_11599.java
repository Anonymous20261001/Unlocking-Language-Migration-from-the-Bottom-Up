package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.tan(). */
    @Test
    public void tan_test_11599() throws Throwable {
        double double1 = java.lang.StrictMath.tan(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.185039863261519d) + "'", double1 == (-2.185039863261519d));
    }
}
