package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.sqrt(). */
    @Test
    public void sqrt_test_11601() throws Throwable {
        double double1 = java.lang.StrictMath.sqrt((double) (-9));
        org.junit.Assert.assertTrue(Double.isNaN(double1));
    }
}
