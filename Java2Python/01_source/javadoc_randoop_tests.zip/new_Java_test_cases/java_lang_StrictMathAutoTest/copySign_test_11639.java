package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.copySign(). */
    @Test
    public void copySign_test_11639() throws Throwable {
        float float2 = java.lang.StrictMath.copySign(0.0f, (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }
}
