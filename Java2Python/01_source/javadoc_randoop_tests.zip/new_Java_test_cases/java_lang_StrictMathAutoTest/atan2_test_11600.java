package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.atan2(). */
    @Test
    public void atan2_test_11600() throws Throwable {
        double double2 = java.lang.StrictMath.atan2((double) 1L, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.540199097849144E-5d + "'", double2 == 4.540199097849144E-5d);
    }
}
