package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.toRadians(). */
    @Test
    public void toRadians_test_11674() throws Throwable {
        double double1 = java.lang.StrictMath.toRadians((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4457272005608357E-47d + "'", double1 == 2.4457272005608357E-47d);
    }
}
