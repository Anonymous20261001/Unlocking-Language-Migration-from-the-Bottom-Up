package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.nextDown(). */
    @Test
    public void nextDown_test_11694() throws Throwable {
        float float1 = java.lang.StrictMath.nextDown((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.999999f + "'", float1 == 9.999999f);
    }
}
