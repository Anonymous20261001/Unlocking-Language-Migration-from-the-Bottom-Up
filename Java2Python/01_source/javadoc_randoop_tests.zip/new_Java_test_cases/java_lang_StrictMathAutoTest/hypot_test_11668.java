package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.hypot(). */
    @Test
    public void hypot_test_11668() throws Throwable {
        double double2 = java.lang.StrictMath.hypot(156672.0d, (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156672.0001148897d + "'", double2 == 156672.0001148897d);
    }
}
