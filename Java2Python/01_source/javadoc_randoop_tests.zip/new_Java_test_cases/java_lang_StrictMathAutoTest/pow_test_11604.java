package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.pow(). */
    @Test
    public void pow_test_11604() throws Throwable {
        double double2 = java.lang.StrictMath.pow((double) (byte) 1, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }
}
