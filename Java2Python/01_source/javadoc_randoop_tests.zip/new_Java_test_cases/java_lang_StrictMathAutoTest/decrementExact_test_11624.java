package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.decrementExact(). */
    @Test
    public void decrementExact_test_11624() throws Throwable {
        int int1 = java.lang.StrictMath.decrementExact((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3) + "'", int1 == (-3));
    }
}
