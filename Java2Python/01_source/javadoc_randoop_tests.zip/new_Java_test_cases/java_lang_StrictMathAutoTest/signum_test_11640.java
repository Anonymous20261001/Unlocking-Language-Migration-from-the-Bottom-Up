package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.signum(). */
    @Test
    public void signum_test_11640() throws Throwable {
        float float1 = java.lang.StrictMath.signum(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }
}
