package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.absExact(). */
    @Test
    public void absExact_test_11686() throws Throwable {
        long long1 = java.lang.StrictMath.absExact((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }
}
