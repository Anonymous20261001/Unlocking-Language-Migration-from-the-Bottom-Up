package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.scalb(). */
    @Test
    public void scalb_test_11647() throws Throwable {
        double double2 = java.lang.StrictMath.scalb((double) 10, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }
}
