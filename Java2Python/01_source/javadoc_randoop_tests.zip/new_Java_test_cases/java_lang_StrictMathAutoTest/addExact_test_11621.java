package generated.test;

import org.junit.Test;

public class java_lang_StrictMathAutoTest {

    /** Randoop-generated regression test for java.lang.StrictMath.addExact(). */
    @Test
    public void addExact_test_11621() throws Throwable {
        int int2 = java.lang.StrictMath.addExact(0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }
}
