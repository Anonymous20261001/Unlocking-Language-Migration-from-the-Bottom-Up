package generated.test;

import org.junit.Test;

public class java_awt_print_PrinterJobAutoTest {

    /** Randoop-generated regression test for java.awt.print.PrinterJob.lookupPrintServices(). */
    @Test
    public void lookupPrintServices_test_10009() throws Throwable {
        javax.print.PrintService[] printServiceArray0 = java.awt.print.PrinterJob.lookupPrintServices();
        org.junit.Assert.assertNotNull(printServiceArray0);
        org.junit.Assert.assertArrayEquals(printServiceArray0, new javax.print.PrintService[] {});
    }
}
