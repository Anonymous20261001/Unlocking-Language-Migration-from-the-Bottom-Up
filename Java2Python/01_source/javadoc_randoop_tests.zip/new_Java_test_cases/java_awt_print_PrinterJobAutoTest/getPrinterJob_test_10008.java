package generated.test;

import org.junit.Test;

public class java_awt_print_PrinterJobAutoTest {

    /** Randoop-generated regression test for java.awt.print.PrinterJob.getPrinterJob(). */
    @Test
    public void getPrinterJob_test_10008() throws Throwable {
        java.awt.print.PrinterJob printerJob0 = java.awt.print.PrinterJob.getPrinterJob();
        java.lang.Class<?> wildcardClass1 = printerJob0.getClass();
        org.junit.Assert.assertNotNull(printerJob0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
