package generated.test;

import org.junit.Test;

public class java_awt_print_PrinterJobAutoTest {

    /** Randoop-generated regression test for java.awt.print.PrinterJob.lookupStreamPrintServices(). */
    @Test
    public void lookupStreamPrintServices_test_10010() throws Throwable {
        javax.print.StreamPrintServiceFactory[] streamPrintServiceFactoryArray1 = java.awt.print.PrinterJob.lookupStreamPrintServices("");
        java.lang.Class<?> wildcardClass2 = streamPrintServiceFactoryArray1.getClass();
        org.junit.Assert.assertNotNull(streamPrintServiceFactoryArray1);
        org.junit.Assert.assertArrayEquals(streamPrintServiceFactoryArray1, new javax.print.StreamPrintServiceFactory[] {});
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
