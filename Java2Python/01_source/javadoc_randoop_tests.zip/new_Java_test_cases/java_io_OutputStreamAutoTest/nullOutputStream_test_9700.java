package generated.test;

import org.junit.Test;

public class java_io_OutputStreamAutoTest {

    /** Randoop-generated regression test for java.io.OutputStream.nullOutputStream(). */
    @Test
    public void nullOutputStream_test_9700() throws Throwable {
        java.io.OutputStream outputStream0 = java.io.OutputStream.nullOutputStream();
        java.lang.Class<?> wildcardClass1 = outputStream0.getClass();
        org.junit.Assert.assertNotNull(outputStream0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
