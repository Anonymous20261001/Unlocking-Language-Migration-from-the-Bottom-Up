package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getGarbageCollectorMXBeans(). */
    @Test
    public void getGarbageCollectorMXBeans_test_8272() throws Throwable {
        java.util.List<java.lang.management.GarbageCollectorMXBean> garbageCollectorMXBeanList0 = java.lang.management.ManagementFactory.getGarbageCollectorMXBeans();
        java.lang.Class<?> wildcardClass1 = garbageCollectorMXBeanList0.getClass();
        org.junit.Assert.assertNotNull(garbageCollectorMXBeanList0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
