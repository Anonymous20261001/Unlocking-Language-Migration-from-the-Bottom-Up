package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getMemoryPoolMXBeans(). */
    @Test
    public void getMemoryPoolMXBeans_test_8270() throws Throwable {
        java.util.List<java.lang.management.MemoryPoolMXBean> memoryPoolMXBeanList0 = java.lang.management.ManagementFactory.getMemoryPoolMXBeans();
        java.lang.Class<?> wildcardClass1 = memoryPoolMXBeanList0.getClass();
        org.junit.Assert.assertNotNull(memoryPoolMXBeanList0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
