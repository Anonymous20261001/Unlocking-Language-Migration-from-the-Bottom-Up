package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getOperatingSystemMXBean(). */
    @Test
    public void getOperatingSystemMXBean_test_8269() throws Throwable {
        java.lang.management.OperatingSystemMXBean operatingSystemMXBean0 = java.lang.management.ManagementFactory.getOperatingSystemMXBean();
        java.lang.Class<?> wildcardClass1 = operatingSystemMXBean0.getClass();
        org.junit.Assert.assertNotNull(operatingSystemMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
