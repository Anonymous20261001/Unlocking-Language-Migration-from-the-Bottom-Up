package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getMemoryManagerMXBeans(). */
    @Test
    public void getMemoryManagerMXBeans_test_8271() throws Throwable {
        java.util.List<java.lang.management.MemoryManagerMXBean> memoryManagerMXBeanList0 = java.lang.management.ManagementFactory.getMemoryManagerMXBeans();
        java.lang.Class<?> wildcardClass1 = memoryManagerMXBeanList0.getClass();
        org.junit.Assert.assertNotNull(memoryManagerMXBeanList0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
