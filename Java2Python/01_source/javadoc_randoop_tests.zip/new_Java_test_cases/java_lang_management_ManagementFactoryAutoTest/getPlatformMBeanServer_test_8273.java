package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getPlatformMBeanServer(). */
    @Test
    public void getPlatformMBeanServer_test_8273() throws Throwable {
        javax.management.MBeanServer mBeanServer0 = java.lang.management.ManagementFactory.getPlatformMBeanServer();
        java.lang.Class<?> wildcardClass1 = mBeanServer0.getClass();
        org.junit.Assert.assertNotNull(mBeanServer0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
