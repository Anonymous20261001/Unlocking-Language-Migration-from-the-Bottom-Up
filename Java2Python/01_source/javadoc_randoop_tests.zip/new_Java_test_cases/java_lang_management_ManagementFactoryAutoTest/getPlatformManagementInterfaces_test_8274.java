package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getPlatformManagementInterfaces(). */
    @Test
    public void getPlatformManagementInterfaces_test_8274() throws Throwable {
        java.util.Set<java.lang.Class<? extends java.lang.management.PlatformManagedObject>> wildcardClassSet0 = java.lang.management.ManagementFactory.getPlatformManagementInterfaces();
        java.lang.Class<?> wildcardClass1 = wildcardClassSet0.getClass();
        org.junit.Assert.assertNotNull(wildcardClassSet0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
