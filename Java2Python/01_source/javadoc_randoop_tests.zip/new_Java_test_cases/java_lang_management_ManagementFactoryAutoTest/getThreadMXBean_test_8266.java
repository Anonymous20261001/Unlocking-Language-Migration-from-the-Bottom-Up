package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getThreadMXBean(). */
    @Test
    public void getThreadMXBean_test_8266() throws Throwable {
        java.lang.management.ThreadMXBean threadMXBean0 = java.lang.management.ManagementFactory.getThreadMXBean();
        java.lang.Class<?> wildcardClass1 = threadMXBean0.getClass();
        org.junit.Assert.assertNotNull(threadMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
