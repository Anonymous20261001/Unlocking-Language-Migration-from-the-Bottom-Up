package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getCompilationMXBean(). */
    @Test
    public void getCompilationMXBean_test_8268() throws Throwable {
        java.lang.management.CompilationMXBean compilationMXBean0 = java.lang.management.ManagementFactory.getCompilationMXBean();
        java.lang.Class<?> wildcardClass1 = compilationMXBean0.getClass();
        org.junit.Assert.assertNotNull(compilationMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
