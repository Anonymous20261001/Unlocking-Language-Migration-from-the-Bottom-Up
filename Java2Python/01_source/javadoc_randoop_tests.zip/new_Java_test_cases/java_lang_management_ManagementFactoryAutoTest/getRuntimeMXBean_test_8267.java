package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getRuntimeMXBean(). */
    @Test
    public void getRuntimeMXBean_test_8267() throws Throwable {
        java.lang.management.RuntimeMXBean runtimeMXBean0 = java.lang.management.ManagementFactory.getRuntimeMXBean();
        java.lang.Class<?> wildcardClass1 = runtimeMXBean0.getClass();
        org.junit.Assert.assertNotNull(runtimeMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
