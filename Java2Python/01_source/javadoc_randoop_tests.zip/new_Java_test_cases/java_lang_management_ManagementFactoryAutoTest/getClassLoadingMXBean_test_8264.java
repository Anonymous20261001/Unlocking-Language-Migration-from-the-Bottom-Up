package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getClassLoadingMXBean(). */
    @Test
    public void getClassLoadingMXBean_test_8264() throws Throwable {
        java.lang.management.ClassLoadingMXBean classLoadingMXBean0 = java.lang.management.ManagementFactory.getClassLoadingMXBean();
        java.lang.Class<?> wildcardClass1 = classLoadingMXBean0.getClass();
        org.junit.Assert.assertNotNull(classLoadingMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
