package generated.test;

import org.junit.Test;

public class java_lang_management_ManagementFactoryAutoTest {

    /** Randoop-generated regression test for java.lang.management.ManagementFactory.getMemoryMXBean(). */
    @Test
    public void getMemoryMXBean_test_8265() throws Throwable {
        java.lang.management.MemoryMXBean memoryMXBean0 = java.lang.management.ManagementFactory.getMemoryMXBean();
        java.lang.Class<?> wildcardClass1 = memoryMXBean0.getClass();
        org.junit.Assert.assertNotNull(memoryMXBean0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
