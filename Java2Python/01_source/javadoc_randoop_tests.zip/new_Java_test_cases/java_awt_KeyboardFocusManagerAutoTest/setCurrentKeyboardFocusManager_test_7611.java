package generated.test;

import org.junit.Test;

public class java_awt_KeyboardFocusManagerAutoTest {

    /** Randoop-generated regression test for java.awt.KeyboardFocusManager.setCurrentKeyboardFocusManager(). */
    @Test
    public void setCurrentKeyboardFocusManager_test_7611() throws Throwable {
        java.awt.KeyboardFocusManager keyboardFocusManager0 = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        java.awt.KeyboardFocusManager.setCurrentKeyboardFocusManager(keyboardFocusManager0);
        java.lang.Class<?> wildcardClass2 = keyboardFocusManager0.getClass();
        org.junit.Assert.assertNotNull(keyboardFocusManager0);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
