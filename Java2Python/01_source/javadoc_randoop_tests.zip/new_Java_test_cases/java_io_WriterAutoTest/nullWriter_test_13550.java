package generated.test;

import org.junit.Test;

public class java_io_WriterAutoTest {

    /** Randoop-generated regression test for java.io.Writer.nullWriter(). */
    @Test
    public void nullWriter_test_13550() throws Throwable {
        java.io.Writer writer0 = java.io.Writer.nullWriter();
        java.lang.Class<?> wildcardClass1 = writer0.getClass();
        org.junit.Assert.assertNotNull(writer0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
