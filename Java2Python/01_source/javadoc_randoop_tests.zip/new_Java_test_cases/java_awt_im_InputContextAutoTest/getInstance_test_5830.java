package generated.test;

import org.junit.Test;

public class java_awt_im_InputContextAutoTest {

    /** Randoop-generated regression test for java.awt.im.InputContext.getInstance(). */
    @Test
    public void getInstance_test_5830() throws Throwable {
        java.awt.im.InputContext inputContext0 = java.awt.im.InputContext.getInstance();
        java.lang.Class<?> wildcardClass1 = inputContext0.getClass();
        org.junit.Assert.assertNotNull(inputContext0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
