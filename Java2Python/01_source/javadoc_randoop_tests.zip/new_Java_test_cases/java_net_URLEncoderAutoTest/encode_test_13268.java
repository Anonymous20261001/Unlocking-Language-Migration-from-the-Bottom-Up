package generated.test;

import org.junit.Test;

public class java_net_URLEncoderAutoTest {

    /** Randoop-generated regression test for java.net.URLEncoder.encode(). */
    @Test
    public void encode_test_13268() throws Throwable {
        java.nio.charset.Charset charset1 = java.nio.charset.Charset.defaultCharset();
        java.util.Set<java.lang.String> strSet2 = charset1.aliases();
        java.lang.String str3 = java.net.URLEncoder.encode("hi%2521", charset1);
        java.util.Set<java.lang.String> strSet4 = charset1.aliases();
        org.junit.Assert.assertNotNull(charset1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "hi%252521" + "'", str3, "hi%252521");
        org.junit.Assert.assertNotNull(strSet4);
    }
}
