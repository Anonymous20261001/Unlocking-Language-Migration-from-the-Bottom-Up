package generated.test;

import org.junit.Test;

public class java_net_URLEncoderAutoTest {

    /** Randoop-generated regression test for java.net.URLEncoder.encode(). */
    @Test
    public void encode_test_13267() throws Throwable {
        java.lang.String str1 = java.net.URLEncoder.encode("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
