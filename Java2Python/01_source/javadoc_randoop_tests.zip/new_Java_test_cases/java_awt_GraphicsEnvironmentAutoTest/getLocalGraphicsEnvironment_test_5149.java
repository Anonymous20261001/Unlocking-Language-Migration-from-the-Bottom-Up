package generated.test;

import org.junit.Test;

public class java_awt_GraphicsEnvironmentAutoTest {

    /** Randoop-generated regression test for java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment(). */
    @Test
    public void getLocalGraphicsEnvironment_test_5149() throws Throwable {
        java.awt.GraphicsEnvironment graphicsEnvironment0 = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
        java.util.Locale locale1 = null;
        java.lang.String[] strArray2 = graphicsEnvironment0.getAvailableFontFamilyNames(locale1);
        java.lang.String[] strArray3 = graphicsEnvironment0.getAvailableFontFamilyNames();
        java.lang.String[] strArray4 = graphicsEnvironment0.getAvailableFontFamilyNames();
        org.junit.Assert.assertNotNull(graphicsEnvironment0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertArrayEquals(strArray2, new java.lang.String[] { "DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif" });
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertArrayEquals(strArray3, new java.lang.String[] { "DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif" });
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertArrayEquals(strArray4, new java.lang.String[] { "DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Dialog", "DialogInput", "Monospaced", "SansSerif", "Serif" });
    }
}
