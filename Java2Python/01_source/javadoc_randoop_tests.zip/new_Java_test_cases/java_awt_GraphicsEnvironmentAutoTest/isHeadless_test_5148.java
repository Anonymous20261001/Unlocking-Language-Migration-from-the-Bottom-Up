package generated.test;

import org.junit.Test;

public class java_awt_GraphicsEnvironmentAutoTest {

    /** Randoop-generated regression test for java.awt.GraphicsEnvironment.isHeadless(). */
    @Test
    public void isHeadless_test_5148() throws Throwable {
        boolean boolean0 = java.awt.GraphicsEnvironment.isHeadless();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }
}
