package generated.test;

import org.junit.Test;

public class java_lang_PackageAutoTest {

    /** Randoop-generated regression test for java.lang.Package.getPackages(). */
    @Test
    public void getPackages_test_9714() throws Throwable {
        java.lang.Package[] packageArray0 = java.lang.Package.getPackages();
        java.lang.Class<?> wildcardClass1 = packageArray0.getClass();
        org.junit.Assert.assertNotNull(packageArray0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
