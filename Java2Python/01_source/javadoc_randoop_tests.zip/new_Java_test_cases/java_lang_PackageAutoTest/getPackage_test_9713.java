package generated.test;

import org.junit.Test;

public class java_lang_PackageAutoTest {

    /** Randoop-generated regression test for java.lang.Package.getPackage(). */
    @Test
    public void getPackage_test_9713() throws Throwable {
        java.lang.Package package1 = java.lang.Package.getPackage("hi!");
        org.junit.Assert.assertNull(package1);
    }
}
