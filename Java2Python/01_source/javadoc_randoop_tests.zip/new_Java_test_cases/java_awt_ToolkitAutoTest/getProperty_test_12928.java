package generated.test;

import org.junit.Test;

public class java_awt_ToolkitAutoTest {

    /** Randoop-generated regression test for java.awt.Toolkit.getProperty(). */
    @Test
    public void getProperty_test_12928() throws Throwable {
        java.lang.String str2 = java.awt.Toolkit.getProperty("", "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }
}
