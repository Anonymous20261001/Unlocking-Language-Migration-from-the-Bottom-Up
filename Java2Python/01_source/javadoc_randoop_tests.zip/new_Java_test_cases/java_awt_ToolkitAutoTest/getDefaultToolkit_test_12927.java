package generated.test;

import org.junit.Test;

public class java_awt_ToolkitAutoTest {

    /** Randoop-generated regression test for java.awt.Toolkit.getDefaultToolkit(). */
    @Test
    public void getDefaultToolkit_test_12927() throws Throwable {
        java.awt.Toolkit toolkit0 = java.awt.Toolkit.getDefaultToolkit();
        java.lang.Class<?> wildcardClass1 = toolkit0.getClass();
        org.junit.Assert.assertNotNull(toolkit0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
