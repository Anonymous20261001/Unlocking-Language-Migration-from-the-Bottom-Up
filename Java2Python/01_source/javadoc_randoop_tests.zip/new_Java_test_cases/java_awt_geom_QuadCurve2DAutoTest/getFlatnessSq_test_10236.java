package generated.test;

import org.junit.Test;

public class java_awt_geom_QuadCurve2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.QuadCurve2D.getFlatnessSq(). */
    @Test
    public void getFlatnessSq_test_10236() throws Throwable {
        double[] doubleArray0 = new double[] {};
        // The following exception was thrown during execution in test generation
        try {
            double double2 = java.awt.geom.QuadCurve2D.getFlatnessSq(doubleArray0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 97 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertArrayEquals(doubleArray0, new double[] {}, 1.0E-15);
    }
}
