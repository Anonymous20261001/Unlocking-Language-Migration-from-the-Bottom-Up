package generated.test;

import org.junit.Test;

public class java_awt_geom_QuadCurve2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.QuadCurve2D.solveQuadratic(). */
    @Test
    public void solveQuadratic_test_10241() throws Throwable {
        double[] doubleArray3 = new double[] { 100.0f, (short) 0, 100.0d };
        int int4 = java.awt.geom.QuadCurve2D.solveQuadratic(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertArrayEquals(doubleArray3, new double[] { 100.0d, 0.0d, 100.0d }, 1.0E-15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }
}
