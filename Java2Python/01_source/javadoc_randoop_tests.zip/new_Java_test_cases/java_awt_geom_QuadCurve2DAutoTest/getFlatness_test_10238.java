package generated.test;

import org.junit.Test;

public class java_awt_geom_QuadCurve2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.QuadCurve2D.getFlatness(). */
    @Test
    public void getFlatness_test_10238() throws Throwable {
        double[] doubleArray1 = new double[] { 0.0d };
        // The following exception was thrown during execution in test generation
        try {
            double double3 = java.awt.geom.QuadCurve2D.getFlatness(doubleArray1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 10 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertArrayEquals(doubleArray1, new double[] { 0.0d }, 1.0E-15);
    }
}
