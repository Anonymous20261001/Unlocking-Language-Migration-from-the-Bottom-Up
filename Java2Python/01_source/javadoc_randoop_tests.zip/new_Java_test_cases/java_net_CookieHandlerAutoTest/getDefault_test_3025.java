package generated.test;

import org.junit.Test;

public class java_net_CookieHandlerAutoTest {

    /** Randoop-generated regression test for java.net.CookieHandler.getDefault(). */
    @Test
    public void getDefault_test_3025() throws Throwable {
        java.net.CookieHandler cookieHandler0 = java.net.CookieHandler.getDefault();
        org.junit.Assert.assertNull(cookieHandler0);
    }
}
