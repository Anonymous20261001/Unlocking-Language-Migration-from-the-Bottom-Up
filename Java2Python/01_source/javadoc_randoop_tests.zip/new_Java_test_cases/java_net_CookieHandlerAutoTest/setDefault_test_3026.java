package generated.test;

import org.junit.Test;

public class java_net_CookieHandlerAutoTest {

    /** Randoop-generated regression test for java.net.CookieHandler.setDefault(). */
    @Test
    public void setDefault_test_3026() throws Throwable {
        java.net.CookieHandler cookieHandler0 = null;
        java.net.CookieHandler.setDefault(cookieHandler0);
    }
}
