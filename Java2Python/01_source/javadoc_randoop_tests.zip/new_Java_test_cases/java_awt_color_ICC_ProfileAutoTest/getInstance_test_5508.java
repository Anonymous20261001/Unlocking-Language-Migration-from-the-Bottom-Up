package generated.test;

import org.junit.Test;

public class java_awt_color_ICC_ProfileAutoTest {

    /** Randoop-generated regression test for java.awt.color.ICC_Profile.getInstance(). */
    @Test
    public void getInstance_test_5508() throws Throwable {
        byte[] byteArray0 = new byte[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.awt.color.ICC_Profile iCC_Profile1 = java.awt.color.ICC_Profile.getInstance(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid ICC Profile Data");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertArrayEquals(byteArray0, new byte[] {});
    }
}
