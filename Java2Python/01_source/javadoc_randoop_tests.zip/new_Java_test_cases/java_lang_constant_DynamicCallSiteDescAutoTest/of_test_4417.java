package generated.test;

import org.junit.Test;

public class java_lang_constant_DynamicCallSiteDescAutoTest {

    /** Randoop-generated regression test for java.lang.constant.DynamicCallSiteDesc.of(). */
    @Test
    public void of_test_4417() throws Throwable {
        java.lang.constant.DirectMethodHandleDesc directMethodHandleDesc0 = null;
        java.lang.constant.MethodTypeDesc methodTypeDesc2 = null;
        java.lang.constant.ConstantDesc[] constantDescArray3 = new java.lang.constant.ConstantDesc[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.constant.DynamicCallSiteDesc dynamicCallSiteDesc4 = java.lang.constant.DynamicCallSiteDesc.of(directMethodHandleDesc0, "hi!", methodTypeDesc2, constantDescArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(constantDescArray3);
        org.junit.Assert.assertArrayEquals(constantDescArray3, new java.lang.constant.ConstantDesc[] {});
    }
}
