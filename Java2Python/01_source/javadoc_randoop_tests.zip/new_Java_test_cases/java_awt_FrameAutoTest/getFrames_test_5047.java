package generated.test;

import org.junit.Test;

public class java_awt_FrameAutoTest {

    /** Randoop-generated regression test for java.awt.Frame.getFrames(). */
    @Test
    public void getFrames_test_5047() throws Throwable {
        java.awt.Frame[] frameArray0 = java.awt.Frame.getFrames();
        java.lang.Class<?> wildcardClass1 = frameArray0.getClass();
        org.junit.Assert.assertNotNull(frameArray0);
        org.junit.Assert.assertArrayEquals(frameArray0, new java.awt.Frame[] {});
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
