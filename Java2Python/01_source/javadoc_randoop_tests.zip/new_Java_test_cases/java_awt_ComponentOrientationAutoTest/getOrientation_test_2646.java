package generated.test;

import org.junit.Test;

public class java_awt_ComponentOrientationAutoTest {

    /** Randoop-generated regression test for java.awt.ComponentOrientation.getOrientation(). */
    @Test
    public void getOrientation_test_2646() throws Throwable {
        java.util.Locale locale0 = java.util.Locale.TAIWAN;
        java.util.Locale locale1 = java.util.Locale.ITALIAN;
        java.lang.String str2 = locale0.getDisplayName(locale1);
        java.lang.String str3 = locale1.getDisplayScript();
        java.awt.ComponentOrientation componentOrientation4 = java.awt.ComponentOrientation.getOrientation(locale1);
        org.junit.Assert.assertNotNull(locale0);
        org.junit.Assert.assertEquals(locale0.toString(), "zh_TW");
        org.junit.Assert.assertNotNull(locale1);
        org.junit.Assert.assertEquals(locale1.toString(), "it");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "cinese (Taiwan)" + "'", str2, "cinese (Taiwan)");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(componentOrientation4);
    }
}
