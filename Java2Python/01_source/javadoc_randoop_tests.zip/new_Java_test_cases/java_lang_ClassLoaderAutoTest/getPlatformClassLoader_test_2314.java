package generated.test;

import org.junit.Test;

public class java_lang_ClassLoaderAutoTest {

    /** Randoop-generated regression test for java.lang.ClassLoader.getPlatformClassLoader(). */
    @Test
    public void getPlatformClassLoader_test_2314() throws Throwable {
        java.lang.ClassLoader classLoader0 = java.lang.ClassLoader.getPlatformClassLoader();
        java.lang.Class<?> wildcardClass1 = classLoader0.getClass();
        org.junit.Assert.assertNotNull(classLoader0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
