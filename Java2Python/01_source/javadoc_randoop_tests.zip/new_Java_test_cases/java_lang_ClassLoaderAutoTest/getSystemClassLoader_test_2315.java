package generated.test;

import org.junit.Test;

public class java_lang_ClassLoaderAutoTest {

    /** Randoop-generated regression test for java.lang.ClassLoader.getSystemClassLoader(). */
    @Test
    public void getSystemClassLoader_test_2315() throws Throwable {
        java.lang.ClassLoader classLoader0 = java.lang.ClassLoader.getSystemClassLoader();
        java.lang.ClassLoader classLoader1 = classLoader0.getParent();
        java.lang.Class<?> wildcardClass2 = classLoader0.getClass();
        org.junit.Assert.assertNotNull(classLoader0);
        org.junit.Assert.assertNotNull(classLoader1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
