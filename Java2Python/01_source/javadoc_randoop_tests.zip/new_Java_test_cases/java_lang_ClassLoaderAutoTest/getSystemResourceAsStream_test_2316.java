package generated.test;

import org.junit.Test;

public class java_lang_ClassLoaderAutoTest {

    /** Randoop-generated regression test for java.lang.ClassLoader.getSystemResourceAsStream(). */
    @Test
    public void getSystemResourceAsStream_test_2316() throws Throwable {
        java.io.InputStream inputStream1 = java.lang.ClassLoader.getSystemResourceAsStream("hi!");
        org.junit.Assert.assertNull(inputStream1);
    }
}
