package generated.test;

import org.junit.Test;

public class java_lang_ClassLoaderAutoTest {

    /** Randoop-generated regression test for java.lang.ClassLoader.getSystemResource(). */
    @Test
    public void getSystemResource_test_2317() throws Throwable {
        java.net.URL uRL1 = java.lang.ClassLoader.getSystemResource("hi!");
        org.junit.Assert.assertNull(uRL1);
    }
}
