package generated.test;

import org.junit.Test;

public class java_lang_ShortAutoTest {

    /** Randoop-generated regression test for java.lang.Short.decode(). */
    @Test
    public void decode_test_11092() throws Throwable {
        java.lang.Short short1 = java.lang.Short.decode("0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }
}
