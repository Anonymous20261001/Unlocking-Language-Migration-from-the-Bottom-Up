package generated.test;

import org.junit.Test;

public class java_lang_ShortAutoTest {

    /** Randoop-generated regression test for java.lang.Short.parseShort(). */
    @Test
    public void parseShort_test_11096() throws Throwable {
        short short1 = java.lang.Short.parseShort("0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }
}
