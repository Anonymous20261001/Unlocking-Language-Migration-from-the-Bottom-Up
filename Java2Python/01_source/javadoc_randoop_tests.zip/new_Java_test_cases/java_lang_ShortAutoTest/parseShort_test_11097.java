package generated.test;

import org.junit.Test;

public class java_lang_ShortAutoTest {

    /** Randoop-generated regression test for java.lang.Short.parseShort(). */
    @Test
    public void parseShort_test_11097() throws Throwable {
        short short2 = java.lang.Short.parseShort("100", 16);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 256 + "'", short2 == (short) 256);
    }
}
