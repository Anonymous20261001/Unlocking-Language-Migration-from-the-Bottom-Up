package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isAbstract(). */
    @Test
    public void isAbstract_test_8979() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isAbstract(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
