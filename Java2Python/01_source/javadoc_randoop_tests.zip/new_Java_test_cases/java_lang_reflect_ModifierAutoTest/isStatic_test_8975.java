package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isStatic(). */
    @Test
    public void isStatic_test_8975() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isStatic(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
