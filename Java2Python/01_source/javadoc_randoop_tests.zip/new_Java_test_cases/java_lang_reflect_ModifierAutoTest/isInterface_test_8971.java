package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isInterface(). */
    @Test
    public void isInterface_test_8971() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isInterface(512);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
