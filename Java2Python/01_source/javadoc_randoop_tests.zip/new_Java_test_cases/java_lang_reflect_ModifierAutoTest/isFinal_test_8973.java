package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isFinal(). */
    @Test
    public void isFinal_test_8973() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isFinal(16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
