package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.interfaceModifiers(). */
    @Test
    public void interfaceModifiers_test_8986() throws Throwable {
        int int0 = java.lang.reflect.Modifier.interfaceModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3087 + "'", int0 == 3087);
    }
}
