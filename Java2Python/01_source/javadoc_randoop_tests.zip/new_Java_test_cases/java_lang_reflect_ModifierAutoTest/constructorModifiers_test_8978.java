package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.constructorModifiers(). */
    @Test
    public void constructorModifiers_test_8978() throws Throwable {
        int int0 = java.lang.reflect.Modifier.constructorModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }
}
