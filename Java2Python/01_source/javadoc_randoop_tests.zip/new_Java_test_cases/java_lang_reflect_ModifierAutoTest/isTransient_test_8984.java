package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isTransient(). */
    @Test
    public void isTransient_test_8984() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isTransient(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
