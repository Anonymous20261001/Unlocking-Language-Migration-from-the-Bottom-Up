package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isProtected(). */
    @Test
    public void isProtected_test_8976() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isProtected(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
