package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isPrivate(). */
    @Test
    public void isPrivate_test_8981() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isPrivate(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
