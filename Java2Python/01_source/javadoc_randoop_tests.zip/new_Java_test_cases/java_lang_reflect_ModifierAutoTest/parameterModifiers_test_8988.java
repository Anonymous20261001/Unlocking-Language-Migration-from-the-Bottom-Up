package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.parameterModifiers(). */
    @Test
    public void parameterModifiers_test_8988() throws Throwable {
        int int0 = java.lang.reflect.Modifier.parameterModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }
}
