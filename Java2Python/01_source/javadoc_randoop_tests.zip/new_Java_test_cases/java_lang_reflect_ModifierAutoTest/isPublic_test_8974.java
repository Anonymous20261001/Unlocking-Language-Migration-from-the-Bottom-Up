package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isPublic(). */
    @Test
    public void isPublic_test_8974() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isPublic(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
