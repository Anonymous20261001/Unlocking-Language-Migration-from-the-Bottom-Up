package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.methodModifiers(). */
    @Test
    public void methodModifiers_test_8977() throws Throwable {
        int int0 = java.lang.reflect.Modifier.methodModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3391 + "'", int0 == 3391);
    }
}
