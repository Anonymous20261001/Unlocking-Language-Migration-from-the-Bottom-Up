package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.classModifiers(). */
    @Test
    public void classModifiers_test_8972() throws Throwable {
        int int0 = java.lang.reflect.Modifier.classModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3103 + "'", int0 == 3103);
    }
}
