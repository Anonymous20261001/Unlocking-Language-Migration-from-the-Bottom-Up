package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isVolatile(). */
    @Test
    public void isVolatile_test_8980() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isVolatile(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
