package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.fieldModifiers(). */
    @Test
    public void fieldModifiers_test_8987() throws Throwable {
        int int0 = java.lang.reflect.Modifier.fieldModifiers();
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 223 + "'", int0 == 223);
    }
}
