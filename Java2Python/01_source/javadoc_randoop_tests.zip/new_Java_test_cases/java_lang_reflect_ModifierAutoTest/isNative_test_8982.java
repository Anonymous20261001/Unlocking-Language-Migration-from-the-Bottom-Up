package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isNative(). */
    @Test
    public void isNative_test_8982() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isNative(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
