package generated.test;

import org.junit.Test;

public class java_lang_reflect_ModifierAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.Modifier.isStrict(). */
    @Test
    public void isStrict_test_8985() throws Throwable {
        boolean boolean1 = java.lang.reflect.Modifier.isStrict(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}
