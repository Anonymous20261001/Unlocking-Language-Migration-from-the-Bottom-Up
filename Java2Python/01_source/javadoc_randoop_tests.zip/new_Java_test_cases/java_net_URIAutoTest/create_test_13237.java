package generated.test;

import org.junit.Test;

public class java_net_URIAutoTest {

    /** Randoop-generated regression test for java.net.URI.create(). */
    @Test
    public void create_test_13237() throws Throwable {
        java.net.URI uRI1 = java.net.URI.create("hi!");
        java.lang.Class<?> wildcardClass2 = uRI1.getClass();
        org.junit.Assert.assertNotNull(uRI1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
