package generated.test;

import org.junit.Test;

public class java_lang_module_ConfigurationAutoTest {

    /** Randoop-generated regression test for java.lang.module.Configuration.empty(). */
    @Test
    public void empty_test_2903() throws Throwable {
        java.lang.module.Configuration configuration0 = java.lang.module.Configuration.empty();
        java.lang.String str1 = configuration0.toString();
        java.lang.String str2 = configuration0.toString();
        java.lang.String str3 = configuration0.toString();
        java.lang.Class<?> wildcardClass4 = configuration0.getClass();
        org.junit.Assert.assertNotNull(configuration0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
