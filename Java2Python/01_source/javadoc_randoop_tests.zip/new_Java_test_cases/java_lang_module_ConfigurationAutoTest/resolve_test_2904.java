package generated.test;

import org.junit.Test;

public class java_lang_module_ConfigurationAutoTest {

    /** Randoop-generated regression test for java.lang.module.Configuration.resolve(). */
    @Test
    public void resolve_test_2904() throws Throwable {
        java.lang.module.ModuleFinder moduleFinder0 = null;
        java.util.List<java.lang.module.Configuration> configurationList1 = null;
        java.lang.module.ModuleFinder moduleFinder2 = null;
        java.util.Collection<java.lang.String> strCollection3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.module.Configuration configuration4 = java.lang.module.Configuration.resolve(moduleFinder0, configurationList1, moduleFinder2, strCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
