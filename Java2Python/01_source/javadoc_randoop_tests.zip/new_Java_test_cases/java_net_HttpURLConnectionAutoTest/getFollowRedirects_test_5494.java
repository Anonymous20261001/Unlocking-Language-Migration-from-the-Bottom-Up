package generated.test;

import org.junit.Test;

public class java_net_HttpURLConnectionAutoTest {

    /** Randoop-generated regression test for java.net.HttpURLConnection.getFollowRedirects(). */
    @Test
    public void getFollowRedirects_test_5494() throws Throwable {
        boolean boolean0 = java.net.HttpURLConnection.getFollowRedirects();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }
}
