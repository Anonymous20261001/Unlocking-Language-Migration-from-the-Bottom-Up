package generated.test;

import org.junit.Test;

public class java_net_HttpURLConnectionAutoTest {

    /** Randoop-generated regression test for java.net.HttpURLConnection.setFollowRedirects(). */
    @Test
    public void setFollowRedirects_test_5493() throws Throwable {
        java.net.HttpURLConnection.setFollowRedirects(true);
    }
}
