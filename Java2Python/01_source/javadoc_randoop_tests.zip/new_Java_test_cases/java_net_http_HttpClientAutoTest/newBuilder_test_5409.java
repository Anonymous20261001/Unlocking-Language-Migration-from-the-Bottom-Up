package generated.test;

import org.junit.Test;

public class java_net_http_HttpClientAutoTest {

    /** Randoop-generated regression test for java.net.http.HttpClient.newBuilder(). */
    @Test
    public void newBuilder_test_5409() throws Throwable {
        java.net.http.HttpClient.Builder builder0 = java.net.http.HttpClient.newBuilder();
        java.net.http.HttpClient httpClient1 = builder0.build();
        java.net.http.HttpClient httpClient2 = builder0.build();
        java.net.http.HttpClient httpClient3 = builder0.build();
        java.net.http.HttpClient httpClient4 = builder0.build();
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(httpClient1);
        org.junit.Assert.assertNotNull(httpClient2);
        org.junit.Assert.assertNotNull(httpClient3);
        org.junit.Assert.assertNotNull(httpClient4);
    }
}
