package generated.test;

import org.junit.Test;

public class java_net_http_HttpClientAutoTest {

    /** Randoop-generated regression test for java.net.http.HttpClient.newHttpClient(). */
    @Test
    public void newHttpClient_test_5410() throws Throwable {
        java.net.http.HttpClient httpClient0 = java.net.http.HttpClient.newHttpClient();
        java.util.Optional<java.net.ProxySelector> proxySelectorOptional1 = httpClient0.proxy();
        java.util.Optional<java.net.ProxySelector> proxySelectorOptional2 = httpClient0.proxy();
        java.lang.Class<?> wildcardClass3 = proxySelectorOptional2.getClass();
        org.junit.Assert.assertNotNull(httpClient0);
        org.junit.Assert.assertNotNull(proxySelectorOptional1);
        org.junit.Assert.assertNotNull(proxySelectorOptional2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
