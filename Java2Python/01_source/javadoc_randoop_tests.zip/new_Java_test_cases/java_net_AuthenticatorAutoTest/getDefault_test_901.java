package generated.test;

import org.junit.Test;

public class java_net_AuthenticatorAutoTest {

    /** Randoop-generated regression test for java.net.Authenticator.getDefault(). */
    @Test
    public void getDefault_test_901() throws Throwable {
        java.net.Authenticator authenticator0 = java.net.Authenticator.getDefault();
        org.junit.Assert.assertNull(authenticator0);
    }
}
