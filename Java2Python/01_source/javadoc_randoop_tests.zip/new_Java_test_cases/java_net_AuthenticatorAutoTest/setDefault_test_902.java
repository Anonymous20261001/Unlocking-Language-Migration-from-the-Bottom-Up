package generated.test;

import org.junit.Test;

public class java_net_AuthenticatorAutoTest {

    /** Randoop-generated regression test for java.net.Authenticator.setDefault(). */
    @Test
    public void setDefault_test_902() throws Throwable {
        java.net.Authenticator authenticator0 = null;
        java.net.Authenticator.setDefault(authenticator0);
    }
}
