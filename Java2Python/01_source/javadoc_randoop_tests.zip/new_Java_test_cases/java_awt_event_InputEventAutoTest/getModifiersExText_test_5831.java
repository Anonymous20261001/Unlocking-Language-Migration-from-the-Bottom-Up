package generated.test;

import org.junit.Test;

public class java_awt_event_InputEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.InputEvent.getModifiersExText(). */
    @Test
    public void getModifiersExText_test_5831() throws Throwable {
        java.lang.String str1 = java.awt.event.InputEvent.getModifiersExText(0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
