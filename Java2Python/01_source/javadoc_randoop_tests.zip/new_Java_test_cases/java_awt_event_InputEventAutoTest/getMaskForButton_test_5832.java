package generated.test;

import org.junit.Test;

public class java_awt_event_InputEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.InputEvent.getMaskForButton(). */
    @Test
    public void getMaskForButton_test_5832() throws Throwable {
        int int1 = java.awt.event.InputEvent.getMaskForButton(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }
}
