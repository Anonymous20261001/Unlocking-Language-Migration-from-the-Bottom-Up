package generated.test;

import org.junit.Test;

public class java_awt_SystemTrayAutoTest {

    /** Randoop-generated regression test for java.awt.SystemTray.getSystemTray(). */
    @Test
    public void getSystemTray_test_12443() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.SystemTray systemTray0 = java.awt.SystemTray.getSystemTray();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
