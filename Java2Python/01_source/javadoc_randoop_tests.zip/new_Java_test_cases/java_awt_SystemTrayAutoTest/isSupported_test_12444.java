package generated.test;

import org.junit.Test;

public class java_awt_SystemTrayAutoTest {

    /** Randoop-generated regression test for java.awt.SystemTray.isSupported(). */
    @Test
    public void isSupported_test_12444() throws Throwable {
        boolean boolean0 = java.awt.SystemTray.isSupported();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }
}
