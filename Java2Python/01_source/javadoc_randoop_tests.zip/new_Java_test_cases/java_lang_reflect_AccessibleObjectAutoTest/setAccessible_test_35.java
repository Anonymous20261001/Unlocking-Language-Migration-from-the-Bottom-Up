package generated.test;

import org.junit.Test;

public class java_lang_reflect_AccessibleObjectAutoTest {

    /** Randoop-generated regression test for java.lang.reflect.AccessibleObject.setAccessible(). */
    @Test
    public void setAccessible_test_35() throws Throwable {
        java.lang.reflect.AccessibleObject[] accessibleObjectArray0 = new java.lang.reflect.AccessibleObject[] {};
        java.lang.reflect.AccessibleObject.setAccessible(accessibleObjectArray0, true);
        java.lang.Class<?> wildcardClass3 = accessibleObjectArray0.getClass();
        org.junit.Assert.assertNotNull(accessibleObjectArray0);
        org.junit.Assert.assertArrayEquals(accessibleObjectArray0, new java.lang.reflect.AccessibleObject[] {});
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
