package generated.test;

import org.junit.Test;

public class java_awt_font_NumericShaperAutoTest {

    /** Randoop-generated regression test for java.awt.font.NumericShaper.getContextualShaper(). */
    @Test
    public void getContextualShaper_test_9584() throws Throwable {
        java.awt.font.NumericShaper numericShaper2 = java.awt.font.NumericShaper.getContextualShaper(16, 4096);
        java.lang.Class<?> wildcardClass3 = numericShaper2.getClass();
        org.junit.Assert.assertNotNull(numericShaper2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}
