package generated.test;

import org.junit.Test;

public class java_awt_font_NumericShaperAutoTest {

    /** Randoop-generated regression test for java.awt.font.NumericShaper.getShaper(). */
    @Test
    public void getShaper_test_9579() throws Throwable {
        java.awt.font.NumericShaper numericShaper1 = java.awt.font.NumericShaper.getShaper(1);
        java.awt.font.NumericShaper.Range range2 = java.awt.font.NumericShaper.Range.KHMER;
        boolean boolean3 = numericShaper1.equals((java.lang.Object) range2);
        java.lang.Class<?> wildcardClass4 = range2.getClass();
        org.junit.Assert.assertNotNull(numericShaper1);
        org.junit.Assert.assertTrue("'" + range2 + "' != '" + java.awt.font.NumericShaper.Range.KHMER + "'", range2.equals(java.awt.font.NumericShaper.Range.KHMER));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
