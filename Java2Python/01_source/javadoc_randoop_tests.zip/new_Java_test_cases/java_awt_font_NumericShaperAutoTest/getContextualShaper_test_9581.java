package generated.test;

import org.junit.Test;

public class java_awt_font_NumericShaperAutoTest {

    /** Randoop-generated regression test for java.awt.font.NumericShaper.getContextualShaper(). */
    @Test
    public void getContextualShaper_test_9581() throws Throwable {
        java.awt.font.NumericShaper numericShaper1 = java.awt.font.NumericShaper.getContextualShaper(512);
        java.lang.Class<?> wildcardClass2 = numericShaper1.getClass();
        org.junit.Assert.assertNotNull(numericShaper1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
