package generated.test;

import org.junit.Test;

public class java_net_IDNAutoTest {

    /** Randoop-generated regression test for java.net.IDN.toASCII(). */
    @Test
    public void toASCII_test_5533() throws Throwable {
        java.lang.String str2 = java.net.IDN.toASCII("", 1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }
}
