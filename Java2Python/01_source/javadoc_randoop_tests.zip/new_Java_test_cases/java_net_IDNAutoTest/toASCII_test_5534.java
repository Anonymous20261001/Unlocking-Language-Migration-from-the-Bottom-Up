package generated.test;

import org.junit.Test;

public class java_net_IDNAutoTest {

    /** Randoop-generated regression test for java.net.IDN.toASCII(). */
    @Test
    public void toASCII_test_5534() throws Throwable {
        java.lang.String str1 = java.net.IDN.toASCII("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
