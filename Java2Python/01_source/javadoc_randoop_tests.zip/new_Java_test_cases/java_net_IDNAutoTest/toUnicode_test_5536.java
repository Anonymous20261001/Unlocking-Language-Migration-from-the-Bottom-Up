package generated.test;

import org.junit.Test;

public class java_net_IDNAutoTest {

    /** Randoop-generated regression test for java.net.IDN.toUnicode(). */
    @Test
    public void toUnicode_test_5536() throws Throwable {
        java.lang.String str2 = java.net.IDN.toUnicode("", 0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
    }
}
