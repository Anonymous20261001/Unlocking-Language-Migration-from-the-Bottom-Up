package generated.test;

import org.junit.Test;

public class java_net_IDNAutoTest {

    /** Randoop-generated regression test for java.net.IDN.toUnicode(). */
    @Test
    public void toUnicode_test_5535() throws Throwable {
        java.lang.String str1 = java.net.IDN.toUnicode("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
