package generated.test;

import org.junit.Test;

public class java_awt_geom_Point2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Point2D.distance(). */
    @Test
    public void distance_test_9957() throws Throwable {
        double double4 = java.awt.geom.Point2D.distance((double) 'a', (double) (short) 1, (double) 10, 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 87.0d + "'", double4 == 87.0d);
    }
}
