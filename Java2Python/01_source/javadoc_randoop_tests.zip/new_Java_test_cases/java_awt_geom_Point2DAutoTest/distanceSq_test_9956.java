package generated.test;

import org.junit.Test;

public class java_awt_geom_Point2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Point2D.distanceSq(). */
    @Test
    public void distanceSq_test_9956() throws Throwable {
        double double4 = java.awt.geom.Point2D.distanceSq(1.0d, 1.0d, (double) 0.0f, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9802.0d + "'", double4 == 9802.0d);
    }
}
