package generated.test;

import org.junit.Test;

public class java_net_UnixDomainSocketAddressAutoTest {

    /** Randoop-generated regression test for java.net.UnixDomainSocketAddress.of(). */
    @Test
    public void of_test_13211() throws Throwable {
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.nio.file.Path path2 = java.nio.file.Path.of("", strArray1);
        int int3 = path2.getNameCount();
        java.net.UnixDomainSocketAddress unixDomainSocketAddress4 = java.net.UnixDomainSocketAddress.of(path2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertArrayEquals(strArray1, new java.lang.String[] {});
        org.junit.Assert.assertNotNull(path2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(unixDomainSocketAddress4);
    }
}
