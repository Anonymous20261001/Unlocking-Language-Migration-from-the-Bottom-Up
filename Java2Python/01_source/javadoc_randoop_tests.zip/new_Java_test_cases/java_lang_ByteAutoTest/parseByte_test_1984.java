package generated.test;

import org.junit.Test;

public class java_lang_ByteAutoTest {

    /** Randoop-generated regression test for java.lang.Byte.parseByte(). */
    @Test
    public void parseByte_test_1984() throws Throwable {
        byte byte2 = java.lang.Byte.parseByte("81", 9);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 73 + "'", byte2 == (byte) 73);
    }
}
