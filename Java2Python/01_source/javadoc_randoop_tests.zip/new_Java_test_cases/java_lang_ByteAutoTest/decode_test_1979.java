package generated.test;

import org.junit.Test;

public class java_lang_ByteAutoTest {

    /** Randoop-generated regression test for java.lang.Byte.decode(). */
    @Test
    public void decode_test_1979() throws Throwable {
        java.lang.Byte byte1 = java.lang.Byte.decode("0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }
}
