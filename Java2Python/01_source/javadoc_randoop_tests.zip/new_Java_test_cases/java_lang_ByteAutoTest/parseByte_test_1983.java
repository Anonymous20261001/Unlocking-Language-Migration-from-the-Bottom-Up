package generated.test;

import org.junit.Test;

public class java_lang_ByteAutoTest {

    /** Randoop-generated regression test for java.lang.Byte.parseByte(). */
    @Test
    public void parseByte_test_1983() throws Throwable {
        byte byte1 = java.lang.Byte.parseByte("0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }
}
