package generated.test;

import org.junit.Test;

public class java_awt_SplashScreenAutoTest {

    /** Randoop-generated regression test for java.awt.SplashScreen.getSplashScreen(). */
    @Test
    public void getSplashScreen_test_11313() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.SplashScreen splashScreen0 = java.awt.SplashScreen.getSplashScreen();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
