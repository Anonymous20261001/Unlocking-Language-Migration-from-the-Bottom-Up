package generated.test;

import org.junit.Test;

public class java_awt_TaskbarAutoTest {

    /** Randoop-generated regression test for java.awt.Taskbar.isTaskbarSupported(). */
    @Test
    public void isTaskbarSupported_test_12519() throws Throwable {
        boolean boolean0 = java.awt.Taskbar.isTaskbarSupported();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }
}
