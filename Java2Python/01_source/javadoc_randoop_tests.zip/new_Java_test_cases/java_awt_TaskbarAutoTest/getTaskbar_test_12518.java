package generated.test;

import org.junit.Test;

public class java_awt_TaskbarAutoTest {

    /** Randoop-generated regression test for java.awt.Taskbar.getTaskbar(). */
    @Test
    public void getTaskbar_test_12518() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.awt.Taskbar taskbar0 = java.awt.Taskbar.getTaskbar();
            org.junit.Assert.fail("Expected exception of type java.awt.HeadlessException; message: null");
        } catch (java.awt.HeadlessException e) {
            // Expected exception.
        }
    }
}
