package generated.test;

import org.junit.Test;

public class java_lang_ref_CleanerAutoTest {

    /** Randoop-generated regression test for java.lang.ref.Cleaner.create(). */
    @Test
    public void create_test_2320() throws Throwable {
        java.util.concurrent.ThreadFactory threadFactory0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.ref.Cleaner cleaner1 = java.lang.ref.Cleaner.create(threadFactory0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: threadFactory");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
