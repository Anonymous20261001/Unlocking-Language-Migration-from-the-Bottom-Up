package generated.test;

import org.junit.Test;

public class java_lang_ref_CleanerAutoTest {

    /** Randoop-generated regression test for java.lang.ref.Cleaner.create(). */
    @Test
    public void create_test_2319() throws Throwable {
        java.lang.ref.Cleaner cleaner0 = java.lang.ref.Cleaner.create();
        java.lang.Object obj1 = new java.lang.Object();
        java.lang.Class<?> wildcardClass2 = obj1.getClass();
        java.lang.Runnable runnable3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.ref.Cleaner.Cleanable cleanable4 = cleaner0.register(obj1, runnable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: action");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(cleaner0);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
