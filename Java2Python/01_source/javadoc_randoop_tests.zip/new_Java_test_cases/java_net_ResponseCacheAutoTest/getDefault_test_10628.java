package generated.test;

import org.junit.Test;

public class java_net_ResponseCacheAutoTest {

    /** Randoop-generated regression test for java.net.ResponseCache.getDefault(). */
    @Test
    public void getDefault_test_10628() throws Throwable {
        java.net.ResponseCache responseCache0 = java.net.ResponseCache.getDefault();
        org.junit.Assert.assertNull(responseCache0);
    }
}
