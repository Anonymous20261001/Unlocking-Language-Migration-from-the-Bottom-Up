package generated.test;

import org.junit.Test;

public class java_net_ResponseCacheAutoTest {

    /** Randoop-generated regression test for java.net.ResponseCache.setDefault(). */
    @Test
    public void setDefault_test_10629() throws Throwable {
        java.net.ResponseCache responseCache0 = null;
        java.net.ResponseCache.setDefault(responseCache0);
    }
}
