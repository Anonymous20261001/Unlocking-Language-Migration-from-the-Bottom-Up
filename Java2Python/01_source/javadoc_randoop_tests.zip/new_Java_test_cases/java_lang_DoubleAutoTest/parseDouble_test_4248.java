package generated.test;

import org.junit.Test;

public class java_lang_DoubleAutoTest {

    /** Randoop-generated regression test for java.lang.Double.parseDouble(). */
    @Test
    public void parseDouble_test_4248() throws Throwable {
        double double1 = java.lang.Double.parseDouble("0.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}
