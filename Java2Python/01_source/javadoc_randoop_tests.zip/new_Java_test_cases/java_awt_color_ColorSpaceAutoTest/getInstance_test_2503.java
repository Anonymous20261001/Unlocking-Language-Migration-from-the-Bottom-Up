package generated.test;

import org.junit.Test;

public class java_awt_color_ColorSpaceAutoTest {

    /** Randoop-generated regression test for java.awt.color.ColorSpace.getInstance(). */
    @Test
    public void getInstance_test_2503() throws Throwable {
        java.awt.color.ColorSpace colorSpace1 = java.awt.color.ColorSpace.getInstance(1002);
        java.lang.Class<?> wildcardClass2 = colorSpace1.getClass();
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
