package generated.test;

import org.junit.Test;

public class java_awt_geom_CubicCurve2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.CubicCurve2D.solveCubic(). */
    @Test
    public void solveCubic_test_3132() throws Throwable {
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (short) 100 };
        // The following exception was thrown during execution in test generation
        try {
            int int3 = java.awt.geom.CubicCurve2D.solveCubic(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot load from double array because \"eqn\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertArrayEquals(doubleArray2, new double[] { 100.0d }, 1.0E-15);
    }
}
