package generated.test;

import org.junit.Test;

public class java_awt_geom_CubicCurve2DAutoTest {

    /** Randoop-generated regression test for java.awt.geom.CubicCurve2D.solveCubic(). */
    @Test
    public void solveCubic_test_3133() throws Throwable {
        double[] doubleArray0 = new double[] {};
        // The following exception was thrown during execution in test generation
        try {
            int int1 = java.awt.geom.CubicCurve2D.solveCubic(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 3 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertArrayEquals(doubleArray0, new double[] {}, 1.0E-15);
    }
}
