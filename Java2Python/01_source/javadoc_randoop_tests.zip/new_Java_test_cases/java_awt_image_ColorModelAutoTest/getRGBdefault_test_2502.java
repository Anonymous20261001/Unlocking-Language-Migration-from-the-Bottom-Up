package generated.test;

import org.junit.Test;

public class java_awt_image_ColorModelAutoTest {

    /** Randoop-generated regression test for java.awt.image.ColorModel.getRGBdefault(). */
    @Test
    public void getRGBdefault_test_2502() throws Throwable {
        java.awt.image.ColorModel colorModel0 = java.awt.image.ColorModel.getRGBdefault();
        java.lang.Class<?> wildcardClass1 = colorModel0.getClass();
        org.junit.Assert.assertNotNull(colorModel0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
