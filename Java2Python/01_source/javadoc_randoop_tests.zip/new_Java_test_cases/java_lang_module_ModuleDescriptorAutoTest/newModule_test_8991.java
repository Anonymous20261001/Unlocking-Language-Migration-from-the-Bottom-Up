package generated.test;

import org.junit.Test;

public class java_lang_module_ModuleDescriptorAutoTest {

    /** Randoop-generated regression test for java.lang.module.ModuleDescriptor.newModule(). */
    @Test
    public void newModule_test_8991() throws Throwable {
        java.lang.module.ModuleDescriptor.Modifier[] modifierArray1 = new java.lang.module.ModuleDescriptor.Modifier[] {};
        java.util.LinkedHashSet<java.lang.module.ModuleDescriptor.Modifier> modifierSet2 = new java.util.LinkedHashSet<java.lang.module.ModuleDescriptor.Modifier>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<java.lang.module.ModuleDescriptor.Modifier>) modifierSet2, modifierArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.module.ModuleDescriptor.Builder builder4 = java.lang.module.ModuleDescriptor.newModule("", (java.util.Set<java.lang.module.ModuleDescriptor.Modifier>) modifierSet2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: : Invalid module name: '' is not a Java identifier");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(modifierArray1);
        org.junit.Assert.assertArrayEquals(modifierArray1, new java.lang.module.ModuleDescriptor.Modifier[] {});
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
