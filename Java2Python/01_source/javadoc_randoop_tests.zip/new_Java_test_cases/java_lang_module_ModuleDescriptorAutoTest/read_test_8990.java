package generated.test;

import org.junit.Test;

public class java_lang_module_ModuleDescriptorAutoTest {

    /** Randoop-generated regression test for java.lang.module.ModuleDescriptor.read(). */
    @Test
    public void read_test_8990() throws Throwable {
        java.nio.ByteBuffer byteBuffer1 = java.nio.ByteBuffer.allocateDirect((int) (byte) 100);
        float float2 = byteBuffer1.getFloat();
        int int3 = byteBuffer1.position();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.module.ModuleDescriptor moduleDescriptor4 = java.lang.module.ModuleDescriptor.read(byteBuffer1);
            org.junit.Assert.fail("Expected exception of type java.lang.module.InvalidModuleDescriptorException; message: Bad magic number");
        } catch (java.lang.module.InvalidModuleDescriptorException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteBuffer1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }
}
