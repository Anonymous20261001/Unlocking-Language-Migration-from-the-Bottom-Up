package generated.test;

import org.junit.Test;

public class java_lang_module_ModuleDescriptorAutoTest {

    /** Randoop-generated regression test for java.lang.module.ModuleDescriptor.read(). */
    @Test
    public void read_test_8989() throws Throwable {
        java.nio.ByteBuffer byteBuffer1 = java.nio.ByteBuffer.allocate((int) (short) 10);
        java.nio.ByteBuffer byteBuffer2 = byteBuffer1.duplicate();
        java.util.function.Supplier<java.util.Set<java.lang.String>> strSetSupplier3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.module.ModuleDescriptor moduleDescriptor4 = java.lang.module.ModuleDescriptor.read(byteBuffer2, strSetSupplier3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(byteBuffer1);
        org.junit.Assert.assertNotNull(byteBuffer2);
    }
}
