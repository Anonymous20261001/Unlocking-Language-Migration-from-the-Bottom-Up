package generated.test;

import org.junit.Test;

public class java_lang_module_ModuleDescriptorAutoTest {

    /** Randoop-generated regression test for java.lang.module.ModuleDescriptor.newAutomaticModule(). */
    @Test
    public void newAutomaticModule_test_8994() throws Throwable {
        // The following exception was thrown during execution in test generation
        try {
            java.lang.module.ModuleDescriptor.Builder builder1 = java.lang.module.ModuleDescriptor.newAutomaticModule("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: : Invalid module name: '' is not a Java identifier");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
