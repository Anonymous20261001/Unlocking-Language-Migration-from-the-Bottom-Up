package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.loop(). */
    @Test
    public void loop_test_8884() throws Throwable {
        java.lang.invoke.MethodHandle[] methodHandleArray0 = new java.lang.invoke.MethodHandle[] {};
        java.lang.invoke.MethodHandle[] methodHandleArray1 = new java.lang.invoke.MethodHandle[] {};
        java.lang.invoke.MethodHandle[] methodHandleArray2 = new java.lang.invoke.MethodHandle[] {};
        java.lang.invoke.MethodHandle[][] methodHandleArray3 = new java.lang.invoke.MethodHandle[][] { methodHandleArray0, methodHandleArray1, methodHandleArray2 };
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle4 = java.lang.invoke.MethodHandles.loop(methodHandleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: no predicate found: []");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(methodHandleArray0);
        org.junit.Assert.assertArrayEquals(methodHandleArray0, new java.lang.invoke.MethodHandle[] {});
        org.junit.Assert.assertNotNull(methodHandleArray1);
        org.junit.Assert.assertArrayEquals(methodHandleArray1, new java.lang.invoke.MethodHandle[] {});
        org.junit.Assert.assertNotNull(methodHandleArray2);
        org.junit.Assert.assertArrayEquals(methodHandleArray2, new java.lang.invoke.MethodHandle[] {});
        org.junit.Assert.assertNotNull(methodHandleArray3);
    }
}
