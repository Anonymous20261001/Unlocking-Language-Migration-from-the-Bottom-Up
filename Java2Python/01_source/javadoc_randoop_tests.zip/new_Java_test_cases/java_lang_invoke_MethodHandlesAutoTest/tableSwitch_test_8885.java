package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.tableSwitch(). */
    @Test
    public void tableSwitch_test_8885() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodHandle[] methodHandleArray1 = new java.lang.invoke.MethodHandle[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle2 = java.lang.invoke.MethodHandles.tableSwitch(methodHandle0, methodHandleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(methodHandleArray1);
        org.junit.Assert.assertArrayEquals(methodHandleArray1, new java.lang.invoke.MethodHandle[] {});
    }
}
