package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.filterArguments(). */
    @Test
    public void filterArguments_test_8914() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodHandle[] methodHandleArray2 = new java.lang.invoke.MethodHandle[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle3 = java.lang.invoke.MethodHandles.filterArguments(methodHandle0, 4, methodHandleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.invoke.MethodHandle.type()\" because \"target\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(methodHandleArray2);
        org.junit.Assert.assertArrayEquals(methodHandleArray2, new java.lang.invoke.MethodHandle[] {});
    }
}
