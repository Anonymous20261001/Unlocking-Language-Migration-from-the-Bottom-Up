package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.lookup(). */
    @Test
    public void lookup_test_8875() throws Throwable {
        java.lang.invoke.MethodHandles.Lookup lookup0 = java.lang.invoke.MethodHandles.lookup();
        java.lang.Class<?> wildcardClass1 = lookup0.lookupClass();
        java.lang.Class<?> wildcardClass2 = lookup0.lookupClass();
        java.lang.Class<?> wildcardClass3 = lookup0.previousLookupClass();
        int int4 = lookup0.lookupModes();
        org.junit.Assert.assertNotNull(lookup0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 95 + "'", int4 == 95);
    }
}
