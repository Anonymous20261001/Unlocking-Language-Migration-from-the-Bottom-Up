package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.doWhileLoop(). */
    @Test
    public void doWhileLoop_test_8920() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodHandle methodHandle1 = null;
        java.lang.invoke.MethodHandle methodHandle2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle3 = java.lang.invoke.MethodHandles.doWhileLoop(methodHandle0, methodHandle1, methodHandle2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
