package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.permuteArguments(). */
    @Test
    public void permuteArguments_test_8898() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodType methodType1 = null;
        int[] intArray2 = new int[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle3 = java.lang.invoke.MethodHandles.permuteArguments(methodHandle0, methodType1, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.invoke.MethodHandle.type()\" because \"target\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertArrayEquals(intArray2, new int[] {});
    }
}
