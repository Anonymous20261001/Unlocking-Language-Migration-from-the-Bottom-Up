package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.dropReturn(). */
    @Test
    public void dropReturn_test_8913() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle1 = java.lang.invoke.MethodHandles.dropReturn(methodHandle0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
