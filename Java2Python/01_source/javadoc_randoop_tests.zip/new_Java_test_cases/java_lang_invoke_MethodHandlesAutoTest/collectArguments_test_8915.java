package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.collectArguments(). */
    @Test
    public void collectArguments_test_8915() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodHandle methodHandle2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle3 = java.lang.invoke.MethodHandles.collectArguments(methodHandle0, 4, methodHandle2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.invoke.MethodHandle.type()\" because \"target\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
