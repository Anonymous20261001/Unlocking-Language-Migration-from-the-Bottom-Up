package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.empty(). */
    @Test
    public void empty_test_8876() throws Throwable {
        java.lang.invoke.MethodType methodType0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle1 = java.lang.invoke.MethodHandles.empty(methodType0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
