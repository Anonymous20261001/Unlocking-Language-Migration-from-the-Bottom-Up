package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.spreadInvoker(). */
    @Test
    public void spreadInvoker_test_8879() throws Throwable {
        java.lang.invoke.MethodType methodType0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle2 = java.lang.invoke.MethodHandles.spreadInvoker(methodType0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: bad argument count: -1");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
