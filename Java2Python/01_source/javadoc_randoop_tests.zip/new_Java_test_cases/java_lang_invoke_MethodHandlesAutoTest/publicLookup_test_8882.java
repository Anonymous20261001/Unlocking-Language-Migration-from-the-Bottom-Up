package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.publicLookup(). */
    @Test
    public void publicLookup_test_8882() throws Throwable {
        java.lang.invoke.MethodHandles.Lookup lookup0 = java.lang.invoke.MethodHandles.publicLookup();
        java.lang.Class<?> wildcardClass1 = lookup0.lookupClass();
        int int2 = lookup0.lookupModes();
        java.lang.Class<?> wildcardClass3 = lookup0.lookupClass();
        java.lang.Class<?> wildcardClass4 = lookup0.lookupClass();
        org.junit.Assert.assertNotNull(lookup0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
