package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.explicitCastArguments(). */
    @Test
    public void explicitCastArguments_test_8911() throws Throwable {
        java.lang.invoke.MethodHandle methodHandle0 = null;
        java.lang.invoke.MethodType methodType1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle2 = java.lang.invoke.MethodHandles.explicitCastArguments(methodHandle0, methodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.invoke.MethodHandle.type()\" because \"target\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
