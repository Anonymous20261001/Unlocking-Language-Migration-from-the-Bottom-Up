package generated.test;

import org.junit.Test;

public class java_lang_invoke_MethodHandlesAutoTest {

    /** Randoop-generated regression test for java.lang.invoke.MethodHandles.varHandleInvoker(). */
    @Test
    public void varHandleInvoker_test_8881() throws Throwable {
        java.lang.invoke.VarHandle.AccessMode accessMode0 = null;
        java.lang.invoke.MethodType methodType1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.MethodHandle methodHandle2 = java.lang.invoke.MethodHandles.varHandleInvoker(accessMode0, methodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.lang.invoke.MethodType.invokers()\" because \"type\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
