package generated.test;

import org.junit.Test;

public class java_beans_IntrospectorAutoTest {

    /** Randoop-generated regression test for java.beans.Introspector.setBeanInfoSearchPath(). */
    @Test
    public void setBeanInfoSearchPath_test_5925() throws Throwable {
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.beans.Introspector.setBeanInfoSearchPath(strArray0);
        java.lang.Class<?> wildcardClass2 = strArray0.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertArrayEquals(strArray0, new java.lang.String[] {});
        org.junit.Assert.assertNotNull(wildcardClass2);
    }
}
