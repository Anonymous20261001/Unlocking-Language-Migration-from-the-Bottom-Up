package generated.test;

import org.junit.Test;

public class java_beans_IntrospectorAutoTest {

    /** Randoop-generated regression test for java.beans.Introspector.flushCaches(). */
    @Test
    public void flushCaches_test_5926() throws Throwable {
        java.beans.Introspector.flushCaches();
    }
}
