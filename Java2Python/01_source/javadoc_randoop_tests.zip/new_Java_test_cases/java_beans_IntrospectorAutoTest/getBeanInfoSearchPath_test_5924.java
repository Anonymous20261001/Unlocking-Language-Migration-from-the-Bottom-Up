package generated.test;

import org.junit.Test;

public class java_beans_IntrospectorAutoTest {

    /** Randoop-generated regression test for java.beans.Introspector.getBeanInfoSearchPath(). */
    @Test
    public void getBeanInfoSearchPath_test_5924() throws Throwable {
        java.lang.String[] strArray0 = java.beans.Introspector.getBeanInfoSearchPath();
        java.lang.Class<?> wildcardClass1 = strArray0.getClass();
        org.junit.Assert.assertNotNull(strArray0);
        // flaky "1) test07(Test0)":         org.junit.Assert.assertArrayEquals(strArray0, new java.lang.String[] { "hi!" });
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
