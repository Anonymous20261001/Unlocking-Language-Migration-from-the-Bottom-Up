package generated.test;

import org.junit.Test;

public class java_beans_IntrospectorAutoTest {

    /** Randoop-generated regression test for java.beans.Introspector.decapitalize(). */
    @Test
    public void decapitalize_test_5928() throws Throwable {
        java.lang.String str1 = java.beans.Introspector.decapitalize("");
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
