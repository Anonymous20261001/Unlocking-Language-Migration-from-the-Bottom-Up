package generated.test;

import org.junit.Test;

public class java_awt_image_DataBufferAutoTest {

    /** Randoop-generated regression test for java.awt.image.DataBuffer.getDataTypeSize(). */
    @Test
    public void getDataTypeSize_test_3173() throws Throwable {
        int int1 = java.awt.image.DataBuffer.getDataTypeSize(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }
}
