package generated.test;

import org.junit.Test;

public class java_lang_StackWalkerAutoTest {

    /** Randoop-generated regression test for java.lang.StackWalker.getInstance(). */
    @Test
    public void getInstance_test_11457() throws Throwable {
        java.lang.StackWalker stackWalker0 = java.lang.StackWalker.getInstance();
        java.lang.Class<?> wildcardClass1 = stackWalker0.getClass();
        org.junit.Assert.assertNotNull(stackWalker0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}
