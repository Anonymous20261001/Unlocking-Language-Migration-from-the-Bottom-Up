package generated.test;

import org.junit.Test;

public class java_lang_StackWalkerAutoTest {

    /** Randoop-generated regression test for java.lang.StackWalker.getInstance(). */
    @Test
    public void getInstance_test_11454() throws Throwable {
        java.lang.StackWalker.Option option0 = java.lang.StackWalker.Option.SHOW_REFLECT_FRAMES;
        java.lang.StackWalker stackWalker1 = java.lang.StackWalker.getInstance(option0);
        java.lang.StackWalker.Option[] optionArray2 = new java.lang.StackWalker.Option[] { option0 };
        java.lang.StackWalker.Option[][] optionArray3 = new java.lang.StackWalker.Option[][] { optionArray2 };
        java.util.Set<java.lang.StackWalker.Option[]> optionArraySet4 = java.util.Set.of(optionArray3);
        org.junit.Assert.assertTrue("'" + option0 + "' != '" + java.lang.StackWalker.Option.SHOW_REFLECT_FRAMES + "'", option0.equals(java.lang.StackWalker.Option.SHOW_REFLECT_FRAMES));
        org.junit.Assert.assertNotNull(stackWalker1);
        org.junit.Assert.assertNotNull(optionArray2);
        org.junit.Assert.assertArrayEquals(optionArray2, new java.lang.StackWalker.Option[] { java.lang.StackWalker.Option.SHOW_REFLECT_FRAMES });
        org.junit.Assert.assertNotNull(optionArray3);
        org.junit.Assert.assertNotNull(optionArraySet4);
    }
}
