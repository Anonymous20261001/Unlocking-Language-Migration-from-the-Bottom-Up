package generated.test;

import org.junit.Test;

public class java_lang_StackWalkerAutoTest {

    /** Randoop-generated regression test for java.lang.StackWalker.getInstance(). */
    @Test
    public void getInstance_test_11456() throws Throwable {
        java.util.HashSet<java.lang.StackWalker.Option> optionSet0 = new java.util.HashSet<java.lang.StackWalker.Option>();
        java.lang.Object[] objArray1 = optionSet0.toArray();
        java.lang.String str2 = optionSet0.toString();
        java.lang.StackWalker stackWalker4 = java.lang.StackWalker.getInstance((java.util.Set<java.lang.StackWalker.Option>) optionSet0, (int) ' ');
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertArrayEquals(objArray1, new java.lang.Object[] {});
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(stackWalker4);
    }
}
