package generated.test;

import org.junit.Test;

public class java_lang_ModuleLayerAutoTest {

    /** Randoop-generated regression test for java.lang.ModuleLayer.defineModulesWithManyLoaders(). */
    @Test
    public void defineModulesWithManyLoaders_test_9000() throws Throwable {
        java.lang.module.Configuration configuration0 = null;
        java.lang.ModuleLayer moduleLayer1 = java.lang.ModuleLayer.boot();
        java.util.List<java.lang.ModuleLayer> moduleLayerList2 = moduleLayer1.parents();
        java.lang.ClassLoader classLoader3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.ModuleLayer.Controller controller4 = java.lang.ModuleLayer.defineModulesWithManyLoaders(configuration0, moduleLayerList2, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(moduleLayer1);
        org.junit.Assert.assertNotNull(moduleLayerList2);
    }
}
