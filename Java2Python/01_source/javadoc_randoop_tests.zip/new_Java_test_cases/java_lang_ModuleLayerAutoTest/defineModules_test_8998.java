package generated.test;

import org.junit.Test;

public class java_lang_ModuleLayerAutoTest {

    /** Randoop-generated regression test for java.lang.ModuleLayer.defineModules(). */
    @Test
    public void defineModules_test_8998() throws Throwable {
        java.lang.module.Configuration configuration0 = null;
        java.lang.ModuleLayer moduleLayer1 = java.lang.ModuleLayer.empty();
        java.util.List<java.lang.ModuleLayer> moduleLayerList2 = moduleLayer1.parents();
        java.util.function.Function<java.lang.String, java.lang.ClassLoader> strFunction3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.ModuleLayer.Controller controller4 = java.lang.ModuleLayer.defineModules(configuration0, moduleLayerList2, strFunction3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(moduleLayer1);
        org.junit.Assert.assertNotNull(moduleLayerList2);
    }
}
