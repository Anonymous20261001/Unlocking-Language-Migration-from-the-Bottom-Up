package generated.test;

import org.junit.Test;

public class java_lang_ModuleLayerAutoTest {

    /** Randoop-generated regression test for java.lang.ModuleLayer.empty(). */
    @Test
    public void empty_test_8996() throws Throwable {
        java.lang.ModuleLayer moduleLayer0 = java.lang.ModuleLayer.empty();
        java.lang.String str1 = moduleLayer0.toString();
        java.lang.String str2 = moduleLayer0.toString();
        java.lang.String str3 = moduleLayer0.toString();
        java.lang.Class<?> wildcardClass4 = moduleLayer0.getClass();
        org.junit.Assert.assertNotNull(moduleLayer0);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "" + "'", str2, "");
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
