package generated.test;

import org.junit.Test;

public class java_io_ReaderAutoTest {

    /** Randoop-generated regression test for java.io.Reader.nullReader(). */
    @Test
    public void nullReader_test_10346() throws Throwable {
        java.io.Reader reader0 = java.io.Reader.nullReader();
        char[] charArray2 = new char[] { '4' };
        int int3 = reader0.read(charArray2);
        java.lang.Class<?> wildcardClass4 = reader0.getClass();
        org.junit.Assert.assertNotNull(reader0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertArrayEquals(charArray2, new char[] { '4' });
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }
}
