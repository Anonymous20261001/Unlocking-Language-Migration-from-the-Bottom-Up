```cpp
#include <iostream>
#include <memory>

// ============================================================================
// C++ equivalent of java.net.CookiePolicy
// ============================================================================
class CookiePolicy {
public:
    CookiePolicy() = default;
    CookiePolicy(const CookiePolicy&) = default;
    CookiePolicy& operator=(const CookiePolicy&) = default;
    virtual ~CookiePolicy() = default;
};

// ============================================================================
// C++ equivalent of java.net.CookieStore
// ============================================================================
class CookieStore {
public:
    CookieStore() = default;
    virtual ~CookieStore() = default;
    // Additional methods (add, get, remove, etc.) can be added if needed.
};

// ============================================================================
// C++ equivalent of java.net.CookieManager
// ============================================================================
class CookieManager {
private:
    CookiePolicy policy_;    // Stored by value (copy semantics)
    CookieStore store_;      // Internal cookie store

public:
    CookieManager() = default;

    // Sets the cookie policy (stores a copy of the provided policy)
    void setCookiePolicy(const CookiePolicy& policy) {
        policy_ = policy;
    }

    // Returns a reference to the internal cookie store
    CookieStore& getCookieStore() {
        return store_;
    }

    // Const overload (for completeness)
    const CookieStore& getCookieStore() const {
        return store_;
    }
};

// ============================================================================
// Test functions (direct translations of Java @Test methods)
// ============================================================================

// Translates: setCookiePolicy_test_2543(CookiePolicy p0)
void setCookiePolicy_test_2543(const CookiePolicy& p0) {
    CookieManager instance;
    instance.setCookiePolicy(p0);
}

// Translates: getCookieStore_test_2544()
void getCookieStore_test_2544() {
    CookieManager instance;
    instance.getCookieStore();
}
```