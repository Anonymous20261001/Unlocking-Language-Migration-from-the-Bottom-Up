```cpp
#include <vector>
#include <algorithm>

// Forward declarations
namespace generated::test {

class ChangeEvent {
public:
    void* source;
    explicit ChangeEvent(void* src) : source(src) {}
};

class ChangeListener {
public:
    virtual ~ChangeListener() = default;
    virtual void stateChanged(ChangeEvent& event) = 0;
};

class Color {
public:
    int red, green, blue;
    
    Color() : red(0), green(0), blue(0) {}
    Color(int r, int g, int b) : red(r), green(g), blue(b) {}
    explicit Color(int rgb) {
        red   = (rgb >> 16) & 0xFF;
        green = (rgb >> 8) & 0xFF;
        blue  = rgb & 0xFF;
    }
    
    bool operator==(const Color& other) const {
        return red == other.red && green == other.green && blue == other.blue;
    }
    
    static Color white;
};

Color Color::white = Color(255, 255, 255);

class DefaultColorSelectionModel {
private:
    Color selectedColor;
    std::vector<ChangeListener*> listenerList;
    
    void fireStateChanged() {
        ChangeEvent event(this);
        // Iterate over a copy to avoid issues if listener modifies list (not required)
        for (auto* listener : listenerList) {
            listener->stateChanged(event);
        }
    }
    
public:
    DefaultColorSelectionModel() : selectedColor(Color::white) {}
    
    void addChangeListener(ChangeListener* listener) {
        listenerList.push_back(listener);
    }
    
    void removeChangeListener(ChangeListener* listener) {
        auto it = std::find(listenerList.begin(), listenerList.end(), listener);
        if (it != listenerList.end()) {
            listenerList.erase(it);
        }
    }
    
    std::vector<ChangeListener*> getChangeListeners() {
        return listenerList;
    }
    
    Color getSelectedColor() const {
        return selectedColor;
    }
    
    void setSelectedColor(const Color& color) {
        selectedColor = color;
        fireStateChanged();
    }
};

// Test function implementations

void addChangeListener_test_8515(ChangeListener* p0) {
    DefaultColorSelectionModel instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_8516(ChangeListener* p0) {
    DefaultColorSelectionModel instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_8517() {
    DefaultColorSelectionModel instance;
    instance.getChangeListeners();
}

void getSelectedColor_test_8518() {
    DefaultColorSelectionModel instance;
    instance.getSelectedColor();
}

void setSelectedColor_test_8519(const Color& p0) {
    DefaultColorSelectionModel instance;
    instance.setSelectedColor(p0);
}

} // namespace generated::test
```