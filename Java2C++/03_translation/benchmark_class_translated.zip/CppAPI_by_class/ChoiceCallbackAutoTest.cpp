```cpp
#include <string>
#include <vector>
#include <stdexcept>
#include <algorithm>

class ChoiceCallback {
private:
    std::string prompt_;
    std::vector<std::string> choices_;
    int defaultChoice_;
    bool allowMultipleSelections_;
    std::vector<int> selectedIndexes_;

public:
    // Constructor: mirrors Java's ChoiceCallback(String prompt, String[] choices, int defaultChoice, boolean multipleSelections)
    ChoiceCallback(const std::string& prompt,
                   const std::vector<std::string>& choices,
                   int defaultChoice,
                   bool multipleSelections)
        : prompt_(prompt),
          choices_(choices),
          defaultChoice_(defaultChoice),
          allowMultipleSelections_(multipleSelections)
    {
        // Validate as per Java API: throw IllegalArgumentException if choices is empty or defaultChoice out of range
        if (choices_.empty())
            throw std::invalid_argument("choices must not be empty");
        if (defaultChoice_ < -1 || defaultChoice_ >= static_cast<int>(choices_.size()))
            throw std::invalid_argument("defaultChoice is out of valid range");
        // Note: Java also checks for null prompt, but C++ std::string cannot be null.
        // We assume prompt is non-null.
    }

    // Get the prompt string
    std::string getPrompt() const {
        return prompt_;
    }

    // Get the choices (returns a copy to avoid external modification)
    std::vector<std::string> getChoices() const {
        return choices_;
    }

    // Get the default choice index
    int getDefaultChoice() const {
        return defaultChoice_;
    }

    // Whether multiple selections are allowed
    bool allowMultipleSelections() const {
        return allowMultipleSelections_;
    }

    // Set a single selected index (as per Java: throws IllegalArgumentException if index is invalid)
    void setSelectedIndex(int index) {
        if (index < 0 || index >= static_cast<int>(choices_.size()))
            throw std::invalid_argument("Selected index out of bounds");
        selectedIndexes_.clear();
        selectedIndexes_.push_back(index);
    }

    // Set multiple selected indexes (mirrors Java's setSelectedIndexes(int[]))
    void setSelectedIndexes(const std::vector<int>& indexes) {
        // Validate: must not be empty? Java's spec says selections must not be null;
        // we treat an empty vector as invalid (though not explicitly stated, but logical).
        if (indexes.empty())
            throw std::invalid_argument("Selected indexes must not be empty");
        // Validate all indices
        for (int idx : indexes) {
            if (idx < 0 || idx >= static_cast<int>(choices_.size()))
                throw std::invalid_argument("Selected index out of bounds");
        }
        // If multiple selections not allowed, only one index is permitted
        if (!allowMultipleSelections_ && indexes.size() != 1)
            throw std::invalid_argument("Multiple selections not allowed, but more than one index provided");
        selectedIndexes_ = indexes;
    }

    // Get the current selected indexes (returns a copy)
    std::vector<int> getSelectedIndexes() const {
        return selectedIndexes_;
    }
};

// ========== Test functions (translated from Java @Test methods) ==========

void getPrompt_test_6326(std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.getPrompt();
}

void getChoices_test_6327(std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.getChoices();
}

void getDefaultChoice_test_6328(std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.getDefaultChoice();
}

void allowMultipleSelections_test_6329(std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.allowMultipleSelections();
}

void setSelectedIndex_test_6330(int p0, std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.setSelectedIndex(p0);
}

void setSelectedIndexes_test_6331(std::vector<int> p0, std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.setSelectedIndexes(p0);
}

void getSelectedIndexes_test_6332(std::string c0, std::vector<std::string> c1, int c2, bool c3) {
    ChoiceCallback instance(c0, c1, c2, c3);
    instance.getSelectedIndexes();
}
```