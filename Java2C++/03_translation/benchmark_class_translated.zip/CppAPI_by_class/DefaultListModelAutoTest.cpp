```cpp
#include <vector>
#include <string>
#include <stdexcept>
#include <cstddef>
#include <memory>

// Minimal Object base class
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other; // pointer identity by default
    }
    virtual std::string toString() const {
        return "Object@" + std::to_string(reinterpret_cast<uintptr_t>(this));
    }
};

// Abstract Collection interface (subset of java.util.Collection)
class Collection {
public:
    virtual ~Collection() = default;
    virtual int size() const = 0;
    virtual Object* get(int index) const = 0; // returns nullptr if index out of bounds? but we trust caller
};

// Concrete collection holding vector of Object*
class SimpleCollection : public Collection {
    std::vector<Object*> data;
public:
    SimpleCollection() = default;
    SimpleCollection(const std::vector<Object*>& vec) : data(vec) {}
    int size() const override { return static_cast<int>(data.size()); }
    Object* get(int index) const override {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Collection::get index out of range");
        return data[index];
    }
};

// Enumeration interface (subset of java.util.Enumeration)
class Enumeration {
public:
    virtual ~Enumeration() = default;
    virtual bool hasMoreElements() const = 0;
    virtual Object* nextElement() = 0; // throws if no more
};

// Concrete enumeration over vector iterators
class VectorEnumeration : public Enumeration {
    using const_iterator = std::vector<Object*>::const_iterator;
    const_iterator current;
    const_iterator end;
public:
    VectorEnumeration(const_iterator begin, const_iterator end)
        : current(begin), end(end) {}
    bool hasMoreElements() const override {
        return current != end;
    }
    Object* nextElement() override {
        if (!hasMoreElements())
            throw std::out_of_range("Enumeration::nextElement - no more elements");
        return *current++;
    }
};

// DefaultListModel - mimics javax.swing.DefaultListModel
class DefaultListModel {
    std::vector<Object*> data;  // stored as raw pointers (ownership not managed here)
public:
    DefaultListModel() = default;

    // ------------- methods from Vector / AbstractList -------------
    void setElementAt(Object* obj, int index) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in setElementAt");
        data[index] = obj;
    }

    Object* getElementAt(int index) const {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in getElementAt");
        return data[index];
    }

    Object* firstElement() const {
        if (data.empty())
            throw std::out_of_range("NoSuchElementException: firstElement on empty list");
        return data.front();
    }

    Object* lastElement() const {
        if (data.empty())
            throw std::out_of_range("NoSuchElementException: lastElement on empty list");
        return data.back();
    }

    void addElement(Object* obj) {
        data.push_back(obj);
    }

    void removeElementAt(int index) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in removeElementAt");
        data.erase(data.begin() + index);
    }

    void insertElementAt(Object* obj, int index) {
        if (index < 0 || index > static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in insertElementAt");
        data.insert(data.begin() + index, obj);
    }

    void removeAllElements() {
        data.clear();
    }

    bool removeElement(Object* obj) {
        for (auto it = data.begin(); it != data.end(); ++it) {
            if (*it == obj || (*it && obj && (*it)->equals(*obj))) {
                data.erase(it);
                return true;
            }
        }
        return false;
    }

    Object* remove(int index) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in remove(int)");
        Object* old = data[index];
        data.erase(data.begin() + index);
        return old;
    }

    int size() const {
        return static_cast<int>(data.size());
    }

    Object* get(int index) const {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in get");
        return data[index];
    }

    std::string toString() const {
        return "DefaultListModel";
    }

    int indexOf(Object* obj) const {
        for (int i = 0; i < static_cast<int>(data.size()); ++i) {
            if (data[i] == obj || (data[i] && obj && data[i]->equals(*obj)))
                return i;
        }
        return -1;
    }

    int indexOf(Object* obj, int startIndex) const {
        if (startIndex < 0 || startIndex >= static_cast<int>(data.size()))
            throw std::out_of_range("startIndex out of bounds in indexOf(Object, int)");
        for (int i = startIndex; i < static_cast<int>(data.size()); ++i) {
            if (data[i] == obj || (data[i] && obj && data[i]->equals(*obj)))
                return i;
        }
        return -1;
    }

    void clear() {
        removeAllElements();
    }

    int lastIndexOf(Object* obj) const {
        for (int i = static_cast<int>(data.size()) - 1; i >= 0; --i) {
            if (data[i] == obj || (data[i] && obj && data[i]->equals(*obj)))
                return i;
        }
        return -1;
    }

    int lastIndexOf(Object* obj, int startIndex) const {
        if (startIndex < 0 || startIndex >= static_cast<int>(data.size()))
            throw std::out_of_range("startIndex out of bounds in lastIndexOf(Object, int)");
        for (int i = startIndex; i >= 0; --i) {
            if (data[i] == obj || (data[i] && obj && data[i]->equals(*obj)))
                return i;
        }
        return -1;
    }

    bool isEmpty() const {
        return data.empty();
    }

    void add(int index, Object* obj) {
        insertElementAt(obj, index);
    }

    std::vector<Object*> toArray() const {
        return data; // copy
    }

    bool contains(Object* obj) const {
        return indexOf(obj) != -1;
    }

    Enumeration* elements() const {
        return new VectorEnumeration(data.begin(), data.end());
    }

    bool addAll(Collection& c) {
        int oldSize = static_cast<int>(data.size());
        int cSize = c.size();
        for (int i = 0; i < cSize; ++i) {
            data.push_back(c.get(i));
        }
        return cSize > 0;
    }

    bool addAll(int index, Collection& c) {
        if (index < 0 || index > static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in addAll(int, Collection)");
        int cSize = c.size();
        if (cSize == 0) return false;
        // insert elements in reverse order to maintain order
        for (int i = cSize - 1; i >= 0; --i) {
            data.insert(data.begin() + index, c.get(i));
        }
        return true;
    }

    void trimToSize() {
        data.shrink_to_fit();
    }

    void ensureCapacity(int minCapacity) {
        if (minCapacity > static_cast<int>(data.capacity()))
            data.reserve(minCapacity);
    }

    int capacity() const {
        return static_cast<int>(data.capacity());
    }

    void setSize(int newSize) {
        int curSize = static_cast<int>(data.size());
        if (newSize > curSize) {
            data.resize(newSize, nullptr); // pad with nulls
        } else if (newSize < curSize) {
            data.resize(newSize);
        }
    }

    int getSize() const {
        return size();
    }

    Object* elementAt(int index) const {
        return getElementAt(index);
    }

    void removeRange(int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex > static_cast<int>(data.size()) || fromIndex > toIndex)
            throw std::out_of_range("Invalid range in removeRange");
        data.erase(data.begin() + fromIndex, data.begin() + toIndex);
    }

    void copyInto(Object** dest) const {
        for (int i = 0; i < static_cast<int>(data.size()); ++i) {
            dest[i] = data[i];
        }
    }

    Object* set(int index, Object* obj) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds in set");
        Object* old = data[index];
        data[index] = obj;
        return old;
    }
};

// ============ TEST FUNCTIONS ============

void setElementAt_test_6736(Object* p0, int p1) {
    DefaultListModel instance;
    instance.setElementAt(p0, p1);
}

void getElementAt_test_6737(int p0) {
    DefaultListModel instance;
    instance.getElementAt(p0);
}

void firstElement_test_6738() {
    DefaultListModel instance;
    instance.firstElement();
}

void lastElement_test_6739() {
    DefaultListModel instance;
    instance.lastElement();
}

void addElement_test_6740(Object* p0) {
    DefaultListModel instance;
    instance.addElement(p0);
}

void removeElementAt_test_6741(int p0) {
    DefaultListModel instance;
    instance.removeElementAt(p0);
}

void insertElementAt_test_6742(Object* p0, int p1) {
    DefaultListModel instance;
    instance.insertElementAt(p0, p1);
}

void removeAllElements_test_6743() {
    DefaultListModel instance;
    instance.removeAllElements();
}

void removeElement_test_6744(Object* p0) {
    DefaultListModel instance;
    instance.removeElement(p0);
}

void remove_test_6745(int p0) {
    DefaultListModel instance;
    instance.remove(p0);
}

void size_test_6746() {
    DefaultListModel instance;
    instance.size();
}

void get_test_6747(int p0) {
    DefaultListModel instance;
    instance.get(p0);
}

void toString_test_6748() {
    DefaultListModel instance;
    instance.toString();
}

void indexOf_test_6749(Object* p0) {
    DefaultListModel instance;
    instance.indexOf(p0);
}

void indexOf_test_6750(Object* p0, int p1) {
    DefaultListModel instance;
    instance.indexOf(p0, p1);
}

void clear_test_6751() {
    DefaultListModel instance;
    instance.clear();
}

void lastIndexOf_test_6752(Object* p0) {
    DefaultListModel instance;
    instance.lastIndexOf(p0);
}

void lastIndexOf_test_6753(Object* p0, int p1) {
    DefaultListModel instance;
    instance.lastIndexOf(p0, p1);
}

void isEmpty_test_6754() {
    DefaultListModel instance;
    instance.isEmpty();
}

void add_test_6755(int p0, Object* p1) {
    DefaultListModel instance;
    instance.add(p0, p1);
}

void toArray_test_6756() {
    DefaultListModel instance;
    instance.toArray();
}

void contains_test_6757(Object* p0) {
    DefaultListModel instance;
    instance.contains(p0);
}

void elements_test_6758() {
    DefaultListModel instance;
    instance.elements();
}

void addAll_test_6759(Collection& p0) {
    DefaultListModel instance;
    instance.addAll(p0);
}

void addAll_test_6760(int p0, Collection& p1) {
    DefaultListModel instance;
    instance.addAll(p0, p1);
}

void trimToSize_test_6761() {
    DefaultListModel instance;
    instance.trimToSize();
}

void set_test_6762(int p0, Object* p1) {
    DefaultListModel instance;
    instance.set(p0, p1);
}

void getSize_test_6763() {
    DefaultListModel instance;
    instance.getSize();
}

void capacity_test_6764() {
    DefaultListModel instance;
    instance.capacity();
}

void ensureCapacity_test_6765(int p0) {
    DefaultListModel instance;
    instance.ensureCapacity(p0);
}

void elementAt_test_6766(int p0) {
    DefaultListModel instance;
    instance.elementAt(p0);
}

void removeRange_test_6767(int p0, int p1) {
    DefaultListModel instance;
    instance.removeRange(p0, p1);
}

void copyInto_test_6768(Object* p0[]) {
    DefaultListModel instance;
    instance.copyInto(p0);
}

void setSize_test_6769(int p0) {
    DefaultListModel instance;
    instance.setSize(p0);
}
```