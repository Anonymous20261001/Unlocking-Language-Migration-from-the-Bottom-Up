```cpp
#include <vector>
#include <cstdint>
#include <unordered_map>
#include <string>
#include <memory>

// -----------------------------------------------------------------------------
// Forward declarations
// -----------------------------------------------------------------------------
class ColorModel;
class ImageConsumer;
class ImageProducer;
class ImageFilter;

// -----------------------------------------------------------------------------
// Hashtable – simplified key-value store (keys/values as strings)
// -----------------------------------------------------------------------------
class Hashtable {
public:
    void put(const std::string& key, const std::string& value) {
        data_[key] = value;
    }
    std::string get(const std::string& key) const {
        auto it = data_.find(key);
        return (it != data_.end()) ? it->second : "";
    }
private:
    std::unordered_map<std::string, std::string> data_;
};

// -----------------------------------------------------------------------------
// ColorModel – minimal dummy implementation
// -----------------------------------------------------------------------------
class ColorModel {
public:
    ColorModel() = default;
    // Additional methods can be added if needed (none used in tests)
};

// -----------------------------------------------------------------------------
// ImageConsumer – abstract interface (Java's ImageConsumer)
// -----------------------------------------------------------------------------
class ImageConsumer {
public:
    virtual ~ImageConsumer() = default;

    virtual void setHints(int hints) = 0;
    virtual void setPixels(int x, int y, int w, int h, const ColorModel& model,
                           const std::vector<uint8_t>& pixels, int offset, int scansize) = 0;
    virtual void setPixels(int x, int y, int w, int h, const ColorModel& model,
                           const std::vector<int32_t>& pixels, int offset, int scansize) = 0;
    virtual void setDimensions(int width, int height) = 0;
    virtual void setColorModel(const ColorModel& model) = 0;
    virtual void imageComplete(int status) = 0;
    virtual void setProperties(const Hashtable& props) = 0;
};

// -----------------------------------------------------------------------------
// ImageProducer – abstract interface (Java's ImageProducer)
// -----------------------------------------------------------------------------
class ImageProducer {
public:
    virtual ~ImageProducer() = default;
    virtual void requestTopDownLeftRight(ImageConsumer* ic) = 0;
    // Other methods (addConsumer, removeConsumer, startProduction) omitted as unused.
};

// -----------------------------------------------------------------------------
// ImageFilter – concrete class implementing ImageConsumer
// -----------------------------------------------------------------------------
class ImageFilter : public ImageConsumer {
public:
    ImageFilter() = default;
    ImageFilter(const ImageFilter& other) : consumer_(other.consumer_) {}

    // ImageConsumer methods
    void setHints(int hints) override {
        if (consumer_) consumer_->setHints(hints);
    }

    void setPixels(int x, int y, int w, int h, const ColorModel& model,
                   const std::vector<uint8_t>& pixels, int offset, int scansize) override {
        if (consumer_) consumer_->setPixels(x, y, w, h, model, pixels, offset, scansize);
    }

    void setPixels(int x, int y, int w, int h, const ColorModel& model,
                   const std::vector<int32_t>& pixels, int offset, int scansize) override {
        if (consumer_) consumer_->setPixels(x, y, w, h, model, pixels, offset, scansize);
    }

    void setDimensions(int width, int height) override {
        if (consumer_) consumer_->setDimensions(width, height);
    }

    void setColorModel(const ColorModel& model) override {
        if (consumer_) consumer_->setColorModel(model);
    }

    void imageComplete(int status) override {
        if (consumer_) consumer_->imageComplete(status);
    }

    void setProperties(const Hashtable& props) override {
        if (consumer_) consumer_->setProperties(props);
    }

    // Returns an ImageConsumer that will receive filtered data.
    // In Java's ImageFilter, this method stores the consumer and returns the filter itself.
    ImageConsumer* getFilterInstance(ImageConsumer* ic) {
        consumer_ = ic;
        return this;
    }

    // Resends image data using the given producer.
    void resendTopDownLeftRight(ImageProducer* ip) {
        if (ip) ip->requestTopDownLeftRight(this);
    }

    // Returns a clone (shallow copy) of this filter.
    ImageFilter* clone() const {
        return new ImageFilter(*this);
    }

private:
    ImageConsumer* consumer_ = nullptr;   // downstream consumer
};

// -----------------------------------------------------------------------------
// Concrete ImageProducer stub (needed for resendTopDownLeftRight test)
// -----------------------------------------------------------------------------
class DummyImageProducer : public ImageProducer {
public:
    void requestTopDownLeftRight(ImageConsumer* ic) override {
        // Do nothing in this stub; real implementation would send data.
    }
};

// -----------------------------------------------------------------------------
// Auto‑generated test functions (translated from Java @Test methods)
// -----------------------------------------------------------------------------

void setHints_test_1269(int p0) {
    ImageFilter instance;
    instance.setHints(p0);
}

void setPixels_test_1270(int p0, int p1, int p2, int p3, ColorModel p4,
                         std::vector<uint8_t> p5, int p6, int p7) {
    ImageFilter instance;
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
}

void setPixels_test_1271(int p0, int p1, int p2, int p3, ColorModel p4,
                         std::vector<int32_t> p5, int p6, int p7) {
    ImageFilter instance;
    instance.setPixels(p0, p1, p2, p3, p4, p5, p6, p7);
}

void setDimensions_test_1272(int p0, int p1) {
    ImageFilter instance;
    instance.setDimensions(p0, p1);
}

void setColorModel_test_1273(ColorModel p0) {
    ImageFilter instance;
    instance.setColorModel(p0);
}

void imageComplete_test_1274(int p0) {
    ImageFilter instance;
    instance.imageComplete(p0);
}

void getFilterInstance_test_1275(ImageConsumer* p0) {
    ImageFilter instance;
    instance.getFilterInstance(p0);
}

void resendTopDownLeftRight_test_1276(ImageProducer* p0) {
    ImageFilter instance;
    instance.resendTopDownLeftRight(p0);
}

void clone_test_1277() {
    ImageFilter instance;
    // In Java the return value is ignored; we still call the method.
    delete instance.clone();   // avoid memory leak – but test does not care.
}

void setProperties_test_1278(Hashtable p0) {
    ImageFilter instance;
    instance.setProperties(p0);
}
```