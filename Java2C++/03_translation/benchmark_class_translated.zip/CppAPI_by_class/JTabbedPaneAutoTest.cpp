```cpp
#include <string>
#include <vector>
#include <memory>
#include <stdexcept>
#include <functional>

// Forward declarations
class Icon;
class Component;
class MouseEvent;
class TabbedPaneUI;
class SingleSelectionModel;
class ChangeListener;
class ChangeEvent;
class AccessibleContext;

// -----------------------------------------------------------------------------
// Minimal Color class
class Color {
public:
    int red, green, blue, alpha;
    Color(int r, int g, int b, int a = 255) : red(r), green(g), blue(b), alpha(a) {}
    Color() : red(0), green(0), blue(0), alpha(255) {}
};

// -----------------------------------------------------------------------------
// Icon interface (abstract)
class Icon {
public:
    virtual ~Icon() = default;
    virtual int getIconWidth() const = 0;
    virtual int getIconHeight() const = 0;
    // paintIcon would require a Graphics object – omitted for stub
};

// -----------------------------------------------------------------------------
// Component base class
class Component {
public:
    virtual ~Component() = default;
    // minimal: name, etc.
    std::string name;
    Component() : name("") {}
};

// -----------------------------------------------------------------------------
// MouseEvent (stub, only event coordinates)
class MouseEvent {
public:
    int x, y;
    int modifiers;
    MouseEvent(int x, int y, int mod = 0) : x(x), y(y), modifiers(mod) {}
};

// -----------------------------------------------------------------------------
// TabbedPaneUI interface (stub)
class TabbedPaneUI {
public:
    virtual ~TabbedPaneUI() = default;
    // minimal, no pure virtual
};

// -----------------------------------------------------------------------------
// SingleSelectionModel interface
class SingleSelectionModel {
public:
    virtual ~SingleSelectionModel() = default;
    virtual void setSelectedIndex(int index) = 0;
    virtual int getSelectedIndex() const = 0;
    virtual void addChangeListener(ChangeListener* listener) = 0;
    virtual void removeChangeListener(ChangeListener* listener) = 0;
};

// -----------------------------------------------------------------------------
// ChangeListener interface
class ChangeListener {
public:
    virtual ~ChangeListener() = default;
    virtual void stateChanged(ChangeEvent* e) = 0;
};

// -----------------------------------------------------------------------------
// ChangeEvent (stub)
class ChangeEvent {
public:
    // source object
    void* source;
    ChangeEvent(void* src) : source(src) {}
};

// -----------------------------------------------------------------------------
// AccessibleContext (stub)
class AccessibleContext {
public:
    virtual ~AccessibleContext() = default;
    // no methods needed for tests
};

// -----------------------------------------------------------------------------
// JTabbedPane – the main class
class JTabbedPane {
private:
    struct TabData {
        std::string title;
        Icon* icon = nullptr;
        Component* component = nullptr;
        std::string tooltip;
        Color background;
        Color foreground;
        bool enabled = true;
        Icon* disabledIcon = nullptr;
        Component* tabComponent = nullptr;
        int mnemonic = 0;
        int displayedMnemonicIndex = -1;
    };

    std::vector<TabData> tabs;
    int tabPlacement = 1; // default TOP
    int tabLayoutPolicy = 1; // default WRAP_TAB_LAYOUT
    Component* selectedComponent = nullptr;
    int selectedIndex = -1;
    std::vector<ChangeListener*> changeListeners;
    SingleSelectionModel* selectionModel = nullptr;
    TabbedPaneUI* ui = nullptr;
    AccessibleContext accessibleContext;

    // stub for model – we maintain selectedIndex directly
    class DefaultSingleSelectionModel : public SingleSelectionModel {
    private:
        int selIndex = -1;
        std::vector<ChangeListener*> listeners;
        JTabbedPane* owner;
    public:
        DefaultSingleSelectionModel(JTabbedPane* o) : owner(o) {}
        void setSelectedIndex(int index) override {
            if (index != selIndex) {
                selIndex = index;
                owner->selectedIndex = index;
                if (index >= 0 && index < (int)owner->tabs.size())
                    owner->selectedComponent = owner->tabs[index].component;
                ChangeEvent evt(owner);
                for (auto* l : listeners) l->stateChanged(&evt);
            }
        }
        int getSelectedIndex() const override { return selIndex; }
        void addChangeListener(ChangeListener* listener) override {
            listeners.push_back(listener);
        }
        void removeChangeListener(ChangeListener* listener) override {
            auto it = std::find(listeners.begin(), listeners.end(), listener);
            if (it != listeners.end()) listeners.erase(it);
        }
    };
    std::unique_ptr<DefaultSingleSelectionModel> defaultModel;

public:
    JTabbedPane() {
        defaultModel = std::make_unique<DefaultSingleSelectionModel>(this);
        selectionModel = defaultModel.get();
    }

    // -----------------------------------------------------------------------
    // Tab placement
    void setTabPlacement(int p0) { tabPlacement = p0; }
    int getTabPlacement() const { return tabPlacement; }

    // Tab layout policy
    void setTabLayoutPolicy(int p0) { tabLayoutPolicy = p0; }
    int getTabLayoutPolicy() const { return tabLayoutPolicy; }

    // Tab count
    int getTabCount() const { return static_cast<int>(tabs.size()); }

    // Disabled icon
    void setDisabledIconAt(int index, Icon* icon) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].disabledIcon = icon;
    }
    Icon* getDisabledIconAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].disabledIcon;
        return nullptr;
    }

    // Index of component
    int indexOfComponent(Component* comp) const {
        for (size_t i = 0; i < tabs.size(); ++i)
            if (tabs[i].component == comp) return static_cast<int>(i);
        return -1;
    }

    // Remove tab
    void removeTabAt(int index) {
        if (index >= 0 && index < (int)tabs.size()) {
            tabs.erase(tabs.begin() + index);
            if (selectedIndex == index) selectedIndex = -1;
            else if (selectedIndex > index) --selectedIndex;
        }
    }

    // Insert tab
    void insertTab(const std::string& title, Icon* icon, Component* component,
                   const std::string& tip, int index) {
        TabData td;
        td.title = title;
        td.icon = icon;
        td.component = component;
        td.tooltip = tip;
        if (index < 0 || index > (int)tabs.size())
            index = (int)tabs.size();
        tabs.insert(tabs.begin() + index, td);
        if (tabs.size() == 1) {
            selectedIndex = 0;
            selectedComponent = component;
        }
    }

    // Add tab (overloads)
    void addTab(const std::string& title, Icon* icon, Component* component,
                const std::string& tip) {
        insertTab(title, icon, component, tip, -1);
    }
    void addTab(const std::string& title, Component* component) {
        addTab(title, nullptr, component, "");
    }
    void addTab(const std::string& title, Icon* icon, Component* component) {
        addTab(title, icon, component, "");
    }

    // Tab component
    void setTabComponentAt(int index, Component* comp) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].tabComponent = comp;
    }
    Component* getTabComponentAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].tabComponent;
        return nullptr;
    }
    int indexOfTabComponent(Component* comp) const {
        for (size_t i = 0; i < tabs.size(); ++i)
            if (tabs[i].tabComponent == comp) return static_cast<int>(i);
        return -1;
    }

    // Selected component
    Component* getSelectedComponent() const { return selectedComponent; }
    void setSelectedComponent(Component* comp) {
        int idx = indexOfComponent(comp);
        if (idx >= 0) setSelectedIndex(idx);
    }

    // Tab run count (stub)
    int getTabRunCount() const { return 1; }

    // Enabled at
    bool isEnabledAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].enabled;
        return false;
    }

    // Bounds (stub returns empty)
    // In Java returns Rectangle, here we return a dummy struct or just void
    // Test does not use return value, so we can omit implementation.
    // For compilation, we define a method that returns something.
    // We'll use a dummy struct Rectangle.
    struct Rectangle { int x, y, w, h; };
    Rectangle getBoundsAt(int index) const {
        return {0,0,0,0};
    }

    // Title
    std::string getTitleAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].title;
        return "";
    }
    void setTitleAt(int index, const std::string& title) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].title = title;
    }

    // Icon
    Icon* getIconAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].icon;
        return nullptr;
    }
    void setIconAt(int index, Icon* icon) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].icon = icon;
    }

    // Tooltip
    std::string getToolTipTextAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].tooltip;
        return "";
    }
    void setToolTipTextAt(int index, const std::string& tip) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].tooltip = tip;
    }
    std::string getToolTipText(MouseEvent* /*event*/) {
        // For simplicity, returns tooltip of selected tab
        if (selectedIndex >=0 && selectedIndex < (int)tabs.size())
            return tabs[selectedIndex].tooltip;
        return "";
    }

    // Background
    Color getBackgroundAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].background;
        return Color();
    }
    void setBackgroundAt(int index, const Color& c) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].background = c;
    }

    // Foreground
    Color getForegroundAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].foreground;
        return Color();
    }
    void setForegroundAt(int index, const Color& c) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].foreground = c;
    }

    // Mnemonic
    int getMnemonicAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].mnemonic;
        return 0;
    }
    void setMnemonicAt(int index, int mnem) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].mnemonic = mnem;
    }

    // Displayed mnemonic index
    int getDisplayedMnemonicIndexAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].displayedMnemonicIndex;
        return -1;
    }
    void setDisplayedMnemonicIndexAt(int index, int mnemIndex) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].displayedMnemonicIndex = mnemIndex;
    }

    // Enabled
    void setEnabledAt(int index, bool enabled) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].enabled = enabled;
    }

    // Component at
    Component* getComponentAt(int index) const {
        if (index >= 0 && index < (int)tabs.size())
            return tabs[index].component;
        return nullptr;
    }
    void setComponentAt(int index, Component* comp) {
        if (index >= 0 && index < (int)tabs.size())
            tabs[index].component = comp;
    }

    // Index of tab by icon or title
    int indexOfTab(Icon* icon) const {
        for (size_t i = 0; i < tabs.size(); ++i)
            if (tabs[i].icon == icon) return static_cast<int>(i);
        return -1;
    }
    int indexOfTab(const std::string& title) const {
        for (size_t i = 0; i < tabs.size(); ++i)
            if (tabs[i].title == title) return static_cast<int>(i);
        return -1;
    }

    // Index at location (stub)
    int indexAtLocation(int /*x*/, int /*y*/) const {
        // always -1 or something
        return -1;
    }

    // UI
    std::string getUIClassID() const { return "TabbedPaneUI"; }
    TabbedPaneUI* getUI() const { return ui; }
    void setUI(TabbedPaneUI* newUI) { ui = newUI; }
    void updateUI() { /* stub */ }

    // Model
    SingleSelectionModel* getModel() const { return selectionModel; }
    void setModel(SingleSelectionModel* model) { selectionModel = model; }

    // Change listeners
    void addChangeListener(ChangeListener* listener) {
        changeListeners.push_back(listener);
        // also add to model? model already does, but we keep separate list for getChangeListeners
    }
    void removeChangeListener(ChangeListener* listener) {
        auto it = std::find(changeListeners.begin(), changeListeners.end(), listener);
        if (it != changeListeners.end()) changeListeners.erase(it);
    }
    std::vector<ChangeListener*> getChangeListeners() const {
        return changeListeners;
    }

    // Selected index
    int getSelectedIndex() const { return selectedIndex; }
    void setSelectedIndex(int index) {
        if (selectionModel) {
            selectionModel->setSelectedIndex(index);
        } else {
            selectedIndex = index;
            if (index >= 0 && index < (int)tabs.size())
                selectedComponent = tabs[index].component;
        }
    }

    // Accessible context
    AccessibleContext* getAccessibleContext() { return &accessibleContext; }

    // Add/remove component methods
    // add(Component) - adds as new tab with no title
    void add(Component* comp) {
        addTab("", comp);
    }
    void add(Component* comp, int index) {
        insertTab("", nullptr, comp, "", index);
    }
    void add(const std::string& title, Component* comp) {
        addTab(title, comp);
    }
    void add(Component* comp, const std::string& constraints) {
        addTab(constraints, comp);
    }
    void add(Component* comp, const std::string& constraints, int index) {
        insertTab(constraints, nullptr, comp, "", index);
    }

    // remove(Component)
    void remove(Component* comp) {
        int idx = indexOfComponent(comp);
        if (idx >= 0) removeTabAt(idx);
    }
    void remove(int index) {
        removeTabAt(index);
    }
    void removeAll() {
        tabs.clear();
        selectedIndex = -1;
        selectedComponent = nullptr;
    }
};

// =============================================================================
// C++ test functions (one-to-one translation of Java @Test methods)
// =============================================================================

// Since the original Java tests are parameterized, we reproduce the same parameter lists.
// We assume an appropriate test framework would call these with actual values.
// For completeness, we define them as free functions.

void setTabPlacement_test_7732(int p0) {
    JTabbedPane instance;
    instance.setTabPlacement(p0);
}

void setTabLayoutPolicy_test_7733(int p0) {
    JTabbedPane instance;
    instance.setTabLayoutPolicy(p0);
}

void getTabCount_test_7734() {
    JTabbedPane instance;
    instance.getTabCount();
}

void setDisabledIconAt_test_7735(int p0, Icon* p1) {
    JTabbedPane instance;
    instance.setDisabledIconAt(p0, p1);
}

void indexOfComponent_test_7736(Component* p0) {
    JTabbedPane instance;
    instance.indexOfComponent(p0);
}

void removeTabAt_test_7737(int p0) {
    JTabbedPane instance;
    instance.removeTabAt(p0);
}

void insertTab_test_7738(const std::string& p0, Icon* p1, Component* p2, const std::string& p3, int p4) {
    JTabbedPane instance;
    instance.insertTab(p0, p1, p2, p3, p4);
}

void addTab_test_7739(const std::string& p0, Icon* p1, Component* p2, const std::string& p3) {
    JTabbedPane instance;
    instance.addTab(p0, p1, p2, p3);
}

void addTab_test_7740(const std::string& p0, Component* p1) {
    JTabbedPane instance;
    instance.addTab(p0, p1);
}

void addTab_test_7741(const std::string& p0, Icon* p1, Component* p2) {
    JTabbedPane instance;
    instance.addTab(p0, p1, p2);
}

void setTabComponentAt_test_7742(int p0, Component* p1) {
    JTabbedPane instance;
    instance.setTabComponentAt(p0, p1);
}

void getSelectedComponent_test_7743() {
    JTabbedPane instance;
    instance.getSelectedComponent();
}

void getTabRunCount_test_7744() {
    JTabbedPane instance;
    instance.getTabRunCount();
}

void isEnabledAt_test_7745(int p0) {
    JTabbedPane instance;
    instance.isEnabledAt(p0);
}

void getBoundsAt_test_7746(int p0) {
    JTabbedPane instance;
    instance.getBoundsAt(p0);
}

void getTitleAt_test_7747(int p0) {
    JTabbedPane instance;
    instance.getTitleAt(p0);
}

void getIconAt_test_7748(int p0) {
    JTabbedPane instance;
    instance.getIconAt(p0);
}

void getTabComponentAt_test_7749(int p0) {
    JTabbedPane instance;
    instance.getTabComponentAt(p0);
}

void indexOfTabComponent_test_7750(Component* p0) {
    JTabbedPane instance;
    instance.indexOfTabComponent(p0);
}

void getTabPlacement_test_7751() {
    JTabbedPane instance;
    instance.getTabPlacement();
}

void getTabLayoutPolicy_test_7752() {
    JTabbedPane instance;
    instance.getTabLayoutPolicy();
}

void setSelectedComponent_test_7753(Component* p0) {
    JTabbedPane instance;
    instance.setSelectedComponent(p0);
}

void getDisabledIconAt_test_7754(int p0) {
    JTabbedPane instance;
    instance.getDisabledIconAt(p0);
}

void getToolTipTextAt_test_7755(int p0) {
    JTabbedPane instance;
    instance.getToolTipTextAt(p0);
}

void getBackgroundAt_test_7756(int p0) {
    JTabbedPane instance;
    instance.getBackgroundAt(p0);
}

void getForegroundAt_test_7757(int p0) {
    JTabbedPane instance;
    instance.getForegroundAt(p0);
}

void getMnemonicAt_test_7758(int p0) {
    JTabbedPane instance;
    instance.getMnemonicAt(p0);
}

void getDisplayedMnemonicIndexAt_test_7759(int p0) {
    JTabbedPane instance;
    instance.getDisplayedMnemonicIndexAt(p0);
}

void setTitleAt_test_7760(int p0, const std::string& p1) {
    JTabbedPane instance;
    instance.setTitleAt(p0, p1);
}

void setIconAt_test_7761(int p0, Icon* p1) {
    JTabbedPane instance;
    instance.setIconAt(p0, p1);
}

void setToolTipTextAt_test_7762(int p0, const std::string& p1) {
    JTabbedPane instance;
    instance.setToolTipTextAt(p0, p1);
}

void setBackgroundAt_test_7763(int p0, const Color& p1) {
    JTabbedPane instance;
    instance.setBackgroundAt(p0, p1);
}

void setForegroundAt_test_7764(int p0, const Color& p1) {
    JTabbedPane instance;
    instance.setForegroundAt(p0, p1);
}

void setEnabledAt_test_7765(int p0, bool p1) {
    JTabbedPane instance;
    instance.setEnabledAt(p0, p1);
}

void setComponentAt_test_7766(int p0, Component* p1) {
    JTabbedPane instance;
    instance.setComponentAt(p0, p1);
}

void setDisplayedMnemonicIndexAt_test_7767(int p0, int p1) {
    JTabbedPane instance;
    instance.setDisplayedMnemonicIndexAt(p0, p1);
}

void setMnemonicAt_test_7768(int p0, int p1) {
    JTabbedPane instance;
    instance.setMnemonicAt(p0, p1);
}

void indexOfTab_test_7769(Icon* p0) {
    JTabbedPane instance;
    instance.indexOfTab(p0);
}

void indexOfTab_test_7770(const std::string& p0) {
    JTabbedPane instance;
    instance.indexOfTab(p0);
}

void indexAtLocation_test_7771(int p0, int p1) {
    JTabbedPane instance;
    instance.indexAtLocation(p0, p1);
}

void getToolTipText_test_7772(MouseEvent* p0) {
    JTabbedPane instance;
    instance.getToolTipText(p0);
}

void getUIClassID_test_7773() {
    JTabbedPane instance;
    instance.getUIClassID();
}

void getUI_test_7774() {
    JTabbedPane instance;
    instance.getUI();
}

void setUI_test_7775(TabbedPaneUI* p0) {
    JTabbedPane instance;
    instance.setUI(p0);
}

void getModel_test_7776() {
    JTabbedPane instance;
    instance.getModel();
}

void addChangeListener_test_7777(ChangeListener* p0) {
    JTabbedPane instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_7778(ChangeListener* p0) {
    JTabbedPane instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_7779() {
    JTabbedPane instance;
    instance.getChangeListeners();
}

void setModel_test_7780(SingleSelectionModel* p0) {
    JTabbedPane instance;
    instance.setModel(p0);
}

void setSelectedIndex_test_7781(int p0) {
    JTabbedPane instance;
    instance.setSelectedIndex(p0);
}

void getAccessibleContext_test_7782() {
    JTabbedPane instance;
    instance.getAccessibleContext();
}

void getComponentAt_test_7783(int p0) {
    JTabbedPane instance;
    instance.getComponentAt(p0);
}

void getSelectedIndex_test_7784() {
    JTabbedPane instance;
    instance.getSelectedIndex();
}

void updateUI_test_7785() {
    JTabbedPane instance;
    instance.updateUI();
}

void remove_test_7786(Component* p0) {
    JTabbedPane instance;
    instance.remove(p0);
}

void remove_test_7787(int p0) {
    JTabbedPane instance;
    instance.remove(p0);
}

void add_test_7788(Component* p0, int p1) {
    JTabbedPane instance;
    instance.add(p0, p1);
}

void add_test_7789(const std::string& p0, Component* p1) {
    JTabbedPane instance;
    instance.add(p0, p1);
}

void add_test_7790(Component* p0) {
    JTabbedPane instance;
    instance.add(p0);
}

void add_test_7791(Component* p0, const std::string& p1) {
    JTabbedPane instance;
    instance.add(p0, p1);
}

void add_test_7792(Component* p0, const std::string& p1, int p2) {
    JTabbedPane instance;
    instance.add(p0, p1, p2);
}

void removeAll_test_7793() {
    JTabbedPane instance;
    instance.removeAll();
}
```