```cpp
#include <string>
#include <iostream>
#include <cstring>
#include <cstddef>
#include <functional>

// ---------------------------------------------------------------------
// Base class to mimic Java Object (minimal)
// ---------------------------------------------------------------------
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object* other) const {
        // Default: reference equality
        return this == other;
    }
    virtual std::string toString() const {
        // Default: class name + hash code
        return "Object@" + std::to_string(hashCode());
    }
    virtual std::size_t hashCode() const {
        // Default: use address as hash (like identityHashCode)
        return reinterpret_cast<std::size_t>(this);
    }
};

// ---------------------------------------------------------------------
// JMXPrincipal class (mimics javax.management.remote.JMXPrincipal)
// ---------------------------------------------------------------------
class JMXPrincipal : public Object {
private:
    std::string name;

public:
    explicit JMXPrincipal(const std::string& name) : name(name) {}

    const std::string& getName() const {
        return name;
    }

    bool equals(const Object* other) const override {
        if (other == nullptr) return false;
        const JMXPrincipal* jmx = dynamic_cast<const JMXPrincipal*>(other);
        if (jmx == nullptr) return false;
        return name == jmx->name;
    }

    std::string toString() const override {
        return "JMXPrincipal: " + name;
    }

    std::size_t hashCode() const override {
        // Mimics String.hashCode() in Java (simple version)
        std::size_t h = 0;
        for (char c : name) {
            h = 31 * h + static_cast<std::size_t>(c);
        }
        return h;
    }
};

// ---------------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ---------------------------------------------------------------------

void getName_test_5834(const std::string& c0) {
    JMXPrincipal instance(c0);
    std::string result = instance.getName();
    // No assertion, just call (original Java test does the same)
    (void)result;
}

void equals_test_5835(const Object* p0, const std::string& c0) {
    JMXPrincipal instance(c0);
    bool result = instance.equals(p0);
    (void)result;
}

void toString_test_5836(const std::string& c0) {
    JMXPrincipal instance(c0);
    std::string result = instance.toString();
    (void)result;
}

void hashCode_test_5837(const std::string& c0) {
    JMXPrincipal instance(c0);
    std::size_t result = instance.hashCode();
    (void)result;
}

// ---------------------------------------------------------------------
// Main: call all test functions with example data
// ---------------------------------------------------------------------
int main() {
    // Example arguments for the tests
    std::string name1 = "testUser";
    JMXPrincipal other(name1);
    std::string name2 = "differentUser";

    getName_test_5834(name1);
    equals_test_5835(&other, name1);       // test equals with same name
    equals_test_5835(nullptr, name1);      // test equals with null
    toString_test_5836(name1);
    hashCode_test_5837(name1);

    std::cout << "All test functions executed successfully." << std::endl;
    return 0;
}
```