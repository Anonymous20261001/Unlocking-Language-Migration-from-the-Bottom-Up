```cpp
#include <gtest/gtest.h>

// Forward declaration
class JComponent;

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicTextPaneUI class with API matching Java
class BasicTextPaneUI {
public:
    // Non-static method: installUI
    void installUI(JComponent* /*c*/) {
        // No-op implementation; in real Swing this sets up the UI delegate
    }

    // Static method: createUI (factory)
    static BasicTextPaneUI* createUI(JComponent* /*c*/) {
        // Returns a new instance; caller is responsible for deletion
        return new BasicTextPaneUI();
    }
};

// Test functions (one per @Test method)
void installUI_test_9012(JComponent* p0) {
    BasicTextPaneUI instance;
    instance.installUI(p0);
}

void createUI_test_9013(JComponent* p0) {
    BasicTextPaneUI::createUI(p0);  // Return value ignored, matches Java test
}

// Optional main to run tests if using Google Test manually; not required
// int main(int argc, char** argv) {
//     ::testing::InitGoogleTest(&argc, argv);
//     return RUN_ALL_TESTS();
// }
```