```cpp
#include <iostream>
#include <string>
#include <functional>
#include <chrono>
#include <exception>

// Minimal Object base class (Java-like)
class Object {
public:
    virtual ~Object() = default;
};

// Runnable interface (Java-like)
class Runnable {
public:
    virtual void run() = 0;
    virtual ~Runnable() = default;
};

// Simple wrapper to adapt std::function to Runnable
class RunnableImpl : public Runnable {
public:
    explicit RunnableImpl(std::function<void()> func) : func_(std::move(func)) {}
    void run() override { func_(); }
private:
    std::function<void()> func_;
};

// Throwable class (simplified)
class Throwable {
public:
    virtual const char* what() const { return "Throwable"; }
    virtual ~Throwable() = default;
};

// InvocationEvent equivalent to java.awt.event.InvocationEvent
class InvocationEvent : public Object {
public:
    // Constructor: source (Object), runnable (Runnable)
    InvocationEvent(Object* source, Runnable* runnable)
        : source_(source), runnable_(runnable),
          when_(std::chrono::system_clock::now().time_since_epoch().count()),
          dispatched_(false), throwable_(nullptr) {}

    // Constructor with Runnable as std::function (convenience)
    InvocationEvent(Object* source, std::function<void()> func)
        : InvocationEvent(source, new RunnableImpl(std::move(func))) {}

    long long getWhen() const {
        return when_;
    }

    bool isDispatched() const {
        return dispatched_;
    }

    Throwable* getThrowable() const {
        return throwable_;
    }

    void dispatch() {
        if (!dispatched_ && runnable_ != nullptr) {
            try {
                runnable_->run();
            } catch (...) {
                throwable_ = new Throwable(); // simplified: store a generic throwable
                // In real implementation, we might capture the exception.
            }
            dispatched_ = true;
        }
    }

    // In Java, getException() returns the Throwable if any, otherwise null.
    // It is the same as getThrowable() in this implementation.
    Throwable* getException() const {
        return throwable_;
    }

    std::string paramString() const {
        std::string result = "INVOCATION_EVENT";
        result += ",when=" + std::to_string(when_);
        result += ",dispatched=" + std::to_string(dispatched_);
        result += ",throwable=" + (throwable_ ? "present" : "null");
        return result;
    }

private:
    Object* source_;
    Runnable* runnable_;
    long long when_;
    bool dispatched_;
    Throwable* throwable_; // owned? In Java, it's a reference; we assume ownership.
};

// ---------- Test functions (translated from Java @Test methods) ----------

void getWhen_test_772(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.getWhen();
}

void isDispatched_test_773(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.isDispatched();
}

void getThrowable_test_774(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.getThrowable();
}

void dispatch_test_775(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.dispatch();
}

void getException_test_776(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.getException();
}

void paramString_test_777(Object* c0, Runnable* c1) {
    InvocationEvent instance(c0, c1);
    instance.paramString();
}

// Example usage (if needed for compilation, not part of tests)
int main() {
    // Just to verify compilation
    Object obj;
    RunnableImpl run([](){ std::cout << "Run!" << std::endl; });
    getWhen_test_772(&obj, &run);
    paramString_test_777(&obj, &run);
    return 0;
}
```