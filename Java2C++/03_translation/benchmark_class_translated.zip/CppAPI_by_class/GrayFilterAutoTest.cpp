```cpp
#include <cstdint>

// Minimal Image class (Java's java.awt.Image is abstract; we don't need any functionality)
struct Image {
    virtual ~Image() = default;
};

// C++ equivalent of javax.swing.GrayFilter
class GrayFilter {
public:
    GrayFilter(bool brightness, int percent)
        : brightness_(brightness), percent_(percent) {}

    // Static method: create a disabled image (stub returns the same image pointer)
    static Image* createDisabledImage(Image* img) {
        // In reality, this would create a new grayscale version of the image.
        // For test stub, we simply return the input.
        return img;
    }

    // Instance method: convert a single pixel to grayscale (preserves alpha)
    int filterRGB(int x, int y, int rgb) const {
        // Extract components
        int a = (rgb >> 24) & 0xFF;
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;

        // Luminosity grayscale conversion
        int gray = (r * 299 + g * 587 + b * 114) / 1000;

        // Build new pixel (grayscale with original alpha)
        return (a << 24) | (gray << 16) | (gray << 8) | gray;
    }

private:
    bool brightness_;
    int percent_;
};

// Test functions (translated from Java @Test methods)
void createDisabledImage_test_6804(Image* p0, bool c0, int c1) {
    GrayFilter instance(c0, c1);
    GrayFilter::createDisabledImage(p0);
}

void filterRGB_test_6805(int p0, int p1, int p2, bool c0, int c1) {
    GrayFilter instance(c0, c1);
    instance.filterRGB(p0, p1, p2);
}
```