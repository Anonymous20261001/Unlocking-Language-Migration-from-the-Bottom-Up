```cpp
#include <iostream>
#include <cassert>

// Minimal JComponent class to satisfy the interface
class JComponent {
public:
    virtual ~JComponent() = default;
    // Additional methods as needed, but for this test minimal is fine
};

// BasicViewportUI class matching Java's javax.swing.plaf.basic.BasicViewportUI
class BasicViewportUI {
public:
    // installUI: called to install the UI on a JComponent
    void installUI(JComponent* c) {
        // In a real implementation, this would set up listeners, install defaults, etc.
        // For testing, we just mark that it was called.
        std::cout << "BasicViewportUI::installUI called" << std::endl;
    }

    // uninstallUI: called to uninstall the UI from a JComponent
    void uninstallUI(JComponent* c) {
        std::cout << "BasicViewportUI::uninstallUI called" << std::endl;
    }

    // Static factory method to create a UI delegate for a JComponent
    static BasicViewportUI* createUI(JComponent* c) {
        std::cout << "BasicViewportUI::createUI called" << std::endl;
        return new BasicViewportUI();
    }
};

// Translated test functions (as free functions, preserving Java method names and parameters)
void installUI_test_9070(JComponent* p0) {
    BasicViewportUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_9071(JComponent* p0) {
    BasicViewportUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_9072(JComponent* p0) {
    BasicViewportUI instance;  // Not used, but kept for consistency with Java
    BasicViewportUI* ui = BasicViewportUI::createUI(p0);
    delete ui;  // Clean up to avoid memory leak (original Java does not, but good practice)
}
```