```cpp
#include <string>
#include <vector>
#include <cstddef>
#include <memory>

// Forward declarations
class Component;
class Dimension;
class Insets;
class LayoutManager;
class Action;
class AccessibleContext;
class ToolBarUI;

// ---------------------------------------------------------------------------
// Minimal AWT/Swing types
// ---------------------------------------------------------------------------

class Component {
public:
    virtual ~Component() = default;
    // No-op base
};

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
    Insets(int t, int l, int b, int r) : top(t), left(l), bottom(b), right(r) {}
};

class LayoutManager {
public:
    virtual ~LayoutManager() = default;
    // Stub interface
};

class Action {
public:
    virtual ~Action() = default;
    // Stub interface
};

class AccessibleContext {
public:
    virtual ~AccessibleContext() = default;
    // Stub interface
};

class ToolBarUI {
public:
    virtual ~ToolBarUI() = default;
    // Stub interface
};

// ---------------------------------------------------------------------------
// JToolBar
// ---------------------------------------------------------------------------

class JToolBar : public Component {
public:
    // Orientation constants
    static const int HORIZONTAL = 0;
    static const int VERTICAL = 1;

    JToolBar()
        : floatable_(true)
        , rollover_(false)
        , borderPainted_(true)
        , orientation_(HORIZONTAL)
        , margin_(nullptr)
        , layout_(nullptr)
        , ui_(nullptr)
        , accessibleContext_(std::make_shared<AccessibleContext>())
    {}

    // getUIClassID
    std::string getUIClassID() const {
        return "ToolBarUI";
    }

    // getUI / setUI
    ToolBarUI* getUI() const {
        return ui_.get();
    }

    void setUI(ToolBarUI* ui) {
        ui_.reset(ui);
    }

    // floatable
    bool isFloatable() const {
        return floatable_;
    }

    void setFloatable(bool b) {
        floatable_ = b;
    }

    // rollover
    bool isRollover() const {
        return rollover_;
    }

    void setRollover(bool b) {
        rollover_ = b;
    }

    // getComponentAtIndex
    Component* getComponentAtIndex(int index) {
        if (index >= 0 && index < static_cast<int>(components_.size())) {
            return components_[index];
        }
        return nullptr;
    }

    const Component* getComponentAtIndex(int index) const {
        if (index >= 0 && index < static_cast<int>(components_.size())) {
            return components_[index];
        }
        return nullptr;
    }

    // border painted
    bool isBorderPainted() const {
        return borderPainted_;
    }

    void setBorderPainted(bool b) {
        borderPainted_ = b;
    }

    // margin
    void setMargin(Insets* m) {
        if (m) {
            margin_ = std::make_shared<Insets>(*m);
        } else {
            margin_.reset();
        }
    }

    Insets* getMargin() const {
        return margin_.get();
    }

    // accessible context
    AccessibleContext* getAccessibleContext() const {
        return accessibleContext_.get();
    }

    // layout
    void setLayout(LayoutManager* layout) {
        layout_ = layout; // Note: we do not take ownership (Java delegates)
    }

    LayoutManager* getLayout() const {
        return layout_;
    }

    // orientation
    int getOrientation() const {
        return orientation_;
    }

    void setOrientation(int o) {
        orientation_ = o;
    }

    // getComponentIndex
    int getComponentIndex(Component* comp) const {
        for (size_t i = 0; i < components_.size(); ++i) {
            if (components_[i] == comp)
                return static_cast<int>(i);
        }
        return -1;
    }

    // updateUI
    void updateUI() {
        // Java: calls setUI(getUI().getClass().newInstance()) or similar.
        // Simulate by just calling setUI with a new default ToolBarUI.
        setUI(new ToolBarUI());
    }

    // addSeparator
    void addSeparator() {
        // Adds a separator component – ignore for stubs.
    }

    void addSeparator(Dimension* size) {
        (void)size;
        // Adds separator with size – ignore.
    }

    // add(Action)
    Component* add(Action* a) {
        // In Java, add(Action) creates a JButton, associates action, and adds it.
        // For stubs, we just store the action and return a dummy component.
        (void)a;
        Component* dummy = new Component();
        components_.push_back(dummy);
        return dummy;
    }

    // For testing purposes: add a raw Component (not exposed in test but used internally)
    Component* add(Component* comp) {
        components_.push_back(comp);
        return comp;
    }

private:
    bool floatable_;
    bool rollover_;
    bool borderPainted_;
    int orientation_;
    std::shared_ptr<Insets> margin_;
    LayoutManager* layout_;          // not owned
    std::shared_ptr<ToolBarUI> ui_;
    std::shared_ptr<AccessibleContext> accessibleContext_;
    std::vector<Component*> components_; // not owned (Java manages memory)
};

// ---------------------------------------------------------------------------
// Test functions (exactly one per @Test)
// ---------------------------------------------------------------------------

void getUIClassID_test_7998() {
    JToolBar instance;
    instance.getUIClassID();
}

void getUI_test_7999() {
    JToolBar instance;
    instance.getUI();
}

void setUI_test_8000(ToolBarUI* p0) {
    JToolBar instance;
    instance.setUI(p0);
}

void isFloatable_test_8001() {
    JToolBar instance;
    instance.isFloatable();
}

void setFloatable_test_8002(bool p0) {
    JToolBar instance;
    instance.setFloatable(p0);
}

void isRollover_test_8003() {
    JToolBar instance;
    instance.isRollover();
}

void setRollover_test_8004(bool p0) {
    JToolBar instance;
    instance.setRollover(p0);
}

void getComponentAtIndex_test_8005(int p0) {
    JToolBar instance;
    instance.getComponentAtIndex(p0);
}

void isBorderPainted_test_8006() {
    JToolBar instance;
    instance.isBorderPainted();
}

void setBorderPainted_test_8007(bool p0) {
    JToolBar instance;
    instance.setBorderPainted(p0);
}

void setMargin_test_8008(Insets* p0) {
    JToolBar instance;
    instance.setMargin(p0);
}

void getMargin_test_8009() {
    JToolBar instance;
    instance.getMargin();
}

void getAccessibleContext_test_8010() {
    JToolBar instance;
    instance.getAccessibleContext();
}

void setLayout_test_8011(LayoutManager* p0) {
    JToolBar instance;
    instance.setLayout(p0);
}

void getOrientation_test_8012() {
    JToolBar instance;
    instance.getOrientation();
}

void getComponentIndex_test_8013(Component* p0) {
    JToolBar instance;
    instance.getComponentIndex(p0);
}

void updateUI_test_8014() {
    JToolBar instance;
    instance.updateUI();
}

void addSeparator_test_8015() {
    JToolBar instance;
    instance.addSeparator();
}

void addSeparator_test_8016(Dimension* p0) {
    JToolBar instance;
    instance.addSeparator(p0);
}

void setOrientation_test_8017(int p0) {
    JToolBar instance;
    instance.setOrientation(p0);
}

void add_test_8018(Action* p0) {
    JToolBar instance;
    instance.add(p0);
}
```