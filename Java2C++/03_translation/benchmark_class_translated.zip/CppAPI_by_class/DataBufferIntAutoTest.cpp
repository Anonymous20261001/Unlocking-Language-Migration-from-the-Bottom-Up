```cpp
#include <vector>

class DataBufferInt {
private:
    int numBanks;
    std::vector<std::vector<int>> banks;

public:
    // Constructor with one bank of given size
    DataBufferInt(int size) : numBanks(1) {
        banks.push_back(std::vector<int>(size));
    }

    // Returns reference to internal bank array (non-const for modification)
    std::vector<std::vector<int>>& getBankData() {
        return banks;
    }

    // Returns const reference to internal bank array
    const std::vector<std::vector<int>>& getBankData() const {
        return banks;
    }

    // Get element from a specific bank and index
    int getElem(int bank, int i) const {
        return banks[bank][i];
    }

    // Get element from first bank (bank=0)
    int getElem(int i) const {
        return banks[0][i];
    }

    // Set element in a specific bank and index
    void setElem(int bank, int i, int val) {
        banks[bank][i] = val;
    }

    // Set element in first bank (bank=0)
    void setElem(int i, int val) {
        banks[0][i] = val;
    }

    // Get pointer to data array of a specific bank (non-const)
    int* getData(int bank) {
        return banks[bank].data();
    }

    // Get pointer to data array of a specific bank (const)
    const int* getData(int bank) const {
        return banks[bank].data();
    }

    // Get pointer to data array of first bank (non-const)
    int* getData() {
        return banks[0].data();
    }

    // Get pointer to data array of first bank (const)
    const int* getData() const {
        return banks[0].data();
    }
};

// Test functions (exact translations of Java @Test methods)
void getBankData_test_1220(int c0) {
    DataBufferInt instance(c0);
    instance.getBankData();
}

void getElem_test_1221(int p0, int p1, int c0) {
    DataBufferInt instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1222(int p0, int c0) {
    DataBufferInt instance(c0);
    instance.getElem(p0);
}

void setElem_test_1223(int p0, int p1, int p2, int c0) {
    DataBufferInt instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1224(int p0, int p1, int c0) {
    DataBufferInt instance(c0);
    instance.setElem(p0, p1);
}

void getData_test_1225(int p0, int c0) {
    DataBufferInt instance(c0);
    instance.getData(p0);
}

void getData_test_1226(int c0) {
    DataBufferInt instance(c0);
    instance.getData();
}
```