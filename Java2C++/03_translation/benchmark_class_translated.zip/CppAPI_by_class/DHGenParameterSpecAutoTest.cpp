```cpp
#include <cstdint>

class DHGenParameterSpec {
private:
    int primeSize;
    int exponentSize;

public:
    DHGenParameterSpec(int primeSize, int exponentSize)
        : primeSize(primeSize), exponentSize(exponentSize) {}

    int getPrimeSize() const {
        return primeSize;
    }

    int getExponentSize() const {
        return exponentSize;
    }
};

void getPrimeSize_test_5236(int c0, int c1) {
    DHGenParameterSpec instance(c0, c1);
    instance.getPrimeSize();
}

void getExponentSize_test_5237(int c0, int c1) {
    DHGenParameterSpec instance(c0, c1);
    instance.getExponentSize();
}
```