```cpp
#include <vector>
#include <cstdint>

class DataBufferFloat {
public:
    // Single-bank constructor: creates one bank with given size
    explicit DataBufferFloat(int size) {
        data_.resize(1);
        data_[0].resize(size, 0.0f);
    }

    // Returns the internal bank data as a vector of vectors (reference)
    std::vector<std::vector<float>>& getBankData() {
        return data_;
    }

    // Const version for safety (not required by tests)
    const std::vector<std::vector<float>>& getBankData() const {
        return data_;
    }

    // Two-argument getElem returns int from specified bank and index
    int getElem(int bank, int i) const {
        return static_cast<int>(data_[bank][i]);
    }

    // One-argument getElem returns int from bank 0
    int getElem(int i) const {
        return static_cast<int>(data_[0][i]);
    }

    // One-argument getElemFloat returns float from bank 0
    float getElemFloat(int i) const {
        return data_[0][i];
    }

    // Two-argument getElemFloat returns float from specified bank and index
    float getElemFloat(int bank, int i) const {
        return data_[bank][i];
    }

    // One-argument getElemDouble returns double from bank 0
    double getElemDouble(int i) const {
        return static_cast<double>(data_[0][i]);
    }

    // Two-argument getElemDouble returns double from specified bank and index
    double getElemDouble(int bank, int i) const {
        return static_cast<double>(data_[bank][i]);
    }

    // Three-argument setElem sets int value into specified bank and index
    void setElem(int bank, int i, int val) {
        data_[bank][i] = static_cast<float>(val);
    }

    // Two-argument setElem sets int value into bank 0
    void setElem(int i, int val) {
        data_[0][i] = static_cast<float>(val);
    }

    // Three-argument setElemFloat sets float value into specified bank and index
    void setElemFloat(int bank, int i, float val) {
        data_[bank][i] = val;
    }

    // Two-argument setElemFloat sets float value into bank 0
    void setElemFloat(int i, float val) {
        data_[0][i] = val;
    }

    // Two-argument setElemDouble sets double value into bank 0
    void setElemDouble(int i, double val) {
        data_[0][i] = static_cast<float>(val);
    }

    // Three-argument setElemDouble sets double value into specified bank and index
    void setElemDouble(int bank, int i, double val) {
        data_[bank][i] = static_cast<float>(val);
    }

    // One-argument getData returns bank 0 as vector reference
    std::vector<float>& getData() {
        return data_[0];
    }

    const std::vector<float>& getData() const {
        return data_[0];
    }

    // Two-argument getData returns specified bank as vector reference
    std::vector<float>& getData(int bank) {
        return data_[bank];
    }

    const std::vector<float>& getData(int bank) const {
        return data_[bank];
    }

private:
    // Internal storage: one vector per bank
    std::vector<std::vector<float>> data_;
};

// Test function implementations (exact signatures from Java)
void getBankData_test_1205(int c0) {
    DataBufferFloat instance(c0);
    instance.getBankData();
}

void getElem_test_1206(int p0, int p1, int c0) {
    DataBufferFloat instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1207(int p0, int c0) {
    DataBufferFloat instance(c0);
    instance.getElem(p0);
}

void getElemFloat_test_1208(int p0, int c0) {
    DataBufferFloat instance(c0);
    instance.getElemFloat(p0);
}

void getElemFloat_test_1209(int p0, int p1, int c0) {
    DataBufferFloat instance(c0);
    instance.getElemFloat(p0, p1);
}

void getElemDouble_test_1210(int p0, int c0) {
    DataBufferFloat instance(c0);
    instance.getElemDouble(p0);
}

void getElemDouble_test_1211(int p0, int p1, int c0) {
    DataBufferFloat instance(c0);
    instance.getElemDouble(p0, p1);
}

void setElem_test_1212(int p0, int p1, int p2, int c0) {
    DataBufferFloat instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1213(int p0, int p1, int c0) {
    DataBufferFloat instance(c0);
    instance.setElem(p0, p1);
}

void setElemFloat_test_1214(int p0, int p1, float p2, int c0) {
    DataBufferFloat instance(c0);
    instance.setElemFloat(p0, p1, p2);
}

void setElemFloat_test_1215(int p0, float p1, int c0) {
    DataBufferFloat instance(c0);
    instance.setElemFloat(p0, p1);
}

void setElemDouble_test_1216(int p0, double p1, int c0) {
    DataBufferFloat instance(c0);
    instance.setElemDouble(p0, p1);
}

void setElemDouble_test_1217(int p0, int p1, double p2, int c0) {
    DataBufferFloat instance(c0);
    instance.setElemDouble(p0, p1, p2);
}

void getData_test_1218(int p0, int c0) {
    DataBufferFloat instance(c0);
    instance.getData(p0);
}

void getData_test_1219(int c0) {
    DataBufferFloat instance(c0);
    instance.getData();
}
```