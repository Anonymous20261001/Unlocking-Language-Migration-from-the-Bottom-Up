```cpp
#include <string>
#include <ostream>
#include <functional>
#include <cstddef>
#include <typeinfo>

// ============================================================================
// Base class Object (mimics java.lang.Object)
// ============================================================================
class Object {
public:
    virtual ~Object() = default;

    virtual std::string toString() const {
        return "Object";
    }

    virtual size_t hashCode() const {
        return reinterpret_cast<size_t>(this);
    }

    virtual bool equals(const Object& other) const {
        return this == &other;
    }
};

// ============================================================================
// Forward declaration of Format and its nested class Field
// ============================================================================
class Format {
public:
    class Field : public Object {
    public:
        // Optional name for debugging/toString
        Field(const std::string& name = "Field") : name_(name) {}

        std::string toString() const override {
            return "Format::Field(" + name_ + ")";
        }

        size_t hashCode() const override {
            // Combine hash of type and name
            return std::hash<std::string>()(name_) ^
                   std::hash<std::string>()(typeid(Field).name());
        }

        bool equals(const Object& other) const override {
            // Only equal to another Field with same type and name
            const Field* f = dynamic_cast<const Field*>(&other);
            return f != nullptr && f->name_ == name_;
        }

    private:
        std::string name_;
    };
};

// ============================================================================
// FieldPosition class (mimics java.text.FieldPosition)
// ============================================================================
class FieldPosition : public Object {
public:
    // Constructors matching Java API
    explicit FieldPosition(int field)
        : field_(field), attribute_(nullptr), beginIndex_(0), endIndex_(0) {}

    explicit FieldPosition(const Format::Field* attribute)
        : field_(-1), attribute_(attribute), beginIndex_(0), endIndex_(0) {}

    // Copy constructor and assignment (not in Java but needed for safety)
    FieldPosition(const FieldPosition&) = default;
    FieldPosition& operator=(const FieldPosition&) = default;

    // --- API methods ---

    int getField() const {
        return field_;
    }

    const Format::Field* getFieldAttribute() const {
        return attribute_;
    }

    void setBeginIndex(int bi) {
        beginIndex_ = bi;
    }

    void setEndIndex(int ei) {
        endIndex_ = ei;
    }

    int getBeginIndex() const {
        return beginIndex_;
    }

    int getEndIndex() const {
        return endIndex_;
    }

    // Override Object methods
    std::string toString() const override {
        std::string result = "FieldPosition[field=" + std::to_string(field_);
        if (attribute_) {
            result += ", attribute=" + attribute_->toString();
        }
        result += ", beginIndex=" + std::to_string(beginIndex_);
        result += ", endIndex=" + std::to_string(endIndex_) + "]";
        return result;
    }

    size_t hashCode() const override {
        // Combine hash of field, attribute (if present), begin, end
        size_t h = std::hash<int>()(field_);
        if (attribute_) {
            h ^= attribute_->hashCode();
        }
        h ^= std::hash<int>()(beginIndex_);
        h ^= std::hash<int>()(endIndex_);
        return h;
    }

    bool equals(const Object& other) const override {
        const FieldPosition* fp = dynamic_cast<const FieldPosition*>(&other);
        if (fp == nullptr) return false;

        // Field equality: compare field integer and attribute
        if (field_ != fp->field_) return false;
        if (attribute_ == nullptr && fp->attribute_ != nullptr) return false;
        if (attribute_ != nullptr && fp->attribute_ == nullptr) return false;
        if (attribute_ && !attribute_->equals(*fp->attribute_)) return false;

        // Indices must match
        return (beginIndex_ == fp->beginIndex_ &&
                endIndex_ == fp->endIndex_);
    }

private:
    int field_;
    const Format::Field* attribute_;   // could be nullptr
    int beginIndex_;
    int endIndex_;
};

// ============================================================================
// Test function definitions (each corresponds to one @Test method)
// ============================================================================

// equals_test_3166
void equals_test_3166(Object* p0, Format::Field* c0) {
    FieldPosition instance(c0);
    instance.equals(*p0);
}

// toString_test_3167
void toString_test_3167(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.toString();
}

// hashCode_test_3168
void hashCode_test_3168(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.hashCode();
}

// getField_test_3169
void getField_test_3169(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.getField();
}

// setBeginIndex_test_3170
void setBeginIndex_test_3170(int p0, Format::Field* c0) {
    FieldPosition instance(c0);
    instance.setBeginIndex(p0);
}

// setEndIndex_test_3171
void setEndIndex_test_3171(int p0, Format::Field* c0) {
    FieldPosition instance(c0);
    instance.setEndIndex(p0);
}

// getFieldAttribute_test_3172
void getFieldAttribute_test_3172(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.getFieldAttribute();
}

// getBeginIndex_test_3173
void getBeginIndex_test_3173(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.getBeginIndex();
}

// getEndIndex_test_3174
void getEndIndex_test_3174(Format::Field* c0) {
    FieldPosition instance(c0);
    instance.getEndIndex();
}
```