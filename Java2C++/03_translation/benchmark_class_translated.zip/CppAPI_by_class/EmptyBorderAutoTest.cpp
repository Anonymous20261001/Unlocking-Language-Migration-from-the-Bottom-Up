```cpp
#include <cstddef>

class Component {
public:
    virtual ~Component() = default;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;

    Insets() : top(0), left(0), bottom(0), right(0) {}
    Insets(int top, int left, int bottom, int right)
        : top(top), left(left), bottom(bottom), right(right) {}
};

class EmptyBorder {
private:
    Insets borderInsets;

public:
    EmptyBorder(const Insets& insets) : borderInsets(insets) {}

    void paintBorder(Component* c, Graphics* g, int x, int y, int width, int height) {
        // EmptyBorder does nothing
    }

    Insets* getBorderInsets(Component* c, Insets* insets) {
        if (insets) {
            insets->top = borderInsets.top;
            insets->left = borderInsets.left;
            insets->bottom = borderInsets.bottom;
            insets->right = borderInsets.right;
        }
        return insets;
    }

    Insets getBorderInsets() const {
        return borderInsets; // returns a copy
    }

    bool isBorderOpaque() const {
        return false;
    }
};

// Test functions (exact translations of the Java @Test methods)

void paintBorder_test_8464(Component* p0, Graphics* p1, int p2, int p3, int p4, int p5,
                           const Insets& c0) {
    EmptyBorder instance(c0);
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
}

void getBorderInsets_test_8465(Component* p0, Insets* p1, const Insets& c0) {
    EmptyBorder instance(c0);
    instance.getBorderInsets(p0, p1);
}

void getBorderInsets_test_8466(const Insets& c0) {
    EmptyBorder instance(c0);
    instance.getBorderInsets();
}

void isBorderOpaque_test_8467(const Insets& c0) {
    EmptyBorder instance(c0);
    instance.isBorderOpaque();
}
```