```cpp
#include <string>

// Minimal C++ equivalent of Java's BigInteger for this context.
// We use std::string to represent large integers since the test only stores and retrieves them.
// No arithmetic is performed in these tests.

class DHPublicKeySpec {
private:
    std::string y;
    std::string p;
    std::string g;

public:
    // Constructor matching Java's DHPublicKeySpec(BigInteger y, BigInteger p, BigInteger g)
    DHPublicKeySpec(const std::string& y, const std::string& p, const std::string& g)
        : y(y), p(p), g(g) {}

    // Getter methods matching the Java API
    std::string getY() const { return y; }
    std::string getP() const { return p; }
    std::string getG() const { return g; }
};

// Test functions translated from the Java JUnit tests.
// They take three std::string parameters representing the three BigInteger arguments.

void getP_test_5244(const std::string& c0, const std::string& c1, const std::string& c2) {
    DHPublicKeySpec instance(c0, c1, c2);
    instance.getP();
}

void getG_test_5245(const std::string& c0, const std::string& c1, const std::string& c2) {
    DHPublicKeySpec instance(c0, c1, c2);
    instance.getG();
}

void getY_test_5246(const std::string& c0, const std::string& c1, const std::string& c2) {
    DHPublicKeySpec instance(c0, c1, c2);
    instance.getY();
}
```