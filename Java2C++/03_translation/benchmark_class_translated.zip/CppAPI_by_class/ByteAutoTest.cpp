```cpp
#include <cstdint>
#include <string>
#include <optional>
#include <cstring>
#include <stdexcept>

// Minimal Object base class for polymorphic equals
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other; // default identity comparison
    }
    virtual std::string toString() const {
        return "Object@" + std::to_string(reinterpret_cast<uintptr_t>(this));
    }
    virtual int hashCode() const {
        return static_cast<int>(reinterpret_cast<uintptr_t>(this));
    }
};

// Byte class mimicking java.lang.Byte
class Byte : public Object {
private:
    int8_t value;

public:
    explicit Byte(int8_t val) : value(val) {}

    // Instance methods
    bool equals(const Object& other) const override {
        auto* rhs = dynamic_cast<const Byte*>(&other);
        return rhs != nullptr && value == rhs->value;
    }

    std::string toString() const override {
        return std::to_string(value);
    }

    int hashCode() const override {
        return static_cast<int>(value);
    }

    int compareTo(const Byte& other) const {
        return static_cast<int>(value) - static_cast<int>(other.value);
    }

    int8_t byteValue() const { return value; }
    int16_t shortValue() const { return static_cast<int16_t>(value); }
    int32_t intValue() const { return static_cast<int32_t>(value); }
    int64_t longValue() const { return static_cast<int64_t>(value); }
    float   floatValue() const { return static_cast<float>(value); }
    double  doubleValue() const { return static_cast<double>(value); }

    // Returns an optional containing a copy of this Byte
    std::optional<Byte> describeConstable() const {
        return std::make_optional(*this);
    }

    // Static methods
    static std::string toString(int8_t v) {
        return std::to_string(v);
    }

    static int hashCode(int8_t v) {
        return static_cast<int>(v);
    }

    static int compareUnsigned(int8_t x, int8_t y) {
        uint8_t ux = static_cast<uint8_t>(x);
        uint8_t uy = static_cast<uint8_t>(y);
        if (ux < uy) return -1;
        if (ux > uy) return  1;
        return 0;
    }

    static int compare(int8_t x, int8_t y) {
        return static_cast<int>(x) - static_cast<int>(y);
    }

    static Byte valueOf(int8_t v) {
        return Byte(v);
    }

    static uint64_t toUnsignedLong(int8_t v) {
        return static_cast<uint64_t>(static_cast<uint8_t>(v));
    }

    static uint32_t toUnsignedInt(int8_t v) {
        return static_cast<uint32_t>(static_cast<uint8_t>(v));
    }
};

// ============== Test Functions (translated from Java) ==============

void equals_test_1853(const Object& p0, int8_t c0) {
    Byte instance(c0);
    instance.equals(p0);
}

void toString_test_1854(int8_t c0) {
    Byte instance(c0);
    instance.toString();
}

void toString_test_1855(int8_t p0, int8_t c0) {
    Byte instance(c0);
    Byte::toString(p0);
}

void hashCode_test_1856(int8_t p0, int8_t c0) {
    Byte instance(c0);
    Byte::hashCode(p0);
}

void hashCode_test_1857(int8_t c0) {
    Byte instance(c0);
    instance.hashCode();
}

void compareUnsigned_test_1858(int8_t p0, int8_t p1, int8_t c0) {
    Byte instance(c0);
    Byte::compareUnsigned(p0, p1);
}

void compareTo_test_1859(const Byte& p0, int8_t c0) {
    Byte instance(c0);
    instance.compareTo(p0);
}

void compare_test_1860(int8_t p0, int8_t p1, int8_t c0) {
    Byte instance(c0);
    Byte::compare(p0, p1);
}

void byteValue_test_1861(int8_t c0) {
    Byte instance(c0);
    instance.byteValue();
}

void shortValue_test_1862(int8_t c0) {
    Byte instance(c0);
    instance.shortValue();
}

void intValue_test_1863(int8_t c0) {
    Byte instance(c0);
    instance.intValue();
}

void longValue_test_1864(int8_t c0) {
    Byte instance(c0);
    instance.longValue();
}

void floatValue_test_1865(int8_t c0) {
    Byte instance(c0);
    instance.floatValue();
}

void doubleValue_test_1866(int8_t c0) {
    Byte instance(c0);
    instance.doubleValue();
}

void valueOf_test_1867(int8_t p0, int8_t c0) {
    Byte instance(c0);
    Byte::valueOf(p0);
}

void describeConstable_test_1868(int8_t c0) {
    Byte instance(c0);
    instance.describeConstable();
}

void toUnsignedLong_test_1869(int8_t p0, int8_t c0) {
    Byte instance(c0);
    Byte::toUnsignedLong(p0);
}

void toUnsignedInt_test_1870(int8_t p0, int8_t c0) {
    Byte instance(c0);
    Byte::toUnsignedInt(p0);
}
```