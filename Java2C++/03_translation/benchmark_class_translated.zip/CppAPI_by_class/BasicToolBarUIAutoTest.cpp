```cpp
#include <cstddef>   // for NULL
#include <utility>   // for std::move

// ------------------------------------------------------------
// Minimal equivalents of Java classes used in the tests
// ------------------------------------------------------------

class Color {
public:
    // Java Color is usually represented by an ARGB int.
    // For this minimal implementation we store a single int.
    int rgb;
    Color() : rgb(0) {}
    explicit Color(int rgb) : rgb(rgb) {}
};

class Point {
public:
    int x;
    int y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class Component {
public:
    virtual ~Component() {}
    // Placeholder for any common component functionality
};

class JComponent : public Component {
public:
    // JComponent specific members (none needed for this minimal test)
};

// ------------------------------------------------------------
// BasicToolBarUI – minimal implementation matching the tested API
// ------------------------------------------------------------
class BasicToolBarUI {
private:
    bool rolloverBorders = false;
    bool floating = false;
    int orientation = 0;       // HORIZONTAL = 0, VERTICAL = 1 (arbitrary)
    Color dockingColor;
    Color floatingColor;
    Point floatingLocation;

public:
    BasicToolBarUI() {}
    ~BasicToolBarUI() {}

    void installUI(JComponent* /*p0*/) {
        // In real Swing this would install the UI delegate.
        // Stub – do nothing.
    }

    void uninstallUI(JComponent* /*p0*/) {
        // Stub – do nothing.
    }

    void setFloating(bool b, const Point& p) {
        floating = b;
        floatingLocation = p;
    }

    bool isRolloverBorders() const {
        return rolloverBorders;
    }

    void setRolloverBorders(bool b) {
        rolloverBorders = b;
    }

    bool canDock(Component* /*c*/, const Point& /*p*/) {
        // In real code this would check docking constraints.
        // Stub – always return true.
        return true;
    }

    Color getDockingColor() const {
        return dockingColor;
    }

    Color getFloatingColor() const {
        return floatingColor;
    }

    void setFloatingLocation(int x, int y) {
        floatingLocation = Point(x, y);
    }

    void setDockingColor(const Color& c) {
        dockingColor = c;
    }

    void setFloatingColor(const Color& c) {
        floatingColor = c;
    }

    // Java static method createUI(JComponent) returns a ComponentUI.
    // We mirror it as a static method returning a BasicToolBarUI*.
    static BasicToolBarUI* createUI(JComponent* /*c*/) {
        return new BasicToolBarUI();
    }

    void setOrientation(int o) {
        orientation = o;
    }

    bool isFloating() const {
        return floating;
    }
};

// ------------------------------------------------------------
// C++ test functions (translated from Java @Test methods)
// ------------------------------------------------------------

void installUI_test_9019(JComponent* p0) {
    BasicToolBarUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_9020(JComponent* p0) {
    BasicToolBarUI instance;
    instance.uninstallUI(p0);
}

void setFloating_test_9021(bool p0, const Point& p1) {
    BasicToolBarUI instance;
    instance.setFloating(p0, p1);
}

void isRolloverBorders_test_9022() {
    BasicToolBarUI instance;
    instance.isRolloverBorders();
}

void setRolloverBorders_test_9023(bool p0) {
    BasicToolBarUI instance;
    instance.setRolloverBorders(p0);
}

void canDock_test_9024(Component* p0, const Point& p1) {
    BasicToolBarUI instance;
    instance.canDock(p0, p1);
}

void getDockingColor_test_9025() {
    BasicToolBarUI instance;
    instance.getDockingColor();
}

void getFloatingColor_test_9026() {
    BasicToolBarUI instance;
    instance.getFloatingColor();
}

void setFloatingLocation_test_9027(int p0, int p1) {
    BasicToolBarUI instance;
    instance.setFloatingLocation(p0, p1);
}

void setDockingColor_test_9028(const Color& p0) {
    BasicToolBarUI instance;
    instance.setDockingColor(p0);
}

void setFloatingColor_test_9029(const Color& p0) {
    BasicToolBarUI instance;
    instance.setFloatingColor(p0);
}

void createUI_test_9030(JComponent* p0) {
    BasicToolBarUI::createUI(p0);
}

void setOrientation_test_9031(int p0) {
    BasicToolBarUI instance;
    instance.setOrientation(p0);
}

void isFloating_test_9032() {
    BasicToolBarUI instance;
    instance.isFloating();
}
```