```cpp
#include <cstdint>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <stdexcept>

// Minimal ByteBuffer (read-only, sequential access)
class ByteBuffer {
public:
    ByteBuffer(const std::vector<uint8_t>& data) : data_(data), pos_(0) {}

    uint8_t get() {
        if (pos_ >= data_.size()) throw std::out_of_range("ByteBuffer::get");
        return data_[pos_++];
    }

    size_t remaining() const {
        return data_.size() - pos_;
    }

private:
    std::vector<uint8_t> data_;
    size_t pos_;
};

// Minimal LongBuffer (read-only, sequential access)
class LongBuffer {
public:
    LongBuffer(const std::vector<int64_t>& data) : data_(data), pos_(0) {}

    int64_t get() {
        if (pos_ >= data_.size()) throw std::out_of_range("LongBuffer::get");
        return data_[pos_++];
    }

    size_t remaining() const {
        return data_.size() - pos_;
    }

private:
    std::vector<int64_t> data_;
    size_t pos_;
};

// C++ equivalent of java.util.BitSet
class BitSet {
public:
    BitSet() : words_(1, 0) {}  // start with one word

    // size(): number of bits allocated (words.size() * 64)
    int64_t size() const {
        return static_cast<int64_t>(words_.size()) * 64;
    }

    // get single bit
    bool get(int bitIndex) const {
        ensureCapacity(bitIndex); // may expand, but const? we'll make mutable? Actually get does not modify, but Java's get does not expand. We'll implement without expansion for const correctness.
        // We'll keep the internal method non-const for expansion, but for get we need to ensure capacity? In Java, get does not expand, but it returns false if index is beyond current length. So we should not expand.
        // We'll check if index is within current words; if not, return false.
        if (bitIndex < 0) throw std::invalid_argument("bitIndex < 0");
        int wordIndex = bitIndex / 64;
        if (wordIndex >= static_cast<int>(words_.size())) return false;
        return (words_[wordIndex] >> (bitIndex % 64)) & 1ULL;
    }

    // get range (returns new BitSet)
    BitSet get(int fromIndex, int toIndex) const {
        if (fromIndex < 0 || toIndex < fromIndex) throw std::invalid_argument("invalid range");
        BitSet result;
        for (int i = fromIndex; i < toIndex; ++i) {
            if (get(i)) result.set(i - fromIndex);
        }
        return result;
    }

    // set single bit
    void set(int bitIndex) {
        ensureCapacity(bitIndex);
        int wordIndex = bitIndex / 64;
        words_[wordIndex] |= (1ULL << (bitIndex % 64));
    }

    // set single bit with value
    void set(int bitIndex, bool value) {
        if (value) set(bitIndex);
        else clear(bitIndex);
    }

    // set range (inclusive? Java's set(from,to) sets bits from from to to-1. We'll follow Java)
    void set(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; ++i) set(i);
    }

    // set range with value
    void set(int fromIndex, int toIndex, bool value) {
        for (int i = fromIndex; i < toIndex; ++i) set(i, value);
    }

    // clear all
    void clear() {
        std::fill(words_.begin(), words_.end(), 0ULL);
    }

    // clear single bit
    void clear(int bitIndex) {
        ensureCapacity(bitIndex);
        int wordIndex = bitIndex / 64;
        words_[wordIndex] &= ~(1ULL << (bitIndex % 64));
    }

    // clear range
    void clear(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; ++i) clear(i);
    }

    // flip single bit
    void flip(int bitIndex) {
        ensureCapacity(bitIndex);
        int wordIndex = bitIndex / 64;
        words_[wordIndex] ^= (1ULL << (bitIndex % 64));
    }

    // flip range
    void flip(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; ++i) flip(i);
    }

    // length (logical size)
    int64_t length() const {
        for (int i = static_cast<int>(words_.size()) - 1; i >= 0; --i) {
            if (words_[i] != 0) {
                // find highest set bit in this word
                int bit = 63;
                while (bit >= 0 && ((words_[i] >> bit) & 1ULL) == 0) --bit;
                return static_cast<int64_t>(i) * 64 + bit + 1;
            }
        }
        return 0;
    }

    bool isEmpty() const {
        for (auto w : words_) if (w != 0) return false;
        return true;
    }

    int cardinality() const {
        int count = 0;
        for (auto w : words_) count += __builtin_popcountll(w);
        return count;
    }

    // next set bit >= fromIndex
    int nextSetBit(int fromIndex) const {
        int wordIndex = fromIndex / 64;
        int bitInWord = fromIndex % 64;
        // check inside word
        if (wordIndex < static_cast<int>(words_.size())) {
            uint64_t w = words_[wordIndex] >> bitInWord;
            if (w != 0) {
                int trailing = __builtin_ctzll(w);
                return fromIndex + trailing;
            }
        }
        // search subsequent words
        for (int i = wordIndex + 1; i < static_cast<int>(words_.size()); ++i) {
            if (words_[i] != 0) {
                int trailing = __builtin_ctzll(words_[i]);
                return i * 64 + trailing;
            }
        }
        return -1;
    }

    // next clear bit >= fromIndex
    int nextClearBit(int fromIndex) const {
        int wordIndex = fromIndex / 64;
        int bitInWord = fromIndex % 64;
        // ensure capacity? In Java, if beyond length, returns fromIndex. We'll expand? Simulate: if wordIndex >= words_.size(), return fromIndex.
        if (wordIndex >= static_cast<int>(words_.size())) return fromIndex;
        // check inside word
        uint64_t w = ~words_[wordIndex] >> bitInWord;
        if (w != 0) {
            int trailing = __builtin_ctzll(w);
            return fromIndex + trailing;
        }
        // subsequent words
        for (int i = wordIndex + 1; ; ++i) {
            if (i >= static_cast<int>(words_.size())) {
                // no more words, return the next bit index
                return i * 64;
            }
            if (words_[i] != ~0ULL) {
                int trailing = __builtin_ctzll(~words_[i]);
                return i * 64 + trailing;
            }
        }
    }

    // previous set bit <= fromIndex
    int previousSetBit(int fromIndex) const {
        if (fromIndex < 0) return -1;
        int wordIndex = fromIndex / 64;
        int bitInWord = fromIndex % 64;
        if (wordIndex >= static_cast<int>(words_.size())) wordIndex = words_.size() - 1;
        // check inside word
        uint64_t w = words_[wordIndex] << (63 - bitInWord);
        if (w != 0) {
            int leading = __builtin_clzll(w); // number of leading zeros in 64-bit
            return fromIndex - leading;
        }
        // previous words
        for (int i = wordIndex - 1; i >= 0; --i) {
            if (words_[i] != 0) {
                int leading = __builtin_clzll(words_[i]);
                return (i + 1) * 64 - 1 - leading;
            }
        }
        return -1;
    }

    // previous clear bit <= fromIndex
    int previousClearBit(int fromIndex) const {
        if (fromIndex < 0) return -1;
        int wordIndex = fromIndex / 64;
        int bitInWord = fromIndex % 64;
        if (wordIndex >= static_cast<int>(words_.size())) return fromIndex; // all bits are 0 beyond
        // check inside word
        uint64_t w = ~words_[wordIndex] << (63 - bitInWord);
        if (w != 0) {
            int leading = __builtin_clzll(w);
            return fromIndex - leading;
        }
        for (int i = wordIndex - 1; i >= 0; --i) {
            if (words_[i] != ~0ULL) {
                int leading = __builtin_clzll(~words_[i]);
                return (i + 1) * 64 - 1 - leading;
            }
        }
        return -1;
    }

    // toByteArray (little-endian)
    std::vector<uint8_t> toByteArray() const {
        if (isEmpty()) return std::vector<uint8_t>();
        // compute needed length
        int64_t len = length();
        int byteLen = (len + 7) / 8;
        std::vector<uint8_t> result(byteLen, 0);
        for (int i = 0; i < byteLen; ++i) {
            int bitIndex = i * 8;
            int wordIndex = bitIndex / 64;
            int bitOffset = bitIndex % 64;
            uint64_t word = (wordIndex < static_cast<int>(words_.size())) ? words_[wordIndex] : 0ULL;
            result[i] = (word >> bitOffset) & 0xFF;
        }
        return result;
    }

    // toLongArray (little-endian)
    std::vector<int64_t> toLongArray() const {
        if (isEmpty()) return std::vector<int64_t>();
        int64_t len = length();
        int longLen = (len + 63) / 64;
        std::vector<int64_t> result(longLen, 0);
        for (int i = 0; i < longLen; ++i) {
            if (i < static_cast<int>(words_.size()))
                result[i] = static_cast<int64_t>(words_[i]);
        }
        return result;
    }

    // static valueOf from long array
    static BitSet valueOf(const std::vector<int64_t>& longs) {
        BitSet bs;
        bs.words_.resize(longs.size(), 0);
        for (size_t i = 0; i < longs.size(); ++i) {
            bs.words_[i] = static_cast<uint64_t>(longs[i]);
        }
        return bs;
    }

    // static valueOf from LongBuffer
    static BitSet valueOf(LongBuffer& buf) {
        std::vector<int64_t> longs;
        while (buf.remaining() > 0) {
            longs.push_back(buf.get());
        }
        return valueOf(longs);
    }

    // static valueOf from byte array
    static BitSet valueOf(const std::vector<uint8_t>& bytes) {
        BitSet bs;
        if (bytes.empty()) return bs;
        int wordLen = (bytes.size() + 7) / 8;
        bs.words_.resize(wordLen, 0);
        for (size_t i = 0; i < bytes.size(); ++i) {
            int wordIndex = i / 8;
            int bitOffset = (i % 8) * 8;
            bs.words_[wordIndex] |= (static_cast<uint64_t>(bytes[i]) << bitOffset);
        }
        return bs;
    }

    // static valueOf from ByteBuffer
    static BitSet valueOf(ByteBuffer& buf) {
        std::vector<uint8_t> bytes;
        while (buf.remaining() > 0) {
            bytes.push_back(buf.get());
        }
        return valueOf(bytes);
    }

    // equals (compare with another BitSet)
    bool equals(const BitSet& other) const {
        // find highest set bit index
        int64_t maxLen = std::max(length(), other.length());
        // compare bits up to maxLen
        int maxWord = (maxLen + 63) / 64;
        for (int i = 0; i < maxWord; ++i) {
            uint64_t w1 = (i < static_cast<int>(words_.size())) ? words_[i] : 0ULL;
            uint64_t w2 = (i < static_cast<int>(other.words_.size())) ? other.words_[i] : 0ULL;
            if (w1 != w2) return false;
        }
        return true;
    }

    // hashCode
    int hashCode() const {
        int hash = 1234;
        for (size_t i = words_.size(); i > 0; --i) {
            uint64_t w = words_[i-1];
            hash ^= static_cast<int>(w & 0xFFFFFFFF) ^ static_cast<int>((w >> 32) & 0xFFFFFFFF);
        }
        return hash;
    }

    // clone
    BitSet clone() const {
        return *this;
    }

    // toString
    std::string toString() const {
        std::vector<int> indices;
        int idx = nextSetBit(0);
        while (idx >= 0) {
            indices.push_back(idx);
            idx = nextSetBit(idx + 1);
        }
        std::ostringstream oss;
        oss << "{";
        for (size_t i = 0; i < indices.size(); ++i) {
            if (i > 0) oss << ", ";
            oss << indices[i];
        }
        oss << "}";
        return oss.str();
    }

    // stream (return vector of set indices)
    std::vector<int> stream() const {
        std::vector<int> indices;
        int idx = nextSetBit(0);
        while (idx >= 0) {
            indices.push_back(idx);
            idx = nextSetBit(idx + 1);
        }
        return indices;
    }

    // bitwise operations
    void or_(const BitSet& other) {
        ensureCapacity(other.words_.size() * 64 - 1);
        for (size_t i = 0; i < other.words_.size(); ++i) {
            words_[i] |= other.words_[i];
        }
    }

    void and_(const BitSet& other) {
        for (size_t i = 0; i < words_.size(); ++i) {
            if (i < other.words_.size()) {
                words_[i] &= other.words_[i];
            } else {
                words_[i] = 0;
            }
        }
    }

    void xor_(const BitSet& other) {
        ensureCapacity(other.words_.size() * 64 - 1);
        for (size_t i = 0; i < other.words_.size(); ++i) {
            words_[i] ^= other.words_[i];
        }
    }

    void andNot(const BitSet& other) {
        for (size_t i = 0; i < words_.size(); ++i) {
            if (i < other.words_.size()) {
                words_[i] &= ~other.words_[i];
            }
        }
    }

    bool intersects(const BitSet& other) const {
        size_t minSize = std::min(words_.size(), other.words_.size());
        for (size_t i = 0; i < minSize; ++i) {
            if (words_[i] & other.words_[i]) return true;
        }
        return false;
    }

private:
    std::vector<uint64_t> words_;

    void ensureCapacity(int bitIndex) {
        if (bitIndex < 0) throw std::invalid_argument("bitIndex < 0");
        int wordIndex = bitIndex / 64;
        if (wordIndex >= static_cast<int>(words_.size())) {
            words_.resize(wordIndex + 1, 0ULL);
        }
    }
};

// ========== TEST FUNCTIONS ==========

void size_test_3353() {
    BitSet instance;
    instance.size();
}

void get_test_3354(int p0) {
    BitSet instance;
    instance.get(p0);
}

void get_test_3355(int p0, int p1) {
    BitSet instance;
    instance.get(p0, p1);
}

void equals_test_3356(const BitSet& p0) {
    BitSet instance;
    instance.equals(p0);
}

void length_test_3357() {
    BitSet instance;
    instance.length();
}

void toString_test_3358() {
    BitSet instance;
    instance.toString();
}

void hashCode_test_3359() {
    BitSet instance;
    instance.hashCode();
}

void clone_test_3360() {
    BitSet instance;
    instance.clone();
}

void valueOf_test_3361(const std::vector<int64_t>& p0) {
    BitSet instance;
    BitSet::valueOf(p0);
}

void valueOf_test_3362(LongBuffer& p0) {
    BitSet instance;
    BitSet::valueOf(p0);
}

void valueOf_test_3363(const std::vector<uint8_t>& p0) {
    BitSet instance;
    BitSet::valueOf(p0);
}

void valueOf_test_3364(ByteBuffer& p0) {
    BitSet instance;
    BitSet::valueOf(p0);
}

void clear_test_3365(int p0) {
    BitSet instance;
    instance.clear(p0);
}

void clear_test_3366(int p0, int p1) {
    BitSet instance;
    instance.clear(p0, p1);
}

void clear_test_3367() {
    BitSet instance;
    instance.clear();
}

void isEmpty_test_3368() {
    BitSet instance;
    instance.isEmpty();
}

void stream_test_3369() {
    BitSet instance;
    instance.stream();
}

void set_test_3370(int p0, int p1) {
    BitSet instance;
    instance.set(p0, p1);
}

void set_test_3371(int p0, bool p1) {
    BitSet instance;
    instance.set(p0, p1);
}

void set_test_3372(int p0) {
    BitSet instance;
    instance.set(p0);
}

void set_test_3373(int p0, int p1, bool p2) {
    BitSet instance;
    instance.set(p0, p1, p2);
}

void flip_test_3374(int p0) {
    BitSet instance;
    instance.flip(p0);
}

void flip_test_3375(int p0, int p1) {
    BitSet instance;
    instance.flip(p0, p1);
}

void toByteArray_test_3376() {
    BitSet instance;
    instance.toByteArray();
}

void nextClearBit_test_3377(int p0) {
    BitSet instance;
    instance.nextClearBit(p0);
}

void or_test_3378(const BitSet& p0) {
    BitSet instance;
    instance.or_(p0);
}

void and_test_3379(const BitSet& p0) {
    BitSet instance;
    instance.and_(p0);
}

void xor_test_3380(const BitSet& p0) {
    BitSet instance;
    instance.xor_(p0);
}

void andNot_test_3381(const BitSet& p0) {
    BitSet instance;
    instance.andNot(p0);
}

void cardinality_test_3382() {
    BitSet instance;
    instance.cardinality();
}

void nextSetBit_test_3383(int p0) {
    BitSet instance;
    instance.nextSetBit(p0);
}

void toLongArray_test_3384() {
    BitSet instance;
    instance.toLongArray();
}

void previousSetBit_test_3385(int p0) {
    BitSet instance;
    instance.previousSetBit(p0);
}

void previousClearBit_test_3386(int p0) {