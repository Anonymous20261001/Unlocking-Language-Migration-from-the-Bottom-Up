```cpp
#include <string>
#include <vector>
#include <memory>
#include <ctime>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <cctype>

// Minimal base class to mimic Java's Object
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other; // default identity comparison
    }
    virtual int hashCode() const {
        return reinterpret_cast<intptr_t>(this);
    }
    virtual std::string toString() const {
        return "Object";
    }
    virtual Object* clone() const {
        return new Object(*this);
    }
};

// C++ equivalent of java.net.HttpCookie
class HttpCookie : public Object {
private:
    std::string name;
    std::string value;
    int version = 0;
    std::string comment;
    std::string commentURL;
    std::string domain;
    std::string path;
    std::string portlist;
    bool secure = false;
    bool httpOnly = false;
    bool discard = false;
    long maxAge = -1L; // -1 means session cookie

    // For hasExpired: if maxAge == 0 -> expired; negative -> never expires by time
    bool expired = false;

public:
    HttpCookie(const std::string& name, const std::string& value) {
        if (name.empty()) {
            throw std::invalid_argument("Cookie name cannot be empty");
        }
        this->name = name;
        this->value = value;
        // According to Java spec, version defaults to 0 (old Netscape)
    }

    // Getter methods
    std::string getName() const { return name; }
    std::string getValue() const { return value; }
    int getVersion() const { return version; }
    std::string getComment() const { return comment; }
    std::string getCommentURL() const { return commentURL; }
    std::string getDomain() const { return domain; }
    std::string getPath() const { return path; }
    std::string getPortlist() const { return portlist; }
    bool getSecure() const { return secure; }
    bool isHttpOnly() const { return httpOnly; }
    bool getDiscard() const { return discard; }
    long getMaxAge() const { return maxAge; }

    // Setter methods
    void setValue(const std::string& value) { this->value = value; }
    void setVersion(int version) { this->version = version; }
    void setComment(const std::string& comment) { this->comment = comment; }
    void setCommentURL(const std::string& commentURL) { this->commentURL = commentURL; }
    void setDomain(const std::string& domain) { this->domain = domain; }
    void setPath(const std::string& path) { this->path = path; }
    void setPortlist(const std::string& portlist) { this->portlist = portlist; }
    void setSecure(bool secure) { this->secure = secure; }
    void setHttpOnly(bool httpOnly) { this->httpOnly = httpOnly; }
    void setDiscard(bool discard) { this->discard = discard; }
    void setMaxAge(long maxAge) {
        this->maxAge = maxAge;
        // If maxAge == 0, cookie expires immediately
        if (maxAge == 0) {
            expired = true;
        } else if (maxAge < 0) {
            expired = false; // session cookie, not expired by time
        } else {
            // For positive maxAge, we could store expiration time.
            // Simplified: we don't keep creation time, so hasExpired() will check maxAge.
            // We'll treat positive as not expired unless maxAge is 0. For real behavior,
            // we would need a timestamp. As a test placeholder, set expired = false.
            expired = false;
        }
    }

    bool hasExpired() const {
        // In Java, hasExpired() returns true if maxAge == 0.
        // For positive maxAge, it would compare against current time.
        // Since we don't store creation time, we approximate.
        // For test purposes, we rely on the flag set in setMaxAge.
        return expired || (maxAge == 0);
    }

    // Static methods
    static bool domainMatches(const std::string& domain, const std::string& host) {
        // Simplified implementation: check if host ends with domain after a dot
        // Java's implementation follows RFC 2965.
        // For test purposes we just do basic check.
        if (domain.empty() || host.empty()) return false;
        // If domain equals host
        if (domain == host) return true;
        // If host ends with "." + domain
        if (host.size() > domain.size() + 1 && host[host.size() - domain.size() - 1] == '.') {
            std::string suffix = host.substr(host.size() - domain.size());
            return suffix == domain;
        }
        return false;
    }

    static std::vector<HttpCookie> parse(const std::string& header) {
        // Minimal parse – return empty vector
        // In real implementation you'd parse the Set-Cookie header.
        return {};
    }

    // Override Object methods
    bool equals(const Object& other) const override {
        const HttpCookie* otherCookie = dynamic_cast<const HttpCookie*>(&other);
        if (otherCookie == nullptr) return false;
        // Java's equals: compare name (case-insensitive?), but actually case-insensitive?
        // According to Java doc, equals only compares name (case-insensitive) and domain?
        // Actually: "Two HttpCookie objects are equal if they have the same name, domain, and path."
        // We'll implement that.
        return (name == otherCookie->name) && (domain == otherCookie->domain) && (path == otherCookie->path);
    }

    int hashCode() const override {
        // Java's hashCode: based on name, domain, path (consistent with equals)
        int hash = 7;
        hash = 31 * hash + std::hash<std::string>{}(name);
        hash = 31 * hash + std::hash<std::string>{}(domain);
        hash = 31 * hash + std::hash<std::string>{}(path);
        return hash;
    }

    std::string toString() const override {
        // Mimics Java's Cookie.toString() which returns "Cookie: version=0; name=value; ..."
        // Simplified: "name=value"
        return name + "=" + value;
    }

    HttpCookie* clone() const override {
        return new HttpCookie(*this);
    }
};

// ========== Test functions (translated from Java @Test methods) ==========

void getSecure_test_2557(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getSecure();
}

void isHttpOnly_test_2558(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.isHttpOnly();
}

void getPortlist_test_2559(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getPortlist();
}

void setPath_test_2560(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setPath(p0);
}

void getDomain_test_2561(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getDomain();
}

void setDomain_test_2562(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setDomain(p0);
}

void setPortlist_test_2563(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setPortlist(p0);
}

void hasExpired_test_2564(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.hasExpired();
}

void setCommentURL_test_2565(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setCommentURL(p0);
}

void getCommentURL_test_2566(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getCommentURL();
}

void setDiscard_test_2567(bool p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setDiscard(p0);
}

void getDiscard_test_2568(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getDiscard();
}

void setMaxAge_test_2569(long p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setMaxAge(p0);
}

void getMaxAge_test_2570(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getMaxAge();
}

void setSecure_test_2571(bool p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setSecure(p0);
}

void setHttpOnly_test_2572(bool p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setHttpOnly(p0);
}

void domainMatches_test_2573(std::string p0, std::string p1, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    HttpCookie::domainMatches(p0, p1);
}

void getName_test_2574(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getName();
}

void equals_test_2575(Object p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.equals(p0);
}

void toString_test_2576(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.toString();
}

void hashCode_test_2577(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.hashCode();
}

void clone_test_2578(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.clone();
    // Note: clone returns a pointer; ignoring it leaks memory in test.
    // In real code, we would delete it. Here we just call it to match Java.
}

void getValue_test_2579(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getValue();
}

void setValue_test_2580(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setValue(p0);
}

void parse_test_2581(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    HttpCookie::parse(p0);
}

void getPath_test_2582(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getPath();
}

void setVersion_test_2583(int p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setVersion(p0);
}

void setComment_test_2584(std::string p0, std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.setComment(p0);
}

void getComment_test_2585(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getComment();
}

void getVersion_test_2586(std::string c0, std::string c1) {
    HttpCookie instance(c0, c1);
    instance.getVersion();
}
```