```cpp
#include <string>
#include <cstdint>
#include <sstream>

// ------------------------------------------------------------
// C++ equivalents of Java classes used in the tests
// ------------------------------------------------------------

// ObjectName – simplified version wrapping a string.
class ObjectName {
public:
    explicit ObjectName(const std::string& name) : name_(name) {}

    std::string toString() const {
        return name_;
    }

private:
    std::string name_;
};

// Object – base class providing a minimal toString().
class Object {
public:
    virtual ~Object() = default;

    virtual std::string toString() const {
        std::ostringstream oss;
        oss << "Object@" << static_cast<const void*>(this);
        return oss.str();
    }
};

// MBeanServerNotification – mirrors the Java class.
class MBeanServerNotification {
public:
    // Constructor signature matches Java: (String, Object, long, ObjectName)
    MBeanServerNotification(const std::string& type,
                            const Object& source,
                            int64_t sequenceNumber,
                            const ObjectName& objectName)
        : type_(type), source_(source), sequenceNumber_(sequenceNumber), objectName_(objectName) {}

    // getMBeanName() returns the ObjectName stored in the notification.
    ObjectName getMBeanName() const {
        return objectName_;
    }

    // toString() returns a string representation.
    std::string toString() const {
        std::ostringstream oss;
        oss << "MBeanServerNotification[type=" << type_
            << ", source=" << source_.toString()
            << ", sequenceNumber=" << sequenceNumber_
            << ", objectName=" << objectName_.toString() << "]";
        return oss.str();
    }

private:
    std::string type_;
    const Object& source_;      // reference to the original object
    int64_t sequenceNumber_;
    ObjectName objectName_;
};

// ------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ------------------------------------------------------------

void getMBeanName_test_5608(const std::string& c0, const Object& c1, int64_t c2, const ObjectName& c3) {
    MBeanServerNotification instance(c0, c1, c2, c3);
    instance.getMBeanName();
}

void toString_test_5609(const std::string& c0, const Object& c1, int64_t c2, const ObjectName& c3) {
    MBeanServerNotification instance(c0, c1, c2, c3);
    instance.toString();
}
```