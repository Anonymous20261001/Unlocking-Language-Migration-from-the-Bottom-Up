```cpp
#include <string>
#include <map>
#include <any>
#include <iostream>

class AudioFormat {
public:
    // Encoding type as string for simplicity
    static const std::string PCM_SIGNED;
    static const std::string PCM_UNSIGNED;

    AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed_, bool bigEndian)
        : m_sampleRate(sampleRate),
          m_sampleSizeInBits(sampleSizeInBits),
          m_channels(channels),
          m_signed(signed_),
          m_bigEndian(bigEndian),
          m_frameSize((sampleSizeInBits / 8) * channels),
          m_frameRate(sampleRate),
          m_encoding(signed_ ? PCM_SIGNED : PCM_UNSIGNED) // simplified
    {}

    int getChannels() const { return m_channels; }
    float getSampleRate() const { return m_sampleRate; }
    int getSampleSizeInBits() const { return m_sampleSizeInBits; }
    float getFrameRate() const { return m_frameRate; }
    int getFrameSize() const { return m_frameSize; }

    // In Java, getProperty returns Object (null if not found).
    // We simulate with std::any, returning empty std::any if property not present.
    std::any getProperty(const std::string& key) const {
        auto it = m_properties.find(key);
        if (it != m_properties.end()) {
            return it->second;
        }
        return std::any(); // equivalent to null
    }

    std::string toString() const {
        // Simplified string representation
        return "AudioFormat@" + std::to_string(reinterpret_cast<std::uintptr_t>(this));
    }

    // matches: returns true if the two formats are equal (all fields match)
    bool matches(const AudioFormat& other) const {
        return m_sampleRate == other.m_sampleRate &&
               m_sampleSizeInBits == other.m_sampleSizeInBits &&
               m_channels == other.m_channels &&
               m_signed == other.m_signed &&
               m_bigEndian == other.m_bigEndian &&
               m_encoding == other.m_encoding;
    }

    // In Java, properties() returns Map<String, Object>.
    // We return a copy of the internal map (which is empty unless set).
    std::map<std::string, std::any> properties() const {
        return m_properties;
    }

    bool isBigEndian() const { return m_bigEndian; }

    std::string getEncoding() const { return m_encoding; }

private:
    float m_sampleRate;
    int m_sampleSizeInBits;
    int m_channels;
    bool m_signed;
    bool m_bigEndian;
    int m_frameSize;
    float m_frameRate;
    std::string m_encoding;
    std::map<std::string, std::any> m_properties; // initially empty
};

const std::string AudioFormat::PCM_SIGNED = "PCM_SIGNED";
const std::string AudioFormat::PCM_UNSIGNED = "PCM_UNSIGNED";

// ------------------------------------------------------------
// Test functions (direct translations of Java @Test methods)
// ------------------------------------------------------------

void getChannels_test_6504(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getChannels();
}

void getSampleRate_test_6505(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getSampleRate();
}

void getSampleSizeInBits_test_6506(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getSampleSizeInBits();
}

void getFrameRate_test_6507(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getFrameRate();
}

void getFrameSize_test_6508(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getFrameSize();
}

void getProperty_test_6509(const std::string& p0, float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getProperty(p0);
}

void toString_test_6510(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.toString();
}

void matches_test_6511(const AudioFormat& p0, float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.matches(p0);
}

void properties_test_6512(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.properties();
}

void isBigEndian_test_6513(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.isBigEndian();
}

void getEncoding_test_6514(float c0, int c1, int c2, bool c3, bool c4) {
    AudioFormat instance(c0, c1, c2, c3, c4);
    instance.getEncoding();
}
```