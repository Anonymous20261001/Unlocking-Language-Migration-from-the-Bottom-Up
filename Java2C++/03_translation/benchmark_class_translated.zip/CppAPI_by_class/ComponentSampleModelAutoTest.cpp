```cpp
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <memory>
#include <stdexcept>

// Forward declarations
class DataBuffer;
class ComponentSampleModel;

// Minimal Object class (like Java's Object)
class Object {
public:
    virtual ~Object() = default;
};

// ----------------------------------------------------------------------------
// DataBuffer – simplified version (single bank of ints, with type tag)
// ----------------------------------------------------------------------------
class DataBuffer {
public:
    enum DataType { TYPE_BYTE = 0, TYPE_USHORT, TYPE_SHORT, TYPE_INT, TYPE_FLOAT, TYPE_DOUBLE };

    DataBuffer(int dataType, int size)
        : type(dataType), data(size, 0) {}

    int getElem(int bank, int offset) const {
        if (bank != 0) throw std::runtime_error("Only single bank supported");
        return data.at(offset);
    }
    void setElem(int bank, int offset, int val) {
        if (bank != 0) throw std::runtime_error("Only single bank supported");
        data.at(offset) = val;
    }
    float getElemFloat(int bank, int offset) const {
        return static_cast<float>(getElem(bank, offset));
    }
    double getElemDouble(int bank, int offset) const {
        return static_cast<double>(get