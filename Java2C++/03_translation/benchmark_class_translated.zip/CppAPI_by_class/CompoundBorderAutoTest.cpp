```cpp
#include <cstddef>

// Minimal Insets class mimicking Java's java.awt.Insets
class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;

    Insets() : top(0), left(0), bottom(0), right(0) {}
    Insets(int t, int l, int b, int r) : top(t), left(l), bottom(b), right(r) {}
};

// Minimal Component class (no actual functionality needed)
class Component {
public:
    virtual ~Component() = default;
};

// Minimal Graphics class (no actual functionality needed)
class Graphics {
public:
    virtual ~Graphics() = default;
};

// Abstract base class for Border (mimics javax.swing.border.Border)
class Border {
public:
    virtual ~Border() = default;
    virtual void paintBorder(Component* c, Graphics* g, int x, int y, int width, int height) = 0;
    virtual void getBorderInsets(Component* c, Insets* insets) = 0;
    virtual bool isBorderOpaque() = 0;
};

// Concrete implementation of CompoundBorder (mimics javax.swing.border.CompoundBorder)
class CompoundBorder : public Border {
private:
    Border* outsideBorder;   // may be nullptr
    Border* insideBorder;    // may be nullptr

public:
    // Default constructor – both borders null
    CompoundBorder() : outsideBorder(nullptr), insideBorder(nullptr) {}

    // Constructor with outside and inside borders (not used by tests, but provided for completeness)
    CompoundBorder(Border* outside, Border* inside) : outsideBorder(outside), insideBorder(inside) {}

    // Delegate to outside and inside borders (safely handle null)
    void paintBorder(Component* c, Graphics* g, int x, int y, int width, int height) override {
        if (outsideBorder != nullptr) {
            outsideBorder->paintBorder(c, g, x, y, width, height);
        }
        if (insideBorder != nullptr) {
            insideBorder->paintBorder(c, g, x, y, width, height);
        }
    }

    // Compute combined insets from outside and inside borders.
    // Implementation mimics Java's CompoundBorder.getBorderInsets(Component, Insets)
    void getBorderInsets(Component* c, Insets* insets) override {
        if (outsideBorder != nullptr) {
            outsideBorder->getBorderInsets(c, insets);
        } else {
            insets->top = insets->left = insets->bottom = insets->right = 0;
        }
        if (insideBorder != nullptr) {
            Insets insideInsets;
            insideBorder->getBorderInsets(c, &insideInsets);
            insets->top    += insideInsets.top;
            insets->left   += insideInsets.left;
            insets->bottom += insideInsets.bottom;
            insets->right  += insideInsets.right;
        }
    }

    // Returns true if both borders (if present) are opaque.
    // If a border is null, it is considered opaque for the purpose of combination.
    bool isBorderOpaque() override {
        bool outsideOpaque = (outsideBorder == nullptr) || outsideBorder->isBorderOpaque();
        bool insideOpaque  = (insideBorder  == nullptr) || insideBorder->isBorderOpaque();
        return outsideOpaque && insideOpaque;
    }

    // Accessors for the outside and inside borders
    Border* getOutsideBorder() const {
        return outsideBorder;
    }

    Border* getInsideBorder() const {
        return insideBorder;
    }
};

// ---------------------------------------------------------------------------
// Translation of the Java @Test methods into equivalent C++ test functions
// ---------------------------------------------------------------------------

void paintBorder_test_8459(Component* p0, Graphics* p1, int p2, int p3, int p4, int p5) {
    CompoundBorder instance;
    instance.paintBorder(p0, p1, p2, p3, p4, p5);
}

void getBorderInsets_test_8460(Component* p0, Insets* p1) {
    CompoundBorder instance;
    instance.getBorderInsets(p0, p1);
}

void isBorderOpaque_test_8461() {
    CompoundBorder instance;
    instance.isBorderOpaque();
}

void getOutsideBorder_test_8462() {
    CompoundBorder instance;
    instance.getOutsideBorder();
}

void getInsideBorder_test_8463() {
    CompoundBorder instance;
    instance.getInsideBorder();
}
```