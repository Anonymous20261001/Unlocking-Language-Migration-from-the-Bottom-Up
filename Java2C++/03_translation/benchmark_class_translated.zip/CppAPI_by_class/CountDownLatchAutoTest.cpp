```cpp
#include <iostream>
#include <sstream>
#include <string>
#include <atomic>
#include <mutex>

class CountDownLatch {
public:
    explicit CountDownLatch(int count) : count_(count) {}

    void countDown() {
        if (count_ > 0) {
            count_--;
        }
    }

    int getCount() const {
        return count_.load();
    }

    std::string toString() const {
        // Mimic Java's toString: "java.util.concurrent.CountDownLatch@<hex_hash>"
        // For C++, we use the address of this object.
        std::ostringstream oss;
        oss << "CountDownLatch@" << std::hex << reinterpret_cast<uintptr_t>(this);
        return oss.str();
    }

private:
    std::atomic<int> count_;
};

// Test functions (C++ translation of the Java @Test methods)
void toString_test_4441(int c0) {
    CountDownLatch instance(c0);
    instance.toString();
}

void getCount_test_4442(int c0) {
    CountDownLatch instance(c0);
    instance.getCount();
}

void countDown_test_4443(int c0) {
    CountDownLatch instance(c0);
    instance.countDown();
}
```