```cpp
#include <cstddef>

// ==================== Forward declarations ====================
class DragSourceEvent;
class DragSourceDragEvent;
class DragSourceDropEvent;
class DragGestureEvent;
class DragSource;
class Component;
class Cursor;
class Image;
class Point;
class Transferable;
class DragSourceListener;

// ==================== Basic types ====================
class Cursor {
public:
    virtual ~Cursor() = default;
};

class Image {
public:
    virtual ~Image() = default;
};

class Point {
public:
    int x;
    int y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class Transferable {
public:
    virtual ~Transferable() = default;
};

// ==================== AWT Component ====================
class Component {
public:
    virtual ~Component() = default;
};

// ==================== DragSource ====================
class DragSource {
public:
    virtual ~DragSource() = default;
};

// ==================== DragGestureEvent ====================
class DragGestureEvent {
private:
    DragSource source;
    Component comp;
public:
    DragGestureEvent() = default;
    DragSource& getDragSource() { return source; }
    Component& getComponent() { return comp; }
};

// ==================== DragSource events ====================
class DragSourceEvent {
public:
    virtual ~DragSourceEvent() = default;
};

class DragSourceDragEvent : public DragSourceEvent {
public:
    ~DragSourceDragEvent() override = default;
};

class DragSourceDropEvent : public DragSourceEvent {
public:
    ~DragSourceDropEvent() override = default;
};

// ==================== DragSourceListener ====================
class DragSourceListener {
public:
    virtual ~DragSourceListener() = default;
    virtual void dragEnter(DragSourceDragEvent&) {}
    virtual void dragOver(DragSourceDragEvent&)