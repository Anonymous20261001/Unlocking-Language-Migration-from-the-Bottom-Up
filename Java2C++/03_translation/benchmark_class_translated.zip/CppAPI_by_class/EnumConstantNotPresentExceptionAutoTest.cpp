```cpp
#include <string>
#include <stdexcept>

// C++ equivalent of Java's EnumConstantNotPresentException
class EnumConstantNotPresentException : public std::runtime_error {
private:
    std::string enumTypeName;
    std::string constantName;
public:
    EnumConstantNotPresentException(const std::string& enumType, const std::string& constant)
        : std::runtime_error("Enum constant not present: " + enumType + "." + constant),
          enumTypeName(enumType), constantName(constant) {}

    const std::string& enumType() const { return enumTypeName; }
    const std::string& constantName() const { return constantName; }
};

void enumType_test_1995(const std::string& c0, const std::string& c1) {
    EnumConstantNotPresentException instance(c0, c1);
    instance.enumType();
}

void constantName_test_1996(const std::string& c0, const std::string& c1) {
    EnumConstantNotPresentException instance(c0, c1);
    instance.constantName();
}
```