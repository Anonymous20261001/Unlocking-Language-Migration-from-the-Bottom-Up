```cpp
#include <vector>
#include <string>
#include <cstddef>
#include <cstdint>
#include <unordered_map>

// Forward declarations
class SliderUI;
class ChangeListener;
class BoundedRangeModel;
class Dictionary;
class Font;
class Image;

// ---------------------------------------------------------------------------
// Dummy classes mimicking Java AWT/Swing types (minimal interface)
// ---------------------------------------------------------------------------

class SliderUI {
public:
    virtual ~SliderUI() = default;
};

class ChangeListener {
public:
    virtual ~ChangeListener() = default;
    // In real Swing, stateChanged(ChangeEvent) is the callback.
    // Not needed for these tests.
};

class BoundedRangeModel {
public:
    virtual ~BoundedRangeModel() = default;
    // Minimal required methods (getters/setters) are not used directly in tests
    // but JSlider holds a reference.
};

// java.util.Dictionary is an abstract class; we use a simple map-like interface.
class Dictionary {
public:
    virtual ~Dictionary() = default;
    // Not actually used in these tests.
};

class Font {
public:
    virtual ~Font() = default;
};

class Image {
public:
    virtual ~Image() = default;
};

// ---------------------------------------------------------------------------
// JSlider implementation (simplified, only methods exercised by tests)
// ---------------------------------------------------------------------------
class JSlider {
public:
    JSlider()
        : orientation_(0),           // HORIZONTAL = 0, VERTICAL = 1
          min_(0), max_(100), value_(50), extent_(0),
          majorTickSpacing_(0), minorTickSpacing_(0),
          paintLabels_(false), paintTicks_(false), paintTrack_(true),
          inverted_(false), snapToTicks_(false), valueIsAdjusting_(false),
          ui_(nullptr), model_(nullptr), labelTable_(nullptr),
          font_(nullptr)
    {}

    // ---------- UI methods ----------
    const char* getUIClassID() {
        return "SliderUI";
    }

    SliderUI* getUI() {
        return ui_;
    }

    void setUI(SliderUI* ui) {
        ui_ = ui;
    }

    // ---------- Model ----------
    BoundedRangeModel* getModel() {
        return model_;
    }

    void setModel(BoundedRangeModel* model) {
        model_ = model;
    }

    // ---------- Label table ----------
    Dictionary* getLabelTable() {
        return labelTable_;
    }

    void setLabelTable(Dictionary* table) {
        labelTable_ = table;
    }

    Dictionary* createStandardLabels(int increment) {
        // In real Swing this returns a Hashtable of Integer->JLabel
        return new Dictionary();
    }

    Dictionary* createStandardLabels(int increment, int start) {
        return new Dictionary();
    }

    // ---------- Ticks ----------
    int getMajorTickSpacing() { return majorTickSpacing_; }
    void setMajorTickSpacing(int s) { majorTickSpacing_ = s; }

    int getMinorTickSpacing() { return minorTickSpacing_; }
    void setMinorTickSpacing(int s) { minorTickSpacing_ = s; }

    bool getPaintTicks() { return paintTicks_; }
    void setPaintTicks(bool b) { paintTicks_ = b; }

    // ---------- Labels ----------
    bool getPaintLabels() { return paintLabels_; }
    void setPaintLabels(bool b) { paintLabels_ = b; }

    // ---------- Track ----------
    bool getPaintTrack() { return paintTrack_; }
    void setPaintTrack(bool b) { paintTrack_ = b; }

    // ---------- Inverted ----------
    bool getInverted() { return inverted_; }
    void setInverted(bool b) { inverted_ = b; }

    // ---------- Snap to ticks ----------
    bool getSnapToTicks() { return snapToTicks_; }
    void setSnapToTicks(bool b) { snapToTicks_ = b; }

    // ---------- Extent ----------
    int getExtent() { return extent_; }
    void setExtent(int e) { extent_ = e; }

    // ---------- Change listeners ----------
    void addChangeListener(ChangeListener* listener) {
        changeListeners_.push_back(listener);
    }

    void removeChangeListener(ChangeListener* listener) {
        for (auto it = changeListeners_.begin(); it != changeListeners_.end(); ++it) {
            if (*it == listener) {
                changeListeners_.erase(it);
                break;
            }
        }
    }

    std::vector<ChangeListener*> getChangeListeners() {
        return changeListeners_;
    }

    // ---------- Accessibility ----------
    // Not a real implementation; just a stub
    void* getAccessibleContext() {
        return nullptr;
    }

    // ---------- Font ----------
    void setFont(Font* f) { font_ = f; }

    // ---------- Image update (inherited from java.awt.Component) ----------
    bool imageUpdate(Image* img, int infoflags, int x, int y, int w, int h) {
        // Stub: returns false
        return false;
    }

    // ---------- Orientation ----------
    int getOrientation() { return orientation_; }
    void setOrientation(int o) { orientation_ = o; }

    // ---------- Value & range ----------
    int getValue() { return value_; }
    void setValue(int v) { value_ = v; }

    int getMinimum() { return min_; }
    void setMinimum(int m) { min_ = m; }

    int getMaximum() { return max_; }
    void setMaximum(int m) { max_ = m; }

    bool getValueIsAdjusting() { return valueIsAdjusting_; }
    void setValueIsAdjusting(bool b) { valueIsAdjusting_ = b; }

    // ---------- UI update ----------
    void updateUI() {
        // In real Swing this would install the current look and feel
        // Stub does nothing
    }

private:
    int orientation_;
    int min_, max_, value_, extent_;
    int majorTickSpacing_, minorTickSpacing_;
    bool paintLabels_, paintTicks_, paintTrack_;
    bool inverted_, snapToTicks_, valueIsAdjusting_;
    SliderUI* ui_;
    BoundedRangeModel* model_;
    Dictionary* labelTable_;
    Font* font_;
    std::vector<ChangeListener*> changeListeners_;
};

// ---------------------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ---------------------------------------------------------------------------

void getUIClassID_test_7637() {
    JSlider instance;
    instance.getUIClassID();
}

void getUI_test_7638() {
    JSlider instance;
    instance.getUI();
}

void setUI_test_7639(SliderUI* p0) {
    JSlider instance;
    instance.setUI(p0);
}

void getModel_test_7640() {
    JSlider instance;
    instance.getModel();
}

void getLabelTable_test_7641() {
    JSlider instance;
    instance.getLabelTable();
}

void createStandardLabels_test_7642(int p0) {
    JSlider instance;
    instance.createStandardLabels(p0);
}

void createStandardLabels_test_7643(int p0, int p1) {
    JSlider instance;
    instance.createStandardLabels(p0, p1);
}

void getMajorTickSpacing_test_7644() {
    JSlider instance;
    instance.getMajorTickSpacing();
}

void getPaintLabels_test_7645() {
    JSlider instance;
    instance.getPaintLabels();
}

void setLabelTable_test_7646(Dictionary* p0) {
    JSlider instance;
    instance.setLabelTable(p0);
}

void getPaintTicks_test_7647() {
    JSlider instance;
    instance.getPaintTicks();
}

void getInverted_test_7648() {
    JSlider instance;
    instance.getInverted();
}

void setInverted_test_7649(bool p0) {
    JSlider instance;
    instance.setInverted(p0);
}

void setMajorTickSpacing_test_7650(int p0) {
    JSlider instance;
    instance.setMajorTickSpacing(p0);
}

void getMinorTickSpacing_test_7651() {
    JSlider instance;
    instance.getMinorTickSpacing();
}

void setMinorTickSpacing_test_7652(int p0) {
    JSlider instance;
    instance.setMinorTickSpacing(p0);
}

void getSnapToTicks_test_7653() {
    JSlider instance;
    instance.getSnapToTicks();
}

void setSnapToTicks_test_7654(bool p0) {
    JSlider instance;
    instance.setSnapToTicks(p0);
}

void setPaintTicks_test_7655(bool p0) {
    JSlider instance;
    instance.setPaintTicks(p0);
}

void getPaintTrack_test_7656() {
    JSlider instance;
    instance.getPaintTrack();
}

void setPaintTrack_test_7657(bool p0) {
    JSlider instance;
    instance.setPaintTrack(p0);
}

void setPaintLabels_test_7658(bool p0) {
    JSlider instance;
    instance.setPaintLabels(p0);
}

void getExtent_test_7659() {
    JSlider instance;
    instance.getExtent();
}

void setExtent_test_7660(int p0) {
    JSlider instance;
    instance.setExtent(p0);
}

void addChangeListener_test_7661(ChangeListener* p0) {
    JSlider instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_7662(ChangeListener* p0) {
    JSlider instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_7663() {
    JSlider instance;
    instance.getChangeListeners();
}

void setModel_test_7664(BoundedRangeModel* p0) {
    JSlider instance;
    instance.setModel(p0);
}

void getAccessibleContext_test_7665() {
    JSlider instance;
    instance.getAccessibleContext();
}

void setFont_test_7666(Font* p0) {
    JSlider instance;
    instance.setFont(p0);
}

void imageUpdate_test_7667(Image* p0, int p1, int p2, int p3, int p4, int p5) {
    JSlider instance;
    instance.imageUpdate(p0, p1, p2, p3, p4, p5);
}

void getOrientation_test_7668() {
    JSlider instance;
    instance.getOrientation();
}

void updateUI_test_7669() {
    JSlider instance;
    instance.updateUI();
}

void setMinimum_test_7670(int p0) {
    JSlider instance;
    instance.setMinimum(p0);
}

void setMaximum_test_7671(int p0) {
    JSlider instance;
    instance.setMaximum(p0);
}

void setValueIsAdjusting_test_7672(bool p0) {
    JSlider instance;
    instance.setValueIsAdjusting(p0);
}

void getValueIsAdjusting_test_7673() {
    JSlider instance;
    instance.getValueIsAdjusting();
}

void setOrientation_test_7674(int p0) {
    JSlider instance;
    instance.setOrientation(p0);
}

void getValue_test_7675() {
    JSlider instance;
    instance.getValue();
}

void setValue_test_7676(int p0) {
    JSlider instance;
    instance.setValue(p0);
}

void getMaximum_test_7677() {
    JSlider instance;
    instance.getMaximum();
}

void getMinimum_test_7678() {
    JSlider instance;
    instance.getMinimum();
}
```