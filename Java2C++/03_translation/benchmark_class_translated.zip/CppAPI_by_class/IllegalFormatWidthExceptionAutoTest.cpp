```cpp
#include <string>
#include <exception>
#include <utility>

class IllegalFormatWidthException : public std::exception {
private:
    int width;
    std::string message;

public:
    explicit IllegalFormatWidthException(int width)
        : width(width), message("Width = " + std::to_string(width)) {}

    int getWidth() const {
        return width;
    }

    const std::string& getMessage() const {
        return message;
    }

    const char* what() const noexcept override {
        return message.c_str();
    }
};

// Test functions as requested
void getWidth_test_3573(int c0) {
    IllegalFormatWidthException instance(c0);
    instance.getWidth();
}

void getMessage_test_3574(int c0) {
    IllegalFormatWidthException instance(c0);
    instance.getMessage();
}
```