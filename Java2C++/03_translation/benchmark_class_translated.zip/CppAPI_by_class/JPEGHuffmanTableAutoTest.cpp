```cpp
#include <string>
#include <vector>
#include <cstdint>

// Equivalent of javax.imageio.plugins.jpeg.JPEGHuffmanTable
class JPEGHuffmanTable {
public:
    // Constructor matching Java API: JPEGHuffmanTable(short[] lengths, short[] values)
    JPEGHuffmanTable(const std::vector<short>& lengths, const std::vector<short>& values)
        : lengths_(lengths), values_(values) {}

    // Returns a reference to the internal lengths array (equivalent to Java returning reference)
    const std::vector<short>& getLengths() const {
        return lengths_;
    }

    // Returns a reference to the internal values array
    const std::vector<short>& getValues() const {
        return values_;
    }

    // Returns a simple string representation (mimics Java's toString() output)
    std::string toString() const {
        return "JPEGHuffmanTable";
    }

private:
    std::vector<short> lengths_;
    std::vector<short> values_;
};

// Translated test functions (exact names as in Java)
void getLengths_test_5392(const std::vector<short>& c0, const std::vector<short>& c1) {
    JPEGHuffmanTable instance(c0, c1);
    instance.getLengths();
}

void getValues_test_5393(const std::vector<short>& c0, const std::vector<short>& c1) {
    JPEGHuffmanTable instance(c0, c1);
    instance.getValues();
}

void toString_test_5394(const std::vector<short>& c0, const std::vector<short>& c1) {
    JPEGHuffmanTable instance(c0, c1);
    instance.toString();
}
```