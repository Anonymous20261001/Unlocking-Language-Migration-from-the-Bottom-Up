```cpp
#include <cstdint>
#include <vector>

// Equivalent of Java's javax.crypto.spec.ChaCha20ParameterSpec
class ChaCha20ParameterSpec {
private:
    std::vector<uint8_t> nonce;
    int counter;

public:
    // Constructor: copies the input nonce and stores the counter
    ChaCha20ParameterSpec(const std::vector<uint8_t>& nonce, int counter)
        : nonce(nonce), counter(counter) {}

    // Returns a mutable reference to the internal nonce (matches Java's getNonce() returning byte[])
    std::vector<uint8_t>& getNonce() {
        return nonce;
    }

    // Returns the counter value
    int getCounter() const {
        return counter;
    }
};

// Test function equivalent of getNonce_test_5234
void getNonce_test_5234(const std::vector<uint8_t>& c0, int c1) {
    ChaCha20ParameterSpec instance(c0, c1);
    instance.getNonce();
}

// Test function equivalent of getCounter_test_5235
void getCounter_test_5235(const std::vector<uint8_t>& c0, int c1) {
    ChaCha20ParameterSpec instance(c0, c1);
    instance.getCounter();
}
```