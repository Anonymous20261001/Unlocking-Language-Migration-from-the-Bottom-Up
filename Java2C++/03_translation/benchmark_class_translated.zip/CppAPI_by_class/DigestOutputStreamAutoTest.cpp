```cpp
#include <string>

// Forward declarations
class OutputStream;
class MessageDigest;

// Base classes (mimicking Java's OutputStream and MessageDigest)
class OutputStream {
public:
    virtual ~OutputStream() {}
};

class MessageDigest {
public:
    virtual ~MessageDigest() {}
    virtual std::string toString() const { return "MessageDigest"; }
};

// C++ equivalent of java.security.DigestOutputStream
class DigestOutputStream {
private:
    OutputStream* out;
    MessageDigest* digest;
    bool digestOn;
public:
    DigestOutputStream(OutputStream* os, MessageDigest* md)
        : out(os), digest(md), digestOn(true) {}

    void setMessageDigest(MessageDigest* md) {
        digest = md;
    }

    MessageDigest* getMessageDigest() {
        return digest;
    }

    std::string toString() {
        return std::string("DigestOutputStream: ") +
               (digest ? digest->toString() : "null");
    }

    void on(bool on) {
        digestOn = on;
    }
};

// Test functions (exact names as in Java, parameters follow Java method signatures)
void setMessageDigest_test_2700(MessageDigest* p0, OutputStream* c0, MessageDigest* c1) {
    DigestOutputStream instance(c0, c1);
    instance.setMessageDigest(p0);
}

void getMessageDigest_test_2701(OutputStream* c0, MessageDigest* c1) {
    DigestOutputStream instance(c0, c1);
    instance.getMessageDigest();
}

void toString_test_2702(OutputStream* c0, MessageDigest* c1) {
    DigestOutputStream instance(c0, c1);
    instance.toString();
}

void on_test_2703(bool p0, OutputStream* c0, MessageDigest* c1) {
    DigestOutputStream instance(c0, c1);
    instance.on(p0);
}

// Main function to run all tests (like JUnit runner)
int main() {
    OutputStream out;
    MessageDigest md1, md2;
    bool flag = true;

    setMessageDigest_test_2700(&md2, &out, &md1);
    getMessageDigest_test_2701(&out, &md1);
    toString_test_2702(&out, &md1);
    on_test_2703(flag, &out, &md1);

    return 0;
}
```