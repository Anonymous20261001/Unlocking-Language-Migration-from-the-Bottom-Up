```cpp
#include <cstdint>
#include <vector>

// Minimal ByteBuffer class mimicking Java's ByteBuffer for Adler32 update
class ByteBuffer {
public:
    // Construct from a byte vector (the data is copied)
    ByteBuffer(const std::vector<uint8_t>& data)
        : data_(data), pos_(0), limit_(data.size()) {}

    // Returns true if there are remaining bytes to read
    bool hasRemaining() const {
        return pos_ < limit_;
    }

    // Reads the current byte and advances the position
    uint8_t get() {
        return data_[pos_++];
    }

    // Accessors for position and limit (not strictly needed)
    int position() const { return pos_; }
    int limit() const { return limit_; }
    void position(int p) { pos_ = p; }

private:
    std::vector<uint8_t> data_;
    int pos_;
    int limit_;
};

// C++ equivalent of java.util.zip.Adler32
class Adler32 {
public:
    Adler32() : a_(1), b_(0) {}

    // Resets checksum to initial value
    void reset() {
        a_ = 1;
        b_ = 0;
    }

    // Updates with a single byte (given as int, lower 8 bits used)
    void update(int byteVal) {
        uint8_t byte = static_cast<uint8_t>(byteVal & 0xFF);
        a_ = (a_ + byte) % MOD;
        b_ = (b_ + a_) % MOD;
    }

    // Updates with all remaining bytes from a ByteBuffer,
    // advancing the buffer's position to its limit.
    void update(ByteBuffer& buf) {
        while (buf.hasRemaining()) {
            uint8_t byte = buf.get();
            a_ = (a_ + byte) % MOD;
            b_ = (b_ + a_) % MOD;
        }
    }

    // Updates with a portion of a byte array (vector).
    void update(std::vector<uint8_t>& b, int off, int len) {
        for (int i = off; i < off + len; ++i) {
            a_ = (a_ + b[i]) % MOD;
            b_ = (b_ + a_) % MOD;
        }
    }

    // Returns the current checksum value (as 64-bit to match Java long)
    uint64_t getValue() const {
        return (static_cast<uint64_t>(b_) << 16) | a_;
    }

private:
    static const int MOD = 65521;
    uint32_t a_;
    uint32_t b_;
};

// Translated test functions (exact names and matching parameter types)
void reset_test_5119() {
    Adler32 instance;
    instance.reset();
}

void update_test_5120(int p0) {
    Adler32 instance;
    instance.update(p0);
}

void update_test_5121(ByteBuffer& p0) {
    Adler32 instance;
    instance.update(p0);
}

void update_test_5122(std::vector<uint8_t>& p0, int p1, int p2) {
    Adler32 instance;
    instance.update(p0, p1, p2);
}

void getValue_test_5123() {
    Adler32 instance;
    instance.getValue();
}
```