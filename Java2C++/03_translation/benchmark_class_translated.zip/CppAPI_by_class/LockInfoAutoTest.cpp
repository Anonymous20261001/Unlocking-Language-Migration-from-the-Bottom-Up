```cpp
#include <string>
#include <sstream>

// Minimal CompositeData class with getters for the fields needed by LockInfo::from
class CompositeData {
private:
    std::string className_;
    int identityHashCode_;
public:
    CompositeData(const std::string& cl, int hash)
        : className_(cl), identityHashCode_(hash) {}

    std::string getClassName() const { return className_; }
    int getIdentityHashCode() const { return identityHashCode_; }
};

// C++ equivalent of java.lang.management.LockInfo
class LockInfo {
private:
    std::string className_;
    int identityHashCode_;
public:
    LockInfo(const std::string& cl, int hash)
        : className_(cl), identityHashCode_(hash) {}

    int getIdentityHashCode() const {
        return identityHashCode_;
    }

    std::string getClassName() const {
        return className_;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "LockInfo[" << className_ << " @ " << identityHashCode_ << "]";
        return oss.str();
    }

    static LockInfo from(const CompositeData& cd) {
        return LockInfo(cd.getClassName(), cd.getIdentityHashCode());
    }
};

// --- Test functions (exact translations of the Java @Test methods) ---

void getIdentityHashCode_test_2403(const std::string& c0, int c1) {
    LockInfo instance(c0, c1);
    instance.getIdentityHashCode();
}

void toString_test_2404(const std::string& c0, int c1) {
    LockInfo instance(c0, c1);
    instance.toString();
}

void from_test_2405(const CompositeData& p0, const std::string& c0, int c1) {
    LockInfo instance(c0, c1);
    LockInfo::from(p0);
}

void getClassName_test_2406(const std::string& c0, int c1) {
    LockInfo instance(c0, c1);
    instance.getClassName();
}
```