```cpp
#include <cstddef>

class FileDescriptor {
private:
    int fd;

public:
    FileDescriptor() : fd(-1) {}

    bool valid() const {
        return fd >= 0;
    }
};

void valid_test_1774() {
    FileDescriptor instance;
    instance.valid();
}
```