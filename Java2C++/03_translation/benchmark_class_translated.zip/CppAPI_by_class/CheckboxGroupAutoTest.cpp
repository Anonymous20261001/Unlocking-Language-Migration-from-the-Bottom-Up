```cpp
#include <string>
#include <utility>

class CheckboxGroup; // forward declaration

class Checkbox {
private:
    std::string label;
    bool state;
    CheckboxGroup* group;

public:
    Checkbox() : label(""), state(false), group(nullptr) {}
    explicit Checkbox(std::string lbl) : label(std::move(lbl)), state(false), group(nullptr) {}
    Checkbox(const Checkbox&) = delete;
    Checkbox& operator=(const Checkbox&) = delete;

    const std::string& getLabel() const { return label; }
    bool getState() const { return state; }
    void setState(bool s) { state = s; }
    CheckboxGroup* getGroup() const { return group; }
    void setGroup(CheckboxGroup* g) { group = g; }
};

class CheckboxGroup {
private:
    Checkbox* selected;

public:
    CheckboxGroup() : selected(nullptr) {}

    Checkbox* getSelectedCheckbox() const {
        return selected;
    }

    void setSelectedCheckbox(Checkbox* cb) {
        if (cb == selected) return; // no change
        // Deselect current
        if (selected && selected != cb) {
            selected->setState(false);
        }
        // Select new
        if (cb) {
            cb->setState(true);
            // Ensure checkbox belongs to this group
            if (cb->getGroup() != this) {
                cb->setGroup(this);
            }
        }
        selected = cb;
    }

    // Deprecated synonyms
    Checkbox* getCurrent() const {
        return getSelectedCheckbox();
    }

    void setCurrent(Checkbox* cb) {
        setSelectedCheckbox(cb);
    }

    std::string toString() const {
        if (selected) {
            return "java.awt.CheckboxGroup[selectedCheckbox=" + selected->getLabel() + "]";
        } else {
            return "java.awt.CheckboxGroup[selectedCheckbox=null]";
        }
    }
};

// Test functions matching the Java @Test methods

void setSelectedCheckbox_test_61(Checkbox* p0) {
    CheckboxGroup instance;
    instance.setSelectedCheckbox(p0);
}

void getSelectedCheckbox_test_62() {
    CheckboxGroup instance;
    instance.getSelectedCheckbox();
}

void getCurrent_test_63() {
    CheckboxGroup instance;
    instance.getCurrent();
}

void setCurrent_test_64(Checkbox* p0) {
    CheckboxGroup instance;
    instance.setCurrent(p0);
}

void toString_test_65() {
    CheckboxGroup instance;
    instance.toString();
}
```