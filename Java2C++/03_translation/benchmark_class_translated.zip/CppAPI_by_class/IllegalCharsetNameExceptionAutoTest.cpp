```cpp
#include <string>
#include <stdexcept>

class IllegalCharsetNameException : public std::invalid_argument {
public:
    explicit IllegalCharsetNameException(const std::string& charsetName)
        : std::invalid_argument("Illegal charset name: " + charsetName)
        , charsetName_(charsetName) {}

    const std::string& getCharsetName() const noexcept {
        return charsetName_;
    }

private:
    std::string charsetName_;
};

void getCharsetName_test_2641(const std::string& c0) {
    IllegalCharsetNameException instance(c0);
    instance.getCharsetName();
}
```