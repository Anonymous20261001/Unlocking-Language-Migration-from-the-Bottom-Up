```cpp
#include <stdexcept>

// Base interface for XMLEventReader
class XMLEventReader {
public:
    virtual bool hasNext() = 0;
    virtual void next() = 0;
    virtual void remove() = 0;
    virtual ~XMINEventReader() = default;
};

// Concrete dummy implementation for testing
class DummyXMLEventReader : public XMLEventReader {
public:
    bool hasNext() override { return false; }
    void next() override {}
    void remove() override {}
};

// EventReaderDelegate that delegates to a parent XMLEventReader
class EventReaderDelegate : public XMLEventReader {
private:
    XMLEventReader* parent;
public:
    EventReaderDelegate() : parent(nullptr) {}

    XMLEventReader* getParent() const {
        return parent;
    }

    void setParent(XMLEventReader* p) {
        parent = p;
    }

    bool hasNext() override {
        if (parent)
            return parent->hasNext();
        throw std::runtime_error("NullPointerException: parent is null");
    }

    void next() override {
        if (parent)
            parent->next();
        else
            throw std::runtime_error("NullPointerException: parent is null");
    }

    void remove() override {
        if (parent)
            parent->remove();
        else
            throw std::runtime_error("NullPointerException: parent is null");
    }
};

// Test functions (translated from the Java @Test methods)
void remove_test_10914() {
    EventReaderDelegate instance;
    instance.remove();
}

void hasNext_test_10915() {
    EventReaderDelegate instance;
    instance.hasNext();
}

void next_test_10916() {
    EventReaderDelegate instance;
    instance.next();
}

void getParent_test_10917() {
    EventReaderDelegate instance;
    instance.getParent();
}

void setParent_test_10918() {
    EventReaderDelegate instance;
    DummyXMLEventReader dummy;
    instance.setParent(&dummy);
}

// Optional main to run all tests (similar to JUnit running them)
int main() {
    // In the original Java tests, uncaught exceptions would cause test failures.
    // Here we call them directly; if any throw, the program will terminate.
    remove_test_10914();
    hasNext_test_10915();
    next_test_10916();
    getParent_test_10917();
    setParent_test_10918();
    return 0;
}
```