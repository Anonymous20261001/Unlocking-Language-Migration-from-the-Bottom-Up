```cpp
#include <string>
#include <stdexcept>

// Minimal BigInteger class for compatibility with the tests.
class BigInteger {
public:
    BigInteger() : value_("0") {}
    BigInteger(const std::string& val) : value_(val) {}
    BigInteger(const char* val) : value_(val) {}
    BigInteger(const BigInteger&) = default;
    BigInteger& operator=(const BigInteger&) = default;

    const std::string& toString() const { return value_; }

    // Comparison operators required for some internal uses (not used here)
    bool operator==(const BigInteger& other) const { return value_ == other.value_; }
    bool operator!=(const BigInteger& other) const { return !(*this == other); }

private:
    std::string value_;
};

// C++ equivalent of java.security.spec.DSAParameterSpec
class DSAParameterSpec {
public:
    DSAParameterSpec(const BigInteger& p, const BigInteger& q, const BigInteger& g)
        : p_(p), q_(q), g_(g) {}

    const BigInteger& getP() const { return p_; }
    const BigInteger& getQ() const { return q_; }
    const BigInteger& getG() const { return g_; }

private:
    BigInteger p_, q_, g_;
};

// Test functions (equivalent to the Java @Test methods)
void getP_test_2848(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance(c0, c1, c2);
    instance.getP();
}

void getQ_test_2849(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance(c0, c1, c2);
    instance.getQ();
}

void getG_test_2850(BigInteger c0, BigInteger c1, BigInteger c2) {
    DSAParameterSpec instance(c0, c1, c2);
    instance.getG();
}
```