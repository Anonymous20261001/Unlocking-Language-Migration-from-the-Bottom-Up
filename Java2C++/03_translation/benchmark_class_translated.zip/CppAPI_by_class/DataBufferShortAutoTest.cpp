```cpp
#include <vector>
#include <cstdint>
#include <stdexcept>

class DataBufferShort {
public:
    // Construct a single bank of 'size' shorts, all initialized to 0.
    explicit DataBufferShort(int size) {
        if (size < 0) {
            throw std::invalid_argument("Negative size");
        }
        banks_.emplace_back(size, 0);
    }

    // Return the entire bank data (2D vector).
    std::vector<std::vector<short>>& getBankData() {
        return banks_;
    }

    const std::vector<std::vector<short>>& getBankData() const {
        return banks_;
    }

    // Get element at (bank, index).
    short getElem(int bank, int index) const {
        return banks_.at(bank).at(index);
    }

    // Get element from bank 0.
    short getElem(int index) const {
        return banks_.at(0).at(index);
    }

    // Set element at (bank, index).
    void setElem(int bank, int index, int value) {
        banks_.at(bank).at(index) = static_cast<short>(value);
    }

    // Set element at bank 0.
    void setElem(int index, int value) {
        banks_.at(0).at(index) = static_cast<short>(value);
    }

    // Get data (one bank) by bank index.
    std::vector<short>& getData(int bank) {
        return banks_.at(bank);
    }

    const std::vector<short>& getData(int bank) const {
        return banks_.at(bank);
    }

    // Get data from bank 0.
    std::vector<short>& getData() {
        return banks_.at(0);
    }

    const std::vector<short>& getData() const {
        return banks_.at(0);
    }

private:
    std::vector<std::vector<short>> banks_;
};

// ------------------------------------------------------------
// Test functions (translated from JUnit @Test methods)
// ------------------------------------------------------------

void getBankData_test_1227(int c0) {
    DataBufferShort instance(c0);
    instance.getBankData();
}

void getElem_test_1228(int p0, int p1, int c0) {
    DataBufferShort instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1229(int p0, int c0) {
    DataBufferShort instance(c0);
    instance.getElem(p0);
}

void setElem_test_1230(int p0, int p1, int p2, int c0) {
    DataBufferShort instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1231(int p0, int p1, int c0) {
    DataBufferShort instance(c0);
    instance.setElem(p0, p1);
}

void getData_test_1232(int p0, int c0) {
    DataBufferShort instance(c0);
    instance.getData(p0);
}

void getData_test_1233(int c0) {
    DataBufferShort instance(c0);
    instance.getData();
}
```