```cpp
#include <vector>
#include <algorithm>
#include <memory>
#include <mutex>
#include <string>
#include <iostream>
#include <cstddef>

// ------------------------------------------------------------
// Java-like base classes and interfaces
// ------------------------------------------------------------

class Object {
public:
    virtual ~Object() = default;
    virtual std::string toString() const { return "Object"; }
    virtual bool equals(const Object* other) const { return this == other; }
    virtual size_t hashCode() const { return reinterpret_cast<size_t>(this); }
    virtual Object* clone() const { return new Object(*this); }
};

class Collection {
public:
    virtual ~Collection() = default;
    virtual size_t size() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool contains(const Object* o) const = 0;
    virtual std::vector<Object*> toArray() const = 0;
    virtual bool add(Object* e) = 0;
    virtual bool remove(const Object* o) = 0;
    virtual bool containsAll(const Collection& c) const = 0;
    virtual bool addAll(const Collection& c) = 0;
    virtual bool removeAll(const Collection& c) = 0;
    virtual bool retainAll(const Collection& c) = 0;
    virtual void clear() = 0;
};

class Comparator {
public:
    virtual ~Comparator() = default;
    virtual int compare(const Object* a, const Object* b) const = 0;
};

class Consumer {
public:
    virtual ~Consumer() = default;
    virtual void accept(Object* t) = 0;
};

class Predicate {
public:
    virtual ~Predicate() = default;
    virtual bool test(Object* t) = 0;
};

class UnaryOperator {
public:
    virtual ~UnaryOperator() = default;
    virtual Object* apply(Object* t) = 0;
};

// ------------------------------------------------------------
// Iterator (simplified forward iterator)
// ------------------------------------------------------------
class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() const = 0;
    virtual Object* next() = 0;
};

class ListIterator : public Iterator {
public:
    virtual bool hasPrevious() const = 0;
    virtual Object* previous() = 0;
    virtual int nextIndex() const = 0;
    virtual int previousIndex() const = 0;
    virtual void set(Object* e) = 0;
    virtual void add(Object* e) = 0;
};

class Spliterator {
public:
    virtual ~Spliterator() = default;
    // simplified stub
};

// ------------------------------------------------------------
// CopyOnWriteArrayList (simplified, not thread-safe for brevity)
// ------------------------------------------------------------
class CopyOnWriteArrayList : public Collection {
private:
    std::vector<Object*> data;
    mutable std::mutex mtx;

    void copyOnWrite() {
        if (!data.empty()) {
            data = data; // no-op in single-threaded, but concept: make a copy
        }
    }

public:
    CopyOnWriteArrayList() = default;
    CopyOnWriteArrayList(const CopyOnWriteArrayList& other) : data(other.data) {}
    CopyOnWriteArrayList& operator=(const CopyOnWriteArrayList& other) {
        if (this != &other) {
            std::lock_guard<std::mutex> lock(mtx);
            data = other.data;
        }
        return *this;
    }
    ~CopyOnWriteArrayList() override {
        for (auto* o : data) {
            delete o;
        }
    }

    // ---------- Collection interface ----------
    size_t size() const override {
        std::lock_guard<std::mutex> lock(mtx);
        return data.size();
    }

    bool isEmpty() const override {
        std::lock_guard<std::mutex> lock(mtx);
        return data.empty();
    }

    bool contains(const Object* o) const override {
        std::lock_guard<std::mutex> lock(mtx);
        return std::find(data.begin(), data.end(), o) != data.end();
    }

    std::vector<Object*> toArray() const override {
        std::lock_guard<std::mutex> lock(mtx);
        return data;
    }

    bool add(Object* e) override {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        data.push_back(e);
        return true;
    }

    bool remove(const Object* o) override {
        std::lock_guard<std::mutex> lock(mtx);
        auto it = std::find(data.begin(), data.end(), o);
        if (it != data.end()) {
            copyOnWrite();
            data.erase(it);
            return true;
        }
        return false;
    }

    bool containsAll(const Collection& c) const override {
        std::lock_guard<std::mutex> lock(mtx);
        auto arr = c.toArray();
        for (auto* o : arr) {
            if (std::find(data.begin(), data.end(), o) == data.end())
                return false;
        }
        return true;
    }

    bool addAll(const Collection& c) override {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        auto arr = c.toArray();
        data.insert(data.end(), arr.begin(), arr.end());
        return !arr.empty();
    }

    bool removeAll(const Collection& c) override {
        std::lock_guard<std::mutex> lock(mtx);
        auto arr = c.toArray();
        bool changed = false;
        for (auto* o : arr) {
            auto it = std::find(data.begin(), data.end(), o);
            if (it != data.end()) {
                copyOnWrite();
                data.erase(it);
                changed = true;
            }
        }
        return changed;
    }

    bool retainAll(const Collection& c) override {
        std::lock_guard<std::mutex> lock(mtx);
        auto arr = c.toArray();
        std::vector<Object*> newData;
        for (auto* o : data) {
            if (std::find(arr.begin(), arr.end(), o) != arr.end()) {
                newData.push_back(o);
            }
        }
        if (newData.size() != data.size()) {
            copyOnWrite();
            data = newData;
            return true;
        }
        return false;
    }

    void clear() override {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        for (auto* o : data) delete o;
        data.clear();
    }

    // ---------- List operations ----------
    Object* get(int index) const {
        std::lock_guard<std::mutex> lock(mtx);
        return data.at(index);
    }

    Object* set(int index, Object* element) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        Object* old = data[index];
        data[index] = element;
        return old;
    }

    void add(int index, Object* element) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        data.insert(data.begin() + index, element);
    }

    Object* remove(int index) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        Object* old = data[index];
        data.erase(data.begin() + index);
        return old;
    }

    int indexOf(const Object* o) const {
        std::lock_guard<std::mutex> lock(mtx);
        for (size_t i = 0; i < data.size(); ++i) {
            if (data[i] == o) return static_cast<int>(i);
        }
        return -1;
    }

    int indexOf(const Object* o, int index) const {
        std::lock_guard<std::mutex> lock(mtx);
        for (int i = index; i < static_cast<int>(data.size()); ++i) {
            if (data[i] == o) return i;
        }
        return -1;
    }

    int lastIndexOf(const Object* o) const {
        std::lock_guard<std::mutex> lock(mtx);
        for (int i = static_cast<int>(data.size()) - 1; i >= 0; --i) {
            if (data[i] == o) return i;
        }
        return -1;
    }

    int lastIndexOf(const Object* o, int index) const {
        std::lock_guard<std::mutex> lock(mtx);
        for (int i = index; i >= 0; --i) {
            if (data[i] == o) return i;
        }
        return -1;
    }

    CopyOnWriteArrayList* subList(int fromIndex, int toIndex) {
        std::lock_guard<std::mutex> lock(mtx);
        auto* sub = new CopyOnWriteArrayList();
        sub->data.assign(data.begin() + fromIndex, data.begin() + toIndex);
        return sub;
    }

    void sort(Comparator* comp) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        std::sort(data.begin(), data.end(),
            [comp](Object* a, Object* b) {
                return comp->compare(a, b) < 0;
            });
    }

    void replaceAll(UnaryOperator* op) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        for (auto& o : data) {
            o = op->apply(o);
        }
    }

    void forEach(Consumer* action) {
        std::lock_guard<std::mutex> lock(mtx);
        for (auto* o : data) {
            action->accept(o);
        }
    }

    bool removeIf(Predicate* filter) {
        std::lock_guard<std::mutex> lock(mtx);
        bool changed = false;
        for (auto it = data.begin(); it != data.end(); ) {
            if (filter->test(*it)) {
                copyOnWrite();
                it = data.erase(it);
                changed = true;
            } else {
                ++it;
            }
        }
        return changed;
    }

    // ---------- Deque-like methods ----------
    Object* getFirst() const {
        std::lock_guard<std::mutex> lock(mtx);
        return data.front();
    }

    Object* getLast() const {
        std::lock_guard<std::mutex> lock(mtx);
        return data.back();
    }

    void addFirst(Object* e) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        data.insert(data.begin(), e);
    }

    void addLast(Object* e) {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        data.push_back(e);
    }

    Object* removeFirst() {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        Object* front = data.front();
        data.erase(data.begin());
        return front;
    }

    Object* removeLast() {
        std::lock_guard<std::mutex> lock(mtx);
        copyOnWrite();
        Object* back = data.back();
        data.pop_back();
        return back;
    }

    // ---------- Other methods ----------
    bool addIfAbsent(Object* e) {
        std::lock_guard<std::mutex> lock(mtx);
        if (std::find(data.begin(), data.end(), e) == data.end()) {
            copyOnWrite();
            data.push_back(e);
            return true;
        }
        return false;
    }

    int addAllAbsent(const Collection& c) {
        std::lock_guard<std::mutex> lock(mtx);
        auto arr = c.toArray();
        int added = 0;
        for (auto* o : arr) {
            if (std::find(data.begin(), data.end(), o) == data.end()) {
                copyOnWrite();
                data.push_back(o);
                ++added;
            }
        }
        return added;
    }

    // ---------- ToArray with array argument ----------
    Object** toArray(Object** a) const {
        std::lock_guard<std::mutex> lock(mtx);
        size_t sz = data.size();
        if (a && sz <= sizeof(a)/sizeof(a[0])) {
            std::copy(data.begin(), data.end(), a);
            return a;
        }
        auto* newArr = new Object*[sz];
        std::copy(data.begin(), data.end(), newArr);
        return newArr;
    }

    // Iterator (simplified, returns raw pointer, user must delete)
    Iterator* iterator() {
        class SimpleIterator : public Iterator {
            const std::vector<Object*>& ref;
            size_t pos;
        public:
            SimpleIterator(const std::vector<Object*>& r) : ref(r), pos(0) {}
            bool hasNext() const override { return pos < ref.size(); }
            Object* next() override { return ref[pos++]; }
        };
        std::lock_guard<std::mutex> lock(mtx);
        return new SimpleIterator(data);
    }

    ListIterator* listIterator() {
        class SimpleListIterator : public ListIterator {
            const std::vector<Object*>& ref;
            int pos;
        public:
            SimpleListIterator(const std::vector<Object*>& r) : ref(r), pos(0) {}
            bool hasNext() const override { return pos < static_cast<int>(ref.size()); }
            Object* next() override { return ref[pos++]; }
            bool hasPrevious() const override { return pos > 0; }
            Object* previous() override { return ref[--pos]; }
            int nextIndex() const override { return pos; }
            int previousIndex() const override { return pos - 1; }
            void set(Object* e) override { /* mutable? no */ }
            void add(Object* e) override { /* not supported */ }
        };
        std::lock_guard<std::mutex> lock(mtx);
        return new SimpleListIterator(data);
    }

    ListIterator* listIterator(int index) {
        class SimpleListIterator : public ListIterator {
            const std::vector<Object*>& ref;
            int pos;
        public:
            SimpleListIterator(const std::vector<Object*>& r, int idx) : ref(r), pos(idx) {}
            bool hasNext() const override { return pos < static_cast<int>(ref.size()); }
            Object* next() override { return ref[pos++]; }
            bool hasPrevious() const override { return pos > 0; }
            Object* previous() override { return ref[--pos]; }
            int nextIndex() const override { return pos; }
            int previousIndex() const override { return pos - 1; }
            void set(Object* e) override {}
            void add(Object* e) override {}
        };
        std::lock_guard<std::mutex> lock(mtx);
        return new SimpleListIterator(data, index);
    }

    Spliterator* spliterator() {
        return new Spliterator();
    }

    CopyOnWriteArrayList* reversed() {
        std::lock_guard<std::mutex> lock(mtx);
        auto* rev = new CopyOnWriteArrayList();
        rev->data.assign(data.rbegin(), data.rend());
        return rev;
    }

    CopyOnWriteArrayList* clone() const {
        std::lock_guard<std::mutex> lock(mtx);
        return new CopyOnWriteArrayList(*this);
    }

    bool equals(const Object* other) const override {
        auto* rhs = dynamic_cast<const CopyOnWriteArrayList*>(other);
        if (!rhs) return false;
        std::lock_guard<std::mutex> lock(mtx);
        std::lock_guard<std::mutex> lock2(rhs->mtx);
        return data == rhs->data;
    }

    std::string toString() const override {
        std::lock_guard<std::mutex> lock(mtx);
        std::string s = "[";
        for (size_t i = 0; i < data.size(); ++i) {
            if (i > 0) s += ", ";
            s += data[i]->toString();
        }
        s += "]";
        return s;
    }

    size_t hashCode() const override {
        std::lock_guard<std::mutex> lock(mtx);
        size_t h = 1;
        for (auto* o : data) {
            h = 31 * h + (o ? o->hashCode() : 0);
        }
        return h;
    }
};

// ------------------------------------------------------------
// Test functions (matching the Java test methods)
// ------------------------------------------------------------

void remove_test_4381(int p0) {
    CopyOnWriteArrayList instance;
    instance.remove(p0);
}

void remove_test_4382(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.remove(p0);
}

void size_test_4383() {
    CopyOnWriteArrayList instance;
    instance.size();
}

void get_test_4384(int p0) {
    CopyOnWriteArrayList instance;
    instance.get(p0);
}

void equals_test_4385(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.equals(p0);
}

void toString_test_4386() {
    CopyOnWriteArrayList instance;
    instance.toString();
}

void hashCode_test_4387() {
    CopyOnWriteArrayList instance;
    instance.hashCode();
}

void clone_test_4388() {
    CopyOnWriteArrayList instance;
    instance.clone();
}

void sort_test_4389(Comparator* p0) {
    CopyOnWriteArrayList instance;
    instance.sort(p0);
}

void indexOf_test_4390(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.indexOf(p0);
}

void indexOf_test_4391(Object* p0, int p1) {
    CopyOnWriteArrayList instance;
    instance.indexOf(p0, p1);
}

void clear_test_4392() {
    CopyOnWriteArrayList instance;
    instance.clear();
}

void lastIndexOf_test_4393(Object* p0, int p1) {
    CopyOnWriteArrayList instance;
    instance.lastIndexOf(p0, p1);
}

void lastIndexOf_test_4394(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.lastIndexOf(p0);
}

void isEmpty_test_4395() {
    CopyOnWriteArrayList instance;
    instance.isEmpty();
}

void replaceAll_test_4396(UnaryOperator* p0) {
    CopyOnWriteArrayList instance;
    instance.replaceAll(p0);
}

void add_test_4397(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.add(p0);
}

void add_test_4398(int p0, Object* p1) {
    CopyOnWriteArrayList instance;
    instance.add(p0, p1);
}

void subList_test_4399(int p0, int p1) {
    CopyOnWriteArrayList instance;
    instance.subList(p0, p1);
}

void toArray_test_4400(Object** p0) {
    CopyOnWriteArrayList instance;
    instance.toArray(p0);
}

void toArray_test_4401() {
    CopyOnWriteArrayList instance;
    instance.toArray();
}

void iterator_test_4402() {
    CopyOnWriteArrayList instance;
    instance.iterator();
}

void contains_test_4403(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.contains(p0);
}

void spliterator_test_4404() {
    CopyOnWriteArrayList instance;
    instance.spliterator();
}

void addAll_test_4405(Collection* p0) {
    CopyOnWriteArrayList instance;
    instance.addAll(*p0);
}

void addAll_test_4406(int p0, Collection* p1) {
    CopyOnWriteArrayList instance;
    instance.addAll(p0, *p1);
}

void set_test_4407(int p0, Object* p1) {
    CopyOnWriteArrayList instance;
    instance.set(p0, p1);
}

void forEach_test_4408(Consumer* p0) {
    CopyOnWriteArrayList instance;
    instance.forEach(p0);
}

void removeIf_test_4409(Predicate* p0) {
    CopyOnWriteArrayList instance;
    instance.removeIf(p0);
}

void getFirst_test_4410() {
    CopyOnWriteArrayList instance;
    instance.getFirst();
}

void getLast_test_4411() {
    CopyOnWriteArrayList instance;
    instance.getLast();
}

void addFirst_test_4412(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.addFirst(p0);
}

void addLast_test_4413(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.addLast(p0);
}

void removeFirst_test_4414() {
    CopyOnWriteArrayList instance;
    instance.removeFirst();
}

void removeLast_test_4415() {
    CopyOnWriteArrayList instance;
    instance.removeLast();
}

void removeAll_test_4416(Collection* p0) {
    CopyOnWriteArrayList instance;
    instance.removeAll(*p0);
}

void retainAll_test_4417(Collection* p0) {
    CopyOnWriteArrayList instance;
    instance.retainAll(*p0);
}

void listIterator_test_4418() {
    CopyOnWriteArrayList instance;
    instance.listIterator();
}

void listIterator_test_4419(int p0) {
    CopyOnWriteArrayList instance;
    instance.listIterator(p0);
}

void reversed_test_4420() {
    CopyOnWriteArrayList instance;
    instance.reversed();
}

void containsAll_test_4421(Collection* p0) {
    CopyOnWriteArrayList instance;
    instance.containsAll(*p0);
}

void addIfAbsent_test_4422(Object* p0) {
    CopyOnWriteArrayList instance;
    instance.addIfAbsent(p0);
}

void addAllAbsent_test_4423(Collection* p0) {
    CopyOnWriteArrayList instance;
    instance.addAllAbsent(*p0);
}
```