```cpp
#include <string>
#include <vector>
#include <stdexcept>

// Minimal AWT-like classes for CardLayout stub implementation

class Object {
public:
    virtual ~Object() = default;
};

class Component : public Object {
public:
    virtual ~Component() = default;
};

class Container : public Component {
public:
    virtual ~Container() = default;
    // Minimal: no children tracking needed for stubs
};

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class CardLayout : public Object {
private:
    int hgap_;
    int vgap_;
    // For simplicity, we don't maintain a component list; stubs operate on empty state.

public:
    CardLayout() : hgap_(0), vgap_(0) {}
    CardLayout(int hgap, int vgap) : hgap_(hgap), vgap_(vgap) {}

    // LayoutManager2 / LayoutManager interface methods (stubs)
    void removeLayoutComponent(Component& /*comp*/) {
        // stub: do nothing
    }

    void addLayoutComponent(const std::string& /*name*/, Component& /*comp*/) {
        // stub: do nothing
    }

    void addLayoutComponent(Component& /*comp*/, Object& /*constraints*/) {
        // stub: do nothing
    }

    void layoutContainer(Container& /*parent*/) {
        // stub: do nothing
    }

    void invalidateLayout(Container& /*target*/) {
        // stub: do nothing
    }

    Dimension preferredLayoutSize(Container& /*parent*/) {
        return Dimension(10, 10); // dummy
    }

    Dimension minimumLayoutSize(Container& /*parent*/) {
        return Dimension(10, 10); // dummy
    }

    Dimension maximumLayoutSize(Container& /*target*/) {
        return Dimension(32767, 32767); // default maximum
    }

    float getLayoutAlignmentX(Container& /*parent*/) {
        return 0.5f; // center alignment
    }

    float getLayoutAlignmentY(Container& /*parent*/) {
        return 0.5f; // center alignment
    }

    void show(Container& /*parent*/, const std::string& /*name*/) {
        // stub: do nothing
    }

    int getHgap() const {
        return hgap_;
    }

    void setHgap(int hgap) {
        hgap_ = hgap;
    }

    int getVgap() const {
        return vgap_;
    }

    void setVgap(int vgap) {
        vgap_ = vgap;
    }

    std::string toString() const {
        return "CardLayout[hgap=" + std::to_string(hgap_) + ",vgap=" + std::to_string(vgap_) + "]";
    }

    void next(Container& /*parent*/) {
        // stub: should cycle to next card; no-op
    }

    void previous(Container& /*parent*/) {
        // stub: no-op
    }

    void first(Container& /*parent*/) {
        // stub: no-op
    }

    void last(Container& /*parent*/) {
        // stub: no-op
    }
};

// ========== Test functions ==========

void removeLayoutComponent_test_41(Component& p0) {
    CardLayout instance;
    instance.removeLayoutComponent(p0);
}

void addLayoutComponent_test_42(const std::string& p0, Component& p1) {
    CardLayout instance;
    instance.addLayoutComponent(p0, p1);
}

void addLayoutComponent_test_43(Component& p0, Object& p1) {
    CardLayout instance;
    instance.addLayoutComponent(p0, p1);
}

void layoutContainer_test_44(Container& p0) {
    CardLayout instance;
    instance.layoutContainer(p0);
}

void invalidateLayout_test_45(Container& p0) {
    CardLayout instance;
    instance.invalidateLayout(p0);
}

void preferredLayoutSize_test_46(Container& p0) {
    CardLayout instance;
    instance.preferredLayoutSize(p0);
}

void minimumLayoutSize_test_47(Container& p0) {
    CardLayout instance;
    instance.minimumLayoutSize(p0);
}

void maximumLayoutSize_test_48(Container& p0) {
    CardLayout instance;
    instance.maximumLayoutSize(p0);
}

void getLayoutAlignmentX_test_49(Container& p0) {
    CardLayout instance;
    instance.getLayoutAlignmentX(p0);
}

void getLayoutAlignmentY_test_50(Container& p0) {
    CardLayout instance;
    instance.getLayoutAlignmentY(p0);
}

void show_test_51(Container& p0, const std::string& p1) {
    CardLayout instance;
    instance.show(p0, p1);
}

void getHgap_test_52() {
    CardLayout instance;
    instance.getHgap();
}

void setHgap_test_53(int p0) {
    CardLayout instance;
    instance.setHgap(p0);
}

void getVgap_test_54() {
    CardLayout instance;
    instance.getVgap();
}

void setVgap_test_55(int p0) {
    CardLayout instance;
    instance.setVgap(p0);
}

void toString_test_56() {
    CardLayout instance;
    instance.toString();
}

void next_test_57(Container& p0) {
    CardLayout instance;
    instance.next(p0);
}

void last_test_58(Container& p0) {
    CardLayout instance;
    instance.last(p0);
}

void first_test_59(Container& p0) {
    CardLayout instance;
    instance.first(p0);
}

void previous_test_60(Container& p0) {
    CardLayout instance;
    instance.previous(p0);
}
```