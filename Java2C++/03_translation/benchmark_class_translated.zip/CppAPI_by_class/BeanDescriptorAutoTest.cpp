```cpp
#include <string>

// Mimics java.lang.Class as a simple wrapper around a class name.
class Class {
public:
    std::string name;

    Class() : name() {}
    explicit Class(const std::string& className) : name(className) {}
    // Copy constructor, assignment, etc. are compiler-generated.
};

// Mimics java.beans.BeanDescriptor.
class BeanDescriptor {
private:
    Class beanClass_;
    Class customizerClass_;

public:
    explicit BeanDescriptor(const Class& beanClass)
        : beanClass_(beanClass), customizerClass_() {}

    BeanDescriptor(const Class& beanClass, const Class& customizerClass)
        : beanClass_(beanClass), customizerClass_(customizerClass) {}

    Class getBeanClass() const {
        return beanClass_;
    }

    Class getCustomizerClass() const {
        return customizerClass_;
    }
};

// Test functions equivalent to the Java @Test methods.
void getBeanClass_test_1510(Class c0) {
    BeanDescriptor instance(c0);
    instance.getBeanClass();
}

void getCustomizerClass_test_1511(Class c0) {
    BeanDescriptor instance(c0);
    instance.getCustomizerClass();
}
```