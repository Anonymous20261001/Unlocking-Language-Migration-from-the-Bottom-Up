```cpp
#include <map>
#include <vector>
#include <functional>
#include <optional>
#include <stdexcept>
#include <cstddef>
#include <algorithm>
#include <iostream>

// Minimal types to mimic Java's Map.Entry, Set, Collection
template<typename K, typename V>
struct SimpleEntry {
    K key;
    V value;
};

// C++ equivalent of ConcurrentSkipListMap (non-concurrent, using std::map)
template<typename K, typename V>
class ConcurrentSkipListMap {
private:
    std::map<K, V> data;
    std::function<bool(const K&, const K&)> comp;

public:
    // Default constructor uses std::less<K>
    ConcurrentSkipListMap() : comp(std::less<K>()) {}

    explicit ConcurrentSkipListMap(std::function<bool(const K&, const K&)> comparator)
        : comp(comparator) {}

    // ---------- Basic operations ----------
    size_t size() const { return data.size(); }

    bool isEmpty() const { return data.empty(); }

    void clear() { data.clear(); }

    V get(const K& key) const {
        auto it = data.find(key);
        if (it != data.end()) return it->second;
        return V{}; // default
    }

    V put(const K& key, const V& value) {
        V old = V{};
        auto it = data.find(key);
        if (it != data.end()) old = it->second;
        data[key] = value;
        return old;
    }

    V remove(const K& key) {
        V old = V{};
        auto it = data.find(key);
        if (it != data.end()) {
            old = it->second;
            data.erase(it);
        }
        return old;
    }

    bool remove(const K& key, const V& value) {
        auto it = data.find(key);
        if (it != data.end() && it->second == value) {
            data.erase(it);
            return true;
        }
        return false;
    }

    bool containsKey(const K& key) const {
        return data.find(key) != data.end();
    }

    bool containsValue(const V& value) const {
        for (const auto& [k, v] : data) {
            if (v == value) return true;
        }
        return false;
    }

    V getOrDefault(const K& key, const V& defaultValue) const {
        auto it = data.find(key);
        if (it != data.end()) return it->second;
        return defaultValue;
    }

    // ---------- replace ----------
    V replace(const K& key, const V& value) {
        auto it = data.find(key);
        if (it != data.end()) {
            V old = it->second;
            it->second = value;
            return old;
        }
        return V{};
    }

    bool replace(const K& key, const V& oldValue, const V& newValue) {
        auto it = data.find(key);
        if (it != data.end() && it->second == oldValue) {
            it->second = newValue;
            return true;
        }
        return false;
    }

    void replaceAll(std::function<V(const K&, const V&)> function) {
        for (auto& [k, v] : data) {
            v = function(k, v);
        }
    }

    // ---------- putIfAbsent / compute ----------
    V putIfAbsent(const K& key, const V& value) {
        auto [it, inserted] = data.try_emplace(key, value);
        if (!inserted) return it->second;
        return V{}; // no old value
    }

    V compute(const K& key, std::function<V(const K&, const std::optional<V>&)> remappingFunction) {
        V newValue;
        auto it = data.find(key);
        if (it != data.end()) {
            newValue = remappingFunction(key, std::optional<V>(it->second));
        } else {
            newValue = remappingFunction(key, std::nullopt);
        }
        if (newValue == V{}) {
            // If remapping returns null (default), remove the entry
            if (it != data.end()) data.erase(it);
            return V{};
        }
        data[key] = newValue;
        return newValue;
    }

    V computeIfAbsent(const K& key, std::function<V(const K&)> mappingFunction) {
        auto it = data.find(key);
        if (it != data.end()) return it->second;
        V value = mappingFunction(key);
        if (value != V{}) {
            data[key] = value;
        }
        return value;
    }

    V computeIfPresent(const K& key, std::function<V(const K&, const V&)> remappingFunction) {
        auto it = data.find(key);
        if (it != data.end()) {
            V newValue = remappingFunction(key, it->second);
            if (newValue == V{}) {
                data.erase(it);
                return V{};
            }
            it->second = newValue;
            return newValue;
        }
        return V{};
    }

    // ---------- merge ----------
    V merge(const K& key, const V& value,
            std::function<V(const V&, const V&)> remappingFunction) {
        auto it = data.find(key);
        if (it != data.end()) {
            it->second = remappingFunction(it->second, value);
            return it->second;
        } else {
            data[key] = value;
            return value;
        }
    }

    // ---------- views (return simplified containers) ----------
    std::vector<K> keySet() const {
        std::vector<K> keys;
        keys.reserve(data.size());
        for (const auto& [k, v] : data) keys.push_back(k);
        return keys;
    }

    std::vector<V> values() const {
        std::vector<V> vals;
        vals.reserve(data.size());
        for (const auto& [k, v] : data) vals.push_back(v);
        return vals;
    }

    std::vector<SimpleEntry<K, V>> entrySet() const {
        std::vector<SimpleEntry<K, V>> entries;
        entries.reserve(data.size());
        for (const auto& [k, v] : data) entries.push_back({k, v});
        return entries;
    }

    // ---------- forEach ----------
    void forEach(std::function<void(const K&, const V&)> action) const {
        for (const auto& [k, v] : data) action(k, v);
    }

    // ---------- clone ----------
    ConcurrentSkipListMap<K, V> clone() const {
        ConcurrentSkipListMap<K, V> copy;
        copy.data = data;
        return copy;
    }

    // ---------- equals ----------
    bool equals(const ConcurrentSkipListMap<K, V>& other) const {
        return data == other.data;
    }

    // ---------- sorted map methods ----------
    std::function<bool(const K&, const K&)> comparator() const {
        return comp;
    }

    K firstKey() const {
        if (data.empty()) throw std::out_of_range("map is empty");
        return data.begin()->first;
    }

    K lastKey() const {
        if (data.empty()) throw std::out_of_range("map is empty");
        return data.rbegin()->first;
    }

    void putFirst(const K& key, const V& value) {
        // In a sorted map, putFirst just does put (the key order is maintained)
        put(key, value);
    }

    void putLast(const K& key, const V& value) {
        put(key, value);
    }

    std::optional<SimpleEntry<K, V>> firstEntry() const {
        if (data.empty()) return std::nullopt;
        auto it = data.begin();
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<SimpleEntry<K, V>> lastEntry() const {
        if (data.empty()) return std::nullopt;
        auto it = data.rbegin();
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<SimpleEntry<K, V>> pollFirstEntry() {
        if (data.empty()) return std::nullopt;
        auto it = data.begin();
        SimpleEntry<K, V> entry{it->first, it->second};
        data.erase(it);
        return entry;
    }

    std::optional<SimpleEntry<K, V>> pollLastEntry() {
        if (data.empty()) return std::nullopt;
        auto it = data.rbegin();
        SimpleEntry<K, V> entry{it->first, it->second};
        data.erase(std::prev(data.end()));
        return entry;
    }

    ConcurrentSkipListMap<K, V> descendingMap() const {
        // For simplicity, return a copy (descending order not maintained)
        ConcurrentSkipListMap<K, V> copy;
        copy.data = data;
        // In real implementation, we would use a reverse comparator
        return copy;
    }

    // ---------- lower, floor, ceiling, higher ----------
    std::optional<SimpleEntry<K, V>> lowerEntry(const K& key) const {
        auto it = data.lower_bound(key);
        if (it == data.begin()) return std::nullopt;
        --it;
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<K> lowerKey(const K& key) const {
        auto entry = lowerEntry(key);
        if (entry) return entry->key;
        return std::nullopt;
    }

    std::optional<SimpleEntry<K, V>> floorEntry(const K& key) const {
        auto it = data.upper_bound(key);
        if (it == data.begin()) return std::nullopt;
        --it;
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<K> floorKey(const K& key) const {
        auto entry = floorEntry(key);
        if (entry) return entry->key;
        return std::nullopt;
    }

    std::optional<SimpleEntry<K, V>> ceilingEntry(const K& key) const {
        auto it = data.lower_bound(key);
        if (it == data.end()) return std::nullopt;
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<K> ceilingKey(const K& key) const {
        auto entry = ceilingEntry(key);
        if (entry) return entry->key;
        return std::nullopt;
    }

    std::optional<SimpleEntry<K, V>> higherEntry(const K& key) const {
        auto it = data.upper_bound(key);
        if (it == data.end()) return std::nullopt;
        return SimpleEntry<K, V>{it->first, it->second};
    }

    std::optional<K> higherKey(const K& key) const {
        auto entry = higherEntry(key);
        if (entry) return entry->key;
        return std::nullopt;
    }

    // ---------- navigable key sets (simplified) ----------
    std::vector<K> navigableKeySet() const {
        return keySet();
    }

    std::vector<K> descendingKeySet() const {
        std::vector<K> keys = keySet();
        std::reverse(keys.begin(), keys.end());
        return keys;
    }

    // ---------- subMap, headMap, tailMap ----------
    ConcurrentSkipListMap<K, V> subMap(const K& fromKey, bool fromInclusive,
                                       const K& toKey, bool toInclusive) const {
        ConcurrentSkipListMap<K, V> result;
        auto lower = fromInclusive ? data.lower_bound(fromKey) : data.upper_bound(fromKey);
        auto upper = toInclusive ? data.upper_bound(toKey) : data.lower_bound(toKey);
        for (auto it = lower; it != upper; ++it) {
            result.data[it->first] = it->second;
        }
        return result;
    }

    ConcurrentSkipListMap<K, V> subMap(const K& fromKey, const K& toKey) const {
        return subMap(fromKey, true, toKey, false);
    }

    ConcurrentSkipListMap<K, V> headMap(const K& toKey, bool inclusive) const {
        ConcurrentSkipListMap<K, V> result;
        auto upper = inclusive ? data.upper_bound(toKey) : data.lower_bound(toKey);
        for (auto it = data.begin(); it != upper; ++it) {
            result.data[it->first] = it->second;
        }
        return result;
    }

    ConcurrentSkipListMap<K, V> headMap(const K& toKey) const {
        return headMap(toKey, false);
    }

    ConcurrentSkipListMap<K, V> tailMap(const K& fromKey, bool inclusive) const {
        ConcurrentSkipListMap<K, V> result;
        auto lower = inclusive ? data.lower_bound(fromKey) : data.upper_bound(fromKey);
        for (auto it = lower; it != data.end(); ++it) {
            result.data[it->first] = it->second;
        }
        return result;
    }

    ConcurrentSkipListMap<K, V> tailMap(const K& fromKey) const {
        return tailMap(fromKey, true);
    }
};

// ========== TEST FUNCTIONS ==========
// Using int as the concrete type for Object for simplicity

using Object = int;

void remove_test_4301(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.remove(p0, p1);
}

void remove_test_4302(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.remove(p0);
}

void size_test_4303() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.size();
}

void get_test_4304(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.get(p0);
}

void put_test_4305(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.put(p0, p1);
}

void equals_test_4306(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    ConcurrentSkipListMap<Object, Object> other;
    instance.equals(other);
}

void values_test_4307() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.values();
}

void clone_test_4308() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.clone();
}

void clear_test_4309() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.clear();
}

void isEmpty_test_4310() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.isEmpty();
}

void replace_test_4311(Object p0, Object p1, Object p2) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.replace(p0, p1, p2);
}

void replace_test_4312(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.replace(p0, p1);
}

void replaceAll_test_4313(std::function<Object(const Object&, const Object&)> p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.replaceAll(p0);
}

void merge_test_4314(Object p0, Object p1, std::function<Object(const Object&, const Object&)> p2) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.merge(p0, p1, p2);
}

void entrySet_test_4315() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.entrySet();
}

void putIfAbsent_test_4316(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.putIfAbsent(p0, p1);
}

void compute_test_4317(Object p0, std::function<Object(const Object&, const std::optional<Object>&)> p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.compute(p0, p1);
}

void computeIfAbsent_test_4318(Object p0, std::function<Object(const Object&)> p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.computeIfAbsent(p0, p1);
}

void forEach_test_4319(std::function<void(const Object&, const Object&)> p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.forEach(p0);
}

void keySet_test_4320() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.keySet();
}

void containsValue_test_4321(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.containsValue(p0);
}

void containsKey_test_4322(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.containsKey(p0);
}

void getOrDefault_test_4323(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.getOrDefault(p0, p1);
}

void computeIfPresent_test_4324(Object p0, std::function<Object(const Object&, const Object&)> p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.computeIfPresent(p0, p1);
}

void comparator_test_4325() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.comparator();
}

void firstKey_test_4326() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.firstKey();
}

void putFirst_test_4327(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.putFirst(p0, p1);
}

void putLast_test_4328(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.putLast(p0, p1);
}

void firstEntry_test_4329() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.firstEntry();
}

void lastEntry_test_4330() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.lastEntry();
}

void pollFirstEntry_test_4331() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.pollFirstEntry();
}

void pollLastEntry_test_4332() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.pollLastEntry();
}

void descendingMap_test_4333() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.descendingMap();
}

void lowerEntry_test_4334(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.lowerEntry(p0);
}

void lowerKey_test_4335(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.lowerKey(p0);
}

void floorEntry_test_4336(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.floorEntry(p0);
}

void floorKey_test_4337(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.floorKey(p0);
}

void ceilingEntry_test_4338(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.ceilingEntry(p0);
}

void ceilingKey_test_4339(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.ceilingKey(p0);
}

void higherEntry_test_4340(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.higherEntry(p0);
}

void higherKey_test_4341(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.higherKey(p0);
}

void navigableKeySet_test_4342() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.navigableKeySet();
}

void descendingKeySet_test_4343() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.descendingKeySet();
}

void subMap_test_4344(Object p0, bool p1, Object p2, bool p3) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.subMap(p0, p1, p2, p3);
}

void subMap_test_4345(Object p0, Object p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.subMap(p0, p1);
}

void headMap_test_4346(Object p0, bool p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.headMap(p0, p1);
}

void headMap_test_4347(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.headMap(p0);
}

void tailMap_test_4348(Object p0, bool p1) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.tailMap(p0, p1);
}

void tailMap_test_4349(Object p0) {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.tailMap(p0);
}

void lastKey_test_4350() {
    ConcurrentSkipListMap<Object, Object> instance;
    instance.lastKey();
}
```