```cpp
#include <string>
#include <stdexcept>

// Abstract base class for CharSequence (Java interface equivalent)
class CharSequence {
public:
    virtual ~CharSequence() = default;
    virtual std::string toString() const = 0;
};

// Concrete implementation wrapping a std::string
class StringCharSequence : public CharSequence {
private:
    std::string data;
public:
    explicit StringCharSequence(const std::string& str) : data(str) {}
    std::string toString() const override {
        return data;
    }
};

// C++ exception class equivalent to java.time.format.DateTimeParseException
class DateTimeParseException : public std::runtime_error {
private:
    std::string parsedString;
    int errorIndex;
public:
    DateTimeParseException(const std::string& message,
                           const CharSequence& parsedData,
                           int errorIndex)
        : std::runtime_error(message),
          parsedString(parsedData.toString()),
          errorIndex(errorIndex) {}

    // Additional constructor that accepts a std::string for parsedData (convenience)
    DateTimeParseException(const std::string& message,
                           const std::string& parsedData,
                           int errorIndex)
        : std::runtime_error(message),
          parsedString(parsedData),
          errorIndex(errorIndex) {}

    std::string getParsedString() const {
        return parsedString;
    }

    int getErrorIndex() const {
        return errorIndex;
    }
};

// Test function equivalent to getParsedString_test_3275
void getParsedString_test_3275(const std::string& c0,
                               const CharSequence& c1,
                               int c2) {
    DateTimeParseException instance(c0, c1, c2);
    instance.getParsedString();
}

// Test function equivalent to getErrorIndex_test_3276
void getErrorIndex_test_3276(const std::string& c0,
                             const CharSequence& c1,
                             int c2) {
    DateTimeParseException instance(c0, c1, c2);
    instance.getErrorIndex();
}
```