```cpp
#include <string>
#include <stdexcept>

// C++ equivalent of javax.swing.text.ChangedCharSetException
class ChangedCharSetException : public std::exception {
private:
    std::string charSetSpec;
    bool keyEqualsCharSet;

public:
    ChangedCharSetException(const std::string& charSetSpec, bool keyEqualsCharSet)
        : charSetSpec(charSetSpec), keyEqualsCharSet(keyEqualsCharSet) {}

    const std::string& getCharSetSpec() const {
        return charSetSpec;
    }

    bool keyEqualsCharSet() const {
        return keyEqualsCharSet;
    }

    const char* what() const noexcept override {
        return "ChangedCharSetException";
    }
};

// Test function for getCharSetSpec_test_10146
void getCharSetSpec_test_10146(const std::string& c0, bool c1) {
    ChangedCharSetException instance(c0, c1);
    instance.getCharSetSpec();  // no exception expected
}

// Test function for keyEqualsCharSet_test_10147
void keyEqualsCharSet_test_10147(const std::string& c0, bool c1) {
    ChangedCharSetException instance(c0, c1);
    instance.keyEqualsCharSet();  // no exception expected
}

// Optional main to run the tests with example values
int main() {
    getCharSetSpec_test_10146("UTF-8", true);
    keyEqualsCharSet_test_10147("ISO-8859-1", false);
    return 0;
}
```