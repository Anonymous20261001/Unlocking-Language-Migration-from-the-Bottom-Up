```cpp
#include <cstdint>
#include <vector>

class IIOByteBuffer {
private:
    std::vector<uint8_t>* data_ptr;
    int offset_;
    int length_;

public:
    IIOByteBuffer(std::vector<uint8_t>& data, int offset, int length)
        : data_ptr(&data), offset_(offset), length_(length) {}

    std::vector<uint8_t>& getData() {
        return *data_ptr;
    }

    void setData(std::vector<uint8_t>& newData) {
        data_ptr = &newData;
    }

    int getOffset() const {
        return offset_;
    }

    void setOffset(int offset) {
        offset_ = offset;
    }

    int getLength() const {
        return length_;
    }

    void setLength(int length) {
        length_ = length;
    }
};

// Test function translations
void setData_test_5495(std::vector<uint8_t>& p0, std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.setData(p0);
}

void getLength_test_5496(std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.getLength();
}

void setLength_test_5497(int p0, std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.setLength(p0);
}

void getOffset_test_5498(std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.getOffset();
}

void setOffset_test_5499(int p0, std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.setOffset(p0);
}

void getData_test_5500(std::vector<uint8_t>& c0, int c1, int c2) {
    IIOByteBuffer instance(c0, c1, c2);
    instance.getData();
}
```