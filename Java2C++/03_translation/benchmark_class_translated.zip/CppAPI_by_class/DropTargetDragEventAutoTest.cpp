```cpp
#include <vector>
#include <string>
#include <iostream>

// ----- Java packages to C++ namespaces -----

namespace java {
namespace awt {

struct Point {
    int x;
    int y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

} // namespace awt

namespace awt {
namespace datatransfer {

class DataFlavor {
    std::string mimeType;
public:
    DataFlavor() : mimeType("") {}
    explicit DataFlavor(const std::string& mt) : mimeType(mt) {}
    bool operator==(const DataFlavor& other) const {
        return mimeType == other.mimeType;
    }
    const std::string& getMimeType() const { return mimeType; }
};

class Transferable {
public:
    virtual std::vector<DataFlavor> getTransferDataFlavors() const = 0;
    virtual bool isDataFlavorSupported(const DataFlavor& flavor) const = 0;
    virtual void* getTransferData(const DataFlavor& flavor) const = 0;
    virtual ~Transferable() {}
};

class SimpleTransferable : public Transferable {
    std::vector<DataFlavor> flavors;
public:
    explicit SimpleTransferable(const std::vector<DataFlavor>& f) : flavors(f) {}
    std::vector<DataFlavor> getTransferDataFlavors() const override {
        return flavors;
    }
    bool isDataFlavorSupported(const DataFlavor& flavor) const override {
        for (const auto& f : flavors) {
            if (f == flavor) return true;
        }
        return false;
    }
    void* getTransferData(const DataFlavor& flavor) const override {
        return nullptr; // stub
    }
};

} // namespace datatransfer
} // namespace awt

namespace awt {
namespace dnd {

class DropTargetContext {
    datatransfer::Transferable* transferable;
    bool accepted;
public:
    explicit DropTargetContext(datatransfer::Transferable* t)
        : transferable(t), accepted(false) {}

    datatransfer::Transferable& getTransferable() const {
        return *