```cpp
#include <unordered_map>
#include <functional>
#include <vector>
#include <utility>
#include <cstddef>

// Minimal HashMap implementation mimicking Java's HashMap with Object references.
// All keys and values are stored as void* (pointers).
// Functional interfaces are represented by std::function.

// Forward declaration for Map-like types.
class Map {
public:
    virtual ~Map() = default;
    // We don't need to implement Map interface fully; just enough for putAll.
};

class HashMap {
public:
    using BiConsumer = std::function<void(void*, void*)>;
    using BiFunction = std::function<void*(void*, void*)>;
    using Function = std::function<void*(void*)>;

private:
    std::unordered_map<void*, void*> data_;

public:
    HashMap() = default;
    HashMap(const HashMap& other) : data_(other.data_) {}
    HashMap& operator=(const HashMap& other) = default;

    // Returns the value to which the specified key is mapped, or nullptr if none.
    void* get(void* key) {
        auto it = data_.find(key);
        if (it != data_.end()) {
            return it->second;
        }
        return nullptr;
    }

    // Associates the specified value with the specified key.
    void* put(void* key, void* value) {
        void* old = get(key);
        data_[key] = value;
        return old;
    }

    // Removes the mapping for the specified key if present.
    void* remove(void* key) {
        void* old = get(key);
        data_.erase(key);
        return old;
    }

    // Removes the entry for the specified key only if it is currently mapped to the specified value.
    bool remove(void* key, void* value) {
        auto it = data_.find(key);
        if (it != data_.end() && it->second == value) {
            data_.erase(it);
            return true;
        }
        return false;
    }

    // Returns the number of key-value mappings.
    std::size_t size() const {
        return data_.size();
    }

    // Returns true if this map contains no key-value mappings.
    bool isEmpty() const {
        return data_.empty();
    }

    // Returns true if this map contains a mapping for the specified key.
    bool containsKey(void* key) const {
        return data_.find(key) != data_.end();
    }

    // Returns true if this map maps one or more keys to the specified value.
    bool containsValue(void* value) const {
        for (const auto& pair : data_) {
            if (pair.second == value) {
                return true;
            }
        }
        return false;
    }

    // Returns a Set view of the keys contained in this map.
    // For simplicity, we return nullptr (not used in tests).
    void* keySet() {
        return nullptr;
    }

    // Returns a Collection view of the values in this map.
    void* values() {
        return nullptr;
    }

    // Returns a Set view of the mappings in this map.
    void* entrySet() {
        return nullptr;
    }

    // Returns a shallow copy of this HashMap instance.
    HashMap clone() {
        return HashMap(*this);
    }

    // Removes all of the mappings from this map.
    void clear() {
        data_.clear();
    }

    // Copies all of the mappings from the specified map to this map.
    void putAll(Map& m) {
        // Since Map is abstract and we don't know its contents, we do nothing.
        // The test only calls putAll with a Map reference; we ignore.
    }

    // If the specified key is not already associated with a value, associate it with the given value.
    void* putIfAbsent(void* key, void* value) {
        auto it = data_.find(key);
        if (it == data_.end()) {
            data_[key] = value;
            return nullptr;
        }
        return it->second;
    }

    // Returns the value to which the specified key is mapped, or defaultValue if not present.
    void* getOrDefault(void* key, void* defaultValue) {
        auto it = data_.find(key);
        if (it != data_.end()) {
            return it->second;
        }
        return defaultValue;
    }

    // Replaces the entry for the specified key only if it is currently mapped to some value.
    void* replace(void* key, void* value) {
        auto it = data_.find(key);
        if (it != data_.end()) {
            void* old = it->second;
            it->second = value;
            return old;
        }
        return nullptr;
    }

    // Replaces the entry for the specified key only if currently mapped to the specified old value.
    bool replace(void* key, void* oldValue, void* newValue) {
        auto it = data_.find(key);
        if (it != data_.end() && it->second == oldValue) {
            it->second = newValue;
            return true;
        }
        return false;
    }

    // Replaces each entry's value with the result of invoking the given function on that entry.
    void replaceAll(BiFunction function) {
        // The Java signature is BiFunction<? super K, ? super V, ? extends V>
        // We assume the function takes (key, value) and returns new value.
        for (auto& pair : data_) {
            void* newVal = function(pair.first, pair.second);
            pair.second = newVal;
        }
    }

    // Performs the given action for each entry in this map.
    void forEach(BiConsumer action) {
        for (const auto& pair : data_) {
            action(pair.first, pair.second);
        }
    }

    // Attempts to compute a mapping for the specified key and its current mapped value (or nullptr if none).
    void* compute(void* key, BiFunction remappingFunction) {
        void* old = get(key);
        void* newVal = remappingFunction(key, old);
        if (newVal != nullptr) {
            data_[key] = newVal;
        } else {
            data_.erase(key);
        }
        return newVal;
    }

    // If the specified key is not already associated with a value, attempts to compute its value.
    void* computeIfAbsent(void* key, Function mappingFunction) {
        auto it = data_.find(key);
        if (it == data_.end()) {
            void* newVal = mappingFunction(key);
            if (newVal != nullptr) {
                data_[key] = newVal;
                return newVal;
            }
        }
        return it != data_.end() ? it->second : nullptr;
    }

    // If the value for the specified key is present and non-null, attempts to compute a new mapping.
    void* computeIfPresent(void* key, BiFunction remappingFunction) {
        auto it = data_.find(key);
        if (it != data_.end() && it->second != nullptr) {
            void* newVal = remappingFunction(key, it->second);
            if (newVal != nullptr) {
                it->second = newVal;
            } else {
                data_.erase(it);
            }
            return newVal;
        }
        return nullptr;
    }

    // Merges the specified key if it is not already associated with a value.
    void* merge(void* key, void* value, BiFunction remappingFunction) {
        auto it = data_.find(key);
        if (it == data_.end() || it->second == nullptr) {
            data_[key] = value;
            return value;
        } else {
            void* newVal = remappingFunction(it->second, value);
            it->second = newVal;
            return newVal;
        }
    }

    // Static factory method (Java 19+).
    static HashMap newHashMap(int numMappings) {
        HashMap map;
        // Preallocate capacity (ignored in this simple implementation)
        map.data_.reserve(static_cast<std::size_t>(numMappings));
        return map;
    }
};

// ---------- Test functions (translated from Java @Test methods) ----------

void remove_test_3478(void* p0) {
    HashMap instance;
    instance.remove(p0);
}

void remove_test_3479(void* p0, void* p1) {
    HashMap instance;
    instance.remove(p0, p1);
}

void size_test_3480() {
    HashMap instance;
    instance.size();
}

void get_test_3481(void* p0) {
    HashMap instance;
    instance.get(p0);
}

void put_test_3482(void* p0, void* p1) {
    HashMap instance;
    instance.put(p0, p1);
}

void values_test_3483() {
    HashMap instance;
    instance.values();
}

void clone_test_3484() {
    HashMap instance;
    instance.clone();
}

void clear_test_3485() {
    HashMap instance;
    instance.clear();
}

void isEmpty_test_3486() {
    HashMap instance;
    instance.isEmpty();
}

void replace_test_3487(void* p0, void* p1) {
    HashMap instance;
    instance.replace(p0, p1);
}

void replace_test_3488(void* p0, void* p1, void* p2) {
    HashMap instance;
    instance.replace(p0, p1, p2);
}

void replaceAll_test_3489(HashMap::BiFunction p0) {
    HashMap instance;
    instance.replaceAll(p0);
}

void merge_test_3490(void* p0, void* p1, HashMap::BiFunction p2) {
    HashMap instance;
    instance.merge(p0, p1, p2);
}

void newHashMap_test_3491(int p0) {
    HashMap instance;
    HashMap::newHashMap(p0);
}

void entrySet_test_3492() {
    HashMap instance;
    instance.entrySet();
}

void putAll_test_3493(Map& p0) {
    HashMap instance;
    instance.putAll(p0);
}

void putIfAbsent_test_3494(void* p0, void* p1) {
    HashMap instance;
    instance.putIfAbsent(p0, p1);
}

void compute_test_3495(void* p0, HashMap::BiFunction p1) {
    HashMap instance;
    instance.compute(p0, p1);
}

void computeIfAbsent_test_3496(void* p0, HashMap::Function p1) {
    HashMap instance;
    instance.computeIfAbsent(p0, p1);
}

void forEach_test_3497(HashMap::BiConsumer p0) {
    HashMap instance;
    instance.forEach(p0);
}

void keySet_test_3498() {
    HashMap instance;
    instance.keySet();
}

void containsValue_test_3499(void* p0) {
    HashMap instance;
    instance.containsValue(p0);
}

void containsKey_test_3500(void* p0) {
    HashMap instance;
    instance.containsKey(p0);
}

void getOrDefault_test_3501(void* p0, void* p1) {
    HashMap instance;
    instance.getOrDefault(p0, p1);
}

void computeIfPresent_test_3502(void* p0, HashMap::BiFunction p1) {
    HashMap instance;
    instance.computeIfPresent(p0, p1);
}
```