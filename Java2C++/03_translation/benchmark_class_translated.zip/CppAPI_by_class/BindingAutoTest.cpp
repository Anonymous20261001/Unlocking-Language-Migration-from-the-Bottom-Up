```cpp
#include <string>

// Base class for all objects (analogous to Java Object)
class Object {
public:
    virtual ~Object() = default;
    virtual std::string toString() const = 0;
    virtual std::string getClassName() const = 0;
};

// A simple concrete Object for testing (holds a class name and a string representation)
class SimpleObject : public Object {
    std::string className_;
    std::string str_;
public:
    SimpleObject(const std::string& className, const std::string& str)
        : className_(className), str_(str) {}

    std::string toString() const override { return str_; }
    std::string getClassName() const override { return className_; }
};

// C++ equivalent of javax.naming.Binding
class Binding {
    std::string name_;
    Object* obj_;          // non-owning pointer (caller manages lifetime)
public:
    Binding(const std::string& name, Object* obj)
        : name_(name), obj_(obj) {}

    void setObject(Object* p0) { obj_ = p0; }

    std::string toString() const {
        std::string result = name_ + ": ";
        if (obj_) {
            result += obj_->getClassName() + ": " + obj_->toString();
        } else {
            result += "null";
        }
        return result;
    }

    std::string getClassName() const {
        return obj_ ? obj_->getClassName() : "";
    }

    Object* getObject() const { return obj_; }
};

// ---- Translated test functions ----
void setObject_test_5877(Object* p0, const std::string& c0, Object* c1) {
    Binding instance(c0, c1);
    instance.setObject(p0);
}

void toString_test_5878(const std::string& c0, Object* c1) {
    Binding instance(c0, c1);
    instance.toString();
}

void getClassName_test_5879(const std::string& c0, Object* c1) {
    Binding instance(c0, c1);
    instance.getClassName();
}

void getObject_test_5880(const std::string& c0, Object* c1) {
    Binding instance(c0, c1);
    instance.getObject();
}
```