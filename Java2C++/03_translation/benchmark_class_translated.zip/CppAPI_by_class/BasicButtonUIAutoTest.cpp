```cpp
#include <cstddef>

// -------------------------------------------------------------------
// Minimal stubs for Java Swing classes used in the tests
// -------------------------------------------------------------------

class JComponent {
public:
    virtual ~JComponent() = default;
};

class AbstractButton : public JComponent {
public:
    virtual ~AbstractButton() = default;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

struct Dimension {
    int width = 0;
    int height = 0;
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// -------------------------------------------------------------------
// BasicButtonUI equivalent (stub implementation)
// -------------------------------------------------------------------
class BasicButtonUI {
public:
    BasicButtonUI() = default;

    void installUI(JComponent* /*c*/) {
        // stub – no operation
    }

    void uninstallUI(JComponent* /*c*/) {
        // stub – no operation
    }

    static BasicButtonUI* createUI(JComponent* /*c*/) {
        return new BasicButtonUI();
    }

    int getDefaultTextIconGap(AbstractButton* /*b*/) {
        return 0;
    }

    Dimension getMaximumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    void paint(Graphics* /*g*/, JComponent* /*c*/) {
        // stub – no operation
    }

    Dimension getPreferredSize(JComponent* /*c*/) {
        return Dimension{};
    }

    Dimension getMinimumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    int getBaseline(JComponent* /*c*/, int /*width*/, int /*height*/) {
        return 0;
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* /*c*/) {
        return BaselineResizeBehavior::OTHER;
    }
};

// -------------------------------------------------------------------
// Translated test functions (one per @Test method)
// -------------------------------------------------------------------

void installUI_test_8640(JComponent* p0) {
    BasicButtonUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8641(JComponent* p0) {
    BasicButtonUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8642(JComponent* p0) {
    BasicButtonUI instance;          // unused, just to match Java code
    BasicButtonUI::createUI(p0);    // static method call
}

void getDefaultTextIconGap_test_8643(AbstractButton* p0) {
    BasicButtonUI instance;
    instance.getDefaultTextIconGap(p0);
}

void getMaximumSize_test_8644(JComponent* p0) {
    BasicButtonUI instance;
    instance.getMaximumSize(p0);
}

void paint_test_8645(Graphics* p0, JComponent* p1) {
    BasicButtonUI instance;
    instance.paint(p0, p1);
}

void getPreferredSize_test_8646(JComponent* p0) {
    BasicButtonUI instance;
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8647(JComponent* p0) {
    BasicButtonUI instance;
    instance.getMinimumSize(p0);
}

void getBaseline_test_8648(JComponent* p0, int p1, int p2) {
    BasicButtonUI instance;
    instance.getBaseline(p0, p1, p2);
}

void getBaselineResizeBehavior_test_8649(JComponent* p0) {
    BasicButtonUI instance;
    instance.getBaselineResizeBehavior(p0);
}
```