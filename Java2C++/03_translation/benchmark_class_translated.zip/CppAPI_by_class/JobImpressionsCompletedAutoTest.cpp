```cpp
#include <string>
#include <cstdint>
#include <stdexcept>

// Minimal Object base class to mimic Java's Object
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return (this == &other); // default identity comparison
    }
};

// Simple class to represent a Category (like Java's Class)
class Category {
public:
    explicit Category(const std::string& name) : name_(name) {}
    std::string getName() const { return name_; }
private:
    std::string name_;
};

// JobImpressionsCompleted class mimicking javax.print.attribute.standard.JobImpressionsCompleted
class JobImpressionsCompleted : public Object {
public:
    explicit JobImpressionsCompleted(int value) : value_(value) {}

    int getValue() const { return value_; }

    // getCategory() returns a Category object
    Category getCategory() const {
        return Category("job-impressions-completed");
    }

    // getName() returns a string name of the attribute
    std::string getName() const {
        return "job-impressions-completed";
    }

    // equals() override to compare with other JobImpressionsCompleted objects
    bool equals(const Object& other) const override {
        const auto* otherJob = dynamic_cast<const JobImpressionsCompleted*>(&other);
        if (otherJob == nullptr) {
            return false;
        }
        return value_ == otherJob->value_;
    }

private:
    int value_;
};

// Test functions (translations of @Test methods)

void getCategory_test_6127(int c0) {
    JobImpressionsCompleted instance(c0);
    instance.getCategory();
}

void getName_test_6128(int c0) {
    JobImpressionsCompleted instance(c0);
    instance.getName();
}

void equals_test_6129(const Object& p0, int c0) {
    JobImpressionsCompleted instance(c0);
    instance.equals(p0);
}
```