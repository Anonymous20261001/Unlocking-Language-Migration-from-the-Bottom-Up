```cpp
#include <string>
#include <typeinfo>

// Base Object class to mimic Java Object
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object* other) const {
        return this == other; // identity by default
    }
    virtual std::string toString() const {
        return "Object";
    }
    virtual int hashCode() const {
        return reinterpret_cast<intptr_t>(this);
    }
};

// Class representing javax.print.attribute.standard.JobPriority
class JobPriority : public Object {
private:
    int value; // the priority value (1..100)

public:
    explicit JobPriority(int c0) : value(c0) {}

    // Returns the category (class name) as a string (simulating Java's Class)
    // In Java this returns a Class object; here we return a descriptive string.
    std::string getCategory() const {
        return "javax.print.attribute.standard.JobPriority";
    }

    // Returns the attribute name as defined in the standard
    std::string getName() const {
        return "job-priority";
    }

    // Returns the underlying integer value
    int getValue() const {
        return value;
    }

    // Override equals: true if other is a JobPriority with the same value
    bool equals(const Object* other) const override {
        const JobPriority* jp = dynamic_cast<const JobPriority*>(other);
        if (jp == nullptr) {
            return false;
        }
        return this->value == jp->value;
    }

    // Override toString for completeness
    std::string toString() const override {
        return "JobPriority: " + std::to_string(value);
    }

    // Override hashCode (consistent with Java: equal objects have same hash)
    int hashCode() const override {
        return value;
    }
};

// Test functions (translation of the JUnit @Test methods)

void getCategory_test_6160(int c0) {
    JobPriority instance(c0);
    instance.getCategory(); // just call, ignore return (as Java test does)
}

void getName_test_6161(int c0) {
    JobPriority instance(c0);
    instance.getName(); // just call
}

void equals_test_6162(Object* p0, int c0) {
    JobPriority instance(c0);
    instance.equals(p0); // just call, result discarded
}
```