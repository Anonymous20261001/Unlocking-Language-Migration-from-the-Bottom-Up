```cpp
#include <vector>
#include <algorithm>
#include <iterator>
#include <functional>
#include <stdexcept>
#include <memory>

// ---------- Base Object ----------
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object* other) const {
        return this == other; // default identity
    }
    // For simplicity, we assume each object has a unique address
};

// ---------- Collection Interface ----------
class Collection {
public:
    virtual ~Collection() = default;
    virtual bool add(Object* e) = 0;
    virtual bool addAll(Collection& c) = 0;
    virtual void clear() = 0;
    virtual bool contains(Object* o) = 0;
    virtual bool containsAll(Collection& c) = 0;
    virtual bool isEmpty() const = 0;
    virtual std::vector<Object*> iterator() const = 0; // returns snapshot
    virtual bool remove(Object* o) = 0;
    virtual bool removeAll(Collection& c) = 0;
    virtual bool retainAll(Collection& c) = 0;
    virtual int size() const = 0;
    virtual std::vector<Object*> toArray() const = 0;
    virtual void toArray(std::vector<Object*>& arr) const = 0;
};

// ---------- Consumer Interface ----------
class Consumer {
public:
    virtual ~Consumer() = default;
    virtual void accept(Object* t) = 0;
};

// ---------- Predicate Interface ----------
class Predicate {
public:
    virtual ~Predicate() = default;
    virtual bool test(Object* t) = 0;
};

// ---------- simple Collection implementation for testing ----------
class ArrayList : public Collection {
private:
    std::vector<Object*> data;
public:
    bool add(Object* e) override {
        data.push_back(e);
        return true;
    }

    bool addAll(Collection& c) override {
        auto it = c.iterator();
        bool modified = false;
        for (auto* e : it) {
            if (add(e)) modified = true;
        }
        return modified;
    }

    void clear() override {
        data.clear();
    }

    bool contains(Object* o) override {
        return std::any_of(data.begin(), data.end(),
                           [o](Object* x) { return x->equals(o); });
    }

    bool containsAll(Collection& c) override {
        auto it = c.iterator();
        for (auto* e : it) {
            if (!contains(e)) return false;
        }
        return true;
    }

    bool isEmpty() const override {
        return data.empty();
    }

    std::vector<Object*> iterator() const override {
        return data; // snapshot
    }

    bool remove(Object* o) override {
        auto it = std::find_if(data.begin(), data.end(),
                               [o](Object* x) { return x->equals(o); });
        if (it != data.end()) {
            data.erase(it);
            return true;
        }
        return false;
    }

    bool removeAll(Collection& c) override {
        auto it = c.iterator();
        bool modified = false;
        for (auto* e : it) {
            while (remove(e)) modified = true;
        }
        return modified;
    }

    bool retainAll(Collection& c) override {
        std::vector<Object*> result;
        for (auto* e : data) {
            if (c.contains(e)) {
                result.push_back(e);
            }
        }
        bool modified = (result.size() != data.size());
        data = std::move(result);
        return modified;
    }

    int size() const override {
        return data.size();
    }

    std::vector<Object*> toArray() const override {
        return data;
    }

    void toArray(std::vector<Object*>& arr) const override {
        arr = data;
    }
};

// ---------- Iterator (simple forward) ----------
class Iterator {
private:
    std::vector<Object*> elements;
    size_t pos = 0;
public:
    explicit Iterator(std::vector<Object*> elems) : elements(std::move(elems)) {}
    bool hasNext() const { return pos < elements.size(); }
    Object* next() {
        if (!hasNext()) throw std::out_of_range("No more elements");
        return elements[pos++];
    }
};

// ---------- Spliterator (simplified: non-splittable) ----------
class Spliterator {
private:
    std::vector<Object*> elements;
    size_t pos = 0;
public:
    explicit Spliterator(std::vector<Object*> elems) : elements(std::move(elems)) {}
    bool tryAdvance(std::function<void(Object*)> action) {
        if (pos < elements.size()) {
            action(elements[pos++]);
            return true;
        }
        return false;
    }
    Spliterator trySplit() {
        // returns an empty spliterator (cannot split)
        return Spliterator({});
    }
    long estimateSize() const {
        return elements.size() - pos;
    }
    int characteristics() const {
        return 0; // SIZED, SUBSIZED, etc. but we return 0 for simplicity
    }
};

// ---------- CopyOnWriteArraySet ----------
class CopyOnWriteArraySet {
private:
    std::vector<Object*> array; // snapshot array

    // remove first occurrence by equality (Object::equals)
    bool removeFirst(Object* o) {
        for (auto it = array.begin(); it != array.end(); ++it) {
            if ((*it)->equals(o)) {
                array.erase(it);
                return true;
            }
        }
        return false;
    }

public:
    CopyOnWriteArraySet() = default;

    // copy constructor (snapshot semantics)
    CopyOnWriteArraySet(const CopyOnWriteArraySet& other) : array(other.array) {}

    bool add(Object* e) {
        // Check if already present
        for (auto* x : array) {
            if (x->equals(e)) return false;
        }
        // Create new copy with added element
        std::vector<Object*> newArray = array;
        newArray.push_back(e);
        array = std::move(newArray);
        return true;
    }

    bool addAll(Collection& c) {
        bool modified = false;
        auto it = c.iterator();
        for (auto* e : it) {
            if (add(e)) modified = true;
        }
        return modified;
    }

    void clear() {
        array.clear(); // atomic in sense of single copy
    }

    bool contains(Object* o) {
        return std::any_of(array.begin(), array.end(),
                           [o](Object* x) { return x->equals(o); });
    }

    bool containsAll(Collection& c) {
        auto it = c.iterator();
        for (auto* e : it) {
            if (!contains(e)) return false;
        }
        return true;
    }

    bool equals(const Object& other) {
        // In Java equals on set compares as a set; we simplify to address identity
        return this == &other;
    }

    void forEach(Consumer& action) {
        // snapshot iteration
        auto snapshot = array;
        for (auto* e : snapshot) {
            action.accept(e);
        }
    }

    bool isEmpty() {
        return array.empty();
    }

    Iterator iterator() {
        return Iterator(array);
    }

    bool remove(Object* o) {
        return removeFirst(o);
    }

    bool removeAll(Collection& c) {
        bool modified = false;
        auto it = c.iterator();
        for (auto* e : it) {
            while (removeFirst(e)) modified = true;
        }
        return modified;
    }

    bool removeIf(Predicate& filter) {
        bool modified = false;
        std::vector<Object*> newArray;
        for (auto* e : array) {
            if (!filter.test(e)) {
                newArray.push_back(e);
            } else {
                modified = true;
            }
        }
        if (modified) {
            array = std::move(newArray);
        }
        return modified;
    }

    bool retainAll(Collection& c) {
        bool modified = false;
        std::vector<Object*> newArray;
        for (auto* e : array) {
            if (c.contains(e)) {
                newArray.push_back(e);
            } else {
                modified = true;
            }
        }
        if (modified) {
            array = std::move(newArray);
        }
        return modified;
    }

    int size() {
        return array.size();
    }

    Spliterator spliterator() {
        return Spliterator(array);
    }

    std::vector<Object*> toArray() {
        return array;
    }

    void toArray(std::vector<Object*>& a) {
        a = array;
    }
};

// ========== Test functions ==========

void remove_test_4424(Object* p0) {
    CopyOnWriteArraySet instance;
    instance.remove(p0);
}

void size_test_4425() {
    CopyOnWriteArraySet instance;
    instance.size();
}

void equals_test_4426(Object* p0) {
    CopyOnWriteArraySet instance;
    instance.equals(*p0);  // p0 is an Object*, dereference to reference
}

void clear_test_4427() {
    CopyOnWriteArraySet instance;
    instance.clear();
}

void isEmpty_test_4428() {
    CopyOnWriteArraySet instance;
    instance.isEmpty();
}

void add_test_4429(Object* p0) {
    CopyOnWriteArraySet instance;
    instance.add(p0);
}

void toArray_test_4430() {
    CopyOnWriteArraySet instance;
    instance.toArray();
}

void toArray_test_4431(std::vector<Object*>& p0) {
    CopyOnWriteArraySet instance;
    instance.toArray(p0);
}

void iterator_test_4432() {
    CopyOnWriteArraySet instance;
    instance.iterator();
}

void contains_test_4433(Object* p0) {
    CopyOnWriteArraySet instance;
    instance.contains(p0);
}

void spliterator_test_4434() {
    CopyOnWriteArraySet instance;
    instance.spliterator();
}

void addAll_test_4435(Collection& p0) {
    CopyOnWriteArraySet instance;
    instance.addAll(p0);
}

void forEach_test_4436(Consumer& p0) {
    CopyOnWriteArraySet instance;
    instance.forEach(p0);
}

void removeIf_test_4437(Predicate& p0) {
    CopyOnWriteArraySet instance;
    instance.removeIf(p0);
}

void removeAll_test_4438(Collection& p0) {
    CopyOnWriteArraySet instance;
    instance.removeAll(p0);
}

void retainAll_test_4439(Collection& p0) {
    CopyOnWriteArraySet instance;
    instance.retainAll(p0);
}

void containsAll_test_4440(Collection& p0) {
    CopyOnWriteArraySet instance;
    instance.containsAll(p0);
}
```