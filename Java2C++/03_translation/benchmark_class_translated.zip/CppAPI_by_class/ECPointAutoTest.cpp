```cpp
#include <string>
#include <functional>
#include <stdexcept>
#include <typeinfo>
#include <cstddef>

// =========================
// Base Object class
// =========================
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other; // default reference equality
    }
    virtual size_t hashCode() const {
        return reinterpret_cast<size_t>(this);
    }
};

// =========================
// BigInteger class (immutable)
// =========================
class BigInteger : public Object {
public:
    BigInteger() : value_("0"), negative_(false) {}

    explicit BigInteger(const std::string& str) {
        if (str.empty()) throw std::invalid_argument("Empty string");
        negative_ = (str[0] == '-');
        size_t start = (str[0] == '-' || str[0] == '+') ? 1 : 0;
        value_ = str.substr(start);
        normalize();
        if (value_.empty()) throw std::invalid_argument("No digits");
    }

    BigInteger(int val) : negative_(val < 0), value_(std::to_string(val < 0 ? -val : val)) {
        if (value_ == "0") negative_ = false;
        normalize();
    }

    BigInteger(const BigInteger&) = default;
    BigInteger& operator=(const BigInteger&) = default;

    bool equals(const Object& other) const override {
        const BigInteger* otherBig = dynamic_cast<const BigInteger*>(&other);
        if (otherBig == nullptr) return false;
        return negative_ == otherBig->negative_ && value_ == otherBig->value_;
    }

    size_t hashCode() const override {
        size_t h = std::hash<std::string>{}(value_);
        if (negative_) h = ~h + 1; // flip bits for negative numbers
        return h;
    }

    // Accessors for internal use by ECPoint
    const std::string& strValue() const { return value_; }
    bool isNegative() const { return negative_; }

private:
    std::string value_;  // absolute value, no leading zeros (except "0")
    bool negative_;

    void normalize() {
        // Remove leading zeros but keep at least one digit
        size_t pos = 0;
        while (pos < value_.size() - 1 && value_[pos] == '0') ++pos;
        if (pos > 0) value_ = value_.substr(pos);
        if (value_ == "0") negative_ = false;
    }
};

// =========================
// ECPoint class
// =========================
class ECPoint : public Object {
public:
    ECPoint(BigInteger affineX, BigInteger affineY)
        : affineX_(std::move(affineX)), affineY_(std::move(affineY)) {}

    const BigInteger& getAffineX() const { return affineX_; }
    const BigInteger& getAffineY() const { return affineY_; }

    bool equals(const Object& other) const override {
        const ECPoint* otherPoint = dynamic_cast<const ECPoint*>(&other);
        if (otherPoint == nullptr) return false;
        return affineX_.equals(otherPoint->affineX_) && affineY_.equals(otherPoint->affineY_);
    }

    size_t hashCode() const override {
        return affineX_.hashCode() ^ affineY_.hashCode(); // Java's ECPoint hashCode
    }

private:
    BigInteger affineX_;
    BigInteger affineY_;
};

// =========================
// Test functions (translations of @Test methods)
// =========================
void getAffineX_test_2873(BigInteger c0, BigInteger c1) {
    ECPoint instance(c0, c1);
    instance.getAffineX();
}

void getAffineY_test_2874(BigInteger c0, BigInteger c1) {
    ECPoint instance(c0, c1);
    instance.getAffineY();
}

void equals_test_2875(const Object& p0, BigInteger c0, BigInteger c1) {
    ECPoint instance(c0, c1);
    instance.equals(p0);
}

void hashCode_test_2876(BigInteger c0, BigInteger c1) {
    ECPoint instance(c0, c1);
    instance.hashCode();
}
```