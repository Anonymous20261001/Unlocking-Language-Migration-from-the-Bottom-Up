```cpp
#include <vector>
#include <cstddef> // for size_t

// ----- Minimal stubs for java.awt.print classes -----

// Printable: abstract base class (interface)
class Printable {
public:
    virtual ~Printable() = default;
};

// PageFormat: simple class with default constructor (stub)
class PageFormat {
public:
    PageFormat() = default;
};

// ----- C++ equivalent of java.awt.print.Book -----
class Book {
private:
    struct PageEntry {
        Printable* painter;   // non-owning pointer
        PageFormat* format;   // non-owning pointer
        int pageCount;
    };
    std::vector<PageEntry> entries;

public:
    // Returns the total number of pages in the book.
    int getNumberOfPages() const {
        int total = 0;
        for (const auto& entry : entries) {
            total += entry.pageCount;
        }
        return total;
    }

    // Appends a painter with the given format and explicit number of pages.
    void append(Printable& painter, PageFormat& format, int numPages) {
        entries.push_back({&painter, &format, numPages});
    }

    // Convenience: appends a painter with the given format and 1 page.
    void append(Printable& painter, PageFormat& format) {
        append(painter, format, 1);
    }
};

// ----- Test functions (translated from Java @Test methods) -----

void getNumberOfPages_test_1485() {
    Book instance;
    instance.getNumberOfPages(); // no assertion, just call (as in original)
}

void append_test_1486(Printable& p0, PageFormat& p1, int p2) {
    Book instance;
    instance.append(p0, p1, p2);
}

void append_test_1487(Printable& p0, PageFormat& p1) {
    Book instance;
    instance.append(p0, p1);
}

// ----- Optional main to show that the code compiles and runs -----
int main() {
    // Create minimal concrete objects for testing
    Printable dummyPrintable;
    PageFormat dummyFormat;

    // Call each test function (matching the Java test cases)
    getNumberOfPages_test_1485();
    append_test_1486(dummyPrintable, dummyFormat, 10);
    append_test_1487(dummyPrintable, dummyFormat);

    return 0;
}
```