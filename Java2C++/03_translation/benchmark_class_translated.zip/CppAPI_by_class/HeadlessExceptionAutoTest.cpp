```cpp
#include <string>

// C++ equivalent of java.awt.HeadlessException
class HeadlessException {
public:
    HeadlessException() : message() {}
    explicit HeadlessException(const std::string& msg) : message(msg) {}

    // Returns the detail message string, or nullptr if no message is set.
    const char* getMessage() const {
        return message.empty() ? nullptr : message.c_str();
    }

private:
    std::string message;
};

// Test function corresponding to getMessage_test_348
void getMessage_test_348() {
    HeadlessException instance;
    instance.getMessage();
}
```