```cpp
// Forward declarations
class Graphics;
class JComponent;
class JTabbedPane;

// Enums
enum BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Simple data classes
class Dimension {
public:
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle(int x = 0, int y = 0, int w = 0, int h = 0)
        : x(x), y(y), width(w), height(h) {}
};

// Stub classes
class Graphics {
public:
    // No implementation needed for stub
};

class JComponent {
public:
    virtual ~JComponent() {}
};

class JTabbedPane : public JComponent {
public:
    // No additional stubs needed
};

// Main class under test
class BasicTabbedPaneUI {
public:
    BasicTabbedPaneUI() {}

    int getTabRunCount(JTabbedPane* p0) { return 0; }
    Rectangle getTabBounds(JTabbedPane* p0, int p1) { return Rectangle(); }
    int tabForCoordinate(JTabbedPane* p0, int p1, int p2) { return -1; }
    void installUI(JComponent* p0) {}
    void uninstallUI(JComponent* p0) {}
    static BasicTabbedPaneUI* createUI(JComponent* p0) { return new BasicTabbedPaneUI(); }
    Dimension getMaximumSize(JComponent* p0) { return Dimension(); }
    void paint(Graphics* p0, JComponent* p1) {}
    Dimension getMinimumSize(JComponent* p0) { return Dimension(); }
    int getBaseline(JComponent* p0, int p1, int p2) { return 0; }
    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* p0) { return CONSTANT_ASCENT; }
};

// Test functions (one per Java @Test)
void getTabRunCount_test_8974(JTabbedPane* p0) {
    BasicTabbedPaneUI instance;
    instance.getTabRunCount(p0);
}

void getTabBounds_test_8975(JTabbedPane* p0, int p1) {
    BasicTabbedPaneUI instance;
    instance.getTabBounds(p0, p1);
}

void tabForCoordinate_test_8976(JTabbedPane* p0, int p1, int p2) {
    BasicTabbedPaneUI instance;
    instance.tabForCoordinate(p0, p1, p2);
}

void installUI_test_8977(JComponent* p0) {
    BasicTabbedPaneUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8978(JComponent* p0) {
    BasicTabbedPaneUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8979(JComponent* p0) {
    BasicTabbedPaneUI instance;          // unused, but matches Java instance variable
    BasicTabbedPaneUI::createUI(p0);    // call static method
}

void getMaximumSize_test_8980(JComponent* p0) {
    BasicTabbedPaneUI instance;
    instance.getMaximumSize(p0);
}

void paint_test_8981(Graphics* p0, JComponent* p1) {
    BasicTabbedPaneUI instance;
    instance.paint(p0, p1);
}

void getMinimumSize_test_8982(JComponent* p0) {
    BasicTabbedPaneUI instance;
    instance.getMinimumSize(p0);
}

void getBaseline_test_8983(JComponent* p0, int p1, int p2) {
    BasicTabbedPaneUI instance;
    instance.getBaseline(p0, p1, p2);
}

void getBaselineResizeBehavior_test_8984(JComponent* p0) {
    BasicTabbedPaneUI instance;
    instance.getBaselineResizeBehavior(p0);
}
```