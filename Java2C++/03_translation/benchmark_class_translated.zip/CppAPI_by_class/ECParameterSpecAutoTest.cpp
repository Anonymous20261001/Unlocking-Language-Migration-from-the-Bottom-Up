```cpp
#include <cstdint>

// Minimal BigInteger class for testing purposes
class BigInteger {
public:
    long long value;
    BigInteger() : value(0) {}
    BigInteger(long long v) : value(v) {}
    BigInteger(const BigInteger& other) : value(other.value) {}
};

// Minimal ECPoint class (stores affine coordinates as BigIntegers)
class ECPoint {
public:
    BigInteger affineX;
    BigInteger affineY;
    ECPoint() {}
    ECPoint(const BigInteger& x, const BigInteger& y) : affineX(x), affineY(y) {}
};

// Minimal EllipticCurve class (placeholder, not fully implemented)
class EllipticCurve {
public:
    EllipticCurve() {}
};

// ECParameterSpec class matching the Java API
class ECParameterSpec {
private:
    EllipticCurve curve_;
    ECPoint generator_;
    BigInteger order_;
    int cofactor_;

public:
    ECParameterSpec(const EllipticCurve& curve, const ECPoint& generator,
                    const BigInteger& order, int cofactor)
        : curve_(curve), generator_(generator), order_(order), cofactor_(cofactor) {}

    EllipticCurve getCurve() const { return curve_; }
    ECPoint getGenerator() const { return generator_; }
    BigInteger getOrder() const { return order_; }
    int getCofactor() const { return cofactor_; }
};

// Translated test functions
void getCurve_test_2869(EllipticCurve c0, ECPoint c1, BigInteger c2, int c3) {
    ECParameterSpec instance(c0, c1, c2, c3);
    instance.getCurve();
}

void getGenerator_test_2870(EllipticCurve c0, ECPoint c1, BigInteger c2, int c3) {
    ECParameterSpec instance(c0, c1, c2, c3);
    instance.getGenerator();
}

void getCofactor_test_2871(EllipticCurve c0, ECPoint c1, BigInteger c2, int c3) {
    ECParameterSpec instance(c0, c1, c2, c3);
    instance.getCofactor();
}

void getOrder_test_2872(EllipticCurve c0, ECPoint c1, BigInteger c2, int c3) {
    ECParameterSpec instance(c0, c1, c2, c3);
    instance.getOrder();
}
```