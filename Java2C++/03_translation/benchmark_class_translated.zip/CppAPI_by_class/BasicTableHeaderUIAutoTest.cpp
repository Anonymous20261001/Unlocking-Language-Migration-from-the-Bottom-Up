```cpp
// Minimal Graphics class
class Graphics {
public:
    Graphics() {}
};

// Minimal Dimension class
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Minimal JComponent class
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// BasicTableHeaderUI class with identical API but no real implementation
class BasicTableHeaderUI {
public:
    BasicTableHeaderUI() {}

    void installUI(JComponent* p0) {
        // stub
    }

    void uninstallUI(JComponent* p0) {
        // stub
    }

    static void createUI(JComponent* p0) {
        // stub
    }

    Dimension getMaximumSize(JComponent* p0) {
        return Dimension(100, 100); // arbitrary default
    }

    void paint(Graphics* p0, JComponent* p1) {
        // stub
    }

    Dimension getPreferredSize(JComponent* p0) {
        return Dimension(50, 50);
    }

    Dimension getMinimumSize(JComponent* p0) {
        return Dimension(10, 10);
    }

    int getBaseline(JComponent* p0, int p1, int p2) {
        return 0;
    }
};

// Test functions – one per Java @Test method

void installUI_test_8985(JComponent* p0) {
    BasicTableHeaderUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8986(JComponent* p0) {
    BasicTableHeaderUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8987(JComponent* p0) {
    BasicTableHeaderUI instance;
    BasicTableHeaderUI::createUI(p0);
}

void getMaximumSize_test_8988(JComponent* p0) {
    BasicTableHeaderUI instance;
    instance.getMaximumSize(p0);
}

void paint_test_8989(Graphics* p0, JComponent* p1) {
    BasicTableHeaderUI instance;
    instance.paint(p0, p1);
}

void getPreferredSize_test_8990(JComponent* p0) {
    BasicTableHeaderUI instance;
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8991(JComponent* p0) {
    BasicTableHeaderUI instance;
    instance.getMinimumSize(p0);
}

void getBaseline_test_8992(JComponent* p0, int p1, int p2) {
    BasicTableHeaderUI instance;
    instance.getBaseline(p0, p1, p2);
}
```