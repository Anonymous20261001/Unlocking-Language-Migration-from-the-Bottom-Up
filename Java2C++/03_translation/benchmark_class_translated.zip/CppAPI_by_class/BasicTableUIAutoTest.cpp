```cpp
#include <cstddef> // for nullptr

// Forward declarations and minimal implementations for Java-like classes
class Graphics {
public:
    virtual ~Graphics() = default;
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

struct Dimension {
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class BasicTableUI {
public:
    // Instance methods
    void installUI(JComponent* p0) {}
    void uninstallUI(JComponent* p0) {}
    Dimension getMaximumSize(JComponent* p0) { return Dimension(); }
    void paint(Graphics* p0, JComponent* p1) {}
    Dimension getPreferredSize(JComponent* p0) { return Dimension(); }
    Dimension getMinimumSize(JComponent* p0) { return Dimension(); }
    int getBaseline(JComponent* p0, int p1, int p2) { return 0; }
    int getBaselineResizeBehavior(JComponent* p0) { return 0; }

    // Static method
    static BasicTableUI* createUI(JComponent* p0) { return new BasicTableUI(); }
};

// Test function equivalents (exact names and signatures)
void installUI_test_8993(JComponent* p0) {
    BasicTableUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8994(JComponent* p0) {
    BasicTableUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8995(JComponent* p0) {
    BasicTableUI instance;
    BasicTableUI::createUI(p0);
}

void getMaximumSize_test_8996(JComponent* p0) {
    BasicTableUI instance;
    instance.getMaximumSize(p0);
}

void paint_test_8997(Graphics* p0, JComponent* p1) {
    BasicTableUI instance;
    instance.paint(p0, p1);
}

void getPreferredSize_test_8998(JComponent* p0) {
    BasicTableUI instance;
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8999(JComponent* p0) {
    BasicTableUI instance;
    instance.getMinimumSize(p0);
}

void getBaseline_test_9000(JComponent* p0, int p1, int p2) {
    BasicTableUI instance;
    instance.getBaseline(p0, p1, p2);
}

void getBaselineResizeBehavior_test_9001(JComponent* p0) {
    BasicTableUI instance;
    instance.getBaselineResizeBehavior(p0);
}
```