```cpp
#include <string>
#include <functional>
#include <typeinfo>
#include <cstdint>
#include <algorithm>
#include <iostream>

// Minimal BigInteger class to support the ECFieldFp API
class BigInteger {
public:
    BigInteger() : value("0") {}
    BigInteger(const std::string& val) : value(val) {
        // Remove leading zeros but keep at least one digit
        size_t pos = value.find_first_not_of('0');
        if (pos == std::string::npos) {
            value = "0";
        } else if (pos > 0) {
            value = value.substr(pos);
        }
    }
    BigInteger(long long val) : value(std::to_string(val)) {}

    std::string toString() const { return value; }

    // Number of bits needed to represent this non-negative integer
    int bitLength() const {
        if (value == "0") return 0;
        std::string copy = value;
        int bits = 0;
        while (copy != "0") {
            copy = divideByTwo(copy);
            ++bits;
        }
        return bits;
    }

    bool operator==(const BigInteger& other) const {
        return value == other.value;
    }

    bool operator!=(const BigInteger& other) const {
        return value != other.value;
    }

private:
    std::string value;

    // Divide a decimal string by 2 and return the quotient (non-negative)
    static std::string divideByTwo(const std::string& str) {
        std::string result;
        int remainder = 0;
        for (char ch : str) {
            int digit = remainder * 10 + (ch - '0');
            int quotient = digit / 2;
            remainder = digit % 2;
            if (!(result.empty() && quotient == 0)) {
                result.push_back(static_cast<char>('0' + quotient));
            }
        }
        if (result.empty()) result = "0";
        return result;
    }
};

// Base class for Object (to mimic Java Object.equals)
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const = 0;
    virtual int hashCode() const = 0;
};

// ECFieldFp – copies the Java class java.security.spec.ECFieldFp
class ECFieldFp : public Object {
private:
    BigInteger p;
public:
    explicit ECFieldFp(const BigInteger& prime) : p(prime) {}

    BigInteger getP() const {
        return p;
    }

    int getFieldSize() const {
        return p.bitLength();
    }

    bool equals(const Object& obj) const override {
        // Try dynamic cast; if it fails, the objects are not equal
        const ECFieldFp* other = dynamic_cast<const ECFieldFp*>(&obj);
        if (!other) return false;
        return p == other->p;
    }

    int hashCode() const override {
        // Use the hash of the decimal string representation
        std::hash<std::string> hasher;
        return static_cast<int>(hasher(p.toString()));
    }
};

// ----- Translated test functions ------------------------------------------------------
void getP_test_2865(BigInteger c0) {
    ECFieldFp instance(c0);
    instance.getP();
}

void getFieldSize_test_2866(BigInteger c0) {
    ECFieldFp instance(c0);
    instance.getFieldSize();
}

void equals_test_2867(Object& p0, BigInteger c0) {
    ECFieldFp instance(c0);
    instance.equals(p0);
}

void hashCode_test_2868(BigInteger c0) {
    ECFieldFp instance(c0);
    instance.hashCode();
}
```