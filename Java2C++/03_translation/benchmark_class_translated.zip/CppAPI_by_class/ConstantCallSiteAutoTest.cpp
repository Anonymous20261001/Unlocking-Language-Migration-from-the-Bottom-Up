```cpp
#include <stdexcept>

// Minimal placeholder for java.lang.invoke.MethodHandle
class MethodHandle {
public:
    MethodHandle() = default;
    MethodHandle(const MethodHandle&) = default;
    MethodHandle& operator=(const MethodHandle&) = default;
    // No further methods needed for the tests
};

// C++ equivalent of java.lang.invoke.ConstantCallSite
class ConstantCallSite {
private:
    MethodHandle target;

public:
    // Constructor: stores given method handle
    ConstantCallSite(const MethodHandle& target) : target(target) {}

    // Returns the target method handle (copy from Java)
    MethodHandle getTarget() const {
        return target;
    }

    // Returns a method handle that always invokes the call site's target
    // In Java, dynamicInvoker() returns a method handle equivalent to getTarget()
    // for ConstantCallSite. We mimic by returning a copy.
    MethodHandle dynamicInvoker() const {
        return target;
    }

    // In Java, ConstantCallSite.setTarget() always throws UnsupportedOperationException
    void setTarget(const MethodHandle& /*p0*/) {
        throw std::runtime_error("ConstantCallSite does not support setTarget");
    }
};

// Translated test functions (named exactly as in Java)
void getTarget_test_2378(MethodHandle c0) {
    ConstantCallSite instance(c0);
    instance.getTarget();
}

void dynamicInvoker_test_2379(MethodHandle c0) {
    ConstantCallSite instance(c0);
    instance.dynamicInvoker();
}

void setTarget_test_2380(MethodHandle p0, MethodHandle c0) {
    ConstantCallSite instance(c0);
    instance.setTarget(p0);
}
```