```cpp
#include <cstddef>  // not strictly needed

// Forward declarations
class ImageConsumer;
class ImageProducer;
class ImageFilter;

/** Interface for image consumers (analogous to java.awt.image.ImageConsumer) */
class ImageConsumer {
public:
    virtual ~ImageConsumer() = default;
    // In Java, ImageConsumer defines many methods (setDimensions, setPixels, ...)
    // but none of them are used in the translated tests, so we leave the interface empty.
};

/** Interface for image producers (analogous to java.awt.image.ImageProducer) */
class ImageProducer {
public:
    virtual ~ImageProducer() = default;
    virtual void addConsumer(ImageConsumer* consumer) = 0;
    virtual void removeConsumer(ImageConsumer* consumer) = 0;
    virtual void startProduction(ImageConsumer* consumer) = 0;
    virtual bool isConsumer(ImageConsumer* consumer) = 0;
    virtual void requestTopDownLeftRightResend(ImageConsumer* consumer) = 0;
};

/** Base class for image filters (analogous to java.awt.image.ImageFilter) */
class ImageFilter {
public:
    virtual ~ImageFilter() = default;
    // ImageFilter in Java has many filter-related methods, but they are not used in the tests.
};

/**
 * Implementation of FilteredImageSource (java.awt.image.FilteredImageSource).
 * Wraps an existing ImageProducer and an ImageFilter, and forwards
 * consumer registration/production requests to the underlying producer.
 */
class FilteredImageSource : public ImageProducer {
public:
    FilteredImageSource(ImageProducer* producer, ImageFilter* filter)
        : m_producer(producer), m_filter(filter) {}

    void addConsumer(ImageConsumer* consumer) override {
        m_producer->addConsumer(consumer);
    }

    void removeConsumer(ImageConsumer* consumer) override {
        m_producer->removeConsumer(consumer);
    }

    void startProduction(ImageConsumer* consumer) override {
        m_producer->startProduction(consumer);
    }

    bool isConsumer(ImageConsumer* consumer) override {
        return m_producer->isConsumer(consumer);
    }

    void requestTopDownLeftRightResend(ImageConsumer* consumer) override {
        m_producer->requestTopDownLeftRightResend(consumer);
    }

private:
    ImageProducer* m_producer;
    ImageFilter*   m_filter;
};

// ============================================================
// Translated test functions (one per @Test method)
// ============================================================

void addConsumer_test_1264(ImageConsumer* p0, ImageProducer* c0, ImageFilter* c1) {
    FilteredImageSource instance(c0, c1);
    instance.addConsumer(p0);
}

void removeConsumer_test_1265(ImageConsumer* p0, ImageProducer* c0, ImageFilter* c1) {
    FilteredImageSource instance(c0, c1);
    instance.removeConsumer(p0);
}

void startProduction_test_1266(ImageConsumer* p0, ImageProducer* c0, ImageFilter* c1) {
    FilteredImageSource instance(c0, c1);
    instance.startProduction(p0);
}

void isConsumer_test_1267(ImageConsumer* p0, ImageProducer* c0, ImageFilter* c1) {
    FilteredImageSource instance(c0, c1);
    instance.isConsumer(p0);
}

void requestTopDownLeftRightResend_test_1268(ImageConsumer* p0, ImageProducer* c0,
                                              ImageFilter* c1) {
    FilteredImageSource instance(c0, c1);
    instance.requestTopDownLeftRightResend(p0);
}
```