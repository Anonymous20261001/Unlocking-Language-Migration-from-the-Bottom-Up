```cpp
#include <cstddef>

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicMenuBarUI implementation with identical API (stubbed)
class BasicMenuBarUI {
public:
    void installUI(JComponent* /*c*/) {}
    void uninstallUI(JComponent* /*c*/) {}
    static BasicMenuBarUI* createUI(JComponent* /*c*/) { return new BasicMenuBarUI(); }
    void getMaximumSize(JComponent* /*c*/) {}
    void getMinimumSize(JComponent* /*c*/) {}
};

// Test functions – one per @Test method, same name and parameter type
void installUI_test_8824(JComponent* p0) {
    BasicMenuBarUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8825(JComponent* p0) {
    BasicMenuBarUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8826(JComponent* p0) {
    BasicMenuBarUI instance;
    BasicMenuBarUI::createUI(p0);   // static call, result discarded (as in Java test)
}

void getMaximumSize_test_8827(JComponent* p0) {
    BasicMenuBarUI instance;
    instance.getMaximumSize(p0);
}

void getMinimumSize_test_8828(JComponent* p0) {
    BasicMenuBarUI instance;
    instance.getMinimumSize(p0);
}
```