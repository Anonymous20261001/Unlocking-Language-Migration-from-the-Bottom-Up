```cpp
#include <memory>
#include <functional>

// Minimal Object class (equivalent to java.lang.Object)
class Object {
public:
    virtual ~Object() = default;
};

// Runnable interface
class Runnable {
public:
    virtual void run() = 0;
    virtual ~Runnable() = default;
};

// Callable interface (returning Object*)
class Callable {
public:
    virtual std::shared_ptr<Object> call() = 0;
    virtual ~Callable() = default;
};

// Executor interface
class Executor {
public:
    virtual void execute(std::shared_ptr<Runnable> task) = 0;
    virtual ~Executor() = default;
};

// Future (minimal placeholder, not fully implemented)
class Future {
public:
    virtual std::shared_ptr<Object> get() = 0; // blocks until result
    virtual ~Future() = default;
};

// ExecutorCompletionService
class ExecutorCompletionService {
private:
    Executor& executor;
public:
    ExecutorCompletionService(Executor& exec) : executor(exec) {}

    // poll() returns nullptr if no task completed, otherwise a Future
    std::shared_ptr<Future> poll() {
        // In a real implementation this would check a completion queue
        return nullptr;
    }

    // submit a Callable task
    std::shared_ptr<Future> submit(std::shared_ptr<Callable> task) {
        // Wraps the Callable into a Runnable and executes it
        class FutureTask : public Future, public Runnable {
        private:
            std::shared_ptr<Callable> callable;
            std::shared_ptr<Object> result;
        public:
            FutureTask(std::shared_ptr<Callable> c) : callable(c) {}
            void run() override {
                result = callable->call();
            }
            std::shared_ptr<Object> get() override {
                // In a real implementation would wait for completion
                return result;
            }
        };
        auto future = std::make_shared<FutureTask>(task);
        executor.execute(future);
        return future;
    }

    // submit a Runnable task with a predefined result
    std::shared_ptr<Future> submit(std::shared_ptr<Runnable> task, std::shared_ptr<Object> result) {
        class FutureTask : public Future, public Runnable {
        private:
            std::shared_ptr<Runnable> runnable;
            std::shared_ptr<Object> result;
        public:
            FutureTask(std::shared_ptr<Runnable> r, std::shared_ptr<Object> res)
                : runnable(r), result(res) {}
            void run() override {
                runnable->run();
            }
            std::shared_ptr<Object> get() override {
                return result;
            }
        };
        auto future = std::make_shared<FutureTask>(task, result);
        executor.execute(future);
        return future;
    }
};

// ========== Test functions ==========

void poll_test_4464(Executor& c0) {
    ExecutorCompletionService instance(c0);
    instance.poll();
}

void submit_test_4465(std::shared_ptr<Callable> p0, Executor& c0) {
    ExecutorCompletionService instance(c0);
    instance.submit(p0);
}

void submit_test_4466(std::shared_ptr<Runnable> p0, std::shared_ptr<Object> p1, Executor& c0) {
    ExecutorCompletionService instance(c0);
    instance.submit(p0, p1);
}
```