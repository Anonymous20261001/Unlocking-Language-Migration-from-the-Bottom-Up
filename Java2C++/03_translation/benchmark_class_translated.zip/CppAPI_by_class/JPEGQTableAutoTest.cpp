```cpp
#include <vector>
#include <string>
#include <sstream>
#include <cmath>
#include <stdexcept>
#include <cstdint>
#include <algorithm>

// C++ equivalent of Java's javax.imageio.plugins.jpeg.JPEGQTable
class JPEGQTable {
public:
    // Constructor: expects a vector of exactly 64 quantization values
    explicit JPEGQTable(const std::vector<int>& table) {
        if (table.size() != 64) {
            throw std::invalid_argument("JPEGQTable requires exactly 64 entries");
        }
        table_.assign(table.begin(), table.end());
    }

    // Returns a scaled copy of this quantization table
    JPEGQTable getScaledInstance(float scaleFactor, bool forceBaseline) const {
        std::vector<int> scaled(64);
        const int maxVal = forceBaseline ? 255 : 65535;
        for (size_t i = 0; i < 64; ++i) {
            double scaledDouble = table_[i] * static_cast<double>(scaleFactor);
            int rounded = static_cast<int>(std::round(scaledDouble));
            // Clamp to [1, maxVal] as per Java spec
            int clamped = std::max(1, std::min(rounded, maxVal));
            scaled[i] = clamped;
        }
        return JPEGQTable(scaled);
    }

    // Returns a copy of the internal table
    std::vector<int> getTable() const {
        return table_;
    }

    // Returns a string representation (similar to Java's default)
    std::string toString() const {
        std::ostringstream oss;
        oss << "JPEGQTable[";
        for (size_t i = 0; i < 64; ++i) {
            if (i > 0) oss << ", ";
            oss << table_[i];
        }
        oss << "]";
        return oss.str();
    }

private:
    std::vector<int> table_; // always size 64
};

// -----------------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// -----------------------------------------------------------------------

void getScaledInstance_test_5413(float p0, bool p1, const std::vector<int>& c0) {
    JPEGQTable instance(c0);
    instance.getScaledInstance(p0, p1);
}

void toString_test_5414(const std::vector<int>& c0) {
    JPEGQTable instance(c0);
    instance.toString();
}

void getTable_test_5415(const std::vector<int>& c0) {
    JPEGQTable instance(c0);
    instance.getTable();
}
```