```cpp
#include <functional>
#include <string>

using DoubleBinaryOperator = std::function<double(double, double)>;

class DoubleAccumulator {
private:
    double value;
    double identity;
    DoubleBinaryOperator accumulatorFunction;

public:
    DoubleAccumulator(DoubleBinaryOperator op, double identityValue)
        : identity(identityValue), value(identityValue), accumulatorFunction(op) {}

    void accumulate(double x) {
        value = accumulatorFunction(value, x);
    }

    double getThenReset() {
        double old = value;
        reset();
        return old;
    }

    void reset() {
        value = identity;
    }

    double get() const {
        return value;
    }

    std::string toString() const {
        return std::to_string(value);
    }

    int intValue() const {
        return static_cast<int>(value);
    }

    long longValue() const {
        return static_cast<long>(value);
    }

    float floatValue() const {
        return static_cast<float>(value);
    }

    double doubleValue() const {
        return value;
    }
};

// Test functions (each corresponds to a Java @Test method)
void accumulate_test_4945(double p0, DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.accumulate(p0);
}

void getThenReset_test_4946(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.getThenReset();
}

void reset_test_4947(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.reset();
}

void get_test_4948(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.get();
}

void toString_test_4949(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.toString();
}

void intValue_test_4950(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.intValue();
}

void longValue_test_4951(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.longValue();
}

void floatValue_test_4952(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.floatValue();
}

void doubleValue_test_4953(DoubleBinaryOperator c0, double c1) {
    DoubleAccumulator instance(c0, c1);
    instance.doubleValue();
}
```