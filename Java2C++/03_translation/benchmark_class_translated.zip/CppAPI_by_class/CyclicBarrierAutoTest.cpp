```cpp
#include <cstddef>  // not strictly needed, but kept for completeness

class CyclicBarrier {
private:
    int parties;
    int waiting;
    bool broken;

public:
    explicit CyclicBarrier(int parties)
        : parties(parties), waiting(0), broken(false) {}

    int getParties() const {
        return parties;
    }

    bool isBroken() const {
        return broken;
    }

    int getNumberWaiting() const {
        return waiting;
    }

    void reset() {
        waiting = 0;
        broken = false;
    }
};

// Test functions (exact translations of the Java @Test methods)

void getParties_test_4444(int c0) {
    CyclicBarrier instance(c0);
    instance.getParties();
}

void isBroken_test_4445(int c0) {
    CyclicBarrier instance(c0);
    instance.isBroken();
}

void getNumberWaiting_test_4446(int c0) {
    CyclicBarrier instance(c0);
    instance.getNumberWaiting();
}

void reset_test_4447(int c0) {
    CyclicBarrier instance(c0);
    instance.reset();
}
```