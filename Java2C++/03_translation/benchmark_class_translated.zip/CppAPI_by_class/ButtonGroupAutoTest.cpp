```cpp
#include <vector>
#include <algorithm>

class ButtonModel {
public:
    ButtonModel() : selected(false) {}
    virtual ~ButtonModel() {}
    bool isSelected() const { return selected; }
    void setSelected(bool b) { selected = b; }
private:
    bool selected;
};

class AbstractButton {
public:
    AbstractButton() : model(nullptr) {}
    virtual ~AbstractButton() {}
    void setModel(ButtonModel* m) { model = m; }
    ButtonModel* getModel() const { return model; }
private:
    ButtonModel* model;
};

class ButtonGroup {
public:
    ButtonGroup() {}
    ~ButtonGroup() {}

    void setSelected(ButtonModel* model, bool selected) {
        if (selected) {
            for (auto& btn : buttons) {
                ButtonModel* m = btn->getModel();
                if (m && m != model) {
                    m->setSelected(false);
                }
            }
        }
        if (model) {
            model->setSelected(selected);
        }
    }

    void clearSelection() {
        for (auto& btn : buttons) {
            ButtonModel* m = btn->getModel();
            if (m) m->setSelected(false);
        }
    }

    std::vector<AbstractButton*> getElements() const {
        return buttons;
    }

    ButtonModel* getSelection() const {
        for (auto& btn : buttons) {
            ButtonModel* m = btn->getModel();
            if (m && m->isSelected()) return m;
        }
        return nullptr;
    }

    int getButtonCount() const {
        return static_cast<int>(buttons.size());
    }

    bool isSelected(ButtonModel* model) const {
        return model && model->isSelected();
    }

    void remove(AbstractButton* button) {
        auto it = std::find(buttons.begin(), buttons.end(), button);
        if (it != buttons.end()) {
            buttons.erase(it);
        }
    }

    void add(AbstractButton* button) {
        if (button && std::find(buttons.begin(), buttons.end(), button) == buttons.end()) {
            buttons.push_back(button);
        }
    }

private:
    std::vector<AbstractButton*> buttons;
};

// Test functions
void setSelected_test_6561(ButtonModel* p0, bool p1) {
    ButtonGroup instance;
    instance.setSelected(p0, p1);
}

void clearSelection_test_6562() {
    ButtonGroup instance;
    instance.clearSelection();
}

void getElements_test_6563() {
    ButtonGroup instance;
    instance.getElements();
}

void getSelection_test_6564() {
    ButtonGroup instance;
    instance.getSelection();
}

void getButtonCount_test_6565() {
    ButtonGroup instance;
    instance.getButtonCount();
}

void isSelected_test_6566(ButtonModel* p0) {
    ButtonGroup instance;
    instance.isSelected(p0);
}

void remove_test_6567(AbstractButton* p0) {
    ButtonGroup instance;
    instance.remove(p0);
}

void add_test_6568(AbstractButton* p0) {
    ButtonGroup instance;
    instance.add(p0);
}
```