```cpp
#include <vector>
#include <cstddef>
#include <algorithm>
#include <stdexcept>

class ByteArrayInputStream {
public:
    // Constructor taking a vector of bytes
    explicit ByteArrayInputStream(const std::vector<char>& data)
        : buf(data), pos(0), mark(0) {}

    // Reset to the last mark (initially 0)
    void reset() {
        pos = mark;
    }

    // Read all remaining bytes and return them as a new vector
    std::vector<char> readAllBytes() {
        std::vector<char> result(buf.begin() + pos, buf.end());
        pos = buf.size();
        return result;
    }

    // Set a mark at the current position (readlimit ignored)
    void mark(int /*readlimit*/) {
        mark = pos;
    }

    // Read up to len bytes into the output array starting at offset off.
    // Returns the number of bytes actually read.
    int read(std::vector<char>& b, int off, int len) {
        if (len <= 0) return 0;
        if (off < 0 || off + len > static_cast<int>(b.size())) {
            throw std::out_of_range("Offset and length out of bounds");
        }
        int available = buf.size() - pos;
        int toRead = std::min(len, available);
        if (toRead <= 0) return -1; // end of stream
        std::copy(buf.begin() + pos, buf.begin() + pos + toRead, b.begin() + off);
        pos += toRead;
        return toRead;
    }

    // Read a single byte, return as int (0-255) or -1 if end
    int read() {
        if (pos >= buf.size()) return -1;
        return static_cast<unsigned char>(buf[pos++]);
    }

    // Read exactly len bytes into b (or as many as available), returns count.
    int readNBytes(std::vector<char>& b, int off, int len) {
        int totalRead = 0;
        while (totalRead < len) {
            int r = read(b, off + totalRead, len - totalRead);
            if (r == -1) break; // end of stream
            totalRead += r;
        }
        return totalRead;
    }

    // Skip n bytes, return actual number skipped
    long skip(long n) {
        if (n <= 0) return 0;
        int available = buf.size() - pos;
        long actual = std::min<long>(n, available);
        pos += actual;
        return actual;
    }

    // Return number of remaining bytes (as int)
    int available() {
        return buf.size() - pos;
    }

    // Mark is always supported
    bool markSupported() {
        return true;
    }

private:
    std::vector<char> buf;
    std::size_t pos;
    std::size_t mark;
};

// ----------------------------------------------------------------------------
// Translated test functions (one per Java @Test method)
// ----------------------------------------------------------------------------

void reset_test_1697(const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.reset();
}

void readAllBytes_test_1698(const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.readAllBytes();
}

void mark_test_1699(int p0, const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.mark(p0);
}

void read_test_1700(std::vector<char>& p0, int p1, int p2, const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.read(p0, p1, p2);
}

void read_test_1701(const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.read();
}

void readNBytes_test_1702(std::vector<char>& p0, int p1, int p2, const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.readNBytes(p0, p1, p2);
}

void skip_test_1703(long p0, const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.skip(p0);
}

void available_test_1704(const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.available();
}

void markSupported_test_1705(const std::vector<char>& c0) {
    ByteArrayInputStream instance(c0);
    instance.markSupported();
}
```