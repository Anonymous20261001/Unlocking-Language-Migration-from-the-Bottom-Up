```cpp
#include <string>
#include <memory>

// Minimal BigInteger class that stores a string representation.
// No arithmetic operations are needed for the test cases.
class BigInteger {
public:
    BigInteger() : value_("0") {}
    explicit BigInteger(const std::string& val) : value_(val) {}
    BigInteger(const BigInteger&) = default;
    BigInteger& operator=(const BigInteger&) = default;

    // Provide a way to create BigInteger from a C string (optional)
    static BigInteger fromString(const char* str) {
        return BigInteger(std::string(str));
    }

    const std::string& toString() const { return value_; }

private:
    std::string value_;
};

// C++ equivalent of java.security.spec.DSAPrivateKeySpec
class DSAPrivateKeySpec {
public:
    DSAPrivateKeySpec(const BigInteger& p, const BigInteger& q,
                      const BigInteger& g, const BigInteger& x)
        : p_(p), q_(q), g_(g), x_(x) {}

    const BigInteger& getP() const { return p_; }
    const BigInteger& getQ() const { return q_; }
    const BigInteger& getG() const { return g_; }
    const BigInteger& getX() const { return x_; }

private:
    BigInteger p_;
    BigInteger q_;
    BigInteger g_;
    BigInteger x_;
};

// Test functions (translated from DSAPrivateKeySpecAutoTest.java)
// Each function takes four BigInteger arguments (by const reference)
// and exercises one API method.

void getP_test_2851(const BigInteger& c0, const BigInteger& c1,
                    const BigInteger& c2, const BigInteger& c3) {
    DSAPrivateKeySpec instance(c0, c1, c2, c3);
    instance.getP();
}

void getQ_test_2852(const BigInteger& c0, const BigInteger& c1,
                    const BigInteger& c2, const BigInteger& c3) {
    DSAPrivateKeySpec instance(c0, c1, c2, c3);
    instance.getQ();
}

void getG_test_2853(const BigInteger& c0, const BigInteger& c1,
                    const BigInteger& c2, const BigInteger& c3) {
    DSAPrivateKeySpec instance(c0, c1, c2, c3);
    instance.getG();
}

void getX_test_2854(const BigInteger& c0, const BigInteger& c1,
                    const BigInteger& c2, const BigInteger& c3) {
    DSAPrivateKeySpec instance(c0, c1, c2, c3);
    instance.getX();
}
```