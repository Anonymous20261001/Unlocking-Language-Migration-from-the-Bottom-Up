```cpp
#include <string>
#include <vector>
#include <memory>

// ----- Minimal stubs for Java AWT/Swing types -----

// Forward declarations
class Component;
class Dimension;
class KeyEvent;
class MouseEvent;
class MenuSelectionManager;
class SingleSelectionModel;
class MenuKeyListener;
class PopupMenuListener;
class Action;
class JMenuItem;
class PopupMenuUI;
class AccessibleContext;

// MenuElement interface
class MenuElement {
public:
    virtual void processKeyEvent(KeyEvent* e, MenuElement** path, MenuSelectionManager* manager) = 0;
    virtual void processMouseEvent(MouseEvent* e, MenuElement** path, MenuSelectionManager* manager) = 0;
    virtual void menuSelectionChanged(bool isIncluded) = 0;
    virtual std::vector<MenuElement*> getSubElements() = 0;
    virtual ~MenuElement() = default;
};

// PopupMenuUI stub
class PopupMenuUI {
public:
    virtual ~PopupMenuUI() = default;
};

// Component stub (no visible functionality)
class Component {
public:
    virtual ~Component() = default;
};

// Dimension stub
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// KeyEvent stub
class KeyEvent {
public:
    // minimal stub; no methods used directly
};

// MouseEvent stub
class MouseEvent {
public:
    // stub
};

// MenuSelectionManager stub
class MenuSelectionManager {
public:
    // stub
};

// SingleSelectionModel stub
class SingleSelectionModel {
public:
    // stub
};

// MenuKeyListener stub
class MenuKeyListener {
public:
    virtual ~MenuKeyListener() = default;
};

// PopupMenuListener stub
class PopupMenuListener {
public:
    virtual ~PopupMenuListener() = default;
};

// Action stub
class Action {
public:
    virtual ~Action() = default;
};

// JMenuItem stub
class JMenuItem : public Component {
public:
    // stub
};

// AccessibleContext stub
class AccessibleContext {
public:
    // stub
};

// ----- JPopupMenu implementation -----
class JPopupMenu : public MenuElement {
private:
    PopupMenuUI* ui = nullptr;
    Component* selected = nullptr;
    Dimension popupSize;
    Component* invoker = nullptr;
    bool borderPainted = true;
    bool lightWeightPopupEnabled = true;
    bool visible = false;
    int locationX = 0, locationY = 0;
    std::string label;
    SingleSelectionModel* selectionModel = nullptr;
    static bool defaultLightWeightPopupEnabled;

    // Lists for listeners (stubs, not really used)
    std::vector<MenuKeyListener*> menuKeyListeners;
    std::vector<PopupMenuListener*> popupMenuListeners;
    // Internal components list (simplified)
    std::vector<Component*> components;

public:
    JPopupMenu() = default;

    // Methods from the test
    std::string getUIClassID() { return "PopupMenuUI"; }
    PopupMenuUI* getUI() { return ui; }
    void setUI(PopupMenuUI* p0) { ui = p0; }
    void setSelected(Component* p0) { selected = p0; }
    void setPopupSize(int p0, int p1) { popupSize = Dimension(p0, p1); }
    void setPopupSize(Dimension p0) { popupSize = p0; }
    static void setDefaultLightWeightPopupEnabled(bool p0) { defaultLightWeightPopupEnabled = p0; }
    static bool getDefaultLightWeightPopupEnabled() { return defaultLightWeightPopupEnabled; }
    void setInvoker(Component* p0) { invoker = p0; }
    Component* getInvoker() { return invoker; }
    Component* getComponentAtIndex(int p0) {
        if (p0 >= 0 && p0 < (int)components.size())
            return components[p0];
        return nullptr;
    }
    bool isBorderPainted() { return borderPainted; }
    void setBorderPainted(bool p0) { borderPainted = p0; }
    // getMargin returns an Insets object; we'll return a dummy (maybe -1)
    // Since test doesn't use return, we'll just return nullptr or a simple struct?
    // Create a dummy Insets class? Simpler: use Dimension*? But method signature is java.awt.Insets.
    // We'll introduce a minimal Insets class.
    // To avoid too many classes, just return nullptr; test will compile (calling function, no use)
    void* getMargin() { return nullptr; }
    void menuSelectionChanged(bool p0) override {
        // stub
    }
    std::vector<MenuElement*> getSubElements() override {
        // return an empty vector; in Java returns MenuElement[],
        // but we can represent as vector of MenuElement*
        return {};
    }
    void addMenuKeyListener(MenuKeyListener* p0) { menuKeyListeners.push_back(p0); }
    void removeMenuKeyListener(MenuKeyListener* p0) {
        // stub removal
    }
    std::vector<MenuKeyListener*> getMenuKeyListeners() { return menuKeyListeners; }
    SingleSelectionModel* getSelectionModel() { return selectionModel; }
    void setSelectionModel(SingleSelectionModel* p0) { selectionModel = p0; }
    void setLightWeightPopupEnabled(bool p0) { lightWeightPopupEnabled = p0; }
    bool isLightWeightPopupEnabled() { return lightWeightPopupEnabled; }
    void addPopupMenuListener(PopupMenuListener* p0) { popupMenuListeners.push_back(p0); }
    void removePopupMenuListener(PopupMenuListener* p0) {
        // stub
    }
    std::vector<PopupMenuListener*> getPopupMenuListeners() { return popupMenuListeners; }
    AccessibleContext* getAccessibleContext() {
        static AccessibleContext ac;
        return &ac;
    }
    bool isVisible() { return visible; }
    void setVisible(bool p0) { visible = p0; }
    void setLocation(int p0, int p1) { locationX = p0; locationY = p1; }
    void show(Component* p0, int p1, int p2) {
        // no-op stub
    }
    void processKeyEvent(KeyEvent* e, MenuElement** path, MenuSelectionManager* manager) override {
        // stub
    }
    bool isPopupTrigger(MouseEvent* e) { return false; }
    void processMouseEvent(MouseEvent* e, MenuElement** path, MenuSelectionManager* manager) override {
        // stub
    }
    void setLabel(const std::string& p0) { label = p0; }
    int getComponentIndex(Component* p0) {
        for (size_t i = 0; i < components.size(); ++i) {
            if (components[i] == p0) return (int)i;
        }
        return -1;
    }
    void updateUI() {
        // no-op
    }
    void pack() {
        // no-op
    }
    void addSeparator() {
        // no-op
    }
    void remove(int p0) {
        if (p0 >= 0 && p0 < (int)components.size())
            components.erase(components.begin() + p0);
    }
    JMenuItem* insert(Action* p0, int p1) {
        // stub, return nullptr
        return nullptr;
    }
    void insert(Component* p0, int p1) {
        // stub insertion
    }
    JMenuItem* add(Action* p0) {
        // return a dummy JMenuItem
        JMenuItem* item = new JMenuItem();
        components.push_back(item);
        return item;
    }
    JMenuItem* add(const std::string& p0) {
        JMenuItem* item = new JMenuItem();
        components.push_back(item);
        return item;
    }
    JMenuItem* add(JMenuItem* p0) {
        components.push_back(p0);
        return p0;
    }
    std::string getLabel() { return label; }
    Component* getComponent() {
        // In Java JPopupMenu.getComponent() returns the invoker? Actually it's from Component.
        // JPopupMenu inherits from Component, so getComponent() is likely this.
        // But the test calls instance.getComponent() which is inherited from Component.
        // Since we don't have a meaningful implementation, return nullptr.
        // To be safe, return a dummy.
        return nullptr;
    }

    // Destructor: clean up owned objects? For test purposes we can ignore leaks.
    ~JPopupMenu() override = default;
};

bool JPopupMenu::defaultLightWeightPopupEnabled = true;

// ----- Test functions (translation of @Test methods) -----

#include <cassert> // optional

void getUIClassID_test_7459() {
    JPopupMenu instance;
    instance.getUIClassID();
}

void getUI_test_7460() {
    JPopupMenu instance;
    instance.getUI();
}

void setUI_test_7461(PopupMenuUI* p0) {
    JPopupMenu instance;
    instance.setUI(p0);
}

void setSelected_test_7462(Component* p0) {
    JPopupMenu instance;
    instance.setSelected(p0);
}

void setPopupSize_test_7463(int p0, int p1) {
    JPopupMenu instance;
    instance.setPopupSize(p0, p1);
}

void setPopupSize_test_7464(Dimension* p0) {
    JPopupMenu instance;
    instance.setPopupSize(*p0);
}

void setDefaultLightWeightPopupEnabled_test_7465(bool p0) {
    JPopupMenu instance;
    JPopupMenu::setDefaultLightWeightPopupEnabled(p0);
}

void setInvoker_test_7466(Component* p0) {
    JPopupMenu instance;
    instance.setInvoker(p0);
}

void getInvoker_test_7467() {
    JPopupMenu instance;
    instance.getInvoker();
}

void getComponentAtIndex_test_7468(int p0) {
    JPopupMenu instance;
    instance.getComponentAtIndex(p0);
}

void isBorderPainted_test_7469() {
    JPopupMenu instance;
    instance.isBorderPainted();
}

void setBorderPainted_test_7470(bool p0) {
    JPopupMenu instance;
    instance.setBorderPainted(p0);
}

void getMargin_test_7471() {
    JPopupMenu instance;
    instance.getMargin();
}

void menuSelectionChanged_test_7472(bool p0) {
    JPopupMenu instance;
    instance.menuSelectionChanged(p0);
}

void getSubElements_test_7473() {
    JPopupMenu instance;
    instance.getSubElements();
}

void addMenuKeyListener_test_7474(MenuKeyListener* p0) {
    JPopupMenu instance;
    instance.addMenuKeyListener(p0);
}

void removeMenuKeyListener_test_7475(MenuKeyListener* p0) {
    JPopupMenu instance;
    instance.removeMenuKeyListener(p0);
}

void getMenuKeyListeners_test_7476() {
    JPopupMenu instance;
    instance.getMenuKeyListeners();
}

void getSelectionModel_test_7477() {
    JPopupMenu instance;
    instance.getSelectionModel();
}

void setSelectionModel_test_7478(SingleSelectionModel* p0) {
    JPopupMenu instance;
    instance.setSelectionModel(p0);
}

void getDefaultLightWeightPopupEnabled_test_7479() {
    JPopupMenu instance;
    JPopupMenu::getDefaultLightWeightPopupEnabled();
}

void setLightWeightPopupEnabled_test_7480(bool p0) {
    JPopupMenu instance;
    instance.setLightWeightPopupEnabled(p0);
}

void isLightWeightPopupEnabled_test_7481() {
    JPopupMenu instance;
    instance.isLightWeightPopupEnabled();
}

void addPopupMenuListener_test_7482(PopupMenuListener* p0) {
    JPopupMenu instance;
    instance.addPopupMenuListener(p0);
}

void removePopupMenuListener_test_7483(PopupMenuListener* p0) {
    JPopupMenu instance;
    instance.removePopupMenuListener(p0);
}

void getPopupMenuListeners_test_7484() {
    JPopupMenu instance;
    instance.getPopupMenuListeners();
}

void getAccessibleContext_test_7485() {
    JPopupMenu instance;
    instance.getAccessibleContext();
}

void isVisible_test_7486() {
    JPopupMenu instance;
    instance.isVisible();
}

void setVisible_test_7487(bool p0) {
    JPopupMenu instance;
    instance.setVisible(p0);
}

void setLocation_test_7488(int p0, int p1) {
    JPopupMenu instance;
    instance.setLocation(p0, p1);
}

void show_test_7489(Component* p0, int p1, int p2) {
    JPopupMenu instance;
    instance.show(p0, p1, p2);
}

void processKeyEvent_test_7490(KeyEvent* p0, MenuElement** p1, MenuSelectionManager* p2) {
    JPopupMenu instance;
    instance.processKeyEvent(p0, p1, p2);
}

void isPopupTrigger_test_7491(MouseEvent* p0) {
    JPopupMenu instance;
    instance.isPopupTrigger(p0);
}

void processMouseEvent_test_7492(MouseEvent* p0, MenuElement** p1, MenuSelectionManager* p2) {
    JPopupMenu instance;
    instance.processMouseEvent(p0, p1, p2);
}

void setLabel_test_7493(const std::string& p0) {
    JPopupMenu instance;
    instance.setLabel(p0);
}

void getComponentIndex_test_7494(Component* p0) {
    JPopupMenu instance;
    instance.getComponentIndex(p0);
}

void updateUI_test_7495() {
    JPopupMenu instance;
    instance.updateUI();
}

void pack_test_7496() {
    JPopupMenu instance;
    instance.pack();
}

void addSeparator_test_7497() {
    JPopupMenu instance;
    instance.addSeparator();
}

void remove_test_7498(int p0) {
    JPopupMenu instance;
    instance.remove(p0);
}

void insert_test_7499(Action* p0, int p1) {
    JPopupMenu instance;
    instance.insert(p0, p1);
}

void insert_test_7500(Component* p0, int p1) {
    JPopupMenu instance;
    instance.insert(p0, p1);
}

void add_test_7501(Action* p0) {
    JPopupMenu instance;
    instance.add(p0);
}

void add_test_7502(const std::string& p0) {
    JPopupMenu instance;
    instance.add(p0);
}

void add_test_7503(JMenuItem* p0) {
    JPopupMenu instance;
    instance.add(p0);
}

void getLabel_test_7504() {
    JPopupMenu instance;
    instance.getLabel();
}

void getComponent_test_7505() {
    JPopupMenu instance;
    instance.getComponent();
}

// Optional main for standalone testing
int main() {
    // Example: call all functions (they should compile and run without crashes)
    getUIClassID_test_7459();
    getUI_test_7460();
    // ... (other functions would need arguments; not provided here, but compilation is sufficient)
    return 0;
}
```