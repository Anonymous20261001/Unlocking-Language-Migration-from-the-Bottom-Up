```cpp
#include <atomic>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// Type aliases matching Java functional interfaces
using LongUnaryOperator = std::function<int64_t(int64_t)>;
using LongBinaryOperator = std::function<int64_t(int64_t, int64_t)>;

class AtomicLongArray {
public:
    explicit AtomicLongArray(int length)
        : length_(length), data_(length) {}

    // --- Plain (relaxed) operations ---
    int64_t getPlain(int i) const {
        return data_[i].load(std::memory_order_relaxed);
    }

    void setPlain(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_relaxed);
    }

    // --- Opaque (relaxed) operations ---
    int64_t getOpaque(int i) const {
        return data_[i].load(std::memory_order_relaxed);
    }

    void setOpaque(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_relaxed);
    }

    // --- Acquire operations ---
    int64_t getAcquire(int i) const {
        return data_[i].load(std::memory_order_acquire);
    }

    // --- Release operations ---
    void setRelease(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_release);
    }

    // --- Volatile (sequentially consistent) operations ---
    int64_t get(int i) const {
        return data_[i].load(std::memory_order_seq_cst);
    }

    void set(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_seq_cst);
    }

    int length() const {
        return length_;
    }

    std::string toString() const {
        std::string result = "[";
        for (int i = 0; i < length_; ++i) {
            if (i > 0) result += ", ";
            result += std::to_string(get(i));
        }
        result += "]";
        return result;
    }

    // --- CAS with different orderings ---
    bool compareAndSet(int i, int64_t expected, int64_t newValue) {
        return data_[i].compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
    }

    int64_t compareAndExchange(int i, int64_t expected, int64_t newValue) {
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
        return expected;
    }

    int64_t compareAndExchangeAcquire(int i, int64_t expected, int64_t newValue) {
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_acquire);
        return expected;
    }

    int64_t compareAndExchangeRelease(int i, int64_t expected, int64_t newValue) {
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_release);
        return expected;
    }

    // --- Weak CAS variants ---
    bool weakCompareAndSetPlain(int i, int64_t expected, int64_t newValue) {
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_relaxed);
    }

    bool weakCompareAndSet(int i, int64_t expected, int64_t newValue) {
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetAcquire(int i, int64_t expected, int64_t newValue) {
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_acquire);
    }

    bool weakCompareAndSetRelease(int i, int64_t expected, int64_t newValue) {
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_release);
    }

    // weakCompareAndSetVolatile is an alias for weakCompareAndSet
    bool weakCompareAndSetVolatile(int i, int64_t expected, int64_t newValue) {
        return weakCompareAndSet(i, expected, newValue);
    }

    // --- Read-modify-write operations (sequentially consistent) ---
    int64_t getAndSet(int i, int64_t newValue) {
        return data_[i].exchange(newValue, std::memory_order_seq_cst);
    }

    int64_t getAndAdd(int i, int64_t delta) {
        return data_[i].fetch_add(delta, std::memory_order_seq_cst);
    }

    int64_t incrementAndGet(int i) {
        return data_[i].fetch_add(1, std::memory_order_seq_cst) + 1;
    }

    int64_t getAndIncrement(int i) {
        return data_[i].fetch_add(1, std::memory_order_seq_cst);
    }

    int64_t getAndDecrement(int i) {
        return data_[i].fetch_sub(1, std::memory_order_seq_cst);
    }

    int64_t decrementAndGet(int i) {
        return data_[i].fetch_sub(1, std::memory_order_seq_cst) - 1;
    }

    int64_t addAndGet(int i, int64_t delta) {
        return data_[i].fetch_add(delta, std::memory_order_seq_cst) + delta;
    }

    // Lazy set (release semantics)
    void lazySet(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_release);
    }

    // --- Functional update methods ---
    int64_t getAndUpdate(int i, const LongUnaryOperator& function) {
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return old;
    }

    int64_t updateAndGet(int i, const LongUnaryOperator& function) {
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return function(expected); // store succeeded, function(expected) is the new value
    }

    int64_t getAndAccumulate(int i, int64_t x, const LongBinaryOperator& function) {
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected, x),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return old;
    }

    int64_t accumulateAndGet(int i, int64_t x, const LongBinaryOperator& function) {
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected, x),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return function(expected, x);
    }

private:
    int length_;
    std::vector<std::atomic<int64_t>> data_;
};

// ====================== Test functions ======================

void get_test_4851(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.get(p0);
}

void length_test_4852(int c0) {
    AtomicLongArray instance(c0);
    instance.length();
}

void toString_test_4853(int c0) {
    AtomicLongArray instance(c0);
    instance.toString();
}

void set_test_4854(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.set(p0, p1);
}

void getOpaque_test_4855(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.getOpaque(p0);
}

void setOpaque_test_4856(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.setOpaque(p0, p1);
}

void getAcquire_test_4857(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.getAcquire(p0);
}

void setRelease_test_4858(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.setRelease(p0, p1);
}

void compareAndSet_test_4859(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.compareAndSet(p0, p1, p2);
}

void compareAndExchange_test_4860(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.compareAndExchange(p0, p1, p2);
}

void compareAndExchangeAcquire_test_4861(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.compareAndExchangeAcquire(p0, p1, p2);
}

void compareAndExchangeRelease_test_4862(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.compareAndExchangeRelease(p0, p1, p2);
}

void weakCompareAndSetPlain_test_4863(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.weakCompareAndSetPlain(p0, p1, p2);
}

void weakCompareAndSet_test_4864(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.weakCompareAndSet(p0, p1, p2);
}

void weakCompareAndSetAcquire_test_4865(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.weakCompareAndSetAcquire(p0, p1, p2);
}

void weakCompareAndSetRelease_test_4866(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.weakCompareAndSetRelease(p0, p1, p2);
}

void getAndSet_test_4867(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndSet(p0, p1);
}

void getAndAdd_test_4868(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndAdd(p0, p1);
}

void incrementAndGet_test_4869(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.incrementAndGet(p0);
}

void weakCompareAndSetVolatile_test_4870(int p0, long p1, long p2, int c0) {
    AtomicLongArray instance(c0);
    instance.weakCompareAndSetVolatile(p0, p1, p2);
}

void lazySet_test_4871(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.lazySet(p0, p1);
}

void getAndIncrement_test_4872(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndIncrement(p0);
}

void getAndDecrement_test_4873(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndDecrement(p0);
}

void decrementAndGet_test_4874(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.decrementAndGet(p0);
}

void addAndGet_test_4875(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.addAndGet(p0, p1);
}

void getAndUpdate_test_4876(int p0, LongUnaryOperator p1, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndUpdate(p0, p1);
}

void updateAndGet_test_4877(int p0, LongUnaryOperator p1, int c0) {
    AtomicLongArray instance(c0);
    instance.updateAndGet(p0, p1);
}

void getAndAccumulate_test_4878(int p0, long p1, LongBinaryOperator p2, int c0) {
    AtomicLongArray instance(c0);
    instance.getAndAccumulate(p0, p1, p2);
}

void accumulateAndGet_test_4879(int p0, long p1, LongBinaryOperator p2, int c0) {
    AtomicLongArray instance(c0);
    instance.accumulateAndGet(p0, p1, p2);
}

void getPlain_test_4880(int p0, int c0) {
    AtomicLongArray instance(c0);
    instance.getPlain(p0);
}

void setPlain_test_4881(int p0, long p1, int c0) {
    AtomicLongArray instance(c0);
    instance.setPlain(p0, p1);
}
```