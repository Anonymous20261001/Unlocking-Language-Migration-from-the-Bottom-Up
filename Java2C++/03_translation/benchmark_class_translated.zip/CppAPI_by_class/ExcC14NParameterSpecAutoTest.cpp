```cpp
#include <vector>
#include <string>

class ExcC14NParameterSpec {
public:
    ExcC14NParameterSpec() : prefixList_() {}
    explicit ExcC14NParameterSpec(const std::vector<std::string>& prefixes) : prefixList_(prefixes) {}

    std::vector<std::string> getPrefixList() const {
        return prefixList_;
    }

private:
    std::vector<std::string> prefixList_;
};

void getPrefixList_test_10889() {
    ExcC14NParameterSpec instance;
    instance.getPrefixList();
}
```