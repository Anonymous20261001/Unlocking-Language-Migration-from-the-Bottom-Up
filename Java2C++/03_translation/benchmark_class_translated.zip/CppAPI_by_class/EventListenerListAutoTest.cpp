```cpp
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <utility>

// Abstract base class for event listeners
class EventListener {
public:
    virtual ~EventListener() = default;
};

// Simple class to represent a type (like java.lang.Class)
class Class {
private:
    std::string name;
public:
    explicit Class(const std::string& name) : name(name) {}
    bool operator==(const Class& other) const {
        return name == other.name;
    }
    std::string getName() const { return name; }
};

// C++ equivalent of javax.swing.event.EventListenerList
class EventListenerList {
private:
    std::vector<std::pair<Class, EventListener*>> listeners;
public:
    EventListenerList() = default;

    // Returns all listener/class pairs (like Java's getListenerList())
    std::vector<std::pair<Class, EventListener*>> getListenerList() const {
        return listeners;
    }

    // Returns all listeners of the given class type
    std::vector<EventListener*> getListeners(const Class& listenerClass) const {
        std::vector<EventListener*> result;
        for (const auto& p : listeners) {
            if (p.first == listenerClass) {
                result.push_back(p.second);
            }
        }
        return result;
    }

    // Counts listeners of a specific class
    int getListenerCount(const Class& listenerClass) const {
        int count = 0;
        for (const auto& p : listeners) {
            if (p.first == listenerClass) {
                ++count;
            }
        }
        return count;
    }

    // Total listener count
    int getListenerCount() const {
        return listeners.size();
    }

    // Adds a listener for the given class
    void add(const Class& listenerClass, EventListener* listener) {
        listeners.emplace_back(listenerClass, listener);
    }

    // Removes a specific listener for the given class (first occurrence)
    void remove(const Class& listenerClass, EventListener* listener) {
        auto it = std::find_if(listeners.begin(), listeners.end(),
            [&](const auto& p) {
                return p.first == listenerClass && p.second == listener;
            });
        if (it != listeners.end()) {
            listeners.erase(it);
        }
    }

    // String representation mimicking Java's toString()
    std::string toString() const {
        return "EventListenerList: count=" + std::to_string(listeners.size());
    }
};

// A concrete listener for testing
class MyListener : public EventListener {};

// Test functions (each corresponds to a @Test method in the Java file)
void getListenerList_test_8523() {
    EventListenerList instance;
    instance.getListenerList();
}

void getListeners_test_8524(Class p0) {
    EventListenerList instance;
    instance.getListeners(p0);
}

void getListenerCount_test_8525(Class p0) {
    EventListenerList instance;
    instance.getListenerCount(p0);
}

void getListenerCount_test_8526() {
    EventListenerList instance;
    instance.getListenerCount();
}

void remove_test_8527(Class p0, EventListener* p1) {
    EventListenerList instance;
    instance.remove(p0, p1);
}

void toString_test_8528() {
    EventListenerList instance