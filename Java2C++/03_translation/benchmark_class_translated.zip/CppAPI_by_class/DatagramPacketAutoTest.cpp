```cpp
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Forward declarations
// ---------------------------------------------------------------------------
class InetAddress;
class SocketAddress;
class InetSocketAddress;
class DatagramPacket;

// ---------------------------------------------------------------------------
// InetAddress – minimal version storing an IP address as a string
// ---------------------------------------------------------------------------
class InetAddress {
public:
    InetAddress() = default;
    explicit InetAddress(const std::string& addr) : address_(addr) {}
    InetAddress(const InetAddress&) = default;
    InetAddress& operator=(const InetAddress&) = default;
    
    const std::string& getHostAddress() const { return address_; }
    bool operator==(const InetAddress& other) const { return address_ == other.address_; }
    bool operator!=(const InetAddress& other) const { return !(*this == other); }
    
private:
    std::string address_;
};

// ---------------------------------------------------------------------------
// SocketAddress – abstract base
// ---------------------------------------------------------------------------
class SocketAddress {
public:
    virtual ~SocketAddress() = default;
};

// ---------------------------------------------------------------------------
// InetSocketAddress – concrete subclass holding an InetAddress and port
// ---------------------------------------------------------------------------
class InetSocketAddress : public SocketAddress {
public:
    InetSocketAddress(const InetAddress& addr, int port)
        : address_(addr), port_(port) {}
    
    InetSocketAddress() = default;
    InetSocketAddress(const InetSocketAddress&) = default;
    InetSocketAddress& operator=(const InetSocketAddress&) = default;
    
    const InetAddress& getAddress() const { return address_; }
    int getPort() const { return port_; }
    
private:
    InetAddress address_;
    int port_ = 0;
};

// ---------------------------------------------------------------------------
// DatagramPacket – mirrors java.net.DatagramPacket
// ---------------------------------------------------------------------------
class DatagramPacket {
public:
    // Constructor: byte[] buf, int length
    DatagramPacket(const std::vector<uint8_t>& buf, int length)
        : buffer_(buf), offset_(0), length_(length), port_(0)
    {
        if (length < 0 || length > static_cast<int>(buffer_.size()))
            throw std::invalid_argument("DatagramPacket: invalid length");
    }

    // -----------------------------------------------------------------------
    // Mutators
    // -----------------------------------------------------------------------
    void setAddress(const InetAddress& addr) {
        address_ = addr;
    }

    void setPort(int port) {
        port_ = port;
    }

    void setSocketAddress(const SocketAddress& addr) {
        // Expect an InetSocketAddress (the only concrete type we have)
        const InetSocketAddress* isa = dynamic_cast<const InetSocketAddress*>(&addr);
        if (!isa)
            throw std::invalid_argument("setSocketAddress: not an InetSocketAddress");
        address_ = isa->getAddress();
        port_ = isa->getPort();
    }

    // setData(byte[] buf, int offset, int length)
    void setData(const std::vector<uint8_t>& buf, int offset, int length) {
        if (offset < 0 || length < 0 || offset + length > static_cast<int>(buf.size()))
            throw std::invalid_argument("setData: invalid offset/length");
        buffer_ = buf;
        offset_ = offset;
        length_ = length;
    }

    // setData(byte[] buf)
    void setData(const std::vector<uint8_t>& buf) {
        buffer_ = buf;
        offset_ = 0;
        length_ = static_cast<int>(buf.size());
    }

    void setLength(int len) {
        if (len < 0 || len > static_cast<int>(buffer_.size()) - offset_)
            throw std::invalid_argument("setLength: exceeds buffer capacity");
        length_ = len;
    }

    // -----------------------------------------------------------------------
    // Accessors
    // -----------------------------------------------------------------------
    std::vector<uint8_t>& getData() {
        return buffer_;
    }

    const std::vector<uint8_t>& getData() const {
        return buffer_;
    }

    int getOffset() const {
        return offset_;
    }

    int getLength() const {
        return length_;
    }

    InetAddress getAddress() const {
        return address_;
    }

    int getPort() const {
        return port_;
    }

    // Returns a reference to an internal InetSocketAddress object.
    // In Java getSocketAddress() returns a SocketAddress (often InetSocketAddress).
    // We return a const reference to a stored InetSocketAddress.
    const InetSocketAddress& getSocketAddress() const {
        // Lazily create the socket address if needed
        if (!socketAddress_) {
            socketAddress_ = std::make_shared<InetSocketAddress>(address_, port_);
        } else {
            // Update if something changed
            *socketAddress_ = InetSocketAddress(address_, port_);
        }
        return *socketAddress_;
    }

private:
    std::vector<uint8_t> buffer_;
    int offset_ = 0;
    int length_ = 0;
    InetAddress address_;
    int port_ = 0;
    mutable std::shared_ptr<InetSocketAddress> socketAddress_;
};

// ===========================================================================
// Test functions (one per @Test method)
// ===========================================================================

void setAddress_test_2545(InetAddress p0, std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setAddress(p0);
}

void setPort_test_2546(int p0, std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setPort(p0);
}

void setSocketAddress_test_2547(SocketAddress& p0, std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setSocketAddress(p0);
}

void getSocketAddress_test_2548(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getSocketAddress();
}

void setData_test_2549(std::vector<uint8_t> p0, int p1, int p2,
                       std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setData(p0, p1, p2);
}

void setData_test_2550(std::vector<uint8_t> p0, std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setData(p0);
}

void getLength_test_2551(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getLength();
}

void setLength_test_2552(int p0, std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.setLength(p0);
}

void getAddress_test_2553(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getAddress();
}

void getPort_test_2554(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getPort();
}

void getOffset_test_2555(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getOffset();
}

void getData_test_2556(std::vector<uint8_t> c0, int c1) {
    DatagramPacket instance(c0, c1);
    instance.getData();
}
```