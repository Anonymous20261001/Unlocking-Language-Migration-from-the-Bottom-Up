```cpp
#include <cstdint>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <functional>
#include <string>
#include <cstring>

// Minimal Object base class for signature compatibility (if needed)
// Not truly used, but present to mimic Java's Object parameter.
class Object {
public:
    virtual ~Object() = default;
};

class CommandAPDU : public Object {
private:
    std::vector<uint8_t> apduBytes;
    int cla, ins, p1, p2;
    int nc; // number of data bytes (Nc)
    int ne; // expected length (Ne), 0 if not present
    std::vector<uint8_t> dataField; // actual data bytes

public:
    // Constructor from raw APDU bytes (short APDU only)
    explicit CommandAPDU(const std::vector<uint8_t>& bytes) {
        apduBytes = bytes;
        if (bytes.size() < 4) return; // invalid, but keep

        cla = bytes[0];
        ins = bytes[1];
        p1  = bytes[2];
        p2  = bytes[3];

        size_t len = bytes.size();
        if (len == 4) {
            // Case 1: no data, no Le
            nc = 0;
            ne = 0;
            dataField.clear();
        } else if (len == 5) {
            // Case 2S: header + Le
            nc = 0;
            ne = bytes[4];
            if (ne == 0) ne = 256; // Le=0 means 256
            dataField.clear();
        } else {
            // Cases 3S or 4S: header + Lc + data [+ Le]
            int lc = bytes[4]; // Lc field (short, 0-255)
            nc = lc;
            dataField.assign(bytes.begin() + 5, bytes.begin() + 5 + nc);
            if (len == 5 + nc + 1) {
                // Le present
                ne = bytes[5 + nc];
                if (ne == 0) ne = 256;
            } else {
                // No Le
                ne = 0;
            }
        }
    }

    // Copy
    std::vector<uint8_t> getBytes() const {
        return apduBytes;
    }

    std::vector<uint8_t> getData() const {
        return dataField;
    }

    int getCLA() const { return cla; }
    int getINS() const { return ins; }
    int getP1() const  { return p1;  }
    int getP2() const  { return p2;  }
    int getNc() const  { return nc;  }
    int getNe() const  { return ne;  }

    // Equality: compare raw bytes
    bool equals(const Object& other) const {
        // In Java, equals only returns true if the other is a CommandAPDU.
        const auto* otherApdu = dynamic_cast<const CommandAPDU*>(&other);
        if (!otherApdu) return false;
        return apduBytes == otherApdu->apduBytes;
    }

    // Java hashCode based on byte array hash
    size_t hashCode() const {
        size_t hash = 0;
        for (auto b : apduBytes) {
            hash = 31 * hash + static_cast<size_t>(b);
        }
        return hash;
    }

    // toString: "CommandAPDU: " + hex string (uppercase, no spaces)
    std::string toString() const {
        std::ostringstream oss;
        oss << "CommandAPDU: ";
        oss << std::hex << std::uppercase << std::setfill('0');
        for (size_t i = 0; i < apduBytes.size(); ++i) {
            oss << std::setw(2) << static_cast<int>(apduBytes[i]);
        }
        return oss.str();
    }
};

// Test function signatures are translated into C++
void equals_test_6455(const CommandAPDU& p0, const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.equals(p0);
}

void toString_test_6456(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.toString();
}

void hashCode_test_6457(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.hashCode();
}

void getBytes_test_6458(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getBytes();
}

void getData_test_6459(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getData();
}

void getCLA_test_6460(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getCLA();
}

void getINS_test_6461(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getINS();
}

void getP1_test_6462(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getP1();
}

void getP2_test_6463(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getP2();
}

void getNc_test_6464(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getNc();
}

void getNe_test_6465(const std::vector<uint8_t>& c0) {
    CommandAPDU instance(c0);
    instance.getNe();
}
```