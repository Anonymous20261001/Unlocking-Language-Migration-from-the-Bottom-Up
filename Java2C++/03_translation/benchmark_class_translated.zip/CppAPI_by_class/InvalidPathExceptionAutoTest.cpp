```cpp
#include <string>
#include <stdexcept>

// C++ equivalent of java.nio.file.InvalidPathException
class InvalidPathException : public std::runtime_error {
private:
    std::string input;
    std::string reason;
    int index;

public:
    // Constructor without index (default index = -1)
    InvalidPathException(const std::string& input, const std::string& reason)
        : std::runtime_error(reason),
          input(input),
          reason(reason),
          index(-1) {}

    // Constructor with index
    InvalidPathException(const std::string& input, const std::string& reason, int index)
        : std::runtime_error(index >= 0 ? (reason + " at index " + std::to_string(index)) : reason),
          input(input),
          reason(reason),
          index(index) {}

    // Equivalent to Java's getMessage()
    std::string getMessage() const {
        return std::runtime_error::what();
    }

    // Equivalent to Java's getIndex()
    int getIndex() const {
        return index;
    }

    // Equivalent to Java's getReason()
    std::string getReason() const {
        return reason;
    }

    // Equivalent to Java's getInput()
    std::string getInput() const {
        return input;
    }
};

// Translated test functions (same names and signatures as Java @Test methods)
void getMessage_test_2652(const std::string& c0, const std::string& c1) {
    InvalidPathException instance(c0, c1);
    instance.getMessage();
}

void getIndex_test_2653(const std::string& c0, const std::string& c1) {
    InvalidPathException instance(c0, c1);
    instance.getIndex();
}

void getReason_test_2654(const std::string& c0, const std::string& c1) {
    InvalidPathException instance(c0, c1);
    instance.getReason();
}

void getInput_test_2655(const std::string& c0, const std::string& c1) {
    InvalidPathException instance(c0, c1);
    instance.getInput();
}
```