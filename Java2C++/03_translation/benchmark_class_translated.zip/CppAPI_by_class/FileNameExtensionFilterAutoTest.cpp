```cpp
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>
#include <sstream>

// -----------------------------------------------------------------------------
// Simple File class mimicking java.io.File for the purpose of extension filter
// -----------------------------------------------------------------------------
class File {
public:
    explicit File(const std::string& path) : path_(path) {}

    std::string getName() const {
        // Extract the last component after the last '/' or '\\'
        size_t pos = path_.find_last_of("/\\");
        if (pos == std::string::npos) {
            return path_;
        }
        return path_.substr(pos + 1);
    }

    const std::string& getPath() const { return path_; }

private:
    std::string path_;
};

// -----------------------------------------------------------------------------
// FileNameExtensionFilter mimicking javax.swing.filechooser.FileNameExtensionFilter
// -----------------------------------------------------------------------------
class FileNameExtensionFilter {
public:
    FileNameExtensionFilter(const std::string& description,
                            const std::vector<std::string>& extensions)
        : description_(description), extensions_(extensions) {
        // Convert extensions to lower case for case-insensitive comparisons
        for (auto& ext : extensions_) {
            std::transform(ext.begin(), ext.end(), ext.begin(),
                           [](unsigned char c){ return std::tolower(c); });
        }
    }

    std::string getDescription() const {
        return description_;
    }

    std::vector<std::string> getExtensions() const {
        return extensions_;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << description_ << " (";
        for (size_t i = 0; i < extensions_.size(); ++i) {
            if (i > 0) oss << ", ";
            oss << extensions_[i];
        }
        oss << ")";
        return oss.str();
    }

    bool accept(const File& file) const {
        std::string name = file.getName();
        // Convert file name to lower case for case-insensitive comparison
        std::string lowerName = name;
        std::transform(lowerName.begin(), lowerName.end(), lowerName.begin(),
                       [](unsigned char c){ return std::tolower(c); });

        for (const auto& ext : extensions_) {
            // If the file name ends with "." + extension, accept
            if (lowerName.size() >= ext.size() + 1 &&
                lowerName[lowerName.size() - ext.size() - 1] == '.' &&
                lowerName.substr(lowerName.size() - ext.size()) == ext) {
                return true;
            }
        }
        return false;
    }

private:
    std::string description_;
    std::vector<std::string> extensions_;
};

// -----------------------------------------------------------------------------
// Test functions – exact names and parameter types as in Java test file
// -----------------------------------------------------------------------------

void getDescription_test_8576(const std::string& c0,
                              const std::vector<std::string>& c1) {
    FileNameExtensionFilter instance(c0, c1);
    instance.getDescription();
}

void getExtensions_test_8577(const std::string& c0,
                             const std::vector<std::string>& c1) {
    FileNameExtensionFilter instance(c0, c1);
    instance.getExtensions();
}

void toString_test_8578(const std::string& c0,
                        const std::vector<std::string>& c1) {
    FileNameExtensionFilter instance(c0, c1);
    instance.toString();
}

void accept_test_8579(const File& p0,
                      const std::string& c0,
                      const std::vector<std::string>& c1) {
    FileNameExtensionFilter instance(c0, c1);
    instance.accept(p0);
}
```