```cpp
#include <cstddef> // for NULL

// Minimal Graphics class, does nothing
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

// Minimal Dimension class
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Minimal JComponent class (base for Swing components)
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// BasicPopupMenuSeparatorUI mimicking the Swing UI delegate
class BasicPopupMenuSeparatorUI {
public:
    BasicPopupMenuSeparatorUI() {}

    // Static factory method – returns a new instance
    static BasicPopupMenuSeparatorUI* createUI(JComponent* c) {
        // In real Swing this returns ComponentUI, but we ignore the actual component
        return new BasicPopupMenuSeparatorUI();
    }

    // Paint method – stub, takes Graphics pointer and JComponent pointer
    void paint(Graphics* g, JComponent* c) {
        // No painting implementation needed for the test
    }

    // Returns a dummy preferred size
    Dimension getPreferredSize(JComponent* c) {
        return Dimension(10, 10); // arbitrary default
    }
};

// Test functions matching the Java @Test methods

void createUI_test_8855(JComponent* p0) {
    BasicPopupMenuSeparatorUI instance;
    BasicPopupMenuSeparatorUI::createUI(p0); // static call, return ignored
}

void paint_test_8856(Graphics* p0, JComponent* p1) {
    BasicPopupMenuSeparatorUI instance;
    instance.paint(p0, p1);
}

void getPreferredSize_test_8857(JComponent* p0) {
    BasicPopupMenuSeparatorUI instance;
    instance.getPreferredSize(p0);
}
```