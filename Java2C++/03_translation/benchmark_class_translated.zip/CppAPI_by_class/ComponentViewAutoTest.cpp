```cpp
#include <vector>
#include <cstddef>

// -----------------------------------------------------------------------------
// Minimal equivalents of Java types used in the tests
// -----------------------------------------------------------------------------

// Forward declarations
class Graphics {};
class Shape {};
class View;
class Element;
class ComponentView;

// Position::Bias – an enumeration with two values
struct Position {
    enum class Bias {
        Forward,
        Backward
    };
};

// Element – a minimal placeholder
class Element {
public:
    Element() = default;
    // No data needed for the tests
};

// View – base class for views (simplified)
class View {
public:
    View() = default;
    virtual ~View() = default;

    // Dummy methods to satisfy the test (not all needed)
    virtual void setParent(View* parent) { parent_ = parent; }
    virtual View* getParent() const { return parent_; }
private:
    View* parent_ = nullptr;
};

// Component – dummy for getComponent()
class Component {
public:
    Component() = default;
};

// ComponentView – the main tested class
class ComponentView : public View {
public:
    explicit ComponentView(const Element& elem) : element_(elem) {}

    // viewToModel(float x, float y, Shape a, Position::Bias biasReturn[])
    int viewToModel(float x, float y, Shape& a, Position::Bias* biasReturn) {
        // Simulate filling biasReturn (ignore actual logic)
        if (biasReturn) {
            biasReturn[0] = Position::Bias::Forward;
        }
        return 0; // dummy
    }

    float getPreferredSpan(int axis) {
        return 10.0f; // dummy
    }

    float getMinimumSpan(int axis) {
        return 5.0f; // dummy
    }

    float getMaximumSpan(int axis) {
        return 20.0f; // dummy
    }

    void paint(Graphics& g, Shape& allocation) {
        // No-op
    }

    float getAlignment(int axis) {
        return 0.5f; // dummy
    }

    // Returns a reference to a static component (simplified)
    Component& getComponent() {
        static Component comp;
        return comp;
    }

    void setParent(View* p) override {
        View::setParent(p);
    }

private:
    const Element& element_; // reference to test‑provided element
};

// -----------------------------------------------------------------------------
// Test functions (one per Java @Test)
// -----------------------------------------------------------------------------

void viewToModel_test_10148(float p0, float p1, Shape& p2, Position::Bias* p3, Element& c0) {
    ComponentView instance(c0);
    instance.viewToModel(p0, p1, p2, p3);
}

void getPreferredSpan_test_10149(int p0, Element& c0) {
    ComponentView instance(c0);
    instance.getPreferredSpan(p0);
}

void getMinimumSpan_test_10150(int p0, Element& c0) {
    ComponentView instance(c0);
    instance.getMinimumSpan(p0);
}

void getMaximumSpan_test_10151(int p0, Element& c0) {
    ComponentView instance(c0);
    instance.getMaximumSpan(p0);
}

void paint_test_10152(Graphics& p0, Shape& p1, Element& c0) {
    ComponentView instance(c0);
    instance.paint(p0, p1);
}

void getAlignment_test_10153(int p0, Element& c0) {
    ComponentView instance(c0);
    instance.getAlignment(p0);
}

void getComponent_test_10154(Element& c0) {
    ComponentView instance(c0);
    instance.getComponent();
}

void setParent_test_10155(View& p0, Element& c0) {
    ComponentView instance(c0);
    instance.setParent(&p0);
}
```