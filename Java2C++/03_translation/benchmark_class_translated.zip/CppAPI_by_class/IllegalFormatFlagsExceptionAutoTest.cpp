```cpp
#include <string>
#include <stdexcept>

// Equivalent to java.util.IllegalFormatFlagsException
class IllegalFormatFlagsException {
private:
    std::string flags;
    std::string message;
public:
    explicit IllegalFormatFlagsException(const std::string& f)
        : flags(f), message("Flags = " + f) {}

    std::string getMessage() const {
        return message;
    }

    std::string getFlags() const {
        return flags;
    }
};

// C++ test functions corresponding to the Java @Test methods

void getMessage_test_3569(const std::string& c0) {
    IllegalFormatFlagsException instance(c0);
    instance.getMessage();  // no assertion, just call the method
}

void getFlags_test_3570(const std::string& c0) {
    IllegalFormatFlagsException instance(c0);
    instance.getFlags();    // no assertion, just call the method
}
```