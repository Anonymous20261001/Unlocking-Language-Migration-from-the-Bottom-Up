```cpp
#include <functional>
#include <string>
#include <mutex>
#include <atomic>
#include <exception>
#include <stdexcept>
#include <sstream>

class FutureTask {
public:
    using Callable = std::function<int()>;

    static const int NEW = 0;
    static const int COMPLETING = 1;
    static const int NORMAL = 2;
    static const int EXCEPTIONAL = 3;
    static const int CANCELLED = 4;
    static const int INTERRUPTING = 5;
    static const int INTERRUPTED = 6;

    FutureTask(Callable callable) : callable_(std::move(callable)), state_(NEW) {}

    void run() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (state_ != NEW)
            return;
        state_ = COMPLETING;
        try {
            result_ = callable_();
            state_ = NORMAL;
        } catch (...) {
            exception_ = std::current_exception();
            state_ = EXCEPTIONAL;
        }
    }

    std::string toString() {
        std::ostringstream oss;
        oss << "FutureTask@" << this;
        return oss.str();
    }

    int state() const {
        return state_.load();
    }

    bool isDone() const {
        return state_ != NEW;
    }

    bool cancel(bool mayInterruptIfRunning) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (state_ != NEW)
            return false;
        state_ = CANCELLED;
        return true;
    }

    bool isCancelled() const {
        return state_ == CANCELLED;
    }

    int resultNow() {
        if (state_ != NORMAL)
            throw std::logic_error("Not completed normally");
        return result_;
    }

    std::exception_ptr exceptionNow() {
        if (state_ != EXCEPTIONAL)
            throw std::logic_error("No exception");
        return exception_;
    }

private:
    Callable callable_;
    std::atomic<int> state_{NEW};
    int result_{0};
    std::exception_ptr exception_;
    mutable std::mutex mutex_;
};

// Test functions
void run_test_4507(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.run();
}

void toString_test_4508(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.toString();
}

void state_test_4509(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.state();
}

void isDone_test_4510(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.isDone();
}

void cancel_test_4511(bool p0, std::function<int()> c0) {
    FutureTask instance(c0);
    instance.cancel(p0);
}

void isCancelled_test_4512(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.isCancelled();
}

void resultNow_test_4513(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.resultNow();
}

void exceptionNow_test_4514(std::function<int()> c0) {
    FutureTask instance(c0);
    instance.exceptionNow();
}
```