```cpp
#include <cstddef>

class HMACParameterSpec {
private:
    int outputLength;
public:
    HMACParameterSpec(int outputLength) : outputLength(outputLength) {}
    int getOutputLength() const { return outputLength; }
};

void getOutputLength_test_10890(int c0) {
    HMACParameterSpec instance(c0);
    instance.getOutputLength();
}
```