```cpp
#include <cstddef>

// Minimal stubs for Java Swing types used in the test
struct Dimension {
    int width = 0;
    int height = 0;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

// Base class for UI delegates (ComponentUI)
class ComponentUI {
public:
    virtual void installUI(JComponent* c) {}
    virtual void uninstallUI(JComponent* c) {}
    virtual Dimension getMaximumSize(JComponent* c) { return Dimension{}; }
    virtual Dimension getMinimumSize(JComponent* c) { return Dimension{}; }
    virtual Dimension getPreferredSize(JComponent* c) { return Dimension{}; }
    virtual void paint(Graphics* g, JComponent* c) {}
    virtual ~ComponentUI() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicDesktopPaneUI
class BasicDesktopPaneUI : public ComponentUI {
public:
    void installUI(JComponent* c) override {}
    void uninstallUI(JComponent* c) override {}
    Dimension getMaximumSize(JComponent* c) override { return Dimension{}; }
    Dimension getMinimumSize(JComponent* c) override { return Dimension{}; }
    Dimension getPreferredSize(JComponent* c) override { return Dimension{}; }
    void paint(Graphics* g, JComponent* c) override {}

    // Static factory method matching Java's createUI
    static BasicDesktopPaneUI* createUI(JComponent* c) {
        return new BasicDesktopPaneUI();
    }
};

// ------------------------------------------------------------
// Translated test functions (one for each @Test)
// ------------------------------------------------------------

void installUI_test_8704(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();
    instance.installUI(p0);
}

void uninstallUI_test_8705(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();
    instance.uninstallUI(p0);
}

void createUI_test_8706(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();       // unused, just like Java
    BasicDesktopPaneUI* result = BasicDesktopPaneUI::createUI(p0);
    delete result;                              // avoid memory leak
}

void getMaximumSize_test_8707(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();
    instance.getMaximumSize(p0);
}

void paint_test_8708(Graphics* p0, JComponent* p1) {
    auto instance = BasicDesktopPaneUI();
    instance.paint(p0, p1);
}

void getPreferredSize_test_8709(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8710(JComponent* p0) {
    auto instance = BasicDesktopPaneUI();
    instance.getMinimumSize(p0);
}
```