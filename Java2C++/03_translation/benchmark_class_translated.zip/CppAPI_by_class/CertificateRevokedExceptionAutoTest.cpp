```cpp
#include <string>
#include <map>
#include <ctime>
#include <exception>
#include <iostream>
#include <cassert>

// Simple Date class (wrapping time_t)
class Date {
public:
    Date() : time_(0) {}
    explicit Date(long millis) : time_(millis / 1000) {}
    long getTime() const { return static_cast<long>(time_ * 1000); }
private:
    std::time_t time_;
};

// CRLReason enum (simplified, partial)
enum class CRLReason {
    UNSPECIFIED,
    KEY_COMPROMISE,
    CA_COMPROMISE,
    AFFILIATION_CHANGED,
    SUPERSEDED,
    CESSATION_OF_OPERATION,
    CERTIFICATE_HOLD,
    REMOVE_FROM_CRL,
    PRIVILEGE_WITHDRAWN,
    AA_COMPROMISE
};

// X500Principal (simple string wrapper)
class X500Principal {
public:
    explicit X500Principal(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

// Placeholder for Extension (not fully implemented)
class Extension {
public:
    explicit Extension(const std::string& id) : id_(id) {}
    const std::string& getId() const { return id_; }
private:
    std::string id_;
};

// CertificateRevokedException (simplified)
class CertificateRevokedException : public std::exception {
public:
    CertificateRevokedException(const Date& revocationDate,
                                CRLReason reason,
                                const X500Principal& authority,
                                const std::map<std::string, std::string>& extensions)
        : revocationDate_(revocationDate),
          reason_(reason),
          authority_(authority),
          extensions_() {
        // Convert simple string map to Extension map (for demonstration)
        for (const auto& kv : extensions) {
            extensions_[kv.first] = Extension(kv.second);
        }
        message_ = "Certificate revoked: " + authority.getName();
    }

    const std::map<std::string, Extension>& getExtensions() const {
        return extensions_;
    }

    Date getRevocationDate() const {
        return revocationDate_;
    }

    CRLReason getRevocationReason() const {
        return reason_;
    }

    X500Principal getAuthorityName() const {
        return authority_;
    }

    // getInvalidityDate returns a Date; in Java it returns Date or null.
    // We'll return a default Date if no invalidity date is stored.
    Date getInvalidityDate() const {
        return invalidityDate_; // not set in constructor, default Date(0)
    }

    const char* what() const noexcept override {
        return message_.c_str();
    }

    std::string getMessage() const {
        return message_;
    }

private:
    Date revocationDate_;
    CRLReason reason_;
    X500Principal authority_;
    std::map<std::string, Extension> extensions_;
    Date invalidityDate_; // not set
    std::string message_;
};

// ---------- Test functions ----------

void getExtensions_test_2764(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getExtensions();
}

void getRevocationDate_test_2765(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getRevocationDate();
}

void getRevocationReason_test_2766(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getRevocationReason();
}

void getAuthorityName_test_2767(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getAuthorityName();
}

void getInvalidityDate_test_2768(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getInvalidityDate();
}

void getMessage_test_2769(const Date& c0, CRLReason c1, const X500Principal& c2, const std::map<std::string, std::string>& c3) {
    CertificateRevokedException instance(c0, c1, c2, c3);
    instance.getMessage();
}

// Example usage (if compiled as standalone)
int main() {
    // Minimal test to ensure compilation and basic functionality
    Date d(1234567890L);
    CRLReason r = CRLReason::KEY_COMPROMISE;
    X500Principal p("CN=Test");
    std::map<std::string, std::string> ext = {{"1.2.3.4", "value"}};

    getExtensions_test_2764(d, r, p, ext);
    getRevocationDate_test_2765(d, r, p, ext);
    getRevocationReason_test_2766(d, r, p, ext);
    getAuthorityName_test_2767(d, r, p, ext);
    getInvalidityDate_test_2768(d, r, p, ext);
    getMessage_test_2769(d, r, p, ext);

    std::cout << "All tests passed (compilation and basic calls)." << std::endl;
    return 0;
}
```