```cpp
#include <string>
#include <vector>
#include <iostream>

// ------------------------------------------------------------
// Minimal stubs for Java AWT-like types
// ------------------------------------------------------------
struct Object {};
struct Rectangle {
    int x, y, width, height;
    Rectangle(int x = 0, int y = 0, int w = 0, int h = 0) : x(x), y(y), width(w), height(h) {}
};
struct ImageObserver {};
struct Raster {
    virtual ~Raster() = default;
};
struct WritableRaster : public Raster {};
struct TileObserver {
    virtual ~TileObserver() = default;
    virtual void tileUpdate(Object* img, int tileX, int tileY, bool writable) = 0;
};
struct ColorModel {};
struct Graphics {};
struct SampleModel {};
struct ImageProducer {};
struct Point { int x, y; };

// ------------------------------------------------------------
// BufferedImage class (stub implementation)
// ------------------------------------------------------------
class BufferedImage {
private:
    int width;
    int height;
    int type;
    std::vector<int> pixels; // not used functionally

public:
    BufferedImage(int width, int height, int type)
        : width(width), height(height), type(type) {
        pixels.resize(width * height, 0);
    }

    // ---- API methods ----
    BufferedImage* getSubimage(int x, int y, int w, int h) {
        static BufferedImage dummy(1, 1, 1);
        return &dummy;
    }

    std::vector<ImageProducer*> getSources() {
        return {};
    }

    std::vector<std::string> getPropertyNames() {
        return {};
    }

    int getNumXTiles() { return 0; }
    int getNumYTiles() { return 0; }
    int getMinTileX() { return 0; }
    int getMinTileY() { return 0; }
    int getTileWidth() { return width; }
    int getTileHeight() { return height; }
    int getTileGridXOffset() { return 0; }
    int getTileGridYOffset() { return 0; }

    Raster* getTile(int tileX, int tileY) {
        static Raster dummy;
        return &dummy;
    }

    WritableRaster* copyData(WritableRaster* outRaster) {
        static WritableRaster dummy;
        return &dummy;
    }

    void addTileObserver(TileObserver* observer) {}
    void removeTileObserver(TileObserver* observer) {}

    bool isTileWritable(int tileX, int tileY) { return false; }

    std::vector<Point> getWritableTileIndices() { return {}; }

    bool hasTileWriters() { return false; }

    WritableRaster* getWritableTile(int tileX, int tileY) {
        static WritableRaster dummy;
        return &dummy;
    }

    void releaseWritableTile(int tileX, int tileY) {}

    bool isAlphaPremultiplied() { return false; }
    void coerceData(bool isAlphaPremultiplied) {}

    Raster* getAlphaRaster() {
        static Raster dummy;
        return &dummy;
    }

    void setRGB(int x, int y, int rgb) {}
    void setRGB(int startX, int startY, int w, int h, int* rgbArray, int offset, int scansize) {}

    int getWidth() { return width; }
    int getWidth(ImageObserver* observer) { return width; }
    int getHeight() { return height; }
    int getHeight(ImageObserver* observer) { return height; }

    ColorModel* getColorModel() {
        static ColorModel dummy;
        return &dummy;
    }

    Graphics* getGraphics() {
        static Graphics dummy;
        return &dummy;
    }

    ImageProducer* getSource() {
        static ImageProducer dummy;
        return &dummy;
    }

    int getRGB(int x, int y) { return 0; }
    void getRGB(int startX, int startY, int w, int h, int* rgbArray, int offset, int scansize) {}

    int getTransparency() { return 1; } // OPAQUE

    int getMinX() { return 0; }
    int getMinY() { return 0; }

    Graphics* createGraphics() {
        static Graphics dummy;
        return &dummy;
    }

    WritableRaster* getRaster() {
        static WritableRaster dummy;
        return &dummy;
    }

    SampleModel* getSampleModel() {
        static SampleModel dummy;
        return &dummy;
    }

    void setData(Raster* r) {}

    Object* getProperty(const std::string& name, ImageObserver* observer) {
        return nullptr;
    }

    Object* getProperty(const std::string& name) {
        return nullptr;
    }

    std::string toString() { return "BufferedImage"; }

    int getType() { return type; }

    Raster* getData() {
        static Raster dummy;
        return &dummy;
    }

    Raster* getData(Rectangle* rect) {
        static Raster dummy;
        return &dummy;
    }
};

// ------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ------------------------------------------------------------
void getSubimage_test_1048(int p0, int p1, int p2, int p3, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getSubimage(p0, p1, p2, p3);
}

void getSources_test_1049(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getSources();
}

void getPropertyNames_test_1050(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getPropertyNames();
}

void getNumXTiles_test_1051(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getNumXTiles();
}

void getNumYTiles_test_1052(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getNumYTiles();
}

void getMinTileX_test_1053(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getMinTileX();
}

void getMinTileY_test_1054(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getMinTileY();
}

void getTileWidth_test_1055(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTileWidth();
}

void getTileHeight_test_1056(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTileHeight();
}

void getTileGridXOffset_test_1057(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTileGridXOffset();
}

void getTileGridYOffset_test_1058(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTileGridYOffset();
}

void getTile_test_1059(int p0, int p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTile(p0, p1);
}

void copyData_test_1060(WritableRaster* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.copyData(p0);
}

void addTileObserver_test_1061(TileObserver* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.addTileObserver(p0);
}

void removeTileObserver_test_1062(TileObserver* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.removeTileObserver(p0);
}

void isTileWritable_test_1063(int p0, int p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.isTileWritable(p0, p1);
}

void getWritableTileIndices_test_1064(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getWritableTileIndices();
}

void hasTileWriters_test_1065(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.hasTileWriters();
}

void getWritableTile_test_1066(int p0, int p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getWritableTile(p0, p1);
}

void releaseWritableTile_test_1067(int p0, int p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.releaseWritableTile(p0, p1);
}

void isAlphaPremultiplied_test_1068(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.isAlphaPremultiplied();
}

void coerceData_test_1069(bool p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.coerceData(p0);
}

void getAlphaRaster_test_1070(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getAlphaRaster();
}

void setRGB_test_1071(int p0, int p1, int p2, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.setRGB(p0, p1, p2);
}

void setRGB_test_1072(int p0, int p1, int p2, int p3, int* p4, int p5, int p6, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.setRGB(p0, p1, p2, p3, p4, p5, p6);
}

void getWidth_test_1073(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getWidth();
}

void getWidth_test_1074(ImageObserver* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getWidth(p0);
}

void getHeight_test_1075(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getHeight();
}

void getHeight_test_1076(ImageObserver* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getHeight(p0);
}

void getColorModel_test_1077(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getColorModel();
}

void getGraphics_test_1078(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getGraphics();
}

void getSource_test_1079(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getSource();
}

void getRGB_test_1080(int p0, int p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getRGB(p0, p1);
}

void getRGB_test_1081(int p0, int p1, int p2, int p3, int* p4, int p5, int p6, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getRGB(p0, p1, p2, p3, p4, p5, p6);
}

void getTransparency_test_1082(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getTransparency();
}

void getMinX_test_1083(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getMinX();
}

void getMinY_test_1084(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getMinY();
}

void createGraphics_test_1085(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.createGraphics();
}

void getRaster_test_1086(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getRaster();
}

void getSampleModel_test_1087(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getSampleModel();
}

void setData_test_1088(Raster* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.setData(p0);
}

void getProperty_test_1089(const std::string& p0, ImageObserver* p1, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getProperty(p0, p1);
}

void getProperty_test_1090(const std::string& p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getProperty(p0);
}

void toString_test_1091(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.toString();
}

void getType_test_1092(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getType();
}

void getData_test_1093(int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getData();
}

void getData_test_1094(Rectangle* p0, int c0, int c1, int c2) {
    BufferedImage instance(c0, c1, c2);
    instance.getData(p0);
}
```