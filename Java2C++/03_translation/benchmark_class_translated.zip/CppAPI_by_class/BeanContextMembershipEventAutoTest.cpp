```cpp
#include <vector>
#include <cstddef>

// Minimal Object base class
class Object {
public:
    virtual ~Object() {}
};

// Simple collection of Object pointers, mimicking java.util.Collection
class Collection {
private:
    std::vector<Object*> elements;
public:
    Collection() = default;
    explicit Collection(const std::vector<Object*>& elems) : elements(elems) {}

    int size() const {
        return static_cast<int>(elements.size());
    }

    std::vector<Object*> toArray() const {
        return elements;
    }

    // Minimal forward iterator
    class Iterator {
        std::vector<Object*>::const_iterator it;
        std::vector<Object*>::const_iterator end;
    public:
        Iterator(std::vector<Object*>::const_iterator begin,
                 std::vector<Object*>::const_iterator end)
            : it(begin), end(end) {}
        bool hasNext() const { return it != end; }
        Object* next() { return *it++; }
    };

    Iterator iterator() const {
        return Iterator(elements.begin(), elements.end());
    }

    bool contains(Object* obj) const {
        for (auto p : elements) {
            if (p == obj) return true;
        }
        return false;
    }
};

// Minimal BeanContext (source for the event)
class BeanContext {
public:
    // Could hold additional state if needed
};

// Mimics java.beans.beancontext.BeanContextMembershipEvent
class BeanContextMembershipEvent {
private:
    BeanContext* source;
    Collection* children;
public:
    BeanContextMembershipEvent(BeanContext* bc, Collection* c)
        : source(bc), children(c) {}

    BeanContextMembershipEvent(BeanContext& bc, Collection& c)
        : source(&bc), children(&c) {}

    int size() const {
        return children->size();
    }

    std::vector<Object*> toArray() const {
        return children->toArray();
    }

    Collection::Iterator iterator() const {
        return children->iterator();
    }

    bool contains(Object* obj) const {
        return children->contains(obj);
    }
};

// ---------- Test functions (translated from Java @Test) ----------

void size_test_1642(BeanContext& c0, Collection& c1) {
    BeanContextMembershipEvent instance(c0, c1);
    instance.size();
}

void toArray_test_1643(BeanContext& c0, Collection& c1) {
    BeanContextMembershipEvent instance(c0, c1);
    instance.toArray();
}

void iterator_test_1644(BeanContext& c0, Collection& c1) {
    BeanContextMembershipEvent instance(c0, c1);
    instance.iterator();
}

void contains_test_1645(Object* p0, BeanContext& c0, Collection& c1) {
    BeanContextMembershipEvent instance(c0, c1);
    instance.contains(p0);
}
```