```cpp
#include <string>
#include <cstdint>

class EventObject {
public:
    EventObject(void* source) : source_(source) {}

    void* getSource() const {
        return source_;
    }

    std::string toString() const {
        // Mimic Java's default toString: class name @ hex hash code
        return "java.util.EventObject@" + std::to_string(reinterpret_cast<uintptr_t>(this));
    }

private:
    void* source_;
};

// Test functions (translations of JUnit @Test methods)
void getSource_test_3441(void* c0) {
    EventObject instance(c0);
    instance.getSource();
}

void toString_test_3442(void* c0) {
    EventObject instance(c0);
    instance.toString();
}
```