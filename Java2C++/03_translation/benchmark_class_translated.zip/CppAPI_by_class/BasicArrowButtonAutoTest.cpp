```cpp
#include <iostream>

// Minimal Graphics class to match Java's java.awt.Graphics
class Graphics {
public:
    Graphics() = default;
};

// Simple Dimension struct to match java.awt.Dimension
struct Dimension {
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// BasicArrowButton simulating javax.swing.plaf.basic.BasicArrowButton
class BasicArrowButton {
private:
    int direction;
public:
    BasicArrowButton(int direction) : direction(direction) {}

    void setDirection(int dir) {
        direction = dir;
    }

    void paintTriangle(Graphics& g, int x, int y, int size, int dir, bool enabled) {
        // Stub – does nothing
    }

    int getDirection() const {
        return direction;
    }

    Dimension getMaximumSize() const {
        return Dimension(0, 0);
    }

    void paint(Graphics& g) {
        // Stub – does nothing
    }

    Dimension getPreferredSize() const {
        return Dimension(0, 0);
    }

    Dimension getMinimumSize() const {
        return Dimension(0, 0);
    }

    bool isFocusTraversable() const {
        return false;
    }
};

// Test functions (translated from Java @Test methods)
void setDirection_test_8610(int p0, int c0) {
    BasicArrowButton instance(c0);
    instance.setDirection(p0);
}

void paintTriangle_test_8611(Graphics& p0, int p1, int p2, int p3, int p4, bool p5, int c0) {
    BasicArrowButton instance(c0);
    instance.paintTriangle(p0, p1, p2, p3, p4, p5);
}

void getDirection_test_8612(int c0) {
    BasicArrowButton instance(c0);
    instance.getDirection();
}

void getMaximumSize_test_8613(int c0) {
    BasicArrowButton instance(c0);
    instance.getMaximumSize();
}

void paint_test_8614(Graphics& p0, int c0) {
    BasicArrowButton instance(c0);
    instance.paint(p0);
}

void getPreferredSize_test_8615(int c0) {
    BasicArrowButton instance(c0);
    instance.getPreferredSize();
}

void getMinimumSize_test_8616(int c0) {
    BasicArrowButton instance(c0);
    instance.getMinimumSize();
}

void isFocusTraversable_test_8617(int c0) {
    BasicArrowButton instance(c0);
    instance.isFocusTraversable();
}
```