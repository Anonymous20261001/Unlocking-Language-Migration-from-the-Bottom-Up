```cpp
#include <iostream>
#include <vector>
#include <algorithm>
#include <memory>
#include <stdexcept>
#include <sstream>
#include <string>
#include <functional>
#include <cstring>

// Base Object class (equivalent to java.lang.Object)
class Object {
public:
    virtual ~Object() = default;
};

using ObjectPtr = std::shared_ptr<Object>;

// Collection interface (equivalent to java.util.Collection)
class Collection {
public:
    virtual bool add(ObjectPtr e) = 0;
    virtual bool remove(Object* o) = 0;
    virtual int size() const = 0;
    virtual bool contains(Object* o) const = 0;
    virtual void clear() = 0;
    virtual ~Collection() = default;
};

// Concrete collection implementation (simplified ArrayList)
class ArrayList : public Collection {
    std::vector<ObjectPtr> data;
public:
    bool add(ObjectPtr e) override {
        data.push_back(e);
        return true;
    }
    bool remove(Object* o) override {
        auto it = std::find_if(data.begin(), data.end(),
            [o](const ObjectPtr& ptr) { return ptr.get() == o; });
        if (it != data.end()) {
            data.erase(it);
            return true;
        }
        return false;
    }
    int size() const override { return data.size(); }
    bool contains(Object* o) const override {
        return std::any_of(data.begin(), data.end(),
            [o](const ObjectPtr& ptr) { return ptr.get() == o; });
    }
    void clear() override { data.clear(); }
};

// Predicate interface (equivalent to java.util.function.Predicate)
class Predicate {
public:
    virtual bool test(Object* o) = 0;
    virtual ~Predicate() = default;
};

// Consumer interface (equivalent to java.util.function.Consumer)
class Consumer {
public:
    virtual void accept(Object* o) = 0;
    virtual ~Consumer() = default;
};

// Dummy Spliterator (not fully implemented)
class Spliterator {
public:
    // Minimal stub
};

// Iterator for ArrayBlockingQueue (forward only, no removal)
class ABQIterator {
    std::vector<ObjectPtr>& buffer;
    int capacity;
    int head;
    int tail;
    int current;
    int count;
    int index; // number of elements returned
public:
    ABQIterator(std::vector<ObjectPtr>& buf, int cap, int h, int t, int cnt)
        : buffer(buf), capacity(cap), head(h), tail(t), count(cnt), index(0) {
        current = head;
    }
    bool hasNext() const { return index < count; }
    ObjectPtr next() {
        if (!hasNext()) throw std::out_of_range("No more elements");
        ObjectPtr elem = buffer[current];
        current = (current + 1) % capacity;
        ++index;
        return elem;
    }
};

// ArrayBlockingQueue implementation (equivalent to java.util.concurrent.ArrayBlockingQueue)
class ArrayBlockingQueue {
    std::vector<ObjectPtr> buffer;
    int capacity;
    int head;
    int tail;
    int count;
public:
    ArrayBlockingQueue(int cap) : capacity(cap), head(0), tail(0), count(0) {
        if (cap <= 0)
            throw std::invalid_argument("Capacity must be positive");
        buffer.resize(capacity);
    }

    // drainTo(Collection, int)
    int drainTo(Collection& c, int maxElements) {
        int toDrain = std::min(maxElements, count);
        int drained = 0;
        while (drained < toDrain) {
            ObjectPtr elem = buffer[head];
            c.add(elem);
            head = (head + 1) % capacity;
            --count;
            ++drained;
        }
        return drained;
    }

    // drainTo(Collection)
    int drainTo(Collection& c) {
        return drainTo(c, count);
    }

    int remainingCapacity() const {
        return capacity - count;
    }

    bool remove(Object* o) {
        // Find and remove first occurrence using pointer identity
        for (int i = 0; i < count; ++i) {
            int idx = (head + i) % capacity;
            if (buffer[idx].get() == o) {
                // Shift elements left
                for (int j = i; j < count - 1; ++j) {
                    int src = (head + j + 1) % capacity;
                    int dst = (head + j) % capacity;
                    buffer[dst] = buffer[src];
                }
                tail = (tail - 1 + capacity) % capacity;
                buffer[tail].reset();
                --count;
                return true;
            }
        }
        return false;
    }

    int size() const { return count; }

    std::string toString() const {
        std::ostringstream oss;
        oss << "[";
        for (int i = 0; i < count; ++i) {
            if (i > 0) oss << ", ";
            int idx = (head + i) % capacity;
            // Since Object has no toString, just print address
            oss << buffer[idx].get();
        }
        oss << "]";
        return oss.str();
    }

    void clear() {
        for (int i = 0; i < capacity; ++i)
            buffer[i].reset();
        head = tail = count = 0;
    }

    bool add(ObjectPtr e) {
        if (count == capacity)
            throw std::runtime_error("Queue full");
        buffer[tail] = e;
        tail = (tail + 1) % capacity;
        ++count;
        return true;
    }

    // toArray() returning vector of ObjectPtr