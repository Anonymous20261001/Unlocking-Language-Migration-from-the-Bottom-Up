```cpp
#include <string>
#include <iostream>
#include <vector>

// ------------------------------------------------------------------
// Minimal Object base class (equivalent to java.lang.Object)
// ------------------------------------------------------------------
class Object {
public:
    virtual ~Object() {}
};

// ------------------------------------------------------------------
// Forward declaration of ItemListener (needed for ItemSelectable)
// ------------------------------------------------------------------
class ItemListener;

// ------------------------------------------------------------------
// ItemSelectable interface (equivalent to java.awt.ItemSelectable)
// ------------------------------------------------------------------
class ItemSelectable {
public:
    virtual void addItemListener(ItemListener* l) = 0;
    virtual void removeItemListener(ItemListener* l) = 0;
    virtual std::vector<Object*> getSelectedObjects() = 0;
    virtual ~ItemSelectable() {}
};

// ------------------------------------------------------------------
// A concrete ItemSelectable for testing (does nothing useful)
// ------------------------------------------------------------------
class ConcreteItemSelectable : public ItemSelectable {
public:
    void addItemListener(ItemListener* l) override {}
    void removeItemListener(ItemListener* l) override {}
    std::vector<Object*> getSelectedObjects() override { return {}; }
};

// ------------------------------------------------------------------
// ItemEvent class (equivalent to java.awt.event.ItemEvent)
// ------------------------------------------------------------------
class ItemEvent {
public:
    // Constants matching java.awt.event.ItemEvent
    static const int SELECTED = 1;
    static const int DESELECTED = 2;
    static const int ITEM_STATE_CHANGED = 701;

    // Constructor
    ItemEvent(ItemSelectable* source, int id, Object* item, int stateChange)
        : source_(source), id_(id), item_(item), stateChange_(stateChange) {}

    // API methods
    int getStateChange() const {
        return stateChange_;
    }

    ItemSelectable* getItemSelectable() const {
        return source_;
    }

    Object* getItem() const {
        return item_;
    }

    std::string paramString() const {
        // Mimic the Java format: "java.awt.event.ItemEvent[ITEM_STATE_CHANGED,item=...,stateChange=...]"
        std::string result = "java.awt.event.ItemEvent[";
        // id part
        if (id_ == ITEM_STATE_CHANGED) {
            result += "ITEM_STATE_CHANGED";
        } else {
            result += "id=" + std::to_string(id_);
        }
        // item part
        result += ",item=";
        // In Java, the item's toString() is called; here we use a placeholder
        result += (item_ ? "Object@" + std::to_string(reinterpret_cast<uintptr_t>(item_)) : "null");
        // stateChange part
        result += ",stateChange=";
        if (stateChange_ == SELECTED) {
            result += "SELECTED";
        } else if (stateChange_ == DESELECTED) {
            result += "DESELECTED";
        } else {
            result += std::to_string(stateChange_);
        }
        result += "]";
        return result;
    }

private:
    ItemSelectable* source_;
    int id_;
    Object* item_;
    int stateChange_;
};

// ------------------------------------------------------------------
// Translated test functions (each takes the same parameters as Java)
// ------------------------------------------------------------------
void getStateChange_test_778(ItemSelectable* c0, int c1, Object* c2, int c3) {
    ItemEvent instance(c0, c1, c2, c3);
    instance.getStateChange();
}

void getItemSelectable_test_779(ItemSelectable* c0, int c1, Object* c2, int c3) {
    ItemEvent instance(c0, c1, c2, c3);
    instance.getItemSelectable();
}

void getItem_test_780(ItemSelectable* c0, int c1, Object* c2, int c3) {
    ItemEvent instance(c0, c1, c2, c3);
    instance.getItem();
}

void paramString_test_781(ItemSelectable* c0, int c1, Object* c2, int c3) {
    ItemEvent instance(c0, c1, c2, c3);
    instance.paramString();
}

// ------------------------------------------------------------------
// Main function to exercise all tests (optional, but completes the program)
// ------------------------------------------------------------------
int main() {
    ConcreteItemSelectable selectable;
    Object item;
    int id = ItemEvent::ITEM_STATE_CHANGED;
    int state = ItemEvent::SELECTED;

    getStateChange_test_778(&selectable, id, &item, state);
    getItemSelectable_test_779(&selectable, id, &item, state);
    getItem_test_780(&selectable, id, &item, state);
    paramString_test_781(&selectable, id, &item, state);

    std::cout << "All tests passed (no crashes)." << std::endl;
    return 0;
}
```