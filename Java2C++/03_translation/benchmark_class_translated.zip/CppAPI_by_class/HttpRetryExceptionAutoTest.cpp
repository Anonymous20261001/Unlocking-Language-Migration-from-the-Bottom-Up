Code_test_2587 returns void, etc. Fully matches.

Now output.```cpp
#include <string>
#include <stdexcept>

class HttpRetryException : public std::runtime_error {
private:
    int _responseCode;
    std::string _location;

public:
    HttpRetryException(const std::string& detail, int code)
        : std::runtime_error(detail), _responseCode(code), _location() {}

    HttpRetryException(const std::string& detail, int code, const std::string& location)
        : std::runtime_error(detail), _responseCode(code), _location(location) {}

    int responseCode() const {
        return _responseCode;
    }

    std::string getLocation() const {
        return _location;
    }

    std::string getReason() const {
        return what();
    }
};

void responseCode_test_2587(const std::string& c0, int c1) {
    HttpRetryException instance(c0, c1);
    instance.responseCode();
}

void getLocation_test_2588(const std::string& c0, int c1) {
    HttpRetryException instance(c0, c1);
    instance.getLocation();
}

void getReason_test_2589(const std::string& c0, int c1) {
    HttpRetryException instance(c0, c1);
    instance.getReason();
}
```