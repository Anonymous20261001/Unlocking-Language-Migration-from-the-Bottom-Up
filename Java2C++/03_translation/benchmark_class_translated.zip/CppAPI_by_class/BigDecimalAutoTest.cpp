```cpp
#include <string>
#include <cstdint>
#include <stdexcept>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <sstream>
#include <iomanip>
#include <vector>

// ---------- RoundingMode ----------
enum class RoundingMode {
    UP,
    DOWN,
    CEILING,
    FLOOR,
    HALF_UP,
    HALF_DOWN,
    HALF_EVEN,
    UNNECESSARY
};

// ---------- MathContext ----------
class MathContext {
public:
    MathContext(int precision, RoundingMode roundingMode)
        : precision_(precision), roundingMode_(roundingMode) {}
    int precision() const { return precision_; }
    RoundingMode roundingMode() const { return roundingMode_; }
private:
    int precision_;
    RoundingMode roundingMode_;
};

// ---------- BigDecimal (simplified) ----------
class BigDecimal {
public:
    // Constructors
    BigDecimal() : value_("0"), scale_(0) {}
    BigDecimal(const std::string& val) {
        // Parse string to store normalized form: integer part and scale
        // For simplicity, store the raw string and compute scale on demand.
        value_ = val;
        scale_ = computeScale();
    }
    BigDecimal(int val) : value_(std::to_string(val)), scale_(0) {}
    BigDecimal(long val) : value_(std::to_string(val)), scale_(0) {}
    BigDecimal(double val) : value_(doubleToString(val)), scale_(computeScale()) {}

    // Copy constructor and assignment
    BigDecimal(const BigDecimal& other) = default;
    BigDecimal& operator=(const BigDecimal& other) = default;

    // Static factory methods
    static BigDecimal valueOf(long val) { return BigDecimal(val); }
    static BigDecimal valueOf(double val) { return BigDecimal(val); }
    static BigDecimal valueOf(long unscaledVal, int scale) {
        // Create string with appropriate decimal point
        std::string s = std::to_string(unscaledVal);
        if (scale > 0) {
            if (static_cast<int>(s.length()) <= scale) {
                s = std::string(scale - s.length() + 1, '0') + s;
                s.insert(s.length() - scale, ".");
            } else {
                s.insert(s.length() - scale, ".");
            }
        }
        return BigDecimal(s);
    }

    // Instance methods (return new BigDecimal)
    BigDecimal stripTrailingZeros() const {
        std::string s = value_;
        size_t dot = s.find('.');
        if (dot != std::string::npos) {
            size_t last_non_zero = s.find_last_not_of('0');
            if (last_non_zero == dot) { // all zeros after decimal point
                s.erase(dot);
            } else {
                s.erase(last_non_zero + 1);
            }
        }
        return BigDecimal(s);
    }

    BigDecimal movePointLeft(int n) const {
        std::string s = value_;
        size_t dot = s.find('.');
        if (dot == std::string::npos) {
            s.push_back('.');
            dot = s.size() - 1;
        }
        if (n > 0) {
            if ((int)dot < n) {
                s.insert(0, n - dot, '0');
                dot += n - dot;
            }
            s.insert(dot - n, ".");
            if (dot - n > 0) s.erase(dot + 1, 1);
        }
        return BigDecimal(s);
    }

    std::string toEngineeringString() const {
        // Simplified: same as toPlainString for this demo
        return value_;
    }

    std::string toPlainString() const {
        return value_;
    }

    bool equals(const BigDecimal& other) const {
        return value_ == other.value_;
    }

    std::string toString() const {
        return value_;
    }

    size_t hashCode() const {
        return std::hash<std::string>{}(value_);
    }

    BigDecimal abs() const {
        if (value_.empty() || value_[0] != '-') return *this;
        return BigDecimal(value_.substr(1));
    }

    BigDecimal abs(const MathContext&) const {
        return abs();
    }

    BigDecimal sqrt(const MathContext&) const {
        double d = std::stod(value_);
        double r = std::sqrt(d);
        return BigDecimal(r);
    }

    BigDecimal pow(int exponent, const MathContext&) const {
        double d = std::stod(value_);
        double r = std::pow(d, exponent);
        return BigDecimal(r);
    }

    BigDecimal pow(int exponent) const {
        return pow(exponent, MathContext(10, RoundingMode::HALF_UP));
    }

    BigDecimal min(const BigDecimal& other) const {
        if (compareTo(other) <= 0) return *this;
        return other;
    }

    BigDecimal max(const BigDecimal& other) const {
        if (compareTo(other) >= 0) return *this;
        return other;
    }

    BigDecimal round(const MathContext&) const {
        return *this; // simplified
    }

    int signum() const {
        if (value_.empty()) return 0;
        if (value_[0] == '-') return -1;
        if (value_[0] == '0') return 0;
        return 1;
    }

    int compareTo(const BigDecimal& other) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(other.value_);
        if (d1 < d2) return -1;
        if (d1 > d2) return 1;
        return 0;
    }

    int intValue() const {
        return static_cast<int>(std::stoll(value_));
    }

    long longValue() const {
        return static_cast<long>(std::stoll(value_));
    }

    float floatValue() const {
        return std::stof(value_);
    }

    double doubleValue() const {
        return std::stod(value_);
    }

    int scale() const {
        return scale_;
    }

    BigDecimal add(const BigDecimal& other) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(other.value_);
        return BigDecimal(d1 + d2);
    }

    BigDecimal add(const BigDecimal& other, const MathContext&) const {
        return add(other);
    }

    BigDecimal multiply(const BigDecimal& other) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(other.value_);
        return BigDecimal(d1 * d2);
    }

    BigDecimal multiply(const BigDecimal& other, const MathContext&) const {
        return multiply(other);
    }

    BigDecimal ulp() const {
        // Return unit in the last place based on scale
        if (scale_ == 0) return BigDecimal(1);
        double u = std::pow(10.0, -scale_);
        return BigDecimal(u);
    }

    BigDecimal negate() const {
        if (value_.empty()) return *this;
        if (value_[0] == '-') return BigDecimal(value_.substr(1));
        return BigDecimal("-" + value_);
    }

    BigDecimal negate(const MathContext&) const {
        return negate();
    }

    BigDecimal remainder(const BigDecimal& divisor) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(divisor.value_);
        return BigDecimal(std::fmod(d1, d2));
    }

    BigDecimal remainder(const BigDecimal& divisor, const MathContext&) const {
        return remainder(divisor);
    }

    BigDecimal subtract(const BigDecimal& other, const MathContext&) const {
        return subtract(other);
    }

    BigDecimal subtract(const BigDecimal& other) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(other.value_);
        return BigDecimal(d1 - d2);
    }

    std::string toBigInteger() const {
        // Return integer part as string
        size_t dot = value_.find('.');
        if (dot == std::string::npos) return value_;
        return value_.substr(0, dot);
    }

    BigDecimal divide(const BigDecimal& divisor, RoundingMode) const {
        return divide(divisor);
    }

    BigDecimal divide(const BigDecimal& divisor, int roundingMode) const {
        // roundingMode is integer; treat as rounding mode (simplified)
        return divide(divisor);
    }

    BigDecimal divide(const BigDecimal& divisor) const {
        if (std::stod(divisor.value_) == 0.0) throw std::runtime_error("Division by zero");
        double d1 = std::stod(value_);
        double d2 = std::stod(divisor.value_);
        return BigDecimal(d1 / d2);
    }

    BigDecimal divide(const BigDecimal& divisor, int scale, RoundingMode) const {
        // Ignore scale and rounding
        return divide(divisor);
    }

    BigDecimal divide(const BigDecimal& divisor, int scale, int roundingMode) const {
        // Ignore scale and rounding
        return divide(divisor);
    }

    BigDecimal divide(const BigDecimal& divisor, const MathContext&) const {
        return divide(divisor);
    }

    std::vector<BigDecimal> divideAndRemainder(const BigDecimal& divisor) const {
        BigDecimal quotient = divide(divisor);
        BigDecimal remainder = this->remainder(divisor);
        return {quotient, remainder};
    }

    std::vector<BigDecimal> divideAndRemainder(const BigDecimal& divisor, const MathContext&) const {
        return divideAndRemainder(divisor);
    }

    long longValueExact() const {
        // Simplified: no overflow check
        return longValue();
    }

    int intValueExact() const {
        return intValue();
    }

    short shortValueExact() const {
        return static_cast<short>(intValue());
    }

    char byteValueExact() const {
        return static_cast<char>(intValue());
    }

    BigDecimal scaleByPowerOfTen(int n) const {
        // Multiply by 10^n: move decimal point right
        return movePointLeft(-n);
    }

    BigDecimal plus(const MathContext&) const {
        return *this;
    }

    BigDecimal plus() const {
        return *this;
    }

    BigDecimal divideToIntegralValue(const BigDecimal& divisor) const {
        double d1 = std::stod(value_);
        double d2 = std::stod(divisor.value_);
        double q = std::floor(d1 / d2);
        return BigDecimal(static_cast<long>(q));
    }

    BigDecimal divideToIntegralValue(const BigDecimal& divisor, const MathContext&) const {
        return divideToIntegralValue(divisor);
    }

    BigDecimal movePointRight(int n) const {
        return movePointLeft(-n);
    }

    std::string toBigIntegerExact() const {
        // Simplified: return integer part
        return toBigInteger();
    }

    int precision() const {
        // Count significant digits: exclude sign, leading zeros, decimal point
        std::string s = value_;
        if (s.empty()) return 0;
        if (s[0] == '-') s = s.substr(1);
        size_t dot = s.find('.');
        if (dot != std::string::npos) {
            s.erase(dot, 1);
        }
        // Remove leading zeros
        size_t first_non_zero = s.find_first_not_of('0');
        if (first_non_zero == std::string::npos) return 1; // all zeros
        return s.size() - first_non_zero;
    }

    std::string unscaledValue() const {
        // Return the integer part (without decimal point) as string
        size_t dot = value_.find('.');
        if (dot == std::string::npos) return value_;
        std::string intPart = value_.substr(0, dot);
        std::string fracPart = value_.substr(dot + 1);
        return intPart + fracPart;
    }

    BigDecimal setScale(int newScale) const {
        // Adjust scale without rounding (may truncate)
        int currentScale = scale_;
        std::string s = value_;
        if (newScale == currentScale) return *this;
        if (newScale > currentScale) {
            // Add trailing zeros
            if (s.find('.') == std::string::npos) s.push_back('.');
            s.append(newScale - currentScale, '0');
        } else {
            // Truncate
            size_t dot = s.find('.');
            if (dot != std::string::npos) {
                if ((int)s.size() - (int)dot - 1 > newScale) {
                    s.erase(dot + 1 + newScale);
                }
            }
        }
        return BigDecimal(s);
    }

    BigDecimal setScale(int newScale, RoundingMode) const {
        // Simplified: just set scale (may truncate)
        return setScale(newScale);
    }

    BigDecimal setScale(int newScale, int roundingMode) const {
        return setScale(newScale);
    }

private:
    std::string value_;
    int scale_;

    int computeScale() const {
        size_t dot = value_.find('.');
        if (dot == std::string::npos) return 0;
        return value_.size() - dot - 1;
    }

    static std::string doubleToString(double val) {
        std::ostringstream oss;
        oss << std::setprecision(20) << val;
        return oss.str();
    }
};

// ---------- Test functions ----------
void stripTrailingZeros_test_2426(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.stripTrailingZeros();
}

void movePointLeft_test_2427(int p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.movePointLeft(p0);
}

void toEngineeringString_test_2428(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.toEngineeringString();
}

void toPlainString_test_2429(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.toPlainString();
}

void equals_test_2430(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.equals(p0);
}

void toString_test_2431(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.toString();
}

void hashCode_test_2432(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.hashCode();
}

void abs_test_2433(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.abs();
}

void abs_test_2434(const MathContext& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.abs(p0);
}

void sqrt_test_2435(const MathContext& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.sqrt(p0);
}

void pow_test_2436(int p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.pow(p0, p1);
}

void pow_test_2437(int p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.pow(p0);
}

void min_test_2438(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.min(p0);
}

void max_test_2439(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.max(p0);
}

void round_test_2440(const MathContext& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.round(p0);
}

void signum_test_2441(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.signum();
}

void compareTo_test_2442(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.compareTo(p0);
}

void intValue_test_2443(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.intValue();
}

void longValue_test_2444(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.longValue();
}

void floatValue_test_2445(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.floatValue();
}

void doubleValue_test_2446(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.doubleValue();
}

void valueOf_test_2447(long p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    BigDecimal::valueOf(p0);
}

void valueOf_test_2448(double p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    BigDecimal::valueOf(p0);
}

void valueOf_test_2449(long p0, int p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    BigDecimal::valueOf(p0, p1);
}

void scale_test_2450(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.scale();
}

void add_test_2451(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.add(p0);
}

void add_test_2452(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.add(p0, p1);
}

void multiply_test_2453(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.multiply(p0);
}

void multiply_test_2454(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.multiply(p0, p1);
}

void ulp_test_2455(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.ulp();
}

void negate_test_2456(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.negate();
}

void negate_test_2457(const MathContext& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.negate(p0);
}

void remainder_test_2458(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.remainder(p0);
}

void remainder_test_2459(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.remainder(p0, p1);
}

void subtract_test_2460(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.subtract(p0, p1);
}

void subtract_test_2461(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.subtract(p0);
}

void toBigInteger_test_2462(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.toBigInteger();
}

void divide_test_2463(const BigDecimal& p0, RoundingMode p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0, p1);
}

void divide_test_2464(const BigDecimal& p0, int p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0, p1);
}

void divide_test_2465(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0);
}

void divide_test_2466(const BigDecimal& p0, int p1, RoundingMode p2, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0, p1, p2);
}

void divide_test_2467(const BigDecimal& p0, int p1, int p2, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0, p1, p2);
}

void divide_test_2468(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divide(p0, p1);
}

void divideAndRemainder_test_2469(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divideAndRemainder(p0);
}

void divideAndRemainder_test_2470(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divideAndRemainder(p0, p1);
}

void longValueExact_test_2471(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.longValueExact();
}

void intValueExact_test_2472(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.intValueExact();
}

void shortValueExact_test_2473(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.shortValueExact();
}

void byteValueExact_test_2474(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.byteValueExact();
}

void scaleByPowerOfTen_test_2475(int p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.scaleByPowerOfTen(p0);
}

void plus_test_2476(const MathContext& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.plus(p0);
}

void plus_test_2477(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.plus();
}

void divideToIntegralValue_test_2478(const BigDecimal& p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divideToIntegralValue(p0);
}

void divideToIntegralValue_test_2479(const BigDecimal& p0, const MathContext& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.divideToIntegralValue(p0, p1);
}

void movePointRight_test_2480(int p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.movePointRight(p0);
}

void toBigIntegerExact_test_2481(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.toBigIntegerExact();
}

void precision_test_2482(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.precision();
}

void unscaledValue_test_2483(const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.unscaledValue();
}

void setScale_test_2484(int p0, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.setScale(p0);
}

void setScale_test_2485(int p0, const RoundingMode& p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.setScale(p0, p1);
}

void setScale_test_2486(int p0, int p1, const std::string& c0) {
    BigDecimal instance = BigDecimal(c0);
    instance.setScale(p0, p1);
}