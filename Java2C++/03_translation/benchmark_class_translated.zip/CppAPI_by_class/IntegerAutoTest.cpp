```cpp
#include <string>
#include <sstream>
#include <iomanip>
#include <climits>
#include <cstdint>
#include <algorithm>
#include <stdexcept>
#include <cstdlib> // for getenv
#include <iostream>

// -----------------------------------------------------------------------------
// Minimal Optional< T > (to mimic java.util.Optional)
// -----------------------------------------------------------------------------
template <typename T>
class Optional {
public:
    Optional() : present_(false), value_() {}
    Optional(const T& v) : present_(true), value_(v) {}
    bool isPresent() const { return present_; }
    T get() const { if (!present_) throw std::runtime_error("No value"); return value_; }
private:
    bool present_;
    T value_;
};

// -----------------------------------------------------------------------------
// Minimal MethodHandles::Lookup (stub)
// -----------------------------------------------------------------------------
namespace MethodHandles {
    class Lookup {
    public:
        Lookup() = default;
    };
} // namespace MethodHandles

// -----------------------------------------------------------------------------
// Integer class – mimicking java.lang.Integer (static and instance API)
// -----------------------------------------------------------------------------
class Integer {
public:
    // Constructors
    Integer() : value_(0) {}
    explicit Integer(int v) : value_(v) {}
    Integer(const Integer&) = default;
    Integer& operator=(const Integer&) = default;

    // ---------- instance methods ----------
    bool equals(const Integer& other) const { return value_ == other.value_; }
    std::string toString() const { return std::to_string(value_); }
    int hashCode() const { return value_; }
    int compareTo(const Integer& other) const {
        if (value_ < other.value_) return -1;
        if (value_ > other.value_) return 1;
        return 0;
    }

    // Number conversion methods (narrowing)
    int8_t byteValue() const { return static_cast<int8_t>(value_); }
    int16_t shortValue() const { return static_cast<int16_t>(value_); }
    int intValue() const { return value_; }
    int64_t longValue() const { return static_cast<int64_t>(value_); }
    float floatValue() const { return static_cast<float>(value_); }
    double doubleValue() const { return static_cast<double>(value_); }

    // resolveConstantDesc and describeConstable (stubs)
    Integer resolveConstantDesc(const MethodHandles::Lookup&) const { return *this; }
    Optional<Integer> describeConstable() const { return Optional<Integer>(*this); }

    // ---------- static methods ----------
    static int numberOfLeadingZeros(int i) {
        if (i == 0) return 32;
        int n = 0;
        if (i <= 0x0000FFFF) { n += 16; i <<= 16; }
        if (i <= 0x00FFFFFF) { n += 8;  i <<= 8; }
        if (i <= 0x0FFFFFFF) { n += 4;  i <<= 4; }
        if (i <= 0x3FFFFFFF) { n += 2;  i <<= 2; }
        if (i <= 0x7FFFFFFF) { n += 1; }
        return n;
    }

    static int numberOfTrailingZeros(int i) {
        if (i == 0) return 32;
        int n = 31;
        int y;
        y = i << 16; if (y != 0) { n -= 16; i = y; }
        y = i << 8;  if (y != 0) { n -= 8;  i = y; }
        y = i << 4;  if (y != 0) { n -= 4;  i = y; }
        y = i << 2;  if (y != 0) { n -= 2;  i = y; }
        y = i << 1;  if (y != 0) { n -= 1; }
        return n;
    }

    static int bitCount(int i) {
        i = i - ((i >> 1) & 0x55555555);
        i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
        i = (i + (i >> 4)) & 0x0F0F0F0F;
        i = i + (i >> 8);
        i = i + (i >> 16);
        return i & 0x3F;
    }

    static std::string toString(int i) { return std::to_string(i); }

    static std::string toString(int i, int radix) {
        if (radix < 2 || radix > 36) radix = 10;
        bool negative = (i < 0);
        std::string result;
        if (i == 0) result = "0";
        else {
            unsigned int u = negative ? -static_cast<unsigned int>(i) : static_cast<unsigned int>(i);
            while (u) {
                unsigned int digit = u % radix;
                char c = static_cast<char>(digit < 10 ? '0' + digit : 'a' + digit - 10);
                result.push_back(c);
                u /= radix;
            }
            if (negative) result.push_back('-');
            std::reverse(result.begin(), result.end());
        }
        return result;
    }

    static int hashCode(int i) { return i; }

    static int min(int a, int b) { return (a < b) ? a : b; }
    static int max(int a, int b) { return (a > b) ? a : b; }

    static int signum(int i) {
        return (i > 0) ? 1 : (i < 0) ? -1 : 0;
    }

    static int expand(int i, int mask) {
        // Bit expand: place bits of i at positions where mask has 1s.
        int result = 0;
        int pos = 0;
        for (int m = mask; m; m >>= 1) {
            if (m & 1) {
                result |= ((i >> pos) & 1) << (31 - __builtin_ctz(mask)); // naive, need correct mapping
                // simpler: walk through bits
            }
        }
        // a proper implementation (Java 19) – using general algorithm
        int x = i;
        int m = mask;
        int r = 0;
        int k = 0;
        while (m) {
            int b = m & -m;
            int t = (x >> k) & 1;
            if (t) r |= b;
            m ^= b;
            k++;
        }
        return r;
    }

    static int compress(int i, int mask) {
        int r = 0;
        int k = 0;
        for (int m = mask; m; m >>= 1) {
            if (m & 1) {
                r |= ((i >> (31 - __builtin_ctz(m))) & 1) << k;
                k++;
            }
        }
        // proper compress using loops
        int x = i;
        int m = mask;
        int res = 0;
        int shift = 0;
        while (m) {
            int low = m & -m;
            m ^= low;
            int src_bit = (x & low) ? 1 : 0;
            res |= (src_bit << shift);
            shift++;
        }
        return res;
    }

    static int compareUnsigned(int x, int y) {
        unsigned int ux = static_cast<unsigned int>(x);
        unsigned int uy = static_cast<unsigned int>(y);
        if (ux < uy) return -1;
        if (ux > uy) return 1;
        return 0;
    }

    static int divideUnsigned(int dividend, int divisor) {
        unsigned int u_dividend = static_cast<unsigned int>(dividend);
        unsigned int u_divisor = static_cast<unsigned int>(divisor);
        return static_cast<int>(u_dividend / u_divisor);
    }

    static int remainderUnsigned(int dividend, int divisor) {
        unsigned int u_dividend = static_cast<unsigned int>(dividend);
        unsigned int u_divisor = static_cast<unsigned int>(divisor);
        return static_cast<int>(u_dividend % u_divisor);
    }

    static int reverse(int i) {
        i = ((i & 0x55555555) << 1) | ((i >> 1) & 0x55555555);
        i = ((i & 0x33333333) << 2) | ((i >> 2) & 0x33333333);
        i = ((i & 0x0F0F0F0F) << 4) | ((i >> 4) & 0x0F0F0F0F);
        i = (i << 24) | ((i & 0xFF00) << 8) | ((i >> 8) & 0xFF00) | (i >> 24);
        return i;
    }

    static int reverseBytes(int i) {
        return ((i >> 24) & 0xFF) | ((i >> 8) & 0xFF00) | ((i << 8) & 0xFF0000) | (i << 24);
    }

    static int compare(int x, int y) {
        if (x < y) return -1;
        if (x > y) return 1;
        return 0;
    }

    static Integer valueOf(int i) { return Integer(i); }

    static std::string toHexString(int i) {
        std::stringstream ss;
        ss << std::hex << i;
        return ss.str();
    }

    static uint64_t toUnsignedLong(int x) {
        return static_cast<uint64_t>(static_cast<unsigned int>(x));
    }

    static int sum(int a, int b) { return a + b; }

    static std::string toUnsignedString(int i) {
        return std::to_string(static_cast<unsigned int>(i));
    }

    static std::string toUnsignedString(int i, int radix) {
        if (radix < 2 || radix > 36) radix = 10;
        unsigned int u = static_cast<unsigned int>(i);
        if (u == 0) return "0";
        std::string result;
        while (u) {
            unsigned int d = u % radix;
            result.push_back(d < 10 ? '0' + d : 'a' + d - 10);
            u /= radix;
        }
        std::reverse(result.begin(), result.end());
        return result;
    }

    // getInteger (stub – returns default or null)
    static Integer getInteger(const std::string& nm) {
        const char* env = std::getenv(nm.c_str());
        if (env) {
            return Integer(std::stoi(env));
        }
        // In Java returns null; we return Integer(0) as placeholder
        return Integer(0);
    }

    static Integer getInteger(const std::string& nm, Integer def) {
        const char* env = std::getenv(nm.c_str());
        if (env) {
            return Integer(std::stoi(env));
        }
        return def;
    }

    static Integer getInteger(const std::string& nm, int def) {
        return getInteger(nm, Integer(def));
    }

    static std::string toOctalString(int i) {
        std::stringstream ss;
        ss << std::oct << i;
        return ss.str();
    }

    static std::string toBinaryString(int i) {
        std::string result;
        unsigned int u = static_cast<unsigned int>(i);
        if (u == 0) return "0";
        while (u) {
            result.push_back((u & 1) ? '1' : '0');
            u >>= 1;
        }
        std::reverse(result.begin(), result.end());
        return result;
    }

    static int highestOneBit(int i) {
        if (i == 0) return 0;
        i |= (i >> 1);
        i |= (i >> 2);
        i |= (i >> 4);
        i |= (i >> 8);
        i |= (i >> 16);
        return i - (i >> 1);
    }

    static int lowestOneBit(int i) {
        return i & -i;
    }

    static int rotateLeft(int i, int distance) {
        unsigned int u = static_cast<unsigned int>(i);
        distance &= 0x1F; // 32 bits
        return static_cast<int>((u << distance) | (u >> (32 - distance)));
    }

    static int rotateRight(int i, int distance) {
        unsigned int u = static_cast<unsigned int>(i);
        distance &= 0x1F;
        return static_cast<int>((u >> distance) | (u << (32 - distance)));
    }

private:
    int value_;
};

// =============================================================================
// Test functions (one per @Test method in the Java file)
// =============================================================================
void numberOfLeadingZeros_test_1998(int p0, int c0) {
    Integer instance(c0);
    Integer::numberOfLeadingZeros(p0);
}

void numberOfTrailingZeros_test_1999(int p0, int c0) {
    Integer instance(c0);
    Integer::numberOfTrailingZeros(p0);
}

void bitCount_test_2000(int p0, int c0) {
    Integer instance(c0);
    Integer::bitCount(p0);
}

void equals_test_2001(const Integer& p0, int c0) {
    Integer instance(c0);
    instance.equals(p0);
}

void toString_test_2002(int p0, int c0) {
    Integer instance(c0);
    Integer::toString(p0);
}

void toString_test_2003(int c0) {
    Integer instance(c0);
    instance.toString();
}

void toString_test_2004(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::toString(p0, p1);
}

void hashCode_test_2005(int c0) {
    Integer instance(c0);
    instance.hashCode();
}

void hashCode_test_2006(int p0, int c0) {
    Integer instance(c0);
    Integer::hashCode(p0);
}

void min_test_2007(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::min(p0, p1);
}

void max_test_2008(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::max(p0, p1);
}

void signum_test_2009(int p0, int c0) {
    Integer instance(c0);
    Integer::signum(p0);
}

void expand_test_2010(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::expand(p0, p1);
}

void compareUnsigned_test_2011(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::compareUnsigned(p0, p1);
}

void divideUnsigned_test_2012(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::divideUnsigned(p0, p1);
}

void remainderUnsigned_test_2013(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::remainderUnsigned(p0, p1);
}

void reverse_test_2014(int p0, int c0) {
    Integer instance(c0);
    Integer::reverse(p0);
}

void reverseBytes_test_2015(int p0, int c0) {
    Integer instance(c0);
    Integer::reverseBytes(p0);
}

void compress_test_2016(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::compress(p0, p1);
}

void compareTo_test_2017(const Integer& p0, int c0) {
    Integer instance(c0);
    instance.compareTo(p0);
}

void compare_test_2018(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::compare(p0, p1);
}

void byteValue_test_2019(int c0) {
    Integer instance(c0);
    instance.byteValue();
}

void shortValue_test_2020(int c0) {
    Integer instance(c0);
    instance.shortValue();
}

void intValue_test_2021(int c0) {
    Integer instance(c0);
    instance.intValue();
}

void longValue_test_2022(int c0) {
    Integer instance(c0);
    instance.longValue();
}

void floatValue_test_2023(int c0) {
    Integer instance(c0);
    instance.floatValue();
}

void doubleValue_test_2024(int c0) {
    Integer instance(c0);
    instance.doubleValue();
}

void valueOf_test_2025(int p0, int c0) {
    Integer instance(c0);
    Integer::valueOf(p0);
}

void toHexString_test_2026(int p0, int c0) {
    Integer instance(c0);
    Integer::toHexString(p0);
}

void resolveConstantDesc_test_2027(const MethodHandles::Lookup& p0, int c0) {
    Integer instance(c0);
    instance.resolveConstantDesc(p0);
}

void describeConstable_test_2028(int c0) {
    Integer instance(c0);
    instance.describeConstable();
}

void toUnsignedLong_test_2029(int p0, int c0) {
    Integer instance(c0);
    Integer::toUnsignedLong(p0);
}

void sum_test_2030(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::sum(p0, p1);
}

void toUnsignedString_test_2031(int p0, int c0) {
    Integer instance(c0);
    Integer::toUnsignedString(p0);
}

void toUnsignedString_test_2032(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::toUnsignedString(p0, p1);
}

void getInteger_test_2033(const std::string& p0, const Integer& p1, int c0) {
    Integer instance(c0);
    Integer::getInteger(p0, p1);
}

void getInteger_test_2034(const std::string& p0, int c0) {
    Integer instance(c0);
    Integer::getInteger(p0);
}

void getInteger_test_2035(const std::string& p0, int p1, int c0) {
    Integer instance(c0);
    Integer::getInteger(p0, p1);
}

void toOctalString_test_2036(int p0, int c0) {
    Integer instance(c0);
    Integer::toOctalString(p0);
}

void toBinaryString_test_2037(int p0, int c0) {
    Integer instance(c0);
    Integer::toBinaryString(p0);
}

void highestOneBit_test_2038(int p0, int c0) {
    Integer instance(c0);
    Integer::highestOneBit(p0);
}

void lowestOneBit_test_2039(int p0, int c0) {
    Integer instance(c0);
    Integer::lowestOneBit(p0);
}

void rotateLeft_test_2040(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::rotateLeft(p0, p1);
}

void rotateRight_test_2041(int p0, int p1, int c0) {
    Integer instance(c0);
    Integer::rotateRight(p0, p1);
}
```