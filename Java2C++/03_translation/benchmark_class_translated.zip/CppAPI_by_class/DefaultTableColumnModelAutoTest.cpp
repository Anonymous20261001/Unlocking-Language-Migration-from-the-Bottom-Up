```cpp
#include <vector>
#include <algorithm>

// ---------- Basic types ----------
struct Object {
    virtual ~Object() = default;
};

struct Class {}; // placeholder type for Java's java.lang.Class

struct PropertyChangeEvent {
    PropertyChangeEvent(Object* source = nullptr) : source(source) {}
    Object* source;
};

struct ListSelectionEvent {
    ListSelectionEvent(Object* source = nullptr) : source(source) {}
    Object* source;
};

struct TableColumnModelListener {
    virtual ~TableColumnModelListener() = default;
    virtual void columnAdded() = 0;
    virtual void columnRemoved() = 0;
    virtual void columnMoved() = 0;
    virtual void columnMarginChanged() = 0;
    virtual void columnSelectionChanged() = 0;
};

struct ListSelectionModel {
    virtual ~ListSelectionModel() = default;
    virtual void addListSelectionListener() = 0;
    virtual void removeListSelectionListener() = 0;
    // minimal interface
};

struct TableColumn : public Object {
    // minimal
};

// ---------- DefaultTableColumnModel ----------
class DefaultTableColumnModel {
public:
    DefaultTableColumnModel() : columnMargin_(0), columnSelectionAllowed_(false), selectionModel_(nullptr) {}

    void propertyChange(PropertyChangeEvent* /*p0*/) {
        // stub
    }

    void setColumnMargin(int p0) {
        columnMargin_ = p0;
    }

    int getColumnMargin() {
        return columnMargin_;
    }

    TableColumn* getColumn(int /*p0*/) {
        if (columns_.empty()) return nullptr;
        if (p0 >= 0 && p0 < static_cast<int>(columns_.size()))
            return columns_[p0];
        return nullptr;
    }

    void removeColumn(TableColumn* p0) {
        auto it = std::find(columns_.begin(), columns_.end(), p0);
        if (it != columns_.end())
            columns_.erase(it);
    }

    void addColumn(TableColumn* p0) {
        columns_.push_back(p0);
    }

    std::vector<int> getSelectedColumns() {
        return {};
    }

    bool getColumnSelectionAllowed() {
        return columnSelectionAllowed_;
    }

    void setColumnSelectionAllowed(bool p0) {
        columnSelectionAllowed_ = p0;
    }

    int getSelectedColumnCount() {
        return 0;
    }

    int getColumnIndex(Object* /*p0*/) {
        return 0;
    }

    void moveColumn(int /*p0*/, int /*p1*/) {
        // stub
    }

    int getColumnIndexAtX(int /*p0*/) {
        return 0;
    }

    int getTotalColumnWidth() {
        return 0;
    }

    void removeColumnModelListener(TableColumnModelListener* p0) {
        auto it = std::find(listeners_.begin(), listeners_.end(), p0);
        if (it != listeners_.end())
            listeners_.erase(it);
    }

    void addColumnModelListener(TableColumnModelListener* p0) {
        listeners_.push_back(p0);
    }

    void valueChanged(ListSelectionEvent* /*p0*/) {
        // stub
    }

    ListSelectionModel* getSelectionModel() {
        return selectionModel_;
    }

    void setSelectionModel(ListSelectionModel* p0) {
        selectionModel_ = p0;
    }

    std::vector<TableColumnModelListener*> getColumnModelListeners() {
        return listeners_;
    }

    std::vector<void*> getListeners(Class /*p0*/) {
        return {};
    }

    std::vector<TableColumn*> getColumns() {
        return columns_;
    }

    int getColumnCount() {
        return static_cast<int>(columns_.size());
    }

private:
    int columnMargin_;
    bool columnSelectionAllowed_;
    ListSelectionModel* selectionModel_;
    std::vector<TableColumn*> columns_;
    std::vector<TableColumnModelListener*> listeners_;
};

// ---------- Test functions ----------
void propertyChange_test_9992(PropertyChangeEvent* p0) {
    DefaultTableColumnModel instance;
    instance.propertyChange(p0);
}

void setColumnMargin_test_9993(int p0) {
    DefaultTableColumnModel instance;
    instance.setColumnMargin(p0);
}

void getColumnMargin_test_9994() {
    DefaultTableColumnModel instance;
    instance.getColumnMargin();
}

void getColumn_test_9995(int p0) {
    DefaultTableColumnModel instance;
    instance.getColumn(p0);
}

void removeColumn_test_9996(TableColumn* p0) {
    DefaultTableColumnModel instance;
    instance.removeColumn(p0);
}

void addColumn_test_9997(TableColumn* p0) {
    DefaultTableColumnModel instance;
    instance.addColumn(p0);
}

void getSelectedColumns_test_9998() {
    DefaultTableColumnModel instance;
    instance.getSelectedColumns();
}

void getColumnSelectionAllowed_test_9999() {
    DefaultTableColumnModel instance;
    instance.getColumnSelectionAllowed();
}

void setColumnSelectionAllowed_test_10000(bool p0) {
    DefaultTableColumnModel instance;
    instance.setColumnSelectionAllowed(p0);
}

void getSelectedColumnCount_test_10001() {
    DefaultTableColumnModel instance;
    instance.getSelectedColumnCount();
}

void getColumnIndex_test_10002(Object* p0) {
    DefaultTableColumnModel instance;
    instance.getColumnIndex(p0);
}

void moveColumn_test_10003(int p0, int p1) {
    DefaultTableColumnModel instance;
    instance.moveColumn(p0, p1);
}

void getColumnIndexAtX_test_10004(int p0) {
    DefaultTableColumnModel instance;
    instance.getColumnIndexAtX(p0);
}

void getTotalColumnWidth_test_10005() {
    DefaultTableColumnModel instance;
    instance.getTotalColumnWidth();
}

void removeColumnModelListener_test_10006(TableColumnModelListener* p0) {
    DefaultTableColumnModel instance;
    instance.removeColumnModelListener(p0);
}

void addColumnModelListener_test_10007(TableColumnModelListener* p0) {
    DefaultTableColumnModel instance;
    instance.addColumnModelListener(p0);
}

void valueChanged_test_10008(ListSelectionEvent* p0) {
    DefaultTableColumnModel instance;
    instance.valueChanged(p0);
}

void getSelectionModel_test_10009() {
    DefaultTableColumnModel instance;
    instance.getSelectionModel();
}

void setSelectionModel_test_10010(ListSelectionModel* p0) {
    DefaultTableColumnModel instance;
    instance.setSelectionModel(p0);
}

void getColumnModelListeners_test_10011() {
    DefaultTableColumnModel instance;
    instance.getColumnModelListeners();
}

void getListeners_test_10012(Class p0) {
    DefaultTableColumnModel instance;
    instance.getListeners(p0);
}

void getColumns_test_10013() {
    DefaultTableColumnModel instance;
    instance.getColumns();
}

void getColumnCount_test_10014() {
    DefaultTableColumnModel instance;
    instance.getColumnCount();
}
```