```cpp
#include <string>
#include <vector>

class AccessibleRelation {
private:
    std::string key;
    std::vector<void*> targets;

public:
    AccessibleRelation(const std::string& key) : key(key) {}

    std::string getKey() const {
        return key;
    }

    void* getTarget() const {
        return targets.empty() ? nullptr : targets[0];
    }

    void setTarget(void* target) {
        targets.clear();
        targets.push_back(target);
    }

    void setTarget(const std::vector<void*>& targets) {
        this->targets = targets;
    }
};

// Test function declarations (no test framework, just plain C++ functions)
void getKey_test_5212(const std::string& c0) {
    AccessibleRelation instance(c0);
    instance.getKey();
}

void getTarget_test_5213(const std::string& c0) {
    AccessibleRelation instance(c0);
    instance.getTarget();
}

void setTarget_test_5214(void* p0, const std::string& c0) {
    AccessibleRelation instance(c0);
    instance.setTarget(p0);
}

void setTarget_test_5215(const std::vector<void*>& p0, const std::string& c0) {
    AccessibleRelation instance(c0);
    instance.setTarget(p0);
}
```