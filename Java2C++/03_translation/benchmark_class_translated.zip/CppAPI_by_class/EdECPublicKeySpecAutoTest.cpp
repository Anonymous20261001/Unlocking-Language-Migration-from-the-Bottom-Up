```cpp
#include <utility>

/**
 * Equivalent of java.security.spec.NamedParameterSpec.
 * In Java, it's a named parameter (e.g., "Ed25519").
 * For simplicity, we store the name as a string.
 */
class NamedParameterSpec {
public:
    explicit NamedParameterSpec(std::string name) : name_(std::move(name)) {}

    const std::string& getName() const { return name_; }

private:
    std::string name_;
};

/**
 * Equivalent of java.security.spec.EdECPoint.
 * Represents a point on an Edwards curve with x and y coordinates.
 * In Java, coordinates are BigInteger; here we use long for simplicity.
 */
class EdECPoint {
public:
    EdECPoint(long x, long y) : x_(x), y_(y) {}

    long getX() const { return x_; }
    long getY() const { return y_; }

private:
    long x_;
    long y_;
};

/**
 * Equivalent of java.security.spec.EdECPublicKeySpec.
 * Holds the curve parameters and the public key point.
 */
class EdECPublicKeySpec {
public:
    EdECPublicKeySpec(NamedParameterSpec params, EdECPoint point)
        : params_(std::move(params)), point_(std::move(point)) {}

    /** Returns the EdECPoint (the public key point). */
    const EdECPoint& getPoint() const { return point_; }

    /** Returns the NamedParameterSpec (the curve parameters). */
    const NamedParameterSpec& getParams() const { return params_; }

private:
    NamedParameterSpec params_;
    EdECPoint point_;
};

// Test functions (translated from JUnit @Test methods)

void getPoint_test_2887(NamedParameterSpec c0, EdECPoint c1) {
    EdECPublicKeySpec instance(c0, c1);
    instance.getPoint();
}

void getParams_test_2888(NamedParameterSpec c0, EdECPoint c1) {
    EdECPublicKeySpec instance(c0, c1);
    instance.getParams();
}
```