```cpp
#include <iostream>
#include <memory>

// C++ equivalent of java.awt.ImageCapabilities
class ImageCapabilities {
private:
    bool accelerated;
    bool trueVolatile;

public:
    // Constructor matching Java: ImageCapabilities(boolean)
    explicit ImageCapabilities(bool accelerated) 
        : accelerated(accelerated), trueVolatile(accelerated) {   // In Java, isTrueVolatile seems to always return same as constructor arg? Actually Java's ImageCapabilities constructor sets both flags? According to docs: isTrueVolatile() returns whether the image is true volatile. But from common usage, both flags are often the same. We'll set trueVolatile equal to accelerated for simplicity.
    }

    // Copy constructor (used by clone)
    ImageCapabilities(const ImageCapabilities& other)
        : accelerated(other.accelerated), trueVolatile(other.trueVolatile) {}

    // isAccelerated() - returns boolean
    bool isAccelerated() const {
        return accelerated;
    }

    // isTrueVolatile() - returns boolean
    bool isTrueVolatile() const {
        return trueVolatile;
    }

    // clone() - returns a pointer to a new ImageCapabilities (like Java's Object clone)
    ImageCapabilities* clone() const {
        return new ImageCapabilities(*this);
    }

    // Destructor (for completeness)
    ~ImageCapabilities() = default;
};

// Test functions (exact names as in Java)
void isAccelerated_test_349(bool c0) {
    ImageCapabilities instance(c0);
    instance.isAccelerated();
}

void isTrueVolatile_test_350(bool c0) {
    ImageCapabilities instance(c0);
    instance.isTrueVolatile();
}

void clone_test_351(bool c0) {
    ImageCapabilities instance(c0);
    instance.clone();
}
```