```cpp
#include <vector>
#include <memory>
#include <algorithm>
#include <stdexcept>

// Simple base class mimicking java.awt.Image
class Image {
public:
    virtual ~Image() = default;

    // In Java these are abstract and must be overridden.
    // For our dummy implementation, return -1 to indicate unknown.
    virtual int getWidth() const { return -1; }
    virtual int getHeight() const { return -1; }
};

// C++ implementation of java.awt.image.BaseMultiResolutionImage
class BaseMultiResolutionImage {
public:
    // Constructor: takes a vector of shared_ptr<Image>
    explicit BaseMultiResolutionImage(const std::vector<std::shared_ptr<Image>>& images)
        : variants(images) {}

    // Returns a reference to the stored vector (equivalent to array in Java)
    const std::vector<std::shared_ptr<Image>>& getResolutionVariants() const {
        return variants;
    }

    // Returns the best matching resolution variant for the given dimensions.
    // Simplified logic: returns the first variant that has both width >= destWidth
    // and height >= destHeight. If none, returns the last variant.
    // If the vector is empty, throws an exception (matching Java behavior).
    std::shared_ptr<Image> getResolutionVariant(double destWidth, double destHeight) const {
        if (variants.empty()) {
            throw std::runtime_error("No resolution variants available");
        }

        // Try to find a variant that can accommodate the requested size
        for (const auto& img : variants) {
            if (img->getWidth() >= destWidth && img->getHeight() >= destHeight) {
                return img;
            }
        }

        // Fallback: return the last variant (largest by insertion order)
        return variants.back();
    }

private:
    std::vector<std::shared_ptr<Image>> variants;
};

// --------------------------------------------------------------
// Translated test functions (exact same names and parameter types)
// --------------------------------------------------------------

void getResolutionVariants_test_1046(std::vector<std::shared_ptr<Image>>& c0) {
    BaseMultiResolutionImage instance(c0);
    instance.getResolutionVariants();
}

void getResolutionVariant_test_1047(double p0, double p1, std::vector<std::shared_ptr<Image>>& c0) {
    BaseMultiResolutionImage instance(c0);
    instance.getResolutionVariant(p0, p1);
}
```