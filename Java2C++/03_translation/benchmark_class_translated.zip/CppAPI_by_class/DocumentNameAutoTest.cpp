```cpp
#include <string>
#include <typeinfo>
#include <stdexcept>
#include <iostream>

// Minimal base class to mimic Java's Object
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other;
    }
};

// Simple Locale class representing language, country, variant
class Locale : public Object {
private:
    std::string language;
    std::string country;
    std::string variant;
public:
    // Constructors matching Java Locale
    Locale() : language(""), country(""), variant("") {}
    explicit Locale(const std::string& lang) : language(lang), country(""), variant("") {}
    Locale(const std::string& lang, const std::string& ctry) : language(lang), country(ctry), variant("") {}
    Locale(const std::string& lang, const std::string& ctry, const std::string& var)
        : language(lang), country(ctry), variant(var) {}

    // Accessors
    const std::string& getLanguage() const { return language; }
    const std::string& getCountry() const { return country; }
    const std::string& getVariant() const { return variant; }

    // Equality
    bool operator==(const Locale& other) const {
        return language == other.language && country == other.country && variant == other.variant;
    }
    bool operator!=(const Locale& other) const { return !(*this == other); }

    // String representation (for debugging)
    std::string toString() const {
        std::string result = language;
        if (!country.empty()) {
            result += "_" + country;
            if (!variant.empty()) {
                result += "_" + variant;
            }
        }
        return result;
    }

    // Override Object::equals
    bool equals(const Object& other) const override {
        const Locale* o = dynamic_cast<const Locale*>(&other);
        return o != nullptr && *this == *o;
    }
};

// DocumentName class – equivalent to javax.print.attribute.standard.DocumentName
class DocumentName : public Object {
private:
    std::string name;
    Locale locale;
public:
    DocumentName(const std::string& name, const Locale& locale)
        : name(name), locale(locale) {}

    // Returns a category identifier (mimics Java's getCategory returning class object)
    std::string getCategory() const {
        return "javax.print.attribute.standard.DocumentName";
    }

    // Returns the document name
    std::string getName() const {
        return name;
    }

    // Override Object::equals – compares name and locale
    bool equals(const Object& other) const override {
        const DocumentName* o = dynamic_cast<const DocumentName*>(&other);
        return o != nullptr && name == o->name && locale == o->locale;
    }

    // Convenience (not required but useful)
    bool operator==(const DocumentName& other) const {
        return name == other.name && locale == other.locale;
    }
    bool operator!=(const DocumentName& other) const { return !(*this == other); }
};

// ---------- Translation of the Java test methods ----------

void getCategory_test_6118(const std::string& c0, const Locale& c1) {
    DocumentName instance(c0, c1);
    instance.getCategory();
}

void getName_test_6119(const std::string& c0, const Locale& c1) {
    DocumentName instance(c0, c1);
    instance.getName();
}

void equals_test_6120(const Object& p0, const std::string& c0, const Locale& c1) {
    DocumentName instance(c0, c1);
    instance.equals(p0);
}
```