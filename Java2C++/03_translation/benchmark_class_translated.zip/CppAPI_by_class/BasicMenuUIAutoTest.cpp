```cpp
#include <cstddef>

// Forward declaration
class JComponent;

// Simple Dimension class to mimic java.awt.Dimension
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Minimal JComponent class (like javax.swing.JComponent)
class JComponent {
public:
    // No members needed for the test stubs
};

// BasicMenuUI class mimicking javax.swing.plaf.basic.BasicMenuUI
class BasicMenuUI {
public:
    // Static factory method (returns a new instance, caller owns the pointer)
    static BasicMenuUI* createUI(JComponent* c) {
        return new BasicMenuUI();
    }

    // Instance methods
    Dimension getMaximumSize(JComponent* c) {
        return Dimension();  // default (0,0)
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();  // default (0,0)
    }
};

// Translated test functions (exact names as in Java @Test methods)
void createUI_test_8838(JComponent* p0) {
    BasicMenuUI* instance = new BasicMenuUI();
    BasicMenuUI::createUI(p0);
    delete instance;  // prevent memory leak (not done in Java, but good C++ practice)
}

void getMaximumSize_test_8839(JComponent* p0) {
    BasicMenuUI* instance = new BasicMenuUI();
    instance->getMaximumSize(p0);
    delete instance;
}

void getMinimumSize_test_8840(JComponent* p0) {
    BasicMenuUI* instance = new BasicMenuUI();
    instance->getMinimumSize(p0);
    delete instance;
}
```