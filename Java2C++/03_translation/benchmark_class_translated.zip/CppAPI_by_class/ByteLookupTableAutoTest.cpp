```cpp
#include <vector>
#include <cstdint>
#include <stdexcept>

using byte = int8_t;

class ByteLookupTable {
private:
    int offset;
    std::vector<std::vector<byte>> table;

public:
    ByteLookupTable(int offset, const std::vector<std::vector<byte>>& table)
        : offset(offset), table(table) {}

    void lookupPixel(const std::vector<byte>& src, std::vector<byte>& dest) {
        if (src.size() != dest.size()) {
            throw std::invalid_argument("src and dest must have the same length");
        }
        for (size_t i = 0; i < src.size(); ++i) {
            int idx = static_cast<int>(src[i]) + offset;
            if (idx < 0 || static_cast<size_t>(idx) >= table[i].size()) {
                throw std::out_of_range("Index out of bounds in lookup table");
            }
            dest[i] = table[i][idx];
        }
    }

    void lookupPixel(const std::vector<int>& src, std::vector<int>& dest) {
        if (src.size() != dest.size()) {
            throw std::invalid_argument("src and dest must have the same length");
        }
        for (size_t i = 0; i < src.size(); ++i) {
            int idx = src[i] + offset;
            if (idx < 0 || static_cast<size_t>(idx) >= table[i].size()) {
                throw std::out_of_range("Index out of bounds in lookup table");
            }
            dest[i] = static_cast<int>(table[i][idx]);
        }
    }

    const std::vector<std::vector<byte>>& getTable() const {
        return table;
    }
};

// Test functions (equivalent to the Java @Test methods)

void lookupPixel_test_1101(const std::vector<byte>& p0, std::vector<byte>& p1,
                           int c0, const std::vector<std::vector<byte>>& c1) {
    ByteLookupTable instance(c0, c1);
    instance.lookupPixel(p0, p1);
}

void lookupPixel_test_1102(const std::vector<int>& p0, std::vector<int>& p1,
                           int c0, const std::vector<std::vector<byte>>& c1) {
    ByteLookupTable instance(c0, c1);
    instance.lookupPixel(p0, p1);
}

void getTable_test_1103(int c0, const std::vector<std::vector<byte>>& c1) {
    ByteLookupTable instance(c0, c1);
    instance.getTable();
}
```