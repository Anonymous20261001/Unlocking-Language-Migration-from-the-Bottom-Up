```cpp
#include <string>
#include <vector>
#include <unordered_map>

// C++ equivalent of javax.swing.text.html.parser.Entity
class Entity {
public:
    static const int INVALID = 0;
    static const int GENERAL = 1;
    static const int PARAMETER = 2;

private:
    std::string name;
    int type;
    std::vector<char> data;

    // Static map for name2type (simulating HTML entity lookup)
    static const std::unordered_map<std::string, int>& typeMap() {
        static const std::unordered_map<std::string, int> map = {
            {"amp", GENERAL},
            {"lt", GENERAL},
            {"gt", GENERAL},
            {"quot", GENERAL},
            {"apos", GENERAL}
        };
        return map;
    }

public:
    Entity(const std::string& name, int type, const std::vector<char>& data)
        : name(name), type(type), data(data) {}

    static int name2type(const std::string& name) {
        auto it = typeMap().find(name);
        return (it != typeMap().end()) ? it->second : INVALID;
    }

    std::string getName() const { return name; }
    int getType() const { return type; }
    bool isParameter() const { return type == PARAMETER; }
    bool isGeneral() const { return type == GENERAL; }
    std::string getString() const {
        return (type == PARAMETER) ? ("%" + name + ";") : ("&" + name + ";");
    }
    std::vector<char> getData() const { return data; }
};

// Test functions (exact names as in the Java test file)
void name2type_test_10582(const std::string& p0, const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    Entity::name2type(p0);
}

void getName_test_10583(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.getName();
}

void getType_test_10584(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.getType();
}

void isParameter_test_10585(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.isParameter();
}

void getString_test_10586(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.getString();
}

void isGeneral_test_10587(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.isGeneral();
}

void getData_test_10588(const std::string& c0, int c1, const std::vector<char>& c2) {
    Entity instance(c0, c1, c2);
    instance.getData();
}
```