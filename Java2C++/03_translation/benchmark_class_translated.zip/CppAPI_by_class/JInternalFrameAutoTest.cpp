```cpp
#include <string>
#include <vector>
#include <cstdint>
#include <memory>

// Forward declarations for classes that will be used as pointers or references
class Component;
class Container;
class Cursor;
class LayoutManager;
class Rectangle;
class Icon;
class InternalFrameListener;
class InternalFrameUI;
class JMenuBar;
class JLayeredPane;
class JDesktopIcon;

// Minimal Integer wrapper (to support both int and Integer overloads)
class Integer {
public:
    int value;
    Integer(int v) : value(v) {}
    Integer() : value(0) {}
    int intValue() const { return value; }
};

// Minimal Rectangle
class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
    Rectangle(int x, int y, int w, int h) : x(x), y(y), width(w), height(h) {}
};

// Minimal Component
class Component {
public:
    virtual ~Component() = default;
    // add other methods if needed
};

// Container extends Component
class Container : public Component {
public:
    virtual ~Container() = default;
};

// Cursor
class Cursor {
public:
    int type;
    Cursor(int t) : type(t) {}
    Cursor() : type(0) {}
};

// LayoutManager
class LayoutManager {
public:
    virtual ~LayoutManager() = default;
};

// Icon
class Icon {
public:
    virtual ~Icon() = default;
};

// InternalFrameListener
class InternalFrameListener {
public:
    virtual ~InternalFrameListener() = default;
    // event methods (not needed for test)
};

// InternalFrameUI
class InternalFrameUI {
public:
    virtual ~InternalFrameUI() = default;
};

// JMenuBar
class JMenuBar {
public:
    virtual ~JMenuBar() = default;
};

// JLayeredPane extends Container
class JLayeredPane : public Container {
public:
    virtual ~JLayeredPane() = default;
};

// JDesktopIcon (nested class of JInternalFrame, but we define it separately)
class JDesktopIcon : public Component {
public:
    JInternalFrame* internalFrame;
    JDesktopIcon() : internalFrame(nullptr) {}
    void setInternalFrame(JInternalFrame* f) { internalFrame = f; }
    JInternalFrame* getInternalFrame() { return internalFrame; }
};

// Main JInternalFrame class
class JInternalFrame {
private:
    int defaultCloseOperation;
    InternalFrameUI* ui;
    JDesktopIcon* desktopIcon;
    bool iconable;
    bool maximizable;
    bool closable;
    Icon* frameIcon;
    Cursor* lastCursor;
    std::vector<InternalFrameListener*> internalFrameListeners;
    JMenuBar* menuBar;
    Container* contentPane;
    JLayeredPane* layeredPane;
    Component* glassPane;
    LayoutManager* layoutManager;
    bool focusCycleRoot;
    bool resizable;
    std::string title;
    int layer;
    bool selected;
    bool closed;
    Rectangle normalBounds;
    // other internal state

public:
    JInternalFrame() 
        : defaultCloseOperation(0), ui(nullptr), desktopIcon(new JDesktopIcon()),
          iconable(false), maximizable(false), closable(false), frameIcon(nullptr),
          lastCursor(nullptr), menuBar(nullptr), contentPane(new Container()),
          layeredPane(new JLayeredPane()), glassPane(new Component()),
          layoutManager(nullptr), focusCycleRoot(false), resizable(true),
          title(""), layer(0), selected(false), closed(false), normalBounds() 
    {
        // desktop icon needs reference back
        desktopIcon->setInternalFrame(this);
    }

    ~JInternalFrame() {
        delete desktopIcon;
        delete contentPane;
        delete layeredPane;
        delete glassPane;
        // other pointers are not owned (UI, listeners, etc.)
    }

    void setDefaultCloseOperation(int op) { defaultCloseOperation = op; }
    int getDefaultCloseOperation() const { return defaultCloseOperation; }

    std::string getUIClassID() const { return "InternalFrameUI"; }
    InternalFrameUI* getUI() const { return ui; }
    void setUI(InternalFrameUI* u) { ui = u; }

    JDesktopIcon* getDesktopIcon() const { return desktopIcon; }
    Container* getDesktopPane() const { return nullptr; } // stub

    Rectangle getNormalBounds() const { return normalBounds; }
    void setNormalBounds(const Rectangle& r) { normalBounds = r; }

    bool isIcon() const { return false; } // stub
    void restoreSubcomponentFocus() {} 

    bool isMaximum() const { return false; } // stub

    void setClosable(bool b) { closable = b; }
    bool isClosable() const { return closable; }

    void setIconifiable(bool b) { iconable = b; }
    bool isIconifiable() const { return iconable; }

    void setMaximizable(bool b) { maximizable = b; }
    bool isMaximizable() const { return maximizable; }

    void setFrameIcon(Icon* icon) { frameIcon = icon; }
    Icon* getFrameIcon() const { return frameIcon; }

    Cursor* getLastCursor() const { return lastCursor; }
    void setDesktopIcon(JDesktopIcon* icon) { 
        delete desktopIcon;
        desktopIcon = icon;
        if (desktopIcon) desktopIcon->setInternalFrame(this);
    }

    void addInternalFrameListener(InternalFrameListener* l) { internalFrameListeners.push_back(l); }
    void removeInternalFrameListener(InternalFrameListener* l) {
        auto it = std::find(internalFrameListeners.begin(), internalFrameListeners.end(), l);
        if (it != internalFrameListeners.end()) internalFrameListeners.erase(it);
    }
    std::vector<InternalFrameListener*> getInternalFrameListeners() const { return internalFrameListeners; }

    void doDefaultCloseAction() {}

    void setJMenuBar(JMenuBar* mb) { menuBar = mb; }
    JMenuBar* getJMenuBar() const { return menuBar; }

    void setContentPane(Container* c) { delete contentPane; contentPane = c; }
    void setLayeredPane(JLayeredPane* lp) { delete layeredPane; layeredPane = lp; }

    Component* getGlassPane() const { return glassPane; }
    void setGlassPane(Component* c) { delete glassPane; glassPane = c; }

    void moveToBack() {}
    void setLayer(Integer layer) { this->layer = layer.intValue(); }
    void setLayer(int l) { this->layer = l; }
    int getLayer() const { return layer; }

    void* getAccessibleContext() const { return nullptr; } // stub

    void setLayout(LayoutManager* lm) { layoutManager = lm; }

    bool isFocusCycleRoot() const { return focusCycleRoot; }
    Component* getFocusOwner() const { return nullptr; }
    Component* getMostRecentFocusOwner() const { return nullptr; }
    Container* getFocusCycleRootAncestor() const { return nullptr; }
    void setFocusCycleRoot(bool b) { focusCycleRoot = b; }

    void show() {}
    void hide() {}
    void reshape(int x, int y, int w, int h) {}

    void setCursor(Cursor* c) { lastCursor = c; }

    void updateUI() {}

    void setTitle(const std::string& t) { title = t; }
    std::string getTitle() const { return title; }

    void toFront() {}
    void toBack() {}

    void setResizable(bool b) { resizable = b; }
    bool isResizable() const { return resizable; }

    Container* getRootPane() const { return nullptr; } // stub
    JLayeredPane* getLayeredPane() const { return layeredPane; }
    Container* getContentPane() const { return contentPane; }

    void pack() {}

    std::string getWarningString() const { return ""; }

    void setMenuBar(JMenuBar* mb) { menuBar = mb; }
    JMenuBar* getMenuBar() const { return menuBar; }

    bool isSelected() const { return selected; }
    void remove(Component* /* comp */) {} // stub

    void dispose() { closed = true; }
    void moveToFront() {}
    bool isClosed() const { return closed; }
};

// ========================
// Test functions (translated from Java @Test methods)
// ========================

void setDefaultCloseOperation_test_7091(int p0) {
    JInternalFrame instance;
    instance.setDefaultCloseOperation(p0);
}

void getDefaultCloseOperation_test_7092() {
    JInternalFrame instance;
    instance.getDefaultCloseOperation();
}

void getUIClassID_test_7093() {
    JInternalFrame instance;
    instance.getUIClassID();
}

void getUI_test_7094() {
    JInternalFrame instance;
    instance.getUI();
}

void setUI_test_7095(InternalFrameUI* p0) {
    JInternalFrame instance;
    instance.setUI(p0);
}

void getDesktopIcon_test_7096() {
    JInternalFrame instance;
    instance.getDesktopIcon();
}

void getDesktopPane_test_7097() {
    JInternalFrame instance;
    instance.getDesktopPane();
}

void getNormalBounds_test_7098() {
    JInternalFrame instance;
    instance.getNormalBounds();
}

void setNormalBounds_test_7099(Rectangle p0) {
    JInternalFrame instance;
    instance.setNormalBounds(p0);
}

void isIcon_test_7100() {
    JInternalFrame instance;
    instance.isIcon();
}

void restoreSubcomponentFocus_test_7101() {
    JInternalFrame instance;
    instance.restoreSubcomponentFocus();
}

void isMaximum_test_7102() {
    JInternalFrame instance;
    instance.isMaximum();
}

void setClosable_test_7103(bool p0) {
    JInternalFrame instance;
    instance.setClosable(p0);
}

void isClosable_test_7104() {
    JInternalFrame instance;
    instance.isClosable();
}

void setIconifiable_test_7105(bool p0) {
    JInternalFrame instance;
    instance.setIconifiable(p0);
}

void isIconifiable_test_7106() {
    JInternalFrame instance;
    instance.isIconifiable();
}

void setMaximizable_test_7107(bool p0) {
    JInternalFrame instance;
    instance.setMaximizable(p0);
}

void isMaximizable_test_7108() {
    JInternalFrame instance;
    instance.isMaximizable();
}

void setFrameIcon_test_7109(Icon* p0) {
    JInternalFrame instance;
    instance.setFrameIcon(p0);
}

void getFrameIcon_test_7110() {
    JInternalFrame instance;
    instance.getFrameIcon();
}

void getLastCursor_test_7111() {
    JInternalFrame instance;
    instance.getLastCursor();
}

void setDesktopIcon_test_7112(JDesktopIcon* p0) {
    JInternalFrame instance;
    instance.setDesktopIcon(p0);
}

void addInternalFrameListener_test_7113(InternalFrameListener* p0) {
    JInternalFrame instance;
    instance.addInternalFrameListener(p0);
}

void removeInternalFrameListener_test_7114(InternalFrameListener* p0) {
    JInternalFrame instance;
    instance.removeInternalFrameListener(p0);
}

void getInternalFrameListeners_test_7115() {
    JInternalFrame instance;
    instance.getInternalFrameListeners();
}

void doDefaultCloseAction_test_7116() {
    JInternalFrame instance;
    instance.doDefaultCloseAction();
}

void setJMenuBar_test_7117(JMenuBar* p0) {
    JInternalFrame instance;
    instance.setJMenuBar(p0);
}

void getJMenuBar_test_7118() {
    JInternalFrame instance;
    instance.getJMenuBar();
}

void setContentPane_test_7119(Container* p0) {
    JInternalFrame instance;
    instance.setContentPane(p0);
}

void setLayeredPane_test_7120(JLayeredPane* p0) {
    JInternalFrame instance;
    instance.setLayeredPane(p0);
}

void getGlassPane_test_7121() {
    JInternalFrame instance;
    instance.getGlassPane();
}

void setGlassPane_test_7122(Component* p0) {
    JInternalFrame instance;
    instance.setGlassPane(p0);
}

void moveToBack_test_7123() {
    JInternalFrame instance;
    instance.moveToBack();
}

void setLayer_test_7124(Integer p0) {
    JInternalFrame instance;
    instance.setLayer(p0);
}

void setLayer_test_7125(int p0) {
    JInternalFrame instance;
    instance.setLayer(p0);
}

void getAccessibleContext_test_7126() {
    JInternalFrame instance;
    instance.getAccessibleContext();
}

void setLayout_test_7127(LayoutManager* p0) {
    JInternalFrame instance;
    instance.setLayout(p0);
}

void isFocusCycleRoot_test_7128() {
    JInternalFrame instance;
    instance.isFocusCycleRoot();
}

void getFocusOwner_test_7129() {
    JInternalFrame instance;
    instance.getFocusOwner();
}

void getMostRecentFocusOwner_test_7130() {
    JInternalFrame instance;
    instance.getMostRecentFocusOwner();
}

void getFocusCycleRootAncestor_test_7131() {
    JInternalFrame instance;
    instance.getFocusCycleRootAncestor();
}

void setFocusCycleRoot_test_7132(bool p0) {
    JInternalFrame instance;
    instance.setFocusCycleRoot(p0);
}

void show_test_7133() {
    JInternalFrame instance;
    instance.show();
}

void hide_test_7134() {
    JInternalFrame instance;
    instance.hide();
}

void reshape_test_7135(int p0, int p1, int p2, int p3) {
    JInternalFrame instance;
    instance.reshape(p0, p1, p2, p3);
}

void setCursor_test_7136(Cursor* p0) {
    JInternalFrame instance;
    instance.setCursor(p0);
}

void updateUI_test_7137() {
    JInternalFrame instance;
    instance.updateUI();
}

void setTitle_test_7138(std::string p0) {
    JInternalFrame instance;
    instance.setTitle(p0);
}

void toFront_test_7139() {
    JInternalFrame instance;
    instance.toFront();
}

void toBack_test_7140() {
    JInternalFrame instance;
    instance.toBack();
}

void setResizable_test_7141(bool p0) {
    JInternalFrame instance;
    instance.setResizable(p0);
}

void getTitle_test_7142() {
    JInternalFrame instance;
    instance.getTitle();
}

void isResizable_test_7143() {
    JInternalFrame instance;
    instance.isResizable();
}

void getRootPane_test_7144() {
    JInternalFrame instance;
    instance.getRootPane();
}

void getLayeredPane_test_7145() {
    JInternalFrame instance;
    instance.getLayeredPane();
}

void getContentPane_test_7146() {
    JInternalFrame instance;
    instance.getContentPane();
}

void pack_test_7147() {
    JInternalFrame instance;
    instance.pack();
}

void getWarningString_test_7148() {
    JInternalFrame instance;
    instance.getWarningString();
}

void setMenuBar_test_7149(JMenuBar* p0) {
    JInternalFrame instance;
    instance.setMenuBar(p0);
}

void getMenuBar_test_7150() {
    JInternalFrame instance;
    instance.getMenuBar();
}

void isSelected_test_7151() {
    JInternalFrame instance;
    instance.isSelected();
}

void remove_test_7152(Component* p0) {
    JInternalFrame instance;
    instance.remove(p0);
}

void getLayer_test_7153() {
    JInternalFrame instance;
    instance.getLayer();
}

void dispose_test_7154() {
    JInternalFrame instance;
    instance.dispose();
}

void moveToFront_test_7155() {
    JInternalFrame instance;
    instance.moveToFront();
}

void isClosed_test_7156() {
    JInternalFrame instance;
    instance.isClosed();
}
```