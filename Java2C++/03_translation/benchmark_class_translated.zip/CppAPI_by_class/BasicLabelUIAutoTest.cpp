```cpp
#include <cstdint>

// Forward declarations for classes used
class PropertyChangeEvent;
class JComponent;
class Graphics;

// Enum for baseline resize behavior (mimics JComponent.BaselineResizeBehavior)
enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Stub Graphics class
class Graphics {
public:
    virtual ~Graphics() = default;
    // No real methods needed for these tests
};

// Stub PropertyChangeEvent class
class PropertyChangeEvent {
public:
    PropertyChangeEvent(void* source, const char* propertyName,
                        void* oldValue, void* newValue)
        : source_(source), propertyName_(propertyName),
          oldValue_(oldValue), newValue_(newValue) {}
    virtual ~PropertyChangeEvent() = default;
private:
    void* source_;
    const char* propertyName_;
    void* oldValue_;
    void* newValue_;
};

// Stub JComponent class
class JComponent {
public:
    virtual ~JComponent() = default;
    // Minimum stubs for the tests to compile
    int getWidth() const { return 0; }
    int getHeight() const { return 0; }
};

// BasicLabelUI – stub implementation matching Java API
class BasicLabelUI {
public:
    BasicLabelUI() = default;
    ~BasicLabelUI() = default;

    void propertyChange(PropertyChangeEvent* p0) {
        // No-op, just like the test (no assertion)
        (void)p0;
    }

    void installUI(JComponent* c) {
        (void)c;
    }

    void uninstallUI(JComponent* c) {
        (void)c;
    }

    static BasicLabelUI* createUI(JComponent* c) {
        (void)c;
        // In Swing, createUI often returns a shared instance.
        // For simplicity, return a new instance (or static).
        static BasicLabelUI instance;
        return &instance;
    }

    // getMaximumSize is supposed to return Dimension, but test ignores return.
    // We'll just return a nullptr or default, but the signature should match.
    // Since Java method returns a Dimension, we can return a fake pointer.
    // For simplicity, we return the same instance each time (like a shared object).
    void* getMaximumSize(JComponent* c) {
        (void)c;
        return nullptr; // No actual object needed
    }

    void paint(Graphics* g, JComponent* c) {
        (void)g;
        (void)c;
    }

    void* getPreferredSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    void* getMinimumSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    int getBaseline(JComponent* c, int width, int height) {
        (void)c;
        (void)width;
        (void)height;
        return 0; // Typically the baseline
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* c) {
        (void)c;
        return BaselineResizeBehavior::CONSTANT_ASCENT;
    }
};

// Test functions (exact names as in Java @Test methods, with C++ signatures)

void propertyChange_test_8804(PropertyChangeEvent* p0) {
    BasicLabelUI instance;
    instance.propertyChange(p0);
}

void installUI_test_8805(JComponent* p0) {
    BasicLabelUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8806(JComponent* p0) {
    BasicLabelUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8807(JComponent* p0) {
    BasicLabelUI instance;
    BasicLabelUI::createUI(p0); // static call
}

void getMaximumSize_test_8808(JComponent* p0) {
    BasicLabelUI instance;
    instance.getMaximumSize(p0);
}

void paint_test_8809(Graphics* p0, JComponent* p1) {
    BasicLabelUI instance;
    instance.paint(p0, p1);
}

void getPreferredSize_test_8810(JComponent* p0) {
    BasicLabelUI instance;
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8811(JComponent* p0) {
    BasicLabelUI instance;
    instance.getMinimumSize(p0);
}

void getBaseline_test_8812(JComponent* p0, int p1, int p2) {
    BasicLabelUI instance;
    instance.getBaseline(p0, p1, p2);
}

void getBaselineResizeBehavior_test_8813(JComponent* p0) {
    BasicLabelUI instance;
    instance.getBaselineResizeBehavior(p0);
}
```