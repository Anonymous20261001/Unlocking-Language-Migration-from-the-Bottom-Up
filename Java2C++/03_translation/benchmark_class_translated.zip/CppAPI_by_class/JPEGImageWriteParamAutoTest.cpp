```cpp
#include <vector>
#include <string>
#include <cstdint>
#include <stdexcept>

// Minimal Locale class – only needed for constructor signature
class Locale {
public:
    Locale() = default;
    Locale(const Locale&) = default;
    // In real Java, Locale has more fields, but they are not used in the tests.
};

// JPEGQTable – represents a quantization table (64 ints)
class JPEGQTable {
public:
    // Java: JPEGQTable(int[] table) expects 64 elements.
    explicit JPEGQTable(const std::vector<int>& table) {
        if (table.size() != 64) {
            throw std::invalid_argument("JPEGQTable requires exactly 64 values");
        }
        data_ = table;
    }

    // Default constructor for empty table (needed for storage)
    JPEGQTable() : data_(64, 0) {}

    const std::vector<int>& getData() const { return data_; }

private:
    std::vector<int> data_;
};

// JPEGHuffmanTable – represents a Huffman table (DC or AC)
class JPEGHuffmanTable {
public:
    // Java: JPEGHuffmanTable(int[] lengths, int[] values)
    JPEGHuffmanTable(const std::vector<int>& lengths, const std::vector<int>& values)
        : lengths_(lengths), values_(values) {}

    // Default constructor for empty table
    JPEGHuffmanTable() = default;

    const std::vector<int>& getLengths() const { return lengths_; }
    const std::vector<int>& getValues() const { return values_; }

private:
    std::vector<int> lengths_;
    std::vector<int> values_;
};

// JPEGImageWriteParam – implementation of the Java class
class JPEGImageWriteParam {
public:
    // Constructor that accepts a Locale (Java constructor signature)
    explicit JPEGImageWriteParam(const Locale& /*locale*/) {
        // In Java, the locale is used for error messages; we ignore it.
        compressionLossless_ = false; // JPEG is lossy
        tablesSet_ = false;
        optimizeHuffman_ = false;
        compressionMode_ = MODE_DEFAULT; // artificial constant
    }

    // ---------- Methods from the tests ----------

    void unsetCompression() {
        // Java: sets compression mode to MODE_DISABLED
        // We'll just set a flag.
        compressionMode_ = MODE_DISABLED;
    }

    bool isCompressionLossless() const {
        // JPEG is lossy, so normally false
        return compressionLossless_;
    }

    std::vector<std::string> getCompressionQualityDescriptions() const {
        // Java: returns an array of Strings describing quality levels.
        // JPEGImageWriteParam has default descriptions; we return empty.
        return {};
    }

    std::vector<float> getCompressionQualityValues() const {
        // Java: returns an array of float values.
        // JPEGImageWriteParam has default values; we return empty.
        return {};
    }

    bool areTablesSet() const {
        return tablesSet_;
    }

    std::vector<JPEGQTable> getQTables() const {
        if (!tablesSet_) {
            // Java: returns null if not set. In C++ we return empty vector.
            return {};
        }
        return qTables_;
    }

    std::vector<JPEGHuffmanTable> getDCHuffmanTables() const {
        if (!tablesSet_) {
            return {};
        }
        return dcHuffmanTables_;
    }

    std::vector<JPEGHuffmanTable> getACHuffmanTables() const {
        if (!tablesSet_) {
            return {};
        }
        return acHuffmanTables_;
    }

    void setEncodeTables(const std::vector<JPEGQTable>& qTables,
                         const std::vector<JPEGHuffmanTable>& dcTables,
                         const std::vector<JPEGHuffmanTable>& acTables) {
        // Java: copies the arrays, sets the 'tablesSet' flag.
        qTables_ = qTables;
        dcHuffmanTables_ = dcTables;
        acHuffmanTables_ = acTables;
        tablesSet_ = true;
    }

    void unsetEncodeTables() {
        tablesSet_ = false;
        qTables_.clear();
        dcHuffmanTables_.clear();
        acHuffmanTables_.clear();
    }

    void setOptimizeHuffmanTables(bool optimize) {
        optimizeHuffman_ = optimize;
    }

    bool getOptimizeHuffmanTables() const {
        return optimizeHuffman_;
    }

private:
    // Artificial constants for compression mode (not part of Java API but for internal)
    enum CompressionMode { MODE_DEFAULT, MODE_DISABLED };

    bool compressionLossless_;
    bool tablesSet_;
    bool optimizeHuffman_;
    int compressionMode_;

    std::vector<JPEGQTable> qTables_;
    std::vector<JPEGHuffmanTable> dcHuffmanTables_;
    std::vector<JPEGHuffmanTable> acHuffmanTables_;
};

// ---------- Test functions (exact translation of JUnit @Test methods) ----------

void unsetCompression_test_5401(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.unsetCompression();
}

void isCompressionLossless_test_5402(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.isCompressionLossless();
}

void getCompressionQualityDescriptions_test_5403(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getCompressionQualityDescriptions();
}

void getCompressionQualityValues_test_5404(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getCompressionQualityValues();
}

void areTablesSet_test_5405(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.areTablesSet();
}

void getQTables_test_5406(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getQTables();
}

void getDCHuffmanTables_test_5407(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getDCHuffmanTables();
}

void getACHuffmanTables_test_5408(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getACHuffmanTables();
}

void setEncodeTables_test_5409(std::vector<JPEGQTable> p0,
                               std::vector<JPEGHuffmanTable> p1,
                               std::vector<JPEGHuffmanTable> p2,
                               Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.setEncodeTables(p0, p1, p2);
}

void unsetEncodeTables_test_5410(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.unsetEncodeTables();
}

void setOptimizeHuffmanTables_test_5411(bool p0, Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.setOptimizeHuffmanTables(p0);
}

void getOptimizeHuffmanTables_test_5412(Locale c0) {
    JPEGImageWriteParam instance(c0);
    instance.getOptimizeHuffmanTables();
}
```