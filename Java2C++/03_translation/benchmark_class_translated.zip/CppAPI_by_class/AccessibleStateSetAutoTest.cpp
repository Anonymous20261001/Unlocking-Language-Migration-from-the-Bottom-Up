```cpp
#include <set>
#include <vector>
#include <string>
#include <sstream>

class AccessibleState {
public:
    std::string name;

    AccessibleState() : name("") {}
    explicit AccessibleState(const std::string& name) : name(name) {}

    bool operator==(const AccessibleState& other) const {
        return name == other.name;
    }
    bool operator<(const AccessibleState& other) const {
        return name < other.name;
    }
};

class AccessibleStateSet {
private:
    std::set<AccessibleState> states;

public:
    bool add(const AccessibleState& state) {
        return states.insert(state).second;
    }

    bool remove(const AccessibleState& state) {
        return states.erase(state) > 0;
    }

    bool contains(const AccessibleState& state) const {
        return states.find(state) != states.end();
    }

    void clear() {
        states.clear();
    }

    std::vector<AccessibleState> toArray() const {
        return std::vector<AccessibleState>(states.begin(), states.end());
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "[";
        bool first = true;
        for (const auto& s : states) {
            if (!first) oss << ", ";
            oss << s.name;
            first = false;
        }
        oss << "]";
        return oss.str();
    }

    bool addAll(const std::vector<AccessibleState>& arr) {
        bool changed = false;
        for (const auto& s : arr) {
            if (add(s)) changed = true;
        }
        return changed;
    }
};

// Test functions
void remove_test_5226(const AccessibleState& p0) {
    AccessibleStateSet instance;
    instance.remove(p0);
}

void toString_test_5227() {
    AccessibleStateSet instance;
    instance.toString();
}

void clear_test_5228() {
    AccessibleStateSet instance;
    instance.clear();
}

void add_test_5229(const AccessibleState& p0) {
    AccessibleStateSet instance;
    instance.add(p0);
}

void toArray_test_5230() {
    AccessibleStateSet instance;
    instance.toArray();
}

void contains_test_5231(const AccessibleState& p0) {
    AccessibleStateSet instance;
    instance.contains(p0);
}

void addAll_test_5232(const std::vector<AccessibleState>& p0) {
    AccessibleStateSet instance;
    instance.addAll(p0);
}
```