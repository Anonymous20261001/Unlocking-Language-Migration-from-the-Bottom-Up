```cpp
#include <iostream>
#include <cstring>

// Base class equivalent to java.lang.Throwable
class Throwable {
public:
    virtual const char* what() const noexcept { return "Throwable"; }
    virtual ~Throwable() = default;
};

// Exception class equivalent to java.lang.reflect.InvocationTargetException
class InvocationTargetException : public Throwable {
private:
    Throwable* cause_;  // non-owning pointer for simplicity
public:
    InvocationTargetException(Throwable* cause) : cause_(cause) {}

    Throwable* getCause() const {
        return cause_;
    }

    Throwable* getTargetException() const {
        return cause_;
    }

    const char* what() const noexcept override {
        return "InvocationTargetException";
    }
};

// Test functions (translation of the @Test methods)
void getCause_test_2423(Throwable* c0) {
    InvocationTargetException instance(c0);
    instance.getCause();
}

void getTargetException_test_2424(Throwable* c0) {
    InvocationTargetException instance(c0);
    instance.getTargetException();
}

// Simple main to run the tests (not required but makes it self-contained)
int main() {
    Throwable dummy;
    getCause_test_2423(&dummy);
    getTargetException_test_2424(&dummy);
    std::cout << "All tests passed (no crashes)." << std::endl;
    return 0;
}
```