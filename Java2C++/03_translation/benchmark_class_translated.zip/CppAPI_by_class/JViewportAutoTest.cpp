```cpp
#include <vector>
#include <string>
#include <algorithm>
#include <cstdint>
#include <cstddef>

//-----------------------------------------------------------------------------
// Minimal stubs for java.awt classes
//-----------------------------------------------------------------------------

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class Point {
public:
    int x;
    int y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class Rectangle {
public:
    int x;
    int y;
    int width;
    int height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
    Rectangle(int x, int y, int w, int h) : x(x), y(y), width(w), height(h) {}
};

class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
    Insets(int t, int l, int b, int r) : top(t), left(l), bottom(b), right(r) {}
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class Component {
public:
    virtual ~Component() = default;
    // Minimal stubs for methods used by JViewport
    virtual void repaint(long tm, int x, int y, int w, int h) {}
    virtual void reshape(int x, int y, int w, int h) {}
    virtual void remove(Component* comp) {}
    virtual void paint(Graphics* g) {}
    // Others not needed for tests
};

//-----------------------------------------------------------------------------
// Stub for javax.swing.border.Border
//-----------------------------------------------------------------------------

class Border {
public:
    virtual ~Border() = default;
};

//-----------------------------------------------------------------------------
// Stub for javax.swing.event.ChangeListener and ChangeEvent
//-----------------------------------------------------------------------------

class ChangeEvent {
public:
    // Minimal event stub, not used in tests
};

class ChangeListener {
public:
    virtual ~ChangeListener() = default;
    virtual void stateChanged(ChangeEvent* e) = 0;
};

//-----------------------------------------------------------------------------
// Stub for javax.swing.plaf.ViewportUI
//-----------------------------------------------------------------------------

class ViewportUI {
public:
    virtual ~ViewportUI() = default;
};

//-----------------------------------------------------------------------------
// JViewport implementation (stub with state)
//-----------------------------------------------------------------------------

class JViewport : public Component {
private:
    bool optimizedDrawingEnabled_;
    bool backingStoreEnabled_;
    int scrollMode_;
    Point viewPosition_;
    Dimension extentSize_;
    Dimension viewSize_;
    ViewportUI* ui_;
    Border* border_;
    Component* view_;
    std::vector<ChangeListener*> changeListeners_;

public:
    JViewport()
        : optimizedDrawingEnabled_(false),
          backingStoreEnabled_(false),
          scrollMode_(0),
          viewPosition_(0, 0),
          extentSize_(0, 0),
          viewSize_(0, 0),
          ui_(nullptr),
          border_(nullptr),
          view_(nullptr) {}

    bool isOptimizedDrawingEnabled() const { return optimizedDrawingEnabled_; }

    void scrollRectToVisible(const Rectangle& r) {
        // stub
    }

    std::string getUIClassID() const {
        return "ViewportUI";
    }

    ViewportUI* getUI() const { return ui_; }

    void setUI(ViewportUI* ui) { ui_ = ui; }

    void setBorder(Border* border) { border_ = border; }

    Point getViewPosition() const { return viewPosition_; }

    Dimension getExtentSize() const { return extentSize_; }

    void setScrollMode(int mode) { scrollMode_ = mode; }

    int getScrollMode() const { return scrollMode_; }

    bool isBackingStoreEnabled() const { return backingStoreEnabled_; }

    void setBackingStoreEnabled(bool enabled) { backingStoreEnabled_ = enabled; }

    Dimension getViewSize() const { return viewSize_; }

    void setViewSize(const Dimension& size) { viewSize_ = size; }

    Rectangle getViewRect() const {
        return Rectangle(viewPosition_.x, viewPosition_.y, extentSize_.width, extentSize_.height);
    }

    Dimension toViewCoordinates(const Dimension& d) const {
        return d;
    }

    Point toViewCoordinates(const Point& p) const {
        return p;
    }

    void setExtentSize(const Dimension& size) { extentSize_ = size; }

    void setViewPosition(const Point& pos) { viewPosition_ = pos; }

    void addChangeListener(ChangeListener* listener) {
        changeListeners_.push_back(listener);
    }

    void removeChangeListener(ChangeListener* listener) {
        auto it = std::find(changeListeners_.begin(), changeListeners_.end(), listener);
        if (it != changeListeners_.end())
            changeListeners_.erase(it);
    }

    std::vector<ChangeListener*> getChangeListeners() const {
        return changeListeners_;
    }

    void setView(Component* comp) { view_ = comp; }

    Component* getView() const { return view_; }

    void* getAccessibleContext() const { return nullptr; } // stub

    Insets getInsets(const Insets& in) const {
        return in; // simply returns the passed insets (Java's getInsets copies)
    }

    Insets getInsets() const {
        return Insets(0, 0, 0, 0);
    }

    // override base class paint/repaint/reshape/remove with stubs
    void paint(Graphics* g) override {}
    void repaint(long tm, int x, int y, int w, int h) override {}
    void reshape(int x, int y, int w, int h) override {}
    void updateUI() {}

    void remove(Component* comp) override {
        // stub: not implemented
    }
};

//-----------------------------------------------------------------------------
// Test functions (translated one-to-one from Java @Test methods)
//-----------------------------------------------------------------------------

void isOptimizedDrawingEnabled_test_8146() {
    JViewport instance;
    instance.isOptimizedDrawingEnabled();
}

void scrollRectToVisible_test_8147(Rectangle p0) {
    JViewport instance;
    instance.scrollRectToVisible(p0);
}

void getUIClassID_test_8148() {
    JViewport instance;
    instance.getUIClassID();
}

void getUI_test_8149() {
    JViewport instance;
    instance.getUI();
}

void setUI_test_8150(ViewportUI* p0) {
    JViewport instance;
    instance.setUI(p0);
}

void setBorder_test_8151(Border* p0) {
    JViewport instance;
    instance.setBorder(p0);
}

void getViewPosition_test_8152() {
    JViewport instance;
    instance.getViewPosition();
}

void getExtentSize_test_8153() {
    JViewport instance;
    instance.getExtentSize();
}

void setScrollMode_test_8154(int p0) {
    JViewport instance;
    instance.setScrollMode(p0);
}

void getScrollMode_test_8155() {
    JViewport instance;
    instance.getScrollMode();
}

void isBackingStoreEnabled_test_8156() {
    JViewport instance;
    instance.isBackingStoreEnabled();
}

void setBackingStoreEnabled_test_8157(bool p0) {
    JViewport instance;
    instance.setBackingStoreEnabled(p0);
}

void getViewSize_test_8158() {
    JViewport instance;
    instance.getViewSize();
}

void setViewSize_test_8159(Dimension p0) {
    JViewport instance;
    instance.setViewSize(p0);
}

void getViewRect_test_8160() {
    JViewport instance;
    instance.getViewRect();
}

void toViewCoordinates_test_8161(Dimension p0) {
    JViewport instance;
    instance.toViewCoordinates(p0);
}

void toViewCoordinates_test_8162(Point p0) {
    JViewport instance;
    instance.toViewCoordinates(p0);
}

void setExtentSize_test_8163(Dimension p0) {
    JViewport instance;
    instance.setExtentSize(p0);
}

void setViewPosition_test_8164(Point p0) {
    JViewport instance;
    instance.setViewPosition(p0);
}

void addChangeListener_test_8165(ChangeListener* p0) {
    JViewport instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_8166(ChangeListener* p0) {
    JViewport instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_8167() {
    JViewport instance;
    instance.getChangeListeners();
}

void setView_test_8168(Component* p0) {
    JViewport instance;
    instance.setView(p0);
}

void getView_test_8169() {
    JViewport instance;
    instance.getView();
}

void getAccessibleContext_test_8170() {
    JViewport instance;
    instance.getAccessibleContext();
}

void getInsets_test_8171(Insets p0) {
    JViewport instance;
    instance.getInsets(p0);
}

void getInsets_test_8172() {
    JViewport instance;
    instance.getInsets();
}

void paint_test_8173(Graphics* p0) {
    JViewport instance;
    instance.paint(p0);
}

void repaint_test_8174(long p0, int p1, int p2, int p3, int p4) {
    JViewport instance;
    instance.repaint(p0, p1, p2, p3, p4);
}

void reshape_test_8175(int p0, int p1, int p2, int p3) {
    JViewport instance;
    instance.reshape(p0, p1, p2, p3);
}

void updateUI_test_8176() {
    JViewport instance;
    instance.updateUI();
}

void remove_test_8177(Component* p0) {
    JViewport instance;
    instance.remove(p0);
}

// end of translation
```