#include <cstdint>
#include <string>
#include <vector>

class Object { public: virtual ~Object() = default; };
class Shape { public: virtual ~Shape() = default; };
class Point2D { public: double x = 0, y = 0; };

class AffineTransform {
public:
    AffineTransform() = default;
    void setToTranslation(double p0, double p1) { return {}; }
    void setToRotation(double p0, double p1) { return {}; }
    void setToRotation(double p0, double p1, double p2, double p3) { return {}; }
    void setToRotation(double p0) { return {}; }
    void setToRotation(double p0, double p1, double p2) { return {}; }
    void setToQuadrantRotation(int32_t p0, double p1, double p2) { return {}; }
    void setToQuadrantRotation(int32_t p0) { return {}; }
    void setToScale(double p0, double p1) { return {}; }
    void setToShear(double p0, double p1) { return {}; }
    auto getRotateInstance(double p0, double p1) { return {}; }
    auto getRotateInstance(double p0) { return {}; }
    auto getRotateInstance(double p0, double p1, double p2, double p3) { return {}; }
    auto getRotateInstance(double p0, double p1, double p2) { return {}; }
    auto getQuadrantRotateInstance(int32_t p0) { return {}; }
    auto getQuadrantRotateInstance(int32_t p0, double p1, double p2) { return {}; }
    auto getScaleInstance(double p0, double p1) { return {}; }
    auto getShearInstance(double p0, double p1) { return {}; }
    auto getDeterminant() { return {}; }
    auto getShearX() { return {}; }
    auto getShearY() { return {}; }
    auto getTranslateX() { return {}; }
    void quadrantRotate(int32_t p0) { return {}; }
    void quadrantRotate(int32_t p0, double p1, double p2) { return {}; }
    void shear(double p0, double p1) { return {}; }
    void setToIdentity() { return {}; }
    auto createTransformedShape(Shape& p0) { return {}; }
    void translate(double p0, double p1) { return {}; }
    auto getTranslateInstance(double p0, double p1) { return {}; }
    void preConcatenate(const AffineTransform& p0) { return {}; }
    auto getTranslateY() { return {}; }
    void deltaTransform(Point2D& p0, Point2D& p1) { return {}; }
    void deltaTransform(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void setTransform(const AffineTransform& p0) { return {}; }
    void setTransform(double p0, double p1, double p2, double p3, double p4, double p5) { return {}; }
    void concatenate(const AffineTransform& p0) { return {}; }
    auto getScaleX() { return {}; }
    auto getScaleY() { return {}; }
    auto getMatrix(const std::vector<double>& p0) { return {}; }
    void equals(Object& p0) { return {}; }
    auto toString() { return {}; }
    auto hashCode() { return {}; }
    auto clone() { return {}; }
    void scale(double p0, double p1) { return {}; }
    void transform(const std::vector<double>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<Point2D&>& p0, int32_t p1, const std::vector<Point2D&>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<float>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<float>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(Point2D& p0, Point2D& p1) { return {}; }
    auto getType() { return {}; }
    auto isIdentity() { return {}; }
    void rotate(double p0, double p1, double p2, double p3) { return {}; }
    void rotate(double p0, double p1) { return {}; }
    void rotate(double p0, double p1, double p2) { return {}; }
    void rotate(double p0) { return {}; }
};

// ── Test Functions ──────────────────────────────────────────────

void setToTranslation_test_920(double p0, double p1) {
    AffineTransform instance;
    instance.setToTranslation(p0, p1);
}

void setToRotation_test_921(double p0, double p1) {
    AffineTransform instance;
    instance.setToRotation(p0, p1);
}

void setToRotation_test_922(double p0, double p1, double p2, double p3) {
    AffineTransform instance;
    instance.setToRotation(p0, p1, p2, p3);
}

void setToRotation_test_923(double p0) {
    AffineTransform instance;
    instance.setToRotation(p0);
}

void setToRotation_test_924(double p0, double p1, double p2) {
    AffineTransform instance;
    instance.setToRotation(p0, p1, p2);
}

void setToQuadrantRotation_test_925(int32_t p0, double p1, double p2) {
    AffineTransform instance;
    instance.setToQuadrantRotation(p0, p1, p2);
}

void setToQuadrantRotation_test_926(int32_t p0) {
    AffineTransform instance;
    instance.setToQuadrantRotation(p0);
}

void setToScale_test_927(double p0, double p1) {
    AffineTransform instance;
    instance.setToScale(p0, p1);
}

void setToShear_test_928(double p0, double p1) {
    AffineTransform instance;
    instance.setToShear(p0, p1);
}

void getRotateInstance_test_929(double p0, double p1) {
    AffineTransform instance;
    AffineTransform::getRotateInstance(p0, p1);
}

void getRotateInstance_test_930(double p0) {
    AffineTransform instance;
    AffineTransform::getRotateInstance(p0);
}

void getRotateInstance_test_931(double p0, double p1, double p2, double p3) {
    AffineTransform instance;
    AffineTransform::getRotateInstance(p0, p1, p2, p3);
}

void getRotateInstance_test_932(double p0, double p1, double p2) {
    AffineTransform instance;
    AffineTransform::getRotateInstance(p0, p1, p2);
}

void getQuadrantRotateInstance_test_933(int32_t p0) {
    AffineTransform instance;
    AffineTransform::getQuadrantRotateInstance(p0);
}

void getQuadrantRotateInstance_test_934(int32_t p0, double p1, double p2) {
    AffineTransform instance;
    AffineTransform::getQuadrantRotateInstance(p0, p1, p2);
}

void getScaleInstance_test_935(double p0, double p1) {
    AffineTransform instance;
    AffineTransform::getScaleInstance(p0, p1);
}

void getShearInstance_test_936(double p0, double p1) {
    AffineTransform instance;
    AffineTransform::getShearInstance(p0, p1);
}

void getDeterminant_test_937() {
    AffineTransform instance;
    instance.getDeterminant();
}

void getShearX_test_938() {
    AffineTransform instance;
    instance.getShearX();
}

void getShearY_test_939() {
    AffineTransform instance;
    instance.getShearY();
}

void getTranslateX_test_940() {
    AffineTransform instance;
    instance.getTranslateX();
}

void quadrantRotate_test_941(int32_t p0) {
    AffineTransform instance;
    instance.quadrantRotate(p0);
}

void quadrantRotate_test_942(int32_t p0, double p1, double p2) {
    AffineTransform instance;
    instance.quadrantRotate(p0, p1, p2);
}

void shear_test_943(double p0, double p1) {
    AffineTransform instance;
    instance.shear(p0, p1);
}

void setToIdentity_test_944() {
    AffineTransform instance;
    instance.setToIdentity();
}

void createTransformedShape_test_945(Shape& p0) {
    AffineTransform instance;
    instance.createTransformedShape(p0);
}

void translate_test_946(double p0, double p1) {
    AffineTransform instance;
    instance.translate(p0, p1);
}

void getTranslateInstance_test_947(double p0, double p1) {
    AffineTransform instance;
    AffineTransform::getTranslateInstance(p0, p1);
}

void preConcatenate_test_948(const AffineTransform& p0) {
    AffineTransform instance;
    instance.preConcatenate(p0);
}

void getTranslateY_test_949() {
    AffineTransform instance;
    instance.getTranslateY();
}

void deltaTransform_test_950(Point2D& p0, Point2D& p1) {
    AffineTransform instance;
    instance.deltaTransform(p0, p1);
}

void deltaTransform_test_951(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.deltaTransform(p0, p1, p2, p3, p4);
}

void setTransform_test_952(const AffineTransform& p0) {
    AffineTransform instance;
    instance.setTransform(p0);
}

void setTransform_test_953(double p0, double p1, double p2, double p3, double p4, double p5) {
    AffineTransform instance;
    instance.setTransform(p0, p1, p2, p3, p4, p5);
}

void concatenate_test_954(const AffineTransform& p0) {
    AffineTransform instance;
    instance.concatenate(p0);
}

void getScaleX_test_955() {
    AffineTransform instance;
    instance.getScaleX();
}

void getScaleY_test_956() {
    AffineTransform instance;
    instance.getScaleY();
}

void getMatrix_test_957(const std::vector<double>& p0) {
    AffineTransform instance;
    instance.getMatrix(p0);
}

void equals_test_958(Object& p0) {
    AffineTransform instance;
    instance.equals(p0);
}

void toString_test_959() {
    AffineTransform instance;
    instance.toString();
}

void hashCode_test_960() {
    AffineTransform instance;
    instance.hashCode();
}

void clone_test_961() {
    AffineTransform instance;
    instance.clone();
}

void scale_test_962(double p0, double p1) {
    AffineTransform instance;
    instance.scale(p0, p1);
}

void transform_test_963(const std::vector<double>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.transform(p0, p1, p2, p3, p4);
}

void transform_test_964(const std::vector<Point2D&>& p0, int32_t p1, const std::vector<Point2D&>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.transform(p0, p1, p2, p3, p4);
}

void transform_test_965(const std::vector<float>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.transform(p0, p1, p2, p3, p4);
}

void transform_test_966(const std::vector<float>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.transform(p0, p1, p2, p3, p4);
}

void transform_test_967(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) {
    AffineTransform instance;
    instance.transform(p0, p1, p2, p3, p4);
}

void transform_test_968(Point2D& p0, Point2D& p1) {
    AffineTransform instance;
    instance.transform(p0, p1);
}

void getType_test_969() {
    AffineTransform instance;
    instance.getType();
}

void isIdentity_test_970() {
    AffineTransform instance;
    instance.isIdentity();
}

void rotate_test_971(double p0, double p1, double p2, double p3) {
    AffineTransform instance;
    instance.rotate(p0, p1, p2, p3);
}

void rotate_test_972(double p0, double p1) {
    AffineTransform instance;
    instance.rotate(p0, p1);
}

void rotate_test_973(double p0, double p1, double p2) {
    AffineTransform instance;
    instance.rotate(p0, p1, p2);
}

void rotate_test_974(double p0) {
    AffineTransform instance;
    instance.rotate(p0);
}
