```cpp
#include <iostream>
#include <limits>
#include <sstream>
#include <string>

class IntSummaryStatistics {
private:
    long long count;
    long long sum;
    int min;
    int max;

public:
    IntSummaryStatistics()
        : count(0)
        , sum(0)
        , min(std::numeric_limits<int>::max())
        , max(std::numeric_limits<int>::min()) {}

    void accept(int value) {
        if (count == 0) {
            min = value;
            max = value;
        } else {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        sum += value;
        ++count;
    }

    void combine(const IntSummaryStatistics& other) {
        if (other.count == 0) return;
        if (count == 0) {
            count = other.count;
            sum = other.sum;
            min = other.min;
            max = other.max;
            return;
        }
        count += other.count;
        sum += other.sum;
        if (other.min < min) min = other.min;
        if (other.max > max) max = other.max;
    }

    long long getCount() const { return count; }
    long long getSum() const { return sum; }

    int getMin() const {
        return (count == 0) ? std::numeric_limits<int>::max() : min;
    }

    int getMax() const {
        return (count == 0) ? std::numeric_limits<int>::min() : max;
    }

    double getAverage() const {
        return (count == 0) ? 0.0 : static_cast<double>(sum) / count;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "IntSummaryStatistics{count=" << count
            << ", sum=" << sum
            << ", min=" << getMin()
            << ", average=" << getAverage()
            << ", max=" << getMax() << "}";
        return oss.str();
    }
};

// ---------------------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ---------------------------------------------------------------------------

void toString_test_3576() {
    IntSummaryStatistics instance;
    instance.toString();
}

void accept_test_3577(int p0) {
    IntSummaryStatistics instance;
    instance.accept(p0);
}

void getCount_test_3578() {
    IntSummaryStatistics instance;
    instance.getCount();
}

void combine_test_3579(const IntSummaryStatistics& p0) {
    IntSummaryStatistics instance;
    instance.combine(p0);
}

void getSum_test_3580() {
    IntSummaryStatistics instance;
    instance.getSum();
}

void getMin_test_3581() {
    IntSummaryStatistics instance;
    instance.getMin();
}

void getAverage_test_3582() {
    IntSummaryStatistics instance;
    instance.getAverage();
}

void getMax_test_3583() {
    IntSummaryStatistics instance;
    instance.getMax();
}

// ---------------------------------------------------------------------------
// Main – runs all tests
// ---------------------------------------------------------------------------

int main() {
    // Test 1: toString
    toString_test_3576();

    // Test 2: accept with a sample value
    accept_test_3577(42);

    // Test 3: getCount on empty instance
    getCount_test_3578();

    // Test 4: combine with another instance
    {
        IntSummaryStatistics other;
        other.accept(10);
        combine_test_3579(other);
    }

    // Test 5: getSum
    getSum_test_3580();

    // Test 6: getMin
    getMin_test_3581();

    // Test 7: getAverage
    getAverage_test_3582();

    // Test 8: getMax
    getMax_test_3583();

    std::cout << "All tests completed (no assertions – methods called)." << std::endl;
    return 0;
}
```