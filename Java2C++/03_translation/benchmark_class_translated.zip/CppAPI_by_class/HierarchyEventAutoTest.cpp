```cpp
#include <string>

// Forward declarations
class Container;
class Component;

class Component {
public:
    Component() = default;
    virtual ~Component() = default;
};

class Container : public Component {
public:
    Container() = default;
};

class HierarchyEvent {
private:
    Component* source;
    int id;
    Component* changed;
    Container* changedParent;
    int changeFlags;

public:
    HierarchyEvent(Component& source, int id, Component& changed, Container& changedParent)
        : source(&source), id(id), changed(&changed), changedParent(&changedParent), changeFlags(0) {
        // In the 4-argument Java constructor, changeFlags is not set (default 0).
    }

    Component* getChanged() const {
        return changed;
    }

    Container* getChangedParent() const {
        return changedParent;
    }

    int getChangeFlags() const {
        return changeFlags;
    }

    std::string paramString() const {
        // Return a simple string representation (like Java's paramString)
        return "HIERARCHY_EVENT";
    }

    Component* getComponent() const {
        return source;
    }
};

// Test functions (corresponding to Java @Test methods)
void getChanged_test_759(Component& c0, int c1, Component& c2, Container& c3) {
    HierarchyEvent instance(c0, c1, c2, c3);
    instance.getChanged();
}

void getChangedParent_test_760(Component& c0, int c1, Component& c2, Container& c3) {
    HierarchyEvent instance(c0, c1, c2, c3);
    instance.getChangedParent();
}

void getChangeFlags_test_761(Component& c0, int c1, Component& c2, Container& c3) {
    HierarchyEvent instance(c0, c1, c2, c3);
    instance.getChangeFlags();
}

void paramString_test_762(Component& c0, int c1, Component& c2, Container& c3) {
    HierarchyEvent instance(c0, c1, c2, c3);
    instance.paramString();
}

void getComponent_test_763(Component& c0, int c1, Component& c2, Container& c3) {
    HierarchyEvent instance(c0, c1, c2, c3);
    instance.getComponent();
}
```