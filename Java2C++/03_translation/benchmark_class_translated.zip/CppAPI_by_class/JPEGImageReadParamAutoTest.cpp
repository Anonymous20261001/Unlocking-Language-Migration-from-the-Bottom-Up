```cpp
#include <vector>
#include <cstdint>
#include <algorithm>

// Minimal implementation of JPEGQTable for API compatibility
class JPEGQTable {
public:
    // Default constructor
    JPEGQTable() = default;

    // Copy constructor and assignment are implicitly generated

    // For simplicity, store a copy of the table data if needed
    // The actual implementation in Java holds an int[64]; we can mimic that.
    // Not needed for the test, but provided for completeness.
private:
    std::vector<int> table;
};

// Minimal implementation of JPEGHuffmanTable
class JPEGHuffmanTable {
public:
    JPEGHuffmanTable() = default;
    // Similarly, would store huffman tables
private:
    // Some data
};

// JPEGImageReadParam class with the required API
class JPEGImageReadParam {
public:
    // areTablesSet: returns whether decode tables are set
    bool areTablesSet() const {
        return qTablesSet || dcTablesSet || acTablesSet;
    }

    // setDecodeTables: store copies of the provided tables
    void setDecodeTables(const std::vector<JPEGQTable>& qTables,
                         const std::vector<JPEGHuffmanTable>& dcHuffmanTables,
                         const std::vector<JPEGHuffmanTable>& acHuffmanTables) {
        this->qTables = qTables;
        this->dcTables = dcHuffmanTables;
        this->acTables = acHuffmanTables;
        qTablesSet = !qTables.empty();
        dcTablesSet = !dcTables.empty();
        acTablesSet = !acTables.empty();
    }

    // unsetDecodeTables: clear all stored tables
    void unsetDecodeTables() {
        qTables.clear();
        dcTables.clear();
        acTables.clear();
        qTablesSet = false;
        dcTablesSet = false;
        acTablesSet = false;
    }

    // getQTables: return a copy of the stored quantization tables
    std::vector<JPEGQTable> getQTables() const {
        return qTables;
    }

    // getDCHuffmanTables: return a copy of the stored DC huffman tables
    std::vector<JPEGHuffmanTable> getDCHuffmanTables() const {
        return dcTables;
    }

    // getACHuffmanTables: return a copy of the stored AC huffman tables
    std::vector<JPEGHuffmanTable> getACHuffmanTables() const {
        return acTables;
    }

private:
    std::vector<JPEGQTable> qTables;
    std::vector<JPEGHuffmanTable> dcTables;
    std::vector<JPEGHuffmanTable> acTables;
    bool qTablesSet = false;
    bool dcTablesSet = false;
    bool acTablesSet = false;
};

// Test functions (translation of each @Test method)

void areTablesSet_test_5395() {
    JPEGImageReadParam instance;
    instance.areTablesSet();
}

void setDecodeTables_test_5396(const std::vector<JPEGQTable>& p0,
                               const std::vector<JPEGHuffmanTable>& p1,
                               const std::vector<JPEGHuffmanTable>& p2) {
    JPEGImageReadParam instance;
    instance.setDecodeTables(p0, p1, p2);
}

void unsetDecodeTables_test_5397() {
    JPEGImageReadParam instance;
    instance.unsetDecodeTables();
}

void getQTables_test_5398() {
    JPEGImageReadParam instance;
    instance.getQTables();
}

void getDCHuffmanTables_test_5399() {
    JPEGImageReadParam instance;
    instance.getDCHuffmanTables();
}

void getACHuffmanTables_test_5400() {
    JPEGImageReadParam instance;
    instance.getACHuffmanTables();
}
```