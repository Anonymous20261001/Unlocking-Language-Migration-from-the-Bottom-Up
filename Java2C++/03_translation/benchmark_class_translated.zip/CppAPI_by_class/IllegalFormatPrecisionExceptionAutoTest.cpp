```cpp
#include <string>
#include <sstream>
#include <stdexcept>

// C++ equivalent of java.util.IllegalFormatPrecisionException
class IllegalFormatPrecisionException : public std::runtime_error {
private:
    int precision;
public:
    // Constructor matching Java: IllegalFormatPrecisionException(int)
    IllegalFormatPrecisionException(int precision) 
        : std::runtime_error(buildMessage(precision)), precision(precision) {}

    // Corresponds to Java's getPrecision()
    int getPrecision() const {
        return precision;
    }

    // Corresponds to Java's getMessage()
    std::string getMessage() const {
        return what();
    }

private:
    static std::string buildMessage(int precision) {
        std::ostringstream oss;
        oss << "Precision = " << precision;
        return oss.str();
    }
};

// Test functions (exact names as in Java, with the same signature)
void getPrecision_test_3571(int c0) {
    IllegalFormatPrecisionException instance(c0);
    instance.getPrecision();
}

void getMessage_test_3572(int c0) {
    IllegalFormatPrecisionException instance(c0);
    instance.getMessage();
}
```