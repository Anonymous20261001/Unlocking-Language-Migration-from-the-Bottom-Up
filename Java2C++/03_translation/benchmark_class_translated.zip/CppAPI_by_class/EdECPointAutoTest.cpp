```cpp
#include <string>

// Minimal BigInteger class for compatibility with the Java tests
class BigInteger {
public:
    BigInteger() : value("0") {}
    BigInteger(const std::string& val) : value(val) {}
    BigInteger(const BigInteger& other) : value(other.value) {}
    BigInteger& operator=(const BigInteger& other) {
        if (this != &other) value = other.value;
        return *this;
    }
    bool operator==(const BigInteger& other) const {
        return value == other.value;
    }
    const std::string& toString() const { return value; }
private:
    std::string value;
};

// C++ equivalent of java.security.spec.EdECPoint
class EdECPoint {
public:
    // Constructor matching Java: EdECPoint(boolean isXOdd, BigInteger y)
    EdECPoint(bool isXOdd, const BigInteger& y)
        : isXOdd_(isXOdd), y_(y) {}

    // Method isXOdd() returns boolean
    bool isXOdd() const { return isXOdd_; }

    // Method getY() returns BigInteger by value (matching Java reference semantics)
    BigInteger getY() const { return y_; }

private:
    bool isXOdd_;
    BigInteger y_;
};

// Translated test functions

void isXOdd_test_2883(bool c0, BigInteger c1) {
    EdECPoint instance(c0, c1);
    instance.isXOdd();
}

void getY_test_2884(bool c0, BigInteger c1) {
    EdECPoint instance(c0, c1);
    instance.getY();
}
```