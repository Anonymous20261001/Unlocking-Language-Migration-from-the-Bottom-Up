```cpp
#include <string>
#include <vector>
#include <unordered_map>
#include <any>
#include <sstream>

// Simple Object type alias for Java's Object
using Object = std::any;

class FeatureDescriptor {
private:
    std::string name_;
    std::string displayName_;
    std::string shortDescription_;
    bool expert_ = false;
    bool hidden_ = false;
    bool preferred_ = false;
    std::unordered_map<std::string, std::any> attributes_;

public:
    FeatureDescriptor() = default;

    void setPreferred(bool preferred) {
        preferred_ = preferred;
    }

    void setShortDescription(const std::string& shortDescription) {
        shortDescription_ = shortDescription;
    }

    void setDisplayName(const std::string& displayName) {
        displayName_ = displayName;
    }

    bool isExpert() const {
        return expert_;
    }

    void setExpert(bool expert) {
        expert_ = expert;
    }

    void setHidden(bool hidden) {
        hidden_ = hidden;
    }

    bool isPreferred() const {
        return preferred_;
    }

    std::string getShortDescription() const {
        return shortDescription_;
    }

    std::vector<std::string> attributeNames() const {
        std::vector<std::string> names;
        for (const auto& pair : attributes_) {
            names.push_back(pair.first);
        }
        return names;
    }

    std::string getName() const {
        return name_;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "FeatureDescriptor[name=" << name_ 
            << ", displayName=" << displayName_
            << ", shortDescription=" << shortDescription_
            << ", expert=" << (expert_ ? "true" : "false")
            << ", hidden=" << (hidden_ ? "true" : "false")
            << ", preferred=" << (preferred_ ? "true" : "false")
            << "]";
        return oss.str();
    }

    bool isHidden() const {
        return hidden_;
    }

    Object getValue(const std::string& attributeName) const {
        auto it = attributes_.find(attributeName);
        if (it != attributes_.end()) {
            return it->second;
        }
        return Object(); // null equivalent
    }

    void setName(const std::string& name) {
        name_ = name;
    }

    void setValue(const std::string& attributeName, const Object& value) {
        attributes_[attributeName] = value;
    }

    std::string getDisplayName() const {
        return displayName_;
    }
};

// Test functions (mirroring the Java @Test methods)
void setPreferred_test_1536(bool p0) {
    FeatureDescriptor instance;
    instance.setPreferred(p0);
}

void setShortDescription_test_1537(std::string p0) {
    FeatureDescriptor instance;
    instance.setShortDescription(p0);
}

void setDisplayName_test_1538(std::string p0) {
    FeatureDescriptor instance;
    instance.setDisplayName(p0);
}

void isExpert_test_1539() {
    FeatureDescriptor instance;
    instance.isExpert();
}

void setExpert_test_1540(bool p0) {
    FeatureDescriptor instance;
    instance.setExpert(p0);
}

void setHidden_test_1541(bool p0) {
    FeatureDescriptor instance;
    instance.setHidden(p0);
}

void isPreferred_test_1542() {
    FeatureDescriptor instance;
    instance.isPreferred();
}

void getShortDescription_test_1543() {
    FeatureDescriptor instance;
    instance.getShortDescription();
}

void attributeNames_test_1544() {
    FeatureDescriptor instance;
    instance.attributeNames();
}

void getName_test_1545() {
    FeatureDescriptor instance;
    instance.getName();
}

void toString_test_1546() {
    FeatureDescriptor instance;
    instance.toString();
}

void isHidden_test_1547() {
    FeatureDescriptor instance;
    instance.isHidden();
}

void getValue_test_1548(std::string p0) {
    FeatureDescriptor instance;
    instance.getValue(p0);
}

void setName_test_1549(std::string p0) {
    FeatureDescriptor instance;
    instance.setName(p0);
}

void setValue_test_1550(std::string p0, Object p1) {
    FeatureDescriptor instance;
    instance.setValue(p0, p1);
}

void getDisplayName_test_1551() {
    FeatureDescriptor instance;
    instance.getDisplayName();
}
```