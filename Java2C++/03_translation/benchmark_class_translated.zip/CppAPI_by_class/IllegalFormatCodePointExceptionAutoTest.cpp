```cpp
#include <exception>
#include <string>

class IllegalFormatCodePointException : public std::exception {
private:
    int codePoint;
    std::string message;
public:
    IllegalFormatCodePointException(int cp)
        : codePoint(cp), message("Illegal format code point: " + std::to_string(cp)) {}

    const char* what() const noexcept override {
        return message.c_str();
    }

    // Mimics Java's getMessage() -> returns a std::string (as Java String)
    std::string getMessage() const {
        return message;
    }

    int getCodePoint() const {
        return codePoint;
    }
};

void getMessage_test_3564(int c0) {
    IllegalFormatCodePointException instance(c0);
    instance.getMessage();
}

void getCodePoint_test_3565(int c0) {
    IllegalFormatCodePointException instance(c0);
    instance.getCodePoint();
}
```