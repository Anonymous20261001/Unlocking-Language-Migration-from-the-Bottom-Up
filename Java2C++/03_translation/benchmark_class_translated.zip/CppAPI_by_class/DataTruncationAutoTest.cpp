```cpp
#include <iostream>
#include <cstddef>

// Equivalent to java.sql.DataTruncation
class DataTruncation {
private:
    int index_;
    bool parameter_;
    bool read_;
    int dataSize_;
    int transferSize_;

public:
    DataTruncation(int index, bool parameter, bool read, int dataSize, int transferSize)
        : index_(index), parameter_(parameter), read_(read), dataSize_(dataSize), transferSize_(transferSize) {}

    bool getParameter() const noexcept { return parameter_; }
    int getIndex() const noexcept { return index_; }
    bool getRead() const noexcept { return read_; }
    int getDataSize() const noexcept { return dataSize_; }
    int getTransferSize() const noexcept { return transferSize_; }
};

// Translated test functions
void getParameter_test_2939(int c0, bool c1, bool c2, int c3, int c4) {
    DataTruncation instance(c0, c1, c2, c3, c4);
    instance.getParameter();
}

void getIndex_test_2940(int c0, bool c1, bool c2, int c3, int c4) {
    DataTruncation instance(c0, c1, c2, c3, c4);
    instance.getIndex();
}

void getRead_test_2941(int c0, bool c1, bool c2, int c3, int c4) {
    DataTruncation instance(c0, c1, c2, c3, c4);
    instance.getRead();
}

void getDataSize_test_2942(int c0, bool c1, bool c2, int c3, int c4) {
    DataTruncation instance(c0, c1, c2, c3, c4);
    instance.getDataSize();
}

void getTransferSize_test_2943(int c0, bool c1, bool c2, int c3, int c4) {
    DataTruncation instance(c0, c1, c2, c3, c4);
    instance.getTransferSize();
}
```