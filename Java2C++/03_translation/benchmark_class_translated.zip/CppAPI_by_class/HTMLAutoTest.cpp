```cpp
#include <string>
#include <vector>

// Dummy types to mimic Java's javax.swing.text.AttributeSet and inner classes
struct AttributeSet {
    // placeholder, no members needed for this test
};

class HTML {
public:
    // Inner types
    struct Attribute {
        // dummy enum or class; just a placeholder
        std::string name;
        explicit Attribute(const std::string& n = "") : name(n) {}
        bool operator==(const Attribute& other) const { return name == other.name; }
    };

    struct Tag {
        std::string name;
        explicit Tag(const std::string& n = "") : name(n) {}
        bool operator==(const Tag& other) const { return name == other.name; }
    };

    // Default constructor (unused but present)
    HTML() = default;

    // Static methods matching Java API
    static int getIntegerAttributeValue(const AttributeSet& attrs, Attribute attr, int defaultValue) {
        // Dummy implementation: always returns default
        return defaultValue;
    }

    static Tag getTag(const std::string& tagName) {
        // Dummy: return Tag with given name (or empty)
        return Tag(tagName);
    }

    static std::vector<Tag> getAllTags() {
        // Dummy: return empty vector
        return {};
    }

    static Attribute getAttributeKey(const std::string& attrName) {
        // Dummy: return Attribute with given name
        return Attribute(attrName);
    }

    static std::vector<Attribute> getAllAttributeKeys() {
        // Dummy: return empty vector
        return {};
    }
};

// Test functions (one per @Test method, same names)
void getIntegerAttributeValue_test_10461(AttributeSet p0, HTML::Attribute p1, int p2) {
    HTML instance;
    // In Java, static methods can be called on instance, but it's equivalent to class call.
    HTML::getIntegerAttributeValue(p0, p1, p2);
}

void getTag_test_10462(std::string p0) {
    HTML instance;
    HTML::getTag(p0);
}

void getAllTags_test_10463() {
    HTML instance;
    HTML::getAllTags();
}

void getAttributeKey_test_10464(std::string p0) {
    HTML instance;
    HTML::getAttributeKey(p0);
}

void getAllAttributeKeys_test_10465() {
    HTML instance;
    HTML::getAllAttributeKeys();
}
```