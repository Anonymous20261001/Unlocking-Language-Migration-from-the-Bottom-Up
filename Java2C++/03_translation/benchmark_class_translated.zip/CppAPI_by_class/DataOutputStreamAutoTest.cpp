```cpp
#include <cstddef>

// Abstract base class mimicking Java's OutputStream
class OutputStream {
public:
    virtual void write(int b) = 0;
    virtual void write(const char* b, std::size_t len) = 0;
    virtual ~OutputStream() = default;
};

// Concrete implementation of DataOutputStream tracking written byte count
class DataOutputStream {
private:
    OutputStream& m_out;
    int m_written;

public:
    explicit DataOutputStream(OutputStream& out)
        : m_out(out), m_written(0) {}

    void write(int b) {
        m_out.write(b);
        ++m_written;
    }

    void write(const char* b, std::size_t len) {
        m_out.write(b, len);
        m_written += static_cast<int>(len);
    }

    int size() const {
        return m_written;
    }
};

// Test function translated from Java @Test
void size_test_1729(OutputStream& c0) {
    DataOutputStream instance(c0);
    instance.size();
}
```