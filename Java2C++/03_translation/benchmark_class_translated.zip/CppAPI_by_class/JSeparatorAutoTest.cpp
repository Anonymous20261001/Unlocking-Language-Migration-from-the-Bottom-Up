```cpp
#include <string>
#include <stdexcept>
#include <cassert>

// ---------------------------------------------------------------------------
// Minimal Java-like classes for JSeparator, SeparatorUI, AccessibleContext
// ---------------------------------------------------------------------------

class SeparatorUI {
public:
    virtual ~SeparatorUI() = default;
};

class AccessibleContext {
public:
    virtual ~AccessibleContext() = default;
};

class JSeparator {
public:
    static const int HORIZONTAL = 0;
    static const int VERTICAL   = 1;

    // Constructor: default horizontal orientation
    JSeparator()
        : orientation(HORIZONTAL)
        , ui(nullptr)
        , accessibleContext(nullptr)
    {}

    // Simulate Java's getUIClassID() returning "SeparatorUI"
    std::string getUIClassID() const {
        return "SeparatorUI";
    }

    // getUI: returns current UI (may be nullptr)
    SeparatorUI* getUI() const {
        return ui;
    }

    // setUI: sets the UI object
    void setUI(SeparatorUI* u) {
        ui = u;
    }

    // getAccessibleContext: returns a cached AccessibleContext
    AccessibleContext* getAccessibleContext() {
        if (!accessibleContext) {
            accessibleContext = new AccessibleContext();
        }
        return accessibleContext;
    }

    // getOrientation: returns current orientation
    int getOrientation() const {
        return orientation;
    }

    // setOrientation: validates orientation, throws if invalid
    void setOrientation(int o) {
        if (o != HORIZONTAL && o != VERTICAL) {
            throw std::invalid_argument("Invalid orientation: must be HORIZONTAL or VERTICAL");
        }
        orientation = o;
    }

    // updateUI: resets UI to a new default SeparatorUI
    void updateUI() {
        ui = new SeparatorUI();
    }

private:
    int orientation;
    SeparatorUI* ui;
    AccessibleContext* accessibleContext;
};

// ---------------------------------------------------------------------------
// Test functions (one per Java @Test method)
// ---------------------------------------------------------------------------

void getUIClassID_test_7630() {
    JSeparator instance;
    instance.getUIClassID();          // just call, no return value used
}

void getUI_test_7631() {
    JSeparator instance;
    instance.getUI();                 // just call
}

void setUI_test_7632() {
    JSeparator instance;
    SeparatorUI ui;
    instance.setUI(&ui);              // pass address of a real object
}

void getAccessibleContext_test_7633() {
    JSeparator instance;
    instance.getAccessibleContext();  // just call
}

void getOrientation_test_7634() {
    JSeparator instance;
    instance.getOrientation();        // just call
}

void updateUI_test_7635() {
    JSeparator instance;
    instance.updateUI();              // just call
}

void setOrientation_test_7636() {
    JSeparator instance;
    instance.setOrientation(JSeparator::HORIZONTAL); // pass valid constant
}

// ---------------------------------------------------------------------------
// Optional main() – runs all tests (simple self‑check)
// ---------------------------------------------------------------------------

int main() {
    // Execute every test; no explicit assertions – they must not throw.
    getUIClassID_test_7630();
    getUI_test_7631();
    setUI_test_7632();
    getAccessibleContext_test_7633();
    getOrientation_test_7634();
    updateUI_test_7635();
    setOrientation_test_7636();

    // All tests completed successfully.
    return 0;
}
```