```cpp
#include <cstdint>
#include <vector>
#include <cassert>

// C++ equivalent of javax.crypto.spec.IvParameterSpec
class IvParameterSpec {
private:
    std::vector<uint8_t> iv;

public:
    // Constructor: takes a copy of the provided byte vector
    explicit IvParameterSpec(const std::vector<uint8_t>& iv)
        : iv(iv) {}

    // Returns a copy of the initialization vector
    std::vector<uint8_t> getIV() const {
        return iv;  // returns a copy (as std::vector copy constructor is used)
    }
};

// Test function equivalent to Java @Test method
void getIV_test_5249(const std::vector<uint8_t>& c0) {
    IvParameterSpec instance(c0);
    instance.getIV();
    // No explicit assertion in the original Java test; just exercises the API.
    // If desired, one could add a check that the returned IV matches the original input.
    // For fidelity, we keep it minimal.
}

// Optional demonstration main (not required by problem but included for completeness)
int main() {
    std::vector<uint8_t> sample_iv = {0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef};
    getIV_test_5249(sample_iv);
    return 0;
}
```