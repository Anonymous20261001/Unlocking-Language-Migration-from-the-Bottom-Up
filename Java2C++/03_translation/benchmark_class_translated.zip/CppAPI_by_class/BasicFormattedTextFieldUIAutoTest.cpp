```cpp
#include <iostream>

// Minimal JComponent class for testing
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicFormattedTextFieldUI with static createUI method
class BasicFormattedTextFieldUI {
public:
    static void createUI(JComponent* c) {
        // Simulate the static UI creation (no-op for testing)
    }
};

// Test function matching the Java @Test method name
void createUI_test_8761(JComponent* p0) {
    BasicFormattedTextFieldUI instance;               // Unused instance
    BasicFormattedTextFieldUI::createUI(p0);          // Static method call
}
```