```cpp
#include <limits>
#include <sstream>
#include <string>

class DoubleSummaryStatistics {
private:
    long count_;
    double sum_;
    double min_;
    double max_;

public:
    DoubleSummaryStatistics()
        : count_(0), sum_(0.0),
          min_(std::numeric_limits<double>::infinity()),
          max_(-std::numeric_limits<double>::infinity()) {}

    void accept(double value) {
        ++count_;
        sum_ += value;
        if (value < min_) min_ = value;
        if (value > max_) max_ = value;
    }

    void combine(const DoubleSummaryStatistics& other) {
        count_ += other.count_;
        sum_ += other.sum_;
        if (other.min_ < min_) min_ = other.min_;
        if (other.max_ > max_) max_ = other.max_;
    }

    long getCount() const {
        return count_;
    }

    double getSum() const {
        return sum_;
    }

    double getMin() const {
        return min_;
    }

    double getMax() const {
        return max_;
    }

    double getAverage() const {
        if (count_ == 0) return 0.0;
        return sum_ / count_;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "DoubleSummaryStatistics{count=" << count_
            << ", sum=" << sum_
            << ", min=" << min_
            << ", average=" << getAverage()
            << ", max=" << max_ << "}";
        return oss.str();
    }
};

// Test functions (mirroring the Java @Test methods)
void toString_test_3417() {
    DoubleSummaryStatistics instance;
    instance.toString();
}

void accept_test_3418(double p0) {
    DoubleSummaryStatistics instance;
    instance.accept(p0);
}

void getCount_test_3419() {
    DoubleSummaryStatistics instance;
    instance.getCount();
}

void combine_test_3420(DoubleSummaryStatistics p0) {
    DoubleSummaryStatistics instance;
    instance.combine(p0);
}

void getSum_test_3421() {
    DoubleSummaryStatistics instance;
    instance.getSum();
}

void getMin_test_3422() {
    DoubleSummaryStatistics instance;
    instance.getMin();
}

void getAverage_test_3423() {
    DoubleSummaryStatistics instance;
    instance.getAverage();
}

void getMax_test_3424() {
    DoubleSummaryStatistics instance;
    instance.getMax();
}
```