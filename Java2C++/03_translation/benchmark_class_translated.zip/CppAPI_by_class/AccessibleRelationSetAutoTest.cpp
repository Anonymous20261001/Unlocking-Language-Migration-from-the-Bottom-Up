```cpp
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iostream>

// C++ equivalent of javax.accessibility.AccessibleRelation
class AccessibleRelation {
public:
    std::string key;

    // Default constructor
    AccessibleRelation() : key("") {}

    // Constructor with key
    explicit AccessibleRelation(const std::string& key) : key(key) {}

    // Equality based on key
    bool operator==(const AccessibleRelation& other) const {
        return key == other.key;
    }
};

// C++ equivalent of javax.accessibility.AccessibleRelationSet
class AccessibleRelationSet {
private:
    std::vector<AccessibleRelation> relations;

public:
    AccessibleRelationSet() = default;

    // Add a relation (if not already present by key)
    void add(const AccessibleRelation& rel) {
        auto it = std::find_if(relations.begin(), relations.end(),
            [&rel](const AccessibleRelation& r) { return r.key == rel.key; });
        if (it == relations.end()) {
            relations.push_back(rel);
        }
    }

    // Add all relations from a vector
    void addAll(const std::vector<AccessibleRelation>& rels) {
        for (const auto& rel : rels) {
            add(rel);
        }
    }

    // Remove a specific relation object (by equality)
    void remove(const AccessibleRelation& rel) {
        auto it = std::find(relations.begin(), relations.end(), rel);
        if (it != relations.end()) {
            relations.erase(it);
        }
    }

    // Clear all relations
    void clear() {
        relations.clear();
    }

    // Check if a relation with the given key exists
    bool contains(const std::string& key) const {
        auto it = std::find_if(relations.begin(), relations.end(),
            [&key](const AccessibleRelation& r) { return r.key == key; });
        return it != relations.end();
    }

    // Get the relation with the given key (returns default if not found)
    AccessibleRelation get(const std::string& key) const {
        auto it = std::find_if(relations.begin(), relations.end(),
            [&key](const AccessibleRelation& r) { return r.key == key; });
        if (it != relations.end()) {
            return *it;
        }
        return AccessibleRelation(); // empty key
    }

    // Return the number of relations
    int size() const {
        return static_cast<int>(relations.size());
    }

    // Return all relations as a vector
    std::vector<AccessibleRelation> toArray() const {
        return relations;
    }

    // Return a string representation
    std::string toString() const {
        std::ostringstream oss;
        oss << "AccessibleRelationSet{";
        for (size_t i = 0; i < relations.size(); ++i) {
            if (i > 0) oss << ", ";
            oss << relations[i].key;
        }
        oss << "}";
        return oss.str();
    }
};

// ===== Test functions (one per @Test method) =====

void remove_test_5216(AccessibleRelation p0) {
    AccessibleRelationSet instance;
    instance.remove(p0);
}

void size_test_5217() {
    AccessibleRelationSet instance;
    instance.size();
}

void get_test_5218(std::string p0) {
    AccessibleRelationSet instance;
    instance.get(p0);
}

void toString_test_5219() {
    AccessibleRelationSet instance;
    instance.toString();
}

void clear_test_5220() {
    AccessibleRelationSet instance;
    instance.clear();
}

void add_test_5221(AccessibleRelation p0) {
    AccessibleRelationSet instance;
    instance.add(p0);
}

void toArray_test_5222() {
    AccessibleRelationSet instance;
    instance.toArray();
}

void contains_test_5223(std::string p0) {
    AccessibleRelationSet instance;
    instance.contains(p0);
}

void addAll_test_5224(const std::vector<AccessibleRelation>& p0) {
    AccessibleRelationSet instance;
    instance.addAll(p0);
}
```