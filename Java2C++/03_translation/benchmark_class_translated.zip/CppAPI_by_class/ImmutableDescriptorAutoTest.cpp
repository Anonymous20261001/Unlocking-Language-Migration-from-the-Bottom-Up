```cpp
#include <map>
#include <string>
#include <vector>
#include <memory>
#include <stdexcept>
#include <sstream>
#include <functional>
#include <any>
#include <cassert>

// ----------------------------------------------------------------------------
// Base Descriptor interface (simplified to match used methods)
// ----------------------------------------------------------------------------
class Descriptor {
public:
    virtual ~Descriptor() = default;

    virtual std::vector<std::string> getFieldNames() const = 0;
    virtual std::string getFieldValue(const std::string& name) const = 0;
    virtual std::vector<std::string> getFieldValues(const std::vector<std::string>& names) const = 0;
    virtual void removeField(const std::string& name) = 0; // may throw
    virtual std::vector<std::string> getFields() const = 0;
    virtual bool isValid() const = 0;
    virtual bool equals(const std::any& obj) const = 0;
    virtual size_t hashCode() const = 0;
    virtual std::string toString() const = 0;
    virtual std::unique_ptr<Descriptor> clone() const = 0;
};

// ----------------------------------------------------------------------------
// ImmutableDescriptor implementation
// ----------------------------------------------------------------------------
class ImmutableDescriptor final : public Descriptor {
public:
    // Constructor taking a map of string keys to string values
    explicit ImmutableDescriptor(const std::map<std::string, std::string>& fields)
        : fields_(fields) {}

    // ------------------------------------------------------------------------
    // Descriptor interface
    // ------------------------------------------------------------------------
    std::vector<std::string> getFieldNames() const override {
        std::vector<std::string> names;
        names.reserve(fields_.size());
        for (const auto& [key, _] : fields_) {
            names.push_back(key);
        }
        return names;
    }

    std::string getFieldValue(const std::string& name) const override {
        auto it = fields_.find(name);
        if (it != fields_.end()) {
            return it->second;
        }
        // Java returns null; we return empty string to simulate absent field
        return "";
    }

    std::vector<std::string> getFieldValues(const std::vector<std::string>& names) const override {
        std::vector<std::string> values;
        values.reserve(names.size());
        for (const auto& n : names) {
            auto it = fields_.find(n);
            if (it != fields_.end()) {
                values.push_back(it->second);
            } else {
                values.push_back(""); // Java sets null for absent fields
            }
        }
        return values;
    }

    void removeField(const std::string& /*name*/) override {
        // ImmutableDescriptor does not allow removal
        throw std::runtime_error("UnsupportedOperationException: cannot remove field from ImmutableDescriptor");
    }

    std::vector<std::string> getFields() const override {
        std::vector<std::string> result;
        result.reserve(fields_.size());
        for (const auto& [key, value] : fields_) {
            std::ostringstream oss;
            oss << key << '=' << value;
            result.push_back(oss.str());
        }
        return result;
    }

    bool isValid() const override {
        return true;
    }

    bool equals(const std::any& obj) const override {
        // Try to cast to const ImmutableDescriptor*
        const ImmutableDescriptor* other = std::any_cast<const ImmutableDescriptor*>(&obj);
        if (!other) {
            // Also try std::shared_ptr<ImmutableDescriptor>
            const auto* sharedOther = std::any_cast<const std::shared_ptr<ImmutableDescriptor>>(&obj);
            if (sharedOther) {
                other = sharedOther->get();
            }
        }
        if (!other) return false;
        return fields_ == other->fields_;
    }

    size_t hashCode() const override {
        // Simple hash: combine hashes of key=value pairs
        size_t h = 0;
        for (const auto& [key, value] : fields_) {
            h ^= std::hash<std::string>{}(key + "=" + value);
        }
        return h;
    }

    std::string toString() const override {
        std::ostringstream oss;
        oss << "{ ";
        bool first = true;
        for (const auto& [key, value] : fields_) {
            if (!first) oss << ", ";
            oss << key << '=' << value;
            first = false;
        }
        oss << " }";
        return oss.str();
    }

    std::unique_ptr<Descriptor> clone() const override {
        return std::make_unique<ImmutableDescriptor>(fields_);
    }

    // ------------------------------------------------------------------------
    // Static union method (as in Java ImmutableDescriptor.union)
    // ------------------------------------------------------------------------
    static std::unique_ptr<Descriptor> union_(const std::vector<const Descriptor*>& descriptors) {
        std::map<std::string, std::string> merged;
        for (const auto* d : descriptors) {
            if (!d) continue;
            auto names = d->getFieldNames();
            for (const auto& name : names) {
                merged[name] = d->getFieldValue(name);
            }
        }
        return std::make_unique<ImmutableDescriptor>(merged);
    }

private:
    std::map<std::string, std::string> fields_;
};

// ============================================================================
// Test functions (translated from Java)
// ============================================================================

void getFieldNames_test_5549(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldNames();
}

void getFieldValues_test_5550(const std::vector<std::string>& p0,
                              const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldValues(p0);
}

void removeField_test_5551(const std::string& p0,
                           const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    try {
        instance.removeField(p0);
        assert(false && "Expected exception not thrown");
    } catch (const std::runtime_error&) {
        // expected
    }
}

void equals_test_5552(const std::any& p0,
                      const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.equals(p0);
}

void toString_test_5553(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.toString();
}

void hashCode_test_5554(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.hashCode();
}

void clone_test_5555(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    auto cloned = instance.clone();
    // The clone is not used further, but we keep it alive until end of scope.
    (void)cloned;
}

void getFields_test_5556(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFields();
}

void isValid_test_5557(const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.isValid();
}

// Note: In Java the parameter is Descriptor[] p0, we translate to vector<const Descriptor*>
void union_test_5558(const std::vector<const Descriptor*>& p0,
                     const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    auto result = ImmutableDescriptor::union_(p0);
    (void)result;
}

void getFieldValue_test_5559(const std::string& p0,
                             const std::map<std::string, std::string>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldValue(p0);
}

// ============================================================================
// Example usage (if compiled as standalone)
// ============================================================================
int main() {
    // Minimal test to verify compilation and basic behavior
    std::map<std::string, std::string> testMap = {{"name", "value"}, {"type", "example"}};
    
    getFieldNames_test_5549(testMap);
    getFieldValues_test_5550({"name", "missing"}, testMap);
    removeField_test_5551