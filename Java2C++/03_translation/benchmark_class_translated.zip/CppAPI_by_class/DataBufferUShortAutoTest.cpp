```cpp
#include <vector>
#include <cstdint>

class DataBufferUShort {
private:
    std::vector<std::vector<unsigned short>> banks;

public:
    // Constructor: single bank of given size, all elements initialized to 0
    DataBufferUShort(int size) {
        banks.emplace_back(size, 0);
    }

    // Returns a vector of pointers to the internal bank data (simulates Java's short[][])
    // The returned pointers remain valid as long as the DataBufferUShort object exists.
    std::vector<unsigned short*> getBankData() {
        std::vector<unsigned short*> ptrs;
        for (auto& bank : banks) {
            ptrs.push_back(bank.data());
        }
        return ptrs;
    }

    // Returns element at given bank and index, as int (unsigned short promoted to int)
    int getElem(int bank, int i) const {
        return banks[bank][i];
    }

    // Returns element at index i from the first bank
    int getElem(int i) const {
        return banks[0][i];
    }

    // Sets element at given bank and index to val (truncated to unsigned short)
    void setElem(int bank, int i, int val) {
        banks[bank][i] = static_cast<unsigned short>(val);
    }

    // Sets element at index i in the first bank to val
    void setElem(int i, int val) {
        banks[0][i] = static_cast<unsigned short>(val);
    }

    // Returns a reference to the data vector for the given bank
    std::vector<unsigned short>& getData(int bank) {
        return banks[bank];
    }

    // Returns a reference to the data vector of the first bank
    std::vector<unsigned short>& getData() {
        return banks[0];
    }
};

// --- Test function translations (same names and parameter signatures as Java methods) ---

void getBankData_test_1234(int c0) {
    DataBufferUShort instance(c0);
    instance.getBankData();
}

void getElem_test_1235(int p0, int p1, int c0) {
    DataBufferUShort instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1236(int p0, int c0) {
    DataBufferUShort instance(c0);
    instance.getElem(p0);
}

void setElem_test_1237(int p0, int p1, int p2, int c0) {
    DataBufferUShort instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1238(int p0, int p1, int c0) {
    DataBufferUShort instance(c0);
    instance.setElem(p0, p1);
}

void getData_test_1239(int p0, int c0) {
    DataBufferUShort instance(c0);
    instance.getData(p0);
}

void getData_test_1240(int c0) {
    DataBufferUShort instance(c0);
    instance.getData();
}
```