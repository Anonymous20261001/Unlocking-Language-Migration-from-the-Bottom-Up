```cpp
#include <string>
#include <cstdint>
#include <stdexcept>
#include <functional>
#include <iostream>

// Minimal base class to simulate Java Object
class Object {
public:
    virtual ~Object() = default;
    virtual std::string toString() const = 0;
    virtual int hashCode() const = 0;
    virtual bool equals(const Object& other) const = 0;
};

// Class representing a KerberosPrincipal (simplified)
class KerberosPrincipal : public Object {
private:
    std::string name;
    int nameType;  // in Java defaults to KRB_NT_PRINCIPAL (1)

    // Helper: extract realm (part after '@') or empty string if none
    std::string extractRealm() const {
        std::size_t at = name.find('@');
        if (at != std::string::npos) {
            return name.substr(at + 1);
        }
        return "";  // Java would return null, but we use empty for simplicity
    }

public:
    // Constructor matching Java's KerberosPrincipal(String)
    explicit KerberosPrincipal(const std::string& principalName)
        : name(principalName), nameType(1) // KRB_NT_PRINCIPAL
    {
        // In a full implementation we would validate the name format
    }

    // getName(): returns the full principal name
    std::string getName() const {
        return name;
    }

    // toString(): Java's KerberosPrincipal.toString() returns the name
    std::string toString() const override {
        return name;
    }

    // hashCode(): returns a hash based on the name (Java uses String.hashCode())
    int hashCode() const override {
        // Simple string hash similar to Java's String.hashCode()
        int hash = 0;
        for (char c : name) {
            hash = 31 * hash + static_cast<int>(c);
        }
        return hash;
    }

    // equals(Object): checks if other is a KerberosPrincipal with same name
    bool equals(const Object& other) const override {
        // dynamic_cast to verify if it's a KerberosPrincipal
        const KerberosPrincipal* kp = dynamic_cast<const KerberosPrincipal*>(&other);
        if (kp == nullptr) {
            return false;
        }
        return name == kp->name;
    }

    // getRealm(): returns the realm part of the principal
    std::string getRealm() const {
        return extractRealm();
    }

    // getNameType(): returns the name type (default: 1 = KRB_NT_PRINCIPAL)
    int getNameType() const {
        return nameType;
    }
};

// ---------------------- Test functions (translated from Java) ----------------------

void getName_test_6388(std::string c0) {
    KerberosPrincipal instance(c0);
    instance.getName();
}

void equals_test_6389(const Object& p0, std::string c0) {
    KerberosPrincipal instance(c0);
    instance.equals(p0);
}

void toString_test_6390(std::string c0) {
    KerberosPrincipal instance(c0);
    instance.toString();
}

void hashCode_test_6391(std::string c0) {
    KerberosPrincipal instance(c0);
    instance.hashCode();
}

void getRealm_test_6392(std::string c0) {
    KerberosPrincipal instance(c0);
    instance.getRealm();
}

void getNameType_test_6393(std::string c0) {
    KerberosPrincipal instance(c0);
    instance.getNameType();
}
```