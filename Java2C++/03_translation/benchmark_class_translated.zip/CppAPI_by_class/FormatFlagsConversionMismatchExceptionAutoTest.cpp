```cpp
#include <string>
#include <stdexcept>
#include <sstream>

// C++ equivalent of java.util.FormatFlagsConversionMismatchException
class FormatFlagsConversionMismatchException : public std::runtime_error {
private:
    std::string flags_;
    char conversion_;

    // Build the message in the same style as the Java original
    static std::string buildMessage(const std::string& flags, char conversion) {
        std::ostringstream oss;
        oss << "Flags = '" << flags << "' conversion = '" << conversion << "'";
        return oss.str();
    }

public:
    FormatFlagsConversionMismatchException(const std::string& flags, char conversion)
        : std::runtime_error(buildMessage(flags, conversion)),
          flags_(flags),
          conversion_(conversion)
    {}

    // getFlags() returns the flags string
    std::string getFlags() const {
        return flags_;
    }

    // getConversion() returns the conversion character
    char getConversion() const {
        return conversion_;
    }

    // getMessage() is equivalent to what() from std::runtime_error
    std::string getMessage() const {
        return std::runtime_error::what();
    }
};

// Test function equivalents (exactly matching the Java method signatures)
void getConversion_test_3443(const std::string& c0, char c1) {
    FormatFlagsConversionMismatchException instance(c0, c1);
    instance.getConversion();
}

void getMessage_test_3444(const std::string& c0, char c1) {
    FormatFlagsConversionMismatchException instance(c0, c1);
    instance.getMessage();
}

void getFlags_test_3445(const std::string& c0, char c1) {
    FormatFlagsConversionMismatchException instance(c0, c1);
    instance.getFlags();
}
```