```cpp
#include <string>
#include <vector>
#include <optional>

// ---------- Minimal Locale class ----------
class Locale {
public:
    Locale() = default;
    // For simplicity, just a placeholder; real implementation would store language/country.
    // Tests just need to pass a Locale object, so this is sufficient.
};

// ---------- Minimal Dimension class ----------
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// ---------- ImageWriteParam class ----------
class ImageWriteParam {
private:
    Locale locale;
    int tilingMode = 0;          // MODE_DEFAULT
    int compressionMode = 0;     // MODE_DEFAULT
    int progressiveMode = 0;     // MODE_DEFAULT

    // Tiling state
    bool tilingSet = false;
    int tileWidth = 0;
    int tileHeight = 0;
    int tileGridXOffset = 0;
    int tileGridYOffset = 0;

    // Compression state
    bool compressionSet = false;
    std::string compressionType;
    float compressionQuality = 0.0f;

public:
    // Constructor
    ImageWriteParam(const Locale& locale) : locale(locale) {}

    // Tiling methods
    int getTileWidth() const { return tileWidth; }
    int getTileHeight() const { return tileHeight; }
    int getTileGridXOffset() const { return tileGridXOffset; }
    int getTileGridYOffset() const { return tileGridYOffset; }
    bool canWriteTiles() const { return false; }   // default false
    bool canOffsetTiles() const { return false; }  // default false
    void unsetTiling() { tilingSet = false; }
    int getTilingMode() const { return tilingMode; }
    void setTilingMode(int mode) { tilingMode = mode; }

    // Preferred tile sizes (returns a Dimension with default 0,0)
    Dimension getPreferredTileSizes() const { return Dimension(0, 0); }

    void setTiling(int tileWidth, int tileHeight, int tileGridXOffset, int tileGridYOffset) {
        // In real Java, this would validate and set; for test we just store.
        this->tileWidth = tileWidth;
        this->tileHeight = tileHeight;
        this->tileGridXOffset = tileGridXOffset;
        this->tileGridYOffset = tileGridYOffset;
        tilingSet = true;
    }

    // Progressive methods
    bool canWriteProgressive() const { return false; }  // default false
    void setProgressiveMode(int mode) { progressiveMode = mode; }
    int getProgressiveMode() const { return progressiveMode; }

    // Compression methods
    bool canWriteCompressed() const { return false; }   // default false
    void unsetCompression() { compressionSet = false; }
    int getCompressionMode() const { return compressionMode; }
    void setCompressionMode(int mode) { compressionMode = mode; }

    // Compression types (return empty vector as default)
    std::vector<std::string> getCompressionTypes() const { return {}; }

    // Compression type (default empty string)
    std::string getCompressionType() const { return compressionType; }
    void setCompressionType(const std::string& type) { compressionType = type; }

    // Localized compression type name (default empty)
    std::string getLocalizedCompressionTypeName() const { return {}; }

    // Lossless check (default false)
    bool isCompressionLossless() const { return false; }

    // Compression quality
    void setCompressionQuality(float quality) { compressionQuality = quality; }
    float getCompressionQuality() const { return compressionQuality; }

    // Bit rate (default 0.0f)
    float getBitRate(float quality) const { return 0.0f; }

    // Compression quality descriptions and values (default empty vectors)
    std::vector<std::string> getCompressionQualityDescriptions() const { return {}; }
    std::vector<float> getCompressionQualityValues() const { return {}; }

    // Locale
    Locale getLocale() const { return locale; }
};

// ---------- Test functions (translated from Java @Test methods) ----------

void getTileWidth_test_5317(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getTileWidth();
}

void getTileHeight_test_5318(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getTileHeight();
}

void getTileGridXOffset_test_5319(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getTileGridXOffset();
}

void getTileGridYOffset_test_5320(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getTileGridYOffset();
}

void canWriteTiles_test_5321(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.canWriteTiles();
}

void canOffsetTiles_test_5322(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.canOffsetTiles();
}

void canWriteProgressive_test_5323(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.canWriteProgressive();
}

void canWriteCompressed_test_5324(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.canWriteCompressed();
}

void unsetTiling_test_5325(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.unsetTiling();
}

void getTilingMode_test_5326(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getTilingMode();
}

void unsetCompression_test_5327(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.unsetCompression();
}

void getCompressionMode_test_5328(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionMode();
}

void getCompressionTypes_test_5329(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionTypes();
}

void getCompressionType_test_5330(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionType();
}

void setTilingMode_test_5331(int p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setTilingMode(p0);
}

void getPreferredTileSizes_test_5332(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getPreferredTileSizes();
}

void setTiling_test_5333(int p0, int p1, int p2, int p3, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setTiling(p0, p1, p2, p3);
}

void setProgressiveMode_test_5334(int p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setProgressiveMode(p0);
}

void getProgressiveMode_test_5335(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getProgressiveMode();
}

void setCompressionMode_test_5336(int p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setCompressionMode(p0);
}

void setCompressionType_test_5337(const std::string& p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setCompressionType(p0);
}

void getLocalizedCompressionTypeName_test_5338(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getLocalizedCompressionTypeName();
}

void isCompressionLossless_test_5339(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.isCompressionLossless();
}

void setCompressionQuality_test_5340(float p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.setCompressionQuality(p0);
}

void getCompressionQuality_test_5341(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionQuality();
}

void getBitRate_test_5342(float p0, const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getBitRate(p0);
}

void getCompressionQualityDescriptions_test_5343(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionQualityDescriptions();
}

void getCompressionQualityValues_test_5344(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getCompressionQualityValues();
}

void getLocale_test_5345(const Locale& c0) {
    ImageWriteParam instance(c0);
    instance.getLocale();
}
```