```cpp
#include <vector>

class BatchUpdateException {
public:
    BatchUpdateException() = default;
    
    std::vector<int> getUpdateCounts() const {
        return {};
    }
    
    std::vector<long long> getLargeUpdateCounts() const {
        return {};
    }
};

void getLargeUpdateCounts_test_2937() {
    BatchUpdateException instance;
    instance.getLargeUpdateCounts();
}

void getUpdateCounts_test_2938() {
    BatchUpdateException instance;
    instance.getUpdateCounts();
}
```