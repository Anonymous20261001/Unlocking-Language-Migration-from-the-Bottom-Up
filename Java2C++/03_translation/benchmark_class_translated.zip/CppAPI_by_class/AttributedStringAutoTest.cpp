```cpp
#include <string>
#include <vector>
#include <map>
#include <any>
#include <memory>
#include <iostream>
#include <stdexcept>

// ---------------------------------------------------------------------------
// Forward declarations and class implementations
// ---------------------------------------------------------------------------

class AttributedCharacterIterator {
public:
    // Inner class Attribute (simplified, uses name as identifier)
    class Attribute {
    public:
        explicit Attribute(const std::string& name) : name_(name) {}
        const std::string& getName() const { return name_; }
        bool operator<(const Attribute& other) const { return name_ < other.name_; }
    private:
        std::string name_;
    };

    // Minimal placeholder – tests do not call any methods on the iterator
    // In a full implementation this would provide iteration over attributes.
    AttributedCharacterIterator() = default;
    AttributedCharacterIterator(const AttributedCharacterIterator&) = default;
    AttributedCharacterIterator& operator=(const AttributedCharacterIterator&) = default;
};

// ---------------------------------------------------------------------------
// AttributedString class – simplified implementation matching Java API
// ---------------------------------------------------------------------------

class AttributedString {
public:
    explicit AttributedString(const std::string& text) : text_(text) {}

    // Add a single attribute to the whole string
    void addAttribute(const AttributedCharacterIterator::Attribute& attr,
                     const std::any& value) {
        addAttribute(attr, value, 0, static_cast<int>(text_.length()));
    }

    // Add a single attribute to a specific range
    void addAttribute(const AttributedCharacterIterator::Attribute& attr,
                     const std::any& value,
                     int beginIndex,
                     int endIndex) {
        if (beginIndex < 0 || endIndex > static_cast<int>(text_.length()) || beginIndex > endIndex) {
            throw std::out_of_range("Invalid attribute range");
        }
        AttributeRange range{beginIndex, endIndex, {}};
        range.attribs[attr.getName()] = value;
        ranges_.push_back(range);
    }

    // Add multiple attributes (a map) to a specific range
    void addAttributes(const std::map<AttributedCharacterIterator::Attribute, std::any>& attrs,
                      int beginIndex,
                      int endIndex) {
        if (beginIndex < 0 || endIndex > static_cast<int>(text_.length()) || beginIndex > endIndex) {
            throw std::out_of_range("Invalid attribute range");
        }
        AttributeRange range{beginIndex, endIndex, {}};
        for (const auto& [attr, val] : attrs) {
            range.attribs[attr.getName()] = val;
        }
        ranges_.push_back(range);
    }

    // Get an iterator covering the whole string with all attributes
    AttributedCharacterIterator getIterator() {
        // Return a dummy iterator – no actual implementation needed for these tests
        return AttributedCharacterIterator();
    }

    // Get an iterator covering the whole string filtered to specific attributes
    AttributedCharacterIterator getIterator(
        const std::vector<AttributedCharacterIterator::Attribute>& /* attrs */) {
        return AttributedCharacterIterator();
    }

    // Get an iterator covering a subrange with specific attribute filter
    AttributedCharacterIterator getIterator(
        const std::vector<AttributedCharacterIterator::Attribute>& /* attrs */,
        int /* beginIndex */,
        int /* endIndex */) {
        return AttributedCharacterIterator();
    }

private:
    struct AttributeRange {
        int start;
        int end;
        std::map<std::string, std::any> attribs;
    };

    std::string text_;
    std::vector<AttributeRange> ranges_;
};

// ---------------------------------------------------------------------------
// Translated test functions (matching Java @Test methods exactly)
// ---------------------------------------------------------------------------

// Helper type aliases to match Java signatures
using Map = std::map<AttributedCharacterIterator::Attribute, std::any>;
using AttributeArray = std::vector<AttributedCharacterIterator::Attribute>;

void addAttributes_test_2996(Map p0, int p1, int p2, std::string c0) {
    AttributedString instance(c0);
    instance.addAttributes(p0, p1, p2);
}

void getIterator_test_2997(AttributeArray p0, std::string c0) {
    AttributedString instance(c0);
    instance.getIterator(p0);
}

void getIterator_test_2998(AttributeArray p0, int p1, int p2, std::string c0) {
    AttributedString instance(c0);
    instance.getIterator(p0, p1, p2);
}

void getIterator_test_2999(std::string c0) {
    AttributedString instance(c0);
    instance.getIterator();
}

void addAttribute_test_3000(AttributedCharacterIterator::Attribute p0, std::any p1, std::string c0) {
    AttributedString instance(c0);
    instance.addAttribute(p0, p1);
}

void addAttribute_test_3001(AttributedCharacterIterator::Attribute p0, std::any p1, int p2, int p3, std::string c0) {
    AttributedString instance(c0);
    instance.addAttribute(p0, p1, p2, p3);
}

// ---------------------------------------------------------------------------
// (Optional) main to demonstrate compilability and basic usage
// ---------------------------------------------------------------------------

int main() {
    // Run each test with dummy values
    {
        Map emptyMap;
        addAttributes_test_2996(emptyMap, 0, 0, "");
    }
    {
        AttributeArray emptyArr;
        getIterator_test_2997(emptyArr, "hello");
    }
    {
        AttributeArray emptyArr;
        getIterator_test_2998(emptyArr, 0, 5, "world");
    }
    {
        getIterator_test_2999("test");
    }
    {
        AttributedCharacterIterator::Attribute attr("font");
        addAttribute_test_3000(attr, std::any(42), "example");
    }
    {
        AttributedCharacterIterator::Attribute attr("size");
        addAttribute_test_3001(attr, std::any(12.5), 1, 3, "sample");
    }

    std::cout << "All test functions executed successfully (no assertions)." << std::endl;
    return 0;
}
```