```cpp
#include <string>

// Minimal BigInteger-like class (for demonstration, we use std::string)
class ECPoint {
public:
    ECPoint() = default;
    ECPoint(const std::string& affineX, const std::string& affineY)
        : affineX_(affineX), affineY_(affineY) {}

    // Getters for completeness (not used in tests)
    const std::string& getAffineX() const { return affineX_; }
    const std::string& getAffineY() const { return affineY_; }

private:
    std::string affineX_;
    std::string affineY_;
};

// Minimal ECParameterSpec (stores nothing meaningful for these tests)
class ECParameterSpec {
public:
    ECParameterSpec() = default;
};

// ECPublicKeySpec mimicking Java's java.security.spec.ECPublicKeySpec
class ECPublicKeySpec {
public:
    ECPublicKeySpec(const ECPoint& w, const ECParameterSpec& params)
        : w_(w), params_(params) {}

    const ECParameterSpec& getParams() const { return params_; }
    const ECPoint& getW() const { return w_; }

private:
    ECPoint w_;
    ECParameterSpec params_;
};

// Test functions (exact names from Java)
void getParams_test_2879(const ECPoint& c0, const ECParameterSpec& c1) {
    ECPublicKeySpec instance(c0, c1);
    instance.getParams();
}

void getW_test_2880(const ECPoint& c0, const ECParameterSpec& c1) {
    ECPublicKeySpec instance(c0, c1);
    instance.getW();
}
```