```cpp
#include <vector>
#include <algorithm>
#include <typeinfo>

// Forward declarations
class DefaultSingleSelectionModel;
class ChangeEvent;
class ChangeListener;

// ChangeEvent class (simple)
class ChangeEvent {
public:
    DefaultSingleSelectionModel* source;
    explicit ChangeEvent(DefaultSingleSelectionModel* src) : source(src) {}
};

// ChangeListener interface
class ChangeListener {
public:
    virtual void stateChanged(ChangeEvent& event) = 0;
    virtual ~ChangeListener() = default;
};

// DefaultSingleSelectionModel implementation
class DefaultSingleSelectionModel {
private:
    int selectedIndex;
    std::vector<ChangeListener*> changeListeners;

    // Notify all registered listeners
    void fireStateChanged() {
        ChangeEvent event(this);
        for (ChangeListener* listener : changeListeners) {
            if (listener) {
                listener->stateChanged(event);
            }
        }
    }

public:
    DefaultSingleSelectionModel() : selectedIndex(-1) {}

    void clearSelection() {
        selectedIndex = -1;
        fireStateChanged();
    }

    void addChangeListener(ChangeListener* listener) {
        if (listener) {
            changeListeners.push_back(listener);
        }
    }

    void removeChangeListener(ChangeListener* listener) {
        auto it = std::remove(changeListeners.begin(), changeListeners.end(), listener);
        changeListeners.erase(it, changeListeners.end());
    }

    std::vector<ChangeListener*> getChangeListeners() const {
        return changeListeners;
    }

    void setSelectedIndex(int index) {
        // In Swing, this fires even if index is same (but typical implementation checks)
        // We mimic the exact behavior: fire event unconditionally (as in the JDK)
        selectedIndex = index;
        fireStateChanged();
    }

    // getListeners with type_info – mirroring Java's getListeners(Class)
    // For this model, only ChangeListener type is supported.
    std::vector<ChangeListener*> getListeners(const std::type_info& type) const {
        if (type == typeid(ChangeListener)) {
            return changeListeners;
        }
        return {};
    }

    int getSelectedIndex() const {
        return selectedIndex;
    }

    bool isSelected() const {
        return selectedIndex != -1;
    }
};

// ==================== Test Functions ====================

void clearSelection_test_6796() {
    DefaultSingleSelectionModel instance;
    instance.clearSelection();
}

void addChangeListener_test_6797(ChangeListener* p0) {
    DefaultSingleSelectionModel instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_6798(ChangeListener* p0) {
    DefaultSingleSelectionModel instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_6799() {
    DefaultSingleSelectionModel instance;
    instance.getChangeListeners();
}

void setSelectedIndex_test_6800(int p0) {
    DefaultSingleSelectionModel instance;
    instance.setSelectedIndex(p0);
}

void getListeners_test_6801(const std::type_info& p0) {
    DefaultSingleSelectionModel instance;
    instance.getListeners(p0);
}

void getSelectedIndex_test_6802() {
    DefaultSingleSelectionModel instance;
    instance.getSelectedIndex();
}

void isSelected_test_6803() {
    DefaultSingleSelectionModel instance;
    instance.isSelected();
}
```