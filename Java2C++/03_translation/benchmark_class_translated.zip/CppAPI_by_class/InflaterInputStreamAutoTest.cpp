```cpp
#include <stdexcept>
#include <iostream>

// ---------- InputStream (abstract base) ----------
class InputStream {
public:
    virtual ~InputStream() = default;
    virtual void mark(int readlimit) = 0;
    virtual bool markSupported() = 0;
};

// ---------- ByteArrayInputStream (concrete, mock) ----------
class ByteArrayInputStream : public InputStream {
private:
    // Minimal implementation: mark is supported, but does nothing useful.
    bool mark_supported = true;
    int pos = 0;
public:
    void mark(int readlimit) override {
        // store position for eventual reset, but we don't use it.
        pos = 0; // dummy
    }
    bool markSupported() override {
        return mark_supported;
    }
};

// ---------- FilterInputStream (delegates to underlying stream) ----------
class FilterInputStream : public InputStream {
protected:
    InputStream& in;
public:
    explicit FilterInputStream(InputStream& input) : in(input) {}
    void mark(int readlimit) override {
        in.mark(readlimit);
    }
    bool markSupported() override {
        return in.markSupported();
    }
};

// ---------- InflaterInputStream (overrides mark/markSupported to disable) ----------
class InflaterInputStream : public FilterInputStream {
public:
    explicit InflaterInputStream(InputStream& input) : FilterInputStream(input) {}
    void mark(int readlimit) override {
        // Java's InflaterInputStream throws IOException ("mark not supported")
        throw std::runtime_error("mark not supported");
    }
    bool markSupported() override {
        return false;
    }
};

// ---------- Test functions (translated from Java @Test) ----------
void mark_test_5180(int p0, InputStream& c0) {
    InflaterInputStream instance(c0);
    instance.mark(p0);
}

void markSupported_test_5181(InputStream& c0) {
    InflaterInputStream instance(c0);
    instance.markSupported();
}

// ---------- Main to demonstrate ----------
int main() {
    ByteArrayInputStream byteStream;       // concrete input stream
    int p0 = 100;                         // dummy readlimit

    // Test markSupported_test_5181 (should not throw)
    std::cout << "Running markSupported_test_5181... ";
    markSupported_test_5181(byteStream);
    std::cout << "OK (returned false implicitly)" << std::endl;

    // Test mark_test_5180 (will throw because mark is not supported)
    std::cout << "Running mark_test_5180... ";
    try {
        mark_test_5180(p0, byteStream);
        std::cout << "Unexpected success" << std::endl;
    } catch (const std::runtime_error& e) {
        std::cout << "Caught expected exception: " << e.what() << std::endl;
    }

    return 0;
}
```