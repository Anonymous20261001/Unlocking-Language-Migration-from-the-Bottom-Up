```cpp
#include <string>

// Base class to mimic Java's Object
class Object {
public:
    virtual ~Object() = default;
};

// C++ equivalent of javax.print.attribute.standard.JobMediaSheets
class JobMediaSheets : public Object {
public:
    explicit JobMediaSheets(int value) : value_(value) {}

    std::string getCategory() const {
        return "javax.print.attribute.standard.JobMediaSheets";
    }

    std::string getName() const {
        return "job-media-sheets";
    }

    bool equals(const Object& obj) const {
        const JobMediaSheets* other = dynamic_cast<const JobMediaSheets*>(&obj);
        return other != nullptr && value_ == other->value_;
    }

    int getValue() const {
        return value_;
    }

private:
    int value_;
};

// Test function for getCategory
void getCategory_test_6142(int c0) {
    JobMediaSheets instance(c0);
    instance.getCategory();
}

// Test function for getName
void getName_test_6143(int c0) {
    JobMediaSheets instance(c0);
    instance.getName();
}

// Test function for equals
void equals_test_6144(const Object& p0, int c0) {
    JobMediaSheets instance(c0);
    instance.equals(p0);
}
```