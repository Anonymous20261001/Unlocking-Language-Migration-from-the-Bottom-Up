```cpp
#include <string>

class IllformedLocaleException {
private:
    int errorIndex;
    std::string message;

public:
    IllformedLocaleException() : errorIndex(-1), message() {}
    IllformedLocaleException(const std::string& msg) : errorIndex(-1), message(msg) {}
    IllformedLocaleException(const std::string& msg, int idx) : errorIndex(idx), message(msg) {}

    int getErrorIndex() const {
        return errorIndex;
    }

    // Optional: to mimic Java's getMessage() if needed
    const std::string& getMessage() const {
        return message;
    }
};

void getErrorIndex_test_3575() {
    IllformedLocaleException instance;
    instance.getErrorIndex();
}
```