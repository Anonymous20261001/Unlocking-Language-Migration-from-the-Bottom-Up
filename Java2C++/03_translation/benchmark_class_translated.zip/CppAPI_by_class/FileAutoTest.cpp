```cpp
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <ctime>
#include <any>
#include <functional>
#include <memory>
#include <cstring>
#include <algorithm>
#include <system_error>

namespace fs = std::filesystem;

// Forward declarations
class File;
class FilenameFilter;
class FileFilter;

// ---------------------------------------------------------------------------
// FilenameFilter (interface)
// ---------------------------------------------------------------------------
class FilenameFilter {
public:
    virtual ~FilenameFilter() = default;
    virtual bool accept(const File& dir, const std::string& name) const = 0;
};

// ---------------------------------------------------------------------------
// FileFilter (interface)
// ---------------------------------------------------------------------------
class FileFilter {
public:
    virtual ~FileFilter() = default;
    virtual bool accept(const File& pathname) const = 0;
};

// ---------------------------------------------------------------------------
// File class (mimics java.io.File)
// ---------------------------------------------------------------------------
class File {
private:
    std::string path;

    // Helper: normalize path (remove trailing separators except root)
    static std::string normalize(const std::string& p) {
        if (p.empty()) return p;
        std::string s = p;
        // replace backslashes with forward slashes for consistency
        std::replace(s.begin(), s.end(), '\\', '/');
        // remove trailing '/' except for root "/" or "C:/"
        while (s.size() > 1 && s.back() == '/')
            s.pop_back();
        return s;
    }

    // Helper: resolve relative path against current working directory
    std::string resolve() const {
        if (isAbsolute()) return path;
        return normalize(fs::current_path().string() + "/" + path);
    }

public:
    // Constructor
    explicit File(const std::string& pathname) : path(normalize(pathname)) {}

    // Default constructor (for listRoots)
    File() : path("") {}

    // Accessor
    const std::string& getPath() const { return path; }

    // -----------------------------------------------------------------------
    // Methods
    // -----------------------------------------------------------------------
    std::string getName() const {
        // find last separator
        auto pos = path.find_last_of('/');
        if (pos == std::string::npos)
            return path;
        return path.substr(pos + 1);
    }

    // equals: compare with another File or with a string (mimics Java Object.equals)
    bool equals(const std::any& obj) const {
        if (obj.type() == typeid(File)) {
            return path == std::any_cast<File>(obj).path;
        }
        if (obj.type() == typeid(std::string)) {
            return path == normalize(std::any_cast<std::string>(obj));
        }
        return false;
    }

    int64_t length() const {
        std::error_code ec;
        auto size = fs::file_size(resolve(), ec);
        return ec ? 0 : static_cast<int64_t>(size);
    }

    std::string toString() const {
        return path;
    }

    size_t hashCode() const {
        return std::hash<std::string>{}(path);
    }

    bool isHidden() const {
        // simple: check if dot file (Unix) or hidden attribute (Windows)
        auto name = getName();
        if (!name.empty() && name[0] == '.')
            return true;
#ifdef _WIN32
        DWORD attrs = GetFileAttributesA(path.c_str());
        return (attrs != INVALID_FILE_ATTRIBUTES) && (attrs & FILE_ATTRIBUTE_HIDDEN);
#else
        return false;
#endif
    }

    int compareTo(const File& other) const {
        return path.compare(other.path);
    }

    std::vector<std::string> list() const {
        std::vector<std::string> result;
        if (!isDirectory()) return result;
        for (const auto& entry : fs::directory_iterator(resolve())) {
            result.push_back(entry.path().filename().string());
        }
        return result;
    }

    std::vector<std::string> list(const FilenameFilter& filter) const {
        std::vector<std::string> all = list();
        std::vector<std::string> filtered;
        for (const auto& name : all) {
            File child(resolve() + "/" + name);
            if (filter.accept(child, name))
                filtered.push_back(name);
        }
        return filtered;
    }

    bool isAbsolute() const {
        // simple: starts with '/' or has drive letter (Windows)
        if (path.empty()) return false;
#ifdef _WIN32
        if (path.size() >= 2 && std::isalpha(path[0]) && path[1] == ':')
            return true;
#endif
        return path[0] == '/';
    }

    std::string getParent() const {
        auto pos = path.find_last_of('/');
        if (pos == std::string::npos)
            return "";
        if (pos == 0) // root
            return "/";
        return path.substr(0, pos);
    }

    bool setReadOnly() {
        std::error_code ec;
        fs::permissions(resolve(), fs::perms::owner_write, fs::perm_options::remove, ec);
        return !ec;
    }

    bool canRead() const {
        std::error_code ec;
        auto status = fs::status(resolve(), ec);
        return !ec && ((status.permissions() & fs::perms::owner_read) != fs::perms::none);
    }

    bool deleteFile() {  // avoid keyword 'delete'
        std::error_code ec;
        fs::remove(resolve(), ec);
        return !ec;
    }

    std::string getAbsolutePath() const {
        return fs::absolute(resolve()).string();
    }

    std::string toURI() const {
        // simple file URI
        std::string abs = getAbsolutePath();
        // Replace backslashes with forward slashes
        std::replace(abs.begin(), abs.end(), '\\', '/');
        // Ensure it starts with "/" for Windows drives: "C:/" -> "file:///C:/"
        if (abs.size() >= 2 && std::isalpha(abs[0]) && abs[1] == ':') {
            return "file:///" + abs;
        }
        return "file://" + abs;
    }

    bool exists() const {
        std::error_code ec;
        return fs::exists(resolve(), ec);
    }

    bool renameTo(const File& dest) {
        std::error_code ec;
        fs::rename(resolve(), dest.resolve(), ec);
        return !ec;
    }

    bool isDirectory() const {
        std::error_code ec;
        return fs::is_directory(resolve(), ec);
    }

    File getAbsoluteFile() const {
        return File(getAbsolutePath());
    }

    bool mkdir() {
        std::error_code ec;
        fs::create_directory(resolve(), ec);
        return !ec;
    }

    File getParentFile() const {
        std::string parent = getParent();
        if (parent.empty())
            return File();  // null-like empty File
        return File(parent);
    }

    bool mkdirs() {
        std::error_code ec;
        fs::create_directories(resolve(), ec);
        return !ec;
    }

    bool setWritable(bool writable, bool ownerOnly = true) {
        std::error_code ec;
        auto perm = fs::perms::owner_write;
        if (!ownerOnly) {
            perm = perm | fs::perms::group_write | fs::perms::others_write;
        }
        if (writable)
            fs::permissions(resolve(), perm, fs::perm_options::add, ec);
        else
            fs::permissions(resolve(), perm, fs::perm_options::remove, ec);
        return !ec;
    }

    // overload with two booleans: setWritable(boolean writable, boolean ownerOnly)
    bool setWritable(bool writable, bool ownerOnly) {
        return setWritable(writable, ownerOnly);
    }

    bool setReadable(bool readable, bool ownerOnly = true) {
        std::error_code ec;
        auto perm = fs::perms::owner_read;
        if (!ownerOnly) {
            perm = perm | fs::perms::group_read | fs::perms::others_read;
        }
        if (readable)
            fs::permissions(resolve(), perm, fs::perm_options::add, ec);
        else
            fs::permissions(resolve(), perm, fs::perm_options::remove, ec);
        return !ec;
    }

    bool setReadable(bool readable, bool ownerOnly) {
        return setReadable(readable, ownerOnly);
    }

    bool setExecutable(bool executable, bool ownerOnly = true) {
        std::error_code ec;
        auto perm = fs::perms::owner_exec;
        if (!ownerOnly) {
            perm = perm | fs::perms::group_exec | fs::perms::others_exec;
        }
        if (executable)
            fs::permissions(resolve(), perm, fs::perm_options::add, ec);
        else
            fs::permissions(resolve(), perm, fs::perm_options::remove, ec);
        return !ec;
    }

    bool setExecutable(bool executable, bool ownerOnly) {
        return setExecutable(executable, ownerOnly);
    }

    static std::vector<File> listRoots() {
        std::vector<File> roots;
        for (const auto& root : fs::directory_iterator("/")) {
            // On Unix, every entry is a root? Actually "/" is root.
            // On Windows, we would need to list drives.
            // Simpler: just return "/"
            roots.emplace_back("/");
            break;
        }
        // For Windows, we could use GetLogicalDrives, but keeping cross-platform.
        return roots;
    }

    bool canWrite() const {
        std::error_code ec;
        auto status = fs::status(resolve(), ec);
        return !ec && ((status.permissions() & fs::perms::owner_write) != fs::perms::none);
    }

    bool isFile() const {
        std::error_code ec;
        return fs::is_regular_file(resolve(), ec);
    }

    int64_t lastModified() const {
        std::error_code ec;
        auto ftime = fs::last_write_time(resolve(), ec);
        if (ec) return 0;
        // Convert to seconds since epoch
        auto epoch = ftime.time_since_epoch();
        return std::chrono::duration_cast<std::chrono::seconds>(epoch).count();
    }

    void deleteOnExit() {
        // Register a static cleanup function
        static std::vector<std::string> filesToDelete;
        filesToDelete.push_back(resolve());
        static bool cleanupRegistered = false;
        if (!cleanupRegistered) {
            std::atexit([](){
                for (const auto& f : filesToDelete) {
                    fs::remove(f);
                }
            });
            cleanupRegistered = true;
        }
    }

    std::vector<File> listFiles() const {
        std::vector<File> result;
        if (!isDirectory()) return result;
        for (const auto& entry : fs::directory_iterator(resolve())) {
            result.emplace_back(entry.path().string());
        }
        return result;
    }

    std::vector<File> listFiles(const FileFilter& filter) const {
        std::vector<File> all = listFiles();
        std::vector<File> filtered;
        for (const auto& f : all) {
            if (filter.accept(f))
                filtered.push_back(f);
        }
        return filtered;
    }

    std::vector<File> listFiles(const FilenameFilter& filter) const {
        std::vector<File> all = listFiles();
        std::vector<File> filtered;
        for (const auto& f : all) {
            if (filter.accept(f, f.getName()))
                filtered.push_back(f);
        }
        return filtered;
    }

    bool setLastModified(int64_t time) {
        // convert to filesystem time
        auto tp = std::chrono::system_clock::from_time_t(static_cast<std::time_t>(time));
        std::error_code ec;
        fs::last_write_time(resolve(), tp, ec);
        return !ec;
    }

    bool canExecute() const {
        std::error_code ec;
        auto status = fs::status(resolve(), ec);
        return !ec && ((status.permissions() & fs::perms::owner_exec) != fs::perms::none);
    }

    int64_t getTotalSpace() const {
        std::error_code ec;
        auto space = fs::space(resolve(), ec);
        return ec ? 0 : static_cast<int64_t>(space.capacity);
    }

    int64_t getFreeSpace() const {
        std::error_code ec;
        auto space = fs::space(resolve(), ec);
        return ec ? 0 : static_cast<int64_t>(space.free);
    }

    int64_t getUsableSpace() const {
        std::error_code ec;
        auto space = fs::space(resolve(), ec);
        return ec ? 0 : static_cast<int64_t>(space.available);
    }

    std::string toPath() const {
        return resolve();  // simply return the absolute/relative path
    }
};

// ---------------------------------------------------------------------------
// Test functions (translated from Java @Test methods)
// ---------------------------------------------------------------------------
void getName_test_1730(const std::string& c0) {
    File instance(c0);
    instance.getName();
}

void equals_test_1731(const std::any& p0, const std::string& c0) {
    File instance(c0);
    instance.equals(p0);
}

void length_test_1732(const std::string& c0) {
    File instance(c0);
    instance.length();
}

void toString_test_1733(const std::string& c0) {
    File instance(c0);
    instance.toString();
}

void hashCode_test_1734(const std::string& c0) {
    File instance(c0);
    instance.hashCode();
}

void isHidden_test_1735(const std::string& c0) {
    File instance(c0);
    instance.isHidden();
}

void compareTo_test_1736(const File& p0, const std::string& c0) {
    File instance(c0);
    instance.compareTo(p0);
}

void list_test_1737(const std::string& c0) {
    File instance(c0);
    instance.list();
}

void list_test_1738(const FilenameFilter& p0, const std::string& c0) {
    File instance(c0);
    instance.list(p0);
}

void isAbsolute_test_1739(const std::string& c0) {
    File instance(c0);
    instance.isAbsolute();
}

void getParent_test_1740(const std::string& c0) {
    File instance(c0);
    instance.getParent();
}

void setReadOnly_test_1741(const std::string& c0) {
    File instance(c0);
    instance.setReadOnly();
}

void canRead_test_1742(const std::string& c0) {
    File instance(c0);
    instance.canRead();
}

void delete_test_1743(const std::string& c0) {
    File instance(c0);
    instance.deleteFile();
}

void getPath_test_1744(const std::string& c0) {
    File instance(c0);
    instance.getPath();
}

void toURI_test_1745(const std::string& c0) {
    File instance(c0);
    instance.toURI();
}

void getAbsolutePath_test_1746(const std::string& c0) {
    File instance(c0);
    instance.getAbsolutePath();
}

void exists_test_1747(const std::string& c0) {
    File instance(c0);
    instance.exists();
}

void renameTo_test_1748(const File& p0, const std::string& c0) {
    File instance(c0);
    instance.renameTo(p0);
}

void isDirectory_test_1749(const std::string& c0) {
    File instance(c0);
    instance.isDirectory();
}

void getAbsoluteFile_test_1750(const std::string& c0) {
    File instance(c0);
    instance.getAbsoluteFile();
}

void mkdir_test_1751(const std::string& c0) {
    File instance(c0);
    instance.mkdir();
}

void getParentFile_test_1752(const std::string& c0) {
    File instance(c0);
    instance.getParentFile();
}

void mkdirs_test_1753(const std::string& c0) {
    File instance(c0);
    instance.mkdirs();
}

void setWritable_test_1754(bool p0, const std::string& c0) {
    File instance(c0);
    instance.setWritable(p0);
}

void setWritable_test_1755(bool p0, bool p1, const std::string& c0) {
    File instance(c0);
    instance.setWritable(p0, p1);
}

void setReadable_test_1756(bool p0, bool p1, const std::string& c0) {
    File instance(c0);
    instance.setReadable(p0, p1);
}

void setReadable_test_1757(bool p0, const std::string& c0) {
    File instance(c0);
    instance.setReadable(p0);
}

void setExecutable_test_1758(bool p0, bool p1, const std::string& c0) {
    File instance(c0);
    instance.setExecutable(p0, p1);
}

void setExecutable_test_1759(bool p0, const std::string& c0) {
    File instance(c0);
    instance.setExecutable(p0);
}

void listRoots_test_1760(const std::string& c0) {
    File instance(c0);  // unused? Java test creates File then calls static
    File::listRoots();
}

void canWrite_test_1761(const std::string& c0) {
    File instance(c0);
    instance.canWrite();
}

void isFile_test_1762(const std::string& c0) {
    File instance(c0);
    instance.isFile();
}

void lastModified_test_1763(const std::string& c0) {
    File instance(c0);
    instance.lastModified();
}

void deleteOnExit_test_1764(const std::string& c0) {
    File instance(c0);
    instance.deleteOnExit();
}

void listFiles_test_1765(const FileFilter& p0, const std::string& c0) {
    File instance(c0);
    instance.listFiles(p0);
}

void listFiles_test_1766(const FilenameFilter& p0, const std::string& c0) {
    File instance(c0);
    instance.listFiles(p0);
}

void listFiles_test_1767(const std::string& c0) {
    File instance(c0);
    instance.listFiles();
}

void setLastModified_test_1768(int64_t p0, const std::string& c0) {
    File instance(c0);
    instance.setLastModified(p0);
}

void canExecute_test_1769(const std::string& c0) {
    File instance(c0);
    instance.canExecute();
}

void getTotalSpace_test_1770(const std::string& c0) {
    File instance(c0);
    instance.getTotalSpace();
}

void getFreeSpace_test_1771(const std::string& c0) {
    File instance(c0);
    instance.getFreeSpace();
}

void getUsableSpace_test_1772(const std::string& c0) {
    File instance(c0);
    instance.getUsableSpace();
}

void toPath_test_1773(const std::string& c0) {
    File instance(c0);
    instance.toPath();
}
```