```cpp
#include <memory>
#include <vector>
#include <cmath>
#include <cstdint>

// ----- Base classes mimicking java.lang.Object and java.awt.Shape -----

class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const {
        return this == &other;   // identity comparison like Java default
    }
    virtual int hashCode() const {
        return reinterpret_cast<std::intptr_t>(this);
    }
};

class Shape {
public:
    virtual ~Shape() = default;
};

// A concrete shape used for return values
class SimpleShape : public Shape {};

// ----- BasicStroke implementation -----

class BasicStroke : public Object {
private:
    float width;
    int cap;
    int join;
    float miterLimit;
    std::vector<float> dashArray;
    float dashPhase;

public:
    // Constants
    static const int CAP_BUTT   = 0;
    static const int CAP_ROUND  = 1;
    static const int CAP_SQUARE = 2;
    static const int JOIN_MITER = 0;
    static const int JOIN_ROUND = 1;
    static const int JOIN_BEVEL = 2;

    // Default constructor (matches Java default stroke)
    BasicStroke()
        : width(1.0f),
          cap(CAP_SQUARE),
          join(JOIN_MITER),
          miterLimit(10.0f),
          dashArray(),
          dashPhase(0.0f) {}

    // Full constructor (not used in tests but available for completeness)
    BasicStroke(float width, int cap, int join, float miterLimit,
                const std::vector<float>& dashArray, float dashPhase)
        : width(width),
          cap(cap),
          join(join),
          miterLimit(miterLimit),
          dashArray(dashArray),
          dashPhase(dashPhase) {}

    // API methods
    std::unique_ptr<Shape> createStrokedShape(const Shape&) const {
        return std::make_unique<SimpleShape>();
    }

    float getLineWidth() const { return width; }
    int getEndCap() const { return cap; }
    int getLineJoin() const { return join; }
    float getMiterLimit() const { return miterLimit; }
    std::vector<float> getDashArray() const { return dashArray; }
    float getDashPhase() const { return dashPhase; }

    // Override Object methods
    bool equals(const Object& obj) const override {
        if (this == &obj) return true;
        const BasicStroke* other = dynamic_cast<const BasicStroke*>(&obj);
        if (!other) return false;
        return (width == other->width) &&
               (cap == other->cap) &&
               (join == other->join) &&
               (miterLimit == other->miterLimit) &&
               (dashArray == other->dashArray) &&
               (dashPhase == other->dashPhase);
    }

    int hashCode() const override {
        int result = 1;
        result = 31 * result + std::hash<float>{}(width);
        result = 31 * result + cap;
        result = 31 * result + join;
        result = 31 * result + std::hash<float>{}(miterLimit);
        for (float d : dashArray) {
            result = 31 * result + std::hash<float>{}(d);
        }
        result = 31 * result + std::hash<float>{}(dashPhase);
        return result;
    }
};

// ----- Test functions (direct translation of Java @Test methods) -----

void createStrokedShape_test_1(Shape& p0) {
    BasicStroke instance;
    instance.createStrokedShape(p0);
}

void getLineWidth_test_2() {
    BasicStroke instance;
    instance.getLineWidth();
}

void getEndCap_test_3() {
    BasicStroke instance;
    instance.getEndCap();
}

void getLineJoin_test_4() {
    BasicStroke instance;
    instance.getLineJoin();
}

void getMiterLimit_test_5() {
    BasicStroke instance;
    instance.getMiterLimit();
}

void getDashArray_test_6() {
    BasicStroke instance;
    instance.getDashArray();
}

void getDashPhase_test_7() {
    BasicStroke instance;
    instance.getDashPhase();
}

void equals_test_8(Object& p0) {
    BasicStroke instance;
    instance.equals(p0);
}

void hashCode_test_9() {
    BasicStroke instance;
    instance.hashCode();
}
```