Below is the complete C++ implementation, including stub classes that mimic the Java API behavior and the translated test functions. The test functions are written as free functions that can be called from any test runner (e.g., Google Test, Catch2, or a simple `main`). For clarity, the `Graphics`, `Point`, `JComponent`, and `JList` classes are provided as minimal stubs; all methods are no-ops or return default values as the original Java tests do not verify return values.

```cpp
#include <iostream>
#include <memory>
#include <utility>

// ----------------------------------------------------------------------------
// Minimal stubs for Java classes used in the tests
// ----------------------------------------------------------------------------

namespace java {
namespace awt {

class Graphics {
public:
    virtual ~Graphics() = default;
    // Minimal implementation – no actual drawing
};

class Point {
public:
    int x, y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

} // namespace awt

namespace javax {
namespace swing {

class JComponent {
public:
    virtual ~JComponent() = default;
    // Stub – no real component behaviour
};

class JList : public JComponent {
public:
    JList() = default;
    // Could hold model etc., but not needed for these tests
};

} // namespace swing

namespace swing {
namespace plaf {
namespace basic {

class BasicListUI {
public:
    // Instance methods
    void installUI(JComponent* p0) {
        // No-op in stub
        (void)p0;
    }

    void uninstallUI(JComponent* p0) {
        (void)p0;
    }

    int locationToIndex(JList* p0, const awt::Point& p1) {
        (void)p0; (void)p1;
        return 0; // default
    }

    // getCellBounds returns a Rectangle, but in Java it returns Rectangle.
    // For simplicity we return a dummy pointer – tests don't check it.
    void* getCellBounds(JList* p0, int p1, int p2) {
        (void)p0; (void)p1; (void)p2;
        return nullptr;
    }

    awt::Point indexToLocation(JList* p0, int p1) {
        (void)p0; (void)p1;
        return awt::Point();
    }

    static BasicListUI* createUI(JComponent* p0) {
        (void)p0;
        return new BasicListUI();
    }

    void paint(awt::Graphics* p0, JComponent* p1) {
        (void)p0; (void)p1;
    }

    // getPreferredSize returns Dimension – stub returns null pointer.
    void* getPreferredSize(JComponent* p0) {
        (void)p0;
        return nullptr;
    }

    int getBaseline(JComponent* p0, int p1, int p2) {
        (void)p0; (void)p1; (void)p2;
        return 0;
    }

    // getBaselineResizeBehavior returns an enum – stub returns int 0.
    int getBaselineResizeBehavior(JComponent* p0) {
        (void)p0;
        return 0;
    }

    virtual ~BasicListUI() = default;
};

} // namespace basic
} // namespace plaf
} // namespace swing
} // namespace javax
} // namespace java

// ----------------------------------------------------------------------------
// Translated test functions (C++ free functions)
// ----------------------------------------------------------------------------

void installUI_test_8814(java::javax::swing::JComponent* p0) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.installUI(p0);
}

void uninstallUI_test_8815(java::javax::swing::JComponent* p0) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.uninstallUI(p0);
}

void locationToIndex_test_8816(java::javax::swing::JList* p0, java::awt::Point p1) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.locationToIndex(p0, p1);
}

void getCellBounds_test_8817(java::javax::swing::JList* p0, int p1, int p2) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.getCellBounds(p0, p1, p2);
}

void indexToLocation_test_8818(java::javax::swing::JList* p0, int p1) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.indexToLocation(p0, p1);
}

void createUI_test_8819(java::javax::swing::JComponent* p0) {
    // Static method – returns a newly allocated UI object.
    // In a real test you might delete it, but here we ignore the result.
    java::javax::swing::plaf::basic::BasicListUI::createUI(p0);
}

void paint_test_8820(java::awt::Graphics* p0, java::javax::swing::JComponent* p1) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.paint(p0, p1);
}

void getPreferredSize_test_8821(java::javax::swing::JComponent* p0) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.getPreferredSize(p0);
}

void getBaseline_test_8822(java::javax::swing::JComponent* p0, int p1, int p2) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.getBaseline(p0, p1, p2);
}

void getBaselineResizeBehavior_test_8823(java::javax::swing::JComponent* p0) {
    auto instance = java::javax::swing::plaf::basic::BasicListUI();
    instance.getBaselineResizeBehavior(p0);
}

// ----------------------------------------------------------------------------
// Optional: a simple main that runs all tests with dummy arguments
// ----------------------------------------------------------------------------
int main() {
    java::javax::swing::JComponent comp;
    java::javax::swing::JList list;
    java::awt::Graphics gfx;
    java::awt::Point pt(10, 20);

    installUI_test_8814(&comp);
    uninstallUI_test_8815(&comp);
    locationToIndex_test_8816(&list, pt);
    getCellBounds_test_8817(&list, 0, 5);
    indexToLocation_test_8818(&list, 3);
    createUI_test_8819(&comp);
    paint_test_8820(&gfx, &comp);
    getPreferredSize_test_8821(&comp);
    getBaseline_test_8822(&comp, 100, 30);
    getBaselineResizeBehavior_test_8823(&comp);

    std::cout << "All tests executed successfully (no crashes)" << std::endl;
    return 0;
}
```