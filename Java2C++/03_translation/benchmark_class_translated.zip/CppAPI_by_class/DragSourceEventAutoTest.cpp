```cpp
#include <cstddef>

// Forward declaration
class DragSourceContext;

// Simple Point class matching Java's java.awt.Point
class Point {
public:
    int x;
    int y;

    Point(int x = 0, int y = 0) : x(x), y(y) {}
};

// DragSourceEvent equivalent to java.awt.dnd.DragSourceEvent
class DragSourceEvent {
private:
    DragSourceContext* context;
    int x;
    int y;

public:
    // Constructor: DragSourceEvent(DragSourceContext)
    DragSourceEvent(DragSourceContext* c0) : context(c0), x(0), y(0) {}

    // Get the DragSourceContext
    DragSourceContext* getDragSourceContext() {
        return context;
    }

    // Get X coordinate
    int getX() {
        return x;
    }

    // Get Y coordinate
    int getY() {
        return y;
    }

    // Get location as a Point
    Point getLocation() {
        return Point(x, y);
    }
};

// DragSourceContext equivalent (minimal, not used in tests)
class DragSourceContext {
public:
    virtual ~DragSourceContext() {}
};

// Test functions (exactly one per Java @Test method)

void getDragSourceContext_test_714(DragSourceContext* c0) {
    DragSourceEvent instance(c0);
    instance.getDragSourceContext();
}

void getX_test_715(DragSourceContext* c0) {
    DragSourceEvent instance(c0);
    instance.getX();
}

void getY_test_716(DragSourceContext* c0) {
    DragSourceEvent instance(c0);
    instance.getY();
}

void getLocation_test_717(DragSourceContext* c0) {
    DragSourceEvent instance(c0);
    instance.getLocation();
}
```