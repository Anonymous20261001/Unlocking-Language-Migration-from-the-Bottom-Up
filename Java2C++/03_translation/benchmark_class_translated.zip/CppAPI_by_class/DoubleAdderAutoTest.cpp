```cpp
#include <string>

class DoubleAdder {
private:
    double value;

public:
    DoubleAdder() : value(0.0) {}

    void reset() {
        value = 0.0;
    }

    std::string toString() {
        return std::to_string(value);
    }

    int intValue() {
        return static_cast<int>(value);
    }

    long longValue() {
        return static_cast<long>(value);
    }

    float floatValue() {
        return static_cast<float>(value);
    }

    double doubleValue() {
        return value;
    }

    void add(double p0) {
        value += p0;
    }

    double sum() {
        return value;
    }

    double sumThenReset() {
        double old = value;
        value = 0.0;
        return old;
    }
};

// Test function definitions (one per Java @Test)

void reset_test_4954() {
    DoubleAdder instance;
    instance.reset();
}

void toString_test_4955() {
    DoubleAdder instance;
    instance.toString();
}

void intValue_test_4956() {
    DoubleAdder instance;
    instance.intValue();
}

void longValue_test_4957() {
    DoubleAdder instance;
    instance.longValue();
}

void floatValue_test_4958() {
    DoubleAdder instance;
    instance.floatValue();
}

void doubleValue_test_4959() {
    DoubleAdder instance;
    instance.doubleValue();
}

void add_test_4960(double p0) {
    DoubleAdder instance;
    instance.add(p0);
}

void sum_test_4961() {
    DoubleAdder instance;
    instance.sum();
}

void sumThenReset_test_4962() {
    DoubleAdder instance;
    instance.sumThenReset();
}

int main() {
    // Execute all test functions
    reset_test_4954();
    toString_test_4955();
    intValue_test_4956();
    longValue_test_4957();
    floatValue_test_4958();
    doubleValue_test_4959();
    add_test_4960(1.5);          // arbitrary double value
    sum_test_4961();
    sumThenReset_test_4962();
    return 0;
}
```