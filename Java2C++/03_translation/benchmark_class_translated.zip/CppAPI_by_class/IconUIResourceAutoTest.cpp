```cpp
#include <iostream>
#include <memory>

// Forward declarations
class Component;
class Graphics;
class Icon;

// Abstract base class for Icon
class Icon {
public:
    virtual ~Icon() = default;
    virtual int getIconWidth() const = 0;
    virtual int getIconHeight() const = 0;
    virtual void paintIcon(Component* comp, Graphics* g, int x, int y) = 0;
};

// Concrete wrapper class mimicking javax.swing.plaf.IconUIResource
class IconUIResource : public Icon {
private:
    Icon& wrappedIcon;

public:
    explicit IconUIResource(Icon& icon) : wrappedIcon(icon) {}

    int getIconWidth() const override {
        return wrappedIcon.getIconWidth();
    }

    int getIconHeight() const override {
        return wrappedIcon.getIconHeight();
    }

    void paintIcon(Component* comp, Graphics* g, int x, int y) override {
        wrappedIcon.paintIcon(comp, g, x, y);
    }
};

// Stub for java.awt.Component (empty placeholder)
class Component {
public:
    virtual ~Component() = default;
};

// Stub for java.awt.Graphics (empty placeholder)
class Graphics {
public:
    virtual ~Graphics() = default;
};

// Test functions (exact names from Java)
void getIconWidth_test_8587(Icon& c0) {
    IconUIResource instance(c0);
    instance.getIconWidth();
}

void getIconHeight_test_8588(Icon& c0) {
    IconUIResource instance(c0);
    instance.getIconHeight();
}

void paintIcon_test_8589(Component& p0, Graphics& p1, int p2, int p3, Icon& c0) {
    IconUIResource instance(c0);
    instance.paintIcon(&p0, &p1, p2, p3);
}
```