```cpp
#include <string>
#include <map>
#include <sstream>
#include <functional>

// C++ equivalent of javax.print.DocFlavor
class DocFlavor {
private:
    std::string mediaType;
    std::string mediaSubtype;
    std::string representationClassName;
    std::map<std::string, std::string> parameters;

public:
    // Constructor: mediaType/subtype only (simplified)
    DocFlavor(const std::string& mediaType, const std::string& mediaSubtype)
        : mediaType(mediaType), mediaSubtype(mediaSubtype) {
        // Representation class name is not set in this simplified version
        representationClassName = "";
    }

    const std::string& getMediaType() const {
        return mediaType;
    }

    const std::string& getMediaSubtype() const {
        return mediaSubtype;
    }

    const std::string& getRepresentationClassName() const {
        return representationClassName;
    }

    std::string getParameter(const std::string& key) const {
        auto it = parameters.find(key);
        if (it != parameters.end())
            return it->second;
        return ""; // Java returns null; empty string as substitute
    }

    std::string getMimeType() const {
        std::string mime = mediaType + "/" + mediaSubtype;
        if (!parameters.empty()) {
            mime += ";";
            for (const auto& p : parameters) {
                mime += p.first + "=" + p.second + ";";
            }
            mime.pop_back(); // remove trailing semicolon
        }
        return mime;
    }

    // Equals for string (treating the argument as a MIME type)
    bool equals(const std::string& other) const {
        return getMimeType() == other;
    }

    // Equals for another DocFlavor
    bool equals(const DocFlavor& other) const {
        return getMimeType() == other.getMimeType();
    }

    std::string toString() const {
        return getMimeType();
    }

    int hashCode() const {
        std::hash<std::string> hasher;
        return static_cast<int>(hasher(getMimeType()));
    }
};

// Translated test functions (plain C++)
void getMediaType_test_6074(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.getMediaType();
}

void getMediaSubtype_test_6075(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.getMediaSubtype();
}

void getRepresentationClassName_test_6076(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.getRepresentationClassName();
}

void getParameter_test_6077(std::string p0, std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.getParameter(p0);
}

void getMimeType_test_6078(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.getMimeType();
}

void equals_test_6079(std::string p0, std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.equals(p0);
}

void toString_test_6080(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.toString();
}

void hashCode_test_6081(std::string c0, std::string c1) {
    DocFlavor instance(c0, c1);
    instance.hashCode();
}
```