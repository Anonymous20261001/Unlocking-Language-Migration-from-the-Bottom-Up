```cpp
#include <string>
#include <vector>
#include <memory>

// Forward declarations
class Element;
class Shape;
class View;
class ViewFactory;
class DocumentEvent;
class Graphics;

// Position with Bias enum
class Position {
public:
    enum class Bias { Forward, Backward };
};

// Stub classes for Swing-like types
class Element {
public:
    virtual ~Element() = default;
};

class Shape {
public:
    virtual ~Shape() = default;
};

class View {
public:
    virtual ~View() = default;
};

class ViewFactory {
public:
    virtual ~ViewFactory() = default;
};

class DocumentEvent {
public:
    virtual ~DocumentEvent() = default;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

// ImageView class (partial stub implementation)
class ImageView : public View {
public:
    explicit ImageView(Element* elem) : element(elem) {}

    // Mimic Java API
    int viewToModel(float x, float y, Shape* a, Position::Bias* bias) { return 0; }
    std::string getToolTipText(float x, float y, Shape* a) { return ""; }
    void changedUpdate(DocumentEvent* e, Shape* a, ViewFactory* f) {}
    std::string getAltText() { return altText; }
    int getLoadingImageIcon() { return 0; }
    int getNoImageIcon() { return 0; }
    bool getLoadsSynchronously() { return sync; }
    void setLoadsSynchronously(bool b) { sync = b; }
    float getPreferredSpan(int axis) { return 0.0f; }
    void* getImage() { return nullptr; }
    void paint(Graphics* g, Shape* a) {}
    float getAlignment(int axis) { return 0.0f; }
    std::string getImageURL() { return imageURL; }
    void* getAttributes() { return nullptr; }
    void setParent(View* parent) {}
    void setSize(float width, float height) {}

private:
    Element* element;
    std::string altText;
    std::string imageURL;
    bool sync = false;
};

// Test functions (exact names as in Java)
void viewToModel_test_10500(float p0, float p1, Shape* p2, Position::Bias* p3, Element* c0) {
    ImageView instance(c0);
    instance.viewToModel(p0, p1, p2, p3);
}

void getToolTipText_test_10501(float p0, float p1, Shape* p2, Element* c0) {
    ImageView instance(c0);
    instance.getToolTipText(p0, p1, p2);
}

void changedUpdate_test_10502(DocumentEvent* p0, Shape* p1, ViewFactory* p2, Element* c0) {
    ImageView instance(c0);
    instance.changedUpdate(p0, p1, p2);
}

void getAltText_test_10503(Element* c0) {
    ImageView instance(c0);
    instance.getAltText();
}

void getLoadingImageIcon_test_10504(Element* c0) {
    ImageView instance(c0);
    instance.getLoadingImageIcon();
}

void getNoImageIcon_test_10505(Element* c0) {
    ImageView instance(c0);
    instance.getNoImageIcon();
}

void getLoadsSynchronously_test_10506(Element* c0) {
    ImageView instance(c0);
    instance.getLoadsSynchronously();
}

void setLoadsSynchronously_test_10507(bool p0, Element* c0) {
    ImageView instance(c0);
    instance.setLoadsSynchronously(p0);
}

void getPreferredSpan_test_10508(int p0, Element* c0) {
    ImageView instance(c0);
    instance.getPreferredSpan(p0);
}

void getImage_test_10509(Element* c0) {
    ImageView instance(c0);
    instance.getImage();
}

void paint_test_10510(Graphics* p0, Shape* p1, Element* c0) {
    ImageView instance(c0);
    instance.paint(p0, p1);
}

void getAlignment_test_10511(int p0, Element* c0) {
    ImageView instance(c0);
    instance.getAlignment(p0);
}

void getImageURL_test_10512(Element* c0) {
    ImageView instance(c0);
    instance.getImageURL();
}

void getAttributes_test_10513(Element* c0) {
    ImageView instance(c0);
    instance.getAttributes();
}

void setParent_test_10514(View* p0, Element* c0) {
    ImageView instance(c0);
    instance.setParent(p0);
}

void setSize_test_10515(float p0, float p1, Element* c0) {
    ImageView instance(c0);
    instance.setSize(p0, p1);
}
```