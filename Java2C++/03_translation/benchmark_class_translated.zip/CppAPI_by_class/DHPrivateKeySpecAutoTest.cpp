```cpp
#include <string>
#include <iostream>

// Minimal BigInteger class that stores a decimal string (immutable).
class BigInteger {
public:
    // Construct from C-string (e.g., "123")
    BigInteger(const char* value) : value_(value) {}
    
    // Construct from std::string
    BigInteger(const std::string& value) : value_(value) {}
    
    // Copy constructor
    BigInteger(const BigInteger& other) : value_(other.value_) {}
    
    // Assignment operator
    BigInteger& operator=(const BigInteger& other) {
        if (this != &other) {
            value_ = other.value_;
        }
        return *this;
    }
    
    // Access the underlying string representation
    const std::string& toString() const {
        return value_;
    }

private:
    std::string value_;
};

// C++ equivalent of javax.crypto.spec.DHPrivateKeySpec
class DHPrivateKeySpec {
public:
    // Constructor: (BigInteger x, BigInteger p, BigInteger g)
    DHPrivateKeySpec(const BigInteger& x, const BigInteger& p, const BigInteger& g)
        : x_(x), p_(p), g_(g) {}
    
    // Getter methods (return const references for immutability)
    const BigInteger& getP() const { return p_; }
    const BigInteger& getG() const { return g_; }
    const BigInteger& getX() const { return x_; }

private:
    const BigInteger x_;
    const BigInteger p_;
    const BigInteger g_;
};

// Test functions (translated from Java @Test methods)
void getP_test_5241(const BigInteger& c0, const BigInteger& c1, const BigInteger& c2) {
    DHPrivateKeySpec instance(c0, c1, c2);
    instance.getP();
}

void getG_test_5242(const BigInteger& c0, const BigInteger& c1, const BigInteger& c2) {
    DHPrivateKeySpec instance(c0, c1, c2);
    instance.getG();
}

void getX_test_5243(const BigInteger& c0, const BigInteger& c1, const BigInteger& c2) {
    DHPrivateKeySpec instance(c0, c1, c2);
    instance.getX();
}

// Entry point: calls each test with sample BigInteger values
int main() {
    // Example BigIntegers: x = 123, p = 456, g = 789
    BigInteger x("123");
    BigInteger p("456");
    BigInteger g("789");
    
    getP_test_5241(x, p, g);
    getG_test_5242(x, p, g);
    getX_test_5243(x, p, g);
    
    std::cout << "All tests passed (no exceptions thrown)." << std::endl;
    return 0;
}
```