```cpp
#include <string>
#include <stdexcept>

// C++ equivalent of java.io.InvalidClassException
class InvalidClassException : public std::exception {
public:
    explicit InvalidClassException(const std::string& msg) : message(msg) {}

    // Mimics Java's getMessage() returning String (std::string)
    std::string getMessage() const {
        return message;
    }

    // Override standard what() for compatibility with std::exception
    const char* what() const noexcept override {
        return message.c_str();
    }

private:
    std::string message;
};

// Test function corresponding to @Test getMessage_test_1783
void getMessage_test_1783(const std::string& c0) {
    InvalidClassException instance(c0);
    instance.getMessage();
}
```