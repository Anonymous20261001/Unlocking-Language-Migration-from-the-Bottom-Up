```cpp
#include <string>
#include <typeinfo>

// Base class to mimic Java's Object
class Object {
public:
    virtual bool equals(const Object& other) const = 0;
    virtual ~Object() = default;
};

// CopiesSupported class equivalent to javax.print.attribute.standard.CopiesSupported
class CopiesSupported : public Object {
private:
    int value;

public:
    CopiesSupported(int c0) : value(c0) {}

    // Returns a constant representing the category (like CopiesSupported.class)
    std::string getCategory() {
        return "CopiesSupported";
    }

    // Returns the attribute name as defined in Java
    std::string getName() {
        return "copies-supported";
    }

    // Implements equals taking an Object argument, comparing with CopiesSupported instances
    bool equals(const Object& other) const override {
        const CopiesSupported* otherCS = dynamic_cast<const CopiesSupported*>(&other);
        if (otherCS) {
            return value == otherCS->value;
        }
        return false;
    }
};

// Test functions translated from the Java @Test methods
void getCategory_test_6100(int c0) {
    CopiesSupported instance(c0);
    instance.getCategory();
}

void getName_test_6101(int c0) {
    CopiesSupported instance(c0);
    instance.getName();
}

void equals_test_6102(const Object& p0, int c0) {
    CopiesSupported instance(c0);
    instance.equals(p0);
}
```