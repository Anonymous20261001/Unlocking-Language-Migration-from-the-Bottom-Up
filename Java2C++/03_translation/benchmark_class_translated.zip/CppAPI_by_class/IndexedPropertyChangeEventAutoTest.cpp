```cpp
#include <string>
#include <any>

class IndexedPropertyChangeEvent {
public:
    IndexedPropertyChangeEvent(const std::any& source, const std::string& propertyName,
                               const std::any& oldValue, const std::any& newValue, int index)
        : source_(source), propertyName_(propertyName),
          oldValue_(oldValue), newValue_(newValue), index_(index) {}

    int getIndex() const {
        return index_;
    }

private:
    std::any source_;
    std::string propertyName_;
    std::any oldValue_;
    std::any newValue_;
    int index_;
};

void getIndex_test_1552(std::any c0, std::string c1, std::any c2, std::any c3, int c4) {
    IndexedPropertyChangeEvent instance(c0, c1, c2, c3, c4);
    instance.getIndex();
}
```