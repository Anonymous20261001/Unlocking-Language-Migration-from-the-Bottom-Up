```cpp
#include <cstdint>
#include <vector>
#include <cstddef>

// Minimal ByteBuffer emulating Java's java.nio.ByteBuffer for the purpose of CRC32C update
class ByteBuffer {
public:
    ByteBuffer(const std::vector<uint8_t>& data) : data_(data), pos_(0), lim_(data.size()) {}

    size_t remaining() const {
        return lim_ - pos_;
    }

    uint8_t get() {
        return data_[pos_++];
    }

private:
    std::vector<uint8_t> data_;
    size_t pos_;
    size_t lim_;
};

// CRC32C implementation (polynomial 0x82F63B78, reflected)
class CRC32C {
public:
    CRC32C() : crc_(0) {
        if (!tableComputed_) {
            computeTable();
            tableComputed_ = true;
        }
    }

    void reset() {
        crc_ = 0;
    }

    // Update with a sub-array of bytes
    void update(const std::vector<uint8_t>& b, int off, int len) {
        uint32_t c = crc_;
        for (int i = 0; i < len; ++i) {
            uint8_t byte = b[off + i];
            c = table_[(c ^ byte) & 0xFF] ^ (c >> 8);
        }
        crc_ = c;
    }

    // Update with a single byte (only low 8 bits are used)
    void update(int b) {
        uint8_t byte = static_cast<uint8_t>(b & 0xFF);
        crc_ = table_[(crc_ ^ byte) & 0xFF] ^ (crc_ >> 8);
    }

    // Update with the remaining bytes of a ByteBuffer
    void update(const ByteBuffer& buf) {
        uint32_t c = crc_;
        while (buf.remaining() > 0) {
            uint8_t byte = buf.get();
            c = table_[(c ^ byte) & 0xFF] ^ (c >> 8);
        }
        crc_ = c;
    }

    // Return the CRC value (as a 32-bit unsigned integer, comparable to Java's long)
    uint32_t getValue() const {
        return crc_;
    }

private:
    static uint32_t table_[256];
    static bool tableComputed_;
    uint32_t crc_;

    static void computeTable() {
        for (int n = 0; n < 256; ++n) {
            uint32_t c = static_cast<uint32_t>(n);
            for (int k = 0; k < 8; ++k) {
                if (c & 1)
                    c = 0x82F63B78 ^ (c >> 1);
                else
                    c = c >> 1;
            }
            table_[n] = c;
        }
    }
};

// Static member definitions
uint32_t CRC32C::table_[256] = {0};
bool CRC32C::tableComputed_ = false;

// ---------------------- Test functions (one per Java @Test) ----------------------

void reset_test_5129() {
    CRC32C instance;
    instance.reset();
}

void update_test_5130(const std::vector<uint8_t>& p0, int p1, int p2) {
    CRC32C instance;
    instance.update(p0, p1, p2);
}

void update_test_5131(int p0) {
    CRC32C instance;
    instance.update(p0);
}

void update_test_5132(const ByteBuffer& p0) {
    CRC32C instance;
    instance.update(p0);
}

void getValue_test_5133() {
    CRC32C instance;
    instance.getValue();
}
```