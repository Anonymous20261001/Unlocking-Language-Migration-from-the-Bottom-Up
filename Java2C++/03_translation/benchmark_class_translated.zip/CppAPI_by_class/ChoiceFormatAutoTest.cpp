```cpp
#include <string>
#include <vector>
#include <cstdint>
#include <memory>
#include <iostream>

// ---------- Minimal Java-like standard library classes ----------

class Object {
public:
    virtual ~Object() = default;
    virtual Object* clone() const { return new Object(*this); }
};

class Number : public Object {
public:
    double value;
    Number(double v = 0.0) : value(v) {}
    double doubleValue() const { return value; }
};

class Format : public Object {
public:
    virtual ~Format() = default;
};

class StringBuffer {
public:
    std::string data;

    StringBuffer& append(const std::string& s) {
        data += s;
        return *this;
    }
    StringBuffer& append(char c) {
        data += c;
        return *this;
    }
    StringBuffer& append(int i) {
        data += std::to_string(i);
        return *this;
    }
    StringBuffer& append(long long i) {
        data += std::to_string(i);
        return *this;
    }
    StringBuffer& append(double d) {
        data += std::to_string(d);
        return *this;
    }
    std::string toString() const { return data; }
};

class FieldPosition {
public:
    int field;
    int beginIndex;
    int endIndex;

    FieldPosition(int f = 0) : field(f), beginIndex(0), endIndex(0) {}
    int getField() const { return field; }
    void setBeginIndex(int bi) { beginIndex = bi; }
    void setEndIndex(int ei) { endIndex = ei; }
    int getBeginIndex() const { return beginIndex; }
    int getEndIndex() const { return endIndex; }
};

class ParsePosition {
public:
    int index;
    int errorIndex;

    ParsePosition(int i = 0) : index(i), errorIndex(-1) {}
    int getIndex() const { return index; }
    void setIndex(int i) { index = i; }
    int getErrorIndex() const { return errorIndex; }
    void setErrorIndex(int ei) { errorIndex = ei; }
};

// ---------- ChoiceFormat implementation (stub) ----------

class ChoiceFormat : public Object {
private:
    std::string pattern_;
    std::vector<double> limits_;
    std::vector<std::string> formats_;
    bool strict_ = false;

public:
    explicit ChoiceFormat(const std::string& pattern)
        : pattern_(pattern) {}

    // Copy constructor (needed for clone)
    ChoiceFormat(const ChoiceFormat& other)
        : Object(other),
          pattern_(other.pattern_),
          limits_(other.limits_),
          formats_(other.formats_),
          strict_(other.strict_) {}

    // Static methods
    static double previousDouble(double d) { return d - 1.0; }
    static double nextDouble(double d, bool positive) { return positive ? d + 1.0 : d - 1.0; }
    static double nextDouble(double d) { return d + 1.0; }

    // Instance methods
    void setChoices(const std::vector<double>& limits, const std::vector<std::string>& formats) {
        limits_ = limits;
        formats_ = formats;
    }

    const std::vector<double>& getLimits() const { return limits_; }

    bool equals(const Object& /*obj*/) const override { return false; }

    std::string toString() const override { return pattern_; }

    int hashCode() const { return 0; }

    Object* clone() const override { return new ChoiceFormat(*this); }

    StringBuffer& format(long long number, StringBuffer& toAppendTo, FieldPosition& /*pos*/) {
        toAppendTo.append("formatted:");
        toAppendTo.append(number);
        return toAppendTo;
    }

    StringBuffer& format(double number, StringBuffer& toAppendTo, FieldPosition& /*pos*/) {
        toAppendTo.append("formatted:");
        toAppendTo.append(number);
        return toAppendTo;
    }

    Number* parse(const std::string& /*text*/, ParsePosition& pos) {
        pos.setIndex(0);
        return new Number(0.0);
    }

    bool isStrict() const { return strict_; }

    void applyPattern(const std::string& pat) { pattern_ = pat; }

    std::string toPattern() const { return pattern_; }

    void setStrict(bool s) { strict_ = s; }

    std::vector<Format*> getFormats() const {
        std::vector<Format*> result;
        for (size_t i = 0; i < formats_.size(); ++i) {
            result.push_back(nullptr); // stub: no real Format objects
        }
        return result;
    }
};

// ---------- Translated test functions ----------

void previousDouble_test_3017(double p0, const std::string& c0) {
    ChoiceFormat instance(c0);
    ChoiceFormat::previousDouble(p0);
}

void setChoices_test_3018(const std::vector<double>& p0, const std::vector<std::string>& p1, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.setChoices(p0, p1);
}

void getLimits_test_3019(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.getLimits();
}

void equals_test_3020(const Object& p0, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.equals(p0);
}

void toString_test_3021(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.toString();
}

void hashCode_test_3022(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.hashCode();
}

void clone_test_3023(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.clone(); // result ignored (memory leak, but acceptable for stub)
}

void format_test_3024(long long p0, StringBuffer& p1, FieldPosition& p2, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.format(p0, p1, p2);
}

void format_test_3025(double p0, StringBuffer& p1, FieldPosition& p2, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.format(p0, p1, p2);
}

void parse_test_3026(const std::string& p0, ParsePosition& p1, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.parse(p0, p1); // result ignored
}

void nextDouble_test_3027(double p0, bool p1, const std::string& c0) {
    ChoiceFormat instance(c0);
    ChoiceFormat::nextDouble(p0, p1);
}

void nextDouble_test_3028(double p0, const std::string& c0) {
    ChoiceFormat instance(c0);
    ChoiceFormat::nextDouble(p0);
}

void isStrict_test_3029(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.isStrict();
}

void applyPattern_test_3030(const std::string& p0, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.applyPattern(p0);
}

void toPattern_test_3031(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.toPattern();
}

void setStrict_test_3032(bool p0, const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.setStrict(p0);
}

void getFormats_test_3033(const std::string& c0) {
    ChoiceFormat instance(c0);
    instance.getFormats();
}
```