```cpp
#include <iostream>
#include <string>
#include <vector>

// Forward declarations
class JFormattedTextField;

// -----------------------------------------------------------------------
// JFormattedTextField::AbstractFormatter (nested class)
// -----------------------------------------------------------------------
class JFormattedTextField {
public:
    class AbstractFormatter {
    public:
        virtual ~AbstractFormatter() = default;
    };

    // Minimal implementation – the tests do not use any of its members.
    std::string text;
};

// -----------------------------------------------------------------------
// DefaultFormatterFactory – mirrors the Java class
// -----------------------------------------------------------------------
class DefaultFormatterFactory {
private:
    JFormattedTextField::AbstractFormatter* defaultFormatter_;
    JFormattedTextField::AbstractFormatter* displayFormatter_;
    JFormattedTextField::AbstractFormatter* editFormatter_;
    JFormattedTextField::AbstractFormatter* nullFormatter_;

public:
    DefaultFormatterFactory()
        : defaultFormatter_(nullptr)
        , displayFormatter_(nullptr)
        , editFormatter_(nullptr)
        , nullFormatter_(nullptr)
    {}

    // Getters
    JFormattedTextField::AbstractFormatter* getDefaultFormatter() const {
        return defaultFormatter_;
    }

    JFormattedTextField::AbstractFormatter* getDisplayFormatter() const {
        return displayFormatter_;
    }

    JFormattedTextField::AbstractFormatter* getEditFormatter() const {
        return editFormatter_;
    }

    JFormattedTextField::AbstractFormatter* getNullFormatter() const {
        return nullFormatter_;
    }

    // Setters
    void setDefaultFormatter(JFormattedTextField::AbstractFormatter* fmt) {
        defaultFormatter_ = fmt;
    }

    void setDisplayFormatter(JFormattedTextField::AbstractFormatter* fmt) {
        displayFormatter_ = fmt;
    }

    void setEditFormatter(JFormattedTextField::AbstractFormatter* fmt) {
        editFormatter_ = fmt;
    }

    void setNullFormatter(JFormattedTextField::AbstractFormatter* fmt) {
        nullFormatter_ = fmt;
    }

    // getFormatter – simplified version; in Java it considers the state of
    // the JFormattedTextField (e.g., focus). Here we only return the
    // first non-null formatter: display > edit > default > null.
    JFormattedTextField::AbstractFormatter* getFormatter(
        const JFormattedTextField* tf) const {
        // The real Java algorithm is more complex, but tests do not check
        // the return value, so a stub is sufficient.
        if (displayFormatter_ != nullptr)
            return displayFormatter_;
        if (editFormatter_ != nullptr)
            return editFormatter_;
        if (defaultFormatter_ != nullptr)
            return defaultFormatter_;
        return nullFormatter_;
    }
};

// -----------------------------------------------------------------------
// Test functions – one per @Test method
// -----------------------------------------------------------------------
void getNullFormatter_test_10208() {
    DefaultFormatterFactory instance;
    instance.getNullFormatter();
}

void getEditFormatter_test_10209() {
    DefaultFormatterFactory instance;
    instance.getEditFormatter();
}

void getDisplayFormatter_test_10210() {
    DefaultFormatterFactory instance;
    instance.getDisplayFormatter();
}

void getDefaultFormatter_test_10211() {
    DefaultFormatterFactory instance;
    instance.getDefaultFormatter();
}

void setDefaultFormatter_test_10212() {
    JFormattedTextField::AbstractFormatter p0;
    DefaultFormatterFactory instance;
    instance.setDefaultFormatter(&p0);
}

void setDisplayFormatter_test_10213() {
    JFormattedTextField::AbstractFormatter p0;
    DefaultFormatterFactory instance;
    instance.setDisplayFormatter(&p0);
}

void setEditFormatter_test_10214() {
    JFormattedTextField::AbstractFormatter p0;
    DefaultFormatterFactory instance;
    instance.setEditFormatter(&p0);
}

void setNullFormatter_test_10215() {
    JFormattedTextField::AbstractFormatter p0;
    DefaultFormatterFactory instance;
    instance.setNullFormatter(&p0);
}

void getFormatter_test_10216() {
    JFormattedTextField p0;
    DefaultFormatterFactory instance;
    instance.getFormatter(&p0);
}

// -----------------------------------------------------------------------
// Optional: main to execute all tests (not required but convenient)
// -----------------------------------------------------------------------
int main() {
    getNullFormatter_test_10208();
    getEditFormatter_test_10209();
    getDisplayFormatter_test_10210();
    getDefaultFormatter_test_10211();
    setDefaultFormatter_test_10212();
    setDisplayFormatter_test_10213();
    setEditFormatter_test_10214();
    setNullFormatter_test_10215();
    getFormatter_test_10216();

    std::cout << "All tests completed (no assertions)." << std::endl;
    return 0;
}
```