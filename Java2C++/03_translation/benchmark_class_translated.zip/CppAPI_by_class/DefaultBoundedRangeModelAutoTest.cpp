```cpp
#include <vector>
#include <string>
#include <typeinfo>
#include <algorithm>

// ---------------------------------------------------------------------------
// Minimal representation of a Java Class object (for getListeners)
// ---------------------------------------------------------------------------
struct Class {
    const std::type_info* info;

    template<typename T>
    static Class of() {
        return { &typeid(T) };
    }

    bool operator==(const Class& other) const {
        return *info == *other.info;
    }
    bool operator!=(const Class& other) const {
        return !(*this == other);
    }
};

// ---------------------------------------------------------------------------
// ChangeEvent (simplified)
// ---------------------------------------------------------------------------
class ChangeEvent {
public:
    virtual ~ChangeEvent() = default;
};

// ---------------------------------------------------------------------------
// ChangeListener (abstract base)
// ---------------------------------------------------------------------------
class ChangeListener {
public:
    virtual ~ChangeListener() = default;
    virtual void stateChanged(ChangeEvent* e) = 0;
};

// ---------------------------------------------------------------------------
// DefaultBoundedRangeModel
// ---------------------------------------------------------------------------
class DefaultBoundedRangeModel {
private:
    int value_;
    int extent_;
    int minimum_;
    int maximum_;
    bool isAdjusting_;
    std::vector<ChangeListener*> listeners_;   // non-owning pointers

public:
    DefaultBoundedRangeModel()
        : value_(0), extent_(0), minimum_(0), maximum_(100), isAdjusting_(false)
    {}

    // ----- Getters / Setters -----
    int getValue() const { return value_; }

    void setValue(int v) {
        if (v < minimum_) v = minimum_;
        if (v > maximum_ - extent_) v = maximum_ - extent_;
        value_ = v;
        fireStateChanged();
    }

    int getExtent() const { return extent_; }

    void setExtent(int e) {
        if (e < 0) e = 0;
        if (value_ + e > maximum_) e = maximum_ - value_;
        extent_ = e;
        fireStateChanged();
    }

    int getMinimum() const { return minimum_; }

    void setMinimum(int m) {
        if (m > maximum_) m = maximum_;
        minimum_ = m;
        if (value_ < minimum_) setValue(minimum_);
        fireStateChanged();
    }

    int getMaximum() const { return maximum_; }

    void setMaximum(int m) {
        if (m < minimum_) m = minimum_;
        maximum_ = m;
        if (value_ > maximum_ - extent_) setValue(maximum_ - extent_);
        fireStateChanged();
    }

    bool getValueIsAdjusting() const { return isAdjusting_; }

    void setValueIsAdjusting(bool b) {
        isAdjusting_ = b;
        fireStateChanged();
    }

    // ----- setRangeProperties -----
    void setRangeProperties(int value, int extent, int min, int max, bool adjusting) {
        // clamp values as in the Java implementation (simplified)
        if (min > max) min = max;
        if (max < min) max = min;
        if (extent < 0) extent = 0;
        if (value < min) value = min;
        if (value + extent > max) {
            extent = max - value;
            if (extent < 0) extent = 0;
        }
        value_ = value;
        extent_ = extent;
        minimum_ = min;
        maximum_ = max;
        isAdjusting_ = adjusting;
        fireStateChanged();
    }

    // ----- Listener management -----
    void addChangeListener(ChangeListener* l) {
        if (l && std::find(listeners_.begin(), listeners_.end(), l) == listeners_.end()) {
            listeners_.push_back(l);
        }
    }

    void removeChangeListener(ChangeListener* l) {
        listeners_.erase(std::remove(listeners_.begin(), listeners_.end(), l), listeners_.end());
    }

    std::vector<ChangeListener*> getChangeListeners() const {
        return listeners_;
    }

    // Simplified getListeners – returns only listeners of the given class type.
    // Since we only have ChangeListener, we check if the requested class matches.
    std::vector<ChangeListener*> getListeners(Class cls) const {
        if (cls == Class::of<ChangeListener>()) {
            return listeners_;
        }
        return {};
    }

    // ----- toString -----
    std::string toString() const {
        return "DefaultBoundedRangeModel[value=" + std::to_string(value_) +
               ", extent=" + std::to_string(extent_) +
               ", min=" + std::to_string(minimum_) +
               ", max=" + std::to_string(maximum_) +
               ", adj=" + (isAdjusting_ ? "true" : "false") + "]";
    }

private:
    void fireStateChanged() {
        ChangeEvent evt;
        for (auto* l : listeners_) {
            l->stateChanged(&evt);
        }
    }
};

// ===========================================================================
// Test functions (exact translations from the Java @Test methods)
// ===========================================================================

void setRangeProperties_test_6635(int p0, int p1, int p2, int p3, bool p4) {
    DefaultBoundedRangeModel instance;
    instance.setRangeProperties(p0, p1, p2, p3, p4);
}

void getExtent_test_6636() {
    DefaultBoundedRangeModel instance;
    instance.getExtent();
}

void setExtent_test_6637(int p0) {
    DefaultBoundedRangeModel instance;
    instance.setExtent(p0);
}

void addChangeListener_test_6638(ChangeListener* p0) {
    DefaultBoundedRangeModel instance;
    instance.addChangeListener(p0);
}

void removeChangeListener_test_6639(ChangeListener* p0) {
    DefaultBoundedRangeModel instance;
    instance.removeChangeListener(p0);
}

void getChangeListeners_test_6640() {
    DefaultBoundedRangeModel instance;
    instance.getChangeListeners();
}

void getListeners_test_6641(Class p0) {
    DefaultBoundedRangeModel instance;
    instance.getListeners(p0);
}

void setMinimum_test_6642(int p0) {
    DefaultBoundedRangeModel instance;
    instance.setMinimum(p0);
}

void setMaximum_test_6643(int p0) {
    DefaultBoundedRangeModel instance;
    instance.setMaximum(p0);
}

void setValueIsAdjusting_test_6644(bool p0) {
    DefaultBoundedRangeModel instance;
    instance.setValueIsAdjusting(p0);
}

void getValueIsAdjusting_test_6645() {
    DefaultBoundedRangeModel instance;
    instance.getValueIsAdjusting();
}

void toString_test_6646() {
    DefaultBoundedRangeModel instance;
    instance.toString();
}

void getValue_test_6647() {
    DefaultBoundedRangeModel instance;
    instance.getValue();
}

void setValue_test_6648(int p0) {
    DefaultBoundedRangeModel instance;
    instance.setValue(p0);
}

void getMaximum_test_6649() {
    DefaultBoundedRangeModel instance;
    instance.getMaximum();
}

void getMinimum_test_6650() {
    DefaultBoundedRangeModel instance;
    instance.getMinimum();
}
```