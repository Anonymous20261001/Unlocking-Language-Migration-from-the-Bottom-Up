```cpp
#include <cstddef>

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    void installUI(JComponent* /*c*/) {
        // No-op in this stub
    }

    void uninstallUI(JComponent* /*c*/) {
        // No-op
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        // In real Swing, createUI returns a new instance of the UI delegate.
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // No-op
    }

    bool isPopupTrigger(MouseEvent* /*e*/) {
        return false;
    }
};

// Test functions – each corresponds exactly to one Java @Test method

void installUI_test_8858(JComponent* p0) {
    BasicPopupMenuUI instance;
    instance.installUI(p0);
}

void uninstallUI_test_8859(JComponent* p0) {
    BasicPopupMenuUI instance;
    instance.uninstallUI(p0);
}

void createUI_test_8860(JComponent* p0) {
    BasicPopupMenuUI instance;
    BasicPopupMenuUI::createUI(p0);   // static call, return value ignored
}

void installDefaults_test_8861() {
    BasicPopupMenuUI instance;
    instance.installDefaults();
}

void isPopupTrigger_test_8862(MouseEvent* p0) {
    BasicPopupMenuUI instance;
    instance.isPopupTrigger(p0);
}
```