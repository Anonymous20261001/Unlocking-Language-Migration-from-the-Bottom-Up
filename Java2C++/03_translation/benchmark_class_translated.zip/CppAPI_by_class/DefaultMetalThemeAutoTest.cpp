```cpp
#include <string>

// Simple Font class mimicking java.awt.Font
class Font {
private:
    std::string family;
public:
    Font() : family("") {}
    Font(const std::string& f) : family(f) {}
    std::string getFamily() const { return family; }
};

// C++ equivalent of javax.swing.plaf.metal.DefaultMetalTheme
class DefaultMetalTheme {
public:
    Font getControlTextFont() {
        return Font("Dialog");
    }

    Font getSystemTextFont() {
        return Font("Dialog");
    }

    Font getUserTextFont() {
        return Font("Dialog");
    }

    Font getMenuTextFont() {
        return Font("Dialog");
    }

    Font getWindowTitleFont() {
        return Font("Dialog");
    }

    Font getSubTextFont() {
        return Font("Dialog");
    }

    std::string getName() {
        return "Default Theme";
    }
};

// Test functions (translated from @Test methods)
void getControlTextFont_test_9074() {
    DefaultMetalTheme instance;
    instance.getControlTextFont();
}

void getSystemTextFont_test_9075() {
    DefaultMetalTheme instance;
    instance.getSystemTextFont();
}

void getUserTextFont_test_9076() {
    DefaultMetalTheme instance;
    instance.getUserTextFont();
}

void getMenuTextFont_test_9077() {
    DefaultMetalTheme instance;
    instance.getMenuTextFont();
}

void getWindowTitleFont_test_9078() {
    DefaultMetalTheme instance;
    instance.getWindowTitleFont();
}

void getSubTextFont_test_9079() {
    DefaultMetalTheme instance;
    instance.getSubTextFont();
}

void getName_test_9080() {
    DefaultMetalTheme instance;
    instance.getName();
}

// Main function to run all tests (optional, for completeness)
int main() {
    getControlTextFont_test_9074();
    getSystemTextFont_test_9075();
    getUserTextFont_test_9076();
    getMenuTextFont_test_9077();
    getWindowTitleFont_test_9078();
    getSubTextFont_test_9079();
    getName_test_9080();
    return 0;
}
```