```cpp
#include <string>
#include <sstream>

// Minimal Component class (analogous to java.awt.Component)
class Component {
public:
    virtual ~Component() = default;
    // Add any other members as needed; for this test, no specific behavior required
};

// Minimal ComponentEvent class (analogous to java.awt.event.ComponentEvent)
class ComponentEvent {
private:
    Component* source;
    int id;

public:
    ComponentEvent(Component* source, int id) : source(source), id(id) {}

    // Returns a string representation of the event (similar to Java's paramString)
    std::string paramString() const {
        std::ostringstream oss;
        oss << "COMPONENT_EVENT,id=" << id << ",source=" << source;
        return oss.str();
    }

    // Returns the source component
    Component* getComponent() const {
        return source;
    }
};

// Test function for paramString_test_750
void paramString_test_750(Component* c0, int c1) {
    ComponentEvent instance(c0, c1);
    instance.paramString();  // Returns a string, but we ignore it as in Java (method called for its effect)
}

// Test function for getComponent_test_751
void getComponent_test_751(Component* c0, int c1) {
    ComponentEvent instance(c0, c1);
    instance.getComponent();  // Returns a pointer, ignored
}
```