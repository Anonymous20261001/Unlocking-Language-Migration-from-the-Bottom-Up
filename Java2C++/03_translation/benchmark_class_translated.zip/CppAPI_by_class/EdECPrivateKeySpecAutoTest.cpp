```cpp
#include <vector>
#include <cstdint>
#include <string>

// Mimics java.security.spec.NamedParameterSpec (minimal)
class NamedParameterSpec {
public:
    NamedParameterSpec() = default;
    // The class could hold a parameter name, but it's not needed for the tests.
};

// Mimics java.security.spec.EdECPrivateKeySpec
class EdECPrivateKeySpec {
public:
    EdECPrivateKeySpec(const NamedParameterSpec& params, const std::vector<uint8_t>& bytes)
        : params_(params), bytes_(bytes) {}

    const NamedParameterSpec& getParams() const {
        return params_;
    }

    const std::vector<uint8_t>& getBytes() const {
        return bytes_;
    }

private:
    NamedParameterSpec params_;
    std::vector<uint8_t> bytes_;
};

// C++ equivalent of @Test methods
void getParams_test_2885(NamedParameterSpec c0, std::vector<uint8_t> c1) {
    EdECPrivateKeySpec instance(c0, c1);
    instance.getParams();
}

void getBytes_test_2886(NamedParameterSpec c0, std::vector<uint8_t> c1) {
    EdECPrivateKeySpec instance(c0, c1);
    instance.getBytes();
}
```