```cpp
#include <string>
#include <vector>

// Forward declarations
class Component;
class ComponentOrientation;
class SplitPaneUI;
class AccessibleContext;

// ===================== Component =====================
class Component {
public:
    Component() = default;
    virtual ~Component() = default;
};

// ===================== ComponentOrientation =====================
class ComponentOrientation {
private:
    int id;
    ComponentOrientation(int id) : id(id) {}
public:
    static const ComponentOrientation LEFT_TO_RIGHT;
    static const ComponentOrientation RIGHT_TO_LEFT;
    static const ComponentOrientation UNKNOWN;
    bool operator==(const ComponentOrientation& other) const { return id == other.id; }
};

const ComponentOrientation ComponentOrientation::LEFT_TO_RIGHT(0);
const ComponentOrientation ComponentOrientation::RIGHT_TO_LEFT(1);
const ComponentOrientation ComponentOrientation::UNKNOWN(2);

// ===================== SplitPaneUI =====================
class SplitPaneUI {
public:
    SplitPaneUI() = default;
    virtual ~SplitPaneUI() = default;
};

// ===================== AccessibleContext =====================
class AccessibleContext {
public:
    AccessibleContext() = default;
};

// ===================== JSplitPane =====================
class JSplitPane {
public:
    static const int HORIZONTAL_SPLIT = 1;
    static const int VERTICAL_SPLIT   = 0;

    // Constructors
    JSplitPane() 
        : continuousLayout(false), resizeWeight(0.5), dividerLocation(0), lastDividerLocation(0),
          dividerSize(10), oneTouchExpandable(false), orientation(HORIZONTAL_SPLIT), enabled(true),
          ui(nullptr), leftComponent(nullptr), rightComponent(nullptr), topComponent(nullptr),
          bottomComponent(nullptr), accessibleContext(nullptr) {}

    // Getters and setters
    int getLastDividerLocation() const { return lastDividerLocation; }
    void setLastDividerLocation(int loc) { lastDividerLocation = loc; }

    bool isContinuousLayout() const { return continuousLayout; }
    void setContinuousLayout(bool b) { continuousLayout = b; }

    double getResizeWeight() const { return resizeWeight; }
    void setResizeWeight(double w) { resizeWeight = w; }

    int getDividerLocation() const { return dividerLocation; }
    void setDividerLocation(int loc) { dividerLocation = loc; }
    void setDividerLocation(double proportional) { 
        // simplified: just store as int
        dividerLocation = static_cast<int>(proportional); 
    }

    int getDividerSize() const { return dividerSize; }
    void setDividerSize(int s) { dividerSize = s; }

    int getMinimumDividerLocation() const { return 0; }   // dummy
    int getMaximumDividerLocation() const { return 100; } // dummy

    bool isOneTouchExpandable() const { return oneTouchExpandable; }
    void setOneTouchExpandable(bool b) { oneTouchExpandable = b; }

    bool isValidateRoot() const { return true; } // simplified

    void setEnabled(bool e) { enabled = e; }

    int getOrientation() const { return orientation; }
    void setOrientation(int o) { orientation = o; }

    void setComponentOrientation(const ComponentOrientation& /*o*/) { /* ignore */ }

    std::string getUIClassID() const { return "SplitPaneUI"; }

    SplitPaneUI* getUI() const { return ui; }
    void setUI(SplitPaneUI* u) { ui = u; }

    Component* getLeftComponent() const { return leftComponent; }
    void setLeftComponent(Component* c) { leftComponent = c; }

    Component* getRightComponent() const { return rightComponent; }
    void setRightComponent(Component* c) { rightComponent = c; }

    Component* getTopComponent() const { return topComponent; }
    void setTopComponent(Component* c) { topComponent = c; }

    Component* getBottomComponent() const { return bottomComponent; }
    void setBottomComponent(Component* c) { bottomComponent = c; }

    AccessibleContext* getAccessibleContext() const { return accessibleContext; }

    void updateUI() { /* dummy */ }

    void resetToPreferredSizes() { /* dummy */ }

    void remove(Component* /*c*/) { /* dummy */ }
    void remove(int /*index*/) { /* dummy */ }
    void removeAll() { /* dummy */ }

private:
    bool continuousLayout;
    double resizeWeight;
    int dividerLocation;
    int lastDividerLocation;
    int dividerSize;
    bool oneTouchExpandable;
    int orientation;
    bool enabled;
    SplitPaneUI* ui;
    Component* leftComponent;
    Component* rightComponent;
    Component* topComponent;
    Component* bottomComponent;
    AccessibleContext* accessibleContext;
};

// ===================== Test functions =====================

void getLastDividerLocation_test_7695() {
    JSplitPane instance;
    instance.getLastDividerLocation();
}

void setContinuousLayout_test_7696(bool p0) {
    JSplitPane instance;
    instance.setContinuousLayout(p0);
}

void isContinuousLayout_test_7697() {
    JSplitPane instance;
    instance.isContinuousLayout();
}

void setResizeWeight_test_7698(double p0) {
    JSplitPane instance;
    instance.setResizeWeight(p0);
}

void getResizeWeight_test_7699() {
    JSplitPane instance;
    instance.getResizeWeight();
}

void getDividerLocation_test_7700() {
    JSplitPane instance;
    instance.getDividerLocation();
}

void getUIClassID_test_7701() {
    JSplitPane instance;
    instance.getUIClassID();
}

void getUI_test_7702() {
    JSplitPane instance;
    instance.getUI();
}

void setUI_test_7703(SplitPaneUI* p0) {
    JSplitPane instance;
    instance.setUI(p0);
}

void setLeftComponent_test_7704(Component* p0) {
    JSplitPane instance;
    instance.setLeftComponent(p0);
}

void setRightComponent_test_7705(Component* p0) {
    JSplitPane instance;
    instance.setRightComponent(p0);
}

void getLeftComponent_test_7706() {
    JSplitPane instance;
    instance.getLeftComponent();
}

void getRightComponent_test_7707() {
    JSplitPane instance;
    instance.getRightComponent();
}

void resetToPreferredSizes_test_7708() {
    JSplitPane instance;
    instance.resetToPreferredSizes();
}

void getDividerSize_test_7709() {
    JSplitPane instance;
    instance.getDividerSize();
}

void setDividerLocation_test_7710(int p0) {
    JSplitPane instance;
    instance.setDividerLocation(p0);
}

void setDividerLocation_test_7711(double p0) {
    JSplitPane instance;
    instance.setDividerLocation(p0);
}

void setLastDividerLocation_test_7712(int p0) {
    JSplitPane instance;
    instance.setLastDividerLocation(p0);
}

void getMinimumDividerLocation_test_7713() {
    JSplitPane instance;
    instance.getMinimumDividerLocation();
}

void getMaximumDividerLocation_test_7714() {
    JSplitPane instance;
    instance.getMaximumDividerLocation();
}

void setDividerSize_test_7715(int p0) {
    JSplitPane instance;
    instance.setDividerSize(p0);
}

void setOneTouchExpandable_test_7716(bool p0) {
    JSplitPane instance;
    instance.setOneTouchExpandable(p0);
}

void setTopComponent_test_7717(Component* p0) {
    JSplitPane instance;
    instance.setTopComponent(p0);
}

void getTopComponent_test_7718() {
    JSplitPane instance;
    instance.getTopComponent();
}

void setBottomComponent_test_7719(Component* p0) {
    JSplitPane instance;
    instance.setBottomComponent(p0);
}

void getBottomComponent_test_7720() {
    JSplitPane instance;
    instance.getBottomComponent();
}

void isOneTouchExpandable_test_7721() {
    JSplitPane instance;
    instance.isOneTouchExpandable();
}

void isValidateRoot_test_7722() {
    JSplitPane instance;
    instance.isValidateRoot();
}

void getAccessibleContext_test_7723() {
    JSplitPane instance;
    instance.getAccessibleContext();
}

void setEnabled_test_7724(bool p0) {
    JSplitPane instance;
    instance.setEnabled(p0);
}

void setComponentOrientation_test_7725(ComponentOrientation p0) {
    JSplitPane instance;
    instance.setComponentOrientation(p0);
}

void getOrientation_test_7726() {
    JSplitPane instance;
    instance.getOrientation();
}

void updateUI_test_7727() {
    JSplitPane instance;
    instance.updateUI();
}

void setOrientation_test_7728(int p0) {
    JSplitPane instance;
    instance.setOrientation(p0);
}

void remove_test_7729(Component* p0) {
    JSplitPane instance;
    instance.remove(p0);
}

void remove_test_7730(int p0) {
    JSplitPane instance;
    instance.remove(p0);
}

void removeAll_test_7731() {
    JSplitPane instance;
    instance.removeAll();
}
```