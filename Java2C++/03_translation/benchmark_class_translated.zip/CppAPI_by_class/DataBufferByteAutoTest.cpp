```cpp
#include <cstdint>
#include <vector>
#include <cstddef>

// C++ equivalent of java.awt.image.DataBufferByte
class DataBufferByte {
public:
    // Constructor: single bank of 'size' bytes
    explicit DataBufferByte(int size)
        : data(1, std::vector<uint8_t>(size)) {}

    // Return reference to the internal bank array (mutable, like Java's byte[][])
    std::vector<std::vector<uint8_t>>& getBankData() {
        return data;
    }

    // Return const reference to avoid accidental modification (optional)
    const std::vector<std::vector<uint8_t>>& getBankData() const {
        return data;
    }

    // Get element from a specific bank
    int getElem(int bank, int i) const {
        return static_cast<int>(data[bank][i]);
    }

    // Get element from bank 0
    int getElem(int i) const {
        return getElem(0, i);
    }

    // Set element in a specific bank
    void setElem(int bank, int i, int val) {
        data[bank][i] = static_cast<uint8_t>(val & 0xFF);
    }

    // Set element in bank 0
    void setElem(int i, int val) {
        setElem(0, i, val);
    }

    // Get reference to the byte array of a specific bank (mutable, like Java's byte[])
    std::vector<uint8_t>& getData(int bank) {
        return data[bank];
    }

    // Get reference to the byte array of bank 0
    std::vector<uint8_t>& getData() {
        return getData(0);
    }

    // Const versions for safe access
    const std::vector<uint8_t>& getData(int bank) const {
        return data[bank];
    }

    const std::vector<uint8_t>& getData() const {
        return getData(0);
    }

private:
    std::vector<std::vector<uint8_t>> data;
};

// Test functions (translated from Java @Test methods)

void getBankData_test_1183(int c0) {
    DataBufferByte instance(c0);
    instance.getBankData();
}

void getElem_test_1184(int p0, int p1, int c0) {
    DataBufferByte instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1185(int p0, int c0) {
    DataBufferByte instance(c0);
    instance.getElem(p0);
}

void setElem_test_1186(int p0, int p1, int p2, int c0) {
    DataBufferByte instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1187(int p0, int p1, int c0) {
    DataBufferByte instance(c0);
    instance.setElem(p0, p1);
}

void getData_test_1188(int p0, int c0) {
    DataBufferByte instance(c0);
    instance.getData(p0);
}

void getData_test_1189(int c0) {
    DataBufferByte instance(c0);
    instance.getData();
}
```