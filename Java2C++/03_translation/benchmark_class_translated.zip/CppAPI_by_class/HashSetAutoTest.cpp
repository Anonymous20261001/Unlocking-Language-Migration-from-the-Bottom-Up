```cpp
#include <unordered_set>
#include <vector>
#include <cstddef>
#include <iterator>
#include <iostream>

// Minimal HashSet wrapper mimicking Java's HashSet<Object> (raw type)
class HashSet {
public:
    // ---------- nested Iterator class ----------
    class Iterator {
        std::unordered_set<void*>::const_iterator it;
        std::unordered_set<void*>::const_iterator end;
    public:
        Iterator(const std::unordered_set<void*>& s)
            : it(s.begin()), end(s.end()) {}
        bool hasNext() const { return it != end; }
        void* next() {
            if (it == end) return nullptr; // error in real usage
            return *it++;
        }
    };

    // ---------- constructors ----------
    HashSet() = default;
    HashSet(const HashSet& other) : data(other.data) {}

    // ---------- methods ----------
    void remove(void* p0) {
        data.erase(p0);
    }

    int size() const {
        return static_cast<int>(data.size());
    }

    HashSet* clone() const {
        return new HashSet(*this);
    }

    void clear() {
        data.clear();
    }

    bool isEmpty() const {
        return data.empty();
    }

    void add(void* p0) {
        data.insert(p0);
    }

    // toArray() with no argument returns a vector of pointers
    std::vector<void*> toArray() const {
        return std::vector<void*>(data.begin(), data.end());
    }

    // toArray(Object[] a) - fills the given vector and returns it by reference
    // In Java this also returns the array, but we return the modified vector for convenience.
    std::vector<void*>& toArray(std::vector<void*>& p0) const {
        p0.assign(data.begin(), data.end());
        return p0;
    }

    // iterator() returns a pointer to a new Iterator (caller responsible for deletion)
    Iterator* iterator() const {
        return new Iterator(data);
    }

    bool contains(void* p0) const {
        return data.find(p0) != data.end();
    }

    // spliterator() - dummy stub, returns nullptr (Java's Spliterator not fully emulated)
    void* spliterator() const {
        return nullptr; // minimal stub
    }

    // Static factory method (Java: HashSet.newHashSet(int))
    static HashSet* newHashSet(int capacity) {
        (void)capacity; // ignored in this simple implementation
        return new HashSet();
    }

private:
    std::unordered_set<void*> data;
};

// ==================== Test functions (translated from Java @Test methods) ====================

void remove_test_3503(void* p0) {
    HashSet instance;
    instance.remove(p0);
}

void size_test_3504() {
    HashSet instance;
    instance.size();
}

void clone_test_3505() {
    HashSet instance;
    instance.clone(); // memory leak ignored, as in Java test
}

void clear_test_3506() {
    HashSet instance;
    instance.clear();
}

void isEmpty_test_3507() {
    HashSet instance;
    instance.isEmpty();
}

void add_test_3508(void* p0) {
    HashSet instance;
    instance.add(p0);
}

// Java: toArray(Object[] p0) ==> C++: takes a vector reference
void toArray_test_3509(std::vector<void*>& p0) {
    HashSet instance;
    instance.toArray(p0);
}

void toArray_test_3510() {
    HashSet instance;
    instance.toArray();
}

void iterator_test_3511() {
    HashSet instance;
    instance.iterator();
}

void contains_test_3512(void* p0) {
    HashSet instance;
    instance.contains(p0);
}

void spliterator_test_3513() {
    HashSet instance;
    instance.spliterator();
}

void newHashSet_test_3514(int p0) {
    HashSet::newHashSet(p0); // static call
}
```