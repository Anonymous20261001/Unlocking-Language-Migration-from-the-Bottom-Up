```cpp
#include <string>
#include <exception>

// Minimal Node class representing a DOM node
class Node {
public:
    virtual ~Node() = default;
};

// IIOInvalidTreeException equivalent
class IIOInvalidTreeException : public std::exception {
private:
    std::string message;
    Node* offendingNode;

public:
    IIOInvalidTreeException(const std::string& msg, Node* node)
        : message(msg), offendingNode(node) {}

    Node* getOffendingNode() const {
        return offendingNode;
    }

    const char* what() const noexcept override {
        return message.c_str();
    }
};

// Test function (equivalent to JUnit @Test method)
void getOffendingNode_test_5346(std::string c0, Node* c1) {
    IIOInvalidTreeException instance(c0, c1);
    instance.getOffendingNode();
}
```