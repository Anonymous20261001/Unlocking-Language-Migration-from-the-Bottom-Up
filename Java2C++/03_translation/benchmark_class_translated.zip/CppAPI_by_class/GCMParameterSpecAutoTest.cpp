```cpp
#include <cstdint>
#include <vector>

class GCMParameterSpec {
private:
    int tLen;
    std::vector<uint8_t> iv;

public:
    GCMParameterSpec(int tLen, const std::vector<uint8_t>& iv)
        : tLen(tLen), iv(iv) {}

    std::vector<uint8_t> getIV() const {
        return iv; // return a copy
    }

    int getTLen() const {
        return tLen;
    }
};

// Test functions (equivalent to the Java @Test methods)
void getIV_test_5247(int c0, const std::vector<uint8_t>& c1) {
    GCMParameterSpec instance(c0, c1);
    instance.getIV();
}

void getTLen_test_5248(int c0, const std::vector<uint8_t>& c1) {
    GCMParameterSpec instance(c0, c1);
    instance.getTLen();
}
```