```cpp
#include <iostream>

// Minimal Dimension class to match Java's java.awt.Dimension
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Base class for Swing components (stub)
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// JInternalFrame extends JComponent (stub)
class JInternalFrame : public JComponent {
public:
    JInternalFrame() {}
};

// BasicInternalFrameUI (stub implementing similar API)
class BasicInternalFrameUI {
private:
    JInternalFrame* frame;
    JComponent* northPane;
    JComponent* southPane;
    JComponent* eastPane;
    JComponent* westPane;
    bool keyBindingActive;
    Dimension maximumSize;
    Dimension preferredSize;
    Dimension minimumSize;

public:
    BasicInternalFrameUI(JInternalFrame* c0)
        : frame(c0), northPane(nullptr), southPane(nullptr),
          eastPane(nullptr), westPane(nullptr), keyBindingActive(false) {}

    // Static factory method
    static BasicInternalFrameUI* createUI(JComponent* p0) {
        // In real Swing, creates UI for the component; here we return a dummy instance.
        // Note: The test calls this but ignores the return value.
        return new BasicInternalFrameUI(nullptr);
    }

    void installUI(JComponent* p0) {
        // Install UI for the component
    }

    void uninstallUI(JComponent* p0) {
        // Uninstall UI
    }

    void setNorthPane(JComponent* p0) {
        northPane = p0;
    }

    void setSouthPane(JComponent* p0) {
        southPane = p0;
    }

    void setEastPane(JComponent* p0) {
        eastPane = p0;
    }

    void setWestPane(JComponent* p0) {
        westPane = p0;
    }

    bool isKeyBindingActive() {
        return keyBindingActive;
    }

    JComponent* getNorthPane() {
        return northPane;
    }

    JComponent* getSouthPane() {
        return southPane;
    }

    JComponent* getWestPane() {
        return westPane;
    }

    JComponent* getEastPane() {
        return eastPane;
    }

    Dimension getMaximumSize(JComponent* p0) {
        return maximumSize;
    }

    Dimension getPreferredSize(JComponent* p0) {
        return preferredSize;
    }

    Dimension getMinimumSize(JComponent* p0) {
        return minimumSize;
    }
};

// Test functions (C++ translation of Java @Test methods)

void installUI_test_8789(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.installUI(p0);
}

void uninstallUI_test_8790(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.uninstallUI(p0);
}

void setNorthPane_test_8791(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.setNorthPane(p0);
}

void setSouthPane_test_8792(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.setSouthPane(p0);
}

void setEastPane_test_8793(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.setEastPane(p0);
}

void setWestPane_test_8794(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.setWestPane(p0);
}

void isKeyBindingActive_test_8795(JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.isKeyBindingActive();
}

void getNorthPane_test_8796(JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getNorthPane();
}

void getSouthPane_test_8797(JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getSouthPane();
}

void getWestPane_test_8798(JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getWestPane();
}

void getEastPane_test_8799(JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getEastPane();
}

void createUI_test_8800(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0); // not used
    BasicInternalFrameUI::createUI(p0);
}

void getMaximumSize_test_8801(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getMaximumSize(p0);
}

void getPreferredSize_test_8802(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getPreferredSize(p0);
}

void getMinimumSize_test_8803(JComponent* p0, JInternalFrame* c0) {
    BasicInternalFrameUI instance(c0);
    instance.getMinimumSize(p0);
}
```