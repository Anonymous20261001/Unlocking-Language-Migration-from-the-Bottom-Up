```cpp
#include <string>

// Forward declarations
class JComponent;
class Graphics;
class Graphics2D;
class Color;
class FontMetrics;
class AbstractButton;

// ==================== Stub Classes ====================

class Color {
public:
    int r, g, b;
    Color(int r, int g, int b) : r(r), g(g), b(b) {}
};

class FontMetrics {
public:
    // Stub – no methods used in the tests
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class Graphics2D : public Graphics {
public:
    // Stub – no methods used in the tests
};

class JComponent {
public:
    // Stub – no methods used in the tests
};

class AbstractButton : public JComponent {
public:
    // Stub – no methods used in the tests
};

// ==================== BasicGraphicsUtils ====================

class BasicGraphicsUtils {
public:
    static void drawString(JComponent*, Graphics2D*, const std::string&, float, float) {
        // No implementation needed for the test
    }

    static void drawString(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void drawLoweredBezel(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawEtchedRect(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void getEtchedInsets() {
        // Return type ignored in test
    }

    static void drawGroove(Graphics*, int, int, int, int, Color*, Color*) {
        // No implementation needed for the test
    }

    static void getGrooveInsets() {
        // Return type ignored in test
    }

    static void drawBezel(Graphics*, int, int, int, int, bool, bool, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawDashedRect(Graphics*, int, int, int, int) {
        // No implementation needed for the test
    }

    static void getClippedString(JComponent*, FontMetrics*, const std::string&, int) {
        // Return type ignored in test
    }

    static void getStringWidth(JComponent*, FontMetrics*, const std::string&) {
        // Return type ignored in test
    }

    static void drawStringUnderlineCharAt(JComponent*, Graphics2D*, const std::string&, int, float, float) {
        // No implementation needed for the test
    }

    static void drawStringUnderlineCharAt(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void getPreferredButtonSize(AbstractButton*, int) {
        // Return type ignored in test
    }
};

// ==================== Test Functions ====================

void drawString_test_8762(JComponent* p0, Graphics2D* p1, std::string p2, float p3, float p4) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawString(p0, p1, p2, p3, p4);
}

void drawString_test_8763(Graphics* p0, std::string p1, int p2, int p3, int p4) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawString(p0, p1, p2, p3, p4);
}

void drawLoweredBezel_test_8764(Graphics* p0, int p1, int p2, int p3, int p4,
                                Color* p5, Color* p6, Color* p7, Color* p8) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawLoweredBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8);
}

void drawEtchedRect_test_8765(Graphics* p0, int p1, int p2, int p3, int p4,
                              Color* p5, Color* p6, Color* p7, Color* p8) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawEtchedRect(p0, p1, p2, p3, p4, p5, p6, p7, p8);
}

void getEtchedInsets_test_8766() {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::getEtchedInsets();
}

void drawGroove_test_8767(Graphics* p0, int p1, int p2, int p3, int p4,
                          Color* p5, Color* p6) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawGroove(p0, p1, p2, p3, p4, p5, p6);
}

void getGrooveInsets_test_8768() {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::getGrooveInsets();
}

void drawBezel_test_8769(Graphics* p0, int p1, int p2, int p3, int p4,
                         bool p5, bool p6, Color* p7, Color* p8,
                         Color* p9, Color* p10) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
}

void drawDashedRect_test_8770(Graphics* p0, int p1, int p2, int p3, int p4) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawDashedRect(p0, p1, p2, p3, p4);
}

void getClippedString_test_8771(JComponent* p0, FontMetrics* p1, std::string p2, int p3) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::getClippedString(p0, p1, p2, p3);
}

void getStringWidth_test_8772(JComponent* p0, FontMetrics* p1, std::string p2) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::getStringWidth(p0, p1, p2);
}

void drawStringUnderlineCharAt_test_8773(JComponent* p0, Graphics2D* p1,
                                          std::string p2, int p3,
                                          float p4, float p5) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawStringUnderlineCharAt(p0, p1, p2, p3, p4, p5);
}

void drawStringUnderlineCharAt_test_8774(Graphics* p0, std::string p1,
                                          int p2, int p3, int p4) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::drawStringUnderlineCharAt(p0, p1, p2, p3, p4);
}

void getPreferredButtonSize_test_8775(AbstractButton* p0, int p1) {
    BasicGraphicsUtils instance;
    BasicGraphicsUtils::getPreferredButtonSize(p0, p1);
}
```