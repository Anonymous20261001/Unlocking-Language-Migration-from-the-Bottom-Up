```cpp
#include <string>
#include <stdexcept>

class DuplicateFormatFlagsException : public std::runtime_error {
private:
    std::string flags;

public:
    DuplicateFormatFlagsException(const std::string& f)
        : std::runtime_error("Duplicate flags: " + f), flags(f) {}

    std::string getFlags() const {
        return flags;
    }

    // getMessage() is inherited from std::runtime_error via what()
    // For consistency with Java's getMessage() we provide an explicit method
    std::string getMessage() const {
        return what();
    }
};

// Test function declarations
void getMessage_test_3425(const std::string& c0);
void getFlags_test_3426(const std::string& c0);

// Test function implementations
void getMessage_test_3425(const std::string& c0) {
    DuplicateFormatFlagsException instance(c0);
    instance.getMessage();
}

void getFlags_test_3426(const std::string& c0) {
    DuplicateFormatFlagsException instance(c0);
    instance.getFlags();
}
```