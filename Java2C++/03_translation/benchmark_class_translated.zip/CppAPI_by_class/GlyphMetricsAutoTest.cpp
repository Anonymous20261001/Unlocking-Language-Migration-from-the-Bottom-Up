```cpp
#include <cstdint>
#include <cmath>

// -----------------------------------------------------------------------------
// Rectangle2D (simplified, mimicking java.awt.geom.Rectangle2D)
// -----------------------------------------------------------------------------
class Rectangle2D {
public:
    float x, y, width, height;

    Rectangle2D() : x(0), y(0), width(0), height(0) {}
    Rectangle2D(float x, float y, float w, float h) : x(x), y(y), width(w), height(h) {}

    float getX() const { return x; }
    float getY() const { return y; }
    float getWidth() const { return width; }
    float getHeight() const { return height; }
    float getMinX() const { return x; }
    float getMaxX() const { return x + width; }
    float getMinY() const { return y; }
    float getMaxY() const { return y + height; }
};

// -----------------------------------------------------------------------------
// GlyphMetrics (mimicking java.awt.font.GlyphMetrics)
// -----------------------------------------------------------------------------
class GlyphMetrics {
public:
    // Glyph type constants (matching Java's GlyphMetrics)
    static constexpr int8_t STANDARD   = 0;
    static constexpr int8_t LIGATURE   = 1;
    static constexpr int8_t COMBINING  = 2;
    static constexpr int8_t COMPONENT  = 3;
    static constexpr int8_t WHITESPACE = 4;

private:
    float advanceX_;
    float advanceY_;
    float lsb_;
    float rsb_;
    Rectangle2D bounds_;
    int8_t glyphType_;
    bool horizontal_;

public:
    // Constructor for horizontal glyphs (advance = X advance, Y advance = 0)
    GlyphMetrics(float advance, const Rectangle2D& bounds, int8_t glyphType)
        : advanceX_(advance), advanceY_(0.0f), bounds_(bounds), glyphType_(glyphType), horizontal_(true)
    {
        // Compute side bearings
        lsb_ = -bounds.getMinX();               // distance from origin to left edge
        rsb_ = advanceX_ - bounds.getMaxX();    // distance from right edge to advance point
    }

    // Accessors
    float getAdvanceX() const { return advanceX_; }
    float getAdvanceY() const { return advanceY_; }
    float getLSB() const { return lsb_; }
    float getRSB() const { return rsb_; }

    float getAdvance() const {
        // For horizontal glyphs returns X advance, for vertical returns Y advance.
        // This constructor always creates horizontal glyphs.
        return advanceX_;
    }

    const Rectangle2D& getBounds2D() const {
        return bounds_;
    }

    int8_t getType() const { return glyphType_; }

    bool isStandard()   const { return glyphType_ == STANDARD; }
    bool isLigature()   const { return glyphType_ == LIGATURE; }
    bool isCombining()  const { return glyphType_ == COMBINING; }
    bool isComponent()  const { return glyphType_ == COMPONENT; }
    bool isWhitespace() const { return glyphType_ == WHITESPACE; }
};

// -----------------------------------------------------------------------------
// Test functions (each corresponds to a Java @Test method)
// -----------------------------------------------------------------------------
void getAdvanceX_test_832(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getAdvanceX();
}

void getAdvanceY_test_833(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getAdvanceY();
}

void getLSB_test_834(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getLSB();
}

void getRSB_test_835(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getRSB();
}

void isStandard_test_836(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.isStandard();
}

void isLigature_test_837(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.isLigature();
}

void isCombining_test_838(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.isCombining();
}

void isComponent_test_839(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.isComponent();
}

void getAdvance_test_840(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getAdvance();
}

void getBounds2D_test_841(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getBounds2D();
}

void isWhitespace_test_842(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.isWhitespace();
}

void getType_test_843(float c0, const Rectangle2D& c1, int8_t c2) {
    GlyphMetrics instance(c0, c1, c2);
    instance.getType();
}
```