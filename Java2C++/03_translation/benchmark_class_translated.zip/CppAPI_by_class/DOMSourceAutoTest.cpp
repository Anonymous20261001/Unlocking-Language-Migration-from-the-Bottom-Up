```cpp
#include <string>

// Minimal Node class to represent org.w3c.dom.Node
class Node {
public:
    virtual ~Node() = default;
};

// C++ equivalent of javax.xml.transform.dom.DOMSource
class DOMSource {
private:
    std::string systemId_;
    Node* node_;

public:
    // Default constructor: node is null, systemId empty
    DOMSource() : systemId_(), node_(nullptr) {}

    // Get system ID
    const std::string& getSystemId() const {
        return systemId_;
    }

    // Set system ID
    void setSystemId(const std::string& systemId) {
        systemId_ = systemId;
    }

    // Returns true if the node is null
    bool isEmpty() const {
        return node_ == nullptr;
    }

    // Get the underlying Node
    Node* getNode() const {
        return node_;
    }

    // Set the underlying Node
    void setNode(Node* node) {
        node_ = node;
    }
};

// Test functions (translated from Java @Test methods)
void getSystemId_test_10978() {
    DOMSource instance;
    instance.getSystemId();
}

void setSystemId_test_10979(std::string p0) {
    DOMSource instance;
    instance.setSystemId(p0);
}

void isEmpty_test_10980() {
    DOMSource instance;
    instance.isEmpty();
}

void getNode_test_10981() {
    DOMSource instance;
    instance.getNode();
}

void setNode_test_10982(Node* p0) {
    DOMSource instance;
    instance.setNode(p0);
}
```