```cpp
#include <cstdint>
#include <vector>
#include <cstddef>
#include <cstring>

// Minimal ByteBuffer class to mimic Java's java.nio.ByteBuffer
class ByteBuffer {
public:
    ByteBuffer(const uint8_t* data, size_t size)
        : data_(data), size_(size), pos_(0) {}

    // Returns number of remaining bytes (from current position to limit)
    size_t remaining() const {
        return size_ - pos_;
    }

    // Returns pointer to the first remaining byte
    const uint8_t* pointer() const {
        return data_ + pos_;
    }

    // Advance position (not needed for update but kept for completeness)
    void advance(size_t n) {
        pos_ += n;
        if (pos_ > size_) pos_ = size_;
    }

private:
    const uint8_t* data_;
    size_t size_;
    size_t pos_;
};

// CRC32 class with API identical to java.util.zip.CRC32
class CRC32 {
public:
    CRC32() {
        reset();
        initLookupTable();
    }

    void reset() {
        crc_ = 0xFFFFFFFFu;
    }

    void update(int b) {
        uint8_t byte = static_cast<uint8_t>(b & 0xFF);
        crc_ = (crc_ >> 8) ^ table_[(crc_ ^ byte) & 0xFF];
    }

    void update(const ByteBuffer& buffer) {
        const uint8_t* data = buffer.pointer();
        size_t len = buffer.remaining();
        for (size_t i = 0; i < len; ++i) {
            uint8_t byte = data[i];
            crc_ = (crc_ >> 8) ^ table_[(crc_ ^ byte) & 0xFF];
        }
    }

    void update(const uint8_t* b, int off, int len) {
        for (int i = 0; i < len; ++i) {
            uint8_t byte = b[off + i];
            crc_ = (crc_ >> 8) ^ table_[(crc_ ^ byte) & 0xFF];
        }
    }

    uint32_t getValue() const {
        return crc_ ^ 0xFFFFFFFFu;
    }

private:
    uint32_t crc_;
    static uint32_t table_[256];
    static bool tableInitialized_;

    static void initLookupTable() {
        if (tableInitialized_) return;
        for (uint32_t i = 0; i < 256; ++i) {
            uint32_t crc = i;
            for (int j = 0; j < 8; ++j) {
                if (crc & 1)
                    crc = (crc >> 1) ^ 0xEDB88320u;
                else
                    crc >>= 1;
            }
            table_[i] = crc;
        }
        tableInitialized_ = true;
    }
};

// Static table definition
uint32_t CRC32::table_[256];
bool CRC32::tableInitialized_ = false;

// -------------------------------------------------------------------
// Test functions (exact translations of the Java @Test methods)
// -------------------------------------------------------------------

void reset_test_5124() {
    CRC32 instance;
    instance.reset();
}

void update_test_5125(int p0) {
    CRC32 instance;
    instance.update(p0);
}

void update_test_5126(ByteBuffer p0) {
    CRC32 instance;
    instance.update(p0);
}

void update_test_5127(const uint8_t* p0, int p1, int p2) {
    CRC32 instance;
    instance.update(p0, p1, p2);
}

void getValue_test_5128() {
    CRC32 instance;
    instance.getValue();
}
```