```cpp
#include <vector>
#include <stdexcept>

// ============ Stub classes for Java types ============

class RenderedImage {
public:
    virtual ~RenderedImage() = default;
};

class Raster {
public:
    virtual ~Raster() = default;
};

class IIOMetadata {
public:
    virtual ~IIOMetadata() = default;
};

// Minimal List implementation emulating Java List<RenderedImage>
class List {
public:
    std::vector<RenderedImage*> items;

    int size() const {
        return static_cast<int>(items.size());
    }

    RenderedImage* get(int index) const {
        if (index < 0 || index >= static_cast<int>(items.size()))
            throw std::out_of_range("List::get index out of range");
        return items[index];
    }

    // Convenience method to add elements (not used by tests directly, but needed for construction)
    void add(RenderedImage* img) {
        items.push_back(img);
    }
};

// ============ IIOImage implementation ============

class IIOImage {
private:
    RenderedImage* image;
    Raster* raster;
    List* thumbnails;
    IIOMetadata* metadata;

public:
    IIOImage(RenderedImage* image, List* thumbnails, IIOMetadata* metadata)
        : image(image), raster(nullptr), thumbnails(thumbnails), metadata(metadata) {}

    RenderedImage* getRenderedImage() const {
        return image;
    }

    void setRenderedImage(RenderedImage* image) {
        this->image = image;
    }

    bool hasRaster() const {
        return raster != nullptr;
    }

    void setRaster(Raster* raster) {
        this->raster = raster;
    }

    int getNumThumbnails() const {
        return thumbnails ? thumbnails->size() : 0;
    }

    RenderedImage* getThumbnail(int index) const {
        if (!thumbnails)
            throw std::out_of_range("No thumbnails");
        return thumbnails->get(index);
    }

    List* getThumbnails() const {
        return thumbnails;
    }

    void setThumbnails(List* thumbnails) {
        this->thumbnails = thumbnails;
    }

    IIOMetadata* getMetadata() const {
        return metadata;
    }

    void setMetadata(IIOMetadata* metadata) {
        this->metadata = metadata;
    }

    Raster* getRaster() const {
        return raster;
    }
};

// ============ Translated test functions ============

void getRenderedImage_test_5277(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getRenderedImage();
}

void setRenderedImage_test_5278(RenderedImage* p0, RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.setRenderedImage(p0);
}

void hasRaster_test_5279(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.hasRaster();
}

void setRaster_test_5280(Raster* p0, RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.setRaster(p0);
}

void getNumThumbnails_test_5281(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getNumThumbnails();
}

void getThumbnail_test_5282(int p0, RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getThumbnail(p0);
}

void getThumbnails_test_5283(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getThumbnails();
}

void setThumbnails_test_5284(List* p0, RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.setThumbnails(p0);
}

void getMetadata_test_5285(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getMetadata();
}

void setMetadata_test_5286(IIOMetadata* p0, RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.setMetadata(p0);
}

void getRaster_test_5287(RenderedImage* c0, List* c1, IIOMetadata* c2) {
    IIOImage instance(c0, c1, c2);
    instance.getRaster();
}
```