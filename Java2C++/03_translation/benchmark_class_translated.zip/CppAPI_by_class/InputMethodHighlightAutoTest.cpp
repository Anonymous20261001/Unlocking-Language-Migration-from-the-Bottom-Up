```cpp
#include <cstddef>  // not strictly needed, but included for completeness

// Equivalent of java.awt.im.InputMethodHighlight
class InputMethodHighlight {
public:
    // Nested class mimicking Java's InputMethodHighlight.Style
    class Style {
    public:
        // Static constant for the default style, as in Java
        static const Style DEFAULT;

        // Copy constructor and assignment are implicitly deleted because of
        // private constructor; we do not need them as we only use references.
    private:
        int id;
        // Private constructor – only we can create instances
        Style(int id) : id(id) {}
    };

    // Two-argument constructor (as used in the tests)
    InputMethodHighlight(bool selected, int state)
        : selected(selected), state(state), variation(0), style(Style::DEFAULT) {}

    // Accessor methods – exact same names and signatures as Java
    int getVariation() const { return variation; }
    const Style& getStyle() const { return style; }
    bool isSelected() const { return selected; }
    int getState() const { return state; }

private:
    bool selected;
    int state;
    int variation;
    const Style& style; // reference to the static DEFAULT style
};

// Definition of the static constant
const InputMethodHighlight::Style InputMethodHighlight::Style::DEFAULT(0);

// ------------------------------------------------------------------
// C++ test functions corresponding to the Java @Test methods.
// All functions keep the same name and parameter types as the original.
// ------------------------------------------------------------------

void getVariation_test_1005(bool c0, int c1) {
    InputMethodHighlight instance(c0, c1);
    instance.getVariation();
}

void getStyle_test_1006(bool c0, int c1) {
    InputMethodHighlight instance(c0, c1);
    instance.getStyle();
}

void isSelected_test_1007(bool c0, int c1) {
    InputMethodHighlight instance(c0, c1);
    instance.isSelected();
}

void getState_test_1008(bool c0, int c1) {
    InputMethodHighlight instance(c0, c1);
    instance.getState();
}
```