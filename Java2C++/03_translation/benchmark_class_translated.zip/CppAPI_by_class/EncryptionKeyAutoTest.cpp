```cpp
#include <vector>
#include <cstdint>
#include <string>
#include <sstream>
#include <functional>

// Base class to mimic Java Object (minimal)
class Object {
public:
    virtual ~Object() = default;
};

// C++ equivalent of javax.security.auth.kerberos.EncryptionKey
class EncryptionKey : public Object {
private:
    std::vector<uint8_t> key;
    int keyType;
    bool destroyed;

public:
    EncryptionKey(const std::vector<uint8_t>& keyBytes, int type)
        : key(keyBytes), keyType(type), destroyed(false) {}

    // equals: checks if the other object is also an EncryptionKey with same key and type
    bool equals(const Object& obj) const {
        const EncryptionKey* other = dynamic_cast<const EncryptionKey*>(&obj);
        if (!other) return false;
        return key == other->key && keyType == other->keyType;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "EncryptionKey: keyType=" << keyType << ", key.size=" << key.size();
        return oss.str();
    }

    int hashCode() const {
        int hash = std::hash<std::string>{}(std::string(key.begin(), key.end()));
        hash ^= keyType;
        return hash;
    }

    bool isDestroyed() const {
        return destroyed;
    }

    std::vector<uint8_t> getEncoded() const {
        return key;
    }

    std::string getFormat() const {
        return "RAW";
    }

    std::string getAlgorithm() const {
        switch (keyType) {
            case 1: return "DES";
            case 2: return "DESede";
            case 3: return "AES128";
            case 4: return "AES256";
            default: return "unknown";
        }
    }

    int getKeyType() const {
        return keyType;
    }
};

// ------------------ Test functions (one per @Test method) ------------------

void equals_test_6362(const Object& p0, const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.equals(p0);
}

void toString_test_6363(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.toString();
}

void hashCode_test_6364(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.hashCode();
}

void isDestroyed_test_6365(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.isDestroyed();
}

void getEncoded_test_6366(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.getEncoded();
}

void getFormat_test_6367(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.getFormat();
}

void getAlgorithm_test_6368(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.getAlgorithm();
}

void getKeyType_test_6369(const std::vector<uint8_t>& c0, int c1) {
    EncryptionKey instance(c0, c1);
    instance.getKeyType();
}
```