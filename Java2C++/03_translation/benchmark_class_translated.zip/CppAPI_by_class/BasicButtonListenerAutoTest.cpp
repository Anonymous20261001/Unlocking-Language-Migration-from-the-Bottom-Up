```cpp
#include <cstddef> // For NULL

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature
void propertyChange_test_8627(PropertyChangeEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.propertyChange(p0);
}

void stateChanged_test_8628(ChangeEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.stateChanged(p0);
}

void installKeyboardActions_test_8629(JComponent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.installKeyboardActions(p0);
}

void uninstallKeyboardActions_test_8630(JComponent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.uninstallKeyboardActions(p0);
}

void focusGained_test_8631(FocusEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.focusGained(p0);
}

void focusLost_test_8632(FocusEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.focusLost(p0);
}

void mousePressed_test_8633(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mousePressed(p0);
}

void mouseReleased_test_8634(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseReleased(p0);
}

void mouseClicked_test_8635(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseClicked(p0);
}

void mouseExited_test_8636(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseExited(p0);
}

void mouseEntered_test_8637(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseEntered(p0);
}

void mouseMoved_test_8638(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseMoved(p0);
}

void mouseDragged_test_8639(MouseEvent* p0, AbstractButton* c0) {
    BasicButtonListener instance(c0);
    instance.mouseDragged(p0);
}
```