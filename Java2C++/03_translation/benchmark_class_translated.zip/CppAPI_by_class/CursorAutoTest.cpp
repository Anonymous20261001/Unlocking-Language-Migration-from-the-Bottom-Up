```cpp
#include <string>
#include <unordered_map>
#include <sstream>

// C++ equivalent of java.awt.Cursor
class Cursor {
private:
    int type;
    std::string name;

    // Helper to get cursor name from type
    static std::string getNameForType(int type) {
        static const std::unordered_map<int, std::string> names = {
            {0, "Default Cursor"},
            {1, "Crosshair Cursor"},
            {2, "Text Cursor"},
            {3, "Wait Cursor"},
            {4, "SW Resize Cursor"},
            {5, "SE Resize Cursor"},
            {6, "NW Resize Cursor"},
            {7, "NE Resize Cursor"},
            {8, "N Resize Cursor"},
            {9, "S Resize Cursor"},
            {10, "W Resize Cursor"},
            {11, "E Resize Cursor"},
            {12, "Hand Cursor"},
            {13, "Move Cursor"}
        };
        auto it = names.find(type);
        if (it != names.end()) {
            return it->second;
        }
        return "Unknown Cursor";
    }

public:
    // Constructor matching Java Cursor(int)
    explicit Cursor(int type) : type(type), name(getNameForType(type)) {}

    // Static method: getPredefinedCursor
    static Cursor getPredefinedCursor(int type) {
        return Cursor(type);
    }

    // Static method: getDefaultCursor
    static Cursor getDefaultCursor() {
        return Cursor(0); // DEFAULT_CURSOR = 0
    }

    // Instance methods
    std::string getName() const {
        return name;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "java.awt.Cursor[type=" << type << "]";
        return oss.str();
    }

    int getType() const {
        return type;
    }
};

// Translation of the Java @Test methods
void getPredefinedCursor_test_164(int p0, int c0) {
    Cursor instance(c0);
    Cursor::getPredefinedCursor(p0);
}

void getDefaultCursor_test_165(int c0) {
    Cursor instance(c0);
    Cursor::getDefaultCursor();
}

void getName_test_166(int c0) {
    Cursor instance(c0);
    instance.getName();
}

void toString_test_167(int c0) {
    Cursor instance(c0);
    instance.toString();
}

void getType_test_168(int c0) {
    Cursor instance(c0);
    instance.getType();
}
```