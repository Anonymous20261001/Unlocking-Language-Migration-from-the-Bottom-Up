```cpp
#include <string>

// Minimal stubs for Java AWT/Swing types used in the tests
class Component {};
class Graphics {};
class Image {};
class ImageObserver {};
class AccessibleContext {};

// ImageIcon stub mimicking the Java API
class ImageIcon {
public:
    ImageIcon() : description(), image(nullptr), observer(nullptr) {}

    int getIconWidth() { return 0; }
    int getIconHeight() { return 0; }
    int getImageLoadStatus() { return 0; }

    void setDescription(const std::string& desc) { description = desc; }
    std::string getDescription() { return description; }

    void paintIcon(Component*, Graphics*, int, int) { /* no-op */ }

    void setImage(Image* img) { image = img; }
    Image* getImage() { return image; }

    void setImageObserver(ImageObserver* obs) { observer = obs; }
    ImageObserver* getImageObserver() { return observer; }

    AccessibleContext* getAccessibleContext() { return nullptr; }

    std::string toString() { return "ImageIcon"; }

private:
    std::string description;
    Image* image;
    ImageObserver* observer;
};

// Test functions (translated from the Java @Test methods)
void getIconWidth_test_6836() {
    ImageIcon instance;
    instance.getIconWidth();
}

void getIconHeight_test_6837() {
    ImageIcon instance;
    instance.getIconHeight();
}

void getImageLoadStatus_test_6838() {
    ImageIcon instance;
    instance.getImageLoadStatus();
}

void setDescription_test_6839(const std::string& p0) {
    ImageIcon instance;
    instance.setDescription(p0);
}

void paintIcon_test_6840(Component* p0, Graphics* p1, int p2, int p3) {
    ImageIcon instance;
    instance.paintIcon(p0, p1, p2, p3);
}

void setImageObserver_test_6841(ImageObserver* p0) {
    ImageIcon instance;
    instance.setImageObserver(p0);
}

void getImageObserver_test_6842() {
    ImageIcon instance;
    instance.getImageObserver();
}

void getDescription_test_6843() {
    ImageIcon instance;
    instance.getDescription();
}

void getImage_test_6844() {
    ImageIcon instance;
    instance.getImage();
}

void getAccessibleContext_test_6845() {
    ImageIcon instance;
    instance.getAccessibleContext();
}

void setImage_test_6846(Image* p0) {
    ImageIcon instance;
    instance.setImage(p0);
}

void toString_test_6847() {
    ImageIcon instance;
    instance.toString();
}
```