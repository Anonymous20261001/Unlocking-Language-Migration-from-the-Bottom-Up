```cpp
#include <string>
#include <exception>

class FileSystemException : public std::exception {
public:
    explicit FileSystemException(const std::string& file)
        : file_(file), other_(nullptr), reason_(nullptr) {}

    FileSystemException(const std::string& file, const std::string& other, const std::string& reason)
        : file_(file), other_(std::make_shared<std::string>(other)), reason_(std::make_shared<std::string>(reason)) {}

    const std::string& getFile() const {
        return file_;
    }

    std::string getMessage() const {
        std::string msg = file_;
        if (other_) {
            msg += " -> " + *other_;
        }
        if (reason_) {
            msg += " (" + *reason_ + ")";
        }
        return msg;
    }

    std::string getReason() const {
        return reason_ ? *reason_ : "";
    }

    std::string getOtherFile() const {
        return other_ ? *other_ : "";
    }

    // Override what() for exception compatibility
    const char* what() const noexcept override {
        // We store the message to avoid temporary issues
        static std::string msg;
        msg = getMessage();
        return msg.c_str();
    }

private:
    std::string file_;
    std::shared_ptr<std::string> other_;   // null if not set
    std::shared_ptr<std::string> reason_;  // null if not set
};

// Test functions (equivalent to Java @Test methods)
void getMessage_test_2648(const std::string& c0) {
    FileSystemException instance(c0);
    instance.getMessage();
}

void getFile_test_2649(const std::string& c0) {
    FileSystemException instance(c0);
    instance.getFile();
}

void getReason_test_2650(const std::string& c0) {
    FileSystemException instance(c0);
    instance.getReason();
}

void getOtherFile_test_2651(const std::string& c0) {
    FileSystemException instance(c0);
    instance.getOtherFile();
}
```