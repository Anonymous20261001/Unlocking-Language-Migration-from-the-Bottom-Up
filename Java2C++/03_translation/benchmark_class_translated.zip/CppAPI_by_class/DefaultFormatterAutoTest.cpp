```cpp
#include <cstddef>

// Minimal stubs for Java classes
class JFormattedTextField {
public:
    JFormattedTextField() = default;
    JFormattedTextField(const JFormattedTextField&) = default;
    JFormattedTextField& operator=(const JFormattedTextField&) = default;
    ~JFormattedTextField() = default;
};

class Class {
public:
    Class() = default;
    Class(const Class&) = default;
    Class& operator=(const Class&) = default;
    ~Class() = default;
};

// C++ equivalent of javax.swing.text.DefaultFormatter
class DefaultFormatter {
public:
    DefaultFormatter()
        : overwriteMode(false)
        , allowsInvalid(true)
        , commitsOnValidEdit(false)
        , valueClass()
    {}

    void install(JFormattedTextField& /*p0*/) {
        // No real behaviour needed for tests
    }

    void setOverwriteMode(bool p0) {
        overwriteMode = p0;
    }

    bool getOverwriteMode() const {
        return overwriteMode;
    }

    Class getValueClass() const {
        return valueClass;
    }

    void setValueClass(Class p0) {
        valueClass = p0;
    }

    bool getAllowsInvalid() const {
        return allowsInvalid;
    }

    void setAllowsInvalid(bool p0) {
        allowsInvalid = p0;
    }

    bool getCommitsOnValidEdit() const {
        return commitsOnValidEdit;
    }

    void setCommitsOnValidEdit(bool p0) {
        commitsOnValidEdit = p0;
    }

private:
    bool overwriteMode;
    bool allowsInvalid;
    bool commitsOnValidEdit;
    Class valueClass;
};

// ===== Test functions (translated from Java @Test methods) =====

void install_test_10199(JFormattedTextField p0) {
    DefaultFormatter instance;
    instance.install(p0);
}

void setOverwriteMode_test_10200(bool p0) {
    DefaultFormatter instance;
    instance.setOverwriteMode(p0);
}

void getValueClass_test_10201() {
    DefaultFormatter instance;
    instance.getValueClass();
}

void getAllowsInvalid_test_10202() {
    DefaultFormatter instance;
    instance.getAllowsInvalid();
}

void getOverwriteMode_test_10203() {
    DefaultFormatter instance;
    instance.getOverwriteMode();
}

void getCommitsOnValidEdit_test_10204() {
    DefaultFormatter instance;
    instance.getCommitsOnValidEdit();
}

void setCommitsOnValidEdit_test_10205(bool p0) {
    DefaultFormatter instance;
    instance.setCommitsOnValidEdit(p0);
}

void setAllowsInvalid_test_10206(bool p0) {
    DefaultFormatter instance;
    instance.setAllowsInvalid(p0);
}

void setValueClass_test_10207(Class p0) {
    DefaultFormatter instance;
    instance.setValueClass(p0);
}
```