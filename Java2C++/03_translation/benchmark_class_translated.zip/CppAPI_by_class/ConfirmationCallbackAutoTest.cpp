```cpp
#include <string>
#include <vector>

class ConfirmationCallback {
public:
    // Option type constants
    static const int UNSPECIFIED_OPTION = -1;
    static const int YES_NO_OPTION = 0;
    static const int YES_NO_CANCEL_OPTION = 1;
    static const int OK_CANCEL_OPTION = 2;

    // Message type constants
    static const int INFORMATION = 0;
    static const int WARNING = 1;
    static const int ERROR = 2;

    // Constructor: messageType, explicit options, default option index
    ConfirmationCallback(int messageType, const std::vector<std::string>& options, int defaultOption)
        : messageType(messageType), options(options), defaultOption(defaultOption),
          selectedIndex(defaultOption), optionType(UNSPECIFIED_OPTION) {}

    // Get prompt (not set via this constructor, returns empty string to mimic null)
    std::string getPrompt() const {
        return ""; // matches Java's null behaviour
    }

    // Set the selected index
    void setSelectedIndex(int selection) {
        selectedIndex = selection;
    }

    // Get the message type
    int getMessageType() const {
        return messageType;
    }

    // Get the option type (always UNSPECIFIED_OPTION since options are provided explicitly)
    int getOptionType() const {
        return optionType;
    }

    // Get the options (returns a copy of the internal vector)
    std::vector<std::string> getOptions() const {
        return options;
    }

    // Get the default option index
    int getDefaultOption() const {
        return defaultOption;
    }

    // Get the currently selected index
    int getSelectedIndex() const {
        return selectedIndex;
    }

private:
    int messageType;
    std::vector<std::string> options;
    int defaultOption;
    int selectedIndex;
    int optionType;
};

// ========== Translated test functions ==========

void getPrompt_test_6333(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getPrompt();
}

void setSelectedIndex_test_6334(int p0, int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.setSelectedIndex(p0);
}

void getMessageType_test_6335(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getMessageType();
}

void getOptionType_test_6336(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getOptionType();
}

void getOptions_test_6337(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getOptions();
}

void getDefaultOption_test_6338(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getDefaultOption();
}

void getSelectedIndex_test_6339(int c0, const std::vector<std::string>& c1, int c2) {
    ConfirmationCallback instance(c0, c1, c2);
    instance.getSelectedIndex();
}
```