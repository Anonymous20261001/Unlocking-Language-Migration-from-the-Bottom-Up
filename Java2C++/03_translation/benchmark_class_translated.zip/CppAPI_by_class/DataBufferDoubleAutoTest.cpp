```cpp
#include <vector>
#include <cstddef>

class DataBufferDouble {
public:
    // Constructor: creates a single bank of the given size, initialized to 0.0
    explicit DataBufferDouble(int size) : m_size(size), m_data(size, 0.0) {
        m_banks.push_back(m_data.data());
    }

    // Returns a pointer to an array of pointers, each pointing to a bank's data
    double** getBankData() {
        return m_banks.data();
    }

    // Get element from bank 0
    double getElem(int i) {
        return m_data[i];
    }

    // Get element from a specific bank (only bank 0 exists)
    double getElem(int bank, int i) {
        return m_data[i];
    }

    // Get element as float from bank 0
    float getElemFloat(int i) {
        return static_cast<float>(m_data[i]);
    }

    // Get element as float from a specific bank
    float getElemFloat(int bank, int i) {
        return static_cast<float>(m_data[i]);
    }

    // Get element as double from bank 0
    double getElemDouble(int i) {
        return m_data[i];
    }

    // Get element as double from a specific bank
    double getElemDouble(int bank, int i) {
        return m_data[i];
    }

    // Set element to an int value (cast to double) in a specific bank
    void setElem(int bank, int i, int val) {
        m_data[i] = static_cast<double>(val);
    }

    // Set element to an int value (cast to double) in bank 0
    void setElem(int i, int val) {
        m_data[i] = static_cast<double>(val);
    }

    // Set element to a float value in a specific bank
    void setElemFloat(int bank, int i, float val) {
        m_data[i] = static_cast<double>(val);
    }

    // Set element to a float value in bank 0
    void setElemFloat(int i, float val) {
        m_data[i] = static_cast<double>(val);
    }

    // Set element to a double value in a specific bank
    void setElemDouble(int bank, int i, double val) {
        m_data[i] = val;
    }

    // Set element to a double value in bank 0
    void setElemDouble(int i, double val) {
        m_data[i] = val;
    }

    // Get pointer to the data array of a specific bank
    double* getData(int bank) {
        return m_data.data();
    }

    // Get pointer to the data array of bank 0
    double* getData() {
        return m_data.data();
    }

private:
    int m_size;
    std::vector<double> m_data;
    std::vector<double*> m_banks;
};

// Translated test functions (parameter names match the Java source)
void getBankData_test_1190(int c0) {
    DataBufferDouble instance(c0);
    instance.getBankData();
}

void getElem_test_1191(int p0, int p1, int c0) {
    DataBufferDouble instance(c0);
    instance.getElem(p0, p1);
}

void getElem_test_1192(int p0, int c0) {
    DataBufferDouble instance(c0);
    instance.getElem(p0);
}

void getElemFloat_test_1193(int p0, int c0) {
    DataBufferDouble instance(c0);
    instance.getElemFloat(p0);
}

void getElemFloat_test_1194(int p0, int p1, int c0) {
    DataBufferDouble instance(c0);
    instance.getElemFloat(p0, p1);
}

void getElemDouble_test_1195(int p0, int c0) {
    DataBufferDouble instance(c0);
    instance.getElemDouble(p0);
}

void getElemDouble_test_1196(int p0, int p1, int c0) {
    DataBufferDouble instance(c0);
    instance.getElemDouble(p0, p1);
}

void setElem_test_1197(int p0, int p1, int p2, int c0) {
    DataBufferDouble instance(c0);
    instance.setElem(p0, p1, p2);
}

void setElem_test_1198(int p0, int p1, int c0) {
    DataBufferDouble instance(c0);
    instance.setElem(p0, p1);
}

void setElemFloat_test_1199(int p0, int p1, float p2, int c0) {
    DataBufferDouble instance(c0);
    instance.setElemFloat(p0, p1, p2);
}

void setElemFloat_test_1200(int p0, float p1, int c0) {
    DataBufferDouble instance(c0);
    instance.setElemFloat(p0, p1);
}

void setElemDouble_test_1201(int p0, double p1, int c0) {
    DataBufferDouble instance(c0);
    instance.setElemDouble(p0, p1);
}

void setElemDouble_test_1202(int p0, int p1, double p2, int c0) {
    DataBufferDouble instance(c0);
    instance.setElemDouble(p0, p1, p2);
}

void getData_test_1203(int p0, int c0) {
    DataBufferDouble instance(c0);
    instance.getData(p0);
}

void getData_test_1204(int c0) {
    DataBufferDouble instance(c0);
    instance.getData();
}
```