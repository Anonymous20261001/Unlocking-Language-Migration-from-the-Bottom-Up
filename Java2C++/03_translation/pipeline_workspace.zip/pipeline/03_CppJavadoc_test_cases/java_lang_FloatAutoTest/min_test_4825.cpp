#include <cassert>
#include <string>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <sstream>
#include <iomanip>
#include <optional>
#include <stdexcept>

// Forward declarations
class MethodHandles_Lookup;

// Java Float equivalent class
class Float {
private:
    float value;

public:
    // Constructors
    Float() : value(0.0f) {}
    Float(float v) : value(v) {}
    Float(double v) : value(static_cast<float>(v)) {}
    Float(const std::string& s) : value(parseFloat(s)) {}
    Float(const char* s) : value(parseFloat(std::string(s))) {}

    // Static methods
    static float min(float a, float b) {
        return (a < b) ? a : b;
    }

    static float max(float a, float b) {
        return (a > b) ? a : b;
    }

    static bool isInfinite(float v) {
        return std::isinf(v);
    }

    static bool isFinite(float v) {
        return std::isfinite(v);
    }

    static bool isNaN(float v) {
        return std::isnan(v);
    }

    static int32_t floatToRawIntBits(float v) {
        int32_t bits;
        std::memcpy(&bits, &v, sizeof(bits));
        return bits;
    }

    static int32_t floatToIntBits(float v) {
        if (std::isnan(v)) {
            return 0x7fc00000; // canonical NaN
        }
        return floatToRawIntBits(v);
    }

    static float intBitsToFloat(int32_t bits) {
        float v;
        std::memcpy(&v, &bits, sizeof(v));
        return v;
    }

    static float float16ToFloat(uint16_t h) {
        // Convert half-precision to single-precision
        uint32_t sign = (h & 0x8000) << 16;
        uint32_t exponent = (h >> 10) & 0x1F;
        uint32_t mantissa = h & 0x3FF;

        uint32_t result;
        if (exponent == 0) {
            if (mantissa == 0) {
                result = sign; // +/- zero
            } else {
                // Subnormal half
                exponent = 127 - 15 + 1;
                while ((mantissa & 0x400) == 0) {
                    mantissa <<= 1;
                    exponent--;
                }
                mantissa &= 0x3FF;
                result = sign | (exponent << 23) | (mantissa << 13);
            }
        } else if (exponent == 0x1F) {
            if (mantissa == 0) {
                result = sign | 0x7F800000; // +/- infinity
            } else {
                result = sign | 0x7FC00000 | (mantissa << 13); // NaN
            }
        } else {
            result = sign | ((exponent - 15 + 127) << 23) | (mantissa << 13);
        }
        return intBitsToFloat(static_cast<int32_t>(result));
    }

    static uint16_t floatToFloat16(float v) {
        int32_t bits = floatToRawIntBits(v);
        uint32_t sign = (bits >> 16) & 0x8000;
        int32_t exponent = ((bits >> 23) & 0xFF) - 127 + 15;
        uint32_t mantissa = bits & 0x7FFFFF;

        if (exponent <= 0) {
            if (exponent < -10) {
                return static_cast<uint16_t>(sign); // too small, return zero
            }
            // Subnormal half
            mantissa |= 0x800000;
            int shift = 14 - exponent;
            uint32_t halfMantissa = mantissa >> shift;
            // Round to nearest even
            uint32_t remainder = mantissa & ((1 << shift) - 1);
            uint32_t halfway = 1 << (shift - 1);
            if (remainder > halfway || (remainder == halfway && (halfMantissa & 1))) {
                halfMantissa++;
            }
            return static_cast<uint16_t>(sign | halfMantissa);
        } else if (exponent >= 0x1F) {
            if (exponent > 0x1F) {
                return static_cast<uint16_t>(sign | 0x7C00); // infinity
            }
            // Check for NaN
            if (mantissa != 0) {
                return static_cast<uint16_t>(sign | 0x7E00 | (mantissa >> 13)); // NaN
            }
            return static_cast<uint16_t>(sign | 0x7C00); // infinity
        } else {
            // Normal number
            uint32_t halfMantissa = mantissa >> 13;
            uint32_t remainder = mantissa & 0x1FFF;
            uint32_t halfway = 0x1000;
            if (remainder > halfway || (remainder == halfway && (halfMantissa & 1))) {
                halfMantissa++;
                if (halfMantissa == 0x400) {
                    halfMantissa = 0;
                    exponent++;
                    if (exponent >= 0x1F) {
                        return static_cast<uint16_t>(sign | 0x7C00); // overflow to infinity
                    }
                }
            }
            return static_cast<uint16_t>(sign | (exponent << 10) | halfMantissa);
        }
    }

    static int compare(float a, float b) {
        if (std::isnan(a) && std::isnan(b)) return 0;
        if (std::isnan(a)) return 1;
        if (std::isnan(b)) return -1;
        if (a < b) return -1;
        if (a > b) return 1;
        // Handle signed zero
        if (a == b) {
            if (a == 0.0f) {
                int32_t bitsA = floatToRawIntBits(a);
                int32_t bitsB = floatToRawIntBits(b);
                if (bitsA == bitsB) return 0;
                return (bitsA < bitsB) ? -1 : 1;
            }
            return 0;
        }
        return 0;
    }

    static Float valueOf(float v) {
        return Float(v);
    }

    static Float valueOf(const std::string& s) {
        return Float(s);
    }

    static std::string toHexString(float v) {
        if (std::isnan(v)) return "NaN";
        if (std::isinf(v)) return (v > 0) ? "Infinity" : "-Infinity";
        if (v == 0.0f) {
            return (std::signbit(v)) ? "-0x0.0p0" : "0x0.0p0";
        }

        std::ostringstream oss;
        oss << std::hex << std::showbase << std::nouppercase;
        if (v < 0) {
            oss << "-";
            v = -v;
        }
        oss << "0x";
        int exponent;
        float mantissa = std::frexp(v, &exponent);
        // Adjust to get mantissa in [1, 2)
        mantissa *= 2.0f;
        exponent -= 1;
        // Convert mantissa to hex
        uint32_t bits = floatToRawIntBits(mantissa);
        uint32_t mantissaBits = bits & 0x7FFFFF;
        int expField = (bits >> 23) & 0xFF;
        if (expField == 0) {
            // Subnormal
            oss << "0.";
            // Handle subnormal mantissa
            uint32_t m = mantissaBits;
            int shift = 23;
            while ((m & 0x800000) == 0 && shift > 0) {
                m <<= 1;
                shift--;
            }
            m &= 0xFFFFFF;
            oss << std::hex << m;
            oss << "p" << (exponent - shift);
        } else {
            // Normal
            oss << "1.";
            uint32_t m = mantissaBits;
            oss << std::hex << m;
            oss << "p" << exponent;
        }
        return oss.str();
    }

    static float parseFloat(const std::string& s) {
        try {
            size_t pos;
            float result = std::stof(s, &pos);
            if (pos != s.length()) {
                throw std::invalid_argument("Invalid float string");
            }
            return result;
        } catch (const std::exception&) {
            // Handle special values
            if (s == "NaN") return std::nanf("");
            if (s == "Infinity" || s == "+Infinity") return INFINITY;
            if (s == "-Infinity") return -INFINITY;
            throw;
        }
    }

    static float sum(float a, float b) {
        return a + b;
    }

    // Instance methods
    bool isInfinite() const {
        return std::isinf(value);
    }

    bool isNaN() const {
        return std::isnan(value);
    }

    int compareTo(const Float& other) const {
        return compare(value, other.value);
    }

    int8_t byteValue() const {
        return static_cast<int8_t>(value);
    }

    int16_t shortValue() const {
        return static_cast<int16_t>(value);
    }

    int32_t intValue() const {
        return static_cast<int32_t>(value);
    }

    int64_t longValue() const {
        return static_cast<int64_t>(value);
    }

    float floatValue() const {
        return value;
    }

    double doubleValue() const {
        return static_cast<double>(value);
    }

    // Methods for constable support
    Float resolveConstantDesc(MethodHandles_Lookup& lookup) {
        return *this;
    }

    std::optional<Float> describeConstable() {
        return *this;
    }

    // Operators for convenience
    bool operator==(const Float& other) const { return value == other.value; }
    bool operator!=(const Float& other) const { return value != other.value; }
    bool operator<(const Float& other) const { return value < other.value; }
    bool operator>(const Float& other) const { return value > other.value; }
    bool operator<=(const Float& other) const { return value <= other.value; }
    bool operator>=(const Float& other) const { return value >= other.value; }

    // Conversion operators
    operator float() const { return value; }
    operator double() const { return static_cast<double>(value); }
    operator int() const { return static_cast<int>(value); }
    operator long() const { return static_cast<long>(value); }
    operator short() const { return static_cast<short>(value); }
    operator char() const { return static_cast<char>(value); }
};

// MethodHandles.Lookup equivalent (minimal)
class MethodHandles_Lookup {
public:
    MethodHandles_Lookup() = default;
};

// Test functions

void min_test_4825() {
float float2 = Float::min(static_cast<float>(10L), 0.0f);
    assert(float2 == 0.0f);
}
