#include <cassert>
#include <string>

class Toolkit {
public:
    static Toolkit& getDefaultToolkit() {
        static Toolkit instance;
        return instance;
    }

    static std::string getProperty(const std::string& key, const std::string& defaultValue) {
        // Mimic Java Toolkit.getProperty: if the property is not found, return defaultValue.
        (void)key;
        return defaultValue;
    }

private:
    Toolkit() = default;
    ~Toolkit() = default;
    Toolkit(const Toolkit&) = delete;
    Toolkit& operator=(const Toolkit&) = delete;
};

void getProperty_test_12928() {
std::string str2 = Toolkit::getProperty("", "");
    assert(str2 == "");
}
