#include <cassert>
#include <cstddef>

class SystemTray {
public:
    static SystemTray& getSystemTray() {
        static SystemTray instance;
        return instance;
    }

    static bool isSupported() {
        return true;
    }

private:
    SystemTray() = default;
    SystemTray(const SystemTray&) = delete;
    SystemTray& operator=(const SystemTray&) = delete;
};

void isSupported_test_12444() {
bool boolean0 = SystemTray::isSupported();
    assert(boolean0 == false);
}
