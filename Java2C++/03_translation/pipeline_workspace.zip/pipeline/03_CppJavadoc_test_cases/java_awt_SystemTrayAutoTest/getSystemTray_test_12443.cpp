#include <cassert>
#include <cstddef>

class SystemTray {
public:
    static SystemTray& getSystemTray() {
        static SystemTray instance;
        return instance;
    }

    static bool isSupported() {
        return true;
    }

private:
    SystemTray() = default;
    SystemTray(const SystemTray&) = delete;
    SystemTray& operator=(const SystemTray&) = delete;
};

void getSystemTray_test_12443() {
try {
        SystemTray& systemTray0 = SystemTray::getSystemTray();
    } catch (...) {
        // Expected exception.
    }
}
