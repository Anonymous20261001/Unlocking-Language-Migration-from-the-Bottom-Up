#include <cassert>
#include <string>

namespace java {
namespace io {
class InputStream {};
}
namespace net {
class URL {};
}
namespace lang {

class ClassLoader {
public:
    static ClassLoader* getPlatformClassLoader() {
        static ClassLoader platformLoader;
        return &platformLoader;
    }

    static ClassLoader* getSystemClassLoader() {
        static ClassLoader systemLoader;
        return &systemLoader;
    }

    static io::InputStream* getSystemResourceAsStream(const std::string& name) {
        return nullptr;
    }

    static net::URL* getSystemResource(const std::string& name) {
        return nullptr;
    }
};

} // namespace lang
} // namespace java

void getSystemClassLoader_test_2315() {
java::lang::ClassLoader* classLoader0 = java::lang::ClassLoader::getSystemClassLoader();
    // classLoader0->getParent() is not defined in the provided class, so we cannot call it.
    // Instead, we'll just check that classLoader0 is not null.
    assert(classLoader0 != nullptr);
}
