#include <cassert>
#include <string>

namespace java {
namespace io {
class InputStream {};
}
namespace net {
class URL {};
}
namespace lang {

class ClassLoader {
public:
    static ClassLoader* getPlatformClassLoader() {
        static ClassLoader platformLoader;
        return &platformLoader;
    }

    static ClassLoader* getSystemClassLoader() {
        static ClassLoader systemLoader;
        return &systemLoader;
    }

    static io::InputStream* getSystemResourceAsStream(const std::string& name) {
        return nullptr;
    }

    static net::URL* getSystemResource(const std::string& name) {
        return nullptr;
    }
};

} // namespace lang
} // namespace java

void getPlatformClassLoader_test_2314() {
java::lang::ClassLoader* classLoader0 = java::lang::ClassLoader::getPlatformClassLoader();
    // removed: java::lang::Class<?> wildcardClass1 = classLoader0.getClass();
    // removed: assert(classLoader0 != nullptr);
    // removed: assert(wildcardClass1 != nullptr);
}
