#include <cassert>
#include <string>

namespace java {
namespace io {
class InputStream {};
}
namespace net {
class URL {};
}
namespace lang {

class ClassLoader {
public:
    static ClassLoader* getPlatformClassLoader() {
        static ClassLoader platformLoader;
        return &platformLoader;
    }

    static ClassLoader* getSystemClassLoader() {
        static ClassLoader systemLoader;
        return &systemLoader;
    }

    static io::InputStream* getSystemResourceAsStream(const std::string& name) {
        return nullptr;
    }

    static net::URL* getSystemResource(const std::string& name) {
        return nullptr;
    }
};

} // namespace lang
} // namespace java

void getSystemResource_test_2317() {
java::net::URL* uRL1 = java::lang::ClassLoader::getSystemResource("hi!");
    assert(uRL1 == nullptr);
}
