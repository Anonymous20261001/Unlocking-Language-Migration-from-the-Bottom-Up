#include <cassert>
#include <cmath>

class Point2D {
public:
    static double distanceSq(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return dx * dx + dy * dy;
    }

    static double distance(double x1, double y1, double x2, double y2) {
        return std::sqrt(distanceSq(x1, y1, x2, y2));
    }
};

void distance_test_9957() {
double double4 = Point2D::distance((double) 'a', (double) (short) 1, (double) 10, 1.0);
    assert(double4 == 87.0);
}
