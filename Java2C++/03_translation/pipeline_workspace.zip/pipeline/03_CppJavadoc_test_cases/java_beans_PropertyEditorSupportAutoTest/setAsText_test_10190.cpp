#include <cassert>
#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <stdexcept>

namespace java {
namespace awt {
class Graphics {
public:
    virtual ~Graphics() = default;
};

class Rectangle {
public:
    int x = 0;
    int y = 0;
    int width = 0;
    int height = 0;
    Rectangle() = default;
    Rectangle(int x, int y, int width, int height) : x(x), y(y), width(width), height(height) {}
};
} // namespace awt

namespace beans {
class PropertyChangeListener {
public:
    virtual ~PropertyChangeListener() = default;
    virtual void propertyChange() = 0;
};

class PropertyEditorSupport {
private:
    std::shared_ptr<void> source;
    std::shared_ptr<void> value;
    std::vector<std::shared_ptr<PropertyChangeListener>> listeners;

public:
    PropertyEditorSupport() = default;
    explicit PropertyEditorSupport(std::shared_ptr<void> src) : source(src) {}

    void firePropertyChange() {
        for (auto& listener : listeners) {
            if (listener) {
                listener->propertyChange();
            }
        }
    }

    void addPropertyChangeListener(std::shared_ptr<PropertyChangeListener> listener) {
        if (listener) {
            listeners.push_back(listener);
        }
    }

    void removePropertyChangeListener(std::shared_ptr<PropertyChangeListener> listener) {
        listeners.erase(
            std::remove_if(listeners.begin(), listeners.end(),
                [&listener](const std::shared_ptr<PropertyChangeListener>& l) {
                    return l == listener;
                }),
            listeners.end());
    }

    void setSource(std::shared_ptr<void> src) {
        source = src;
    }

    std::shared_ptr<void> getSource() {
        return source;
    }

    bool isPaintable() {
        return false;
    }

    void paintValue(std::shared_ptr<java::awt::Graphics> gfx, std::shared_ptr<java::awt::Rectangle> box) {
        // Default implementation does nothing
    }

    std::string getJavaInitializationString() {
        return "null";
    }

    std::string getAsText() {
        if (value) {
            // In real Java, this would call toString() on the value
            // For simplicity, return a placeholder
            return "value";
        }
        return "null";
    }

    void setAsText(const std::string& text) {
        // Default implementation does nothing
    }

    std::vector<std::string> getTags() {
        return {};
    }

    std::shared_ptr<void> getCustomEditor() {
        return nullptr;
    }

    bool supportsCustomEditor() {
        return false;
    }

    std::shared_ptr<void> getValue() {
        return value;
    }

    void setValue(std::shared_ptr<void> val) {
        value = val;
    }
};
} // namespace beans
} // namespace java

// Test functions

void setAsText_test_10190() {
auto propertyEditorSupport0 = std::make_shared<java::beans::PropertyEditorSupport>();
auto obj1 = propertyEditorSupport0->getValue();
auto obj2 = propertyEditorSupport0->getValue();
try {
    propertyEditorSupport0->setAsText("hi!");
} catch (...) {
}
assert(obj1 == nullptr);
assert(obj2 == nullptr);
}
