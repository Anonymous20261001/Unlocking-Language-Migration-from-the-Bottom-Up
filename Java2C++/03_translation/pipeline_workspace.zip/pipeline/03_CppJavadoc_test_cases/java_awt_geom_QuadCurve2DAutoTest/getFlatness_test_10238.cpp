#include <cassert>
#include <cmath>

class QuadCurve2D {
public:
    double x1, y1, ctrlx, ctrly, x2, y2;

    QuadCurve2D() : x1(0), y1(0), ctrlx(0), ctrly(0), x2(0), y2(0) {}

    QuadCurve2D(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        : x1(x1), y1(y1), ctrlx(ctrlx), ctrly(ctrly), x2(x2), y2(y2) {}

    double getX1() const { return x1; }
    double getY1() const { return y1; }
    double getCtrlX() const { return ctrlx; }
    double getCtrlY() const { return ctrly; }
    double getX2() const { return x2; }
    double getY2() const { return y2; }

    void setCurve(double x1, double y1, double ctrlx, double ctrly, double x2, double y2) {
        this->x1 = x1;
        this->y1 = y1;
        this->ctrlx = ctrlx;
        this->ctrly = ctrly;
        this->x2 = x2;
        this->y2 = y2;
    }

    static double ptSegDistSq(double x1, double y1, double x2, double y2, double px, double py) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double lenSq = dx * dx + dy * dy;

        if (lenSq == 0.0) {
            dx = px - x1;
            dy = py - y1;
            return dx * dx + dy * dy;
        }

        double t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
        if (t < 0.0) t = 0.0;
        else if (t > 1.0) t = 1.0;

        double projX = x1 + t * dx;
        double projY = y1 + t * dy;
        dx = px - projX;
        dy = py - projY;
        return dx * dx + dy * dy;
    }

    static double getFlatnessSq(double x1, double y1, double ctrlx, double ctrly, double x2, double y2) {
        return ptSegDistSq(x1, y1, x2, y2, ctrlx, ctrly);
    }

    static double getFlatnessSq(double* coords, int offset) {
        return getFlatnessSq(coords[offset], coords[offset + 1],
                             coords[offset + 2], coords[offset + 3],
                             coords[offset + 4], coords[offset + 5]);
    }

    static double getFlatness(double x1, double y1, double ctrlx, double ctrly, double x2, double y2) {
        return std::sqrt(getFlatnessSq(x1, y1, ctrlx, ctrly, x2, y2));
    }

    static double getFlatness(double* coords, int offset) {
        return std::sqrt(getFlatnessSq(coords, offset));
    }

    static void subdivide(double* src, int srcOff, double* left, int leftOff, double* right, int rightOff) {
        double x1 = src[srcOff];
        double y1 = src[srcOff + 1];
        double ctrlx = src[srcOff + 2];
        double ctrly = src[srcOff + 3];
        double x2 = src[srcOff + 4];
        double y2 = src[srcOff + 5];

        double midx = (x1 + 2.0 * ctrlx + x2) / 4.0;
        double midy = (y1 + 2.0 * ctrly + y2) / 4.0;

        left[leftOff] = x1;
        left[leftOff + 1] = y1;
        left[leftOff + 2] = (x1 + ctrlx) / 2.0;
        left[leftOff + 3] = (y1 + ctrly) / 2.0;
        left[leftOff + 4] = midx;
        left[leftOff + 5] = midy;

        right[rightOff] = midx;
        right[rightOff + 1] = midy;
        right[rightOff + 2] = (ctrlx + x2) / 2.0;
        right[rightOff + 3] = (ctrly + y2) / 2.0;
        right[rightOff + 4] = x2;
        right[rightOff + 5] = y2;
    }

    static void subdivide(const QuadCurve2D& src, QuadCurve2D& left, QuadCurve2D& right) {
        double x1 = src.x1;
        double y1 = src.y1;
        double ctrlx = src.ctrlx;
        double ctrly = src.ctrly;
        double x2 = src.x2;
        double y2 = src.y2;

        double midx = (x1 + 2.0 * ctrlx + x2) / 4.0;
        double midy = (y1 + 2.0 * ctrly + y2) / 4.0;

        left.setCurve(x1, y1, (x1 + ctrlx) / 2.0, (y1 + ctrly) / 2.0, midx, midy);
        right.setCurve(midx, midy, (ctrlx + x2) / 2.0, (ctrly + y2) / 2.0, x2, y2);
    }

    static int solveQuadratic(double* eqn, double* res) {
        double a = eqn[0];
        double b = eqn[1];
        double c = eqn[2];

        if (a == 0.0) {
            if (b == 0.0) {
                return -1;
            }
            res[0] = -c / b;
            return 1;
        }

        double discrim = b * b - 4.0 * a * c;
        if (discrim <= 0.0) {
            if (discrim == 0.0) {
                res[0] = -b / (2.0 * a);
                return 1;
            }
            return 0;
        }

        discrim = std::sqrt(discrim);
        res[0] = (-b + discrim) / (2.0 * a);
        res[1] = (-b - discrim) / (2.0 * a);
        return 2;
    }

    static int solveQuadratic(double* eqn) {
        return solveQuadratic(eqn, eqn);
    }
};

void getFlatness_test_10238() {
double doubleArray1[1] = {0.0};
    try {
        double double3 = QuadCurve2D::getFlatness(doubleArray1, (int)(signed char)10);
    } catch (...) {
    }
    // assertNotNull removed
    // assertArrayEquals removed
}
