#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <limits>
#include <string>
#include <sstream>
#include <stdexcept>

using String = std::string;

struct MethodHandles {
    struct Lookup {};
};

template <typename T>
struct Optional {
    Optional() : has_value(false), value() {}
    Optional(const T& v) : has_value(true), value(v) {}
    bool has_value;
    T value;
};

class Double {
public:
    Double(double v) : value(v) {}

    bool isInfinite() const { return Double::isInfinite(value); }
    bool isNaN() const { return Double::isNaN(value); }

    int compareTo(const Double& other) const { return Double::compare(value, other.value); }

    int8_t byteValue() const { return static_cast<int8_t>(Double::doubleToInt(value) & 0xFF); }
    int16_t shortValue() const { return static_cast<int16_t>(Double::doubleToInt(value) & 0xFFFF); }
    int intValue() const { return Double::doubleToInt(value); }
    long long longValue() const { return Double::doubleToLong(value); }
    float floatValue() const { return static_cast<float>(value); }
    double doubleValue() const { return value; }

    Double resolveConstantDesc(MethodHandles::Lookup) const { return *this; }
    Optional<Double> describeConstable() const { return Optional<Double>(*this); }

    static double min(double a, double b) {
        if (std::isnan(a) || std::isnan(b)) return std::numeric_limits<double>::quiet_NaN();
        if (a == 0.0 && b == 0.0) {
            return (std::signbit(a) || std::signbit(b)) ? -0.0 : 0.0;
        }
        return a < b ? a : b;
    }

    static double max(double a, double b) {
        if (std::isnan(a) || std::isnan(b)) return std::numeric_limits<double>::quiet_NaN();
        if (a == 0.0 && b == 0.0) {
            return (std::signbit(a) && std::signbit(b)) ? -0.0 : 0.0;
        }
        return a > b ? a : b;
    }

    static bool isInfinite(double v) { return std::isinf(v) != 0; }
    static bool isFinite(double v) { return std::isfinite(v) != 0; }

    static long long doubleToRawLongBits(double v) {
        uint64_t bits;
        std::memcpy(&bits, &v, sizeof(v));
        return static_cast<long long>(bits);
    }

    static long long doubleToLongBits(double v) {
        uint64_t raw = static_cast<uint64_t>(doubleToRawLongBits(v));
        uint64_t exponent = (raw >> 52) & 0x7FFULL;
        uint64_t mantissa = raw & 0xFFFFFFFFFFFFFULL;
        if (exponent == 0x7FFULL && mantissa != 0) {
            return static_cast<long long>(0x7FF8000000000000ULL);
        }
        return static_cast<long long>(raw);
    }

    static double longBitsToDouble(long long bits) {
        uint64_t raw = static_cast<uint64_t>(bits);
        uint64_t exponent = (raw >> 52) & 0x7FFULL;
        uint64_t mantissa = raw & 0xFFFFFFFFFFFFFULL;
        if (exponent == 0x7FFULL && mantissa != 0) {
            return std::numeric_limits<double>::quiet_NaN();
        }
        double result;
        std::memcpy(&result, &raw, sizeof(result));
        return result;
    }

    static int compare(double d1, double d2) {
        if (std::isnan(d1)) return std::isnan(d2) ? 0 : 1;
        if (std::isnan(d2)) return -1;
        if (d1 == d2) {
            if (d1 == 0.0) {
                if (std::signbit(d1) && !std::signbit(d2)) return -1;
                if (!std::signbit(d1) && std::signbit(d2)) return 1;
            }
            return 0;
        }
        return d1 < d2 ? -1 : 1;
    }

    static Double valueOf(const String& s) { return Double(parseDouble(s)); }
    static Double valueOf(double v) { return Double(v); }

    static String toHexString(double d) {
        if (std::isnan(d)) return "NaN";
        if (std::isinf(d)) return std::signbit(d) ? "-Infinity" : "Infinity";
        if (d == 0.0) return std::signbit(d) ? "-0x0.0p0" : "0x0.0p0";

        std::ostringstream oss;
        oss << std::hexfloat << d;
        String s = oss.str();

        size_t ppos = s.find('p');
        if (ppos != String::npos && ppos + 1 < s.size() && s[ppos + 1] == '+') {
            s.erase(ppos + 1, 1);
        }

        if (s.find('.') == String::npos) {
            size_t xpos = s.find('x');
            if (xpos != String::npos && xpos + 2 < s.size()) {
                if (s[xpos + 2] == 'p' || s[xpos + 2] == 'P') {
                    if (ppos != String::npos) {
                        s.insert(ppos, ".0");
                    }
                }
            }
        }

        return s;
    }

    static bool isNaN(double v) { return std::isnan(v) != 0; }
    static double sum(double a, double b) { return a + b; }

    static double parseDouble(const String& s) {
        const char* start = s.c_str();
        char* end = nullptr;
        double value = std::strtod(start, &end);
        if (end == start) {
            throw std::invalid_argument("Unable to parse double: " + s);
        }
        return value;
    }

private:
    double value;

    static int doubleToInt(double v) {
        if (std::isnan(v)) return 0;
        if (v >= static_cast<double>(std::numeric_limits<int>::max())) return std::numeric_limits<int>::max();
        if (v <= static_cast<double>(std::numeric_limits<int>::min())) return std::numeric_limits<int>::min();
        return static_cast<int>(v);
    }

    static long long doubleToLong(double v) {
        if (std::isnan(v)) return 0;
        if (v >= static_cast<double>(std::numeric_limits<long long>::max())) return std::numeric_limits<long long>::max();
        if (v <= static_cast<double>(std::numeric_limits<long long>::min())) return std::numeric_limits<long long>::min();
        return static_cast<long long>(v);
    }
};

void parseDouble_test_4248() {
double double1 = Double::parseDouble("0.0");
    assert(double1 == 0.0);
}
