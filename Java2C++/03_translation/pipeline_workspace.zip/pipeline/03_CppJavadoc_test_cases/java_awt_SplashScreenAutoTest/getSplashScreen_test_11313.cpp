#include <cassert>
#include <cstddef>

class SplashScreen {
public:
    static SplashScreen* getSplashScreen() {
        return nullptr;
    }

private:
    SplashScreen() = default;
};


void getSplashScreen_test_11313() {
try {
    SplashScreen* splashScreen0 = SplashScreen::getSplashScreen();
} catch (...) {
}
}
