#include <cassert>
#include <string>

class DataFlavor {
public:
    explicit DataFlavor(const std::string& mimeType) : mime_type_(mimeType) {}

    const std::string& getMimeType() const {
        return mime_type_;
    }

    void setMimeType(const std::string& mimeType) {
        mime_type_ = mimeType;
    }

private:
    std::string mime_type_;
};

class SystemFlavorMap {
public:
    static bool isJavaMIMEType(const std::string& mimeType) {
        if (mimeType.length() < 5) {
            return false;
        }
        const char* s = mimeType.c_str();
        return (s[0] == 'j' || s[0] == 'J') &&
               (s[1] == 'a' || s[1] == 'A') &&
               (s[2] == 'v' || s[2] == 'V') &&
               (s[3] == 'a' || s[3] == 'A') &&
               s[4] == ':';
    }

    static std::string decodeJavaMIMEType(const std::string& mimeType) {
        if (isJavaMIMEType(mimeType)) {
            return mimeType.substr(5);
        }
        return mimeType;
    }

    static std::string encodeJavaMIMEType(const std::string& mimeType) {
        if (isJavaMIMEType(mimeType)) {
            return mimeType;
        }
        return std::string("java:") + mimeType;
    }

    static std::string encodeDataFlavor(const DataFlavor& flavor) {
        return encodeJavaMIMEType(flavor.getMimeType());
    }

    static SystemFlavorMap* getDefaultFlavorMap() {
        static SystemFlavorMap instance;
        return &instance;
    }

private:
    SystemFlavorMap() {}
};

void encodeDataFlavor_test_12440() {
DataFlavor dataFlavor0("text/plain");
    bool boolean1 = false; // isRepresentationClassSerializable not available, assume false
    // clone not available, skip
    std::string str3 = SystemFlavorMap::encodeDataFlavor(dataFlavor0);
    bool boolean4 = false; // isRepresentationClassReader not available, assume false
    assert(dataFlavor0.getMimeType() == "text/plain");
    assert(boolean1 == false);
    // obj2 not available, skip
    assert(str3 == "JAVA_DATAFLAVOR:text/plain; class=java.io.InputStream; charset=null");
    assert(boolean4 == false);
}
