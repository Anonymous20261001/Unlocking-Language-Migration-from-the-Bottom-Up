#include <cassert>
#include <stdexcept>

namespace java {
namespace awt {

class Taskbar {
public:
    static bool isTaskbarSupported() {
#if defined(_WIN32) || defined(__APPLE__)
        return true;
#else
        return false;
#endif
    }

    static Taskbar& getTaskbar() {
        if (!isTaskbarSupported()) {
            throw std::runtime_error("Taskbar is not supported on this platform");
        }
        static Taskbar instance;
        return instance;
    }

    ~Taskbar() = default;

private:
    Taskbar() = default;
    Taskbar(const Taskbar&) = delete;
    Taskbar& operator=(const Taskbar&) = delete;
};

} // namespace awt
} // namespace java

using java::awt::Taskbar;

void isTaskbarSupported_test_12519() {
bool boolean0 = Taskbar::isTaskbarSupported();
    assert(boolean0 == false);
}
