#include <cassert>
class ColorModel {
public:
    static ColorModel& getRGBdefault() {
        static ColorModel instance;
        return instance;
    }
private:
    ColorModel() {}
};

void getRGBdefault_test_2502() {
ColorModel& colorModel0 = ColorModel::getRGBdefault();
// removed (null check not needed in C++)
// removed (null check not needed in C++)
}
