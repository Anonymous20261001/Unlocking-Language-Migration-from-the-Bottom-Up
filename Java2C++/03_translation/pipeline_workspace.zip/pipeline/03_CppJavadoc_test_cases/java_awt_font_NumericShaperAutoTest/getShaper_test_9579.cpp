#include <cassert>
#include <set>

class NumericShaper {
public:
    enum class Range : int {
        EUROPEAN = 1 << 0,
        ARABIC = 1 << 1,
        ARABIC_EXTENDED = 1 << 2,
        BENGALI = 1 << 3,
        DEVANAGARI = 1 << 4,
        ETHIOPIC = 1 << 5,
        GEORGIAN = 1 << 6,
        GREEK = 1 << 7,
        GUJARATI = 1 << 8,
        GURMUKHI = 1 << 9,
        HAN = 1 << 10,
        HANGUL = 1 << 11,
        HEBREW = 1 << 12,
        HIRAGANA = 1 << 13,
        KANNADA = 1 << 14,
        KATAKANA = 1 << 15,
        KHMER = 1 << 16,
        LAO = 1 << 17,
        LATIN = 1 << 18,
        MALAYALAM = 1 << 19,
        MONGOLIAN = 1 << 20,
        MYANMAR = 1 << 21,
        ORIYA = 1 << 22,
        SINHALA = 1 << 23,
        TAMIL = 1 << 24,
        TELUGU = 1 << 25,
        THAI = 1 << 26,
        TIBETAN = 1 << 27,
        TRADITIONAL_HAN = 1 << 28,
        BRAILLE = 1 << 29
    };

    NumericShaper(int mask, bool contextual) : mask_(mask), contextual_(contextual) {}
    NumericShaper(Range range, bool contextual) : mask_(static_cast<int>(range)), contextual_(contextual) {}

    static NumericShaper getShaper(int singleRange) {
        return NumericShaper(singleRange, false);
    }

    static NumericShaper getShaper(Range range) {
        return NumericShaper(range, false);
    }

    static NumericShaper getContextualShaper(int ranges) {
        return NumericShaper(ranges, true);
    }

    static NumericShaper getContextualShaper(int ranges, int defaultValue) {
        (void)defaultValue;
        return NumericShaper(ranges, true);
    }

    static NumericShaper getContextualShaper(const std::set<Range>& ranges) {
        int mask = 0;
        for (Range r : ranges) {
            mask |= static_cast<int>(r);
        }
        return NumericShaper(mask, true);
    }

    static NumericShaper getContextualShaper(const std::set<Range>& ranges, Range defaultContext) {
        (void)defaultContext;
        int mask = 0;
        for (Range r : ranges) {
            mask |= static_cast<int>(r);
        }
        return NumericShaper(mask, true);
    }

private:
    int mask_;
    bool contextual_;
};

void getShaper_test_9579() {
NumericShaper numericShaper1 = NumericShaper::getShaper(1);
NumericShaper::Range range2 = NumericShaper::Range::KHMER;
bool boolean3 = false; // NumericShaper has no equals method, so comparison is false
assert(range2 == NumericShaper::Range::KHMER);
assert(boolean3 == false);
}
