#include <cassert>
#include <cstddef>

class PointerInfo {
public:
    PointerInfo() = default;
};

class MouseInfo {
public:
    static int getNumberOfButtons();
    static PointerInfo getPointerInfo();
};

int MouseInfo::getNumberOfButtons() {
    return 3;
}

PointerInfo MouseInfo::getPointerInfo() {
    return PointerInfo();
}


void getPointerInfo_test_9026() {
try {
    PointerInfo pointerInfo0 = MouseInfo::getPointerInfo();
} catch (...) {
    // Expected exception.
}
}
