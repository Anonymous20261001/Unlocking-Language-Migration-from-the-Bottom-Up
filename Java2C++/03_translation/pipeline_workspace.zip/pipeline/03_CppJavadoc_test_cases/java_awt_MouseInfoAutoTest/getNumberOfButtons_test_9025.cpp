#include <cassert>
#include <cstddef>

class PointerInfo {
public:
    PointerInfo() = default;
};

class MouseInfo {
public:
    static int getNumberOfButtons();
    static PointerInfo getPointerInfo();
};

int MouseInfo::getNumberOfButtons() {
    return 3;
}

PointerInfo MouseInfo::getPointerInfo() {
    return PointerInfo();
}

void getNumberOfButtons_test_9025() {
try {
        int int0 = MouseInfo::getNumberOfButtons();
    } catch (...) {
    }
}
