#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>

namespace java {
namespace lang {

class Math {
public:
    // abs methods
    static float abs(float a) { return std::fabs(a); }
    static long abs(long a) { return (a < 0) ? -a : a; }
    static int abs(int a) { return (a < 0) ? -a : a; }
    static double abs(double a) { return std::fabs(a); }

    // trigonometric
    static double sin(double a) { return std::sin(a); }
    static double cos(double a) { return std::cos(a); }
    static double tan(double a) { return std::tan(a); }
    static double atan2(double y, double x) { return std::atan2(y, x); }
    static double asin(double a) { return std::asin(a); }
    static double acos(double a) { return std::acos(a); }
    static double atan(double a) { return std::atan(a); }

    // exponential/logarithmic
    static double sqrt(double a) { return std::sqrt(a); }
    static double log(double a) { return std::log(a); }
    static double log10(double a) { return std::log10(a); }
    static double pow(double a, double b) { return std::pow(a, b); }
    static double exp(double a) { return std::exp(a); }
    static double expm1(double a) { return std::expm1(a); }
    static double log1p(double a) { return std::log1p(a); }
    static double cbrt(double a) { return std::cbrt(a); }

    // min/max
    static int min(int a, int b) { return (a < b) ? a : b; }
    static long min(long a, long b) { return (a < b) ? a : b; }
    static double min(double a, double b) { return (a < b) ? a : b; }
    static float min(float a, float b) { return (a < b) ? a : b; }
    static long max(long a, long b) { return (a > b) ? a : b; }
    static int max(int a, int b) { return (a > b) ? a : b; }
    static double max(double a, double b) { return (a > b) ? a : b; }
    static float max(float a, float b) { return (a > b) ? a : b; }

    // rounding
    static double floor(double a) { return std::floor(a); }
    static double ceil(double a) { return std::ceil(a); }
    static double rint(double a) { return std::rint(a); }
    static long round(double a) { return std::llround(a); }
    static int round(float a) { return std::lround(a); }

    // hyperbolic
    static double tanh(double a) { return std::tanh(a); }
    static double sinh(double a) { return std::sinh(a); }
    static double cosh(double a) { return std::cosh(a); }

    // exact arithmetic
    static int addExact(int x, int y) {
        if ((y > 0 && x > std::numeric_limits<int>::max() - y) ||
            (y < 0 && x < std::numeric_limits<int>::min() - y)) {
            throw std::overflow_error("integer overflow");
        }
        return x + y;
    }
    static long addExact(long x, long y) {
        if ((y > 0 && x > std::numeric_limits<long>::max() - y) ||
            (y < 0 && x < std::numeric_limits<long>::min() - y)) {
            throw std::overflow_error("long overflow");
        }
        return x + y;
    }
    static int decrementExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return a - 1;
    }
    static long decrementExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return a - 1;
    }
    static long incrementExact(long a) {
        if (a == std::numeric_limits<long>::max()) throw std::overflow_error("long overflow");
        return a + 1;
    }
    static int incrementExact(int a) {
        if (a == std::numeric_limits<int>::max()) throw std::overflow_error("integer overflow");
        return a + 1;
    }
    static long multiplyExact(long x, long y) {
        if (x == 0 || y == 0) return 0;
        if (x == -1 && y == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        if (y == -1 && x == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        long r = x * y;
        if (r / y != x) throw std::overflow_error("long overflow");
        return r;
    }
    static int multiplyExact(int x, int y) {
        long long result = static_cast<long long>(x) * y;
        if (result > std::numeric_limits<int>::max() || result < std::numeric_limits<int>::min()) {
            throw std::overflow_error("integer overflow");
        }
        return static_cast<int>(result);
    }
    static long multiplyExact(long x, int y) {
        return multiplyExact(x, static_cast<long>(y));
    }
    static long multiplyHigh(long x, long y) {
        __int128 result = static_cast<__int128>(x) * y;
        return static_cast<long>(result >> 64);
    }
    static long unsignedMultiplyHigh(long x, long y) {
        unsigned __int128 result = static_cast<unsigned __int128>(static_cast<uint64_t>(x)) * static_cast<uint64_t>(y);
        return static_cast<long>(result >> 64);
    }
    static long negateExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return -a;
    }
    static int negateExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return -a;
    }
    static int subtractExact(int x, int y) {
        if ((y > 0 && x < std::numeric_limits<int>::min() + y) ||
            (y < 0 && x > std::numeric_limits<int>::max() + y)) {
            throw std::overflow_error("integer overflow");
        }
        return x - y;
    }
    static long subtractExact(long x, long y) {
        if ((y > 0 && x < std::numeric_limits<long>::min() + y) ||
            (y < 0 && x > std::numeric_limits<long>::max() + y)) {
            throw std::overflow_error("long overflow");
        }
        return x - y;
    }

    // fma
    static double fma(double a, double b, double c) { return std::fma(a, b, c); }
    static float fma(float a, float b, float c) { return std::fma(a, b, c); }

    // copySign
    static double copySign(double magnitude, double sign) { return std::copysign(magnitude, sign); }
    static float copySign(float magnitude, float sign) { return std::copysign(magnitude, sign); }

    // signum
    static float signum(float a) { return (a > 0) ? 1.0f : (a < 0) ? -1.0f : a; }
    static double signum(double a) { return (a > 0) ? 1.0 : (a < 0) ? -1.0 : a; }

    // clamp
    static float clamp(float value, float min, float max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static long clamp(long value, int min, int max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static double clamp(double value, double min, double max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static long clamp(long value, long min, long max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    // scalb
    static float scalb(float d, int scaleFactor) { return std::scalbn(d, scaleFactor); }
    static double scalb(double d, int scaleFactor) { return std::scalbn(d, scaleFactor); }

    // getExponent
    static int getExponent(float f) { return std::ilogb(f); }
    static int getExponent(double d) { return std::ilogb(d); }

    // floorMod
    static long floorMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r += y;
        return r;
    }
    static int floorMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r += y;
        return r;
    }
    static long floorMod(long x, int y) {
        return floorMod(x, static_cast<long>(y));
    }

    // IEEEremainder
    static double IEEEremainder(double f1, double f2) { return std::remainder(f1, f2); }

    // floorDiv
    static long floorDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0))) q--;
        return q;
    }
    static long floorDiv(long x, int y) {
        return floorDiv(x, static_cast<long>(y));
    }
    static int floorDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0))) q--;
        return q;
    }

    // ceilDiv
    static long ceilDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0))) q++;
        return q;
    }
    static long ceilDiv(long x, int y) {
        return ceilDiv(x, static_cast<long>(y));
    }
    static int ceilDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0))) q++;
        return q;
    }

    // ceilMod
    static int ceilMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r -= y;
        return r;
    }
    static long ceilMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r -= y;
        return r;
    }
    static long ceilMod(long x, int y) {
        return ceilMod(x, static_cast<long>(y));
    }

    // hypot
    static double hypot(double x, double y) { return std::hypot(x, y); }

    // unsignedMultiplyExact
    static int unsignedMultiplyExact(int x, int y) {
        unsigned int ux = static_cast<unsigned int>(x);
        unsigned int uy = static_cast<unsigned int>(y);
        unsigned long long result = static_cast<unsigned long long>(ux) * uy;
        if (result > std::numeric_limits<unsigned int>::max()) throw std::overflow_error("unsigned integer overflow");
        return static_cast<int>(result);
    }
    static long unsignedMultiplyExact(long x, long y) {
        unsigned long long ux = static_cast<unsigned long long>(x);
        unsigned long long uy = static_cast<unsigned long long>(y);
        unsigned __int128 result = static_cast<unsigned __int128>(ux) * uy;
        if (result > std::numeric_limits<unsigned long long>::max()) throw std::overflow_error("unsigned long overflow");
        return static_cast<long>(result);
    }
    static long unsignedMultiplyExact(long x, int y) {
        return unsignedMultiplyExact(x, static_cast<long>(y));
    }

    // toRadians/toDegrees
    static double toRadians(double angdeg) { return angdeg * M_PI / 180.0; }
    static double toDegrees(double angrad) { return angrad * 180.0 / M_PI; }

    // random
    static double random() { return static_cast<double>(rand()) / RAND_MAX; }

    // divideExact
    static int divideExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return x / y;
    }
    static long divideExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return x / y;
    }

    // floorDivExact
    static int floorDivExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return floorDiv(x, y);
    }
    static long floorDivExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return floorDiv(x, y);
    }

    // ceilDivExact
    static long ceilDivExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return ceilDiv(x, y);
    }
    static int ceilDivExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return ceilDiv(x, y);
    }

    // toIntExact
    static int toIntExact(long value) {
        if (value > std::numeric_limits<int>::max() || value < std::numeric_limits<int>::min()) {
            throw std::overflow_error("integer overflow");
        }
        return static_cast<int>(value);
    }

    // multiplyFull
    static long multiplyFull(int x, int y) {
        return static_cast<long>(x) * y;
    }

    // absExact
    static long absExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return (a < 0) ? -a : a;
    }
    static int absExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return (a < 0) ? -a : a;
    }

    // ulp
    static float ulp(float f) { return std::nextafter(f, std::numeric_limits<float>::infinity()) - f; }
    static double ulp(double d) { return std::nextafter(d, std::numeric_limits<double>::infinity()) - d; }

    // nextAfter
    static double nextAfter(double start, double direction) { return std::nextafter(start, direction); }
    static float nextAfter(float start, double direction) { return std::nextafter(start, static_cast<float>(direction)); }

    // nextUp/nextDown
    static float nextUp(float f) { return std::nextafter(f, std::numeric_limits<float>::infinity()); }
    static double nextUp(double d) { return std::nextafter(d, std::numeric_limits<double>::infinity()); }
    static float nextDown(float f) { return std::nextafter(f, -std::numeric_limits<float>::infinity()); }
    static double nextDown(double d) { return std::nextafter(d, -std::numeric_limits<double>::infinity()); }

    // powExact
    static int powExact(int a, int b) {
        long long result = 1;
        for (int i = 0; i < b; ++i) {
            result *= a;
            if (result > std::numeric_limits<int>::max() || result < std::numeric_limits<int>::min()) {
                throw std::overflow_error("integer overflow");
            }
        }
        return static_cast<int>(result);
    }
    static long powExact(long a, int b) {
        long long result = 1;
        for (int i = 0; i < b; ++i) {
            result *= a;
            if (result > std::numeric_limits<long>::max() || result < std::numeric_limits<long>::min()) {
                throw std::overflow_error("long overflow");
            }
        }
        return result;
    }

    // unsignedPowExact
    static long unsignedPowExact(long a, int b) {
        unsigned long long result = 1;
        unsigned long long ua = static_cast<unsigned long long>(a);
        for (int i = 0; i < b; ++i) {
            result *= ua;
            if (result > std::numeric_limits<unsigned long long>::max()) {
                throw std::overflow_error("unsigned long overflow");
            }
        }
        return static_cast<long>(result);
    }
    static int unsignedPowExact(int a, int b) {
        unsigned int result = 1;
        unsigned int ua = static_cast<unsigned int>(a);
        for (int i = 0; i < b; ++i) {
            result *= ua;
            if (result > std::numeric_limits<unsigned int>::max()) {
                throw std::overflow_error("unsigned integer overflow");
            }
        }
        return static_cast<int>(result);
    }
};

} // namespace lang
} // namespace java

using java::lang::Math;

// Test functions

void pow_test_8307() {
double double2 = Math::pow(static_cast<double>(-2604L), 0.15348481875996808);
    assert(std::isnan(double2));
}
