#include <cassert>
#include <stdexcept>

class Desktop {
private:
    Desktop() {}

public:
    static Desktop& getDesktop() {
        static Desktop instance;
        return instance;
    }

    static bool isDesktopSupported() {
#if defined(_WIN32) || defined(__APPLE__) || defined(__linux__)
        return true;
#else
        return false;
#endif
    }
};

void getDesktop_test_4108() {
try {
        Desktop& desktop0 = Desktop::getDesktop();
    } catch (...) {
        // Expected exception.
    }
}
