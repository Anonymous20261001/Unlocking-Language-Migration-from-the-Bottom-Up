#include <cassert>
#include <cstddef>

class KeyboardFocusManager {
public:
    KeyboardFocusManager() = default;
    virtual ~KeyboardFocusManager() = default;

    static void setCurrentKeyboardFocusManager(KeyboardFocusManager* focusManager) {
        current_ = focusManager;
    }

    static KeyboardFocusManager* getCurrentKeyboardFocusManager() {
        return current_;
    }

private:
    static KeyboardFocusManager* current_;
};

KeyboardFocusManager* KeyboardFocusManager::current_ = nullptr;

void setCurrentKeyboardFocusManager_test_7611() {
KeyboardFocusManager* keyboardFocusManager0 = KeyboardFocusManager::getCurrentKeyboardFocusManager();
    KeyboardFocusManager::setCurrentKeyboardFocusManager(keyboardFocusManager0);
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
