#include <cassert>
#include <string>
#include <cstddef>

class Point {
public:
    int x;
    int y;

    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class DataBuffer {
public:
    DataBuffer() {}
    virtual ~DataBuffer() {}
};

class SampleModel {
public:
    SampleModel() {}
    virtual ~SampleModel() {}
};

class Raster {
public:
    virtual ~Raster() {}

    static Raster* createInterleavedRaster(int dataType, int w, int h, int bands,
                                           int scanlineStride, int* bandOffsets,
                                           const Point& location) {
        return nullptr;
    }

    static Raster* createInterleavedRaster(int dataType, int w, int h, int bands,
                                           const Point& location) {
        return nullptr;
    }

    static Raster* createInterleavedRaster(DataBuffer& dataBuffer, int w, int h,
                                           int scanlineStride, int pixelStride,
                                           int* bandOffsets, const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(int dataType, int w, int h, int* bandMasks,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(int dataType, int w, int h, int bitsPerPixel,
                                      int scanlineStride, const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int scanlineStride, int* bandMasks,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int bitsPerPixel, const Point& location) {
        return nullptr;
    }

    static Raster* createWritableRaster(SampleModel& sampleModel, const Point& location) {
        return nullptr;
    }

    static Raster* createWritableRaster(SampleModel& sampleModel, DataBuffer& dataBuffer,
                                        const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int scanlineStride, int* bankIndices,
                                      int* bandOffsets, const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(int dataType, int w, int h, int bands,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(int dataType, int w, int h, int scanlineStride,
                                      int* bankIndices, int* bandOffsets,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createRaster(SampleModel& sampleModel, DataBuffer& dataBuffer,
                                const Point& location) {
        return nullptr;
    }
};


void createWritableRaster_test_10332() {
Point point1;
    std::string str2 = "java.awt.Point[x=0,y=0]";
    try {
        Raster::createWritableRaster(*static_cast<SampleModel*>(nullptr), point1);
    } catch (...) {
        // Expected exception.
    }
    assert(str2 == "java.awt.Point[x=0,y=0]");
}
