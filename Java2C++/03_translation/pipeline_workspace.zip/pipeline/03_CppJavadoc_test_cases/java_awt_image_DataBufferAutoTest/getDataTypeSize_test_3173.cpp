#include <cassert>
#include <stdexcept>

class DataBuffer {
public:
    static const int TYPE_BYTE = 0;
    static const int TYPE_USHORT = 1;
    static const int TYPE_SHORT = 2;
    static const int TYPE_INT = 3;
    static const int TYPE_FLOAT = 4;
    static const int TYPE_DOUBLE = 5;
    static const int TYPE_UNDEFINED = 32;
    static const int TYPE_UNKNOWN = 64;

    static int getDataTypeSize(int dataType) {
        switch (dataType) {
            case TYPE_BYTE:
                return 8;
            case TYPE_USHORT:
            case TYPE_SHORT:
                return 16;
            case TYPE_INT:
            case TYPE_FLOAT:
                return 32;
            case TYPE_DOUBLE:
                return 64;
            default:
                throw std::invalid_argument("Unknown data type: " + dataType);
        }
    }
};

void getDataTypeSize_test_3173() {
int int1 = DataBuffer::getDataTypeSize(0);
    assert(int1 == 8);
}
