#include <cassert>
#include <exception>

class RMIFailureHandler {
public:
    virtual ~RMIFailureHandler() = default;
    virtual bool failure(const std::exception& ex) = 0;
};

class RMISocketFactory {
private:
    static RMISocketFactory* socketFactory;
    static RMISocketFactory* defaultSocketFactory;
    static RMIFailureHandler* failureHandler;

protected:
    RMISocketFactory() = default;

public:
    virtual ~RMISocketFactory() = default;

    static RMISocketFactory* getSocketFactory() {
        return socketFactory;
    }

    static RMISocketFactory* getDefaultSocketFactory() {
        if (defaultSocketFactory == nullptr) {
            defaultSocketFactory = new RMISocketFactory();
        }
        return defaultSocketFactory;
    }

    static void setFailureHandler(RMIFailureHandler* handler) {
        failureHandler = handler;
    }

    static RMIFailureHandler* getFailureHandler() {
        return failureHandler;
    }
};

RMISocketFactory* RMISocketFactory::socketFactory = nullptr;
RMISocketFactory* RMISocketFactory::defaultSocketFactory = nullptr;
RMIFailureHandler* RMISocketFactory::failureHandler = nullptr;

void getFailureHandler_test_10639() {
RMIFailureHandler* rMIFailureHandler0 = RMISocketFactory::getFailureHandler();
assert(rMIFailureHandler0 == nullptr);
}
