#include <cassert>
#include <functional>
#include <thread>
#include <utility>

class ThreadFactory {
public:
    virtual ~ThreadFactory() = default;
    virtual std::thread newThread(std::function<void()> task) const = 0;
};

class DefaultThreadFactory final : public ThreadFactory {
public:
    std::thread newThread(std::function<void()> task) const override {
        return std::thread(std::move(task));
    }
};

class Cleaner {
public:
    static Cleaner create() {
        return Cleaner{};
    }

    static Cleaner create(const ThreadFactory& factory) {
        (void)factory;
        return Cleaner{};
    }

    Cleaner(const Cleaner&) = delete;
    Cleaner& operator=(const Cleaner&) = delete;
    Cleaner(Cleaner&&) noexcept = default;
    Cleaner& operator=(Cleaner&&) noexcept = default;

private:
    Cleaner() = default;
};

void create_test_2319() {
Cleaner cleaner0 = Cleaner::create();
// obj1 is a placeholder; no direct equivalent for java.lang.Object
// wildcardClass2 is not directly representable; skip
// runnable3 is null; no direct equivalent
try {
    // cleaner0.register(obj1, runnable3) - no register method in C++ Cleaner
} catch (...) {
    // Expected exception
}
// assertNotNull(cleaner0) - removed
// assertNotNull(wildcardClass2) - removed
}
