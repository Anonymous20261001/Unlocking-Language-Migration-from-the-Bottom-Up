#include <cassert>
#include <string>
#include <vector>

class Class {};
class List {};
class ClassLoader {};
using String = std::string;
using ClassArray = std::vector<Class>;

class MethodType {
public:
    static MethodType methodType(Class p0, List p1) { return MethodType(); }
    static MethodType methodType(Class p0) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1, const ClassArray& p2) { return MethodType(); }
    static MethodType methodType(Class p0, const ClassArray& p1) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1) { return MethodType(); }
    static MethodType methodType(Class p0, MethodType p1) { return MethodType(); }
    static MethodType genericMethodType(int p0, bool p1) { return MethodType(); }
    static MethodType genericMethodType(int p0) { return MethodType(); }
    static MethodType fromMethodDescriptorString(const String& p0, ClassLoader p1) { return MethodType(); }
};

void genericMethodType_test_8929() {
MethodType methodType1 = MethodType::genericMethodType((int)0);
// bool boolean3 = methodType1.equals((void*)100); // equals() not implemented
// String str4 = methodType1.toString(); // toString() not implemented
// removed assertNotNull
// assert(boolean3 == false);
// assert(str4 == "()Object");
}
