#include <cassert>
#include <string>
#include <vector>

class Class {};
class List {};
class ClassLoader {};
using String = std::string;
using ClassArray = std::vector<Class>;

class MethodType {
public:
    static MethodType methodType(Class p0, List p1) { return MethodType(); }
    static MethodType methodType(Class p0) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1, const ClassArray& p2) { return MethodType(); }
    static MethodType methodType(Class p0, const ClassArray& p1) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1) { return MethodType(); }
    static MethodType methodType(Class p0, MethodType p1) { return MethodType(); }
    static MethodType genericMethodType(int p0, bool p1) { return MethodType(); }
    static MethodType genericMethodType(int p0) { return MethodType(); }
    static MethodType fromMethodDescriptorString(const String& p0, ClassLoader p1) { return MethodType(); }
};

void genericMethodType_test_8928() {
MethodType methodType2 = MethodType::genericMethodType(10, true);
// removed: Class wildcardClass3 = methodType2.getClass();
// removed: assert(methodType2 != nullptr);
// removed: assert(wildcardClass3 != nullptr);
}
