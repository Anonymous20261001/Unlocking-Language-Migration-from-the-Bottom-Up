#include <cassert>
class ResponseCache {
public:
    virtual ~ResponseCache() = default;

    static ResponseCache* getDefault() {
        return defaultCache;
    }

    static void setDefault(ResponseCache* cache) {
        defaultCache = cache;
    }

private:
    static ResponseCache* defaultCache;
};

ResponseCache* ResponseCache::defaultCache = nullptr;

void setDefault_test_10629() {
ResponseCache::setDefault(nullptr);
}
