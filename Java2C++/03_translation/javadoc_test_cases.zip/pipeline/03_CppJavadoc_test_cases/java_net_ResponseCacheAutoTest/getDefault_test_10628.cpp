#include <cassert>
class ResponseCache {
public:
    virtual ~ResponseCache() = default;

    static ResponseCache* getDefault() {
        return defaultCache;
    }

    static void setDefault(ResponseCache* cache) {
        defaultCache = cache;
    }

private:
    static ResponseCache* defaultCache;
};

ResponseCache* ResponseCache::defaultCache = nullptr;

void getDefault_test_10628() {
ResponseCache* responseCache0 = ResponseCache::getDefault();
    assert(responseCache0 == nullptr);
}
