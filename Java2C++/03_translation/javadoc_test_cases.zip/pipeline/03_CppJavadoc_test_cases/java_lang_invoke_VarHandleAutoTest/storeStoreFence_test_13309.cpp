#include <cassert>
#include <atomic>

class VarHandle {
public:
    static void storeStoreFence() {
        std::atomic_thread_fence(std::memory_order_release);
    }

    static void fullFence() {
        std::atomic_thread_fence(std::memory_order_seq_cst);
    }

    static void loadLoadFence() {
        std::atomic_thread_fence(std::memory_order_acquire);
    }

    static void acquireFence() {
        std::atomic_thread_fence(std::memory_order_acquire);
    }

    static void releaseFence() {
        std::atomic_thread_fence(std::memory_order_release);
    }
};

void storeStoreFence_test_13309() {
VarHandle::storeStoreFence();
}
