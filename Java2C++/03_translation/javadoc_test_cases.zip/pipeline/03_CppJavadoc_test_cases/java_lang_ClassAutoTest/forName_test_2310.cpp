#include <cassert>
#include <string>

class Module {
public:
    Module() = default;
};

class String {
public:
    std::string value;

    String() = default;
    String(const char* s) : value(s) {}
    String(const std::string& s) : value(s) {}
};

class Class {
public:
    Class() = default;

    static Class forName(Module module, String name) {
        return Class();
    }

    static Class forPrimitiveName(String name) {
        return Class();
    }
};

void forName_test_2310() {
Module module0;
    try {
        Class wildcardClass2 = Class::forName(module0, String(""));
    } catch (...) {
        // Expected exception.
    }
}
