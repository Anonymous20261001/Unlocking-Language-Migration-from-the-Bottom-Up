#include <cassert>
#include <map>
#include <string>
#include <vector>
#include <functional>
#include <utility>

class HttpHeaders {
public:
    using Map = std::map<std::string, std::vector<std::string>>;
    using BiPredicate = std::function<bool(const std::string&, const std::string&)>;

    static HttpHeaders of(const Map& headers, BiPredicate filter) {
        Map result;
        for (const auto& entry : headers) {
            const std::string& key = entry.first;
            const std::vector<std::string>& values = entry.second;

            std::vector<std::string> filteredValues;
            for (const auto& value : values) {
                if (filter(key, value)) {
                    filteredValues.push_back(value);
                }
            }

            if (!filteredValues.empty()) {
                result[key] = std::move(filteredValues);
            }
        }
        return HttpHeaders(std::move(result));
    }

private:
    Map headers_;

    explicit HttpHeaders(Map headers) : headers_(std::move(headers)) {}
};

void of_test_5437() {
HttpHeaders::Map strMap0;
    HttpHeaders::BiPredicate strBiPredicate1 = nullptr;
    try {
        HttpHeaders httpHeaders2 = HttpHeaders::of(strMap0, strBiPredicate1);
    } catch (...) {
    }
}
