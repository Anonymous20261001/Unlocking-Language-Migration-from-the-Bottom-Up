#include <cassert>
#include <cstddef>

class CoderResult {
public:
    enum class Type {
        UNDERFLOW,
        OVERFLOW,
        MALFORMED,
        UNMAPPABLE
    };

    static CoderResult malformedForLength(int length) {
        return CoderResult(Type::MALFORMED, length);
    }

    static CoderResult unmappableForLength(int length) {
        return CoderResult(Type::UNMAPPABLE, length);
    }

    Type getType() const {
        return type;
    }

    int length() const {
        return length_;
    }

private:
    Type type;
    int length_;

    CoderResult(Type type, int length)
        : type(type), length_(length) {}
};

void malformedForLength_test_2338() {
CoderResult coderResult1 = CoderResult::malformedForLength((int) '#');
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
