#include <cassert>
#include <string>

class URI {
public:
    explicit URI(const std::string& uri) : value_(uri) {}

    static URI create(const std::string& uri) {
        return URI(uri);
    }

private:
    std::string value_;
};

void create_test_13237() {
URI uRI1 = URI::create("hi!");
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
