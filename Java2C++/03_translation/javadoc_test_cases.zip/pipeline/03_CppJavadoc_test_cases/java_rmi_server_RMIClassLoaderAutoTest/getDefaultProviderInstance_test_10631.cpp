#include <cassert>
#include <string>

namespace java {
namespace lang {

class Class {
public:
    Class() : name_() {}
    explicit Class(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class ClassLoader {
public:
    ClassLoader() = default;
    virtual ~ClassLoader() = default;
};

class Object {
public:
    virtual ~Object() = default;
};

} // namespace lang

namespace rmi {
namespace server {

class RMIClassLoader {
public:
    static std::string getClassAnnotation(const java::lang::Class& cl) {
        (void)cl;
        return std::string();
    }

    static java::lang::ClassLoader& getDefaultProviderInstance() {
        static java::lang::ClassLoader instance;
        return instance;
    }

    static java::lang::Object getSecurityContext(const java::lang::ClassLoader& loader) {
        (void)loader;
        return java::lang::Object();
    }
};

} // namespace server
} // namespace rmi
} // namespace java

void getDefaultProviderInstance_test_10631() {
java::rmi::server::RMIClassLoader::getDefaultProviderInstance();
}
