#include <cassert>
#include <string>
#include <cstddef>

class CharSequence {
    std::string data;
public:
    CharSequence() = default;
    CharSequence(const std::string& s) : data(s) {}
    size_t length() const { return data.size(); }
    char charAt(size_t index) const { return data[index]; }
    const std::string& str() const { return data; }
};

namespace java_text {
class Normalizer {
public:
    enum class Form {
        NFD, NFC, NFKD, NFKC
    };

    static std::string normalize(const CharSequence& charSequence, Form form) {
        return charSequence.str();
    }

    static bool isNormalized(const CharSequence& charSequence, Form form) {
        return true;
    }
};
}

void isNormalized_test_9530() {
java_text::Normalizer::Form form1 = java_text::Normalizer::Form::NFC;
    bool boolean2 = java_text::Normalizer::isNormalized(CharSequence(""), form1);
    // wildcardClass3 removed (null check not needed)
    assert(form1 == java_text::Normalizer::Form::NFC);
    assert(boolean2 == true);
}
