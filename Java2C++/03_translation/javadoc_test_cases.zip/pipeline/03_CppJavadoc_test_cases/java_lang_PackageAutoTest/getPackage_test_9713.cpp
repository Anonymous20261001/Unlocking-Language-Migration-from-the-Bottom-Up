#include <cassert>
#include <string>
#include <vector>
#include <map>

class Package {
public:
    static Package* getPackage(const std::string& name) {
        auto& pkgs = packages();
        auto it = pkgs.find(name);
        if (it != pkgs.end()) {
            return &it->second;
        }
        return nullptr;
    }

    static std::vector<Package> getPackages() {
        std::vector<Package> result;
        const auto& pkgs = packages();
        result.reserve(pkgs.size());
        for (const auto& entry : pkgs) {
            result.push_back(entry.second);
        }
        return result;
    }

private:
    Package() = default;
    explicit Package(const std::string& name)
        : name_(name) {}
    Package(const std::string& name,
            const std::string& specTitle,
            const std::string& specVersion,
            const std::string& specVendor,
            const std::string& implTitle,
            const std::string& implVersion,
            const std::string& implVendor)
        : name_(name), specTitle_(specTitle), specVersion_(specVersion),
          specVendor_(specVendor), implTitle_(implTitle),
          implVersion_(implVersion), implVendor_(implVendor) {}

    static std::map<std::string, Package>& packages() {
        static std::map<std::string, Package> instance;
        return instance;
    }

    std::string name_;
    std::string specTitle_;
    std::string specVersion_;
    std::string specVendor_;
    std::string implTitle_;
    std::string implVersion_;
    std::string implVendor_;
};

void getPackage_test_9713() {
Package* package1 = Package::getPackage("hi!");
    // removed (null check not needed in C++)
}
