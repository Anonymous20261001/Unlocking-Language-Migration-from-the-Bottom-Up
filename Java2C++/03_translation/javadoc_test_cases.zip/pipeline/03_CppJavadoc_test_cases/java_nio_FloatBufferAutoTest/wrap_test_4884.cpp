#include <cassert>
#include <vector>
#include <utility>

class FloatBuffer {
private:
    std::vector<float> data_;
    int offset_ = 0;
    int length_ = 0;

    FloatBuffer(std::vector<float> data, int offset, int length)
        : data_(std::move(data)), offset_(offset), length_(length) {}

public:
    static FloatBuffer wrap(std::vector<float>& array) {
        return FloatBuffer(array, 0, static_cast<int>(array.size()));
    }

    static FloatBuffer wrap(std::vector<float>& array, int offset, int length) {
        return FloatBuffer(array, offset, length);
    }

    static FloatBuffer allocate(int capacity) {
        std::vector<float> data(capacity);
        return FloatBuffer(std::move(data), 0, capacity);
    }
};

void wrap_test_4884() {
std::vector<float> floatArray1 = {100.0f};
    try {
        FloatBuffer floatBuffer4 = FloatBuffer::wrap(floatArray1, 0, 10);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    assert(floatArray1.size() == 1);
    assert(floatArray1[0] == 100.0f);
}
