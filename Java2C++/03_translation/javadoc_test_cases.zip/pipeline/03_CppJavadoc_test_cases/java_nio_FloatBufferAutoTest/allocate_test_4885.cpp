#include <cassert>
#include <vector>
#include <utility>
#include <string>
#include <typeinfo>

class FloatBuffer {
private:
    std::vector<float> data_;
    int offset_ = 0;
    int length_ = 0;

    FloatBuffer(std::vector<float> data, int offset, int length)
        : data_(std::move(data)), offset_(offset), length_(length) {}

public:
    static FloatBuffer wrap(std::vector<float>& array) {
        return FloatBuffer(array, 0, static_cast<int>(array.size()));
    }

    static FloatBuffer wrap(std::vector<float>& array, int offset, int length) {
        return FloatBuffer(array, offset, length);
    }

    static FloatBuffer allocate(int capacity) {
        std::vector<float> data(capacity);
        return FloatBuffer(std::move(data), 0, capacity);
    }
};

void allocate_test_4885() {
FloatBuffer floatBuffer1 = FloatBuffer::allocate((int)(unsigned char)1);
// std::string str2 = floatBuffer1.toString(); // FloatBuffer has no toString()
std::string wildcardClass3 = typeid(floatBuffer1).name();
// assert(floatBuffer1 != nullptr); // FloatBuffer is a value type, no operator!=
// assert(str2 == "java.nio.HeapFloatBuffer[pos=0 lim=1 cap=1]"); // depends on str2
assert(!wildcardClass3.empty());
}
