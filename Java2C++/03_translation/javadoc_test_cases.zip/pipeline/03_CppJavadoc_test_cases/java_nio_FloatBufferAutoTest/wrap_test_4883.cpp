#include <cassert>
#include <vector>
#include <utility>

class FloatBuffer {
private:
    std::vector<float> data_;
    int offset_ = 0;
    int length_ = 0;

    FloatBuffer(std::vector<float> data, int offset, int length)
        : data_(std::move(data)), offset_(offset), length_(length) {}

public:
    static FloatBuffer wrap(std::vector<float>& array) {
        return FloatBuffer(array, 0, static_cast<int>(array.size()));
    }

    static FloatBuffer wrap(std::vector<float>& array, int offset, int length) {
        return FloatBuffer(array, offset, length);
    }

    static FloatBuffer allocate(int capacity) {
        std::vector<float> data(capacity);
        return FloatBuffer(std::move(data), 0, capacity);
    }
};

void wrap_test_4883() {
std::vector<float> floatArray2 = { -1.0f, 32.0f };
    FloatBuffer floatBuffer3 = FloatBuffer::wrap(floatArray2);
    // removed (null check not needed in C++)
    assert(floatArray2.size() == 2 && floatArray2[0] == -1.0f && floatArray2[1] == 32.0f);
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
