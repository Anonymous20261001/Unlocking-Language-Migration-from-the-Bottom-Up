#include <cassert>
#include <string>
#include <functional>
#include <utility>

class URI {
public:
    std::string value;

    URI() = default;
    explicit URI(const std::string& uri) : value(uri) {}
};

class BiPredicate {
public:
    using Predicate = std::function<bool(const std::string&, const std::string&)>;

    BiPredicate() = default;
    BiPredicate(Predicate pred) : pred_(std::move(pred)) {}

    bool test(const std::string& t, const std::string& u) const {
        if (pred_) {
            return pred_(t, u);
        }
        return true;
    }

private:
    Predicate pred_;
};

class HttpRequest {
public:
    URI uri;

    HttpRequest() = default;
    explicit HttpRequest(const URI& u) : uri(u) {}

    class Builder {
    public:
        Builder() = default;
    };

    static Builder newBuilder() {
        return Builder();
    }

    static Builder newBuilder(const URI& uri) {
        (void)uri;
        return Builder();
    }

    static Builder newBuilder(const HttpRequest& request, const BiPredicate& filter) {
        (void)request;
        (void)filter;
        return Builder();
    }
};

void newBuilder_test_5439() {
URI uRI1 = URI("");
    std::string str2 = uRI1.value;
    bool boolean3 = false;
    try {
        HttpRequest::Builder builder4 = HttpRequest::newBuilder(uRI1);
    } catch (...) {
    }
    assert(uRI1.value == "");
    assert(str2 == "");
    assert(boolean3 == false);
}
