#include <cassert>
#include <cstddef>
#include <vector>
#include <typeinfo>

class OutputStream {
public:
    virtual ~OutputStream() = default;
};

class RemoteServer {
public:
    static void setLog(OutputStream* log) {
        logStream_ = log;
    }

    static OutputStream* getLog() {
        return logStream_;
    }

private:
    static OutputStream* logStream_;
};

OutputStream* RemoteServer::logStream_ = nullptr;

void setLog_test_10522() {
OutputStream* outputStream0 = new OutputStream();
std::vector<std::byte> byteArray1;
// outputStream0->write(byteArray1.data(), byteArray1.size()); // OutputStream has no write()
RemoteServer::setLog(outputStream0);
const std::type_info& wildcardClass4 = typeid(*outputStream0);
assert(outputStream0 != nullptr);
assert(byteArray1.empty());
assert(byteArray1 == std::vector<std::byte>());
assert(wildcardClass4 == typeid(OutputStream));
}
