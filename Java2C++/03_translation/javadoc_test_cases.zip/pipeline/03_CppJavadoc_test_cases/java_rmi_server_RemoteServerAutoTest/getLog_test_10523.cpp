#include <cassert>
#include <cstddef>

class OutputStream {
public:
    virtual ~OutputStream() = default;
};

class RemoteServer {
public:
    static void setLog(OutputStream* log) {
        logStream_ = log;
    }

    static OutputStream* getLog() {
        return logStream_;
    }

private:
    static OutputStream* logStream_;
};

OutputStream* RemoteServer::logStream_ = nullptr;

void getLog_test_10523() {
OutputStream* printStream0 = RemoteServer::getLog();
    assert(printStream0 == nullptr);
}
