#include <cassert>
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <vector>
#include <string>
#include <cstring>
#include <type_traits>
#include <memory>

// Minimal Java-like Object base class
class Object {
public:
    virtual ~Object() = default;
};

// Minimal Java-like Class representation
class Class {
public:
    enum class Type {
        BOOLEAN,
        BYTE,
        SHORT,
        CHAR,
        INT,
        LONG,
        FLOAT,
        DOUBLE,
        OBJECT,
        ARRAY
    };

    Type type;
    std::string name;
    Class* componentType = nullptr;

    Class(Type t, const std::string& n) : type(t), name(n) {}
    Class(Type t, const std::string& n, Class* comp) : type(t), name(n), componentType(comp) {}

    static Class* getBoolean() { static Class c(Type::BOOLEAN, "boolean"); return &c; }
    static Class* getByte() { static Class c(Type::BYTE, "byte"); return &c; }
    static Class* getShort() { static Class c(Type::SHORT, "short"); return &c; }
    static Class* getChar() { static Class c(Type::CHAR, "char"); return &c; }
    static Class* getInt() { static Class c(Type::INT, "int"); return &c; }
    static Class* getLong() { static Class c(Type::LONG, "long"); return &c; }
    static Class* getFloat() { static Class c(Type::FLOAT, "float"); return &c; }
    static Class* getDouble() { static Class c(Type::DOUBLE, "double"); return &c; }
    static Class* getObject() { static Class c(Type::OBJECT, "java.lang.Object"); return &c; }
    static Class* getArray(Class* comp) {
        static std::vector<std::unique_ptr<Class>> arrays;
        for (auto& arr : arrays) {
            if (arr->componentType == comp) return arr.get();
        }
        arrays.push_back(std::make_unique<Class>(Type::ARRAY, "[" + comp->name, comp));
        return arrays.back().get();
    }
};

// Array wrapper class that mimics Java arrays
class Array : public Object {
public:
    Class* elementClass;
    size_t length;
    void* data; // raw data storage

    Array(Class* elemClass, size_t len) : elementClass(elemClass), length(len) {
        if (elemClass->type == Class::Type::BOOLEAN) {
            data = new bool[len];
        } else if (elemClass->type == Class::Type::BYTE) {
            data = new int8_t[len];
        } else if (elemClass->type == Class::Type::SHORT) {
            data = new int16_t[len];
        } else if (elemClass->type == Class::Type::CHAR) {
            data = new char16_t[len];
        } else if (elemClass->type == Class::Type::INT) {
            data = new int32_t[len];
        } else if (elemClass->type == Class::Type::LONG) {
            data = new int64_t[len];
        } else if (elemClass->type == Class::Type::FLOAT) {
            data = new float[len];
        } else if (elemClass->type == Class::Type::DOUBLE) {
            data = new double[len];
        } else if (elemClass->type == Class::Type::OBJECT) {
            data = new Object*[len];
            for (size_t i = 0; i < len; ++i) static_cast<Object**>(data)[i] = nullptr;
        } else {
            throw std::invalid_argument("Unsupported array element type");
        }
    }

    ~Array() override {
        if (elementClass->type == Class::Type::BOOLEAN) delete[] static_cast<bool*>(data);
        else if (elementClass->type == Class::Type::BYTE) delete[] static_cast<int8_t*>(data);
        else if (elementClass->type == Class::Type::SHORT) delete[] static_cast<int16_t*>(data);
        else if (elementClass->type == Class::Type::CHAR) delete[] static_cast<char16_t*>(data);
        else if (elementClass->type == Class::Type::INT) delete[] static_cast<int32_t*>(data);
        else if (elementClass->type == Class::Type::LONG) delete[] static_cast<int64_t*>(data);
        else if (elementClass->type == Class::Type::FLOAT) delete[] static_cast<float*>(data);
        else if (elementClass->type == Class::Type::DOUBLE) delete[] static_cast<double*>(data);
        else if (elementClass->type == Class::Type::OBJECT) delete[] static_cast<Object**>(data);
    }

    // Static methods mimicking java.lang.reflect.Array
    static Object* get(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr) throw std::invalid_argument("Not an array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        if (arr->elementClass->type == Class::Type::OBJECT) {
            return static_cast<Object**>(arr->data)[index];
        }
        throw std::invalid_argument("get() only works for object arrays");
    }

    static int getLength(Object* array) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr) throw std::invalid_argument("Not an array");
        return static_cast<int>(arr->length);
    }

    static bool getBoolean(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::BOOLEAN) throw std::invalid_argument("Not a boolean array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<bool*>(arr->data)[index];
    }

    static int8_t getByte(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::BYTE) throw std::invalid_argument("Not a std::byte array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<int8_t*>(arr->data)[index];
    }

    static int16_t getShort(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::SHORT) throw std::invalid_argument("Not a short array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<int16_t*>(arr->data)[index];
    }

    static char16_t getChar(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::CHAR) throw std::invalid_argument("Not a char array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<char16_t*>(arr->data)[index];
    }

    static int32_t getInt(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::INT) throw std::invalid_argument("Not an int array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<int32_t*>(arr->data)[index];
    }

    static int64_t getLong(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::LONG) throw std::invalid_argument("Not a long array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<int64_t*>(arr->data)[index];
    }

    static float getFloat(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::FLOAT) throw std::invalid_argument("Not a float array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<float*>(arr->data)[index];
    }

    static double getDouble(Object* array, int index) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::DOUBLE) throw std::invalid_argument("Not a double array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        return static_cast<double*>(arr->data)[index];
    }

    static Array* newInstance(Class* componentType, int length) {
        if (length < 0) throw std::invalid_argument("Negative array length");
        return new Array(componentType, static_cast<size_t>(length));
    }

    static Array* newInstance(Class* componentType, int* dimensions, size_t dimCount) {
        if (dimCount == 0) throw std::invalid_argument("No dimensions");
        if (dimCount == 1) return newInstance(componentType, dimensions[0]);
        // For multi-dimensional, create array of arrays
        Class* arrayClass = Class::getArray(componentType);
        Array* result = new Array(arrayClass, static_cast<size_t>(dimensions[0]));
        // Recursively create sub-arrays
        for (int i = 0; i < dimensions[0]; ++i) {
            static_cast<Object**>(result->data)[i] = newInstance(componentType, dimensions + 1, dimCount - 1);
        }
        return result;
    }

    static void set(Object* array, int index, Object* value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::OBJECT) throw std::invalid_argument("Not an object array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<Object**>(arr->data)[index] = value;
    }

    static void setBoolean(Object* array, int index, bool value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::BOOLEAN) throw std::invalid_argument("Not a boolean array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<bool*>(arr->data)[index] = value;
    }

    static void setByte(Object* array, int index, int8_t value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::BYTE) throw std::invalid_argument("Not a std::byte array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<int8_t*>(arr->data)[index] = value;
    }

    static void setChar(Object* array, int index, char16_t value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::CHAR) throw std::invalid_argument("Not a char array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<char16_t*>(arr->data)[index] = value;
    }

    static void setShort(Object* array, int index, int16_t value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::SHORT) throw std::invalid_argument("Not a short array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<int16_t*>(arr->data)[index] = value;
    }

    static void setInt(Object* array, int index, int32_t value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::INT) throw std::invalid_argument("Not an int array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<int32_t*>(arr->data)[index] = value;
    }

    static void setLong(Object* array, int index, int64_t value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::LONG) throw std::invalid_argument("Not a long array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<int64_t*>(arr->data)[index] = value;
    }

    static void setFloat(Object* array, int index, float value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::FLOAT) throw std::invalid_argument("Not a float array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<float*>(arr->data)[index] = value;
    }

    static void setDouble(Object* array, int index, double value) {
        Array* arr = dynamic_cast<Array*>(array);
        if (!arr || arr->elementClass->type != Class::Type::DOUBLE) throw std::invalid_argument("Not a double array");
        if (index < 0 || index >= static_cast<int>(arr->length)) throw std::out_of_range("Index out of bounds");
        static_cast<double*>(arr->data)[index] = value;
    }
};

// Test functions


void setChar_test_247() {
try {
    Array::setChar((Object*)1, 0, u'a');
    assert(false);
} catch (...) {
}
}
