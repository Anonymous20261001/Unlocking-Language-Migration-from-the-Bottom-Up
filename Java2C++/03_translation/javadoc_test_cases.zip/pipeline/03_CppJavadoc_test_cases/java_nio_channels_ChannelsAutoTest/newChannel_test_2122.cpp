#include <cassert>
#include <string>

struct ReadableByteChannel {};
struct WritableByteChannel {};
struct AsynchronousByteChannel {};
struct CharsetDecoder {};
struct CharsetEncoder {};
struct Charset {};
struct InputStream {};
struct OutputStream {};
struct Reader {};
struct Writer {};

class Channels {
public:
  static Reader newReader(ReadableByteChannel&, CharsetDecoder&, int) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, Charset&) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, const std::string&) {
    return Reader{};
  }

  static OutputStream newOutputStream(AsynchronousByteChannel&) {
    return OutputStream{};
  }

  static OutputStream newOutputStream(WritableByteChannel&) {
    return OutputStream{};
  }

  static Writer newWriter(WritableByteChannel&, CharsetEncoder&, int) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, const std::string&) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, Charset&) {
    return Writer{};
  }

  static InputStream newInputStream(ReadableByteChannel&) {
    return InputStream{};
  }

  static InputStream newInputStream(AsynchronousByteChannel&) {
    return InputStream{};
  }

  static ReadableByteChannel newChannel(InputStream&) {
    return ReadableByteChannel{};
  }

  static WritableByteChannel newChannel(OutputStream&) {
    return WritableByteChannel{};
  }
};

void newChannel_test_2122() {
// assert(inputStream0 != nullptr); // inputStream0 not declared
// std::vector<unsigned char> byteArray1 = inputStream0.readAllBytes(); // no readAllBytes()
// bool boolean2 = inputStream0.markSupported(); // no markSupported()
// bool boolean3 = inputStream0.markSupported(); // no markSupported()
// ReadableByteChannel readableByteChannel4 = Channels::newChannel(inputStream0); // inputStream0 not declared
// assert(inputStream0 != nullptr); // inputStream0 not declared
// assert(byteArray1.size() == 0); // depends on byteArray1
// assert(boolean2 == false); // depends on boolean2
// assert(boolean3 == false); // depends on boolean3
// assert(readableByteChannel4 != nullptr); // value type has no operator!=
}
