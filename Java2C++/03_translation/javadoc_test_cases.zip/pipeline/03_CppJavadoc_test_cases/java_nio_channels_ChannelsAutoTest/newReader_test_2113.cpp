#include <cassert>
#include <string>

struct ReadableByteChannel {};
struct WritableByteChannel {};
struct AsynchronousByteChannel {};
struct CharsetDecoder {};
struct CharsetEncoder {};
struct Charset {};
struct InputStream {};
struct OutputStream {};
struct Reader {};
struct Writer {};

class Channels {
public:
  static Reader newReader(ReadableByteChannel&, CharsetDecoder&, int) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, Charset&) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, const std::string&) {
    return Reader{};
  }

  static OutputStream newOutputStream(AsynchronousByteChannel&) {
    return OutputStream{};
  }

  static OutputStream newOutputStream(WritableByteChannel&) {
    return OutputStream{};
  }

  static Writer newWriter(WritableByteChannel&, CharsetEncoder&, int) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, const std::string&) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, Charset&) {
    return Writer{};
  }

  static InputStream newInputStream(ReadableByteChannel&) {
    return InputStream{};
  }

  static InputStream newInputStream(AsynchronousByteChannel&) {
    return InputStream{};
  }

  static ReadableByteChannel newChannel(InputStream&) {
    return ReadableByteChannel{};
  }

  static WritableByteChannel newChannel(OutputStream&) {
    return WritableByteChannel{};
  }
};

void newReader_test_2113() {
InputStream inputStream0 = InputStream{};
int int1 = 0;
ReadableByteChannel readableByteChannel2 = Channels::newChannel(inputStream0);
try {
    Reader reader4 = Channels::newReader(readableByteChannel2, "");
} catch (...) {
}
assert(int1 == 0);
}
