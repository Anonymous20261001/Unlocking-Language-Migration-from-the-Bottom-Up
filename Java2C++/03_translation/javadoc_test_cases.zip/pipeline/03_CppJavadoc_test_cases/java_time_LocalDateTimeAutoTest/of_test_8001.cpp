#include <cassert>
#include <cstdint>
#include <string>

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
};

class LocalDate : public TemporalAccessor {
public:
    LocalDate() : year_(1970), month_(1), day_(1) {}
    LocalDate(int year, int month, int day) : year_(year), month_(month), day_(day) {}
    int getYear() const { return year_; }
    int getMonth() const { return month_; }
    int getDay() const { return day_; }
private:
    int year_;
    int month_;
    int day_;
};

class LocalTime : public TemporalAccessor {
public:
    LocalTime() : hour_(0), minute_(0), second_(0), nano_(0) {}
    LocalTime(int hour, int minute) : hour_(hour), minute_(minute), second_(0), nano_(0) {}
    LocalTime(int hour, int minute, int second) : hour_(hour), minute_(minute), second_(second), nano_(0) {}
    LocalTime(int hour, int minute, int second, int nanoOfSecond) : hour_(hour), minute_(minute), second_(second), nano_(nanoOfSecond) {}
    int getHour() const { return hour_; }
    int getMinute() const { return minute_; }
    int getSecond() const { return second_; }
    int getNano() const { return nano_; }
private:
    int hour_;
    int minute_;
    int second_;
    int nano_;
};

class ZoneId {
public:
    ZoneId() : id_("UTC") {}
    explicit ZoneId(const std::string& id) : id_(id) {}
    virtual ~ZoneId() = default;
    const std::string& getId() const { return id_; }
private:
    std::string id_;
};

class ZoneOffset : public ZoneId {
public:
    ZoneOffset() : ZoneId("UTC"), totalSeconds_(0) {}
    explicit ZoneOffset(int totalSeconds) : ZoneId(""), totalSeconds_(totalSeconds) {}
    int getTotalSeconds() const { return totalSeconds_; }
private:
    int totalSeconds_;
};

class Clock {
public:
    virtual ~Clock() = default;
};

class Instant {
public:
    Instant() : seconds_(0), nanos_(0) {}
    Instant(std::int64_t seconds, int nanos) : seconds_(seconds), nanos_(nanos) {}
    std::int64_t getEpochSecond() const { return seconds_; }
    int getNano() const { return nanos_; }
private:
    std::int64_t seconds_;
    int nanos_;
};

class CharSequence {
public:
    CharSequence() : text_() {}
    CharSequence(const char* s) : text_(s != nullptr ? s : "") {}
    CharSequence(const std::string& s) : text_(s) {}
    const std::string& toString() const { return text_; }
    size_t length() const { return text_.length(); }
private:
    std::string text_;
};

class DateTimeFormatter {
public:
    DateTimeFormatter() = default;
};

enum class Month {
    JANUARY = 1,
    FEBRUARY = 2,
    MARCH = 3,
    APRIL = 4,
    MAY = 5,
    JUNE = 6,
    JULY = 7,
    AUGUST = 8,
    SEPTEMBER = 9,
    OCTOBER = 10,
    NOVEMBER = 11,
    DECEMBER = 12
};

class LocalDateTime : public TemporalAccessor {
public:
    LocalDateTime() : date_(), time_() {}
    LocalDateTime(const LocalDate& date, const LocalTime& time) : date_(date), time_(time) {}

    static LocalDateTime of(const LocalDate& date, const LocalTime& time) {
        return LocalDateTime(date, time);
    }

    static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute) {
        return LocalDateTime(LocalDate(year, month, dayOfMonth), LocalTime(hour, minute));
    }

    static LocalDateTime of(int year, Month month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond) {
        return LocalDateTime(LocalDate(year, static_cast<int>(month), dayOfMonth),
                             LocalTime(hour, minute, second, nanoOfSecond));
    }

    static LocalDateTime of(int year, Month month, int dayOfMonth, int hour, int minute, int second) {
        return LocalDateTime(LocalDate(year, static_cast<int>(month), dayOfMonth),
                             LocalTime(hour, minute, second));
    }

    static LocalDateTime of(int year, Month month, int dayOfMonth, int hour, int minute) {
        return LocalDateTime(LocalDate(year, static_cast<int>(month), dayOfMonth),
                             LocalTime(hour, minute));
    }

    static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond) {
        return LocalDateTime(LocalDate(year, month, dayOfMonth),
                             LocalTime(hour, minute, second, nanoOfSecond));
    }

    static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second) {
        return LocalDateTime(LocalDate(year, month, dayOfMonth),
                             LocalTime(hour, minute, second));
    }

    static LocalDateTime from(const TemporalAccessor& temporal) {
        const LocalDateTime* ldt = dynamic_cast<const LocalDateTime*>(&temporal);
        if (ldt != nullptr) {
            return *ldt;
        }
        return LocalDateTime();
    }

    static LocalDateTime parse(const CharSequence& text) {
        (void)text;
        return LocalDateTime();
    }

    static LocalDateTime parse(const CharSequence& text, const DateTimeFormatter& formatter) {
        (void)text;
        (void)formatter;
        return LocalDateTime();
    }

    static LocalDateTime now() {
        return LocalDateTime();
    }

    static LocalDateTime now(const ZoneId& zone) {
        (void)zone;
        return LocalDateTime();
    }

    static LocalDateTime now(const Clock& clock) {
        (void)clock;
        return LocalDateTime();
    }

    static LocalDateTime ofEpochSecond(std::int64_t epochSecond, int nanoOfSecond, const ZoneOffset& offset) {
        (void)epochSecond;
        (void)nanoOfSecond;
        (void)offset;
        return LocalDateTime();
    }

    static LocalDateTime ofInstant(const Instant& instant, const ZoneId& zone) {
        (void)instant;
        (void)zone;
        return LocalDateTime();
    }

    const LocalDate& getDate() const { return date_; }
    const LocalTime& getTime() const { return time_; }

private:
    LocalDate date_;
    LocalTime time_;
};

void of_test_8001() {
LocalDateTime localDateTime0 = LocalDateTime::now();
    const LocalDate& localDate1 = localDateTime0.getDate();
    LocalTime* localTime2 = nullptr;
    try {
        LocalDateTime localDateTime3 = LocalDateTime::of(localDate1, *localTime2);
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
