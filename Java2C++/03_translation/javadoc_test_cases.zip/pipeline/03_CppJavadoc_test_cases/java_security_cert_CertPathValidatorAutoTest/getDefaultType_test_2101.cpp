#include <cassert>
#include <string>

class CertPathValidator {
public:
    static std::string getDefaultType() {
        return "PKIX";
    }
};

void getDefaultType_test_2101() {
std::string str0 = CertPathValidator::getDefaultType();
    assert(str0 == "PKIX");
}
