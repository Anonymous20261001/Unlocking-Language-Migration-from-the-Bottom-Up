#include <cassert>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <vector>

class LongBuffer {
public:
    static LongBuffer wrap(const std::vector<std::int64_t>& array) {
        return wrap(array, 0, static_cast<int>(array.size()));
    }

    static LongBuffer wrap(const std::vector<std::int64_t>& array, int offset, int length) {
        if (offset < 0 || length < 0) {
            throw std::invalid_argument("Negative offset or length");
        }
        if (static_cast<std::size_t>(offset) + static_cast<std::size_t>(length) > array.size()) {
            throw std::out_of_range("Offset plus length exceeds array size");
        }

        LongBuffer result;
        result.data_ = array;
        result.capacity_ = static_cast<int>(array.size());
        result.position_ = offset;
        result.limit_ = offset + length;
        return result;
    }

    static LongBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("Negative capacity");
        }

        LongBuffer result;
        result.data_.assign(static_cast<std::size_t>(capacity), 0);
        result.capacity_ = capacity;
        result.position_ = 0;
        result.limit_ = capacity;
        return result;
    }

private:
    LongBuffer() = default;

    std::vector<std::int64_t> data_;
    int capacity_ = 0;
    int position_ = 0;
    int limit_ = 0;
};

void wrap_test_8208() {
std::vector<std::int64_t> longArray1 = { 1 };
    try {
        LongBuffer longBuffer4 = LongBuffer::wrap(longArray1, 2, 100);
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    assert(longArray1 == std::vector<std::int64_t>{ 1 });
}
