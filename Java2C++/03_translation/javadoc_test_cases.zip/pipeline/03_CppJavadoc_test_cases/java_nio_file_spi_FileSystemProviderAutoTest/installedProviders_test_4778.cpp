#include <cassert>
#include <typeinfo>
#include <vector>

class FileSystemProvider {
public:
    virtual ~FileSystemProvider() = default;
    using InstalledProviders = std::vector<FileSystemProvider*>;

    static InstalledProviders installedProviders() {
        return {};
    }
};


void installedProviders_test_4778() {
auto fileSystemProviderList0 = FileSystemProvider::installedProviders();
// auto wildcardClass1 = typeid(fileSystemProviderList0);  // FIXME: API not available in skeleton
assert(fileSystemProviderList0.size() > 0);
// removed: assertNotNull(wildcardClass1)
}
