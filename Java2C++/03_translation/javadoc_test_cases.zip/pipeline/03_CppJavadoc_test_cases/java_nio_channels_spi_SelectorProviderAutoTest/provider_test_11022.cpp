#include <cassert>
#include <mutex>

class SelectorProvider {
public:
    static SelectorProvider& provider() {
        static SelectorProvider instance;
        return instance;
    }

    SelectorProvider(const SelectorProvider&) = delete;
    SelectorProvider& operator=(const SelectorProvider&) = delete;

private:
    SelectorProvider() = default;
};

void provider_test_11022() {
SelectorProvider& selectorProvider0 = SelectorProvider::provider();
    // removed (null check not needed in C++)
    // removed (null check not needed in C++)
}
