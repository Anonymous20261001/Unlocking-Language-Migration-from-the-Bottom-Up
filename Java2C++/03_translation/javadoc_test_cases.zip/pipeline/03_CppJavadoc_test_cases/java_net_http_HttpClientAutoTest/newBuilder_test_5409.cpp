#include <cassert>
class HttpClient {
public:
    class Builder {
    public:
        Builder() {}
    };

    static Builder newBuilder() {
        return Builder();
    }

    static HttpClient newHttpClient() {
        return HttpClient();
    }

    HttpClient() {}
};


void newBuilder_test_5409() {
HttpClient::Builder builder0 = HttpClient::newBuilder();
// HttpClient httpClient1 = builder0.build();  // FIXME: API not available in skeleton
// HttpClient httpClient2 = builder0.build();  // FIXME: API not available in skeleton
// HttpClient httpClient3 = builder0.build();  // FIXME: API not available in skeleton
// HttpClient httpClient4 = builder0.build();  // assert(!=) - operator!= not available  // assert(!=) - operator!= not available  // assert(!=) - operator!= not available  // assert(!=) - operator!= not available  // assert(!=) - operator!= not available  // FIXME: API not available in skeleton
}
