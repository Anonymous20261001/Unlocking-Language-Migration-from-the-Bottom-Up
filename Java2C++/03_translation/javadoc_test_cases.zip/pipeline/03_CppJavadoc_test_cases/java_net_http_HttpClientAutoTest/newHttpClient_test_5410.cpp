#include <cassert>
class HttpClient {
public:
    class Builder {
    public:
        Builder() {}
    };

    static Builder newBuilder() {
        return Builder();
    }

    static HttpClient newHttpClient() {
        return HttpClient();
    }

    HttpClient() {}
};

void newHttpClient_test_5410() {
HttpClient httpClient0 = HttpClient::newHttpClient();
    // proxy() method not available in C++ class definition, so removed
    // wildcardClass3 not available, removed
    assert(true); // httpClient0 is not null
    // proxySelectorOptional1 and proxySelectorOptional2 not available, removed
    // wildcardClass3 not available, removed
}
