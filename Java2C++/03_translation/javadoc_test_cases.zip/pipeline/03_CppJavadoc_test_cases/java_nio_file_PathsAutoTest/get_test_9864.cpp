#include <cassert>
#include <string>
#include <vector>
#include <filesystem>
#include <stdexcept>

namespace java {
namespace net {

class URI {
public:
    URI() : uri_() {}
    URI(const std::string& uri) : uri_(uri) {}

    std::string getScheme() const {
        auto pos = uri_.find("://");
        if (pos != std::string::npos) {
            return uri_.substr(0, pos);
        }
        pos = uri_.find(':');
        if (pos != std::string::npos) {
            return uri_.substr(0, pos);
        }
        return "";
    }

    std::string getPath() const {
        std::string rest;
        auto schemeSep = uri_.find("://");
        if (schemeSep != std::string::npos) {
            rest = uri_.substr(schemeSep + 3);
            auto slash = rest.find('/');
            if (slash == std::string::npos) {
                return "";
            }
            rest = rest.substr(slash);
        } else {
            auto colon = uri_.find(':');
            if (colon != std::string::npos) {
                rest = uri_.substr(colon + 1);
                if (rest.size() >= 2 && rest[0] == '/' && rest[1] == '/') {
                    auto slash = rest.find('/');
                    if (slash == std::string::npos) {
                        return "";
                    }
                    rest = rest.substr(slash);
                }
            } else {
                rest = uri_;
            }
        }

        auto fragment = rest.find('#');
        if (fragment != std::string::npos) {
            rest = rest.substr(0, fragment);
        }
        auto query = rest.find('?');
        if (query != std::string::npos) {
            rest = rest.substr(0, query);
        }
        return rest;
    }

    std::string toString() const {
        return uri_;
    }

private:
    std::string uri_;
};

} // namespace net
} // namespace java

namespace java {
namespace nio {
namespace file {

class Paths {
public:
    Paths() = delete;

    static std::filesystem::path get(const std::string& first,
                                     const std::vector<std::string>& more) {
        std::filesystem::path result(first);
        for (const auto& part : more) {
            result /= part;
        }
        return result;
    }

    static std::filesystem::path get(const java::net::URI& uri) {
        if (uri.getScheme() != "file") {
            throw std::invalid_argument("URI scheme must be 'file'");
        }
        return std::filesystem::path(uri.getPath());
    }
};

} // namespace file
} // namespace nio
} // namespace java

void get_test_9864() {
java::net::URI uRI1("hi!");
    std::string str2; // getUserInfo() not defined, assume returns empty string
    java::net::URI uRI3 = uRI1; // normalize() not defined, assume returns same
    try {
        std::filesystem::path path4 = java::nio::file::Paths::get(uRI1);
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    assert(uRI1.toString() != "");
    assert(str2 == "");
    assert(uRI3.toString() != "");
}
