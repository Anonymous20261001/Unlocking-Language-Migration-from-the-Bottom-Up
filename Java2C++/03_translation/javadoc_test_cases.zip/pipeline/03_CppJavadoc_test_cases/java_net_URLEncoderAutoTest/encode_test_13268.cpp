#include <cassert>
#include <string>
#include <cctype>
#include <cstdio>

class Charset {
public:
    explicit Charset(const std::string& name) : name_(name) {}

    static Charset forName(const std::string& name) {
        return Charset(name);
    }

    static Charset defaultCharset() {
        return Charset("UTF-8");
    }

    const std::string& name() const {
        return name_;
    }

private:
    std::string name_;
};

class URLEncoder {
public:
    static std::string encode(const std::string& s) {
        return encode(s, Charset::defaultCharset());
    }

    static std::string encode(const std::string& s, const Charset& charset) {
        std::string result;
        for (unsigned char c : s) {
            if (std::isalnum(c)) {
                result += static_cast<char>(c);
            } else if (c == '.' || c == '-' || c == '_' || c == '*') {
                result += static_cast<char>(c);
            } else if (c == ' ') {
                result += '+';
            } else {
                char buf[4];
                std::snprintf(buf, sizeof(buf), "%%%02X", c);
                result += buf;
            }
        }
        return result;
    }
};

void encode_test_13268() {
Charset charset1 = Charset::defaultCharset();
    // strSet2 and strSet4 are not used in C++ (no aliases method)
    std::string str3 = URLEncoder::encode("hi%2521", charset1);
    assert(str3 == "hi%252521");
}
