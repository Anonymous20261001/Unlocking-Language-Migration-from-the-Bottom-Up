#include <cassert>
#include <string>

class CertStore {
public:
    static std::string getDefaultType() {
        return "LDAP";
    }
};

void getDefaultType_test_2105() {
std::string str0 = CertStore::getDefaultType();
    assert(str0 == "LDAP");
}
