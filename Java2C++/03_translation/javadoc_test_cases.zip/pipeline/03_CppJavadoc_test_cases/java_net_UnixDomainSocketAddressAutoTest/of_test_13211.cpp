#include <cassert>
#include <filesystem>
#include <string>
#include <utility>
#include <vector>

class UnixDomainSocketAddress {
public:
    static UnixDomainSocketAddress of(const std::filesystem::path& path) {
        return UnixDomainSocketAddress(path.string());
    }

    static UnixDomainSocketAddress of(const std::string& pathname) {
        return UnixDomainSocketAddress(pathname);
    }

private:
    explicit UnixDomainSocketAddress(std::string path)
        : path_(std::move(path)) {}

    std::string path_;
};

void of_test_13211() {
std::vector<std::string> strArray1;
std::filesystem::path path2 = std::filesystem::path("");
int int3 = path2.filename().string().empty() ? 0 : 1;
UnixDomainSocketAddress unixDomainSocketAddress4 = UnixDomainSocketAddress::of(path2);
assert(strArray1.empty());
assert(path2.empty());
assert(int3 == 1);
}
