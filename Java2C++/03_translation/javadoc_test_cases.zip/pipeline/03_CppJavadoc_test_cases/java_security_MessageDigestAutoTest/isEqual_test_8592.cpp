#include <cassert>
#include <cstdint>
#include <vector>

using byte = std::uint8_t;

class MessageDigest {
public:
    static bool isEqual(const std::vector<byte>& digesta, const std::vector<byte>& digestb) {
        if (digesta.size() != digestb.size()) {
            return false;
        }

        int result = 0;
        for (std::size_t i = 0; i < digesta.size(); ++i) {
            result |= static_cast<int>(digesta[i]) ^ static_cast<int>(digestb[i]);
        }

        return result == 0;
    }
};

void isEqual_test_8592() {
std::vector<byte> byteArray0 = {};
    std::vector<byte> byteArray1 = {};
    bool boolean2 = MessageDigest::isEqual(byteArray0, byteArray1);
    // removed (null check not needed in C++)
    assert(byteArray0.size() == 0);
    // removed (null check not needed in C++)
    assert(byteArray1.size() == 0);
    assert(boolean2 == true);
    // removed (null check not needed in C++)
}
