#include <cassert>
class Configuration {};
class ClassLoader {};
class List {};
class Function {};

class ModuleLayer {
public:
    static ModuleLayer empty() { return ModuleLayer(); }
    static ModuleLayer boot() { return ModuleLayer(); }
    static ModuleLayer defineModules(Configuration, List, Function) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithOneLoader(Configuration, List, ClassLoader) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithManyLoaders(Configuration, List, ClassLoader) { return ModuleLayer(); }
};

void defineModules_test_8998() {
Configuration configuration0 = Configuration();
ModuleLayer moduleLayer1 = ModuleLayer::empty();
List moduleLayerList2 = List();
Function strFunction3 = Function();
try {
    ModuleLayer::defineModules(configuration0, moduleLayerList2, strFunction3);
} catch (...) {
}
assert(true);
assert(true);
}
