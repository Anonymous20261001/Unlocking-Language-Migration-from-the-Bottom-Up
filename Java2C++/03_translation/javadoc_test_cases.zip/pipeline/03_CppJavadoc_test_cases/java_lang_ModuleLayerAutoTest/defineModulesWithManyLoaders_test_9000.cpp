#include <cassert>
#include <vector>
class Configuration {};
class ClassLoader {};
class List {};
class Function {};

class ModuleLayer {
public:
    static ModuleLayer empty() { return ModuleLayer(); }
    static ModuleLayer boot() { return ModuleLayer(); }
    static ModuleLayer defineModules(Configuration, List, Function) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithOneLoader(Configuration, List, ClassLoader) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithManyLoaders(Configuration, List, ClassLoader) { return ModuleLayer(); }
};


void defineModulesWithManyLoaders_test_9000() {
Configuration configuration0 = Configuration();
ModuleLayer moduleLayer1 = ModuleLayer::boot();
// std::vector<ModuleLayer> moduleLayerList2 = moduleLayer1.parents();  // FIXME: API not available in skeleton
ClassLoader classLoader3 = ClassLoader();
try {
// ModuleLayer::Controller controller4 = ModuleLayer::defineModulesWithManyLoaders(configuration0, moduleLayerList2, classLoader3);  // FIXME: API not available in skeleton
} catch (...) {
    // Expected exception.
}
// removed
// removed
}
