class Configuration {};
class ClassLoader {};
class List {};
class Function {};

class ModuleLayer {
public:
    static ModuleLayer empty() { return ModuleLayer(); }
    static ModuleLayer boot() { return ModuleLayer(); }
    static ModuleLayer defineModules(Configuration, List, Function) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithOneLoader(Configuration, List, ClassLoader) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithManyLoaders(Configuration, List, ClassLoader) { return ModuleLayer(); }
};

void empty_test_8996() {
    ModuleLayer::empty();
}
