#include <cassert>
#include <string>
#include <vector>

class Color {
public:
    Color() = default;
};

class Rectangle {
public:
    Rectangle() = default;
};

class Shape {
public:
    virtual ~Shape() = default;
};

class Image {
public:
    Image() = default;
};

class MenuComponent {
public:
    virtual ~MenuComponent() = default;
};

class MenuBar : public MenuComponent {
public:
    MenuBar() = default;
};

class Frame {
public:
    Frame() {
        frames_.push_back(this);
    }

    std::string getTitle() const {
        return title_;
    }

    void setTitle(const std::string& p0) {
        title_ = p0;
    }

    static std::vector<Frame*>& getFrames() {
        return frames_;
    }

    int getExtendedState() const {
        return extendedState_;
    }

    MenuBar* getMenuBar() const {
        return menuBar_;
    }

    void setMenuBar(MenuBar* p0) {
        menuBar_ = p0;
    }

    void setResizable(bool p0) {
        resizable_ = p0;
    }

    bool isResizable() const {
        return resizable_;
    }

    void setShape(Shape* p0) {
        shape_ = p0;
    }

    void setOpacity(float p0) {
        opacity_ = p0;
    }

    void setIconImage(Image* p0) {
        iconImage_ = p0;
    }

    void setMaximizedBounds(Rectangle* p0) {
        maximizedBounds_ = p0;
    }

    void setExtendedState(int p0) {
        extendedState_ = p0;
    }

    bool isUndecorated() const {
        return undecorated_;
    }

    Image* getIconImage() const {
        return iconImage_;
    }

    Rectangle* getMaximizedBounds() const {
        return maximizedBounds_;
    }

    int getCursorType() const {
        return cursorType_;
    }

    void setBackground(Color* p0) {
        background_ = p0;
    }

    void addNotify() {
    }

    void removeNotify() {
    }

    void* getAccessibleContext() {
        return nullptr;
    }

    void setCursor(int p0) {
        cursor_ = p0;
    }

    void setUndecorated(bool p0) {
        undecorated_ = p0;
    }

    void remove(MenuComponent* p0) {
        (void)p0;
    }

    int getState() const {
        return state_;
    }

    void setState(int p0) {
        state_ = p0;
    }

private:
    std::string title_;
    int extendedState_ = 0;
    MenuBar* menuBar_ = nullptr;
    bool resizable_ = true;
    Shape* shape_ = nullptr;
    float opacity_ = 1.0f;
    Image* iconImage_ = nullptr;
    Rectangle* maximizedBounds_ = nullptr;
    bool undecorated_ = false;
    int cursorType_ = 0;
    Color* background_ = nullptr;
    int cursor_ = 0;
    int state_ = 0;
    static std::vector<Frame*> frames_;
};

std::vector<Frame*> Frame::frames_;

void getFrames_test_5047() {
std::vector<Frame*>& frameArray0 = Frame::getFrames();
assert(frameArray0.empty());
}
