#include <cassert>
#include <typeinfo>
#include <set>

class StackWalker {
public:
    enum class Option {
        RETAIN_CLASS_REFERENCE,
        SHOW_HIDDEN_FRAMES,
        DECLARING_CLASS
    };

    using Set = std::set<Option>;

    static StackWalker getInstance(Option option) {
        (void)option;
        return StackWalker();
    }

    static StackWalker getInstance(Set options) {
        (void)options;
        return StackWalker();
    }

    static StackWalker getInstance(Set options, int estimate) {
        (void)options;
        (void)estimate;
        return StackWalker();
    }

    static StackWalker getInstance() {
        return StackWalker();
    }

    StackWalker() = default;
    ~StackWalker() = default;
};


void getInstance_test_11457() {
StackWalker stackWalker0 = StackWalker::getInstance();
std::type_info const& wildcardClass1 = typeid(stackWalker0);  // assert(==) - operator== not available
// removed: assertNotNull(wildcardClass1)
}
