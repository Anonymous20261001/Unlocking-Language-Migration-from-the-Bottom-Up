#include <cassert>
#include <set>

class StackWalker {
public:
    enum class Option {
        RETAIN_CLASS_REFERENCE,
        SHOW_HIDDEN_FRAMES,
        DECLARING_CLASS
    };

    using Set = std::set<Option>;

    static StackWalker getInstance(Option option) {
        (void)option;
        return StackWalker();
    }

    static StackWalker getInstance(Set options) {
        (void)options;
        return StackWalker();
    }

    static StackWalker getInstance(Set options, int estimate) {
        (void)options;
        (void)estimate;
        return StackWalker();
    }

    static StackWalker getInstance() {
        return StackWalker();
    }

    StackWalker() = default;
    ~StackWalker() = default;
};

void getInstance_test_11455() {
StackWalker::Option option0 = StackWalker::Option::SHOW_HIDDEN_FRAMES;
StackWalker stackWalker1 = StackWalker::getInstance(option0);
StackWalker::Option optionArray2[1] = { option0 };
StackWalker::Option optionArray3[1][1] = { { option0 } };
std::set<StackWalker::Option*> optionArraySet4 = { optionArray3[0] };
assert(option0 == StackWalker::Option::SHOW_HIDDEN_FRAMES);
// removed
// removed
assert(optionArray2[0] == StackWalker::Option::SHOW_HIDDEN_FRAMES);
// removed
// removed
}
