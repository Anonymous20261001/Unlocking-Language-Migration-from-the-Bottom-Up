#include <cassert>
#include <set>
#include <string>
#include <vector>

class StackWalker {
public:
    enum class Option {
        RETAIN_CLASS_REFERENCE,
        SHOW_HIDDEN_FRAMES,
        DECLARING_CLASS
    };

    using Set = std::set<Option>;

    static StackWalker getInstance(Option option) {
        (void)option;
        return StackWalker();
    }

    static StackWalker getInstance(Set options) {
        (void)options;
        return StackWalker();
    }

    static StackWalker getInstance(Set options, int estimate) {
        (void)options;
        (void)estimate;
        return StackWalker();
    }

    static StackWalker getInstance() {
        return StackWalker();
    }

    StackWalker() = default;
    ~StackWalker() = default;
};

void getInstance_test_11456() {
std::set<StackWalker::Option> optionSet0;
std::vector<StackWalker::Option> objArray1(optionSet0.begin(), optionSet0.end());
std::string str2 = "[]";
StackWalker stackWalker4 = StackWalker::getInstance(optionSet0, (int)' ');
assert(objArray1.empty());
assert(str2 == "[]");
}
