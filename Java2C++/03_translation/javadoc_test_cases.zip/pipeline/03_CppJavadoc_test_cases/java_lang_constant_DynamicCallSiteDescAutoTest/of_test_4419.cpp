#include <cassert>
#include <string>
#include <vector>

class ConstantDesc {
public:
    virtual ~ConstantDesc() = default;
};

class DirectMethodHandleDesc : public ConstantDesc {
public:
    DirectMethodHandleDesc() = default;
};

class MethodTypeDesc : public ConstantDesc {
public:
    MethodTypeDesc() = default;
};

class DynamicCallSiteDesc {
public:
    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2, const std::vector<ConstantDesc*>& p3) {
        return DynamicCallSiteDesc();
    }

    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, MethodTypeDesc* p1) {
        return DynamicCallSiteDesc();
    }

    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2) {
        return DynamicCallSiteDesc();
    }

private:
    DynamicCallSiteDesc() = default;
};

void of_test_4419() {
DirectMethodHandleDesc* directMethodHandleDesc0 = nullptr;
    MethodTypeDesc* methodTypeDesc2 = nullptr;
    try {
        DynamicCallSiteDesc dynamicCallSiteDesc3 = DynamicCallSiteDesc::of(directMethodHandleDesc0, "hi!", methodTypeDesc2);
    } catch (...) {
        // Expected exception.
    }
}
