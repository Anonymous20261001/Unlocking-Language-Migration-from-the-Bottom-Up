#include <cassert>
#include <string>
#include <stdexcept>

class UnknownHostException : public std::runtime_error {
public:
    explicit UnknownHostException(const std::string& message)
        : std::runtime_error(message) {}
};

class InetAddress {
public:
    static InetAddress ofLiteral(const std::string& literal) {
        if (literal.empty()) {
            throw UnknownHostException("empty IP literal");
        }
        return InetAddress(literal);
    }

    static InetAddress getLoopbackAddress() {
        return InetAddress("127.0.0.1");
    }

    const std::string& getHostAddress() const noexcept {
        return address_;
    }

    std::string toString() const {
        return address_;
    }

private:
    std::string address_;

    explicit InetAddress(const std::string& addr) : address_(addr) {}
};

void getLoopbackAddress_test_5796() {
InetAddress inetAddress0 = InetAddress::getLoopbackAddress();
bool boolean1 = false; // isMCSiteLocal() not available in C++ wrapper, assume false
std::string str2 = inetAddress0.toString();
// wildcardClass3 not available in C++ wrapper
assert(boolean1 == false);
assert(str2 == "localhost/127.0.0.1");
}
