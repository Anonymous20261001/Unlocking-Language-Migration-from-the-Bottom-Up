#include <cassert>
#include <vector>
#include <string>
#include <utility>

class ModuleFinder {
public:
    ModuleFinder() = default;
};

class Configuration {
public:
    Configuration() = default;

    static Configuration empty() {
        return Configuration();
    }

    static Configuration resolve(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }

    static Configuration resolveAndBind(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }
};

using List = std::vector<Configuration>;
using Collection = std::vector<std::string>;


void empty_test_2903() {
Configuration configuration0 = Configuration::empty();
  // assert using .toString() — not available
  // assert using .toString() — not available
  // assert using .toString() — not available
}
