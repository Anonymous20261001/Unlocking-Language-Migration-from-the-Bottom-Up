#include <cassert>
#include <vector>
#include <string>
#include <utility>

class ModuleFinder {
public:
    ModuleFinder() = default;
};

class Configuration {
public:
    Configuration() = default;

    static Configuration empty() {
        return Configuration();
    }

    static Configuration resolve(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }

    static Configuration resolveAndBind(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }
};

using List = std::vector<Configuration>;
using Collection = std::vector<std::string>;


void resolveAndBind_test_2905() {
try {
// Configuration::resolveAndBind(nullptr, nullptr, nullptr, nullptr);  // FIXME: API not available in skeleton
} catch (...) {
    // Expected exception.
}
}
