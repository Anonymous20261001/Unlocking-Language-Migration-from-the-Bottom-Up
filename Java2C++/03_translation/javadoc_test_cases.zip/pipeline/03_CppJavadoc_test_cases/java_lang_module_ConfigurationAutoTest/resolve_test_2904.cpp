#include <cassert>
#include <vector>
#include <string>
#include <utility>

class ModuleFinder {
public:
    ModuleFinder() = default;
};

class Configuration {
public:
    Configuration() = default;

    static Configuration empty() {
        return Configuration();
    }

    static Configuration resolve(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }

    static Configuration resolveAndBind(
        ModuleFinder before,
        std::vector<Configuration> parents,
        ModuleFinder after,
        std::vector<std::string> roots
    ) {
        (void)before;
        (void)parents;
        (void)after;
        (void)roots;
        return Configuration();
    }
};

using List = std::vector<Configuration>;
using Collection = std::vector<std::string>;

void resolve_test_2904() {
ModuleFinder moduleFinder0;
    List configurationList1;
    ModuleFinder moduleFinder2;
    Collection strCollection3;
    try {
        Configuration configuration4 = Configuration::resolve(moduleFinder0, configurationList1, moduleFinder2, strCollection3);
    } catch (...) {
    }
}
