#include <cassert>
#include <memory>
#include <string>
#include <vector>

class Locale {
public:
    Locale() = default;
    Locale(const std::string& language, const std::string& country = "", const std::string& variant = "")
        : language_(language), country_(country), variant_(variant) {}

    const std::string& getLanguage() const { return language_; }
    const std::string& getCountry() const { return country_; }
    const std::string& getVariant() const { return variant_; }

private:
    std::string language_;
    std::string country_;
    std::string variant_;
};

class BreakIterator {
private:
    BreakIterator() = default;

public:
    static std::vector<Locale> getAvailableLocales() {
        std::vector<Locale> locales;
        locales.push_back(Locale("en", "US"));
        locales.push_back(Locale("fr", "FR"));
        locales.push_back(Locale("de", "DE"));
        locales.push_back(Locale("ja", "JP"));
        locales.push_back(Locale("zh", "CN"));
        return locales;
    }

    static std::unique_ptr<BreakIterator> getWordInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getWordInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getLineInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getLineInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getCharacterInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getCharacterInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getSentenceInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getSentenceInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }
};

void getWordInstance_test_1880() {
Locale locale0("ko", "KR");
Locale locale1 = locale0;
auto breakIterator2 = BreakIterator::getWordInstance(locale0);
std::string str3 = locale0.getLanguage();
assert(locale0.getLanguage() == "ko");
assert(locale0.getCountry() == "KR");
assert(locale1.getLanguage() == "ko");
assert(locale1.getCountry() == "KR");
assert(breakIterator2 != nullptr);
assert(str3 == "");
}
