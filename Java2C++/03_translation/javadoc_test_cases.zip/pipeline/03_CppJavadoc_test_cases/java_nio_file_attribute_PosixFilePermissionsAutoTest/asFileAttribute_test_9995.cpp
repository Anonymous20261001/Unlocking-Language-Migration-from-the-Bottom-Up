#include <cassert>
#include <cstddef>
#include <set>
#include <stdexcept>
#include <string>

enum class PosixFilePermission {
    OWNER_READ,
    OWNER_WRITE,
    OWNER_EXECUTE,
    GROUP_READ,
    GROUP_WRITE,
    GROUP_EXECUTE,
    OTHERS_READ,
    OTHERS_WRITE,
    OTHERS_EXECUTE
};

template <typename T>
struct FileAttribute {
    std::string name;
    T value;
};

class PosixFilePermissions {
public:
    static FileAttribute<std::set<PosixFilePermission>> asFileAttribute(
        const std::set<PosixFilePermission>& perms) {
        return FileAttribute<std::set<PosixFilePermission>>{"posix:permissions", perms};
    }

    static std::set<PosixFilePermission> fromString(const std::string& s) {
        if (s.length() != 9) {
            throw std::invalid_argument("Permission string must be 9 characters long: " + s);
        }

        std::set<PosixFilePermission> result;

        for (std::size_t i = 0; i < 9; ++i) {
            char c = s[i];
            if (c == '-') {
                continue;
            }

            PosixFilePermission perm;

            switch (i) {
                case 0: perm = PosixFilePermission::OWNER_READ; break;
                case 1: perm = PosixFilePermission::OWNER_WRITE; break;
                case 2: perm = PosixFilePermission::OWNER_EXECUTE; break;
                case 3: perm = PosixFilePermission::GROUP_READ; break;
                case 4: perm = PosixFilePermission::GROUP_WRITE; break;
                case 5: perm = PosixFilePermission::GROUP_EXECUTE; break;
                case 6: perm = PosixFilePermission::OTHERS_READ; break;
                case 7: perm = PosixFilePermission::OTHERS_WRITE; break;
                case 8: perm = PosixFilePermission::OTHERS_EXECUTE; break;
                default: throw std::invalid_argument("Invalid permission index");
            }

            switch (c) {
                case 'r':
                case 'w':
                case 'x':
                    result.insert(perm);
                    break;
                default:
                    throw std::invalid_argument("Illegal permission character: " + std::string(1, c));
            }
        }

        return result;
    }
};

void asFileAttribute_test_9995() {
std::set<PosixFilePermission> posixFilePermissionSet0;
posixFilePermissionSet0.clear();
FileAttribute<std::set<PosixFilePermission>> posixFilePermissionSetFileAttribute2 = PosixFilePermissions::asFileAttribute(posixFilePermissionSet0);
// removed (null check not needed in C++)
// removed (null check not needed in C++)
assert(posixFilePermissionSet0.empty());
// removed (null check not needed in C++)
assert(posixFilePermissionSet0.empty());
}
