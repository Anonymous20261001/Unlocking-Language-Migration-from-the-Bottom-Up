#include <cassert>
#include <vector>

class Object {};
class Class {};
class MethodHandle {};
class MethodType {};
class ByteOrder {};
class List {};

class VarHandle {
public:
  enum class AccessMode {
    GET,
    SET,
    GET_AND_SET,
    GET_AND_ADD,
    GET_AND_BITWISE_OR,
    GET_AND_BITWISE_AND,
    GET_AND_BITWISE_XOR,
    COMPARE_AND_SET,
    COMPARE_AND_EXCHANGE,
    COMPARE_AND_EXCHANGE_ACQUIRE,
    COMPARE_AND_EXCHANGE_RELEASE,
    WEAK_COMPARE_AND_SET_PLAIN,
    WEAK_COMPARE_AND_SET,
    WEAK_COMPARE_AND_SET_ACQUIRE,
    WEAK_COMPARE_AND_SET_RELEASE
  };
};

class MethodHandles {
public:
  class Lookup {};

  static MethodHandle throwException(Class, Class) { return {}; }
  static Lookup lookup() { return {}; }
  static MethodHandle empty(MethodType) { return {}; }
  static MethodHandle constant(Class, Object) { return {}; }
  static MethodHandle identity(Class) { return {}; }
  static MethodHandle spreadInvoker(MethodType, int) { return {}; }
  static MethodHandle arrayLength(Class) { return {}; }
  static MethodHandle varHandleInvoker(VarHandle::AccessMode, MethodType) { return {}; }
  static Lookup publicLookup() { return {}; }
  static MethodHandle tryFinally(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle loop(std::vector<std::vector<MethodHandle>>) { return {}; }
  static MethodHandle tableSwitch(MethodHandle, std::vector<MethodHandle>) { return {}; }
  static MethodHandle arrayConstructor(Class) { return {}; }
  static MethodHandle exactInvoker(MethodType) { return {}; }
  static MethodHandle foldArguments(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle foldArguments(MethodHandle, int, MethodHandle) { return {}; }
  static MethodHandle invoker(MethodType) { return {}; }
  static Object reflectAs(Class, MethodHandle) { return {}; }
  static MethodHandle zero(Class) { return {}; }
  static MethodHandle dropArgumentsToMatch(MethodHandle, int, List, int) { return {}; }
  static MethodHandle dropArguments(MethodHandle, int, List) { return {}; }
  static MethodHandle dropArguments(MethodHandle, int, std::vector<Class>) { return {}; }
  static MethodHandle countedLoop(MethodHandle, MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle countedLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle permuteArguments(MethodHandle, MethodType, std::vector<int>) { return {}; }
  static VarHandle filterValue(VarHandle, MethodHandle, MethodHandle) { return {}; }
  static VarHandle filterCoordinates(VarHandle, int, std::vector<MethodHandle>) { return {}; }
  static VarHandle insertCoordinates(VarHandle, int, std::vector<Object>) { return {}; }
  static VarHandle permuteCoordinates(VarHandle, List, std::vector<int>) { return {}; }
  static VarHandle collectCoordinates(VarHandle, int, MethodHandle) { return {}; }
  static VarHandle dropCoordinates(VarHandle, int, std::vector<Class>) { return {}; }
  static MethodHandle arrayElementGetter(Class) { return {}; }
  static MethodHandle arrayElementSetter(Class) { return {}; }
  static VarHandle arrayElementVarHandle(Class) { return {}; }
  static VarHandle byteArrayViewVarHandle(Class, ByteOrder) { return {}; }
  static VarHandle byteBufferViewVarHandle(Class, ByteOrder) { return {}; }
  static MethodHandle varHandleExactInvoker(VarHandle::AccessMode, MethodType) { return {}; }
  static MethodHandle explicitCastArguments(MethodHandle, MethodType) { return {}; }
  static MethodHandle insertArguments(MethodHandle, int, std::vector<Object>) { return {}; }
  static MethodHandle dropReturn(MethodHandle) { return {}; }
  static MethodHandle filterArguments(MethodHandle, int, std::vector<MethodHandle>) { return {}; }
  static MethodHandle collectArguments(MethodHandle, int, MethodHandle) { return {}; }
  static MethodHandle filterReturnValue(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle guardWithTest(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle catchException(MethodHandle, Class, MethodHandle) { return {}; }
  static MethodHandle whileLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle doWhileLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle iteratedLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
};

void filterArguments_test_8914() {
MethodHandle* methodHandle0 = nullptr;
    std::vector<MethodHandle> methodHandleArray2 = {};
    try {
        MethodHandle methodHandle3 = MethodHandles::filterArguments(*methodHandle0, 4, methodHandleArray2);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    assert(methodHandleArray2.size() == 0);
}
