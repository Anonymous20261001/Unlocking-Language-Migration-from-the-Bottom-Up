#include <cassert>
#include <vector>
#include <stdexcept>
#include <string>

class Permission {
public:
    virtual ~Permission() = default;
    virtual bool implies(const Permission&) const { return false; }
};

class ProtectionDomain {
public:
    virtual ~ProtectionDomain() = default;
};

class DomainCombiner {
public:
    virtual ~DomainCombiner() = default;
};

class AccessControlException : public std::runtime_error {
public:
    explicit AccessControlException(const std::string& message)
        : std::runtime_error(message) {}
};

class AccessControlContext {
public:
    AccessControlContext(const std::vector<ProtectionDomain*>& context)
        : domains(context) {}

    DomainCombiner* getDomainCombiner() const {
        return nullptr;
    }

    void checkPermission(Permission* perm) const {
        if (perm == nullptr) {
            throw std::invalid_argument("Null permission");
        }
    }

private:
    std::vector<ProtectionDomain*> domains;
};

void checkPermission_test_26() {
std::vector<ProtectionDomain*> protectionDomainArray0;
    AccessControlContext accessControlContext1(protectionDomainArray0);
    Permission* permission2 = nullptr;
    try {
        accessControlContext1.checkPermission(permission2);
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    assert(protectionDomainArray0.empty());
}
