#include <cassert>
#include <vector>
#include <set>

class Class {
public:
    bool operator<(const Class& other) const {
        return this < &other;
    }
};

class PlatformManagedObject {
public:
    virtual ~PlatformManagedObject() = default;
};

class ClassLoadingMXBean : public PlatformManagedObject {};
class MemoryMXBean : public PlatformManagedObject {};
class ThreadMXBean : public PlatformManagedObject {};
class RuntimeMXBean : public PlatformManagedObject {};
class CompilationMXBean : public PlatformManagedObject {};
class OperatingSystemMXBean : public PlatformManagedObject {};
class MemoryPoolMXBean : public PlatformManagedObject {};
class MemoryManagerMXBean : public PlatformManagedObject {};
class GarbageCollectorMXBean : public MemoryManagerMXBean {};
class MBeanServer {};

class ManagementFactory {
public:
    ManagementFactory() = delete;

    template<typename T = PlatformManagedObject>
    static T getPlatformMXBean(Class) {
        return T();
    }

    template<typename T = PlatformManagedObject>
    static std::vector<T> getPlatformMXBeans(Class) {
        return {};
    }

    static ClassLoadingMXBean getClassLoadingMXBean() { return {}; }
    static MemoryMXBean getMemoryMXBean() { return {}; }
    static ThreadMXBean getThreadMXBean() { return {}; }
    static RuntimeMXBean getRuntimeMXBean() { return {}; }
    static CompilationMXBean getCompilationMXBean() { return {}; }
    static OperatingSystemMXBean getOperatingSystemMXBean() { return {}; }
    static std::vector<MemoryPoolMXBean> getMemoryPoolMXBeans() { return {}; }
    static std::vector<MemoryManagerMXBean> getMemoryManagerMXBeans() { return {}; }
    static std::vector<GarbageCollectorMXBean> getGarbageCollectorMXBeans() { return {}; }
    static MBeanServer getPlatformMBeanServer() { return {}; }
    static std::set<Class> getPlatformManagementInterfaces() { return {}; }
};

void getMemoryManagerMXBeans_test_8271() {
std::vector<MemoryManagerMXBean> memoryManagerMXBeanList0 = ManagementFactory::getMemoryManagerMXBeans();
    // removed: java.lang.Class<?> wildcardClass1 = memoryManagerMXBeanList0.getClass();
    // removed: assertNotNull(memoryManagerMXBeanList0);
    // removed: assertNotNull(wildcardClass1);
}
