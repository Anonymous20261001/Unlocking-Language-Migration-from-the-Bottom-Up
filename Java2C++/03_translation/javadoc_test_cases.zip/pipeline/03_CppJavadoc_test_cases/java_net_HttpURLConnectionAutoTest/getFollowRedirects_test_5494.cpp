#include <cassert>
class HttpURLConnection {
public:
    static bool followRedirects;
    static void setFollowRedirects(bool set) { followRedirects = set; }
    static bool getFollowRedirects() { return followRedirects; }
};

bool HttpURLConnection::followRedirects = true;

void getFollowRedirects_test_5494() {
bool boolean0 = HttpURLConnection::getFollowRedirects();
    assert(boolean0 == true);
}
