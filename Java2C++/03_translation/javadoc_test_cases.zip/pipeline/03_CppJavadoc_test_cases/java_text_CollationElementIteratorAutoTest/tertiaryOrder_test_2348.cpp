#include <cassert>
#include <cstdint>

class CollationElementIterator {
public:
    static int primaryOrder(int order) {
        return static_cast<int>((static_cast<uint32_t>(order) >> 16) & 0xFFFF);
    }

    static int secondaryOrder(int order) {
        return static_cast<int>((static_cast<uint32_t>(order) >> 8) & 0xFF);
    }

    static int tertiaryOrder(int order) {
        return static_cast<int>(static_cast<uint32_t>(order) & 0xFF);
    }
};

void tertiaryOrder_test_2348() {
short short1 = CollationElementIterator::tertiaryOrder(0);
    assert(short1 == (short) 0);
}
