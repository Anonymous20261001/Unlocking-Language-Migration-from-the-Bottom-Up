#include <cassert>
#include <vector>

class AccessibleObject {
public:
    AccessibleObject() : accessible(false) {}

    bool isAccessible() const {
        return accessible;
    }

    void setAccessible(bool flag) {
        accessible = flag;
    }

    static void setAccessible(std::vector<AccessibleObject*>& objects, bool flag) {
        for (AccessibleObject* obj : objects) {
            if (obj != nullptr) {
                obj->accessible = flag;
            }
        }
    }

    static void setAccessible(std::vector<AccessibleObject>& objects, bool flag) {
        for (auto& obj : objects) {
            obj.accessible = flag;
        }
    }

private:
    bool accessible;
};

void setAccessible_test_35() {
std::vector<AccessibleObject*> accessibleObjectArray0;
    AccessibleObject::setAccessible(accessibleObjectArray0, true);
    // removed (null check not needed in C++)
    assert(accessibleObjectArray0.empty());
    // removed (null check not needed in C++)
}
