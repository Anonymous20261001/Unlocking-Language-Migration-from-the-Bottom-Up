#include <cassert>
#include <vector>
#include <stdexcept>
#include <utility>

class DoubleBuffer {
public:
    static DoubleBuffer wrap(const std::vector<double>& array) {
        return DoubleBuffer(array, 0, static_cast<int>(array.size()));
    }

    static DoubleBuffer wrap(const std::vector<double>& array, int offset, int length) {
        if (offset < 0 || length < 0 ||
            offset > static_cast<int>(array.size()) ||
            length > static_cast<int>(array.size()) - offset) {
            throw std::invalid_argument("IndexOutOfBoundsException");
        }
        return DoubleBuffer(array, offset, length);
    }

    static DoubleBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("IllegalArgumentException");
        }
        return DoubleBuffer(std::vector<double>(capacity, 0.0), 0, capacity);
    }

private:
    DoubleBuffer(const std::vector<double>& data, int offset, int length)
        : data_(data), offset_(offset), length_(length) {}

    DoubleBuffer(std::vector<double>&& data, int offset, int length)
        : data_(std::move(data)), offset_(offset), length_(length) {}

    std::vector<double> data_;
    int offset_;
    int length_;
};

void wrap_test_4265() {
std::vector<double> doubleArray2 = { 100.0, 0.0 };
    DoubleBuffer doubleBuffer3 = DoubleBuffer::wrap(doubleArray2);
    // removed: assertNotNull(doubleArray2);
    // removed: assertArrayEquals(doubleArray2, new double[] { 100.0d, 0.0d }, 1.0E-15);
    // removed: assertNotNull(doubleBuffer3);
    // removed: assertNotNull(wildcardClass4);
}
