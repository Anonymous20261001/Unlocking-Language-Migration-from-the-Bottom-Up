#include <cassert>
#include <vector>
#include <stdexcept>
#include <utility>

class DoubleBuffer {
public:
    static DoubleBuffer wrap(const std::vector<double>& array) {
        return DoubleBuffer(array, 0, static_cast<int>(array.size()));
    }

    static DoubleBuffer wrap(const std::vector<double>& array, int offset, int length) {
        if (offset < 0 || length < 0 ||
            offset > static_cast<int>(array.size()) ||
            length > static_cast<int>(array.size()) - offset) {
            throw std::invalid_argument("IndexOutOfBoundsException");
        }
        return DoubleBuffer(array, offset, length);
    }

    static DoubleBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("IllegalArgumentException");
        }
        return DoubleBuffer(std::vector<double>(capacity, 0.0), 0, capacity);
    }

private:
    DoubleBuffer(const std::vector<double>& data, int offset, int length)
        : data_(data), offset_(offset), length_(length) {}

    DoubleBuffer(std::vector<double>&& data, int offset, int length)
        : data_(std::move(data)), offset_(offset), length_(length) {}

    std::vector<double> data_;
    int offset_;
    int length_;
};

void wrap_test_4266() {
std::vector<double> doubleArray1 = { 'a' };
try {
    DoubleBuffer doubleBuffer4 = DoubleBuffer::wrap(doubleArray1, (int) (short) 0, (int) 10);
    assert(false);
} catch (...) {
    // Expected exception.
}
assert(doubleArray1.size() == 1);
assert(doubleArray1[0] == 97.0);
}
