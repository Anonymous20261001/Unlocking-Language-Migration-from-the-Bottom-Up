#include <cassert>
#include <cstddef>

class CookieHandler {
public:
    virtual ~CookieHandler() = default;

    static CookieHandler* getDefault() {
        return defaultHandler;
    }

    static void setDefault(CookieHandler* handler) {
        defaultHandler = handler;
    }

private:
    static CookieHandler* defaultHandler;
};

CookieHandler* CookieHandler::defaultHandler = nullptr;

void getDefault_test_3025() {
CookieHandler* cookieHandler0 = CookieHandler::getDefault();
    assert(cookieHandler0 == nullptr);
}
