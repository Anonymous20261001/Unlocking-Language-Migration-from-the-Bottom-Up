#include <cassert>
#include <cstddef>

class Policy {
public:
    virtual ~Policy() = default;

    static void setPolicy(Policy* policy) {
        currentPolicy = policy;
    }

    static Policy* getPolicy() {
        return currentPolicy != nullptr ? currentPolicy : getDefaultPolicy();
    }

private:
    static inline Policy* currentPolicy = nullptr;

    static Policy* getDefaultPolicy() {
        static Policy defaultPolicy;
        return &defaultPolicy;
    }
};

void setPolicy_test_9965() {
Policy* policy0 = Policy::getPolicy();
// std::string str1 = policy0->getType(); // Policy has no getType()
// std::string str2 = policy0->getType(); // Policy has no getType()
Policy::setPolicy(policy0);
assert(policy0 != nullptr);
// assert(str1.empty()); // depends on str1
// assert(str2.empty()); // depends on str2
}
