#include <cassert>
#include <cstddef>

class Policy {
public:
    virtual ~Policy() = default;

    static void setPolicy(Policy* policy) {
        currentPolicy = policy;
    }

    static Policy* getPolicy() {
        return currentPolicy != nullptr ? currentPolicy : getDefaultPolicy();
    }

private:
    static inline Policy* currentPolicy = nullptr;

    static Policy* getDefaultPolicy() {
        static Policy defaultPolicy;
        return &defaultPolicy;
    }
};

void getPolicy_test_9966() {
Policy* policy0 = Policy::getPolicy();
// removed (null check not needed in C++)
// removed (null check not needed in C++)
}
