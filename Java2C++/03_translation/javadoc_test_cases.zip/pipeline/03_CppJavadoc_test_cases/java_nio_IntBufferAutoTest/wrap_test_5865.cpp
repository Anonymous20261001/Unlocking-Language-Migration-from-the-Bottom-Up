#include <cassert>
#include <vector>
#include <stdexcept>

class IntBuffer {
private:
    std::vector<int> buffer;
    int capacity_;
    int position_;
    int limit_;

    IntBuffer(const std::vector<int>& data, int capacity, int position, int limit)
        : buffer(data), capacity_(capacity), position_(position), limit_(limit) {}

public:
    static IntBuffer wrap(const std::vector<int>& array) {
        int capacity = static_cast<int>(array.size());
        return IntBuffer(array, capacity, 0, capacity);
    }

    static IntBuffer wrap(const std::vector<int>& array, int offset, int length) {
        int capacity = static_cast<int>(array.size());
        if (offset < 0 || length < 0 || offset > capacity - length) {
            throw std::invalid_argument("IndexOutOfBoundsException");
        }
        return IntBuffer(array, capacity, offset, offset + length);
    }

    static IntBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("NegativeCapacityException");
        }
        return IntBuffer(std::vector<int>(capacity, 0), capacity, 0, capacity);
    }

    int capacity() const { return capacity_; }
    int position() const { return position_; }
    int limit() const { return limit_; }
};

void wrap_test_5865() {
std::vector<int> intArray0 = std::vector<int>();
IntBuffer intBuffer1 = IntBuffer::wrap(intArray0);
try {
    IntBuffer intBuffer4 = IntBuffer::wrap(intArray0, 0, (int)(char)100);
    assert(false);
} catch (...) {
    // Expected exception.
}
// removed
assert(intArray0 == std::vector<int>());
// removed
}
