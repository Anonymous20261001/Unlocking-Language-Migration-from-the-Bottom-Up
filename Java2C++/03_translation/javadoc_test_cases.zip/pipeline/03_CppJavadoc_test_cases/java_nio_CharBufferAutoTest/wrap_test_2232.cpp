#include <cassert>
#include <vector>
#include <string>
#include <stdexcept>
#include <utility>

class CharSequence {
    std::string data_;
public:
    CharSequence() = default;
    CharSequence(const std::string& s) : data_(s) {}
    CharSequence(const char* s) : data_(s ? s : "") {}

    size_t length() const { return data_.length(); }
    char charAt(size_t index) const { return data_.at(index); }
    std::string str() const { return data_; }
};

class CharBuffer {
    std::vector<char> data_;
    int capacity_;
    int limit_;
    int position_;
    bool readOnly_;

    CharBuffer(std::vector<char> data, int capacity, int position, int limit, bool readOnly)
        : data_(std::move(data)), capacity_(capacity), limit_(limit), position_(position), readOnly_(readOnly) {}

public:
    static CharBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("Negative capacity");
        }
        std::vector<char> data(static_cast<size_t>(capacity), 0);
        return CharBuffer(std::move(data), capacity, 0, capacity, false);
    }

    static CharBuffer wrap(const CharSequence& csq) {
        std::string s = csq.str();
        std::vector<char> data(s.begin(), s.end());
        int cap = static_cast<int>(data.size());
        return CharBuffer(std::move(data), cap, 0, cap, true);
    }

    static CharBuffer wrap(const CharSequence& csq, int start, int end) {
        int len = static_cast<int>(csq.length());
        if (start < 0 || end < start || end > len) {
            throw std::out_of_range("CharBuffer.wrap bounds out of range");
        }
        std::string s = csq.str().substr(static_cast<size_t>(start), static_cast<size_t>(end - start));
        std::vector<char> data(s.begin(), s.end());
        int cap = static_cast<int>(data.size());
        return CharBuffer(std::move(data), cap, 0, cap, true);
    }

    static CharBuffer wrap(const std::vector<char>& array) {
        int cap = static_cast<int>(array.size());
        return CharBuffer(array, cap, 0, cap, false);
    }

    static CharBuffer wrap(const std::vector<char>& array, int offset, int length) {
        int cap = static_cast<int>(array.size());
        if (offset < 0 || length < 0 || offset > cap - length) {
            throw std::out_of_range("CharBuffer.wrap bounds out of range");
        }
        return CharBuffer(array, cap, offset, offset + length, false);
    }

    int capacity() const { return capacity_; }
    int limit() const { return limit_; }
    int position() const { return position_; }
    bool isReadOnly() const { return readOnly_; }
};

void wrap_test_2232() {
std::vector<char> charArray0 = {};
    CharBuffer charBuffer1 = CharBuffer::wrap(charArray0);
    try {
        CharBuffer charBuffer4 = CharBuffer::wrap(charArray0, 99, (int)'#');
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    // removed (null check not needed in C++)
    assert(charArray0.empty());
    assert(charBuffer1.capacity() == 0);
}
