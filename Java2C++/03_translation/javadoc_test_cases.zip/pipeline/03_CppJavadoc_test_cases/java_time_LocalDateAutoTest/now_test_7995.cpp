#include <cassert>
#include <string>

enum class Month {
    JANUARY = 1,
    FEBRUARY = 2,
    MARCH = 3,
    APRIL = 4,
    MAY = 5,
    JUNE = 6,
    JULY = 7,
    AUGUST = 8,
    SEPTEMBER = 9,
    OCTOBER = 10,
    NOVEMBER = 11,
    DECEMBER = 12
};

class CharSequence {
public:
    std::string value;
    CharSequence() {}
    CharSequence(const std::string& s) : value(s) {}
    CharSequence(const char* s) : value(s) {}
};

class TemporalAccessor {};
class Clock {};
class ZoneId {};
class Instant {};
class DateTimeFormatter {};

class LocalDate {
public:
    int year;
    int month;
    int day;

    LocalDate() : year(1970), month(1), day(1) {}
    LocalDate(int y, int m, int d) : year(y), month(m), day(d) {}

    static LocalDate of(int year, int month, int day) {
        return LocalDate(year, month, day);
    }

    static LocalDate of(int year, Month month, int day) {
        return LocalDate(year, static_cast<int>(month), day);
    }

    static LocalDate from(const TemporalAccessor& temporal) {
        (void)temporal;
        return LocalDate();
    }

    static LocalDate parse(const CharSequence& text) {
        (void)text;
        return LocalDate();
    }

    static LocalDate parse(const CharSequence& text, const DateTimeFormatter& formatter) {
        (void)text;
        (void)formatter;
        return LocalDate();
    }

    static LocalDate now() {
        return LocalDate();
    }

    static LocalDate now(const Clock& clock) {
        (void)clock;
        return LocalDate();
    }

    static LocalDate now(const ZoneId& zone) {
        (void)zone;
        return LocalDate();
    }

    static LocalDate ofInstant(const Instant& instant, const ZoneId& zone) {
        (void)instant;
        (void)zone;
        return LocalDate();
    }

    static LocalDate ofEpochDay(long epochDay) {
        (void)epochDay;
        return LocalDate();
    }

    static LocalDate ofYearDay(int year, int dayOfYear) {
        (void)year;
        (void)dayOfYear;
        return LocalDate();
    }
};

void now_test_7995() {
ZoneId zoneId0;
Clock clock1;
std::string str2 = "Asia/Shanghai";
std::string str3 = "Asia/Shanghai";
LocalDate localDate4 = LocalDate::now(zoneId0);
assert(str2 == "Asia/Shanghai");
assert(str3 == "Asia/Shanghai");
}
