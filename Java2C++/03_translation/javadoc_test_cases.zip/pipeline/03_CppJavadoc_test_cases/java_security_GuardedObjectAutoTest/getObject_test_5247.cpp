#include <cassert>
#include <exception>

class Object {
public:
    virtual ~Object() = default;
};

class Guard {
public:
    virtual ~Guard() = default;
    virtual void checkGuard(Object* object) = 0;
};

class GuardedObject {
private:
    Object* object_;
    Guard* guard_;

public:
    GuardedObject(Object* object, Guard* guard)
        : object_(object), guard_(guard) {}

    Object* getObject() {
        if (guard_ != nullptr) {
            guard_->checkGuard(object_);
        }
        return object_;
    }
};

void getObject_test_5247() {
Object* obj0 = new Object();
Object* wildcardClass1 = obj0;
Guard* guard2 = nullptr;
GuardedObject guardedObject3(wildcardClass1, guard2);
Object* obj4 = guardedObject3.getObject();
assert(wildcardClass1 != nullptr);
assert(obj4 != nullptr);
// removed: assertEquals(obj4.toString(), "class java.lang.Object");
}
