#include <cassert>
#include <string>
#include <vector>
#include <functional>
#include <stdexcept>

namespace java {
namespace nio {
namespace file {

class Path {
public:
    std::string path;
    Path() : path("") {}
    Path(const std::string& p) : path(p) {}
    Path(const char* p) : path(p) {}
    Path(const Path& other) : path(other.path) {}
    Path& operator=(const Path& other) { path = other.path; return *this; }
    bool operator==(const Path& other) const { return path == other.path; }
    bool operator!=(const Path& other) const { return path != other.path; }
    std::string toString() const { return path; }
};

class LinkOption {
public:
    enum Option { NOFOLLOW_LINKS };
    Option value;
    LinkOption() : value(NOFOLLOW_LINKS) {}
    LinkOption(Option v) : value(v) {}
    bool operator==(const LinkOption& other) const { return value == other.value; }
    bool operator!=(const LinkOption& other) const { return value != other.value; }
};

class Class {
public:
    std::string name;
    Class() : name("") {}
    Class(const std::string& n) : name(n) {}
    Class(const Class& other) : name(other.name) {}
    Class& operator=(const Class& other) { name = other.name; return *this; }
    bool operator==(const Class& other) const { return name == other.name; }
    bool operator!=(const Class& other) const { return name != other.name; }
    std::string getName() const { return name; }
};

class Files {
public:
    static bool exists(const Path& path, const std::vector<LinkOption>& options = {}) {
        // Simulate existence check
        return !path.path.empty();
    }

    static bool isDirectory(const Path& path, const std::vector<LinkOption>& options = {}) {
        // Simulate directory check
        return path.path.find("dir") != std::string::npos;
    }

    static bool isRegularFile(const Path& path, const std::vector<LinkOption>& options = {}) {
        // Simulate regular file check
        return path.path.find("file") != std::string::npos;
    }

    static bool notExists(const Path& path, const std::vector<LinkOption>& options = {}) {
        return !exists(path, options);
    }

    static bool isWritable(const Path& path) {
        // Simulate writable check
        return true;
    }

    static Class getFileAttributeView(const Path& path, const Class& viewType, const std::vector<LinkOption>& options = {}) {
        // Simulate returning a class
        return viewType;
    }

    static bool isSymbolicLink(const Path& path) {
        // Simulate symbolic link check
        return path.path.find("symlink") != std::string::npos;
    }

    static bool isReadable(const Path& path) {
        // Simulate readable check
        return true;
    }

    static bool isExecutable(const Path& path) {
        // Simulate executable check
        return true;
    }
};

} // namespace file
} // namespace nio
} // namespace java

// Test functions

void isReadable_test_4772() {
std::vector<std::string> strArray1;
java::nio::file::Path path2("");
java::nio::file::Path path3;
bool boolean4 = java::nio::file::Files::isReadable(path2);
assert(strArray1 == std::vector<std::string>{});
assert(path2.path == "");
assert(path3.path == "");
assert(boolean4 == true);
}
