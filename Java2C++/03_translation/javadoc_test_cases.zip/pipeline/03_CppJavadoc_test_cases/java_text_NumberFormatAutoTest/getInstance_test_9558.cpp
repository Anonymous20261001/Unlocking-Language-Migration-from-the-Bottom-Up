#include <cassert>
#include <memory>
#include <string>
#include <vector>

namespace java {
namespace util {

class Locale {
public:
    Locale(const std::string& language)
        : language_(language), country_(), variant_() {}
    Locale(const std::string& language, const std::string& country)
        : language_(language), country_(country), variant_() {}
    Locale(const std::string& language, const std::string& country, const std::string& variant)
        : language_(language), country_(country), variant_(variant) {}

    const std::string& getLanguage() const { return language_; }
    const std::string& getCountry() const { return country_; }
    const std::string& getVariant() const { return variant_; }

    static const Locale& getDefault() {
        static const Locale defaultLocale("en", "US");
        return defaultLocale;
    }

private:
    std::string language_;
    std::string country_;
    std::string variant_;
};

} // namespace util

namespace text {

class NumberFormat {
public:
    enum class Style {
        SHORT,
        LONG
    };

    virtual ~NumberFormat() = default;

    static std::shared_ptr<NumberFormat> getInstance() {
        return getInstance(java::util::Locale::getDefault());
    }

    static std::shared_ptr<NumberFormat> getInstance(const java::util::Locale& locale) {
        (void)locale;
        return std::make_shared<NumberFormat>();
    }

    static std::vector<java::util::Locale> getAvailableLocales() {
        static const std::vector<java::util::Locale> locales = {
            java::util::Locale("en", "US"),
            java::util::Locale("de", "DE"),
            java::util::Locale("fr", "FR")
        };
        return locales;
    }

    static std::shared_ptr<NumberFormat> getCurrencyInstance() {
        return getCurrencyInstance(java::util::Locale::getDefault());
    }

    static std::shared_ptr<NumberFormat> getCurrencyInstance(const java::util::Locale& locale) {
        (void)locale;
        return std::make_shared<NumberFormat>();
    }

    static std::shared_ptr<NumberFormat> getPercentInstance() {
        return getPercentInstance(java::util::Locale::getDefault());
    }

    static std::shared_ptr<NumberFormat> getPercentInstance(const java::util::Locale& locale) {
        (void)locale;
        return std::make_shared<NumberFormat>();
    }

    static std::shared_ptr<NumberFormat> getIntegerInstance() {
        return getIntegerInstance(java::util::Locale::getDefault());
    }

    static std::shared_ptr<NumberFormat> getIntegerInstance(const java::util::Locale& locale) {
        (void)locale;
        return std::make_shared<NumberFormat>();
    }

    static std::shared_ptr<NumberFormat> getCompactNumberInstance() {
        return getCompactNumberInstance(java::util::Locale::getDefault(), Style::SHORT);
    }

    static std::shared_ptr<NumberFormat> getCompactNumberInstance(const java::util::Locale& locale, Style style) {
        (void)locale;
        (void)style;
        return std::make_shared<NumberFormat>();
    }

    static std::shared_ptr<NumberFormat> getNumberInstance() {
        return getNumberInstance(java::util::Locale::getDefault());
    }

    static std::shared_ptr<NumberFormat> getNumberInstance(const java::util::Locale& locale) {
        (void)locale;
        return std::make_shared<NumberFormat>();
    }
};

} // namespace text
} // namespace java

using java::text::NumberFormat;
using java::util::Locale;

void getInstance_test_9558() {
// removed: java::text::AttributedCharacterIterator::Attribute attribute0 = java::text::AttributedCharacterIterator::Attribute::LANGUAGE;
    java::text::NumberFormat::Style style1 = java::text::NumberFormat::Style::SHORT;
    // removed: boolean boolean2 = attribute0.equals((java.lang.Object) style1);
    std::shared_ptr<NumberFormat> numberFormat3 = NumberFormat::getInstance();
    // removed: boolean boolean4 = attribute0.equals((java.lang.Object) numberFormat3);
    // removed: assert(attribute0 != nullptr);
    assert(style1 == java::text::NumberFormat::Style::SHORT);
    // removed: assert(boolean2 == false);
    assert(numberFormat3 != nullptr);
    // removed: assert(boolean4 == false);
}
