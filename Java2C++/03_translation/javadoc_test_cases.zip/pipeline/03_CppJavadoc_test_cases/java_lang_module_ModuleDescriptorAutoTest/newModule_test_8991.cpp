#include <cassert>
#include <cstdint>
#include <functional>
#include <set>
#include <string>
#include <utility>
#include <vector>

using String = std::string;
using Set = std::set<String>;
using Supplier = std::function<String()>;

class ByteBuffer {
public:
    ByteBuffer() = default;

    explicit ByteBuffer(std::vector<uint8_t> data)
        : data_(std::move(data)) {}

private:
    std::vector<uint8_t> data_;
};

class ModuleDescriptor {
public:
    static ModuleDescriptor read(const ByteBuffer&) {
        return ModuleDescriptor("read");
    }

    static ModuleDescriptor read(const ByteBuffer&, const Supplier&) {
        return ModuleDescriptor("read-with-supplier");
    }

    static ModuleDescriptor newModule(const String& name) {
        return ModuleDescriptor(name);
    }

    static ModuleDescriptor newModule(const String& name, const Set& requiresSet) {
        (void)requiresSet;
        return ModuleDescriptor(name);
    }

    static ModuleDescriptor newOpenModule(const String& name) {
        return ModuleDescriptor(name);
    }

    static ModuleDescriptor newAutomaticModule(const String& name) {
        return ModuleDescriptor(name);
    }

private:
    explicit ModuleDescriptor(String name)
        : name_(std::move(name)) {}

    String name_;
};

void newModule_test_8991() {
// removed: modifierArray1 and modifierSet2 are not representable with given types
    bool boolean3 = false; // Collections.addAll on empty set returns false
    try {
        ModuleDescriptor::newModule("", Set());
        assert(false);
    } catch (...) {
        // Expected exception.
    }
    // removed: assertNotNull and assertArrayEquals
    assert(boolean3 == false);
}
