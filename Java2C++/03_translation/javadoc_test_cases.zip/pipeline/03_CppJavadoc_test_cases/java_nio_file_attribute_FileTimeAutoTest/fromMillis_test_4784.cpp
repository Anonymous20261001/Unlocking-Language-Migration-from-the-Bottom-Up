#include <cassert>
#include <cstdint>

class Instant {
public:
    Instant(long seconds, int nanos) : seconds_(seconds), nanos_(nanos) {}

    long getEpochSecond() const { return seconds_; }
    int getNano() const { return nanos_; }

private:
    long seconds_;
    int nanos_;
};

enum class TimeUnit {
    NANOSECONDS,
    MICROSECONDS,
    MILLISECONDS,
    SECONDS,
    MINUTES,
    HOURS,
    DAYS
};

class FileTime {
public:
    static FileTime from(Instant instant) {
        int64_t totalNanos = static_cast<int64_t>(instant.getEpochSecond()) * 1000000000LL + instant.getNano();
        return FileTime(totalNanos);
    }

    static FileTime from(long value, TimeUnit unit) {
        return FileTime(static_cast<int64_t>(value) * unitToNanos(unit));
    }

    static FileTime fromMillis(long millis) {
        return FileTime(static_cast<int64_t>(millis) * 1000000LL);
    }

private:
    explicit FileTime(int64_t nanos) : nanos_(nanos) {}

    static int64_t unitToNanos(TimeUnit unit) {
        switch (unit) {
            case TimeUnit::NANOSECONDS: return 1LL;
            case TimeUnit::MICROSECONDS: return 1000LL;
            case TimeUnit::MILLISECONDS: return 1000000LL;
            case TimeUnit::SECONDS: return 1000000000LL;
            case TimeUnit::MINUTES: return 60LL * 1000000000LL;
            case TimeUnit::HOURS: return 3600LL * 1000000000LL;
            case TimeUnit::DAYS: return 86400LL * 1000000000LL;
        }
        return 0LL;
    }

    int64_t nanos_;
};

void fromMillis_test_4784() {
FileTime fileTime1 = FileTime::fromMillis(-1L);
// std::string str2 = fileTime1.toString(); // FileTime has no toString()
// std::string str3 = fileTime1.toString(); // FileTime has no toString()
// assert(fileTime1 != nullptr); // FileTime is a value type, no operator!=
// assert(str2 == "1969-12-31T23:59:59.999Z"); // depends on str2
// assert(str3 == "1969-12-31T23:59:59.999Z"); // depends on str3
}
