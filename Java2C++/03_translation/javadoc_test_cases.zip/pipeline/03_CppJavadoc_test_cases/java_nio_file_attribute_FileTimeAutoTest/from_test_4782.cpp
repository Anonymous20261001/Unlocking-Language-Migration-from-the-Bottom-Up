#include <cassert>
#include <cstdint>

class Instant {
public:
    Instant(long seconds, int nanos) : seconds_(seconds), nanos_(nanos) {}

    long getEpochSecond() const { return seconds_; }
    int getNano() const { return nanos_; }

private:
    long seconds_;
    int nanos_;
};

enum class TimeUnit {
    NANOSECONDS,
    MICROSECONDS,
    MILLISECONDS,
    SECONDS,
    MINUTES,
    HOURS,
    DAYS
};

class FileTime {
public:
    static FileTime from(Instant instant) {
        int64_t totalNanos = static_cast<int64_t>(instant.getEpochSecond()) * 1000000000LL + instant.getNano();
        return FileTime(totalNanos);
    }

    static FileTime from(long value, TimeUnit unit) {
        return FileTime(static_cast<int64_t>(value) * unitToNanos(unit));
    }

    static FileTime fromMillis(long millis) {
        return FileTime(static_cast<int64_t>(millis) * 1000000LL);
    }

private:
    explicit FileTime(int64_t nanos) : nanos_(nanos) {}

    static int64_t unitToNanos(TimeUnit unit) {
        switch (unit) {
            case TimeUnit::NANOSECONDS: return 1LL;
            case TimeUnit::MICROSECONDS: return 1000LL;
            case TimeUnit::MILLISECONDS: return 1000000LL;
            case TimeUnit::SECONDS: return 1000000000LL;
            case TimeUnit::MINUTES: return 60LL * 1000000000LL;
            case TimeUnit::HOURS: return 3600LL * 1000000000LL;
            case TimeUnit::DAYS: return 86400LL * 1000000000LL;
        }
        return 0LL;
    }

    int64_t nanos_;
};

void from_test_4782() {
Instant instant0 = Instant(31556889864403199L, 999999999);
Instant instant2 = Instant(instant0.getEpochSecond() - 1, instant0.getNano());
FileTime fileTime3 = FileTime::from(instant2);
// removed
// removed
// removed
// removed
}
