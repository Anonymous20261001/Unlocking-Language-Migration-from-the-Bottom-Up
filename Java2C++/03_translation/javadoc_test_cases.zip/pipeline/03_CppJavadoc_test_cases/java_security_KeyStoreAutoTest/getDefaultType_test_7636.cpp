#include <cassert>
#include <string>

class KeyStore {
public:
    static std::string getDefaultType() {
        return "pkcs12";
    }
};

void getDefaultType_test_7636() {
std::string str0 = KeyStore::getDefaultType();
    assert(str0 == "pkcs12");
}
