#include <atomic>
#include <string>
#include <functional>
#include <cstdint>
#include <cstring>
#include <sstream>
#include <cassert>

class AtomicLong {
private:
    std::atomic<int64_t> value;

public:
    // Constructors
    AtomicLong() noexcept : value(0) {}
    explicit AtomicLong(int64_t initialValue) noexcept : value(initialValue) {}

    // Basic get/set
    int64_t get() const noexcept {
        return value.load(std::memory_order_seq_cst);
    }
    void set(int64_t newValue) noexcept {
        value.store(newValue, std::memory_order_seq_cst);
    }

    // Number conversion methods
    int32_t intValue() const noexcept {
        return static_cast<int32_t>(value.load(std::memory_order_seq_cst));
    }
    int64_t longValue() const noexcept {
        return value.load(std::memory_order_seq_cst);
    }
    float floatValue() const noexcept {
        return static_cast<float>(value.load(std::memory_order_seq_cst));
    }
    double doubleValue() const noexcept {
        return static_cast<double>(value.load(std::memory_order_seq_cst));
    }

    // toString
    std::string toString() const {
        std::ostringstream oss;
        oss << value.load(std::memory_order_seq_cst);
        return oss.str();
    }

    // Opaque operations (relaxed order)
    int64_t getOpaque() const noexcept {
        return value.load(std::memory_order_relaxed);
    }
    void setOpaque(int64_t newValue) noexcept {
        value.store(newValue, std::memory_order_relaxed);
    }

    // Acquire/Release operations
    int64_t getAcquire() const noexcept {
        return value.load(std::memory_order_acquire);
    }
    void setRelease(int64_t newValue) noexcept {
        value.store(newValue, std::memory_order_release);
    }

    // Plain operations (like volatile, use relaxed for simplicity)
    int64_t getPlain() const noexcept {
        return value.load(std::memory_order_relaxed);
    }
    void setPlain(int64_t newValue) noexcept {
        value.store(newValue, std::memory_order_relaxed);
    }

    // Compare-and-set (strong version)
    bool compareAndSet(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
    }

    // Compare-and-exchange (returns old value)
    int64_t compareAndExchange(int64_t expected, int64_t newValue) noexcept {
        value.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
        return expected;
    }
    int64_t compareAndExchangeAcquire(int64_t expected, int64_t newValue) noexcept {
        value.compare_exchange_strong(expected, newValue, std::memory_order_acquire);
        return expected;
    }
    int64_t compareAndExchangeRelease(int64_t expected, int64_t newValue) noexcept {
        value.compare_exchange_strong(expected, newValue, std::memory_order_release);
        return expected;
    }

    // Weak compare-and-set variants
    bool weakCompareAndSetPlain(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_weak(expected, newValue, std::memory_order_relaxed, std::memory_order_relaxed);
    }
    bool weakCompareAndSet(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }
    bool weakCompareAndSetAcquire(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_weak(expected, newValue, std::memory_order_acquire, std::memory_order_relaxed);
    }
    bool weakCompareAndSetRelease(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_weak(expected, newValue, std::memory_order_release, std::memory_order_relaxed);
    }
    bool weakCompareAndSetVolatile(int64_t expected, int64_t newValue) noexcept {
        return value.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    // getAndSet
    int64_t getAndSet(int64_t newValue) noexcept {
        return value.exchange(newValue, std::memory_order_seq_cst);
    }

    // getAndAdd and addAndGet
    int64_t getAndAdd(int64_t delta) noexcept {
        return value.fetch_add(delta, std::memory_order_seq_cst);
    }
    int64_t addAndGet(int64_t delta) noexcept {
        return value.fetch_add(delta, std::memory_order_seq_cst) + delta;
    }

    // increment/decrement
    int64_t incrementAndGet() noexcept {
        return value.fetch_add(1, std::memory_order_seq_cst) + 1;
    }
    int64_t decrementAndGet() noexcept {
        return value.fetch_sub(1, std::memory_order_seq_cst) - 1;
    }
    int64_t getAndIncrement() noexcept {
        return value.fetch_add(1, std::memory_order_seq_cst);
    }
    int64_t getAndDecrement() noexcept {
        return value.fetch_sub(1, std::memory_order_seq_cst);
    }

    // lazySet (implemented with release order, similar to Java)
    void lazySet(int64_t newValue) noexcept {
        value.store(newValue, std::memory_order_release);
    }

    // Functional update methods
    int64_t getAndUpdate(const std::function<int64_t(int64_t)>& updater) {
        int64_t old = value.load(std::memory_order_seq_cst);
        int64_t newVal;
        do {
            newVal = updater(old);
        } while (!value.compare_exchange_weak(old, newVal, std::memory_order_seq_cst));
        return old;
    }

    int64_t updateAndGet(const std::function<int64_t(int64_t)>& updater) {
        int64_t old = value.load(std::memory_order_seq_cst);
        int64_t newVal;
        do {
            newVal = updater(old);
        } while (!value.compare_exchange_weak(old, newVal, std::memory_order_seq_cst));
        return newVal;
    }

    int64_t getAndAccumulate(int64_t x, const std::function<int64_t(int64_t, int64_t)>& accumulator) {
        int64_t old = value.load(std::memory_order_seq_cst);
        int64_t newVal;
        do {
            newVal = accumulator(old, x);
        } while (!value.compare_exchange_weak(old, newVal, std::memory_order_seq_cst));
        return old;
    }

    int64_t accumulateAndGet(int64_t x, const std::function<int64_t(int64_t, int64_t)>& accumulator) {
        int64_t old = value.load(std::memory_order_seq_cst);
        int64_t newVal;
        do {
            newVal = accumulator(old, x);
        } while (!value.compare_exchange_weak(old, newVal, std::memory_order_seq_cst));
        return newVal;
    }
};

// ==================== TEST FUNCTIONS ====================

void getAndDecrement_test_4842() {
    AtomicLong instance{1};
    int64_t long2 = instance.getAndDecrement();
    int64_t long3 = instance.getAndDecrement();
    assert(long2 == 1L && "long2 != 1L");
    assert(long3 == 0L && "long3 != 0L");
}