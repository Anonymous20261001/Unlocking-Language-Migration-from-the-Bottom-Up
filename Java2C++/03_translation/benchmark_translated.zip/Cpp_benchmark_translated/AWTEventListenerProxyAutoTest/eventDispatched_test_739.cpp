#include <cstdint>
#include <iostream>
#include <stdexcept>

namespace awt {

class AWTEvent {
public:
    virtual ~AWTEvent() = default;
};

class AWTEventListener {
public:
    virtual ~AWTEventListener() = default;
    virtual void eventDispatched(AWTEvent* event) = 0;  // changed to pointer to allow null
};

class AWTEventListenerProxy : public AWTEventListener {
public:
    AWTEventListenerProxy(int64_t eventMask, AWTEventListener* listener)
        : m_eventMask(eventMask), m_listener(listener) {}

    int64_t getEventMask() const { return m_eventMask; }

    void eventDispatched(AWTEvent* event) override {
        if (!m_listener) {
            throw std::runtime_error(
                "Cannot invoke \"awt::AWTEventListener.eventDispatched(awt::AWTEvent)\" "
                "because the return value of \"awt::AWTEventListenerProxy.getListener()\" is null");
        }
        m_listener->eventDispatched(event);
    }

private:
    int64_t m_eventMask;
    AWTEventListener* m_listener;
};

} // namespace awt

// Translated test function
void eventDispatched_test_739() {
    awt::AWTEventListener* aWTEventListener1 = nullptr;
    awt::AWTEventListenerProxy aWTEventListenerProxy2(0L, aWTEventListener1);
    awt::AWTEvent* aWTEvent3 = nullptr;
    try {
        aWTEventListenerProxy2.eventDispatched(aWTEvent3);
        // If no exception, fail the test
        std::cerr << "Expected exception of type std::runtime_error" << std::endl;
        // In a real test framework, we'd call an assertion macro.
        // Here we just print and exit with error.
        std::exit(1);
    } catch (const std::runtime_error& e) {
        // Expected exception.
        std::cout << "Caught expected exception: " << e.what() << std::endl;
    }
}