#include <cassert>
#include <cstddef> // for nullptr

// Forward declarations
class EditorKit;

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
    // No other members needed for the test
};

// JTextComponent inherits from JComponent
class JTextComponent : public JComponent {
public:
    // No additional methods needed for the test
};

// BasicEditorPaneUI – mimics the Swing class
class BasicEditorPaneUI {
public:
    // Instance methods
    EditorKit* getEditorKit(JTextComponent* p0) {
        // Returning nullptr because the test doesn't check the value
        return nullptr;
    }

    void installUI(JComponent* p0) {
        // No operation (stub)
    }

    void uninstallUI(JComponent* p0) {
        // No operation (stub)
    }

    // Static method – creates a new instance
    static BasicEditorPaneUI* createUI(JComponent* p0) {
        // In the real Swing implementation this might return a shared instance,
        // but for the test we just allocate a new object.
        return new BasicEditorPaneUI();
    }

    virtual ~BasicEditorPaneUI() = default;
};

// Minimal EditorKit definition (needed only for the return type of getEditorKit)
class EditorKit {
public:
    virtual ~EditorKit() = default;
};

// ===== Test functions (translated from Java @Test methods) =====

void createUI_test_8730() {
    JComponent* jComponent0 = nullptr;
    BasicEditorPaneUI* componentUI1 = BasicEditorPaneUI::createUI(jComponent0);
    assert(componentUI1 != nullptr);
    delete componentUI1;  // Avoid memory leak – optional but good practice.
}