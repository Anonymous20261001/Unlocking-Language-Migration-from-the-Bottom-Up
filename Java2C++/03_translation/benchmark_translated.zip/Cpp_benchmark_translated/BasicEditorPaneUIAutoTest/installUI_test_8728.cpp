#include <cstddef>   // for nullptr
#include <stdexcept> // for std::runtime_error
#include <iostream>  // for std::cerr
#include <cstdlib>   // for std::abort

// Forward declarations
class EditorKit;

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
    // No other members needed for the test
};

// JTextComponent inherits from JComponent
class JTextComponent : public JComponent {
public:
    // No additional methods needed for the test
};

// BasicEditorPaneUI – mimics the Swing class
class BasicEditorPaneUI {
public:
    // Instance methods
    EditorKit* getEditorKit(JTextComponent* p0) {
        // Returning nullptr because the test doesn't check the value
        return nullptr;
    }

    void installUI(JComponent* p0) {
        // In the real Swing implementation, if p0 is null or not a JTextComponent, an Error is thrown.
        if (p0 == nullptr) {
            throw std::runtime_error("TextUI needs JTextComponent");
        }
        // No operation (stub)
    }

    void uninstallUI(JComponent* p0) {
        // No operation (stub)
    }

    // Static method – creates a new instance
    static BasicEditorPaneUI* createUI(JComponent* p0) {
        // In the real Swing implementation this might return a shared instance,
        // but for the test we just allocate a new object.
        return new BasicEditorPaneUI();
    }

    virtual ~BasicEditorPaneUI() = default;
};

// Minimal EditorKit definition (needed only for the return type of getEditorKit)
class EditorKit {
public:
    virtual ~EditorKit() = default;
};

// ===== Test function (translated from Java @Test) =====

void installUI_test_8728() {
    BasicEditorPaneUI instance;
    JComponent* jComponent3 = nullptr;
    try {
        instance.installUI(jComponent3);
        // If no exception, test fails
        std::cerr << "Expected exception of type std::exception with message: TextUI needs JTextComponent" << std::endl;
        std::abort();
    } catch (const std::exception& e) {
        // Expected exception: verify message (optional, but check for correctness)
        if (std::string(e.what()) != "TextUI needs JTextComponent") {
            std::cerr << "Unexpected exception message: " << e.what() << std::endl;
            std::abort();
        }
    }
}