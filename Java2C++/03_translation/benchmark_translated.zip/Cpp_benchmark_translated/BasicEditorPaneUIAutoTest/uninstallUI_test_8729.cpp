#include <cstddef> // for nullptr
#include <stdexcept> // for std::runtime_error

// Forward declarations
class EditorKit;

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
    // No other members needed for the test
};

// JTextComponent inherits from JComponent
class JTextComponent : public JComponent {
public:
    // No additional methods needed for the test
};

// BasicEditorPaneUI – mimics the Swing class
class BasicEditorPaneUI {
public:
    // Instance methods
    EditorKit* getEditorKit(JTextComponent* p0) {
        // Returning nullptr because the test doesn't check the value
        return nullptr;
    }

    void installUI(JComponent* p0) {
        // No operation (stub)
    }

    void uninstallUI(JComponent* p0) {
        // No operation (stub)
    }

    // Static method – creates a new instance
    static BasicEditorPaneUI* createUI(JComponent* p0) {
        return new BasicEditorPaneUI();
    }

    virtual ~BasicEditorPaneUI() = default;
};

// Minimal EditorKit definition (needed only for the return type of getEditorKit)
class EditorKit {
public:
    virtual ~EditorKit() = default;
};

// ===== Test functions (translated from Java @Test methods) =====

void uninstallUI_test_8729() {
    BasicEditorPaneUI instance;
    bool caught = false;
    try {
        instance.uninstallUI(nullptr);
    } catch (...) {
        caught = true;
    }
    if (!caught) {
        throw std::runtime_error("Expected exception of type NullPointerException but none was thrown");
    }
}