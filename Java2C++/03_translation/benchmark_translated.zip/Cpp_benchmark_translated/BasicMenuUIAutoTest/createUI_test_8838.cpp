#include <cstddef>
#include <cassert>

// Forward declaration
class JComponent;

// Simple Dimension class to mimic java.awt.Dimension
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Minimal JComponent class (like javax.swing.JComponent)
class JComponent {
public:
    // No members needed for the test stubs
};

// BasicMenuUI class mimicking javax.swing.plaf.basic.BasicMenuUI
class BasicMenuUI {
public:
    // Static factory method (returns a new instance, caller owns the pointer)
    static BasicMenuUI* createUI(JComponent* c) {
        return new BasicMenuUI();
    }

    // Instance methods
    Dimension getMaximumSize(JComponent* c) {
        return Dimension();  // default (0,0)
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();  // default (0,0)
    }
};

// Translated test function (exact name as in Java @Test method)
void createUI_test_8838() {
    JComponent* jComponent0 = nullptr;
    BasicMenuUI* componentUI1 = BasicMenuUI::createUI(jComponent0);
    assert(componentUI1 != nullptr);
    delete componentUI1;
}