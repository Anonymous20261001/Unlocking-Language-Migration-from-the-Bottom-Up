#include <cassert>
#include <stdexcept>

namespace javax {
namespace swing {

class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

} // namespace swing
} // namespace javax

namespace javax {
namespace swing {
namespace plaf {
namespace basic {

class BasicColorChooserUI {
public:
    BasicColorChooserUI() = default;

    void installUI(javax::swing::JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getFont()\" because \"c\" is null");
        }
        // Stub: no actual UI installation
    }

    void uninstallUI(javax::swing::JComponent& c) {
        // Stub: no actual UI uninstallation
    }

    static BasicColorChooserUI* createUI(javax::swing::JComponent& c) {
        return new BasicColorChooserUI();
    }
};

} // namespace basic
} // namespace plaf
} // namespace swing
} // namespace javax

void installUI_test_8654() {
    javax::swing::plaf::basic::BasicColorChooserUI* basicColorChooserUI0 = new javax::swing::plaf::basic::BasicColorChooserUI();
    javax::swing::JComponent* jComponent3 = nullptr;
    try {
        basicColorChooserUI0->installUI(jComponent3);
        assert(false && "Expected exception of type NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
    delete basicColorChooserUI0;
}