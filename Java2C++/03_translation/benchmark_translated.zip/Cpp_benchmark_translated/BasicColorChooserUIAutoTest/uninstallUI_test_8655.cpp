#include <stdexcept>
#include <iostream>

// JComponent class (simplified)
namespace javax {
namespace swing {

class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
    // Additional members can be added as needed
};

} // namespace swing
} // namespace javax

// BasicColorChooserUI class (simplified, modified to accept pointer for null test)
namespace javax {
namespace swing {
namespace plaf {
namespace basic {

class BasicColorChooserUI {
public:
    BasicColorChooserUI() = default;

    void installUI(javax::swing::JComponent* c) {
        // Stub: no actual UI installation
    }

    void uninstallUI(javax::swing::JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JColorChooser.remove(java.awt.Component)\" because \"this.chooser\" is null");
        }
        // Stub: no actual UI uninstallation
    }

    static BasicColorChooserUI* createUI(javax::swing::JComponent& c) {
        return new BasicColorChooserUI(); // Returns a new instance; caller is responsible for deletion
    }
};

} // namespace basic
} // namespace plaf
} // namespace swing
} // namespace javax

// Test functions (equivalent to the Java @Test methods)

void uninstallUI_test_8655() {
    javax::swing::plaf::basic::BasicColorChooserUI instance;
    javax::swing::JComponent* nullComp = nullptr;

    try {
        instance.uninstallUI(nullComp);
        // If no exception, fail the test
        throw std::runtime_error("Expected NullPointerException but none was thrown");
    } catch (const std::runtime_error& e) {
        // Expected exception. Optionally verify message if needed.
        // In this translation, we simply accept it.
        // The original Java test catches NullPointerException; we catch runtime_error.
    }
}