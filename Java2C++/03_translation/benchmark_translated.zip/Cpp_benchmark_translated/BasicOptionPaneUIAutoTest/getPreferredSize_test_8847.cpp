#include <cstddef>
#include <stdexcept>

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
};

// JOptionPane extends JComponent
class JOptionPane : public JComponent {
public:
    // Additional members could be added if needed
};

// BasicOptionPaneUI with the required API stubs
class BasicOptionPaneUI {
public:
    void installUI(JComponent* /*p0*/) {
        // stub
    }

    void uninstallUI(JComponent* /*p0*/) {
        // stub
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getMinimumOptionPaneSize() {
        // stub
    }

    // Returns false as a simple stub
    bool containsCustomComponents(JOptionPane* /*p0*/) {
        return false;
    }

    void selectInitialValue(JOptionPane* /*p0*/) {
        // stub
    }

    static BasicOptionPaneUI* createUI(JComponent* /*p0*/) {
        // Leaks memory but matches the test (ignored return)
        return new BasicOptionPaneUI();
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getPreferredSize(JComponent* p0) {
        if (p0 == nullptr) {
            throw std::invalid_argument("Cannot invoke \"javax.swing.JComponent.getLayout()\" because \"c\" is null");
        }
        // stub
    }
};

// Test functions (exact names as Java @Test methods)

void getPreferredSize_test_8847() {
    BasicOptionPaneUI basicOptionPaneUI0;
    JComponent* jComponent3 = nullptr;
    try {
        basicOptionPaneUI0.getPreferredSize(jComponent3);
        // If we reach here, no exception was thrown -> test should fail
        throw std::runtime_error("Expected exception of type std::invalid_argument; message: Cannot invoke \"javax.swing.JComponent.getLayout()\" because \"c\" is null");
    } catch (const std::invalid_argument& e) {
        // Expected exception.
    }
}