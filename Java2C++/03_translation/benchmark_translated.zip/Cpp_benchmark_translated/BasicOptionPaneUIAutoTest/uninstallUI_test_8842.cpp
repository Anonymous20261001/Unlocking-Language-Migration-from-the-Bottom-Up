#include <cstddef>
#include <stdexcept>

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
};

// JOptionPane extends JComponent
class JOptionPane : public JComponent {
public:
    // Additional members could be added if needed
};

// BasicOptionPaneUI with the required API stubs
class BasicOptionPaneUI {
public:
    void installUI(JComponent* /*p0*/) {
        // stub
    }

    void uninstallUI(JComponent* p0) {
        if (p0 == nullptr) {
            throw std::logic_error("Cannot invoke \"javax.swing.JOptionPane.removeAll()\" because \"this.optionPane\" is null");
        }
        // stub
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getMinimumOptionPaneSize() {
        // stub
    }

    // Returns false as a simple stub
    bool containsCustomComponents(JOptionPane* /*p0*/) {
        return false;
    }

    void selectInitialValue(JOptionPane* /*p0*/) {
        // stub
    }

    static BasicOptionPaneUI* createUI(JComponent* /*p0*/) {
        // Leaks memory but matches the test (ignored return)
        return new BasicOptionPaneUI();
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getPreferredSize(JComponent* /*p0*/) {
        // stub
    }
};

// Test function (exact name as Java @Test method)
void uninstallUI_test_8842() {
    BasicOptionPaneUI instance;
    try {
        instance.uninstallUI(nullptr);
        // Should have thrown an exception; fail the test
        // In a real test framework we would use a macro, but here we simulate by throwing
        throw std::logic_error("Expected exception of type NullPointerException");
    } catch (const std::logic_error& e) {
        // Expected exception; check message if needed (optional)
    }
}