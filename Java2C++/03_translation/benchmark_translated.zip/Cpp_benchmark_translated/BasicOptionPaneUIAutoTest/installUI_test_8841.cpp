#include <cstddef>
#include <stdexcept>

// Minimal JComponent base class
class JComponent {
public:
    virtual ~JComponent() = default;
};

// JOptionPane extends JComponent
class JOptionPane : public JComponent {
public:
    // Additional members could be added if needed
};

// BasicOptionPaneUI with the required API stubs
class BasicOptionPaneUI {
public:
    void installUI(JComponent* p0) {
        if (p0 == nullptr) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JComponent.getFont()\" because \"c\" is null");
        }
        // stub
    }

    void uninstallUI(JComponent* /*p0*/) {
        // stub
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getMinimumOptionPaneSize() {
        // stub
    }

    // Returns false as a simple stub
    bool containsCustomComponents(JOptionPane* /*p0*/) {
        return false;
    }

    void selectInitialValue(JOptionPane* /*p0*/) {
        // stub
    }

    static BasicOptionPaneUI* createUI(JComponent* /*p0*/) {
        // Leaks memory but matches the test (ignored return)
        return new BasicOptionPaneUI();
    }

    // In Java this returns Dimension; we ignore the return for the test
    void getPreferredSize(JComponent* /*p0*/) {
        // stub
    }
};

// Test functions (exact names as Java @Test methods)
void installUI_test_8841() {
    BasicOptionPaneUI instance;
    try {
        instance.installUI(nullptr);
        throw std::logic_error("Expected exception of type java.lang.NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}