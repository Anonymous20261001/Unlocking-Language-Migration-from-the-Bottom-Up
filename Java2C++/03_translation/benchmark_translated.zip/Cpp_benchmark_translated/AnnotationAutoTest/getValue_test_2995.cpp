#include <any>
#include <string>
#include <sstream>
#include <stdexcept>

// C++ equivalent of java.text.Annotation
class Annotation {
public:
    // Constructor: stores a copy of the value
    explicit Annotation(const std::any& value) : value_(value) {}

    // Mimics Java's toString(): returns "java.text.Annotation[value=...]"
    std::string toString() const {
        std::ostringstream oss;
        oss << "java.text.Annotation[value=";
        if (value_.has_value()) {
            try {
                // Try char (java.lang.Object '4' becomes char)
                char c = std::any_cast<char>(value_);
                oss << c;
            } catch (const std::bad_any_cast&) {
                try {
                    std::string s = std::any_cast<std::string>(value_);
                    oss << s;
                } catch (const std::bad_any_cast&) {
                    try {
                        // Recursive for nested Annotation
                        Annotation a = std::any_cast<Annotation>(value_);
                        oss << a.toString();
                    } catch (const std::bad_any_cast&) {
                        // Fallback for other types
                        oss << "<non-string>";
                    }
                }
            }
        } else {
            oss << "null";
        }
        oss << "]";
        return oss.str();
    }

    // Mimics Java's getValue(): returns the stored object (by value)
    std::any getValue() const {
        return value_;
    }

private:
    std::any value_;
};

// Test function translated from Java
void getValue_test_2995() {
    Annotation annotation1('4');                     // equivalent to new java.text.Annotation((Object) '4')
    Annotation annotation2(annotation1);            // equivalent to new java.text.Annotation((Object) annotation1)
    std::any obj3 = annotation2.getValue();         // equivalent to Object obj3 = annotation2.getValue()

    // assertNotNull(obj3)
    if (!obj3.has_value()) {
        throw std::runtime_error("assertNotNull failed");
    }

    // assertEquals(obj3.toString(), "java.text.Annotation[value=4]")
    Annotation retrieved = std::any_cast<Annotation>(obj3);
    std::string obj3_str = retrieved.toString();
    if (obj3_str != "java.text.Annotation[value=4]") {
        std::ostringstream oss;
        oss << "assertEquals failed: expected \"java.text.Annotation[value=4]\" but got \"" << obj3_str << "\"";
        throw std::runtime_error(oss.str());
    }
}