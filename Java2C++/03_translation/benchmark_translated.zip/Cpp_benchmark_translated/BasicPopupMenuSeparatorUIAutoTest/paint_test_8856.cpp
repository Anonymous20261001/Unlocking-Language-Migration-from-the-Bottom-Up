#include <cstddef>
#include <stdexcept>

// Minimal Graphics class, does nothing
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

// Minimal Dimension class
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Minimal JComponent class (base for Swing components)
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// BasicPopupMenuSeparatorUI mimicking the Swing UI delegate
class BasicPopupMenuSeparatorUI {
public:
    BasicPopupMenuSeparatorUI() {}

    // Static factory method – returns a new instance
    static BasicPopupMenuSeparatorUI* createUI(JComponent* c) {
        return new BasicPopupMenuSeparatorUI();
    }

    // Paint method – throws exception if the component is null, simulating NullPointerException
    void paint(Graphics* g, JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getSize()\" because \"c\" is null");
        }
        // No painting implementation needed for the test
    }

    // Returns a dummy preferred size
    Dimension getPreferredSize(JComponent* c) {
        return Dimension(10, 10);
    }
};

// Test function matching the Java @Test method
void paint_test_8856() {
    BasicPopupMenuSeparatorUI basicPopupMenuSeparatorUI0;
    Graphics* graphics1 = nullptr;
    JComponent* jComponent2 = nullptr;

    bool exceptionCaught = false;
    try {
        basicPopupMenuSeparatorUI0.paint(graphics1, jComponent2);
    } catch (const std::runtime_error& e) {
        exceptionCaught = true;
    }

    if (!exceptionCaught) {
        throw std::runtime_error("Expected exception of type std::runtime_error; message: Cannot invoke \"javax.swing.JComponent.getSize()\" because \"c\" is null");
    }
}