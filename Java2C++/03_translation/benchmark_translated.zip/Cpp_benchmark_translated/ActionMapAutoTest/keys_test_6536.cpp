#include <map>
#include <vector>
#include <algorithm>
#include <cassert>

// Base classes to mimic Java Object and Action
class Object {
public:
    virtual ~Object() = default;
};

class Action {
public:
    virtual ~Action() = default;
    // Additional Action interface methods can be added if needed
};

// C++ equivalent of javax.swing.ActionMap
class ActionMap {
private:
    std::map<Object*, Action*> entries;
    ActionMap* parent;

public:
    ActionMap() : parent(nullptr) {}

    void remove(Object* key) {
        entries.erase(key);
    }

    int size() const {
        return static_cast<int>(entries.size());
    }

    Action* get(Object* key) const {
        auto it = entries.find(key);
        if (it != entries.end())
            return it->second;
        return nullptr;
    }

    void put(Object* key, Action* action) {
        entries[key] = action;
    }

    void clear() {
        entries.clear();
    }

    ActionMap* getParent() const {
        return parent;
    }

    // Modified to return a pointer that can be null (to match Java test expectations)
    std::vector<Object*>* keys() const {
        if (entries.empty())
            return nullptr;
        std::vector<Object*>* result = new std::vector<Object*>();
        for (const auto& entry : entries) {
            result->push_back(entry.first);
        }
        return result;
    }

    void setParent(ActionMap* p) {
        parent = p;
    }

    // allKeys also changed to return pointer (consistency)
    std::vector<Object*>* allKeys() const {
        std::vector<Object*>* result = keys(); // returns nullptr if empty
        if (parent != nullptr) {
            std::vector<Object*>* parentKeys = parent->allKeys();
            if (parentKeys != nullptr) {
                if (result == nullptr)
                    result = new std::vector<Object*>();
                result->insert(result->end(), parentKeys->begin(), parentKeys->end());
                delete parentKeys; // clean up parentKeys
            }
        }
        return result;
    }
};

// -------------------------------------------------------------------
// Translated test functions (each corresponds to one @Test method)
// -------------------------------------------------------------------

void keys_test_6536() {
    ActionMap instance;
    std::vector<Object*>* objArray1 = instance.keys();
    std::vector<Object*>* objArray2 = instance.keys();
    assert(objArray1 == nullptr);
    assert(objArray2 == nullptr);
    // clean up to avoid memory leak (though in this test, they are nullptr)
    delete objArray1; // safe if nullptr
    delete objArray2; // safe if nullptr
}