#include <map>
#include <vector>
#include <algorithm>

// Base classes to mimic Java Object and Action
class Object {
public:
    virtual ~Object() = default;
};

class Action {
public:
    virtual ~Action() = default;
    // Additional Action interface methods can be added if needed
};

// Helper class to represent a Java Double
class DoubleObject : public Object {
public:
    double value;
    DoubleObject(double v) : value(v) {}
};

// C++ equivalent of javax.swing.ActionMap
class ActionMap {
private:
    std::map<Object*, Action*> entries;
    ActionMap* parent;

public:
    ActionMap() : parent(nullptr) {}

    void remove(Object* key) {
        entries.erase(key);
    }

    int size() const {
        return static_cast<int>(entries.size());
    }

    Action* get(Object* key) const {
        auto it = entries.find(key);
        if (it != entries.end())
            return it->second;
        return nullptr;
    }

    void put(Object* key, Action* action) {
        entries[key] = action;
    }

    void clear() {
        entries.clear();
    }

    ActionMap* getParent() const {
        return parent;
    }

    std::vector<Object*> keys() const {
        std::vector<Object*> result;
        for (const auto& entry : entries) {
            result.push_back(entry.first);
        }
        return result;
    }

    void setParent(ActionMap* p) {
        parent = p;
    }

    std::vector<Object*> allKeys() const {
        std::vector<Object*> result = keys();
        if (parent != nullptr) {
            std::vector<Object*> parentKeys = parent->allKeys();
            result.insert(result.end(), parentKeys.begin(), parentKeys.end());
        }
        return result;
    }
};

// Translated test method (no parameters, following Java test semantics)
void put_test_6533() {
    ActionMap instance;
    DoubleObject key(10.0);
    Action* action = nullptr;
    instance.put(&key, action);
}