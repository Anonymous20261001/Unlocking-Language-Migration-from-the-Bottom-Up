#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <stdexcept>

// Minimal Notification base class (Java equivalent)
class Notification {
public:
    virtual ~Notification() = default;
    // In Java, Notification does not have getAttributeName().
    // We provide a virtual method returning empty string by default.
    virtual std::string getAttributeName() const {
        return "";
    }
};

// AttributeChangeNotification derived class
class AttributeChangeNotification : public Notification {
public:
    explicit AttributeChangeNotification(const std::string& attrName)
        : attributeName_(attrName) {}

    std::string getAttributeName() const override {
        return attributeName_;
    }

private:
    std::string attributeName_;
};

// AttributeChangeNotificationFilter (C++ equivalent of javax.management.AttributeChangeNotificationFilter)
class AttributeChangeNotificationFilter {
public:
    // Enable initially all attributes? In Java the constructor does nothing; the set is empty.
    // But isNotificationEnabled returns false if attribute not in set.
    // We'll start with empty set.
    AttributeChangeNotificationFilter() = default;

    // Returns true if the notification is an AttributeChangeNotification
    // and its attribute name is in the enabled set.
    // Modified to accept a pointer to allow null (as in Java test)
    bool isNotificationEnabled(const Notification* notif) const {
        if (!notif) {
            throw std::invalid_argument("Cannot invoke \"javax.management.Notification.getType()\" because \"notification\" is null");
        }
        const auto* attrNotif = dynamic_cast<const AttributeChangeNotification*>(notif);
        if (!attrNotif) {
            return false;   // not an AttributeChangeNotification
        }
        const std::string& attr = attrNotif->getAttributeName();
        return enabledAttributes_.find(attr) != enabledAttributes_.end();
    }

    // Disable a specific attribute (remove it from the set)
    void disableAttribute(const std::string& attr) {
        enabledAttributes_.erase(attr);
    }

    // Disable all attributes (clear the set)
    void disableAllAttributes() {
        enabledAttributes_.clear();
    }

    // Return a list (vector) of currently enabled attribute names
    std::vector<std::string> getEnabledAttributes() const {
        return std::vector<std::string>(enabledAttributes_.begin(), enabledAttributes_.end());
    }

private:
    std::set<std::string> enabledAttributes_;
};

// ---------- Test function (translated from Java @Test method) ----------

void isNotificationEnabled_test_5527() {
    AttributeChangeNotificationFilter attributeChangeNotificationFilter0;
    // The Java test passes a null Notification reference, expecting NullPointerException.
    // In C++, we use a null pointer; the modified method throws an exception.
    try {
        bool boolean4 = attributeChangeNotificationFilter0.isNotificationEnabled(nullptr);
        // If we reach here, no exception was thrown -> fail the test
        throw std::logic_error("Expected exception of type std::invalid_argument; message: ...");
    } catch (const std::invalid_argument& e) {
        // Expected exception. (The message content is not checked exactly, but it's present.)
    }
}