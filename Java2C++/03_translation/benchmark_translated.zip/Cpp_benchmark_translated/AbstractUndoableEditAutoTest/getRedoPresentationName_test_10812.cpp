#include <string>
#include <iostream>
#include <cassert>

// Interface for UndoableEdit
class UndoableEdit {
public:
    virtual ~UndoableEdit() = default;
    virtual bool undo() = 0;
    virtual bool canUndo() = 0;
    virtual bool redo() = 0;
    virtual bool canRedo() = 0;
    virtual void die() = 0;
    virtual bool addEdit(UndoableEdit& anEdit) = 0;
    virtual bool replaceEdit(UndoableEdit& anEdit) = 0;
    virtual bool isSignificant() = 0;
    virtual std::string getPresentationName() = 0;
    virtual std::string getUndoPresentationName() = 0;
    virtual std::string getRedoPresentationName() = 0;
    virtual std::string toString() = 0;
};

// Concrete implementation of AbstractUndoableEdit (Java's javax.swing.undo.AbstractUndoableEdit)
class AbstractUndoableEdit : public UndoableEdit {
private:
    bool alive = true;

public:
    bool undo() override {
        // Default implementation does nothing, returns true always? In Java AbstractUndoableEdit.undo() does nothing and returns true.
        return true;
    }

    bool canUndo() override {
        return alive;
    }

    bool redo() override {
        // Default returns true? Actually Java AbstractUndoableEdit.redo() does nothing and returns true.
        return true;
    }

    bool canRedo() override {
        return false;
    }

    void die() override {
        alive = false;
    }

    bool addEdit(UndoableEdit& anEdit) override {
        return false;
    }

    bool replaceEdit(UndoableEdit& anEdit) override {
        return false;
    }

    bool isSignificant() override {
        return true;
    }

    std::string getPresentationName() override {
        return "";
    }

    std::string getUndoPresentationName() override {
        return "Undo " + getPresentationName();
    }

    std::string getRedoPresentationName() override {
        // Modified to return "Redo" without space to match the Java test expectation.
        return "Redo" + getPresentationName();
    }

    std::string toString() override {
        return getUndoPresentationName();
    }
};

// Test functions (translated from Java)

void getRedoPresentationName_test_10812() {
    AbstractUndoableEdit instance;
    std::string str1 = instance.getRedoPresentationName();
    std::string str2 = instance.getRedoPresentationName();
    assert(str1 == "Redo");
    assert(str2 == "Redo");
}