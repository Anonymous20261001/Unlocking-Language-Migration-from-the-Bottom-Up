#include <string>
#include <vector>
#include <any>
#include <stdexcept>
#include <cstddef>
#include <functional>
#include <sstream>
#include <typeinfo>
#include <cassert>

// Equivalent to javax.naming.directory.BasicAttribute
class BasicAttribute {
private:
    std::string id;
    std::vector<std::any> values;
    bool ordered;

    // Helper to compare two any values (assumes only int and string are used)
    static bool any_equal(const std::any& a, const std::any& b) {
        if (a.type() != b.type()) return false;
        if (a.type() == typeid(int)) {
            return std::any_cast<int>(a) == std::any_cast<int>(b);
        }
        if (a.type() == typeid(std::string)) {
            return std::any_cast<std::string>(a) == std::any_cast<std::string>(b);
        }
        return false;
    }

    // Helper to compute hash of an any value
    static std::size_t any_hash(const std::any& a) {
        if (a.type() == typeid(int)) {
            return std::hash<int>{}(std::any_cast<int>(a));
        }
        if (a.type() == typeid(std::string)) {
            return std::hash<std::string>{}(std::any_cast<std::string>(a));
        }
        return 0;
    }

public:
    explicit BasicAttribute(const std::string& id) : id(id), ordered(true) {}

    BasicAttribute(const std::string& id, bool ordered) : id(id), ordered(ordered) {}

    // Returns the ID
    std::string getID() const { return id; }

    // Returns true if ordered
    bool isOrdered() const { return ordered; }

    // Returns the number of values
    int size() const { return static_cast<int>(values.size()); }

    // Clears all values
    void clear() { values.clear(); }

    // Adds a value at the end
    void add(const std::any& value) { values.push_back(value); }

    // Adds a value at the specified position
    void add(int index, const std::any& value) {
        if (index < 0 || index > size())
            throw std::out_of_range("Index out of bounds");
        values.insert(values.begin() + index, value);
    }

    // Removes the element at the specified index and returns the removed value
    std::any remove(int index) {
        if (index < 0 || index >= size())
            throw std::out_of_range("Index out of bounds");
        std::any old = values[index];
        values.erase(values.begin() + index);
        return old;
    }

    // Removes the first occurrence of the specified value; returns true if found
    bool remove(const std::any& value) {
        for (auto it = values.begin(); it != values.end(); ++it) {
            if (any_equal(*it, value)) {
                values.erase(it);
                return true;
            }
        }
        return false;
    }

    // Replaces the value at the specified index
    void set(int index, const std::any& value) {
        if (index < 0 || index >= size())
            throw std::out_of_range("Index out of bounds");
        values[index] = value;
    }

    // Checks if the attribute contains the specified value
    bool contains(const std::any& value) const {
        for (const auto& v : values) {
            if (any_equal(v, value))
                return true;
        }
        return false;
    }

    // Clones the attribute (deep copy)
    BasicAttribute clone() const {
        BasicAttribute cloned(id, ordered);
        cloned.values = values;
        return cloned;
    }

    // Equality check: same ID and same values (order matters)
    bool equals(const std::any& obj) const {
        if (obj.type() != typeid(BasicAttribute))
            return false;
        const BasicAttribute& other = std::any_cast<const BasicAttribute&>(obj);
        if (id != other.id) return false;
        if (values.size() != other.values.size()) return false;
        for (size_t i = 0; i < values.size(); ++i) {
            if (!any_equal(values[i], other.values[i]))
                return false;
        }
        return true;
    }

    // Hash code based on ID and values
    std::size_t hashCode() const {
        std::size_t h = std::hash<std::string>{}(id);
        for (const auto& v : values) {
            h ^= any_hash(v) + 0x9e3779b9 + (h << 6) + (h >> 2);
        }
        return h;
    }

    // String representation
    std::string toString() const {
        if (values.empty()) {
            return id + ": No values";
        }
        std::ostringstream oss;
        oss << id << ": ";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i > 0) oss << ", ";
            if (values[i].type() == typeid(int)) {
                oss << std::any_cast<int>(values[i]);
            } else if (values[i].type() == typeid(std::string)) {
                oss << "\"" << std::any_cast<std::string>(values[i]) << "\"";
            } else {
                oss << "?";
            }
        }
        return oss.str();
    }
};

// ----------------------------------------------------------------------------
// Test function (exact translation of Java @Test method)
// ----------------------------------------------------------------------------

void clone_test_5961() {
    BasicAttribute basicAttribute2(": No values", false);
    BasicAttribute obj3 = basicAttribute2.clone();
    // assertNotNull is implicitly satisfied because obj3 is a value
    assert(obj3.toString() == ": No values: No values");
}