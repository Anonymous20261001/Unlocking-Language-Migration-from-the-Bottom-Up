#include <cstddef>
#include <stdexcept>
#include <cassert>

// Dummy classes mimicking Java Swing types
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

class Dimension {
public:
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class MenuElement {
public:
    MenuElement() {}
    virtual ~MenuElement() {}
};

class BasicMenuItemUI {
public:
    BasicMenuItemUI() {}
    virtual ~BasicMenuItemUI() {}

    void installUI(JComponent* c) { /* stub */ }
    void uninstallUI(JComponent* c) { /* stub */ }

    static BasicMenuItemUI* createUI(JComponent* c) {
        return new BasicMenuItemUI(); // In Java returns ComponentUI, we return a new instance for simplicity
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    void paint(Graphics* g, JComponent* c) {
        if (g == nullptr) {
            throw std::runtime_error("Cannot invoke \"java.awt.Graphics.getFont()\" because \"g\" is null");
        }
        /* stub */
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }

    void update(Graphics* g, JComponent* c) { /* stub */ }

    MenuElement* getPath() {
        return nullptr; // In Java returns MenuElement[], we return nullptr
    }
};

// Test functions (exact translations of Java @Test methods)

void paint_test_8833() {
    BasicMenuItemUI instance;
    Graphics* g = nullptr;
    JComponent* c = nullptr;
    try {
        instance.paint(g, c);
        assert(false && "Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}