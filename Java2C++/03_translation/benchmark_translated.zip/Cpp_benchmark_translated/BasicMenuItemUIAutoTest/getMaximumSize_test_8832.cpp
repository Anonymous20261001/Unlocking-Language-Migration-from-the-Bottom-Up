#include <cstddef>
#include <stdexcept>
#include <cassert>

// Dummy classes mimicking Java Swing types
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

class Dimension {
public:
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class MenuElement {
public:
    MenuElement() {}
    virtual ~MenuElement() {}
};

class BasicMenuItemUI {
public:
    BasicMenuItemUI() {}
    virtual ~BasicMenuItemUI() {}

    void installUI(JComponent* c) { /* stub */ }
    void uninstallUI(JComponent* c) { /* stub */ }

    static BasicMenuItemUI* createUI(JComponent* c) {
        return new BasicMenuItemUI(); // In Java returns ComponentUI, we return a new instance for simplicity
    }

    Dimension getMaximumSize(JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getClientProperty(Object)\" because \"c\" is null");
        }
        return Dimension();
    }

    void paint(Graphics* g, JComponent* c) { /* stub */ }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }

    void update(Graphics* g, JComponent* c) { /* stub */ }

    MenuElement* getPath() {
        return nullptr; // In Java returns MenuElement[], we return nullptr
    }
};

// Test functions (exact translations of Java @Test methods)

void getMaximumSize_test_8832() {
    BasicMenuItemUI basicMenuItemUI0;
    JComponent* jComponent3 = nullptr;
    try {
        Dimension dimension4 = basicMenuItemUI0.getMaximumSize(jComponent3);
        // Should not reach here
        throw std::logic_error("Expected exception of type std::runtime_error; message: Cannot invoke \"javax.swing.JComponent.getClientProperty(Object)\" because \"c\" is null");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}