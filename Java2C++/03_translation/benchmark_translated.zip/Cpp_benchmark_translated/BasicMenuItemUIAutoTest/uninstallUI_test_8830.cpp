#include <cstddef>
#include <stdexcept>
#include <cassert>

// Dummy classes mimicking Java Swing types
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

class Dimension {
public:
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class MenuElement {
public:
    MenuElement() {}
    virtual ~MenuElement() {}
};

class BasicMenuItemUI {
public:
    BasicMenuItemUI() {}
    virtual ~BasicMenuItemUI() {}

    void installUI(JComponent* c) { /* stub */ }
    void uninstallUI(JComponent* c) {
        if (c == nullptr) {
            throw std::invalid_argument("Null pointer");
        }
        // stub
    }

    static BasicMenuItemUI* createUI(JComponent* c) {
        return new BasicMenuItemUI(); // In Java returns ComponentUI, we return a new instance for simplicity
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    void paint(Graphics* g, JComponent* c) { /* stub */ }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }

    void update(Graphics* g, JComponent* c) { /* stub */ }

    MenuElement* getPath() {
        return nullptr; // In Java returns MenuElement[], we return nullptr
    }
};

// Test functions (exact translations of Java @Test methods)

void uninstallUI_test_8830() {
    BasicMenuItemUI instance;
    JComponent* p0 = nullptr;
    bool exceptionCaught = false;
    try {
        instance.uninstallUI(p0);
    } catch (const std::exception& e) {
        exceptionCaught = true;
    }
    assert(exceptionCaught); // Expect exception as in Java test
}