#include <cstddef>
#include <stdexcept>
#include <cassert>

// Dummy classes mimicking Java Swing types
class Graphics {
public:
    Graphics() {}
    virtual ~Graphics() {}
};

class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

class Dimension {
public:
    int width;
    int height;
    Dimension(int w = 0, int h = 0) : width(w), height(h) {}
};

class MenuElement {
public:
    MenuElement() {}
    virtual ~MenuElement() {}
};

class BasicMenuItemUI {
public:
    BasicMenuItemUI() {}
    virtual ~BasicMenuItemUI() {}

    void installUI(JComponent* c) {
        if (c == nullptr) throw std::runtime_error("c is null");
        /* stub */
    }

    void uninstallUI(JComponent* c) { /* stub */ }

    static BasicMenuItemUI* createUI(JComponent* c) {
        return new BasicMenuItemUI();
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    void paint(Graphics* g, JComponent* c) { /* stub */ }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }

    void update(Graphics* g, JComponent* c) { /* stub */ }

    MenuElement* getPath() {
        return nullptr;
    }
};

// Test functions (exact translations of Java @Test methods)

void installUI_test_8829() {
    BasicMenuItemUI instance;
    JComponent* jComponent3 = nullptr;
    try {
        instance.installUI(jComponent3);
        // Should have thrown an exception
        assert(!"Expected exception of type NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}