#include <cstddef>
#include <stdexcept>

// Exception to simulate Java's NullPointerException
class NullPointerException : public std::exception {
public:
    const char* what() const noexcept override {
        return "NullPointerException";
    }
};

// Minimal C++ equivalent of javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicPanelUI
class BasicPanelUI {
public:
    // Public default constructor
    BasicPanelUI() = default;
    virtual ~BasicPanelUI() = default;

    // Modified to take pointer and throw on null
    void installUI(JComponent* c) {
        if (c == nullptr) {
            throw NullPointerException();
        }
        // No-op: equivalent to empty Java implementation
    }

    void uninstallUI(JComponent& c) {
        // No-op
    }

    static BasicPanelUI* createUI(JComponent& c) {
        // Simulates the Java static method that returns a new instance.
        // Memory is not managed in this test translation; in a real scenario
        // it would be cleaned up by the UI manager.
        return new BasicPanelUI();
    }

    int getBaseline(JComponent& c, int width, int height) {
        // Default baseline; in Java it returns -1 or the actual baseline.
        return 0;
    }

    // Enum matching Java's BaselineResizeBehavior
    enum BaselineResizeBehavior {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    };

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return CONSTANT_ASCENT;
    }
};

// Test function – no parameters, matches Java test semantics
void installUI_test_8848() {
    BasicPanelUI instance;
    JComponent* nullComp = nullptr;
    try {
        instance.installUI(nullComp);
        // If no exception, fail the test
        throw std::runtime_error("Expected NullPointerException was not thrown");
    } catch (const NullPointerException& e) {
        // Expected exception, test passes
    }
}