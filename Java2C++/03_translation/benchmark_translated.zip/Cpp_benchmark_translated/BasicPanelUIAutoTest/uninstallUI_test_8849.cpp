#include <cstddef>
#include <stdexcept>
#include <cassert>

// Minimal C++ equivalent of javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicPanelUI
class BasicPanelUI {
public:
    // Public default constructor
    BasicPanelUI() = default;
    virtual ~BasicPanelUI() = default;

    // Modified to accept pointer to allow null argument
    void installUI(JComponent* c) {
        if (c == nullptr)
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JComponent.getBorder()\" because \"c\" is null");
        // No-op equivalent to empty Java implementation
    }

    void uninstallUI(JComponent* c) {
        if (c == nullptr)
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JComponent.getBorder()\" because \"c\" is null");
        // No-op
    }

    static BasicPanelUI* createUI(JComponent& c) {
        // Simulates the Java static method that returns a new instance.
        // Memory is not managed in this test translation; in a real scenario
        // it would be cleaned up by the UI manager.
        return new BasicPanelUI();
    }

    int getBaseline(JComponent& c, int width, int height) {
        // Default baseline; in Java it returns -1 or the actual baseline.
        return 0;
    }

    // Enum matching Java's BaselineResizeBehavior
    enum BaselineResizeBehavior {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    };

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return CONSTANT_ASCENT;
    }
};

// Test function – one per @Test method, with identical names.
void uninstallUI_test_8849() {
    BasicPanelUI instance;
    JComponent* jComponent3 = nullptr;
    try {
        instance.uninstallUI(jComponent3);
        // If no exception was thrown, the test should fail
        assert(false && "Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}