#include <cstddef>
#include <stdexcept>
#include <cassert>

// Minimal C++ equivalent of javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicPanelUI
class BasicPanelUI {
public:
    // Public default constructor
    BasicPanelUI() = default;
    virtual ~BasicPanelUI() = default;

    void installUI(JComponent& c) {
        // No-op: equivalent to empty Java implementation
    }

    void uninstallUI(JComponent& c) {
        // No-op
    }

    static BasicPanelUI* createUI(JComponent& c) {
        // Simulates the Java static method that returns a new instance.
        // Memory is not managed in this test translation; in a real scenario
        // it would be cleaned up by the UI manager.
        return new BasicPanelUI();
    }

    int getBaseline(JComponent& c, int width, int height) {
        // Default baseline; in Java it returns -1 or the actual baseline.
        return 0;
    }

    // Enum matching Java's BaselineResizeBehavior
    enum BaselineResizeBehavior {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    };

    // Modified to accept a pointer to simulate null reference
    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* c) {
        if (c == nullptr) {
            throw std::invalid_argument("Component must be non-null");
        }
        return CONSTANT_ASCENT;
    }
};

// Translated test method – no parameters, mimics Java JUnit test
void getBaselineResizeBehavior_test_8852() {
    BasicPanelUI basicPanelUI0;
    JComponent* jComponent3 = nullptr;  // simulate null reference
    try {
        basicPanelUI0.getBaselineResizeBehavior(jComponent3);
        // If no exception, fail the test
        assert(false && "Expected exception of type std::invalid_argument");
    } catch (const std::invalid_argument& e) {
        // Expected exception: do nothing (test passes)
    }
}