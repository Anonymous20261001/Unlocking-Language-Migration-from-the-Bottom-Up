#include <cstddef>
#include <stdexcept>

// Minimal C++ equivalent of javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicPanelUI
class BasicPanelUI {
public:
    // Public default constructor
    BasicPanelUI() = default;
    virtual ~BasicPanelUI() = default;

    void installUI(JComponent& c) {
        // No-op: equivalent to empty Java implementation
    }

    void uninstallUI(JComponent& c) {
        // No-op
    }

    static BasicPanelUI* createUI(JComponent& c) {
        // Simulates the Java static method that returns a new instance.
        // Memory is not managed in this test translation; in a real scenario
        // it would be cleaned up by the UI manager.
        return new BasicPanelUI();
    }

    // Changed: accepts pointer to allow null component (as in Java)
    int getBaseline(JComponent* c, int width, int height) {
        if (c == nullptr) {
            throw std::runtime_error("Component must be non-null");
        }
        // Default baseline; in Java it returns -1 or the actual baseline.
        return 0;
    }

    // Enum matching Java's BaselineResizeBehavior
    enum BaselineResizeBehavior {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    };

    // Changed: accepts pointer to allow null component (as in Java)
    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("Component must be non-null");
        }
        return CONSTANT_ASCENT;
    }
};

// Test functions – one per @Test method, with identical names.
void getBaseline_test_8851() {
    BasicPanelUI basicPanelUI0;
    JComponent* jComponent1 = nullptr;
    try {
        int int4 = basicPanelUI0.getBaseline(jComponent1, 1, 0);
        // Should have thrown exception; fail if reached
        throw std::logic_error("Expected exception of type NullPointerException; message: Component must be non-null");
    } catch (const std::runtime_error& e) {
        // Expected exception, messages are not compared exactly
    }
}