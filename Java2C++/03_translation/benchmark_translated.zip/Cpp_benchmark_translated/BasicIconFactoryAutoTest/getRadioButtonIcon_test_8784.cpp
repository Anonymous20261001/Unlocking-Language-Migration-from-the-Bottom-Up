#include <iostream>
#include <cassert>

// Minimal Icon class to simulate javax.swing.Icon
class Icon {
public:
    virtual ~Icon() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicIconFactory
class BasicIconFactory {
public:
    static Icon* getMenuItemCheckIcon() { return nullptr; }
    static Icon* getMenuItemArrowIcon() { return nullptr; }
    static Icon* getMenuArrowIcon() { return nullptr; }
    static Icon* getCheckBoxIcon() { return nullptr; }
    static Icon* getRadioButtonIcon() { return new Icon(); }
    static Icon* getCheckBoxMenuItemIcon() { return nullptr; }
    static Icon* getRadioButtonMenuItemIcon() { return nullptr; }
    static Icon* createEmptyFrameIcon() { return nullptr; }
};

// Test function – translated from Java @Test
void getRadioButtonIcon_test_8784() {
    Icon* icon0 = BasicIconFactory::getRadioButtonIcon();
    assert(icon0 != nullptr);
    delete icon0; // clean up allocated memory
}