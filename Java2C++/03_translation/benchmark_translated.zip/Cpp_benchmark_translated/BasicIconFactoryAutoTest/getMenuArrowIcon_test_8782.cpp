#include <iostream>
#include <cassert>

struct Icon {};

class BasicIconFactory {
public:
    static Icon* getMenuItemCheckIcon() { static Icon icon; return &icon; }
    static Icon* getMenuItemArrowIcon() { static Icon icon; return &icon; }
    static Icon* getMenuArrowIcon() { static Icon icon; return &icon; }
    static Icon* getCheckBoxIcon() { static Icon icon; return &icon; }
    static Icon* getRadioButtonIcon() { static Icon icon; return &icon; }
    static Icon* getCheckBoxMenuItemIcon() { static Icon icon; return &icon; }
    static Icon* getRadioButtonMenuItemIcon() { static Icon icon; return &icon; }
    static Icon* createEmptyFrameIcon() { static Icon icon; return &icon; }
};

void getMenuArrowIcon_test_8782() {
    Icon* icon0 = BasicIconFactory::getMenuArrowIcon();
    assert(icon0 != nullptr);
}