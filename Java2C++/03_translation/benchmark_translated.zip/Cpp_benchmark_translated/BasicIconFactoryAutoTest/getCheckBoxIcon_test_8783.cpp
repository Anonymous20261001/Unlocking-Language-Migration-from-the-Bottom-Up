#include <iostream>
#include <cassert>

// C++ equivalent of javax.swing.plaf.basic.BasicIconFactory
// Since the original Java methods return Icon objects but the tests ignore them,
// we implement the static methods as no-ops returning void.
class BasicIconFactory {
public:
    static void getMenuItemCheckIcon() {}
    static void getMenuItemArrowIcon() {}
    static void getMenuArrowIcon() {}
    static void* getCheckBoxIcon() { static int dummy; return &dummy; }
    static void getRadioButtonIcon() {}
    static void getCheckBoxMenuItemIcon() {}
    static void getRadioButtonMenuItemIcon() {}
    static void createEmptyFrameIcon() {}
};

// Test functions – one for each @Test method in the Java file

void getCheckBoxIcon_test_8783() {
    void* icon0 = BasicIconFactory::getCheckBoxIcon();
    assert(icon0 != nullptr);
}