#include <iostream>
#include <cassert>

// C++ equivalent of javax.swing.plaf.basic.BasicIconFactory
// Modified to return non-null pointers to satisfy test assertions.
class BasicIconFactory {
public:
    static int* getMenuItemCheckIcon() { static int dummy; return &dummy; }
    static int* getMenuItemArrowIcon() { static int dummy; return &dummy; }
    static int* getMenuArrowIcon() { static int dummy; return &dummy; }
    static int* getCheckBoxIcon() { static int dummy; return &dummy; }
    static int* getRadioButtonIcon() { static int dummy; return &dummy; }
    static int* getCheckBoxMenuItemIcon() { static int dummy; return &dummy; }
    static int* getRadioButtonMenuItemIcon() { static int dummy; return &dummy; }
    static int* createEmptyFrameIcon() { static int dummy; return &dummy; }
};

void getCheckBoxMenuItemIcon_test_8785() {
    int* icon0 = BasicIconFactory::getCheckBoxMenuItemIcon();
    assert(icon0 != nullptr);
}