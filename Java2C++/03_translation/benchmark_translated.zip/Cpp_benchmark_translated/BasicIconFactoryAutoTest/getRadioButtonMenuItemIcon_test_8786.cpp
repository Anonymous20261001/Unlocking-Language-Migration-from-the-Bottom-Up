#include <iostream>
#include <cassert>

struct Icon {}; // minimal icon class

class BasicIconFactory {
public:
    static void getMenuItemCheckIcon() {}
    static void getMenuItemArrowIcon() {}
    static void getMenuArrowIcon() {}
    static void getCheckBoxIcon() {}
    static void getRadioButtonIcon() {}
    static void getCheckBoxMenuItemIcon() {}
    static Icon* getRadioButtonMenuItemIcon() { return &icon; }
    static void createEmptyFrameIcon() {}
private:
    static Icon icon;
};

Icon BasicIconFactory::icon;

void getRadioButtonMenuItemIcon_test_8786() {
    Icon* icon0 = BasicIconFactory::getRadioButtonMenuItemIcon();
    assert(icon0 != nullptr);
}