#include <iostream>
#include <cassert>

// Minimal Icon class for test purposes
class Icon {};

// C++ equivalent of javax.swing.plaf.basic.BasicIconFactory
class BasicIconFactory {
public:
    static Icon* getMenuItemCheckIcon() { return nullptr; }
    static Icon* getMenuItemArrowIcon() { return nullptr; }
    static Icon* getMenuArrowIcon() { return nullptr; }
    static Icon* getCheckBoxIcon() { return nullptr; }
    static Icon* getRadioButtonIcon() { return nullptr; }
    static Icon* getCheckBoxMenuItemIcon() { return nullptr; }
    static Icon* getRadioButtonMenuItemIcon() { return nullptr; }
    static Icon* createEmptyFrameIcon() {
        static Icon dummy;
        return &dummy;
    }
};

// Test functions – one for each @Test method in the Java file

void createEmptyFrameIcon_test_8787() {
    Icon* icon0 = BasicIconFactory::createEmptyFrameIcon();
    assert(icon0 != nullptr);
}