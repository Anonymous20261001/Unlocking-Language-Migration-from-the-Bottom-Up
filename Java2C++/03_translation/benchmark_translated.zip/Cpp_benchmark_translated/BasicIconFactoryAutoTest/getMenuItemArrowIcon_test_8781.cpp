#include <iostream>
#include <cassert>

// C++ equivalent of javax.swing.plaf.basic.BasicIconFactory
// Modified to return a non-null pointer to preserve assertion semantics.
class BasicIconFactory {
public:
    static const int* getMenuItemCheckIcon() { static int dummy; return &dummy; }
    static const int* getMenuItemArrowIcon() { static int dummy; return &dummy; }
    static const int* getMenuArrowIcon() { static int dummy; return &dummy; }
    static const int* getCheckBoxIcon() { static int dummy; return &dummy; }
    static const int* getRadioButtonIcon() { static int dummy; return &dummy; }
    static const int* getCheckBoxMenuItemIcon() { static int dummy; return &dummy; }
    static const int* getRadioButtonMenuItemIcon() { static int dummy; return &dummy; }
    static const int* createEmptyFrameIcon() { static int dummy; return &dummy; }
};

void getMenuItemArrowIcon_test_8781() {
    const int* icon0 = BasicIconFactory::getMenuItemArrowIcon();
    assert(icon0 != nullptr);
}