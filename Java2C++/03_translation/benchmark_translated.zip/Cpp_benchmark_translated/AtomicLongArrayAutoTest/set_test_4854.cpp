#include <atomic>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include <stdexcept>
#include <iostream>
#include <cstdlib>

// Type aliases matching Java functional interfaces
using LongUnaryOperator = std::function<int64_t(int64_t)>;
using LongBinaryOperator = std::function<int64_t(int64_t, int64_t)>;

class AtomicLongArray {
public:
    explicit AtomicLongArray(int length)
        : length_(length), data_(length) {}

    // --- Plain (relaxed) operations ---
    int64_t getPlain(int i) const {
        return data_[i].load(std::memory_order_relaxed);
    }

    void setPlain(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_relaxed);
    }

    // --- Opaque (relaxed) operations ---
    int64_t getOpaque(int i) const {
        return data_[i].load(std::memory_order_relaxed);
    }

    void setOpaque(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_relaxed);
    }

    // --- Acquire operations ---
    int64_t getAcquire(int i) const {
        return data_[i].load(std::memory_order_acquire);
    }

    // --- Release operations ---
    void setRelease(int i, int64_t newValue) {
        data_[i].store(newValue, std::memory_order_release);
    }

    // --- Volatile (sequentially consistent) operations ---
    int64_t get(int i) const {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].load(std::memory_order_seq_cst);
    }

    void set(int i, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        data_[i].store(newValue, std::memory_order_seq_cst);
    }

    int length() const {
        return length_;
    }

    std::string toString() const {
        std::string result = "[";
        for (int i = 0; i < length_; ++i) {
            if (i > 0) result += ", ";
            result += std::to_string(get(i));
        }
        result += "]";
        return result;
    }

    // --- CAS with different orderings ---
    bool compareAndSet(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
    }

    int64_t compareAndExchange(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
        return expected;
    }

    int64_t compareAndExchangeAcquire(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_acquire);
        return expected;
    }

    int64_t compareAndExchangeRelease(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        data_[i].compare_exchange_strong(expected, newValue, std::memory_order_release);
        return expected;
    }

    // --- Weak CAS variants ---
    bool weakCompareAndSetPlain(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_relaxed);
    }

    bool weakCompareAndSet(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetAcquire(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_acquire);
    }

    bool weakCompareAndSetRelease(int i, int64_t expected, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].compare_exchange_weak(expected, newValue, std::memory_order_release);
    }

    // weakCompareAndSetVolatile is an alias for weakCompareAndSet
    bool weakCompareAndSetVolatile(int i, int64_t expected, int64_t newValue) {
        return weakCompareAndSet(i, expected, newValue);
    }

    // --- Read-modify-write operations (sequentially consistent) ---
    int64_t getAndSet(int i, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].exchange(newValue, std::memory_order_seq_cst);
    }

    int64_t getAndAdd(int i, int64_t delta) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_add(delta, std::memory_order_seq_cst);
    }

    int64_t incrementAndGet(int i) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_add(1, std::memory_order_seq_cst) + 1;
    }

    int64_t getAndIncrement(int i) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_add(1, std::memory_order_seq_cst);
    }

    int64_t getAndDecrement(int i) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_sub(1, std::memory_order_seq_cst);
    }

    int64_t decrementAndGet(int i) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_sub(1, std::memory_order_seq_cst) - 1;
    }

    int64_t addAndGet(int i, int64_t delta) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        return data_[i].fetch_add(delta, std::memory_order_seq_cst) + delta;
    }

    // Lazy set (release semantics)
    void lazySet(int i, int64_t newValue) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        data_[i].store(newValue, std::memory_order_release);
    }

    // --- Functional update methods ---
    int64_t getAndUpdate(int i, const LongUnaryOperator& function) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return old;
    }

    int64_t updateAndGet(int i, const LongUnaryOperator& function) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return function(expected); // store succeeded, function(expected) is the new value
    }

    int64_t getAndAccumulate(int i, int64_t x, const LongBinaryOperator& function) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected, x),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return old;
    }

    int64_t accumulateAndGet(int i, int64_t x, const LongBinaryOperator& function) {
        if (i < 0 || i >= length_) throw std::out_of_range("Index " + std::to_string(i) + " out of bounds for length " + std::to_string(length_));
        int64_t old = data_[i].load(std::memory_order_seq_cst);
        int64_t expected = old;
        while (!data_[i].compare_exchange_weak(expected, function(expected, x),
                                              std::memory_order_seq_cst,
                                              std::memory_order_seq_cst)) {
            // expected is updated automatically; retry
        }
        return function(expected, x);
    }

private:
    int length_;
    std::vector<std::atomic<int64_t>> data_;
};

// ====================== Test functions ======================

void set_test_4854() {
    AtomicLongArray atomicLongArray1(0);  // empty array of length 0
    try {
        atomicLongArray1.set(100, 0);   // out-of-bounds
        // If no exception, fail the test
        std::cerr << "fail: Expected exception of type std::out_of_range" << std::endl;
        std::abort();
    } catch (const std::out_of_range& e) {
        // Expected exception, test passes
    }
}