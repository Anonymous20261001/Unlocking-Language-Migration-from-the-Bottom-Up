#include <cstddef>
#include <stdexcept> // for std::runtime_error
#include <cassert>   // for assert

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    // Modified to throw on null argument, matching the Java behavior
    void installUI(JComponent* c) {
        if (!c) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JPopupMenu.getLayout()\" because \"this.popupMenu\" is null");
        }
        // No-op otherwise
    }

    void uninstallUI(JComponent* /*c*/) {
        // No-op
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // No-op
    }

    bool isPopupTrigger(MouseEvent* /*e*/) {
        return false;
    }
};

// Test function – translated from Java test method
void installUI_test_8858() {
    BasicPopupMenuUI basicPopupMenuUI0;
    JComponent* jComponent3 = nullptr; // null pointer

    // The following exception was thrown during execution in test generation
    try {
        basicPopupMenuUI0.installUI(jComponent3);
        // If no exception, fail the test
        assert(false && "Expected exception of type std::runtime_error; message: ...");
    } catch (const std::exception& e) {
        // Expected exception – test passes
    }
}