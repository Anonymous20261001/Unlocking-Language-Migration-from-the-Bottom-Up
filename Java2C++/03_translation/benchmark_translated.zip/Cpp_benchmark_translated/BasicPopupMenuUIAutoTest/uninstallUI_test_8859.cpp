#include <cstddef>
#include <stdexcept>

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    void installUI(JComponent* /*c*/) {
        // No-op in this stub
    }

    void uninstallUI(JComponent* c) {
        // Simulate NullPointerException when c is null
        if (c == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getBorder()\" because \"c\" is null");
        }
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        // In real Swing, createUI returns a new instance of the UI delegate.
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // No-op
    }

    bool isPopupTrigger(MouseEvent* /*e*/) {
        return false;
    }
};

// Test functions – each corresponds exactly to one Java @Test method

void uninstallUI_test_8859() {
    BasicPopupMenuUI instance;
    JComponent* p0 = nullptr;
    try {
        instance.uninstallUI(p0);
        // If we reach here, no exception was thrown, fail
        throw std::logic_error("Expected NullPointerException but no exception was thrown.");
    } catch (const std::exception& e) {
        // Expected exception, do nothing
    }
}