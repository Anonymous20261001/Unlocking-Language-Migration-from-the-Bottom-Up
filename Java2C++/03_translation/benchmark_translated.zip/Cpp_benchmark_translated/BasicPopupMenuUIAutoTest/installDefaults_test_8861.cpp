#include <cstddef>
#include <stdexcept>

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    void installUI(JComponent* /*c*/) {
        // No-op in this stub
    }

    void uninstallUI(JComponent* /*c*/) {
        // No-op
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        // In real Swing, createUI returns a new instance of the UI delegate.
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // Simulate the NullPointerException from the real implementation
        throw std::runtime_error("Cannot invoke \"javax.swing.JPopupMenu.getLayout()\" because \"this.popupMenu\" is null");
    }

    bool isPopupTrigger(MouseEvent* /*e*/) {
        return false;
    }
};

// Test functions – each corresponds exactly to one Java @Test method

void installDefaults_test_8861() {
    BasicPopupMenuUI basicPopupMenuUI0;
    try {
        basicPopupMenuUI0.installDefaults();
        // If no exception, fail the test
        throw std::logic_error("Expected exception of type java.lang.NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception
    }
}