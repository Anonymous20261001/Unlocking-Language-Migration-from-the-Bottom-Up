#include <cstddef>
#include <stdexcept>

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    void installUI(JComponent* /*c*/) {
        // No-op in this stub
    }

    void uninstallUI(JComponent* /*c*/) {
        // No-op
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        // In real Swing, createUI returns a new instance of the UI delegate.
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // No-op
    }

    bool isPopupTrigger(MouseEvent* e) {
        // Simulate Java's NullPointerException when e is null
        if (e == nullptr) {
            throw std::runtime_error("Cannot invoke \"java.awt.event.MouseEvent.getID()\" because \"e\" is null");
        }
        return false;
    }
};

// Test functions – each corresponds exactly to one Java @Test method

void isPopupTrigger_test_8862() {
    BasicPopupMenuUI instance;
    MouseEvent* mouseEvent3 = nullptr;
    try {
        instance.isPopupTrigger(mouseEvent3);
        // If we reach here, the expected exception was not thrown
        throw std::runtime_error("Expected exception not thrown");
    } catch (const std::exception& e) {
        // Expected exception, test passes
    }
}