#include <cstddef>
#include <cassert>

// Minimal stub for javax.swing.JComponent
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal stub for java.awt.event.MouseEvent
class MouseEvent {
public:
    virtual ~MouseEvent() = default;
};

// Stub for javax.swing.plaf.basic.BasicPopupMenuUI
class BasicPopupMenuUI {
public:
    BasicPopupMenuUI() = default;
    ~BasicPopupMenuUI() = default;

    void installUI(JComponent* /*c*/) {
        // No-op in this stub
    }

    void uninstallUI(JComponent* /*c*/) {
        // No-op
    }

    static BasicPopupMenuUI* createUI(JComponent* /*c*/) {
        // In real Swing, createUI returns a new instance of the UI delegate.
        return new BasicPopupMenuUI();
    }

    void installDefaults() {
        // No-op
    }

    bool isPopupTrigger(MouseEvent* /*e*/) {
        return false;
    }
};

// Test functions – each corresponds exactly to one Java @Test method

void createUI_test_8860() {
    JComponent* jComponent0 = nullptr;
    BasicPopupMenuUI* componentUI1 = BasicPopupMenuUI::createUI(jComponent0);
    assert(componentUI1 != nullptr);
}