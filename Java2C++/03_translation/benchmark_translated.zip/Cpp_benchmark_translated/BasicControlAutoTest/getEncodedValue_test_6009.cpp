#include <string>
#include <vector>
#include <cstdint>
#include <cassert>

// C++ equivalent of javax.naming.ldap.BasicControl
class BasicControl {
public:
    // Constructor matching Java BasicControl(String id)
    explicit BasicControl(const std::string& id)
        : m_id(id), m_critical(false), m_encodedValue() {}

    // Additional constructor matching Java BasicControl(String id, boolean critical, byte[] value)
    BasicControl(const std::string& id, bool critical, const std::vector<uint8_t>& encodedValue)
        : m_id(id), m_critical(critical), m_encodedValue(encodedValue) {}

    // isCritical() method
    bool isCritical() const {
        return m_critical;
    }

    // getEncodedValue() method - returns a copy of the encoded value as vector<uint8_t>
    std::vector<uint8_t> getEncodedValue() const {
        return m_encodedValue;
    }

    // getID() method
    std::string getID() const {
        return m_id;
    }

private:
    std::string m_id;
    bool m_critical;
    std::vector<uint8_t> m_encodedValue;
};

// Test function 1: getEncodedValue_test_6009 (translated from Java)
void getEncodedValue_test_6009() {
    std::vector<uint8_t> byteArray2 = {};  // empty byte array
    BasicControl basicControl3("", true, byteArray2);
    std::vector<uint8_t> byteArray4 = basicControl3.getEncodedValue();
    // Assert that the returned vector is not null (always true in C++) and equals empty array
    assert(byteArray4.size() == 0);
    // Equivalent to Java's assertArrayEquals(byteArray4, new byte[] {});
    assert(byteArray4 == std::vector<uint8_t>{});
}