#include <string>
#include <vector>
#include <cstdint>
#include <cassert>

// C++ equivalent of javax.naming.ldap.BasicControl
class BasicControl {
public:
    // Constructor matching Java BasicControl(String id)
    explicit BasicControl(const std::string& id)
        : m_id(id), m_critical(false), m_encodedValue() {}

    // Added constructor to match Java BasicControl(String id, boolean critical, byte[] encodedValue)
    BasicControl(const std::string& id, bool critical, const std::vector<uint8_t>& encodedValue)
        : m_id(id), m_critical(critical), m_encodedValue(encodedValue) {}

    // isCritical() method
    bool isCritical() const {
        return m_critical;
    }

    // getEncodedValue() method - returns a copy of the encoded value as vector<uint8_t>
    std::vector<uint8_t> getEncodedValue() const {
        return m_encodedValue;
    }

    // getID() method
    std::string getID() const {
        return m_id;
    }

private:
    std::string m_id;
    bool m_critical;
    std::vector<uint8_t> m_encodedValue;
};

// Test function 1: isCritical_test_6008
void isCritical_test_6008() {
    std::vector<uint8_t> byteArray2;  // empty byte array
    BasicControl basicControl3("", true, byteArray2);
    bool boolean4 = basicControl3.isCritical();
    assert(boolean4 == true);
}