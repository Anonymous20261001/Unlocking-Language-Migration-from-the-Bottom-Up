#include <iostream>
#include <stdexcept>
#include <cassert>

// Minimal Dimension class to match Java's java.awt.Dimension
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Base class for Swing components (stub)
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// JInternalFrame extends JComponent (stub)
class JInternalFrame : public JComponent {
public:
    JInternalFrame() {}
};

// BasicInternalFrameUI (stub implementing similar API, modified to throw when frame is null)
class BasicInternalFrameUI {
private:
    JInternalFrame* frame;
    JComponent* northPane;
    JComponent* southPane;
    JComponent* eastPane;
    JComponent* westPane;
    bool keyBindingActive;
    Dimension maximumSize;
    Dimension preferredSize;
    Dimension minimumSize;

public:
    BasicInternalFrameUI(JInternalFrame* c0)
        : frame(c0), northPane(nullptr), southPane(nullptr),
          eastPane(nullptr), westPane(nullptr), keyBindingActive(false) {}

    // Static factory method
    static BasicInternalFrameUI* createUI(JComponent* p0) {
        return new BasicInternalFrameUI(nullptr);
    }

    void installUI(JComponent* p0) {}
    void uninstallUI(JComponent* p0) {}

    void setNorthPane(JComponent* p0) { northPane = p0; }
    void setSouthPane(JComponent* p0) { southPane = p0; }
    void setEastPane(JComponent* p0) { eastPane = p0; }
    void setWestPane(JComponent* p0) { westPane = p0; }

    bool isKeyBindingActive() { return keyBindingActive; }

    JComponent* getNorthPane() { return northPane; }
    JComponent* getSouthPane() { return southPane; }
    JComponent* getWestPane() { return westPane; }
    JComponent* getEastPane() { return eastPane; }

    // Modified to throw if frame is null (matching Java exception)
    Dimension getMaximumSize(JComponent* p0) {
        if (frame == nullptr) throw std::runtime_error("NullPointerException: Cannot invoke ... because this.frame is null");
        return maximumSize;
    }

    // Modified to throw if frame is null
    Dimension getPreferredSize(JComponent* p0) {
        if (frame == nullptr) throw std::runtime_error("NullPointerException: Cannot invoke ... because this.frame is null");
        return preferredSize;
    }

    // Modified to throw if frame is null
    Dimension getMinimumSize(JComponent* p0) {
        if (frame == nullptr) throw std::runtime_error("NullPointerException: Cannot invoke ... because this.frame is null");
        return minimumSize;
    }
};

// Translated test function (no parameters)
void getPreferredSize_test_8802() {
    JInternalFrame* jInternalFrame0 = nullptr;
    BasicInternalFrameUI basicInternalFrameUI1(jInternalFrame0);
    JComponent* jComponent2 = nullptr;

    try {
        Dimension dimension3 = basicInternalFrameUI1.getPreferredSize(jComponent2);
        // If we reach here, no exception was thrown -> test fails
        assert(false && "Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception, do nothing (test passes)
    }
}