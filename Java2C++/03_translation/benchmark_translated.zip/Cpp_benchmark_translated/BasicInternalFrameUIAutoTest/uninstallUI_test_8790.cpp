#include <iostream>
#include <stdexcept>
#include <cassert>

// Minimal Dimension class to match Java's java.awt.Dimension
class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// Base class for Swing components (stub)
class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

// JInternalFrame extends JComponent (stub)
class JInternalFrame : public JComponent {
public:
    JInternalFrame() {}
};

// BasicInternalFrameUI (stub implementing similar API)
class BasicInternalFrameUI {
private:
    JInternalFrame* frame;
    JComponent* northPane;
    JComponent* southPane;
    JComponent* eastPane;
    JComponent* westPane;
    bool keyBindingActive;
    Dimension maximumSize;
    Dimension preferredSize;
    Dimension minimumSize;

public:
    BasicInternalFrameUI(JInternalFrame* c0)
        : frame(c0), northPane(nullptr), southPane(nullptr),
          eastPane(nullptr), westPane(nullptr), keyBindingActive(false) {}

    // Static factory method
    static BasicInternalFrameUI* createUI(JComponent* p0) {
        // In real Swing, creates UI for the component; here we return a dummy instance.
        // Note: The test calls this but ignores the return value.
        return new BasicInternalFrameUI(nullptr);
    }

    void installUI(JComponent* p0) {
        // Install UI for the component
    }

    void uninstallUI(JComponent* p0) {
        // Simulate NullPointerException when component is null
        if (p0 == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getInputMap(int, boolean)\" because \"component\" is null");
        }
        // Uninstall UI (stub)
    }

    void setNorthPane(JComponent* p0) {
        northPane = p0;
    }

    void setSouthPane(JComponent* p0) {
        southPane = p0;
    }

    void setEastPane(JComponent* p0) {
        eastPane = p0;
    }

    void setWestPane(JComponent* p0) {
        westPane = p0;
    }

    bool isKeyBindingActive() {
        return keyBindingActive;
    }

    JComponent* getNorthPane() {
        return northPane;
    }

    JComponent* getSouthPane() {
        return southPane;
    }

    JComponent* getWestPane() {
        return westPane;
    }

    JComponent* getEastPane() {
        return eastPane;
    }

    Dimension getMaximumSize(JComponent* p0) {
        return maximumSize;
    }

    Dimension getPreferredSize(JComponent* p0) {
        return preferredSize;
    }

    Dimension getMinimumSize(JComponent* p0) {
        return minimumSize;
    }
};

// Test function (C++ translation of Java @Test method)
void uninstallUI_test_8790() {
    JInternalFrame* jInternalFrame0 = nullptr;
    BasicInternalFrameUI* basicInternalFrameUI1 = new BasicInternalFrameUI(jInternalFrame0);
    JComponent* jComponent3 = nullptr;
    try {
        basicInternalFrameUI1->uninstallUI(jComponent3);
        // If we reach here, no exception was thrown – fail the test
        assert(false);
    } catch (const std::exception& e) {
        // Expected exception (NullPointerException behavior)
    }
    delete basicInternalFrameUI1;
}