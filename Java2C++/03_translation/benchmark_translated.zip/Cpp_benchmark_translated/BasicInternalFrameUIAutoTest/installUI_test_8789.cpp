#include <iostream>
#include <stdexcept>
#include <cassert>

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class JComponent {
public:
    JComponent() {}
    virtual ~JComponent() {}
};

class JInternalFrame : public JComponent {
public:
    JInternalFrame() {}
};

class BasicInternalFrameUI {
private:
    JInternalFrame* frame;
    JComponent* northPane;
    JComponent* southPane;
    JComponent* eastPane;
    JComponent* westPane;
    bool keyBindingActive;
    Dimension maximumSize;
    Dimension preferredSize;
    Dimension minimumSize;

public:
    BasicInternalFrameUI(JInternalFrame* c0)
        : frame(c0), northPane(nullptr), southPane(nullptr),
          eastPane(nullptr), westPane(nullptr), keyBindingActive(false) {}

    static BasicInternalFrameUI* createUI(JComponent* p0) {
        return new BasicInternalFrameUI(nullptr);
    }

    void installUI(JComponent* p0) {
        if (frame == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JInternalFrame.getFrameIcon()\" because \"this.frame\" is null");
        }
        // Install UI for the component
    }

    void uninstallUI(JComponent* p0) {
    }

    void setNorthPane(JComponent* p0) {
        northPane = p0;
    }

    void setSouthPane(JComponent* p0) {
        southPane = p0;
    }

    void setEastPane(JComponent* p0) {
        eastPane = p0;
    }

    void setWestPane(JComponent* p0) {
        westPane = p0;
    }

    bool isKeyBindingActive() {
        return keyBindingActive;
    }

    JComponent* getNorthPane() {
        return northPane;
    }

    JComponent* getSouthPane() {
        return southPane;
    }

    JComponent* getWestPane() {
        return westPane;
    }

    JComponent* getEastPane() {
        return eastPane;
    }

    Dimension getMaximumSize(JComponent* p0) {
        return maximumSize;
    }

    Dimension getPreferredSize(JComponent* p0) {
        return preferredSize;
    }

    Dimension getMinimumSize(JComponent* p0) {
        return minimumSize;
    }
};

void installUI_test_8789() {
    // Test: basicInternalFrameUI1.installUI(jComponent3) should throw NullPointerException
    JInternalFrame* jInternalFrame0 = nullptr;
    BasicInternalFrameUI basicInternalFrameUI1(jInternalFrame0);
    JComponent* jComponent3 = nullptr;
    try {
        basicInternalFrameUI1.installUI(jComponent3);
        // If we reach here, no exception was thrown, test should fail
        assert(false && "Expected exception of type std::runtime_error; message: Cannot invoke...");
    } catch (const std::exception& e) {
        // Expected exception.
    }
}