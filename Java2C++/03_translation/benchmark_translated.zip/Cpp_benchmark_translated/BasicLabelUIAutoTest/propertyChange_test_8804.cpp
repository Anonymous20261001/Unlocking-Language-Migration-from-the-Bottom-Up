#include <cstdint>
#include <stdexcept>

// Forward declarations for classes used
class PropertyChangeEvent;
class JComponent;
class Graphics;

// Enum for baseline resize behavior (mimics JComponent.BaselineResizeBehavior)
enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Stub Graphics class
class Graphics {
public:
    virtual ~Graphics() = default;
    // No real methods needed for these tests
};

// Stub PropertyChangeEvent class
class PropertyChangeEvent {
public:
    PropertyChangeEvent(void* source, const char* propertyName,
                        void* oldValue, void* newValue)
        : source_(source), propertyName_(propertyName),
          oldValue_(oldValue), newValue_(newValue) {}
    virtual ~PropertyChangeEvent() = default;
private:
    void* source_;
    const char* propertyName_;
    void* oldValue_;
    void* newValue_;
};

// Stub JComponent class
class JComponent {
public:
    virtual ~JComponent() = default;
    // Minimum stubs for the tests to compile
    int getWidth() const { return 0; }
    int getHeight() const { return 0; }
};

// BasicLabelUI – stub implementation matching Java API
class BasicLabelUI {
public:
    BasicLabelUI() = default;
    ~BasicLabelUI() = default;

    void propertyChange(PropertyChangeEvent* p0) {
        // Match Java behavior: throw NullPointerException when argument is null
        if (p0 == nullptr) {
            throw std::runtime_error("Cannot invoke \"java.beans.PropertyChangeEvent.getPropertyName()\" because \"e\" is null");
        }
        // No-op otherwise
    }

    void installUI(JComponent* c) {
        (void)c;
    }

    void uninstallUI(JComponent* c) {
        (void)c;
    }

    static BasicLabelUI* createUI(JComponent* c) {
        (void)c;
        // In Swing, createUI often returns a shared instance.
        // For simplicity, return a new instance (or static).
        static BasicLabelUI instance;
        return &instance;
    }

    // getMaximumSize is supposed to return Dimension, but test ignores return.
    // We'll just return a nullptr or default, but the signature should match.
    // Since Java method returns a Dimension, we can return a fake pointer.
    // For simplicity, we return the same instance each time (like a shared object).
    void* getMaximumSize(JComponent* c) {
        (void)c;
        return nullptr; // No actual object needed
    }

    void paint(Graphics* g, JComponent* c) {
        (void)g;
        (void)c;
    }

    void* getPreferredSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    void* getMinimumSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    int getBaseline(JComponent* c, int width, int height) {
        (void)c;
        (void)width;
        (void)height;
        return 0; // Typically the baseline
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* c) {
        (void)c;
        return BaselineResizeBehavior::CONSTANT_ASCENT;
    }
};

// Test functions (exact names as in Java @Test methods, with C++ signatures)

void propertyChange_test_8804() {
    BasicLabelUI instance;
    PropertyChangeEvent* p0 = nullptr;
    try {
        instance.propertyChange(p0);
        // If no exception, fail the test
        throw std::runtime_error("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.beans.PropertyChangeEvent.getPropertyName()\" because \"e\" is null");
    } catch (const std::runtime_error& e) {
        // Expected exception: check message? The Java test only checks that an exception was thrown.
        // We could also check the message, but for simplicity we just catch.
        // Optionally, we can check the message to match the expected one.
        // Since the test expects exactly that message, we can rethrow if mismatch.
        // But to keep simple, we just catch.
    }
}