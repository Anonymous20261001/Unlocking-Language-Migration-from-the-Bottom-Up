#include <cstdint>
#include <stdexcept>
#include <string>

// Forward declarations for classes used
class PropertyChangeEvent;
class JComponent;
class Graphics;

// Enum for baseline resize behavior (mimics JComponent.BaselineResizeBehavior)
enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Simple NullPointerException for testing
class NullPointerException : public std::runtime_error {
public:
    explicit NullPointerException(const std::string& msg) : std::runtime_error(msg) {}
};

// Stub Graphics class
class Graphics {
public:
    virtual ~Graphics() = default;
    // No real methods needed for these tests
};

// Stub PropertyChangeEvent class
class PropertyChangeEvent {
public:
    PropertyChangeEvent(void* source, const char* propertyName,
                        void* oldValue, void* newValue)
        : source_(source), propertyName_(propertyName),
          oldValue_(oldValue), newValue_(newValue) {}
    virtual ~PropertyChangeEvent() = default;
private:
    void* source_;
    const char* propertyName_;
    void* oldValue_;
    void* newValue_;
};

// Stub JComponent class
class JComponent {
public:
    virtual ~JComponent() = default;
    // Minimum stubs for the tests to compile
    int getWidth() const { return 0; }
    int getHeight() const { return 0; }
};

// BasicLabelUI – stub implementation matching Java API
class BasicLabelUI {
public:
    BasicLabelUI() = default;
    ~BasicLabelUI() = default;

    void propertyChange(PropertyChangeEvent* p0) {
        // No-op, just like the test (no assertion)
        (void)p0;
    }

    void installUI(JComponent* c) {
        (void)c;
    }

    void uninstallUI(JComponent* c) {
        (void)c;
    }

    static BasicLabelUI* createUI(JComponent* c) {
        (void)c;
        // In Swing, createUI often returns a shared instance.
        // For simplicity, return a new instance (or static).
        static BasicLabelUI instance;
        return &instance;
    }

    // getMaximumSize is supposed to return Dimension, but test ignores return.
    // We'll just return a nullptr or default, but the signature should match.
    // Since Java method returns a Dimension, we can return a fake pointer.
    // For simplicity, we return the same instance each time (like a shared object).
    void* getMaximumSize(JComponent* c) {
        (void)c;
        return nullptr; // No actual object needed
    }

    void paint(Graphics* g, JComponent* c) {
        (void)g;
        (void)c;
    }

    void* getPreferredSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    void* getMinimumSize(JComponent* c) {
        (void)c;
        return nullptr;
    }

    int getBaseline(JComponent* c, int width, int height) {
        (void)c;
        (void)width;
        (void)height;
        return 0; // Typically the baseline
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* c) {
        // Simulate the Java NullPointerException when component is null
        if (c == nullptr) {
            throw NullPointerException("Component must be non-null");
        }
        (void)c;
        return BaselineResizeBehavior::CONSTANT_ASCENT;
    }
};

// Helper to emulate JUnit's fail()
void fail(const char* message) {
    throw std::runtime_error(message);
}

// Test functions (exact names as in Java @Test methods, with C++ signatures)

void getBaselineResizeBehavior_test_8813() {
    BasicLabelUI basicLabelUI0;
    JComponent* jComponent1 = nullptr;
    try {
        BaselineResizeBehavior baselineResizeBehavior2 = basicLabelUI0.getBaselineResizeBehavior(jComponent1);
        fail("Expected exception of type NullPointerException; message: Component must be non-null");
    } catch (const NullPointerException& e) {
        // Expected exception.
    }
}