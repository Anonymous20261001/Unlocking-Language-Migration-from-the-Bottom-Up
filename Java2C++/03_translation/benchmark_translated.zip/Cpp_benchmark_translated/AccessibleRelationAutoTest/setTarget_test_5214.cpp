#include <string>
#include <vector>

class AccessibleRelation {
private:
    std::string key;
    std::vector<void*> targets;

public:
    AccessibleRelation(const std::string& key) : key(key) {}

    std::string getKey() const {
        return key;
    }

    void* getTarget() const {
        return targets.empty() ? nullptr : targets[0];
    }

    void setTarget(void* target) {
        targets.clear();
        targets.push_back(target);
    }

    void setTarget(const std::vector<void*>& targets) {
        this->targets = targets;
    }
};

void setTarget_test_5214() {
    AccessibleRelation instance("controlledByProperty");
    int val = 1;
    std::vector<void*> targets = { &val };
    instance.setTarget(targets);
}