#include <string>
#include <vector>
#include <cassert>

class AccessibleRelation {
private:
    std::string key;
    std::vector<void*> targets;

public:
    AccessibleRelation(const std::string& key) : key(key) {}

    std::string getKey() const {
        return key;
    }

    void* getTarget() const {
        return targets.empty() ? nullptr : targets[0];
    }

    void setTarget(void* target) {
        targets.clear();
        targets.push_back(target);
    }

    void setTarget(const std::vector<void*>& targets) {
        this->targets = targets;
    }
};

void getKey_test_5212() {
    AccessibleRelation instance("parentWindowOfProperty");
    std::string str = instance.getKey();
    assert(str == "parentWindowOfProperty");
}