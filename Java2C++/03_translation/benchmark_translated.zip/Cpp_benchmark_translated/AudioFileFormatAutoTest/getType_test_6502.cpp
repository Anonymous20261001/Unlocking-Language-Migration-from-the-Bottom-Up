#include <string>
#include <map>
#include <iostream>
#include <cassert>

class AudioFormat {
private:
    float sampleRate;
    int sampleSizeInBits;
    int channels;
    bool signed_;
    bool bigEndian;
    int frameSize;

public:
    AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed_, bool bigEndian)
        : sampleRate(sampleRate), sampleSizeInBits(sampleSizeInBits), channels(channels),
          signed_(signed_), bigEndian(bigEndian) {
        if (sampleSizeInBits > 0 && channels > 0) {
            frameSize = (sampleSizeInBits * channels) / 8;
        } else {
            frameSize = -1;
        }
    }

    int getFrameSize() const {
        return frameSize;
    }
};

class AudioFileFormat {
public:
    class Type {
    private:
        std::string name;
        std::string extension;
    public:
        Type(const std::string& name, const std::string& extension)
            : name(name), extension(extension) {}
        std::string getName() const { return name; }
        std::string getExtension() const { return extension; }
    };

private:
    Type type;
    const AudioFormat* format;
    int frameLength;
    std::map<std::string, std::string> props;

public:
    AudioFileFormat(const Type& type, const AudioFormat* format, int frameLength)
        : type(type), format(format), frameLength(frameLength) {}

    int getByteLength() const {
        if (format != nullptr && format->getFrameSize() > 0) {
            return frameLength * format->getFrameSize();
        }
        return -1;
    }

    int getFrameLength() const {
        return frameLength;
    }

    std::string getProperty(const std::string& key) const {
        auto it = props.find(key);
        if (it != props.end()) {
            return it->second;
        }
        return std::string();
    }

    std::string toString() const {
        std::string formatStr = (format != nullptr) ? "AudioFormat" : "null";
        return "AudioFileFormat[type=" + type.getName() + ", format=" + formatStr + ", frameLength=" + std::to_string(frameLength) + "]";
    }

    const std::map<std::string, std::string>& properties() const {
        return props;
    }

    Type getType() const {
        return type;
    }

    const AudioFormat* getFormat() const {
        return format;
    }
};

void getType_test_6502() {
    AudioFileFormat::Type type0("SND", "snd");
    AudioFormat* audioFormat1 = nullptr;
    AudioFileFormat instance(type0, audioFormat1, 1);
    AudioFileFormat::Type type4 = instance.getType();
    assert(type4.getName() == "SND");
}