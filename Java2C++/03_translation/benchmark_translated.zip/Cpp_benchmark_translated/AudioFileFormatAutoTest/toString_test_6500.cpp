#include <string>
#include <map>
#include <iostream>
#include <cassert>

class AudioFormat {
private:
    float sampleRate;
    int sampleSizeInBits;
    int channels;
    bool signed_;
    bool bigEndian;
    int frameSize;

public:
    AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed_, bool bigEndian)
        : sampleRate(sampleRate), sampleSizeInBits(sampleSizeInBits), channels(channels),
          signed_(signed_), bigEndian(bigEndian) {
        if (sampleSizeInBits > 0 && channels > 0) {
            frameSize = (sampleSizeInBits * channels) / 8;
        } else {
            frameSize = -1;
        }
    }

    int getFrameSize() const {
        return frameSize;
    }

    std::string toString() const {
        return "AudioFormat[" + std::to_string(sampleRate) + " Hz, " +
               std::to_string(sampleSizeInBits) + " bit, " +
               std::to_string(channels) + " channels, " +
               (signed_ ? "signed" : "unsigned") + ", " +
               (bigEndian ? "big-endian" : "little-endian") + ", " +
               std::to_string(frameSize) + " bytes/frame]";
    }
};

class AudioFileFormat {
public:
    class Type {
    private:
        std::string name;
        std::string extension;
    public:
        Type(const std::string& name, const std::string& extension)
            : name(name), extension(extension) {}
        std::string getName() const { return name; }
        std::string getExtension() const { return extension; }

        static const Type AU;
    };

private:
    Type type;
    const AudioFormat* format;  // allows null
    int frameLength;
    std::map<std::string, std::string> props;

public:
    AudioFileFormat(const Type& type, const AudioFormat* fmt, int frameLength)
        : type(type), format(fmt), frameLength(frameLength) {}

    int getByteLength() const {
        if (format == nullptr) return -1;
        int frameSize = format->getFrameSize();
        if (frameSize > 0) {
            return frameLength * frameSize;
        }
        return -1;
    }

    int getFrameLength() const {
        return frameLength;
    }

    std::string getProperty(const std::string& key) const {
        auto it = props.find(key);
        if (it != props.end()) {
            return it->second;
        }
        return std::string();
    }

    std::string toString() const {
        std::string result = type.getName() + " (" + type.getExtension() + ") file, data format: ";
        if (format == nullptr) {
            result += "null";
        } else {
            result += format->toString();
        }
        return result;
    }

    const std::map<std::string, std::string>& properties() const {
        return props;
    }

    Type getType() const {
        return type;
    }

    const AudioFormat* getFormat() const {
        return format;
    }
};

// Define the AU static member
const AudioFileFormat::Type AudioFileFormat::Type::AU("AU", "au");

// Translation of Java test method
void toString_test_6500() {
    const AudioFileFormat::Type& type0 = AudioFileFormat::Type::AU;
    const AudioFormat* audioFormat1 = nullptr;
    AudioFileFormat audioFileFormat3(type0, audioFormat1, (int)(short)-1);
    std::string str4 = audioFileFormat3.toString();
    assert(str4 == "AU (.au) file, data format: null");
}