#include <string>
#include <map>
#include <cassert>

class AudioFormat {
private:
    float sampleRate;
    int sampleSizeInBits;
    int channels;
    bool signed_;
    bool bigEndian;
    int frameSize;

public:
    AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed_, bool bigEndian)
        : sampleRate(sampleRate), sampleSizeInBits(sampleSizeInBits), channels(channels),
          signed_(signed_), bigEndian(bigEndian) {
        if (sampleSizeInBits > 0 && channels > 0) {
            frameSize = (sampleSizeInBits * channels) / 8;
        } else {
            frameSize = -1;
        }
    }

    int getFrameSize() const {
        return frameSize;
    }
};

class AudioFileFormat {
public:
    class Type {
    private:
        std::string name;
        std::string extension;
    public:
        Type(const std::string& name, const std::string& extension)
            : name(name), extension(extension) {}
        std::string getName() const { return name; }
        std::string getExtension() const { return extension; }
        static const Type AIFC; // added for test
    };

private:
    Type type;
    const AudioFormat* format; // changed to pointer to allow null
    int frameLength;
    std::map<std::string, std::string> props;

public:
    AudioFileFormat(const Type& type, const AudioFormat* format, int frameLength)
        : type(type), format(format), frameLength(frameLength) {
        if (format != nullptr) {
            int fs = format->getFrameSize();
            if (fs > 0) {
                // frame size already computed in AudioFormat, but we don't store it separately
                // We'll rely on getByteLength using format->getFrameSize()
            }
        }
    }

    int getByteLength() const {
        if (format == nullptr) return -1;
        int frameSize = format->getFrameSize();
        if (frameSize > 0) {
            return frameLength * frameSize;
        }
        return -1;
    }

    int getFrameLength() const {
        return frameLength;
    }

    const AudioFormat* getFormat() const { // returns pointer
        return format;
    }

    std::string getProperty(const std::string& key) const {
        auto it = props.find(key);
        if (it != props.end()) {
            return it->second;
        }
        return std::string();
    }

    std::string toString() const {
        return "AudioFileFormat[type=" + type.getName() + ", format=AudioFormat, frameLength=" + std::to_string(frameLength) + "]";
    }

    const std::map<std::string, std::string>& properties() const {
        return props;
    }

    Type getType() const {
        return type;
    }
};

// Define static member
const AudioFileFormat::Type AudioFileFormat::Type::AIFC("AIFC", "aifc");

// Test function
void getFormat_test_6503() {
    AudioFileFormat::Type type0 = AudioFileFormat::Type::AIFC;
    AudioFormat* audioFormat1 = nullptr;
    AudioFileFormat audioFileFormat3(type0, audioFormat1, 0);
    const AudioFormat* audioFormat4 = audioFileFormat3.getFormat();
    assert(audioFormat4 == nullptr);
}