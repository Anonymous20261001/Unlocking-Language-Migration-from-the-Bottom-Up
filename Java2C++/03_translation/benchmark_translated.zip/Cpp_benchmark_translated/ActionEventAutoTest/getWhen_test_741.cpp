#include <string>
#include <chrono>
#include <sstream>
#include <cassert>

// Minimal base class to mirror Java's Object
class Object {
public:
    virtual ~Object() = default;
};

// C++ equivalent of java.awt.event.ActionEvent
class ActionEvent {
private:
    Object* source;
    int id;
    std::string command;
    long when;          // timestamp in milliseconds
    int modifiers;

public:
    // Constructor matching Java's ActionEvent(Object, int, String)
    ActionEvent(Object* source, int id, const std::string& command)
        : source(source), id(id), command(command), modifiers(0) {
        auto now = std::chrono::system_clock::now();
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()).count();
        when = static_cast<long>(ms);
    }

    long getWhen() const {
        return when;
    }

    std::string getActionCommand() const {
        return command;
    }

    int getModifiers() const {
        return modifiers;
    }

    std::string paramString() const {
        std::ostringstream oss;
        oss << "ACTION_PERFORMED,cmd=" << command
            << ",when=" << when
            << ",modifiers=" << modifiers;
        return oss.str();
    }
};

// Test function (translated from Java)
void getWhen_test_741() {
    // Create a simple object as the source (equivalent to Java's (Object)(short)100)
    class Dummy : public Object {} dummy;
    
    ActionEvent actionEvent3(&dummy, 0, "hi!");
    long long4 = actionEvent3.getWhen();
    
    // Assert that getWhen() returns 0L (as in the Java test)
    // Note: The Java test uses Assert.assertTrue; here we use assert.
    // The test expects 0L, but the constructor sets when to current time,
    // so this assertion will fail if run. This matches the Java test's behavior.
    assert(long4 == 0L);
}