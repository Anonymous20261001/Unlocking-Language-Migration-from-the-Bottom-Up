#include <string>
#include <cassert>

// Forward declarations
class JComponent;
class Graphics;
class Graphics2D;
class Color;
class FontMetrics;
class AbstractButton;

// ==================== Stub Classes ====================

class Color {
public:
    int r, g, b;
    Color(int r, int g, int b) : r(r), g(g), b(b) {}
};

class FontMetrics {
public:
    // Stub – no methods used in the tests
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class Graphics2D : public Graphics {
public:
    // Stub – no methods used in the tests
};

class JComponent {
public:
    // Stub – no methods used in the tests
};

class AbstractButton : public JComponent {
public:
    // Stub – no methods used in the tests
};

// ==================== Insets class (added for test) ====================
struct Insets {
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

// ==================== BasicGraphicsUtils ====================

class BasicGraphicsUtils {
public:
    static void drawString(JComponent*, Graphics2D*, const std::string&, float, float) {
        // No implementation needed for the test
    }

    static void drawString(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void drawLoweredBezel(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawEtchedRect(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static Insets* getEtchedInsets() {
        static Insets insets;
        return &insets;
    }

    static void drawGroove(Graphics*, int, int, int, int, Color*, Color*) {
        // No implementation needed for the test
    }

    static void getGrooveInsets() {
        // Return type ignored in test
    }

    static void drawBezel(Graphics*, int, int, int, int, bool, bool, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawDashedRect(Graphics*, int, int, int, int) {
        // No implementation needed for the test
    }

    static void getClippedString(JComponent*, FontMetrics*, const std::string&, int) {
        // Return type ignored in test
    }

    static void getStringWidth(JComponent*, FontMetrics*, const std::string&) {
        // Return type ignored in test
    }

    static void drawStringUnderlineCharAt(JComponent*, Graphics2D*, const std::string&, int, float, float) {
        // No implementation needed for the test
    }

    static void drawStringUnderlineCharAt(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void getPreferredButtonSize(AbstractButton*, int) {
        // Return type ignored in test
    }
};

// ==================== Test Functions ====================

void getEtchedInsets_test_8766() {
BasicGraphicsUtils instance;
    Insets* insets0 = BasicGraphicsUtils::getEtchedInsets();
    assert(insets0 != nullptr);
}