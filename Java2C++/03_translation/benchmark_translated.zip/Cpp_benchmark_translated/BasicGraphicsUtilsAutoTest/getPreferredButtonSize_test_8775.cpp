#include <string>
#include <stdexcept>
#include <cassert>

// Forward declarations
class JComponent;
class Graphics;
class Graphics2D;
class Color;
class FontMetrics;
class AbstractButton;

// ==================== Stub Classes ====================

class Color {
public:
    int r, g, b;
    Color(int r, int g, int b) : r(r), g(g), b(b) {}
};

class FontMetrics {
public:
    // Stub – no methods used in the tests
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class Graphics2D : public Graphics {
public:
    // Stub – no methods used in the tests
};

class JComponent {
public:
    // Stub – no methods used in the tests
};

class AbstractButton : public JComponent {
public:
    // Stub – no methods used in the tests
};

// ==================== BasicGraphicsUtils ====================

class BasicGraphicsUtils {
public:
    static void drawString(JComponent*, Graphics2D*, const std::string&, float, float) {
        // No implementation needed for the test
    }

    static void drawString(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void drawLoweredBezel(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawEtchedRect(Graphics*, int, int, int, int, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void getEtchedInsets() {
        // Return type ignored in test
    }

    static void drawGroove(Graphics*, int, int, int, int, Color*, Color*) {
        // No implementation needed for the test
    }

    static void getGrooveInsets() {
        // Return type ignored in test
    }

    static void drawBezel(Graphics*, int, int, int, int, bool, bool, Color*, Color*, Color*, Color*) {
        // No implementation needed for the test
    }

    static void drawDashedRect(Graphics*, int, int, int, int) {
        // No implementation needed for the test
    }

    static void getClippedString(JComponent*, FontMetrics*, const std::string&, int) {
        // Return type ignored in test
    }

    static void getStringWidth(JComponent*, FontMetrics*, const std::string&) {
        // Return type ignored in test
    }

    static void drawStringUnderlineCharAt(JComponent*, Graphics2D*, const std::string&, int, float, float) {
        // No implementation needed for the test
    }

    static void drawStringUnderlineCharAt(Graphics*, const std::string&, int, int, int) {
        // No implementation needed for the test
    }

    static void getPreferredButtonSize(AbstractButton* b, int) {
        // Modified to throw when b is null, matching Java behavior
        if (b == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.AbstractButton.getComponentCount()\" because \"b\" is null");
        }
    }
};

// ==================== Test Functions ====================

void getPreferredButtonSize_test_8775() {
    AbstractButton* abstractButton0 = nullptr;
    try {
        BasicGraphicsUtils::getPreferredButtonSize(abstractButton0, 0);
        // If we reach here, no exception was thrown → test should fail
        assert(false && "Expected exception of type std::exception");
    } catch (const std::exception& e) {
        // Expected exception.
    }
}