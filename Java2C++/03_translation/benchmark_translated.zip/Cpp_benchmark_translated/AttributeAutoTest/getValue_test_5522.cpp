#include <string>
#include <memory>
#include <sstream>
#include <functional>
#include <typeindex>
#include <cstddef>

// ---------------------------------------------------------------------------
// Base class for Java-like Object
// ---------------------------------------------------------------------------
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const = 0;
    virtual std::size_t hashCode() const = 0;
    virtual std::string toString() const = 0;
};

// ---------------------------------------------------------------------------
// Concrete wrapper for std::string behaving like Java String
// ---------------------------------------------------------------------------
class StringObject : public Object {
private:
    std::string str;

public:
    explicit StringObject(const std::string& s) : str(s) {}

    const std::string& getString() const { return str; }

    bool equals(const Object& other) const override {
        const auto* otherStr = dynamic_cast<const StringObject*>(&other);
        return otherStr != nullptr && str == otherStr->str;
    }

    std::size_t hashCode() const override {
        return std::hash<std::string>{}(str);
    }

    std::string toString() const override {
        return str;
    }
};

// ---------------------------------------------------------------------------
// java.lang.Class equivalent (simplified)
// ---------------------------------------------------------------------------
class ClassObject : public Object {
private:
    std::string className;

public:
    explicit ClassObject(const std::string& cn) : className(cn) {}

    bool equals(const Object& other) const override {
        const auto* otherClass = dynamic_cast<const ClassObject*>(&other);
        return otherClass != nullptr && className == otherClass->className;
    }

    std::size_t hashCode() const override {
        return std::hash<std::string>{}(className);
    }

    std::string toString() const override {
        return "class " + className;
    }
};

// ---------------------------------------------------------------------------
// javax.management.Attribute equivalent
// ---------------------------------------------------------------------------
class Attribute {
private:
    std::string name;
    std::shared_ptr<Object> value;

public:
    Attribute(const std::string& name, std::shared_ptr<Object> value)
        : name(name), value(std::move(value)) {}

    std::string getName() const {
        return name;
    }

    std::shared_ptr<Object> getValue() const {
        return value;
    }

    bool equals(const Object& other) const {
        const auto* otherAttr = dynamic_cast<const Attribute*>(&other);
        if (!otherAttr) return false;
        return name == otherAttr->name &&
               value->equals(*otherAttr->value);
    }

    std::size_t hashCode() const {
        return std::hash<std::string>{}(name) ^ value->hashCode();
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << name << " = " << value->toString();
        return oss.str();
    }
};

// ===========================================================================
// Test functions (translated from Java @Test methods)
// ===========================================================================

void getValue_test_5522() {
    // Simulate: java.lang.Object obj1 = new java.lang.Object();
    // In C++, we don't need the actual object, only its class representation.
    // Equivalent to: java.lang.Class<?> wildcardClass2 = obj1.getClass();
    // The toString() of that class is "class java.lang.Object".
    auto classValue = std::make_shared<ClassObject>("java.lang.Object");
    
    // javax.management.Attribute attribute3 = new javax.management.Attribute(" = a", wildcardClass2);
    Attribute attribute3(" = a", classValue);
    
    // java.lang.Object obj4 = attribute3.getValue();
    std::shared_ptr<Object> obj4 = attribute3.getValue();
    
    // org.junit.Assert.assertNotNull(obj4);
    // In C++ we can use a simple check; if null we'd throw or assert.
    if (!obj4) {
        throw std::runtime_error("assertNotNull failed: obj4 is null");
    }
    
    // org.junit.Assert.assertEquals(obj4.toString(), "class java.lang.Object");
    std::string expected = "class java.lang.Object";
    if (obj4->toString() != expected) {
        throw std::runtime_error("assertEquals failed: expected '" + expected + "' but got '" + obj4->toString() + "'");
    }
}