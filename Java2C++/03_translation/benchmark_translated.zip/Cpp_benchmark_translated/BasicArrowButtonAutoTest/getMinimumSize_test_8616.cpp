#include <iostream>

// Minimal Graphics class to match Java's java.awt.Graphics
class Graphics {
public:
    Graphics() = default;
};

// Simple Dimension struct to match java.awt.Dimension
struct Dimension {
    int width;
    int height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

// BasicArrowButton simulating javax.swing.plaf.basic.BasicArrowButton
class BasicArrowButton {
private:
    int direction;
public:
    BasicArrowButton(int direction) : direction(direction) {}

    void setDirection(int dir) {
        direction = dir;
    }

    void paintTriangle(Graphics& g, int x, int y, int size, int dir, bool enabled) {
        // Stub – does nothing
    }

    int getDirection() const {
        return direction;
    }

    Dimension getMaximumSize() const {
        return Dimension(0, 0);
    }

    void paint(Graphics& g) {
        // Stub – does nothing
    }

    Dimension getPreferredSize() const {
        return Dimension(0, 0);
    }

    Dimension getMinimumSize() const {
        return Dimension(0, 0);
    }

    bool isFocusTraversable() const {
        return false;
    }
};

// Test functions (translated from Java @Test methods)

void getMinimumSize_test_8616() {
    int c0 = 0;
    BasicArrowButton instance(c0);
    Dimension dimension3 = instance.getMinimumSize();
    // AssertNotNull is not applicable for value types; method call is sufficient.
}