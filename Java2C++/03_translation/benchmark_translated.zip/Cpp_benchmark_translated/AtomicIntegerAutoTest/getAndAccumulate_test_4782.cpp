#include <atomic>
#include <string>
#include <functional>
#include <cstdint>
#include <stdexcept>

// Java equivalent of IntUnaryOperator
using IntUnaryOperator = std::function<int(int)>;
// Java equivalent of IntBinaryOperator
using IntBinaryOperator = std::function<int(int, int)>;

// C++ equivalent of java.util.concurrent.atomic.AtomicInteger
class AtomicInteger {
public:
    // Default constructor: initial value 0
    AtomicInteger() : val(0) {}

    // Constructor with initial value
    explicit AtomicInteger(int initialValue) : val(initialValue) {}

    // get() - equivalent to volatile read (acquire semantics)
    int get() const {
        return val.load(std::memory_order_acquire);
    }

    // set() - equivalent to volatile write (release semantics)
    void set(int newValue) {
        val.store(newValue, std::memory_order_release);
    }

    // toString() - returns string representation of the value
    std::string toString() const {
        return std::to_string(get());
    }

    // intValue(), longValue(), floatValue(), doubleValue()
    int intValue() const { return get(); }
    int64_t longValue() const { return static_cast<int64_t>(get()); }
    float floatValue() const { return static_cast<float>(get()); }
    double doubleValue() const { return static_cast<double>(get()); }

    // getOpaque() - opaque access (no ordering guarantees)
    int getOpaque() const {
        return val.load(std::memory_order_relaxed);
    }

    // setOpaque() - opaque store
    void setOpaque(int newValue) {
        val.store(newValue, std::memory_order_relaxed);
    }

    // getAcquire() - acquire semantics
    int getAcquire() const {
        return val.load(std::memory_order_acquire);
    }

    // setRelease() - release semantics
    void setRelease(int newValue) {
        val.store(newValue, std::memory_order_release);
    }

    // compareAndSet() - full memory ordering (sequential consistency)
    bool compareAndSet(int expected, int newValue) {
        return val.compare_exchange_strong(expected, newValue,
                                           std::memory_order_seq_cst,
                                           std::memory_order_seq_cst);
    }

    // compareAndExchange() - full ordering
    int compareAndExchange(int expected, int newValue) {
        val.compare_exchange_strong(expected, newValue,
                                    std::memory_order_seq_cst,
                                    std::memory_order_seq_cst);
        return expected;
    }

    // compareAndExchangeAcquire() - acquire ordering on success
    int compareAndExchangeAcquire(int expected, int newValue) {
        val.compare_exchange_strong(expected, newValue,
                                    std::memory_order_acquire,
                                    std::memory_order_acquire);
        return expected;
    }

    // compareAndExchangeRelease() - release ordering on success
    int compareAndExchangeRelease(int expected, int newValue) {
        val.compare_exchange_strong(expected, newValue,
                                    std::memory_order_release,
                                    std::memory_order_relaxed);
        return expected;
    }

    // weakCompareAndSetPlain() - weak, no ordering (plain)
    bool weakCompareAndSetPlain(int expected, int newValue) {
        return val.compare_exchange_weak(expected, newValue,
                                         std::memory_order_relaxed,
                                         std::memory_order_relaxed);
    }

    // weakCompareAndSet() - weak, full ordering
    bool weakCompareAndSet(int expected, int newValue) {
        return val.compare_exchange_weak(expected, newValue,
                                         std::memory_order_seq_cst,
                                         std::memory_order_seq_cst);
    }

    // weakCompareAndSetAcquire() - weak, acquire ordering
    bool weakCompareAndSetAcquire(int expected, int newValue) {
        return val.compare_exchange_weak(expected, newValue,
                                         std::memory_order_acquire,
                                         std::memory_order_acquire);
    }

    // weakCompareAndSetRelease() - weak, release ordering
    bool weakCompareAndSetRelease(int expected, int newValue) {
        return val.compare_exchange_weak(expected, newValue,
                                         std::memory_order_release,
                                         std::memory_order_relaxed);
    }

    // getAndSet() - atomic exchange
    int getAndSet(int newValue) {
        return val.exchange(newValue, std::memory_order_seq_cst);
    }

    // getAndAdd() - atomic fetch-and-add
    int getAndAdd(int delta) {
        return val.fetch_add(delta, std::memory_order_seq_cst);
    }

    // incrementAndGet() - pre-increment
    int incrementAndGet() {
        return val.fetch_add(1, std::memory_order_seq_cst) + 1;
    }

    // weakCompareAndSetVolatile() - weak, volatile semantics (seq_cst)
    bool weakCompareAndSetVolatile(int expected, int newValue) {
        return val.compare_exchange_weak(expected, newValue,
                                         std::memory_order_seq_cst,
                                         std::memory_order_seq_cst);
    }

    // lazySet() - lazy write (store release relaxed)
    void lazySet(int newValue) {
        val.store(newValue, std::memory_order_release);
    }

    // getAndIncrement() - fetch-and-add 1
    int getAndIncrement() {
        return val.fetch_add(1, std::memory_order_seq_cst);
    }

    // getAndDecrement() - fetch-and-sub 1
    int getAndDecrement() {
        return val.fetch_sub(1, std::memory_order_seq_cst);
    }

    // decrementAndGet() - pre-decrement
    int decrementAndGet() {
        return val.fetch_sub(1, std::memory_order_seq_cst) - 1;
    }

    // addAndGet() - add and return new value
    int addAndGet(int delta) {
        return val.fetch_add(delta, std::memory_order_seq_cst) + delta;
    }

    // getAndUpdate() - apply function and return old value
    int getAndUpdate(const IntUnaryOperator& updateFunction) {
        int old = val.load(std::memory_order_seq_cst);
        int next;
        do {
            next = updateFunction(old);
        } while (!val.compare_exchange_weak(old, next,
                                            std::memory_order_seq_cst,
                                            std::memory_order_seq_cst));
        return old;
    }

    // updateAndGet() - apply function and return new value
    int updateAndGet(const IntUnaryOperator& updateFunction) {
        int old = val.load(std::memory_order_seq_cst);
        int next;
        do {
            next = updateFunction(old);
        } while (!val.compare_exchange_weak(old, next,
                                            std::memory_order_seq_cst,
                                            std::memory_order_seq_cst));
        return next;
    }

    // getAndAccumulate() - apply binary function with x and return old value
    int getAndAccumulate(int x, const IntBinaryOperator& accumulatorFunction) {
        int old = val.load(std::memory_order_seq_cst);
        int next;
        do {
            next = accumulatorFunction(old, x);
        } while (!val.compare_exchange_weak(old, next,
                                            std::memory_order_seq_cst,
                                            std::memory_order_seq_cst));
        return old;
    }

    // accumulateAndGet() - apply binary function with x and return new value
    int accumulateAndGet(int x, const IntBinaryOperator& accumulatorFunction) {
        int old = val.load(std::memory_order_seq_cst);
        int next;
        do {
            next = accumulatorFunction(old, x);
        } while (!val.compare_exchange_weak(old, next,
                                            std::memory_order_seq_cst,
                                            std::memory_order_seq_cst));
        return next;
    }

    // getPlain() - plain non-atomic read (no ordering)
    int getPlain() const {
        return val.load(std::memory_order_relaxed);
    }

    // setPlain() - plain non-atomic write (no ordering)
    void setPlain(int newValue) {
        val.store(newValue, std::memory_order_relaxed);
    }

private:
    mutable std::atomic<int> val;
};

// ===== Test functions (translated from Java @Test methods) =====

void getAndAccumulate_test_4782() {
    AtomicInteger atomicInteger1(1);
    IntBinaryOperator intBinaryOperator3; // default constructed (empty)

    try {
        atomicInteger1.getAndAccumulate(10, intBinaryOperator3);
        // If no exception, test fails
        throw std::runtime_error("Expected exception: std::bad_function_call");
    } catch (const std::bad_function_call&) {
        // Expected exception
    }
}