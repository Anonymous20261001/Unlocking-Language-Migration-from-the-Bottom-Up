#include <cstddef> // For NULL
#include <stdexcept> // For std::runtime_error
#include <cassert>   // For assert

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    // Modified to throw NullPointerException if event is null (matching Java behavior)
    void propertyChange(PropertyChangeEvent* evt) {
        if (evt == NULL) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"java.beans.PropertyChangeEvent.getPropertyName()\" because \"e\" is null");
        }
    }
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test function – matches the Java @Test method name
void propertyChange_test_8627() {
    AbstractButton* abstractButton0 = NULL;
    BasicButtonListener basicButtonListener1(abstractButton0);
    PropertyChangeEvent* propertyChangeEvent2 = NULL;
    try {
        basicButtonListener1.propertyChange(propertyChangeEvent2);
        // If we get here, no exception was thrown – fail the test
        assert(false && "Expected exception of type NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception: verify message contains "NullPointerException"
        assert(std::string(e.what()).find("NullPointerException") != std::string::npos && "Unexpected exception message");
    } catch (...) {
        // Any other exception is a failure
        assert(false && "Expected a std::runtime_error");
    }
}