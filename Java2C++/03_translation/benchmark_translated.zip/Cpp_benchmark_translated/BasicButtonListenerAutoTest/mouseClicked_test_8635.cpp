#include <cstddef> // For NULL

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature

void mouseClicked_test_8635() {
    AbstractButton* abstractButton0 = NULL;
    BasicButtonListener instance(abstractButton0);
    MouseEvent* mouseEvent2 = NULL;
    instance.mouseClicked(mouseEvent2);
}