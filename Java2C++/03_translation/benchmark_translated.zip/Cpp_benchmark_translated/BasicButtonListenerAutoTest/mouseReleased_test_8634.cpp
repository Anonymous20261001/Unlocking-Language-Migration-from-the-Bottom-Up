#include <cstddef> // For NULL
#include <stdexcept> // For runtime_error

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent* anEvent) {
        if (anEvent == nullptr) {
            throw std::runtime_error("Cannot invoke \"java.awt.event.MouseEvent.getID()\" because \"anEvent\" is null");
        }
    }
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test function – matches Java @Test method

void mouseReleased_test_8634() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener basicButtonListener1(abstractButton0);
    MouseEvent* mouseEvent2 = nullptr;
    try {
        basicButtonListener1.mouseReleased(mouseEvent2);
        // If we reach here, no exception was thrown -> fail
        throw std::runtime_error("Expected exception of type std::runtime_error; message: Cannot invoke ...");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}