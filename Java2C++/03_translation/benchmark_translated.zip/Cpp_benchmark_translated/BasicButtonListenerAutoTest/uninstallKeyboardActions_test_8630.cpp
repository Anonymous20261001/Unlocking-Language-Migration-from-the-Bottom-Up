#include <cstddef> // For NULL
#include <cassert>   // For assert

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature
void uninstallKeyboardActions_test_8630() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener basicButtonListener1(abstractButton0);
    JComponent* jComponent2 = nullptr;
    try {
        basicButtonListener1.uninstallKeyboardActions(jComponent2);
        assert(false && "Expected exception of type java.lang.NullPointerException");
    } catch (...) {
        // Expected exception.
    }
}