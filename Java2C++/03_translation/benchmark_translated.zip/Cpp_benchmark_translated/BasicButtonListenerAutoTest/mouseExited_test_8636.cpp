#include <cstddef> // For NULL
#include <cassert>  // For assert
#include <stdexcept> // For std::runtime_error

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent* e) {
        // Simulate NullPointerException from Java when e is null
        if (e == nullptr) {
            throw std::runtime_error("Cannot invoke \"java.awt.event.MouseEvent.getSource()\" because \"e\" is null");
        }
    }
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature

void mouseExited_test_8636() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener instance(abstractButton0);
    MouseEvent* mouseEvent2 = nullptr;
    // The following exception was thrown during execution in test generation
    try {
        instance.mouseExited(mouseEvent2);
        assert(false); // Expected exception was not thrown
    } catch (const std::exception& e) {
        // Expected exception.
    }
}