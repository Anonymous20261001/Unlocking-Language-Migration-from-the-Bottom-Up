#include <cstddef> // For NULL
#include <stdexcept> // For std::runtime_error

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {
        // Simulate the NullPointerException that occurs when button is null
        if (button == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.AbstractButton.getMnemonic()\" because \"b\" is null");
        }
    }
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test function – no parameters, body translated from Java
void installKeyboardActions_test_8629() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener basicButtonListener1(abstractButton0);
    JComponent* jComponent2 = nullptr;
    try {
        basicButtonListener1.installKeyboardActions(jComponent2);
        // If we reach here, no exception was thrown – test should fail
        throw std::logic_error("Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception. Test passes.
    }
}