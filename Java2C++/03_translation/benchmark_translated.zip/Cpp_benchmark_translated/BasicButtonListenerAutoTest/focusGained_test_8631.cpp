#include <cstddef> // For NULL
#include <stdexcept> // For std::runtime_error

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent* e) {
        if (e == nullptr) throw std::runtime_error("NullPointerException");
    }
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature
void focusGained_test_8631() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener basicButtonListener1(abstractButton0);
    FocusEvent* focusEvent2 = nullptr;
    try {
        basicButtonListener1.focusGained(focusEvent2);
        // If no exception, fail the test
        throw std::runtime_error("Expected exception");
    } catch (std::exception&) {
        // Expected exception, test passes
    }
}