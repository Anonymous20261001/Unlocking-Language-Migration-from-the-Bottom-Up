#include <cstddef>
#include <stdexcept>
#include <cassert>

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent* e) {
        if (e == NULL) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"java.awt.event.MouseEvent.getSource()\" because \"e\" is null");
        }
    }
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test function – matches the Java @Test method
void mouseEntered_test_8637() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener instance(abstractButton0);
    MouseEvent* mouseEvent2 = nullptr;
    try {
        instance.mouseEntered(mouseEvent2);
        // If we reach here, no exception was thrown – fail the test
        assert(false && "Expected exception of type std::runtime_error; message: Cannot invoke ... because e is null");
    } catch (const std::runtime_error& e) {
        // Expected exception – test passes
    }
}