#include <cstddef> // For NULL
#include <stdexcept> // For std::runtime_error

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent*) {}
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent* anEvent) {
        // Simulate Java NullPointerException when anEvent is null
        if (anEvent == NULL) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"java.awt.event.MouseEvent.getID()\" because \"anEvent\" is null");
        }
    }
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test functions – each matches a Java @Test method name and signature

void mousePressed_test_8633() {
    AbstractButton* abstractButton0 = NULL;
    BasicButtonListener basicButtonListener1(abstractButton0);
    MouseEvent* mouseEvent2 = NULL;
    try {
        basicButtonListener1.mousePressed(mouseEvent2);
        // If no exception was thrown, test fails
        throw std::runtime_error("Expected exception of type std::exception; message: expected NullPointerException");
    } catch (std::exception&) {
        // Expected exception, test passes
    }
}