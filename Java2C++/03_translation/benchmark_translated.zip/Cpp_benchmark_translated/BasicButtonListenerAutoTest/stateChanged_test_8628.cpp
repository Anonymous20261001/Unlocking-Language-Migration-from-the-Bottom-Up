#include <cstddef> // For NULL
#include <stdexcept>
#include <cassert>

// Forward declarations (minimal event/component stubs)
class FocusEvent {};
class MouseEvent {};
class PropertyChangeEvent {};
class ChangeEvent {};
class JComponent { public: virtual ~JComponent() {} };
class AbstractButton : public JComponent { public: virtual ~AbstractButton() {} };

// BasicButtonListener mimicking the Java class
class BasicButtonListener {
private:
    AbstractButton* button;
public:
    BasicButtonListener(AbstractButton* b) : button(b) {}

    void propertyChange(PropertyChangeEvent*) {}
    void stateChanged(ChangeEvent* e) {
        if (e == nullptr) {
            throw std::runtime_error("NullPointerException");
        }
    }
    void installKeyboardActions(JComponent*) {}
    void uninstallKeyboardActions(JComponent*) {}
    void focusGained(FocusEvent*) {}
    void focusLost(FocusEvent*) {}
    void mousePressed(MouseEvent*) {}
    void mouseReleased(MouseEvent*) {}
    void mouseClicked(MouseEvent*) {}
    void mouseExited(MouseEvent*) {}
    void mouseEntered(MouseEvent*) {}
    void mouseMoved(MouseEvent*) {}
    void mouseDragged(MouseEvent*) {}
};

// Test function – translated from Java
void stateChanged_test_8628() {
    AbstractButton* abstractButton0 = nullptr;
    BasicButtonListener instance(abstractButton0);
    ChangeEvent* changeEvent2 = nullptr;
    try {
        instance.stateChanged(changeEvent2);
        // If we reach here, no exception was thrown – fail the test
        assert(false && "Expected exception of type NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}