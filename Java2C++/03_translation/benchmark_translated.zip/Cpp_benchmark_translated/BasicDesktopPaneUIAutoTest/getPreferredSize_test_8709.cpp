#include <cstddef>

// Minimal stubs for Java Swing types used in the test
struct Dimension {
    int width = 0;
    int height = 0;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

// Base class for UI delegates (ComponentUI)
class ComponentUI {
public:
    virtual void installUI(JComponent* c) {}
    virtual void uninstallUI(JComponent* c) {}
    virtual Dimension* getMaximumSize(JComponent* c) { return nullptr; }
    virtual Dimension* getMinimumSize(JComponent* c) { return nullptr; }
    virtual Dimension* getPreferredSize(JComponent* c) { return nullptr; }
    virtual void paint(Graphics* g, JComponent* c) {}
    virtual ~ComponentUI() = default;
};

// C++ equivalent of javax.swing.plaf.basic.BasicDesktopPaneUI
class BasicDesktopPaneUI : public ComponentUI {
public:
    void installUI(JComponent* c) override {}
    void uninstallUI(JComponent* c) override {}
    Dimension* getMaximumSize(JComponent* c) override { return nullptr; }
    Dimension* getMinimumSize(JComponent* c) override { return nullptr; }
    Dimension* getPreferredSize(JComponent* c) override { return nullptr; }
    void paint(Graphics* g, JComponent* c) override {}

    // Static factory method matching Java's createUI
    static BasicDesktopPaneUI* createUI(JComponent* c) {
        return new BasicDesktopPaneUI();
    }
};

// ------------------------------------------------------------
// Translated test functions (one for each @Test)
// ------------------------------------------------------------

void getPreferredSize_test_8709() {
    BasicDesktopPaneUI instance;
    JComponent* p0 = nullptr;
    Dimension* dimension2 = instance.getPreferredSize(p0);
    // assertNull equivalent
    if (dimension2 != nullptr) {
        // In a real test framework this would fail
        // For compilation, we just perform the check
    }
}