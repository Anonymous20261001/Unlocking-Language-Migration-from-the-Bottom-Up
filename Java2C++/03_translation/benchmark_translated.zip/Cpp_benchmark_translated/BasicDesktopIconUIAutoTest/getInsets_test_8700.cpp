#include <cstddef>
#include <stdexcept>
#include <cassert>

// Minimal stubs for Java Swing classes
class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

class Insets {
public:
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
};

// Equivalent of javax.swing.plaf.basic.BasicDesktopIconUI
class BasicDesktopIconUI {
public:
    BasicDesktopIconUI() = default;
    ~BasicDesktopIconUI() = default;

    void deiconize() {
        // No-op
    }

    void installUI(JComponent* c) {
        // No-op
    }

    void uninstallUI(JComponent* c) {
        // No-op
    }

    static BasicDesktopIconUI* createUI(JComponent* c) {
        return new BasicDesktopIconUI();
    }

    Insets getInsets(JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JInternalFrame$JDesktopIcon.getInternalFrame()\" because \"this.desktopIcon\" is null");
        }
        return Insets();
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }
};

// Translated test function
void getInsets_test_8700() {
    BasicDesktopIconUI basicDesktopIconUI0;
    JComponent* jComponent1 = nullptr;
    try {
        Insets insets2 = basicDesktopIconUI0.getInsets(jComponent1);
        assert(false && "Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}