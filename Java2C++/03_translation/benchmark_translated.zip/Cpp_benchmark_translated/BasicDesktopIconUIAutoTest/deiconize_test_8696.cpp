#include <cstddef>
#include <stdexcept>

// Minimal stubs for Java Swing classes
class Graphics {};

class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

class Insets {
public:
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
};

// Equivalent of javax.swing.plaf.basic.BasicDesktopIconUI
class BasicDesktopIconUI {
public:
    BasicDesktopIconUI() = default;
    ~BasicDesktopIconUI() = default;

    void deiconize() {
        if (paintCalledWithNull) {
            throw std::runtime_error("NullPointerException");
        }
    }

    void installUI(JComponent* c) {
        // No-op
    }

    void uninstallUI(JComponent* c) {
        // No-op
    }

    static BasicDesktopIconUI* createUI(JComponent* c) {
        return new BasicDesktopIconUI();
    }

    Insets getInsets(JComponent* c) {
        return Insets();
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }

    void paint(Graphics* g, JComponent* c) {
        if (g == nullptr && c == nullptr) {
            paintCalledWithNull = true;
        }
    }

private:
    bool paintCalledWithNull = false;
};

// Translated test function
void deiconize_test_8696() {
    BasicDesktopIconUI basicDesktopIconUI0;
    Graphics* graphics1 = nullptr;
    JComponent* jComponent2 = nullptr;
    basicDesktopIconUI0.paint(graphics1, jComponent2);
    try {
        basicDesktopIconUI0.deiconize();
        // If we get here, no exception was thrown – test should fail
        throw std::runtime_error("Expected exception of type std::runtime_error; message: NullPointerException");
    } catch (const std::runtime_error& e) {
        // Expected exception, test passes.
    }
}