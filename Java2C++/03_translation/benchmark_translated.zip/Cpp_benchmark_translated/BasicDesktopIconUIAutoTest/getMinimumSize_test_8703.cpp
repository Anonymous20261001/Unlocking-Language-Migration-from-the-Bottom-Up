#include <cstddef>
#include <stdexcept>
#include <cstdlib>

// Minimal stubs for Java Swing classes
class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

class Insets {
public:
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
};

// Equivalent of javax.swing.plaf.basic.BasicDesktopIconUI
class BasicDesktopIconUI {
public:
    BasicDesktopIconUI() = default;
    ~BasicDesktopIconUI() = default;

    void deiconize() {
        // No-op
    }

    void installUI(JComponent* c) {
        // No-op
    }

    void uninstallUI(JComponent* c) {
        // No-op
    }

    static BasicDesktopIconUI* createUI(JComponent* c) {
        return new BasicDesktopIconUI();
    }

    Insets getInsets(JComponent* c) {
        return Insets();
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        if (c == nullptr) {
            throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JComponent.getMinimumSize()\" because \"this.iconPane\" is null");
        }
        return Dimension();
    }
};

// Translated test functions (exact names from Java)

void getMinimumSize_test_8703() {
    BasicDesktopIconUI basicDesktopIconUI0;
    JComponent* jComponent1 = nullptr;
    try {
        basicDesktopIconUI0.getMinimumSize(jComponent1);
        std::abort(); // fail if no exception
    } catch (const std::runtime_error& e) {
        // Expected exception, test passes
    }
}