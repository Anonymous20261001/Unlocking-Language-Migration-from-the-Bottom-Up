#include <cstddef>
#include <cassert>
#include <typeinfo>

// Minimal stubs for Java Swing classes
class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

class Insets {
public:
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
};

// Equivalent of javax.swing.plaf.basic.BasicDesktopIconUI
class BasicDesktopIconUI {
public:
    BasicDesktopIconUI() = default;
    ~BasicDesktopIconUI() = default;

    void deiconize() {
        // No-op
    }

    void installUI(JComponent* c) {
        // No-op
    }

    void uninstallUI(JComponent* c) {
        // No-op
    }

    static BasicDesktopIconUI* createUI(JComponent* c) {
        return new BasicDesktopIconUI();
    }

    Insets getInsets(JComponent* c) {
        return Insets();
    }

    Dimension getMaximumSize(JComponent* c) {
        return Dimension();
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }
};

// Translated test function (equivalent to Java test)
void createUI_test_8699() {
    JComponent* jComponent0 = nullptr;
    BasicDesktopIconUI* componentUI1 = BasicDesktopIconUI::createUI(jComponent0);
    assert(componentUI1 != nullptr);
    const std::type_info& wildcardClass2 = typeid(*componentUI1);
    assert(wildcardClass2.name() != nullptr);
    delete componentUI1;
}