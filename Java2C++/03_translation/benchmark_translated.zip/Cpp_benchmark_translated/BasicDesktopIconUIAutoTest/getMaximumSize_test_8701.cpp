#include <cstddef>
#include <stdexcept>

// Minimal stubs for Java Swing classes
class JComponent {
public:
    JComponent() = default;
    virtual ~JComponent() = default;
};

class Insets {
public:
    int top, left, bottom, right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
};

// Equivalent of javax.swing.plaf.basic.BasicDesktopIconUI
class BasicDesktopIconUI {
private:
    JComponent* iconPane;

public:
    BasicDesktopIconUI() : iconPane(nullptr) {}
    ~BasicDesktopIconUI() = default;

    void deiconize() {
        // No-op
    }

    void installUI(JComponent* c) {
        // No-op
    }

    void uninstallUI(JComponent* c) {
        // No-op
    }

    static BasicDesktopIconUI* createUI(JComponent* c) {
        return new BasicDesktopIconUI();
    }

    Insets getInsets(JComponent* c) {
        return Insets();
    }

    Dimension getMaximumSize(JComponent* c) {
        // Replicate Java behavior: NullPointerException because iconPane is null
        if (iconPane == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComponent.getMaximumSize()\" because \"this.iconPane\" is null");
        }
        return Dimension();
    }

    Dimension getPreferredSize(JComponent* c) {
        return Dimension();
    }

    Dimension getMinimumSize(JComponent* c) {
        return Dimension();
    }
};

// Translated test functions (exact names from Java)

void getMaximumSize_test_8701() {
    BasicDesktopIconUI instance;
    JComponent* comp = nullptr;
    try {
        instance.getMaximumSize(comp);
        // Should not reach here; if we do, fail the test
        throw std::logic_error("Expected exception of type std::runtime_error; message: Cannot invoke \"javax.swing.JComponent.getMaximumSize()\" because \"this.iconPane\" is null");
    } catch (const std::runtime_error& e) {
        // Expected exception.
    }
}