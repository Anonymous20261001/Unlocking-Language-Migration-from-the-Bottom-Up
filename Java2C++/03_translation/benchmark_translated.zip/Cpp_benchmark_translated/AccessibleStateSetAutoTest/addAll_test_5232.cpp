#include <set>
#include <vector>
#include <string>
#include <sstream>

class AccessibleState {
public:
    std::string name;

    AccessibleState() : name("") {}
    explicit AccessibleState(const std::string& name) : name(name) {}

    bool operator==(const AccessibleState& other) const {
        return name == other.name;
    }
    bool operator<(const AccessibleState& other) const {
        return name < other.name;
    }
};

class AccessibleStateSet {
private:
    std::set<AccessibleState> states;

public:
    bool add(const AccessibleState& state) {
        return states.insert(state).second;
    }

    bool remove(const AccessibleState& state) {
        return states.erase(state) > 0;
    }

    bool contains(const AccessibleState& state) const {
        return states.find(state) != states.end();
    }

    void clear() {
        states.clear();
    }

    std::vector<AccessibleState> toArray() const {
        return std::vector<AccessibleState>(states.begin(), states.end());
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "[";
        bool first = true;
        for (const auto& s : states) {
            if (!first) oss << ", ";
            oss << s.name;
            first = false;
        }
        oss << "]";
        return oss.str();
    }

    bool addAll(const std::vector<AccessibleState>& arr) {
        bool changed = false;
        for (const auto& s : arr) {
            if (add(s)) changed = true;
        }
        return changed;
    }
};

// Test functions

void addAll_test_5232() {
    std::vector<AccessibleState> accessibleStateArray0 = {};
    AccessibleStateSet accessibleStateSet1;
    // Note: Java constructor initializes set with array; since array is empty, default set is fine.
    std::vector<AccessibleState> accessibleStateArray2 = {};
    accessibleStateSet1.addAll(accessibleStateArray2);
}