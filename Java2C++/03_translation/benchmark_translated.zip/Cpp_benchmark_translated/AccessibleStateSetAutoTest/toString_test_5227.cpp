#include <set>
#include <vector>
#include <string>
#include <sstream>
#include <optional>
#include <cassert>

class AccessibleState {
public:
    std::string name;

    AccessibleState() : name("") {}
    explicit AccessibleState(const std::string& name) : name(name) {}

    bool operator==(const AccessibleState& other) const {
        return name == other.name;
    }
    bool operator<(const AccessibleState& other) const {
        return name < other.name;
    }
};

class AccessibleStateSet {
private:
    std::set<AccessibleState> states;

public:
    AccessibleStateSet() = default;

    // Constructor from vector (like Java array constructor)
    AccessibleStateSet(const std::vector<AccessibleState>& arr) {
        for (const auto& s : arr) {
            states.insert(s);
        }
    }

    bool add(const AccessibleState& state) {
        return states.insert(state).second;
    }

    bool remove(const AccessibleState& state) {
        return states.erase(state) > 0;
    }

    bool contains(const AccessibleState& state) const {
        return states.find(state) != states.end();
    }

    void clear() {
        states.clear();
    }

    std::vector<AccessibleState> toArray() const {
        return std::vector<AccessibleState>(states.begin(), states.end());
    }

    // Changed to return optional to allow null semantics
    std::optional<std::string> toString() const {
        if (states.empty()) {
            return std::nullopt;
        }
        std::ostringstream oss;
        oss << "[";
        bool first = true;
        for (const auto& s : states) {
            if (!first) oss << ", ";
            oss << s.name;
            first = false;
        }
        oss << "]";
        return oss.str();
    }

    bool addAll(const std::vector<AccessibleState>& arr) {
        bool changed = false;
        for (const auto& s : arr) {
            if (add(s)) changed = true;
        }
        return changed;
    }
};

// Test function
void toString_test_5227() {
    std::vector<AccessibleState> accessibleStateArray0 = {};
    AccessibleStateSet accessibleStateSet1(accessibleStateArray0);
    std::optional<std::string> str2 = accessibleStateSet1.toString();
    // Assert that the optional has no value (null)
    assert(!str2.has_value());
}