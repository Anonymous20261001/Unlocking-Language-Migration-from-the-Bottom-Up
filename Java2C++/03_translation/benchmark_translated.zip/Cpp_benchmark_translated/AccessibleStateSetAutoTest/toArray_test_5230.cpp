#include <set>
#include <vector>
#include <string>
#include <sstream>
#include <cassert>

class AccessibleState {
public:
    std::string name;

    AccessibleState() : name("") {}
    explicit AccessibleState(const std::string& name) : name(name) {}

    bool operator==(const AccessibleState& other) const {
        return name == other.name;
    }
    bool operator<(const AccessibleState& other) const {
        return name < other.name;
    }
};

class AccessibleStateSet {
private:
    std::set<AccessibleState> states;

public:
    bool add(const AccessibleState& state) {
        return states.insert(state).second;
    }

    bool remove(const AccessibleState& state) {
        return states.erase(state) > 0;
    }

    bool contains(const AccessibleState& state) const {
        return states.find(state) != states.end();
    }

    void clear() {
        states.clear();
    }

    std::vector<AccessibleState> toArray() const {
        return std::vector<AccessibleState>(states.begin(), states.end());
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "[";
        bool first = true;
        for (const auto& s : states) {
            if (!first) oss << ", ";
            oss << s.name;
            first = false;
        }
        oss << "]";
        return oss.str();
    }

    bool addAll(const std::vector<AccessibleState>& arr) {
        bool changed = false;
        for (const auto& s : arr) {
            if (add(s)) changed = true;
        }
        return changed;
    }
};

// Test functions

void toArray_test_5230() {
    AccessibleStateSet instance;
    std::vector<AccessibleState> emptyArr;
    instance.addAll(emptyArr);
    std::vector<AccessibleState> result = instance.toArray();
    assert(result.empty());
}