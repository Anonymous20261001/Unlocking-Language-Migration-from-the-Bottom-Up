#include <atomic>
#include <functional>
#include <string>
#include <sstream>
#include <cassert>
#include <iostream>

// Forward declarations for functional types used in the API
using UnaryOperator = std::function<void*(void*)>;
using BinaryOperator = std::function<void*(void*, void*)>;

/**
 * C++ equivalent of java.util.concurrent.atomic.AtomicReference.
 * Stores a void* (nullptr by default) and provides atomic operations
 * with memory ordering similar to the Java API.
 */
class AtomicReference {
private:
    std::atomic<void*> m_ref;

public:
    AtomicReference() : m_ref(nullptr) {}
    // Added constructor with initial value for test compatibility
    explicit AtomicReference(void* initial) : m_ref(initial) {}

    // ----- simple get / set -----
    void* get() {
        return m_ref.load(std::memory_order_seq_cst);
    }

    void set(void* newValue) {
        m_ref.store(newValue, std::memory_order_seq_cst);
    }

    // ----- toString (Java style) -----
    std::string toString() {
        std::ostringstream oss;
        oss << "AtomicReference@" << std::hex << m_ref.load(std::memory_order_seq_cst);
        return oss.str();
    }

    // ----- opaque (relaxed) -----
    void* getOpaque() {
        return m_ref.load(std::memory_order_relaxed);
    }

    void setOpaque(void* newValue) {
        m_ref.store(newValue, std::memory_order_relaxed);
    }

    // ----- acquire / release -----
    void* getAcquire() {
        return m_ref.load(std::memory_order_acquire);
    }

    void setRelease(void* newValue) {
        m_ref.store(newValue, std::memory_order_release);
    }

    // ----- compareAndSet (strong, seq_cst) -----
    bool compareAndSet(void* expected, void* newValue) {
        return m_ref.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
    }

    // ----- compareAndExchange variants -----
    void* compareAndExchange(void* expected, void* newValue) {
        m_ref.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
        return expected;
    }

    void* compareAndExchange(void* expected, void* newValue, std::memory_order order) {
        m_ref.compare_exchange_strong(expected, newValue, order);
        return expected;
    }

    void* compareAndExchangeAcquire(void* expected, void* newValue) {
        return compareAndExchange(expected, newValue, std::memory_order_acquire);
    }

    void* compareAndExchangeRelease(void* expected, void* newValue) {
        return compareAndExchange(expected, newValue, std::memory_order_release);
    }

    // ----- weakCompareAndSet variants -----
    bool weakCompareAndSetPlain(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_relaxed);
    }

    bool weakCompareAndSet(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetAcquire(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_acquire);
    }

    bool weakCompareAndSetRelease(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_release);
    }

    bool weakCompareAndSetVolatile(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    // ----- getAndSet -----
    void* getAndSet(void* newValue) {
        return m_ref.exchange(newValue, std::memory_order_seq_cst);
    }

    // ----- lazySet (release) -----
    void lazySet(void* newValue) {
        m_ref.store(newValue, std::memory_order_release);
    }

    // ----- getAndUpdate / updateAndGet -----
    void* getAndUpdate(UnaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return old;
            }
        }
    }

    void* updateAndGet(UnaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return newVal;
            }
        }
    }

    // ----- getAndAccumulate / accumulateAndGet -----
    void* getAndAccumulate(void* x, BinaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old, x);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return old;
            }
        }
    }

    void* accumulateAndGet(void* x, BinaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old, x);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return newVal;
            }
        }
    }

    // ----- getPlain / setPlain (relaxed) -----
    void* getPlain() {
        return m_ref.load(std::memory_order_relaxed);
    }

    void setPlain(void* newValue) {
        m_ref.store(newValue, std::memory_order_relaxed);
    }
};

// ============================
// Translated test function
// ============================

void get_test_4889() {
    // Simulate java.lang.Object and java.lang.Class
    // We'll use a static array to represent a unique "class" object.
    static char dummyClassObject = 0;
    void* obj0_class = &dummyClassObject;  // simulates the Class<?> object

    // Cast to TypeDescriptor (just reuse the same pointer in C++)
    void* typeDescriptorAtomicReference2_initial = obj0_class;

    // Create AtomicReference<TypeDescriptor> with the initial value
    AtomicReference typeDescriptorAtomicReference2(typeDescriptorAtomicReference2_initial);

    // Call get() and assert non-null
    void* typeDescriptor3 = typeDescriptorAtomicReference2.get();
    assert(typeDescriptor3 != nullptr);
}