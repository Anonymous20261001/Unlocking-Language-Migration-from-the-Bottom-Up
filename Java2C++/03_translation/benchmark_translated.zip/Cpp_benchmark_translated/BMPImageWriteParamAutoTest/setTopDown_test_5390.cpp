#include <cstdint>

class BMPImageWriteParam {
private:
    bool topDown;

public:
    BMPImageWriteParam() : topDown(false) {}

    void setTopDown(bool p0) {
        topDown = p0;
    }

    bool isTopDown() {
        return topDown;
    }
};

// Test functions (equivalent to the Java @Test methods)

void setTopDown_test_5390() {
    BMPImageWriteParam instance;
    instance.setTopDown(true);
}