#include <cstdint>
#include <cassert>

class BMPImageWriteParam {
private:
    bool topDown;

public:
    BMPImageWriteParam() : topDown(false) {}

    void setTopDown(bool p0) {
        topDown = p0;
    }

    bool isTopDown() {
        return topDown;
    }
};

// Test functions (equivalent to the Java @Test methods)

void isTopDown_test_5391() {
    BMPImageWriteParam instance;
    bool result = instance.isTopDown();
    assert(result == false);
}