#include <memory>
#include <cassert>

// Base class for borders (minimal interface)
class Border {
public:
    virtual ~Border() = default;
};

// Class equivalent to javax.swing.plaf.basic.BasicBorders
class BasicBorders {
public:
    BasicBorders() = default;

    static std::shared_ptr<Border> getButtonBorder();
    static std::shared_ptr<Border> getRadioButtonBorder();
    static std::shared_ptr<Border> getToggleButtonBorder();
    static std::shared_ptr<Border> getMenuBarBorder();
    static std::shared_ptr<Border> getSplitPaneBorder();
    static std::shared_ptr<Border> getSplitPaneDividerBorder();
    static std::shared_ptr<Border> getTextFieldBorder();
    static std::shared_ptr<Border> getProgressBarBorder();
    static std::shared_ptr<Border> getInternalFrameBorder();
};

// Static method implementations (return shared singletons)
std::shared_ptr<Border> BasicBorders::getButtonBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getRadioButtonBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getToggleButtonBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getMenuBarBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getSplitPaneBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getSplitPaneDividerBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getTextFieldBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getProgressBarBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

std::shared_ptr<Border> BasicBorders::getInternalFrameBorder() {
    static auto border = std::make_shared<Border>();
    return border;
}

// C++ test functions (exact Java names)

void getTextFieldBorder_test_8624() {
    auto border0 = BasicBorders::getTextFieldBorder();
    assert(border0 != nullptr);
}