#include <iostream>
#include <memory>
#include <stdexcept>

// Minimal stubs for Java AWT/Swing classes used in the tests
class Graphics {
public:
    virtual ~Graphics() = default;
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

class JComboBox : public JComponent {
public:
    virtual ~JComboBox() = default;
};

// Forward declare return types needed for some methods
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Accessible stubs (return types only, not used in tests)
class Accessible {
public:
    virtual ~Accessible() = default;
};

// Additional stub for ComboPopup (needed for uninstallUI test)
class ComboPopup {
public:
    void uninstallingUI() {}
};

// Main class to be tested (modified to support the null pointer test)
class BasicComboBoxUI {
public:
    BasicComboBoxUI() : popup(nullptr) {}
    virtual ~BasicComboBoxUI() = default;

    // Modified to accept a pointer and throw if popup is null
    void uninstallUI(JComponent* c) {
        if (popup == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.plaf.basic.ComboPopup.uninstallingUI()\" because \"this.popup\" is null");
        }
        // In a real implementation, popup->uninstallingUI() would be called
    }

    void configureArrowButton() {
        // Stub: no operation
    }

    void addEditor() {
        // Stub
    }

    void unconfigureArrowButton() {
        // Stub
    }

    void paintCurrentValueBackground(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void paintCurrentValue(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void removeEditor() {
        // Stub
    }

    void installUI(JComponent& c) {
        // Stub
    }

    void setPopupVisible(JComboBox& c, bool b) {
        // Stub
    }

    bool isPopupVisible(JComboBox& c) {
        return false; // stub
    }

    static BasicComboBoxUI* createUI(JComponent& c) {
        return new BasicComboBoxUI(); // Java returns a new instance
    }

    Dimension getMaximumSize(JComponent& c) {
        return Dimension(); // stub
    }

    void paint(Graphics& g, JComponent& c) {
        // Stub
    }

    int getAccessibleChildrenCount(JComponent& c) {
        return 0; // stub
    }

    Accessible* getAccessibleChild(JComponent& c, int index) {
        return nullptr; // stub
    }

    Dimension getPreferredSize(JComponent& c) {
        return Dimension(); // stub
    }

    Dimension getMinimumSize(JComponent& c) {
        return Dimension(); // stub
    }

    bool isFocusTraversable(JComboBox& c) {
        return false; // stub
    }

    int getBaseline(JComponent& c, int width, int height) {
        return 0; // stub
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return BaselineResizeBehavior::OTHER; // stub
    }

private:
    ComboPopup* popup; // added for testing
};

// ==================== Test functions ====================
// Translated from Java test: uninstallUI_test_8674

void uninstallUI_test_8674() {
    BasicComboBoxUI instance;
    JComponent* jComponent1 = nullptr;
    try {
        instance.uninstallUI(jComponent1);
        // If no exception, fail
        throw std::runtime_error("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.plaf.basic.ComboPopup.uninstallingUI()\" because \"this.popup\" is null");
    } catch (const std::runtime_error& e) {
        // Expected exception
    }
}