#include <iostream>
#include <memory>
#include <stdexcept>
#include <cassert>

// Minimal stubs for Java AWT/Swing classes used in the tests
class Graphics {
public:
    virtual ~Graphics() = default;
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

class JComboBox : public JComponent {
public:
    virtual ~JComboBox() = default;
};

// Forward declare return types needed for some methods
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Accessible stubs (return types only, not used in tests)
class Accessible {
public:
    virtual ~Accessible() = default;
};

// Main class to be tested (modified to support test semantics)
class BasicComboBoxUI {
public:
    BasicComboBoxUI() : comboBox(nullptr) {}
    virtual ~BasicComboBoxUI() = default;

    // Modified to accept pointers and throw when comboBox is null
    void paintCurrentValue(Graphics* g, Rectangle* r, bool b) {
        if (comboBox == nullptr) {
            throw std::runtime_error("Cannot invoke \"javax.swing.JComboBox.getRenderer()\" because \"this.comboBox\" is null");
        }
        // Stub normally would do something
    }

    void configureArrowButton() {
        // Stub: no operation
    }

    void addEditor() {
        // Stub
    }

    void unconfigureArrowButton() {
        // Stub
    }

    void paintCurrentValueBackground(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void removeEditor() {
        // Stub
    }

    void installUI(JComponent& c) {
        // Stub
    }

    void uninstallUI(JComponent& c) {
        // Stub
    }

    void setPopupVisible(JComboBox& c, bool b) {
        // Stub
    }

    bool isPopupVisible(JComboBox& c) {
        return false; // stub
    }

    static BasicComboBoxUI* createUI(JComponent& c) {
        return new BasicComboBoxUI(); // Java returns a new instance
    }

    Dimension getMaximumSize(JComponent& c) {
        return Dimension(); // stub
    }

    void paint(Graphics& g, JComponent& c) {
        // Stub
    }

    int getAccessibleChildrenCount(JComponent& c) {
        return 0; // stub
    }

    Accessible* getAccessibleChild(JComponent& c, int index) {
        return nullptr; // stub
    }

    Dimension getPreferredSize(JComponent& c) {
        return Dimension(); // stub
    }

    Dimension getMinimumSize(JComponent& c) {
        return Dimension(); // stub
    }

    bool isFocusTraversable(JComboBox& c) {
        return false; // stub
    }

    int getBaseline(JComponent& c, int width, int height) {
        return 0; // stub
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return BaselineResizeBehavior::OTHER; // stub
    }

protected:
    JComboBox* comboBox; // field used by paintCurrentValue
};

// ==================== Test functions ====================
void paintCurrentValue_test_8671() {
    BasicComboBoxUI instance;
    Graphics* p0 = nullptr;
    Rectangle* p1 = nullptr;
    bool p2 = true;
    try {
        instance.paintCurrentValue(p0, p1, p2);
        // If we reach here, exception was not thrown -> test fails
        assert(false && "Expected exception of type std::runtime_error");
    } catch (const std::runtime_error& e) {
        // Expected exception, test passes (do nothing)
    }
}