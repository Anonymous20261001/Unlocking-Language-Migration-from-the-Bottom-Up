#include <iostream>
#include <memory>
#include <stdexcept>

// Minimal stubs for Java AWT/Swing classes used in the tests
class Graphics {
public:
    virtual ~Graphics() = default;
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

class JComboBox : public JComponent {
public:
    virtual ~JComboBox() = default;
};

// Forward declare return types needed for some methods
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Accessible stubs (return types only, not used in tests)
class Accessible {
public:
    virtual ~Accessible() = default;
};

// Main class to be tested
class BasicComboBoxUI {
public:
    BasicComboBoxUI() = default;
    virtual ~BasicComboBoxUI() = default;

    void configureArrowButton() {
        // Stub: no operation
    }

    void addEditor() {
        // Stub
    }

    void unconfigureArrowButton() {
        // Stub
    }

    void paintCurrentValueBackground(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void paintCurrentValue(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void removeEditor() {
        // Stub
    }

    void installUI(JComponent& c) {
        // Stub
    }

    void uninstallUI(JComponent& c) {
        // Stub
    }

    void setPopupVisible(JComboBox& c, bool b) {
        // Stub
    }

    bool isPopupVisible(JComboBox& c) {
        return false; // stub
    }

    static BasicComboBoxUI* createUI(JComponent& c) {
        return new BasicComboBoxUI(); // Java returns a new instance
    }

    // Modified to accept pointer to allow null testing
    Dimension getMaximumSize(JComponent* c) {
        if (!c) throw std::runtime_error("null pointer");
        return Dimension(); // stub
    }

    void paint(Graphics& g, JComponent& c) {
        // Stub
    }

    int getAccessibleChildrenCount(JComponent& c) {
        return 0; // stub
    }

    Accessible* getAccessibleChild(JComponent& c, int index) {
        return nullptr; // stub
    }

    // Modified to accept pointer to allow null testing
    Dimension getPreferredSize(JComponent* c) {
        if (!c) throw std::runtime_error("null pointer");
        return Dimension(); // stub
    }

    // Modified to accept pointer to allow null testing
    Dimension getMinimumSize(JComponent* c) {
        if (!c) throw std::runtime_error("null pointer");
        return Dimension(); // stub
    }

    bool isFocusTraversable(JComboBox& c) {
        return false; // stub
    }

    int getBaseline(JComponent& c, int width, int height) {
        return 0; // stub
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return BaselineResizeBehavior::OTHER; // stub
    }
};

// ==================== Test functions ====================
// Each matches exactly the corresponding Java @Test method name and signature

void getMinimumSize_test_8683() {
    BasicComboBoxUI basicComboBoxUI0;
    JComponent* jComponent1 = nullptr;
    try {
        Dimension dimension2 = basicComboBoxUI0.getMinimumSize(jComponent1);
        throw std::runtime_error("Expected NullPointerException but none was thrown");
    } catch (const std::runtime_error& e) {
        // Expected exception
    }
}