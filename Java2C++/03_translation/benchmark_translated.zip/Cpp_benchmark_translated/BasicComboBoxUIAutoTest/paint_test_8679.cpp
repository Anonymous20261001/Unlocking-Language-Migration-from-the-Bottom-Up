#include <iostream>
#include <memory>
#include <stdexcept>
#include <cassert>

// Minimal stubs for Java AWT/Swing classes used in the tests
class Graphics {
public:
    virtual ~Graphics() = default;
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
};

class JComponent {
public:
    virtual ~JComponent() = default;
};

class JComboBox : public JComponent {
public:
    virtual ~JComboBox() = default;
    bool hasFocus() { return false; } // stub, added for completeness
};

// Forward declare return types needed for some methods
class Dimension {
public:
    int width, height;
    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// Accessible stubs (return types only, not used in tests)
class Accessible {
public:
    virtual ~Accessible() = default;
};

// Custom exception to mimic Java's NullPointerException
class NullPointerException : public std::exception {
public:
    const char* what() const noexcept override {
        return "NullPointerException";
    }
};

// Main class to be tested
class BasicComboBoxUI {
public:
    BasicComboBoxUI() : comboBox(nullptr) {}
    virtual ~BasicComboBoxUI() = default;

    void configureArrowButton() {
        // Stub: no operation
    }

    void addEditor() {
        // Stub
    }

    void unconfigureArrowButton() {
        // Stub
    }

    void paintCurrentValueBackground(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void paintCurrentValue(Graphics& g, Rectangle& r, bool b) {
        // Stub
    }

    void removeEditor() {
        // Stub
    }

    void installUI(JComponent& c) {
        // Stub
    }

    void uninstallUI(JComponent& c) {
        // Stub
    }

    void setPopupVisible(JComboBox& c, bool b) {
        // Stub
    }

    bool isPopupVisible(JComboBox& c) {
        return false; // stub
    }

    static BasicComboBoxUI* createUI(JComponent& c) {
        return new BasicComboBoxUI(); // Java returns a new instance
    }

    Dimension getMaximumSize(JComponent& c) {
        return Dimension(); // stub
    }

    // Modified to take pointers and throw if comboBox is null
    void paint(Graphics* g, JComponent* c) {
        if (comboBox == nullptr) {
            throw NullPointerException();
        }
        // Original stub would use comboBox->hasFocus() etc.
        // Here we just don't dereference the pointers.
    }

    int getAccessibleChildrenCount(JComponent& c) {
        return 0; // stub
    }

    Accessible* getAccessibleChild(JComponent& c, int index) {
        return nullptr; // stub
    }

    Dimension getPreferredSize(JComponent& c) {
        return Dimension(); // stub
    }

    Dimension getMinimumSize(JComponent& c) {
        return Dimension(); // stub
    }

    bool isFocusTraversable(JComboBox& c) {
        return false; // stub
    }

    int getBaseline(JComponent& c, int width, int height) {
        return 0; // stub
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent& c) {
        return BaselineResizeBehavior::OTHER; // stub
    }

private:
    JComboBox* comboBox; // initially null
};

// ==================== Test functions ====================
// Each matches exactly the corresponding Java @Test method name and signature

void paint_test_8679() {
    BasicComboBoxUI instance;
    Graphics* graphics1 = nullptr;
    JComponent* jComponent2 = nullptr;
    bool exceptionThrown = false;
    try {
        instance.paint(graphics1, jComponent2);
    } catch (NullPointerException& e) {
        exceptionThrown = true;
    }
    if (!exceptionThrown) {
        throw std::logic_error("Expected NullPointerException but none was thrown");
    }
}