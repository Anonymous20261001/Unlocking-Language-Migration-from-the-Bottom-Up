#include <string>
#include <iostream>
#include <cassert>

// Minimal C++ equivalent of java.lang.reflect.Method
// Only contains a name for identification; tests do not use its internals.
class Method {
private:
    std::string name_;
public:
    Method() : name_("") {}
    explicit Method(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
};

// C++ equivalent of java.lang.annotation.AnnotationTypeMismatchException
// Modified to store a pointer to Method to allow null representation.
class AnnotationTypeMismatchException {
private:
    const Method* method_;
    std::string foundType_;
public:
    AnnotationTypeMismatchException(const Method* method, const std::string& foundType)
        : method_(method), foundType_(foundType) {}

    const Method* element() const { return method_; }
    std::string foundType() const { return foundType_; }
};

// Test function (parameterless, matches Java test)
void element_test_2373() {
    const Method* method0 = nullptr;
    AnnotationTypeMismatchException instance(method0, "hi!");
    const Method* result = instance.element();
    assert(result == nullptr);
}