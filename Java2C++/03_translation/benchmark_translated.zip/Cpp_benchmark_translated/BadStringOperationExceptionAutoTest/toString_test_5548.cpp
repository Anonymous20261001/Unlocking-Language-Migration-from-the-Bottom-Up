#include <string>
#include <exception>
#include <stdexcept>

class BadStringOperationException : public std::exception {
private:
    std::string message;

public:
    explicit BadStringOperationException(const std::string& msg) : message(msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }

    std::string toString() const {
        return std::string("javax.management.BadStringOperationException: ") + message;
    }
};

void toString_test_5548() {
    BadStringOperationException instance("");
    std::string str2 = instance.toString();
    const std::string expected = "javax.management.BadStringOperationException: ";
    if (str2 != expected) {
        throw std::runtime_error("Assertion failed: expected '" + expected + "' but got '" + str2 + "'");
    }
}