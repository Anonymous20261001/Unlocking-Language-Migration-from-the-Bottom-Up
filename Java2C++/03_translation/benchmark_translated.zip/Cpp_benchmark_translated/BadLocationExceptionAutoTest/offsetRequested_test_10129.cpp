#include <string>
#include <stdexcept>
#include <utility>
#include <cassert>

// C++ equivalent of javax.swing.text.BadLocationException
class BadLocationException : public std::exception {
private:
    std::string msg;
    int offs;

public:
    BadLocationException(const std::string& s, int offset)
        : msg(s), offs(offset) {}

    // Returns the offset that was requested
    int offsetRequested() const noexcept {
        return offs;
    }

    // Override what() to provide the message
    const char* what() const noexcept override {
        return msg.c_str();
    }
};

// Test function corresponding to Java @Test method
void offsetRequested_test_10129() {
    BadLocationException instance("hi!", 1);
    int result = instance.offsetRequested();
    assert(result == 1);
}