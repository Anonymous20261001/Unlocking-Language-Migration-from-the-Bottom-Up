#include <cstddef>
#include <stdexcept>

// -------------------------------------------------------------------
// Minimal stubs for Java Swing classes used in the tests
// -------------------------------------------------------------------

class JComponent {
public:
    virtual ~JComponent() = default;
};

class AbstractButton : public JComponent {
public:
    virtual ~AbstractButton() = default;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

struct Dimension {
    int width = 0;
    int height = 0;
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// -------------------------------------------------------------------
// BasicButtonUI equivalent (stub implementation)
// -------------------------------------------------------------------
class BasicButtonUI {
public:
    BasicButtonUI() = default;

    void installUI(JComponent* /*c*/) {
        // stub – no operation
    }

    void uninstallUI(JComponent* /*c*/) {
        // stub – no operation
    }

    static BasicButtonUI* createUI(JComponent* /*c*/) {
        return new BasicButtonUI();
    }

    int getDefaultTextIconGap(AbstractButton* /*b*/) {
        return 0;
    }

    Dimension getMaximumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    void paint(Graphics* /*g*/, JComponent* /*c*/) {
        // stub – no operation
    }

    Dimension getPreferredSize(JComponent* c) {
        if (c == nullptr) {
            throw std::invalid_argument("NullPointerException: Cannot invoke \"javax.swing.AbstractButton.getIconTextGap()\" because \"b\" is null");
        }
        return Dimension{};
    }

    Dimension getMinimumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    int getBaseline(JComponent* /*c*/, int /*width*/, int /*height*/) {
        return 0;
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* /*c*/) {
        return BaselineResizeBehavior::OTHER;
    }
};

// -------------------------------------------------------------------
// Translated test functions (one per @Test method)
// -------------------------------------------------------------------

void getPreferredSize_test_8646() {
    BasicButtonUI basicButtonUI0;
    JComponent* jComponent3 = nullptr;
    try {
        Dimension dimension4 = basicButtonUI0.getPreferredSize(jComponent3);
        // If no exception, fail the test
        throw std::logic_error("Expected exception of type NullPointerException");
    } catch (const std::invalid_argument& e) {
        // Expected exception.
    }
}