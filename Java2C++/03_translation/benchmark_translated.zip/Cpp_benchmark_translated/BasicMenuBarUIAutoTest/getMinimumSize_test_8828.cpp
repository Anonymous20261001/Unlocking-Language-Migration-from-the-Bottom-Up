#include <cstddef>
#include <cassert>

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Minimal Dimension stub (returned by getMinimumSize / getMaximumSize)
struct Dimension {
};

// BasicMenuBarUI implementation with identical API (stubbed)
class BasicMenuBarUI {
public:
    void installUI(JComponent* /*c*/) {}
    void uninstallUI(JComponent* /*c*/) {}
    static BasicMenuBarUI* createUI(JComponent* /*c*/) { return new BasicMenuBarUI(); }
    Dimension* getMaximumSize(JComponent* /*c*/) { return nullptr; }
    Dimension* getMinimumSize(JComponent* /*c*/) { return nullptr; }
};

// Test functions – one per @Test method, same name and parameter type

void getMinimumSize_test_8828() {
    BasicMenuBarUI instance;
    JComponent* jComponent1 = nullptr;
    Dimension* dimension2 = instance.getMinimumSize(jComponent1);
    assert(dimension2 == nullptr);
}