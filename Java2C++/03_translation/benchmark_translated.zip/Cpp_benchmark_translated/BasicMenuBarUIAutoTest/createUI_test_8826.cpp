#include <cstddef>
#include <cassert>

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicMenuBarUI implementation with identical API (stubbed)
class BasicMenuBarUI {
public:
    void installUI(JComponent* /*c*/) {}
    void uninstallUI(JComponent* /*c*/) {}
    static BasicMenuBarUI* createUI(JComponent* /*c*/) { return new BasicMenuBarUI(); }
    void getMaximumSize(JComponent* /*c*/) {}
    void getMinimumSize(JComponent* /*c*/) {}
};

// Test functions – one per @Test method, same name and parameter type

void createUI_test_8826() {
    BasicMenuBarUI* componentUI1 = BasicMenuBarUI::createUI(nullptr);
    assert(componentUI1 != nullptr);
}