#include <cstddef>
#include <cassert>

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicMenuBarUI implementation with adjusted signature for getMaximumSize
class BasicMenuBarUI {
public:
    void installUI(JComponent* /*c*/) {}
    void uninstallUI(JComponent* /*c*/) {}
    static BasicMenuBarUI* createUI(JComponent* /*c*/) { return new BasicMenuBarUI(); }
    void* getMaximumSize(JComponent* /*c*/) { return nullptr; } // now returns pointer, always null
    void getMinimumSize(JComponent* /*c*/) {}
};

void getMaximumSize_test_8827() {
    BasicMenuBarUI instance;
    JComponent* jComponent = nullptr;
    void* result = instance.getMaximumSize(jComponent);
    assert(result == nullptr);
}