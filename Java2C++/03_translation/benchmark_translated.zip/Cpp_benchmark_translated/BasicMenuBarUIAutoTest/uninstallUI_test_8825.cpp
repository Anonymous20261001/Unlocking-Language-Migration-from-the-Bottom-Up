#include <cstddef>
#include <stdexcept>

// Minimal JComponent stub
class JComponent {
public:
    virtual ~JComponent() = default;
};

// BasicMenuBarUI implementation with similar null‑pointer behavior
class BasicMenuBarUI {
public:
    void installUI(JComponent* c) {
        if (!c) throw std::runtime_error("NullPointerException");
    }
    void uninstallUI(JComponent* c) {
        if (!c) throw std::runtime_error("NullPointerException: Cannot invoke \"javax.swing.JMenuBar.removeContainerListener(java.awt.event.ContainerListener)\" because \"this.menuBar\" is null");
    }
    static BasicMenuBarUI* createUI(JComponent* /*c*/) { return new BasicMenuBarUI(); }
    void getMaximumSize(JComponent* /*c*/) {}
    void getMinimumSize(JComponent* /*c*/) {}
};

// Test function – same name, no parameters, preserves Java semantics
void uninstallUI_test_8825() {
    BasicMenuBarUI basicMenuBarUI0;
    JComponent* jComponent3 = nullptr;
    try {
        basicMenuBarUI0.uninstallUI(jComponent3);
        // No exception thrown – fail the test
        throw std::runtime_error("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.JMenuBar.removeContainerListener(java.awt.event.ContainerListener)\" because \"this.menuBar\" is null");
    } catch (const std::exception& e) {
        // Expected exception.
    }
}