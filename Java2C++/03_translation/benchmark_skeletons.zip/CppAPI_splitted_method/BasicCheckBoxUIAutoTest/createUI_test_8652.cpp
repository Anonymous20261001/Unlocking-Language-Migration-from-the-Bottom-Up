#include <string>

// Base class for UI components (simplified)
class JComponent {
public:
    virtual ~JComponent() = default;
};

// Base class for component UI (simplified)
class ComponentUI {
public:
    virtual ~ComponentUI() = default;
};

// BasicCheckBoxUI mimicking the Java Swing UI class
class BasicCheckBoxUI : public ComponentUI {
public:
    // Static factory method (mimics Java's createUI)
    static BasicCheckBoxUI* createUI(JComponent* c) {
        // In Java, this returns a new BasicCheckBoxUI instance
        return new BasicCheckBoxUI();
    }

    // Instance method returning the property prefix (mimics Java's getPropertyPrefix)
    std::string getPropertyPrefix() const {
        return "CheckBox";
    }
};

// Test functions (exact translation of Java @Test methods)

void createUI_test_8652(JComponent* p0) {
BasicCheckBoxUI instance;              // Unused instance as in Java
    BasicCheckBoxUI::createUI(p0);        // Static method call (return value ignored)
}
