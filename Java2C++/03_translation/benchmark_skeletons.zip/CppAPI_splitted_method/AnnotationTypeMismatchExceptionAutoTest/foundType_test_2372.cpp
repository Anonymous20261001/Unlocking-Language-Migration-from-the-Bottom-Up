#include <string>
#include <iostream>

// Minimal C++ equivalent of java.lang.reflect.Method
// Only contains a name for identification; tests do not use its internals.
class Method {
private:
    std::string name_;
public:
    Method() : name_("") {}
    explicit Method(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
};

// C++ equivalent of java.lang.annotation.AnnotationTypeMismatchException
class AnnotationTypeMismatchException {
private:
    Method method_;
    std::string foundType_;
public:
    AnnotationTypeMismatchException(const Method& method, const std::string& foundType)
        : method_(method), foundType_(foundType) {}

    Method element() const { return method_; }
    std::string foundType() const { return foundType_; }
};

// Test functions (exact names as in Java test)

void foundType_test_2372(Method c0, std::string c1) {
AnnotationTypeMismatchException instance(c0, c1);
    instance.foundType();  // just call the method, ignore return
}
