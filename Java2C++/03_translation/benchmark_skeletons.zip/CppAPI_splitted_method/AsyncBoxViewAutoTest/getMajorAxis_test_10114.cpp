#include <vector>
#include <cstddef>

// Forward declarations
class Graphics;
class Shape;
class Element;
class View;
class AsyncBoxView;

// Minimal Position::Bias implementation
class Position {
public:
    class Bias {
    public:
        static Bias Forward;
        static Bias Backward;
        Bias() = default;
    };
};

Position::Bias Position::Bias::Forward;
Position::Bias Position::Bias::Backward;

// Minimal Element (stub)
class Element {
public:
    Element() = default;
};

// Minimal View (base class)
class View {
public:
    virtual ~View() = default;
    View() = default;
};

// Minimal Shape (stub)
class Shape {
public:
    Shape() = default;
};

// Minimal Graphics (stub)
class Graphics {
public:
    Graphics() = default;
};

// Asynchronous box view implementation (stub)
class AsyncBoxView {
public:
    AsyncBoxView(Element* elem, int axis) : elem(elem), axis(axis) {}

    void viewToModel(float x, float y, Shape* alloc, Position::Bias bias[]) {
        // stub
    }

    int getViewCount() { return 0; }

    float getLeftInset() { return 0.0f; }
    float getRightInset() { return 0.0f; }
    float getTopInset() { return 0.0f; }
    float getBottomInset() { return 0.0f; }

    void preferenceChanged(View* child, bool width, bool height) {
        // stub
    }

    int getViewIndex(int pos, Position::Bias bias) { return 0; }

    int getMajorAxis() { return 0; }
    int getMinorAxis() { return 1; }

    void setTopInset(float inset) {}
    void setBottomInset(float inset) {}
    void setLeftInset(float inset) {}
    void setRightInset(float inset) {}

    Shape* getChildAllocation(int index, Shape* alloc) { return nullptr; }

    View* getView(int index) { return nullptr; }

    float getPreferredSpan(int axis) { return 0.0f; }
    float getMinimumSpan(int axis) { return 0.0f; }
    float getMaximumSpan(int axis) { return 0.0f; }

    void paint(Graphics* g, Shape* alloc) {
        // stub
    }

    void replace(int offset, int length, std::vector<View*> views) {
        // stub
    }

    void setParent(View* parent) {
        // stub
    }

    void setSize(float width, float height) {
        // stub
    }

private:
    Element* elem;
    int axis;
};

// ---------- Test functions (one per Java @Test) ----------

void getMajorAxis_test_10114(Element* c0, int c1) {
AsyncBoxView instance(c0, c1);
    instance.getMajorAxis();
}
