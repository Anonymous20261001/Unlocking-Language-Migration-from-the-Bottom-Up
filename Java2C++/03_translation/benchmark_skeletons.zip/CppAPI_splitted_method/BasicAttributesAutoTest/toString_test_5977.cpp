#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>
#include <any>
#include <sstream>
#include <functional>
#include <cassert>
#include <stdexcept>

// Minimal Attribute class to match javax.naming.directory.Attribute
class Attribute {
private:
    std::string id_;
    std::any value_;
public:
    Attribute(const std::string& id, const std::any& value = {})
        : id_(id), value_(value) {}

    const std::string& getID() const { return id_; }
    std::any getValue() const { return value_; }
    void setValue(const std::any& value) { value_ = value; }

    // For equality and hash (simplified)
    bool operator==(const Attribute& other) const {
        return id_ == other.id_;
    }
};

// C++ equivalent of javax.naming.directory.BasicAttributes
class BasicAttributes {
private:
    bool caseIgnored_;
    std::unordered_map<std::string, std::shared_ptr<Attribute>> attributes_;

    // Helper to normalize key if case-insensitive
    std::string normalizeKey(const std::string& key) const {
        if (caseIgnored_) {
            std::string lower;
            lower.reserve(key.size());
            for (char c : key) {
                lower.push_back(std::tolower(static_cast<unsigned char>(c)));
            }
            return lower;
        }
        return key;
    }

public:
    BasicAttributes() : caseIgnored_(false) {}
    explicit BasicAttributes(bool caseIgnored) : caseIgnored_(caseIgnored) {}

    bool isCaseIgnored() const {
        return caseIgnored_;
    }

    std::vector<std::string> getIDs() const {
        std::vector<std::string> ids;
        ids.reserve(attributes_.size());
        for (const auto& pair : attributes_) {
            ids.push_back(pair.second->getID());
        }
        return ids;
    }

    std::shared_ptr<Attribute> remove(const std::string& id) {
        std::string key = normalizeKey(id);
        auto it = attributes_.find(key);
        if (it != attributes_.end()) {
            std::shared_ptr<Attribute> removed = it->second;
            attributes_.erase(it);
            return removed;
        }
        return nullptr;
    }

    size_t size() const {
        return attributes_.size();
    }

    std::shared_ptr<Attribute> get(const std::string& id) const {
        std::string key = normalizeKey(id);
        auto it = attributes_.find(key);
        if (it != attributes_.end()) {
            return it->second;
        }
        return nullptr;
    }

    // put(String, Object) – returns previous Attribute or null
    std::shared_ptr<Attribute> put(const std::string& id, const std::any& value) {
        auto attr = std::make_shared<Attribute>(id, value);
        return put(attr);
    }

    // put(Attribute) – returns previous Attribute or null
    std::shared_ptr<Attribute> put(const std::shared_ptr<Attribute>& attr) {
        std::string key = normalizeKey(attr->getID());
        std::shared_ptr<Attribute> old = get(attr->getID());
        attributes_[key] = attr;
        return old;
    }

    // equals(Object) – simplified: only compares with another BasicAttributes
    bool equals(const std::any& obj) const {
        try {
            const BasicAttributes& other = std::any_cast<const BasicAttributes&>(obj);
            return *this == other;
        } catch (const std::bad_any_cast&) {
            return false;
        }
    }

    bool operator==(const BasicAttributes& other) const {
        if (caseIgnored_ != other.caseIgnored_) return false;
        if (size() != other.size()) return false;
        // Compare attributes by key
        for (const auto& pair : attributes_) {
            auto other_attr = other.get(pair.second->getID());
            if (!other_attr || !(*pair.second == *other_attr)) {
                return false;
            }
        }
        return true;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << "{ BasicAttributes: ";
        for (const auto& pair : attributes_) {
            oss << pair.second->getID() << "=" << pair.second->getValue().type().name() << " ";
        }
        oss << "}";
        return oss.str();
    }

    size_t hashCode() const {
        size_t hash = std::hash<bool>()(caseIgnored_);
        for (const auto& pair : attributes_) {
            hash ^= std::hash<std::string>()(pair.first);
        }
        return hash;
    }

    // clone() returns a new BasicAttributes*
    BasicAttributes* clone() const {
        return new BasicAttributes(*this);
    }

    std::vector<std::shared_ptr<Attribute>> getAll() const {
        std::vector<std::shared_ptr<Attribute>> all;
        all.reserve(attributes_.size());
        for (const auto& pair : attributes_) {
            all.push_back(pair.second);
        }
        return all;
    }
};

// =============== Test Functions ===============

void toString_test_5977() {
BasicAttributes instance;
    instance.toString();
}
