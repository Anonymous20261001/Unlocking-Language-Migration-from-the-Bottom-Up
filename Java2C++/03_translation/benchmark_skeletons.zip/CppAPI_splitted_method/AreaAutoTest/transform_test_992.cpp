#include <cstddef>

// Forward declarations
class Area;
class AffineTransform;
class Point2D;
class Rectangle2D;
class Rectangle;
class PathIterator;

// AffineTransform
class AffineTransform {
public:
    double m00, m01, m02;
    double m10, m11, m12;
    AffineTransform() : m00(1), m01(0), m02(0), m10(0), m11(1), m12(0) {}
};

// Point2D
class Point2D {
public:
    double x, y;
    Point2D() : x(0), y(0) {}
    Point2D(double x, double y) : x(x), y(y) {}
    double getX() const { return x; }
    double getY() const { return y; }
};

// Rectangle2D
class Rectangle2D {
public:
    double x, y, w, h;
    Rectangle2D() : x(0), y(0), w(0), h(0) {}
    Rectangle2D(double x, double y, double w, double h) : x(x), y(y), w(w), h(h) {}
    double getX() const { return x; }
    double getY() const { return y; }
    double getWidth() const { return w; }
    double getHeight() const { return h; }
};

// Rectangle (integer version)
class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
    Rectangle(int x, int y, int w, int h) : x(x), y(y), width(w), height(h) {}
};

// PathIterator (stub)
class PathIterator {
public:
    // No methods needed for stub
};

// Area class
class Area {
public:
    Area() {}

    void exclusiveOr(const Area& /*other*/) {}
    bool isPolygonal() const { return false; }
    bool isRectangular() const { return false; }
    bool isSingular() const { return false; }
    Area createTransformedArea(const AffineTransform& /*at*/) const { return Area(); }
    PathIterator getPathIterator(const AffineTransform& /*at*/) const { return PathIterator(); }
    PathIterator getPathIterator(const AffineTransform& /*at*/, double /*flatness*/) const { return PathIterator(); }
    Rectangle2D getBounds2D() const { return Rectangle2D(); }
    void reset() {}
    bool equals(const Area& /*other*/) const { return false; }
    Area clone() const { return Area(); }
    bool isEmpty() const { return false; }
    void add(const Area& /*other*/) {}
    bool contains(const Point2D& /*p*/) const { return false; }
    bool contains(double /*x*/, double /*y*/, double /*w*/, double /*h*/) const { return false; }
    bool contains(double /*x*/, double /*y*/) const { return false; }
    bool contains(const Rectangle2D& /*r*/) const { return false; }
    void transform(const AffineTransform& /*at*/) {}
    Rectangle getBounds() const { return Rectangle(); }
    void subtract(const Area& /*other*/) {}
    bool intersects(const Rectangle2D& /*r*/) const { return false; }
    bool intersects(double /*x*/, double /*y*/, double /*w*/, double /*h*/) const { return false; }
    void intersect(const Area& /*other*/) {}
};

// ------------------------------------------------------------
// Test functions (one per Java @Test method, same name)
// ------------------------------------------------------------

void transform_test_992(AffineTransform p0) {
Area instance;
    instance.transform(p0);
}
