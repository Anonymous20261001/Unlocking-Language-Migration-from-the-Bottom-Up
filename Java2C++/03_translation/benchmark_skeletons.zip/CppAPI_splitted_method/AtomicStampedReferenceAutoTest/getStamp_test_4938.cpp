#include <atomic>
#include <cstddef>
#include <cstdint>
#include <utility>

// -------------------------------------------------------------------------
// C++ equivalent of java.util.concurrent.atomic.AtomicStampedReference
// -------------------------------------------------------------------------
class AtomicStampedReference {
private:
    // Pack the reference pointer and stamp into a struct for atomic CAS
    struct RefStamp {
        void* ref;
        int   stamp;
    };

    std::atomic<RefStamp> pair_;

    static_assert(std::atomic<RefStamp>::is_always_lock_free,
                  "AtomicStampedReference requires lock-free atomic operations on RefStamp");

public:
    AtomicStampedReference(void* initialRef, int initialStamp)
        : pair_{initialRef, initialStamp} {}

    // Returns the current stamp
    int getStamp() const {
        return pair_.load(std::memory_order_acquire).stamp;
    }

    // Atomically sets the stamp to newStamp if the current reference equals expectedReference
    bool attemptStamp(void* expectedReference, int newStamp) {
        RefStamp expected = pair_.load(std::memory_order_acquire);
        while (expected.ref == expectedReference) {
            RefStamp desired{expected.ref, newStamp};
            if (pair_.compare_exchange_weak(expected, desired,
                                            std::memory_order_acq_rel,
                                            std::memory_order_acquire))
                return true;
        }
        return false;
    }

    // Returns the current reference and stores the stamp into *stampHolder
    void* get(int* stampHolder) const {
        RefStamp cur = pair_.load(std::memory_order_acquire);
        *stampHolder = cur.stamp;
        return cur.ref;
    }

    // Returns the current reference (without stamp)
    void* getReference() const {
        return pair_.load(std::memory_order_acquire).ref;
    }

    // Unconditionally sets both reference and stamp
    void set(void* newReference, int newStamp) {
        pair_.store({newReference, newStamp}, std::memory_order_release);
    }

    // Atomically sets the value to (newReference, newStamp) if the current
    // (reference, stamp) equals (expectedReference, expectedStamp)
    bool compareAndSet(void* expectedReference, void* newReference,
                       int expectedStamp, int newStamp) {
        RefStamp expected{expectedReference, expectedStamp};
        RefStamp desired{newReference, newStamp};
        return pair_.compare_exchange_strong(expected, desired,
                                             std::memory_order_acq_rel,
                                             std::memory_order_acquire);
    }

    // Weak version of compareAndSet (may fail spuriously)
    bool weakCompareAndSet(void* expectedReference, void* newReference,
                           int expectedStamp, int newStamp) {
        RefStamp expected{expectedReference, expectedStamp};
        RefStamp desired{newReference, newStamp};
        return pair_.compare_exchange_weak(expected, desired,
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire);
    }
};

// -------------------------------------------------------------------------
// Translated test functions (one per Java @Test method)
// -------------------------------------------------------------------------

void getStamp_test_4938(void* c0, int c1) {
AtomicStampedReference instance(c0, c1);
    instance.getStamp();
}
