#include <string>
#include <exception>

class BadStringOperationException : public std::exception {
private:
    std::string message;

public:
    explicit BadStringOperationException(const std::string& msg) : message(msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }

    std::string toString() const {
        return std::string("javax.management.BadStringOperationException: ") + message;
    }
};

void toString_test_5548(const std::string& c0) {
BadStringOperationException instance(c0);
    instance.toString();
}
