#include <any>
#include <string>
#include <sstream>

// C++ equivalent of java.text.Annotation
class Annotation {
public:
    // Constructor: stores a copy of the value
    explicit Annotation(const std::any& value) : value_(value) {}

    // Mimics Java's toString(): returns "Annotation(value=...)"
    std::string toString() const {
        std::ostringstream oss;
        oss << "Annotation(value=";
        // Attempt to convert to string if it holds a known type
        if (value_.has_value()) {
            try {
                // Try to cast to std::string
                oss << std::any_cast<std::string>(value_);
            } catch (const std::bad_any_cast&) {
                // For other types, show type info placeholder
                oss << "<non-string>";
            }
        } else {
            oss << "null";
        }
        oss << ")";
        return oss.str();
    }

    // Mimics Java's getValue(): returns the stored object (by value)
    std::any getValue() const {
        return value_;
    }

private:
    std::any value_;
};

// Translated test functions

void getValue_test_2995(std::any c0) {
Annotation instance(c0);
    instance.getValue();
}
