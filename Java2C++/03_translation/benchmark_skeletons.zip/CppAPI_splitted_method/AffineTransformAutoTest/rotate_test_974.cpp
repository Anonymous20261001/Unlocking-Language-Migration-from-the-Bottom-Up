#include <cstdint>
#include <string>
#include <vector>

class Object { public: virtual ~Object() = default; };
class Shape { public: virtual ~Shape() = default; };
class Point2D { public: double x = 0, y = 0; };

class AffineTransform {
public:
    AffineTransform() = default;
    void setToTranslation(double p0, double p1) { return {}; }
    void setToRotation(double p0, double p1) { return {}; }
    void setToRotation(double p0, double p1, double p2, double p3) { return {}; }
    void setToRotation(double p0) { return {}; }
    void setToRotation(double p0, double p1, double p2) { return {}; }
    void setToQuadrantRotation(int32_t p0, double p1, double p2) { return {}; }
    void setToQuadrantRotation(int32_t p0) { return {}; }
    void setToScale(double p0, double p1) { return {}; }
    void setToShear(double p0, double p1) { return {}; }
    auto getRotateInstance(double p0, double p1) { return {}; }
    auto getRotateInstance(double p0) { return {}; }
    auto getRotateInstance(double p0, double p1, double p2, double p3) { return {}; }
    auto getRotateInstance(double p0, double p1, double p2) { return {}; }
    auto getQuadrantRotateInstance(int32_t p0) { return {}; }
    auto getQuadrantRotateInstance(int32_t p0, double p1, double p2) { return {}; }
    auto getScaleInstance(double p0, double p1) { return {}; }
    auto getShearInstance(double p0, double p1) { return {}; }
    auto getDeterminant() { return {}; }
    auto getShearX() { return {}; }
    auto getShearY() { return {}; }
    auto getTranslateX() { return {}; }
    void quadrantRotate(int32_t p0) { return {}; }
    void quadrantRotate(int32_t p0, double p1, double p2) { return {}; }
    void shear(double p0, double p1) { return {}; }
    void setToIdentity() { return {}; }
    auto createTransformedShape(Shape& p0) { return {}; }
    void translate(double p0, double p1) { return {}; }
    auto getTranslateInstance(double p0, double p1) { return {}; }
    void preConcatenate(const AffineTransform& p0) { return {}; }
    auto getTranslateY() { return {}; }
    void deltaTransform(Point2D& p0, Point2D& p1) { return {}; }
    void deltaTransform(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void setTransform(const AffineTransform& p0) { return {}; }
    void setTransform(double p0, double p1, double p2, double p3, double p4, double p5) { return {}; }
    void concatenate(const AffineTransform& p0) { return {}; }
    auto getScaleX() { return {}; }
    auto getScaleY() { return {}; }
    auto getMatrix(const std::vector<double>& p0) { return {}; }
    void equals(Object& p0) { return {}; }
    auto toString() { return {}; }
    auto hashCode() { return {}; }
    auto clone() { return {}; }
    void scale(double p0, double p1) { return {}; }
    void transform(const std::vector<double>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<Point2D&>& p0, int32_t p1, const std::vector<Point2D&>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<float>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<float>& p0, int32_t p1, const std::vector<float>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(const std::vector<double>& p0, int32_t p1, const std::vector<double>& p2, int32_t p3, int32_t p4) { return {}; }
    void transform(Point2D& p0, Point2D& p1) { return {}; }
    auto getType() { return {}; }
    auto isIdentity() { return {}; }
    void rotate(double p0, double p1, double p2, double p3) { return {}; }
    void rotate(double p0, double p1) { return {}; }
    void rotate(double p0, double p1, double p2) { return {}; }
    void rotate(double p0) { return {}; }
};

// ── Test Functions ──────────────────────────────────────────────

void rotate_test_974(double p0) {
AffineTransform instance;
    instance.rotate(p0);
}
