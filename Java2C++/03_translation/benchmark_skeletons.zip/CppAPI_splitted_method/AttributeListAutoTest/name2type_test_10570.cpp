#include <string>
#include <vector>
#include <map>

// Equivalent C++ class for javax.swing.text.html.parser.AttributeList
class AttributeList {
public:
    // Constructor
    AttributeList(const std::string& name)
        : name(name), type(0), value(""), modifier(0), next(nullptr)
    {
    }

    // Accessors
    std::string getName() const { return name; }
    int getType() const { return type; }
    std::string getValue() const { return value; }
    std::vector<std::string> getValues() const { return values; }
    int getModifier() const { return modifier; }
    AttributeList* getNext() const { return next; }

    // toString - simple representation
    std::string toString() const { return name; }

    // Static methods for type conversion (simplified constants)
    static int name2type(const std::string& name) {
        static const std::map<std::string, int> mapping = {
            {"CDATA", 0},
            {"ENTITY", 1},
            {"ENTITIES", 2},
            {"ID", 3},
            {"IDREF", 4},
            {"IDREFS", 5},
            {"NAME", 6},
            {"NAMES", 7},
            {"NMTOKEN", 8},
            {"NMTOKENS", 9},
            {"NOTATION", 10},
            {"NUMBER", 11},
            {"NUMBERS", 12},
            {"NUTOKEN", 13},
            {"NUTOKENS", 14}
        };
        auto it = mapping.find(name);
        if (it != mapping.end())
            return it->second;
        return -1; // undefined
    }

    static std::string type2name(int type) {
        static const std::map<int, std::string> mapping = {
            {0, "CDATA"},
            {1, "ENTITY"},
            {2, "ENTITIES"},
            {3, "ID"},
            {4, "IDREF"},
            {5, "IDREFS"},
            {6, "NAME"},
            {7, "NAMES"},
            {8, "NMTOKEN"},
            {9, "NMTOKENS"},
            {10, "NOTATION"},
            {11, "NUMBER"},
            {12, "NUMBERS"},
            {13, "NUTOKEN"},
            {14, "NUTOKENS"}
        };
        auto it = mapping.find(type);
        if (it != mapping.end())
            return it->second;
        return "UNKNOWN";
    }

private:
    std::string name;
    int type;
    std::string value;
    std::vector<std::string> values;
    int modifier;
    AttributeList* next;
};

// Equivalents of the Java @Test methods (as C++ functions)

void name2type_test_10570(const std::string& p0, const std::string& c0) {
AttributeList instance(c0);
    AttributeList::name2type(p0);
}
