#include <atomic>
#include <string>

class AtomicBoolean {
private:
    std::atomic<bool> val;

public:
    AtomicBoolean() : val(false) {}
    explicit AtomicBoolean(bool initial) : val(initial) {}

    bool get() const {
        return val.load(std::memory_order_seq_cst);
    }

    void set(bool newValue) {
        val.store(newValue, std::memory_order_seq_cst);
    }

    bool getOpaque() const {
        return val.load(std::memory_order_relaxed);
    }

    void setOpaque(bool newValue) {
        val.store(newValue, std::memory_order_relaxed);
    }

    bool getAcquire() const {
        return val.load(std::memory_order_acquire);
    }

    void setRelease(bool newValue) {
        val.store(newValue, std::memory_order_release);
    }

    bool compareAndSet(bool expected, bool desired) {
        return val.compare_exchange_strong(expected, desired, std::memory_order_seq_cst);
    }

    bool compareAndExchange(bool expected, bool desired) {
        bool old = expected;
        val.compare_exchange_strong(old, desired, std::memory_order_seq_cst);
        return old;
    }

    bool compareAndExchangeAcquire(bool expected, bool desired) {
        bool old = expected;
        val.compare_exchange_strong(old, desired, std::memory_order_acquire, std::memory_order_relaxed);
        return old;
    }

    bool compareAndExchangeRelease(bool expected, bool desired) {
        bool old = expected;
        val.compare_exchange_strong(old, desired, std::memory_order_release, std::memory_order_relaxed);
        return old;
    }

    bool weakCompareAndSetPlain(bool expected, bool desired) {
        return val.compare_exchange_weak(expected, desired, std::memory_order_relaxed, std::memory_order_relaxed);
    }

    bool weakCompareAndSet(bool expected, bool desired) {
        return val.compare_exchange_weak(expected, desired, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetAcquire(bool expected, bool desired) {
        return val.compare_exchange_weak(expected, desired, std::memory_order_acquire, std::memory_order_relaxed);
    }

    bool weakCompareAndSetRelease(bool expected, bool desired) {
        return val.compare_exchange_weak(expected, desired, std::memory_order_release, std::memory_order_relaxed);
    }

    bool getAndSet(bool newValue) {
        return val.exchange(newValue, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetVolatile(bool expected, bool desired) {
        return val.compare_exchange_weak(expected, desired, std::memory_order_seq_cst);
    }

    void lazySet(bool newValue) {
        val.store(newValue, std::memory_order_release);
    }

    bool getPlain() const {
        return val.load(std::memory_order_relaxed);
    }

    void setPlain(bool newValue) {
        val.store(newValue, std::memory_order_relaxed);
    }

    std::string toString() const {
        return val.load() ? "true" : "false";
    }
};

// Test functions (matching the Java @Test methods)

void getAndSet_test_4747(bool p0) {
AtomicBoolean instance;
    instance.getAndSet(p0);
}
