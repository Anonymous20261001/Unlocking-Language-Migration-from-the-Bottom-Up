#include <string>
#include <exception>

// ------------------------------------------------------------------
// Equivalent of the Java interface javax.management.ValueExp
// In Java, ValueExp is an interface. In C++, we model it as a base
// class (or concrete class for simplicity). It must be possible to
// create instances (since the test passes one as a parameter). We
// provide a minimal concrete implementation that can be overridden.
// ------------------------------------------------------------------
class ValueExp {
public:
    virtual ~ValueExp() = default;

    // Mimics Java Object.toString() – overridable.
    virtual std::string toString() const {
        return "ValueExp";
    }
};

// ------------------------------------------------------------------
// Equivalent of javax.management.BadBinaryOpValueExpException
// Extends std::exception to mimic checked exception behavior.
// ------------------------------------------------------------------
class BadBinaryOpValueExpException : public std::exception {
private:
    ValueExp* exp;   // stored pointer (no ownership transfer)
public:
    explicit BadBinaryOpValueExpException(ValueExp* exp)
        : exp(exp) {}

    // Equivalent to Java's getExp() – returns the stored ValueExp.
    ValueExp* getExp() const {
        return exp;
    }

    // Equivalent to Java's toString() – includes the embedded expression.
    std::string toString() const {
        std::string expStr = (exp ? exp->toString() : "null");
        return "BadBinaryOpValueExpException: " + expStr;
    }

    // Override what() from std::exception for completeness.
    const char* what() const noexcept override {
        return "BadBinaryOpValueExpException";
    }
};

// ------------------------------------------------------------------
// Translated test functions (exact names from Java)
// ------------------------------------------------------------------

void toString_test_5547(ValueExp* c0) {
BadBinaryOpValueExpException instance(c0);
    instance.toString(); // exercise the API, result ignored
}
