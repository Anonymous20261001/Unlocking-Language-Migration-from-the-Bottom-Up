#include <string>
#include <vector>
#include <map>
#include <any>
#include <memory>
#include <iostream>
#include <stdexcept>

// ---------------------------------------------------------------------------
// Forward declarations and class implementations
// ---------------------------------------------------------------------------

class AttributedCharacterIterator {
public:
    // Inner class Attribute (simplified, uses name as identifier)
    class Attribute {
    public:
        explicit Attribute(const std::string& name) : name_(name) {}
        const std::string& getName() const { return name_; }
        bool operator<(const Attribute& other) const { return name_ < other.name_; }
    private:
        std::string name_;
    };

    // Minimal placeholder – tests do not call any methods on the iterator
    // In a full implementation this would provide iteration over attributes.
    AttributedCharacterIterator() = default;
    AttributedCharacterIterator(const AttributedCharacterIterator&) = default;
    AttributedCharacterIterator& operator=(const AttributedCharacterIterator&) = default;
};

// ---------------------------------------------------------------------------
// AttributedString class – simplified implementation matching Java API
// ---------------------------------------------------------------------------

class AttributedString {
public:
    explicit AttributedString(const std::string& text) : text_(text) {}

    // Add a single attribute to the whole string
    void addAttribute(const AttributedCharacterIterator::Attribute& attr,
                     const std::any& value) {
        addAttribute(attr, value, 0, static_cast<int>(text_.length()));
    }

    // Add a single attribute to a specific range
    void addAttribute(const AttributedCharacterIterator::Attribute& attr,
                     const std::any& value,
                     int beginIndex,
                     int endIndex) {
        if (beginIndex < 0 || endIndex > static_cast<int>(text_.length()) || beginIndex > endIndex) {
            throw std::out_of_range("Invalid attribute range");
        }
        AttributeRange range{beginIndex, endIndex, {}};
        range.attribs[attr.getName()] = value;
        ranges_.push_back(range);
    }

    // Add multiple attributes (a map) to a specific range
    void addAttributes(const std::map<AttributedCharacterIterator::Attribute, std::any>& attrs,
                      int beginIndex,
                      int endIndex) {
        if (beginIndex < 0 || endIndex > static_cast<int>(text_.length()) || beginIndex > endIndex) {
            throw std::out_of_range("Invalid attribute range");
        }
        AttributeRange range{beginIndex, endIndex, {}};
        for (const auto& [attr, val] : attrs) {
            range.attribs[attr.getName()] = val;
        }
        ranges_.push_back(range);
    }

    // Get an iterator covering the whole string with all attributes
    AttributedCharacterIterator getIterator() {
        // Return a dummy iterator – no actual implementation needed for these tests
        return AttributedCharacterIterator();
    }

    // Get an iterator covering the whole string filtered to specific attributes
    AttributedCharacterIterator getIterator(
        const std::vector<AttributedCharacterIterator::Attribute>& /* attrs */) {
        return AttributedCharacterIterator();
    }

    // Get an iterator covering a subrange with specific attribute filter
    AttributedCharacterIterator getIterator(
        const std::vector<AttributedCharacterIterator::Attribute>& /* attrs */,
        int /* beginIndex */,
        int /* endIndex */) {
        return AttributedCharacterIterator();
    }

private:
    struct AttributeRange {
        int start;
        int end;
        std::map<std::string, std::any> attribs;
    };

    std::string text_;
    std::vector<AttributeRange> ranges_;
};

// ---------------------------------------------------------------------------
// Translated test functions (matching Java @Test methods exactly)
// ---------------------------------------------------------------------------

// Helper type aliases to match Java signatures
using Map = std::map<AttributedCharacterIterator::Attribute, std::any>;
using AttributeArray = std::vector<AttributedCharacterIterator::Attribute>;

void addAttribute_test_3000(AttributedCharacterIterator::Attribute p0, std::any p1, std::string c0) {
AttributedString instance(c0);
    instance.addAttribute(p0, p1);
}
