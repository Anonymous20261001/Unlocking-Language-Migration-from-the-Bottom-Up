#include <string>
#include <utility>

class AuthorizeCallback {
private:
    std::string authenticationID;
    std::string authorizationID;
    bool authorized;
    std::string authorizedID;

public:
    AuthorizeCallback(const std::string& authnID, const std::string& authzID)
        : authenticationID(authnID), authorizationID(authzID), authorized(false), authorizedID() {}

    std::string getAuthenticationID() {
        return authenticationID;
    }

    std::string getAuthorizationID() {
        return authorizationID;
    }

    bool isAuthorized() {
        return authorized;
    }

    void setAuthorized(bool flag) {
        if (flag && authorizedID.empty()) {
            authorizedID = authorizationID;
        }
        authorized = flag;
    }

    std::string getAuthorizedID() {
        return authorizedID;
    }

    void setAuthorizedID(const std::string& id) {
        authorizedID = id;
    }
};

// Test functions

void getAuthorizationID_test_6438(const std::string& c0, const std::string& c1) {
AuthorizeCallback instance(c0, c1);
    instance.getAuthorizationID();
}
