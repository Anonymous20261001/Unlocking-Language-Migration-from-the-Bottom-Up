#include <string>
#include <memory>
#include <sstream>
#include <functional>
#include <typeindex>
#include <cstddef>

// ---------------------------------------------------------------------------
// Base class for Java-like Object
// ---------------------------------------------------------------------------
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const = 0;
    virtual std::size_t hashCode() const = 0;
    virtual std::string toString() const = 0;
};

// ---------------------------------------------------------------------------
// Concrete wrapper for std::string behaving like Java String
// ---------------------------------------------------------------------------
class StringObject : public Object {
private:
    std::string str;

public:
    explicit StringObject(const std::string& s) : str(s) {}

    const std::string& getString() const { return str; }

    bool equals(const Object& other) const override {
        const auto* otherStr = dynamic_cast<const StringObject*>(&other);
        return otherStr != nullptr && str == otherStr->str;
    }

    std::size_t hashCode() const override {
        return std::hash<std::string>{}(str);
    }

    std::string toString() const override {
        return str;
    }
};

// ---------------------------------------------------------------------------
// javax.management.Attribute equivalent
// ---------------------------------------------------------------------------
class Attribute {
private:
    std::string name;
    std::shared_ptr<Object> value;

public:
    Attribute(const std::string& name, std::shared_ptr<Object> value)
        : name(name), value(std::move(value)) {}

    std::string getName() const {
        return name;
    }

    std::shared_ptr<Object> getValue() const {
        return value;
    }

    bool equals(const Object& other) const {
        const auto* otherAttr = dynamic_cast<const Attribute*>(&other);
        if (!otherAttr) return false;
        return name == otherAttr->name &&
               value->equals(*otherAttr->value);
    }

    std::size_t hashCode() const {
        return std::hash<std::string>{}(name) ^ value->hashCode();
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << name << " = " << value->toString();
        return oss.str();
    }
};

// ===========================================================================
// Test functions (translated from Java @Test methods)
// ===========================================================================

void getName_test_5518(const std::string& c0, std::shared_ptr<Object> c1) {
Attribute instance(c0, std::move(c1));
    instance.getName();
}
