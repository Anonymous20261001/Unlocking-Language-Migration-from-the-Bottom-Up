#include <cstdint>
#include <iostream>

// ============== Java AWT Event classes translated to C++ ==============

namespace awt {

// Base class for AWT events
class AWTEvent {
public:
    virtual ~AWTEvent() = default;
};

// Interface for AWT event listeners
class AWTEventListener {
public:
    virtual ~AWTEventListener() = default;
    virtual void eventDispatched(AWTEvent& event) = 0;
};

// Proxy listener that wraps another listener with an event mask
class AWTEventListenerProxy : public AWTEventListener {
public:
    AWTEventListenerProxy(int64_t eventMask, AWTEventListener* listener)
        : m_eventMask(eventMask), m_listener(listener) {}

    int64_t getEventMask() const { return m_eventMask; }

    void eventDispatched(AWTEvent& event) override {
        if (m_listener) {
            m_listener->eventDispatched(event);
        }
    }

private:
    int64_t m_eventMask;
    AWTEventListener* m_listener;
};

} // namespace awt

// ============== Translated Test Functions ==============

// Equivalent to Java: eventDispatched_test_739(AWTEvent p0, long c0, AWTEventListener c1)

void getEventMask_test_740(int64_t c0, awt::AWTEventListener& c1) {
awt::AWTEventListenerProxy instance(c0, &c1);
    instance.getEventMask();  // return value intentionally ignored (matches Java test)
}
