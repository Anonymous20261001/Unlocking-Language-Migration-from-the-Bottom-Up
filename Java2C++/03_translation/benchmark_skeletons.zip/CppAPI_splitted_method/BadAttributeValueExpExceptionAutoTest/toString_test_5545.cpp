#include <string>
#include <memory>
#include <sstream>

namespace java {
namespace lang {

class Object {
public:
    virtual ~Object() = default;
    virtual std::string toString() const = 0;

    // Static null object
    static const Object& null() {
        static class NullObject : public Object {
        public:
            std::string toString() const override { return "null"; }
        } nullObj;
        return nullObj;
    }
};

// Concrete Object that holds a string
class StringObject : public Object {
    std::string value_;
public:
    explicit StringObject(const std::string& v) : value_(v) {}
    std::string toString() const override { return value_; }
};

} // namespace lang
} // namespace java

namespace javax {
namespace management {

class BadAttributeValueExpException : public std::exception {
    std::string msg_;
public:
    // Constructor: stores string representation of the given Object
    explicit BadAttributeValueExpException(const java::lang::Object& val) {
        std::ostringstream oss;
        oss << "javax.management.BadAttributeValueExpException: " << val.toString();
        msg_ = oss.str();
    }

    const char* what() const noexcept override { return msg_.c_str(); }

    // Simulates Java's toString() method
    std::string toString() const { return msg_; }
};

} // namespace management
} // namespace javax

// Test function: exact translation of the Java @Test method

void toString_test_5545(const java::lang::Object& c0) {
javax::management::BadAttributeValueExpException instance(c0);
    instance.toString();
}
