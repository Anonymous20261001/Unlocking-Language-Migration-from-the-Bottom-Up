#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <stdexcept>

// Minimal Notification base class (Java equivalent)
class Notification {
public:
    virtual ~Notification() = default;
    // In Java, Notification does not have getAttributeName().
    // We provide a virtual method returning empty string by default.
    virtual std::string getAttributeName() const {
        return "";
    }
};

// AttributeChangeNotification derived class
class AttributeChangeNotification : public Notification {
public:
    explicit AttributeChangeNotification(const std::string& attrName)
        : attributeName_(attrName) {}

    std::string getAttributeName() const override {
        return attributeName_;
    }

private:
    std::string attributeName_;
};

// AttributeChangeNotificationFilter (C++ equivalent of javax.management.AttributeChangeNotificationFilter)
class AttributeChangeNotificationFilter {
public:
    // Enable initially all attributes? In Java the constructor enables all.
    // Actually the Java constructor does nothing; the set is empty.
    // But isNotificationEnabled returns false if attribute not in set.
    // We'll start with empty set.
    AttributeChangeNotificationFilter() = default;

    // Returns true if the notification is an AttributeChangeNotification
    // and its attribute name is in the enabled set.
    bool isNotificationEnabled(const Notification& notif) const {
        const auto* attrNotif = dynamic_cast<const AttributeChangeNotification*>(&notif);
        if (!attrNotif) {
            return false;   // not an AttributeChangeNotification
        }
        const std::string& attr = attrNotif->getAttributeName();
        return enabledAttributes_.find(attr) != enabledAttributes_.end();
    }

    // Disable a specific attribute (remove it from the set)
    void disableAttribute(const std::string& attr) {
        enabledAttributes_.erase(attr);
    }

    // Disable all attributes (clear the set)
    void disableAllAttributes() {
        enabledAttributes_.clear();
    }

    // Return a list (vector) of currently enabled attribute names
    std::vector<std::string> getEnabledAttributes() const {
        return std::vector<std::string>(enabledAttributes_.begin(), enabledAttributes_.end());
    }

private:
    std::set<std::string> enabledAttributes_;
};

// ---------- Test functions (translated from Java @Test methods) ----------

// Test: isNotificationEnabled_test_5527(Notification p0)

void getEnabledAttributes_test_5530() {
AttributeChangeNotificationFilter instance;
    instance.getEnabledAttributes();
}
