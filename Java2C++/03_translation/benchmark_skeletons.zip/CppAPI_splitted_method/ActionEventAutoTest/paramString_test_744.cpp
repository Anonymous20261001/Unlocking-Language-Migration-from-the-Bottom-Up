#include <string>
#include <chrono>
#include <sstream>

// Minimal base class to mirror Java's Object
class Object {
public:
    virtual ~Object() = default;
};

// C++ equivalent of java.awt.event.ActionEvent
class ActionEvent {
private:
    Object* source;
    int id;
    std::string command;
    long when;          // timestamp in milliseconds
    int modifiers;

public:
    // Constructor matching Java's ActionEvent(Object, int, String)
    ActionEvent(Object* source, int id, const std::string& command)
        : source(source), id(id), command(command), modifiers(0) {
        auto now = std::chrono::system_clock::now();
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            now.time_since_epoch()).count();
        when = static_cast<long>(ms);
    }

    long getWhen() const {
        return when;
    }

    std::string getActionCommand() const {
        return command;
    }

    int getModifiers() const {
        return modifiers;
    }

    std::string paramString() const {
        std::ostringstream oss;
        oss << "ACTION_PERFORMED,cmd=" << command
            << ",when=" << when
            << ",modifiers=" << modifiers;
        return oss.str();
    }
};

// Test functions (exact names from the Java test file)

void paramString_test_744(Object* c0, int c1, std::string c2) {
ActionEvent instance(c0, c1, c2);
    instance.paramString();
}
