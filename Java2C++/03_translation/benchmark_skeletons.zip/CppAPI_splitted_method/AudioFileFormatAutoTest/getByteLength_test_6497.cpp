#include <string>
#include <map>
#include <iostream>

class AudioFormat {
private:
    float sampleRate;
    int sampleSizeInBits;
    int channels;
    bool signed_;
    bool bigEndian;
    int frameSize;

public:
    AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed_, bool bigEndian)
        : sampleRate(sampleRate), sampleSizeInBits(sampleSizeInBits), channels(channels),
          signed_(signed_), bigEndian(bigEndian) {
        if (sampleSizeInBits > 0 && channels > 0) {
            frameSize = (sampleSizeInBits * channels) / 8;
        } else {
            frameSize = -1;
        }
    }

    int getFrameSize() const {
        return frameSize;
    }
};

class AudioFileFormat {
public:
    class Type {
    private:
        std::string name;
        std::string extension;
    public:
        Type(const std::string& name, const std::string& extension)
            : name(name), extension(extension) {}
        std::string getName() const { return name; }
        std::string getExtension() const { return extension; }
    };

private:
    Type type;
    AudioFormat format;
    int frameLength;
    std::map<std::string, std::string> props;

public:
    AudioFileFormat(const Type& type, const AudioFormat& format, int frameLength)
        : type(type), format(format), frameLength(frameLength) {}

    int getByteLength() const {
        int frameSize = format.getFrameSize();
        if (frameSize > 0) {
            return frameLength * frameSize;
        }
        return -1;
    }

    int getFrameLength() const {
        return frameLength;
    }

    std::string getProperty(const std::string& key) const {
        auto it = props.find(key);
        if (it != props.end()) {
            return it->second;
        }
        return std::string();
    }

    std::string toString() const {
        return "AudioFileFormat[type=" + type.getName() + ", format=AudioFormat, frameLength=" + std::to_string(frameLength) + "]";
    }

    const std::map<std::string, std::string>& properties() const {
        return props;
    }

    Type getType() const {
        return type;
    }

    AudioFormat getFormat() const {
        return format;
    }
};

// Test functions (parameterized as in Java)

void getByteLength_test_6497(AudioFileFormat::Type c0, AudioFormat c1, int c2) {
AudioFileFormat instance(c0, c1, c2);
    instance.getByteLength();
}
