#include <vector>
#include <cstdint>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <stdexcept>
#include <functional>

// Minimal base class to mimic Java Object
class Object {
public:
    virtual ~Object() = default;

    virtual bool equals(const Object& other) const {
        return (this == &other);
    }

    virtual std::size_t hashCode() const {
        return std::hash<const Object*>()(this);
    }

    virtual std::string toString() const {
        return "Object@" + std::to_string(reinterpret_cast<std::uintptr_t>(this));
    }
};

// ATR class mimicking javax.smartcardio.ATR
class ATR : public Object {
private:
    std::vector<uint8_t> rawBytes;
    std::vector<uint8_t> historicalBytes;

    // Parse the ATR bytes and extract historical bytes
    void parse() {
        if (rawBytes.size() < 2) {
            historicalBytes.clear();
            return;
        }

        std::size_t idx = 2; // after TS (byte 0) and T0 (byte 1)
        uint8_t T0 = rawBytes[1];
        uint8_t numHistorical = T0 & 0x0F; // lower nibble

        // Skip interface bytes
        uint8_t T = T0;
        while ((T & 0xF0) != 0) {
            if (T & 0x10) idx++; // TA1 present
            if (T & 0x20) idx++; // TB1 present
            if (T & 0x40) idx++; // TC1 present
            if (T & 0x80) {
                if (idx >= rawBytes.size()) {
                    // Malformed; stop
                    break;
                }
                T = rawBytes[idx];
                idx++; // consume TD byte
            } else {
                break;
            }
        }

        // Check that there are enough bytes for historical bytes
        if (idx + numHistorical > rawBytes.size()) {
            numHistorical = static_cast<uint8_t>(rawBytes.size() - idx);
        }
        historicalBytes.assign(rawBytes.begin() + idx, rawBytes.begin() + idx + numHistorical);
    }

public:
    // Constructor takes a byte array (vector)
    ATR(const std::vector<uint8_t>& bytes) : rawBytes(bytes) {
        parse();
    }

    // Constructor from raw pointer and size (for convenience)
    ATR(const uint8_t* data, std::size_t len) : rawBytes(data, data + len) {
        parse();
    }

    // overrides
    bool equals(const Object& other) const override {
        const ATR* otherATR = dynamic_cast<const ATR*>(&other);
        if (!otherATR) {
            return false;
        }
        return rawBytes == otherATR->rawBytes;
    }

    std::size_t hashCode() const override {
        // Simple hash: combine bytes using a polynomial hash
        std::size_t hash = 0;
        for (auto b : rawBytes) {
            hash = (hash * 31) + b; // same as Java String hashCode approach
        }
        // Use a separate constant to differentiate from String
        hash = (hash * 17) ^ rawBytes.size();
        return hash;
    }

    std::string toString() const override {
        std::ostringstream oss;
        oss << "ATR: ";
        for (auto b : rawBytes) {
            oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(b);
        }
        return oss.str();
    }

    // Returns a copy of the raw ATR bytes
    std::vector<uint8_t> getBytes() const {
        return rawBytes;
    }

    // Returns a copy of the historical bytes
    std::vector<uint8_t> getHistoricalBytes() const {
        return historicalBytes;
    }
};

// ========== Test Functions (translated from JUnit tests) ==========

void equals_test_6446(Object& p0, const std::vector<uint8_t>& c0) {
ATR instance(c0);
    instance.equals(p0);  // ignore return value, same as Java test
}
