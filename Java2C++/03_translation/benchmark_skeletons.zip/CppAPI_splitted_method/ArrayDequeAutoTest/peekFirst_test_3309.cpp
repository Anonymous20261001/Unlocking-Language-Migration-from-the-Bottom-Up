#include <deque>
#include <cstddef>

// Minimal base class for Java Object
class Object {
public:
    virtual ~Object() = default;
};

// Abstract interfaces for Collection, Consumer, Predicate (simplified)
class Collection {
public:
    virtual ~Collection() = default;
    virtual int size() const { return 0; }
    virtual bool isEmpty() const { return true; }
    virtual bool contains(Object* o) const { (void)o; return false; }
    virtual void add(Object* o) { (void)o; }
    virtual void remove(Object* o) { (void)o; }
    virtual void clear() {}
    // minimal – not used in test stubs
};

class Consumer {
public:
    virtual ~Consumer() = default;
    virtual void accept(Object* o) = 0;
};

class Predicate {
public:
    virtual ~Predicate() = default;
    virtual bool test(Object* o) = 0;
};

// Forward iterator interface (like Java Iterator)
class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() = 0;
    virtual Object* next() = 0;
};

// Spliterator stub
class Spliterator {
public:
    virtual ~Spliterator() = default;
};

// Concrete iterator for ArrayDeque (forward)
class ArrayDequeIterator : public Iterator {
public:
    ArrayDequeIterator(std::deque<Object*>& dq) : container(dq), pos(dq.begin()) {}
    bool hasNext() override { return pos != container.end(); }
    Object* next() override {
        if (!hasNext()) return nullptr; // Java would throw NoSuchElementException
        return *pos++;
    }
private:
    std::deque<Object*>& container;
    std::deque<Object*>::iterator pos;
};

// Concrete reverse iterator for descendingIterator
class ArrayDequeDescendingIterator : public Iterator {
public:
    ArrayDequeDescendingIterator(std::deque<Object*>& dq) : container(dq), pos(dq.rbegin()) {}
    bool hasNext() override { return pos != container.rend(); }
    Object* next() override {
        if (!hasNext()) return nullptr;
        return *pos++;
    }
private:
    std::deque<Object*>& container;
    std::deque<Object*>::reverse_iterator pos;
};

// ArrayDeque class – mimics java.util.ArrayDeque<Object>
class ArrayDeque {
public:
    ArrayDeque() = default;

    // Copy constructor for clone
    ArrayDeque(const ArrayDeque& other) : data(other.data) {}

    // --- Core deque operations ---
    void addFirst(Object* e) { data.push_front(e); }
    void addLast(Object* e)  { data.push_back(e); }
    void add(Object* e)      { addLast(e); }        // add() = addLast()

    bool offerFirst(Object* e) { addFirst(e); return true; }
    bool offerLast(Object* e)  { addLast(e); return true; }
    bool offer(Object* e)      { return offerLast(e); }

    Object* removeFirst() {
        if (data.empty()) return nullptr; // Java throws NoSuchElementException
        Object* e = data.front();
        data.pop_front();
        return e;
    }
    Object* removeLast() {
        if (data.empty()) return nullptr;
        Object* e = data.back();
        data.pop_back();
        return e;
    }
    Object* remove() { return removeFirst(); }        // remove() = removeFirst()
    bool remove(Object* o) {
        for (auto it = data.begin(); it != data.end(); ++it) {
            if (*it == o) {
                data.erase(it);
                return true;
            }
        }
        return false;
    }

    Object* pollFirst() {
        if (data.empty()) return nullptr;
        Object* e = data.front();
        data.pop_front();
        return e;
    }
    Object* pollLast() {
        if (data.empty()) return nullptr;
        Object* e = data.back();
        data.pop_back();
        return e;
    }
    Object* poll() { return pollFirst(); }

    Object* peekFirst() { return data.empty() ? nullptr : data.front(); }
    Object* peekLast()  { return data.empty() ? nullptr : data.back(); }
    Object* peek()      { return peekFirst(); }
    Object* element()   { return data.front(); } // throws if empty, but here returns nullptr

    void push(Object* e) { addFirst(e); }
    Object* pop()        { return removeFirst(); }

    // --- Collection methods ---
    int size() const { return static_cast<int>(data.size()); }
    bool isEmpty() const { return data.empty(); }
    bool contains(Object* o) const {
        for (auto* e : data) if (e == o) return true;
        return false;
    }
    void clear() { data.clear(); }

    Object* clone() const { return new ArrayDeque(*this); }  // returns new copy as Object*

    // toArray methods
    void toArray(Object** arr) {
        std::size_t i = 0;
        for (auto* e : data) {
            arr[i++] = e;
        }
    }
    std::vector<Object*> toArray() {
        std::vector<Object*> vec;
        for (auto* e : data) vec.push_back(e);
        return vec;
    }

    Iterator* iterator() {
        return new ArrayDequeIterator(data);
    }
    Iterator* descendingIterator() {
        return new ArrayDequeDescendingIterator(data);
    }
    Spliterator* spliterator() {
        return new Spliterator();
    }

    // Bulk operations (stubs – ignore argument for test sake)
    bool addAll(Collection* c) { (void)c; return false; }
    bool removeAll(Collection* c) { (void)c; return false; }
    bool retainAll(Collection* c) { (void)c; return false; }
    bool removeIf(Predicate* p) { (void)p; return false; }

    void forEach(Consumer* c) {
        for (auto* e : data) c->accept(e);
    }

    // Remove first / last occurrence of an object
    bool removeFirstOccurrence(Object* o) {
        for (auto it = data.begin(); it != data.end(); ++it) {
            if (*it == o) {
                data.erase(it);
                return true;
            }
        }
        return false;
    }
    bool removeLastOccurrence(Object* o) {
        for (auto it = data.rbegin(); it != data.rend(); ++it) {
            if (*it == o) {
                // convert reverse_iterator to iterator
                data.erase(std::next(it).base());
                return true;
            }
        }
        return false;
    }

private:
    std::deque<Object*> data;
};

// ========== Test functions ==========
// Each Java @Test method becomes a C++ void function with the same name.

void peekFirst_test_3309() {
ArrayDeque instance;
    instance.peekFirst();
}
