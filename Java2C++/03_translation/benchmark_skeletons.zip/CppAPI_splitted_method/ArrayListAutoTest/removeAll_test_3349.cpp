#include <vector>
#include <functional>
#include <algorithm>
#include <stdexcept>
#include <cstddef>
#include <cstring>
#include <memory>

// Minimal Object class
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(Object* other) const {
        return this == other;
    }
    virtual size_t hashCode() const {
        return reinterpret_cast<size_t>(this);
    }
};

// Forward declarations for function types used in ArrayList
using Comparator = std::function<int(Object*, Object*)>;
using Consumer   = std::function<void(Object*)>;
using Predicate  = std::function<bool(Object*)>;
using UnaryOperator = std::function<Object*(Object*)>;

// Iterator, ListIterator, Spliterator base classes
class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() = 0;
    virtual Object* next() = 0;
};

class ListIterator : public Iterator {
public:
    virtual bool hasPrevious() = 0;
    virtual Object* previous() = 0;
    virtual int nextIndex() = 0;
    virtual int previousIndex() = 0;
    virtual void set(Object* e) = 0;
    virtual void add(Object* e) = 0;
};

class Spliterator {
public:
    virtual ~Spliterator() = default;
    virtual bool tryAdvance(Consumer action) = 0;
    virtual void forEachRemaining(Consumer action) = 0;
    virtual Spliterator* trySplit() = 0;
    virtual long estimateSize() = 0;
    virtual int characteristics() = 0;
};

// The main ArrayList class
class ArrayList {
private:
    std::vector<Object*> data;

public:
    // Constructors
    ArrayList() = default;
    ArrayList(const ArrayList& other) : data(other.data) {} // shallow copy of pointers
    ArrayList& operator=(const ArrayList& other) {
        if (this != &other) data = other.data;
        return *this;
    }

    // Nested iterator implementations
    class ArrayListIterator : public Iterator {
        ArrayList* list;
        size_t index;
    public:
        ArrayListIterator(ArrayList* l, size_t idx) : list(l), index(idx) {}
        bool hasNext() override { return index < list->size(); }
        Object* next() override {
            if (!hasNext()) throw std::out_of_range("Iterator next on empty");
            return list->get(index++);
        }
    };

    class ArrayListListIterator : public ListIterator {
        ArrayList* list;
        int idx;
    public:
        ArrayListListIterator(ArrayList* l, int i) : list(l), idx(i) {}
        bool hasNext() override { return idx < static_cast<int>(list->size()); }
        Object* next() override {
            if (!hasNext()) throw std::out_of_range("ListIterator next");
            return list->get(idx++);
        }
        bool hasPrevious() override { return idx > 0; }
        Object* previous() override {
            if (!hasPrevious()) throw std::out_of_range("ListIterator previous");
            return list->get(--idx);
        }
        int nextIndex() override { return idx; }
        int previousIndex() override { return idx - 1; }
        void set(Object* e) override {
            if (idx == 0 || idx > static_cast<int>(list->size()))
                throw std::out_of_range("ListIterator set");
            list->set(idx - 1, e);
        }
        void add(Object* e) override {
            list->add(idx++, e);
        }
    };

    class ArrayListSpliterator : public Spliterator {
        ArrayList* list;
        size_t index;
        size_t fence;
    public:
        ArrayListSpliterator(ArrayList* l, size_t i, size_t f) : list(l), index(i), fence(f) {}
        bool tryAdvance(Consumer action) override {
            if (index < fence) {
                action(list->get(index++));
                return true;
            }
            return false;
        }
        void forEachRemaining(Consumer action) override {
            while (index < fence)
                action(list->get(index++));
        }
        Spliterator* trySplit() override {
            size_t mid = (index + fence) / 2;
            if (mid == index) return nullptr;
            size_t oldFence = fence;
            fence = mid;
            return new ArrayListSpliterator(list, mid, oldFence);
        }
        long estimateSize() override { return fence - index; }
        int characteristics() override { return 0; }
    };

    // Core ArrayList methods
    bool add(Object* e) {
        data.push_back(e);
        return true;
    }

    void add(int index, Object* element) {
        if (index < 0 || index > static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for add");
        data.insert(data.begin() + index, element);
    }

    bool addAll(ArrayList* c) {
        for (size_t i = 0; i < c->size(); ++i)
            data.push_back(c->get(i));
        return !c->empty();
    }

    bool addAll(int index, ArrayList* c) {
        if (index < 0 || index > static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for addAll");
        for (size_t i = 0; i < c->size(); ++i)
            data.insert(data.begin() + index + i, c->get(i));
        return !c->empty();
    }

    void clear() { data.clear(); }

    ArrayList* clone() {
        return new ArrayList(*this);
    }

    bool contains(Object* o) {
        for (auto e : data)
            if (e->equals(o)) return true;
        return false;
    }

    void ensureCapacity(int minCapacity) {
        if (static_cast<int>(data.capacity()) < minCapacity)
            data.reserve(minCapacity);
    }

    bool equals(Object* o) {
        auto other = dynamic_cast<ArrayList*>(o);
        if (!other || other->size() != size()) return false;
        for (size_t i = 0; i < size(); ++i)
            if (!get(i)->equals(other->get(i))) return false;
        return true;
    }

    void forEach(Consumer action) {
        for (auto e : data) action(e);
    }

    Object* get(int index) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for get");
        return data[index];
    }

    Object* getFirst() {
        if (data.empty()) throw std::out_of_range("getFirst on empty list");
        return data.front();
    }

    Object* getLast() {
        if (data.empty()) throw std::out_of_range("getLast on empty list");
        return data.back();
    }

    size_t hashCode() {
        size_t h = 1;
        for (auto e : data)
            h = 31 * h + e->hashCode();
        return h;
    }

    int indexOf(Object* o) {
        for (size_t i = 0; i < data.size(); ++i)
            if (data[i]->equals(o)) return static_cast<int>(i);
        return -1;
    }

    bool isEmpty() { return data.empty(); }

    Iterator* iterator() {
        return new ArrayListIterator(this, 0);
    }

    int lastIndexOf(Object* o) {
        for (int i = static_cast<int>(data.size()) - 1; i >= 0; --i)
            if (data[i]->equals(o)) return i;
        return -1;
    }

    ListIterator* listIterator() {
        return new ArrayListListIterator(this, 0);
    }

    ListIterator* listIterator(int index) {
        if (index < 0 || index > static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for listIterator");
        return new ArrayListListIterator(this, index);
    }

    Object* remove(int index) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for remove");
        Object* old = data[index];
        data.erase(data.begin() + index);
        return old;
    }

    bool remove(Object* o) {
        for (auto it = data.begin(); it != data.end(); ++it)
            if ((*it)->equals(o)) {
                data.erase(it);
                return true;
            }
        return false;
    }

    bool removeAll(ArrayList* c) {
        bool modified = false;
        for (auto it = data.begin(); it != data.end(); ) {
            if (c->contains(*it)) {
                it = data.erase(it);
                modified = true;
            } else {
                ++it;
            }
        }
        return modified;
    }

    Object* removeFirst() {
        if (data.empty()) throw std::out_of_range("removeFirst on empty list");
        return remove(0);
    }

    Object* removeLast() {
        if (data.empty()) throw std::out_of_range("removeLast on empty list");
        return remove(static_cast<int>(data.size()) - 1);
    }

    bool removeIf(Predicate filter) {
        auto it = std::remove_if(data.begin(), data.end(), filter);
        bool removed = (it != data.end());
        data.erase(it, data.end());
        return removed;
    }

    void replaceAll(UnaryOperator op) {
        std::transform(data.begin(), data.end(), data.begin(), op);
    }

    bool retainAll(ArrayList* c) {
        bool modified = false;
        for (auto it = data.begin(); it != data.end(); ) {
            if (!c->contains(*it)) {
                it = data.erase(it);
                modified = true;
            } else {
                ++it;
            }
        }
        return modified;
    }

    Object* set(int index, Object* element) {
        if (index < 0 || index >= static_cast<int>(data.size()))
            throw std::out_of_range("Index out of bounds for set");
        Object* old = data[index];
        data[index] = element;
        return old;
    }

    int size() { return static_cast<int>(data.size()); }

    void sort(Comparator c) {
        std::sort(data.begin(), data.end(),
                  [&c](Object* a, Object* b) { return c(a, b) < 0; });
    }

    Spliterator* spliterator() {
        return new ArrayListSpliterator(this, 0, data.size());
    }

    ArrayList* subList(int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex > static_cast<int>(data.size()) || fromIndex > toIndex)
            throw std::out_of_range("Index out of bounds for subList");
        ArrayList* sub = new ArrayList();
        for (int i = fromIndex; i < toIndex; ++i)
            sub->add(data[i]);
        return sub;
    }

    Object** toArray() {
        Object** arr = new Object*[data.size()];
        std::copy(data.begin(), data.end(), arr);
        return arr;
    }

    Object** toArray(Object** a) {
        if (a == nullptr) return toArray();
        size_t asize = sizeof(a); // not portable, but used for demonstration
        // In reality we cannot know array size from a pointer, so we assume enough space
        std::copy(data.begin(), data.end(), a);
        return a;
    }

    void trimToSize() {
        data.shrink_to_fit();
    }
};

// The test functions (translated from Java)

void removeAll_test_3349(ArrayList* p0) {
ArrayList instance;
    instance.removeAll(p0);
}
