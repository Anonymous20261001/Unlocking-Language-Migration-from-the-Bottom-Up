#include <atomic>
#include <functional>
#include <string>
#include <sstream>
#include <cassert>
#include <iostream>

// Forward declarations for functional types used in the API
using UnaryOperator = std::function<void*(void*)>;
using BinaryOperator = std::function<void*(void*, void*)>;

/**
 * C++ equivalent of java.util.concurrent.atomic.AtomicReference.
 * Stores a void* (nullptr by default) and provides atomic operations
 * with memory ordering similar to the Java API.
 */
class AtomicReference {
private:
    std::atomic<void*> m_ref;

public:
    AtomicReference() : m_ref(nullptr) {}

    // ----- simple get / set -----
    void* get() {
        return m_ref.load(std::memory_order_seq_cst);
    }

    void set(void* newValue) {
        m_ref.store(newValue, std::memory_order_seq_cst);
    }

    // ----- toString (Java style) -----
    std::string toString() {
        std::ostringstream oss;
        oss << "AtomicReference@" << std::hex << m_ref.load(std::memory_order_seq_cst);
        return oss.str();
    }

    // ----- opaque (relaxed) -----
    void* getOpaque() {
        return m_ref.load(std::memory_order_relaxed);
    }

    void setOpaque(void* newValue) {
        m_ref.store(newValue, std::memory_order_relaxed);
    }

    // ----- acquire / release -----
    void* getAcquire() {
        return m_ref.load(std::memory_order_acquire);
    }

    void setRelease(void* newValue) {
        m_ref.store(newValue, std::memory_order_release);
    }

    // ----- compareAndSet (strong, seq_cst) -----
    bool compareAndSet(void* expected, void* newValue) {
        return m_ref.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
    }

    // ----- compareAndExchange variants -----
    void* compareAndExchange(void* expected, void* newValue) {
        m_ref.compare_exchange_strong(expected, newValue, std::memory_order_seq_cst);
        return expected; // returns the observed value (which is either old or new? Actually Java returns the current value before exchange)
    }
    // Actually Java's compareAndExchange returns the witness value (the current value before the attempted exchange).
    // In C++ compare_exchange_strong stores the observed value into expected if it fails.
    // So we can return the original expected after the operation (which contains the observed value).
    // For simplicity we implement as a loop? Standard is: compare_exchange_strong updates expected to actual value.
    // So we just return expected after the call (since it's passed by reference).
    // But careful: if exchange succeeds, expected remains unchanged (the old value). So we need to return the old value.
    // The best approach is to use a local copy and pass it by reference.
    // We'll implement each variant with its own memory order.

    void* compareAndExchange(void* expected, void* newValue, std::memory_order order) {
        m_ref.compare_exchange_strong(expected, newValue, order);
        return expected;
    }

    void* compareAndExchangeAcquire(void* expected, void* newValue) {
        return compareAndExchange(expected, newValue, std::memory_order_acquire);
    }

    void* compareAndExchangeRelease(void* expected, void* newValue) {
        return compareAndExchange(expected, newValue, std::memory_order_release);
    }

    // ----- weakCompareAndSet variants -----
    bool weakCompareAndSetPlain(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_relaxed);
    }

    bool weakCompareAndSet(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    bool weakCompareAndSetAcquire(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_acquire);
    }

    bool weakCompareAndSetRelease(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_release);
    }

    bool weakCompareAndSetVolatile(void* expected, void* newValue) {
        return m_ref.compare_exchange_weak(expected, newValue, std::memory_order_seq_cst);
    }

    // ----- getAndSet -----
    void* getAndSet(void* newValue) {
        return m_ref.exchange(newValue, std::memory_order_seq_cst);
    }

    // ----- lazySet (release) -----
    void lazySet(void* newValue) {
        m_ref.store(newValue, std::memory_order_release);
    }

    // ----- getAndUpdate / updateAndGet -----
    void* getAndUpdate(UnaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return old;
            }
        }
    }

    void* updateAndGet(UnaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return newVal;
            }
        }
    }

    // ----- getAndAccumulate / accumulateAndGet -----
    void* getAndAccumulate(void* x, BinaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old, x);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return old;
            }
        }
    }

    void* accumulateAndGet(void* x, BinaryOperator op) {
        void* old = m_ref.load(std::memory_order_seq_cst);
        while (true) {
            void* newVal = op(old, x);
            if (m_ref.compare_exchange_weak(old, newVal, std::memory_order_seq_cst)) {
                return newVal;
            }
        }
    }

    // ----- getPlain / setPlain (relaxed) -----
    void* getPlain() {
        return m_ref.load(std::memory_order_relaxed);
    }

    void setPlain(void* newValue) {
        m_ref.store(newValue, std::memory_order_relaxed);
    }
};

// ============================
// Translation of the Java test file
// ============================

// Test: get_test_4889

void getAndSet_test_4904(void* p0) {
AtomicReference instance;
    instance.getAndSet(p0);
}
