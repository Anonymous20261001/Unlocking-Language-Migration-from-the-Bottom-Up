#include <map>
#include <vector>
#include <algorithm>

// Base classes to mimic Java Object and Action
class Object {
public:
    virtual ~Object() = default;
};

class Action {
public:
    virtual ~Action() = default;
    // Additional Action interface methods can be added if needed
};

// C++ equivalent of javax.swing.ActionMap
class ActionMap {
private:
    std::map<Object*, Action*> entries;
    ActionMap* parent;

public:
    ActionMap() : parent(nullptr) {}

    void remove(Object* key) {
        entries.erase(key);
    }

    int size() const {
        return static_cast<int>(entries.size());
    }

    Action* get(Object* key) const {
        auto it = entries.find(key);
        if (it != entries.end())
            return it->second;
        return nullptr;
    }

    void put(Object* key, Action* action) {
        entries[key] = action;
    }

    void clear() {
        entries.clear();
    }

    ActionMap* getParent() const {
        return parent;
    }

    std::vector<Object*> keys() const {
        std::vector<Object*> result;
        for (const auto& entry : entries) {
            result.push_back(entry.first);
        }
        return result;
    }

    void setParent(ActionMap* p) {
        parent = p;
    }

    std::vector<Object*> allKeys() const {
        std::vector<Object*> result = keys();
        if (parent != nullptr) {
            std::vector<Object*> parentKeys = parent->allKeys();
            // Add keys from parent that are not already present (optional, mimicking Java behavior)
            // For simplicity, we just combine (Java's allKeys may include duplicates from parent)
            result.insert(result.end(), parentKeys.begin(), parentKeys.end());
        }
        return result;
    }
};

// -------------------------------------------------------------------
// Translated test functions (each corresponds to one @Test method)
// -------------------------------------------------------------------

void allKeys_test_6538() {
ActionMap instance;
    instance.allKeys();
}
