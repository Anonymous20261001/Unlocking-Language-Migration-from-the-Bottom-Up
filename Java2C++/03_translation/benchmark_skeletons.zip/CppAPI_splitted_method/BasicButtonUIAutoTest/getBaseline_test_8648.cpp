#include <cstddef>

// -------------------------------------------------------------------
// Minimal stubs for Java Swing classes used in the tests
// -------------------------------------------------------------------

class JComponent {
public:
    virtual ~JComponent() = default;
};

class AbstractButton : public JComponent {
public:
    virtual ~AbstractButton() = default;
};

class Graphics {
public:
    virtual ~Graphics() = default;
};

struct Dimension {
    int width = 0;
    int height = 0;
};

enum class BaselineResizeBehavior {
    CONSTANT_ASCENT,
    CONSTANT_DESCENT,
    CENTER_OFFSET,
    OTHER
};

// -------------------------------------------------------------------
// BasicButtonUI equivalent (stub implementation)
// -------------------------------------------------------------------
class BasicButtonUI {
public:
    BasicButtonUI() = default;

    void installUI(JComponent* /*c*/) {
        // stub – no operation
    }

    void uninstallUI(JComponent* /*c*/) {
        // stub – no operation
    }

    static BasicButtonUI* createUI(JComponent* /*c*/) {
        return new BasicButtonUI();
    }

    int getDefaultTextIconGap(AbstractButton* /*b*/) {
        return 0;
    }

    Dimension getMaximumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    void paint(Graphics* /*g*/, JComponent* /*c*/) {
        // stub – no operation
    }

    Dimension getPreferredSize(JComponent* /*c*/) {
        return Dimension{};
    }

    Dimension getMinimumSize(JComponent* /*c*/) {
        return Dimension{};
    }

    int getBaseline(JComponent* /*c*/, int /*width*/, int /*height*/) {
        return 0;
    }

    BaselineResizeBehavior getBaselineResizeBehavior(JComponent* /*c*/) {
        return BaselineResizeBehavior::OTHER;
    }
};

// -------------------------------------------------------------------
// Translated test functions (one per @Test method)
// -------------------------------------------------------------------

void getBaseline_test_8648(JComponent* p0, int p1, int p2) {
BasicButtonUI instance;
    instance.getBaseline(p0, p1, p2);
}
