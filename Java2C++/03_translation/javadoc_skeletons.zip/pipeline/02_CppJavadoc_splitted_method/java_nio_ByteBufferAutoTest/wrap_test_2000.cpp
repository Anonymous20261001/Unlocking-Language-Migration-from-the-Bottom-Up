#include <cstddef>
#include <stdexcept>
#include <vector>

class ByteBuffer {
public:
    static ByteBuffer wrap(std::vector<std::byte>& array, int offset, int length) {
        if (offset < 0 || length < 0 ||
            static_cast<std::size_t>(offset) > array.size() ||
            static_cast<std::size_t>(length) > array.size() - static_cast<std::size_t>(offset)) {
            throw std::out_of_range("IndexOutOfBoundsException");
        }
        return ByteBuffer(array, offset, length, false);
    }

    static ByteBuffer wrap(std::vector<std::byte>& array) {
        return wrap(array, 0, static_cast<int>(array.size()));
    }

    static ByteBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("Negative capacity");
        }
        return ByteBuffer(capacity, false);
    }

    static ByteBuffer allocateDirect(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("Negative capacity");
        }
        return ByteBuffer(capacity, true);
    }

private:
    ByteBuffer(std::vector<std::byte>& array, int offset, int length, bool direct)
        : externalArray(&array), offset_(offset), length_(length),
          capacity_(static_cast<int>(array.size())), direct_(direct) {}

    explicit ByteBuffer(int capacity, bool direct)
        : externalArray(nullptr), internalArray(capacity), offset_(0),
          length_(capacity), capacity_(capacity), direct_(direct) {}

    std::vector<std::byte>* externalArray;
    std::vector<std::byte> internalArray;
    int offset_;
    int length_;
    int capacity_;
    bool direct_;
};

void wrap_test_2000(std::vector<std::byte>& p0, int p1, int p2) {
    ByteBuffer::wrap(p0, p1, p2);
}
