#include <set>
#include <string>

using Class = void*;
using Object = void*;
using String = const char*;
using MethodHandle = void*;
using NameSet = std::set<std::string>;

class BeansLinker {
public:
    MethodHandle getLinkerForClass(Class) {
        return nullptr;
    }

    static bool isDynamicMethod(Object) {
        return false;
    }

    static MethodHandle getConstructorMethod(Class, String) {
        return nullptr;
    }

    static NameSet getReadableStaticPropertyNames(Class) {
        return NameSet();
    }

    static NameSet getWritableStaticPropertyNames(Class) {
        return NameSet();
    }

    static NameSet getStaticMethodNames(Class) {
        return NameSet();
    }

    static bool isDynamicConstructor(Object) {
        return false;
    }

    static NameSet getReadableInstancePropertyNames(Class) {
        return NameSet();
    }

    static NameSet getWritableInstancePropertyNames(Class) {
        return NameSet();
    }

    static NameSet getInstanceMethodNames(Class) {
        return NameSet();
    }
};

void isDynamicMethod_test_1577(Object p0) {
    BeansLinker::isDynamicMethod(p0);
}
