#include <stdexcept>
#include <string>
#include <vector>

namespace java_awt_print {

class Printable {
public:
    virtual ~Printable() = default;
};

class PageFormat {
public:
    virtual ~PageFormat() = default;
};

class Book {
public:
    Book() = default;

    Printable* getPrintable(int pageIndex) {
        checkIndex(pageIndex);
        return printables_[static_cast<std::size_t>(pageIndex)];
    }

    PageFormat* getPageFormat(int pageIndex) {
        checkIndex(pageIndex);
        return pageFormats_[static_cast<std::size_t>(pageIndex)];
    }

    int getNumberOfPages() const {
        return static_cast<int>(printables_.size());
    }

    void setPage(int pageIndex, Printable* painter, PageFormat* pageFormat) {
        if (painter == nullptr) {
            throw std::invalid_argument("painter is null");
        }
        if (pageFormat == nullptr) {
            throw std::invalid_argument("pageFormat is null");
        }
        checkIndex(pageIndex);
        const auto idx = static_cast<std::size_t>(pageIndex);
        printables_[idx] = painter;
        pageFormats_[idx] = pageFormat;
    }

    void append(Printable* painter, PageFormat* pageFormat, int numPages) {
        if (painter == nullptr) {
            throw std::invalid_argument("painter is null");
        }
        if (pageFormat == nullptr) {
            throw std::invalid_argument("pageFormat is null");
        }
        if (numPages <= 0) {
            throw std::invalid_argument("numPages must be greater than zero");
        }
        for (int i = 0; i < numPages; ++i) {
            printables_.push_back(painter);
            pageFormats_.push_back(pageFormat);
        }
    }

    void append(Printable* painter, PageFormat* pageFormat) {
        append(painter, pageFormat, 1);
    }

private:
    std::vector<Printable*> printables_;
    std::vector<PageFormat*> pageFormats_;

    void checkIndex(int pageIndex) const {
        if (pageIndex < 0 || pageIndex >= getNumberOfPages()) {
            throw std::out_of_range("pageIndex must be between 0 and " +
                                    std::to_string(getNumberOfPages() - 1));
        }
    }
};

} // namespace java_awt_print

using java_awt_print::Book;
using java_awt_print::PageFormat;
using java_awt_print::Printable;

void setPage_test_1766(int p0, Printable* p1, PageFormat* p2) {
    Book instance;
    instance.setPage(p0, p1, p2);
}
