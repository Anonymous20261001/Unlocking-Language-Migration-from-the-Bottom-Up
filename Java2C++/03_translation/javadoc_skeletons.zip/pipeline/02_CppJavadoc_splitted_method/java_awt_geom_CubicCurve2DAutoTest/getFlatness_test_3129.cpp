#include <cmath>
#include <algorithm>

class CubicCurve2D {
public:
    CubicCurve2D()
        : x1(0), y1(0), ctrlx1(0), ctrly1(0), ctrlx2(0), ctrly2(0), x2(0), y2(0) {}

    CubicCurve2D(double x1_, double y1_, double ctrlx1_, double ctrly1_,
                 double ctrlx2_, double ctrly2_, double x2_, double y2_)
        : x1(x1_), y1(y1_), ctrlx1(ctrlx1_), ctrly1(ctrly1_),
          ctrlx2(ctrlx2_), ctrly2(ctrly2_), x2(x2_), y2(y2_) {}

    void setCurve(double x1_, double y1_, double ctrlx1_, double ctrly1_,
                  double ctrlx2_, double ctrly2_, double x2_, double y2_) {
        x1 = x1_; y1 = y1_; ctrlx1 = ctrlx1_; ctrly1 = ctrly1_;
        ctrlx2 = ctrlx2_; ctrly2 = ctrly2_; x2 = x2_; y2 = y2_;
    }

    double getX1() const { return x1; }
    double getY1() const { return y1; }
    double getCtrlX1() const { return ctrlx1; }
    double getCtrlY1() const { return ctrly1; }
    double getCtrlX2() const { return ctrlx2; }
    double getCtrlY2() const { return ctrly2; }
    double getX2() const { return x2; }
    double getY2() const { return y2; }

    static double getFlatnessSq(double x1, double y1, double ctrlx1, double ctrly1,
                                double ctrlx2, double ctrly2, double x2, double y2) {
        return std::max(ptSegDistSq(x1, y1, x2, y2, ctrlx1, ctrly1),
                        ptSegDistSq(x1, y1, x2, y2, ctrlx2, ctrly2));
    }

    static double getFlatnessSq(const double* coords, int offset) {
        return getFlatnessSq(coords[offset], coords[offset + 1],
                             coords[offset + 2], coords[offset + 3],
                             coords[offset + 4], coords[offset + 5],
                             coords[offset + 6], coords[offset + 7]);
    }

    static double getFlatness(const double* coords, int offset) {
        return std::sqrt(getFlatnessSq(coords, offset));
    }

    static double getFlatness(double x1, double y1, double ctrlx1, double ctrly1,
                              double ctrlx2, double ctrly2, double x2, double y2) {
        return std::sqrt(getFlatnessSq(x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2));
    }

    static void subdivide(const double* src, int srcOff,
                          double* left, int leftOff,
                          double* right, int rightOff) {
        double x0 = src[srcOff];
        double y0 = src[srcOff + 1];
        double x1 = src[srcOff + 2];
        double y1 = src[srcOff + 3];
        double x2 = src[srcOff + 4];
        double y2 = src[srcOff + 5];
        double x3 = src[srcOff + 6];
        double y3 = src[srcOff + 7];

        double x01 = (x0 + x1) / 2.0;
        double y01 = (y0 + y1) / 2.0;
        double x12 = (x1 + x2) / 2.0;
        double y12 = (y1 + y2) / 2.0;
        double x23 = (x2 + x3) / 2.0;
        double y23 = (y2 + y3) / 2.0;
        double x012 = (x01 + x12) / 2.0;
        double y012 = (y01 + y12) / 2.0;
        double x123 = (x12 + x23) / 2.0;
        double y123 = (y12 + y23) / 2.0;
        double x0123 = (x012 + x123) / 2.0;
        double y0123 = (y012 + y123) / 2.0;

        left[leftOff] = x0;
        left[leftOff + 1] = y0;
        left[leftOff + 2] = x01;
        left[leftOff + 3] = y01;
        left[leftOff + 4] = x012;
        left[leftOff + 5] = y012;
        left[leftOff + 6] = x0123;
        left[leftOff + 7] = y0123;

        right[rightOff] = x0123;
        right[rightOff + 1] = y0123;
        right[rightOff + 2] = x123;
        right[rightOff + 3] = y123;
        right[rightOff + 4] = x23;
        right[rightOff + 5] = y23;
        right[rightOff + 6] = x3;
        right[rightOff + 7] = y3;
    }

    static void subdivide(const CubicCurve2D& src, CubicCurve2D& left, CubicCurve2D& right) {
        double srcCoords[8] = {
            src.getX1(), src.getY1(),
            src.getCtrlX1(), src.getCtrlY1(),
            src.getCtrlX2(), src.getCtrlY2(),
            src.getX2(), src.getY2()
        };
        double leftCoords[8];
        double rightCoords[8];
        subdivide(srcCoords, 0, leftCoords, 0, rightCoords, 0);
        left.setCurve(leftCoords[0], leftCoords[1], leftCoords[2], leftCoords[3],
                      leftCoords[4], leftCoords[5], leftCoords[6], leftCoords[7]);
        right.setCurve(rightCoords[0], rightCoords[1], rightCoords[2], rightCoords[3],
                       rightCoords[4], rightCoords[5], rightCoords[6], rightCoords[7]);
    }

    static int solveCubic(const double* eqn, double* res) {
        double d = eqn[3];
        if (d == 0.0) {
            return solveQuadratic(eqn, res);
        }

        double a = eqn[2] / d;
        double b = eqn[1] / d;
        double c = eqn[0] / d;

        double Q = (a * a - 3.0 * b) / 9.0;
        double R = (2.0 * a * a * a - 9.0 * a * b + 27.0 * c) / 54.0;
        double Q3 = Q * Q * Q;
        double R2 = R * R;
        double n = -a / 3.0;

        if (R2 < Q3) {
            double t = std::acos(R / std::sqrt(Q3));
            Q = -2.0 * std::sqrt(Q);
            res[0] = Q * std::cos(t / 3.0) + n;
            res[1] = Q * std::cos((t + 2.0 * std::acos(-1.0)) / 3.0) + n;
            res[2] = Q * std::cos((t - 2.0 * std::acos(-1.0)) / 3.0) + n;
            return 3;
        } else {
            double A = -std::pow(std::abs(R) + std::sqrt(R2 - Q3), 1.0 / 3.0);
            if (R < 0.0) A = -A;
            double B = (A == 0.0) ? 0.0 : Q / A;
            res[0] = A + B + n;
            return 1;
        }
    }

    static int solveCubic(double* eqn) {
        return solveCubic(eqn, eqn);
    }

private:
    static double ptSegDistSq(double x1, double y1, double x2, double y2,
                              double px, double py) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double lenSq = dx * dx + dy * dy;
        if (lenSq == 0.0) {
            double vx = px - x1;
            double vy = py - y1;
            return vx * vx + vy * vy;
        }
        double t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
        t = std::max(0.0, std::min(1.0, t));
        double cx = x1 + t * dx;
        double cy = y1 + t * dy;
        double vx = px - cx;
        double vy = py - cy;
        return vx * vx + vy * vy;
    }

    static int solveQuadratic(const double* eqn, double* res) {
        double a = eqn[2];
        double b = eqn[1];
        double c = eqn[0];
        if (a == 0.0) {
            if (b == 0.0) return 0;
            res[0] = -c / b;
            return 1;
        }
        double disc = b * b - 4.0 * a * c;
        if (disc < 0.0) return 0;
        disc = std::sqrt(disc);
        res[0] = (-b + disc) / (2.0 * a);
        res[1] = (-b - disc) / (2.0 * a);
        return 2;
    }

    double x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2;
};

void getFlatness_test_3129() {
    double p0 = 0.0, p1 = 0.0, p2 = 1.0, p3 = 2.0;
    double p4 = 2.0, p5 = 2.0, p6 = 3.0, p7 = 0.0;
    CubicCurve2D::getFlatness(p0, p1, p2, p3, p4, p5, p6, p7);
}
