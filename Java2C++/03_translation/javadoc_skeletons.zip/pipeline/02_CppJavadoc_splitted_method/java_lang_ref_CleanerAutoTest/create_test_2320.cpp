#include <functional>
#include <thread>
#include <utility>

class ThreadFactory {
public:
    virtual ~ThreadFactory() = default;
    virtual std::thread newThread(std::function<void()> task) const = 0;
};

class DefaultThreadFactory final : public ThreadFactory {
public:
    std::thread newThread(std::function<void()> task) const override {
        return std::thread(std::move(task));
    }
};

class Cleaner {
public:
    static Cleaner create() {
        return Cleaner{};
    }

    static Cleaner create(const ThreadFactory& factory) {
        (void)factory;
        return Cleaner{};
    }

    Cleaner(const Cleaner&) = delete;
    Cleaner& operator=(const Cleaner&) = delete;
    Cleaner(Cleaner&&) noexcept = default;
    Cleaner& operator=(Cleaner&&) noexcept = default;

private:
    Cleaner() = default;
};

void create_test_2320() {
    DefaultThreadFactory p0;
    Cleaner cleaner = Cleaner::create(p0);
    (void)cleaner;
}
