#include <string>
#include <vector>
#include <utility>

using String = std::string;

class ClassDesc {
private:
    std::string descriptor_;

    explicit ClassDesc(std::string descriptor)
        : descriptor_(std::move(descriptor)) {}

public:
    static ClassDesc ofDescriptor(const String& descriptor) {
        return ClassDesc(descriptor);
    }

    static ClassDesc of(const String& className) {
        std::string desc = "L";
        for (char c : className) {
            if (c == '.') {
                desc += '/';
            } else {
                desc += c;
            }
        }
        desc += ';';
        return ClassDesc(desc);
    }

    const std::string& descriptor() const {
        return descriptor_;
    }

    bool operator==(const ClassDesc& other) const {
        return descriptor_ == other.descriptor_;
    }

    bool operator!=(const ClassDesc& other) const {
        return !(*this == other);
    }
};

using ClassDescArray = std::vector<ClassDesc>;

class DirectMethodHandleDesc {
private:
    std::string kind_;
    ClassDesc owner_;
    String name_;
    ClassDesc returnType_;
    ClassDescArray bootstrapArgs_;

public:
    DirectMethodHandleDesc(String kind,
                           const ClassDesc& owner,
                           const String& name,
                           const ClassDesc& returnType,
                           const ClassDescArray& bootstrapArgs)
        : kind_(std::move(kind)),
          owner_(owner),
          name_(name),
          returnType_(returnType),
          bootstrapArgs_(bootstrapArgs) {}

    const std::string& kind() const {
        return kind_;
    }

    const ClassDesc& owner() const {
        return owner_;
    }

    const String& name() const {
        return name_;
    }

    const ClassDesc& returnType() const {
        return returnType_;
    }

    const ClassDescArray& bootstrapArgs() const {
        return bootstrapArgs_;
    }
};

class ConstantDescs {
public:
    static DirectMethodHandleDesc ofConstantBootstrap(const ClassDesc& owner,
                                                      const String& name,
                                                      const ClassDesc& returnType,
                                                      const ClassDescArray& bootstrapArgs) {
        return DirectMethodHandleDesc("static", owner, name, returnType, bootstrapArgs);
    }

    static DirectMethodHandleDesc ofCallsiteBootstrap(const ClassDesc& owner,
                                                      const String& name,
                                                      const ClassDesc& returnType,
                                                      const ClassDescArray& bootstrapArgs) {
        return DirectMethodHandleDesc("static", owner, name, returnType, bootstrapArgs);
    }
};

void ofCallsiteBootstrap_test_2933() {
    ClassDesc owner = ClassDesc::ofDescriptor("Ljava/lang/invoke/LambdaMetafactory;");
    String name = "metafactory";
    ClassDesc returnType = ClassDesc::ofDescriptor("Ljava/lang/invoke/CallSite;");
    ClassDescArray bootstrapArgs = {
        ClassDesc::ofDescriptor("Ljava/lang/invoke/MethodHandles$Lookup;"),
        ClassDesc::ofDescriptor("Ljava/lang/String;"),
        ClassDesc::ofDescriptor("Ljava/lang/invoke/MethodType;")
    };
    ConstantDescs::ofCallsiteBootstrap(owner, name, returnType, bootstrapArgs);
}
