#include <string>

class Object {
public:
    virtual ~Object() = default;
};

class Attribute : public Object {
public:
    ~Attribute() override = default;
};

class Class : public Object {
public:
    explicit Class(const char* name) : name_(name) {}
    ~Class() override = default;
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class AttributeSet : public Object {
public:
    ~AttributeSet() override = default;
};

class DocAttributeSet : public AttributeSet {
public:
    ~DocAttributeSet() override = default;
};

class PrintJobAttributeSet : public AttributeSet {
public:
    ~PrintJobAttributeSet() override = default;
};

class PrintRequestAttributeSet : public AttributeSet {
public:
    ~PrintRequestAttributeSet() override = default;
};

class PrintServiceAttributeSet : public AttributeSet {
public:
    ~PrintServiceAttributeSet() override = default;
};

class AttributeSetUtilities {
public:
    static AttributeSet* unmodifiableView(AttributeSet* attributeSet) {
        return attributeSet;
    }

    static DocAttributeSet* unmodifiableView(DocAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintJobAttributeSet* unmodifiableView(PrintJobAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintRequestAttributeSet* unmodifiableView(PrintRequestAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintServiceAttributeSet* unmodifiableView(PrintServiceAttributeSet* attributeSet) {
        return attributeSet;
    }

    static AttributeSet* synchronizedView(AttributeSet* attributeSet) {
        return attributeSet;
    }

    static DocAttributeSet* synchronizedView(DocAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintJobAttributeSet* synchronizedView(PrintJobAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintRequestAttributeSet* synchronizedView(PrintRequestAttributeSet* attributeSet) {
        return attributeSet;
    }

    static PrintServiceAttributeSet* synchronizedView(PrintServiceAttributeSet* attributeSet) {
        return attributeSet;
    }

    static void verifyAttributeCategory(Object* object, Class* category) {
        (void)object;
        (void)category;
    }

    static void verifyAttributeValue(Object* object, Class* category) {
        (void)object;
        (void)category;
    }

    static void verifyCategoryForValue(Class* category, Attribute* attribute) {
        (void)category;
        (void)attribute;
    }
};

void unmodifiableView_test_849(AttributeSet* p0) {
    AttributeSetUtilities::unmodifiableView(p0);
}
