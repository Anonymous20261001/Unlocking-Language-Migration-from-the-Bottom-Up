class DatatypeFactory {
public:
    DatatypeFactory() = default;
    static DatatypeFactory newDefaultInstance() {
        return DatatypeFactory();
    }
};

void newDefaultInstance_test_3280() {
    DatatypeFactory::newDefaultInstance();
}
