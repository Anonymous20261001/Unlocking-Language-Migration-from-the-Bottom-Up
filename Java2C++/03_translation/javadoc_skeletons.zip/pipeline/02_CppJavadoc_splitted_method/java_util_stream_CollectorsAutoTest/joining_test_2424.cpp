#include <functional>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <optional>
#include <numeric>
#include <algorithm>
#include <cassert>

// Forward declarations
template<typename T> class Collector;
template<typename T> class Supplier;
template<typename T> class Function;
template<typename T> class Predicate;
template<typename T> class Comparator;
template<typename T> class BinaryOperator;
template<typename T> class BiFunction;
template<typename T> class ToIntFunction;
template<typename T> class ToLongFunction;
template<typename T> class ToDoubleFunction;

// Basic functional interfaces
template<typename R, typename... Args>
class Function {
public:
    virtual R apply(Args... args) = 0;
    virtual ~Function() = default;
};

template<typename T>
class Supplier {
public:
    virtual T get() = 0;
    virtual ~Supplier() = default;
};

template<typename T>
class Predicate {
public:
    virtual bool test(T t) = 0;
    virtual ~Predicate() = default;
};

template<typename T>
class Comparator {
public:
    virtual int compare(T a, T b) = 0;
    virtual ~Comparator() = default;
};

template<typename T>
class BinaryOperator {
public:
    virtual T apply(T a, T b) = 0;
    virtual ~BinaryOperator() = default;
};

template<typename A, typename B, typename R>
class BiFunction {
public:
    virtual R apply(A a, B b) = 0;
    virtual ~BiFunction() = default;
};

template<typename T>
class ToIntFunction {
public:
    virtual int applyAsInt(T t) = 0;
    virtual ~ToIntFunction() = default;
};

template<typename T>
class ToLongFunction {
public:
    virtual long applyAsLong(T t) = 0;
    virtual ~ToLongFunction() = default;
};

template<typename T>
class ToDoubleFunction {
public:
    virtual double applyAsDouble(T t) = 0;
    virtual ~ToDoubleFunction() = default;
};

// CharSequence equivalent
class CharSequence {
public:
    virtual std::string toString() const = 0;
    virtual ~CharSequence() = default;
};

// Collector class
template<typename T, typename A = void, typename R = void>
class Collector {
public:
    virtual ~Collector() = default;
};

// Collectors class
class Collectors {
public:
    // joining with delimiter, prefix, suffix
    static Collector<std::string> joining(CharSequence* delimiter, CharSequence* prefix, CharSequence* suffix) {
        return Collector<std::string>();
    }

    // joining with no arguments
    static Collector<std::string> joining() {
        return Collector<std::string>();
    }

    // joining with delimiter
    static Collector<std::string> joining(CharSequence* delimiter) {
        return Collector<std::string>();
    }

    // toList
    static Collector<std::vector<void*>> toList() {
        return Collector<std::vector<void*>>();
    }

    // toMap with keyMapper, valueMapper, mergeFunction
    template<typename K, typename V>
    static Collector<std::map<K, V>> toMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper, BinaryOperator<V>* mergeFunction) {
        return Collector<std::map<K, V>>();
    }

    // toMap with keyMapper, valueMapper
    template<typename K, typename V>
    static Collector<std::map<K, V>> toMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper) {
        return Collector<std::map<K, V>>();
    }

    // toMap with keyMapper, valueMapper, mergeFunction, mapSupplier
    template<typename K, typename V, typename M>
    static Collector<M> toMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper, BinaryOperator<V>* mergeFunction, Supplier<M>* mapSupplier) {
        return Collector<M>();
    }

    // toSet
    static Collector<std::set<void*>> toSet() {
        return Collector<std::set<void*>>();
    }

    // maxBy
    template<typename T>
    static Collector<std::optional<T>> maxBy(Comparator<T>* comparator) {
        return Collector<std::optional<T>>();
    }

    // minBy
    template<typename T>
    static Collector<std::optional<T>> minBy(Comparator<T>* comparator) {
        return Collector<std::optional<T>>();
    }

    // mapping
    template<typename T, typename U, typename A, typename R>
    static Collector<R> mapping(Function<U, T>* mapper, Collector<A, T, R>* downstream) {
        return Collector<R>();
    }

    // groupingBy with classifier
    template<typename T, typename K>
    static Collector<std::map<K, std::vector<T>>> groupingBy(Function<K, T>* classifier) {
        return Collector<std::map<K, std::vector<T>>>();
    }

    // groupingBy with classifier, mapFactory, downstream
    template<typename T, typename K, typename A, typename D, typename M>
    static Collector<M> groupingBy(Function<K, T>* classifier, Supplier<M>* mapFactory, Collector<A, T, D>* downstream) {
        return Collector<M>();
    }

    // groupingBy with classifier, downstream
    template<typename T, typename K, typename A, typename D>
    static Collector<std::map<K, D>> groupingBy(Function<K, T>* classifier, Collector<A, T, D>* downstream) {
        return Collector<std::map<K, D>>();
    }

    // toCollection
    template<typename T, typename C>
    static Collector<C> toCollection(Supplier<C>* collectionFactory) {
        return Collector<C>();
    }

    // summingLong
    template<typename T>
    static Collector<long> summingLong(ToLongFunction<T>* mapper) {
        return Collector<long>();
    }

    // reducing with BinaryOperator
    template<typename T>
    static Collector<std::optional<T>> reducing(BinaryOperator<T>* op) {
        return Collector<std::optional<T>>();
    }

    // reducing with identity, mapper, op
    template<typename T, typename U>
    static Collector<U> reducing(U identity, Function<U, T>* mapper, BinaryOperator<U>* op) {
        return Collector<U>();
    }

    // reducing with identity, op
    template<typename T>
    static Collector<T> reducing(T identity, BinaryOperator<T>* op) {
        return Collector<T>();
    }

    // groupingByConcurrent with classifier, downstream
    template<typename T, typename K, typename A, typename D>
    static Collector<std::unordered_map<K, D>> groupingByConcurrent(Function<K, T>* classifier, Collector<A, T, D>* downstream) {
        return Collector<std::unordered_map<K, D>>();
    }

    // groupingByConcurrent with classifier, mapFactory, downstream
    template<typename T, typename K, typename A, typename D, typename M>
    static Collector<M> groupingByConcurrent(Function<K, T>* classifier, Supplier<M>* mapFactory, Collector<A, T, D>* downstream) {
        return Collector<M>();
    }

    // groupingByConcurrent with classifier
    template<typename T, typename K>
    static Collector<std::unordered_map<K, std::vector<T>>> groupingByConcurrent(Function<K, T>* classifier) {
        return Collector<std::unordered_map<K, std::vector<T>>>();
    }

    // partitioningBy with predicate
    template<typename T>
    static Collector<std::map<bool, std::vector<T>>> partitioningBy(Predicate<T>* predicate) {
        return Collector<std::map<bool, std::vector<T>>>();
    }

    // partitioningBy with predicate, downstream
    template<typename T, typename A, typename D>
    static Collector<std::map<bool, D>> partitioningBy(Predicate<T>* predicate, Collector<A, T, D>* downstream) {
        return Collector<std::map<bool, D>>();
    }

    // collectingAndThen
    template<typename T, typename A, typename R, typename RR>
    static Collector<RR> collectingAndThen(Collector<A, T, R>* downstream, Function<RR, R>* finisher) {
        return Collector<RR>();
    }

    // toConcurrentMap with keyMapper, valueMapper
    template<typename K, typename V>
    static Collector<std::unordered_map<K, V>> toConcurrentMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper) {
        return Collector<std::unordered_map<K, V>>();
    }

    // toConcurrentMap with keyMapper, valueMapper, mergeFunction, mapSupplier
    template<typename K, typename V, typename M>
    static Collector<M> toConcurrentMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper, BinaryOperator<V>* mergeFunction, Supplier<M>* mapSupplier) {
        return Collector<M>();
    }

    // toConcurrentMap with keyMapper, valueMapper, mergeFunction
    template<typename K, typename V>
    static Collector<std::unordered_map<K, V>> toConcurrentMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper, BinaryOperator<V>* mergeFunction) {
        return Collector<std::unordered_map<K, V>>();
    }

    // toUnmodifiableList
    static Collector<std::vector<void*>> toUnmodifiableList() {
        return Collector<std::vector<void*>>();
    }

    // toUnmodifiableSet
    static Collector<std::set<void*>> toUnmodifiableSet() {
        return Collector<std::set<void*>>();
    }

    // flatMapping
    template<typename T, typename U, typename A, typename R>
    static Collector<R> flatMapping(Function<std::vector<U>, T>* mapper, Collector<A, U, R>* downstream) {
        return Collector<R>();
    }

    // filtering
    template<typename T, typename A, typename R>
    static Collector<R> filtering(Predicate<T>* predicate, Collector<A, T, R>* downstream) {
        return Collector<R>();
    }

    // counting
    static Collector<long> counting() {
        return Collector<long>();
    }

    // summingInt
    template<typename T>
    static Collector<int> summingInt(ToIntFunction<T>* mapper) {
        return Collector<int>();
    }

    // summingDouble
    template<typename T>
    static Collector<double> summingDouble(ToDoubleFunction<T>* mapper) {
        return Collector<double>();
    }

    // averagingInt
    template<typename T>
    static Collector<double> averagingInt(ToIntFunction<T>* mapper) {
        return Collector<double>();
    }

    // averagingLong
    template<typename T>
    static Collector<double> averagingLong(ToLongFunction<T>* mapper) {
        return Collector<double>();
    }

    // averagingDouble
    template<typename T>
    static Collector<double> averagingDouble(ToDoubleFunction<T>* mapper) {
        return Collector<double>();
    }

    // toUnmodifiableMap with keyMapper, valueMapper
    template<typename K, typename V>
    static Collector<std::map<K, V>> toUnmodifiableMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper) {
        return Collector<std::map<K, V>>();
    }

    // toUnmodifiableMap with keyMapper, valueMapper, mergeFunction
    template<typename K, typename V>
    static Collector<std::map<K, V>> toUnmodifiableMap(Function<K, void*>* keyMapper, Function<V, void*>* valueMapper, BinaryOperator<V>* mergeFunction) {
        return Collector<std::map<K, V>>();
    }

    // summarizingInt
    template<typename T>
    static Collector<void> summarizingInt(ToIntFunction<T>* mapper) {
        return Collector<void>();
    }

    // summarizingLong
    template<typename T>
    static Collector<void> summarizingLong(ToLongFunction<T>* mapper) {
        return Collector<void>();
    }

    // summarizingDouble
    template<typename T>
    static Collector<void> summarizingDouble(ToDoubleFunction<T>* mapper) {
        return Collector<void>();
    }

    // teeing
    template<typename T, typename A1, typename A2, typename R1, typename R2, typename R>
    static Collector<R> teeing(Collector<A1, T, R1>* downstream1, Collector<A2, T, R2>* downstream2, BiFunction<R1, R2, R>* merger) {
        return Collector<R>();
    }
};

// Test functions

void joining_test_2424(CharSequence* p0, CharSequence* p1, CharSequence* p2) {
    Collectors::joining(p0, p1, p2);
}
