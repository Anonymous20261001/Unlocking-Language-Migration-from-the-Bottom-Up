#include <memory>
#include <string>
#include <vector>

class Locale {
public:
    Locale() = default;
    explicit Locale(const std::string& language) : language_(language) {}
    Locale(const std::string& language, const std::string& country)
        : language_(language), country_(country) {}

    std::string getLanguage() const { return language_; }
    std::string getCountry() const { return country_; }

    static Locale getDefault() {
        return Locale("en", "US");
    }

private:
    std::string language_;
    std::string country_;
};

class DateFormat {
public:
    static constexpr int FULL = 0;
    static constexpr int LONG = 1;
    static constexpr int MEDIUM = 2;
    static constexpr int SHORT = 3;
    static constexpr int DEFAULT = MEDIUM;

    virtual ~DateFormat() = default;

    static std::shared_ptr<DateFormat> getInstance() {
        return getDateTimeInstance(SHORT, SHORT, Locale::getDefault());
    }

    static std::shared_ptr<DateFormat> getDateTimeInstance(
        int dateStyle, int timeStyle, const Locale& locale) {
        return std::shared_ptr<DateFormat>(
            new DateFormat(dateStyle, timeStyle, locale));
    }

    static std::shared_ptr<DateFormat> getDateTimeInstance(
        int dateStyle, int timeStyle) {
        return getDateTimeInstance(dateStyle, timeStyle, Locale::getDefault());
    }

    static std::shared_ptr<DateFormat> getDateTimeInstance() {
        return getDateTimeInstance(DEFAULT, DEFAULT, Locale::getDefault());
    }

    static std::vector<Locale> getAvailableLocales() {
        return {
            Locale("en", "US"),
            Locale("en", "GB"),
            Locale("fr", "FR"),
            Locale("de", "DE"),
            Locale("ja", "JP")
        };
    }

    static std::shared_ptr<DateFormat> getDateInstance(
        int style, const Locale& locale) {
        return std::shared_ptr<DateFormat>(
            new DateFormat(style, -1, locale));
    }

    static std::shared_ptr<DateFormat> getDateInstance(int style) {
        return getDateInstance(style, Locale::getDefault());
    }

    static std::shared_ptr<DateFormat> getDateInstance() {
        return getDateInstance(DEFAULT, Locale::getDefault());
    }

    static std::shared_ptr<DateFormat> getTimeInstance(
        int style, const Locale& locale) {
        return std::shared_ptr<DateFormat>(
            new DateFormat(-1, style, locale));
    }

    static std::shared_ptr<DateFormat> getTimeInstance(int style) {
        return getTimeInstance(style, Locale::getDefault());
    }

    static std::shared_ptr<DateFormat> getTimeInstance() {
        return getTimeInstance(DEFAULT, Locale::getDefault());
    }

    int getDateStyle() const { return dateStyle_; }
    int getTimeStyle() const { return timeStyle_; }
    const Locale& getLocale() const { return locale_; }

protected:
    DateFormat(int dateStyle, int timeStyle, const Locale& locale)
        : dateStyle_(dateStyle), timeStyle_(timeStyle), locale_(locale) {}

private:
    int dateStyle_;
    int timeStyle_;
    Locale locale_;
};

void getDateTimeInstance_test_3318() {
    DateFormat::getDateTimeInstance(
        DateFormat::DEFAULT, DateFormat::DEFAULT, Locale::getDefault());
}
