#include <string>

class Module {
public:
    Module() = default;
};

class String {
public:
    std::string value;

    String() = default;
    String(const char* s) : value(s) {}
    String(const std::string& s) : value(s) {}
};

class Class {
public:
    Class() = default;

    static Class forName(Module module, String name) {
        return Class();
    }

    static Class forPrimitiveName(String name) {
        return Class();
    }
};

void forName_test_2310(Module p0, String p1) {
    Class::forName(p0, p1);
}
