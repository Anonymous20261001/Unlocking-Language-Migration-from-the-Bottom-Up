#include <vector>

class Object {
public:
    virtual ~Object() = default;
};

class Comparator {
public:
    virtual ~Comparator() = default;
    virtual int compare(Object* a, Object* b) = 0;
};

class Collection {
public:
    virtual ~Collection() = default;
};

class SequencedCollection : public Collection {
};

class List : public SequencedCollection {
};

class Set : public Collection {
};

class SequencedSet : public Set {
};

class SortedSet : public Set {
};

class NavigableSet : public SortedSet {
};

class Queue : public Collection {
};

class Deque : public Queue {
};

class Map {
public:
    virtual ~Map() = default;
};

class SequencedMap : public Map {
};

class SortedMap : public Map {
};

class NavigableMap : public SortedMap {
};

class Enumeration {
public:
    virtual ~Enumeration() = default;
    virtual bool hasMoreElements() = 0;
    virtual Object* nextElement() = 0;
};

class Random {
public:
    virtual ~Random() = default;
};

class RandomGenerator {
public:
    virtual ~RandomGenerator() = default;
};

class Class {
public:
    virtual ~Class() = default;
};

class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() = 0;
    virtual Object* next() = 0;
};

class ListIterator : public Iterator {
public:
    virtual bool hasPrevious() = 0;
    virtual Object* previous() = 0;
};

class Collections {
public:
    static Object* min(Collection* c, Comparator* cmp) { (void)c; (void)cmp; return nullptr; }
    static Object* min(Collection* c) { (void)c; return nullptr; }
    static Object* max(Collection* c) { (void)c; return nullptr; }
    static Object* max(Collection* c, Comparator* cmp) { (void)c; (void)cmp; return nullptr; }
    static void reverse(List* l) { (void)l; }
    static void sort(List* l) { (void)l; }
    static void sort(List* l, Comparator* cmp) { (void)l; (void)cmp; }
    static void copy(List* dest, List* src) { (void)dest; (void)src; }
    static bool replaceAll(List* l, Object* oldVal, Object* newVal) { (void)l; (void)oldVal; (void)newVal; return false; }
    static void fill(List* l, Object* o) { (void)l; (void)o; }
    static List* list(Enumeration* e) { (void)e; return nullptr; }
    static bool addAll(Collection* c, const std::vector<Object*>& elements) { (void)c; (void)elements; return false; }
    static Enumeration* emptyEnumeration() { return nullptr; }
    static Set* newSetFromMap(Map* m) { (void)m; return nullptr; }
    static List* emptyList() { return nullptr; }
    static Set* unmodifiableSet(Set* s) { return s; }
    static Enumeration* enumeration(Collection* c) { (void)c; return nullptr; }
    static Set* synchronizedSet(Set* s) { return s; }
    static Collection* synchronizedCollection(Collection* c) { return c; }
    static Iterator* emptyIterator() { return nullptr; }
    static List* nCopies(int n, Object* o) { (void)n; (void)o; return nullptr; }
    static Comparator* reverseOrder(Comparator* cmp) { return cmp; }
    static Comparator* reverseOrder() { return nullptr; }
    static Map* unmodifiableMap(Map* m) { return m; }
    static SortedMap* unmodifiableSortedMap(SortedMap* m) { return m; }
    static void swap(List* l, int i, int j) { (void)l; (void)i; (void)j; }
    static int binarySearch(List* l, Object* key, Comparator* cmp) { (void)l; (void)key; (void)cmp; return 0; }
    static int binarySearch(List* l, Object* key) { (void)l; (void)key; return 0; }
    static void shuffle(List* l, Random* rnd) { (void)l; (void)rnd; }
    static void shuffle(List* l) { (void)l; }
    static void shuffle(List* l, RandomGenerator* rnd) { (void)l; (void)rnd; }
    static void rotate(List* l, int distance) { (void)l; (void)distance; }
    static int indexOfSubList(List* source, List* target) { (void)source; (void)target; return 0; }
    static int lastIndexOfSubList(List* source, List* target) { (void)source; (void)target; return 0; }
    static Collection* unmodifiableCollection(Collection* c) { return c; }
    static SequencedCollection* unmodifiableSequencedCollection(SequencedCollection* c) { return c; }
    static SequencedSet* unmodifiableSequencedSet(SequencedSet* s) { return s; }
    static SortedSet* unmodifiableSortedSet(SortedSet* s) { return s; }
    static NavigableSet* unmodifiableNavigableSet(NavigableSet* s) { return s; }
    static List* unmodifiableList(List* l) { return l; }
    static SequencedMap* unmodifiableSequencedMap(SequencedMap* m) { return m; }
    static NavigableMap* unmodifiableNavigableMap(NavigableMap* m) { return m; }
    static SortedSet* synchronizedSortedSet(SortedSet* s) { return s; }
    static NavigableSet* synchronizedNavigableSet(NavigableSet* s) { return s; }
    static List* synchronizedList(List* l) { return l; }
    static Map* synchronizedMap(Map* m) { return m; }
    static SortedMap* synchronizedSortedMap(SortedMap* m) { return m; }
    static NavigableMap* synchronizedNavigableMap(NavigableMap* m) { return m; }
    static Collection* checkedCollection(Collection* c, Class* type) { (void)type; return c; }
    static Queue* checkedQueue(Queue* q, Class* type) { (void)type; return q; }
    static Set* checkedSet(Set* s, Class* type) { (void)type; return s; }
    static SortedSet* checkedSortedSet(SortedSet* s, Class* type) { (void)type; return s; }
    static NavigableSet* checkedNavigableSet(NavigableSet* s, Class* type) { (void)type; return s; }
    static List* checkedList(List* l, Class* type) { (void)type; return l; }
    static Map* checkedMap(Map* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static SortedMap* checkedSortedMap(SortedMap* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static NavigableMap* checkedNavigableMap(NavigableMap* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static ListIterator* emptyListIterator() { return nullptr; }
    static Set* emptySet() { return nullptr; }
    static SortedSet* emptySortedSet() { return nullptr; }
    static NavigableSet* emptyNavigableSet() { return nullptr; }
    static Map* emptyMap() { return nullptr; }
    static SortedMap* emptySortedMap() { return nullptr; }
    static NavigableMap* emptyNavigableMap() { return nullptr; }
    static Set* singleton(Object* o) { (void)o; return nullptr; }
    static List* singletonList(Object* o) { (void)o; return nullptr; }
    static Map* singletonMap(Object* k, Object* v) { (void)k; (void)v; return nullptr; }
    static int frequency(Collection* c, Object* o) { (void)c; (void)o; return 0; }
    static bool disjoint(Collection* c1, Collection* c2) { (void)c1; (void)c2; return false; }
    static SequencedSet* newSequencedSetFromMap(SequencedMap* m) { (void)m; return nullptr; }
    static Deque* asLifoQueue(Deque* d) { return d; }
};

void synchronizedNavigableMap_test_2400(NavigableMap* p0) { Collections::synchronizedNavigableMap(p0); }
