#include <any>
#include <map>
#include <stdexcept>
#include <string>

namespace javax {
namespace management {
namespace openmbean {

class CompositeData {
public:
    virtual ~CompositeData() = default;
    virtual bool containsKey(const std::string& key) const = 0;
    virtual std::any get(const std::string& key) const = 0;
};

} // namespace openmbean
} // namespace management
} // namespace javax

namespace jdk {
namespace management {
namespace jfr {

class ConfigurationInfo {
public:
    static ConfigurationInfo from(const javax::management::openmbean::CompositeData& cd) {
        if (!cd.containsKey("name") ||
            !cd.containsKey("label") ||
            !cd.containsKey("description") ||
            !cd.containsKey("provider") ||
            !cd.containsKey("settings") ||
            !cd.containsKey("contents")) {
            throw std::invalid_argument("CompositeData does not contain all required ConfigurationInfo items");
        }

        ConfigurationInfo info;
        info.name_ = std::any_cast<std::string>(cd.get("name"));
        info.label_ = std::any_cast<std::string>(cd.get("label"));
        info.description_ = std::any_cast<std::string>(cd.get("description"));
        info.provider_ = std::any_cast<std::string>(cd.get("provider"));
        info.settings_ = std::any_cast<std::map<std::string, std::string>>(cd.get("settings"));
        info.contents_ = std::any_cast<std::string>(cd.get("contents"));
        return info;
    }

    ConfigurationInfo() = default;

private:
    std::string name_;
    std::string label_;
    std::string description_;
    std::string provider_;
    std::map<std::string, std::string> settings_;
    std::string contents_;
};

} // namespace jfr
} // namespace management
} // namespace jdk

void from_test_2909(const javax::management::openmbean::CompositeData& p0) {
    jdk::management::jfr::ConfigurationInfo::from(p0);
}
