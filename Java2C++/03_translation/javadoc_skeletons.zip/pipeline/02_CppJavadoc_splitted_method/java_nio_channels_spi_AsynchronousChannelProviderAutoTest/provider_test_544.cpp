#include <memory>

namespace java {
namespace nio {
namespace channels {
namespace spi {

class AsynchronousChannelProvider {
public:
    static AsynchronousChannelProvider& provider() {
        static AsynchronousChannelProvider instance;
        return instance;
    }

    virtual ~AsynchronousChannelProvider() = default;

protected:
    AsynchronousChannelProvider() = default;
};

} // namespace spi
} // namespace channels
} // namespace nio
} // namespace java

void provider_test_544() {
    java::nio::channels::spi::AsynchronousChannelProvider::provider();
}
