#include <string>
#include <vector>

class URL {
public:
    URL() = default;
    URL(const URL&) = default;
    URL& operator=(const URL&) = default;
};

class AppletStub {
public:
    AppletStub() = default;
    AppletStub(const AppletStub&) = default;
    AppletStub& operator=(const AppletStub&) = default;
};

class AppletContext {
public:
    AppletContext() = default;
};

class AudioClip {
public:
    AudioClip() = default;
};

class Image {
public:
    Image() = default;
};

class Locale {
public:
    Locale() = default;
};

class AccessibleContext {
public:
    AccessibleContext() = default;
};

class Dimension {
public:
    int width;
    int height;

    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class Applet {
public:
    Applet() = default;

    URL getDocumentBase() {
        return URL();
    }

    URL getCodeBase() {
        return URL();
    }

    AppletContext getAppletContext() {
        return AppletContext();
    }

    void showStatus(const std::string& p0) {
        (void)p0;
    }

    AudioClip getAudioClip(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
        return AudioClip();
    }

    AudioClip getAudioClip(const URL& p0) {
        (void)p0;
        return AudioClip();
    }

    void play(const URL& p0) {
        (void)p0;
    }

    void play(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
    }

    void setStub(AppletStub p0) {
        (void)p0;
    }

    static AudioClip newAudioClip(const URL& p0) {
        (void)p0;
        return AudioClip();
    }

    std::string getAppletInfo() {
        return std::string();
    }

    std::vector<std::vector<std::string>> getParameterInfo() {
        return std::vector<std::vector<std::string>>();
    }

    bool isValidateRoot() {
        return false;
    }

    AccessibleContext getAccessibleContext() {
        return AccessibleContext();
    }

    Image getImage(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
        return Image();
    }

    Image getImage(const URL& p0) {
        (void)p0;
        return Image();
    }

    void init() {
    }

    void start() {
    }

    void stop() {
    }

    void destroy() {
    }

    bool isActive() {
        return false;
    }

    void resize(int p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void resize(Dimension p0) {
        (void)p0;
    }

    Locale getLocale() {
        return Locale();
    }

    std::string getParameter(const std::string& p0) {
        (void)p0;
        return std::string();
    }
};

void newAudioClip_test_172(URL p0) {
    Applet::newAudioClip(p0);
}
