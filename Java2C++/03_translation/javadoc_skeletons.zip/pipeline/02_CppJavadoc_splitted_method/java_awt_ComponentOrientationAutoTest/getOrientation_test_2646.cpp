#include <string>
#include <map>
#include <stdexcept>

class Locale {
public:
    Locale(const std::string& language, const std::string& country = "", const std::string& variant = "")
        : language_(language), country_(country), variant_(variant) {}

    const std::string& getLanguage() const { return language_; }
    const std::string& getCountry() const { return country_; }
    const std::string& getVariant() const { return variant_; }

private:
    std::string language_;
    std::string country_;
    std::string variant_;
};

class ResourceBundle {
public:
    ResourceBundle() = default;
    ResourceBundle(const std::map<std::string, std::string>& resources) : resources_(resources) {}

    bool containsKey(const std::string& key) const {
        return resources_.find(key) != resources_.end();
    }

    std::string getString(const std::string& key) const {
        auto it = resources_.find(key);
        if (it == resources_.end()) {
            throw std::runtime_error("Missing resource: " + key);
        }
        return it->second;
    }

private:
    std::map<std::string, std::string> resources_;
};

class ComponentOrientation {
public:
    enum Orientation {
        LEFT_TO_RIGHT,
        RIGHT_TO_LEFT,
        UNKNOWN
    };

    static ComponentOrientation getOrientation(const Locale& locale) {
        const std::string& lang = locale.getLanguage();
        if (lang == "ar" || lang == "fa" || lang == "he" || lang == "iw" || lang == "ur") {
            return ComponentOrientation(RIGHT_TO_LEFT);
        }
        return ComponentOrientation(LEFT_TO_RIGHT);
    }

    static ComponentOrientation getOrientation(const ResourceBundle& bundle) {
        if (bundle.containsKey("Orientation")) {
            const std::string orientation = bundle.getString("Orientation");
            if (orientation == "leftToRight") {
                return ComponentOrientation(LEFT_TO_RIGHT);
            }
            if (orientation == "rightToLeft") {
                return ComponentOrientation(RIGHT_TO_LEFT);
            }
        }
        return ComponentOrientation(UNKNOWN);
    }

    Orientation value() const { return value_; }

    bool operator==(const ComponentOrientation& other) const { return value_ == other.value_; }
    bool operator!=(const ComponentOrientation& other) const { return value_ != other.value_; }

private:
    explicit ComponentOrientation(Orientation value) : value_(value) {}
    Orientation value_;
};

void getOrientation_test_2646(const ResourceBundle& p0) {
    ComponentOrientation::getOrientation(p0);
}
