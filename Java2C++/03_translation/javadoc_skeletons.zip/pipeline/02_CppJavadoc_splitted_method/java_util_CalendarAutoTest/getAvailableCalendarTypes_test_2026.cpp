#include <string>
#include <vector>
#include <set>

class Locale {
public:
    Locale() = default;
    explicit Locale(const std::string& language) : language_(language) {}
    Locale(const std::string& language, const std::string& country)
        : language_(language), country_(country) {}

    std::string getLanguage() const { return language_; }
    std::string getCountry() const { return country_; }

    static Locale getDefault() { return Locale("en", "US"); }

private:
    std::string language_ = "en";
    std::string country_ = "US";
};

class TimeZone {
public:
    TimeZone() = default;
    explicit TimeZone(const std::string& id) : id_(id) {}

    std::string getID() const { return id_; }

    static TimeZone getDefault() { return TimeZone("UTC"); }
    static TimeZone getTimeZone(const std::string& id) { return TimeZone(id); }

private:
    std::string id_ = "UTC";
};

class Calendar {
public:
    static Calendar getInstance() { return Calendar(); }
    static Calendar getInstance(const Locale&) { return Calendar(); }
    static Calendar getInstance(const TimeZone&) { return Calendar(); }
    static Calendar getInstance(const TimeZone&, const Locale&) { return Calendar(); }

    static std::vector<Locale> getAvailableLocales() {
        return { Locale("en", "US"), Locale("fr", "FR") };
    }

    static std::set<std::string> getAvailableCalendarTypes() {
        return { "gregory", "buddhist", "japanese" };
    }

private:
    Calendar() = default;
};

void getAvailableCalendarTypes_test_2026() {
    Calendar::getAvailableCalendarTypes();
}
