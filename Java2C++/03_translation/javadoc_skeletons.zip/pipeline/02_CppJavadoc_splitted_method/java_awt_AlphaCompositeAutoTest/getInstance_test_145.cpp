#include <stdexcept>

class AlphaComposite {
public:
    static constexpr int CLEAR = 1;
    static constexpr int SRC = 2;
    static constexpr int DST = 3;
    static constexpr int SRC_OVER = 4;
    static constexpr int DST_OVER = 5;
    static constexpr int SRC_IN = 6;
    static constexpr int DST_IN = 7;
    static constexpr int SRC_OUT = 8;
    static constexpr int DST_OUT = 9;
    static constexpr int SRC_ATOP = 10;
    static constexpr int DST_ATOP = 11;
    static constexpr int XOR = 12;

    static AlphaComposite getInstance(int rule) {
        return getInstance(rule, 1.0f);
    }

    static AlphaComposite getInstance(int rule, float alpha) {
        if (rule < 1 || rule > 12) {
            throw std::invalid_argument("Illegal rule");
        }
        if (alpha < 0.0f || alpha > 1.0f) {
            throw std::invalid_argument("Alpha must be in range [0.0, 1.0]");
        }
        return AlphaComposite(rule, alpha);
    }

    int getRule() const {
        return rule_;
    }

    float getAlpha() const {
        return alpha_;
    }

private:
    AlphaComposite(int rule, float alpha) : rule_(rule), alpha_(alpha) {}

    int rule_;
    float alpha_;
};

void getInstance_test_145(int p0, float p1) {
    AlphaComposite::getInstance(p0, p1);
}
