#include <string>
#include <vector>
#include <cstdint>
#include <stdexcept>
#include <cmath>
#include <algorithm>

namespace java {
namespace awt {

class ColorSpace {
public:
    enum Type {
        TYPE_RGB = 1,
        TYPE_GRAY = 2,
        TYPE_CMYK = 3,
        TYPE_XYZ = 4,
        TYPE_Lab = 5,
        TYPE_Luv = 6,
        TYPE_Yxy = 7,
        TYPE_HLS = 8,
        TYPE_HSV = 9,
        TYPE_YCbCr = 10,
        TYPE_YCCK = 11,
        TYPE_ACES = 12,
        TYPE_ACESCG = 13,
        TYPE_RGB_Linear = 14,
        TYPE_CMY = 15,
        TYPE_2CLR = 16,
        TYPE_3CLR = 17,
        TYPE_4CLR = 18,
        TYPE_5CLR = 19,
        TYPE_6CLR = 20,
        TYPE_7CLR = 21,
        TYPE_8CLR = 22,
        TYPE_9CLR = 23,
        TYPE_ACLR = 24,
        TYPE_BCLR = 25,
        TYPE_CCLR = 26,
        TYPE_DCLR = 27,
        TYPE_ECLR = 28,
        TYPE_FCLR = 29,
        CS_sRGB = 1000,
        CS_LINEAR_RGB = 1001,
        CS_GRAY = 1002,
        CS_CIEXYZ = 1003,
        CS_PYCC = 1004
    };

    ColorSpace(int type, int numComponents) : m_type(type), m_numComponents(numComponents) {}
    virtual ~ColorSpace() = default;

    int getType() const { return m_type; }
    int getNumComponents() const { return m_numComponents; }

    virtual std::vector<float> toRGB(const std::vector<float>& colorvalue) const {
        return colorvalue;
    }

    virtual std::vector<float> fromRGB(const std::vector<float>& rgbvalue) const {
        return rgbvalue;
    }

    virtual std::vector<float> toCIEXYZ(const std::vector<float>& colorvalue) const {
        return colorvalue;
    }

    virtual std::vector<float> fromCIEXYZ(const std::vector<float>& colorvalue) const {
        return colorvalue;
    }

    static ColorSpace* getInstance(int colorspace) {
        static ColorSpace sRGB(TYPE_RGB, 3);
        static ColorSpace linearRGB(TYPE_RGB, 3);
        static ColorSpace gray(TYPE_GRAY, 1);
        static ColorSpace ciexyz(TYPE_XYZ, 3);
        static ColorSpace pycc(TYPE_YCbCr, 3);
        switch (colorspace) {
            case CS_sRGB: return &sRGB;
            case CS_LINEAR_RGB: return &linearRGB;
            case CS_GRAY: return &gray;
            case CS_CIEXYZ: return &ciexyz;
            case CS_PYCC: return &pycc;
            default: return &sRGB;
        }
    }

private:
    int m_type;
    int m_numComponents;
};

class ColorModel {
public:
    ColorModel() = default;
    virtual ~ColorModel() = default;
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
    Rectangle(int x, int y, int w, int h) : x(x), y(y), width(w), height(h) {}
};

class Rectangle2D {
public:
    virtual ~Rectangle2D() = default;
    virtual double getX() const = 0;
    virtual double getY() const = 0;
    virtual double getWidth() const = 0;
    virtual double getHeight() const = 0;
};

class Rectangle2DDouble : public Rectangle2D {
public:
    double x, y, width, height;
    Rectangle2DDouble() : x(0), y(0), width(0), height(0) {}
    Rectangle2DDouble(double x, double y, double w, double h) : x(x), y(y), width(w), height(h) {}
    double getX() const override { return x; }
    double getY() const override { return y; }
    double getWidth() const override { return width; }
    double getHeight() const override { return height; }
};

class AffineTransform {
public:
    double m00, m01, m02, m10, m11, m12;
    AffineTransform() : m00(1), m01(0), m02(0), m10(0), m11(1), m12(0) {}
    AffineTransform(double m00, double m01, double m02, double m10, double m11, double m12)
        : m00(m00), m01(m01), m02(m02), m10(m10), m11(m11), m12(m12) {}
};

class RenderingHints {
public:
    RenderingHints() = default;
};

class PaintContext {
public:
    virtual ~PaintContext() = default;
};

class Color {
public:
    static const Color WHITE;
    static const Color LIGHT_GRAY;
    static const Color GRAY;
    static const Color DARK_GRAY;
    static const Color BLACK;
    static const Color RED;
    static const Color PINK;
    static const Color ORANGE;
    static const Color YELLOW;
    static const Color GREEN;
    static const Color MAGENTA;
    static const Color CYAN;
    static const Color BLUE;

    static const int OPAQUE = 1;
    static const int BITMASK = 2;
    static const int TRANSLUCENT = 3;

    Color(int rgb) {
        m_value = rgb & 0xFFFFFFFF;
        m_hasAlpha = false;
    }

    Color(int r, int g, int b) {
        m_value = 0xFF000000 | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
        m_hasAlpha = false;
    }

    Color(int r, int g, int b, int a) {
        m_value = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
        m_hasAlpha = true;
    }

    Color(float r, float g, float b) {
        m_value = 0xFF000000 | ((int)(r * 255 + 0.5f) << 16) | ((int)(g * 255 + 0.5f) << 8) | (int)(b * 255 + 0.5f);
        m_hasAlpha = false;
    }

    Color(float r, float g, float b, float a) {
        m_value = ((int)(a * 255 + 0.5f) << 24) | ((int)(r * 255 + 0.5f) << 16) | ((int)(g * 255 + 0.5f) << 8) | (int)(b * 255 + 0.5f);
        m_hasAlpha = true;
    }

    Color(ColorSpace cspace, std::vector<float> components, float alpha) {
        m_value = 0xFF000000;
        m_hasAlpha = true;
        if (components.size() >= 3) {
            m_value = ((int)(alpha * 255 + 0.5f) << 24) | ((int)(components[0] * 255 + 0.5f) << 16) | ((int)(components[1] * 255 + 0.5f) << 8) | (int)(components[2] * 255 + 0.5f);
        }
    }

    int getRed() const {
        return (m_value >> 16) & 0xFF;
    }

    int getGreen() const {
        return (m_value >> 8) & 0xFF;
    }

    int getBlue() const {
        return m_value & 0xFF;
    }

    int getAlpha() const {
        return (m_value >> 24) & 0xFF;
    }

    int getRGB() const {
        return (int)m_value;
    }

    Color brighter() const {
        int r = getRed();
        int g = getGreen();
        int b = getBlue();
        int a = getAlpha();
        int i = (int)(1.0 / 1.2 * 255);
        if (r == 0 && g == 0 && b == 0) {
            return Color(i, i, i, a);
        }
        if (r > 0 && r < i) r = i;
        if (g > 0 && g < i) g = i;
        if (b > 0 && b < i) b = i;
        return Color(std::min(255, (int)(r / 1.2)), std::min(255, (int)(g / 1.2)), std::min(255, (int)(b / 1.2)), a);
    }

    Color darker() const {
        int r = getRed();
        int g = getGreen();
        int b = getBlue();
        int a = getAlpha();
        return Color((int)(r * 0.7), (int)(g * 0.7), (int)(b * 0.7), a);
    }

    std::vector<float> getComponents(float* compArray) const {
        std::vector<float> comps(4);
        comps[0] = getRed() / 255.0f;
        comps[1] = getGreen() / 255.0f;
        comps[2] = getBlue() / 255.0f;
        comps[3] = getAlpha() / 255.0f;
        if (compArray != nullptr) {
            for (int i = 0; i < 4; i++) compArray[i] = comps[i];
        }
        return comps;
    }

    std::vector<float> getComponents(ColorSpace* cspace, float* compArray) const {
        std::vector<float> comps = getComponents(compArray);
        if (cspace != nullptr) {
            std::vector<float> rgb(3);
            rgb[0] = comps[0];
            rgb[1] = comps[1];
            rgb[2] = comps[2];
            std::vector<float> converted = cspace->fromRGB(rgb);
            comps[0] = converted[0];
            comps[1] = converted[1];
            comps[2] = converted[2];
            if (compArray != nullptr) {
                for (int i = 0; i < 4; i++) compArray[i] = comps[i];
            }
        }
        return comps;
    }

    std::vector<float> getColorComponents(float* compArray) const {
        std::vector<float> comps(3);
        comps[0] = getRed() / 255.0f;
        comps[1] = getGreen() / 255.0f;
        comps[2] = getBlue() / 255.0f;
        if (compArray != nullptr) {
            for (int i = 0; i < 3; i++) compArray[i] = comps[i];
        }
        return comps;
    }

    std::vector<float> getColorComponents(ColorSpace* cspace, float* compArray) const {
        std::vector<float> comps = getColorComponents(compArray);
        if (cspace != nullptr) {
            std::vector<float> converted = cspace->fromRGB(comps);
            comps = converted;
            if (compArray != nullptr) {
                for (size_t i = 0; i < comps.size(); i++) compArray[i] = comps[i];
            }
        }
        return comps;
    }

    std::vector<float> getRGBComponents(float* compArray) const {
        std::vector<float> comps(4);
        comps[0] = getRed() / 255.0f;
        comps[1] = getGreen() / 255.0f;
        comps[2] = getBlue() / 255.0f;
        comps[3] = getAlpha() / 255.0f;
        if (compArray != nullptr) {
            for (int i = 0; i < 4; i++) compArray[i] = comps[i];
        }
        return comps;
    }

    std::vector<float> getRGBColorComponents(float* compArray) const {
        std::vector<float> comps(3);
        comps[0] = getRed() / 255.0f;
        comps[1] = getGreen() / 255.0f;
        comps[2] = getBlue() / 255.0f;
        if (compArray != nullptr) {
            for (int i = 0; i < 3; i++) compArray[i] = comps[i];
        }
        return comps;
    }

    ColorSpace* getColorSpace() const {
        return ColorSpace::getInstance(ColorSpace::CS_sRGB);
    }

    PaintContext* createContext(ColorModel* cm, Rectangle* r, Rectangle2D* r2d, AffineTransform* xform, RenderingHints* hints) const {
        return nullptr;
    }

    int getTransparency() const {
        return getAlpha() == 255 ? OPAQUE : TRANSLUCENT;
    }

    static Color getColor(const std::string& nm) {
        return getColor(nm, 0);
    }

    static Color getColor(const std::string& nm, Color fallback) {
        try {
            return decode(nm);
        } catch (...) {
            return fallback;
        }
    }

    static Color getColor(const std::string& nm, int val) {
        try {
            return decode(nm);
        } catch (...) {
            return Color(val);
        }
    }

    static int HSBtoRGB(float hue, float saturation, float brightness) {
        int r = 0, g = 0, b = 0;
        if (saturation == 0) {
            r = g = b = (int)(brightness * 255.0f + 0.5f);
        } else {
            float h = (hue - (float)std::floor(hue)) * 6.0f;
            float f = h - (float)std::floor(h);
            float p = brightness * (1.0f - saturation);
            float q = brightness * (1.0f - saturation * f);
            float t = brightness * (1.0f - saturation * (1.0f - f));
            switch ((int)h) {
                case 0: r = (int)(brightness * 255.0f + 0.5f); g = (int)(t * 255.0f + 0.5f); b = (int)(p * 255.0f + 0.5f); break;
                case 1: r = (int)(q * 255.0f + 0.5f); g = (int)(brightness * 255.0f + 0.5f); b = (int)(p * 255.0f + 0.5f); break;
                case 2: r = (int)(p * 255.0f + 0.5f); g = (int)(brightness * 255.0f + 0.5f); b = (int)(t * 255.0f + 0.5f); break;
                case 3: r = (int)(p * 255.0f + 0.5f); g = (int)(q * 255.0f + 0.5f); b = (int)(brightness * 255.0f + 0.5f); break;
                case 4: r = (int)(t * 255.0f + 0.5f); g = (int)(p * 255.0f + 0.5f); b = (int)(brightness * 255.0f + 0.5f); break;
                case 5: r = (int)(brightness * 255.0f + 0.5f); g = (int)(p * 255.0f + 0.5f); b = (int)(q * 255.0f + 0.5f); break;
            }
        }
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static std::vector<float> RGBtoHSB(int r, int g, int b, float* hsbvals) {
        std::vector<float> hsb(3);
        float hue, saturation, brightness;
        int cmax = (r > g) ? r : g;
        if (b > cmax) cmax = b;
        int cmin = (r < g) ? r : g;
        if (b < cmin) cmin = b;

        brightness = cmax / 255.0f;
        if (cmax != 0)
            saturation = (float)(cmax - cmin) / (float)cmax;
        else
            saturation = 0;
        if (saturation == 0)
            hue = 0;
        else {
            float redc = (float)(cmax - r) / (float)(cmax - cmin);
            float greenc = (float)(cmax - g) / (float)(cmax - cmin);
            float bluec = (float)(cmax - b) / (float)(cmax - cmin);
            if (r == cmax)
                hue = bluec - greenc;
            else if (g == cmax)
                hue = 2.0f + redc - bluec;
            else
                hue = 4.0f + greenc - redc;
            hue = hue / 6.0f;
            if (hue < 0)
                hue = hue + 1.0f;
        }
        hsb[0] = hue;
        hsb[1] = saturation;
        hsb[2] = brightness;
        if (hsbvals != nullptr) {
            hsbvals[0] = hue;
            hsbvals[1] = saturation;
            hsbvals[2] = brightness;
        }
        return hsb;
    }

    static Color getHSBColor(float h, float s, float b) {
        return Color(HSBtoRGB(h, s, b));
    }

    static Color decode(const std::string& nm) {
        std::string str = nm;
        if (str.empty()) throw std::invalid_argument("Color parameter outside of expected range");
        if (str[0] == '#') {
            str = str.substr(1);
        } else if (str.rfind("0x", 0) == 0) {
            str = str.substr(2);
        } else {
            throw std::invalid_argument("Invalid color string");
        }
        int value = std::stoi(str, nullptr, 16);
        return Color(value);
    }

private:
    uint32_t m_value;
    bool m_hasAlpha;
};

const Color Color::WHITE = Color(0xFFFFFFFF);
const Color Color::LIGHT_GRAY = Color(0xFFC0C0C0);
const Color Color::GRAY = Color(0xFF808080);
const Color Color::DARK_GRAY = Color(0xFF404040);
const Color Color::BLACK = Color(0xFF000000);
const Color Color::RED = Color(0xFFFF0000);
const Color Color::PINK = Color(0xFFFFAFAF);
const Color Color::ORANGE = Color(0xFFFFC800);
const Color Color::YELLOW = Color(0xFFFFFF00);
const Color Color::GREEN = Color(0xFF00FF00);
const Color Color::MAGENTA = Color(0xFFFF00FF);
const Color Color::CYAN = Color(0xFF00FFFF);
const Color Color::BLUE = Color(0xFF0000FF);

} // namespace awt
} // namespace java

// Test functions

void decode_test_2490(const std::string& p0) {
    java::awt::Color::decode(p0);
}
