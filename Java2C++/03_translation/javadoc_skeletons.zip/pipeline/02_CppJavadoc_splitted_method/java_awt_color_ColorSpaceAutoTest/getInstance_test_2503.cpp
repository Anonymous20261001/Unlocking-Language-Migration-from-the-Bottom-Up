#include <stdexcept>

class ColorSpace {
public:
    // Predefined color space types (same values as java.awt.color.ColorSpace)
    static const int CS_sRGB = 1000;
    static const int CS_CIEXYZ = 1001;
    static const int CS_PYCC = 1002;
    static const int CS_GRAY = 1003;
    static const int CS_LINEAR_RGB = 1004;

    virtual ~ColorSpace() = default;

    static ColorSpace& getInstance(int cspace) {
        if (cspace == CS_sRGB) {
            static ColorSpace instance(CS_sRGB);
            return instance;
        } else if (cspace == CS_LINEAR_RGB) {
            static ColorSpace instance(CS_LINEAR_RGB);
            return instance;
        } else if (cspace == CS_CIEXYZ) {
            static ColorSpace instance(CS_CIEXYZ);
            return instance;
        } else if (cspace == CS_GRAY) {
            static ColorSpace instance(CS_GRAY);
            return instance;
        } else if (cspace == CS_PYCC) {
            static ColorSpace instance(CS_PYCC);
            return instance;
        }
        throw std::invalid_argument("Unknown color space");
    }

    int getType() const {
        return type;
    }

protected:
    explicit ColorSpace(int type) : type(type) {}

private:
    int type;
};

void getInstance_test_2503(int p0) {
    ColorSpace::getInstance(p0);
}
