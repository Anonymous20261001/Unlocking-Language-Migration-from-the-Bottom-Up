#include <vector>

class AccessibleObject {
public:
    AccessibleObject() : accessible(false) {}

    bool isAccessible() const {
        return accessible;
    }

    void setAccessible(bool flag) {
        accessible = flag;
    }

    static void setAccessible(std::vector<AccessibleObject*>& objects, bool flag) {
        for (AccessibleObject* obj : objects) {
            if (obj != nullptr) {
                obj->accessible = flag;
            }
        }
    }

    static void setAccessible(std::vector<AccessibleObject>& objects, bool flag) {
        for (auto& obj : objects) {
            obj.accessible = flag;
        }
    }

private:
    bool accessible;
};

void setAccessible_test_35() {
    AccessibleObject obj1;
    AccessibleObject obj2;
    std::vector<AccessibleObject*> p0 = {&obj1, &obj2};
    bool p1 = true;
    AccessibleObject::setAccessible(p0, p1);
}
