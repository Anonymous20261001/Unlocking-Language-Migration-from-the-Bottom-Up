#include <algorithm>
#include <cctype>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

class IllegalCharsetNameException : public std::invalid_argument {
public:
    explicit IllegalCharsetNameException(const std::string& name)
        : std::invalid_argument("Illegal charset name: " + name), charsetName_(name) {}

    const std::string& getCharsetName() const {
        return charsetName_;
    }

private:
    std::string charsetName_;
};

class UnsupportedCharsetException : public std::runtime_error {
public:
    explicit UnsupportedCharsetException(const std::string& name)
        : std::runtime_error("Unsupported charset: " + name), charsetName_(name) {}

    const std::string& getCharsetName() const {
        return charsetName_;
    }

private:
    std::string charsetName_;
};

class Charset {
private:
    struct Data {
        std::string canonicalName;

        explicit Data(const std::string& name) : canonicalName(name) {}
    };

    std::shared_ptr<Data> data_;

    static std::string normalize(const std::string& s) {
        std::string result = s;
        std::transform(result.begin(), result.end(), result.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return result;
    }

    struct RegistryEntry {
        std::string canonical;
        std::vector<std::string> aliases;
    };

    static const std::vector<RegistryEntry>& registry() {
        static const std::vector<RegistryEntry> reg = {
            {"US-ASCII", {"ASCII", "ANSI_X3.4-1968", "iso-ir-6", "us", "cp367"}},
            {"ISO-8859-1", {"ISO_8859-1", "ISO8859-1", "latin1", "l1", "cp819"}},
            {"UTF-8", {"UTF8", "unicode-1-1-utf-8"}},
            {"UTF-16", {"UTF_16", "utf16"}},
            {"UTF-16BE", {"UTF_16BE", "X-UTF-16BE", "ISO-10646-UCS-2"}},
            {"UTF-16LE", {"UTF_16LE", "X-UTF-16LE"}},
            {"windows-1252", {"cp1252", "Cp1252"}}
        };
        return reg;
    }

    static std::string lookupCanonical(const std::string& name) {
        if (name.empty()) {
            throw IllegalCharsetNameException(name);
        }

        for (char c : name) {
            unsigned char uc = static_cast<unsigned char>(c);
            if (!(std::isalnum(uc) || c == '.' || c == '_' || c == '-' || c == ':')) {
                throw IllegalCharsetNameException(name);
            }
        }

        if (!std::isalnum(static_cast<unsigned char>(name[0]))) {
            throw IllegalCharsetNameException(name);
        }

        std::string key = normalize(name);
        for (const auto& entry : registry()) {
            if (normalize(entry.canonical) == key) {
                return entry.canonical;
            }
            for (const auto& alias : entry.aliases) {
                if (normalize(alias) == key) {
                    return entry.canonical;
                }
            }
        }

        return "";
    }

public:
    Charset() : data_(nullptr) {}

    explicit Charset(const std::string& canonicalName)
        : data_(std::make_shared<Data>(canonicalName)) {}

    bool isNull() const {
        return data_ == nullptr;
    }

    const std::string& name() const {
        if (!data_) {
            throw std::logic_error("Null charset has no name");
        }
        return data_->canonicalName;
    }

    static Charset forName(const std::string& charsetName) {
        std::string canonical = lookupCanonical(charsetName);
        if (canonical.empty()) {
            throw UnsupportedCharsetException(charsetName);
        }
        return Charset(canonical);
    }

    static Charset forName(const std::string& charsetName, const Charset& fallback) {
        try {
            return forName(charsetName);
        } catch (const UnsupportedCharsetException&) {
            if (!fallback.isNull()) {
                return fallback;
            }
            throw;
        }
    }

    static Charset defaultCharset() {
        return Charset("UTF-8");
    }

    static bool isSupported(const std::string& charsetName) {
        return !lookupCanonical(charsetName).empty();
    }

    static std::map<std::string, Charset> availableCharsets() {
        std::map<std::string, Charset> result;
        for (const auto& entry : registry()) {
            result[entry.canonical] = Charset(entry.canonical);
        }
        return result;
    }

    bool operator==(const Charset& other) const {
        if (isNull() && other.isNull()) {
            return true;
        }
        if (isNull() || other.isNull()) {
            return false;
        }
        return data_->canonicalName == other.data_->canonicalName;
    }

    bool operator!=(const Charset& other) const {
        return !(*this == other);
    }
};

void isSupported_test_2238(const std::string& p0) {
    Charset::isSupported(p0);
}
