#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <functional>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <stdexcept>
#include <sstream>

// Forward declarations
class Object;
class Class;
class Comparable;
class Comparator;
class BinaryOperator;
class DoubleBinaryOperator;
class IntBinaryOperator;
class IntFunction;
class IntToDoubleFunction;
class IntToLongFunction;
class IntUnaryOperator;
class LongBinaryOperator;

// Basic Object class
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object* other) const { return this == other; }
    virtual int hashCode() const { return reinterpret_cast<intptr_t>(this); }
    virtual std::string toString() const { return "Object@" + std::to_string(hashCode()); }
};

// Class class (simplified)
class Class {
public:
    Class() = default;
    virtual ~Class() = default;
};

// Comparable interface
class Comparable {
public:
    virtual ~Comparable() = default;
    virtual int compareTo(const Object* other) const = 0;
};

// Comparator interface
class Comparator {
public:
    virtual ~Comparator() = default;
    virtual int compare(const Object* a, const Object* b) const = 0;
};

// Functional interfaces
class BinaryOperator {
public:
    virtual ~BinaryOperator() = default;
    virtual Object* apply(Object* a, Object* b) = 0;
};

class DoubleBinaryOperator {
public:
    virtual ~DoubleBinaryOperator() = default;
    virtual double applyAsDouble(double a, double b) = 0;
};

class IntBinaryOperator {
public:
    virtual ~IntBinaryOperator() = default;
    virtual int applyAsInt(int a, int b) = 0;
};

class IntFunction {
public:
    virtual ~IntFunction() = default;
    virtual Object* apply(int value) = 0;
};

class IntToDoubleFunction {
public:
    virtual ~IntToDoubleFunction() = default;
    virtual double applyAsDouble(int value) = 0;
};

class IntToLongFunction {
public:
    virtual ~IntToLongFunction() = default;
    virtual long applyAsLong(int value) = 0;
};

class IntUnaryOperator {
public:
    virtual ~IntUnaryOperator() = default;
    virtual int applyAsInt(int operand) = 0;
};

class LongBinaryOperator {
public:
    virtual ~LongBinaryOperator() = default;
    virtual long applyAsLong(long a, long b) = 0;
};

// Arrays class with static methods
class Arrays {
public:
    // compareUnsigned methods
    static int compareUnsigned(const std::vector<int8_t>& a, const std::vector<int8_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            uint8_t va = static_cast<uint8_t>(a[i]);
            uint8_t vb = static_cast<uint8_t>(b[i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int16_t>& a, const std::vector<int16_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            uint16_t va = static_cast<uint16_t>(a[i]);
            uint16_t vb = static_cast<uint16_t>(b[i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int8_t>& a, int aFrom, int aTo,
                               const std::vector<int8_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            uint8_t va = static_cast<uint8_t>(a[aFrom + i]);
            uint8_t vb = static_cast<uint8_t>(b[bFrom + i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int64_t>& a, int aFrom, int aTo,
                               const std::vector<int64_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            uint64_t va = static_cast<uint64_t>(a[aFrom + i]);
            uint64_t vb = static_cast<uint64_t>(b[bFrom + i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int16_t>& a, int aFrom, int aTo,
                               const std::vector<int16_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            uint16_t va = static_cast<uint16_t>(a[aFrom + i]);
            uint16_t vb = static_cast<uint16_t>(b[bFrom + i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int64_t>& a, const std::vector<int64_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            uint64_t va = static_cast<uint64_t>(a[i]);
            uint64_t vb = static_cast<uint64_t>(b[i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int32_t>& a, int aFrom, int aTo,
                               const std::vector<int32_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            uint32_t va = static_cast<uint32_t>(a[aFrom + i]);
            uint32_t vb = static_cast<uint32_t>(b[bFrom + i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compareUnsigned(const std::vector<int32_t>& a, const std::vector<int32_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            uint32_t va = static_cast<uint32_t>(a[i]);
            uint32_t vb = static_cast<uint32_t>(b[i]);
            if (va != vb) return va < vb ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    // copyOf methods
    static std::vector<double> copyOf(const std::vector<double>& original, int newLength) {
        std::vector<double> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<int32_t> copyOf(const std::vector<int32_t>& original, int newLength) {
        std::vector<int32_t> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<int8_t> copyOf(const std::vector<int8_t>& original, int newLength) {
        std::vector<int8_t> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<Object*> copyOf(const std::vector<Object*>& original, int newLength) {
        std::vector<Object*> result(newLength, nullptr);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<Object*> copyOf(const std::vector<Object*>& original, int newLength, Class* newType) {
        return copyOf(original, newLength);
    }

    static std::vector<bool> copyOf(const std::vector<bool>& original, int newLength) {
        std::vector<bool> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        for (size_t i = 0; i < copyLen; i++) result[i] = original[i];
        return result;
    }

    static std::vector<float> copyOf(const std::vector<float>& original, int newLength) {
        std::vector<float> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<char> copyOf(const std::vector<char>& original, int newLength) {
        std::vector<char> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<int64_t> copyOf(const std::vector<int64_t>& original, int newLength) {
        std::vector<int64_t> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    static std::vector<int16_t> copyOf(const std::vector<int16_t>& original, int newLength) {
        std::vector<int16_t> result(newLength);
        size_t copyLen = std::min(original.size(), static_cast<size_t>(newLength));
        std::copy(original.begin(), original.begin() + copyLen, result.begin());
        return result;
    }

    // sort methods
    static void sort(std::vector<Object*>& a) {
        std::sort(a.begin(), a.end(), [](Object* x, Object* y) {
            Comparable* cx = dynamic_cast<Comparable*>(x);
            Comparable* cy = dynamic_cast<Comparable*>(y);
            if (cx && cy) return cx->compareTo(y) < 0;
            return x < y;
        });
    }

    static void sort(std::vector<int64_t>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<int64_t>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<int16_t>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<Object*>& a, int fromIndex, int toIndex, Comparator* c) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex, [c](Object* x, Object* y) {
            return c->compare(x, y) < 0;
        });
    }

    static void sort(std::vector<Object*>& a, Comparator* c) {
        std::sort(a.begin(), a.end(), [c](Object* x, Object* y) {
            return c->compare(x, y) < 0;
        });
    }

    static void sort(std::vector<Object*>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex, [](Object* x, Object* y) {
            Comparable* cx = dynamic_cast<Comparable*>(x);
            Comparable* cy = dynamic_cast<Comparable*>(y);
            if (cx && cy) return cx->compareTo(y) < 0;
            return x < y;
        });
    }

    static void sort(std::vector<int32_t>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<double>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<double>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<float>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<float>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<int8_t>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<int16_t>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<char>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<char>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    static void sort(std::vector<int8_t>& a) {
        std::sort(a.begin(), a.end());
    }

    static void sort(std::vector<int32_t>& a, int fromIndex, int toIndex) {
        std::sort(a.begin() + fromIndex, a.begin() + toIndex);
    }

    // copyOfRange methods
    static std::vector<bool> copyOfRange(const std::vector<bool>& original, int from, int to) {
        std::vector<bool> result(to - from);
        for (int i = from; i < to; i++) result[i - from] = original[i];
        return result;
    }

    static std::vector<char> copyOfRange(const std::vector<char>& original, int from, int to) {
        std::vector<char> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<int64_t> copyOfRange(const std::vector<int64_t>& original, int from, int to) {
        std::vector<int64_t> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<float> copyOfRange(const std::vector<float>& original, int from, int to) {
        std::vector<float> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<double> copyOfRange(const std::vector<double>& original, int from, int to) {
        std::vector<double> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<Object*> copyOfRange(const std::vector<Object*>& original, int from, int to) {
        std::vector<Object*> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<Object*> copyOfRange(const std::vector<Object*>& original, int from, int to, Class* newType) {
        return copyOfRange(original, from, to);
    }

    static std::vector<int8_t> copyOfRange(const std::vector<int8_t>& original, int from, int to) {
        std::vector<int8_t> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<int16_t> copyOfRange(const std::vector<int16_t>& original, int from, int to) {
        std::vector<int16_t> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    static std::vector<int32_t> copyOfRange(const std::vector<int32_t>& original, int from, int to) {
        std::vector<int32_t> result(to - from);
        std::copy(original.begin() + from, original.begin() + to, result.begin());
        return result;
    }

    // compare methods
    static int compare(const std::vector<char>& a, int aFrom, int aTo,
                       const std::vector<char>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<int32_t>& a, const std::vector<int32_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<char>& a, const std::vector<char>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<int32_t>& a, int aFrom, int aTo,
                       const std::vector<int32_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<int64_t>& a, const std::vector<int64_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<int64_t>& a, int aFrom, int aTo,
                       const std::vector<int64_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<double>& a, const std::vector<double>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<float>& a, int aFrom, int aTo,
                       const std::vector<float>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<int16_t>& a, const std::vector<int16_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<int16_t>& a, int aFrom, int aTo,
                       const std::vector<int16_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<bool>& a, const std::vector<bool>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<bool>& a, int aFrom, int aTo,
                       const std::vector<bool>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<int8_t>& a, const std::vector<int8_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<int8_t>& a, int aFrom, int aTo,
                       const std::vector<int8_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<Comparable*>& a, int aFrom, int aTo,
                       const std::vector<Comparable*>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            int cmp = a[aFrom + i]->compareTo(b[bFrom + i]);
            if (cmp != 0) return cmp;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<Comparable*>& a, const std::vector<Comparable*>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            int cmp = a[i]->compareTo(b[i]);
            if (cmp != 0) return cmp;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<Object*>& a, const std::vector<Object*>& b, Comparator* c) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            int cmp = c->compare(a[i], b[i]);
            if (cmp != 0) return cmp;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    static int compare(const std::vector<double>& a, int aFrom, int aTo,
                       const std::vector<double>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return a[aFrom + i] < b[bFrom + i] ? -1 : 1;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<Object*>& a, int aFrom, int aTo,
                       const std::vector<Object*>& b, int bFrom, int bTo, Comparator* c) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            int cmp = c->compare(a[aFrom + i], b[bFrom + i]);
            if (cmp != 0) return cmp;
        }
        return aLen < bLen ? -1 : (aLen > bLen ? 1 : 0);
    }

    static int compare(const std::vector<float>& a, const std::vector<float>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
        }
        return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
    }

    // mismatch methods
    static int mismatch(const std::vector<int64_t>& a, const std::vector<int64_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<float>& a, const std::vector<float>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<int64_t>& a, int aFrom, int aTo,
                        const std::vector<int64_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<Object*>& a, const std::vector<Object*>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (!a[i]->equals(b[i])) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<Object*>& a, int aFrom, int aTo,
                        const std::vector<Object*>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (!a[aFrom + i]->equals(b[bFrom + i])) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<Object*>& a, const std::vector<Object*>& b, Comparator* c) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (c->compare(a[i], b[i]) != 0) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<Object*>& a, int aFrom, int aTo,
                        const std::vector<Object*>& b, int bFrom, int bTo, Comparator* c) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (c->compare(a[aFrom + i], b[bFrom + i]) != 0) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<double>& a, int aFrom, int aTo,
                        const std::vector<double>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<double>& a, const std::vector<double>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<float>& a, int aFrom, int aTo,
                        const std::vector<float>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<int8_t>& a, int aFrom, int aTo,
                        const std::vector<int8_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<char>& a, const std::vector<char>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<char>& a, int aFrom, int aTo,
                        const std::vector<char>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<int32_t>& a, const std::vector<int32_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<int16_t>& a, int aFrom, int aTo,
                        const std::vector<int16_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<int16_t>& a, const std::vector<int16_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<int32_t>& a, int aFrom, int aTo,
                        const std::vector<int32_t>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<bool>& a, const std::vector<bool>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    static int mismatch(const std::vector<bool>& a, int aFrom, int aTo,
                        const std::vector<bool>& b, int bFrom, int bTo) {
        int aLen = aTo - aFrom;
        int bLen = bTo - bFrom;
        int minLen = std::min(aLen, bLen);
        for (int i = 0; i < minLen; i++) {
            if (a[aFrom + i] != b[bFrom + i]) return i;
        }
        return aLen == bLen ? -1 : minLen;
    }

    static int mismatch(const std::vector<int8_t>& a, const std::vector<int8_t>& b) {
        size_t minLen = std::min(a.size(), b.size());
        for (size_t i = 0; i < minLen; i++) {
            if (a[i] != b[i]) return static_cast<int>(i);
        }
        return a.size() == b.size() ? -1 : static_cast<int>(minLen);
    }

    // stream methods (simplified - return void or dummy)
    static void stream(const std::vector<Object*>& a) {}
    static void stream(const std::vector<int64_t>& a) {}
    static void stream(const std::vector<int32_t>& a, int from, int to) {}
    static void stream(const std::vector<int32_t>& a) {}
    static void stream(const std::vector<Object*>& a, int from, int to) {}
    static void stream(const std::vector<double>& a, int from, int to) {}
    static void stream(const std::vector<double>& a) {}
    static void stream(const std::vector<int64_t>& a, int from, int to) {}

    // fill methods
    static void fill(std::vector<Object*>& a, int from, int to, Object* val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<int64_t>& a, int64_t val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<bool>& a, bool val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<int16_t>& a, int16_t val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<int32_t>& a, int from, int to, int32_t val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<int32_t>& a, int32_t val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<bool>& a, int from, int to, bool val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<int8_t>& a, int8_t val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<char>& a, char val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<int16_t>& a, int from, int to, int16_t val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<int8_t>& a, int from, int to, int8_t val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<double>& a, int from, int to, double val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<float>& a, float val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<float>& a, int from, int to, float val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<Object*>& a, Object* val) {
        std::fill(a.begin(), a.end(), val);
    }

    static void fill(std::vector<char>& a, int from, int to, char val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<int64_t>& a, int from, int to, int64_t val) {
        std::fill(a.begin() + from, a.begin() + to, val);
    }

    static void fill(std::vector<double>& a, double val) {
        std::fill(a.begin(), a.end(), val);
    }

    // spliterator methods (simplified - return void)
    static void spliterator(const std::vector<int32_t>& a) {}
    static void spliterator(const std::vector<int64_t>& a) {}
    static void spliterator(const std::vector<int32_t>& a, int from, int to) {}
    static void spliterator(const std::vector<Object*>& a, int from, int to) {}
    static void spliterator(const std::vector<double>& a, int from, int to) {}
    static void spliterator(const std::vector<Object*>& a) {}
    static void spliterator(const std::vector<int64_t>& a, int from, int to) {}
    static void spliterator(const std::vector<double>& a) {}

    // asList
    static std::vector<Object*> asList(const std::vector<Object*>& a) {
        return a;
    }

    // deepEquals
    static bool deepEquals(const std::vector<Object*>& a, const std::vector<Object*>& b) {
        if (a.size() != b.size()) return false;
        for (size_t i = 0; i < a.size(); i++) {
            if (!a[i]->equals(b[i])) return false;
        }
        return true;
    }

    // deepHashCode
    static int deepHashCode(const std::vector<Object*>& a) {
        int hash = 1;
        for (auto* obj : a) hash = 31 * hash + obj->hashCode();
        return hash;
    }

    // deepToString
    static std::string deepToString(const std::vector<Object*>& a) {
        std::ostringstream oss;
        oss << "[";
        for (size_t i = 0; i < a.size(); i++) {
            if (i > 0) oss << ", ";
            oss << a[i]->toString();
        }
        oss << "]";
        return oss.str();
    }

    // parallelSort (same as sort for simplicity)
    static void parallelSort(std::vector<int32_t>& a) { sort(a); }
    static void parallelSort(std::vector<int32_t>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<int64_t>& a) { sort(a); }
    static void parallelSort(std::vector<Object*>& a, int from, int to, Comparator* c) { sort(a, from, to, c); }
    static void parallelSort(std::vector<int16_t>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<Object*>& a, Comparator* c) { sort(a, c); }
    static void parallelSort(std::vector<int16_t>& a) { sort(a); }
    static void parallelSort(std::vector<double>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<double>& a) { sort(a); }
    static void parallelSort(std::vector<float>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<float>& a) { sort(a); }
    static void parallelSort(std::vector<Comparable*>& a) {
        std::sort(a.begin(), a.end(), [](Comparable* x, Comparable* y) { return x->compareTo(y) < 0; });
    }
    static void parallelSort(std::vector<Comparable*>& a, int from, int to) {
        std::sort(a.begin() + from, a.begin() + to, [](Comparable* x, Comparable* y) { return x->compareTo(y) < 0; });
    }
    static void parallelSort(std::vector<int8_t>& a) { sort(a); }
    static void parallelSort(std::vector<int8_t>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<char>& a) { sort(a); }
    static void parallelSort(std::vector<char>& a, int from, int to) { sort(a, from, to); }
    static void parallelSort(std::vector<int64_t>& a, int from, int to) { sort(a, from, to); }

    // parallelPrefix
    static void parallelPrefix(std::vector<double>& a, int from, int to, DoubleBinaryOperator* op) {
        for (int i = from + 1; i < to; i++) a[i] = op->applyAsDouble(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<double>& a, DoubleBinaryOperator* op) {
        for (size_t i = 1; i < a.size(); i++) a[i] = op->applyAsDouble(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<int32_t>& a, IntBinaryOperator* op) {
        for (size_t i = 1; i < a.size(); i++) a[i] = op->applyAsInt(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<int32_t>& a, int from, int to, IntBinaryOperator* op) {
        for (int i = from + 1; i < to; i++) a[i] = op->applyAsInt(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<int64_t>& a, int from, int to, LongBinaryOperator* op) {
        for (int i = from + 1; i < to; i++) a[i] = op->applyAsLong(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<int64_t>& a, LongBinaryOperator* op) {
        for (size_t i = 1; i < a.size(); i++) a[i] = op->applyAsLong(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<Object*>& a, int from, int to, BinaryOperator* op) {
        for (int i = from + 1; i < to; i++) a[i] = op->apply(a[i-1], a[i]);
    }
    static void parallelPrefix(std::vector<Object*>& a, BinaryOperator* op) {
        for (size_t i = 1; i < a.size(); i++) a[i] = op->apply(a[i-1], a[i]);
    }

    // binarySearch
    static int binarySearch(const std::vector<float>& a, int from, int to, float key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<float>& a, float key) {
        return binarySearch(a, 0, static_cast<int>(a.size()), key);
    }
    static int binarySearch(const std::vector<int16_t>& a, int16_t key) {
        auto it = std::lower_bound(a.begin(), a.end(), key);
        if (it != a.end() && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<int16_t>& a, int from, int to, int16_t key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<Object*>& a, Object* key) {
        for (size_t i = 0; i < a.size(); i++) {
            Comparable* c = dynamic_cast<Comparable*>(a[i]);
            if (c && c->compareTo(key) == 0) return static_cast<int>(i);
        }
        return -1;
    }
    static int binarySearch(const std::vector<Object*>& a, int from, int to, Object* key) {
        for (int i = from; i < to; i++) {
            Comparable* c = dynamic_cast<Comparable*>(a[i]);
            if (c && c->compareTo(key) == 0) return i;
        }
        return -1;
    }
    static int binarySearch(const std::vector<Object*>& a, Object* key, Comparator* c) {
        for (size_t i = 0; i < a.size(); i++) {
            if (c->compare(a[i], key) == 0) return static_cast<int>(i);
        }
        return -1;
    }
    static int binarySearch(const std::vector<double>& a, int from, int to, double key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<double>& a, double key) {
        return binarySearch(a, 0, static_cast<int>(a.size()), key);
    }
    static int binarySearch(const std::vector<int8_t>& a, int from, int to, int8_t key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<int8_t>& a, int8_t key) {
        return binarySearch(a, 0, static_cast<int>(a.size()), key);
    }
    static int binarySearch(const std::vector<char>& a, int from, int to, char key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<char>& a, char key) {
        return binarySearch(a, 0, static_cast<int>(a.size()), key);
    }
    static int binarySearch(const std::vector<int32_t>& a, int from, int to, int32_t key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<int64_t>& a, int64_t key) {
        auto it = std::lower_bound(a.begin(), a.end(), key);
        if (it != a.end() && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<int64_t>& a, int from, int to, int64_t key) {
        auto it = std::lower_bound(a.begin() + from, a.begin() + to, key);
        if (it != a.begin() + to && *it == key) return static_cast<int>(it - a.begin());
        return -static_cast<int>(it - a.begin()) - 1;
    }
    static int binarySearch(const std::vector<int32_t>& a, int32_t key) {
        return binarySearch(a, 0, static_cast<int>(a.size()), key);
    }
    static int binarySearch(const std::vector<Object*>& a, int from, int to, Object* key, Comparator* c) {
        for (int i = from; i < to; i++) {
            if (c->compare(a[i], key) == 0) return i;
        }
        return -1;
    }

    // setAll
    static void setAll(std::vector<double>& a, IntToDoubleFunction* f) {
        for (size_t i = 0; i < a.size(); i++) a[i] = f->applyAsDouble(static_cast<int>(i));
    }
    static void setAll(std::vector<int32_t>& a, IntUnaryOperator* f) {
        for (size_t i = 0; i < a.size(); i++) a[i] = f->applyAsInt(static_cast<int>(i));
    }
    static void setAll(std::vector<int64_t>& a, IntToLongFunction* f) {
        for (size_t i = 0; i < a.size(); i++) a[i] = f->applyAsLong(static_cast<int>(i));
    }
    static void setAll(std::vector<Object*>& a, IntFunction* f) {
        for (size_t i = 0; i < a.size(); i++) a[i] = f->apply(static_cast<int>(i));
    }

    // parallelSetAll
    static void parallelSetAll(std::vector<double>& a, IntToDoubleFunction* f) { setAll(a, f); }
    static void parallelSetAll(std::vector<int64_t>& a, IntToLongFunction* f) { setAll(a, f); }
    static void parallelSetAll(std::vector<Object*>& a, IntFunction* f) { setAll(a, f); }
    static void parallelSetAll(std::vector<int32_t>& a, IntUnaryOperator* f) { setAll(a, f); }
};

// Test class
class java_util_ArraysAutoTest {
public:

void mismatch_test_420(byte* p0, int p1, int p2, byte* p3, int p4, int p5) {
    Arrays::mismatch(p0, p1, p2, p3, p4, p5);
}
