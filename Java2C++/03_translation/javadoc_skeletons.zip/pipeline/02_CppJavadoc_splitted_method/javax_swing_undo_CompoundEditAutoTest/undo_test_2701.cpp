#include <string>
#include <vector>

class UndoableEdit {
public:
    virtual ~UndoableEdit() {}
    virtual void undo() = 0;
    virtual void redo() = 0;
    virtual bool canUndo() const = 0;
    virtual bool canRedo() const = 0;
    virtual bool addEdit(UndoableEdit* edit) = 0;
    virtual bool replaceEdit(UndoableEdit* edit) = 0;
    virtual bool isSignificant() const = 0;
    virtual std::string getPresentationName() const = 0;
    virtual std::string getUndoPresentationName() const = 0;
    virtual std::string getRedoPresentationName() const = 0;
    virtual void die() = 0;
};

class CompoundEdit : public UndoableEdit {
private:
    std::vector<UndoableEdit*> edits;
    bool inProgress;
    bool alive;
    bool hasBeenDone;

public:
    CompoundEdit() : inProgress(true), alive(true), hasBeenDone(false) {}

    bool addEdit(UndoableEdit* edit) override {
        if (!inProgress) {
            return false;
        }
        edits.push_back(edit);
        return true;
    }

    bool replaceEdit(UndoableEdit* edit) override {
        return false;
    }

    void undo() override {
        if (!canUndo()) {
            return;
        }
        for (auto it = edits.rbegin(); it != edits.rend(); ++it) {
            (*it)->undo();
        }
        hasBeenDone = false;
    }

    void redo() override {
        if (!canRedo()) {
            return;
        }
        for (auto* edit : edits) {
            edit->redo();
        }
        hasBeenDone = true;
    }

    bool canUndo() const override {
        return alive && !inProgress && hasBeenDone;
    }

    bool canRedo() const override {
        return alive && !inProgress && !hasBeenDone;
    }

    bool isSignificant() const override {
        for (auto* edit : edits) {
            if (edit->isSignificant()) {
                return true;
            }
        }
        return false;
    }

    std::string getPresentationName() const override {
        return "";
    }

    std::string getUndoPresentationName() const override {
        return "Undo";
    }

    std::string getRedoPresentationName() const override {
        return "Redo";
    }

    void die() override {
        alive = false;
        for (auto* edit : edits) {
            edit->die();
        }
    }

    bool isInProgress() const {
        return inProgress;
    }

    void end() {
        inProgress = false;
    }
};

void undo_test_2701() {
    CompoundEdit instance;
    instance.undo();
}
