#include <string>
#include <vector>

class Locale {
public:
    Locale() : language_("en"), country_("US") {}
    Locale(const std::string& language, const std::string& country)
        : language_(language), country_(country) {}
    explicit Locale(const std::string& language)
        : language_(language), country_("") {}

    static Locale getDefault() {
        return Locale();
    }

    std::string getLanguage() const { return language_; }
    std::string getCountry() const { return country_; }

private:
    std::string language_;
    std::string country_;
};

class Collator {
public:
    static Collator getInstance(const Locale& locale) {
        return Collator(locale);
    }

    static Collator getInstance() {
        return Collator(Locale::getDefault());
    }

    static std::vector<Locale> getAvailableLocales() {
        std::vector<Locale> locales;
        locales.push_back(Locale("en", "US"));
        locales.push_back(Locale("fr", "FR"));
        locales.push_back(Locale("de", "DE"));
        locales.push_back(Locale("ja", "JP"));
        return locales;
    }

private:
    explicit Collator(const Locale& locale) : locale_(locale) {}

    Locale locale_;
};

void getInstance_test_2350() {
    Collator::getInstance();
}
