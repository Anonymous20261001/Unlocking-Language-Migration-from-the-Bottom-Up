#include <string>
#include <vector>
#include <stdexcept>

class Locale {
public:
    Locale(const std::string& language = "", const std::string& country = "")
        : language_(language), country_(country) {}

    std::string getLanguage() const { return language_; }
    std::string getCountry() const { return country_; }

private:
    std::string language_;
    std::string country_;
};

class Currency {
public:
    static std::vector<Currency> getAvailableCurrencies() {
        return allCurrencies();
    }

    static std::vector<Currency> availableCurrencies() {
        return allCurrencies();
    }

    static Currency getInstance(const std::string& currencyCode) {
        const auto& currencies = allCurrencies();
        for (const auto& currency : currencies) {
            if (currency.currencyCode_ == currencyCode) {
                return currency;
            }
        }
        throw std::invalid_argument("Unknown currency code: " + currencyCode);
    }

    static Currency getInstance(const Locale& locale) {
        const auto& currencies = allCurrencies();
        for (const auto& currency : currencies) {
            if (currency.country_ == locale.getCountry()) {
                return currency;
            }
        }
        throw std::invalid_argument("No currency available for the given locale");
    }

    std::string getCurrencyCode() const { return currencyCode_; }

    bool operator<(const Currency& other) const {
        return currencyCode_ < other.currencyCode_;
    }

    bool operator==(const Currency& other) const {
        return currencyCode_ == other.currencyCode_;
    }

private:
    std::string currencyCode_;
    std::string country_;

    Currency(const std::string& currencyCode, const std::string& country)
        : currencyCode_(currencyCode), country_(country) {}

    static const std::vector<Currency>& allCurrencies() {
        static const std::vector<Currency> currencies = {
            {"USD", "US"},
            {"EUR", "DE"},
            {"JPY", "JP"},
            {"GBP", "GB"},
            {"CNY", "CN"}
        };
        return currencies;
    }
};

void getInstance_test_3164(std::string p0) {
    Currency::getInstance(p0);
}
