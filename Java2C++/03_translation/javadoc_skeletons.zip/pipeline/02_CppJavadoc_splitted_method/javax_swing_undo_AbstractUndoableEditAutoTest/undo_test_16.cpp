#include <string>
#include <stdexcept>

class UndoableEdit {
public:
    virtual ~UndoableEdit() = default;
    virtual void undo() = 0;
    virtual bool canUndo() const = 0;
    virtual void redo() = 0;
    virtual bool canRedo() const = 0;
    virtual void die() = 0;
    virtual bool addEdit(UndoableEdit& anEdit) = 0;
    virtual bool replaceEdit(UndoableEdit& anEdit) = 0;
    virtual bool isSignificant() const = 0;
    virtual std::string getPresentationName() const = 0;
    virtual std::string getUndoPresentationName() const = 0;
    virtual std::string getRedoPresentationName() const = 0;
};

class CannotUndoException : public std::runtime_error {
public:
    CannotUndoException() : std::runtime_error("Cannot undo") {}
};

class CannotRedoException : public std::runtime_error {
public:
    CannotRedoException() : std::runtime_error("Cannot redo") {}
};

class AbstractUndoableEdit : public UndoableEdit {
protected:
    bool hasBeenDone;
    bool alive;

public:
    AbstractUndoableEdit()
        : hasBeenDone(true), alive(true) {}

    bool canUndo() const override {
        return alive && hasBeenDone;
    }

    bool canRedo() const override {
        return alive && !hasBeenDone;
    }

    void undo() override {
        if (!canUndo()) {
            throw CannotUndoException();
        }
        hasBeenDone = false;
    }

    void redo() override {
        if (!canRedo()) {
            throw CannotRedoException();
        }
        hasBeenDone = true;
    }

    void die() override {
        alive = false;
    }

    bool addEdit(UndoableEdit& anEdit) override {
        (void)anEdit;
        return false;
    }

    bool replaceEdit(UndoableEdit& anEdit) override {
        (void)anEdit;
        return false;
    }

    bool isSignificant() const override {
        return true;
    }

    std::string getPresentationName() const override {
        return "";
    }

    std::string getUndoPresentationName() const override {
        return "Undo";
    }

    std::string getRedoPresentationName() const override {
        return "Redo";
    }
};

void undo_test_16() {
    AbstractUndoableEdit instance;
    instance.undo();
}
