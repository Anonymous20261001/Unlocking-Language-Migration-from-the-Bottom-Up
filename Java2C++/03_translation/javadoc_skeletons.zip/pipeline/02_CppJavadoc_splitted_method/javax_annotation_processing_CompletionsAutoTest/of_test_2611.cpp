#include <string>

class Completion {
public:
    Completion(const std::string& value, const std::string& message)
        : value_(value), message_(message) {}

    const std::string& getValue() const {
        return value_;
    }

    const std::string& getMessage() const {
        return message_;
    }

private:
    std::string value_;
    std::string message_;
};

class Completions {
public:
    static Completion of(const std::string& value, const std::string& message) {
        return Completion(value, message);
    }

    static Completion of(const std::string& value) {
        return Completion(value, "");
    }

private:
    Completions() = delete;
};

void of_test_2611() {
    std::string p0;
    Completions::of(p0);
}
