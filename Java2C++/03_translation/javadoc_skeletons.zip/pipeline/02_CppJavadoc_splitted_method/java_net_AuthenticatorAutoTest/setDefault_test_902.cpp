#include <string>

class InetAddress {
public:
    InetAddress() = default;
    explicit InetAddress(const std::string& address) : address_(address) {}
private:
    std::string address_;
};

class URL {
public:
    URL() = default;
    explicit URL(const std::string& url) : url_(url) {}
private:
    std::string url_;
};

class PasswordAuthentication {
public:
    PasswordAuthentication() = default;
    PasswordAuthentication(const std::string& user, const std::string& password)
        : user_(user), password_(password) {}
private:
    std::string user_;
    std::string password_;
};

class Authenticator {
public:
    enum class RequestorType {
        PROXY,
        SERVER
    };

    virtual ~Authenticator() = default;

    static PasswordAuthentication requestPasswordAuthentication(
        InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme) {
        (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme) {
        (void)host; (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        Authenticator* authenticator,
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme,
        URL url, RequestorType reqType) {
        (void)authenticator; (void)host; (void)addr; (void)port; (void)protocol;
        (void)prompt; (void)scheme; (void)url; (void)reqType;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme,
        URL url, RequestorType reqType) {
        (void)host; (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        (void)url; (void)reqType;
        return PasswordAuthentication();
    }

    static Authenticator* getDefault() {
        return defaultAuthenticator;
    }

    static void setDefault(Authenticator* authenticator) {
        defaultAuthenticator = authenticator;
    }

private:
    static Authenticator* defaultAuthenticator;
};

Authenticator* Authenticator::defaultAuthenticator = nullptr;

void setDefault_test_902(Authenticator* p0) {
    Authenticator::setDefault(p0);
}
