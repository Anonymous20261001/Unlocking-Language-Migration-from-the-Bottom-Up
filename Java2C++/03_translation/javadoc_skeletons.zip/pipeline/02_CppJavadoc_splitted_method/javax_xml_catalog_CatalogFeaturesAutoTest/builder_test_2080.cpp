namespace javax {
namespace xml {
namespace catalog {

class CatalogFeatures {
public:
    CatalogFeatures(const CatalogFeatures&) = default;
    CatalogFeatures(CatalogFeatures&&) = default;
    CatalogFeatures& operator=(const CatalogFeatures&) = default;
    CatalogFeatures& operator=(CatalogFeatures&&) = default;
    ~CatalogFeatures() = default;

    class Builder {
    public:
        Builder() = default;
        Builder(const Builder&) = default;
        Builder(Builder&&) = default;
        Builder& operator=(const Builder&) = default;
        Builder& operator=(Builder&&) = default;
        ~Builder() = default;

        // Additional Builder API used by callers can be added here.
    };

    static Builder builder() {
        return Builder();
    }

    static CatalogFeatures defaults() {
        return CatalogFeatures();
    }

private:
    CatalogFeatures() = default;
};

} // namespace catalog
} // namespace xml
} // namespace javax

void builder_test_2080() {
    javax::xml::catalog::CatalogFeatures::builder();
}
