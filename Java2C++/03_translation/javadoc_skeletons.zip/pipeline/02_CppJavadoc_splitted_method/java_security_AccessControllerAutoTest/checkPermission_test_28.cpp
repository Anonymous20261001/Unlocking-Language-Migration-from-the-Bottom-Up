#include <vector>

class Permission {
public:
    Permission() = default;
    virtual ~Permission() = default;
};

class AccessControlContext {
public:
    AccessControlContext() = default;
    AccessControlContext(const AccessControlContext&) = default;
    AccessControlContext& operator=(const AccessControlContext&) = default;
    virtual ~AccessControlContext() = default;
};

class PrivilegedAction {
public:
    virtual ~PrivilegedAction() = default;
    virtual void* run() = 0;
};

class AccessController {
public:
    static void checkPermission(const Permission& perm) {
        (void)perm;
    }

    static void* doPrivileged(PrivilegedAction& action) {
        return action.run();
    }

    static void* doPrivileged(PrivilegedAction& action, const AccessControlContext& context) {
        (void)context;
        return doPrivileged(action);
    }

    static void* doPrivileged(PrivilegedAction& action, const AccessControlContext& context,
                              const std::vector<Permission>& perms) {
        (void)context;
        (void)perms;
        return doPrivileged(action);
    }

    static void* doPrivilegedWithCombiner(PrivilegedAction& action) {
        return doPrivileged(action);
    }

    static void* doPrivilegedWithCombiner(PrivilegedAction& action, const AccessControlContext& context,
                                          const std::vector<Permission>& perms) {
        (void)context;
        (void)perms;
        return doPrivileged(action);
    }

    static AccessControlContext getContext() {
        return AccessControlContext();
    }
};

void checkPermission_test_28(Permission& p0) {
    AccessController::checkPermission(p0);
}
