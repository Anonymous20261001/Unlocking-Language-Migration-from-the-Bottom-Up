#include <string>
#include <memory>
#include <functional>

namespace javax {
namespace swing {

class Color {
public:
    Color() : r(0), g(0), b(0), a(255) {}
    Color(int r, int g, int b) : r(r), g(g), b(b), a(255) {}
    Color(int r, int g, int b, int a) : r(r), g(g), b(b), a(a) {}
    int getRed() const { return r; }
    int getGreen() const { return g; }
    int getBlue() const { return b; }
    int getAlpha() const { return a; }
private:
    int r, g, b, a;
};

class Font {
public:
    Font() : name(""), style(0), size(12) {}
    Font(const std::string& name, int style, int size) : name(name), style(style), size(size) {}
    std::string getName() const { return name; }
    int getStyle() const { return style; }
    int getSize() const { return size; }
private:
    std::string name;
    int style;
    int size;
};

class Paint {
public:
    virtual ~Paint() = default;
};

class BasicStroke {
public:
    BasicStroke() : width(1.0f), cap(0), join(0), miterlimit(10.0f), dash(nullptr), dash_phase(0.0f) {}
    BasicStroke(float width) : width(width), cap(0), join(0), miterlimit(10.0f), dash(nullptr), dash_phase(0.0f) {}
    BasicStroke(float width, int cap, int join) : width(width), cap(cap), join(join), miterlimit(10.0f), dash(nullptr), dash_phase(0.0f) {}
    BasicStroke(float width, int cap, int join, float miterlimit) : width(width), cap(cap), join(join), miterlimit(miterlimit), dash(nullptr), dash_phase(0.0f) {}
    BasicStroke(float width, int cap, int join, float miterlimit, const float* dash, int dashLength, float dash_phase)
        : width(width), cap(cap), join(join), miterlimit(miterlimit), dash(dash), dashLength(dashLength), dash_phase(dash_phase) {}
    float getLineWidth() const { return width; }
    int getEndCap() const { return cap; }
    int getLineJoin() const { return join; }
    float getMiterLimit() const { return miterlimit; }
    const float* getDashArray() const { return dash; }
    int getDashLength() const { return dashLength; }
    float getDashPhase() const { return dash_phase; }
private:
    float width;
    int cap;
    int join;
    float miterlimit;
    const float* dash;
    int dashLength;
    float dash_phase;
};

class Icon {
public:
    virtual ~Icon() = default;
    virtual int getIconWidth() const = 0;
    virtual int getIconHeight() const = 0;
};

class Border {
public:
    virtual ~Border() = default;
};

class BevelBorder : public Border {
public:
    BevelBorder(int type) : type(type) {}
    BevelBorder(int type, Color highlight, Color shadow) : type(type), highlight(highlight), shadow(shadow) {}
    BevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
        : type(type), highlightOuter(highlightOuter), highlightInner(highlightInner), shadowOuter(shadowOuter), shadowInner(shadowInner) {}
    int getBevelType() const { return type; }
private:
    int type;
    Color highlight;
    Color shadow;
    Color highlightOuter;
    Color highlightInner;
    Color shadowOuter;
    Color shadowInner;
};

class SoftBevelBorder : public Border {
public:
    SoftBevelBorder(int type) : type(type) {}
    SoftBevelBorder(int type, Color highlight, Color shadow) : type(type), highlight(highlight), shadow(shadow) {}
    SoftBevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
        : type(type), highlightOuter(highlightOuter), highlightInner(highlightInner), shadowOuter(shadowOuter), shadowInner(shadowInner) {}
    int getBevelType() const { return type; }
private:
    int type;
    Color highlight;
    Color shadow;
    Color highlightOuter;
    Color highlightInner;
    Color shadowOuter;
    Color shadowInner;
};

class EtchedBorder : public Border {
public:
    EtchedBorder() : type(0) {}
    EtchedBorder(int type) : type(type) {}
    EtchedBorder(Color highlight, Color shadow) : type(0), highlight(highlight), shadow(shadow) {}
    EtchedBorder(int type, Color highlight, Color shadow) : type(type), highlight(highlight), shadow(shadow) {}
    int getEtchType() const { return type; }
private:
    int type;
    Color highlight;
    Color shadow;
};

class TitledBorder : public Border {
public:
    TitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition, Font* titleFont)
        : border(border), title(title), titleJustification(titleJustification), titlePosition(titlePosition), titleFont(titleFont) {}
    TitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition, Font* titleFont, Color* titleColor)
        : border(border), title(title), titleJustification(titleJustification), titlePosition(titlePosition), titleFont(titleFont), titleColor(titleColor) {}
    TitledBorder(const std::string& title) : border(nullptr), title(title), titleJustification(0), titlePosition(0), titleFont(nullptr) {}
    TitledBorder(Border* border) : border(border), title(""), titleJustification(0), titlePosition(0), titleFont(nullptr) {}
    TitledBorder(Border* border, const std::string& title) : border(border), title(title), titleJustification(0), titlePosition(0), titleFont(nullptr) {}
    TitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition)
        : border(border), title(title), titleJustification(titleJustification), titlePosition(titlePosition), titleFont(nullptr) {}
private:
    Border* border;
    std::string title;
    int titleJustification;
    int titlePosition;
    Font* titleFont;
    Color* titleColor;
};

class CompoundBorder : public Border {
public:
    CompoundBorder() : outsideBorder(nullptr), insideBorder(nullptr) {}
    CompoundBorder(Border* outside, Border* inside) : outsideBorder(outside), insideBorder(inside) {}
private:
    Border* outsideBorder;
    Border* insideBorder;
};

class MatteBorder : public Border {
public:
    MatteBorder(int top, int left, int bottom, int right, Color color)
        : top(top), left(left), bottom(bottom), right(right), color(color), icon(nullptr) {}
    MatteBorder(int top, int left, int bottom, int right, Icon* icon)
        : top(top), left(left), bottom(bottom), right(right), icon(icon) {}
private:
    int top, left, bottom, right;
    Color color;
    Icon* icon;
};

class EmptyBorder : public Border {
public:
    EmptyBorder() : top(0), left(0), bottom(0), right(0) {}
    EmptyBorder(int top, int left, int bottom, int right) : top(top), left(left), bottom(bottom), right(right) {}
private:
    int top, left, bottom, right;
};

class LineBorder : public Border {
public:
    LineBorder(Color color) : color(color), thickness(1), roundedCorners(false) {}
    LineBorder(Color color, int thickness) : color(color), thickness(thickness), roundedCorners(false) {}
    LineBorder(Color color, int thickness, bool roundedCorners) : color(color), thickness(thickness), roundedCorners(roundedCorners) {}
private:
    Color color;
    int thickness;
    bool roundedCorners;
};

class StrokeBorder : public Border {
public:
    StrokeBorder(BasicStroke* stroke) : stroke(stroke), paint(nullptr) {}
    StrokeBorder(BasicStroke* stroke, Paint* paint) : stroke(stroke), paint(paint) {}
private:
    BasicStroke* stroke;
    Paint* paint;
};

class DashedBorder : public Border {
public:
    DashedBorder(Paint* paint) : paint(paint), length(1.0f), spacing(1.0f), thickness(1.0f), rounded(false) {}
    DashedBorder(Paint* paint, float length, float spacing) : paint(paint), length(length), spacing(spacing), thickness(1.0f), rounded(false) {}
    DashedBorder(Paint* paint, float length, float spacing, float thickness, bool rounded)
        : paint(paint), length(length), spacing(spacing), thickness(thickness), rounded(rounded) {}
private:
    Paint* paint;
    float length;
    float spacing;
    float thickness;
    bool rounded;
};

class BorderFactory {
public:
    static Border* createLoweredBevelBorder() {
        return new BevelBorder(1);
    }

    static Border* createBevelBorder(int type) {
        return new BevelBorder(type);
    }

    static Border* createBevelBorder(int type, Color highlight, Color shadow) {
        return new BevelBorder(type, highlight, shadow);
    }

    static Border* createBevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner) {
        return new BevelBorder(type, highlightOuter, highlightInner, shadowOuter, shadowInner);
    }

    static Border* createSoftBevelBorder(int type) {
        return new SoftBevelBorder(type);
    }

    static Border* createSoftBevelBorder(int type, Color highlight, Color shadow) {
        return new SoftBevelBorder(type, highlight, shadow);
    }

    static Border* createSoftBevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner) {
        return new SoftBevelBorder(type, highlightOuter, highlightInner, shadowOuter, shadowInner);
    }

    static Border* createEtchedBorder(Color highlight, Color shadow) {
        return new EtchedBorder(highlight, shadow);
    }

    static Border* createEtchedBorder(int type) {
        return new EtchedBorder(type);
    }

    static Border* createEtchedBorder() {
        return new EtchedBorder();
    }

    static Border* createEtchedBorder(int type, Color highlight, Color shadow) {
        return new EtchedBorder(type, highlight, shadow);
    }

    static Border* createTitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition, Font* titleFont) {
        return new TitledBorder(border, title, titleJustification, titlePosition, titleFont);
    }

    static Border* createTitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition, Font* titleFont, Color titleColor) {
        return new TitledBorder(border, title, titleJustification, titlePosition, titleFont, &titleColor);
    }

    static Border* createTitledBorder(const std::string& title) {
        return new TitledBorder(title);
    }

    static Border* createTitledBorder(Border* border) {
        return new TitledBorder(border);
    }

    static Border* createTitledBorder(Border* border, const std::string& title) {
        return new TitledBorder(border, title);
    }

    static Border* createTitledBorder(Border* border, const std::string& title, int titleJustification, int titlePosition) {
        return new TitledBorder(border, title, titleJustification, titlePosition);
    }

    static Border* createCompoundBorder() {
        return new CompoundBorder();
    }

    static Border* createCompoundBorder(Border* outside, Border* inside) {
        return new CompoundBorder(outside, inside);
    }

    static Border* createMatteBorder(int top, int left, int bottom, int right, Color color) {
        return new MatteBorder(top, left, bottom, right, color);
    }

    static Border* createMatteBorder(int top, int left, int bottom, int right, Icon* icon) {
        return new MatteBorder(top, left, bottom, right, icon);
    }

    static Border* createRaisedBevelBorder() {
        return new BevelBorder(0);
    }

    static Border* createRaisedSoftBevelBorder() {
        return new SoftBevelBorder(0);
    }

    static Border* createLoweredSoftBevelBorder() {
        return new SoftBevelBorder(1);
    }

    static Border* createDashedBorder(Paint* paint) {
        return new DashedBorder(paint);
    }

    static Border* createDashedBorder(Paint* paint, float length, float spacing) {
        return new DashedBorder(paint, length, spacing);
    }

    static Border* createDashedBorder(Paint* paint, float length, float spacing, float thickness, bool rounded) {
        return new DashedBorder(paint, length, spacing, thickness, rounded);
    }

    static Border* createStrokeBorder(BasicStroke* stroke, Paint* paint) {
        return new StrokeBorder(stroke, paint);
    }

    static Border* createStrokeBorder(BasicStroke* stroke) {
        return new StrokeBorder(stroke);
    }

    static Border* createEmptyBorder() {
        return new EmptyBorder();
    }

    static Border* createEmptyBorder(int top, int left, int bottom, int right) {
        return new EmptyBorder(top, left, bottom, right);
    }

    static Border* createLineBorder(Color color, int thickness, bool rounded) {
        return new LineBorder(color, thickness, rounded);
    }

    static Border* createLineBorder(Color color) {
        return new LineBorder(color);
    }

    static Border* createLineBorder(Color color, int thickness) {
        return new LineBorder(color, thickness);
    }
};

} // namespace swing
} // namespace javax

// Test functions

void createStrokeBorder_test_1808(javax::swing::BasicStroke* p0) {
    javax::swing::BorderFactory::createStrokeBorder(p0);
}
