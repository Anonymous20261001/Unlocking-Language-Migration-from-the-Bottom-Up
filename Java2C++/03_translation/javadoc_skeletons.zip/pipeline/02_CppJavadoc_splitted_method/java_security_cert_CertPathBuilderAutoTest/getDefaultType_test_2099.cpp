#include <string>

namespace java {
namespace security {
namespace cert {

class CertPathBuilder {
public:
    static std::string getDefaultType() {
        return "PKIX";
    }
};

} // namespace cert
} // namespace security
} // namespace java

void getDefaultType_test_2099() {
    java::security::cert::CertPathBuilder::getDefaultType();
}
