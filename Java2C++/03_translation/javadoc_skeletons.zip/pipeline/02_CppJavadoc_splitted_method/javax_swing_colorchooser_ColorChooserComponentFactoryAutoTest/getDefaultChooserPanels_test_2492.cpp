struct JComponent {};
struct JTabbedPane : JComponent {};

class ColorChooserComponentFactory {
public:
  static JComponent getPreviewPanel() {
    return JComponent();
  }

  static JTabbedPane getDefaultChooserPanels() {
    return JTabbedPane();
  }
};

void getDefaultChooserPanels_test_2492() {
  ColorChooserComponentFactory::getDefaultChooserPanels();
}
