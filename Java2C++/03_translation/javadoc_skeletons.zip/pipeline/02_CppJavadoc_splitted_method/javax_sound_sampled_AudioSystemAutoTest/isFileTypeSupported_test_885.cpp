#include <string>
#include <vector>

class AudioFormat {
public:
    class Encoding {
    public:
        Encoding() : name_("unknown") {}
        explicit Encoding(const std::string& name) : name_(name) {}

        const std::string& getName() const { return name_; }

        bool operator==(const Encoding& other) const { return name_ == other.name_; }
        bool operator!=(const Encoding& other) const { return !(*this == other); }

    private:
        std::string name_;
    };

    AudioFormat()
        : encoding_(), sampleRate_(0.0f), sampleSizeInBits_(0), channels_(0),
          frameSize_(0), frameRate_(0.0f), bigEndian_(false) {}

    AudioFormat(const Encoding& encoding, float sampleRate, int sampleSizeInBits,
                int channels, int frameSize, float frameRate, bool bigEndian)
        : encoding_(encoding), sampleRate_(sampleRate), sampleSizeInBits_(sampleSizeInBits),
          channels_(channels), frameSize_(frameSize), frameRate_(frameRate), bigEndian_(bigEndian) {}

    AudioFormat(float sampleRate, int sampleSizeInBits, int channels,
                bool /*signed*/, bool bigEndian)
        : encoding_(), sampleRate_(sampleRate), sampleSizeInBits_(sampleSizeInBits),
          channels_(channels), frameSize_(((sampleSizeInBits + 7) / 8) * channels),
          frameRate_(sampleRate), bigEndian_(bigEndian) {}

    Encoding getEncoding() const { return encoding_; }

private:
    Encoding encoding_;
    float sampleRate_;
    int sampleSizeInBits_;
    int channels_;
    int frameSize_;
    float frameRate_;
    bool bigEndian_;
};

class AudioInputStream {
public:
    AudioInputStream() : format_() {}
    explicit AudioInputStream(const AudioFormat& format) : format_(format) {}

    AudioFormat getFormat() const { return format_; }

private:
    AudioFormat format_;
};

class AudioFileFormat {
public:
    class Type {
    public:
        Type() : name_("unknown"), extension_("") {}
        Type(const std::string& name, const std::string& extension)
            : name_(name), extension_(extension) {}

        const std::string& getName() const { return name_; }
        const std::string& getExtension() const { return extension_; }

        bool operator==(const Type& other) const {
            return name_ == other.name_ && extension_ == other.extension_;
        }
        bool operator!=(const Type& other) const { return !(*this == other); }

    private:
        std::string name_;
        std::string extension_;
    };

    AudioFileFormat() : type_(), format_(), frameLength_(-1) {}

private:
    Type type_;
    AudioFormat format_;
    int frameLength_;
};

class Line {
public:
    class Info {
    public:
        Info() : name_("unknown") {}
        explicit Info(const std::string& name) : name_(name) {}

        const std::string& getName() const { return name_; }

        bool operator==(const Info& other) const { return name_ == other.name_; }
        bool operator!=(const Info& other) const { return !(*this == other); }

    private:
        std::string name_;
    };
};

class Mixer {
public:
    class Info {
    public:
        Info()
            : name_("unknown"), vendor_("unknown"), version_("unknown"), description_("unknown") {}

        Info(const std::string& name, const std::string& vendor,
             const std::string& description, const std::string& version)
            : name_(name), vendor_(vendor), version_(version), description_(description) {}

        bool operator==(const Info& other) const {
            return name_ == other.name_ && vendor_ == other.vendor_ &&
                   version_ == other.version_ && description_ == other.description_;
        }
        bool operator!=(const Info& other) const { return !(*this == other); }

    private:
        std::string name_;
        std::string vendor_;
        std::string version_;
        std::string description_;
    };
};

class AudioSystem {
public:
    static AudioInputStream getAudioInputStream(const AudioFormat::Encoding&, const AudioInputStream&) {
        return AudioInputStream();
    }

    static AudioInputStream getAudioInputStream(const AudioFormat&, const AudioInputStream&) {
        return AudioInputStream();
    }

    static std::vector<AudioFileFormat::Type> getAudioFileTypes(const AudioInputStream&) {
        return std::vector<AudioFileFormat::Type>();
    }

    static std::vector<AudioFileFormat::Type> getAudioFileTypes() {
        return std::vector<AudioFileFormat::Type>();
    }

    static bool isFileTypeSupported(const AudioFileFormat::Type&) {
        return false;
    }

    static bool isFileTypeSupported(const AudioFileFormat::Type&, const AudioInputStream&) {
        return false;
    }

    static Mixer* getMixer(const Mixer::Info&) {
        static Mixer mixer;
        return &mixer;
    }

    static std::vector<Mixer::Info> getMixerInfo() {
        return std::vector<Mixer::Info>();
    }

    static std::vector<Line::Info> getSourceLineInfo(const Line::Info&) {
        return std::vector<Line::Info>();
    }

    static std::vector<Line::Info> getTargetLineInfo(const Line::Info&) {
        return std::vector<Line::Info>();
    }

    static bool isLineSupported(const Line::Info&) {
        return false;
    }

    static std::vector<AudioFormat::Encoding> getTargetEncodings(const AudioFormat::Encoding&) {
        return std::vector<AudioFormat::Encoding>();
    }

    static std::vector<AudioFormat::Encoding> getTargetEncodings(const AudioFormat&) {
        return std::vector<AudioFormat::Encoding>();
    }

    static bool isConversionSupported(const AudioFormat&, const AudioFormat&) {
        return false;
    }

    static bool isConversionSupported(const AudioFormat::Encoding&, const AudioFormat&) {
        return false;
    }

    static std::vector<AudioFormat> getTargetFormats(const AudioFormat::Encoding&, const AudioFormat&) {
        return std::vector<AudioFormat>();
    }
};

void isFileTypeSupported_test_885() {
    AudioFileFormat::Type p0;
    AudioSystem::isFileTypeSupported(p0);
}
