class BaselineTIFFTagSet {
public:
    static BaselineTIFFTagSet& getInstance() {
        static BaselineTIFFTagSet instance;
        return instance;
    }
private:
    BaselineTIFFTagSet() {}
    BaselineTIFFTagSet(const BaselineTIFFTagSet&) = delete;
    BaselineTIFFTagSet& operator=(const BaselineTIFFTagSet&) = delete;
};

void getInstance_test_984() {
    BaselineTIFFTagSet::getInstance();
}
