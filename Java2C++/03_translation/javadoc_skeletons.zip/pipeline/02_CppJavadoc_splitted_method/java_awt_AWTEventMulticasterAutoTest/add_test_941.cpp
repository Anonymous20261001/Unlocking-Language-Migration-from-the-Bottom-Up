#include <cstddef>
#include <vector>

// EventListener marker interface
class EventListener {
public:
    virtual ~EventListener() = default;
};

// Listener interfaces
class ActionListener : public EventListener { public: ~ActionListener() override = default; };
class AdjustmentListener : public EventListener { public: ~AdjustmentListener() override = default; };
class ComponentListener : public EventListener { public: ~ComponentListener() override = default; };
class ContainerListener : public EventListener { public: ~ContainerListener() override = default; };
class FocusListener : public EventListener { public: ~FocusListener() override = default; };
class HierarchyBoundsListener : public EventListener { public: ~HierarchyBoundsListener() override = default; };
class HierarchyListener : public EventListener { public: ~HierarchyListener() override = default; };
class InputMethodListener : public EventListener { public: ~InputMethodListener() override = default; };
class ItemListener : public EventListener { public: ~ItemListener() override = default; };
class KeyListener : public EventListener { public: ~KeyListener() override = default; };
class MouseListener : public EventListener { public: ~MouseListener() override = default; };
class MouseMotionListener : public EventListener { public: ~MouseMotionListener() override = default; };
class MouseWheelListener : public EventListener { public: ~MouseWheelListener() override = default; };
class TextListener : public EventListener { public: ~TextListener() override = default; };
class WindowFocusListener : public EventListener { public: ~WindowFocusListener() override = default; };
class WindowListener : public EventListener { public: ~WindowListener() override = default; };
class WindowStateListener : public EventListener { public: ~WindowStateListener() override = default; };

// Minimal equivalent of java.lang.Class
class Class {
public:
    Class() = default;
};

// AWTEventMulticaster equivalent
class AWTEventMulticaster {
public:
    template<typename L>
    static L* add(L* a, L* b) {
        if (a == nullptr) return b;
        if (b == nullptr) return a;
        return a;
    }

    template<typename L>
    static L* remove(L* a, L* b) {
        if (a == nullptr || b == nullptr) return a;
        if (a == b) return nullptr;
        return a;
    }

    static std::vector<EventListener*> getListeners(EventListener* l, Class /*p1*/) {
        if (l == nullptr) return {};
        return {l};
    }
};

// Test functions

void add_test_941(WindowListener* p0, WindowListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}
