#include <vector>
#include <string>
#include <array>
#include <algorithm>
#include <cstdint>
#include <stdexcept>

using ByteArray = std::vector<unsigned char>;

namespace {

const char* BASE64_CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const char* BASE64_URL_CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

const int* base64DecodeTable(bool isUrl) {
    static std::array<int, 256> stdTable;
    static std::array<int, 256> urlTable;
    static bool stdInit = false;
    static bool urlInit = false;

    if (isUrl) {
        if (!urlInit) {
            std::fill(urlTable.begin(), urlTable.end(), -1);
            for (int i = 0; i < 64; ++i) {
                urlTable[static_cast<unsigned char>(BASE64_URL_CHARS[i])] = i;
            }
            urlInit = true;
        }
        return urlTable.data();
    }

    if (!stdInit) {
        std::fill(stdTable.begin(), stdTable.end(), -1);
        for (int i = 0; i < 64; ++i) {
            stdTable[static_cast<unsigned char>(BASE64_CHARS[i])] = i;
        }
        stdInit = true;
    }
    return stdTable.data();
}

std::string base64Encode(const ByteArray& data, bool isUrl) {
    const char* chars = isUrl ? BASE64_URL_CHARS : BASE64_CHARS;
    std::string out;
    out.reserve(((data.size() + 2) / 3) * 4);

    size_t i = 0;
    while (i < data.size()) {
        uint32_t n = static_cast<uint32_t>(data[i]) << 16;
        if (i + 1 < data.size()) n |= static_cast<uint32_t>(data[i + 1]) << 8;
        if (i + 2 < data.size()) n |= static_cast<uint32_t>(data[i + 2]);

        out.push_back(chars[(n >> 18) & 63]);
        out.push_back(chars[(n >> 12) & 63]);
        out.push_back(i + 1 < data.size() ? chars[(n >> 6) & 63] : '=');
        out.push_back(i + 2 < data.size() ? chars[n & 63] : '=');
        i += 3;
    }
    return out;
}

ByteArray base64Decode(const std::string& src, bool isUrl, bool isMime) {
    const int* table = base64DecodeTable(isUrl);
    ByteArray out;
    int buffer = 0;
    int bits = 0;

    for (unsigned char c : src) {
        if (c == '=') continue;
        int v = table[c];
        if (v == -1) {
            if (isMime) continue;
            throw std::invalid_argument("Invalid Base64 character");
        }
        buffer = (buffer << 6) | v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back(static_cast<unsigned char>((buffer >> bits) & 0xFF));
        }
    }
    return out;
}

} // namespace

class Base64 {
public:
    class Encoder {
    public:
        Encoder(bool isUrl, bool isMime, int lineLength, ByteArray lineSeparator)
            : isUrl_(isUrl), isMime_(isMime), lineLength_(lineLength),
              lineSeparator_(std::move(lineSeparator)) {}

        std::string encodeToString(const ByteArray& data) const {
            std::string encoded = base64Encode(data, isUrl_);
            if (isMime_ && lineLength_ > 0 && !encoded.empty()) {
                std::string result;
                result.reserve(encoded.size() +
                               (encoded.size() / static_cast<size_t>(lineLength_)) *
                                   lineSeparator_.size());
                for (size_t i = 0; i < encoded.size(); i += static_cast<size_t>(lineLength_)) {
                    size_t len = std::min(static_cast<size_t>(lineLength_), encoded.size() - i);
                    result.append(encoded, i, len);
                    if (i + len < encoded.size()) {
                        result.append(lineSeparator_.begin(), lineSeparator_.end());
                    }
                }
                return result;
            }
            return encoded;
        }

        ByteArray encode(const ByteArray& data) const {
            std::string s = encodeToString(data);
            return ByteArray(s.begin(), s.end());
        }

    private:
        bool isUrl_;
        bool isMime_;
        int lineLength_;
        ByteArray lineSeparator_;
    };

    class Decoder {
    public:
        Decoder(bool isUrl, bool isMime)
            : isUrl_(isUrl), isMime_(isMime) {}

        ByteArray decode(const std::string& src) const {
            return base64Decode(src, isUrl_, isMime_);
        }

        ByteArray decode(const ByteArray& src) const {
            return decode(std::string(src.begin(), src.end()));
        }

    private:
        bool isUrl_;
        bool isMime_;
    };

    static Encoder getEncoder() {
        return Encoder(false, false, 0, {});
    }

    static Encoder getUrlEncoder() {
        return Encoder(true, false, 0, {});
    }

    static Encoder getMimeEncoder() {
        return Encoder(false, true, 76, ByteArray{'\r', '\n'});
    }

    static Encoder getMimeEncoder(int lineLength, const ByteArray& lineSeparator) {
        return Encoder(false, true, lineLength, lineSeparator);
    }

    static Decoder getDecoder() {
        return Decoder(false, false);
    }

    static Decoder getUrlDecoder() {
        return Decoder(true, false);
    }

    static Decoder getMimeDecoder() {
        return Decoder(false, true);
    }
};

void getEncoder_test_977() {
    Base64::getEncoder();
}
