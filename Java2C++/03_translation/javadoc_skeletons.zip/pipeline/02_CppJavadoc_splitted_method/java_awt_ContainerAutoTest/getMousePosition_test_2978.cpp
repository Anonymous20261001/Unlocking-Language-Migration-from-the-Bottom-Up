#include <vector>

class Object {
public:
    virtual ~Object() {}
};

class String {};

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
};

class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Point {
public:
    int x;
    int y;
    Point() : x(0), y(0) {}
};

class Font {};
class Graphics {};
class LayoutManager {
public:
    virtual ~LayoutManager() {}
};
class FocusTraversalPolicy {
public:
    virtual ~FocusTraversalPolicy() {}
};
class ComponentOrientation {};
class Event {};
class PrintStream {};
class PrintWriter {};
class Class {};
class Set {};

class PropertyChangeListener {
public:
    virtual ~PropertyChangeListener() {}
};

class ContainerListener {
public:
    virtual ~ContainerListener() {}
};

class Component : public Object {
public:
    Component() {}
    virtual ~Component() {}
};

class Container : public Component {
public:
    Container() {}
    virtual ~Container() {}

    void addPropertyChangeListener(PropertyChangeListener* p0) {
        (void)p0;
    }

    void addPropertyChangeListener(const String& p0, PropertyChangeListener* p1) {
        (void)p0;
        (void)p1;
    }

    void setFont(Font* p0) {
        (void)p0;
    }

    int getComponentCount() {
        return 0;
    }

    void paint(Graphics* p0) {
        (void)p0;
    }

    bool isFocusCycleRoot() {
        return false;
    }

    bool isFocusCycleRoot(Container* p0) {
        (void)p0;
        return false;
    }

    FocusTraversalPolicy* getFocusTraversalPolicy() {
        return nullptr;
    }

    void setFocusTraversalPolicy(FocusTraversalPolicy* p0) {
        (void)p0;
    }

    Dimension getPreferredSize() {
        return Dimension();
    }

    Dimension getMaximumSize() {
        return Dimension();
    }

    Dimension getMinimumSize() {
        return Dimension();
    }

    Insets getInsets() {
        return Insets();
    }

    float getAlignmentY() {
        return 0.0f;
    }

    float getAlignmentX() {
        return 0.0f;
    }

    void setFocusTraversalKeys(int p0, Set* p1) {
        (void)p0;
        (void)p1;
    }

    std::vector<void*> getListeners(Class* p0) {
        (void)p0;
        return std::vector<void*>();
    }

    void addNotify() {}

    void removeNotify() {}

    std::vector<Component*> getComponents() {
        return std::vector<Component*>();
    }

    Dimension preferredSize() {
        return Dimension();
    }

    Dimension minimumSize() {
        return Dimension();
    }

    Insets insets() {
        return Insets();
    }

    bool isValidateRoot() {
        return false;
    }

    int countComponents() {
        return 0;
    }

    int getComponentZOrder(Component* p0) {
        (void)p0;
        return -1;
    }

    void layout() {}

    void doLayout() {}

    Component* getComponentAt(Point* p0) {
        (void)p0;
        return nullptr;
    }

    Component* getComponentAt(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    void deliverEvent(Event* p0) {
        (void)p0;
    }

    Component* locate(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    Component* findComponentAt(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    Component* findComponentAt(Point* p0) {
        (void)p0;
        return nullptr;
    }

    bool isFocusTraversalPolicyProvider() {
        return false;
    }

    void applyComponentOrientation(ComponentOrientation* p0) {
        (void)p0;
    }

    void addContainerListener(ContainerListener* p0) {
        (void)p0;
    }

    LayoutManager* getLayout() {
        return nullptr;
    }

    void setComponentZOrder(Component* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void setLayout(LayoutManager* p0) {
        (void)p0;
    }

    void paintComponents(Graphics* p0) {
        (void)p0;
    }

    void printComponents(Graphics* p0) {
        (void)p0;
    }

    void removeContainerListener(ContainerListener* p0) {
        (void)p0;
    }

    std::vector<ContainerListener*> getContainerListeners() {
        return std::vector<ContainerListener*>();
    }

    Point* getMousePosition(bool p0) {
        (void)p0;
        return nullptr;
    }

    bool isAncestorOf(Component* p0) {
        (void)p0;
        return false;
    }

    Set* getFocusTraversalKeys(int p0) {
        (void)p0;
        return nullptr;
    }

    bool areFocusTraversalKeysSet(int p0) {
        (void)p0;
        return false;
    }

    bool isFocusTraversalPolicySet() {
        return false;
    }

    void setFocusCycleRoot(bool p0) {
        (void)p0;
    }

    void setFocusTraversalPolicyProvider(bool p0) {
        (void)p0;
    }

    void transferFocusDownCycle() {}

    void remove(int p0) {
        (void)p0;
    }

    void remove(Component* p0) {
        (void)p0;
    }

    void update(Graphics* p0) {
        (void)p0;
    }

    Component* add(Component* p0) {
        (void)p0;
        return p0;
    }

    Component* add(const String& p0, Component* p1) {
        (void)p0;
        return p1;
    }

    Component* add(Component* p0, Object* p1) {
        (void)p0;
        (void)p1;
        return p0;
    }

    Component* add(Component* p0, Object* p1, int p2) {
        (void)p0;
        (void)p1;
        (void)p2;
        return p0;
    }

    Component* add(Component* p0, int p1) {
        (void)p0;
        (void)p1;
        return p0;
    }

    void list(PrintWriter* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void list(PrintStream* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void validate() {}

    void print(Graphics* p0) {
        (void)p0;
    }

    void removeAll() {}

    Component* getComponent(int p0) {
        (void)p0;
        return nullptr;
    }

    void invalidate() {}
};

void getMousePosition_test_2978(bool p0) {
    (void)p0;
    Container instance;
    instance.getMousePosition(p0);
}
