#include <string>
#include <vector>

class ZoneId {
public:
    explicit ZoneId(const std::string& id) : id_(id) {}
    const std::string& getId() const { return id_; }
private:
    std::string id_;
};

class TimeZone {
public:
    static TimeZone getDefault() {
        return TimeZone(defaultID_, offsetOf(defaultID_));
    }

    static TimeZone getTimeZone(const std::string& id) {
        std::string normalized = id.empty() ? "GMT" : id;
        return TimeZone(normalized, offsetOf(normalized));
    }

    static TimeZone getTimeZone(const ZoneId& zoneId) {
        return getTimeZone(zoneId.getId());
    }

    static void setDefault(const TimeZone& zone) {
        defaultID_ = zone.getID();
    }

    static std::vector<std::string> getAvailableIDs() {
        std::vector<std::string> ids;
        for (const auto& tz : timezones_) {
            ids.push_back(std::string(tz.id));
        }
        return ids;
    }

    static std::vector<std::string> getAvailableIDs(int rawOffset) {
        std::vector<std::string> ids;
        for (const auto& tz : timezones_) {
            if (tz.offset == rawOffset) {
                ids.push_back(std::string(tz.id));
            }
        }
        return ids;
    }

    static std::vector<std::string> availableIDs() {
        return getAvailableIDs();
    }

    static std::vector<std::string> availableIDs(int rawOffset) {
        return getAvailableIDs(rawOffset);
    }

    const std::string& getID() const { return id_; }
    int getRawOffset() const { return rawOffset_; }

private:
    TimeZone(const std::string& id, int rawOffset) : id_(id), rawOffset_(rawOffset) {}

    static int offsetOf(const std::string& id) {
        for (const auto& tz : timezones_) {
            if (id == tz.id) {
                return tz.offset;
            }
        }
        return 0;
    }

    struct TimeZoneEntry {
        const char* id;
        int offset;
    };

    static const TimeZoneEntry timezones_[];
    static std::string defaultID_;
    std::string id_;
    int rawOffset_;
};

const TimeZone::TimeZoneEntry TimeZone::timezones_[] = {
    {"GMT", 0},
    {"UTC", 0},
    {"America/New_York", -5 * 3600 * 1000},
    {"America/Chicago", -6 * 3600 * 1000},
    {"America/Denver", -7 * 3600 * 1000},
    {"America/Los_Angeles", -8 * 3600 * 1000},
    {"Europe/London", 0},
    {"Europe/Paris", 1 * 3600 * 1000},
    {"Asia/Kolkata", (5 * 3600 + 30 * 60) * 1000},
    {"Asia/Tokyo", 9 * 3600 * 1000},
    {"Australia/Sydney", 10 * 3600 * 1000},
};

std::string TimeZone::defaultID_ = "GMT";

void getDefault_test_12901() {
    TimeZone::getDefault();
}

void getTimeZone_test_12902(std::string p0) {
    TimeZone::getTimeZone(p0);
}

void getTimeZone_test_12903(ZoneId p0) {
    TimeZone::getTimeZone(p0);
}

void setDefault_test_12904(TimeZone p0) {
    TimeZone::setDefault(p0);
}

void getAvailableIDs_test_12905() {
    TimeZone::getAvailableIDs();
}

void getAvailableIDs_test_12906(int p0) {
    TimeZone::getAvailableIDs(p0);
}

void availableIDs_test_12907(int p0) {
    TimeZone::availableIDs(p0);
}

void availableIDs_test_12908() {
    TimeZone::availableIDs();
}