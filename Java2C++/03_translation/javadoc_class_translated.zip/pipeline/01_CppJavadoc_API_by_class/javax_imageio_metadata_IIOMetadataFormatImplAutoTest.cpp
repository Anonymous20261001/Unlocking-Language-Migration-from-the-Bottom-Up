class IIOMetadataFormat {
public:
    virtual ~IIOMetadataFormat() = default;
};

class IIOMetadataFormatImpl : public IIOMetadataFormat {
public:
    static IIOMetadataFormat& getStandardFormatInstance() {
        static IIOMetadataFormatImpl instance;
        return instance;
    }

    virtual ~IIOMetadataFormatImpl() = default;

private:
    IIOMetadataFormatImpl() = default;
    IIOMetadataFormatImpl(const IIOMetadataFormatImpl&) = delete;
    IIOMetadataFormatImpl& operator=(const IIOMetadataFormatImpl&) = delete;
};

void getStandardFormatInstance_test_5555() {
    IIOMetadataFormatImpl::getStandardFormatInstance();
}