#include <map>
#include <memory>
#include <string>

class ExecutionEnv {
public:
    ExecutionEnv() = default;
};

using Map = std::map<std::string, std::string>;

class ExecutionControl {
public:
    virtual ~ExecutionControl() = default;
};

class LocalExecutionControl : public ExecutionControl {
};

class LocalExecutionControlProvider {
public:
    std::string name() {
        return "local";
    }

    std::string generate(const ExecutionEnv& env, const Map& parameters) {
        (void)env;
        (void)parameters;
        return "";
    }

    Map defaultParameters() {
        return Map();
    }

    std::unique_ptr<ExecutionControl> createExecutionControl(const ExecutionEnv& env, const Map& parameters) {
        (void)env;
        (void)parameters;
        return std::unique_ptr<ExecutionControl>(new LocalExecutionControl());
    }
};

void name_test_8076() {
    LocalExecutionControlProvider instance;
    instance.name();
}

void generate_test_8077(ExecutionEnv p0, Map p1) {
    LocalExecutionControlProvider instance;
    instance.generate(p0, p1);
}

void defaultParameters_test_8078() {
    LocalExecutionControlProvider instance;
    instance.defaultParameters();
}

void createExecutionControl_test_8079(ExecutionEnv p0, Map p1) {
    LocalExecutionControlProvider instance;
    instance.createExecutionControl(p0, p1);
}