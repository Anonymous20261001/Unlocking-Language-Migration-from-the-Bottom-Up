#include <string>

class TrustManagerFactory {
public:
    static std::string getDefaultAlgorithm() {
        // Equivalent to Java's default TLS trust manager algorithm
        return "PKIX";
    }
};

void getDefaultAlgorithm_test_13101() {
    TrustManagerFactory::getDefaultAlgorithm();
}