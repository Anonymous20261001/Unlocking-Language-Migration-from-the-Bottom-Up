#include <filesystem>
#include <string>
#include <utility>

class UnixDomainSocketAddress {
public:
    static UnixDomainSocketAddress of(const std::filesystem::path& path) {
        return UnixDomainSocketAddress(path.string());
    }

    static UnixDomainSocketAddress of(const std::string& pathname) {
        return UnixDomainSocketAddress(pathname);
    }

private:
    explicit UnixDomainSocketAddress(std::string path)
        : path_(std::move(path)) {}

    std::string path_;
};

void of_test_13210(std::filesystem::path p0) {
    UnixDomainSocketAddress::of(p0);
}

void of_test_13211(std::string p0) {
    UnixDomainSocketAddress::of(p0);
}