#include <string>
#include <stdexcept>

class Locale {
public:
    Locale() : language_("en"), country_(), variant_() {}
    explicit Locale(const std::string& language)
        : language_(language), country_(), variant_() {}
    Locale(const std::string& language, const std::string& country)
        : language_(language), country_(country), variant_() {}
    Locale(const std::string& language, const std::string& country,
           const std::string& variant)
        : language_(language), country_(country), variant_(variant) {}

    const std::string& getLanguage() const { return language_; }
    const std::string& getCountry() const { return country_; }
    const std::string& getVariant() const { return variant_; }

private:
    std::string language_;
    std::string country_;
    std::string variant_;
};

enum class DayOfWeek {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY
};

class WeekFields {
public:
    static WeekFields of(const Locale& locale) {
        const std::string& country = locale.getCountry();
        if (country == "US" || country == "CA") {
            return WeekFields(DayOfWeek::SUNDAY, 1);
        }
        return WeekFields(DayOfWeek::MONDAY, 4);
    }

    static WeekFields of(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek) {
        if (minimalDaysInFirstWeek < 1 || minimalDaysInFirstWeek > 7) {
            throw std::invalid_argument("minimalDaysInFirstWeek must be between 1 and 7");
        }
        return WeekFields(firstDayOfWeek, minimalDaysInFirstWeek);
    }

    DayOfWeek getFirstDayOfWeek() const { return firstDayOfWeek_; }
    int getMinimalDaysInFirstWeek() const { return minimalDaysInFirstWeek_; }

private:
    WeekFields(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek)
        : firstDayOfWeek_(firstDayOfWeek),
          minimalDaysInFirstWeek_(minimalDaysInFirstWeek) {}

    DayOfWeek firstDayOfWeek_;
    int minimalDaysInFirstWeek_;
};

void of_test_13452(Locale p0) {
    WeekFields::of(p0);
}

void of_test_13453(DayOfWeek p0, int p1) {
    WeekFields::of(p0, p1);
}