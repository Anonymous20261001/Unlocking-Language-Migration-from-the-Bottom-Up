#include <vector>

class Component {
public:
    Component() = default;
};

class DataFlavor {
public:
    DataFlavor() = default;
};

class Transferable {
public:
    virtual ~Transferable() = default;

    virtual std::vector<DataFlavor> getTransferDataFlavors() const {
        return std::vector<DataFlavor>();
    }

    virtual bool isDataFlavorSupported(const DataFlavor& flavor) const {
        (void)flavor;
        return false;
    }

    virtual void* getTransferData(const DataFlavor& flavor) const {
        (void)flavor;
        return nullptr;
    }
};

class DropLocation {
public:
    DropLocation() = default;
};

class TransferHandler {
public:
    static constexpr int NONE = 0;
    static constexpr int COPY = 1;
    static constexpr int MOVE = 2;
    static constexpr int LINK = 4;
    static constexpr int COPY_OR_MOVE = COPY | MOVE;

    class TransferSupport {
    public:
        TransferSupport(Component& component, Transferable& transferable)
            : component_(&component), transferable_(&transferable),
              isDrop_(false),
              sourceDropActions_(TransferHandler::COPY_OR_MOVE),
              userDropAction_(TransferHandler::COPY_OR_MOVE),
              dropAction_(TransferHandler::COPY_OR_MOVE),
              showDropLocation_(false) {}

        Transferable& getTransferable() {
            return *transferable_;
        }

        std::vector<DataFlavor> getDataFlavors() {
            return transferable_->getTransferDataFlavors();
        }

        DropLocation getDropLocation() {
            return DropLocation();
        }

        bool isDrop() {
            return isDrop_;
        }

        int getDropAction() {
            return dropAction_;
        }

        int getSourceDropActions() {
            return sourceDropActions_;
        }

        int getUserDropAction() {
            return userDropAction_;
        }

        void setShowDropLocation(bool show) {
            showDropLocation_ = show;
        }

        void setDropAction(int anAction) {
            dropAction_ = anAction;
        }

        bool isDataFlavorSupported(const DataFlavor& flavor) {
            return transferable_->isDataFlavorSupported(flavor);
        }

        Component& getComponent() {
            return *component_;
        }

    private:
        Component* component_;
        Transferable* transferable_;
        bool isDrop_;
        int sourceDropActions_;
        int userDropAction_;
        int dropAction_;
        bool showDropLocation_;
    };
};

void getTransferable_test_12948() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getTransferable();
}

void getDataFlavors_test_12949() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getDataFlavors();
}

void getDropLocation_test_12950() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getDropLocation();
}

void isDrop_test_12951() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.isDrop();
}

void getDropAction_test_12952() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getDropAction();
}

void getSourceDropActions_test_12953() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getSourceDropActions();
}

void getUserDropAction_test_12954() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getUserDropAction();
}

void setShowDropLocation_test_12955() {
    bool p0 = false;
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.setShowDropLocation(p0);
}

void setDropAction_test_12956() {
    int p0 = TransferHandler::COPY;
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.setDropAction(p0);
}

void isDataFlavorSupported_test_12957() {
    DataFlavor p0;
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.isDataFlavorSupported(p0);
}

void getComponent_test_12958() {
    Component c0;
    Transferable c1;
    TransferHandler::TransferSupport instance(c0, c1);
    instance.getComponent();
}