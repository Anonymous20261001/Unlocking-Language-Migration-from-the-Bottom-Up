class HttpURLConnection {
public:
    static bool followRedirects;
    static void setFollowRedirects(bool set) { followRedirects = set; }
    static bool getFollowRedirects() { return followRedirects; }
};

bool HttpURLConnection::followRedirects = true;

void setFollowRedirects_test_5493(bool p0) {
    HttpURLConnection::setFollowRedirects(p0);
}

void getFollowRedirects_test_5494() {
    HttpURLConnection::getFollowRedirects();
}