#include <string>
#include <unordered_map>
#include <stdexcept>
#include <climits>

class Level {
public:
    Level() : value_(0), name_("") {}
    Level(int value, const std::string& name) : value_(value), name_(name) {}

    static Level parse(const std::string& name) {
        static const std::unordered_map<std::string, int> nameToValue = {
            {"SEVERE", 1000},
            {"WARNING", 900},
            {"INFO", 800},
            {"CONFIG", 700},
            {"FINE", 500},
            {"FINER", 400},
            {"FINEST", 300},
            {"ALL", INT_MIN},
            {"OFF", INT_MAX}
        };

        auto it = nameToValue.find(name);
        if (it != nameToValue.end()) {
            return Level(it->second, name);
        }

        try {
            size_t pos = 0;
            int value = std::stoi(name, &pos);
            if (pos == name.size()) {
                return Level(value, name);
            }
        } catch (...) {
        }

        throw std::invalid_argument("Bad level name: " + name);
    }

    int intValue() const { return value_; }
    const std::string& getName() const { return name_; }

private:
    int value_;
    std::string name_;
};

void parse_test_7719(const std::string& p0) {
    Level::parse(p0);
}