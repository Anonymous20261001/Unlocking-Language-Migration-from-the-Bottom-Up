#include <vector>
#include <algorithm>

// Forward declarations
class Component;
class Cursor;
class Image;
class Point;
class Transferable;
class FlavorMap;
class DragGestureListener;
class DragSourceListener;
class DragSourceMotionListener;
class DragGestureEvent;
class DragGestureRecognizer;
class Class;

// Minimal placeholder classes
class Component {
public:
    virtual ~Component() = default;
};

class Cursor {
public:
    virtual ~Cursor() = default;
};

class Image {
public:
    virtual ~Image() = default;
};

class Point {
public:
    virtual ~Point() = default;
};

class Transferable {
public:
    virtual ~Transferable() = default;
};

class FlavorMap {
public:
    virtual ~FlavorMap() = default;
};

class DragGestureListener {
public:
    virtual ~DragGestureListener() = default;
};

class DragSourceListener {
public:
    virtual ~DragSourceListener() = default;
};

class DragSourceMotionListener {
public:
    virtual ~DragSourceMotionListener() = default;
};

class DragGestureEvent {
public:
    virtual ~DragGestureEvent() = default;
};

class DragGestureRecognizer {
public:
    virtual ~DragGestureRecognizer() = default;
};

class Class {
public:
    virtual ~Class() = default;
};

class DragSource {
public:
    DragSource() = default;
    ~DragSource() = default;

    void addDragSourceListener(DragSourceListener* l) {
        if (l) dragSourceListeners.push_back(l);
    }

    void removeDragSourceListener(DragSourceListener* l) {
        dragSourceListeners.erase(
            std::remove(dragSourceListeners.begin(), dragSourceListeners.end(), l),
            dragSourceListeners.end());
    }

    std::vector<DragSourceListener*> getDragSourceListeners() const {
        return dragSourceListeners;
    }

    void addDragSourceMotionListener(DragSourceMotionListener* l) {
        if (l) dragSourceMotionListeners.push_back(l);
    }

    void removeDragSourceMotionListener(DragSourceMotionListener* l) {
        dragSourceMotionListeners.erase(
            std::remove(dragSourceMotionListeners.begin(), dragSourceMotionListeners.end(), l),
            dragSourceMotionListeners.end());
    }

    std::vector<DragSourceMotionListener*> getDragSourceMotionListeners() const {
        return dragSourceMotionListeners;
    }

    static DragSource* getDefaultDragSource() {
        static DragSource instance;
        return &instance;
    }

    static bool isDragImageSupported() {
        return false;
    }

    static int getDragThreshold() {
        return 0;
    }

    DragGestureRecognizer* createDefaultDragGestureRecognizer(
        Component*, int, DragGestureListener*) {
        static DragGestureRecognizer dummy;
        return &dummy;
    }

    DragGestureRecognizer* createDragGestureRecognizer(
        Class*, Component*, int, DragGestureListener*) {
        static DragGestureRecognizer dummy;
        return &dummy;
    }

    std::vector<void*> getListeners(Class*) {
        return {};
    }

    void startDrag(DragGestureEvent*, Cursor*, Image*, Point*, Transferable*, DragSourceListener*) {
    }

    void startDrag(DragGestureEvent*, Cursor*, Transferable*, DragSourceListener*) {
    }

    void startDrag(DragGestureEvent*, Cursor*, Image*, Point*, Transferable*, DragSourceListener*, FlavorMap*) {
    }

    void startDrag(DragGestureEvent*, Cursor*, Transferable*, DragSourceListener*, FlavorMap*) {
    }

    FlavorMap* getFlavorMap() const {
        return nullptr;
    }

private:
    std::vector<DragSourceListener*> dragSourceListeners;
    std::vector<DragSourceMotionListener*> dragSourceMotionListeners;
};

// Test functions
void addDragSourceListener_test_4296(DragSourceListener* p0) {
    DragSource instance;
    instance.addDragSourceListener(p0);
}

void addDragSourceMotionListener_test_4297(DragSourceMotionListener* p0) {
    DragSource instance;
    instance.addDragSourceMotionListener(p0);
}

void getDefaultDragSource_test_4298() {
    DragSource::getDefaultDragSource();
}

void isDragImageSupported_test_4299() {
    DragSource::isDragImageSupported();
}

void createDefaultDragGestureRecognizer_test_4300(Component* p0, int p1, DragGestureListener* p2) {
    DragSource instance;
    instance.createDefaultDragGestureRecognizer(p0, p1, p2);
}

void removeDragSourceListener_test_4301(DragSourceListener* p0) {
    DragSource instance;
    instance.removeDragSourceListener(p0);
}

void getDragSourceListeners_test_4302() {
    DragSource instance;
    instance.getDragSourceListeners();
}

void removeDragSourceMotionListener_test_4303(DragSourceMotionListener* p0) {
    DragSource instance;
    instance.removeDragSourceMotionListener(p0);
}

void getDragSourceMotionListeners_test_4304() {
    DragSource instance;
    instance.getDragSourceMotionListeners();
}

void getDragThreshold_test_4305() {
    DragSource::getDragThreshold();
}

void getListeners_test_4306(Class* p0) {
    DragSource instance;
    instance.getListeners(p0);
}

void createDragGestureRecognizer_test_4307(Class* p0, Component* p1, int p2, DragGestureListener* p3) {
    DragSource instance;
    instance.createDragGestureRecognizer(p0, p1, p2, p3);
}

void startDrag_test_4308(DragGestureEvent* p0, Cursor* p1, Image* p2, Point* p3,
                         Transferable* p4, DragSourceListener* p5) {
    DragSource instance;
    instance.startDrag(p0, p1, p2, p3, p4, p5);
}

void startDrag_test_4309(DragGestureEvent* p0, Cursor* p1, Transferable* p2,
                         DragSourceListener* p3) {
    DragSource instance;
    instance.startDrag(p0, p1, p2, p3);
}

void startDrag_test_4310(DragGestureEvent* p0, Cursor* p1, Image* p2, Point* p3,
                         Transferable* p4, DragSourceListener* p5, FlavorMap* p6) {
    DragSource instance;
    instance.startDrag(p0, p1, p2, p3, p4, p5, p6);
}

void startDrag_test_4311(DragGestureEvent* p0, Cursor* p1, Transferable* p2,
                         DragSourceListener* p3, FlavorMap* p4) {
    DragSource instance;
    instance.startDrag(p0, p1, p2, p3, p4);
}

void getFlavorMap_test_4312() {
    DragSource instance;
    instance.getFlavorMap();
}
