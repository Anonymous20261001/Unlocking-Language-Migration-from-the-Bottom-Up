#include <cstdint>

class CollationElementIterator {
public:
    static int primaryOrder(int order) {
        return static_cast<int>((static_cast<uint32_t>(order) >> 16) & 0xFFFF);
    }

    static int secondaryOrder(int order) {
        return static_cast<int>((static_cast<uint32_t>(order) >> 8) & 0xFF);
    }

    static int tertiaryOrder(int order) {
        return static_cast<int>(static_cast<uint32_t>(order) & 0xFF);
    }
};

void primaryOrder_test_2346(int p0) {
    CollationElementIterator::primaryOrder(p0);
}

void secondaryOrder_test_2347(int p0) {
    CollationElementIterator::secondaryOrder(p0);
}

void tertiaryOrder_test_2348(int p0) {
    CollationElementIterator::tertiaryOrder(p0);
}