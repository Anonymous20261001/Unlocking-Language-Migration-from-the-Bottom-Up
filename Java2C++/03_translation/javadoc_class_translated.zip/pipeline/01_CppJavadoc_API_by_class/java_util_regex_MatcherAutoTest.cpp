#include <string>

class Matcher {
public:
    static std::string quoteReplacement(const std::string& s) {
        std::string result;
        result.reserve(s.size());
        for (char c : s) {
            if (c == '\\' || c == '$') {
                result += '\\';
            }
            result += c;
        }
        return result;
    }
};

void quoteReplacement_test_8295(const std::string& p0) {
    Matcher::quoteReplacement(p0);
}