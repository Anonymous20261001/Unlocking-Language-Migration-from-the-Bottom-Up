#include <vector>
#include <cstdint>

class ICC_Profile {
public:
    ICC_Profile() = default;

    static ICC_Profile getInstance(int p0) {
        (void)p0;
        return ICC_Profile();
    }

    static ICC_Profile getInstance(const std::vector<std::int8_t>& p0) {
        (void)p0;
        return ICC_Profile();
    }
};

void getInstance_test_5507(int p0) {
    ICC_Profile::getInstance(p0);
}

void getInstance_test_5508(std::vector<std::int8_t> p0) {
    ICC_Profile::getInstance(p0);
}