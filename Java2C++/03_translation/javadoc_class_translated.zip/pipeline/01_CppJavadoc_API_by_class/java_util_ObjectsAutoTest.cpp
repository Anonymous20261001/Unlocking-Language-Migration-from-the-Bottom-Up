#include <cstddef>
#include <functional>
#include <stdexcept>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <memory>
#include <typeinfo>
#include <cstring>

// Forward declarations
class Object;
class String;
class Comparator;
class Supplier;
class Objects;

// Base Object class (simplified)
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const { return this == &other; }
    virtual std::string toString() const { return typeid(*this).name(); }
    virtual size_t hashCode() const { return reinterpret_cast<size_t>(this); }
};

// String class (simplified wrapper around std::string)
class String : public Object {
private:
    std::string data_;
public:
    String() : data_() {}
    String(const char* s) : data_(s ? s : "") {}
    String(const std::string& s) : data_(s) {}
    String(const String& other) : data_(other.data_) {}
    
    const std::string& str() const { return data_; }
    size_t length() const { return data_.length(); }
    bool empty() const { return data_.empty(); }
    
    bool equals(const Object& other) const override {
        const String* s = dynamic_cast<const String*>(&other);
        return s && data_ == s->data_;
    }
    
    std::string toString() const override { return data_; }
    
    friend std::ostream& operator<<(std::ostream& os, const String& s) {
        os << s.data_;
        return os;
    }
};

// Comparator interface
class Comparator {
public:
    virtual ~Comparator() = default;
    virtual int compare(const Object& a, const Object& b) const = 0;
};

// Supplier interface
class Supplier {
public:
    virtual ~Supplier() = default;
    virtual Object* get() const = 0;
};

// Objects utility class
class Objects {
public:
    // checkIndex for int
    static int checkIndex(int index, int length) {
        if (index < 0 || index >= length) {
            throw std::out_of_range("Index out of bounds: " + std::to_string(index) + " for length " + std::to_string(length));
        }
        return index;
    }
    
    // checkIndex for long
    static long checkIndex(long index, long length) {
        if (index < 0 || index >= length) {
            throw std::out_of_range("Index out of bounds: " + std::to_string(index) + " for length " + std::to_string(length));
        }
        return index;
    }
    
    // compare using comparator
    template<typename T>
    static int compare(const T& a, const T& b, Comparator* c) {
        if (c == nullptr) {
            throw std::invalid_argument("Comparator cannot be null");
        }
        return c->compare(a, b);
    }
    
    // hash of array of objects
    static size_t hash(const std::vector<Object*>& objects) {
        size_t result = 1;
        for (Object* obj : objects) {
            result = 31 * result + (obj ? obj->hashCode() : 0);
        }
        return result;
    }
    
    // requireNonNull with supplier
    template<typename T>
    static T* requireNonNull(T* obj, Supplier* supplier) {
        if (obj == nullptr) {
            if (supplier == nullptr) {
                throw std::invalid_argument("Supplier cannot be null");
            }
            Object* msg = supplier->get();
            throw std::invalid_argument(msg ? msg->toString() : "null");
        }
        return obj;
    }
    
    // requireNonNull with string message
    template<typename T>
    static T* requireNonNull(T* obj, const String& message) {
        if (obj == nullptr) {
            throw std::invalid_argument(message.str());
        }
        return obj;
    }
    
    // requireNonNull simple
    template<typename T>
    static T* requireNonNull(T* obj) {
        if (obj == nullptr) {
            throw std::invalid_argument("Object is null");
        }
        return obj;
    }
    
    // checkFromToIndex for long
    static long checkFromToIndex(long fromIndex, long toIndex, long length) {
        if (fromIndex < 0 || toIndex < fromIndex || toIndex > length) {
            throw std::out_of_range("Range [" + std::to_string(fromIndex) + ", " + 
                                   std::to_string(toIndex) + ") out of bounds for length " + 
                                   std::to_string(length));
        }
        return toIndex - fromIndex;
    }
    
    // checkFromToIndex for int
    static int checkFromToIndex(int fromIndex, int toIndex, int length) {
        if (fromIndex < 0 || toIndex < fromIndex || toIndex > length) {
            throw std::out_of_range("Range [" + std::to_string(fromIndex) + ", " + 
                                   std::to_string(toIndex) + ") out of bounds for length " + 
                                   std::to_string(length));
        }
        return toIndex - fromIndex;
    }
    
    // checkFromIndexSize for int
    static int checkFromIndexSize(int fromIndex, int size, int length) {
        if (fromIndex < 0 || size < 0 || fromIndex > length - size) {
            throw std::out_of_range("Range [" + std::to_string(fromIndex) + ", " + 
                                   std::to_string(fromIndex + size) + ") out of bounds for length " + 
                                   std::to_string(length));
        }
        return fromIndex;
    }
    
    // checkFromIndexSize for long
    static long checkFromIndexSize(long fromIndex, long size, long length) {
        if (fromIndex < 0 || size < 0 || fromIndex > length - size) {
            throw std::out_of_range("Range [" + std::to_string(fromIndex) + ", " + 
                                   std::to_string(fromIndex + size) + ") out of bounds for length " + 
                                   std::to_string(length));
        }
        return fromIndex;
    }
    
    // deepEquals
    static bool deepEquals(Object* a, Object* b) {
        if (a == b) return true;
        if (a == nullptr || b == nullptr) return false;
        return a->equals(*b);
    }
    
    // toIdentityString
    static std::string toIdentityString(Object* obj) {
        if (obj == nullptr) return "null";
        std::stringstream ss;
        ss << obj;
        return ss.str();
    }
    
    // isNull
    static bool isNull(Object* obj) {
        return obj == nullptr;
    }
    
    // nonNull
    static bool nonNull(Object* obj) {
        return obj != nullptr;
    }
    
    // requireNonNullElse
    template<typename T>
    static T* requireNonNullElse(T* obj, T* defaultObj) {
        return obj != nullptr ? obj : requireNonNull(defaultObj);
    }
    
    // requireNonNullElseGet
    template<typename T>
    static T* requireNonNullElseGet(T* obj, Supplier* supplier) {
        if (obj != nullptr) return obj;
        if (supplier == nullptr) {
            throw std::invalid_argument("Supplier cannot be null");
        }
        T* result = dynamic_cast<T*>(supplier->get());
        return requireNonNull(result);
    }
};

// Test class
class java_util_ObjectsAutoTest {
public:
    // Test methods
    void checkIndex_test_9597(int p0, int p1) {
        Objects::checkIndex(p0, p1);
    }
    
    void checkIndex_test_9598(long p0, long p1) {
        Objects::checkIndex(p0, p1);
    }
    
    void compare_test_9599(Object* p0, Object* p1, Comparator* p2) {
        Objects::compare(*p0, *p1, p2);
    }
    
    void hash_test_9600(std::vector<Object*> p0) {
        Objects::hash(p0);
    }
    
    void requireNonNull_test_9601(Object* p0, Supplier* p1) {
        Objects::requireNonNull(p0, p1);
    }
    
    void requireNonNull_test_9602(Object* p0, String* p1) {
        Objects::requireNonNull(p0, *p1);
    }
    
    void requireNonNull_test_9603(Object* p0) {
        Objects::requireNonNull(p0);
    }
    
    void checkFromToIndex_test_9604(long p0, long p1, long p2) {
        Objects::checkFromToIndex(p0, p1, p2);
    }
    
    void checkFromToIndex_test_9605(int p0, int p1, int p2) {
        Objects::checkFromToIndex(p0, p1, p2);
    }
    
    void checkFromIndexSize_test_9606(int p0, int p1, int p2) {
        Objects::checkFromIndexSize(p0, p1, p2);
    }
    
    void checkFromIndexSize_test_9607(long p0, long p1, long p2) {
        Objects::checkFromIndexSize(p0, p1, p2);
    }
    
    void deepEquals_test_9608(Object* p0, Object* p1) {
        Objects::deepEquals(p0, p1);
    }
    
    void toIdentityString_test_9609(Object* p0) {
        Objects::toIdentityString(p0);
    }
    
    void isNull_test_9610(Object* p0) {
        Objects::isNull(p0);
    }
    
    void nonNull_test_9611(Object* p0) {
        Objects::nonNull(p0);
    }
    
    void requireNonNullElse_test_9612(Object* p0, Object* p1) {
        Objects::requireNonNullElse(p0, p1);
    }
    
    void requireNonNullElseGet_test_9613(Object* p0, Supplier* p1) {
        Objects::requireNonNullElseGet(p0, p1);
    }
};