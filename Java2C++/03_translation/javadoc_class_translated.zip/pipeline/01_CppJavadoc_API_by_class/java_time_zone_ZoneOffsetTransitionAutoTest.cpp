#include <stdexcept>

class LocalDateTime {
public:
    LocalDateTime(int year, int month, int day, int hour, int minute, int second, int nanoOfSecond)
        : year_(year), month_(month), day_(day), hour_(hour), minute_(minute), second_(second), nanoOfSecond_(nanoOfSecond) {}

private:
    int year_;
    int month_;
    int day_;
    int hour_;
    int minute_;
    int second_;
    int nanoOfSecond_;
};

class ZoneOffset {
public:
    explicit ZoneOffset(int totalSeconds) : totalSeconds_(totalSeconds) {}

    bool operator==(const ZoneOffset& other) const {
        return totalSeconds_ == other.totalSeconds_;
    }

    bool operator!=(const ZoneOffset& other) const {
        return !(*this == other);
    }

    int totalSeconds() const {
        return totalSeconds_;
    }

private:
    int totalSeconds_;
};

class ZoneOffsetTransition {
public:
    ZoneOffsetTransition(const LocalDateTime& transition, const ZoneOffset& offsetBefore, const ZoneOffset& offsetAfter)
        : transition_(transition), offsetBefore_(offsetBefore), offsetAfter_(offsetAfter) {}

    static ZoneOffsetTransition of(const LocalDateTime& transition, const ZoneOffset& offsetBefore, const ZoneOffset& offsetAfter) {
        if (offsetBefore == offsetAfter) {
            throw std::invalid_argument("Offsets must not be equal");
        }
        return ZoneOffsetTransition(transition, offsetBefore, offsetAfter);
    }

private:
    LocalDateTime transition_;
    ZoneOffset offsetBefore_;
    ZoneOffset offsetAfter_;
};

void of_test_13734() {
    LocalDateTime p0(2020, 1, 1, 0, 0, 0, 0);
    ZoneOffset p1(0);
    ZoneOffset p2(3600);
    ZoneOffsetTransition::of(p0, p1, p2);
}