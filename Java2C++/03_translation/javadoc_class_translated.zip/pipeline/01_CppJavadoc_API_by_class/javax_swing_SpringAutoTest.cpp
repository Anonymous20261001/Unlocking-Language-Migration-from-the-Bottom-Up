#include <algorithm>

class Component {
public:
    virtual ~Component() = default;
};

class Spring {
public:
    explicit Spring(int value = 0) : value_(value) {}

    int getValue() const { return value_; }

    static Spring height(Component*) {
        return Spring(0);
    }

    static Spring max(const Spring& s1, const Spring& s2) {
        return Spring(std::max(s1.getValue(), s2.getValue()));
    }

    static Spring scale(const Spring& s, float factor) {
        return Spring(static_cast<int>(s.getValue() * factor));
    }

    static Spring constant(int pref) {
        return Spring(pref);
    }

    static Spring constant(int min, int pref, int max) {
        return Spring(pref);
    }

    static Spring sum(const Spring& s1, const Spring& s2) {
        return Spring(s1.getValue() + s2.getValue());
    }

    static Spring width(Component*) {
        return Spring(0);
    }

    static Spring minus(const Spring& s) {
        return Spring(-s.getValue());
    }

private:
    int value_;
};

void height_test_11360() {
    Component c;
    Spring::height(&c);
}

void max_test_11361() {
    Spring s0 = Spring::constant(1);
    Spring s1 = Spring::constant(2);
    Spring::max(s0, s1);
}

void scale_test_11362() {
    Spring s = Spring::constant(10);
    Spring::scale(s, 0.5f);
}

void constant_test_11363() {
    Spring::constant(42);
}

void constant_test_11364() {
    Spring::constant(10, 20, 30);
}

void sum_test_11365() {
    Spring s0 = Spring::constant(1);
    Spring s1 = Spring::constant(2);
    Spring::sum(s0, s1);
}

void width_test_11366() {
    Component c;
    Spring::width(&c);
}

void minus_test_11367() {
    Spring s = Spring::constant(5);
    Spring::minus(s);
}