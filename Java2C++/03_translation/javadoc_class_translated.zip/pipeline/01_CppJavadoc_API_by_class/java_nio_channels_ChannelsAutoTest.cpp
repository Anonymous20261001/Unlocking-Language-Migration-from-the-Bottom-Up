#include <string>

struct ReadableByteChannel {};
struct WritableByteChannel {};
struct AsynchronousByteChannel {};
struct CharsetDecoder {};
struct CharsetEncoder {};
struct Charset {};
struct InputStream {};
struct OutputStream {};
struct Reader {};
struct Writer {};

class Channels {
public:
  static Reader newReader(ReadableByteChannel&, CharsetDecoder&, int) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, Charset&) {
    return Reader{};
  }

  static Reader newReader(ReadableByteChannel&, const std::string&) {
    return Reader{};
  }

  static OutputStream newOutputStream(AsynchronousByteChannel&) {
    return OutputStream{};
  }

  static OutputStream newOutputStream(WritableByteChannel&) {
    return OutputStream{};
  }

  static Writer newWriter(WritableByteChannel&, CharsetEncoder&, int) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, const std::string&) {
    return Writer{};
  }

  static Writer newWriter(WritableByteChannel&, Charset&) {
    return Writer{};
  }

  static InputStream newInputStream(ReadableByteChannel&) {
    return InputStream{};
  }

  static InputStream newInputStream(AsynchronousByteChannel&) {
    return InputStream{};
  }

  static ReadableByteChannel newChannel(InputStream&) {
    return ReadableByteChannel{};
  }

  static WritableByteChannel newChannel(OutputStream&) {
    return WritableByteChannel{};
  }
};

void newReader_test_2112(ReadableByteChannel& p0, CharsetDecoder& p1, int p2) {
  Channels::newReader(p0, p1, p2);
}

void newReader_test_2113(ReadableByteChannel& p0, Charset& p1) {
  Channels::newReader(p0, p1);
}

void newReader_test_2114(ReadableByteChannel& p0, const std::string& p1) {
  Channels::newReader(p0, p1);
}

void newOutputStream_test_2115(AsynchronousByteChannel& p0) {
  Channels::newOutputStream(p0);
}

void newOutputStream_test_2116(WritableByteChannel& p0) {
  Channels::newOutputStream(p0);
}

void newWriter_test_2117(WritableByteChannel& p0, CharsetEncoder& p1, int p2) {
  Channels::newWriter(p0, p1, p2);
}

void newWriter_test_2118(WritableByteChannel& p0, const std::string& p1) {
  Channels::newWriter(p0, p1);
}

void newWriter_test_2119(WritableByteChannel& p0, Charset& p1) {
  Channels::newWriter(p0, p1);
}

void newInputStream_test_2120(ReadableByteChannel& p0) {
  Channels::newInputStream(p0);
}

void newInputStream_test_2121(AsynchronousByteChannel& p0) {
  Channels::newInputStream(p0);
}

void newChannel_test_2122(InputStream& p0) {
  Channels::newChannel(p0);
}

void newChannel_test_2123(OutputStream& p0) {
  Channels::newChannel(p0);
}