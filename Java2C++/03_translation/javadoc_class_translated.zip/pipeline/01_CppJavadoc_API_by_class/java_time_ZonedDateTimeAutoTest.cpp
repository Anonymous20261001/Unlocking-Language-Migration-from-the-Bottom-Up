#include <string>
#include <chrono>
#include <stdexcept>
#include <memory>

namespace java {
namespace time {

class ZoneOffset;
class ZoneId;
class LocalDate;
class LocalTime;
class LocalDateTime;
class Instant;
class Clock;
class TemporalAccessor;
class DateTimeFormatter;
class ZonedDateTime;

// Forward declarations for internal use
class ZoneOffset {
public:
    int totalSeconds;
    ZoneOffset() : totalSeconds(0) {}
    ZoneOffset(int seconds) : totalSeconds(seconds) {}
    static ZoneOffset UTC;
    static ZoneOffset ofTotalSeconds(int seconds) { return ZoneOffset(seconds); }
    bool operator==(const ZoneOffset& other) const { return totalSeconds == other.totalSeconds; }
};

class ZoneId {
public:
    std::string id;
    ZoneId() : id("UTC") {}
    ZoneId(const std::string& zoneId) : id(zoneId) {}
    static ZoneId systemDefault() { return ZoneId("SystemDefault"); }
    static ZoneId of(const std::string& zoneId) { return ZoneId(zoneId); }
    bool operator==(const ZoneId& other) const { return id == other.id; }
};

class LocalDate {
public:
    int year;
    int month;
    int day;
    LocalDate() : year(1970), month(1), day(1) {}
    LocalDate(int y, int m, int d) : year(y), month(m), day(d) {}
    static LocalDate now() { return LocalDate(); }
    static LocalDate of(int year, int month, int day) { return LocalDate(year, month, day); }
    bool operator==(const LocalDate& other) const { return year == other.year && month == other.month && day == other.day; }
};

class LocalTime {
public:
    int hour;
    int minute;
    int second;
    int nano;
    LocalTime() : hour(0), minute(0), second(0), nano(0) {}
    LocalTime(int h, int m, int s, int n = 0) : hour(h), minute(m), second(s), nano(n) {}
    static LocalTime now() { return LocalTime(); }
    static LocalTime of(int hour, int minute, int second = 0, int nano = 0) { return LocalTime(hour, minute, second, nano); }
    bool operator==(const LocalTime& other) const { return hour == other.hour && minute == other.minute && second == other.second && nano == other.nano; }
};

class LocalDateTime {
public:
    LocalDate date;
    LocalTime time;
    LocalDateTime() : date(), time() {}
    LocalDateTime(const LocalDate& d, const LocalTime& t) : date(d), time(t) {}
    LocalDateTime(int year, int month, int day, int hour, int minute, int second = 0, int nano = 0) 
        : date(year, month, day), time(hour, minute, second, nano) {}
    static LocalDateTime now() { return LocalDateTime(); }
    static LocalDateTime of(const LocalDate& date, const LocalTime& time) { return LocalDateTime(date, time); }
    static LocalDateTime of(int year, int month, int day, int hour, int minute, int second = 0, int nano = 0) {
        return LocalDateTime(year, month, day, hour, minute, second, nano);
    }
    LocalDate toLocalDate() const { return date; }
    LocalTime toLocalTime() const { return time; }
    bool operator==(const LocalDateTime& other) const { return date == other.date && time == other.time; }
};

class Instant {
public:
    std::chrono::system_clock::time_point tp;
    Instant() : tp(std::chrono::system_clock::now()) {}
    explicit Instant(const std::chrono::system_clock::time_point& t) : tp(t) {}
    static Instant now() { return Instant(); }
    static Instant ofEpochSecond(long long seconds) {
        return Instant(std::chrono::system_clock::time_point(std::chrono::seconds(seconds)));
    }
    static Instant ofEpochMilli(long long millis) {
        return Instant(std::chrono::system_clock::time_point(std::chrono::milliseconds(millis)));
    }
};

class Clock {
public:
    virtual ~Clock() = default;
    virtual Instant instant() const { return Instant::now(); }
    virtual ZoneId getZone() const { return ZoneId::systemDefault(); }
    static Clock systemUTC() { return Clock(); }
    static Clock systemDefaultZone() { return Clock(); }
};

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
    virtual bool isSupported() const { return true; }
};

class DateTimeFormatter {
public:
    std::string pattern;
    DateTimeFormatter() : pattern("") {}
    explicit DateTimeFormatter(const std::string& p) : pattern(p) {}
    static DateTimeFormatter ofPattern(const std::string& pattern) { return DateTimeFormatter(pattern); }
    static DateTimeFormatter ISO_ZONED_DATE_TIME() { return DateTimeFormatter("ISO_ZONED_DATE_TIME"); }
};

class ZonedDateTime {
public:
    LocalDateTime dateTime;
    ZoneId zone;
    ZoneOffset offset;

    ZonedDateTime() : dateTime(), zone(), offset() {}
    ZonedDateTime(const LocalDateTime& dt, const ZoneId& z, const ZoneOffset& o) 
        : dateTime(dt), zone(z), offset(o) {}

    static ZonedDateTime ofLocal(const LocalDateTime& localDateTime, const ZoneId& zone, const ZoneOffset& preferredOffset) {
        return ZonedDateTime(localDateTime, zone, preferredOffset);
    }

    static ZonedDateTime ofStrict(const LocalDateTime& localDateTime, const ZoneOffset& offset, const ZoneId& zone) {
        return ZonedDateTime(localDateTime, zone, offset);
    }

    static ZonedDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond, const ZoneId& zone) {
        LocalDateTime dt(year, month, dayOfMonth, hour, minute, second, nanoOfSecond);
        return ZonedDateTime(dt, zone, ZoneOffset::UTC);
    }

    static ZonedDateTime of(const LocalDate& date, const LocalTime& time, const ZoneId& zone) {
        LocalDateTime dt(date, time);
        return ZonedDateTime(dt, zone, ZoneOffset::UTC);
    }

    static ZonedDateTime of(const LocalDateTime& localDateTime, const ZoneId& zone) {
        return ZonedDateTime(localDateTime, zone, ZoneOffset::UTC);
    }

    static ZonedDateTime from(const TemporalAccessor& temporal) {
        return ZonedDateTime();
    }

    static ZonedDateTime parse(const std::string& text, const DateTimeFormatter& formatter) {
        return ZonedDateTime();
    }

    static ZonedDateTime parse(const std::string& text) {
        return ZonedDateTime();
    }

    static ZonedDateTime now() {
        return ZonedDateTime();
    }

    static ZonedDateTime now(const Clock& clock) {
        return ZonedDateTime();
    }

    static ZonedDateTime now(const ZoneId& zone) {
        return ZonedDateTime();
    }

    static ZonedDateTime ofInstant(const LocalDateTime& localDateTime, const ZoneOffset& offset, const ZoneId& zone) {
        return ZonedDateTime(localDateTime, zone, offset);
    }

    static ZonedDateTime ofInstant(const Instant& instant, const ZoneId& zone) {
        return ZonedDateTime();
    }
};

ZoneOffset ZoneOffset::UTC = ZoneOffset(0);

} // namespace time
} // namespace java

// Test functions
void ofLocal_test_13709(java::time::LocalDateTime p0, java::time::ZoneId p1, java::time::ZoneOffset p2) {
    java::time::ZonedDateTime::ofLocal(p0, p1, p2);
}

void ofStrict_test_13710(java::time::LocalDateTime p0, java::time::ZoneOffset p1, java::time::ZoneId p2) {
    java::time::ZonedDateTime::ofStrict(p0, p1, p2);
}

void of_test_13711(int p0, int p1, int p2, int p3, int p4, int p5, int p6, java::time::ZoneId p7) {
    java::time::ZonedDateTime::of(p0, p1, p2, p3, p4, p5, p6, p7);
}

void of_test_13712(java::time::LocalDate p0, java::time::LocalTime p1, java::time::ZoneId p2) {
    java::time::ZonedDateTime::of(p0, p1, p2);
}

void of_test_13713(java::time::LocalDateTime p0, java::time::ZoneId p1) {
    java::time::ZonedDateTime::of(p0, p1);
}

void from_test_13714(java::time::TemporalAccessor p0) {
    java::time::ZonedDateTime::from(p0);
}

void parse_test_13715(std::string p0, java::time::DateTimeFormatter p1) {
    java::time::ZonedDateTime::parse(p0, p1);
}

void parse_test_13716(std::string p0) {
    java::time::ZonedDateTime::parse(p0);
}

void now_test_13717() {
    java::time::ZonedDateTime::now();
}

void now_test_13718(java::time::Clock p0) {
    java::time::ZonedDateTime::now(p0);
}

void now_test_13719(java::time::ZoneId p0) {
    java::time::ZonedDateTime::now(p0);
}

void ofInstant_test_13720(java::time::LocalDateTime p0, java::time::ZoneOffset p1, java::time::ZoneId p2) {
    java::time::ZonedDateTime::ofInstant(p0, p1, p2);
}

void ofInstant_test_13721(java::time::Instant p0, java::time::ZoneId p1) {
    java::time::ZonedDateTime::ofInstant(p0, p1);
}