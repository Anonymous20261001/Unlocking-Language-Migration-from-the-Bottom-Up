#include <string>

class InetSocketAddress {
public:
    InetSocketAddress() : host_("localhost"), port_(0) {}
    InetSocketAddress(const std::string& host, int port) : host_(host), port_(port) {}

    const std::string& getHost() const { return host_; }
    int getPort() const { return port_; }

private:
    std::string host_;
    int port_;
};

class ProxySelector {
public:
    static ProxySelector* of(const InetSocketAddress& address) {
        return new ProxySelector(address);
    }

    static ProxySelector* getDefault() {
        return default_;
    }

    static void setDefault(ProxySelector* selector) {
        default_ = selector;
    }

    virtual ~ProxySelector() = default;

private:
    explicit ProxySelector(const InetSocketAddress& addr) : address_(addr) {}

    InetSocketAddress address_;
    static ProxySelector* default_;
};

ProxySelector* ProxySelector::default_ = nullptr;

void of_test_10219() {
    InetSocketAddress p0;
    ProxySelector::of(p0);
}

void getDefault_test_10220() {
    ProxySelector::getDefault();
}

void setDefault_test_10221() {
    InetSocketAddress p0("127.0.0.1", 8080);
    ProxySelector* sel = ProxySelector::of(p0);
    ProxySelector::setDefault(sel);
}
