#include <string>
#include <cstddef>

class CharSequence {
    std::string data;
public:
    CharSequence() = default;
    CharSequence(const std::string& s) : data(s) {}
    size_t length() const { return data.size(); }
    char charAt(size_t index) const { return data[index]; }
    const std::string& str() const { return data; }
};

namespace java_text {
class Normalizer {
public:
    enum class Form {
        NFD, NFC, NFKD, NFKC
    };

    static std::string normalize(const CharSequence& charSequence, Form form) {
        return charSequence.str();
    }

    static bool isNormalized(const CharSequence& charSequence, Form form) {
        return true;
    }
};
}

void normalize_test_9529(const CharSequence& p0, java_text::Normalizer::Form p1) {
    java_text::Normalizer::normalize(p0, p1);
}

void isNormalized_test_9530(const CharSequence& p0, java_text::Normalizer::Form p1) {
    java_text::Normalizer::isNormalized(p0, p1);
}