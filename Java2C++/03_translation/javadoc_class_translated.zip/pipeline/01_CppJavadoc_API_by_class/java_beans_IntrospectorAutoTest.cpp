#include <string>
#include <vector>
#include <cctype>

class Class {};

class Introspector {
public:
    static std::vector<std::string> getBeanInfoSearchPath() {
        return searchPath;
    }

    static void setBeanInfoSearchPath(const std::vector<std::string>& path) {
        searchPath = path;
    }

    static void flushCaches() {
        // No cache maintained.
    }

    static void flushFromCaches(const Class& clz) {
        (void)clz; // No cache maintained.
    }

    static std::string decapitalize(const std::string& name) {
        if (name.empty()) return name;

        if (name.size() >= 2 &&
            std::isupper(static_cast<unsigned char>(name[0])) &&
            std::isupper(static_cast<unsigned char>(name[1]))) {
            return name;
        }

        std::string result = name;
        result[0] = static_cast<char>(
            std::tolower(static_cast<unsigned char>(name[0])));
        return result;
    }

private:
    static std::vector<std::string> searchPath;
};

std::vector<std::string> Introspector::searchPath;

void getBeanInfoSearchPath_test_5924() {
    Introspector::getBeanInfoSearchPath();
}

void setBeanInfoSearchPath_test_5925(std::vector<std::string> p0) {
    Introspector::setBeanInfoSearchPath(p0);
}

void flushCaches_test_5926() {
    Introspector::flushCaches();
}

void flushFromCaches_test_5927(Class p0) {
    Introspector::flushFromCaches(p0);
}

void decapitalize_test_5928(std::string p0) {
    Introspector::decapitalize(p0);
}
