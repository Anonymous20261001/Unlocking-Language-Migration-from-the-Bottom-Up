#include <cstddef>

class Class {
public:
    Class() = default;
    Class(const Class&) = default;
    Class& operator=(const Class&) = default;
};

class MethodType {
public:
    MethodType() = default;
    MethodType(const MethodType&) = default;
    MethodType& operator=(const MethodType&) = default;
};

class MethodHandle {
public:
    MethodHandle() = default;
    MethodHandle(const MethodHandle&) = default;
    MethodHandle& operator=(const MethodHandle&) = default;
};

class LinkerServices {
public:
    LinkerServices() = default;
    LinkerServices(const LinkerServices&) = default;
    LinkerServices& operator=(const LinkerServices&) = default;
};

class Object {
public:
    Object() = default;
    Object(const Object&) = default;
    Object& operator=(const Object&) = default;
};

class Guards {
public:
    static MethodHandle isInstance(Class, MethodType) {
        return MethodHandle();
    }

    static MethodHandle isInstance(Class, int, MethodType) {
        return MethodHandle();
    }

    static MethodHandle isArray(int, MethodType) {
        return MethodHandle();
    }

    static MethodHandle asType(LinkerServices, MethodHandle, MethodType) {
        return MethodHandle();
    }

    static MethodHandle asType(MethodHandle, MethodType) {
        return MethodHandle();
    }

    static MethodHandle isNull() {
        return MethodHandle();
    }

    static MethodHandle isOfClass(Class, MethodType) {
        return MethodHandle();
    }

    static MethodHandle isNotNull() {
        return MethodHandle();
    }

    static MethodHandle getClassGuard(Class) {
        return MethodHandle();
    }

    static MethodHandle getInstanceOfGuard(Class) {
        return MethodHandle();
    }

    static MethodHandle getIdentityGuard(Object) {
        return MethodHandle();
    }
};

void isInstance_test_5248(Class p0, MethodType p1) {
    Guards::isInstance(p0, p1);
}

void isInstance_test_5249(Class p0, int p1, MethodType p2) {
    Guards::isInstance(p0, p1, p2);
}

void isArray_test_5250(int p0, MethodType p1) {
    Guards::isArray(p0, p1);
}

void asType_test_5251(LinkerServices p0, MethodHandle p1, MethodType p2) {
    Guards::asType(p0, p1, p2);
}

void asType_test_5252(MethodHandle p0, MethodType p1) {
    Guards::asType(p0, p1);
}

void isNull_test_5253() {
    Guards::isNull();
}

void isOfClass_test_5254(Class p0, MethodType p1) {
    Guards::isOfClass(p0, p1);
}

void isNotNull_test_5255() {
    Guards::isNotNull();
}

void getClassGuard_test_5256(Class p0) {
    Guards::getClassGuard(p0);
}

void getInstanceOfGuard_test_5257(Class p0) {
    Guards::getInstanceOfGuard(p0);
}

void getIdentityGuard_test_5258(Object p0) {
    Guards::getIdentityGuard(p0);
}