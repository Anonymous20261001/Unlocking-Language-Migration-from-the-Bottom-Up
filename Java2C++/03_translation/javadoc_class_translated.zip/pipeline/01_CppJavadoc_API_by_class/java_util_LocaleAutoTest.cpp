#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <stdexcept>
#include <functional>
#include <algorithm>
#include <cctype>

namespace java {
namespace lang {
class String {
public:
    std::string value;
    String() : value("") {}
    String(const std::string& s) : value(s) {}
    String(const char* s) : value(s) {}
    String(const String& other) : value(other.value) {}
    String& operator=(const String& other) { value = other.value; return *this; }
    bool operator==(const String& other) const { return value == other.value; }
    bool operator!=(const String& other) const { return value != other.value; }
    bool operator<(const String& other) const { return value < other.value; }
    size_t length() const { return value.length(); }
    bool isEmpty() const { return value.empty(); }
    char charAt(size_t index) const { return value.at(index); }
    String substring(size_t beginIndex) const { return String(value.substr(beginIndex)); }
    String substring(size_t beginIndex, size_t endIndex) const { return String(value.substr(beginIndex, endIndex - beginIndex)); }
    String toLowerCase() const {
        std::string result = value;
        std::transform(result.begin(), result.end(), result.begin(), ::tolower);
        return String(result);
    }
    String toUpperCase() const {
        std::string result = value;
        std::transform(result.begin(), result.end(), result.begin(), ::toupper);
        return String(result);
    }
    String trim() const {
        size_t start = value.find_first_not_of(" \t\n\r\f\v");
        if (start == std::string::npos) return String("");
        size_t end = value.find_last_not_of(" \t\n\r\f\v");
        return String(value.substr(start, end - start + 1));
    }
    bool startsWith(const String& prefix) const { return value.rfind(prefix.value, 0) == 0; }
    bool endsWith(const String& suffix) const {
        if (suffix.value.length() > value.length()) return false;
        return value.compare(value.length() - suffix.value.length(), suffix.value.length(), suffix.value) == 0;
    }
    int indexOf(const String& str) const { return value.find(str.value); }
    int indexOf(char ch) const { return value.find(ch); }
    int lastIndexOf(const String& str) const { return value.rfind(str.value); }
    int lastIndexOf(char ch) const { return value.rfind(ch); }
    std::vector<String> split(const String& regex) const {
        std::vector<String> result;
        std::string delimiter = regex.value;
        size_t start = 0;
        size_t end = value.find(delimiter);
        while (end != std::string::npos) {
            result.push_back(String(value.substr(start, end - start)));
            start = end + delimiter.length();
            end = value.find(delimiter, start);
        }
        result.push_back(String(value.substr(start)));
        return result;
    }
    static String valueOf(int i) { return String(std::to_string(i)); }
    static String valueOf(long l) { return String(std::to_string(l)); }
    static String valueOf(double d) { return String(std::to_string(d)); }
    static String valueOf(bool b) { return String(b ? "true" : "false"); }
    static String valueOf(char c) { return String(1, c); }
    static String valueOf(const String& s) { return s; }
    static String format(const String& format, ...) { return format; }
    friend std::ostream& operator<<(std::ostream& os, const String& s) { os << s.value; return os; }
};

class Object {
public:
    virtual ~Object() {}
    virtual String toString() const { return String("Object"); }
    virtual bool equals(const Object& other) const { return this == &other; }
    virtual int hashCode() const { return 0; }
};
} // namespace lang

namespace util {
class Collection {
public:
    virtual ~Collection() {}
    virtual int size() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool contains(const lang::String& element) const = 0;
    virtual void add(const lang::String& element) = 0;
    virtual void remove(const lang::String& element) = 0;
    virtual void clear() = 0;
};

class List : public Collection {
public:
    virtual lang::String get(int index) const = 0;
    virtual void set(int index, const lang::String& element) = 0;
    virtual void add(int index, const lang::String& element) = 0;
    virtual lang::String removeAt(int index) = 0;
    virtual int indexOf(const lang::String& element) const = 0;
    virtual int lastIndexOf(const lang::String& element) const = 0;
};

class ArrayList : public List {
private:
    std::vector<lang::String> elements;
public:
    ArrayList() {}
    ArrayList(const std::vector<lang::String>& elems) : elements(elems) {}
    int size() const override { return elements.size(); }
    bool isEmpty() const override { return elements.empty(); }
    bool contains(const lang::String& element) const override {
        return std::find(elements.begin(), elements.end(), element) != elements.end();
    }
    void add(const lang::String& element) override { elements.push_back(element); }
    void remove(const lang::String& element) override {
        auto it = std::find(elements.begin(), elements.end(), element);
        if (it != elements.end()) elements.erase(it);
    }
    void clear() override { elements.clear(); }
    lang::String get(int index) const override { return elements.at(index); }
    void set(int index, const lang::String& element) override { elements.at(index) = element; }
    void add(int index, const lang::String& element) override {
        elements.insert(elements.begin() + index, element);
    }
    lang::String removeAt(int index) override {
        lang::String result = elements.at(index);
        elements.erase(elements.begin() + index);
        return result;
    }
    int indexOf(const lang::String& element) const override {
        auto it = std::find(elements.begin(), elements.end(), element);
        return it != elements.end() ? std::distance(elements.begin(), it) : -1;
    }
    int lastIndexOf(const lang::String& element) const override {
        auto it = std::find(elements.rbegin(), elements.rend(), element);
        return it != elements.rend() ? elements.size() - 1 - std::distance(elements.rbegin(), it) : -1;
    }
    std::vector<lang::String>& getElements() { return elements; }
    const std::vector<lang::String>& getElements() const { return elements; }
};

class HashSet : public Collection {
private:
    std::set<lang::String> elements;
public:
    HashSet() {}
    HashSet(const std::vector<lang::String>& elems) : elements(elems.begin(), elems.end()) {}
    int size() const override { return elements.size(); }
    bool isEmpty() const override { return elements.empty(); }
    bool contains(const lang::String& element) const override {
        return elements.find(element) != elements.end();
    }
    void add(const lang::String& element) override { elements.insert(element); }
    void remove(const lang::String& element) override { elements.erase(element); }
    void clear() override { elements.clear(); }
    std::set<lang::String>& getElements() { return elements; }
    const std::set<lang::String>& getElements() const { return elements; }
};

class Locale {
public:
    enum class Category {
        DISPLAY,
        FORMAT
    };

    enum class FilteringMode {
        AUTOSELECT_FILTERING,
        EXTENDED_FILTERING,
        IGNORE_EXTENDED_RANGES,
        MAP_EXTENDED_RANGES,
        REJECT_EXTENDED_RANGES
    };

    enum class IsoCountryCode {
        PART1_ALPHA2,
        PART1_ALPHA3,
        PART3
    };

private:
    lang::String language;
    lang::String country;
    lang::String variant;
    lang::String script;
    std::map<char, lang::String> extensions;
    std::set<lang::String> unicodeLocaleAttributes;
    std::set<lang::String> unicodeLocaleKeys;
    std::map<lang::String, lang::String> unicodeLocaleTypes;

    static Locale* defaultLocale;
    static std::map<Category, Locale*> defaultLocaleByCategory;

public:
    Locale(const lang::String& lang) : language(lang), country(""), variant(""), script("") {}
    Locale(const lang::String& lang, const lang::String& country) : language(lang), country(country), variant(""), script("") {}
    Locale(const lang::String& lang, const lang::String& country, const lang::String& variant) 
        : language(lang), country(country), variant(variant), script("") {}

    static Locale of(const lang::String& language) {
        return Locale(language);
    }

    static Locale of(const lang::String& language, const lang::String& country) {
        return Locale(language, country);
    }

    static Locale of(const lang::String& language, const lang::String& country, const lang::String& variant) {
        return Locale(language, country, variant);
    }

    static Locale getDefault() {
        if (defaultLocale == nullptr) {
            defaultLocale = new Locale("en", "US");
        }
        return *defaultLocale;
    }

    static Locale getDefault(Category category) {
        auto it = defaultLocaleByCategory.find(category);
        if (it != defaultLocaleByCategory.end()) {
            return *it->second;
        }
        return getDefault();
    }

    static void setDefault(Locale newLocale) {
        if (defaultLocale != nullptr) {
            delete defaultLocale;
        }
        defaultLocale = new Locale(newLocale);
        for (auto& pair : defaultLocaleByCategory) {
            delete pair.second;
            pair.second = new Locale(newLocale);
        }
    }

    static void setDefault(Category category, Locale newLocale) {
        auto it = defaultLocaleByCategory.find(category);
        if (it != defaultLocaleByCategory.end()) {
            delete it->second;
        }
        defaultLocaleByCategory[category] = new Locale(newLocale);
    }

    static lang::String lookup(List& priorityList, Collection& languages) {
        // Simplified implementation
        for (int i = 0; i < priorityList.size(); i++) {
            lang::String tag = priorityList.get(i);
            if (languages.contains(tag)) {
                return tag;
            }
        }
        return lang::String("");
    }

    static List& filter(List& priorityList, Collection& languages) {
        static ArrayList result;
        result.clear();
        for (int i = 0; i < priorityList.size(); i++) {
            lang::String tag = priorityList.get(i);
            if (languages.contains(tag)) {
                result.add(tag);
            }
        }
        return result;
    }

    static List& filter(List& priorityList, Collection& languages, FilteringMode mode) {
        return filter(priorityList, languages);
    }

    static List& filterTags(List& priorityList, Collection& languages) {
        return filter(priorityList, languages);
    }

    static List& filterTags(List& priorityList, Collection& languages, FilteringMode mode) {
        return filter(priorityList, languages);
    }

    static lang::String lookupTag(List& priorityList, Collection& languages) {
        return lookup(priorityList, languages);
    }

    static std::vector<Locale> getAvailableLocales() {
        std::vector<Locale> result;
        result.push_back(Locale("en", "US"));
        result.push_back(Locale("en", "GB"));
        result.push_back(Locale("fr", "FR"));
        result.push_back(Locale("de", "DE"));
        result.push_back(Locale("ja", "JP"));
        result.push_back(Locale("zh", "CN"));
        return result;
    }

    static std::vector<Locale> availableLocales() {
        return getAvailableLocales();
    }

    static std::vector<lang::String> getISOCountries() {
        std::vector<lang::String> result;
        result.push_back(lang::String("US"));
        result.push_back(lang::String("GB"));
        result.push_back(lang::String("FR"));
        result.push_back(lang::String("DE"));
        result.push_back(lang::String("JP"));
        result.push_back(lang::String("CN"));
        return result;
    }

    static std::vector<lang::String> getISOCountries(IsoCountryCode code) {
        return getISOCountries();
    }

    static std::vector<lang::String> getISOLanguages() {
        std::vector<lang::String> result;
        result.push_back(lang::String("en"));
        result.push_back(lang::String("fr"));
        result.push_back(lang::String("de"));
        result.push_back(lang::String("ja"));
        result.push_back(lang::String("zh"));
        return result;
    }

    lang::String getLanguage() const { return language; }
    lang::String getCountry() const { return country; }
    lang::String getVariant() const { return variant; }
    lang::String getScript() const { return script; }

    lang::String getDisplayName() const {
        return language + "-" + country + "-" + variant;
    }

    lang::String getDisplayName(Locale inLocale) const {
        return getDisplayName();
    }

    lang::String getDisplayLanguage() const {
        return language;
    }

    lang::String getDisplayLanguage(Locale inLocale) const {
        return language;
    }

    lang::String getDisplayScript() const {
        return script;
    }

    lang::String getDisplayScript(Locale inLocale) const {
        return script;
    }

    lang::String getDisplayCountry() const {
        return country;
    }

    lang::String getDisplayCountry(Locale inLocale) const {
        return country;
    }

    lang::String getDisplayVariant() const {
        return variant;
    }

    lang::String getDisplayVariant(Locale inLocale) const {
        return variant;
    }

    Locale stripExtensions() const {
        Locale result = *this;
        result.extensions.clear();
        result.unicodeLocaleAttributes.clear();
        result.unicodeLocaleKeys.clear();
        result.unicodeLocaleTypes.clear();
        return result;
    }

    bool hasExtensions() const {
        return !extensions.empty() || !unicodeLocaleAttributes.empty() || !unicodeLocaleKeys.empty() || !unicodeLocaleTypes.empty();
    }

    lang::String getExtension(char key) const {
        auto it = extensions.find(key);
        if (it != extensions.end()) {
            return it->second;
        }
        return lang::String("");
    }

    std::set<char> getExtensionKeys() const {
        std::set<char> result;
        for (const auto& pair : extensions) {
            result.insert(pair.first);
        }
        return result;
    }

    lang::String getUnicodeLocaleType(const lang::String& key) const {
        auto it = unicodeLocaleTypes.find(key);
        if (it != unicodeLocaleTypes.end()) {
            return it->second;
        }
        return lang::String("");
    }

    std::set<lang::String> getUnicodeLocaleAttributes() const {
        return unicodeLocaleAttributes;
    }

    std::set<lang::String> getUnicodeLocaleKeys() const {
        return unicodeLocaleKeys;
    }

    lang::String toLanguageTag() const {
        lang::String result = language;
        if (!script.isEmpty()) {
            result += "-" + script;
        }
        if (!country.isEmpty()) {
            result += "-" + country;
        }
        if (!variant.isEmpty()) {
            result += "-" + variant;
        }
        return result;
    }

    static lang::String caseFoldLanguageTag(const lang::String& tag) {
        return tag.toLowerCase();
    }

    static Locale forLanguageTag(const lang::String& tag) {
        std::vector<lang::String> parts = tag.split("-");
        if (parts.empty()) return Locale("");
        lang::String lang = parts[0];
        lang::String country = "";
        lang::String variant = "";
        if (parts.size() > 1) country = parts[1];
        if (parts.size() > 2) variant = parts[2];
        return Locale(lang, country, variant);
    }

    lang::String getISO3Language() const {
        if (language == "en") return lang::String("eng");
        if (language == "fr") return lang::String("fra");
        if (language == "de") return lang::String("deu");
        if (language == "ja") return lang::String("jpn");
        if (language == "zh") return lang::String("zho");
        return language;
    }

    lang::String getISO3Country() const {
        if (country == "US") return lang::String("USA");
        if (country == "GB") return lang::String("GBR");
        if (country == "FR") return lang::String("FRA");
        if (country == "DE") return lang::String("DEU");
        if (country == "JP") return lang::String("JPN");
        if (country == "CN") return lang::String("CHN");
        return country;
    }

    bool operator==(const Locale& other) const {
        return language == other.language && country == other.country && variant == other.variant;
    }

    bool operator!=(const Locale& other) const {
        return !(*this == other);
    }
};

Locale* Locale::defaultLocale = nullptr;
std::map<Locale::Category, Locale*> Locale::defaultLocaleByCategory;

} // namespace util
} // namespace java

using namespace java::lang;
using namespace java::util;

// Test functions
void of_test_8014(String p0, String p1) {
    Locale::of(p0, p1);
}

void of_test_8015(String p0, String p1, String p2) {
    Locale::of(p0, p1, p2);
}

void of_test_8016(String p0) {
    Locale::of(p0);
}

void getDefault_test_8017(Locale::Category p0) {
    Locale::getDefault(p0);
}

void getDefault_test_8018() {
    Locale::getDefault();
}

void lookup_test_8019(List& p0, Collection& p1) {
    Locale::lookup(p0, p1);
}

void filter_test_8020(List& p0, Collection& p1, Locale::FilteringMode p2) {
    Locale::filter(p0, p1, p2);
}

void filter_test_8021(List& p0, Collection& p1) {
    Locale::filter(p0, p1);
}

void getLanguage_test_8022(String c0) {
    Locale instance(c0);
    instance.getLanguage();
}

void getDisplayName_test_8023(String c0) {
    Locale instance(c0);
    instance.getDisplayName();
}

void getDisplayName_test_8024(Locale p0, String c0) {
    Locale instance(c0);
    instance.getDisplayName(p0);
}

void getAvailableLocales_test_8025() {
    Locale::getAvailableLocales();
}

void getUnicodeLocaleType_test_8026(String p0, String c0) {
    Locale instance(c0);
    instance.getUnicodeLocaleType(p0);
}

void getCountry_test_8027(String c0) {
    Locale instance(c0);
    instance.getCountry();
}

void stripExtensions_test_8028(String c0) {
    Locale instance(c0);
    instance.stripExtensions();
}

void hasExtensions_test_8029(String c0) {
    Locale instance(c0);
    instance.hasExtensions();
}

void getVariant_test_8030(String c0) {
    Locale instance(c0);
    instance.getVariant();
}

void setDefault_test_8031(Locale::Category p0, Locale p1) {
    Locale::setDefault(p0, p1);
}

void setDefault_test_8032(Locale p0) {
    Locale::setDefault(p0);
}

void getScript_test_8033(String c0) {
    Locale instance(c0);
    instance.getScript();
}

void getUnicodeLocaleAttributes_test_8034(String c0) {
    Locale instance(c0);
    instance.getUnicodeLocaleAttributes();
}

void getUnicodeLocaleKeys_test_8035(String c0) {
    Locale instance(c0);
    instance.getUnicodeLocaleKeys();
}

void getDisplayLanguage_test_8036(String c0) {
    Locale instance(c0);
    instance.getDisplayLanguage();
}

void getDisplayLanguage_test_8037(Locale p0, String c0) {
    Locale instance(c0);
    instance.getDisplayLanguage(p0);
}

void getDisplayScript_test_8038(Locale p0, String c0) {
    Locale instance(c0);
    instance.getDisplayScript(p0);
}

void getDisplayScript_test_8039(String c0) {
    Locale instance(c0);
    instance.getDisplayScript();
}

void getDisplayCountry_test_8040(Locale p0, String c0) {
    Locale instance(c0);
    instance.getDisplayCountry(p0);
}

void getDisplayCountry_test_8041(String c0) {
    Locale instance(c0);
    instance.getDisplayCountry();
}

void getDisplayVariant_test_8042(Locale p0, String c0) {
    Locale instance(c0);
    instance.getDisplayVariant(p0);
}

void getDisplayVariant_test_8043(String c0) {
    Locale instance(c0);
    instance.getDisplayVariant();
}

void filterTags_test_8044(List& p0, Collection& p1) {
    Locale::filterTags(p0, p1);
}

void filterTags_test_8045(List& p0, Collection& p1, Locale::FilteringMode p2) {
    Locale::filterTags(p0, p1, p2);
}

void lookupTag_test_8046(List& p0, Collection& p1) {
    Locale::lookupTag(p0, p1);
}

void availableLocales_test_8047() {
    Locale::availableLocales();
}

void getISOCountries_test_8048(Locale::IsoCountryCode p0) {
    Locale::getISOCountries(p0);
}

void getISOCountries_test_8049() {
    Locale::getISOCountries();
}

void getISOLanguages_test_8050() {
    Locale::getISOLanguages();
}

void getExtension_test_8051(char p0, String c0) {
    Locale instance(c0);
    instance.getExtension(p0);
}

void getExtensionKeys_test_8052(String c0) {
    Locale instance(c0);
    instance.getExtensionKeys();
}

void toLanguageTag_test_8053(String c0) {
    Locale instance(c0);
    instance.toLanguageTag();
}

void caseFoldLanguageTag_test_8054(String p0) {
    Locale::caseFoldLanguageTag(p0);
}

void forLanguageTag_test_8055(String p0) {
    Locale::forLanguageTag(p0);
}

void getISO3Language_test_8056(String c0) {
    Locale instance(c0);
    instance.getISO3Language();
}

void getISO3Country_test_8057(String c0) {
    Locale instance(c0);
    instance.getISO3Country();
}