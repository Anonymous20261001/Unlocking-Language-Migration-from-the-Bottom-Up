#include <vector>

class DocFlavor {
public:
    DocFlavor() = default;
};

class AttributeSet {
public:
    AttributeSet() = default;
};

class PrintService {
public:
    PrintService() = default;
};

class PrintServiceLookup {
public:
    PrintServiceLookup() = default;
    virtual ~PrintServiceLookup() = default;

    static std::vector<PrintService*> lookupPrintServices(const DocFlavor& flavor, const AttributeSet& attributes) {
        return {};
    }

    static std::vector<PrintService*> lookupMultiDocPrintServices(const std::vector<DocFlavor>& flavors, const AttributeSet& attributes) {
        return {};
    }

    static PrintService* lookupDefaultPrintService() {
        return nullptr;
    }

    static bool registerService(PrintService* service) {
        return false;
    }

    static bool registerServiceProvider(PrintServiceLookup* provider) {
        return false;
    }
};

void lookupPrintServices_test_10037() {
    DocFlavor p0;
    AttributeSet p1;
    PrintServiceLookup::lookupPrintServices(p0, p1);
}

void lookupMultiDocPrintServices_test_10038() {
    DocFlavor p0;
    AttributeSet p1;
    std::vector<DocFlavor> p0_array = {p0};
    PrintServiceLookup::lookupMultiDocPrintServices(p0_array, p1);
}

void lookupDefaultPrintService_test_10039() {
    PrintServiceLookup::lookupDefaultPrintService();
}

void registerService_test_10040() {
    PrintService p0;
    PrintServiceLookup::registerService(&p0);
}

void registerServiceProvider_test_10041() {
    PrintServiceLookup p0;
    PrintServiceLookup::registerServiceProvider(&p0);
}