#include <string>
#include <vector>
#include <stdexcept>

class JapaneseEra {
public:
    static std::vector<JapaneseEra> values() {
        return {
            JapaneseEra(1, "MEIJI"),
            JapaneseEra(2, "TAISHO"),
            JapaneseEra(3, "SHOWA"),
            JapaneseEra(4, "HEISEI"),
            JapaneseEra(5, "REIWA")
        };
    }

    static JapaneseEra valueOf(const std::string& name) {
        for (const JapaneseEra& era : values()) {
            if (era.name_ == name) {
                return era;
            }
        }
        throw std::invalid_argument("No enum constant " + name);
    }

    static JapaneseEra of(int eraValue) {
        for (const JapaneseEra& era : values()) {
            if (era.value_ == eraValue) {
                return era;
            }
        }
        throw std::invalid_argument("Invalid JapaneseEra value: " + std::to_string(eraValue));
    }

    int getValue() const {
        return value_;
    }

    const std::string& name() const {
        return name_;
    }

    bool operator==(const JapaneseEra& other) const {
        return value_ == other.value_;
    }

    bool operator!=(const JapaneseEra& other) const {
        return !(*this == other);
    }

private:
    JapaneseEra(int value, const std::string& name)
        : value_(value), name_(name) {}

    int value_;
    std::string name_;
};

void values_test_5974() {
    JapaneseEra::values();
}

void valueOf_test_5975(const std::string& p0) {
    JapaneseEra::valueOf(p0);
}

void of_test_5976(int p0) {
    JapaneseEra::of(p0);
}