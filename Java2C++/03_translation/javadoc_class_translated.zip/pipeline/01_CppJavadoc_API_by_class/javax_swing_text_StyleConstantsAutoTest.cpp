#include <string>
#include <memory>
#include <map>
#include <any>
#include <stdexcept>

// Forward declarations
class AttributeSet;
class MutableAttributeSet;
class Color;
class Component;
class Icon;
class TabSet;

// Basic Color class
class Color {
public:
    int red, green, blue;
    Color(int r, int g, int b) : red(r), green(g), blue(b) {}
    bool operator==(const Color& other) const {
        return red == other.red && green == other.green && blue == other.blue;
    }
};

// Basic Component class
class Component {
public:
    virtual ~Component() = default;
};

// Basic Icon interface
class Icon {
public:
    virtual ~Icon() = default;
};

// TabSet class (simplified)
class TabSet {
public:
    TabSet() = default;
};

// AttributeSet interface
class AttributeSet {
public:
    virtual ~AttributeSet() = default;
    virtual std::any getAttribute(const std::string& key) const = 0;
    virtual bool containsAttribute(const std::string& key) const = 0;
};

// MutableAttributeSet interface
class MutableAttributeSet : public AttributeSet {
public:
    virtual void addAttribute(const std::string& key, const std::any& value) = 0;
    virtual void removeAttribute(const std::string& key) = 0;
};

// Simple implementation of MutableAttributeSet
class SimpleMutableAttributeSet : public MutableAttributeSet {
private:
    std::map<std::string, std::any> attributes;
public:
    std::any getAttribute(const std::string& key) const override {
        auto it = attributes.find(key);
        if (it != attributes.end()) {
            return it->second;
        }
        return std::any();
    }
    
    bool containsAttribute(const std::string& key) const override {
        return attributes.find(key) != attributes.end();
    }
    
    void addAttribute(const std::string& key, const std::any& value) override {
        attributes[key] = value;
    }
    
    void removeAttribute(const std::string& key) override {
        attributes.erase(key);
    }
};

// StyleConstants class with static methods
class StyleConstants {
public:
    // Attribute keys
    static const std::string FontFamily;
    static const std::string FontSize;
    static const std::string Bold;
    static const std::string Italic;
    static const std::string Underline;
    static const std::string StrikeThrough;
    static const std::string Superscript;
    static const std::string Subscript;
    static const std::string Foreground;
    static const std::string Background;
    static const std::string Component;
    static const std::string Icon;
    static const std::string FirstLineIndent;
    static const std::string RightIndent;
    static const std::string LeftIndent;
    static const std::string LineSpacing;
    static const std::string SpaceAbove;
    static const std::string SpaceBelow;
    static const std::string Alignment;
    static const std::string TabSet;
    static const std::string BidiLevel;

    // Font family
    static void setFontFamily(MutableAttributeSet* a, const std::string& family) {
        a->addAttribute(FontFamily, family);
    }
    
    static std::string getFontFamily(AttributeSet* a) {
        auto val = a->getAttribute(FontFamily);
        if (val.has_value()) {
            return std::any_cast<std::string>(val);
        }
        return "";
    }

    // Font size
    static void setFontSize(MutableAttributeSet* a, int size) {
        a->addAttribute(FontSize, size);
    }
    
    static int getFontSize(AttributeSet* a) {
        auto val = a->getAttribute(FontSize);
        if (val.has_value()) {
            return std::any_cast<int>(val);
        }
        return 0;
    }

    // Bold
    static bool isBold(AttributeSet* a) {
        auto val = a->getAttribute(Bold);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setBold(MutableAttributeSet* a, bool bold) {
        a->addAttribute(Bold, bold);
    }

    // Italic
    static bool isItalic(AttributeSet* a) {
        auto val = a->getAttribute(Italic);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setItalic(MutableAttributeSet* a, bool italic) {
        a->addAttribute(Italic, italic);
    }

    // Bidi level
    static void setBidiLevel(MutableAttributeSet* a, int level) {
        a->addAttribute(BidiLevel, level);
    }
    
    static int getBidiLevel(AttributeSet* a) {
        auto val = a->getAttribute(BidiLevel);
        if (val.has_value()) {
            return std::any_cast<int>(val);
        }
        return 0;
    }

    // Underline
    static bool isUnderline(AttributeSet* a) {
        auto val = a->getAttribute(Underline);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setUnderline(MutableAttributeSet* a, bool underline) {
        a->addAttribute(Underline, underline);
    }

    // StrikeThrough
    static bool isStrikeThrough(AttributeSet* a) {
        auto val = a->getAttribute(StrikeThrough);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setStrikeThrough(MutableAttributeSet* a, bool strike) {
        a->addAttribute(StrikeThrough, strike);
    }

    // Subscript
    static bool isSubscript(AttributeSet* a) {
        auto val = a->getAttribute(Subscript);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setSubscript(MutableAttributeSet* a, bool subscript) {
        a->addAttribute(Subscript, subscript);
    }

    // Superscript
    static bool isSuperscript(AttributeSet* a) {
        auto val = a->getAttribute(Superscript);
        if (val.has_value()) {
            return std::any_cast<bool>(val);
        }
        return false;
    }
    
    static void setSuperscript(MutableAttributeSet* a, bool superscript) {
        a->addAttribute(Superscript, superscript);
    }

    // First line indent
    static float getFirstLineIndent(AttributeSet* a) {
        auto val = a->getAttribute(FirstLineIndent);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setFirstLineIndent(MutableAttributeSet* a, float indent) {
        a->addAttribute(FirstLineIndent, indent);
    }

    // Right indent
    static float getRightIndent(AttributeSet* a) {
        auto val = a->getAttribute(RightIndent);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setRightIndent(MutableAttributeSet* a, float indent) {
        a->addAttribute(RightIndent, indent);
    }

    // Left indent
    static float getLeftIndent(AttributeSet* a) {
        auto val = a->getAttribute(LeftIndent);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setLeftIndent(MutableAttributeSet* a, float indent) {
        a->addAttribute(LeftIndent, indent);
    }

    // Line spacing
    static float getLineSpacing(AttributeSet* a) {
        auto val = a->getAttribute(LineSpacing);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setLineSpacing(MutableAttributeSet* a, float spacing) {
        a->addAttribute(LineSpacing, spacing);
    }

    // Space above
    static float getSpaceAbove(AttributeSet* a) {
        auto val = a->getAttribute(SpaceAbove);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setSpaceAbove(MutableAttributeSet* a, float space) {
        a->addAttribute(SpaceAbove, space);
    }

    // Space below
    static float getSpaceBelow(AttributeSet* a) {
        auto val = a->getAttribute(SpaceBelow);
        if (val.has_value()) {
            return std::any_cast<float>(val);
        }
        return 0.0f;
    }
    
    static void setSpaceBelow(MutableAttributeSet* a, float space) {
        a->addAttribute(SpaceBelow, space);
    }

    // Alignment
    static int getAlignment(AttributeSet* a) {
        auto val = a->getAttribute(Alignment);
        if (val.has_value()) {
            return std::any_cast<int>(val);
        }
        return 0;
    }
    
    static void setAlignment(MutableAttributeSet* a, int alignment) {
        a->addAttribute(Alignment, alignment);
    }

    // TabSet
    static TabSet* getTabSet(AttributeSet* a) {
        auto val = a->getAttribute(TabSet);
        if (val.has_value()) {
            return std::any_cast<TabSet*>(val);
        }
        return nullptr;
    }
    
    static void setTabSet(MutableAttributeSet* a, TabSet* tabs) {
        a->addAttribute(TabSet, tabs);
    }

    // Foreground
    static Color getForeground(AttributeSet* a) {
        auto val = a->getAttribute(Foreground);
        if (val.has_value()) {
            return std::any_cast<Color>(val);
        }
        return Color(0, 0, 0);
    }
    
    static void setForeground(MutableAttributeSet* a, Color color) {
        a->addAttribute(Foreground, color);
    }

    // Background
    static Color getBackground(AttributeSet* a) {
        auto val = a->getAttribute(Background);
        if (val.has_value()) {
            return std::any_cast<Color>(val);
        }
        return Color(255, 255, 255);
    }
    
    static void setBackground(MutableAttributeSet* a, Color color) {
        a->addAttribute(Background, color);
    }

    // Component
    static Component* getComponent(AttributeSet* a) {
        auto val = a->getAttribute(Component);
        if (val.has_value()) {
            return std::any_cast<Component*>(val);
        }
        return nullptr;
    }
    
    static void setComponent(MutableAttributeSet* a, Component* component) {
        a->addAttribute(Component, component);
    }

    // Icon
    static Icon* getIcon(AttributeSet* a) {
        auto val = a->getAttribute(Icon);
        if (val.has_value()) {
            return std::any_cast<Icon*>(val);
        }
        return nullptr;
    }
    
    static void setIcon(MutableAttributeSet* a, Icon* icon) {
        a->addAttribute(Icon, icon);
    }
};

// Define static constants
const std::string StyleConstants::FontFamily = "fontFamily";
const std::string StyleConstants::FontSize = "fontSize";
const std::string StyleConstants::Bold = "bold";
const std::string StyleConstants::Italic = "italic";
const std::string StyleConstants::Underline = "underline";
const std::string StyleConstants::StrikeThrough = "strikeThrough";
const std::string StyleConstants::Superscript = "superscript";
const std::string StyleConstants::Subscript = "subscript";
const std::string StyleConstants::Foreground = "foreground";
const std::string StyleConstants::Background = "background";
const std::string StyleConstants::Component = "component";
const std::string StyleConstants::Icon = "icon";
const std::string StyleConstants::FirstLineIndent = "firstLineIndent";
const std::string StyleConstants::RightIndent = "rightIndent";
const std::string StyleConstants::LeftIndent = "leftIndent";
const std::string StyleConstants::LineSpacing = "lineSpacing";
const std::string StyleConstants::SpaceAbove = "spaceAbove";
const std::string StyleConstants::SpaceBelow = "spaceBelow";
const std::string StyleConstants::Alignment = "alignment";
const std::string StyleConstants::TabSet = "tabSet";
const std::string StyleConstants::BidiLevel = "bidiLevel";

// Test functions
void setFontFamily_test_11929(MutableAttributeSet* p0, const std::string& p1) {
    StyleConstants::setFontFamily(p0, p1);
}

void setFontSize_test_11930(MutableAttributeSet* p0, int p1) {
    StyleConstants::setFontSize(p0, p1);
}

void isBold_test_11931(AttributeSet* p0) {
    StyleConstants::isBold(p0);
}

void setBold_test_11932(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setBold(p0, p1);
}

void isItalic_test_11933(AttributeSet* p0) {
    StyleConstants::isItalic(p0);
}

void setItalic_test_11934(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setItalic(p0, p1);
}

void setBidiLevel_test_11935(MutableAttributeSet* p0, int p1) {
    StyleConstants::setBidiLevel(p0, p1);
}

void isUnderline_test_11936(AttributeSet* p0) {
    StyleConstants::isUnderline(p0);
}

void isStrikeThrough_test_11937(AttributeSet* p0) {
    StyleConstants::isStrikeThrough(p0);
}

void setStrikeThrough_test_11938(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setStrikeThrough(p0, p1);
}

void setSubscript_test_11939(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setSubscript(p0, p1);
}

void getFirstLineIndent_test_11940(AttributeSet* p0) {
    StyleConstants::getFirstLineIndent(p0);
}

void setFirstLineIndent_test_11941(MutableAttributeSet* p0, float p1) {
    StyleConstants::setFirstLineIndent(p0, p1);
}

void setRightIndent_test_11942(MutableAttributeSet* p0, float p1) {
    StyleConstants::setRightIndent(p0, p1);
}

void setLeftIndent_test_11943(MutableAttributeSet* p0, float p1) {
    StyleConstants::setLeftIndent(p0, p1);
}

void getLineSpacing_test_11944(AttributeSet* p0) {
    StyleConstants::getLineSpacing(p0);
}

void setLineSpacing_test_11945(MutableAttributeSet* p0, float p1) {
    StyleConstants::setLineSpacing(p0, p1);
}

void setSpaceAbove_test_11946(MutableAttributeSet* p0, float p1) {
    StyleConstants::setSpaceAbove(p0, p1);
}

void setSpaceBelow_test_11947(MutableAttributeSet* p0, float p1) {
    StyleConstants::setSpaceBelow(p0, p1);
}

void setAlignment_test_11948(MutableAttributeSet* p0, int p1) {
    StyleConstants::setAlignment(p0, p1);
}

void getTabSet_test_11949(AttributeSet* p0) {
    StyleConstants::getTabSet(p0);
}

void setTabSet_test_11950(MutableAttributeSet* p0, TabSet* p1) {
    StyleConstants::setTabSet(p0, p1);
}

void setSuperscript_test_11951(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setSuperscript(p0, p1);
}

void setUnderline_test_11952(MutableAttributeSet* p0, bool p1) {
    StyleConstants::setUnderline(p0, p1);
}

void getSpaceAbove_test_11953(AttributeSet* p0) {
    StyleConstants::getSpaceAbove(p0);
}

void getLeftIndent_test_11954(AttributeSet* p0) {
    StyleConstants::getLeftIndent(p0);
}

void getSpaceBelow_test_11955(AttributeSet* p0) {
    StyleConstants::getSpaceBelow(p0);
}

void getRightIndent_test_11956(AttributeSet* p0) {
    StyleConstants::getRightIndent(p0);
}

void getForeground_test_11957(AttributeSet* p0) {
    StyleConstants::getForeground(p0);
}

void setForeground_test_11958(MutableAttributeSet* p0, Color p1) {
    StyleConstants::setForeground(p0, p1);
}

void getBackground_test_11959(AttributeSet* p0) {
    StyleConstants::getBackground(p0);
}

void setBackground_test_11960(MutableAttributeSet* p0, Color p1) {
    StyleConstants::setBackground(p0, p1);
}

void setComponent_test_11961(MutableAttributeSet* p0, Component* p1) {
    StyleConstants::setComponent(p0, p1);
}

void getIcon_test_11962(AttributeSet* p0) {
    StyleConstants::getIcon(p0);
}

void setIcon_test_11963(MutableAttributeSet* p0, Icon* p1) {
    StyleConstants::setIcon(p0, p1);
}

void getBidiLevel_test_11964(AttributeSet* p0) {
    StyleConstants::getBidiLevel(p0);
}

void getAlignment_test_11965(AttributeSet* p0) {
    StyleConstants::getAlignment(p0);
}

void getFontFamily_test_11966(AttributeSet* p0) {
    StyleConstants::getFontFamily(p0);
}

void getFontSize_test_11967(AttributeSet* p0) {
    StyleConstants::getFontSize(p0);
}

void isSuperscript_test_11968(AttributeSet* p0) {
    StyleConstants::isSuperscript(p0);
}

void isSubscript_test_11969(AttributeSet* p0) {
    StyleConstants::isSubscript(p0);
}

void getComponent_test_11970(AttributeSet* p0) {
    StyleConstants::getComponent(p0);
}