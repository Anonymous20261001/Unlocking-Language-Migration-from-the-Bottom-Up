#include <string>
#include <vector>

using String = std::string;
using List = std::vector<std::string>;

class RoleUnresolved {
private:
    String roleName;
    List roleValue;
    int problemType;

public:
    RoleUnresolved(const String& roleName, const List& roleValue, int problemType)
        : roleName(roleName), roleValue(roleValue), problemType(problemType) {}

    void setRoleName(const String& roleName) {
        this->roleName = roleName;
    }

    void setRoleValue(const List& roleValue) {
        this->roleValue = roleValue;
    }

    void setProblemType(int problemType) {
        this->problemType = problemType;
    }

    int getProblemType() const {
        return problemType;
    }

    String getRoleName() const {
        return roleName;
    }

    List getRoleValue() const {
        return roleValue;
    }
};

void setRoleName_test_10670(String p0, String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.setRoleName(p0);
}

void setRoleValue_test_10671(List p0, String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.setRoleValue(p0);
}

void setProblemType_test_10672(int p0, String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.setProblemType(p0);
}

void getProblemType_test_10673(String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.getProblemType();
}

void getRoleName_test_10674(String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.getRoleName();
}

void getRoleValue_test_10675(String c0, List c1, int c2) {
    RoleUnresolved instance(c0, c1, c2);
    instance.getRoleValue();
}