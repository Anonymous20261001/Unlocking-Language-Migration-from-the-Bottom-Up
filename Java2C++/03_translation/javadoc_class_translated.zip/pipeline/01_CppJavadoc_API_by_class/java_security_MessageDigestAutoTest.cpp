#include <cstdint>
#include <vector>

using byte = std::uint8_t;

class MessageDigest {
public:
    static bool isEqual(const std::vector<byte>& digesta, const std::vector<byte>& digestb) {
        if (digesta.size() != digestb.size()) {
            return false;
        }

        int result = 0;
        for (std::size_t i = 0; i < digesta.size(); ++i) {
            result |= static_cast<int>(digesta[i]) ^ static_cast<int>(digestb[i]);
        }

        return result == 0;
    }
};

void isEqual_test_8592(const std::vector<byte>& p0, const std::vector<byte>& p1) {
    MessageDigest::isEqual(p0, p1);
}