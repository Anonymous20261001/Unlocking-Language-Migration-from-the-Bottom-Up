#include <cstddef>

class Stream {};
class IntStream {};
class LongStream {};
class DoubleStream {};

class Supplier {
public:
    Supplier() = default;
    virtual ~Supplier() = default;
};

class Spliterator {
public:
    Spliterator() = default;
    virtual ~Spliterator() = default;

    class OfInt {
    public:
        OfInt() = default;
    };

    class OfLong {
    public:
        OfLong() = default;
    };

    class OfDouble {
    public:
        OfDouble() = default;
    };
};

class StreamSupport {
public:
    static Stream stream(Supplier, int, bool) {
        return Stream();
    }

    static Stream stream(Spliterator, bool) {
        return Stream();
    }

    static IntStream intStream(Supplier, int, bool) {
        return IntStream();
    }

    static IntStream intStream(Spliterator::OfInt, bool) {
        return IntStream();
    }

    static LongStream longStream(Supplier, int, bool) {
        return LongStream();
    }

    static LongStream longStream(Spliterator::OfLong, bool) {
        return LongStream();
    }

    static DoubleStream doubleStream(Supplier, int, bool) {
        return DoubleStream();
    }

    static DoubleStream doubleStream(Spliterator::OfDouble, bool) {
        return DoubleStream();
    }
};

void stream_test_11571(Supplier p0, int p1, bool p2) {
    StreamSupport::stream(p0, p1, p2);
}

void stream_test_11572(Spliterator p0, bool p1) {
    StreamSupport::stream(p0, p1);
}

void intStream_test_11573(Supplier p0, int p1, bool p2) {
    StreamSupport::intStream(p0, p1, p2);
}

void intStream_test_11574(Spliterator::OfInt p0, bool p1) {
    StreamSupport::intStream(p0, p1);
}

void longStream_test_11575(Supplier p0, int p1, bool p2) {
    StreamSupport::longStream(p0, p1, p2);
}

void longStream_test_11576(Spliterator::OfLong p0, bool p1) {
    StreamSupport::longStream(p0, p1);
}

void doubleStream_test_11577(Spliterator::OfDouble p0, bool p1) {
    StreamSupport::doubleStream(p0, p1);
}

void doubleStream_test_11578(Supplier p0, int p1, bool p2) {
    StreamSupport::doubleStream(p0, p1, p2);
}
