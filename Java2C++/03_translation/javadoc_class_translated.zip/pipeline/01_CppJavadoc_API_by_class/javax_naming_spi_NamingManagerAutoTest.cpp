#include <cstddef>

class NamingManager {
public:
    static bool hasInitialContextFactoryBuilder() {
        return builderPresent;
    }

private:
    static bool builderPresent;
};

bool NamingManager::builderPresent = false;

void hasInitialContextFactoryBuilder_test_9513() {
    NamingManager::hasInitialContextFactoryBuilder();
}