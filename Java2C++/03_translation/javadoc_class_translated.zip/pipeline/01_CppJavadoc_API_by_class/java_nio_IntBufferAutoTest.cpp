#include <vector>
#include <stdexcept>

class IntBuffer {
private:
    std::vector<int> buffer;
    int capacity_;
    int position_;
    int limit_;

    IntBuffer(const std::vector<int>& data, int capacity, int position, int limit)
        : buffer(data), capacity_(capacity), position_(position), limit_(limit) {}

public:
    static IntBuffer wrap(const std::vector<int>& array) {
        int capacity = static_cast<int>(array.size());
        return IntBuffer(array, capacity, 0, capacity);
    }

    static IntBuffer wrap(const std::vector<int>& array, int offset, int length) {
        int capacity = static_cast<int>(array.size());
        if (offset < 0 || length < 0 || offset > capacity - length) {
            throw std::invalid_argument("IndexOutOfBoundsException");
        }
        return IntBuffer(array, capacity, offset, offset + length);
    }

    static IntBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::invalid_argument("NegativeCapacityException");
        }
        return IntBuffer(std::vector<int>(capacity, 0), capacity, 0, capacity);
    }

    int capacity() const { return capacity_; }
    int position() const { return position_; }
    int limit() const { return limit_; }
};

void wrap_test_5864(const std::vector<int>& p0) {
    IntBuffer::wrap(p0);
}

void wrap_test_5865(const std::vector<int>& p0, int p1, int p2) {
    IntBuffer::wrap(p0, p1, p2);
}

void allocate_test_5866(int p0) {
    IntBuffer::allocate(p0);
}