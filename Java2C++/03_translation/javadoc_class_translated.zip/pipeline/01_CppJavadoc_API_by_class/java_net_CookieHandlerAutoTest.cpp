#include <cstddef>

class CookieHandler {
public:
    virtual ~CookieHandler() = default;

    static CookieHandler* getDefault() {
        return defaultHandler;
    }

    static void setDefault(CookieHandler* handler) {
        defaultHandler = handler;
    }

private:
    static CookieHandler* defaultHandler;
};

CookieHandler* CookieHandler::defaultHandler = nullptr;

void getDefault_test_3025() {
    CookieHandler::getDefault();
}

void setDefault_test_3026(CookieHandler* p0) {
    CookieHandler::setDefault(p0);
}