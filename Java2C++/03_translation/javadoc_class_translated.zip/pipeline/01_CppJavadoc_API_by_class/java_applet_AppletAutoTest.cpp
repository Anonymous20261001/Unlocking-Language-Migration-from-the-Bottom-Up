#include <string>
#include <vector>

class URL {
public:
    URL() = default;
    URL(const URL&) = default;
    URL& operator=(const URL&) = default;
};

class AppletStub {
public:
    AppletStub() = default;
    AppletStub(const AppletStub&) = default;
    AppletStub& operator=(const AppletStub&) = default;
};

class AppletContext {
public:
    AppletContext() = default;
};

class AudioClip {
public:
    AudioClip() = default;
};

class Image {
public:
    Image() = default;
};

class Locale {
public:
    Locale() = default;
};

class AccessibleContext {
public:
    AccessibleContext() = default;
};

class Dimension {
public:
    int width;
    int height;

    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class Applet {
public:
    Applet() = default;

    URL getDocumentBase() {
        return URL();
    }

    URL getCodeBase() {
        return URL();
    }

    AppletContext getAppletContext() {
        return AppletContext();
    }

    void showStatus(const std::string& p0) {
        (void)p0;
    }

    AudioClip getAudioClip(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
        return AudioClip();
    }

    AudioClip getAudioClip(const URL& p0) {
        (void)p0;
        return AudioClip();
    }

    void play(const URL& p0) {
        (void)p0;
    }

    void play(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
    }

    void setStub(AppletStub p0) {
        (void)p0;
    }

    static AudioClip newAudioClip(const URL& p0) {
        (void)p0;
        return AudioClip();
    }

    std::string getAppletInfo() {
        return std::string();
    }

    std::vector<std::vector<std::string>> getParameterInfo() {
        return std::vector<std::vector<std::string>>();
    }

    bool isValidateRoot() {
        return false;
    }

    AccessibleContext getAccessibleContext() {
        return AccessibleContext();
    }

    Image getImage(const URL& p0, const std::string& p1) {
        (void)p0;
        (void)p1;
        return Image();
    }

    Image getImage(const URL& p0) {
        (void)p0;
        return Image();
    }

    void init() {
    }

    void start() {
    }

    void stop() {
    }

    void destroy() {
    }

    bool isActive() {
        return false;
    }

    void resize(int p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void resize(Dimension p0) {
        (void)p0;
    }

    Locale getLocale() {
        return Locale();
    }

    std::string getParameter(const std::string& p0) {
        (void)p0;
        return std::string();
    }
};

void getDocumentBase_test_163() {
    Applet instance;
    instance.getDocumentBase();
}

void getCodeBase_test_164() {
    Applet instance;
    instance.getCodeBase();
}

void getAppletContext_test_165() {
    Applet instance;
    instance.getAppletContext();
}

void showStatus_test_166(std::string p0) {
    Applet instance;
    instance.showStatus(p0);
}

void getAudioClip_test_167(URL p0, std::string p1) {
    Applet instance;
    instance.getAudioClip(p0, p1);
}

void getAudioClip_test_168(URL p0) {
    Applet instance;
    instance.getAudioClip(p0);
}

void play_test_169(URL p0) {
    Applet instance;
    instance.play(p0);
}

void play_test_170(URL p0, std::string p1) {
    Applet instance;
    instance.play(p0, p1);
}

void setStub_test_171(AppletStub p0) {
    Applet instance;
    instance.setStub(p0);
}

void newAudioClip_test_172(URL p0) {
    Applet::newAudioClip(p0);
}

void getAppletInfo_test_173() {
    Applet instance;
    instance.getAppletInfo();
}

void getParameterInfo_test_174() {
    Applet instance;
    instance.getParameterInfo();
}

void isValidateRoot_test_175() {
    Applet instance;
    instance.isValidateRoot();
}

void getAccessibleContext_test_176() {
    Applet instance;
    instance.getAccessibleContext();
}

void getImage_test_177(URL p0, std::string p1) {
    Applet instance;
    instance.getImage(p0, p1);
}

void getImage_test_178(URL p0) {
    Applet instance;
    instance.getImage(p0);
}

void init_test_179() {
    Applet instance;
    instance.init();
}

void start_test_180() {
    Applet instance;
    instance.start();
}

void stop_test_181() {
    Applet instance;
    instance.stop();
}

void destroy_test_182() {
    Applet instance;
    instance.destroy();
}

void isActive_test_183() {
    Applet instance;
    instance.isActive();
}

void resize_test_184(int p0, int p1) {
    Applet instance;
    instance.resize(p0, p1);
}

void resize_test_185(Dimension p0) {
    Applet instance;
    instance.resize(p0);
}

void getLocale_test_186() {
    Applet instance;
    instance.getLocale();
}

void getParameter_test_187(std::string p0) {
    Applet instance;
    instance.getParameter(p0);
}
