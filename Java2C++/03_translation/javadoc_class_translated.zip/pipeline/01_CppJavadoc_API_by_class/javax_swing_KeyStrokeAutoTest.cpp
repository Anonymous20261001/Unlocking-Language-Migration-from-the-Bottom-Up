#include <string>

class KeyEvent {
public:
    KeyEvent() {}
};

class Character {
public:
    explicit Character(char c) : value(c) {}
    char charValue() const { return value; }
private:
    char value;
};

class KeyStroke {
public:
    KeyStroke() {}

    static KeyStroke getKeyStrokeForEvent(const KeyEvent&) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(char, bool) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(Character, int) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(int, int) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(char) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(const std::string&) {
        return KeyStroke();
    }

    static KeyStroke getKeyStroke(int, int, bool) {
        return KeyStroke();
    }
};

void getKeyStrokeForEvent_test_7655() {
    KeyEvent p0;
    KeyStroke::getKeyStrokeForEvent(p0);
}

void getKeyStroke_test_7656() {
    char p0 = 'a';
    bool p1 = false;
    KeyStroke::getKeyStroke(p0, p1);
}

void getKeyStroke_test_7657() {
    Character p0('a');
    int p1 = 0;
    KeyStroke::getKeyStroke(p0, p1);
}

void getKeyStroke_test_7658() {
    int p0 = 0;
    int p1 = 0;
    KeyStroke::getKeyStroke(p0, p1);
}

void getKeyStroke_test_7659() {
    char p0 = 'a';
    KeyStroke::getKeyStroke(p0);
}

void getKeyStroke_test_7660() {
    std::string p0 = "";
    KeyStroke::getKeyStroke(p0);
}

void getKeyStroke_test_7661() {
    int p0 = 0;
    int p1 = 0;
    bool p2 = false;
    KeyStroke::getKeyStroke(p0, p1, p2);
}