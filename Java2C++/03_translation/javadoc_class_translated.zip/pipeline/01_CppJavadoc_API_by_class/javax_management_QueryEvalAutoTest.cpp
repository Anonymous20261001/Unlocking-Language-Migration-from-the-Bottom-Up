#include <cstddef>

class MBeanServer {
public:
    MBeanServer() = default;
};

class QueryEval {
public:
    static MBeanServer* getMBeanServer() {
        static MBeanServer instance;
        return &instance;
    }
};

void getMBeanServer_test_10293() {
    QueryEval::getMBeanServer();
}