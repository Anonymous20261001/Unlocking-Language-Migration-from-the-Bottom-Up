#include <cstddef>

class LoggingMXBean {
public:
    LoggingMXBean() = default;
    virtual ~LoggingMXBean() = default;
    LoggingMXBean(const LoggingMXBean&) = delete;
    LoggingMXBean& operator=(const LoggingMXBean&) = delete;
};

class LogManager {
public:
    static LogManager& getLogManager() {
        static LogManager instance;
        return instance;
    }

    static LoggingMXBean& getLoggingMXBean() {
        static LoggingMXBean bean;
        return bean;
    }

    LogManager(const LogManager&) = delete;
    LogManager& operator=(const LogManager&) = delete;
    ~LogManager() = default;

private:
    LogManager() = default;
};

void getLogManager_test_8109() {
    LogManager::getLogManager();
}

void getLoggingMXBean_test_8110() {
    LogManager::getLoggingMXBean();
}