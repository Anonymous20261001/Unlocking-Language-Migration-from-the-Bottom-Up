class AclEntry {
public:
  AclEntry() = default;
  AclEntry(const AclEntry&) = default;
  AclEntry& operator=(const AclEntry&) = default;

  class Builder {
  public:
    Builder() = default;
    Builder(const AclEntry& entry) : entry_(entry) {}
    AclEntry build() const { return entry_; }
  private:
    AclEntry entry_;
  };

  static Builder newBuilder() {
    return Builder();
  }

  static Builder newBuilder(const AclEntry& entry) {
    return Builder(entry);
  }
};

void newBuilder_test_55(AclEntry p0) {
  AclEntry::newBuilder(p0);
}

void newBuilder_test_56() {
  AclEntry::newBuilder();
}