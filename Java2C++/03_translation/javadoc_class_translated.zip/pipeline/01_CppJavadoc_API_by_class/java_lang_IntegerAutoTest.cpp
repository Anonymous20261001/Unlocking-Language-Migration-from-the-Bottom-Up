#include <cstdint>
#include <string>
#include <optional>
#include <stdexcept>
#include <limits>
#include <algorithm>

namespace java {
namespace lang {

class Integer;
class String;
class CharSequence;
class MethodHandles;

class CharSequence {
public:
    virtual ~CharSequence() = default;
    virtual int length() const = 0;
    virtual char charAt(int index) const = 0;
    virtual std::string toString() const = 0;
};

class String : public CharSequence {
private:
    std::string data;
public:
    String() : data("") {}
    String(const char* s) : data(s) {}
    String(const std::string& s) : data(s) {}
    String(const String& other) : data(other.data) {}
    
    int length() const override { return static_cast<int>(data.length()); }
    char charAt(int index) const override { return data.at(index); }
    std::string toString() const override { return data; }
    
    const std::string& getData() const { return data; }
    
    bool operator==(const String& other) const { return data == other.data; }
    bool operator!=(const String& other) const { return data != other.data; }
    
    static String valueOf(int value) {
        return String(std::to_string(value));
    }
};

class MethodHandles {
public:
    class Lookup {
    public:
        Lookup() = default;
    };
};

class Integer {
private:
    int value;
    
    static int parseUnsignedIntInternal(const std::string& s, int radix, int beginIndex, int endIndex) {
        if (radix < Character::MIN_RADIX || radix > Character::MAX_RADIX) {
            throw std::invalid_argument("radix out of range");
        }
        if (beginIndex < 0 || endIndex > static_cast<int>(s.length()) || beginIndex > endIndex) {
            throw std::invalid_argument("index out of range");
        }
        
        long long result = 0;
        for (int i = beginIndex; i < endIndex; i++) {
            int digit = Character::digit(s[i], radix);
            if (digit < 0) {
                throw std::invalid_argument("invalid character");
            }
            result = result * radix + digit;
            if (result > 0xFFFFFFFFLL) {
                throw std::invalid_argument("value out of range");
            }
        }
        return static_cast<int>(result);
    }
    
    static int parseUnsignedIntInternal(const std::string& s, int radix) {
        return parseUnsignedIntInternal(s, radix, 0, static_cast<int>(s.length()));
    }
    
    static int parseUnsignedIntInternal(const std::string& s) {
        return parseUnsignedIntInternal(s, 10);
    }
    
    static int parseIntInternal(const std::string& s, int radix, int beginIndex, int endIndex) {
        if (radix < Character::MIN_RADIX || radix > Character::MAX_RADIX) {
            throw std::invalid_argument("radix out of range");
        }
        if (beginIndex < 0 || endIndex > static_cast<int>(s.length()) || beginIndex > endIndex) {
            throw std::invalid_argument("index out of range");
        }
        
        bool negative = false;
        int i = beginIndex;
        if (i < endIndex && (s[i] == '+' || s[i] == '-')) {
            negative = (s[i] == '-');
            i++;
        }
        
        long long result = 0;
        for (; i < endIndex; i++) {
            int digit = Character::digit(s[i], radix);
            if (digit < 0) {
                throw std::invalid_argument("invalid character");
            }
            result = result * radix + digit;
            if (negative) {
                if (result > 2147483648LL) {
                    throw std::invalid_argument("value out of range");
                }
            } else {
                if (result > 2147483647LL) {
                    throw std::invalid_argument("value out of range");
                }
            }
        }
        
        if (negative) {
            return static_cast<int>(-result);
        }
        return static_cast<int>(result);
    }
    
    static int parseIntInternal(const std::string& s, int radix) {
        return parseIntInternal(s, radix, 0, static_cast<int>(s.length()));
    }
    
    static int parseIntInternal(const std::string& s) {
        return parseIntInternal(s, 10);
    }
    
    static std::string toUnsignedStringInternal(int value, int radix) {
        if (radix < Character::MIN_RADIX || radix > Character::MAX_RADIX) {
            radix = 10;
        }
        
        unsigned int uvalue = static_cast<unsigned int>(value);
        if (uvalue == 0) {
            return "0";
        }
        
        std::string result;
        while (uvalue > 0) {
            int digit = uvalue % radix;
            result.insert(result.begin(), Character::forDigit(digit, radix));
            uvalue /= radix;
        }
        return result;
    }
    
    static std::string toUnsignedStringInternal(int value) {
        return toUnsignedStringInternal(value, 10);
    }
    
    static std::string toStringInternal(int value, int radix) {
        if (radix < Character::MIN_RADIX || radix > Character::MAX_RADIX) {
            radix = 10;
        }
        
        if (value == 0) {
            return "0";
        }
        
        bool negative = (value < 0);
        unsigned int uvalue = negative ? static_cast<unsigned int>(-(static_cast<long long>(value))) : static_cast<unsigned int>(value);
        
        std::string result;
        while (uvalue > 0) {
            int digit = uvalue % radix;
            result.insert(result.begin(), Character::forDigit(digit, radix));
            uvalue /= radix;
        }
        
        if (negative) {
            result.insert(result.begin(), '-');
        }
        return result;
    }
    
    static std::string toStringInternal(int value) {
        return toStringInternal(value, 10);
    }
    
public:
    static const int MIN_VALUE = std::numeric_limits<int>::min();
    static const int MAX_VALUE = std::numeric_limits<int>::max();
    static const int SIZE = 32;
    static const int BYTES = 4;
    
    Integer() : value(0) {}
    Integer(int v) : value(v) {}
    Integer(const Integer& other) : value(other.value) {}
    
    int intValue() const { return value; }
    long long longValue() const { return static_cast<long long>(value); }
    float floatValue() const { return static_cast<float>(value); }
    double doubleValue() const { return static_cast<double>(value); }
    short shortValue() const { return static_cast<short>(value); }
    char byteValue() const { return static_cast<char>(value); }
    
    int compareTo(const Integer& other) const {
        return compare(value, other.value);
    }
    
    bool equals(const Integer& other) const {
        return value == other.value;
    }
    
    std::string toString() const {
        return toStringInternal(value);
    }
    
    int hashCode() const {
        return value;
    }
    
    std::optional<Integer> describeConstable() const {
        return Integer(value);
    }
    
    Integer resolveConstantDesc(const MethodHandles::Lookup& lookup) const {
        return *this;
    }
    
    static int numberOfLeadingZeros(int i) {
        if (i == 0) return 32;
        int n = 1;
        if (static_cast<unsigned int>(i) >> 16 == 0) { n += 16; i <<= 16; }
        if (static_cast<unsigned int>(i) >> 24 == 0) { n += 8; i <<= 8; }
        if (static_cast<unsigned int>(i) >> 28 == 0) { n += 4; i <<= 4; }
        if (static_cast<unsigned int>(i) >> 30 == 0) { n += 2; i <<= 2; }
        n -= static_cast<unsigned int>(i) >> 31;
        return n;
    }
    
    static int numberOfTrailingZeros(int i) {
        if (i == 0) return 32;
        int n = 31;
        unsigned int y = static_cast<unsigned int>(i);
        if (y & 0x0000FFFF) { n -= 16; } else { y >>= 16; }
        if (y & 0x000000FF) { n -= 8; } else { y >>= 8; }
        if (y & 0x0000000F) { n -= 4; } else { y >>= 4; }
        if (y & 0x00000003) { n -= 2; } else { y >>= 2; }
        n -= (y & 1);
        return n;
    }
    
    static int bitCount(int i) {
        i = i - ((i >> 1) & 0x55555555);
        i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
        i = (i + (i >> 4)) & 0x0f0f0f0f;
        i = i + (i >> 8);
        i = i + (i >> 16);
        return i & 0x3f;
    }
    
    static int min(int a, int b) {
        return std::min(a, b);
    }
    
    static int max(int a, int b) {
        return std::max(a, b);
    }
    
    static int signum(int i) {
        return (i >> 31) | (-static_cast<unsigned int>(i) >> 31);
    }
    
    static int expand(int i, int mask) {
        int result = 0;
        int m = 0;
        for (int k = 0; k < 32; k++) {
            if ((mask >> k) & 1) {
                result |= ((i >> m) & 1) << k;
                m++;
            }
        }
        return result;
    }
    
    static int compareUnsigned(int x, int y) {
        return compare(static_cast<int>(static_cast<unsigned int>(x) + std::numeric_limits<int>::min()),
                       static_cast<int>(static_cast<unsigned int>(y) + std::numeric_limits<int>::min()));
    }
    
    static int divideUnsigned(int dividend, int divisor) {
        if (divisor == 0) {
            throw std::invalid_argument("division by zero");
        }
        unsigned int udividend = static_cast<unsigned int>(dividend);
        unsigned int udivisor = static_cast<unsigned int>(divisor);
        return static_cast<int>(udividend / udivisor);
    }
    
    static int remainderUnsigned(int dividend, int divisor) {
        if (divisor == 0) {
            throw std::invalid_argument("division by zero");
        }
        unsigned int udividend = static_cast<unsigned int>(dividend);
        unsigned int udivisor = static_cast<unsigned int>(divisor);
        return static_cast<int>(udividend % udivisor);
    }
    
    static int reverse(int i) {
        i = (i & 0x55555555) << 1 | (i >> 1) & 0x55555555;
        i = (i & 0x33333333) << 2 | (i >> 2) & 0x33333333;
        i = (i & 0x0f0f0f0f) << 4 | (i >> 4) & 0x0f0f0f0f;
        i = (i << 24) | ((i & 0xff00) << 8) | ((i >> 8) & 0xff00) | (i >> 24);
        return i;
    }
    
    static int reverseBytes(int i) {
        return ((i >> 24) & 0xff) | ((i >> 8) & 0xff00) | ((i << 8) & 0xff0000) | ((i << 24) & 0xff000000);
    }
    
    static int compress(int i, int mask) {
        int result = 0;
        int m = 0;
        for (int k = 0; k < 32; k++) {
            if ((mask >> k) & 1) {
                result |= ((i >> k) & 1) << m;
                m++;
            }
        }
        return result;
    }
    
    static int compare(int x, int y) {
        return (x < y) ? -1 : ((x == y) ? 0 : 1);
    }
    
    static Integer valueOf(int i) {
        return Integer(i);
    }
    
    static Integer valueOf(const String& s) {
        return Integer(parseIntInternal(s.getData()));
    }
    
    static Integer valueOf(const String& s, int radix) {
        return Integer(parseIntInternal(s.getData(), radix));
    }
    
    static std::string toHexString(int i) {
        return toUnsignedStringInternal(i, 16);
    }
    
    static Integer decode(const String& nm) {
        std::string s = nm.getData();
        int radix = 10;
        int index = 0;
        bool negative = false;
        
        if (s.length() > 0 && (s[0] == '+' || s[0] == '-')) {
            negative = (s[0] == '-');
            index++;
        }
        
        if (s.length() > index + 1 && s[index] == '0') {
            if (s[index + 1] == 'x' || s[index + 1] == 'X') {
                radix = 16;
                index += 2;
            } else if (s[index + 1] == 'b' || s[index + 1] == 'B') {
                radix = 2;
                index += 2;
            } else {
                radix = 8;
                index++;
            }
        }
        
        std::string sub = s.substr(index);
        int result = parseIntInternal(sub, radix);
        return Integer(negative ? -result : result);
    }
    
    static int parseInt(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        std::string str = s.toString();
        return parseIntInternal(str, radix, beginIndex, endIndex);
    }
    
    static int parseInt(const String& s) {
        return parseIntInternal(s.getData());
    }
    
    static int parseInt(const String& s, int radix) {
        return parseIntInternal(s.getData(), radix);
    }
    
    static long long toUnsignedLong(int x) {
        return static_cast<long long>(static_cast<unsigned int>(x));
    }
    
    static int sum(int a, int b) {
        return a + b;
    }
    
    static std::string toUnsignedString(int i) {
        return toUnsignedStringInternal(i);
    }
    
    static std::string toUnsignedString(int i, int radix) {
        return toUnsignedStringInternal(i, radix);
    }
    
    static int parseUnsignedInt(const String& s, int radix) {
        return parseUnsignedIntInternal(s.getData(), radix);
    }
    
    static int parseUnsignedInt(const String& s) {
        return parseUnsignedIntInternal(s.getData());
    }
    
    static int parseUnsignedInt(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        std::string str = s.toString();
        return parseUnsignedIntInternal(str, radix, beginIndex, endIndex);
    }
    
    static Integer getInteger(const String& nm, Integer val) {
        // Simulate system property lookup; return default
        return val;
    }
    
    static Integer getInteger(const String& nm) {
        return Integer(0);
    }
    
    static Integer getInteger(const String& nm, int val) {
        return Integer(val);
    }
    
    static std::string toOctalString(int i) {
        return toUnsignedStringInternal(i, 8);
    }
    
    static std::string toBinaryString(int i) {
        return toUnsignedStringInternal(i, 2);
    }
    
    static int highestOneBit(int i) {
        i |= (i >> 1);
        i |= (i >> 2);
        i |= (i >> 4);
        i |= (i >> 8);
        i |= (i >> 16);
        return i - (i >> 1);
    }
    
    static int lowestOneBit(int i) {
        return i & -i;
    }
    
    static int rotateLeft(int i, int distance) {
        unsigned int ui = static_cast<unsigned int>(i);
        unsigned int ud = static_cast<unsigned int>(distance) & 0x1F;
        return static_cast<int>((ui << ud) | (ui >> (32 - ud)));
    }
    
    static int rotateRight(int i, int distance) {
        unsigned int ui = static_cast<unsigned int>(i);
        unsigned int ud = static_cast<unsigned int>(distance) & 0x1F;
        return static_cast<int>((ui >> ud) | (ui << (32 - ud)));
    }
};

class Character {
public:
    static const int MIN_RADIX = 2;
    static const int MAX_RADIX = 36;
    
    static int digit(char ch, int radix) {
        int val = -1;
        if (ch >= '0' && ch <= '9') {
            val = ch - '0';
        } else if (ch >= 'a' && ch <= 'z') {
            val = ch - 'a' + 10;
        } else if (ch >= 'A' && ch <= 'Z') {
            val = ch - 'A' + 10;
        }
        return (val < radix) ? val : -1;
    }
    
    static char forDigit(int digit, int radix) {
        if (digit < 0 || digit >= radix || radix < MIN_RADIX || radix > MAX_RADIX) {
            return '\0';
        }
        if (digit < 10) {
            return static_cast<char>('0' + digit);
        }
        return static_cast<char>('a' + digit - 10);
    }
};

} // namespace lang
} // namespace java

using namespace java::lang;

// Test functions
void numberOfLeadingZeros_test_5867(int p0) {
    Integer::numberOfLeadingZeros(p0);
}

void numberOfTrailingZeros_test_5868(int p0) {
    Integer::numberOfTrailingZeros(p0);
}

void bitCount_test_5869(int p0) {
    Integer::bitCount(p0);
}

void min_test_5870(int p0, int p1) {
    Integer::min(p0, p1);
}

void max_test_5871(int p0, int p1) {
    Integer::max(p0, p1);
}

void signum_test_5872(int p0) {
    Integer::signum(p0);
}

void expand_test_5873(int p0, int p1) {
    Integer::expand(p0, p1);
}

void compareUnsigned_test_5874(int p0, int p1) {
    Integer::compareUnsigned(p0, p1);
}

void divideUnsigned_test_5875(int p0, int p1) {
    Integer::divideUnsigned(p0, p1);
}

void remainderUnsigned_test_5876(int p0, int p1) {
    Integer::remainderUnsigned(p0, p1);
}

void reverse_test_5877(int p0) {
    Integer::reverse(p0);
}

void reverseBytes_test_5878(int p0) {
    Integer::reverseBytes(p0);
}

void compress_test_5879(int p0, int p1) {
    Integer::compress(p0, p1);
}

void compareTo_test_5880(Integer p0, int c0) {
    Integer instance = Integer(c0);
    instance.compareTo(p0);
}

void compare_test_5881(int p0, int p1) {
    Integer::compare(p0, p1);
}

void byteValue_test_5882(int c0) {
    Integer instance = Integer(c0);
    instance.byteValue();
}

void shortValue_test_5883(int c0) {
    Integer instance = Integer(c0);
    instance.shortValue();
}

void intValue_test_5884(int c0) {
    Integer instance = Integer(c0);
    instance.intValue();
}

void longValue_test_5885(int c0) {
    Integer instance = Integer(c0);
    instance.longValue();
}

void floatValue_test_5886(int c0) {
    Integer instance = Integer(c0);
    instance.floatValue();
}

void doubleValue_test_5887(int c0) {
    Integer instance = Integer(c0);
    instance.doubleValue();
}

void valueOf_test_5888(String p0) {
    Integer::valueOf(p0);
}

void valueOf_test_5889(int p0) {
    Integer::valueOf(p0);
}

void valueOf_test_5890(String p0, int p1) {
    Integer::valueOf(p0, p1);
}

void toHexString_test_5891(int p0) {
    Integer::toHexString(p0);
}

void decode_test_5892(String p0) {
    Integer::decode(p0);
}

void resolveConstantDesc_test_5893(MethodHandles::Lookup p0, int c0) {
    Integer instance = Integer(c0);
    instance.resolveConstantDesc(p0);
}

void describeConstable_test_5894(int c0) {
    Integer instance = Integer(c0);
    instance.describeConstable();
}

void parseInt_test_5895(CharSequence& p0, int p1, int p2, int p3) {
    Integer::parseInt(p0, p1, p2, p3);
}

void parseInt_test_5896(String p0) {
    Integer::parseInt(p0);
}

void parseInt_test_5897(String p0, int p1) {
    Integer::parseInt(p0, p1);
}

void toUnsignedLong_test_5898(int p0) {
    Integer::toUnsignedLong(p0);
}

void sum_test_5899(int p0, int p1) {
    Integer::sum(p0, p1);
}

void toUnsignedString_test_5900(int p0) {
    Integer::toUnsignedString(p0);
}

void toUnsignedString_test_5901(int p0, int p1) {
    Integer::toUnsignedString(p0, p1);
}

void parseUnsignedInt_test_5902(String p0, int p1) {
    Integer::parseUnsignedInt(p0, p1);
}

void parseUnsignedInt_test_5903(String p0) {
    Integer::parseUnsignedInt(p0);
}

void parseUnsignedInt_test_5904(CharSequence& p0, int p1, int p2, int p3) {
    Integer::parseUnsignedInt(p0, p1, p2, p3);
}

void getInteger_test_5905(String p0, Integer p1) {
    Integer::getInteger(p0, p1);
}

void getInteger_test_5906(String p0) {
    Integer::getInteger(p0);
}

void getInteger_test_5907(String p0, int p1) {
    Integer::getInteger(p0, p1);
}

void toOctalString_test_5908(int p0) {
    Integer::toOctalString(p0);
}

void toBinaryString_test_5909(int p0) {
    Integer::toBinaryString(p0);
}

void highestOneBit_test_5910(int p0) {
    Integer::highestOneBit(p0);
}

void lowestOneBit_test_5911(int p0) {
    Integer::lowestOneBit(p0);
}

void rotateLeft_test_5912(int p0, int p1) {
    Integer::rotateLeft(p0, p1);
}

void rotateRight_test_5913(int p0, int p1) {
    Integer::rotateRight(p0, p1);
}