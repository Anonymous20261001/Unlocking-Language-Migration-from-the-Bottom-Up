#include <string>

class Class {
public:
    Class() : name_() {}
    explicit Class(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class Preferences {
public:
    Preferences() {}

    static Preferences userRoot() {
        return Preferences();
    }

    static Preferences systemRoot() {
        return Preferences();
    }

    static Preferences userNodeForPackage(Class p0) {
        (void)p0;
        return Preferences();
    }

    static Preferences systemNodeForPackage(Class p0) {
        (void)p0;
        return Preferences();
    }
};

void userRoot_test_10000() {
    Preferences::userRoot();
}

void systemRoot_test_10001() {
    Preferences::systemRoot();
}

void userNodeForPackage_test_10002(Class p0) {
    Preferences::userNodeForPackage(p0);
}

void systemNodeForPackage_test_10003(Class p0) {
    Preferences::systemNodeForPackage(p0);
}