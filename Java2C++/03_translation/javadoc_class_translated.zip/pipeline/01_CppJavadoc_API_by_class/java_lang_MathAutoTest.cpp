#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <type_traits>

namespace java {
namespace lang {

class Math {
public:
    // abs methods
    static float abs(float a) { return std::fabs(a); }
    static long abs(long a) { return (a < 0) ? -a : a; }
    static int abs(int a) { return (a < 0) ? -a : a; }
    static double abs(double a) { return std::fabs(a); }

    // trigonometric
    static double sin(double a) { return std::sin(a); }
    static double cos(double a) { return std::cos(a); }
    static double tan(double a) { return std::tan(a); }
    static double atan2(double y, double x) { return std::atan2(y, x); }
    static double asin(double a) { return std::asin(a); }
    static double acos(double a) { return std::acos(a); }
    static double atan(double a) { return std::atan(a); }

    // exponential/logarithmic
    static double sqrt(double a) { return std::sqrt(a); }
    static double log(double a) { return std::log(a); }
    static double log10(double a) { return std::log10(a); }
    static double pow(double a, double b) { return std::pow(a, b); }
    static double exp(double a) { return std::exp(a); }
    static double expm1(double a) { return std::expm1(a); }
    static double log1p(double a) { return std::log1p(a); }
    static double cbrt(double a) { return std::cbrt(a); }

    // min/max
    static int min(int a, int b) { return (a < b) ? a : b; }
    static long min(long a, long b) { return (a < b) ? a : b; }
    static double min(double a, double b) { return (a < b) ? a : b; }
    static float min(float a, float b) { return (a < b) ? a : b; }
    static long max(long a, long b) { return (a > b) ? a : b; }
    static int max(int a, int b) { return (a > b) ? a : b; }
    static double max(double a, double b) { return (a > b) ? a : b; }
    static float max(float a, float b) { return (a > b) ? a : b; }

    // rounding
    static double floor(double a) { return std::floor(a); }
    static double ceil(double a) { return std::ceil(a); }
    static double rint(double a) { return std::rint(a); }
    static long round(double a) { return std::llround(a); }
    static int round(float a) { return std::lround(a); }

    // hyperbolic
    static double tanh(double a) { return std::tanh(a); }
    static double sinh(double a) { return std::sinh(a); }
    static double cosh(double a) { return std::cosh(a); }

    // exact arithmetic
    static int addExact(int x, int y) {
        if ((y > 0 && x > std::numeric_limits<int>::max() - y) ||
            (y < 0 && x < std::numeric_limits<int>::min() - y)) {
            throw std::overflow_error("integer overflow");
        }
        return x + y;
    }
    static long addExact(long x, long y) {
        if ((y > 0 && x > std::numeric_limits<long>::max() - y) ||
            (y < 0 && x < std::numeric_limits<long>::min() - y)) {
            throw std::overflow_error("long overflow");
        }
        return x + y;
    }
    static int decrementExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return a - 1;
    }
    static long decrementExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return a - 1;
    }
    static long incrementExact(long a) {
        if (a == std::numeric_limits<long>::max()) throw std::overflow_error("long overflow");
        return a + 1;
    }
    static int incrementExact(int a) {
        if (a == std::numeric_limits<int>::max()) throw std::overflow_error("integer overflow");
        return a + 1;
    }
    static long multiplyExact(long x, long y) {
        if (x == 0 || y == 0) return 0;
        if (x == -1 && y == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        if (y == -1 && x == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        long r = x * y;
        if (r / y != x) throw std::overflow_error("long overflow");
        return r;
    }
    static int multiplyExact(int x, int y) {
        long long result = static_cast<long long>(x) * y;
        if (result > std::numeric_limits<int>::max() || result < std::numeric_limits<int>::min()) {
            throw std::overflow_error("integer overflow");
        }
        return static_cast<int>(result);
    }
    static long multiplyExact(long x, int y) {
        return multiplyExact(x, static_cast<long>(y));
    }
    static long multiplyHigh(long x, long y) {
        __int128 result = static_cast<__int128>(x) * y;
        return static_cast<long>(result >> 64);
    }
    static long unsignedMultiplyHigh(long x, long y) {
        unsigned __int128 result = static_cast<unsigned __int128>(static_cast<uint64_t>(x)) * static_cast<uint64_t>(y);
        return static_cast<long>(result >> 64);
    }
    static long negateExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return -a;
    }
    static int negateExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return -a;
    }
    static int subtractExact(int x, int y) {
        if ((y > 0 && x < std::numeric_limits<int>::min() + y) ||
            (y < 0 && x > std::numeric_limits<int>::max() + y)) {
            throw std::overflow_error("integer overflow");
        }
        return x - y;
    }
    static long subtractExact(long x, long y) {
        if ((y > 0 && x < std::numeric_limits<long>::min() + y) ||
            (y < 0 && x > std::numeric_limits<long>::max() + y)) {
            throw std::overflow_error("long overflow");
        }
        return x - y;
    }

    // fma
    static double fma(double a, double b, double c) { return std::fma(a, b, c); }
    static float fma(float a, float b, float c) { return std::fma(a, b, c); }

    // copySign
    static double copySign(double magnitude, double sign) { return std::copysign(magnitude, sign); }
    static float copySign(float magnitude, float sign) { return std::copysign(magnitude, sign); }

    // signum
    static float signum(float a) { return (a > 0) ? 1.0f : (a < 0) ? -1.0f : a; }
    static double signum(double a) { return (a > 0) ? 1.0 : (a < 0) ? -1.0 : a; }

    // clamp
    static float clamp(float value, float min, float max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static long clamp(long value, int min, int max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static double clamp(double value, double min, double max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    static long clamp(long value, long min, long max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    // scalb
    static float scalb(float d, int scaleFactor) { return std::scalbn(d, scaleFactor); }
    static double scalb(double d, int scaleFactor) { return std::scalbn(d, scaleFactor); }

    // getExponent
    static int getExponent(float f) { return std::ilogb(f); }
    static int getExponent(double d) { return std::ilogb(d); }

    // floorMod
    static long floorMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r += y;
        return r;
    }
    static int floorMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r += y;
        return r;
    }
    static long floorMod(long x, int y) {
        return floorMod(x, static_cast<long>(y));
    }

    // IEEEremainder
    static double IEEEremainder(double f1, double f2) { return std::remainder(f1, f2); }

    // floorDiv
    static long floorDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0))) q--;
        return q;
    }
    static long floorDiv(long x, int y) {
        return floorDiv(x, static_cast<long>(y));
    }
    static int floorDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0))) q--;
        return q;
    }

    // ceilDiv
    static long ceilDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0))) q++;
        return q;
    }
    static long ceilDiv(long x, int y) {
        return ceilDiv(x, static_cast<long>(y));
    }
    static int ceilDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0))) q++;
        return q;
    }

    // ceilMod
    static int ceilMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r -= y;
        return r;
    }
    static long ceilMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0))) r -= y;
        return r;
    }
    static long ceilMod(long x, int y) {
        return ceilMod(x, static_cast<long>(y));
    }

    // hypot
    static double hypot(double x, double y) { return std::hypot(x, y); }

    // unsignedMultiplyExact
    static int unsignedMultiplyExact(int x, int y) {
        unsigned int ux = static_cast<unsigned int>(x);
        unsigned int uy = static_cast<unsigned int>(y);
        unsigned long long result = static_cast<unsigned long long>(ux) * uy;
        if (result > std::numeric_limits<unsigned int>::max()) throw std::overflow_error("unsigned integer overflow");
        return static_cast<int>(result);
    }
    static long unsignedMultiplyExact(long x, long y) {
        unsigned long long ux = static_cast<unsigned long long>(x);
        unsigned long long uy = static_cast<unsigned long long>(y);
        unsigned __int128 result = static_cast<unsigned __int128>(ux) * uy;
        if (result > std::numeric_limits<unsigned long long>::max()) throw std::overflow_error("unsigned long overflow");
        return static_cast<long>(result);
    }
    static long unsignedMultiplyExact(long x, int y) {
        return unsignedMultiplyExact(x, static_cast<long>(y));
    }

    // toRadians/toDegrees
    static double toRadians(double angdeg) { return angdeg * M_PI / 180.0; }
    static double toDegrees(double angrad) { return angrad * 180.0 / M_PI; }

    // random
    static double random() { return static_cast<double>(rand()) / RAND_MAX; }

    // divideExact
    static int divideExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return x / y;
    }
    static long divideExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return x / y;
    }

    // floorDivExact
    static int floorDivExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return floorDiv(x, y);
    }
    static long floorDivExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return floorDiv(x, y);
    }

    // ceilDivExact
    static long ceilDivExact(long x, long y) {
        if (x == std::numeric_limits<long>::min() && y == -1) throw std::overflow_error("long overflow");
        return ceilDiv(x, y);
    }
    static int ceilDivExact(int x, int y) {
        if (x == std::numeric_limits<int>::min() && y == -1) throw std::overflow_error("integer overflow");
        return ceilDiv(x, y);
    }

    // toIntExact
    static int toIntExact(long value) {
        if (value > std::numeric_limits<int>::max() || value < std::numeric_limits<int>::min()) {
            throw std::overflow_error("integer overflow");
        }
        return static_cast<int>(value);
    }

    // multiplyFull
    static long multiplyFull(int x, int y) {
        return static_cast<long>(x) * y;
    }

    // absExact
    static long absExact(long a) {
        if (a == std::numeric_limits<long>::min()) throw std::overflow_error("long overflow");
        return (a < 0) ? -a : a;
    }
    static int absExact(int a) {
        if (a == std::numeric_limits<int>::min()) throw std::overflow_error("integer overflow");
        return (a < 0) ? -a : a;
    }

    // ulp
    static float ulp(float f) { return std::nextafter(f, std::numeric_limits<float>::infinity()) - f; }
    static double ulp(double d) { return std::nextafter(d, std::numeric_limits<double>::infinity()) - d; }

    // nextAfter
    static double nextAfter(double start, double direction) { return std::nextafter(start, direction); }
    static float nextAfter(float start, double direction) { return std::nextafter(start, static_cast<float>(direction)); }

    // nextUp/nextDown
    static float nextUp(float f) { return std::nextafter(f, std::numeric_limits<float>::infinity()); }
    static double nextUp(double d) { return std::nextafter(d, std::numeric_limits<double>::infinity()); }
    static float nextDown(float f) { return std::nextafter(f, -std::numeric_limits<float>::infinity()); }
    static double nextDown(double d) { return std::nextafter(d, -std::numeric_limits<double>::infinity()); }

    // powExact
    static int powExact(int a, int b) {
        long long result = 1;
        for (int i = 0; i < b; ++i) {
            result *= a;
            if (result > std::numeric_limits<int>::max() || result < std::numeric_limits<int>::min()) {
                throw std::overflow_error("integer overflow");
            }
        }
        return static_cast<int>(result);
    }
    static long powExact(long a, int b) {
        long long result = 1;
        for (int i = 0; i < b; ++i) {
            result *= a;
            if (result > std::numeric_limits<long>::max() || result < std::numeric_limits<long>::min()) {
                throw std::overflow_error("long overflow");
            }
        }
        return result;
    }

    // unsignedPowExact
    static long unsignedPowExact(long a, int b) {
        unsigned long long result = 1;
        unsigned long long ua = static_cast<unsigned long long>(a);
        for (int i = 0; i < b; ++i) {
            result *= ua;
            if (result > std::numeric_limits<unsigned long long>::max()) {
                throw std::overflow_error("unsigned long overflow");
            }
        }
        return static_cast<long>(result);
    }
    static int unsignedPowExact(int a, int b) {
        unsigned int result = 1;
        unsigned int ua = static_cast<unsigned int>(a);
        for (int i = 0; i < b; ++i) {
            result *= ua;
            if (result > std::numeric_limits<unsigned int>::max()) {
                throw std::overflow_error("unsigned integer overflow");
            }
        }
        return static_cast<int>(result);
    }
};

} // namespace lang
} // namespace java

using java::lang::Math;

// Test functions
void abs_test_8296(float p0) { Math::abs(p0); }
void abs_test_8297(long p0) { Math::abs(p0); }
void abs_test_8298(int p0) { Math::abs(p0); }
void abs_test_8299(double p0) { Math::abs(p0); }
void sin_test_8300(double p0) { Math::sin(p0); }
void cos_test_8301(double p0) { Math::cos(p0); }
void tan_test_8302(double p0) { Math::tan(p0); }
void atan2_test_8303(double p0, double p1) { Math::atan2(p0, p1); }
void sqrt_test_8304(double p0) { Math::sqrt(p0); }
void log_test_8305(double p0) { Math::log(p0); }
void log10_test_8306(double p0) { Math::log10(p0); }
void pow_test_8307(double p0, double p1) { Math::pow(p0, p1); }
void exp_test_8308(double p0) { Math::exp(p0); }
void min_test_8309(int p0, int p1) { Math::min(p0, p1); }
void min_test_8310(long p0, long p1) { Math::min(p0, p1); }
void min_test_8311(double p0, double p1) { Math::min(p0, p1); }
void min_test_8312(float p0, float p1) { Math::min(p0, p1); }
void max_test_8313(long p0, long p1) { Math::max(p0, p1); }
void max_test_8314(int p0, int p1) { Math::max(p0, p1); }
void max_test_8315(double p0, double p1) { Math::max(p0, p1); }
void max_test_8316(float p0, float p1) { Math::max(p0, p1); }
void floor_test_8317(double p0) { Math::floor(p0); }
void ceil_test_8318(double p0) { Math::ceil(p0); }
void rint_test_8319(double p0) { Math::rint(p0); }
void round_test_8320(double p0) { Math::round(p0); }
void round_test_8321(float p0) { Math::round(p0); }
void tanh_test_8322(double p0) { Math::tanh(p0); }
void cbrt_test_8323(double p0) { Math::cbrt(p0); }
void addExact_test_8324(int p0, int p1) { Math::addExact(p0, p1); }
void addExact_test_8325(long p0, long p1) { Math::addExact(p0, p1); }
void decrementExact_test_8326(int p0) { Math::decrementExact(p0); }
void decrementExact_test_8327(long p0) { Math::decrementExact(p0); }
void incrementExact_test_8328(long p0) { Math::incrementExact(p0); }
void incrementExact_test_8329(int p0) { Math::incrementExact(p0); }
void multiplyExact_test_8330(long p0, long p1) { Math::multiplyExact(p0, p1); }
void multiplyExact_test_8331(int p0, int p1) { Math::multiplyExact(p0, p1); }
void multiplyExact_test_8332(long p0, int p1) { Math::multiplyExact(p0, p1); }
void multiplyHigh_test_8333(long p0, long p1) { Math::multiplyHigh(p0, p1); }
void unsignedMultiplyHigh_test_8334(long p0, long p1) { Math::unsignedMultiplyHigh(p0, p1); }
void negateExact_test_8335(long p0) { Math::negateExact(p0); }
void negateExact_test_8336(int p0) { Math::negateExact(p0); }
void subtractExact_test_8337(int p0, int p1) { Math::subtractExact(p0, p1); }
void subtractExact_test_8338(long p0, long p1) { Math::subtractExact(p0, p1); }
void fma_test_8339(double p0, double p1, double p2) { Math::fma(p0, p1, p2); }
void fma_test_8340(float p0, float p1, float p2) { Math::fma(p0, p1, p2); }
void copySign_test_8341(double p0, double p1) { Math::copySign(p0, p1); }
void copySign_test_8342(float p0, float p1) { Math::copySign(p0, p1); }
void signum_test_8343(float p0) { Math::signum(p0); }
void signum_test_8344(double p0) { Math::signum(p0); }
void clamp_test_8345(float p0, float p1, float p2) { Math::clamp(p0, p1, p2); }
void clamp_test_8346(long p0, int p1, int p2) { Math::clamp(p0, p1, p2); }
void clamp_test_8347(double p0, double p1, double p2) { Math::clamp(p0, p1, p2); }
void clamp_test_8348(long p0, long p1, long p2) { Math::clamp(p0, p1, p2); }
void scalb_test_8349(float p0, int p1) { Math::scalb(p0, p1); }
void scalb_test_8350(double p0, int p1) { Math::scalb(p0, p1); }
void getExponent_test_8351(float p0) { Math::getExponent(p0); }
void getExponent_test_8352(double p0) { Math::getExponent(p0); }
void floorMod_test_8353(long p0, long p1) { Math::floorMod(p0, p1); }
void floorMod_test_8354(int p0, int p1) { Math::floorMod(p0, p1); }
void floorMod_test_8355(long p0, int p1) { Math::floorMod(p0, p1); }
void asin_test_8356(double p0) { Math::asin(p0); }
void acos_test_8357(double p0) { Math::acos(p0); }
void atan_test_8358(double p0) { Math::atan(p0); }
void IEEEremainder_test_8359(double p0, double p1) { Math::IEEEremainder(p0, p1); }
void floorDiv_test_8360(long p0, long p1) { Math::floorDiv(p0, p1); }
void floorDiv_test_8361(long p0, int p1) { Math::floorDiv(p0, p1); }
void floorDiv_test_8362(int p0, int p1) { Math::floorDiv(p0, p1); }
void ceilDiv_test_8363(long p0, long p1) { Math::ceilDiv(p0, p1); }
void ceilDiv_test_8364(long p0, int p1) { Math::ceilDiv(p0, p1); }
void ceilDiv_test_8365(int p0, int p1) { Math::ceilDiv(p0, p1); }
void ceilMod_test_8366(int p0, int p1) { Math::ceilMod(p0, p1); }
void ceilMod_test_8367(long p0, long p1) { Math::ceilMod(p0, p1); }
void ceilMod_test_8368(long p0, int p1) { Math::ceilMod(p0, p1); }
void sinh_test_8369(double p0) { Math::sinh(p0); }
void cosh_test_8370(double p0) { Math::cosh(p0); }
void hypot_test_8371(double p0, double p1) { Math::hypot(p0, p1); }
void expm1_test_8372(double p0) { Math::expm1(p0); }
void log1p_test_8373(double p0) { Math::log1p(p0); }
void unsignedMultiplyExact_test_8374(int p0, int p1) { Math::unsignedMultiplyExact(p0, p1); }
void unsignedMultiplyExact_test_8375(long p0, long p1) { Math::unsignedMultiplyExact(p0, p1); }
void unsignedMultiplyExact_test_8376(long p0, int p1) { Math::unsignedMultiplyExact(p0, p1); }
void toRadians_test_8377(double p0) { Math::toRadians(p0); }
void toDegrees_test_8378(double p0) { Math::toDegrees(p0); }
void random_test_8379() { Math::random(); }
void divideExact_test_8380(int p0, int p1) { Math::divideExact(p0, p1); }
void divideExact_test_8381(long p0, long p1) { Math::divideExact(p0, p1); }
void floorDivExact_test_8382(int p0, int p1) { Math::floorDivExact(p0, p1); }
void floorDivExact_test_8383(long p0, long p1) { Math::floorDivExact(p0, p1); }
void ceilDivExact_test_8384(long p0, long p1) { Math::ceilDivExact(p0, p1); }
void ceilDivExact_test_8385(int p0, int p1) { Math::ceilDivExact(p0, p1); }
void toIntExact_test_8386(long p0) { Math::toIntExact(p0); }
void multiplyFull_test_8387(int p0, int p1) { Math::multiplyFull(p0, p1); }
void absExact_test_8388(long p0) { Math::absExact(p0); }
void absExact_test_8389(int p0) { Math::absExact(p0); }
void ulp_test_8390(float p0) { Math::ulp(p0); }
void ulp_test_8391(double p0) { Math::ulp(p0); }
void nextAfter_test_8392(double p0, double p1) { Math::nextAfter(p0, p1); }
void nextAfter_test_8393(float p0, double p1) { Math::nextAfter(p0, p1); }
void nextUp_test_8394(float p0) { Math::nextUp(p0); }
void nextUp_test_8395(double p0) { Math::nextUp(p0); }
void nextDown_test_8396(float p0) { Math::nextDown(p0); }
void nextDown_test_8397(double p0) { Math::nextDown(p0); }
void powExact_test_8398(int p0, int p1) { Math::powExact(p0, p1); }
void powExact_test_8399(long p0, int p1) { Math::powExact(p0, p1); }
void unsignedPowExact_test_8400(long p0, int p1) { Math::unsignedPowExact(p0, p1); }
void unsignedPowExact_test_8401(int p0, int p1) { Math::unsignedPowExact(p0, p1); }