#include <string>

class String {
public:
    String() = default;
    String(const char* s) : data_(s) {}
    String(const std::string& s) : data_(s) {}
private:
    std::string data_;
};

class ClassLoader {
public:
    ClassLoader() = default;
    explicit ClassLoader(const std::string& name) : name_(name) {}
private:
    std::string name_;
};

class XMLInputFactory {
public:
    XMLInputFactory() = default;

    static XMLInputFactory newDefaultFactory() {
        return XMLInputFactory();
    }

    static XMLInputFactory newInstance() {
        return XMLInputFactory();
    }

    static XMLInputFactory newInstance(const String&, ClassLoader) {
        return XMLInputFactory();
    }

    static XMLInputFactory newFactory(const String&, ClassLoader) {
        return XMLInputFactory();
    }

    static XMLInputFactory newFactory() {
        return XMLInputFactory();
    }
};

void newDefaultFactory_test_13634() {
    XMLInputFactory::newDefaultFactory();
}

void newInstance_test_13635() {
    XMLInputFactory::newInstance();
}

void newInstance_test_13636(const String& p0, ClassLoader p1) {
    XMLInputFactory::newInstance(p0, p1);
}

void newFactory_test_13637(const String& p0, ClassLoader p1) {
    XMLInputFactory::newFactory(p0, p1);
}

void newFactory_test_13638() {
    XMLInputFactory::newFactory();
}