#include <cstdlib>

namespace java {
namespace awt {

class GraphicsEnvironment {
public:
    static bool isHeadless() {
#if defined(_WIN32) || defined(_WIN64)
        return false;
#else
        const char* display = std::getenv("DISPLAY");
        return display == nullptr || display[0] == '\0';
#endif
    }

    static GraphicsEnvironment& getLocalGraphicsEnvironment() {
        static GraphicsEnvironment instance;
        return instance;
    }

    virtual ~GraphicsEnvironment() = default;

private:
    GraphicsEnvironment() = default;
    GraphicsEnvironment(const GraphicsEnvironment&) = delete;
    GraphicsEnvironment& operator=(const GraphicsEnvironment&) = delete;
};

} // namespace awt
} // namespace java

void isHeadless_test_5148() {
    java::awt::GraphicsEnvironment::isHeadless();
}

void getLocalGraphicsEnvironment_test_5149() {
    java::awt::GraphicsEnvironment::getLocalGraphicsEnvironment();
}