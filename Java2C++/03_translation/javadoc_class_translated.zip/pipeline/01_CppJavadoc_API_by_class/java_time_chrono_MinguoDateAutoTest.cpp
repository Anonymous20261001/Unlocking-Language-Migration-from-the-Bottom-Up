#include <chrono>
#include <ctime>
#include <string>

class TemporalAccessor {
public:
    TemporalAccessor() = default;
    virtual ~TemporalAccessor() = default;
};

class ZoneId {
public:
    ZoneId() = default;
    explicit ZoneId(const std::string& id) : id_(id) {}
    std::string id() const { return id_; }
private:
    std::string id_;
};

class Clock {
public:
    Clock() = default;
    virtual ~Clock() = default;
};

class MinguoDate {
public:
    MinguoDate() : year_(0), month_(0), day_(0) {}
    MinguoDate(int year, int month, int day) : year_(year), month_(month), day_(day) {}

    static MinguoDate of(int year, int month, int day) {
        return MinguoDate(year, month, day);
    }

    static MinguoDate from(const TemporalAccessor&) {
        return fromSystem();
    }

    static MinguoDate now() {
        return fromSystem();
    }

    static MinguoDate now(const ZoneId&) {
        return fromSystem();
    }

    static MinguoDate now(const Clock&) {
        return fromSystem();
    }

    int getYear() const { return year_; }
    int getMonth() const { return month_; }
    int getDay() const { return day_; }

private:
    int year_;
    int month_;
    int day_;

    static MinguoDate fromSystem() {
        std::time_t t = std::time(nullptr);
        std::tm* tm = std::localtime(&t);
        int isoYear = tm->tm_year + 1900;
        int month = tm->tm_mon + 1;
        int day = tm->tm_mday;
        return MinguoDate(isoYear - 1911, month, day);
    }
};

void of_test_8947(int p0, int p1, int p2) {
    MinguoDate::of(p0, p1, p2);
}

void from_test_8948(TemporalAccessor p0) {
    MinguoDate::from(p0);
}

void now_test_8949() {
    MinguoDate::now();
}

void now_test_8950(ZoneId p0) {
    MinguoDate::now(p0);
}

void now_test_8951(Clock p0) {
    MinguoDate::now(p0);
}