#include <cstddef>

class Point {
public:
    int x;
    int y;

    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class DataBuffer {
public:
    DataBuffer() {}
    virtual ~DataBuffer() {}
};

class SampleModel {
public:
    SampleModel() {}
    virtual ~SampleModel() {}
};

class Raster {
public:
    virtual ~Raster() {}

    static Raster* createInterleavedRaster(int dataType, int w, int h, int bands,
                                           int scanlineStride, int* bandOffsets,
                                           const Point& location) {
        return nullptr;
    }

    static Raster* createInterleavedRaster(int dataType, int w, int h, int bands,
                                           const Point& location) {
        return nullptr;
    }

    static Raster* createInterleavedRaster(DataBuffer& dataBuffer, int w, int h,
                                           int scanlineStride, int pixelStride,
                                           int* bandOffsets, const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(int dataType, int w, int h, int* bandMasks,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(int dataType, int w, int h, int bitsPerPixel,
                                      int scanlineStride, const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int scanlineStride, int* bandMasks,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createPackedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int bitsPerPixel, const Point& location) {
        return nullptr;
    }

    static Raster* createWritableRaster(SampleModel& sampleModel, const Point& location) {
        return nullptr;
    }

    static Raster* createWritableRaster(SampleModel& sampleModel, DataBuffer& dataBuffer,
                                        const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(DataBuffer& dataBuffer, int w, int h,
                                      int scanlineStride, int* bankIndices,
                                      int* bandOffsets, const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(int dataType, int w, int h, int bands,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createBandedRaster(int dataType, int w, int h, int scanlineStride,
                                      int* bankIndices, int* bandOffsets,
                                      const Point& location) {
        return nullptr;
    }

    static Raster* createRaster(SampleModel& sampleModel, DataBuffer& dataBuffer,
                                const Point& location) {
        return nullptr;
    }
};

void createInterleavedRaster_test_10325(int p0, int p1, int p2, int p3, int p4,
                                        int* p5, Point p6) {
    Raster::createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
}

void createInterleavedRaster_test_10326(int p0, int p1, int p2, int p3, Point p4) {
    Raster::createInterleavedRaster(p0, p1, p2, p3, p4);
}

void createInterleavedRaster_test_10327(DataBuffer& p0, int p1, int p2, int p3,
                                        int p4, int* p5, Point p6) {
    Raster::createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
}

void createPackedRaster_test_10328(int p0, int p1, int p2, int* p3, Point p4) {
    Raster::createPackedRaster(p0, p1, p2, p3, p4);
}

void createPackedRaster_test_10329(int p0, int p1, int p2, int p3, int p4, Point p5) {
    Raster::createPackedRaster(p0, p1, p2, p3, p4, p5);
}

void createPackedRaster_test_10330(DataBuffer& p0, int p1, int p2, int p3,
                                   int* p4, Point p5) {
    Raster::createPackedRaster(p0, p1, p2, p3, p4, p5);
}

void createPackedRaster_test_10331(DataBuffer& p0, int p1, int p2, int p3, Point p4) {
    Raster::createPackedRaster(p0, p1, p2, p3, p4);
}

void createWritableRaster_test_10332(SampleModel& p0, Point p1) {
    Raster::createWritableRaster(p0, p1);
}

void createWritableRaster_test_10333(SampleModel& p0, DataBuffer& p1, Point p2) {
    Raster::createWritableRaster(p0, p1, p2);
}

void createBandedRaster_test_10334(DataBuffer& p0, int p1, int p2, int p3,
                                   int* p4, int* p5, Point p6) {
    Raster::createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
}

void createBandedRaster_test_10335(int p0, int p1, int p2, int p3, Point p4) {
    Raster::createBandedRaster(p0, p1, p2, p3, p4);
}

void createBandedRaster_test_10336(int p0, int p1, int p2, int p3,
                                   int* p4, int* p5, Point p6) {
    Raster::createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
}

void createRaster_test_10337(SampleModel& p0, DataBuffer& p1, Point p2) {
    Raster::createRaster(p0, p1, p2);
}