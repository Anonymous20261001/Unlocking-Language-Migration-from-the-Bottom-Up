#include <string>
#include <stdexcept>
#include <cstddef>
#include <utility>

class Charset {
public:
    explicit Charset(std::string name) : name_(std::move(name)) {}
    const std::string& name() const { return name_; }
private:
    std::string name_;
};

class URLDecoder {
public:
    static std::string decode(const std::string& s) {
        return decode(s, Charset("UTF-8"));
    }

    static std::string decode(const std::string& s, const Charset& charset) {
        std::string decoded;
        decoded.reserve(s.size());

        for (std::size_t i = 0; i < s.size(); ++i) {
            char c = s[i];
            if (c == '+') {
                decoded.push_back(' ');
            } else if (c == '%') {
                if (i + 2 >= s.size()) {
                    throw std::invalid_argument("URLDecoder: Incomplete trailing escape (%) pattern");
                }
                int high = hexValue(s[i + 1]);
                int low = hexValue(s[i + 2]);
                if (high == -1 || low == -1) {
                    throw std::invalid_argument("URLDecoder: Illegal hex characters in escape (%) pattern");
                }
                decoded.push_back(static_cast<char>((high << 4) | low));
                i += 2;
            } else {
                decoded.push_back(c);
            }
        }

        const std::string& name = charset.name();
        if (name == "UTF-8" || name == "US-ASCII") {
            return decoded;
        }
        if (name == "ISO-8859-1" || name == "ISO8859-1") {
            return latin1ToUtf8(decoded);
        }
        return decoded;
    }

private:
    static int hexValue(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0';
        }
        if (c >= 'a' && c <= 'f') {
            return c - 'a' + 10;
        }
        if (c >= 'A' && c <= 'F') {
            return c - 'A' + 10;
        }
        return -1;
    }

    static std::string latin1ToUtf8(const std::string& input) {
        std::string output;
        output.reserve(input.size() * 2);
        for (std::size_t i = 0; i < input.size(); ++i) {
            unsigned char ch = static_cast<unsigned char>(input[i]);
            if (ch < 0x80) {
                output.push_back(static_cast<char>(ch));
            } else {
                output.push_back(static_cast<char>(0xC0 | (ch >> 6)));
                output.push_back(static_cast<char>(0x80 | (ch & 0x3F)));
            }
        }
        return output;
    }
};

void decode_test_13265(std::string p0, Charset p1) {
    URLDecoder::decode(p0, p1);
}

void decode_test_13266(std::string p0) {
    URLDecoder::decode(p0);
}