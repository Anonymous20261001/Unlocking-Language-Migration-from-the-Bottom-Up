#include <cstdint>
#include <string>
#include <string_view>
#include <optional>
#include <stdexcept>
#include <limits>
#include <bit>
#include <charconv>
#include <system_error>

namespace java {
namespace lang {

class Long;
class String;
class CharSequence;
class MethodHandles;

class CharSequence {
public:
    virtual ~CharSequence() = default;
    virtual int length() const = 0;
    virtual char charAt(int index) const = 0;
    virtual std::string toString() const = 0;
};

class String : public CharSequence {
private:
    std::string data;
public:
    String() : data() {}
    String(const char* s) : data(s) {}
    String(const std::string& s) : data(s) {}
    String(const String& other) : data(other.data) {}
    String& operator=(const String& other) { data = other.data; return *this; }
    String& operator=(const char* s) { data = s; return *this; }

    int length() const override { return static_cast<int>(data.length()); }
    char charAt(int index) const override { return data.at(index); }
    std::string toString() const override { return data; }
    const std::string& getData() const { return data; }
    bool operator==(const String& other) const { return data == other.data; }
    bool operator!=(const String& other) const { return data != other.data; }
    bool operator<(const String& other) const { return data < other.data; }
    bool operator>(const String& other) const { return data > other.data; }
    bool operator<=(const String& other) const { return data <= other.data; }
    bool operator>=(const String& other) const { return data >= other.data; }
    String operator+(const String& other) const { return String(data + other.data); }
    String& operator+=(const String& other) { data += other.data; return *this; }
    String& operator+=(const char* s) { data += s; return *this; }
    String& operator+=(char c) { data += c; return *this; }
    char operator[](int index) const { return data[index]; }
    char& operator[](int index) { return data[index]; }
    int indexOf(char c) const { return static_cast<int>(data.find(c)); }
    int indexOf(const String& s) const { return static_cast<int>(data.find(s.data)); }
    int indexOf(char c, int fromIndex) const { return static_cast<int>(data.find(c, fromIndex)); }
    int indexOf(const String& s, int fromIndex) const { return static_cast<int>(data.find(s.data, fromIndex)); }
    int lastIndexOf(char c) const { return static_cast<int>(data.rfind(c)); }
    int lastIndexOf(const String& s) const { return static_cast<int>(data.rfind(s.data)); }
    String substring(int beginIndex) const { return String(data.substr(beginIndex)); }
    String substring(int beginIndex, int endIndex) const { return String(data.substr(beginIndex, endIndex - beginIndex)); }
    String toLowerCase() const {
        std::string result = data;
        for (auto& c : result) {
            if (c >= 'A' && c <= 'Z') c = c - 'A' + 'a';
        }
        return String(result);
    }
    String toUpperCase() const {
        std::string result = data;
        for (auto& c : result) {
            if (c >= 'a' && c <= 'z') c = c - 'a' + 'A';
        }
        return String(result);
    }
    String trim() const {
        size_t start = data.find_first_not_of(" \t\n\r\f\v");
        if (start == std::string::npos) return String();
        size_t end = data.find_last_not_of(" \t\n\r\f\v");
        return String(data.substr(start, end - start + 1));
    }
    bool isEmpty() const { return data.empty(); }
    bool startsWith(const String& prefix) const { return data.rfind(prefix.data, 0) == 0; }
    bool endsWith(const String& suffix) const {
        if (suffix.data.length() > data.length()) return false;
        return data.compare(data.length() - suffix.data.length(), suffix.data.length(), suffix.data) == 0;
    }
    String replace(char oldChar, char newChar) const {
        std::string result = data;
        for (auto& c : result) {
            if (c == oldChar) c = newChar;
        }
        return String(result);
    }
    String replace(const String& target, const String& replacement) const {
        std::string result = data;
        size_t pos = 0;
        while ((pos = result.find(target.data, pos)) != std::string::npos) {
            result.replace(pos, target.data.length(), replacement.data);
            pos += replacement.data.length();
        }
        return String(result);
    }
    bool contains(const String& s) const { return data.find(s.data) != std::string::npos; }
    bool contains(char c) const { return data.find(c) != std::string::npos; }
    int compareTo(const String& other) const { return data.compare(other.data); }
    static String valueOf(int i) { return String(std::to_string(i)); }
    static String valueOf(long l) { return String(std::to_string(l)); }
    static String valueOf(double d) { return String(std::to_string(d)); }
    static String valueOf(float f) { return String(std::to_string(f)); }
    static String valueOf(bool b) { return b ? String("true") : String("false"); }
    static String valueOf(char c) { return String(std::string(1, c)); }
    static String valueOf(const char* s) { return String(s); }
    static String valueOf(const String& s) { return s; }
    static String valueOf(const void* obj) {
        if (obj == nullptr) return String("null");
        return String("@" + std::to_string(reinterpret_cast<uintptr_t>(obj)));
    }
    static String format(const char* fmt, ...) {
        // Simplified: just return the format string
        return String(fmt);
    }
    static String join(const String& delimiter, const std::vector<String>& elements) {
        std::string result;
        for (size_t i = 0; i < elements.size(); ++i) {
            if (i > 0) result += delimiter.data;
            result += elements[i].data;
        }
        return String(result);
    }
    static String join(const String& delimiter, const std::initializer_list<String>& elements) {
        std::string result;
        bool first = true;
        for (const auto& elem : elements) {
            if (!first) result += delimiter.data;
            result += elem.data;
            first = false;
        }
        return String(result);
    }
    std::vector<String> split(const String& regex) const {
        // Simplified split: split by single character
        std::vector<String> result;
        if (regex.data.empty()) {
            for (char c : data) result.push_back(String(std::string(1, c)));
            return result;
        }
        std::string delimiter = regex.data;
        size_t start = 0;
        size_t end = data.find(delimiter);
        while (end != std::string::npos) {
            result.push_back(String(data.substr(start, end - start)));
            start = end + delimiter.length();
            end = data.find(delimiter, start);
        }
        result.push_back(String(data.substr(start)));
        return result;
    }
    bool equals(const String& other) const { return data == other.data; }
    int hashCode() const {
        int hash = 0;
        for (char c : data) {
            hash = 31 * hash + c;
        }
        return hash;
    }
    int length() const { return static_cast<int>(data.length()); }
    bool isEmpty() const { return data.empty(); }
    char charAt(int index) const { return data.at(index); }
    std::string getData() const { return data; }
};

class Long {
private:
    int64_t value;
public:
    static constexpr int64_t MIN_VALUE = std::numeric_limits<int64_t>::min();
    static constexpr int64_t MAX_VALUE = std::numeric_limits<int64_t>::max();
    static constexpr int SIZE = 64;
    static constexpr int BYTES = 8;
    static constexpr int64_t MIN_VALUE_LONG = MIN_VALUE;
    static constexpr int64_t MAX_VALUE_LONG = MAX_VALUE;

    Long() : value(0) {}
    Long(int64_t v) : value(v) {}
    Long(const String& s) : value(parseLong(s)) {}
    Long(const char* s) : value(parseLong(String(s))) {}

    int64_t longValue() const { return value; }
    int intValue() const { return static_cast<int>(value); }
    short shortValue() const { return static_cast<short>(value); }
    char byteValue() const { return static_cast<char>(value); }
    float floatValue() const { return static_cast<float>(value); }
    double doubleValue() const { return static_cast<double>(value); }

    int compareTo(const Long& other) const { return compare(value, other.value); }
    bool equals(const Long& other) const { return value == other.value; }
    int hashCode() const { return static_cast<int>(value ^ (value >> 32)); }
    String toString() const { return String(std::to_string(value)); }

    static int numberOfLeadingZeros(int64_t i) {
        if (i == 0) return 64;
        return std::countl_zero(static_cast<uint64_t>(i));
    }

    static int numberOfTrailingZeros(int64_t i) {
        if (i == 0) return 64;
        return std::countr_zero(static_cast<uint64_t>(i));
    }

    static int bitCount(int64_t i) {
        return std::popcount(static_cast<uint64_t>(i));
    }

    static int64_t min(int64_t a, int64_t b) {
        return a < b ? a : b;
    }

    static int64_t max(int64_t a, int64_t b) {
        return a > b ? a : b;
    }

    static int signum(int64_t i) {
        return (i > 0) ? 1 : ((i < 0) ? -1 : 0);
    }

    static int64_t expand(int64_t i, int64_t mask) {
        // PDEP operation
        uint64_t result = 0;
        uint64_t src = static_cast<uint64_t>(i);
        uint64_t m = static_cast<uint64_t>(mask);
        uint64_t pos = 0;
        for (int bit = 0; bit < 64; ++bit) {
            if (m & (1ULL << bit)) {
                if (src & (1ULL << pos)) {
                    result |= (1ULL << bit);
                }
                ++pos;
            }
        }
        return static_cast<int64_t>(result);
    }

    static int compareUnsigned(int64_t a, int64_t b) {
        uint64_t ua = static_cast<uint64_t>(a);
        uint64_t ub = static_cast<uint64_t>(b);
        return (ua < ub) ? -1 : ((ua > ub) ? 1 : 0);
    }

    static int64_t divideUnsigned(int64_t dividend, int64_t divisor) {
        if (divisor == 0) throw std::invalid_argument("Division by zero");
        uint64_t udividend = static_cast<uint64_t>(dividend);
        uint64_t udivisor = static_cast<uint64_t>(divisor);
        return static_cast<int64_t>(udividend / udivisor);
    }

    static int64_t remainderUnsigned(int64_t dividend, int64_t divisor) {
        if (divisor == 0) throw std::invalid_argument("Division by zero");
        uint64_t udividend = static_cast<uint64_t>(dividend);
        uint64_t udivisor = static_cast<uint64_t>(divisor);
        return static_cast<int64_t>(udividend % udivisor);
    }

    static int64_t reverse(int64_t i) {
        uint64_t x = static_cast<uint64_t>(i);
        x = ((x & 0x5555555555555555ULL) << 1) | ((x >> 1) & 0x5555555555555555ULL);
        x = ((x & 0x3333333333333333ULL) << 2) | ((x >> 2) & 0x3333333333333333ULL);
        x = ((x & 0x0F0F0F0F0F0F0F0FULL) << 4) | ((x >> 4) & 0x0F0F0F0F0F0F0F0FULL);
        x = ((x & 0x00FF00FF00FF00FFULL) << 8) | ((x >> 8) & 0x00FF00FF00FF00FFULL);
        x = ((x & 0x0000FFFF0000FFFFULL) << 16) | ((x >> 16) & 0x0000FFFF0000FFFFULL);
        x = (x << 32) | (x >> 32);
        return static_cast<int64_t>(x);
    }

    static int64_t reverseBytes(int64_t i) {
        uint64_t x = static_cast<uint64_t>(i);
        x = ((x & 0x00FF00FF00FF00FFULL) << 8) | ((x >> 8) & 0x00FF00FF00FF00FFULL);
        x = ((x & 0x0000FFFF0000FFFFULL) << 16) | ((x >> 16) & 0x0000FFFF0000FFFFULL);
        x = (x << 32) | (x >> 32);
        return static_cast<int64_t>(x);
    }

    static int64_t compress(int64_t i, int64_t mask) {
        // PEXT operation
        uint64_t result = 0;
        uint64_t src = static_cast<uint64_t>(i);
        uint64_t m = static_cast<uint64_t>(mask);
        uint64_t pos = 0;
        for (int bit = 0; bit < 64; ++bit) {
            if (m & (1ULL << bit)) {
                if (src & (1ULL << bit)) {
                    result |= (1ULL << pos);
                }
                ++pos;
            }
        }
        return static_cast<int64_t>(result);
    }

    static Long getLong(const String& nm) {
        return getLong(nm, nullptr);
    }

    static Long getLong(const String& nm, Long val) {
        // Simplified: return default value
        return val;
    }

    static Long getLong(const String& nm, int64_t val) {
        return Long(val);
    }

    static int compare(int64_t a, int64_t b) {
        return (a < b) ? -1 : ((a > b) ? 1 : 0);
    }

    static Long valueOf(int64_t l) {
        return Long(l);
    }

    static Long valueOf(const String& s) {
        return Long(parseLong(s));
    }

    static Long valueOf(const String& s, int radix) {
        return Long(parseLong(s, radix));
    }

    static String toHexString(int64_t i) {
        char buffer[20];
        snprintf(buffer, sizeof(buffer), "%llx", static_cast<unsigned long long>(i));
        return String(buffer);
    }

    static Long decode(const String& nm) {
        std::string s = nm.getData();
        int radix = 10;
        size_t index = 0;
        bool negative = false;
        if (s.length() > 0 && (s[0] == '-' || s[0] == '+')) {
            negative = (s[0] == '-');
            index = 1;
        }
        if (s.length() > index + 1 && s[index] == '0') {
            if (s[index + 1] == 'x' || s[index + 1] == 'X') {
                radix = 16;
                index += 2;
            } else if (s[index + 1] == 'b' || s[index + 1] == 'B') {
                radix = 2;
                index += 2;
            } else {
                radix = 8;
                index += 1;
            }
        }
        std::string digits = s.substr(index);
        int64_t result = 0;
        for (char c : digits) {
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            result = result * radix + digit;
        }
        return Long(negative ? -result : result);
    }

    Long resolveConstantDesc(MethodHandles::Lookup lookup) const {
        return *this;
    }

    std::optional<Long> describeConstable() const {
        return *this;
    }

    static int64_t sum(int64_t a, int64_t b) {
        return a + b;
    }

    static String toUnsignedString(int64_t i) {
        return toUnsignedString(i, 10);
    }

    static String toUnsignedString(int64_t i, int radix) {
        uint64_t u = static_cast<uint64_t>(i);
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (u == 0) return String("0");
        std::string result;
        const char* digits = "0123456789abcdefghijklmnopqrstuvwxyz";
        while (u > 0) {
            result = digits[u % radix] + result;
            u /= radix;
        }
        return String(result);
    }

    static String toOctalString(int64_t i) {
        return toUnsignedString(i, 8);
    }

    static String toBinaryString(int64_t i) {
        return toUnsignedString(i, 2);
    }

    static int64_t highestOneBit(int64_t i) {
        if (i == 0) return 0;
        uint64_t u = static_cast<uint64_t>(i);
        u |= u >> 1;
        u |= u >> 2;
        u |= u >> 4;
        u |= u >> 8;
        u |= u >> 16;
        u |= u >> 32;
        return static_cast<int64_t>(u & ~(u >> 1));
    }

    static int64_t lowestOneBit(int64_t i) {
        return i & (-i);
    }

    static int64_t rotateLeft(int64_t i, int distance) {
        distance &= 63;
        if (distance == 0) return i;
        uint64_t u = static_cast<uint64_t>(i);
        return static_cast<int64_t>((u << distance) | (u >> (64 - distance)));
    }

    static int64_t rotateRight(int64_t i, int distance) {
        distance &= 63;
        if (distance == 0) return i;
        uint64_t u = static_cast<uint64_t>(i);
        return static_cast<int64_t>((u >> distance) | (u << (64 - distance)));
    }

    static int64_t parseLong(const String& s) {
        return parseLong(s, 10);
    }

    static int64_t parseLong(const String& s, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        std::string str = s.getData();
        if (str.empty()) throw std::invalid_argument("Empty string");
        size_t index = 0;
        bool negative = false;
        if (str[0] == '-') {
            negative = true;
            index = 1;
        } else if (str[0] == '+') {
            index = 1;
        }
        if (index >= str.length()) throw std::invalid_argument("Invalid number");
        int64_t result = 0;
        for (; index < str.length(); ++index) {
            char c = str[index];
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return negative ? -result : result;
    }

    static int64_t parseLong(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (beginIndex < 0 || endIndex > s.length() || beginIndex > endIndex) throw std::invalid_argument("Invalid range");
        bool negative = false;
        int index = beginIndex;
        if (index < endIndex && s.charAt(index) == '-') {
            negative = true;
            ++index;
        } else if (index < endIndex && s.charAt(index) == '+') {
            ++index;
        }
        if (index >= endIndex) throw std::invalid_argument("Invalid number");
        int64_t result = 0;
        for (; index < endIndex; ++index) {
            char c = s.charAt(index);
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return negative ? -result : result;
    }

    static int64_t parseUnsignedLong(const String& s) {
        return parseUnsignedLong(s, 10);
    }

    static int64_t parseUnsignedLong(const String& s, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        std::string str = s.getData();
        if (str.empty()) throw std::invalid_argument("Empty string");
        size_t index = 0;
        if (str[0] == '+') index = 1;
        if (index >= str.length()) throw std::invalid_argument("Invalid number");
        uint64_t result = 0;
        for (; index < str.length(); ++index) {
            char c = str[index];
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return static_cast<int64_t>(result);
    }

    static int64_t parseUnsignedLong(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (beginIndex < 0 || endIndex > s.length() || beginIndex > endIndex) throw std::invalid_argument("Invalid range");
        int index = beginIndex;
        if (index < endIndex && s.charAt(index) == '+') ++index;
        if (index >= endIndex) throw std::invalid_argument("Invalid number");
        uint64_t result = 0;
        for (; index < endIndex; ++index) {
            char c = s.charAt(index);
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return static_cast<int64_t>(result);
    }

    String toString() const {
        return String(std::to_string(value));
    }

    static String toString(int64_t i) {
        return String(std::to_string(i));
    }

    static String toString(int64_t i, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (i == 0) return String("0");
        bool negative = i < 0;
        uint64_t u = negative ? static_cast<uint64_t>(-(i + 1)) + 1 : static_cast<uint64_t>(i);
        std::string result;
        const char* digits = "0123456789abcdefghijklmnopqrstuvwxyz";
        while (u > 0) {
            result = digits[u % radix] + result;
            u /= radix;
        }
        if (negative) result = "-" + result;
        return String(result);
    }

    static int hashCode(int64_t value) {
        return static_cast<int>(value ^ (value >> 32));
    }

    static int compareTo(int64_t a, int64_t b) {
        return compare(a, b);
    }

    static bool equals(int64_t a, int64_t b) {
        return a == b;
    }

    static Long valueOf(const String& s, int radix) {
        return Long(parseLong(s, radix));
    }

    static Long valueOf(const char* s) {
        return Long(String(s));
    }

    static Long valueOf(const char* s, int radix) {
        return Long(parseLong(String(s), radix));
    }

    static Long decode(const char* nm) {
        return decode(String(nm));
    }

    static Long getLong(const char* nm) {
        return getLong(String(nm));
    }

    static Long getLong(const char* nm, Long val) {
        return getLong(String(nm), val);
    }

    static Long getLong(const char* nm, int64_t val) {
        return getLong(String(nm), val);
    }

    static int64_t parseLong(const char* s) {
        return parseLong(String(s));
    }

    static int64_t parseLong(const char* s, int radix) {
        return parseLong(String(s), radix);
    }

    static int64_t parseUnsignedLong(const char* s) {
        return parseUnsignedLong(String(s));
    }

    static int64_t parseUnsignedLong(const char* s, int radix) {
        return parseUnsignedLong(String(s), radix);
    }

    static String toUnsignedString(int64_t i, int radix) {
        return toUnsignedString(i, radix);
    }

    static String toHexString(int64_t i) {
        return toHexString(i);
    }

    static String toOctalString(int64_t i) {
        return toOctalString(i);
    }

    static String toBinaryString(int64_t i) {
        return toBinaryString(i);
    }

    static int64_t highestOneBit(int64_t i) {
        return highestOneBit(i);
    }

    static int64_t lowestOneBit(int64_t i) {
        return lowestOneBit(i);
    }

    static int64_t rotateLeft(int64_t i, int distance) {
        return rotateLeft(i, distance);
    }

    static int64_t rotateRight(int64_t i, int distance) {
        return rotateRight(i, distance);
    }

    static int64_t sum(int64_t a, int64_t b) {
        return a + b;
    }

    static int64_t min(int64_t a, int64_t b) {
        return a < b ? a : b;
    }

    static int64_t max(int64_t a, int64_t b) {
        return a > b ? a : b;
    }

    static int signum(int64_t i) {
        return (i > 0) ? 1 : ((i < 0) ? -1 : 0);
    }

    static int numberOfLeadingZeros(int64_t i) {
        return numberOfLeadingZeros(i);
    }

    static int numberOfTrailingZeros(int64_t i) {
        return numberOfTrailingZeros(i);
    }

    static int bitCount(int64_t i) {
        return bitCount(i);
    }

    static int64_t reverse(int64_t i) {
        return reverse(i);
    }

    static int64_t reverseBytes(int64_t i) {
        return reverseBytes(i);
    }

    static int64_t expand(int64_t i, int64_t mask) {
        return expand(i, mask);
    }

    static int64_t compress(int64_t i, int64_t mask) {
        return compress(i, mask);
    }

    static int compareUnsigned(int64_t a, int64_t b) {
        return compareUnsigned(a, b);
    }

    static int64_t divideUnsigned(int64_t dividend, int64_t divisor) {
        return divideUnsigned(dividend, divisor);
    }

    static int64_t remainderUnsigned(int64_t dividend, int64_t divisor) {
        return remainderUnsigned(dividend, divisor);
    }

    static int compare(int64_t a, int64_t b) {
        return (a < b) ? -1 : ((a > b) ? 1 : 0);
    }

    static Long valueOf(int64_t l) {
        return Long(l);
    }

    static Long valueOf(const String& s) {
        return Long(parseLong(s));
    }

    static Long valueOf(const String& s, int radix) {
        return Long(parseLong(s, radix));
    }

    static String toHexString(int64_t i) {
        char buffer[20];
        snprintf(buffer, sizeof(buffer), "%llx", static_cast<unsigned long long>(i));
        return String(buffer);
    }

    static Long decode(const String& nm) {
        std::string s = nm.getData();
        int radix = 10;
        size_t index = 0;
        bool negative = false;
        if (s.length() > 0 && (s[0] == '-' || s[0] == '+')) {
            negative = (s[0] == '-');
            index = 1;
        }
        if (s.length() > index + 1 && s[index] == '0') {
            if (s[index + 1] == 'x' || s[index + 1] == 'X') {
                radix = 16;
                index += 2;
            } else if (s[index + 1] == 'b' || s[index + 1] == 'B') {
                radix = 2;
                index += 2;
            } else {
                radix = 8;
                index += 1;
            }
        }
        std::string digits = s.substr(index);
        int64_t result = 0;
        for (char c : digits) {
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            result = result * radix + digit;
        }
        return Long(negative ? -result : result);
    }

    Long resolveConstantDesc(MethodHandles::Lookup lookup) const {
        return *this;
    }

    std::optional<Long> describeConstable() const {
        return *this;
    }

    static int64_t sum(int64_t a, int64_t b) {
        return a + b;
    }

    static String toUnsignedString(int64_t i) {
        return toUnsignedString(i, 10);
    }

    static String toUnsignedString(int64_t i, int radix) {
        uint64_t u = static_cast<uint64_t>(i);
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (u == 0) return String("0");
        std::string result;
        const char* digits = "0123456789abcdefghijklmnopqrstuvwxyz";
        while (u > 0) {
            result = digits[u % radix] + result;
            u /= radix;
        }
        return String(result);
    }

    static String toOctalString(int64_t i) {
        return toUnsignedString(i, 8);
    }

    static String toBinaryString(int64_t i) {
        return toUnsignedString(i, 2);
    }

    static int64_t highestOneBit(int64_t i) {
        if (i == 0) return 0;
        uint64_t u = static_cast<uint64_t>(i);
        u |= u >> 1;
        u |= u >> 2;
        u |= u >> 4;
        u |= u >> 8;
        u |= u >> 16;
        u |= u >> 32;
        return static_cast<int64_t>(u & ~(u >> 1));
    }

    static int64_t lowestOneBit(int64_t i) {
        return i & (-i);
    }

    static int64_t rotateLeft(int64_t i, int distance) {
        distance &= 63;
        if (distance == 0) return i;
        uint64_t u = static_cast<uint64_t>(i);
        return static_cast<int64_t>((u << distance) | (u >> (64 - distance)));
    }

    static int64_t rotateRight(int64_t i, int distance) {
        distance &= 63;
        if (distance == 0) return i;
        uint64_t u = static_cast<uint64_t>(i);
        return static_cast<int64_t>((u >> distance) | (u << (64 - distance)));
    }

    static int64_t parseLong(const String& s) {
        return parseLong(s, 10);
    }

    static int64_t parseLong(const String& s, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        std::string str = s.getData();
        if (str.empty()) throw std::invalid_argument("Empty string");
        size_t index = 0;
        bool negative = false;
        if (str[0] == '-') {
            negative = true;
            index = 1;
        } else if (str[0] == '+') {
            index = 1;
        }
        if (index >= str.length()) throw std::invalid_argument("Invalid number");
        int64_t result = 0;
        for (; index < str.length(); ++index) {
            char c = str[index];
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return negative ? -result : result;
    }

    static int64_t parseLong(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (beginIndex < 0 || endIndex > s.length() || beginIndex > endIndex) throw std::invalid_argument("Invalid range");
        bool negative = false;
        int index = beginIndex;
        if (index < endIndex && s.charAt(index) == '-') {
            negative = true;
            ++index;
        } else if (index < endIndex && s.charAt(index) == '+') {
            ++index;
        }
        if (index >= endIndex) throw std::invalid_argument("Invalid number");
        int64_t result = 0;
        for (; index < endIndex; ++index) {
            char c = s.charAt(index);
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return negative ? -result : result;
    }

    static int64_t parseUnsignedLong(const String& s) {
        return parseUnsignedLong(s, 10);
    }

    static int64_t parseUnsignedLong(const String& s, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        std::string str = s.getData();
        if (str.empty()) throw std::invalid_argument("Empty string");
        size_t index = 0;
        if (str[0] == '+') index = 1;
        if (index >= str.length()) throw std::invalid_argument("Invalid number");
        uint64_t result = 0;
        for (; index < str.length(); ++index) {
            char c = str[index];
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return static_cast<int64_t>(result);
    }

    static int64_t parseUnsignedLong(const CharSequence& s, int beginIndex, int endIndex, int radix) {
        if (radix < 2 || radix > 36) throw std::invalid_argument("Invalid radix");
        if (beginIndex < 0 || endIndex > s.length() || beginIndex > endIndex) throw std::invalid_argument("Invalid range");
        int index = beginIndex;
        if (index < endIndex && s.charAt(index) == '+') ++index;
        if (index >= endIndex) throw std::invalid_argument("Invalid number");
        uint64_t result = 0;
        for (; index < endIndex; ++index) {
            char c = s.charAt(index);
            int digit;
            if (c >= '0' && c <= '9') digit = c - '0';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z') digit = c - 'A' + 10;
            else throw std::invalid_argument("Invalid digit");
            if (digit >= radix) throw std::invalid_argument("Digit out of range");
            result = result * radix + digit;
        }
        return static_cast<int64_t>(result);
    }
};

class MethodHandles {
public:
    class Lookup {
    public:
        Lookup() = default;
    };
};

} // namespace lang
} // namespace java

// Test functions
void numberOfLeadingZeros_test_8143(long p0) {
    java::lang::Long::numberOfLeadingZeros(p0);
}

void numberOfTrailingZeros_test_8144(long p0) {
    java::lang::Long::numberOfTrailingZeros(p0);
}

void bitCount_test_8145(long p0) {
    java::lang::Long::bitCount(p0);
}

void min_test_8146(long p0, long p1) {
    java::lang::Long::min(p0, p1);
}

void max_test_8147(long p0, long p1) {
    java::lang::Long::max(p0, p1);
}

void signum_test_8148(long p0) {
    java::lang::Long::signum(p0);
}

void expand_test_8149(long p0, long p1) {
    java::lang::Long::expand(p0, p1);
}

void compareUnsigned_test_8150(long p0, long p1) {
    java::lang::Long::compareUnsigned(p0, p1);
}

void divideUnsigned_test_8151(long p0, long p1) {
    java::lang::Long::divideUnsigned(p0, p1);
}

void remainderUnsigned_test_8152(long p0, long p1) {
    java::lang::Long::remainderUnsigned(p0, p1);
}

void reverse_test_8153(long p0) {
    java::lang::Long::reverse(p0);
}

void reverseBytes_test_8154(long p0) {
    java::lang::Long::reverseBytes(p0);
}

void compress_test_8155(long p0, long p1) {
    java::lang::Long::compress(p0, p1);
}

void compareTo_test_8156(java::lang::Long p0, java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.compareTo(p0);
}

void getLong_test_8157(java::lang::String p0, java::lang::Long p1) {
    java::lang::Long::getLong(p0, p1);
}

void getLong_test_8158(java::lang::String p0) {
    java::lang::Long::getLong(p0);
}

void getLong_test_8159(java::lang::String p0, long p1) {
    java::lang::Long::getLong(p0, p1);
}

void compare_test_8160(long p0, long p1) {
    java::lang::Long::compare(p0, p1);
}

void byteValue_test_8161(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.byteValue();
}

void shortValue_test_8162(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.shortValue();
}

void intValue_test_8163(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.intValue();
}

void longValue_test_8164(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.longValue();
}

void floatValue_test_8165(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.floatValue();
}

void doubleValue_test_8166(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.doubleValue();
}

void valueOf_test_8167(long p0) {
    java::lang::Long::valueOf(p0);
}

void valueOf_test_8168(java::lang::String p0) {
    java::lang::Long::valueOf(p0);
}

void valueOf_test_8169(java::lang::String p0, int p1) {
    java::lang::Long::valueOf(p0, p1);
}

void toHexString_test_8170(long p0) {
    java::lang::Long::toHexString(p0);
}

void decode_test_8171(java::lang::String p0) {
    java::lang::Long::decode(p0);
}

void resolveConstantDesc_test_8172(java::lang::MethodHandles::Lookup p0, java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.resolveConstantDesc(p0);
}

void describeConstable_test_8173(java::lang::String c0) {
    java::lang::Long instance(c0);
    instance.describeConstable();
}

void sum_test_8174(long p0, long p1) {
    java::lang::Long::sum(p0, p1);
}

void toUnsignedString_test_8175(long p0) {
    java::lang::Long::toUnsignedString(p0);
}

void toUnsignedString_test_8176(long p0, int p1) {
    java::lang::Long::toUnsignedString(p0, p1);
}

void toOctalString_test_8177(long p0) {
    java::lang::Long::toOctalString(p0);
}

void toBinaryString_test_8178(long p0) {
    java::lang::Long::toBinaryString(p0);
}

void highestOneBit_test_8179(long p0) {
    java::lang::Long::highestOneBit(p0);
}

void lowestOneBit_test_8180(long p0) {
    java::lang::Long::lowestOneBit(p0);
}

void rotateLeft_test_8181(long p0, int p1) {
    java::lang::Long::rotateLeft(p0, p1);
}

void rotateRight_test_8182(long p0, int p1) {
    java::lang::Long::rotateRight(p0, p1);
}

void parseLong_test_8183(java::lang::String p0) {
    java::lang::Long::parseLong(p0);
}

void parseLong_test_8184(java::lang::String p0, int p1) {
    java::lang::Long::parseLong(p0, p1);
}

void parseLong_test_8185(java::lang::CharSequence p0, int p1, int p2, int p3) {
    java::lang::Long::parseLong(p0, p1, p2, p3);
}

void parseUnsignedLong_test_8186(java::lang::String p0) {
    java::lang::Long::parseUnsignedLong(p0);
}

void parseUnsignedLong_test_8187(java::lang::String p0, int p1) {
    java::lang::Long::parseUnsignedLong(p0, p1);
}

void parseUnsignedLong_test_8188(java::lang::CharSequence p0, int p1, int p2, int p3) {
    java::lang::Long::parseUnsignedLong(p0, p1, p2, p3);
}