#include <cstddef>

class Graphics {
public:
  Graphics() {}
  virtual ~Graphics() {}
};

class Image {
public:
  Image() {}
  virtual ~Image() {}
};

class LayoutManager {
public:
  LayoutManager() {}
  virtual ~LayoutManager() {}
};

class TransferHandler {
public:
  TransferHandler() {}
  virtual ~TransferHandler() {}
};

class AccessibleContext {
public:
  AccessibleContext() {}
  virtual ~AccessibleContext() {}
};

class JMenuBar;
class JLayeredPane;
class JRootPane;

class Component {
public:
  Component() {}
  virtual ~Component() {}
  virtual Graphics* getGraphics() { return nullptr; }
  virtual void repaint(long tm, int x, int y, int width, int height) {}
  virtual void update(Graphics* g) {}
};

class Container : public Component {
public:
  Container() {}
  virtual ~Container() {}
  void setLayout(LayoutManager* mgr) {}
  void remove(Component* comp) {}
};

class JMenuBar : public Component {
public:
  JMenuBar() {}
};

class JLayeredPane : public Container {
public:
  JLayeredPane() {}
};

class JRootPane : public Container {
public:
  JRootPane() {}
};

class JFrame : public Container {
private:
  static bool defaultLookAndFeelDecorated;
  Container* contentPane;
  JMenuBar* menuBar;
  JLayeredPane* layeredPane;
  Component* glassPane;
  int defaultCloseOperation;
  Image* iconImage;
  JRootPane* rootPane;
  TransferHandler* transferHandler;
  AccessibleContext* accessibleContext;

public:
  JFrame() {
    contentPane = new Container();
    menuBar = nullptr;
    layeredPane = new JLayeredPane();
    glassPane = new Component();
    defaultCloseOperation = 0;
    iconImage = nullptr;
    rootPane = new JRootPane();
    transferHandler = nullptr;
    accessibleContext = new AccessibleContext();
  }

  virtual ~JFrame() override {
    delete contentPane;
    delete layeredPane;
    delete glassPane;
    delete rootPane;
    delete accessibleContext;
  }

  Container* getContentPane() { return contentPane; }

  static bool isDefaultLookAndFeelDecorated() { return defaultLookAndFeelDecorated; }

  JMenuBar* getJMenuBar() { return menuBar; }

  void setJMenuBar(JMenuBar* mb) { menuBar = mb; }

  void setContentPane(Container* c) { contentPane = c; }

  JLayeredPane* getLayeredPane() { return layeredPane; }

  void setLayeredPane(JLayeredPane* lp) { layeredPane = lp; }

  Component* getGlassPane() { return glassPane; }

  void setGlassPane(Component* c) { glassPane = c; }

  void setDefaultCloseOperation(int op) { defaultCloseOperation = op; }

  int getDefaultCloseOperation() { return defaultCloseOperation; }

  void setIconImage(Image* img) { iconImage = img; }

  static void setDefaultLookAndFeelDecorated(bool b) { defaultLookAndFeelDecorated = b; }

  Graphics* getGraphics() override { return nullptr; }

  JRootPane* getRootPane() { return rootPane; }

  void repaint(long tm, int x, int y, int width, int height) override {}

  void setTransferHandler(TransferHandler* th) { transferHandler = th; }

  TransferHandler* getTransferHandler() { return transferHandler; }

  AccessibleContext* getAccessibleContext() { return accessibleContext; }

  void setLayout(LayoutManager* mgr) { Container::setLayout(mgr); }

  void remove(Component* comp) { Container::remove(comp); }

  void update(Graphics* g) override { Component::update(g); }
};

bool JFrame::defaultLookAndFeelDecorated = false;

void getContentPane_test_6253() {
  JFrame instance;
  instance.getContentPane();
}

void isDefaultLookAndFeelDecorated_test_6254() {
  JFrame::isDefaultLookAndFeelDecorated();
}

void getJMenuBar_test_6255() {
  JFrame instance;
  instance.getJMenuBar();
}

void setJMenuBar_test_6256(JMenuBar* p0) {
  JFrame instance;
  instance.setJMenuBar(p0);
}

void setContentPane_test_6257(Container* p0) {
  JFrame instance;
  instance.setContentPane(p0);
}

void getLayeredPane_test_6258() {
  JFrame instance;
  instance.getLayeredPane();
}

void setLayeredPane_test_6259(JLayeredPane* p0) {
  JFrame instance;
  instance.setLayeredPane(p0);
}

void getGlassPane_test_6260() {
  JFrame instance;
  instance.getGlassPane();
}

void setGlassPane_test_6261(Component* p0) {
  JFrame instance;
  instance.setGlassPane(p0);
}

void setDefaultCloseOperation_test_6262(int p0) {
  JFrame instance;
  instance.setDefaultCloseOperation(p0);
}

void getDefaultCloseOperation_test_6263() {
  JFrame instance;
  instance.getDefaultCloseOperation();
}

void setIconImage_test_6264(Image* p0) {
  JFrame instance;
  instance.setIconImage(p0);
}

void setDefaultLookAndFeelDecorated_test_6265(bool p0) {
  JFrame::setDefaultLookAndFeelDecorated(p0);
}

void getGraphics_test_6266() {
  JFrame instance;
  instance.getGraphics();
}

void getRootPane_test_6267() {
  JFrame instance;
  instance.getRootPane();
}

void repaint_test_6268(long p0, int p1, int p2, int p3, int p4) {
  JFrame instance;
  instance.repaint(p0, p1, p2, p3, p4);
}

void setTransferHandler_test_6269(TransferHandler* p0) {
  JFrame instance;
  instance.setTransferHandler(p0);
}

void getTransferHandler_test_6270() {
  JFrame instance;
  instance.getTransferHandler();
}

void getAccessibleContext_test_6271() {
  JFrame instance;
  instance.getAccessibleContext();
}

void setLayout_test_6272(LayoutManager* p0) {
  JFrame instance;
  instance.setLayout(p0);
}

void remove_test_6273(Component* p0) {
  JFrame instance;
  instance.remove(p0);
}

void update_test_6274(Graphics* p0) {
  JFrame instance;
  instance.update(p0);
}