#include <string>

class ZoneId {
public:
    ZoneId() : id_("UTC") {}
    explicit ZoneId(const std::string& id) : id_(id) {}
private:
    std::string id_;
};

class Duration {
public:
    Duration() : seconds_(0), nanos_(0) {}
private:
    long long seconds_;
    int nanos_;
};

class Instant {
public:
    Instant() : seconds_(0), nanos_(0) {}
private:
    long long seconds_;
    int nanos_;
};

class Clock {
public:
    Clock() : zone_(), offset_(), instant_() {}

    static Clock offset(Clock baseClock, Duration offsetDuration) {
        return Clock();
    }

    static Clock system(ZoneId zone) {
        return Clock();
    }

    static Clock fixed(Instant fixedInstant, ZoneId zone) {
        return Clock();
    }

    static Clock systemUTC() {
        return Clock();
    }

    static Clock systemDefaultZone() {
        return Clock();
    }

    static Clock tickMillis(ZoneId zone) {
        return Clock();
    }

    static Clock tickSeconds(ZoneId zone) {
        return Clock();
    }

    static Clock tickMinutes(ZoneId zone) {
        return Clock();
    }

    static Clock tick(Clock baseClock, Duration tickDuration) {
        return Clock();
    }

private:
    ZoneId zone_;
    Duration offset_;
    Instant instant_;
};

void offset_test_2329(Clock p0, Duration p1) {
    Clock::offset(p0, p1);
}

void system_test_2330(ZoneId p0) {
    Clock::system(p0);
}

void fixed_test_2331(Instant p0, ZoneId p1) {
    Clock::fixed(p0, p1);
}

void systemUTC_test_2332() {
    Clock::systemUTC();
}

void systemDefaultZone_test_2333() {
    Clock::systemDefaultZone();
}

void tickMillis_test_2334(ZoneId p0) {
    Clock::tickMillis(p0);
}

void tickSeconds_test_2335(ZoneId p0) {
    Clock::tickSeconds(p0);
}

void tickMinutes_test_2336(ZoneId p0) {
    Clock::tickMinutes(p0);
}

void tick_test_2337(Clock p0, Duration p1) {
    Clock::tick(p0, p1);
}
