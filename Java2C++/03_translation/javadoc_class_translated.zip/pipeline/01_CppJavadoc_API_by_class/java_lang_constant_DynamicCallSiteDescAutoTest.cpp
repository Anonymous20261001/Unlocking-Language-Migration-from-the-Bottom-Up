#include <string>
#include <vector>

class ConstantDesc {
public:
    virtual ~ConstantDesc() = default;
};

class DirectMethodHandleDesc : public ConstantDesc {
public:
    DirectMethodHandleDesc() = default;
};

class MethodTypeDesc : public ConstantDesc {
public:
    MethodTypeDesc() = default;
};

class DynamicCallSiteDesc {
public:
    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2, const std::vector<ConstantDesc*>& p3) {
        return DynamicCallSiteDesc();
    }

    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, MethodTypeDesc* p1) {
        return DynamicCallSiteDesc();
    }

    static DynamicCallSiteDesc of(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2) {
        return DynamicCallSiteDesc();
    }

private:
    DynamicCallSiteDesc() = default;
};

void of_test_4417(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2, const std::vector<ConstantDesc*>& p3) {
    DynamicCallSiteDesc::of(p0, p1, p2, p3);
}

void of_test_4418(DirectMethodHandleDesc* p0, MethodTypeDesc* p1) {
    DynamicCallSiteDesc::of(p0, p1);
}

void of_test_4419(DirectMethodHandleDesc* p0, const std::string& p1, MethodTypeDesc* p2) {
    DynamicCallSiteDesc::of(p0, p1, p2);
}