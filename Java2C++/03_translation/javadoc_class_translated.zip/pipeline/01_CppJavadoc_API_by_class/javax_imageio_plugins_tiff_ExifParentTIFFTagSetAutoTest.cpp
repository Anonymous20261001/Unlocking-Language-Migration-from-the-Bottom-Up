#include <cstddef>

class ExifParentTIFFTagSet {
public:
    static ExifParentTIFFTagSet& getInstance() {
        static ExifParentTIFFTagSet instance;
        return instance;
    }

private:
    ExifParentTIFFTagSet() = default;
    ExifParentTIFFTagSet(const ExifParentTIFFTagSet&) = delete;
    ExifParentTIFFTagSet& operator=(const ExifParentTIFFTagSet&) = delete;
};

void getInstance_test_4663() {
    ExifParentTIFFTagSet::getInstance();
}