class FocusManager {
public:
    virtual ~FocusManager() {}

    static bool isFocusManagerEnabled() {
        return enabled;
    }

    static void setCurrentManager(FocusManager* newManager) {
        currentManager = newManager;
    }

    static FocusManager* getCurrentManager() {
        if (currentManager != nullptr) {
            return currentManager;
        }
        static FocusManager defaultManager;
        return &defaultManager;
    }

    static void disableSwingFocusManager() {
        enabled = false;
    }

protected:
    FocusManager() {}

private:
    static FocusManager* currentManager;
    static bool enabled;
};

FocusManager* FocusManager::currentManager = nullptr;
bool FocusManager::enabled = true;

void isFocusManagerEnabled_test_4917() {
    FocusManager::isFocusManagerEnabled();
}

void setCurrentManager_test_4918(FocusManager* p0) {
    FocusManager::setCurrentManager(p0);
}

void getCurrentManager_test_4919() {
    FocusManager::getCurrentManager();
}

void disableSwingFocusManager_test_4920() {
    FocusManager::disableSwingFocusManager();
}