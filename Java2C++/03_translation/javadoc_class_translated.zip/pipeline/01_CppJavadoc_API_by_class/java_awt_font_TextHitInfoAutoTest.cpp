#include <cstddef>

class TextHitInfo {
private:
    int charIndex;
    bool leadingEdge;

    TextHitInfo(int charIndex, bool leadingEdge) : charIndex(charIndex), leadingEdge(leadingEdge) {}

public:
    static TextHitInfo trailing(int charIndex) {
        return TextHitInfo(charIndex, false);
    }

    static TextHitInfo leading(int charIndex) {
        return TextHitInfo(charIndex, true);
    }

    static TextHitInfo beforeOffset(int offset) {
        return leading(offset);
    }

    static TextHitInfo afterOffset(int offset) {
        if (offset == 0) {
            return leading(0);
        } else {
            return trailing(offset - 1);
        }
    }

    int getCharIndex() const {
        return charIndex;
    }

    bool isLeadingEdge() const {
        return leadingEdge;
    }
};

void trailing_test_12587(int p0) {
    TextHitInfo::trailing(p0);
}

void leading_test_12588(int p0) {
    TextHitInfo::leading(p0);
}

void beforeOffset_test_12589(int p0) {
    TextHitInfo::beforeOffset(p0);
}

void afterOffset_test_12590(int p0) {
    TextHitInfo::afterOffset(p0);
}
