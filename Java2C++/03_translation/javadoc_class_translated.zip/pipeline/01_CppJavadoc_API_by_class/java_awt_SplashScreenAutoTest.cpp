#include <cstddef>

class SplashScreen {
public:
    static SplashScreen* getSplashScreen() {
        return nullptr;
    }

private:
    SplashScreen() = default;
};

void getSplashScreen_test_11313() {
    SplashScreen::getSplashScreen();
}