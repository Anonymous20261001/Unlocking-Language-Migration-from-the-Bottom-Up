#include <cstdint>

class Flow {
public:
    static int defaultBufferSize() {
        return 256;
    }
};

void defaultBufferSize_test_4895() {
    Flow::defaultBufferSize();
}