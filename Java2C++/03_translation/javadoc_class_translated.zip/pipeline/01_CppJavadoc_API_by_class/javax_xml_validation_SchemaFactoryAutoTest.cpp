#include <string>

class ClassLoader {
public:
    ClassLoader() = default;
};

class SchemaFactory {
public:
    static SchemaFactory* newDefaultInstance() {
        return new SchemaFactory();
    }

    static SchemaFactory* newInstance(const std::string&, const std::string&, ClassLoader*) {
        return new SchemaFactory();
    }

    static SchemaFactory* newInstance(const std::string&) {
        return new SchemaFactory();
    }
};

void newDefaultInstance_test_10856() {
    SchemaFactory::newDefaultInstance();
}

void newInstance_test_10857(const std::string& p0, const std::string& p1, ClassLoader* p2) {
    SchemaFactory::newInstance(p0, p1, p2);
}

void newInstance_test_10858(const std::string& p0) {
    SchemaFactory::newInstance(p0);
}