#include <string>

class Component {};
class Image {};
class Icon {};
class LabelUI {};
class AccessibleContext {};

class JLabel {
public:
    JLabel() {}

    int getDisplayedMnemonic() const {
        return mnemonic;
    }

    void setDisplayedMnemonic(int p0) {
        mnemonic = p0;
    }

    void setDisplayedMnemonic(char p0) {
        mnemonic = static_cast<int>(p0);
    }

    Component* getLabelFor() const {
        return labelFor;
    }

    void setLabelFor(Component* p0) {
        labelFor = p0;
    }

    std::string getUIClassID() const {
        return "LabelUI";
    }

    void updateUI() {}

    LabelUI* getUI() const {
        return ui;
    }

    void setUI(LabelUI* p0) {
        ui = p0;
    }

    AccessibleContext* getAccessibleContext() const {
        return accessibleContext;
    }

    bool imageUpdate(Image* p0, int p1, int p2, int p3, int p4, int p5) {
        (void)p0; (void)p1; (void)p2; (void)p3; (void)p4; (void)p5;
        return false;
    }

    Icon* getIcon() const {
        return icon;
    }

    Icon* getDisabledIcon() const {
        return disabledIcon;
    }

    void setDisplayedMnemonicIndex(int p0) {
        mnemonicIndex = p0;
    }

    void setText(const std::string& p0) {
        text = p0;
    }

    void setIcon(Icon* p0) {
        icon = p0;
    }

    void setDisabledIcon(Icon* p0) {
        disabledIcon = p0;
    }

    void setIconTextGap(int p0) {
        iconTextGap = p0;
    }

    int getVerticalAlignment() const {
        return verticalAlignment;
    }

    void setVerticalAlignment(int p0) {
        verticalAlignment = p0;
    }

    int getHorizontalAlignment() const {
        return horizontalAlignment;
    }

    void setHorizontalAlignment(int p0) {
        horizontalAlignment = p0;
    }

    int getVerticalTextPosition() const {
        return verticalTextPosition;
    }

    void setVerticalTextPosition(int p0) {
        verticalTextPosition = p0;
    }

    int getHorizontalTextPosition() const {
        return horizontalTextPosition;
    }

    void setHorizontalTextPosition(int p0) {
        horizontalTextPosition = p0;
    }

    int getIconTextGap() const {
        return iconTextGap;
    }

    int getDisplayedMnemonicIndex() const {
        return mnemonicIndex;
    }

    std::string getText() const {
        return text;
    }

private:
    int mnemonic = 0;
    int mnemonicIndex = -1;
    Component* labelFor = nullptr;
    LabelUI* ui = nullptr;
    AccessibleContext* accessibleContext = nullptr;
    Icon* icon = nullptr;
    Icon* disabledIcon = nullptr;
    std::string text;
    int iconTextGap = 4;
    int verticalAlignment = 0;
    int horizontalAlignment = 0;
    int verticalTextPosition = 0;
    int horizontalTextPosition = 0;
};

void getDisplayedMnemonic_test_6349() {
    JLabel instance;
    instance.getDisplayedMnemonic();
}

void setDisplayedMnemonic_test_6350(int p0) {
    JLabel instance;
    instance.setDisplayedMnemonic(p0);
}

void setDisplayedMnemonic_test_6351(char p0) {
    JLabel instance;
    instance.setDisplayedMnemonic(p0);
}

void getLabelFor_test_6352() {
    JLabel instance;
    instance.getLabelFor();
}

void setLabelFor_test_6353(Component* p0) {
    JLabel instance;
    instance.setLabelFor(p0);
}

void getUIClassID_test_6354() {
    JLabel instance;
    instance.getUIClassID();
}

void updateUI_test_6355() {
    JLabel instance;
    instance.updateUI();
}

void getUI_test_6356() {
    JLabel instance;
    instance.getUI();
}

void setUI_test_6357(LabelUI* p0) {
    JLabel instance;
    instance.setUI(p0);
}

void getAccessibleContext_test_6358() {
    JLabel instance;
    instance.getAccessibleContext();
}

void imageUpdate_test_6359(Image* p0, int p1, int p2, int p3, int p4, int p5) {
    JLabel instance;
    instance.imageUpdate(p0, p1, p2, p3, p4, p5);
}

void getIcon_test_6360() {
    JLabel instance;
    instance.getIcon();
}

void getDisabledIcon_test_6361() {
    JLabel instance;
    instance.getDisabledIcon();
}

void setDisplayedMnemonicIndex_test_6362(int p0) {
    JLabel instance;
    instance.setDisplayedMnemonicIndex(p0);
}

void setText_test_6363(std::string p0) {
    JLabel instance;
    instance.setText(p0);
}

void setIcon_test_6364(Icon* p0) {
    JLabel instance;
    instance.setIcon(p0);
}

void setDisabledIcon_test_6365(Icon* p0) {
    JLabel instance;
    instance.setDisabledIcon(p0);
}

void setIconTextGap_test_6366(int p0) {
    JLabel instance;
    instance.setIconTextGap(p0);
}

void getVerticalAlignment_test_6367() {
    JLabel instance;
    instance.getVerticalAlignment();
}

void setVerticalAlignment_test_6368(int p0) {
    JLabel instance;
    instance.setVerticalAlignment(p0);
}

void getHorizontalAlignment_test_6369() {
    JLabel instance;
    instance.getHorizontalAlignment();
}

void setHorizontalAlignment_test_6370(int p0) {
    JLabel instance;
    instance.setHorizontalAlignment(p0);
}

void getVerticalTextPosition_test_6371() {
    JLabel instance;
    instance.getVerticalTextPosition();
}

void setVerticalTextPosition_test_6372(int p0) {
    JLabel instance;
    instance.setVerticalTextPosition(p0);
}

void getHorizontalTextPosition_test_6373() {
    JLabel instance;
    instance.getHorizontalTextPosition();
}

void setHorizontalTextPosition_test_6374(int p0) {
    JLabel instance;
    instance.setHorizontalTextPosition(p0);
}

void getIconTextGap_test_6375() {
    JLabel instance;
    instance.getIconTextGap();
}

void getDisplayedMnemonicIndex_test_6376() {
    JLabel instance;
    instance.getDisplayedMnemonicIndex();
}

void getText_test_6377() {
    JLabel instance;
    instance.getText();
}