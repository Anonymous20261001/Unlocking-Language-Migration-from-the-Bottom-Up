#include <vector>
#include <string>

class Object {
public:
    virtual ~Object() = default;
};

class Class {
public:
    explicit Class(const std::string& name = "") : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class String {
public:
    String() = default;
    String(const char* s) : value_(s ? s : "") {}
    String(const std::string& s) : value_(s) {}
    const std::string& std_str() const { return value_; }
    const char* c_str() const { return value_.c_str(); }
    bool operator==(const String& other) const { return value_ == other.value_; }
private:
    std::string value_;
};

class JComponent : public Object {};
class InputMap : public Object {};
class Icon : public Object {};
class KeyStroke : public Object {};

class LookAndFeel {
public:
    static Icon* makeIcon(Class* baseClass, const String& gifFile) {
        (void)baseClass;
        (void)gifFile;
        return nullptr;
    }

    static InputMap* makeComponentInputMap(JComponent* c, const std::vector<Object*>& keys) {
        (void)c;
        (void)keys;
        return nullptr;
    }

    static void installProperty(JComponent* c, const String& propertyName, Object* value) {
        (void)c;
        (void)propertyName;
        (void)value;
    }

    static void installColors(JComponent* c, const String& background, const String& foreground) {
        (void)c;
        (void)background;
        (void)foreground;
    }

    static void loadKeyBindings(InputMap* map, const std::vector<Object*>& keys) {
        (void)map;
        (void)keys;
    }

    static std::vector<KeyStroke*> makeKeyBindings(const std::vector<Object*>& keys) {
        (void)keys;
        return {};
    }

    static InputMap* makeInputMap(const std::vector<Object*>& keys) {
        (void)keys;
        return nullptr;
    }

    static Object* getDesktopPropertyValue(const String& systemPropertyName, Object* fallbackValue) {
        (void)systemPropertyName;
        return fallbackValue;
    }

    static void installColorsAndFont(JComponent* c, const String& background, const String& foreground, const String& font) {
        (void)c;
        (void)background;
        (void)foreground;
        (void)font;
    }

    static void installBorder(JComponent* c, const String& defaultBorderName) {
        (void)c;
        (void)defaultBorderName;
    }

    static void uninstallBorder(JComponent* c) {
        (void)c;
    }
};

void makeIcon_test_8226(Class* p0, const String& p1) {
    LookAndFeel::makeIcon(p0, p1);
}

void makeComponentInputMap_test_8227(JComponent* p0, const std::vector<Object*>& p1) {
    LookAndFeel::makeComponentInputMap(p0, p1);
}

void installProperty_test_8228(JComponent* p0, const String& p1, Object* p2) {
    LookAndFeel::installProperty(p0, p1, p2);
}

void installColors_test_8229(JComponent* p0, const String& p1, const String& p2) {
    LookAndFeel::installColors(p0, p1, p2);
}

void loadKeyBindings_test_8230(InputMap* p0, const std::vector<Object*>& p1) {
    LookAndFeel::loadKeyBindings(p0, p1);
}

void makeKeyBindings_test_8231(const std::vector<Object*>& p0) {
    LookAndFeel::makeKeyBindings(p0);
}

void makeInputMap_test_8232(const std::vector<Object*>& p0) {
    LookAndFeel::makeInputMap(p0);
}

void getDesktopPropertyValue_test_8233(const String& p0, Object* p1) {
    LookAndFeel::getDesktopPropertyValue(p0, p1);
}

void installColorsAndFont_test_8234(JComponent* p0, const String& p1, const String& p2, const String& p3) {
    LookAndFeel::installColorsAndFont(p0, p1, p2, p3);
}

void installBorder_test_8235(JComponent* p0, const String& p1) {
    LookAndFeel::installBorder(p0, p1);
}

void uninstallBorder_test_8236(JComponent* p0) {
    LookAndFeel::uninstallBorder(p0);
}