#include <string>
#include <vector>

using String = std::string;

class Class {
public:
    Class() = default;
};

class MethodType {
public:
    MethodType() = default;
};

class Method {
public:
    Method() = default;
};

class Constructor {
public:
    Constructor() = default;
};

class Field {
public:
    Field() = default;
};

struct MethodHandles {
    struct Lookup {
        Lookup() = default;
    };
};

class Lookup {
public:
    Lookup() = default;
    Lookup(const MethodHandles::Lookup& c0) {
        (void)c0;
    }

    void findVirtual(Class p0, String p1, MethodType p2) {
        (void)p0; (void)p1; (void)p2;
    }

    void findStatic(Class p0, String p1, MethodType p2) {
        (void)p0; (void)p1; (void)p2;
    }

    void unreflect(Method p0) {
        (void)p0;
    }

    void unreflectConstructor(Constructor p0) {
        (void)p0;
    }

    void findSpecial(Class p0, String p1, MethodType p2) {
        (void)p0; (void)p1; (void)p2;
    }

    void findGetter(Class p0, String p1, Class p2) {
        (void)p0; (void)p1; (void)p2;
    }

    void unreflectGetter(Field p0) {
        (void)p0;
    }

    void unreflectSetter(Field p0) {
        (void)p0;
    }

    void findOwnSpecial(String p0, Class p1, std::vector<Class> p2) {
        (void)p0; (void)p1; (void)p2;
    }

    void findOwnStatic(String p0, Class p1, std::vector<Class> p2) {
        (void)p0; (void)p1; (void)p2;
    }

    static void unreflect(MethodHandles::Lookup p0, Method p1) {
        (void)p0; (void)p1;
    }

    static void unreflectConstructor(MethodHandles::Lookup p0, Constructor p1) {
        (void)p0; (void)p1;
    }

    static void findOwnSpecial(MethodHandles::Lookup p0, String p1, Class p2, std::vector<Class> p3) {
        (void)p0; (void)p1; (void)p2; (void)p3;
    }

    static void findOwnStatic(MethodHandles::Lookup p0, String p1, Class p2, std::vector<Class> p3) {
        (void)p0; (void)p1; (void)p2; (void)p3;
    }
};

void findVirtual_test_8237(Class p0, String p1, MethodType p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findVirtual(p0, p1, p2);
}

void findStatic_test_8238(Class p0, String p1, MethodType p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findStatic(p0, p1, p2);
}

void unreflect_test_8239(Method p0, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.unreflect(p0);
}

void unreflect_test_8240(MethodHandles::Lookup p0, Method p1) {
    Lookup::unreflect(p0, p1);
}

void unreflectConstructor_test_8241(MethodHandles::Lookup p0, Constructor p1) {
    Lookup::unreflectConstructor(p0, p1);
}

void unreflectConstructor_test_8242(Constructor p0, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.unreflectConstructor(p0);
}

void findSpecial_test_8243(Class p0, String p1, MethodType p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findSpecial(p0, p1, p2);
}

void findGetter_test_8244(Class p0, String p1, Class p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findGetter(p0, p1, p2);
}

void unreflectGetter_test_8245(Field p0, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.unreflectGetter(p0);
}

void unreflectSetter_test_8246(Field p0, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.unreflectSetter(p0);
}

void findOwnSpecial_test_8247(String p0, Class p1, std::vector<Class> p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findOwnSpecial(p0, p1, p2);
}

void findOwnSpecial_test_8248(MethodHandles::Lookup p0, String p1, Class p2, std::vector<Class> p3) {
    Lookup::findOwnSpecial(p0, p1, p2, p3);
}

void findOwnStatic_test_8249(MethodHandles::Lookup p0, String p1, Class p2, std::vector<Class> p3) {
    Lookup::findOwnStatic(p0, p1, p2, p3);
}

void findOwnStatic_test_8250(String p0, Class p1, std::vector<Class> p2, MethodHandles::Lookup c0) {
    Lookup instance = Lookup(c0);
    instance.findOwnStatic(p0, p1, p2);
}