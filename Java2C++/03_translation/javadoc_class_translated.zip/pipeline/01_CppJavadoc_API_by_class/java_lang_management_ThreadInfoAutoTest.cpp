#include <map>
#include <string>
#include <stdexcept>
#include <utility>

namespace javax {
namespace management {
namespace openmbean {

class CompositeData {
public:
    CompositeData() = default;
    explicit CompositeData(std::map<std::string, std::string> values)
        : values_(std::move(values)) {}

    const std::string& get(const std::string& key) const {
        auto it = values_.find(key);
        if (it == values_.end()) {
            throw std::invalid_argument("Key not found: " + key);
        }
        return it->second;
    }

    bool containsKey(const std::string& key) const {
        return values_.find(key) != values_.end();
    }

private:
    std::map<std::string, std::string> values_;
};

} // namespace openmbean
} // namespace management
} // namespace javax

namespace java {
namespace lang {
namespace management {

class ThreadInfo {
public:
    ThreadInfo() = default;

    static ThreadInfo from(const javax::management::openmbean::CompositeData& data) {
        (void)data;
        return ThreadInfo();
    }
};

} // namespace management
} // namespace lang
} // namespace java

void from_test_12708() {
    javax::management::openmbean::CompositeData p0;
    java::lang::management::ThreadInfo::from(p0);
}
