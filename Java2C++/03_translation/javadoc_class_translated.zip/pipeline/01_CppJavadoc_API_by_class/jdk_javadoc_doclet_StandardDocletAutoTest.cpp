#include <string>
#include <set>

namespace javadoc {

class Locale {
public:
    Locale() = default;
};

class Reporter {
public:
    Reporter() = default;
};

class DocletEnvironment {
public:
    DocletEnvironment() = default;
};

enum class SourceVersion {
    RELEASE_0, RELEASE_1, RELEASE_2, RELEASE_3, RELEASE_4, RELEASE_5,
    RELEASE_6, RELEASE_7, RELEASE_8, RELEASE_9, RELEASE_10, RELEASE_11,
    RELEASE_12, RELEASE_13, RELEASE_14, RELEASE_15, RELEASE_16, RELEASE_17,
    RELEASE_18, RELEASE_19, RELEASE_20, RELEASE_21, RELEASE_22, RELEASE_23,
    RELEASE_24, RELEASE_25
};

struct DocletOption {
    std::string name;
};

inline bool operator<(const DocletOption& lhs, const DocletOption& rhs) {
    return lhs.name < rhs.name;
}

class StandardDoclet {
public:
    StandardDoclet() = default;

    std::string getName() const {
        return "StandardDoclet";
    }

    bool run(DocletEnvironment& environment) {
        (void)environment;
        return true;
    }

    void init(const Locale& locale, const Reporter& reporter) {
        locale_ = locale;
        reporter_ = reporter;
    }

    Locale getLocale() const {
        return locale_;
    }

    Reporter getReporter() const {
        return reporter_;
    }

    std::set<DocletOption> getSupportedOptions() const {
        return {};
    }

    SourceVersion getSupportedSourceVersion() const {
        return SourceVersion::RELEASE_25;
    }

private:
    Locale locale_;
    Reporter reporter_;
};

} // namespace javadoc

void getName_test_11482() {
    javadoc::StandardDoclet instance;
    instance.getName();
}

void run_test_11483(javadoc::DocletEnvironment& p0) {
    javadoc::StandardDoclet instance;
    instance.run(p0);
}

void init_test_11484(const javadoc::Locale& p0, const javadoc::Reporter& p1) {
    javadoc::StandardDoclet instance;
    instance.init(p0, p1);
}

void getLocale_test_11485() {
    javadoc::StandardDoclet instance;
    instance.getLocale();
}

void getReporter_test_11486() {
    javadoc::StandardDoclet instance;
    instance.getReporter();
}

void getSupportedOptions_test_11487() {
    javadoc::StandardDoclet instance;
    instance.getSupportedOptions();
}

void getSupportedSourceVersion_test_11488() {
    javadoc::StandardDoclet instance;
    instance.getSupportedSourceVersion();
}