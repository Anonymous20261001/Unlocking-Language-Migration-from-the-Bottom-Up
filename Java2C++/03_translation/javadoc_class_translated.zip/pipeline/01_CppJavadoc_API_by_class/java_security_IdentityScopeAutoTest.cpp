class IdentityScope {
public:
    static IdentityScope& getSystemScope() {
        static IdentityScope instance;
        return instance;
    }

    virtual ~IdentityScope() = default;

protected:
    IdentityScope() = default;
};

void getSystemScope_test_5532() {
    IdentityScope::getSystemScope();
}
