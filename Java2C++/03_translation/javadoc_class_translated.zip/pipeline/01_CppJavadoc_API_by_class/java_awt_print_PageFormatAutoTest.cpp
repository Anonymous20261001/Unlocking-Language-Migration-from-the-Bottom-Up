#include <array>

class Paper {
public:
    Paper()
        : width_(612.0), height_(792.0),
          imageableX_(72.0), imageableY_(72.0),
          imageableWidth_(468.0), imageableHeight_(648.0) {}

    double getWidth() const { return width_; }
    double getHeight() const { return height_; }
    double getImageableX() const { return imageableX_; }
    double getImageableY() const { return imageableY_; }
    double getImageableWidth() const { return imageableWidth_; }
    double getImageableHeight() const { return imageableHeight_; }

    void setSize(double w, double h) {
        width_ = w;
        height_ = h;
    }

    void setImageableArea(double x, double y, double w, double h) {
        imageableX_ = x;
        imageableY_ = y;
        imageableWidth_ = w;
        imageableHeight_ = h;
    }

private:
    double width_;
    double height_;
    double imageableX_;
    double imageableY_;
    double imageableWidth_;
    double imageableHeight_;
};

class PageFormat {
public:
    static const int PORTRAIT = 0;
    static const int LANDSCAPE = 1;
    static const int REVERSE_LANDSCAPE = 2;

    PageFormat() : orientation_(PORTRAIT) {}

    double getWidth() const {
        if (orientation_ == LANDSCAPE || orientation_ == REVERSE_LANDSCAPE) {
            return paper_.getHeight();
        }
        return paper_.getWidth();
    }

    double getHeight() const {
        if (orientation_ == LANDSCAPE || orientation_ == REVERSE_LANDSCAPE) {
            return paper_.getWidth();
        }
        return paper_.getHeight();
    }

    int getOrientation() const {
        return orientation_;
    }

    std::array<double, 6> getMatrix() const {
        std::array<double, 6> m{};
        double w = paper_.getWidth();
        double h = paper_.getHeight();
        switch (orientation_) {
            case PORTRAIT:
                m = {w, 0.0, 0.0, h, 0.0, 0.0};
                break;
            case LANDSCAPE:
                m = {h, 0.0, 0.0, w, 0.0, 0.0};
                break;
            case REVERSE_LANDSCAPE:
                m = {-h, 0.0, 0.0, -w, h, w};
                break;
            default:
                m = {w, 0.0, 0.0, h, 0.0, 0.0};
                break;
        }
        return m;
    }

    void setOrientation(int orientation) {
        orientation_ = orientation;
    }

    double getImageableX() const {
        switch (orientation_) {
            case PORTRAIT:
                return paper_.getImageableX();
            case LANDSCAPE:
                return paper_.getImageableY();
            case REVERSE_LANDSCAPE:
                return paper_.getWidth() - (paper_.getImageableY() + paper_.getImageableHeight());
            default:
                return paper_.getImageableX();
        }
    }

    double getImageableY() const {
        switch (orientation_) {
            case PORTRAIT:
                return paper_.getImageableY();
            case LANDSCAPE:
                return paper_.getWidth() - (paper_.getImageableX() + paper_.getImageableWidth());
            case REVERSE_LANDSCAPE:
                return paper_.getImageableX();
            default:
                return paper_.getImageableY();
        }
    }

    double getImageableWidth() const {
        switch (orientation_) {
            case PORTRAIT:
                return paper_.getImageableWidth();
            case LANDSCAPE:
            case REVERSE_LANDSCAPE:
                return paper_.getImageableHeight();
            default:
                return paper_.getImageableWidth();
        }
    }

    double getImageableHeight() const {
        switch (orientation_) {
            case PORTRAIT:
                return paper_.getImageableHeight();
            case LANDSCAPE:
            case REVERSE_LANDSCAPE:
                return paper_.getImageableWidth();
            default:
                return paper_.getImageableHeight();
        }
    }

    Paper getPaper() const {
        return paper_;
    }

    void setPaper(const Paper& paper) {
        paper_ = paper;
    }

private:
    int orientation_;
    Paper paper_;
};

void getWidth_test_9735() {
    PageFormat instance;
    instance.getWidth();
}

void getHeight_test_9736() {
    PageFormat instance;
    instance.getHeight();
}

void getOrientation_test_9737() {
    PageFormat instance;
    instance.getOrientation();
}

void getMatrix_test_9738() {
    PageFormat instance;
    instance.getMatrix();
}

void setOrientation_test_9739(int p0) {
    PageFormat instance;
    instance.setOrientation(p0);
}

void getImageableY_test_9740() {
    PageFormat instance;
    instance.getImageableY();
}

void getImageableHeight_test_9741() {
    PageFormat instance;
    instance.getImageableHeight();
}

void getImageableX_test_9742() {
    PageFormat instance;
    instance.getImageableX();
}

void getImageableWidth_test_9743() {
    PageFormat instance;
    instance.getImageableWidth();
}

void getPaper_test_9744() {
    PageFormat instance;
    instance.getPaper();
}

void setPaper_test_9745(Paper p0) {
    PageFormat instance;
    instance.setPaper(p0);
}
