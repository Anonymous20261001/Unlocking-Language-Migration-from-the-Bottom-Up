#include <any>
#include <vector>

using List = std::vector<std::any>;

class EventFactory {
public:
    static void create(const List& p0, const List& p1) {
        (void)p0;
        (void)p1;
    }
};

void create_test_4573(List p0, List p1) {
    EventFactory::create(p0, p1);
}