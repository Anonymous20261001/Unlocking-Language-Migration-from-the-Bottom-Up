#include <string>
#include <map>
#include <set>

class TemporalAccessor;
class ZoneOffset;

class ZoneId {
public:
    virtual ~ZoneId() = default;

    const std::string& getId() const {
        return id_;
    }

    static ZoneId of(const std::string& zoneId, const std::map<std::string, std::string>& aliasMap);
    static ZoneId of(const std::string& zoneId);
    static ZoneId from(const TemporalAccessor& temporal);
    static ZoneId systemDefault();
    static std::set<std::string> getAvailableZoneIds();
    static ZoneId ofOffset(const std::string& prefix, const ZoneOffset& offset);

protected:
    explicit ZoneId(const std::string& id) : id_(id) {}

private:
    std::string id_;
};

class ZoneOffset : public ZoneId {
public:
    explicit ZoneOffset(const std::string& id) : ZoneId(id) {}
};

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
};

inline ZoneId ZoneId::of(const std::string& zoneId, const std::map<std::string, std::string>& aliasMap) {
    auto it = aliasMap.find(zoneId);
    if (it != aliasMap.end()) {
        return of(it->second);
    }
    return of(zoneId);
}

inline ZoneId ZoneId::of(const std::string& zoneId) {
    if (zoneId == "Z" || (!zoneId.empty() && (zoneId[0] == '+' || zoneId[0] == '-'))) {
        return ZoneOffset(zoneId);
    }
    return ZoneId(zoneId);
}

inline ZoneId ZoneId::from(const TemporalAccessor&) {
    return systemDefault();
}

inline ZoneId ZoneId::systemDefault() {
    return ZoneId("UTC");
}

inline std::set<std::string> ZoneId::getAvailableZoneIds() {
    return {"UTC", "GMT", "Europe/London", "America/New_York", "Asia/Tokyo"};
}

inline ZoneId ZoneId::ofOffset(const std::string& prefix, const ZoneOffset& offset) {
    if (prefix.empty()) {
        return ZoneId(offset.getId());
    }
    return ZoneId(prefix + offset.getId());
}

void of_test_13722(const std::string& p0, const std::map<std::string, std::string>& p1) {
    ZoneId::of(p0, p1);
}

void of_test_13723(const std::string& p0) {
    ZoneId::of(p0);
}

void from_test_13724(const TemporalAccessor& p0) {
    ZoneId::from(p0);
}

void systemDefault_test_13725() {
    ZoneId::systemDefault();
}

void getAvailableZoneIds_test_13726() {
    ZoneId::getAvailableZoneIds();
}

void ofOffset_test_13727(const std::string& p0, const ZoneOffset& p1) {
    ZoneId::ofOffset(p0, p1);
}
