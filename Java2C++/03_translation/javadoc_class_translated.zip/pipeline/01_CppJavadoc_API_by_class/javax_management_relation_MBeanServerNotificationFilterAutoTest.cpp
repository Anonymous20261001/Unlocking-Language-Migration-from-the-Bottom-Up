#include <string>
#include <set>
#include <vector>

class ObjectName {
public:
    ObjectName() : name() {}
    explicit ObjectName(const std::string& name) : name(name) {}
    const std::string& getCanonicalName() const { return name; }
    bool operator<(const ObjectName& other) const { return name < other.name; }
    bool operator==(const ObjectName& other) const { return name == other.name; }
private:
    std::string name;
};

class Notification {
public:
    Notification() : type() {}
    explicit Notification(const std::string& type) : type(type) {}
    virtual ~Notification() = default;
    const std::string& getType() const { return type; }
    virtual bool isMBeanServerNotification() const { return false; }
private:
    std::string type;
};

class MBeanServerNotification : public Notification {
public:
    MBeanServerNotification(const std::string& type, const ObjectName& name)
        : Notification(type), name(name) {}
    bool isMBeanServerNotification() const override { return true; }
    const ObjectName& getObjectName() const { return name; }
private:
    ObjectName name;
};

class MBeanServerNotificationFilter {
public:
    MBeanServerNotificationFilter() : enabledAllObjectNames(true) {}

    void disableAllObjectNames() {
        enabledAllObjectNames = false;
        enabledObjectNames.clear();
        disabledObjectNames.clear();
    }

    void disableObjectName(const ObjectName& name) {
        disabledObjectNames.insert(name);
        enabledObjectNames.erase(name);
        enabledAllObjectNames = true;
    }

    void enableAllObjectNames() {
        enabledAllObjectNames = true;
        enabledObjectNames.clear();
        disabledObjectNames.clear();
    }

    void enableObjectName(const ObjectName& name) {
        enabledObjectNames.insert(name);
        disabledObjectNames.erase(name);
        enabledAllObjectNames = false;
    }

    std::vector<ObjectName> getEnabledObjectNames() const {
        return std::vector<ObjectName>(enabledObjectNames.begin(), enabledObjectNames.end());
    }

    std::vector<ObjectName> getDisabledObjectNames() const {
        return std::vector<ObjectName>(disabledObjectNames.begin(), disabledObjectNames.end());
    }

    bool isNotificationEnabled(const Notification& notification) const {
        const MBeanServerNotification* mbn = dynamic_cast<const MBeanServerNotification*>(&notification);
        if (mbn == nullptr) {
            return false;
        }
        const ObjectName& name = mbn->getObjectName();
        if (enabledAllObjectNames) {
            return disabledObjectNames.find(name) == disabledObjectNames.end();
        }
        return enabledObjectNames.find(name) != enabledObjectNames.end();
    }

private:
    bool enabledAllObjectNames;
    std::set<ObjectName> enabledObjectNames;
    std::set<ObjectName> disabledObjectNames;
};

void disableAllObjectNames_test_8454() {
    MBeanServerNotificationFilter instance;
    instance.disableAllObjectNames();
}

void disableObjectName_test_8455(const ObjectName& p0) {
    MBeanServerNotificationFilter instance;
    instance.disableObjectName(p0);
}

void enableAllObjectNames_test_8456() {
    MBeanServerNotificationFilter instance;
    instance.enableAllObjectNames();
}

void enableObjectName_test_8457(const ObjectName& p0) {
    MBeanServerNotificationFilter instance;
    instance.enableObjectName(p0);
}

void getEnabledObjectNames_test_8458() {
    MBeanServerNotificationFilter instance;
    instance.getEnabledObjectNames();
}

void getDisabledObjectNames_test_8459() {
    MBeanServerNotificationFilter instance;
    instance.getDisabledObjectNames();
}

void isNotificationEnabled_test_8460(const Notification& p0) {
    MBeanServerNotificationFilter instance;
    instance.isNotificationEnabled(p0);
}