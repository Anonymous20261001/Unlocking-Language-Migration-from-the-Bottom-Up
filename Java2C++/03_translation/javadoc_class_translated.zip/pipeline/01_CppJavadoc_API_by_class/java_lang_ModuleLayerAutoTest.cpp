class Configuration {};
class ClassLoader {};
class List {};
class Function {};

class ModuleLayer {
public:
    static ModuleLayer empty() { return ModuleLayer(); }
    static ModuleLayer boot() { return ModuleLayer(); }
    static ModuleLayer defineModules(Configuration, List, Function) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithOneLoader(Configuration, List, ClassLoader) { return ModuleLayer(); }
    static ModuleLayer defineModulesWithManyLoaders(Configuration, List, ClassLoader) { return ModuleLayer(); }
};

void empty_test_8996() {
    ModuleLayer::empty();
}

void boot_test_8997() {
    ModuleLayer::boot();
}

void defineModules_test_8998(Configuration p0, List p1, Function p2) {
    ModuleLayer::defineModules(p0, p1, p2);
}

void defineModulesWithOneLoader_test_8999(Configuration p0, List p1, ClassLoader p2) {
    ModuleLayer::defineModulesWithOneLoader(p0, p1, p2);
}

void defineModulesWithManyLoaders_test_9000(Configuration p0, List p1, ClassLoader p2) {
    ModuleLayer::defineModulesWithManyLoaders(p0, p1, p2);
}