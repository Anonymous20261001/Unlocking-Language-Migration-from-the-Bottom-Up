#include <string>

class DataFlavor {
public:
    explicit DataFlavor(const std::string& mimeType) : mime_type_(mimeType) {}

    const std::string& getMimeType() const {
        return mime_type_;
    }

    void setMimeType(const std::string& mimeType) {
        mime_type_ = mimeType;
    }

private:
    std::string mime_type_;
};

class SystemFlavorMap {
public:
    static bool isJavaMIMEType(const std::string& mimeType) {
        if (mimeType.length() < 5) {
            return false;
        }
        const char* s = mimeType.c_str();
        return (s[0] == 'j' || s[0] == 'J') &&
               (s[1] == 'a' || s[1] == 'A') &&
               (s[2] == 'v' || s[2] == 'V') &&
               (s[3] == 'a' || s[3] == 'A') &&
               s[4] == ':';
    }

    static std::string decodeJavaMIMEType(const std::string& mimeType) {
        if (isJavaMIMEType(mimeType)) {
            return mimeType.substr(5);
        }
        return mimeType;
    }

    static std::string encodeJavaMIMEType(const std::string& mimeType) {
        if (isJavaMIMEType(mimeType)) {
            return mimeType;
        }
        return std::string("java:") + mimeType;
    }

    static std::string encodeDataFlavor(const DataFlavor& flavor) {
        return encodeJavaMIMEType(flavor.getMimeType());
    }

    static SystemFlavorMap* getDefaultFlavorMap() {
        static SystemFlavorMap instance;
        return &instance;
    }

private:
    SystemFlavorMap() {}
};

void isJavaMIMEType_test_12438(const std::string& p0) {
    SystemFlavorMap::isJavaMIMEType(p0);
}

void decodeJavaMIMEType_test_12439(const std::string& p0) {
    SystemFlavorMap::decodeJavaMIMEType(p0);
}

void encodeDataFlavor_test_12440(const DataFlavor& p0) {
    SystemFlavorMap::encodeDataFlavor(p0);
}

void encodeJavaMIMEType_test_12441(const std::string& p0) {
    SystemFlavorMap::encodeJavaMIMEType(p0);
}

void getDefaultFlavorMap_test_12442() {
    SystemFlavorMap::getDefaultFlavorMap();
}