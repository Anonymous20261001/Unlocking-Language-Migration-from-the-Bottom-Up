#include <string>
#include <vector>

class Number {
public:
    double value;
    Number() : value(0.0) {}
    Number(int v) : value(static_cast<double>(v)) {}
    Number(long v) : value(static_cast<double>(v)) {}
    Number(long long v) : value(static_cast<double>(v)) {}
    Number(float v) : value(v) {}
    Number(double v) : value(v) {}
};

class ObjectName {
public:
    std::string name;
    ObjectName() : name() {}
    explicit ObjectName(const std::string& n) : name(n) {}
    const std::string& toString() const { return name; }
};

struct MBeanNotificationInfo {
    std::string type;
};

class CounterMonitor {
private:
    Number initThreshold;
    Number modulus;
    bool notify;
    bool differenceMode;
    Number derivedGauge;
    long long derivedGaugeTimeStamp;
    Number threshold;
    Number offset;
    bool running;
public:
    CounterMonitor()
        : initThreshold(0), modulus(1), notify(true), differenceMode(false),
          derivedGauge(0), derivedGaugeTimeStamp(0), threshold(0), offset(0),
          running(false) {}

    Number getInitThreshold() const { return initThreshold; }
    Number getModulus() const { return modulus; }
    void setModulus(Number p0) { modulus = p0; }
    bool getNotify() const { return notify; }
    void setNotify(bool p0) { notify = p0; }
    bool getDifferenceMode() const { return differenceMode; }
    void setDifferenceMode(bool p0) { differenceMode = p0; }
    std::vector<MBeanNotificationInfo> getNotificationInfo() const { return std::vector<MBeanNotificationInfo>(); }
    Number getDerivedGauge(const ObjectName& p0) const { (void)p0; return derivedGauge; }
    Number getDerivedGauge() const { return derivedGauge; }
    long long getDerivedGaugeTimeStamp(const ObjectName& p0) const { (void)p0; return derivedGaugeTimeStamp; }
    long long getDerivedGaugeTimeStamp() const { return derivedGaugeTimeStamp; }
    Number getThreshold(const ObjectName& p0) const { (void)p0; return threshold; }
    Number getThreshold() const { return threshold; }
    void setInitThreshold(Number p0) { initThreshold = p0; threshold = p0; }
    void start() { running = true; }
    void stop() { running = false; }
    Number getOffset() const { return offset; }
    void setOffset(Number p0) { offset = p0; }
    void setThreshold(Number p0) { threshold = p0; }
};

void getInitThreshold_test_3090() {
    CounterMonitor instance;
    instance.getInitThreshold();
}

void getModulus_test_3091() {
    CounterMonitor instance;
    instance.getModulus();
}

void setModulus_test_3092(Number p0) {
    CounterMonitor instance;
    instance.setModulus(p0);
}

void getNotify_test_3093() {
    CounterMonitor instance;
    instance.getNotify();
}

void setNotify_test_3094(bool p0) {
    CounterMonitor instance;
    instance.setNotify(p0);
}

void getDifferenceMode_test_3095() {
    CounterMonitor instance;
    instance.getDifferenceMode();
}

void setDifferenceMode_test_3096(bool p0) {
    CounterMonitor instance;
    instance.setDifferenceMode(p0);
}

void getNotificationInfo_test_3097() {
    CounterMonitor instance;
    instance.getNotificationInfo();
}

void getDerivedGauge_test_3098(ObjectName p0) {
    CounterMonitor instance;
    instance.getDerivedGauge(p0);
}

void getDerivedGauge_test_3099() {
    CounterMonitor instance;
    instance.getDerivedGauge();
}

void getDerivedGaugeTimeStamp_test_3100(ObjectName p0) {
    CounterMonitor instance;
    instance.getDerivedGaugeTimeStamp(p0);
}

void getDerivedGaugeTimeStamp_test_3101() {
    CounterMonitor instance;
    instance.getDerivedGaugeTimeStamp();
}

void getThreshold_test_3102(ObjectName p0) {
    CounterMonitor instance;
    instance.getThreshold(p0);
}

void getThreshold_test_3103() {
    CounterMonitor instance;
    instance.getThreshold();
}

void setInitThreshold_test_3104(Number p0) {
    CounterMonitor instance;
    instance.setInitThreshold(p0);
}

void start_test_3105() {
    CounterMonitor instance;
    instance.start();
}

void stop_test_3106() {
    CounterMonitor instance;
    instance.stop();
}

void getOffset_test_3107() {
    CounterMonitor instance;
    instance.getOffset();
}

void setOffset_test_3108(Number p0) {
    CounterMonitor instance;
    instance.setOffset(p0);
}

void setThreshold_test_3109(Number p0) {
    CounterMonitor instance;
    instance.setThreshold(p0);
}