#include <set>

class StackWalker {
public:
    enum class Option {
        RETAIN_CLASS_REFERENCE,
        SHOW_HIDDEN_FRAMES,
        DECLARING_CLASS
    };

    using Set = std::set<Option>;

    static StackWalker getInstance(Option option) {
        (void)option;
        return StackWalker();
    }

    static StackWalker getInstance(Set options) {
        (void)options;
        return StackWalker();
    }

    static StackWalker getInstance(Set options, int estimate) {
        (void)options;
        (void)estimate;
        return StackWalker();
    }

    static StackWalker getInstance() {
        return StackWalker();
    }

    StackWalker() = default;
    ~StackWalker() = default;
};

void getInstance_test_11454(StackWalker::Option p0) {
    StackWalker::getInstance(p0);
}

void getInstance_test_11455(StackWalker::Set p0) {
    StackWalker::getInstance(p0);
}

void getInstance_test_11456(StackWalker::Set p0, int p1) {
    StackWalker::getInstance(p0, p1);
}

void getInstance_test_11457() {
    StackWalker::getInstance();
}