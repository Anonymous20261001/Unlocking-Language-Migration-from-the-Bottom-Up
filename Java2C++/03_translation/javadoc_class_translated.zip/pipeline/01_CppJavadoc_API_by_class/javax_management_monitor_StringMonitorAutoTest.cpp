#include <string>
#include <vector>
#include <cstdint>

class ObjectName {
public:
    ObjectName() = default;
    explicit ObjectName(const std::string& name) : name_(name) {}
    const std::string& toString() const { return name_; }
private:
    std::string name_;
};

class StringMonitor {
public:
    StringMonitor()
        : stringToCompare_(),
          notifyMatch_(false),
          notifyDiffer_(false),
          running_(false),
          derivedGauge_() {}

    std::vector<std::string> getNotificationInfo() {
        return std::vector<std::string>();
    }

    std::string getDerivedGauge() {
        return derivedGauge_;
    }

    std::string getDerivedGauge(const ObjectName&) {
        return derivedGauge_;
    }

    std::int64_t getDerivedGaugeTimeStamp(const ObjectName&) {
        return 0;
    }

    std::int64_t getDerivedGaugeTimeStamp() {
        return 0;
    }

    std::string getStringToCompare() const {
        return stringToCompare_;
    }

    void setStringToCompare(const std::string& p0) {
        stringToCompare_ = p0;
    }

    bool getNotifyMatch() const {
        return notifyMatch_;
    }

    void setNotifyMatch(bool p0) {
        notifyMatch_ = p0;
    }

    bool getNotifyDiffer() const {
        return notifyDiffer_;
    }

    void setNotifyDiffer(bool p0) {
        notifyDiffer_ = p0;
    }

    void start() {
        running_ = true;
    }

    void stop() {
        running_ = false;
    }

private:
    std::string stringToCompare_;
    bool notifyMatch_;
    bool notifyDiffer_;
    bool running_;
    std::string derivedGauge_;
};

void getNotificationInfo_test_11889() {
    StringMonitor instance;
    instance.getNotificationInfo();
}

void getDerivedGauge_test_11890() {
    StringMonitor instance;
    instance.getDerivedGauge();
}

void getDerivedGauge_test_11891(ObjectName p0) {
    StringMonitor instance;
    instance.getDerivedGauge(p0);
}

void getDerivedGaugeTimeStamp_test_11892(ObjectName p0) {
    StringMonitor instance;
    instance.getDerivedGaugeTimeStamp(p0);
}

void getDerivedGaugeTimeStamp_test_11893() {
    StringMonitor instance;
    instance.getDerivedGaugeTimeStamp();
}

void getStringToCompare_test_11894() {
    StringMonitor instance;
    instance.getStringToCompare();
}

void setStringToCompare_test_11895(std::string p0) {
    StringMonitor instance;
    instance.setStringToCompare(p0);
}

void getNotifyMatch_test_11896() {
    StringMonitor instance;
    instance.getNotifyMatch();
}

void setNotifyMatch_test_11897(bool p0) {
    StringMonitor instance;
    instance.setNotifyMatch(p0);
}

void getNotifyDiffer_test_11898() {
    StringMonitor instance;
    instance.getNotifyDiffer();
}

void setNotifyDiffer_test_11899(bool p0) {
    StringMonitor instance;
    instance.setNotifyDiffer(p0);
}

void start_test_11900() {
    StringMonitor instance;
    instance.start();
}

void stop_test_11901() {
    StringMonitor instance;
    instance.stop();
}