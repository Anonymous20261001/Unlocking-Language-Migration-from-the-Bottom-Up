#include <cstddef>
#include <string>
#include <utility>

class CharSequence {
public:
    CharSequence() = default;
    CharSequence(const std::string& s) : data_(s) {}
    CharSequence(std::string&& s) : data_(std::move(s)) {}

    std::size_t length() const { return data_.length(); }
    char charAt(std::size_t index) const { return data_.at(index); }
    std::string toString() const { return data_; }
    CharSequence subSequence(std::size_t start, std::size_t end) const {
        return CharSequence(data_.substr(start, end - start));
    }

private:
    std::string data_;
};

class Reader {
public:
    static Reader nullReader() {
        return Reader();
    }

    static Reader of(const CharSequence& input) {
        return Reader(input.toString());
    }

    Reader() : data_(), pos_(0) {}

    explicit Reader(const std::string& s) : data_(s), pos_(0) {}

    int read() {
        if (pos_ >= data_.length()) {
            return -1;
        }
        return static_cast<unsigned char>(data_[pos_++]);
    }

    std::size_t read(char* buffer, std::size_t length) {
        if (buffer == nullptr || length == 0) {
            return 0;
        }
        std::size_t available = data_.length() - pos_;
        if (available == 0) {
            return 0;
        }
        std::size_t toRead = length < available ? length : available;
        data_.copy(buffer, toRead, pos_);
        pos_ += toRead;
        return toRead;
    }

    bool ready() const {
        return pos_ < data_.length();
    }

    long long skip(long long n) {
        if (n <= 0) {
            return 0;
        }
        std::size_t available = data_.length() - pos_;
        std::size_t s = static_cast<std::size_t>(n);
        if (s > available) {
            s = available;
        }
        pos_ += s;
        return static_cast<long long>(s);
    }

    void close() {}

private:
    std::string data_;
    std::size_t pos_;
};

void nullReader_test_10346() {
    Reader::nullReader();
}

void of_test_10347(CharSequence p0) {
    Reader::of(p0);
}
