#include <string>
#include <cctype>
#include <cstdio>

class Charset {
public:
    explicit Charset(const std::string& name) : name_(name) {}

    static Charset forName(const std::string& name) {
        return Charset(name);
    }

    static Charset defaultCharset() {
        return Charset("UTF-8");
    }

    const std::string& name() const {
        return name_;
    }

private:
    std::string name_;
};

class URLEncoder {
public:
    static std::string encode(const std::string& s) {
        return encode(s, Charset::defaultCharset());
    }

    static std::string encode(const std::string& s, const Charset& charset) {
        std::string result;
        for (unsigned char c : s) {
            if (std::isalnum(c)) {
                result += static_cast<char>(c);
            } else if (c == '.' || c == '-' || c == '_' || c == '*') {
                result += static_cast<char>(c);
            } else if (c == ' ') {
                result += '+';
            } else {
                char buf[4];
                std::snprintf(buf, sizeof(buf), "%%%02X", c);
                result += buf;
            }
        }
        return result;
    }
};

void encode_test_13267(std::string p0) {
    URLEncoder::encode(p0);
}

void encode_test_13268(std::string p0, Charset p1) {
    URLEncoder::encode(p0, p1);
}