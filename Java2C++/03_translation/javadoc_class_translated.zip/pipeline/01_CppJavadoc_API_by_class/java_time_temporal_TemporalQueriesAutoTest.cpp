struct TemporalQuery {};

class TemporalQueries {
public:
    static TemporalQuery offset() { return TemporalQuery{}; }
    static TemporalQuery zone() { return TemporalQuery{}; }
    static TemporalQuery precision() { return TemporalQuery{}; }
    static TemporalQuery chronology() { return TemporalQuery{}; }
    static TemporalQuery zoneId() { return TemporalQuery{}; }
    static TemporalQuery localDate() { return TemporalQuery{}; }
    static TemporalQuery localTime() { return TemporalQuery{}; }
};

void offset_test_12534() { TemporalQueries::offset(); }
void zone_test_12535() { TemporalQueries::zone(); }
void precision_test_12536() { TemporalQueries::precision(); }
void chronology_test_12537() { TemporalQueries::chronology(); }
void zoneId_test_12538() { TemporalQueries::zoneId(); }
void localDate_test_12539() { TemporalQueries::localDate(); }
void localTime_test_12540() { TemporalQueries::localTime(); }