#include <string>

class XMLEvent {
public:
    virtual ~XMLEvent() = default;
};

class XMLEventReader {
public:
    virtual ~XMLEventReader() = default;
    virtual void remove() = 0;
    virtual void* getProperty(const std::string& name) = 0;
    virtual bool hasNext() = 0;
    virtual void* next() = 0;
};

class EventReaderDelegate : public XMLEventReader {
public:
    EventReaderDelegate() : parent(nullptr) {}
    explicit EventReaderDelegate(XMLEventReader* parent) : parent(parent) {}

    void remove() override {
        if (parent) parent->remove();
    }

    void* getProperty(const std::string& name) override {
        return parent ? parent->getProperty(name) : nullptr;
    }

    bool hasNext() override {
        return parent ? parent->hasNext() : false;
    }

    void* next() override {
        return parent ? parent->next() : nullptr;
    }

    XMLEventReader* getParent() {
        return parent;
    }

    void setParent(XMLEventReader* p) {
        parent = p;
    }

private:
    XMLEventReader* parent;
};

void remove_test_4598() {
    EventReaderDelegate instance;
    instance.remove();
}

void getProperty_test_4599(const std::string& p0) {
    EventReaderDelegate instance;
    instance.getProperty(p0);
}

void hasNext_test_4600() {
    EventReaderDelegate instance;
    instance.hasNext();
}

void next_test_4601() {
    EventReaderDelegate instance;
    instance.next();
}

void getParent_test_4602() {
    EventReaderDelegate instance;
    instance.getParent();
}

void setParent_test_4603(XMLEventReader* p0) {
    EventReaderDelegate instance;
    instance.setParent(p0);
}