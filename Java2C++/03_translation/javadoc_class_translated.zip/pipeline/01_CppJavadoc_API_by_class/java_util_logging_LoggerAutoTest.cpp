#include <string>
#include <map>
#include <memory>
#include <mutex>
#include <vector>
#include <utility>
#include <stdexcept>

class Logger {
public:
    static Logger* getLogger(const std::string& name) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = loggers_.find(name);
        if (it != loggers_.end()) {
            return it->second.get();
        }
        auto logger = std::unique_ptr<Logger>(new Logger(name, ""));
        Logger* ptr = logger.get();
        loggers_.emplace(name, std::move(logger));
        return ptr;
    }

    static Logger* getLogger(const std::string& name, const std::string& resourceBundleName) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = loggers_.find(name);
        if (it != loggers_.end()) {
            if (it->second->resourceBundleName_.empty()) {
                it->second->resourceBundleName_ = resourceBundleName;
            } else if (it->second->resourceBundleName_ != resourceBundleName) {
                throw std::invalid_argument("Logger " + name + " already exists with a different resource bundle");
            }
            return it->second.get();
        }
        auto logger = std::unique_ptr<Logger>(new Logger(name, resourceBundleName));
        Logger* ptr = logger.get();
        loggers_.emplace(name, std::move(logger));
        return ptr;
    }

    static Logger* getAnonymousLogger() {
        return createAnonymousLogger("");
    }

    static Logger* getAnonymousLogger(const std::string& resourceBundleName) {
        return createAnonymousLogger(resourceBundleName);
    }

    static Logger& getGlobal() {
        static Logger global("global", "");
        return global;
    }

    std::string getName() const {
        return name_;
    }

    std::string getResourceBundleName() const {
        return resourceBundleName_;
    }

private:
    Logger(const std::string& name, const std::string& resourceBundleName)
        : name_(name), resourceBundleName_(resourceBundleName) {}

    static Logger* createAnonymousLogger(const std::string& resourceBundleName) {
        auto logger = std::unique_ptr<Logger>(new Logger("", resourceBundleName));
        Logger* ptr = logger.get();
        anonymousLoggers_.push_back(std::move(logger));
        return ptr;
    }

    static std::mutex mutex_;
    static std::map<std::string, std::unique_ptr<Logger>> loggers_;
    static std::vector<std::unique_ptr<Logger>> anonymousLoggers_;

    std::string name_;
    std::string resourceBundleName_;
};

std::mutex Logger::mutex_;
std::map<std::string, std::unique_ptr<Logger>> Logger::loggers_;
std::vector<std::unique_ptr<Logger>> Logger::anonymousLoggers_;

void getLogger_test_8104(const std::string& p0) {
    Logger::getLogger(p0);
}

void getLogger_test_8105(const std::string& p0, const std::string& p1) {
    Logger::getLogger(p0, p1);
}

void getAnonymousLogger_test_8106() {
    Logger::getAnonymousLogger();
}

void getAnonymousLogger_test_8107(const std::string& p0) {
    Logger::getAnonymousLogger(p0);
}

void getGlobal_test_8108() {
    Logger::getGlobal();
}