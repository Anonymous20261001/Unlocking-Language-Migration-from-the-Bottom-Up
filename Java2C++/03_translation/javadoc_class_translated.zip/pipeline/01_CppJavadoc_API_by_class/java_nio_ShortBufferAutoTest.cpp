#include <cstddef>
#include <stdexcept>
#include <utility>
#include <vector>

class ShortBuffer {
public:
    static ShortBuffer wrap(std::vector<short>& array) {
        return ShortBuffer(array, 0, static_cast<int>(array.size()));
    }

    static ShortBuffer wrap(std::vector<short>& array, int offset, int length) {
        if (offset < 0 || length < 0 || offset > static_cast<int>(array.size()) ||
            length > static_cast<int>(array.size()) - offset) {
            throw std::out_of_range("wrap index out of bounds");
        }
        ShortBuffer buffer(array, offset, offset + length);
        buffer.capacity_ = static_cast<int>(array.size());
        buffer.limit_ = offset + length;
        return buffer;
    }

    static ShortBuffer allocate(int capacity) {
        if (capacity < 0) {
            throw std::out_of_range("negative capacity");
        }
        std::vector<short> storage(static_cast<std::size_t>(capacity), 0);
        return ShortBuffer(std::move(storage), 0, capacity);
    }

    int capacity() const { return capacity_; }
    int position() const { return position_; }
    int limit() const { return limit_; }

private:
    ShortBuffer(std::vector<short> storage, int position, int limit)
        : storage_(std::move(storage)),
          position_(position),
          limit_(limit),
          capacity_(static_cast<int>(storage_.size())) {}

    ShortBuffer(const std::vector<short>& storage, int position, int limit)
        : storage_(storage),
          position_(position),
          limit_(limit),
          capacity_(static_cast<int>(storage_.size())) {}

    std::vector<short> storage_;
    int capacity_;
    int position_;
    int limit_;
};

void wrap_test_11098(std::vector<short>& p0) {
    ShortBuffer::wrap(p0);
}

void wrap_test_11099(std::vector<short>& p0, int p1, int p2) {
    ShortBuffer::wrap(p0, p1, p2);
}

void allocate_test_11100(int p0) {
    ShortBuffer::allocate(p0);
}