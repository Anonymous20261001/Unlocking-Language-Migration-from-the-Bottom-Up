class Modifier {
public:
    enum {
        PUBLIC = 0x00000001,
        PRIVATE = 0x00000002,
        PROTECTED = 0x00000004,
        STATIC = 0x00000008,
        FINAL = 0x00000010,
        SYNCHRONIZED = 0x00000020,
        VOLATILE = 0x00000040,
        TRANSIENT = 0x00000080,
        NATIVE = 0x00000100,
        INTERFACE = 0x00000200,
        ABSTRACT = 0x00000400,
        STRICT = 0x00000800
    };

    static bool isInterface(int mod) { return (mod & INTERFACE) != 0; }
    static bool isFinal(int mod) { return (mod & FINAL) != 0; }
    static bool isPublic(int mod) { return (mod & PUBLIC) != 0; }
    static bool isStatic(int mod) { return (mod & STATIC) != 0; }
    static bool isProtected(int mod) { return (mod & PROTECTED) != 0; }
    static bool isAbstract(int mod) { return (mod & ABSTRACT) != 0; }
    static bool isVolatile(int mod) { return (mod & VOLATILE) != 0; }
    static bool isPrivate(int mod) { return (mod & PRIVATE) != 0; }
    static bool isNative(int mod) { return (mod & NATIVE) != 0; }
    static bool isSynchronized(int mod) { return (mod & SYNCHRONIZED) != 0; }
    static bool isTransient(int mod) { return (mod & TRANSIENT) != 0; }
    static bool isStrict(int mod) { return (mod & STRICT) != 0; }

    static int classModifiers() { return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | FINAL | STRICT; }
    static int interfaceModifiers() { return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | STRICT; }
    static int methodModifiers() { return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | FINAL | SYNCHRONIZED | NATIVE | STRICT; }
    static int constructorModifiers() { return PUBLIC | PROTECTED | PRIVATE; }
    static int fieldModifiers() { return PUBLIC | PROTECTED | PRIVATE | STATIC | FINAL | TRANSIENT | VOLATILE; }
    static int parameterModifiers() { return FINAL; }
};

void isInterface_test_8971(int p0) { Modifier::isInterface(p0); }

void classModifiers_test_8972() { Modifier::classModifiers(); }

void isFinal_test_8973(int p0) { Modifier::isFinal(p0); }

void isPublic_test_8974(int p0) { Modifier::isPublic(p0); }

void isStatic_test_8975(int p0) { Modifier::isStatic(p0); }

void isProtected_test_8976(int p0) { Modifier::isProtected(p0); }

void methodModifiers_test_8977() { Modifier::methodModifiers(); }

void constructorModifiers_test_8978() { Modifier::constructorModifiers(); }

void isAbstract_test_8979(int p0) { Modifier::isAbstract(p0); }

void isVolatile_test_8980(int p0) { Modifier::isVolatile(p0); }

void isPrivate_test_8981(int p0) { Modifier::isPrivate(p0); }

void isNative_test_8982(int p0) { Modifier::isNative(p0); }

void isSynchronized_test_8983(int p0) { Modifier::isSynchronized(p0); }

void isTransient_test_8984(int p0) { Modifier::isTransient(p0); }

void isStrict_test_8985(int p0) { Modifier::isStrict(p0); }

void interfaceModifiers_test_8986() { Modifier::interfaceModifiers(); }

void fieldModifiers_test_8987() { Modifier::fieldModifiers(); }

void parameterModifiers_test_8988() { Modifier::parameterModifiers(); }