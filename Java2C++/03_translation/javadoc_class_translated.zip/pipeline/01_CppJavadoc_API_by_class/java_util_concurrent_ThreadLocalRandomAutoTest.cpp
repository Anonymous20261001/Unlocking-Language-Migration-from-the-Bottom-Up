#include <random>

class ThreadLocalRandom {
public:
    static ThreadLocalRandom& current() {
        static thread_local ThreadLocalRandom instance;
        return instance;
    }

private:
    ThreadLocalRandom() = default;
};

void current_test_12713() {
    ThreadLocalRandom::current();
}