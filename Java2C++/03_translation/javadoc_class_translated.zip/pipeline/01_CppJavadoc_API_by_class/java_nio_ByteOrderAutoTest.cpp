#include <cstdint>

class ByteOrder {
public:
    static const ByteOrder BIG_ENDIAN;
    static const ByteOrder LITTLE_ENDIAN;

    static const ByteOrder& nativeOrder() {
        std::uint16_t i = 1;
        return (*reinterpret_cast<std::uint8_t*>(&i) == 1) ? LITTLE_ENDIAN : BIG_ENDIAN;
    }

    bool operator==(const ByteOrder& other) const {
        return order_ == other.order_;
    }

    bool operator!=(const ByteOrder& other) const {
        return !(*this == other);
    }

private:
    explicit ByteOrder(std::uint8_t order) : order_(order) {}
    std::uint8_t order_;
};

const ByteOrder ByteOrder::BIG_ENDIAN(1);
const ByteOrder ByteOrder::LITTLE_ENDIAN(2);

void nativeOrder_test_2007() {
    ByteOrder::nativeOrder();
}