#include <cstddef>

namespace javax {
namespace net {

class ServerSocketFactory {
public:
    virtual ~ServerSocketFactory() = default;

    static ServerSocketFactory& getDefault() {
        static ServerSocketFactory instance;
        return instance;
    }

protected:
    ServerSocketFactory() = default;

private:
    ServerSocketFactory(const ServerSocketFactory&) = delete;
    ServerSocketFactory& operator=(const ServerSocketFactory&) = delete;
};

} // namespace net
} // namespace javax

using javax::net::ServerSocketFactory;

void getDefault_test_11047() {
    ServerSocketFactory::getDefault();
}