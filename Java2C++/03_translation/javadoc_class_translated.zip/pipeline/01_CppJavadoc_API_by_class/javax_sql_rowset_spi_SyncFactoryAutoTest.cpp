#include <string>

namespace java {
namespace util {
namespace logging {

class Level {
public:
    static const Level OFF;
    static const Level SEVERE;
    static const Level WARNING;
    static const Level INFO;
    static const Level CONFIG;
    static const Level FINE;
    static const Level FINER;
    static const Level FINEST;
    static const Level ALL;

    const std::string& getName() const { return name_; }
    int intValue() const { return value_; }

private:
    Level(const std::string& name, int value) : name_(name), value_(value) {}

    std::string name_;
    int value_;
};

const Level Level::OFF("OFF", 0);
const Level Level::SEVERE("SEVERE", 1000);
const Level Level::WARNING("WARNING", 900);
const Level Level::INFO("INFO", 800);
const Level Level::CONFIG("CONFIG", 700);
const Level Level::FINE("FINE", 500);
const Level Level::FINER("FINER", 400);
const Level Level::FINEST("FINEST", 300);
const Level Level::ALL("ALL", 0);

class Logger {
public:
    static Logger& getLogger(const std::string& name) {
        static Logger instance(name);
        return instance;
    }

    const std::string& getName() const { return name_; }
    void setLevel(const Level& level) { level_ = &level; }
    const Level* getLevel() const { return level_; }

private:
    explicit Logger(const std::string& name) : name_(name), level_(nullptr) {}

    std::string name_;
    const Level* level_;
};

} // namespace logging
} // namespace util
} // namespace java

namespace javax {
namespace sql {
namespace rowset {
namespace spi {

class SyncFactory {
public:
    static SyncFactory& getSyncFactory() {
        static SyncFactory instance;
        return instance;
    }

    static void setLogger(java::util::logging::Logger logger) {
        logger_ = logger;
    }

    static void setLogger(java::util::logging::Logger logger, java::util::logging::Level level) {
        logger_ = logger;
        level_ = level;
    }

private:
    SyncFactory() {}

    static java::util::logging::Logger logger_;
    static java::util::logging::Level level_;
};

java::util::logging::Logger SyncFactory::logger_ =
    java::util::logging::Logger::getLogger("javax.sql.rowset.spi.SyncFactory");
java::util::logging::Level SyncFactory::level_ = java::util::logging::Level::INFO;

} // namespace spi
} // namespace rowset
} // namespace sql
} // namespace javax

void getSyncFactory_test_12123() {
    javax::sql::rowset::spi::SyncFactory::getSyncFactory();
}

void setLogger_test_12124(java::util::logging::Logger p0) {
    javax::sql::rowset::spi::SyncFactory::setLogger(p0);
}

void setLogger_test_12125(java::util::logging::Logger p0, java::util::logging::Level p1) {
    javax::sql::rowset::spi::SyncFactory::setLogger(p0, p1);
}
