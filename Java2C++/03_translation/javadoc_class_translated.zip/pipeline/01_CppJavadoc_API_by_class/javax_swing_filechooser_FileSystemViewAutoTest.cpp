class FileSystemView {
public:
    static FileSystemView& getFileSystemView() {
        static FileSystemView instance;
        return instance;
    }

private:
    FileSystemView() = default;
};

void getFileSystemView_test_4781() {
    FileSystemView::getFileSystemView();
}