#include <string>
#include <stdexcept>

using String = std::string;

class IllegalArgumentException : public std::invalid_argument {
public:
    explicit IllegalArgumentException(const std::string& message)
        : std::invalid_argument(message) {}
};

class ObjectName {
public:
    ObjectName() : name_() {}
    explicit ObjectName(const String& name) : name_(name) {}
    ObjectName(const ObjectName&) = default;
    ObjectName& operator=(const ObjectName&) = default;

    const String& toString() const { return name_; }

    static String quote(const String& s);
    static String unquote(const String& q);
    static ObjectName getInstance(const ObjectName& name);

private:
    String name_;
};

String ObjectName::quote(const String& s) {
    String result;
    result.reserve(s.size() + 2);
    result += '"';
    for (char c : s) {
        switch (c) {
            case '\n': result += "\\n"; break;
            case '\r': result += "\\r"; break;
            case '\t': result += "\\t"; break;
            case '\\': result += "\\\\"; break;
            case '"': result += "\\\""; break;
            default: result += c; break;
        }
    }
    result += '"';
    return result;
}

String ObjectName::unquote(const String& q) {
    if (q.size() < 2 || q.front() != '"' || q.back() != '"') {
        throw IllegalArgumentException("Argument not quoted");
    }
    String result;
    result.reserve(q.size() - 2);
    for (size_t i = 1; i < q.size() - 1; ++i) {
        char c = q[i];
        if (c == '\\') {
            if (i == q.size() - 2) {
                throw IllegalArgumentException("Trailing backslash");
            }
            char n = q[++i];
            switch (n) {
                case 'n': result += '\n'; break;
                case 'r': result += '\r'; break;
                case 't': result += '\t'; break;
                case '\\': result += '\\'; break;
                case '"': result += '"'; break;
                default: throw IllegalArgumentException("Invalid escape sequence");
            }
        } else {
            result += c;
        }
    }
    return result;
}

ObjectName ObjectName::getInstance(const ObjectName& name) {
    return name;
}

void unquote_test_9594(String p0) {
    ObjectName::unquote(p0);
}

void getInstance_test_9595(ObjectName p0) {
    ObjectName::getInstance(p0);
}

void quote_test_9596(String p0) {
    ObjectName::quote(p0);
}