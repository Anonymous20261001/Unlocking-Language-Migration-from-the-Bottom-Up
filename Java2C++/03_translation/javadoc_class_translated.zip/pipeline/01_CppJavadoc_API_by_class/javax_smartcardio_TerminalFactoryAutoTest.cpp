#include <string>

class TerminalFactory {
public:
    static std::string getDefaultType() {
        return "PC/SC";
    }

    static TerminalFactory getDefault() {
        return TerminalFactory();
    }
};

void getDefaultType_test_12541() {
    TerminalFactory::getDefaultType();
}

void getDefault_test_12542() {
    TerminalFactory::getDefault();
}