#include <string>
#include <utility>

// Minimal C++ equivalents for Java types used in the tests.

enum class Month {
    JANUARY = 1,
    FEBRUARY = 2,
    MARCH = 3,
    APRIL = 4,
    MAY = 5,
    JUNE = 6,
    JULY = 7,
    AUGUST = 8,
    SEPTEMBER = 9,
    OCTOBER = 10,
    NOVEMBER = 11,
    DECEMBER = 12
};

class CharSequence {
    std::string text;
public:
    CharSequence() = default;
    CharSequence(const std::string& s) : text(s) {}
    CharSequence(const char* s) : text(s) {}
    const std::string& toString() const { return text; }
};

class DateTimeFormatter {
    std::string pattern;
public:
    explicit DateTimeFormatter(std::string p) : pattern(std::move(p)) {}
};

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
};

class ZoneId {
    std::string id;
public:
    explicit ZoneId(std::string i) : id(std::move(i)) {}
};

class Clock {
public:
    Clock() = default;
};

class YearMonth {
    int year;
    int month;
public:
    YearMonth(int y, int m) : year(y), month(m) {}

    static YearMonth of(int year, int month) {
        return YearMonth(year, month);
    }

    static YearMonth of(int year, Month month) {
        return YearMonth(year, static_cast<int>(month));
    }

    static YearMonth from(const TemporalAccessor&) {
        return YearMonth(1970, 1);
    }

    static YearMonth parse(const CharSequence&, const DateTimeFormatter&) {
        return YearMonth(1970, 1);
    }

    static YearMonth parse(const CharSequence&) {
        return YearMonth(1970, 1);
    }

    static YearMonth now() {
        return YearMonth(1970, 1);
    }

    static YearMonth now(const ZoneId&) {
        return YearMonth(1970, 1);
    }

    static YearMonth now(const Clock&) {
        return YearMonth(1970, 1);
    }
};

// Translated test functions. Each Java @Test becomes one C++ function.

void of_test_13674(int p0, int p1) {
    YearMonth::of(p0, p1);
}

void of_test_13675(int p0, Month p1) {
    YearMonth::of(p0, p1);
}

void from_test_13676(const TemporalAccessor& p0) {
    YearMonth::from(p0);
}

void parse_test_13677(const CharSequence& p0, const DateTimeFormatter& p1) {
    YearMonth::parse(p0, p1);
}

void parse_test_13678(const CharSequence& p0) {
    YearMonth::parse(p0);
}

void now_test_13679() {
    YearMonth::now();
}

void now_test_13680(const ZoneId& p0) {
    YearMonth::now(p0);
}

void now_test_13681(const Clock& p0) {
    YearMonth::now(p0);
}