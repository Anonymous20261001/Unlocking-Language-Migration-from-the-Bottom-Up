#include <string>
#include <cctype>

class LocalDate {
public:
    int year;
    int month;
    int day;

    LocalDate(int y, int m, int d) : year(y), month(m), day(d) {}

    static bool isLeap(int y) {
        return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    }

    static int daysInMonth(int y, int m) {
        static const int days[] = {31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31};
        if (m == 2 && isLeap(y)) {
            return 29;
        }
        return days[m - 1];
    }
};

class TemporalAmount {
public:
    virtual ~TemporalAmount() = default;
    virtual int getYears() const = 0;
    virtual int getMonths() const = 0;
    virtual int getDays() const = 0;
};

class Period : public TemporalAmount {
private:
    int years;
    int months;
    int days;

    Period(int y, int m, int d) : years(y), months(m), days(d) {}

public:
    static Period of(int y, int m, int d) {
        return Period(y, m, d);
    }

    static Period from(const TemporalAmount& amount) {
        return Period(amount.getYears(), amount.getMonths(), amount.getDays());
    }

    static Period parse(const std::string& text) {
        int years = 0;
        int months = 0;
        int days = 0;

        if (text.empty() || text[0] != 'P') {
            return Period(0, 0, 0);
        }

        size_t i = 1;
        while (i < text.size()) {
            size_t start = i;
            while (i < text.size() && std::isdigit(static_cast<unsigned char>(text[i]))) {
                ++i;
            }

            if (i == start) {
                ++i;
                continue;
            }

            int value = std::stoi(text.substr(start, i - start));

            if (i < text.size()) {
                char unit = text[i];
                if (unit == 'Y') {
                    years = value;
                } else if (unit == 'M') {
                    months = value;
                } else if (unit == 'D') {
                    days = value;
                } else if (unit == 'W') {
                    days += value * 7;
                }
                ++i;
            }
        }

        return Period(years, months, days);
    }

    static Period between(const LocalDate& start, const LocalDate& end) {
        int y = end.year - start.year;
        int m = end.month - start.month;
        int d = end.day - start.day;

        if (d < 0) {
            --m;
            int prevMonth = end.month - 1;
            int prevYear = end.year;
            if (prevMonth == 0) {
                prevMonth = 12;
                --prevYear;
            }
            d += LocalDate::daysInMonth(prevYear, prevMonth);
        }

        if (m < 0) {
            --y;
            m += 12;
        }

        return Period(y, m, d);
    }

    static Period ofDays(int d) {
        return Period(0, 0, d);
    }

    static Period ofYears(int y) {
        return Period(y, 0, 0);
    }

    static Period ofMonths(int m) {
        return Period(0, m, 0);
    }

    static Period ofWeeks(int w) {
        return Period(0, 0, w * 7);
    }

    int getYears() const override {
        return years;
    }

    int getMonths() const override {
        return months;
    }

    int getDays() const override {
        return days;
    }
};

void of_test_9886() {
    Period::of(1, 2, 3);
}

void from_test_9887() {
    Period p = Period::of(1, 2, 3);
    Period::from(p);
}

void parse_test_9888() {
    Period::parse("P1Y2M3D");
}

void between_test_9889() {
    LocalDate d1(2020, 1, 1);
    LocalDate d2(2021, 2, 3);
    Period::between(d1, d2);
}

void ofDays_test_9890() {
    Period::ofDays(5);
}

void ofYears_test_9891() {
    Period::ofYears(3);
}

void ofMonths_test_9892() {
    Period::ofMonths(4);
}

void ofWeeks_test_9893() {
    Period::ofWeeks(2);
}
