#include <string>
#include <vector>
#include <stdexcept>

namespace java_time_format {

class Locale {
public:
    Locale() : language_("en"), country_("") {}
    explicit Locale(const std::string& language) : language_(language), country_("") {}
    Locale(const std::string& language, const std::string& country) : language_(language), country_(country) {}

    static Locale getDefault() { return Locale("en"); }

    std::string getLanguage() const { return language_; }
    std::string getCountry() const { return country_; }

private:
    std::string language_;
    std::string country_;
};

enum class FormatStyle {
    SHORT,
    MEDIUM,
    LONG,
    FULL
};

class TemporalQuery {
public:
    virtual ~TemporalQuery() = default;
};

class DateTimeFormatter {
public:
    static DateTimeFormatter ofPattern(const std::string& pattern) {
        return DateTimeFormatter(pattern, Locale::getDefault());
    }

    static DateTimeFormatter ofPattern(const std::string& pattern, const Locale& locale) {
        return DateTimeFormatter(pattern, locale);
    }

    static DateTimeFormatter ofLocalizedDate(FormatStyle dateStyle) {
        return DateTimeFormatter("localized date", Locale::getDefault(), dateStyle);
    }

    static DateTimeFormatter ofLocalizedTime(FormatStyle timeStyle) {
        return DateTimeFormatter("localized time", Locale::getDefault(), timeStyle);
    }

    static DateTimeFormatter ofLocalizedDateTime(FormatStyle dateTimeStyle) {
        return DateTimeFormatter("localized datetime", Locale::getDefault(), dateTimeStyle);
    }

    static DateTimeFormatter ofLocalizedDateTime(FormatStyle dateStyle, FormatStyle timeStyle) {
        return DateTimeFormatter("localized datetime", Locale::getDefault(), dateStyle, timeStyle);
    }

    static DateTimeFormatter ofLocalizedPattern(const std::string& pattern) {
        return DateTimeFormatter(pattern, Locale::getDefault());
    }

    static TemporalQuery parsedExcessDays() {
        return TemporalQuery();
    }

    static TemporalQuery parsedLeapSecond() {
        return TemporalQuery();
    }

private:
    std::string pattern_;
    Locale locale_;
    FormatStyle dateStyle_;
    FormatStyle timeStyle_;
    bool hasTimeStyle_;

    DateTimeFormatter(const std::string& pattern, const Locale& locale)
        : pattern_(pattern), locale_(locale), dateStyle_(FormatStyle::SHORT),
          timeStyle_(FormatStyle::SHORT), hasTimeStyle_(false) {}

    DateTimeFormatter(const std::string& pattern, const Locale& locale, FormatStyle dateStyle)
        : pattern_(pattern), locale_(locale), dateStyle_(dateStyle),
          timeStyle_(FormatStyle::SHORT), hasTimeStyle_(false) {}

    DateTimeFormatter(const std::string& pattern, const Locale& locale, FormatStyle dateStyle, FormatStyle timeStyle)
        : pattern_(pattern), locale_(locale), dateStyle_(dateStyle),
          timeStyle_(timeStyle), hasTimeStyle_(true) {}
};

} // namespace java_time_format

void ofPattern_test_3355() {
    java_time_format::DateTimeFormatter::ofPattern("yyyy-MM-dd");
}

void ofPattern_test_3356() {
    java_time_format::Locale locale("en", "US");
    java_time_format::DateTimeFormatter::ofPattern("dd/MM/yyyy", locale);
}

void ofLocalizedDate_test_3357() {
    java_time_format::DateTimeFormatter::ofLocalizedDate(java_time_format::FormatStyle::MEDIUM);
}

void ofLocalizedTime_test_3358() {
    java_time_format::DateTimeFormatter::ofLocalizedTime(java_time_format::FormatStyle::SHORT);
}

void ofLocalizedDateTime_test_3359() {
    java_time_format::DateTimeFormatter::ofLocalizedDateTime(java_time_format::FormatStyle::LONG);
}

void ofLocalizedDateTime_test_3360() {
    java_time_format::DateTimeFormatter::ofLocalizedDateTime(java_time_format::FormatStyle::FULL,
                                                              java_time_format::FormatStyle::MEDIUM);
}

void ofLocalizedPattern_test_3361() {
    java_time_format::DateTimeFormatter::ofLocalizedPattern("yyyy-MM-dd HH:mm");
}

void parsedExcessDays_test_3362() {
    java_time_format::DateTimeFormatter::parsedExcessDays();
}

void parsedLeapSecond_test_3363() {
    java_time_format::DateTimeFormatter::parsedLeapSecond();
}