#include <memory>
#include <string>
#include <utility>

class Object {
public:
    virtual ~Object() = default;
};

class String : public Object {
public:
    std::string value;
    explicit String(std::string v = "") : value(std::move(v)) {}
};

class Operation : public Object {
public:
    ~Operation() override = default;
};

class NamedOperation : public Operation {
private:
    std::shared_ptr<Operation> baseOperation_;
    std::shared_ptr<Object> name_;

public:
    NamedOperation(std::shared_ptr<Operation> baseOperation, std::shared_ptr<Object> name)
        : baseOperation_(std::move(baseOperation)), name_(std::move(name)) {}

    std::shared_ptr<Object> getName() const {
        return name_;
    }

    std::shared_ptr<Operation> getBaseOperation() const {
        return baseOperation_;
    }

    std::shared_ptr<NamedOperation> changeName(const std::shared_ptr<String>& newName) const {
        return std::make_shared<NamedOperation>(baseOperation_, newName);
    }

    static std::shared_ptr<Object> getName(const std::shared_ptr<Operation>& op) {
        auto named = std::dynamic_pointer_cast<NamedOperation>(op);
        return named ? named->name_ : nullptr;
    }

    static std::shared_ptr<Operation> getBaseOperation(const std::shared_ptr<Operation>& op) {
        auto named = std::dynamic_pointer_cast<NamedOperation>(op);
        return named ? named->baseOperation_ : op;
    }
};

void getName_test_9477(std::shared_ptr<Operation> p0) {
    NamedOperation::getName(p0);
}

void getName_test_9478(std::shared_ptr<Operation> c0, std::shared_ptr<Object> c1) {
    NamedOperation instance(c0, c1);
    instance.getName();
}

void changeName_test_9479(std::shared_ptr<String> p0, std::shared_ptr<Operation> c0, std::shared_ptr<Object> c1) {
    NamedOperation instance(c0, c1);
    instance.changeName(p0);
}

void getBaseOperation_test_9480(std::shared_ptr<Operation> c0, std::shared_ptr<Object> c1) {
    NamedOperation instance(c0, c1);
    instance.getBaseOperation();
}

void getBaseOperation_test_9481(std::shared_ptr<Operation> p0) {
    NamedOperation::getBaseOperation(p0);
}