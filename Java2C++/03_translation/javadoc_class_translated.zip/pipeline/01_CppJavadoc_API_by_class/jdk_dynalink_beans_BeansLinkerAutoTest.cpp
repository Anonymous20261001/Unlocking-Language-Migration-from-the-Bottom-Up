#include <set>
#include <string>

using Class = void*;
using Object = void*;
using String = const char*;
using MethodHandle = void*;
using NameSet = std::set<std::string>;

class BeansLinker {
public:
    MethodHandle getLinkerForClass(Class) {
        return nullptr;
    }

    static bool isDynamicMethod(Object) {
        return false;
    }

    static MethodHandle getConstructorMethod(Class, String) {
        return nullptr;
    }

    static NameSet getReadableStaticPropertyNames(Class) {
        return NameSet();
    }

    static NameSet getWritableStaticPropertyNames(Class) {
        return NameSet();
    }

    static NameSet getStaticMethodNames(Class) {
        return NameSet();
    }

    static bool isDynamicConstructor(Object) {
        return false;
    }

    static NameSet getReadableInstancePropertyNames(Class) {
        return NameSet();
    }

    static NameSet getWritableInstancePropertyNames(Class) {
        return NameSet();
    }

    static NameSet getInstanceMethodNames(Class) {
        return NameSet();
    }
};

void getLinkerForClass_test_1576(Class p0) {
    BeansLinker instance;
    instance.getLinkerForClass(p0);
}

void isDynamicMethod_test_1577(Object p0) {
    BeansLinker::isDynamicMethod(p0);
}

void getConstructorMethod_test_1578(Class p0, String p1) {
    BeansLinker::getConstructorMethod(p0, p1);
}

void getReadableStaticPropertyNames_test_1579(Class p0) {
    BeansLinker::getReadableStaticPropertyNames(p0);
}

void getWritableStaticPropertyNames_test_1580(Class p0) {
    BeansLinker::getWritableStaticPropertyNames(p0);
}

void getStaticMethodNames_test_1581(Class p0) {
    BeansLinker::getStaticMethodNames(p0);
}

void isDynamicConstructor_test_1582(Object p0) {
    BeansLinker::isDynamicConstructor(p0);
}

void getReadableInstancePropertyNames_test_1583(Class p0) {
    BeansLinker::getReadableInstancePropertyNames(p0);
}

void getWritableInstancePropertyNames_test_1584(Class p0) {
    BeansLinker::getWritableInstancePropertyNames(p0);
}

void getInstanceMethodNames_test_1585(Class p0) {
    BeansLinker::getInstanceMethodNames(p0);
}