#include <string>

class SSLContext {
public:
    static SSLContext getInstance(const std::string& protocol) {
        return SSLContext(protocol);
    }

    static void setDefault(SSLContext& context) {
        defaultContext = &context;
    }

private:
    explicit SSLContext(const std::string& protocol) : protocol(protocol) {}

    std::string protocol;
    static SSLContext* defaultContext;
};

SSLContext* SSLContext::defaultContext = nullptr;

void setDefault_test_11400() {
    SSLContext p0 = SSLContext::getInstance("TLS");
    SSLContext::setDefault(p0);
}