#include <string>

class File {
public:
    File() = default;
    explicit File(const std::string& path) : path_(path) {}
    const std::string& getPath() const { return path_; }

private:
    std::string path_;
};

class KerberosPrincipal {
public:
    KerberosPrincipal() = default;
    explicit KerberosPrincipal(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }

private:
    std::string name_;
};

class KeyTab {
public:
    static KeyTab getInstance(KerberosPrincipal /*principal*/) {
        return KeyTab();
    }

    static KeyTab getInstance(File /*file*/) {
        return KeyTab();
    }

    static KeyTab getInstance() {
        return KeyTab();
    }

    static KeyTab getInstance(KerberosPrincipal /*principal*/, File /*file*/) {
        return KeyTab();
    }

    static KeyTab getUnboundInstance() {
        return KeyTab();
    }

    static KeyTab getUnboundInstance(File /*file*/) {
        return KeyTab();
    }

private:
    KeyTab() = default;
};

void getInstance_test_7662(KerberosPrincipal p0) {
    KeyTab::getInstance(p0);
}

void getInstance_test_7663(File p0) {
    KeyTab::getInstance(p0);
}

void getInstance_test_7664() {
    KeyTab::getInstance();
}

void getInstance_test_7665(KerberosPrincipal p0, File p1) {
    KeyTab::getInstance(p0, p1);
}

void getUnboundInstance_test_7666() {
    KeyTab::getUnboundInstance();
}

void getUnboundInstance_test_7667(File p0) {
    KeyTab::getUnboundInstance(p0);
}