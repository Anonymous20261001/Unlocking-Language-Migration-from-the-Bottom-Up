#include <cstddef>

class Policy {
public:
    virtual ~Policy() = default;

    static void setPolicy(Policy* policy) {
        currentPolicy = policy;
    }

    static Policy* getPolicy() {
        return currentPolicy != nullptr ? currentPolicy : getDefaultPolicy();
    }

private:
    static inline Policy* currentPolicy = nullptr;

    static Policy* getDefaultPolicy() {
        static Policy defaultPolicy;
        return &defaultPolicy;
    }
};

void setPolicy_test_9965(Policy* p0) {
    Policy::setPolicy(p0);
}

void getPolicy_test_9966() {
    Policy::getPolicy();
}