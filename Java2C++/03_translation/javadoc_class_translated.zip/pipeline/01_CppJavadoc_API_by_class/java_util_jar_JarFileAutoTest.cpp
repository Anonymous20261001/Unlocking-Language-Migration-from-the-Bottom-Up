#include <string>

class RuntimeVersion {
public:
    RuntimeVersion() : version_(0) {}
    explicit RuntimeVersion(int version) : version_(version) {}
    int version() const { return version_; }

private:
    int version_;
};

class JarFile {
public:
    static RuntimeVersion runtimeVersion() {
        return RuntimeVersion(21);
    }

    static RuntimeVersion baseVersion() {
        return RuntimeVersion(8);
    }
};

void runtimeVersion_test_5997() {
    JarFile::runtimeVersion();
}

void baseVersion_test_5998() {
    JarFile::baseVersion();
}
