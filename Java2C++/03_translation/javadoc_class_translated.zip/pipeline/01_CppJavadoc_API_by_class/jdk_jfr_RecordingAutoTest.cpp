#include <string>

class Duration {
public:
    Duration() : seconds_(0) {}
    explicit Duration(long long seconds) : seconds_(seconds) {}
    long long seconds() const { return seconds_; }

private:
    long long seconds_;
};

class Map {
public:
    Map() {}
};

class Class {
public:
    Class() {}
};

class Instant {
public:
    Instant() {}
};

class Path {
public:
    Path() {}
};

class EventSettings {
public:
    EventSettings() {}
};

class Recording {
public:
    Recording()
        : id_(nextId_++),
          state_("NEW"),
          toDisk_(false),
          dumpOnExit_(false),
          maxAge_(),
          maxSize_(0),
          size_(0),
          duration_(),
          startTime_(),
          stopTime_(),
          destination_(),
          name_(),
          settings_() {}

    Map getSettings() const { return settings_; }

    void setMaxAge(Duration p0) { maxAge_ = p0; }

    Duration getMaxAge() const { return maxAge_; }

    void setSettings(Map p0) { settings_ = p0; }

    bool isToDisk() const { return toDisk_; }

    Instant getStartTime() const { return startTime_; }

    Instant getStopTime() const { return stopTime_; }

    Path getDestination() const { return destination_; }

    long long getMaxSize() const { return maxSize_; }

    void setMaxSize(long long p0) { maxSize_ = p0; }

    bool getDumpOnExit() const { return dumpOnExit_; }

    void setDumpOnExit(bool p0) { dumpOnExit_ = p0; }

    void setToDisk(bool p0) { toDisk_ = p0; }

    void scheduleStart(Duration p0) { (void)p0; }

    void setDuration(Duration p0) { duration_ = p0; }

    std::string getName() const { return name_; }

    Recording copy(bool p0) { (void)p0; return *this; }

    void start() { state_ = "RUNNING"; }

    void stop() { state_ = "STOPPED"; }

    void setName(std::string p0) { name_ = p0; }

    long long getId() const { return id_; }

    std::string getState() const { return state_; }

    void close() { state_ = "CLOSED"; }

    long long getSize() const { return size_; }

    EventSettings enable(Class p0) { (void)p0; return EventSettings(); }

    EventSettings enable(std::string p0) { (void)p0; return EventSettings(); }

    Duration getDuration() const { return duration_; }

    EventSettings disable(std::string p0) { (void)p0; return EventSettings(); }

    EventSettings disable(Class p0) { (void)p0; return EventSettings(); }

private:
    long long id_;
    static long long nextId_;
    std::string state_;
    bool toDisk_;
    bool dumpOnExit_;
    Duration maxAge_;
    long long maxSize_;
    long long size_;
    Duration duration_;
    Instant startTime_;
    Instant stopTime_;
    Path destination_;
    std::string name_;
    Map settings_;
};

long long Recording::nextId_ = 1;

void getSettings_test_10348() {
    Recording instance;
    instance.getSettings();
}

void setMaxAge_test_10349(Duration p0) {
    Recording instance;
    instance.setMaxAge(p0);
}

void getMaxAge_test_10350() {
    Recording instance;
    instance.getMaxAge();
}

void setSettings_test_10351(Map p0) {
    Recording instance;
    instance.setSettings(p0);
}

void isToDisk_test_10352() {
    Recording instance;
    instance.isToDisk();
}

void getStartTime_test_10353() {
    Recording instance;
    instance.getStartTime();
}

void getStopTime_test_10354() {
    Recording instance;
    instance.getStopTime();
}

void getDestination_test_10355() {
    Recording instance;
    instance.getDestination();
}

void getMaxSize_test_10356() {
    Recording instance;
    instance.getMaxSize();
}

void setMaxSize_test_10357(long long p0) {
    Recording instance;
    instance.setMaxSize(p0);
}

void getDumpOnExit_test_10358() {
    Recording instance;
    instance.getDumpOnExit();
}

void setDumpOnExit_test_10359(bool p0) {
    Recording instance;
    instance.setDumpOnExit(p0);
}

void setToDisk_test_10360(bool p0) {
    Recording instance;
    instance.setToDisk(p0);
}

void scheduleStart_test_10361(Duration p0) {
    Recording instance;
    instance.scheduleStart(p0);
}

void setDuration_test_10362(Duration p0) {
    Recording instance;
    instance.setDuration(p0);
}

void getName_test_10363() {
    Recording instance;
    instance.getName();
}

void copy_test_10364(bool p0) {
    Recording instance;
    instance.copy(p0);
}

void start_test_10365() {
    Recording instance;
    instance.start();
}

void stop_test_10366() {
    Recording instance;
    instance.stop();
}

void setName_test_10367(std::string p0) {
    Recording instance;
    instance.setName(p0);
}

void getId_test_10368() {
    Recording instance;
    instance.getId();
}

void getState_test_10369() {
    Recording instance;
    instance.getState();
}

void close_test_10370() {
    Recording instance;
    instance.close();
}

void getSize_test_10371() {
    Recording instance;
    instance.getSize();
}

void enable_test_10372(Class p0) {
    Recording instance;
    instance.enable(p0);
}

void enable_test_10373(std::string p0) {
    Recording instance;
    instance.enable(p0);
}

void getDuration_test_10374() {
    Recording instance;
    instance.getDuration();
}

void disable_test_10375(std::string p0) {
    Recording instance;
    instance.disable(p0);
}

void disable_test_10376(Class p0) {
    Recording instance;
    instance.disable(p0);
}
