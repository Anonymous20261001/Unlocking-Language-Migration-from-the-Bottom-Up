class HttpClient {
public:
    class Builder {
    public:
        Builder() {}
    };

    static Builder newBuilder() {
        return Builder();
    }

    static HttpClient newHttpClient() {
        return HttpClient();
    }

    HttpClient() {}
};

void newBuilder_test_5409() {
    HttpClient::newBuilder();
}

void newHttpClient_test_5410() {
    HttpClient::newHttpClient();
}