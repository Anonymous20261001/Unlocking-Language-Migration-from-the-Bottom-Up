#include <string>
#include <vector>
#include <stdexcept>
#include <unordered_map>

class Object {
public:
    virtual ~Object() = default;
};

class ClassLoader {
public:
    ClassLoader() = default;
};

class Class {
public:
    Class() : name_(""), proxy_(false), interface_(false) {}
    explicit Class(const std::string& name, bool isProxy = false, bool isInterface = false)
        : name_(name), proxy_(isProxy), interface_(isInterface) {}

    const std::string& getName() const { return name_; }
    bool isProxyClass() const { return proxy_; }
    bool isInterface() const { return interface_; }

private:
    std::string name_;
    bool proxy_;
    bool interface_;
};

class InvocationHandler {
public:
    virtual ~InvocationHandler() = default;
    virtual Object* invoke(Object* proxy, const Class& method, std::vector<Object*>& args) = 0;
};

class ProxyInstance : public Object {
public:
    ProxyInstance(const Class& clazz, InvocationHandler* handler)
        : proxyClass_(clazz), handler_(handler) {}

    Class getProxyClass() const { return proxyClass_; }
    InvocationHandler* getHandler() const { return handler_; }

private:
    Class proxyClass_;
    InvocationHandler* handler_;
};

class Proxy {
public:
    static Class getProxyClass(ClassLoader, const std::vector<Class>& interfaces) {
        std::string key;
        for (const auto& iface : interfaces) {
            if (!key.empty()) key += ",";
            key += iface.getName();
        }
        if (key.empty()) key = "no_interfaces";

        auto& cache = proxyClasses();
        auto it = cache.find(key);
        if (it != cache.end()) {
            return it->second;
        }

        std::string name = "com.sun.proxy.$Proxy" + std::to_string(nextIndex());
        Class proxyClass(name, true, false);
        cache[key] = proxyClass;
        return proxyClass;
    }

    static InvocationHandler& getInvocationHandler(Object& proxy) {
        ProxyInstance* instance = dynamic_cast<ProxyInstance*>(&proxy);
        if (!instance) {
            throw std::invalid_argument("not a proxy instance");
        }
        return *instance->getHandler();
    }

    static bool isProxyClass(Class clazz) {
        return clazz.isProxyClass();
    }

    static Object* newProxyInstance(ClassLoader loader, const std::vector<Class>& interfaces, InvocationHandler& handler) {
        Class proxyClass = getProxyClass(loader, interfaces);
        return new ProxyInstance(proxyClass, &handler);
    }

private:
    static std::unordered_map<std::string, Class>& proxyClasses() {
        static std::unordered_map<std::string, Class> cache;
        return cache;
    }

    static int nextIndex() {
        static int counter = 0;
        return ++counter;
    }

    Proxy() = delete;
};

void getProxyClass_test_10213(ClassLoader p0, const std::vector<Class>& p1) {
    Proxy::getProxyClass(p0, p1);
}

void getInvocationHandler_test_10214(Object& p0) {
    Proxy::getInvocationHandler(p0);
}

void isProxyClass_test_10215(Class p0) {
    Proxy::isProxyClass(p0);
}

void newProxyInstance_test_10216(ClassLoader p0, const std::vector<Class>& p1, InvocationHandler& p2) {
    Proxy::newProxyInstance(p0, p1, p2);
}