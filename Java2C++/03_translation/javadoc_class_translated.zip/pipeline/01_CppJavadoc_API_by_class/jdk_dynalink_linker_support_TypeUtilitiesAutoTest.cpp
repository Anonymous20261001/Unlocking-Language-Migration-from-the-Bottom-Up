#include <string>
#include <type_traits>
#include <unordered_map>
#include <stdexcept>
#include <vector>
#include <memory>

// Minimal Class representation for testing purposes
class Class {
public:
    std::string name;
    bool isPrimitive;
    bool isWrapper;
    Class* wrapperType;
    Class* primitiveType;

    Class(const std::string& n, bool prim = false, bool wrap = false)
        : name(n), isPrimitive(prim), isWrapper(wrap), wrapperType(nullptr), primitiveType(nullptr) {}

    bool operator==(const Class& other) const { return name == other.name; }
    bool operator!=(const Class& other) const { return !(*this == other); }
};

// TypeUtilities equivalent
class TypeUtilities {
private:
    static std::unordered_map<std::string, Class*> primitiveTypes;
    static std::unordered_map<std::string, Class*> wrapperTypes;
    static std::vector<Class*> allClasses;

public:
    static void initialize() {
        if (!allClasses.empty()) return;

        // Primitive types
        auto* boolean = new Class("boolean", true, false);
        auto* byte = new Class("byte", true, false);
        auto* short = new Class("short", true, false);
        auto* int_ = new Class("int", true, false);
        auto* long_ = new Class("long", true, false);
        auto* char_ = new Class("char", true, false);
        auto* float_ = new Class("float", true, false);
        auto* double_ = new Class("double", true, false);
        auto* void_ = new Class("void", true, false);

        // Wrapper types
        auto* Boolean = new Class("java.lang.Boolean", false, true);
        auto* Byte = new Class("java.lang.Byte", false, true);
        auto* Short = new Class("java.lang.Short", false, true);
        auto* Integer = new Class("java.lang.Integer", false, true);
        auto* Long = new Class("java.lang.Long", false, true);
        auto* Character = new Class("java.lang.Character", false, true);
        auto* Float = new Class("java.lang.Float", false, true);
        auto* Double = new Class("java.lang.Double", false, true);
        auto* Void = new Class("java.lang.Void", false, true);

        // Link primitives to wrappers
        boolean->wrapperType = Boolean;
        byte->wrapperType = Byte;
        short->wrapperType = Short;
        int_->wrapperType = Integer;
        long_->wrapperType = Long;
        char_->wrapperType = Character;
        float_->wrapperType = Float;
        double_->wrapperType = Double;
        void_->wrapperType = Void;

        // Link wrappers to primitives
        Boolean->primitiveType = boolean;
        Byte->primitiveType = byte;
        Short->primitiveType = short;
        Integer->primitiveType = int_;
        Long->primitiveType = long_;
        Character->primitiveType = char_;
        Float->primitiveType = float_;
        Double->primitiveType = double_;
        Void->primitiveType = void_;

        // Store in maps
        primitiveTypes["boolean"] = boolean;
        primitiveTypes["byte"] = byte;
        primitiveTypes["short"] = short;
        primitiveTypes["int"] = int_;
        primitiveTypes["long"] = long_;
        primitiveTypes["char"] = char_;
        primitiveTypes["float"] = float_;
        primitiveTypes["double"] = double_;
        primitiveTypes["void"] = void_;

        wrapperTypes["java.lang.Boolean"] = Boolean;
        wrapperTypes["java.lang.Byte"] = Byte;
        wrapperTypes["java.lang.Short"] = Short;
        wrapperTypes["java.lang.Integer"] = Integer;
        wrapperTypes["java.lang.Long"] = Long;
        wrapperTypes["java.lang.Character"] = Character;
        wrapperTypes["java.lang.Float"] = Float;
        wrapperTypes["java.lang.Double"] = Double;
        wrapperTypes["java.lang.Void"] = Void;

        allClasses = {boolean, byte, short, int_, long_, char_, float_, double_, void_,
                      Boolean, Byte, Short, Integer, Long, Character, Float, Double, Void};
    }

    static bool isWrapperType(Class* c) {
        if (!c) return false;
        return c->isWrapper;
    }

    static Class* getPrimitiveType(Class* c) {
        if (!c) return nullptr;
        return c->primitiveType;
    }

    static bool isSubtype(Class* c0, Class* c1) {
        if (!c0 || !c1) return false;
        if (c0 == c1) return true;

        // Handle primitive/wrapper relationships
        if (c0->isPrimitive && c1->isWrapper) {
            return c0->wrapperType == c1;
        }
        if (c0->isWrapper && c1->isPrimitive) {
            return c0->primitiveType == c1;
        }

        // Simple hierarchy: all classes are subtypes of Object (simplified)
        if (c1->name == "java.lang.Object") return true;

        return false;
    }

    static Class* getWrapperType(Class* c) {
        if (!c) return nullptr;
        return c->wrapperType;
    }

    static bool isConvertibleWithoutLoss(Class* c0, Class* c1) {
        if (!c0 || !c1) return false;
        if (c0 == c1) return true;

        // Handle primitive widening conversions
        static const std::unordered_map<std::string, std::vector<std::string>> widening = {
            {"byte", {"short", "int", "long", "float", "double"}},
            {"short", {"int", "long", "float", "double"}},
            {"char", {"int", "long", "float", "double"}},
            {"int", {"long", "float", "double"}},
            {"long", {"float", "double"}},
            {"float", {"double"}}
        };

        if (c0->isPrimitive && c1->isPrimitive) {
            auto it = widening.find(c0->name);
            if (it != widening.end()) {
                for (const auto& target : it->second) {
                    if (target == c1->name) return true;
                }
            }
            return false;
        }

        // Handle wrapper to primitive and vice versa
        if (c0->isWrapper && c1->isPrimitive) {
            return isConvertibleWithoutLoss(c0->primitiveType, c1);
        }
        if (c0->isPrimitive && c1->isWrapper) {
            return isConvertibleWithoutLoss(c0, c1->primitiveType);
        }

        // Handle wrapper to wrapper
        if (c0->isWrapper && c1->isWrapper) {
            return isConvertibleWithoutLoss(c0->primitiveType, c1->primitiveType);
        }

        return false;
    }

    static bool isMethodInvocationConvertible(Class* c0, Class* c1) {
        if (!c0 || !c1) return false;
        if (c0 == c1) return true;

        // Primitive widening
        if (c0->isPrimitive && c1->isPrimitive) {
            return isConvertibleWithoutLoss(c0, c1);
        }

        // Boxing and unboxing
        if (c0->isPrimitive && c1->isWrapper) {
            return c0->wrapperType == c1;
        }
        if (c0->isWrapper && c1->isPrimitive) {
            return c0->primitiveType == c1;
        }

        // Reference widening (simplified: everything is Object)
        if (c1->name == "java.lang.Object") return true;

        return false;
    }

    static Class* getPrimitiveTypeByName(const std::string& name) {
        auto it = primitiveTypes.find(name);
        if (it != primitiveTypes.end()) {
            return it->second;
        }
        return nullptr;
    }
};

std::unordered_map<std::string, Class*> TypeUtilities::primitiveTypes;
std::unordered_map<std::string, Class*> TypeUtilities::wrapperTypes;
std::vector<Class*> TypeUtilities::allClasses;

// Test functions
void isWrapperType_test_13103(Class* p0) {
    TypeUtilities::initialize();
    TypeUtilities::isWrapperType(p0);
}

void getPrimitiveType_test_13104(Class* p0) {
    TypeUtilities::initialize();
    TypeUtilities::getPrimitiveType(p0);
}

void isSubtype_test_13105(Class* p0, Class* p1) {
    TypeUtilities::initialize();
    TypeUtilities::isSubtype(p0, p1);
}

void getWrapperType_test_13106(Class* p0) {
    TypeUtilities::initialize();
    TypeUtilities::getWrapperType(p0);
}

void isConvertibleWithoutLoss_test_13107(Class* p0, Class* p1) {
    TypeUtilities::initialize();
    TypeUtilities::isConvertibleWithoutLoss(p0, p1);
}

void isMethodInvocationConvertible_test_13108(Class* p0, Class* p1) {
    TypeUtilities::initialize();
    TypeUtilities::isMethodInvocationConvertible(p0, p1);
}

void getPrimitiveTypeByName_test_13109(const std::string& p0) {
    TypeUtilities::initialize();
    TypeUtilities::getPrimitiveTypeByName(p0);
}