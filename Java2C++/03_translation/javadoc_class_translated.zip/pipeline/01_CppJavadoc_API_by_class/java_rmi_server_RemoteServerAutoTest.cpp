#include <cstddef>

class OutputStream {
public:
    virtual ~OutputStream() = default;
};

class RemoteServer {
public:
    static void setLog(OutputStream* log) {
        logStream_ = log;
    }

    static OutputStream* getLog() {
        return logStream_;
    }

private:
    static OutputStream* logStream_;
};

OutputStream* RemoteServer::logStream_ = nullptr;

void setLog_test_10522(OutputStream* p0) {
    RemoteServer::setLog(p0);
}

void getLog_test_10523() {
    RemoteServer::getLog();
}