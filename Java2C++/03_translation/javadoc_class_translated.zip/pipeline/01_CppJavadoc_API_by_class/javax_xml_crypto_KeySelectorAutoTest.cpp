class Key {
public:
    virtual ~Key() = default;
};

class KeySelector {
public:
    virtual ~KeySelector() = default;

    static KeySelector* singletonKeySelector(Key* key) {
        return new KeySelector(key);
    }

private:
    Key* key_;

    explicit KeySelector(Key* key) : key_(key) {}
};

void singletonKeySelector_test_7631(Key* p0) {
    KeySelector::singletonKeySelector(p0);
}