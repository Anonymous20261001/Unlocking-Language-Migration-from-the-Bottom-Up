#include <string>

namespace java {
namespace net {

class URI {
public:
    URI() : original_(), scheme_(), rest_() {}
    explicit URI(const std::string& uri) : original_(uri) {
        std::string::size_type colon = uri.find(':');
        if (colon != std::string::npos) {
            scheme_ = uri.substr(0, colon);
            rest_ = uri.substr(colon + 1);
        } else {
            rest_ = uri;
        }
    }

    const std::string& toString() const { return original_; }
    const std::string& getScheme() const { return scheme_; }
    const std::string& getSchemeSpecificPart() const { return rest_; }

private:
    std::string original_;
    std::string scheme_;
    std::string rest_;
};

} // namespace net

namespace nio {
namespace file {

class FileSystem {
public:
    FileSystem() : provider_("default") {}
    explicit FileSystem(const std::string& provider) : provider_(provider) {}

    const std::string& provider() const { return provider_; }
    bool isDefault() const { return provider_ == "default"; }

private:
    std::string provider_;
};

class FileSystems {
public:
    static FileSystem getDefault() {
        return FileSystem("default");
    }

    static FileSystem getFileSystem(const java::net::URI& uri) {
        if (uri.getScheme().empty() || uri.getScheme() == "file") {
            return getDefault();
        }
        return FileSystem(uri.getScheme());
    }
};

} // namespace file
} // namespace nio
} // namespace java

void getDefault_test_4779() {
    java::nio::file::FileSystems::getDefault();
}

void getFileSystem_test_4780(java::net::URI p0) {
    java::nio::file::FileSystems::getFileSystem(p0);
}