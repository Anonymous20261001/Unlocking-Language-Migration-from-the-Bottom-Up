#include <cstddef>

class SystemTray {
public:
    static SystemTray& getSystemTray() {
        static SystemTray instance;
        return instance;
    }

    static bool isSupported() {
        return true;
    }

private:
    SystemTray() = default;
    SystemTray(const SystemTray&) = delete;
    SystemTray& operator=(const SystemTray&) = delete;
};

void getSystemTray_test_12443() {
    SystemTray::getSystemTray();
}

void isSupported_test_12444() {
    SystemTray::isSupported();
}