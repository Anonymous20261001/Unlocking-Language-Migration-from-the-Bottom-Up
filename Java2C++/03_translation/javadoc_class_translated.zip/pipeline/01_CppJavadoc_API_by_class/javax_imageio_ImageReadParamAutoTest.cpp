#include <vector>
#include <memory>
#include <limits>

class Dimension {
public:
    int width;
    int height;

    Dimension() : width(0), height(0) {}
    Dimension(int w, int h) : width(w), height(h) {}
};

class BufferedImage {
public:
    BufferedImage() {}
};

class ImageTypeSpecifier {
public:
    ImageTypeSpecifier() {}
};

class ImageReadParam {
public:
    ImageReadParam()
        : sourceMinProgressivePass(0),
          sourceMaxProgressivePass(std::numeric_limits<int>::max()),
          sourceNumProgressivePasses(std::numeric_limits<int>::max()) {}

    std::vector<int> getDestinationBands() const {
        return destinationBands;
    }

    BufferedImage* getDestination() const {
        return destination.get();
    }

    void setDestination(std::shared_ptr<BufferedImage> p0) {
        destination = p0;
    }

    bool canSetSourceRenderSize() {
        return true;
    }

    void setDestinationBands(const std::vector<int>& p0) {
        destinationBands = p0;
    }

    void setSourceRenderSize(std::shared_ptr<Dimension> p0) {
        sourceRenderSize = p0;
    }

    std::shared_ptr<Dimension> getSourceRenderSize() const {
        return sourceRenderSize;
    }

    void setSourceProgressivePasses(int p0, int p1) {
        sourceMinProgressivePass = p0;
        sourceNumProgressivePasses = p1;
        if (p1 == std::numeric_limits<int>::max()) {
            sourceMaxProgressivePass = std::numeric_limits<int>::max();
        } else {
            sourceMaxProgressivePass = p0 + p1 - 1;
        }
    }

    int getSourceMinProgressivePass() const {
        return sourceMinProgressivePass;
    }

    int getSourceMaxProgressivePass() const {
        return sourceMaxProgressivePass;
    }

    int getSourceNumProgressivePasses() const {
        return sourceNumProgressivePasses;
    }

    void setDestinationType(std::shared_ptr<ImageTypeSpecifier> p0) {
        destinationType = p0;
    }

private:
    std::vector<int> destinationBands;
    std::shared_ptr<BufferedImage> destination;
    std::shared_ptr<Dimension> sourceRenderSize;
    int sourceMinProgressivePass;
    int sourceMaxProgressivePass;
    int sourceNumProgressivePasses;
    std::shared_ptr<ImageTypeSpecifier> destinationType;
};

void getDestinationBands_test_5680() {
    ImageReadParam instance;
    instance.getDestinationBands();
}

void getDestination_test_5681() {
    ImageReadParam instance;
    instance.getDestination();
}

void setDestination_test_5682() {
    ImageReadParam instance;
    std::shared_ptr<BufferedImage> p0 = std::make_shared<BufferedImage>();
    instance.setDestination(p0);
}

void canSetSourceRenderSize_test_5683() {
    ImageReadParam instance;
    instance.canSetSourceRenderSize();
}

void setDestinationBands_test_5684() {
    ImageReadParam instance;
    std::vector<int> p0;
    instance.setDestinationBands(p0);
}

void setSourceRenderSize_test_5685() {
    ImageReadParam instance;
    std::shared_ptr<Dimension> p0 = std::make_shared<Dimension>();
    instance.setSourceRenderSize(p0);
}

void getSourceRenderSize_test_5686() {
    ImageReadParam instance;
    instance.getSourceRenderSize();
}

void setSourceProgressivePasses_test_5687() {
    ImageReadParam instance;
    int p0 = 0;
    int p1 = 0;
    instance.setSourceProgressivePasses(p0, p1);
}

void getSourceMinProgressivePass_test_5688() {
    ImageReadParam instance;
    instance.getSourceMinProgressivePass();
}

void getSourceMaxProgressivePass_test_5689() {
    ImageReadParam instance;
    instance.getSourceMaxProgressivePass();
}

void getSourceNumProgressivePasses_test_5690() {
    ImageReadParam instance;
    instance.getSourceNumProgressivePasses();
}

void setDestinationType_test_5691() {
    ImageReadParam instance;
    std::shared_ptr<ImageTypeSpecifier> p0 = std::make_shared<ImageTypeSpecifier>();
    instance.setDestinationType(p0);
}