#include <string>
#include <memory>

class ClassLoader {
public:
    ClassLoader() = default;
};

class String {
public:
    String() = default;
    String(const std::string& s) : value(s) {}
private:
    std::string value;
};

class TransformerFactory {
public:
    static std::unique_ptr<TransformerFactory> newDefaultInstance() {
        return std::make_unique<TransformerFactory>();
    }

    static std::unique_ptr<TransformerFactory> newInstance(String p0, ClassLoader p1) {
        (void)p0;
        (void)p1;
        return std::make_unique<TransformerFactory>();
    }

    static std::unique_ptr<TransformerFactory> newInstance() {
        return std::make_unique<TransformerFactory>();
    }
};

void newDefaultInstance_test_12971() {
    TransformerFactory::newDefaultInstance();
}

void newInstance_test_12972(String p0, ClassLoader p1) {
    TransformerFactory::newInstance(p0, p1);
}

void newInstance_test_12973() {
    TransformerFactory::newInstance();
}