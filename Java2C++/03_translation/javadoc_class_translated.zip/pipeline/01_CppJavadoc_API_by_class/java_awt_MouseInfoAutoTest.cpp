#include <cstddef>

class PointerInfo {
public:
    PointerInfo() = default;
};

class MouseInfo {
public:
    static int getNumberOfButtons();
    static PointerInfo getPointerInfo();
};

int MouseInfo::getNumberOfButtons() {
    return 3;
}

PointerInfo MouseInfo::getPointerInfo() {
    return PointerInfo();
}

void getNumberOfButtons_test_9025() {
    MouseInfo::getNumberOfButtons();
}

void getPointerInfo_test_9026() {
    MouseInfo::getPointerInfo();
}