#include <cstdint>
#include <vector>

class DrbgParameters {
public:
    enum class Capability {
        RESEED_ONLY,
        PR_AND_RESEED
    };

    class Reseed {
    private:
        Reseed(bool predictionResistance, const std::vector<uint8_t>& additionalInput)
            : predictionResistance(predictionResistance), additionalInput(additionalInput) {}

        bool predictionResistance;
        std::vector<uint8_t> additionalInput;

        friend class DrbgParameters;

    public:
        bool getPredictionResistance() const { return predictionResistance; }
        const std::vector<uint8_t>& getAdditionalInput() const { return additionalInput; }
    };

    class Instantiation {
    private:
        Instantiation(int strength, Capability capability, const std::vector<uint8_t>& additionalInput)
            : strength(strength), capability(capability), additionalInput(additionalInput) {}

        int strength;
        Capability capability;
        std::vector<uint8_t> additionalInput;

        friend class DrbgParameters;

    public:
        int getStrength() const { return strength; }
        Capability getCapability() const { return capability; }
        const std::vector<uint8_t>& getAdditionalInput() const { return additionalInput; }
    };

    class NextBytes {
    private:
        NextBytes(int strength, bool predictionResistance, const std::vector<uint8_t>& additionalInput)
            : strength(strength), predictionResistance(predictionResistance), additionalInput(additionalInput) {}

        int strength;
        bool predictionResistance;
        std::vector<uint8_t> additionalInput;

        friend class DrbgParameters;

    public:
        int getStrength() const { return strength; }
        bool getPredictionResistance() const { return predictionResistance; }
        const std::vector<uint8_t>& getAdditionalInput() const { return additionalInput; }
    };

    static Reseed reseed(bool predictionResistance, const std::vector<uint8_t>& additionalInput) {
        return Reseed(predictionResistance, additionalInput);
    }

    static Instantiation instantiation(int strength, Capability capability, const std::vector<uint8_t>& additionalInput) {
        return Instantiation(strength, capability, additionalInput);
    }

    static NextBytes nextBytes(int strength, bool predictionResistance, const std::vector<uint8_t>& additionalInput) {
        return NextBytes(strength, predictionResistance, additionalInput);
    }

private:
    DrbgParameters() = delete;
};

void reseed_test_4339(bool p0, const std::vector<uint8_t>& p1) {
    DrbgParameters::reseed(p0, p1);
}

void instantiation_test_4340(int p0, DrbgParameters::Capability p1, const std::vector<uint8_t>& p2) {
    DrbgParameters::instantiation(p0, p1, p2);
}

void nextBytes_test_4341(int p0, bool p1, const std::vector<uint8_t>& p2) {
    DrbgParameters::nextBytes(p0, p1, p2);
}
