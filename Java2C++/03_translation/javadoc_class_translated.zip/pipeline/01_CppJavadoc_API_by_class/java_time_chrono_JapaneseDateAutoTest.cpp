class JapaneseEra {
public:
    JapaneseEra() = default;
};

class TemporalAccessor {
public:
    TemporalAccessor() = default;
};

class ZoneId {
public:
    ZoneId() = default;
};

class Clock {
public:
    Clock() = default;
};

class JapaneseDate {
public:
    JapaneseDate() = default;

    static JapaneseDate of(int, int, int) {
        return JapaneseDate();
    }

    static JapaneseDate of(JapaneseEra, int, int, int) {
        return JapaneseDate();
    }

    static JapaneseDate from(const TemporalAccessor&) {
        return JapaneseDate();
    }

    static JapaneseDate now() {
        return JapaneseDate();
    }

    static JapaneseDate now(const ZoneId&) {
        return JapaneseDate();
    }

    static JapaneseDate now(const Clock&) {
        return JapaneseDate();
    }
};

void of_test_5968(int p0, int p1, int p2) {
    JapaneseDate::of(p0, p1, p2);
}

void of_test_5969(JapaneseEra p0, int p1, int p2, int p3) {
    JapaneseDate::of(p0, p1, p2, p3);
}

void from_test_5970(TemporalAccessor p0) {
    JapaneseDate::from(p0);
}

void now_test_5971() {
    JapaneseDate::now();
}

void now_test_5972(ZoneId p0) {
    JapaneseDate::now(p0);
}

void now_test_5973(Clock p0) {
    JapaneseDate::now(p0);
}
