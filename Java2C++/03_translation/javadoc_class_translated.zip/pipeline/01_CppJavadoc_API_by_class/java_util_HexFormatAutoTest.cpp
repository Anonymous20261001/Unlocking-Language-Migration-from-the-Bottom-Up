#include <string_view>
#include <string>
#include <stdexcept>
#include <cstdint>
#include <cstddef>

using CharSequence = std::string_view;

class HexFormat {
public:
    static HexFormat of() {
        return HexFormat();
    }

    static HexFormat ofDelimiter(const std::string& delimiter) {
        return HexFormat(delimiter);
    }

    static bool isHexDigit(int ch) {
        return (ch >= '0' && ch <= '9') ||
               (ch >= 'a' && ch <= 'f') ||
               (ch >= 'A' && ch <= 'F');
    }

    static int fromHexDigit(int ch) {
        if (ch >= '0' && ch <= '9') return ch - '0';
        if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
        if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
        throw std::invalid_argument("Not a hexadecimal digit");
    }

    static int fromHexDigits(CharSequence s) {
        return fromHexDigits(s, 0, static_cast<int>(s.size()));
    }

    static int fromHexDigits(CharSequence s, int fromIndex, int toIndex) {
        validateRange(s.size(), fromIndex, toIndex);
        int length = toIndex - fromIndex;
        if (length <= 0) throw std::invalid_argument("No hexadecimal digits");
        if (length > 8) throw std::invalid_argument("Too many hexadecimal digits");

        uint32_t result = 0;
        for (int i = fromIndex; i < toIndex; ++i) {
            result = (result << 4) | static_cast<uint32_t>(fromHexDigit(static_cast<unsigned char>(s[i])));
        }
        return static_cast<int32_t>(result);
    }

    static int64_t fromHexDigitsToLong(CharSequence s) {
        return fromHexDigitsToLong(s, 0, static_cast<int>(s.size()));
    }

    static int64_t fromHexDigitsToLong(CharSequence s, int fromIndex, int toIndex) {
        validateRange(s.size(), fromIndex, toIndex);
        int length = toIndex - fromIndex;
        if (length <= 0) throw std::invalid_argument("No hexadecimal digits");
        if (length > 16) throw std::invalid_argument("Too many hexadecimal digits");

        uint64_t result = 0;
        for (int i = fromIndex; i < toIndex; ++i) {
            result = (result << 4) | static_cast<uint64_t>(fromHexDigit(static_cast<unsigned char>(s[i])));
        }
        return static_cast<int64_t>(result);
    }

private:
    std::string delimiter_;

    HexFormat() = default;

    explicit HexFormat(const std::string& delimiter) : delimiter_(delimiter) {}

    static void validateRange(std::size_t size, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < fromIndex || static_cast<std::size_t>(toIndex) > size) {
            throw std::invalid_argument("Invalid index range");
        }
    }
};

void of_test_5337() {
    HexFormat::of();
}

void fromHexDigits_test_5338(CharSequence p0) {
    HexFormat::fromHexDigits(p0);
}

void fromHexDigits_test_5339(CharSequence p0, int p1, int p2) {
    HexFormat::fromHexDigits(p0, p1, p2);
}

void fromHexDigit_test_5340(int p0) {
    HexFormat::fromHexDigit(p0);
}

void fromHexDigitsToLong_test_5341(CharSequence p0, int p1, int p2) {
    HexFormat::fromHexDigitsToLong(p0, p1, p2);
}

void fromHexDigitsToLong_test_5342(CharSequence p0) {
    HexFormat::fromHexDigitsToLong(p0);
}

void ofDelimiter_test_5343(const std::string& p0) {
    HexFormat::ofDelimiter(p0);
}

void isHexDigit_test_5344(int p0) {
    HexFormat::isHexDigit(p0);
}