#include <algorithm>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

class FlightRecorderListener {
public:
    virtual ~FlightRecorderListener() = default;
};

class Runnable {
public:
    virtual ~Runnable() = default;
    virtual void run() = 0;
};

class Class {
public:
    explicit Class(std::string name) : name_(std::move(name)) {}

    const std::string& name() const {
        return name_;
    }

private:
    std::string name_;
};

class FlightRecorder {
public:
    static bool isAvailable() {
        return available_;
    }

    static FlightRecorder& getFlightRecorder() {
        if (!available_) {
            throw std::runtime_error("FlightRecorder is not available");
        }
        initialized_ = true;
        return instance_;
    }

    static void addListener(FlightRecorderListener& listener) {
        FlightRecorderListener* ptr = &listener;
        if (std::find(listeners_.begin(), listeners_.end(), ptr) == listeners_.end()) {
            listeners_.push_back(ptr);
        }
    }

    static void removeListener(FlightRecorderListener& listener) {
        FlightRecorderListener* ptr = &listener;
        listeners_.erase(std::remove(listeners_.begin(), listeners_.end(), ptr), listeners_.end());
    }

    static void addPeriodicEvent(const Class&, Runnable& hook) {
        periodicHooks_.push_back(&hook);
    }

    static void removePeriodicEvent(Runnable& hook) {
        Runnable* ptr = &hook;
        periodicHooks_.erase(std::remove(periodicHooks_.begin(), periodicHooks_.end(), ptr), periodicHooks_.end());
    }

    static void _register(const Class& eventClass) {
        registeredClasses_.push_back(eventClass);
    }

    static void unregister(const Class& eventClass) {
        registeredClasses_.erase(
            std::remove_if(registeredClasses_.begin(), registeredClasses_.end(),
                           [&](const Class& c) { return c.name() == eventClass.name(); }),
            registeredClasses_.end());
    }

    static bool isInitialized() {
        return initialized_;
    }

private:
    FlightRecorder() = default;

    FlightRecorder(const FlightRecorder&) = delete;
    FlightRecorder& operator=(const FlightRecorder&) = delete;

    static bool available_;
    static bool initialized_;
    static FlightRecorder instance_;
    static std::vector<FlightRecorderListener*> listeners_;
    static std::vector<Runnable*> periodicHooks_;
    static std::vector<Class> registeredClasses_;
};

bool FlightRecorder::available_ = true;
bool FlightRecorder::initialized_ = false;
FlightRecorder FlightRecorder::instance_;
std::vector<FlightRecorderListener*> FlightRecorder::listeners_;
std::vector<Runnable*> FlightRecorder::periodicHooks_;
std::vector<Class> FlightRecorder::registeredClasses_;

class TestFlightRecorderListener : public FlightRecorderListener {};

class TestRunnable : public Runnable {
public:
    void run() override {}
};

void addListener_test_4816() {
    TestFlightRecorderListener listener;
    FlightRecorder::addListener(listener);
}

void removeListener_test_4817() {
    TestFlightRecorderListener listener;
    FlightRecorder::removeListener(listener);
}

void isAvailable_test_4818() {
    FlightRecorder::isAvailable();
}

void getFlightRecorder_test_4819() {
    FlightRecorder::getFlightRecorder();
}

void addPeriodicEvent_test_4820() {
    Class eventClass("TestEvent");
    TestRunnable runnable;
    FlightRecorder::addPeriodicEvent(eventClass, runnable);
}

void removePeriodicEvent_test_4821() {
    TestRunnable runnable;
    FlightRecorder::removePeriodicEvent(runnable);
}

void register_test_4822() {
    Class eventClass("TestEvent");
    FlightRecorder::_register(eventClass);
}

void unregister_test_4823() {
    Class eventClass("TestEvent");
    FlightRecorder::unregister(eventClass);
}

void isInitialized_test_4824() {
    FlightRecorder::isInitialized();
}