#include <string>

class ClassLoader {};

class DocumentBuilderFactory {
public:
    DocumentBuilderFactory() = default;

    static DocumentBuilderFactory newDefaultInstance() {
        return DocumentBuilderFactory();
    }

    static DocumentBuilderFactory newDefaultNSInstance() {
        return DocumentBuilderFactory();
    }

    static DocumentBuilderFactory newNSInstance() {
        return DocumentBuilderFactory();
    }

    static DocumentBuilderFactory newNSInstance(const std::string& factoryId, const ClassLoader* classLoader) {
        (void)factoryId;
        (void)classLoader;
        return DocumentBuilderFactory();
    }

    static DocumentBuilderFactory newInstance(const std::string& factoryId, const ClassLoader* classLoader) {
        (void)factoryId;
        (void)classLoader;
        return DocumentBuilderFactory();
    }

    static DocumentBuilderFactory newInstance() {
        return DocumentBuilderFactory();
    }
};

void newDefaultInstance_test_4194() {
    DocumentBuilderFactory::newDefaultInstance();
}

void newDefaultNSInstance_test_4195() {
    DocumentBuilderFactory::newDefaultNSInstance();
}

void newNSInstance_test_4196() {
    DocumentBuilderFactory::newNSInstance();
}

void newNSInstance_test_4197(const std::string& p0, const ClassLoader* p1) {
    DocumentBuilderFactory::newNSInstance(p0, p1);
}

void newInstance_test_4198(const std::string& p0, const ClassLoader* p1) {
    DocumentBuilderFactory::newInstance(p0, p1);
}

void newInstance_test_4199() {
    DocumentBuilderFactory::newInstance();
}