#include <string>
#include <vector>
#include <cstdint>
#include <cctype>
#include <algorithm>
#include <climits>

class IDN {
public:
    static const int ALLOW_UNASSIGNED = 0x01;
    static const int USE_STD3_ASCII_RULES = 0x02;

    static std::string toASCII(const std::string& input) {
        return toASCII(input, 0);
    }

    static std::string toASCII(const std::string& input, int flags) {
        std::vector<std::string> labels = split(input, '.');
        std::vector<std::string> result;
        result.reserve(labels.size());
        for (const std::string& label : labels) {
            if (label.empty()) {
                result.push_back("");
                continue;
            }
            std::vector<uint32_t> cps = utf8_decode(label);
            bool basic = true;
            for (uint32_t cp : cps) {
                if (cp >= 0x80) {
                    basic = false;
                    break;
                }
            }
            if (basic) {
                std::string lowered;
                lowered.reserve(label.size());
                for (unsigned char c : label) {
                    lowered.push_back(static_cast<char>(std::tolower(c)));
                }
                result.push_back(lowered);
            } else {
                std::vector<uint32_t> lowered = cps;
                for (uint32_t& cp : lowered) {
                    if (cp >= 'A' && cp <= 'Z') {
                        cp += 32;
                    }
                }
                result.push_back("xn--" + punycode_encode(lowered));
            }
        }
        return join(result, ".");
    }

    static std::string toUnicode(const std::string& input) {
        return toUnicode(input, 0);
    }

    static std::string toUnicode(const std::string& input, int flags) {
        std::vector<std::string> labels = split(input, '.');
        std::vector<std::string> result;
        result.reserve(labels.size());
        for (const std::string& label : labels) {
            if (label.size() >= 4 &&
                (label.compare(0, 4, "xn--") == 0 || label.compare(0, 4, "XN--") == 0)) {
                std::string ace = label.substr(4);
                std::vector<uint32_t> cps = punycode_decode(ace);
                result.push_back(utf8_encode(cps));
            } else {
                result.push_back(label);
            }
        }
        return join(result, ".");
    }

private:
    static uint32_t adapt(uint32_t delta, uint32_t numpoints, bool firsttime) {
        const uint32_t base = 36;
        const uint32_t tmin = 1;
        const uint32_t tmax = 26;
        const uint32_t skew = 38;
        const uint32_t damp = 700;

        if (firsttime) {
            delta = delta / damp;
        } else {
            delta = delta / 2;
        }
        delta = delta + delta / numpoints;
        uint32_t k = 0;
        while (delta > ((base - tmin) * tmax) / 2) {
            delta = delta / (base - tmin);
            k += base;
        }
        return k + (((base - tmin + 1) * delta) / (delta + skew));
    }

    static std::string punycode_encode(const std::vector<uint32_t>& input) {
        const uint32_t base = 36;
        const uint32_t tmin = 1;
        const uint32_t tmax = 26;
        const uint32_t skew = 38;
        const uint32_t damp = 700;
        const uint32_t initial_bias = 72;
        const uint32_t initial_n = 128;

        std::string output;
        size_t b = 0;
        for (uint32_t cp : input) {
            if (cp < 0x80) {
                output.push_back(static_cast<char>(cp));
                ++b;
            }
        }
        uint32_t h = static_cast<uint32_t>(b);
        if (b > 0 && b < input.size()) {
            output.push_back('-');
        }

        uint32_t n = initial_n;
        uint32_t delta = 0;
        uint32_t bias = initial_bias;

        while (h < input.size()) {
            uint32_t m = UINT32_MAX;
            for (uint32_t cp : input) {
                if (cp >= n && cp < m) {
                    m = cp;
                }
            }
            delta += (m - n) * (h + 1);
            n = m;

            for (uint32_t cp : input) {
                if (cp < n) {
                    ++delta;
                }
                if (cp == n) {
                    uint32_t q = delta;
                    for (uint32_t k = base; ; k += base) {
                        uint32_t t = (k <= bias) ? tmin :
                                     (k >= bias + tmax) ? tmax : k - bias;
                        if (q < t) {
                            break;
                        }
                        uint32_t digit = t + (q - t) % (base - t);
                        output.push_back(digit < 26 ? static_cast<char>('a' + digit)
                                                    : static_cast<char>('0' + digit - 26));
                        q = (q - t) / (base - t);
                    }
                    output.push_back(q < 26 ? static_cast<char>('a' + q)
                                            : static_cast<char>('0' + q - 26));
                    bias = adapt(delta, h + 1, h == b);
                    delta = 0;
                    ++h;
                }
            }
        }
        return output;
    }

    static int digit_value(char c) {
        if (c >= 'a' && c <= 'z') return c - 'a';
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= '0' && c <= '9') return c - '0' + 26;
        return -1;
    }

    static std::vector<uint32_t> punycode_decode(const std::string& input) {
        const uint32_t base = 36;
        const uint32_t tmin = 1;
        const uint32_t tmax = 26;
        const uint32_t skew = 38;
        const uint32_t damp = 700;
        const uint32_t initial_bias = 72;
        const uint32_t initial_n = 128;

        std::vector<uint32_t> output;
        size_t last_delim = input.rfind('-');
        size_t b = (last_delim == std::string::npos) ? 0 : last_delim;
        for (size_t i = 0; i < b; ++i) {
            unsigned char c = static_cast<unsigned char>(input[i]);
            if (c < 0x80) {
                output.push_back(c);
            }
        }

        size_t idx = (last_delim == std::string::npos) ? 0 : last_delim + 1;
        uint32_t n = initial_n;
        uint32_t i = 0;
        uint32_t bias = initial_bias;

        while (idx < input.size()) {
            uint32_t oldi = i;
            uint32_t w = 1;
            for (uint32_t k = base; ; k += base) {
                if (idx >= input.size()) {
                    break;
                }
                int c = digit_value(input[idx++]);
                if (c < 0 || c >= static_cast<int>(base)) {
                    break;
                }
                i += static_cast<uint32_t>(c) * w;
                uint32_t t = (k <= bias) ? tmin :
                             (k >= bias + tmax) ? tmax : k - bias;
                if (static_cast<uint32_t>(c) < t) {
                    break;
                }
                w *= (base - t);
            }
            bias = adapt(i - oldi, static_cast<uint32_t>(output.size() + 1), oldi == 0);
            n += i / static_cast<uint32_t>(output.size() + 1);
            i %= static_cast<uint32_t>(output.size() + 1);
            output.insert(output.begin() + i, n);
            ++i;
        }

        return output;
    }

    static std::vector<uint32_t> utf8_decode(const std::string& s) {
        std::vector<uint32_t> out;
        size_t i = 0;
        while (i < s.size()) {
            unsigned char c = static_cast<unsigned char>(s[i++]);
            uint32_t cp;
            int extra;
            if (c < 0x80) {
                cp = c;
                extra = 0;
            } else if ((c & 0xE0) == 0xC0) {
                cp = c & 0x1F;
                extra = 1;
            } else if ((c & 0xF0) == 0xE0) {
                cp = c & 0x0F;
                extra = 2;
            } else if ((c & 0xF8) == 0xF0) {
                cp = c & 0x07;
                extra = 3;
            } else {
                cp = 0xFFFD;
                extra = 0;
            }
            for (int j = 0; j < extra; ++j) {
                if (i < s.size()) {
                    unsigned char cc = static_cast<unsigned char>(s[i++]);
                    if ((cc & 0xC0) == 0x80) {
                        cp = (cp << 6) | (cc & 0x3F);
                    } else {
                        cp = 0xFFFD;
                        break;
                    }
                } else {
                    cp = 0xFFFD;
                    break;
                }
            }
            out.push_back(cp);
        }
        return out;
    }

    static std::string utf8_encode(const std::vector<uint32_t>& cps) {
        std::string out;
        for (uint32_t cp : cps) {
            if (cp < 0x80) {
                out.push_back(static_cast<char>(cp));
            } else if (cp < 0x800) {
                out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
                out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
            } else if (cp < 0x10000) {
                out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
                out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
                out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
            } else if (cp < 0x110000) {
                out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
                out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
                out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
                out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
            }
        }
        return out;
    }

    static std::vector<std::string> split(const std::string& s, char delim) {
        std::vector<std::string> tokens;
        std::string token;
        for (char c : s) {
            if (c == delim) {
                tokens.push_back(token);
                token.clear();
            } else {
                token.push_back(c);
            }
        }
        tokens.push_back(token);
        return tokens;
    }

    static std::string join(const std::vector<std::string>& v, const std::string& sep) {
        std::string result;
        for (size_t i = 0; i < v.size(); ++i) {
            if (i) {
                result += sep;
            }
            result += v[i];
        }
        return result;
    }
};

void toASCII_test_5533(const std::string& p0, int p1) {
    IDN::toASCII(p0, p1);
}

void toASCII_test_5534(const std::string& p0) {
    IDN::toASCII(p0);
}

void toUnicode_test_5535(const std::string& p0) {
    IDN::toUnicode(p0);
}

void toUnicode_test_5536(const std::string& p0, int p1) {
    IDN::toUnicode(p0, p1);
}
