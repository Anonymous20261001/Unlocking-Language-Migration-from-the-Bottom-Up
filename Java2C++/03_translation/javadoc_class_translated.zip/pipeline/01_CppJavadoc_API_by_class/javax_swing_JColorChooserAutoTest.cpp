#include <string>
#include <vector>

class Component {
public:
    virtual ~Component() = default;
};

class JComponent : public Component {
public:
    virtual ~JComponent() = default;
};

class Color {
public:
    int r;
    int g;
    int b;

    Color() : r(255), g(255), b(255) {}
    Color(int r, int g, int b) : r(r), g(g), b(b) {}
    Color(int rgb) : r((rgb >> 16) & 0xFF), g((rgb >> 8) & 0xFF), b(rgb & 0xFF) {}
};

class ActionListener {
public:
    virtual ~ActionListener() = default;
};

class ColorSelectionModel {
public:
    virtual ~ColorSelectionModel() = default;
};

class AbstractColorChooserPanel : public JComponent {
public:
    virtual ~AbstractColorChooserPanel() = default;
};

class ColorChooserUI {
public:
    virtual ~ColorChooserUI() = default;
};

class JColorChooser : public JComponent {
public:
    JColorChooser()
        : color(255, 255, 255),
          selectionModel(nullptr),
          dragEnabled(false),
          previewPanel(nullptr),
          ui(nullptr) {}

    std::string getUIClassID() {
        return "ColorChooserUI";
    }

    void updateUI() {}

    ColorChooserUI* getUI() const {
        return ui;
    }

    void setUI(ColorChooserUI* newUI) {
        ui = newUI;
    }

    void* getAccessibleContext() {
        return nullptr;
    }

    Color getColor() const {
        return color;
    }

    ColorSelectionModel* getSelectionModel() const {
        return selectionModel;
    }

    static Color showDialog(Component* /*parent*/, const std::string& /*title*/, Color /*initial*/) {
        return Color();
    }

    static Color showDialog(Component* /*parent*/, const std::string& /*title*/, Color /*initial*/, bool /*transparent*/) {
        return Color();
    }

    std::vector<AbstractColorChooserPanel*> getChooserPanels() const {
        return chooserPanels;
    }

    static void* createDialog(Component* /*parent*/, const std::string& /*title*/, bool /*modal*/, JColorChooser* /*chooser*/, ActionListener* /*okListener*/, ActionListener* /*cancelListener*/) {
        return nullptr;
    }

    JComponent* getPreviewPanel() const {
        return previewPanel;
    }

    void setChooserPanels(AbstractColorChooserPanel** panels) {
        chooserPanels.clear();
        if (panels) {
            for (int i = 0; panels[i] != nullptr; ++i) {
                chooserPanels.push_back(panels[i]);
            }
        }
    }

    void setDragEnabled(bool enabled) {
        dragEnabled = enabled;
    }

    bool getDragEnabled() const {
        return dragEnabled;
    }

    void setPreviewPanel(JComponent* panel) {
        previewPanel = panel;
    }

    void addChooserPanel(AbstractColorChooserPanel* panel) {
        if (panel) {
            chooserPanels.push_back(panel);
        }
    }

    void removeChooserPanel(AbstractColorChooserPanel* panel) {
        for (auto it = chooserPanels.begin(); it != chooserPanels.end(); ++it) {
            if (*it == panel) {
                chooserPanels.erase(it);
                break;
            }
        }
    }

    void setSelectionModel(ColorSelectionModel* model) {
        selectionModel = model;
    }

    void setColor(int r, int g, int b) {
        color = Color(r, g, b);
    }

    void setColor(int rgb) {
        color = Color(rgb);
    }

    void setColor(Color c) {
        color = c;
    }

private:
    Color color;
    ColorSelectionModel* selectionModel;
    bool dragEnabled;
    JComponent* previewPanel;
    ColorChooserUI* ui;
    std::vector<AbstractColorChooserPanel*> chooserPanels;
};

void getUIClassID_test_6023() {
    JColorChooser instance;
    instance.getUIClassID();
}

void updateUI_test_6024() {
    JColorChooser instance;
    instance.updateUI();
}

void getUI_test_6025() {
    JColorChooser instance;
    instance.getUI();
}

void setUI_test_6026(ColorChooserUI* p0) {
    JColorChooser instance;
    instance.setUI(p0);
}

void getAccessibleContext_test_6027() {
    JColorChooser instance;
    instance.getAccessibleContext();
}

void getColor_test_6028() {
    JColorChooser instance;
    instance.getColor();
}

void getSelectionModel_test_6029() {
    JColorChooser instance;
    instance.getSelectionModel();
}

void showDialog_test_6030(Component* p0, const std::string& p1, Color p2) {
    JColorChooser::showDialog(p0, p1, p2);
}

void showDialog_test_6031(Component* p0, const std::string& p1, Color p2, bool p3) {
    JColorChooser::showDialog(p0, p1, p2, p3);
}

void getChooserPanels_test_6032() {
    JColorChooser instance;
    instance.getChooserPanels();
}

void createDialog_test_6033(Component* p0, const std::string& p1, bool p2, JColorChooser* p3, ActionListener* p4, ActionListener* p5) {
    JColorChooser::createDialog(p0, p1, p2, p3, p4, p5);
}

void getPreviewPanel_test_6034() {
    JColorChooser instance;
    instance.getPreviewPanel();
}

void setChooserPanels_test_6035(AbstractColorChooserPanel** p0) {
    JColorChooser instance;
    instance.setChooserPanels(p0);
}

void setDragEnabled_test_6036(bool p0) {
    JColorChooser instance;
    instance.setDragEnabled(p0);
}

void getDragEnabled_test_6037() {
    JColor