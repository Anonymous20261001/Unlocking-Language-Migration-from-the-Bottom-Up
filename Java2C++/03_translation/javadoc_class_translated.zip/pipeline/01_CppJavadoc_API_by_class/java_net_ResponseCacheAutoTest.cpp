class ResponseCache {
public:
    virtual ~ResponseCache() = default;

    static ResponseCache* getDefault() {
        return defaultCache;
    }

    static void setDefault(ResponseCache* cache) {
        defaultCache = cache;
    }

private:
    static ResponseCache* defaultCache;
};

ResponseCache* ResponseCache::defaultCache = nullptr;

void getDefault_test_10628() {
    ResponseCache::getDefault();
}

void setDefault_test_10629(ResponseCache* p0) {
    ResponseCache::setDefault(p0);
}