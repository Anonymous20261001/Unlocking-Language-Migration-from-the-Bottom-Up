class GeoTIFFTagSet {
public:
    static GeoTIFFTagSet& getInstance() {
        static GeoTIFFTagSet instance;
        return instance;
    }
private:
    GeoTIFFTagSet() = default;
    GeoTIFFTagSet(const GeoTIFFTagSet&) = delete;
    GeoTIFFTagSet& operator=(const GeoTIFFTagSet&) = delete;
};

void getInstance_test_5102() {
    GeoTIFFTagSet::getInstance();
}