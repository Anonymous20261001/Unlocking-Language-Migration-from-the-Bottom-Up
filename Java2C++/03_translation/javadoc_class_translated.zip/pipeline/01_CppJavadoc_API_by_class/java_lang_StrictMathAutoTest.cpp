#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <stdexcept>
#include <type_traits>

namespace java {
namespace lang {

class StrictMath {
public:
    // abs methods
    static float abs(float a) { return std::fabs(a); }
    static long abs(long a) { return std::llabs(a); }
    static int abs(int a) { return std::abs(a); }
    static double abs(double a) { return std::fabs(a); }

    // trigonometric
    static double sin(double a) { return std::sin(a); }
    static double cos(double a) { return std::cos(a); }
    static double tan(double a) { return std::tan(a); }
    static double atan2(double y, double x) { return std::atan2(y, x); }
    static double asin(double a) { return std::asin(a); }
    static double acos(double a) { return std::acos(a); }
    static double atan(double a) { return std::atan(a); }

    // exponential and logarithmic
    static double sqrt(double a) { return std::sqrt(a); }
    static double log(double a) { return std::log(a); }
    static double log10(double a) { return std::log10(a); }
    static double pow(double a, double b) { return std::pow(a, b); }
    static double exp(double a) { return std::exp(a); }
    static double expm1(double a) { return std::expm1(a); }
    static double log1p(double a) { return std::log1p(a); }
    static double cbrt(double a) { return std::cbrt(a); }

    // min/max
    static double min(double a, double b) { return std::fmin(a, b); }
    static float min(float a, float b) { return std::fmin(a, b); }
    static int min(int a, int b) { return (a < b) ? a : b; }
    static long min(long a, long b) { return (a < b) ? a : b; }

    static float max(float a, float b) { return std::fmax(a, b); }
    static long max(long a, long b) { return (a > b) ? a : b; }
    static int max(int a, int b) { return (a > b) ? a : b; }
    static double max(double a, double b) { return std::fmax(a, b); }

    // rounding
    static double floor(double a) { return std::floor(a); }
    static double ceil(double a) { return std::ceil(a); }
    static double rint(double a) { return std::rint(a); }
    static long round(double a) { return std::llround(a); }
    static int round(float a) { return std::lround(a); }

    // hyperbolic
    static double tanh(double a) { return std::tanh(a); }
    static double sinh(double a) { return std::sinh(a); }
    static double cosh(double a) { return std::cosh(a); }

    // exact arithmetic
    static int addExact(int x, int y) {
        if ((y > 0 && x > std::numeric_limits<int>::max() - y) ||
            (y < 0 && x < std::numeric_limits<int>::min() - y)) {
            throw std::overflow_error("integer overflow");
        }
        return x + y;
    }

    static long addExact(long x, long y) {
        if ((y > 0 && x > std::numeric_limits<long>::max() - y) ||
            (y < 0 && x < std::numeric_limits<long>::min() - y)) {
            throw std::overflow_error("long overflow");
        }
        return x + y;
    }

    static long decrementExact(long a) {
        if (a == std::numeric_limits<long>::min()) {
            throw std::overflow_error("long overflow");
        }
        return a - 1;
    }

    static int decrementExact(int a) {
        if (a == std::numeric_limits<int>::min()) {
            throw std::overflow_error("int overflow");
        }
        return a - 1;
    }

    static int incrementExact(int a) {
        if (a == std::numeric_limits<int>::max()) {
            throw std::overflow_error("int overflow");
        }
        return a + 1;
    }

    static long incrementExact(long a) {
        if (a == std::numeric_limits<long>::max()) {
            throw std::overflow_error("long overflow");
        }
        return a + 1;
    }

    static int multiplyExact(int x, int y) {
        long result = static_cast<long>(x) * y;
        if (result < std::numeric_limits<int>::min() || result > std::numeric_limits<int>::max()) {
            throw std::overflow_error("int overflow");
        }
        return static_cast<int>(result);
    }

    static long multiplyExact(long x, int y) {
        return multiplyExact(x, static_cast<long>(y));
    }

    static long multiplyExact(long x, long y) {
        if (x == 0 || y == 0) return 0;
        if (x == std::numeric_limits<long>::min() && y == -1) {
            throw std::overflow_error("long overflow");
        }
        long result = x * y;
        if (result / y != x) {
            throw std::overflow_error("long overflow");
        }
        return result;
    }

    static long multiplyHigh(long x, long y) {
        __int128 result = static_cast<__int128>(x) * y;
        return static_cast<long>(result >> 64);
    }

    static long unsignedMultiplyHigh(long x, long y) {
        unsigned __int128 result = static_cast<unsigned __int128>(static_cast<uint64_t>(x)) * static_cast<uint64_t>(y);
        return static_cast<long>(result >> 64);
    }

    static long negateExact(long a) {
        if (a == std::numeric_limits<long>::min()) {
            throw std::overflow_error("long overflow");
        }
        return -a;
    }

    static int negateExact(int a) {
        if (a == std::numeric_limits<int>::min()) {
            throw std::overflow_error("int overflow");
        }
        return -a;
    }

    static long subtractExact(long x, long y) {
        if ((y > 0 && x < std::numeric_limits<long>::min() + y) ||
            (y < 0 && x > std::numeric_limits<long>::max() + y)) {
            throw std::overflow_error("long overflow");
        }
        return x - y;
    }

    static int subtractExact(int x, int y) {
        if ((y > 0 && x < std::numeric_limits<int>::min() + y) ||
            (y < 0 && x > std::numeric_limits<int>::max() + y)) {
            throw std::overflow_error("int overflow");
        }
        return x - y;
    }

    // fma
    static double fma(double a, double b, double c) { return std::fma(a, b, c); }
    static float fma(float a, float b, float c) { return std::fma(a, b, c); }

    // copySign
    static double copySign(double magnitude, double sign) { return std::copysign(magnitude, sign); }
    static float copySign(float magnitude, float sign) { return std::copysign(magnitude, sign); }

    // signum
    static double signum(double a) { return (a > 0) ? 1.0 : (a < 0) ? -1.0 : a; }
    static float signum(float a) { return (a > 0) ? 1.0f : (a < 0) ? -1.0f : a; }

    // clamp
    static double clamp(double value, double min, double max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    static long clamp(long value, long min, long max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    static float clamp(float value, float min, float max) {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    static long clamp(long value, int min, int max) {
        return clamp(value, static_cast<long>(min), static_cast<long>(max));
    }

    // scalb
    static double scalb(double d, int scaleFactor) { return std::scalbn(d, scaleFactor); }
    static float scalb(float f, int scaleFactor) { return std::scalbn(f, scaleFactor); }

    // getExponent
    static int getExponent(float f) { return std::ilogb(f); }
    static int getExponent(double d) { return std::ilogb(d); }

    // floorMod
    static int floorMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r ^ y) < 0)) {
            r += y;
        }
        return r;
    }

    static long floorMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r ^ y) < 0)) {
            r += y;
        }
        return r;
    }

    static long floorMod(long x, int y) {
        return floorMod(x, static_cast<long>(y));
    }

    // IEEEremainder
    static double IEEEremainder(double f1, double f2) { return std::remainder(f1, f2); }

    // floorDiv
    static long floorDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x ^ y) < 0)) {
            q--;
        }
        return q;
    }

    static long floorDiv(long x, int y) {
        return floorDiv(x, static_cast<long>(y));
    }

    static int floorDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x ^ y) < 0)) {
            q--;
        }
        return q;
    }

    // ceilDiv
    static long ceilDiv(long x, int y) {
        return ceilDiv(x, static_cast<long>(y));
    }

    static long ceilDiv(long x, long y) {
        long q = x / y;
        if ((x % y != 0) && ((x ^ y) >= 0)) {
            q++;
        }
        return q;
    }

    static int ceilDiv(int x, int y) {
        int q = x / y;
        if ((x % y != 0) && ((x ^ y) >= 0)) {
            q++;
        }
        return q;
    }

    // ceilMod
    static int ceilMod(int x, int y) {
        int r = x % y;
        if (r != 0 && ((r ^ y) >= 0)) {
            r -= y;
        }
        return r;
    }

    static long ceilMod(long x, int y) {
        return ceilMod(x, static_cast<long>(y));
    }

    static long ceilMod(long x, long y) {
        long r = x % y;
        if (r != 0 && ((r ^ y) >= 0)) {
            r -= y;
        }
        return r;
    }

    // hypot
    static double hypot(double x, double y) { return std::hypot(x, y); }

    // unsignedMultiplyExact
    static int unsignedMultiplyExact(int x, int y) {
        unsigned int ux = static_cast<unsigned int>(x);
        unsigned int uy = static_cast<unsigned int>(y);
        unsigned long long result = static_cast<unsigned long long>(ux) * uy;
        if (result > std::numeric_limits<unsigned int>::max()) {
            throw std::overflow_error("unsigned int overflow");
        }
        return static_cast<int>(result);
    }

    static long unsignedMultiplyExact(long x, int y) {
        return unsignedMultiplyExact(x, static_cast<long>(y));
    }

    static long unsignedMultiplyExact(long x, long y) {
        unsigned long long ux = static_cast<unsigned long long>(x);
        unsigned long long uy = static_cast<unsigned long long>(y);
        unsigned __int128 result = static_cast<unsigned __int128>(ux) * uy;
        if (result > std::numeric_limits<unsigned long long>::max()) {
            throw std::overflow_error("unsigned long overflow");
        }
        return static_cast<long>(result);
    }

    // toRadians/toDegrees
    static double toRadians(double angdeg) { return angdeg * M_PI / 180.0; }
    static double toDegrees(double angrad) { return angrad * 180.0 / M_PI; }

    // random
    static double random() { return static_cast<double>(std::rand()) / RAND_MAX; }

    // divideExact
    static int divideExact(int x, int y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<int>::min() && y == -1) {
            throw std::overflow_error("int overflow");
        }
        return x / y;
    }

    static long divideExact(long x, long y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<long>::min() && y == -1) {
            throw std::overflow_error("long overflow");
        }
        return x / y;
    }

    // floorDivExact
    static int floorDivExact(int x, int y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<int>::min() && y == -1) {
            throw std::overflow_error("int overflow");
        }
        return floorDiv(x, y);
    }

    static long floorDivExact(long x, long y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<long>::min() && y == -1) {
            throw std::overflow_error("long overflow");
        }
        return floorDiv(x, y);
    }

    // ceilDivExact
    static long ceilDivExact(long x, long y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<long>::min() && y == -1) {
            throw std::overflow_error("long overflow");
        }
        return ceilDiv(x, y);
    }

    static int ceilDivExact(int x, int y) {
        if (y == 0) throw std::overflow_error("division by zero");
        if (x == std::numeric_limits<int>::min() && y == -1) {
            throw std::overflow_error("int overflow");
        }
        return ceilDiv(x, y);
    }

    // toIntExact
    static int toIntExact(long value) {
        if (value < std::numeric_limits<int>::min() || value > std::numeric_limits<int>::max()) {
            throw std::overflow_error("int overflow");
        }
        return static_cast<int>(value);
    }

    // multiplyFull
    static long multiplyFull(int x, int y) {
        return static_cast<long>(x) * y;
    }

    // absExact
    static long absExact(long a) {
        if (a == std::numeric_limits<long>::min()) {
            throw std::overflow_error("long overflow");
        }
        return std::llabs(a);
    }

    static int absExact(int a) {
        if (a == std::numeric_limits<int>::min()) {
            throw std::overflow_error("int overflow");
        }
        return std::abs(a);
    }

    // ulp
    static double ulp(double d) { return std::numeric_limits<double>::epsilon() * std::pow(2, std::ilogb(d)); }
    static float ulp(float f) { return std::numeric_limits<float>::epsilon() * std::pow(2, std::ilogb(f)); }

    // nextAfter
    static float nextAfter(float start, double direction) {
        return std::nextafter(start, static_cast<float>(direction));
    }

    static double nextAfter(double start, double direction) {
        return std::nextafter(start, direction);
    }

    // nextUp
    static float nextUp(float f) { return std::nextafter(f, std::numeric_limits<float>::infinity()); }
    static double nextUp(double d) { return std::nextafter(d, std::numeric_limits<double>::infinity()); }

    // nextDown
    static double nextDown(double d) { return std::nextafter(d, -std::numeric_limits<double>::infinity()); }
    static float nextDown(float f) { return std::nextafter(f, -std::numeric_limits<float>::infinity()); }

    // powExact
    static long powExact(long base, int exponent) {
        if (exponent < 0) throw std::overflow_error("negative exponent");
        long result = 1;
        for (int i = 0; i < exponent; i++) {
            result = multiplyExact(result, base);
        }
        return result;
    }

    static int powExact(int base, int exponent) {
        if (exponent < 0) throw std::overflow_error("negative exponent");
        int result = 1;
        for (int i = 0; i < exponent; i++) {
            result = multiplyExact(result, base);
        }
        return result;
    }

    // unsignedPowExact
    static long unsignedPowExact(long base, int exponent) {
        if (exponent < 0) throw std::overflow_error("negative exponent");
        unsigned long long result = 1;
        unsigned long long ub = static_cast<unsigned long long>(base);
        for (int i = 0; i < exponent; i++) {
            result = unsignedMultiplyExact(result, ub);
        }
        return static_cast<long>(result);
    }

    static int unsignedPowExact(int base, int exponent) {
        if (exponent < 0) throw std::overflow_error("negative exponent");
        unsigned int result = 1;
        unsigned int ub = static_cast<unsigned int>(base);
        for (int i = 0; i < exponent; i++) {
            result = static_cast<unsigned int>(unsignedMultiplyExact(result, ub));
        }
        return static_cast<int>(result);
    }
};

} // namespace lang
} // namespace java

using java::lang::StrictMath;

// Test functions
void abs_test_11593(float p0) { StrictMath::abs(p0); }
void abs_test_11594(long p0) { StrictMath::abs(p0); }
void abs_test_11595(int p0) { StrictMath::abs(p0); }
void abs_test_11596(double p0) { StrictMath::abs(p0); }
void sin_test_11597(double p0) { StrictMath::sin(p0); }
void cos_test_11598(double p0) { StrictMath::cos(p0); }
void tan_test_11599(double p0) { StrictMath::tan(p0); }
void atan2_test_11600(double p0, double p1) { StrictMath::atan2(p0, p1); }
void sqrt_test_11601(double p0) { StrictMath::sqrt(p0); }
void log_test_11602(double p0) { StrictMath::log(p0); }
void log10_test_11603(double p0) { StrictMath::log10(p0); }
void pow_test_11604(double p0, double p1) { StrictMath::pow(p0, p1); }
void exp_test_11605(double p0) { StrictMath::exp(p0); }
void min_test_11606(double p0, double p1) { StrictMath::min(p0, p1); }
void min_test_11607(float p0, float p1) { StrictMath::min(p0, p1); }
void min_test_11608(int p0, int p1) { StrictMath::min(p0, p1); }
void min_test_11609(long p0, long p1) { StrictMath::min(p0, p1); }
void max_test_11610(float p0, float p1) { StrictMath::max(p0, p1); }
void max_test_11611(long p0, long p1) { StrictMath::max(p0, p1); }
void max_test_11612(int p0, int p1) { StrictMath::max(p0, p1); }
void max_test_11613(double p0, double p1) { StrictMath::max(p0, p1); }
void floor_test_11614(double p0) { StrictMath::floor(p0); }
void ceil_test_11615(double p0) { StrictMath::ceil(p0); }
void rint_test_11616(double p0) { StrictMath::rint(p0); }
void round_test_11617(double p0) { StrictMath::round(p0); }
void round_test_11618(float p0) { StrictMath::round(p0); }
void tanh_test_11619(double p0) { StrictMath::tanh(p0); }
void cbrt_test_11620(double p0) { StrictMath::cbrt(p0); }
void addExact_test_11621(int p0, int p1) { StrictMath::addExact(p0, p1); }
void addExact_test_11622(long p0, long p1) { StrictMath::addExact(p0, p1); }
void decrementExact_test_11623(long p0) { StrictMath::decrementExact(p0); }
void decrementExact_test_11624(int p0) { StrictMath::decrementExact(p0); }
void incrementExact_test_11625(int p0) { StrictMath::incrementExact(p0); }
void incrementExact_test_11626(long p0) { StrictMath::incrementExact(p0); }
void multiplyExact_test_11627(int p0, int p1) { StrictMath::multiplyExact(p0, p1); }
void multiplyExact_test_11628(long p0, int p1) { StrictMath::multiplyExact(p0, p1); }
void multiplyExact_test_11629(long p0, long p1) { StrictMath::multiplyExact(p0, p1); }
void multiplyHigh_test_11630(long p0, long p1) { StrictMath::multiplyHigh(p0, p1); }
void unsignedMultiplyHigh_test_11631(long p0, long p1) { StrictMath::unsignedMultiplyHigh(p0, p1); }
void negateExact_test_11632(long p0) { StrictMath::negateExact(p0); }
void negateExact_test_11633(int p0) { StrictMath::negateExact(p0); }
void subtractExact_test_11634(long p0, long p1) { StrictMath::subtractExact(p0, p1); }
void subtractExact_test_11635(int p0, int p1) { StrictMath::subtractExact(p0, p1); }
void fma_test_11636(double p0, double p1, double p2) { StrictMath::fma(p0, p1, p2); }
void fma_test_11637(float p0, float p1, float p2) { StrictMath::fma(p0, p1, p2); }
void copySign_test_11638(double p0, double p1) { StrictMath::copySign(p0, p1); }
void copySign_test_11639(float p0, float p1) { StrictMath::copySign(p0, p1); }
void signum_test_11640(double p0) { StrictMath::signum(p0); }
void signum_test_11641(float p0) { StrictMath::signum(p0); }
void clamp_test_11642(double p0, double p1, double p2) { StrictMath::clamp(p0, p1, p2); }
void clamp_test_11643(long p0, long p1, long p2) { StrictMath::clamp(p0, p1, p2); }
void clamp_test_11644(float p0, float p1, float p2) { StrictMath::clamp(p0, p1, p2); }
void clamp_test_11645(long p0, int p1, int p2) { StrictMath::clamp(p0, p1, p2); }
void scalb_test_11646(double p0, int p1) { StrictMath::scalb(p0, p1); }
void scalb_test_11647(float p0, int p1) { StrictMath::scalb(p0, p1); }
void getExponent_test_11648(float p0) { StrictMath::getExponent(p0); }
void getExponent_test_11649(double p0) { StrictMath::getExponent(p0); }
void floorMod_test_11650(int p0, int p1) { StrictMath::floorMod(p0, p1); }
void floorMod_test_11651(long p0, long p1) { StrictMath::floorMod(p0, p1); }
void floorMod_test_11652(long p0, int p1) { StrictMath::floorMod(p0, p1); }
void asin_test_11653(double p0) { StrictMath::asin(p0); }
void acos_test_11654(double p0) { StrictMath::acos(p0); }
void atan_test_11655(double p0) { StrictMath::atan(p0); }
void IEEEremainder_test_11656(double p0, double p1) { StrictMath::IEEEremainder(p0, p1); }
void floorDiv_test_11657(long p0, long p1) { StrictMath::floorDiv(p0, p1); }
void floorDiv_test_11658(long p0, int p1) { StrictMath::floorDiv(p0, p1); }
void floorDiv_test_11659(int p0, int p1) { StrictMath::floorDiv(p0, p1); }
void ceilDiv_test_11660(long p0, int p1) { StrictMath::ceilDiv(p0, p1); }
void ceilDiv_test_11661(long p0, long p1) { StrictMath::ceilDiv(p0, p1); }
void ceilDiv_test_11662(int p0, int p1) { StrictMath::ceilDiv(p0, p1); }
void ceilMod_test_11663(int p0, int p1) { StrictMath::ceilMod(p0, p1); }
void ceilMod_test_11664(long p0, int p1) { StrictMath::ceilMod(p0, p1); }
void ceilMod_test_11665(long p0, long p1) { StrictMath::ceilMod(p0, p1); }
void sinh_test_11666(double p0) { StrictMath::sinh(p0); }
void cosh_test_11667(double p0) { StrictMath::cosh(p0); }
void hypot_test_11668(double p0, double p1) { StrictMath::hypot(p0, p1); }
void expm1_test_11669(double p0) { StrictMath::expm1(p0); }
void log1p_test_11670(double p0) { StrictMath::log1p(p0); }
void unsignedMultiplyExact_test_11671(int p0, int p1) { StrictMath::unsignedMultiplyExact(p0, p1); }
void unsignedMultiplyExact_test_11672(long p0, int p1) { StrictMath::unsignedMultiplyExact(p0, p1); }
void unsignedMultiplyExact_test_11673(long p0, long p1) { StrictMath::unsignedMultiplyExact(p0, p1); }
void toRadians_test_11674(double p0) { StrictMath::toRadians(p0); }
void toDegrees_test_11675(double p0) { StrictMath::toDegrees(p0); }
void random_test_11676() { StrictMath::random(); }
void divideExact_test_11677(int p0, int p1) { StrictMath::divideExact(p0, p1); }
void divideExact_test_11678(long p0, long p1) { StrictMath::divideExact(p0, p1); }
void floorDivExact_test_11679(int p0, int p1) { StrictMath::floorDivExact(p0, p1); }
void floorDivExact_test_11680(long p0, long p1) { StrictMath::floorDivExact(p0, p1); }
void ceilDivExact_test_11681(long p0, long p1) { StrictMath::ceilDivExact(p0, p1); }
void ceilDivExact_test_11682(int p0, int p1) { StrictMath::ceilDivExact(p0, p1); }
void toIntExact_test_11683(long p0) { StrictMath::toIntExact(p0); }
void multiplyFull_test_11684(int p0, int p1) { StrictMath::multiplyFull(p0, p1); }
void absExact_test_11685(long p0) { StrictMath::absExact(p0); }
void absExact_test_11686(int p0) { StrictMath::absExact(p0); }
void ulp_test_11687(double p0) { StrictMath::ulp(p0); }
void ulp_test_11688(float p0) { StrictMath::ulp(p0); }
void nextAfter_test_11689(float p0, double p1) { StrictMath::nextAfter(p0, p1); }
void nextAfter_test_11690(double p0, double p1) { StrictMath::nextAfter(p0, p1); }
void nextUp_test_11691(float p0) { StrictMath::nextUp(p0); }
void nextUp_test_11692(double p0) { StrictMath::nextUp(p0); }
void nextDown_test_11693(double p0) { StrictMath::nextDown(p0); }
void nextDown_test_11694(float p0) { StrictMath::nextDown(p0); }
void powExact_test_11695(long p0, int p1) { StrictMath::powExact(p0, p1); }
void powExact_test_11696(int p0, int p1) { StrictMath::powExact(p0, p1); }
void unsignedPowExact_test_11697(long p0, int p1) { StrictMath::unsignedPowExact(p0, p1); }
void unsignedPowExact_test_11698(int p0, int p1) { StrictMath::unsignedPowExact(p0, p1); }