#include <string>
#include <cstdint>
#include <chrono>

using CharSequence = std::string;

class Instant {
private:
    std::int64_t epochSecond;
    int nano;
public:
    Instant() : epochSecond(0), nano(0) {}
    Instant(std::int64_t epochSecond, int nano) : epochSecond(epochSecond), nano(nano) {}

    static Instant now() {
        using namespace std::chrono;
        auto tp = system_clock::now();
        auto dur = tp.time_since_epoch();
        auto sec = duration_cast<seconds>(dur).count();
        auto subDur = dur - seconds(sec);
        auto nanos = duration_cast<nanoseconds>(subDur).count();
        return Instant(sec, static_cast<int>(nanos));
    }

    std::int64_t getEpochSecond() const { return epochSecond; }
    int getNano() const { return nano; }
};

class ZoneId {
public:
    ZoneId() = default;
    virtual ~ZoneId() = default;
};

class ZoneOffset : public ZoneId {
private:
    int totalSeconds;
public:
    ZoneOffset() : totalSeconds(0) {}
    explicit ZoneOffset(int totalSeconds) : totalSeconds(totalSeconds) {}

    static ZoneOffset ofTotalSeconds(int totalSeconds) {
        return ZoneOffset(totalSeconds);
    }

    static ZoneOffset ofHours(int hours) {
        return ZoneOffset(hours * 3600);
    }

    int getTotalSeconds() const { return totalSeconds; }
};

class LocalTime {
private:
    int hour;
    int minute;
    int second;
    int nano;
public:
    LocalTime() : hour(0), minute(0), second(0), nano(0) {}
    LocalTime(int hour, int minute, int second, int nano)
        : hour(hour), minute(minute), second(second), nano(nano) {}

    static LocalTime of(int hour, int minute, int second, int nano) {
        return LocalTime(hour, minute, second, nano);
    }

    int getHour() const { return hour; }
    int getMinute() const { return minute; }
    int getSecond() const { return second; }
    int getNano() const { return nano; }
};

class DateTimeFormatter {
public:
    DateTimeFormatter() = default;

    static DateTimeFormatter ofPattern(const std::string& pattern) {
        (void)pattern;
        return DateTimeFormatter();
    }

    static DateTimeFormatter ISO_OFFSET_TIME() {
        return DateTimeFormatter();
    }
};

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
};

class Clock {
public:
    Clock() = default;
    virtual ~Clock() = default;

    virtual Instant instant() const {
        return Instant::now();
    }

    virtual ZoneId getZone() const {
        return ZoneId();
    }

    static Clock systemUTC() {
        return Clock();
    }

    static Clock systemDefaultZone() {
        return Clock();
    }
};

class OffsetTime {
private:
    LocalTime time;
    ZoneOffset offset;

    static OffsetTime fromInstant(const Instant& instant, const ZoneOffset& offset) {
        std::int64_t epochSecond = instant.getEpochSecond();
        int nano = instant.getNano();

        int secsOfDay = static_cast<int>(epochSecond % 86400);
        if (secsOfDay < 0) {
            secsOfDay += 86400;
        }

        int hour = secsOfDay / 3600;
        int minute = (secsOfDay % 3600) / 60;
        int second = secsOfDay % 60;

        return OffsetTime(LocalTime(hour, minute, second, nano), offset);
    }

public:
    OffsetTime() : time(), offset() {}
    OffsetTime(const LocalTime& time, const ZoneOffset& offset) : time(time), offset(offset) {}

    static OffsetTime of(const LocalTime& time, const ZoneOffset& offset) {
        return OffsetTime(time, offset);
    }

    static OffsetTime of(int hour, int minute, int second, int nanoOfSecond, const ZoneOffset& offset) {
        return OffsetTime(LocalTime::of(hour, minute, second, nanoOfSecond), offset);
    }

    static OffsetTime from(const TemporalAccessor& temporal) {
        (void)temporal;
        return OffsetTime();
    }

    static OffsetTime parse(const CharSequence& text) {
        (void)text;
        return OffsetTime();
    }

    static OffsetTime parse(const CharSequence& text, const DateTimeFormatter& formatter) {
        (void)text;
        (void)formatter;
        return OffsetTime();
    }

    static OffsetTime now() {
        return now(Clock::systemDefaultZone());
    }

    static OffsetTime now(const Clock& clock) {
        return fromInstant(clock.instant(), ZoneOffset(0));
    }

    static OffsetTime now(const ZoneId& zone) {
        (void)zone;
        return now(Clock::systemDefaultZone());
    }

    static OffsetTime ofInstant(const Instant& instant, const ZoneId& zone) {
        (void)zone;
        return fromInstant(instant, ZoneOffset(0));
    }

    LocalTime getTime() const { return time; }
    ZoneOffset getOffset() const { return offset; }
};

void of_test_9651(const LocalTime& p0, const ZoneOffset& p1) {
    OffsetTime::of(p0, p1);
}

void of_test_9652(int p0, int p1, int p2, int p3, const ZoneOffset& p4) {
    OffsetTime::of(p0, p1, p2, p3, p4);
}

void from_test_9653(const TemporalAccessor& p0) {
    OffsetTime::from(p0);
}

void parse_test_9654(const CharSequence& p0) {
    OffsetTime::parse(p0);
}

void parse_test_9655(const CharSequence& p0, const DateTimeFormatter& p1) {
    OffsetTime::parse(p0, p1);
}

void now_test_9656() {
    OffsetTime::now();
}

void now_test_9657(const Clock& p0) {
    OffsetTime::now(p0);
}

void now_test_9658(const ZoneId& p0) {
    OffsetTime::now(p0);
}

void ofInstant_test_9659(const Instant& p0, const ZoneId& p1) {
    OffsetTime::ofInstant(p0, p1);
}