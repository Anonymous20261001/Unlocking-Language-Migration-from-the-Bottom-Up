#include <vector>
#include <set>

class Class {
public:
    bool operator<(const Class& other) const {
        return this < &other;
    }
};

class PlatformManagedObject {
public:
    virtual ~PlatformManagedObject() = default;
};

class ClassLoadingMXBean : public PlatformManagedObject {};
class MemoryMXBean : public PlatformManagedObject {};
class ThreadMXBean : public PlatformManagedObject {};
class RuntimeMXBean : public PlatformManagedObject {};
class CompilationMXBean : public PlatformManagedObject {};
class OperatingSystemMXBean : public PlatformManagedObject {};
class MemoryPoolMXBean : public PlatformManagedObject {};
class MemoryManagerMXBean : public PlatformManagedObject {};
class GarbageCollectorMXBean : public MemoryManagerMXBean {};
class MBeanServer {};

class ManagementFactory {
public:
    ManagementFactory() = delete;

    template<typename T = PlatformManagedObject>
    static T getPlatformMXBean(Class) {
        return T();
    }

    template<typename T = PlatformManagedObject>
    static std::vector<T> getPlatformMXBeans(Class) {
        return {};
    }

    static ClassLoadingMXBean getClassLoadingMXBean() { return {}; }
    static MemoryMXBean getMemoryMXBean() { return {}; }
    static ThreadMXBean getThreadMXBean() { return {}; }
    static RuntimeMXBean getRuntimeMXBean() { return {}; }
    static CompilationMXBean getCompilationMXBean() { return {}; }
    static OperatingSystemMXBean getOperatingSystemMXBean() { return {}; }
    static std::vector<MemoryPoolMXBean> getMemoryPoolMXBeans() { return {}; }
    static std::vector<MemoryManagerMXBean> getMemoryManagerMXBeans() { return {}; }
    static std::vector<GarbageCollectorMXBean> getGarbageCollectorMXBeans() { return {}; }
    static MBeanServer getPlatformMBeanServer() { return {}; }
    static std::set<Class> getPlatformManagementInterfaces() { return {}; }
};

void getPlatformMXBean_test_8262(Class p0) {
    ManagementFactory::getPlatformMXBean(p0);
}

void getPlatformMXBeans_test_8263(Class p0) {
    ManagementFactory::getPlatformMXBeans(p0);
}

void getClassLoadingMXBean_test_8264() {
    ManagementFactory::getClassLoadingMXBean();
}

void getMemoryMXBean_test_8265() {
    ManagementFactory::getMemoryMXBean();
}

void getThreadMXBean_test_8266() {
    ManagementFactory::getThreadMXBean();
}

void getRuntimeMXBean_test_8267() {
    ManagementFactory::getRuntimeMXBean();
}

void getCompilationMXBean_test_8268() {
    ManagementFactory::getCompilationMXBean();
}

void getOperatingSystemMXBean_test_8269() {
    ManagementFactory::getOperatingSystemMXBean();
}

void getMemoryPoolMXBeans_test_8270() {
    ManagementFactory::getMemoryPoolMXBeans();
}

void getMemoryManagerMXBeans_test_8271() {
    ManagementFactory::getMemoryManagerMXBeans();
}

void getGarbageCollectorMXBeans_test_8272() {
    ManagementFactory::getGarbageCollectorMXBeans();
}

void getPlatformMBeanServer_test_8273() {
    ManagementFactory::getPlatformMBeanServer();
}

void getPlatformManagementInterfaces_test_8274() {
    ManagementFactory::getPlatformManagementInterfaces();
}