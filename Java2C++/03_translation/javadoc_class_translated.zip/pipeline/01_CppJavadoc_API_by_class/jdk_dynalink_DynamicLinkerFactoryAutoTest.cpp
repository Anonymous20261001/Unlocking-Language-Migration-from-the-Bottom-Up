#include <vector>

class ClassLoader {};
class List { public: List() = default; };
class GuardingDynamicLinker { public: virtual ~GuardingDynamicLinker() = default; };
class GuardedInvocationTransformer { public: virtual ~GuardedInvocationTransformer() = default; };
class MethodTypeConversionStrategy { public: virtual ~MethodTypeConversionStrategy() = default; };
class MethodHandleTransformer { public: virtual ~MethodHandleTransformer() = default; };
class DynamicLinker { public: DynamicLinker() = default; };

class DynamicLinkerFactory {
public:
    DynamicLinkerFactory() = default;

    void setFallbackLinkers(List /*p0*/) {}
    void setFallbackLinkers(GuardingDynamicLinker** /*p0*/) {}

    void setClassLoader(ClassLoader* /*p0*/) {}

    void setSyncOnRelink(bool /*p0*/) {}

    DynamicLinker createLinker() { return DynamicLinker(); }

    void setPrioritizedLinkers(List /*p0*/) {}
    void setPrioritizedLinkers(GuardingDynamicLinker** /*p0*/) {}
    void setPrioritizedLinker(GuardingDynamicLinker* /*p0*/) {}

    void setUnstableRelinkThreshold(int /*p0*/) {}

    void setPrelinkTransformer(GuardedInvocationTransformer* /*p0*/) {}

    void setAutoConversionStrategy(MethodTypeConversionStrategy* /*p0*/) {}

    void setInternalObjectsFilter(MethodHandleTransformer* /*p0*/) {}

    List getAutoLoadingErrors() { return List(); }
};

void setFallbackLinkers_test_4425(List p0) {
    DynamicLinkerFactory instance;
    instance.setFallbackLinkers(p0);
}

void setFallbackLinkers_test_4426(GuardingDynamicLinker** p0) {
    DynamicLinkerFactory instance;
    instance.setFallbackLinkers(p0);
}

void setClassLoader_test_4427(ClassLoader* p0) {
    DynamicLinkerFactory instance;
    instance.setClassLoader(p0);
}

void setSyncOnRelink_test_4428(bool p0) {
    DynamicLinkerFactory instance;
    instance.setSyncOnRelink(p0);
}

void createLinker_test_4429() {
    DynamicLinkerFactory instance;
    instance.createLinker();
}

void setPrioritizedLinkers_test_4430(List p0) {
    DynamicLinkerFactory instance;
    instance.setPrioritizedLinkers(p0);
}

void setPrioritizedLinkers_test_4431(GuardingDynamicLinker** p0) {
    DynamicLinkerFactory instance;
    instance.setPrioritizedLinkers(p0);
}

void setPrioritizedLinker_test_4432(GuardingDynamicLinker* p0) {
    DynamicLinkerFactory instance;
    instance.setPrioritizedLinker(p0);
}

void setUnstableRelinkThreshold_test_4433(int p0) {
    DynamicLinkerFactory instance;
    instance.setUnstableRelinkThreshold(p0);
}

void setPrelinkTransformer_test_4434(GuardedInvocationTransformer* p0) {
    DynamicLinkerFactory instance;
    instance.setPrelinkTransformer(p0);
}

void setAutoConversionStrategy_test_4435(MethodTypeConversionStrategy* p0) {
    DynamicLinkerFactory instance;
    instance.setAutoConversionStrategy(p0);
}

void setInternalObjectsFilter_test_4436(MethodHandleTransformer* p0) {
    DynamicLinkerFactory instance;
    instance.setInternalObjectsFilter(p0);
}

void getAutoLoadingErrors_test_4437() {
    DynamicLinkerFactory instance;
    instance.getAutoLoadingErrors();
}
