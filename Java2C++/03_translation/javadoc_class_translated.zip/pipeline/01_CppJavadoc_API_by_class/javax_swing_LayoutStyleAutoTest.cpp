class LayoutStyle {
public:
    static LayoutStyle* getInstance() {
        static LayoutStyle defaultInstance;
        return instance != nullptr ? instance : &defaultInstance;
    }

    static void setInstance(LayoutStyle* style) {
        instance = style;
    }

protected:
    LayoutStyle() = default;
    virtual ~LayoutStyle() = default;

private:
    static LayoutStyle* instance;
};

LayoutStyle* LayoutStyle::instance = nullptr;

void setInstance_test_7711(LayoutStyle* p0) {
    LayoutStyle::setInstance(p0);
}

void getInstance_test_7712() {
    LayoutStyle::getInstance();
}