#include <string>

class Element {
public:
    enum Type {
        ANY = 0,
        EMPTY = 1,
        PCDATA = 2,
        CDATA = 3,
        RCDATA = 4,
        UNKNOWN = 5
    };

    static int name2type(const std::string& name) {
        if (name == "#PCDATA") return PCDATA;
        if (name == "CDATA") return CDATA;
        if (name == "RCDATA") return RCDATA;
        if (name == "EMPTY") return EMPTY;
        return UNKNOWN;
    }
};

void name2type_test_4462(std::string p0) {
    Element::name2type(p0);
}