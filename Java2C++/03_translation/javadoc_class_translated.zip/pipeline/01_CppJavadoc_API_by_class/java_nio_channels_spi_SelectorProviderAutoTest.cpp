#include <mutex>

class SelectorProvider {
public:
    static SelectorProvider& provider() {
        static SelectorProvider instance;
        return instance;
    }

    SelectorProvider(const SelectorProvider&) = delete;
    SelectorProvider& operator=(const SelectorProvider&) = delete;

private:
    SelectorProvider() = default;
};

void provider_test_11022() {
    SelectorProvider::provider();
}