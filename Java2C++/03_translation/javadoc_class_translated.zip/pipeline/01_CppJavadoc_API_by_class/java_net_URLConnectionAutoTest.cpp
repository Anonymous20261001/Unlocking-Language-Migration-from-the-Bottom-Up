#include <string>
#include <map>

class FileNameMap {
public:
    virtual ~FileNameMap() = default;
};

class ContentHandlerFactory {
public:
    virtual ~ContentHandlerFactory() = default;
};

class URLConnection {
public:
    static bool defaultAllowUserInteraction;
    static bool defaultUseCaches;
    static FileNameMap fileNameMap;
    static ContentHandlerFactory contentHandlerFactory;
    static std::map<std::string, std::string> defaultRequestProperties;

    static bool getDefaultUseCaches(const std::string& file) {
        return defaultUseCaches;
    }

    static FileNameMap getFileNameMap() {
        return fileNameMap;
    }

    static void setFileNameMap(const FileNameMap& map) {
        fileNameMap = map;
    }

    static void setDefaultAllowUserInteraction(bool allow) {
        defaultAllowUserInteraction = allow;
    }

    static bool getDefaultAllowUserInteraction() {
        return defaultAllowUserInteraction;
    }

    static void setDefaultUseCaches(const std::string& file, bool useCaches) {
        defaultUseCaches = useCaches;
    }

    static void setDefaultRequestProperty(const std::string& key, const std::string& value) {
        defaultRequestProperties[key] = value;
    }

    static std::string getDefaultRequestProperty(const std::string& key) {
        auto it = defaultRequestProperties.find(key);
        if (it != defaultRequestProperties.end()) {
            return it->second;
        }
        return "";
    }

    static void setContentHandlerFactory(const ContentHandlerFactory& factory) {
        contentHandlerFactory = factory;
    }

    static std::string guessContentTypeFromName(const std::string& fname) {
        if (fname.size() >= 5 && fname.substr(fname.size() - 5) == ".html") return "text/html";
        if (fname.size() >= 4 && fname.substr(fname.size() - 4) == ".txt") return "text/plain";
        return "application/octet-stream";
    }
};

bool URLConnection::defaultAllowUserInteraction = false;
bool URLConnection::defaultUseCaches = false;
FileNameMap URLConnection::fileNameMap;
ContentHandlerFactory URLConnection::contentHandlerFactory;
std::map<std::string, std::string> URLConnection::defaultRequestProperties;

void getDefaultUseCaches_test_13255(std::string p0) {
    URLConnection::getDefaultUseCaches(p0);
}

void getFileNameMap_test_13256() {
    URLConnection::getFileNameMap();
}

void setFileNameMap_test_13257(FileNameMap p0) {
    URLConnection::setFileNameMap(p0);
}

void setDefaultAllowUserInteraction_test_13258(bool p0) {
    URLConnection::setDefaultAllowUserInteraction(p0);
}

void getDefaultAllowUserInteraction_test_13259() {
    URLConnection::getDefaultAllowUserInteraction();
}

void setDefaultUseCaches_test_13260(std::string p0, bool p1) {
    URLConnection::setDefaultUseCaches(p0, p1);
}

void setDefaultRequestProperty_test_13261(std::string p0, std::string p1) {
    URLConnection::setDefaultRequestProperty(p0, p1);
}

void getDefaultRequestProperty_test_13262(std::string p0) {
    URLConnection::getDefaultRequestProperty(p0);
}

void setContentHandlerFactory_test_13263(ContentHandlerFactory p0) {
    URLConnection::setContentHandlerFactory(p0);
}

void guessContentTypeFromName_test_13264(std::string p0) {
    URLConnection::guessContentTypeFromName(p0);
}