#include <string>
#include <vector>
#include <algorithm>

class Notification {
public:
    virtual ~Notification() = default;
};

class AttributeChangeNotification : public Notification {
public:
    explicit AttributeChangeNotification(const std::string& attributeName)
        : attrName(attributeName) {}

    const std::string& getAttributeName() const {
        return attrName;
    }

private:
    std::string attrName;
};

class AttributeChangeNotificationFilter {
public:
    bool isNotificationEnabled(const Notification* notification) const;
    void enableAttribute(const std::string& name);
    void disableAttribute(const std::string& name);
    void disableAllAttributes();
    std::vector<std::string>& getEnabledAttributes();
    const std::vector<std::string>& getEnabledAttributes() const;

private:
    std::vector<std::string> enabledAttributes;
};

bool AttributeChangeNotificationFilter::isNotificationEnabled(const Notification* notification) const {
    if (notification == nullptr) {
        return false;
    }

    const AttributeChangeNotification* acn =
        dynamic_cast<const AttributeChangeNotification*>(notification);
    if (acn == nullptr) {
        return false;
    }

    const std::string& attributeName = acn->getAttributeName();
    return std::find(enabledAttributes.begin(), enabledAttributes.end(), attributeName)
        != enabledAttributes.end();
}

void AttributeChangeNotificationFilter::enableAttribute(const std::string& name) {
    if (std::find(enabledAttributes.begin(), enabledAttributes.end(), name)
        == enabledAttributes.end()) {
        enabledAttributes.push_back(name);
    }
}

void AttributeChangeNotificationFilter::disableAttribute(const std::string& name) {
    auto it = std::find(enabledAttributes.begin(), enabledAttributes.end(), name);
    if (it != enabledAttributes.end()) {
        enabledAttributes.erase(it);
    }
}

void AttributeChangeNotificationFilter::disableAllAttributes() {
    enabledAttributes.clear();
}

std::vector<std::string>& AttributeChangeNotificationFilter::getEnabledAttributes() {
    return enabledAttributes;
}

const std::vector<std::string>& AttributeChangeNotificationFilter::getEnabledAttributes() const {
    return enabledAttributes;
}

void isNotificationEnabled_test_762(Notification* p0) {
    AttributeChangeNotificationFilter instance;
    instance.isNotificationEnabled(p0);
}

void enableAttribute_test_763(const std::string& p0) {
    AttributeChangeNotificationFilter instance;
    instance.enableAttribute(p0);
}

void disableAttribute_test_764(const std::string& p0) {
    AttributeChangeNotificationFilter instance;
    instance.disableAttribute(p0);
}

void disableAllAttributes_test_765() {
    AttributeChangeNotificationFilter instance;
    instance.disableAllAttributes();
}

void getEnabledAttributes_test_766() {
    AttributeChangeNotificationFilter instance;
    instance.getEnabledAttributes();
}