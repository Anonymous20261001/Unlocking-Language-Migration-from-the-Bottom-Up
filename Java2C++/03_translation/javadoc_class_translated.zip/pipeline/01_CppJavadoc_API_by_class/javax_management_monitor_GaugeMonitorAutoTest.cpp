#include <vector>

namespace java {
namespace lang {

class Number {
public:
    virtual ~Number() = default;
};

} // namespace lang
} // namespace java

namespace javax {
namespace management {

class ObjectName {
public:
    ObjectName() = default;
};

class MBeanNotificationInfo {
public:
    MBeanNotificationInfo() = default;
};

namespace monitor {

class GaugeMonitor {
public:
    GaugeMonitor() = default;

    bool getDifferenceMode() const {
        return differenceMode;
    }

    void setDifferenceMode(bool value) {
        differenceMode = value;
    }

    std::vector<MBeanNotificationInfo> getNotificationInfo() const {
        return std::vector<MBeanNotificationInfo>();
    }

    java::lang::Number* getDerivedGauge() {
        return nullptr;
    }

    java::lang::Number* getDerivedGauge(ObjectName* object) {
        return nullptr;
    }

    long long getDerivedGaugeTimeStamp() const {
        return 0;
    }

    long long getDerivedGaugeTimeStamp(ObjectName* object) const {
        return 0;
    }

    java::lang::Number* getHighThreshold() {
        return nullptr;
    }

    java::lang::Number* getLowThreshold() {
        return nullptr;
    }

    void setThresholds(java::lang::Number* highValue, java::lang::Number* lowValue) {
    }

    bool getNotifyHigh() const {
        return notifyHigh;
    }

    void setNotifyHigh(bool value) {
        notifyHigh = value;
    }

    bool getNotifyLow() const {
        return notifyLow;
    }

    void setNotifyLow(bool value) {
        notifyLow = value;
    }

    void start() {
    }

    void stop() {
    }

private:
    bool differenceMode = false;
    bool notifyHigh = false;
    bool notifyLow = false;
};

} // namespace monitor
} // namespace management
} // namespace javax

void getDifferenceMode_test_5084() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getDifferenceMode();
}

void setDifferenceMode_test_5085(bool p0) {
    javax::management::monitor::GaugeMonitor instance;
    instance.setDifferenceMode(p0);
}

void getNotificationInfo_test_5086() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getNotificationInfo();
}

void getDerivedGauge_test_5087() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getDerivedGauge();
}

void getDerivedGauge_test_5088(javax::management::ObjectName* p0) {
    javax::management::monitor::GaugeMonitor instance;
    instance.getDerivedGauge(p0);
}

void getDerivedGaugeTimeStamp_test_5089() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getDerivedGaugeTimeStamp();
}

void getDerivedGaugeTimeStamp_test_5090(javax::management::ObjectName* p0) {
    javax::management::monitor::GaugeMonitor instance;
    instance.getDerivedGaugeTimeStamp(p0);
}

void getHighThreshold_test_5091() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getHighThreshold();
}

void getLowThreshold_test_5092() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getLowThreshold();
}

void setThresholds_test_5093(java::lang::Number* p0, java::lang::Number* p1) {
    javax::management::monitor::GaugeMonitor instance;
    instance.setThresholds(p0, p1);
}

void getNotifyHigh_test_5094() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getNotifyHigh();
}

void setNotifyHigh_test_5095(bool p0) {
    javax::management::monitor::GaugeMonitor instance;
    instance.setNotifyHigh(p0);
}

void getNotifyLow_test_5096() {
    javax::management::monitor::GaugeMonitor instance;
    instance.getNotifyLow();
}

void setNotifyLow_test_5097(bool p0) {
    javax::management::monitor::GaugeMonitor instance;
    instance.setNotifyLow(p0);
}

void start_test_5098() {
    javax::management::monitor::GaugeMonitor instance;
    instance.start();
}

void stop_test_5099() {
    javax::management::monitor::GaugeMonitor instance;
    instance.stop();
}