#include <cstdint>
#include <cstddef>
#include <string>
#include <optional>
#include <stdexcept>

class Byte {
public:
    int8_t value;

    Byte() : value(0) {}
    Byte(int8_t v) : value(v) {}
    explicit Byte(const std::string& s) : value(parseByte(s)) {}

    int8_t byteValue() const { return value; }
    int16_t shortValue() const { return value; }
    int32_t intValue() const { return value; }
    int64_t longValue() const { return value; }
    float floatValue() const { return static_cast<float>(value); }
    double doubleValue() const { return static_cast<double>(value); }
    std::optional<Byte> describeConstable() const { return Byte(value); }
    int compareTo(const Byte& other) const { return compare(value, other.value); }

    static int compareUnsigned(int8_t x, int8_t y) {
        int ux = static_cast<uint8_t>(x);
        int uy = static_cast<uint8_t>(y);
        return (ux < uy) ? -1 : (ux > uy) ? 1 : 0;
    }

    static int compare(int8_t x, int8_t y) {
        return static_cast<int>(x) - static_cast<int>(y);
    }

    static Byte valueOf(const std::string& s) {
        return Byte(parseByte(s, 10));
    }

    static Byte valueOf(const std::string& s, int radix) {
        return Byte(parseByte(s, radix));
    }

    static Byte valueOf(int8_t b) {
        return Byte(b);
    }

    static int64_t toUnsignedLong(int8_t x) {
        return static_cast<uint8_t>(x);
    }

    static int32_t toUnsignedInt(int8_t x) {
        return static_cast<uint8_t>(x);
    }

    static int8_t parseByte(const std::string& s) {
        return parseByte(s, 10);
    }

    static int8_t parseByte(const std::string& s, int radix) {
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Invalid radix");
        }

        size_t i = 0;
        bool negative = false;
        if (i < s.size() && (s[i] == '+' || s[i] == '-')) {
            negative = (s[i] == '-');
            ++i;
        }

        if (i >= s.size()) {
            throw std::invalid_argument("Missing digits");
        }

        int64_t absValue = 0;
        bool any = false;
        for (; i < s.size(); ++i) {
            char c = s[i];
            int digit;
            if (c >= '0' && c <= '9') {
                digit = c - '0';
            } else if (c >= 'a' && c <= 'z') {
                digit = c - 'a' + 10;
            } else if (c >= 'A' && c <= 'Z') {
                digit = c - 'A' + 10;
            } else {
                throw std::invalid_argument("Invalid digit");
            }

            if (digit >= radix) {
                throw std::invalid_argument("Digit out of range");
            }

            absValue = absValue * radix + digit;
            any = true;
        }

        if (!any) {
            throw std::invalid_argument("Missing digits");
        }

        if (negative) {
            if (absValue > 128) {
                throw std::out_of_range("Byte out of range");
            }
            return static_cast<int8_t>(-absValue);
        } else {
            if (absValue > 127) {
                throw std::out_of_range("Byte out of range");
            }
            return static_cast<int8_t>(absValue);
        }
    }

    static Byte decode(const std::string& nm) {
        if (nm.empty()) {
            throw std::invalid_argument("Empty string");
        }

        size_t i = 0;
        bool negative = false;
        if (nm[0] == '+') {
            i = 1;
        } else if (nm[0] == '-') {
            negative = true;
            i = 1;
        }

        if (i >= nm.size()) {
            throw std::invalid_argument("Missing digits");
        }

        int radix = 10;
        size_t start = i;

        if (nm.compare(i, 2, "0x") == 0 || nm.compare(i, 2, "0X") == 0) {
            radix = 16;
            start += 2;
        } else if (nm[i] == '#') {
            radix = 16;
            start += 1;
        } else if (nm[i] == '0' && nm.size() > i + 1) {
            radix = 8;
            start += 1;
        }

        if (start >= nm.size()) {
            throw std::invalid_argument("Missing digits");
        }

        int64_t absValue = 0;
        bool any = false;
        for (size_t j = start; j < nm.size(); ++j) {
            char c = nm[j];
            int digit;
            if (c >= '0' && c <= '9') {
                digit = c - '0';
            } else if (c >= 'a' && c <= 'z') {
                digit = c - 'a' + 10;
            } else if (c >= 'A' && c <= 'Z') {
                digit = c - 'A' + 10;
            } else {
                throw std::invalid_argument("Invalid digit");
            }

            if (digit >= radix) {
                throw std::invalid_argument("Digit out of range");
            }

            absValue = absValue * radix + digit;
            any = true;
        }

        if (!any) {
            throw std::invalid_argument("Missing digits");
        }

        int64_t value = negative ? -absValue : absValue;
        if (value < -128 || value > 127) {
            throw std::out_of_range("Byte out of range");
        }

        return Byte(static_cast<int8_t>(value));
    }
};

void compareUnsigned_test_1967(int8_t p0, int8_t p1) {
    Byte::compareUnsigned(p0, p1);
}

void compareTo_test_1968(Byte p0, int8_t c0) {
    Byte instance(c0);
    instance.compareTo(p0);
}

void compare_test_1969(int8_t p0, int8_t p1) {
    Byte::compare(p0, p1);
}

void byteValue_test_1970(int8_t c0) {
    Byte instance(c0);
    instance.byteValue();
}

void shortValue_test_1971(int8_t c0) {
    Byte instance(c0);
    instance.shortValue();
}

void intValue_test_1972(int8_t c0) {
    Byte instance(c0);
    instance.intValue();
}

void longValue_test_1973(int8_t c0) {
    Byte instance(c0);
    instance.longValue();
}

void floatValue_test_1974(int8_t c0) {
    Byte instance(c0);
    instance.floatValue();
}

void doubleValue_test_1975(int8_t c0) {
    Byte instance(c0);
    instance.doubleValue();
}

void valueOf_test_1976(const std::string& p0) {
    Byte::valueOf(p0);
}

void valueOf_test_1977(const std::string& p0, int p1) {
    Byte::valueOf(p0, p1);
}

void valueOf_test_1978(int8_t p0) {
    Byte::valueOf(p0);
}

void decode_test_1979(const std::string& p0) {
    Byte::decode(p0);
}

void describeConstable_test_1980(int8_t c0) {
    Byte instance(c0);
    instance.describeConstable();
}

void toUnsignedLong_test_1981(int8_t p0) {
    Byte::toUnsignedLong(p0);
}

void toUnsignedInt_test_1982(int8_t p0) {
    Byte::toUnsignedInt(p0);
}

void parseByte_test_1983(const std::string& p0) {
    Byte::parseByte(p0);
}

void parseByte_test_1984(const std::string& p0, int p1) {
    Byte::parseByte(p0, p1);
}
