#include <string>
#include <stdexcept>

class InputEvent {
public:
    static constexpr int SHIFT_DOWN_MASK = 1 << 0;
    static constexpr int CTRL_DOWN_MASK = 1 << 1;
    static constexpr int META_DOWN_MASK = 1 << 2;
    static constexpr int ALT_DOWN_MASK = 1 << 3;
    static constexpr int ALT_GRAPH_DOWN_MASK = 1 << 4;
    static constexpr int BUTTON1_DOWN_MASK = 1 << 10;
    static constexpr int BUTTON2_DOWN_MASK = 1 << 11;
    static constexpr int BUTTON3_DOWN_MASK = 1 << 12;

    static std::string getModifiersExText(int modifiers) {
        std::string result;
        if (modifiers & META_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Meta";
        }
        if (modifiers & CTRL_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Ctrl";
        }
        if (modifiers & ALT_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Alt";
        }
        if (modifiers & SHIFT_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Shift";
        }
        if (modifiers & ALT_GRAPH_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Alt Graph";
        }
        if (modifiers & BUTTON1_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Button1";
        }
        if (modifiers & BUTTON2_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Button2";
        }
        if (modifiers & BUTTON3_DOWN_MASK) {
            if (!result.empty()) result += "+";
            result += "Button3";
        }
        return result;
    }

    static int getMaskForButton(int button) {
        if (button <= 0) {
            throw std::invalid_argument("button cannot be <= 0");
        }
        switch (button) {
            case 1:
                return BUTTON1_DOWN_MASK;
            case 2:
                return BUTTON2_DOWN_MASK;
            case 3:
                return BUTTON3_DOWN_MASK;
            default:
                throw std::invalid_argument("unsupported button");
        }
    }

private:
    InputEvent() = delete;
};

void getModifiersExText_test_5831(int p0) {
    InputEvent::getModifiersExText(p0);
}

void getMaskForButton_test_5832(int p0) {
    InputEvent::getMaskForButton(p0);
}