#include <string>
#include <vector>
#include <stdexcept>
#include <map>
#include <memory>
#include <cstddef>

// Forward declarations
class Descriptor;
class ImmutableDescriptor;

// Java Object equivalent
class Object {
public:
    virtual ~Object() = default;
    virtual bool equals(const Object& other) const { return this == &other; }
    virtual std::string toString() const { return "Object"; }
    virtual int hashCode() const { return reinterpret_cast<std::ptrdiff_t>(this); }
};

// Java String equivalent (simplified, using std::string)
using String = std::string;

// Java Descriptor interface equivalent
class Descriptor {
public:
    virtual ~Descriptor() = default;
    virtual std::vector<String> getFieldNames() const = 0;
    virtual std::vector<Object*> getFieldValues(const std::vector<String>& fieldNames) const = 0;
    virtual void setField(const String& fieldName, Object* fieldValue) = 0;
    virtual Object* getFieldValue(const String& fieldName) const = 0;
    virtual void removeField(const String& fieldName) = 0;
    virtual std::vector<String> getFields() const = 0;
    virtual bool isValid() const = 0;
    virtual void setFields(const std::vector<String>& fieldNames, const std::vector<Object*>& fieldValues) = 0;
};

// ImmutableDescriptor implementation
class ImmutableDescriptor : public Descriptor {
private:
    std::map<String, Object*> fields;

public:
    // Constructor from String array (field names)
    ImmutableDescriptor(const std::vector<String>& fieldNames) {
        for (const auto& name : fieldNames) {
            fields[name] = nullptr;
        }
    }

    // Constructor from field names and values
    ImmutableDescriptor(const std::vector<String>& fieldNames, const std::vector<Object*>& fieldValues) {
        if (fieldNames.size() != fieldValues.size()) {
            throw std::invalid_argument("Field names and values must have same length");
        }
        for (size_t i = 0; i < fieldNames.size(); ++i) {
            fields[fieldNames[i]] = fieldValues[i];
        }
    }

    // Copy constructor
    ImmutableDescriptor(const ImmutableDescriptor& other) : fields(other.fields) {}

    // Assignment operator
    ImmutableDescriptor& operator=(const ImmutableDescriptor& other) {
        if (this != &other) {
            fields = other.fields;
        }
        return *this;
    }

    // Destructor - note: we don't own the Object pointers, so no deletion
    ~ImmutableDescriptor() override = default;

    // Get all field names
    std::vector<String> getFieldNames() const override {
        std::vector<String> names;
        names.reserve(fields.size());
        for (const auto& pair : fields) {
            names.push_back(pair.first);
        }
        return names;
    }

    // Get field values for given field names
    std::vector<Object*> getFieldValues(const std::vector<String>& fieldNames) const override {
        std::vector<Object*> values;
        values.reserve(fieldNames.size());
        for (const auto& name : fieldNames) {
            auto it = fields.find(name);
            if (it != fields.end()) {
                values.push_back(it->second);
            } else {
                values.push_back(nullptr);
            }
        }
        return values;
    }

    // Set a field (throws because immutable)
    void setField(const String& fieldName, Object* fieldValue) override {
        throw std::runtime_error("ImmutableDescriptor cannot be modified");
    }

    // Get a field value
    Object* getFieldValue(const String& fieldName) const override {
        auto it = fields.find(fieldName);
        if (it != fields.end()) {
            return it->second;
        }
        return nullptr;
    }

    // Remove a field (throws because immutable)
    void removeField(const String& fieldName) override {
        throw std::runtime_error("ImmutableDescriptor cannot be modified");
    }

    // Get all fields as string array (field names)
    std::vector<String> getFields() const override {
        return getFieldNames();
    }

    // Check if descriptor is valid
    bool isValid() const override {
        // In Java, this checks that field names are valid identifiers
        // Simplified: always return true
        return true;
    }

    // Set multiple fields (throws because immutable)
    void setFields(const std::vector<String>& fieldNames, const std::vector<Object*>& fieldValues) override {
        throw std::runtime_error("ImmutableDescriptor cannot be modified");
    }

    // Static union method
    static ImmutableDescriptor union(const std::vector<Descriptor*>& descriptors) {
        std::map<String, Object*> mergedFields;
        for (const auto* desc : descriptors) {
            if (desc) {
                auto names = desc->getFieldNames();
                auto values = desc->getFieldValues(names);
                for (size_t i = 0; i < names.size(); ++i) {
                    mergedFields[names[i]] = values[i];
                }
            }
        }
        std::vector<String> names;
        std::vector<Object*> values;
        for (const auto& pair : mergedFields) {
            names.push_back(pair.first);
            values.push_back(pair.second);
        }
        return ImmutableDescriptor(names, values);
    }
};

// Test functions
void getFieldNames_test_5753(const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldNames();
}

void getFieldValues_test_5754(const std::vector<String>& p0, const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldValues(p0);
}

void setField_test_5755(const String& p0, Object* p1, const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    try {
        instance.setField(p0, p1);
    } catch (const std::runtime_error&) {
        // Expected exception for immutable descriptor
    }
}

void getFieldValue_test_5756(const String& p0, const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFieldValue(p0);
}

void removeField_test_5757(const String& p0, const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    try {
        instance.removeField(p0);
    } catch (const std::runtime_error&) {
        // Expected exception for immutable descriptor
    }
}

void getFields_test_5758(const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    instance.getFields();
}

void isValid_test_5759(const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    instance.isValid();
}

void setFields_test_5760(const std::vector<String>& p0, const std::vector<Object*>& p1, const std::vector<String>& c0) {
    ImmutableDescriptor instance(c0);
    try {
        instance.setFields(p0, p1);
    } catch (const std::runtime_error&) {
        // Expected exception for immutable descriptor
    }
}

void union_test_5761(const std::vector<Descriptor*>& p0) {
    ImmutableDescriptor::union(p0);
}