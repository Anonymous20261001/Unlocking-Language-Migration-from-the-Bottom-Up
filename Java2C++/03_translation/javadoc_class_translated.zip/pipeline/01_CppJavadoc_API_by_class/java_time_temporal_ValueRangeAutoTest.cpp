#include <cstdint>
#include <stdexcept>
#include <string>

class ValueRange {
public:
    static ValueRange of(int64_t min, int64_t max) {
        if (min > max) {
            throw std::invalid_argument("Minimum value must be less than or equal to maximum value");
        }
        return ValueRange(min, min, max, max);
    }

    static ValueRange of(int64_t min, int64_t maxSmallest, int64_t maxLargest) {
        return of(min, min, maxSmallest, maxLargest);
    }

    static ValueRange of(int64_t minSmallest, int64_t minLargest, int64_t maxSmallest, int64_t maxLargest) {
        if (minSmallest > minLargest) {
            throw std::invalid_argument("Smallest minimum value must be less than or equal to largest minimum value");
        }
        if (maxSmallest > maxLargest) {
            throw std::invalid_argument("Smallest maximum value must be less than or equal to largest maximum value");
        }
        if (minLargest > maxSmallest) {
            throw std::invalid_argument("Minimum value must be less than or equal to maximum value");
        }
        return ValueRange(minSmallest, minLargest, maxSmallest, maxLargest);
    }

private:
    int64_t minSmallest;
    int64_t minLargest;
    int64_t maxSmallest;
    int64_t maxLargest;

    ValueRange(int64_t minSmallest, int64_t minLargest, int64_t maxSmallest, int64_t maxLargest)
        : minSmallest(minSmallest), minLargest(minLargest), maxSmallest(maxSmallest), maxLargest(maxLargest) {}
};

void of_test_13306(int64_t p0, int64_t p1) {
    ValueRange::of(p0, p1);
}

void of_test_13307(int64_t p0, int64_t p1, int64_t p2, int64_t p3) {
    ValueRange::of(p0, p1, p2, p3);
}

void of_test_13308(int64_t p0, int64_t p1, int64_t p2) {
    ValueRange::of(p0, p1, p2);
}