#include <string>

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;
};

class ZoneId {
public:
    ZoneId() = default;
    explicit ZoneId(const std::string& id) : id_(id) {}
private:
    std::string id_;
};

class Clock {
public:
    Clock() = default;
};

class HijrahDate {
public:
    HijrahDate() = default;
    HijrahDate(int year, int month, int day) : year_(year), month_(month), day_(day) {}

    static HijrahDate of(int year, int month, int day) {
        return HijrahDate(year, month, day);
    }

    static HijrahDate from(const TemporalAccessor& temporal) {
        (void)temporal;
        return HijrahDate();
    }

    static HijrahDate now(const ZoneId& zone) {
        (void)zone;
        return HijrahDate();
    }

    static HijrahDate now(const Clock& clock) {
        (void)clock;
        return HijrahDate();
    }

    static HijrahDate now() {
        return HijrahDate();
    }

private:
    int year_ = 0;
    int month_ = 0;
    int day_ = 0;
};

void of_test_5350(int p0, int p1, int p2) {
    HijrahDate::of(p0, p1, p2);
}

void from_test_5351(const TemporalAccessor& p0) {
    HijrahDate::from(p0);
}

void now_test_5352(const ZoneId& p0) {
    HijrahDate::now(p0);
}

void now_test_5353(const Clock& p0) {
    HijrahDate::now(p0);
}

void now_test_5354() {
    HijrahDate::now();
}
