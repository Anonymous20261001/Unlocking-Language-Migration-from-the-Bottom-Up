#include <string>
#include <vector>

class Class {};
class List {};
class ClassLoader {};
using String = std::string;
using ClassArray = std::vector<Class>;

class MethodType {
public:
    static MethodType methodType(Class p0, List p1) { return MethodType(); }
    static MethodType methodType(Class p0) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1, const ClassArray& p2) { return MethodType(); }
    static MethodType methodType(Class p0, const ClassArray& p1) { return MethodType(); }
    static MethodType methodType(Class p0, Class p1) { return MethodType(); }
    static MethodType methodType(Class p0, MethodType p1) { return MethodType(); }
    static MethodType genericMethodType(int p0, bool p1) { return MethodType(); }
    static MethodType genericMethodType(int p0) { return MethodType(); }
    static MethodType fromMethodDescriptorString(const String& p0, ClassLoader p1) { return MethodType(); }
};

void methodType_test_8922(Class p0, List p1) {
    MethodType::methodType(p0, p1);
}

void methodType_test_8923(Class p0) {
    MethodType::methodType(p0);
}

void methodType_test_8924(Class p0, Class p1, const ClassArray& p2) {
    MethodType::methodType(p0, p1, p2);
}

void methodType_test_8925(Class p0, const ClassArray& p1) {
    MethodType::methodType(p0, p1);
}

void methodType_test_8926(Class p0, Class p1) {
    MethodType::methodType(p0, p1);
}

void methodType_test_8927(Class p0, MethodType p1) {
    MethodType::methodType(p0, p1);
}

void genericMethodType_test_8928(int p0, bool p1) {
    MethodType::genericMethodType(p0, p1);
}

void genericMethodType_test_8929(int p0) {
    MethodType::genericMethodType(p0);
}

void fromMethodDescriptorString_test_8930(const String& p0, ClassLoader p1) {
    MethodType::fromMethodDescriptorString(p0, p1);
}