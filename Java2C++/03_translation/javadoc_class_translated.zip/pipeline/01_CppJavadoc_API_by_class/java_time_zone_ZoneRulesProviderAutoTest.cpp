#include <map>
#include <set>
#include <string>
#include <vector>

class ZoneRules {
public:
    ZoneRules() = default;
};

class ZoneRulesProvider {
public:
    ZoneRulesProvider() = default;
    virtual ~ZoneRulesProvider() = default;

    static void refresh() {
        for (ZoneRulesProvider* provider : providers_) {
            provider->provideRefresh();
        }
    }

    static std::map<std::string, std::string> getVersions(const std::string& zoneId) {
        std::map<std::string, std::string> result;
        for (ZoneRulesProvider* provider : providers_) {
            std::set<std::string> ids = provider->provideZoneIds();
            if (ids.find(zoneId) != ids.end()) {
                std::map<std::string, std::string> versions = provider->provideVersions(zoneId);
                result.insert(versions.begin(), versions.end());
            }
        }
        return result;
    }

    static ZoneRules getRules(const std::string& zoneId, bool forCaching) {
        for (ZoneRulesProvider* provider : providers_) {
            std::set<std::string> ids = provider->provideZoneIds();
            if (ids.find(zoneId) != ids.end()) {
                return provider->provideRules(zoneId, forCaching);
            }
        }
        return ZoneRules();
    }

    static std::set<std::string> getAvailableZoneIds() {
        std::set<std::string> result;
        for (ZoneRulesProvider* provider : providers_) {
            std::set<std::string> ids = provider->provideZoneIds();
            result.insert(ids.begin(), ids.end());
        }
        return result;
    }

    static void registerProvider(ZoneRulesProvider& provider) {
        providers_.push_back(&provider);
    }

protected:
    virtual std::set<std::string> provideZoneIds() const {
        return std::set<std::string>();
    }

    virtual ZoneRules provideRules(const std::string& zoneId, bool forCaching) const {
        (void)zoneId;
        (void)forCaching;
        return ZoneRules();
    }

    virtual std::map<std::string, std::string> provideVersions(const std::string& zoneId) const {
        (void)zoneId;
        return std::map<std::string, std::string>();
    }

    virtual void provideRefresh() const {}

private:
    static std::vector<ZoneRulesProvider*> providers_;
};

std::vector<ZoneRulesProvider*> ZoneRulesProvider::providers_;

void refresh_test_13738() {
    ZoneRulesProvider::refresh();
}

void getVersions_test_13739(const std::string& p0) {
    ZoneRulesProvider::getVersions(p0);
}

void getRules_test_13740(const std::string& p0, bool p1) {
    ZoneRulesProvider::getRules(p0, p1);
}

void getAvailableZoneIds_test_13741() {
    ZoneRulesProvider::getAvailableZoneIds();
}

void registerProvider_test_13742(ZoneRulesProvider& p0) {
    ZoneRulesProvider::registerProvider(p0);
}