#include <memory>
#include <string>
#include <vector>

class Locale {
public:
    Locale() = default;
    Locale(const std::string& language, const std::string& country = "", const std::string& variant = "")
        : language_(language), country_(country), variant_(variant) {}

    const std::string& getLanguage() const { return language_; }
    const std::string& getCountry() const { return country_; }
    const std::string& getVariant() const { return variant_; }

private:
    std::string language_;
    std::string country_;
    std::string variant_;
};

class BreakIterator {
private:
    BreakIterator() = default;

public:
    static std::vector<Locale> getAvailableLocales() {
        std::vector<Locale> locales;
        locales.push_back(Locale("en", "US"));
        locales.push_back(Locale("fr", "FR"));
        locales.push_back(Locale("de", "DE"));
        locales.push_back(Locale("ja", "JP"));
        locales.push_back(Locale("zh", "CN"));
        return locales;
    }

    static std::unique_ptr<BreakIterator> getWordInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getWordInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getLineInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getLineInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getCharacterInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getCharacterInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getSentenceInstance() {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }

    static std::unique_ptr<BreakIterator> getSentenceInstance(const Locale&) {
        return std::unique_ptr<BreakIterator>(new BreakIterator());
    }
};

void getAvailableLocales_test_1878() {
    BreakIterator::getAvailableLocales();
}

void getWordInstance_test_1879() {
    BreakIterator::getWordInstance();
}

void getWordInstance_test_1880(Locale p0) {
    BreakIterator::getWordInstance(p0);
}

void getLineInstance_test_1881(Locale p0) {
    BreakIterator::getLineInstance(p0);
}

void getLineInstance_test_1882() {
    BreakIterator::getLineInstance();
}

void getCharacterInstance_test_1883(Locale p0) {
    BreakIterator::getCharacterInstance(p0);
}

void getCharacterInstance_test_1884() {
    BreakIterator::getCharacterInstance();
}

void getSentenceInstance_test_1885(Locale p0) {
    BreakIterator::getSentenceInstance(p0);
}

void getSentenceInstance_test_1886() {
    BreakIterator::getSentenceInstance();
}