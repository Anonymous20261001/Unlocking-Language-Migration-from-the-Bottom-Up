#include <string>

class CharSequence {
public:
    std::string value;
    CharSequence() : value() {}
    CharSequence(const std::string& s) : value(s) {}
    CharSequence(const char* s) : value(s) {}
};

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() {}
};

class DateTimeFormatter {
public:
    DateTimeFormatter() {}
};

class ZoneId {
public:
    std::string id;
    ZoneId() : id("UTC") {}
    explicit ZoneId(const std::string& s) : id(s) {}
};

class Instant {
public:
    long long seconds;
    long long nanos;
    Instant() : seconds(0), nanos(0) {}
    Instant(long long secs, long long n) : seconds(secs), nanos(n) {}
};

class Clock {
public:
    virtual ~Clock() {}
};

class LocalTime {
public:
    int hour;
    int minute;
    int second;
    int nano;

    LocalTime(int h, int m, int s, int n)
        : hour(h), minute(m), second(s), nano(n) {}

    static LocalTime of(int h, int m, int s, int n) {
        return LocalTime(h, m, s, n);
    }

    static LocalTime of(int h, int m) {
        return LocalTime(h, m, 0, 0);
    }

    static LocalTime of(int h, int m, int s) {
        return LocalTime(h, m, s, 0);
    }

    static LocalTime from(const TemporalAccessor&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime parse(const CharSequence&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime parse(const CharSequence&, const DateTimeFormatter&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime now() {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime now(const Clock&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime now(const ZoneId&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime ofInstant(const Instant&, const ZoneId&) {
        return LocalTime(0, 0, 0, 0);
    }

    static LocalTime ofNanoOfDay(long long nanoOfDay) {
        long long secs = nanoOfDay / 1000000000LL;
        int nanos = (int)(nanoOfDay % 1000000000LL);
        int h = (int)((secs / 3600) % 24);
        int m = (int)((secs % 3600) / 60);
        int s = (int)(secs % 60);
        return LocalTime(h, m, s, nanos);
    }

    static LocalTime ofSecondOfDay(long long secondOfDay) {
        int h = (int)((secondOfDay / 3600) % 24);
        int m = (int)((secondOfDay % 3600) / 60);
        int s = (int)(secondOfDay % 60);
        return LocalTime(h, m, s, 0);
    }
};

void of_test_8080(int p0, int p1, int p2, int p3) {
    LocalTime::of(p0, p1, p2, p3);
}

void of_test_8081(int p0, int p1) {
    LocalTime::of(p0, p1);
}

void of_test_8082(int p0, int p1, int p2) {
    LocalTime::of(p0, p1, p2);
}

void from_test_8083(TemporalAccessor p0) {
    LocalTime::from(p0);
}

void parse_test_8084(CharSequence p0) {
    LocalTime::parse(p0);
}

void parse_test_8085(CharSequence p0, DateTimeFormatter p1) {
    LocalTime::parse(p0, p1);
}

void now_test_8086() {
    LocalTime::now();
}

void now_test_8087(Clock p0) {
    LocalTime::now(p0);
}

void now_test_8088(ZoneId p0) {
    LocalTime::now(p0);
}

void ofInstant_test_8089(Instant p0, ZoneId p1) {
    LocalTime::ofInstant(p0, p1);
}

void ofNanoOfDay_test_8090(long long p0) {
    LocalTime::ofNanoOfDay(p0);
}

void ofSecondOfDay_test_8091(long long p0) {
    LocalTime::ofSecondOfDay(p0);
}
