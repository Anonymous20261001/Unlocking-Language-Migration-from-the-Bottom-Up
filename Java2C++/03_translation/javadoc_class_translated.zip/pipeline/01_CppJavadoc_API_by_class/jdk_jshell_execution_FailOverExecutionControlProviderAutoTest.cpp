#include <string>
#include <map>

class FailOverExecutionControlProvider {
public:
    std::string name() {
        return "failover";
    }

    std::map<std::string, std::string> defaultParameters() {
        return {};
    }
};

void name_test_4672() {
    FailOverExecutionControlProvider instance;
    instance.name();
}

void defaultParameters_test_4673() {
    FailOverExecutionControlProvider instance;
    instance.defaultParameters();
}