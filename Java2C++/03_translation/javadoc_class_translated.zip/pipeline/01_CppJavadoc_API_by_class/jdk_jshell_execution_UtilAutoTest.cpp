#include <string>

namespace com {
namespace sun {
namespace jdi {

class VirtualMachine {
 public:
  virtual ~VirtualMachine() = default;
};

} // namespace jdi
} // namespace sun
} // namespace com

namespace java {
namespace io {

class ObjectInput {
 public:
  virtual ~ObjectInput() = default;
  virtual std::string readObject() = 0;
};

class ObjectOutput {
 public:
  virtual ~ObjectOutput() = default;
  virtual void writeObject(const std::string&) = 0;
};

} // namespace io

namespace util {
namespace function {

class Consumer {
 public:
  virtual ~Consumer() = default;
  virtual void accept(const std::string&) = 0;
};

} // namespace function
} // namespace util
} // namespace java

namespace jdk {
namespace jshell {
namespace spi {

class ExecutionControl {
 public:
  virtual ~ExecutionControl() = default;
  virtual void stop() = 0;
};

} // namespace spi

namespace execution {

class Util {
 public:
  static void detectJdiExitEvent(com::sun::jdi::VirtualMachine&,
                                 const java::util::function::Consumer&) {
    // Original Java implementation registers a JDI VM death listener.
    // For the C++ translation, the event is not triggered here.
  }

  static void forwardExecutionControl(jdk::jshell::spi::ExecutionControl&,
                                      java::io::ObjectInput& in,
                                      java::io::ObjectOutput& out) {
    while (true) {
      std::string cmd = in.readObject();
      if (cmd.empty()) {
        break;
      }
      out.writeObject(cmd);
    }
  }
};

} // namespace execution
} // namespace jshell
} // namespace jdk

void detectJdiExitEvent_test_13273(com::sun::jdi::VirtualMachine& p0,
                                   const java::util::function::Consumer& p1) {
  jdk::jshell::execution::Util::detectJdiExitEvent(p0, p1);
}

void forwardExecutionControl_test_13274(jdk::jshell::spi::ExecutionControl& p0,
                                        java::io::ObjectInput& p1,
                                        java::io::ObjectOutput& p2) {
  jdk::jshell