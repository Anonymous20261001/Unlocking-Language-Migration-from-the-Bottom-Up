class JComponent {
public:
    virtual ~JComponent() = default;
};

class SynthSliderUI {
public:
    static SynthSliderUI* createUI(JComponent* component) {
        (void)component;
        return new SynthSliderUI();
    }
    virtual ~SynthSliderUI() = default;
};

void createUI_test_12334(JComponent* p0) {
    SynthSliderUI* ui = SynthSliderUI::createUI(p0);
    delete ui;
}