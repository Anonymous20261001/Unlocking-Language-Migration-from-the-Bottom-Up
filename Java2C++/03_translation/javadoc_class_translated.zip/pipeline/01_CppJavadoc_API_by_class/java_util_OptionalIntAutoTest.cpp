#include <cstddef>

class OptionalInt {
public:
    static OptionalInt of(int value) {
        return OptionalInt(value);
    }

    static OptionalInt empty() {
        return OptionalInt();
    }

    bool isPresent() const {
        return has_value;
    }

    int getAsInt() const {
        return value;
    }

private:
    OptionalInt() : has_value(false), value(0) {}
    OptionalInt(int v) : has_value(true), value(v) {}

    bool has_value;
    int value;
};

void of_test_9694(int p0) {
    OptionalInt::of(p0);
}

void empty_test_9695() {
    OptionalInt::empty();
}