class Locale {
public:
    Locale() {}
    Locale(const Locale&) = default;
    Locale& operator=(const Locale&) = default;
    ~Locale() {}
};

class Component {
public:
    Component() : lightweight_(true) {}
    virtual ~Component() {}
    bool isLightweight() const { return lightweight_; }
private:
    bool lightweight_;
};

class JComponent {
public:
    static Locale getDefaultLocale() {
        return defaultLocale;
    }

    static bool isLightweightComponent(const Component& c) {
        return c.isLightweight();
    }

    static void setDefaultLocale(const Locale& l) {
        defaultLocale = l;
    }

private:
    static Locale defaultLocale;
};

Locale JComponent::defaultLocale = Locale();

void getDefaultLocale_test_6106() {
    JComponent::getDefaultLocale();
}

void isLightweightComponent_test_6107() {
    Component p0;
    JComponent::isLightweightComponent(p0);
}

void setDefaultLocale_test_6108() {
    Locale p0;
    JComponent::setDefaultLocale(p0);
}