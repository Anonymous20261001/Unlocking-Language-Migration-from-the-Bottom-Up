#include <iostream>

class ObjectOutput {
public:
    virtual ~ObjectOutput() = default;
    virtual void close() = 0;
};

class ObjectInput {
public:
    virtual ~ObjectInput() = default;
    virtual void close() = 0;
};

class StreamingExecutionControl {
public:
    StreamingExecutionControl(ObjectOutput* output, ObjectInput* input)
        : output_(output), input_(input) {}

    void close() {
        if (output_) {
            output_->close();
        }
        if (input_) {
            input_->close();
        }
    }

private:
    ObjectOutput* output_;
    ObjectInput* input_;
};

void close_test_11512() {
    class MockObjectOutput : public ObjectOutput {
        void close() override {}
    };

    class MockObjectInput : public ObjectInput {
        void close() override {}
    };

    MockObjectOutput out;
    MockObjectInput in;
    StreamingExecutionControl instance(&out, &in);
    instance.close();
}
