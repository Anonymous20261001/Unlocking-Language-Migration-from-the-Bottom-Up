#include <string>

class Duration;

class TemporalUnit {
public:
    virtual ~TemporalUnit() = default;
    virtual Duration getDuration() const = 0;
};

class TemporalAmount {
public:
    virtual ~TemporalAmount() = default;
    virtual long long getSeconds() const = 0;
    virtual long long getNanos() const = 0;
};

class Temporal {
public:
    virtual ~Temporal() = default;
    virtual long long toEpochSecond() const = 0;
    virtual int getNano() const = 0;
};

class CharSequence {
public:
    virtual ~CharSequence() = default;
    virtual std::string toString() const = 0;
    virtual size_t length() const = 0;
    virtual char charAt(size_t index) const = 0;
};

class Duration {
public:
    static Duration of(long long amount, const TemporalUnit& unit);
    static Duration from(const TemporalAmount& amount);
    static Duration parse(const CharSequence& text);
    static Duration between(const Temporal& startInclusive, const Temporal& endExclusive);
    static Duration ofSeconds(long long seconds, long long nanoAdjustment);
    static Duration ofSeconds(long long seconds);
    static Duration ofNanos(long long nanos);
    static Duration ofDays(long long days);
    static Duration ofHours(long long hours);
    static Duration ofMinutes(long long minutes);
    static Duration ofMillis(long long millis);

    long long seconds() const { return secs_; }
    long long nanos() const { return nanos_; }

    Duration plus(const Duration& other) const {
        return Duration(secs_ + other.secs_, nanos_ + other.nanos_);
    }

    Duration multipliedBy(long long multiplicand) const {
        return Duration(secs_ * multiplicand, nanos_ * multiplicand);
    }

private:
    long long secs_;
    long long nanos_;

    Duration(long long seconds, long long nanoAdjustment);
};

inline Duration::Duration(long long seconds, long long nanoAdjustment) {
    long long extra = nanoAdjustment / 1000000000LL;
    long long rem = nanoAdjustment % 1000000000LL;
    if (rem < 0) {
        rem += 1000000000LL;
        extra -= 1;
    }
    secs_ = seconds + extra;
    nanos_ = rem;
}

inline Duration Duration::ofSeconds(long long seconds, long long nanoAdjustment) {
    return Duration(seconds, nanoAdjustment);
}

inline Duration Duration::ofSeconds(long long seconds) {
    return Duration(seconds, 0);
}

inline Duration Duration::ofNanos(long long nanos) {
    return Duration(0, nanos);
}

inline Duration Duration::ofDays(long long days) {
    return Duration(days * 86400LL, 0);
}

inline Duration Duration::ofHours(long long hours) {
    return Duration(hours * 3600LL, 0);
}

inline Duration Duration::ofMinutes(long long minutes) {
    return Duration(minutes * 60LL, 0);
}

inline Duration Duration::ofMillis(long long millis) {
    return Duration(millis / 1000LL, (millis % 1000LL) * 1000000LL);
}

inline Duration Duration::of(long long amount, const TemporalUnit& unit) {
    return unit.getDuration().multipliedBy(amount);
}

inline Duration Duration::from(const TemporalAmount& amount) {
    return Duration(amount.getSeconds(), amount.getNanos());
}

inline Duration Duration::parse(const CharSequence& text) {
    text.toString();
    return Duration(0, 0);
}

inline Duration Duration::between(const Temporal& startInclusive, const Temporal& endExclusive) {
    return Duration(
        endExclusive.toEpochSecond() - startInclusive.toEpochSecond(),
        static_cast<long long>(endExclusive.getNano()) - static_cast<long long>(startInclusive.getNano()));
}

void of_test_4406(long long p0, const TemporalUnit& p1) {
    Duration::of(p0, p1);
}

void from_test_4407(const TemporalAmount& p0) {
    Duration::from(p0);
}

void parse_test_4408(const CharSequence& p0) {
    Duration::parse(p0);
}

void between_test_4409(const Temporal& p0, const Temporal& p1) {
    Duration::between(p0, p1);
}

void ofSeconds_test_4410(long long p0, long long p1) {
    Duration::ofSeconds(p0, p1);
}

void ofSeconds_test_4411(long long p0) {
    Duration::ofSeconds(p0);
}

void ofNanos_test_4412(long long p0) {
    Duration::ofNanos(p0);
}

void ofDays_test_4413(long long p0) {
    Duration::ofDays(p0);
}

void ofHours_test_4414(long long p0) {
    Duration::ofHours(p0);
}

void ofMinutes_test_4415(long long p0) {
    Duration::ofMinutes(p0);
}

void ofMillis_test_4416(long long p0) {
    Duration::ofMillis(p0);
}
