#include <string>

class HostnameVerifier {
public:
    virtual ~HostnameVerifier() = default;
    virtual bool verify(const std::string& hostname, void* session) = 0;
};

class SSLSocketFactory {
public:
    virtual ~SSLSocketFactory() = default;
};

class HttpsURLConnection {
public:
    static HostnameVerifier* getDefaultHostnameVerifier() {
        return defaultHostnameVerifier;
    }

    static void setDefaultHostnameVerifier(HostnameVerifier* p0) {
        defaultHostnameVerifier = p0;
    }

    static SSLSocketFactory* getDefaultSSLSocketFactory() {
        return defaultSSLSocketFactory;
    }

    static void setDefaultSSLSocketFactory(SSLSocketFactory* p0) {
        defaultSSLSocketFactory = p0;
    }

private:
    static HostnameVerifier* defaultHostnameVerifier;
    static SSLSocketFactory* defaultSSLSocketFactory;
};

HostnameVerifier* HttpsURLConnection::defaultHostnameVerifier = nullptr;
SSLSocketFactory* HttpsURLConnection::defaultSSLSocketFactory = nullptr;

void getDefaultSSLSocketFactory_test_5489() {
    HttpsURLConnection::getDefaultSSLSocketFactory();
}

void setDefaultHostnameVerifier_test_5490(HostnameVerifier* p0) {
    HttpsURLConnection::setDefaultHostnameVerifier(p0);
}

void getDefaultHostnameVerifier_test_5491() {
    HttpsURLConnection::getDefaultHostnameVerifier();
}

void setDefaultSSLSocketFactory_test_5492(SSLSocketFactory* p0) {
    HttpsURLConnection::setDefaultSSLSocketFactory(p0);
}