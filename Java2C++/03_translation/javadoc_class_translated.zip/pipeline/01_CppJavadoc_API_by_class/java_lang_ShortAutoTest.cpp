#include <cstdint>
#include <cstdlib>
#include <optional>
#include <stdexcept>
#include <string>

typedef std::string String;

class Short {
public:
    explicit Short(short value) : value_(value) {}
    explicit Short(const String& s) : value_(parseShort(s)) {}

    int compareTo(const Short& another) const {
        return compare(value_, another.value_);
    }

    std::optional<Short> describeConstable() const {
        return Short(value_);
    }

    int8_t byteValue() const {
        return static_cast<int8_t>(value_);
    }

    short shortValue() const {
        return value_;
    }

    int intValue() const {
        return static_cast<int>(value_);
    }

    int64_t longValue() const {
        return static_cast<int64_t>(value_);
    }

    float floatValue() const {
        return static_cast<float>(value_);
    }

    double doubleValue() const {
        return static_cast<double>(value_);
    }

    static int compareUnsigned(short x, short y) {
        uint16_t ux = static_cast<uint16_t>(x);
        uint16_t uy = static_cast<uint16_t>(y);
        if (ux < uy) return -1;
        if (ux > uy) return 1;
        return 0;
    }

    static short reverseBytes(short i) {
        uint16_t x = static_cast<uint16_t>(i);
        uint16_t swapped = static_cast<uint16_t>((x << 8) | (x >> 8));
        return static_cast<short>(swapped);
    }

    static int compare(short x, short y) {
        return static_cast<int>(x) - static_cast<int>(y);
    }

    static Short valueOf(const String& s, int radix) {
        return Short(parseShort(s, radix));
    }

    static Short valueOf(const String& s) {
        return Short(parseShort(s));
    }

    static Short valueOf(short s) {
        return Short(s);
    }

    static Short decode(const String& nm) {
        if (nm.empty()) throw std::invalid_argument("Cannot decode empty string");

        size_t i = 0;
        bool negative = false;

        if (nm[i] == '-') {
            negative = true;
            ++i;
        } else if (nm[i] == '+') {
            ++i;
        }

        if (i >= nm.size()) throw std::invalid_argument("Cannot decode string: " + nm);

        int radix = 10;

        if (nm.compare(i, 2, "0x") == 0 || nm.compare(i, 2, "0X") == 0) {
            radix = 16;
            i += 2;
        } else if (i < nm.size() && nm[i] == '#') {
            radix = 16;
            ++i;
        } else if (i < nm.size() && nm[i] == '0' && i + 1 < nm.size()) {
            radix = 8;
            ++i;
        }

        if (i >= nm.size()) throw std::invalid_argument("Cannot decode string: " + nm);

        String digits = nm.substr(i);
        char* end = nullptr;
        long long magnitude = std::strtoll(digits.c_str(), &end, radix);

        if (end == digits.c_str() || *end != '\0') {
            throw std::invalid_argument("Cannot decode string: " + nm);
        }

        long long value = negative ? -magnitude : magnitude;

        if (value < -32768LL || value > 32767LL) {
            throw std::invalid_argument("Value out of range: " + nm);
        }

        return Short(static_cast<short>(value));
    }

    static int64_t toUnsignedLong(short x) {
        return static_cast<int64_t>(static_cast<uint16_t>(x));
    }

    static int toUnsignedInt(short x) {
        return static_cast<int>(static_cast<uint16_t>(x));
    }

    static short parseShort(const String& s) {
        return parseShort(s, 10);
    }

    static short parseShort(const String& s, int radix) {
        if (radix < 2 || radix > 36) {
            throw std::invalid_argument("Radix out of range");
        }

        if (s.empty()) {
            throw std::invalid_argument("Cannot parse empty string");
        }

        size_t i = 0;
        bool negative = false;

        if (s[i] == '-') {
            negative = true;
            ++i;
        } else if (s[i] == '+') {
            ++i;
        }

        if (i >= s.size()) {
            throw std::invalid_argument("Cannot parse string: " + s);
        }

        int64_t value = 0;

        while (i < s.size()) {
            int digit = digitValue(s[i]);
            if (digit < 0 || digit >= radix) {
                throw std::invalid_argument("Invalid digit in string: " + s);
            }

            value = value * radix + digit;

            if (negative) {
                if (-value < -32768LL) {
                    throw std::invalid_argument("Value out of range: " + s);
                }
            } else {
                if (value > 32767LL) {
                    throw std::invalid_argument("Value out of range: " + s);
                }
            }

            ++i;
        }

        return static_cast<short>(negative ? -value : value);
    }

private:
    static int digitValue(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'z') return c - 'a' + 10;
        if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
        return -1;
    }

    short value_;
};

void compareUnsigned_test_11079() {
    short p0 = 0;
    short p1 = 0;
    Short::compareUnsigned(p0, p1);
}

void reverseBytes_test_11080() {
    short p0 = 0;
    Short::reverseBytes(p0);
}

void compareTo_test_11081() {
    Short p0(0);
    short c0 = 0;
    Short instance(c0);
    instance.compareTo(p0);
}

void compare_test_11082() {
    short p0 = 0;
    short p1 = 0;
    Short::compare(p0, p1);
}

void byteValue_test_11083() {
    short c0 = 0;
    Short instance(c0);
    instance.byteValue();
}

void shortValue_test_11084() {
    short c0 = 0;
    Short instance(c0);
    instance.shortValue();
}

void intValue_test_11085() {
    short c0 = 0;
    Short instance(c0);
    instance.intValue();
}

void longValue_test_11086() {
    short c0 = 0;
    Short instance(c0);
    instance.longValue();
}

void floatValue_test_11087() {
    short c0 = 0;
    Short instance(c0);
    instance.floatValue();
}

void doubleValue_test_11088() {
    short c0 = 0;
    Short instance(c0);
    instance.doubleValue();
}

void valueOf_test_11089() {
    String p0 = "10";
    int p1 = 10;
    Short::valueOf(p0, p1);
}

void valueOf_test_11090() {
    String p0 = "10";
    Short::valueOf(p0);
}

void valueOf_test_11091() {
    short p0 = 0;
    Short::valueOf(p0);
}

void decode_test_11092() {
    String p0 = "0x10";
    Short::decode(p0);
}

void describeConstable_test_11093() {
    short c0 = 0;
    Short instance(c0);
    instance.describeConstable();
}

void toUnsignedLong_test_11094() {
    short p0 = 0;
    Short::toUnsignedLong(p0);
}

void toUnsignedInt_test_11095() {
    short p0 = 0;
    Short::toUnsignedInt(p0);
}

void parseShort_test_11096() {
    String p0 = "10";
    Short::parseShort(p0);
}

void parseShort_test_11097() {
    String p0 = "10";
    int p1 = 10;
    Short::parseShort(p0, p1);
}