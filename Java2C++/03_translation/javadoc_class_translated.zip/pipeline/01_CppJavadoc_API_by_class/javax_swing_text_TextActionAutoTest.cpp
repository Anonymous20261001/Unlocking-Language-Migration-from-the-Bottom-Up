#include <vector>
#include <string>

class Action {
public:
    static constexpr const char* NAME = "Name";

    virtual ~Action() {}

    virtual bool equals(Action* other) {
        return this == other;
    }

    virtual std::string getValue(const std::string& key) const {
        (void)key;
        return std::string();
    }
};

class TextAction : public Action {
public:
    static std::vector<Action*> augmentList(const std::vector<Action*>& list1,
                                            const std::vector<Action*>& list2) {
        std::vector<Action*> result;
        addUnique(result, list1);
        addUnique(result, list2);
        return result;
    }

private:
    static void addUnique(std::vector<Action*>& result,
                          const std::vector<Action*>& list) {
        for (Action* action : list) {
            if (action == nullptr) {
                continue;
            }
            bool duplicate = false;
            for (Action* existing : result) {
                if (existing != nullptr && existing->equals(action)) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                result.push_back(action);
            }
        }
    }
};

void augmentList_test_12543() {
    Action a1;
    Action a2;
    std::vector<Action*> p0;
    std::vector<Action*> p1;

    p0.push_back(&a1);
    p1.push_back(&a1);
    p1.push_back(&a2);

    TextAction::augmentList(p0, p1);
}