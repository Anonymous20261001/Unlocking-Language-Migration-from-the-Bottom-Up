#include <cstddef>

namespace javax {
namespace management {
namespace openmbean {

class CompositeData {
public:
    virtual ~CompositeData() = 0;
};

inline CompositeData::~CompositeData() = default;

} // namespace openmbean
} // namespace management
} // namespace javax

namespace jdk {
namespace management {
namespace jfr {

class RecordingInfo {
private:
    RecordingInfo() = default;

public:
    RecordingInfo(const RecordingInfo&) = default;
    RecordingInfo& operator=(const RecordingInfo&) = default;

    static RecordingInfo from(const javax::management::openmbean::CompositeData& data);
};

RecordingInfo RecordingInfo::from(const javax::management::openmbean::CompositeData& data) {
    // The actual conversion is not needed for this test.
    (void)data;
    return RecordingInfo();
}

} // namespace jfr
} // namespace management
} // namespace jdk

void from_test_10377(const javax::management::openmbean::CompositeData& p0) {
    jdk::management::jfr::RecordingInfo::from(p0);
}
