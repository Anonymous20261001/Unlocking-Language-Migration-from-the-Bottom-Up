namespace javax {
namespace swing {

class JComponent {
public:
    virtual ~JComponent() = default;
};

namespace plaf {

class ComponentUI {
public:
    virtual ~ComponentUI() = default;
};

namespace synth {

class SynthInternalFrameUI : public ComponentUI {
public:
    explicit SynthInternalFrameUI(JComponent& component) : component_(&component) {}

    static ComponentUI& createUI(JComponent& component) {
        return *new SynthInternalFrameUI(component);
    }

private:
    JComponent* component_;
};

} // namespace synth
} // namespace plaf
} // namespace swing
} // namespace javax

void createUI_test_12212(javax::swing::JComponent& p0) {
    javax::swing::plaf::synth::SynthInternalFrameUI::createUI(p0);
}
