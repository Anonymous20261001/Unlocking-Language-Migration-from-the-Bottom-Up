#include <string>

class Provider {
public:
    Provider() = default;
    Provider(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class XMLSignatureFactory {
public:
    static XMLSignatureFactory& getInstance(const std::string& mechanismType) {
        (void)mechanismType;
        return instance();
    }

    static XMLSignatureFactory& getInstance(const std::string& mechanismType, const Provider& provider) {
        (void)mechanismType;
        (void)provider;
        return instance();
    }

    static XMLSignatureFactory& getInstance() {
        return instance();
    }

private:
    XMLSignatureFactory() = default;
    XMLSignatureFactory(const XMLSignatureFactory&) = delete;
    XMLSignatureFactory& operator=(const XMLSignatureFactory&) = delete;

    static XMLSignatureFactory& instance() {
        static XMLSignatureFactory factory;
        return factory;
    }
};

void getInstance_test_13648(const std::string& p0) {
    XMLSignatureFactory::getInstance(p0);
}

void getInstance_test_13649(const std::string& p0, const Provider& p1) {
    XMLSignatureFactory::getInstance(p0, p1);
}

void getInstance_test_13650() {
    XMLSignatureFactory::getInstance();
}