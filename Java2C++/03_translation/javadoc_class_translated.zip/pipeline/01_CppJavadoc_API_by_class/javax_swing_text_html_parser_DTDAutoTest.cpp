#include <string>
#include <unordered_map>

class DTD {
public:
    virtual ~DTD() = default;

    static void putDTDHash(const std::string& name, DTD* dtd) {
        hashTable()[name] = dtd;
    }

    static DTD* getDTD(const std::string& name) {
        auto it = hashTable().find(name);
        return it == hashTable().end() ? nullptr : it->second;
    }

private:
    static std::unordered_map<std::string, DTD*>& hashTable() {
        static std::unordered_map<std::string, DTD*> table;
        return table;
    }
};

void putDTDHash_test_4403(const std::string& p0, DTD* p1) {
    DTD::putDTDHash(p0, p1);
}