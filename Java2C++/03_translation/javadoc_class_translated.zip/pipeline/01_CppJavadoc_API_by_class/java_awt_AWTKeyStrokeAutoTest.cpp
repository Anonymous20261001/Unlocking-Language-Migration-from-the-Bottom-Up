#include <string>

using String = std::string;

class Character {
public:
    char value;

    Character() : value(0) {}
    Character(char c) : value(c) {}

    char charValue() const {
        return value;
    }
};

class KeyEvent {
public:
    enum {
        KEY_PRESSED = 400,
        KEY_RELEASED = 401,
        KEY_TYPED = 402
    };

    int id;
    int keyCode;
    char keyChar;
    int modifiers;

    KeyEvent()
        : id(0), keyCode(0), keyChar(0), modifiers(0) {}

    KeyEvent(int id, int keyCode, char keyChar, int modifiers)
        : id(id), keyCode(keyCode), keyChar(keyChar), modifiers(modifiers) {}
};

class AWTKeyStroke {
public:
    char keyChar;
    int keyCode;
    int modifiers;
    bool onKeyRelease;

    AWTKeyStroke()
        : keyChar(0), keyCode(0), modifiers(0), onKeyRelease(false) {}

    AWTKeyStroke(char keyChar, int keyCode, int modifiers, bool onKeyRelease)
        : keyChar(keyChar), keyCode(keyCode), modifiers(modifiers), onKeyRelease(onKeyRelease) {}

    static AWTKeyStroke getAWTKeyStroke(char keyChar) {
        return AWTKeyStroke(keyChar, 0, 0, false);
    }

    static AWTKeyStroke getAWTKeyStroke(const String& s) {
        (void)s;
        return AWTKeyStroke(0, 0, 0, false);
    }

    static AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers) {
        return AWTKeyStroke(0, keyCode, modifiers, false);
    }

    static AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers, bool onKeyRelease) {
        return AWTKeyStroke(0, keyCode, modifiers, onKeyRelease);
    }

    static AWTKeyStroke getAWTKeyStroke(Character keyChar, int keyCode) {
        return AWTKeyStroke(keyChar.value, keyCode, 0, false);
    }

    static AWTKeyStroke getAWTKeyStrokeForEvent(const KeyEvent& anEvent) {
        return AWTKeyStroke(
            anEvent.keyChar,
            anEvent.keyCode,
            anEvent.modifiers,
            anEvent.id == KeyEvent::KEY_RELEASED
        );
    }
};

void getAWTKeyStroke_test_946(char p0) {
    AWTKeyStroke::getAWTKeyStroke(p0);
}

void getAWTKeyStroke_test_947(String p0) {
    AWTKeyStroke::getAWTKeyStroke(p0);
}

void getAWTKeyStroke_test_948(int p0, int p1) {
    AWTKeyStroke::getAWTKeyStroke(p0, p1);
}

void getAWTKeyStroke_test_949(int p0, int p1, bool p2) {
    AWTKeyStroke::getAWTKeyStroke(p0, p1, p2);
}

void getAWTKeyStroke_test_950(Character p0, int p1) {
    AWTKeyStroke::getAWTKeyStroke(p0, p1);
}

void getAWTKeyStrokeForEvent_test_951(KeyEvent p0) {
    AWTKeyStroke::getAWTKeyStrokeForEvent(p0);
}