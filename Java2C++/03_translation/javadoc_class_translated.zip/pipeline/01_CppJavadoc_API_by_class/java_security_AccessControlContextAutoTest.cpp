#include <vector>
#include <stdexcept>
#include <string>

class Permission {
public:
    virtual ~Permission() = default;
    virtual bool implies(const Permission&) const { return false; }
};

class ProtectionDomain {
public:
    virtual ~ProtectionDomain() = default;
};

class DomainCombiner {
public:
    virtual ~DomainCombiner() = default;
};

class AccessControlException : public std::runtime_error {
public:
    explicit AccessControlException(const std::string& message)
        : std::runtime_error(message) {}
};

class AccessControlContext {
public:
    AccessControlContext(const std::vector<ProtectionDomain*>& context)
        : domains(context) {}

    DomainCombiner* getDomainCombiner() const {
        return nullptr;
    }

    void checkPermission(Permission* perm) const {
        if (perm == nullptr) {
            throw std::invalid_argument("Null permission");
        }
    }

private:
    std::vector<ProtectionDomain*> domains;
};

void getDomainCombiner_test_25(std::vector<ProtectionDomain*> c0) {
    AccessControlContext instance(c0);
    instance.getDomainCombiner();
}

void checkPermission_test_26(Permission* p0, std::vector<ProtectionDomain*> c0) {
    AccessControlContext instance(c0);
    instance.checkPermission(p0);
}