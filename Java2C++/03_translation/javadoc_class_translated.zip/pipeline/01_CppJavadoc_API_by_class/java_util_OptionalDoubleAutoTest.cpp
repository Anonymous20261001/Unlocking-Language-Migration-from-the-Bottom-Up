class OptionalDouble {
private:
    bool present;
    double value;

    OptionalDouble() : present(false), value(0.0) {}
    OptionalDouble(double v) : present(true), value(v) {}

public:
    static OptionalDouble of(double v) {
        return OptionalDouble(v);
    }

    static OptionalDouble empty() {
        return OptionalDouble();
    }

    bool isPresent() const {
        return present;
    }

    double getAsDouble() const {
        return value;
    }
};

void of_test_9692(double p0) {
    OptionalDouble::of(p0);
}

void empty_test_9693() {
    OptionalDouble::empty();
}