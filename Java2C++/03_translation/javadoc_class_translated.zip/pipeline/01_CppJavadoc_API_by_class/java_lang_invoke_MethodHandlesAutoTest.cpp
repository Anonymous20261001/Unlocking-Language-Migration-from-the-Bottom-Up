#include <vector>

class Object {};
class Class {};
class MethodHandle {};
class MethodType {};
class ByteOrder {};
class List {};

class VarHandle {
public:
  enum class AccessMode {
    GET,
    SET,
    GET_AND_SET,
    GET_AND_ADD,
    GET_AND_BITWISE_OR,
    GET_AND_BITWISE_AND,
    GET_AND_BITWISE_XOR,
    COMPARE_AND_SET,
    COMPARE_AND_EXCHANGE,
    COMPARE_AND_EXCHANGE_ACQUIRE,
    COMPARE_AND_EXCHANGE_RELEASE,
    WEAK_COMPARE_AND_SET_PLAIN,
    WEAK_COMPARE_AND_SET,
    WEAK_COMPARE_AND_SET_ACQUIRE,
    WEAK_COMPARE_AND_SET_RELEASE
  };
};

class MethodHandles {
public:
  class Lookup {};

  static MethodHandle throwException(Class, Class) { return {}; }
  static Lookup lookup() { return {}; }
  static MethodHandle empty(MethodType) { return {}; }
  static MethodHandle constant(Class, Object) { return {}; }
  static MethodHandle identity(Class) { return {}; }
  static MethodHandle spreadInvoker(MethodType, int) { return {}; }
  static MethodHandle arrayLength(Class) { return {}; }
  static MethodHandle varHandleInvoker(VarHandle::AccessMode, MethodType) { return {}; }
  static Lookup publicLookup() { return {}; }
  static MethodHandle tryFinally(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle loop(std::vector<std::vector<MethodHandle>>) { return {}; }
  static MethodHandle tableSwitch(MethodHandle, std::vector<MethodHandle>) { return {}; }
  static MethodHandle arrayConstructor(Class) { return {}; }
  static MethodHandle exactInvoker(MethodType) { return {}; }
  static MethodHandle foldArguments(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle foldArguments(MethodHandle, int, MethodHandle) { return {}; }
  static MethodHandle invoker(MethodType) { return {}; }
  static Object reflectAs(Class, MethodHandle) { return {}; }
  static MethodHandle zero(Class) { return {}; }
  static MethodHandle dropArgumentsToMatch(MethodHandle, int, List, int) { return {}; }
  static MethodHandle dropArguments(MethodHandle, int, List) { return {}; }
  static MethodHandle dropArguments(MethodHandle, int, std::vector<Class>) { return {}; }
  static MethodHandle countedLoop(MethodHandle, MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle countedLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle permuteArguments(MethodHandle, MethodType, std::vector<int>) { return {}; }
  static VarHandle filterValue(VarHandle, MethodHandle, MethodHandle) { return {}; }
  static VarHandle filterCoordinates(VarHandle, int, std::vector<MethodHandle>) { return {}; }
  static VarHandle insertCoordinates(VarHandle, int, std::vector<Object>) { return {}; }
  static VarHandle permuteCoordinates(VarHandle, List, std::vector<int>) { return {}; }
  static VarHandle collectCoordinates(VarHandle, int, MethodHandle) { return {}; }
  static VarHandle dropCoordinates(VarHandle, int, std::vector<Class>) { return {}; }
  static MethodHandle arrayElementGetter(Class) { return {}; }
  static MethodHandle arrayElementSetter(Class) { return {}; }
  static VarHandle arrayElementVarHandle(Class) { return {}; }
  static VarHandle byteArrayViewVarHandle(Class, ByteOrder) { return {}; }
  static VarHandle byteBufferViewVarHandle(Class, ByteOrder) { return {}; }
  static MethodHandle varHandleExactInvoker(VarHandle::AccessMode, MethodType) { return {}; }
  static MethodHandle explicitCastArguments(MethodHandle, MethodType) { return {}; }
  static MethodHandle insertArguments(MethodHandle, int, std::vector<Object>) { return {}; }
  static MethodHandle dropReturn(MethodHandle) { return {}; }
  static MethodHandle filterArguments(MethodHandle, int, std::vector<MethodHandle>) { return {}; }
  static MethodHandle collectArguments(MethodHandle, int, MethodHandle) { return {}; }
  static MethodHandle filterReturnValue(MethodHandle, MethodHandle) { return {}; }
  static MethodHandle guardWithTest(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle catchException(MethodHandle, Class, MethodHandle) { return {}; }
  static MethodHandle whileLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle doWhileLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
  static MethodHandle iteratedLoop(MethodHandle, MethodHandle, MethodHandle) { return {}; }
};

void throwException_test_8874(Class p0, Class p1) {
  MethodHandles::throwException(p0, p1);
}

void lookup_test_8875() {
  MethodHandles::lookup();
}

void empty_test_8876(MethodType p0) {
  MethodHandles::empty(p0);
}

void constant_test_8877(Class p0, Object p1) {
  MethodHandles::constant(p0, p1);
}

void identity_test_8878(Class p0) {
  MethodHandles::identity(p0);
}

void spreadInvoker_test_8879(MethodType p0, int p1) {
  MethodHandles::spreadInvoker(p0, p1);
}

void arrayLength_test_8880(Class p0) {
  MethodHandles::arrayLength(p0);
}

void varHandleInvoker_test_8881(VarHandle::AccessMode p0, MethodType p1) {
  MethodHandles::varHandleInvoker(p0, p1);
}

void publicLookup_test_8882() {
  MethodHandles::publicLookup();
}

void tryFinally_test_8883(MethodHandle p0, MethodHandle p1) {
  MethodHandles::tryFinally(p0, p1);
}

void loop_test_8884(std::vector<std::vector<MethodHandle>> p0) {
  MethodHandles::loop(p0);
}

void tableSwitch_test_8885(MethodHandle p0, std::vector<MethodHandle> p1) {
  MethodHandles::tableSwitch(p0, p1);
}

void arrayConstructor_test_8886(Class p0) {
  MethodHandles::arrayConstructor(p0);
}

void exactInvoker_test_8887(MethodType p0) {
  MethodHandles::exactInvoker(p0);
}

void foldArguments_test_8888(MethodHandle p0, MethodHandle p1) {
  MethodHandles::foldArguments(p0, p1);
}

void foldArguments_test_8889(MethodHandle p0, int p1, MethodHandle p2) {
  MethodHandles::foldArguments(p0, p1, p2);
}

void invoker_test_8890(MethodType p0) {
  MethodHandles::invoker(p0);
}

void reflectAs_test_8891(Class p0, MethodHandle p1) {
  MethodHandles::reflectAs(p0, p1);
}

void zero_test_8892(Class p0) {
  MethodHandles::zero(p0);
}

void dropArgumentsToMatch_test_8893(MethodHandle p0, int p1, List p2, int p3) {
  MethodHandles::dropArgumentsToMatch(p0, p1, p2, p3);
}

void dropArguments_test_8894(MethodHandle p0, int p1, List p2) {
  MethodHandles::dropArguments(p0, p1, p2);
}

void dropArguments_test_8895(MethodHandle p0, int p1, std::vector<Class> p2) {
  MethodHandles::dropArguments(p0, p1, p2);
}

void countedLoop_test_8896(MethodHandle p0, MethodHandle p1, MethodHandle p2, MethodHandle p3) {
  MethodHandles::countedLoop(p0, p1, p2, p3);
}

void countedLoop_test_8897(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::countedLoop(p0, p1, p2);
}

void permuteArguments_test_8898(MethodHandle p0, MethodType p1, std::vector<int> p2) {
  MethodHandles::permuteArguments(p0, p1, p2);
}

void filterValue_test_8899(VarHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::filterValue(p0, p1, p2);
}

void filterCoordinates_test_8900(VarHandle p0, int p1, std::vector<MethodHandle> p2) {
  MethodHandles::filterCoordinates(p0, p1, p2);
}

void insertCoordinates_test_8901(VarHandle p0, int p1, std::vector<Object> p2) {
  MethodHandles::insertCoordinates(p0, p1, p2);
}

void permuteCoordinates_test_8902(VarHandle p0, List p1, std::vector<int> p2) {
  MethodHandles::permuteCoordinates(p0, p1, p2);
}

void collectCoordinates_test_8903(VarHandle p0, int p1, MethodHandle p2) {
  MethodHandles::collectCoordinates(p0, p1, p2);
}

void dropCoordinates_test_8904(VarHandle p0, int p1, std::vector<Class> p2) {
  MethodHandles::dropCoordinates(p0, p1, p2);
}

void arrayElementGetter_test_8905(Class p0) {
  MethodHandles::arrayElementGetter(p0);
}

void arrayElementSetter_test_8906(Class p0) {
  MethodHandles::arrayElementSetter(p0);
}

void arrayElementVarHandle_test_8907(Class p0) {
  MethodHandles::arrayElementVarHandle(p0);
}

void byteArrayViewVarHandle_test_8908(Class p0, ByteOrder p1) {
  MethodHandles::byteArrayViewVarHandle(p0, p1);
}

void byteBufferViewVarHandle_test_8909(Class p0, ByteOrder p1) {
  MethodHandles::byteBufferViewVarHandle(p0, p1);
}

void varHandleExactInvoker_test_8910(VarHandle::AccessMode p0, MethodType p1) {
  MethodHandles::varHandleExactInvoker(p0, p1);
}

void explicitCastArguments_test_8911(MethodHandle p0, MethodType p1) {
  MethodHandles::explicitCastArguments(p0, p1);
}

void insertArguments_test_8912(MethodHandle p0, int p1, std::vector<Object> p2) {
  MethodHandles::insertArguments(p0, p1, p2);
}

void dropReturn_test_8913(MethodHandle p0) {
  MethodHandles::dropReturn(p0);
}

void filterArguments_test_8914(MethodHandle p0, int p1, std::vector<MethodHandle> p2) {
  MethodHandles::filterArguments(p0, p1, p2);
}

void collectArguments_test_8915(MethodHandle p0, int p1, MethodHandle p2) {
  MethodHandles::collectArguments(p0, p1, p2);
}

void filterReturnValue_test_8916(MethodHandle p0, MethodHandle p1) {
  MethodHandles::filterReturnValue(p0, p1);
}

void guardWithTest_test_8917(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::guardWithTest(p0, p1, p2);
}

void catchException_test_8918(MethodHandle p0, Class p1, MethodHandle p2) {
  MethodHandles::catchException(p0, p1, p2);
}

void whileLoop_test_8919(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::whileLoop(p0, p1, p2);
}

void doWhileLoop_test_8920(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::doWhileLoop(p0, p1, p2);
}

void iteratedLoop_test_8921(MethodHandle p0, MethodHandle p1, MethodHandle p2) {
  MethodHandles::iteratedLoop(p0, p1, p2);
}