#include <cstddef>
#include <vector>

// EventListener marker interface
class EventListener {
public:
    virtual ~EventListener() = default;
};

// Listener interfaces
class ActionListener : public EventListener { public: ~ActionListener() override = default; };
class AdjustmentListener : public EventListener { public: ~AdjustmentListener() override = default; };
class ComponentListener : public EventListener { public: ~ComponentListener() override = default; };
class ContainerListener : public EventListener { public: ~ContainerListener() override = default; };
class FocusListener : public EventListener { public: ~FocusListener() override = default; };
class HierarchyBoundsListener : public EventListener { public: ~HierarchyBoundsListener() override = default; };
class HierarchyListener : public EventListener { public: ~HierarchyListener() override = default; };
class InputMethodListener : public EventListener { public: ~InputMethodListener() override = default; };
class ItemListener : public EventListener { public: ~ItemListener() override = default; };
class KeyListener : public EventListener { public: ~KeyListener() override = default; };
class MouseListener : public EventListener { public: ~MouseListener() override = default; };
class MouseMotionListener : public EventListener { public: ~MouseMotionListener() override = default; };
class MouseWheelListener : public EventListener { public: ~MouseWheelListener() override = default; };
class TextListener : public EventListener { public: ~TextListener() override = default; };
class WindowFocusListener : public EventListener { public: ~WindowFocusListener() override = default; };
class WindowListener : public EventListener { public: ~WindowListener() override = default; };
class WindowStateListener : public EventListener { public: ~WindowStateListener() override = default; };

// Minimal equivalent of java.lang.Class
class Class {
public:
    Class() = default;
};

// AWTEventMulticaster equivalent
class AWTEventMulticaster {
public:
    template<typename L>
    static L* add(L* a, L* b) {
        if (a == nullptr) return b;
        if (b == nullptr) return a;
        return a;
    }

    template<typename L>
    static L* remove(L* a, L* b) {
        if (a == nullptr || b == nullptr) return a;
        if (a == b) return nullptr;
        return a;
    }

    static std::vector<EventListener*> getListeners(EventListener* l, Class /*p1*/) {
        if (l == nullptr) return {};
        return {l};
    }
};

// Test functions
void getListeners_test_911(EventListener* p0, Class p1) {
    AWTEventMulticaster::getListeners(p0, p1);
}

void remove_test_912(MouseMotionListener* p0, MouseMotionListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_913(HierarchyListener* p0, HierarchyListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_914(WindowListener* p0, WindowListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_915(MouseListener* p0, MouseListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_916(KeyListener* p0, KeyListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_917(FocusListener* p0, FocusListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_918(InputMethodListener* p0, InputMethodListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_919(TextListener* p0, TextListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_920(AdjustmentListener* p0, AdjustmentListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_921(ItemListener* p0, ItemListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_922(ActionListener* p0, ActionListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_923(WindowFocusListener* p0, WindowFocusListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_924(WindowStateListener* p0, WindowStateListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_925(MouseWheelListener* p0, MouseWheelListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_926(ContainerListener* p0, ContainerListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_927(ComponentListener* p0, ComponentListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void remove_test_928(HierarchyBoundsListener* p0, HierarchyBoundsListener* p1) {
    AWTEventMulticaster::remove(p0, p1);
}

void add_test_929(ComponentListener* p0, ComponentListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_930(ContainerListener* p0, ContainerListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_931(KeyListener* p0, KeyListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_932(FocusListener* p0, FocusListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_933(MouseListener* p0, MouseListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_934(MouseMotionListener* p0, MouseMotionListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_935(TextListener* p0, TextListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_936(AdjustmentListener* p0, AdjustmentListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_937(ItemListener* p0, ItemListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_938(ActionListener* p0, ActionListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_939(WindowFocusListener* p0, WindowFocusListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_940(WindowStateListener* p0, WindowStateListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_941(WindowListener* p0, WindowListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_942(MouseWheelListener* p0, MouseWheelListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_943(HierarchyBoundsListener* p0, HierarchyBoundsListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_944(HierarchyListener* p0, HierarchyListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}

void add_test_945(InputMethodListener* p0, InputMethodListener* p1) {
    AWTEventMulticaster::add(p0, p1);
}