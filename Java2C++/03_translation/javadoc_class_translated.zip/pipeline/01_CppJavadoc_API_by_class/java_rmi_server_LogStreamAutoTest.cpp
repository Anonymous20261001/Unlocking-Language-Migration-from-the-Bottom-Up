#include <string>
#include <iostream>

class PrintStream {
public:
    PrintStream() {}
    virtual ~PrintStream() {}
    virtual void print(const std::string& s) { std::cout << s; }
    virtual void println(const std::string& s) { std::cout << s << std::endl; }
};

class LogStream : public PrintStream {
public:
    static const int SILENT = 0;
    static const int BRIEF = 1;
    static const int VERBOSE = 2;

    static LogStream* getDefaultStream() {
        static LogStream instance;
        return &instance;
    }

    static void setDefaultStream(PrintStream& newDefault) {
        s_defaultOutput = &newDefault;
    }

    static int parseLevel(const std::string& level) {
        if (level == "SILENT") return SILENT;
        if (level == "BRIEF") return BRIEF;
        if (level == "VERBOSE") return VERBOSE;
        return BRIEF;
    }

    static LogStream* log(const std::string& name) {
        (void)name;
        return getDefaultStream();
    }

private:
    static PrintStream* s_defaultOutput;
    LogStream() : PrintStream() {}
};

PrintStream* LogStream::s_defaultOutput = nullptr;

void getDefaultStream_test_8139() {
    LogStream::getDefaultStream();
}

void setDefaultStream_test_8140() {
    PrintStream p0;
    LogStream::setDefaultStream(p0);
}

void parseLevel_test_8141() {
    std::string p0 = "BRIEF";
    LogStream::parseLevel(p0);
}

void log_test_8142() {
    std::string p0 = "test";
    LogStream::log(p0);
}
