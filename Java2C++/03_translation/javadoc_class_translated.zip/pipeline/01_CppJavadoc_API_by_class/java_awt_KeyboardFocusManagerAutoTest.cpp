#include <cstddef>

class KeyboardFocusManager {
public:
    KeyboardFocusManager() = default;
    virtual ~KeyboardFocusManager() = default;

    static void setCurrentKeyboardFocusManager(KeyboardFocusManager* focusManager) {
        current_ = focusManager;
    }

    static KeyboardFocusManager* getCurrentKeyboardFocusManager() {
        return current_;
    }

private:
    static KeyboardFocusManager* current_;
};

KeyboardFocusManager* KeyboardFocusManager::current_ = nullptr;

void setCurrentKeyboardFocusManager_test_7611(KeyboardFocusManager* p0) {
    KeyboardFocusManager::setCurrentKeyboardFocusManager(p0);
}

void getCurrentKeyboardFocusManager_test_7612() {
    KeyboardFocusManager::getCurrentKeyboardFocusManager();
}