#include <functional>
#include <utility>

enum class DayOfWeek {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY
};

class Temporal {
public:
    Temporal() = default;
    Temporal(const Temporal&) = default;
    Temporal& operator=(const Temporal&) = default;
};

class TemporalAdjuster {
public:
    using FunctionType = std::function<Temporal(const Temporal&)>;

    explicit TemporalAdjuster(FunctionType function = [](const Temporal& t) { return t; })
        : function_(std::move(function)) {}

    Temporal adjustInto(const Temporal& temporal) const {
        return function_(temporal);
    }

private:
    FunctionType function_;
};

using UnaryOperator = std::function<Temporal(const Temporal&)>;

class TemporalAdjusters {
public:
    static TemporalAdjuster dayOfWeekInMonth(int ordinal, DayOfWeek dayOfWeek) {
        (void)ordinal;
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster ofDateAdjuster(UnaryOperator function) {
        return TemporalAdjuster([function](const Temporal& t) { return function(t); });
    }

    static TemporalAdjuster firstDayOfMonth() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster firstDayOfNextMonth() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster lastDayOfYear() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster firstDayOfNextYear() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster firstInMonth(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster lastInMonth(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster next(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster previous(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster firstDayOfYear() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster lastDayOfMonth() {
        return TemporalAdjuster();
    }

    static TemporalAdjuster nextOrSame(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }

    static TemporalAdjuster previousOrSame(DayOfWeek dayOfWeek) {
        (void)dayOfWeek;
        return TemporalAdjuster();
    }
};

void dayOfWeekInMonth_test_12520(int p0, DayOfWeek p1) {
    TemporalAdjusters::dayOfWeekInMonth(p0, p1);
}

void ofDateAdjuster_test_12521(UnaryOperator p0) {
    TemporalAdjusters::ofDateAdjuster(p0);
}

void firstDayOfMonth_test_12522() {
    TemporalAdjusters::firstDayOfMonth();
}

void firstDayOfNextMonth_test_12523() {
    TemporalAdjusters::firstDayOfNextMonth();
}

void lastDayOfYear_test_12524() {
    TemporalAdjusters::lastDayOfYear();
}

void firstDayOfNextYear_test_12525() {
    TemporalAdjusters::firstDayOfNextYear();
}

void firstInMonth_test_12526(DayOfWeek p0) {
    TemporalAdjusters::firstInMonth(p0);
}

void lastInMonth_test_12527(DayOfWeek p0) {
    TemporalAdjusters::lastInMonth(p0);
}

void next_test_12528(DayOfWeek p0) {
    TemporalAdjusters::next(p0);
}

void previous_test_12529(DayOfWeek p0) {
    TemporalAdjusters::previous(p0);
}

void firstDayOfYear_test_12530() {
    TemporalAdjusters::firstDayOfYear();
}

void lastDayOfMonth_test_12531() {
    TemporalAdjusters::lastDayOfMonth();
}

void nextOrSame_test_12532(DayOfWeek p0) {
    TemporalAdjusters::nextOrSame(p0);
}

void previousOrSame_test_12533(DayOfWeek p0) {
    TemporalAdjusters::previousOrSame(p0);
}