#include <cstddef>

class Object {
public:
    virtual ~Object() {}
};

class Runnable {
public:
    virtual ~Runnable() {}
    virtual void run() = 0;
};

class Callable {
public:
    virtual ~Callable() {}
    virtual Object* call() = 0;
};

class ForkJoinPool {};

class ForkJoinTask;

class Collection {};

class ForkJoinTask {
public:
    static ForkJoinTask* adapt(Runnable* r, Object* result) {
        static ForkJoinTask dummy;
        (void)r;
        (void)result;
        return &dummy;
    }

    static ForkJoinTask* adapt(Callable* c) {
        static ForkJoinTask dummy;
        (void)c;
        return &dummy;
    }

    static ForkJoinTask* adapt(Runnable* r) {
        static ForkJoinTask dummy;
        (void)r;
        return &dummy;
    }

    static ForkJoinTask* adaptInterruptible(Runnable* r) {
        static ForkJoinTask dummy;
        (void)r;
        return &dummy;
    }

    static ForkJoinTask* adaptInterruptible(Runnable* r, Object* result) {
        static ForkJoinTask dummy;
        (void)r;
        (void)result;
        return &dummy;
    }

    static ForkJoinTask* adaptInterruptible(Callable* c) {
        static ForkJoinTask dummy;
        (void)c;
        return &dummy;
    }

    static int getQueuedTaskCount() {
        return 0;
    }

    static ForkJoinPool* getPool() {
        return nullptr;
    }

    static void invokeAll(Collection* tasks) {
        (void)tasks;
    }

    static void invokeAll(ForkJoinTask* t1, ForkJoinTask* t2) {
        (void)t1;
        (void)t2;
    }

    static void invokeAll(ForkJoinTask** tasks) {
        (void)tasks;
    }

    static int getSurplusQueuedTaskCount() {
        return 0;
    }

    static void helpQuiesce() {
    }

    static bool inForkJoinPool() {
        return false;
    }
};

class TestRunnable : public Runnable {
public:
    void run() override {}
};

class TestCallable : public Callable {
public:
    Object* call() override { return nullptr; }
};

void adapt_test_5019() {
    TestRunnable r;
    Object result;
    ForkJoinTask::adapt(&r, &result);
}

void adapt_test_5020() {
    TestCallable c;
    ForkJoinTask::adapt(&c);
}

void adapt_test_5021() {
    TestRunnable r;
    ForkJoinTask::adapt(&r);
}

void getQueuedTaskCount_test_5022() {
    ForkJoinTask::getQueuedTaskCount();
}

void getPool_test_5023() {
    ForkJoinTask::getPool();
}

void invokeAll_test_5024() {
    Collection tasks;
    ForkJoinTask::invokeAll(&tasks);
}

void invokeAll_test_5025() {
    ForkJoinTask t1;
    ForkJoinTask t2;
    ForkJoinTask::invokeAll(&t1, &t2);
}

void invokeAll_test_5026() {
    ForkJoinTask t1;
    ForkJoinTask t2;
    ForkJoinTask* tasks[] = { &t1, &t2 };
    ForkJoinTask::invokeAll(tasks);
}

void getSurplusQueuedTaskCount_test_5027() {
    ForkJoinTask::getSurplusQueuedTaskCount();
}

void helpQuiesce_test_5028() {
    ForkJoinTask::helpQuiesce();
}

void inForkJoinPool_test_5029() {
    ForkJoinTask::inForkJoinPool();
}

void adaptInterruptible_test_5030() {
    TestRunnable r;
    ForkJoinTask::adaptInterruptible(&r);
}

void adaptInterruptible_test_5031() {
    TestRunnable r;
    Object result;
    ForkJoinTask::adaptInterruptible(&r, &result);
}

void adaptInterruptible_test_5032() {
    TestCallable c;
    ForkJoinTask::adaptInterruptible(&c);
}