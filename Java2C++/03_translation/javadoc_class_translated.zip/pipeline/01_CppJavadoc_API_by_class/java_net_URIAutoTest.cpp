#include <string>

class URI {
public:
    explicit URI(const std::string& uri) : value_(uri) {}

    static URI create(const std::string& uri) {
        return URI(uri);
    }

private:
    std::string value_;
};

void create_test_13237(const std::string& p0) {
    URI::create(p0);
}