#include <iostream>
#include <memory>

class InputStream {
public:
    virtual ~InputStream() = default;

    virtual int read() {
        return -1;
    }

    virtual int available() {
        return 0;
    }

    virtual void close() {
        // no-op
    }

    static InputStream nullInputStream() {
        class NullInputStream : public InputStream {
            // Null input stream has no data and does nothing.
        };
        return NullInputStream();
    }

protected:
    InputStream() = default;
    InputStream(const InputStream&) = default;
    InputStream& operator=(const InputStream&) = default;
};

void nullInputStream_test_5854() {
    InputStream::nullInputStream();
}