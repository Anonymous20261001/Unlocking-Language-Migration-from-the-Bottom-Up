#include <string>

class CertPathValidator {
public:
    static std::string getDefaultType() {
        return "PKIX";
    }
};

void getDefaultType_test_2101() {
    CertPathValidator::getDefaultType();
}