#include <cstdlib>

class XPathFactory {
public:
    XPathFactory() = default;

    static XPathFactory newDefaultInstance() {
        return XPathFactory();
    }

    static XPathFactory newInstance() {
        return XPathFactory();
    }
};

void newDefaultInstance_test_13657() {
    XPathFactory::newDefaultInstance();
}

void newInstance_test_13658() {
    XPathFactory::newInstance();
}