#include <string>
#include <vector>
#include <algorithm>

class Notification {
private:
    std::string type;

public:
    Notification() : type("") {}
    Notification(const std::string& type) : type(type) {}

    std::string getType() const {
        return type;
    }
};

class NotificationFilterSupport {
private:
    std::vector<std::string> enabledTypes;

public:
    void enableType(const std::string& prefix) {
        if (std::find(enabledTypes.begin(), enabledTypes.end(), prefix) == enabledTypes.end()) {
            enabledTypes.push_back(prefix);
        }
    }

    std::vector<std::string> getEnabledTypes() const {
        return enabledTypes;
    }

    void disableType(const std::string& prefix) {
        auto it = std::find(enabledTypes.begin(), enabledTypes.end(), prefix);
        if (it != enabledTypes.end()) {
            enabledTypes.erase(it);
        }
    }

    void disableAllTypes() {
        enabledTypes.clear();
    }

    bool isNotificationEnabled(const Notification& notification) const {
        const std::string& type = notification.getType();
        for (const auto& prefix : enabledTypes) {
            if (type.compare(0, prefix.length(), prefix) == 0) {
                return true;
            }
        }
        return false;
    }
};

void enableType_test_9547() {
    NotificationFilterSupport instance;
    std::string p0 = "prefix";
    instance.enableType(p0);
}

void getEnabledTypes_test_9548() {
    NotificationFilterSupport instance;
    (void)instance.getEnabledTypes();
}

void disableType_test_9549() {
    NotificationFilterSupport instance;
    std::string p0 = "prefix";
    instance.disableType(p0);
}

void disableAllTypes_test_9550() {
    NotificationFilterSupport instance;
    instance.disableAllTypes();
}

void isNotificationEnabled_test_9551() {
    NotificationFilterSupport instance;
    Notification p0("test.type");
    (void)instance.isNotificationEnabled(p0);
}
