#include <cmath>

class Point2D {
public:
    static double distanceSq(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return dx * dx + dy * dy;
    }

    static double distance(double x1, double y1, double x2, double y2) {
        return std::sqrt(distanceSq(x1, y1, x2, y2));
    }
};

void distanceSq_test_9956(double p0, double p1, double p2, double p3) {
    Point2D::distanceSq(p0, p1, p2, p3);
}

void distance_test_9957(double p0, double p1, double p2, double p3) {
    Point2D::distance(p0, p1, p2, p3);
}