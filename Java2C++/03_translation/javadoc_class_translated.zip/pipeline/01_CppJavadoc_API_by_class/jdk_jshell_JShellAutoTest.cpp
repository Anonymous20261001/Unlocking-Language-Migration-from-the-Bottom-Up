#include <cstddef>

class JShell {
public:
    JShell() = default;

    class Builder {
    public:
        Builder() = default;
    };

    static Builder builder() {
        return Builder();
    }

    static JShell create() {
        return JShell();
    }
};

void builder_test_6941() {
    JShell::builder();
}

void create_test_6942() {
    JShell::create();
}