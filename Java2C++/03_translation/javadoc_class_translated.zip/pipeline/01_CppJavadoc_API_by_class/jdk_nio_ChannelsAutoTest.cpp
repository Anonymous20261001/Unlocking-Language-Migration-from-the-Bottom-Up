class FileDescriptor {
public:
    FileDescriptor() : fd_(-1) {}
    explicit FileDescriptor(int fd) : fd_(fd) {}
    int getFD() const { return fd_; }
private:
    int fd_;
};

class Channels {
public:
    class SelectableChannelCloser {
    public:
        virtual ~SelectableChannelCloser() = default;
        virtual void close() = 0;
        virtual void implCloseSelectableChannel() = 0;
    };

    static void readWriteSelectableChannel(FileDescriptor& fd, SelectableChannelCloser& closer) {
        (void)fd;
        (void)closer;
    }
};

class TestSelectableChannelCloser : public Channels::SelectableChannelCloser {
public:
    void close() override {}
    void implCloseSelectableChannel() override {}
};

void readWriteSelectableChannel_test_2124() {
    FileDescriptor fd;
    TestSelectableChannelCloser closer;
    Channels::readWriteSelectableChannel(fd, closer);
}