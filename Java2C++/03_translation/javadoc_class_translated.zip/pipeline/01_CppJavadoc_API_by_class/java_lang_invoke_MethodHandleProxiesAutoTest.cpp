class Object {
public:
    virtual ~Object() = default;
};

class Class : public Object {
public:
    Class() = default;
};

class MethodHandle : public Object {
public:
    MethodHandle() = default;
};

class MethodHandleProxies {
private:
    class WrapperInstance : public Object {
    public:
        Class* type;
        MethodHandle* target;

        WrapperInstance(Class* t, MethodHandle* h) : type(t), target(h) {}
    };

public:
    static bool isWrapperInstance(Object* p0) {
        return dynamic_cast<WrapperInstance*>(p0) != nullptr;
    }

    static Object* asInterfaceInstance(Class* p0, MethodHandle* p1) {
        return new WrapperInstance(p0, p1);
    }

    static MethodHandle* wrapperInstanceTarget(Object* p0) {
        WrapperInstance* wrapper = dynamic_cast<WrapperInstance*>(p0);
        return wrapper ? wrapper->target : nullptr;
    }

    static Class* wrapperInstanceType(Object* p0) {
        WrapperInstance* wrapper = dynamic_cast<WrapperInstance*>(p0);
        return wrapper ? wrapper->type : nullptr;
    }
};

void isWrapperInstance_test_8870(Object* p0) {
    MethodHandleProxies::isWrapperInstance(p0);
}

void asInterfaceInstance_test_8871(Class* p0, MethodHandle* p1) {
    MethodHandleProxies::asInterfaceInstance(p0, p1);
}

void wrapperInstanceTarget_test_8872(Object* p0) {
    MethodHandleProxies::wrapperInstanceTarget(p0);
}

void wrapperInstanceType_test_8873(Object* p0) {
    MethodHandleProxies::wrapperInstanceType(p0);
}
