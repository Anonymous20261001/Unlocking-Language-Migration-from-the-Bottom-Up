#include <string>
#include <stdexcept>
#include <cctype>

class TemporalAccessor {
public:
    virtual ~TemporalAccessor() = default;

    virtual bool hasOffsetSeconds() const {
        return false;
    }

    virtual int getOffsetSeconds() const {
        throw std::invalid_argument("TemporalAccessor does not contain offset seconds");
    }
};

class ZoneOffset : public TemporalAccessor {
public:
    explicit ZoneOffset(int totalSeconds) : totalSeconds_(totalSeconds) {}

    static ZoneOffset of(const std::string& offsetId) {
        if (offsetId == "Z") {
            return ZoneOffset(0);
        }

        if (offsetId.empty() || (offsetId[0] != '+' && offsetId[0] != '-')) {
            throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
        }

        int sign = (offsetId[0] == '+') ? 1 : -1;
        std::string body = offsetId.substr(1);

        std::string normalized;
        for (char c : body) {
            if (c != ':') {
                normalized += c;
            }
        }

        std::string fraction;
        std::size_t dotPos = normalized.find('.');
        if (dotPos != std::string::npos) {
            fraction = normalized.substr(dotPos + 1);
            normalized = normalized.substr(0, dotPos);
        }

        if (normalized.empty()) {
            throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
        }

        for (char c : normalized) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
            }
        }

        for (char c : fraction) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
            }
        }

        int hours = 0;
        int minutes = 0;
        int seconds = 0;

        std::size_t len = normalized.size();

        if (len == 1 || len == 2) {
            hours = std::stoi(normalized);
            if (!fraction.empty()) {
                throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
            }
        } else if (len == 3 || len == 4) {
            std::size_t hourLen = len - 2;
            hours = std::stoi(normalized.substr(0, hourLen));
            minutes = std::stoi(normalized.substr(hourLen, 2));
            if (!fraction.empty()) {
                throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
            }
        } else if (len == 5 || len == 6) {
            std::size_t hourLen = len - 4;
            hours = std::stoi(normalized.substr(0, hourLen));
            minutes = std::stoi(normalized.substr(hourLen, 2));
            seconds = std::stoi(normalized.substr(hourLen + 2, 2));
        } else {
            throw std::invalid_argument("Invalid ZoneOffset id: " + offsetId);
        }

        return ofHoursMinutesSeconds(sign * hours, sign * minutes, sign * seconds);
    }

    static ZoneOffset from(const TemporalAccessor& temporal) {
        if (temporal.hasOffsetSeconds()) {
            return ofTotalSeconds(temporal.getOffsetSeconds());
        }
        throw std::invalid_argument("Unable to obtain ZoneOffset from TemporalAccessor");
    }

    static ZoneOffset ofHours(int hours) {
        if (hours < -18 || hours > 18) {
            throw std::invalid_argument("Zone offset hours out of range: " + std::to_string(hours));
        }
        return ofTotalSeconds(hours * 3600);
    }

    static ZoneOffset ofHoursMinutes(int hours, int minutes) {
        return ofHoursMinutesSeconds(hours, minutes, 0);
    }

    static ZoneOffset ofHoursMinutesSeconds(int hours, int minutes, int seconds) {
        if (hours < -18 || hours > 18) {
            throw std::invalid_argument("Zone offset hours out of range: " + std::to_string(hours));
        }
        if (minutes < -59 || minutes > 59) {
            throw std::invalid_argument("Zone offset minutes out of range: " + std::to_string(minutes));
        }
        if (seconds < -59 || seconds > 59) {
            throw std::invalid_argument("Zone offset seconds out of range: " + std::to_string(seconds));
        }

        if (hours > 0 && (minutes < 0 || seconds < 0)) {
            throw std::invalid_argument("Zone offset is not valid");
        }
        if (hours < 0 && (minutes > 0 || seconds > 0)) {
            throw std::invalid_argument("Zone offset is not valid");
        }
        if (minutes > 0 && seconds < 0) {
            throw std::invalid_argument("Zone offset is not valid");
        }
        if (minutes < 0 && seconds > 0) {
            throw std::invalid_argument("Zone offset is not valid");
        }

        int totalSeconds = hours * 3600 + minutes * 60 + seconds;
        return ofTotalSeconds(totalSeconds);
    }

    static ZoneOffset ofTotalSeconds(int totalSeconds) {
        if (totalSeconds < -64800 || totalSeconds > 64800) {
            throw std::invalid_argument("Zone offset seconds out of range: " + std::to_string(totalSeconds));
        }
        return ZoneOffset(totalSeconds);
    }

    bool hasOffsetSeconds() const override {
        return true;
    }

    int getOffsetSeconds() const override {
        return totalSeconds_;
    }

    int getTotalSeconds() const {
        return totalSeconds_;
    }

private:
    int totalSeconds_;
};

void of_test_13728(std::string p0) {
    ZoneOffset::of(p0);
}

void from_test_13729(const TemporalAccessor& p0) {
    ZoneOffset::from(p0);
}

void ofHours_test_13730(int p0) {
    ZoneOffset::ofHours(p0);
}

void ofHoursMinutesSeconds_test_13731(int p0, int p1, int p2) {
    ZoneOffset::ofHoursMinutesSeconds(p0, p1, p2);
}

void ofTotalSeconds_test_13732(int p0) {
    ZoneOffset::ofTotalSeconds(p0);
}

void ofHoursMinutes_test_13733(int p0, int p1) {
    ZoneOffset::ofHoursMinutes(p0, p1);
}
