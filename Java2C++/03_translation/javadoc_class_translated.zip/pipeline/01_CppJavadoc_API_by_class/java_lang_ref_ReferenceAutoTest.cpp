#include <cstddef>

class Object {
public:
    virtual ~Object() = default;
};

class Reference {
public:
    static void reachabilityFence(Object* obj) {
        // In C++ there is no garbage collection; the fence is a no-op.
        (void)obj;
    }
};

void reachabilityFence_test_10486(Object* p0) {
    Reference::reachabilityFence(p0);
}
