#include <string>
#include <regex>
#include <stdexcept>
#include <cstring>
#include <memory>
#include <utility>

class CharSequence {
public:
    virtual ~CharSequence() = default;
    virtual size_t length() const = 0;
    virtual char charAt(size_t index) const = 0;
    virtual std::shared_ptr<CharSequence> subSequence(size_t start, size_t end) const = 0;
    virtual std::string toString() const = 0;
};

class StringCharSequence : public CharSequence {
public:
    explicit StringCharSequence(const std::string& s) : str_(s) {}
    explicit StringCharSequence(std::string&& s) : str_(std::move(s)) {}

    size_t length() const override { return str_.length(); }
    char charAt(size_t index) const override { return str_.at(index); }
    std::shared_ptr<CharSequence> subSequence(size_t start, size_t end) const override {
        if (start > end || end > str_.size()) {
            throw std::out_of_range("subSequence");
        }
        return std::make_shared<StringCharSequence>(str_.substr(start, end - start));
    }
    std::string toString() const override { return str_; }

private:
    std::string str_;
};

class Pattern {
public:
    static Pattern compile(const std::string& regex) {
        return Pattern(regex, 0);
    }

    static Pattern compile(const std::string& regex, int flags) {
        return Pattern(regex, flags);
    }

    static bool matches(const std::string& regex, const CharSequence& input) {
        try {
            return std::regex_match(input.toString(), std::regex(regex));
        } catch (const std::regex_error& e) {
            throw std::runtime_error(e.what());
        }
    }

    static std::string quote(const std::string& s) {
        static const char* special = "\\^$.|?*+()[]{}";
        std::string out;
        out.reserve(s.size() * 2);
        for (char c : s) {
            if (std::strchr(special, c) != nullptr) {
                out.push_back('\\');
            }
            out.push_back(c);
        }
        return out;
    }

    const std::string& pattern() const { return regex_; }
    int flags() const { return flags_; }

private:
    Pattern(const std::string& regex, int flags) : regex_(regex), flags_(flags) {
        try {
            std::regex test(regex_, toStdRegexFlags(flags_));
        } catch (const std::regex_error& e) {
            throw std::runtime_error(e.what());
        }
    }

    static std::regex_constants::syntax_option_type toStdRegexFlags(int flags) {
        std::regex_constants::syntax_option_type f = std::regex_constants::ECMAScript;
        if (flags & 0x02) {
            f |= std::regex_constants::icase;
        }
        return f;
    }

    std::string regex_;
    int flags_;
};

void matches_test_9865(const std::string& p0, const CharSequence& p1) {
    Pattern::matches(p0, p1);
}

void compile_test_9866(const std::string& p0) {
    Pattern::compile(p0);
}

void compile_test_9867(const std::string& p0, int p1) {
    Pattern::compile(p0, p1);
}

void quote_test_9868(const std::string& p0) {
    Pattern::quote(p0);
}
