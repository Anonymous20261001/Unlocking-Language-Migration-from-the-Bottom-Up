#include <vector>

class Object {
public:
    virtual ~Object() {}
};

class String {};

class Dimension {
public:
    int width;
    int height;
    Dimension() : width(0), height(0) {}
};

class Insets {
public:
    int top;
    int left;
    int bottom;
    int right;
    Insets() : top(0), left(0), bottom(0), right(0) {}
};

class Point {
public:
    int x;
    int y;
    Point() : x(0), y(0) {}
};

class Font {};
class Graphics {};
class LayoutManager {
public:
    virtual ~LayoutManager() {}
};
class FocusTraversalPolicy {
public:
    virtual ~FocusTraversalPolicy() {}
};
class ComponentOrientation {};
class Event {};
class PrintStream {};
class PrintWriter {};
class Class {};
class Set {};

class PropertyChangeListener {
public:
    virtual ~PropertyChangeListener() {}
};

class ContainerListener {
public:
    virtual ~ContainerListener() {}
};

class Component : public Object {
public:
    Component() {}
    virtual ~Component() {}
};

class Container : public Component {
public:
    Container() {}
    virtual ~Container() {}

    void addPropertyChangeListener(PropertyChangeListener* p0) {
        (void)p0;
    }

    void addPropertyChangeListener(const String& p0, PropertyChangeListener* p1) {
        (void)p0;
        (void)p1;
    }

    void setFont(Font* p0) {
        (void)p0;
    }

    int getComponentCount() {
        return 0;
    }

    void paint(Graphics* p0) {
        (void)p0;
    }

    bool isFocusCycleRoot() {
        return false;
    }

    bool isFocusCycleRoot(Container* p0) {
        (void)p0;
        return false;
    }

    FocusTraversalPolicy* getFocusTraversalPolicy() {
        return nullptr;
    }

    void setFocusTraversalPolicy(FocusTraversalPolicy* p0) {
        (void)p0;
    }

    Dimension getPreferredSize() {
        return Dimension();
    }

    Dimension getMaximumSize() {
        return Dimension();
    }

    Dimension getMinimumSize() {
        return Dimension();
    }

    Insets getInsets() {
        return Insets();
    }

    float getAlignmentY() {
        return 0.0f;
    }

    float getAlignmentX() {
        return 0.0f;
    }

    void setFocusTraversalKeys(int p0, Set* p1) {
        (void)p0;
        (void)p1;
    }

    std::vector<void*> getListeners(Class* p0) {
        (void)p0;
        return std::vector<void*>();
    }

    void addNotify() {}

    void removeNotify() {}

    std::vector<Component*> getComponents() {
        return std::vector<Component*>();
    }

    Dimension preferredSize() {
        return Dimension();
    }

    Dimension minimumSize() {
        return Dimension();
    }

    Insets insets() {
        return Insets();
    }

    bool isValidateRoot() {
        return false;
    }

    int countComponents() {
        return 0;
    }

    int getComponentZOrder(Component* p0) {
        (void)p0;
        return -1;
    }

    void layout() {}

    void doLayout() {}

    Component* getComponentAt(Point* p0) {
        (void)p0;
        return nullptr;
    }

    Component* getComponentAt(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    void deliverEvent(Event* p0) {
        (void)p0;
    }

    Component* locate(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    Component* findComponentAt(int p0, int p1) {
        (void)p0;
        (void)p1;
        return nullptr;
    }

    Component* findComponentAt(Point* p0) {
        (void)p0;
        return nullptr;
    }

    bool isFocusTraversalPolicyProvider() {
        return false;
    }

    void applyComponentOrientation(ComponentOrientation* p0) {
        (void)p0;
    }

    void addContainerListener(ContainerListener* p0) {
        (void)p0;
    }

    LayoutManager* getLayout() {
        return nullptr;
    }

    void setComponentZOrder(Component* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void setLayout(LayoutManager* p0) {
        (void)p0;
    }

    void paintComponents(Graphics* p0) {
        (void)p0;
    }

    void printComponents(Graphics* p0) {
        (void)p0;
    }

    void removeContainerListener(ContainerListener* p0) {
        (void)p0;
    }

    std::vector<ContainerListener*> getContainerListeners() {
        return std::vector<ContainerListener*>();
    }

    Point* getMousePosition(bool p0) {
        (void)p0;
        return nullptr;
    }

    bool isAncestorOf(Component* p0) {
        (void)p0;
        return false;
    }

    Set* getFocusTraversalKeys(int p0) {
        (void)p0;
        return nullptr;
    }

    bool areFocusTraversalKeysSet(int p0) {
        (void)p0;
        return false;
    }

    bool isFocusTraversalPolicySet() {
        return false;
    }

    void setFocusCycleRoot(bool p0) {
        (void)p0;
    }

    void setFocusTraversalPolicyProvider(bool p0) {
        (void)p0;
    }

    void transferFocusDownCycle() {}

    void remove(int p0) {
        (void)p0;
    }

    void remove(Component* p0) {
        (void)p0;
    }

    void update(Graphics* p0) {
        (void)p0;
    }

    Component* add(Component* p0) {
        (void)p0;
        return p0;
    }

    Component* add(const String& p0, Component* p1) {
        (void)p0;
        return p1;
    }

    Component* add(Component* p0, Object* p1) {
        (void)p0;
        (void)p1;
        return p0;
    }

    Component* add(Component* p0, Object* p1, int p2) {
        (void)p0;
        (void)p1;
        (void)p2;
        return p0;
    }

    Component* add(Component* p0, int p1) {
        (void)p0;
        (void)p1;
        return p0;
    }

    void list(PrintWriter* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void list(PrintStream* p0, int p1) {
        (void)p0;
        (void)p1;
    }

    void validate() {}

    void print(Graphics* p0) {
        (void)p0;
    }

    void removeAll() {}

    Component* getComponent(int p0) {
        (void)p0;
        return nullptr;
    }

    void invalidate() {}
};

void addPropertyChangeListener_test_2934(PropertyChangeListener* p0) {
    (void)p0;
    Container instance;
    instance.addPropertyChangeListener(p0);
}

void addPropertyChangeListener_test_2935(String p0, PropertyChangeListener* p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.addPropertyChangeListener(p0, p1);
}

void setFont_test_2936(Font* p0) {
    (void)p0;
    Container instance;
    instance.setFont(p0);
}

void getComponentCount_test_2937() {
    Container instance;
    instance.getComponentCount();
}

void paint_test_2938(Graphics* p0) {
    (void)p0;
    Container instance;
    instance.paint(p0);
}

void isFocusCycleRoot_test_2939() {
    Container instance;
    instance.isFocusCycleRoot();
}

void isFocusCycleRoot_test_2940(Container* p0) {
    (void)p0;
    Container instance;
    instance.isFocusCycleRoot(p0);
}

void getFocusTraversalPolicy_test_2941() {
    Container instance;
    instance.getFocusTraversalPolicy();
}

void setFocusTraversalPolicy_test_2942(FocusTraversalPolicy* p0) {
    (void)p0;
    Container instance;
    instance.setFocusTraversalPolicy(p0);
}

void getPreferredSize_test_2943() {
    Container instance;
    instance.getPreferredSize();
}

void getMaximumSize_test_2944() {
    Container instance;
    instance.getMaximumSize();
}

void getMinimumSize_test_2945() {
    Container instance;
    instance.getMinimumSize();
}

void getInsets_test_2946() {
    Container instance;
    instance.getInsets();
}

void getAlignmentY_test_2947() {
    Container instance;
    instance.getAlignmentY();
}

void getAlignmentX_test_2948() {
    Container instance;
    instance.getAlignmentX();
}

void setFocusTraversalKeys_test_2949(int p0, Set* p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.setFocusTraversalKeys(p0, p1);
}

void getListeners_test_2950(Class* p0) {
    (void)p0;
    Container instance;
    instance.getListeners(p0);
}

void addNotify_test_2951() {
    Container instance;
    instance.addNotify();
}

void removeNotify_test_2952() {
    Container instance;
    instance.removeNotify();
}

void getComponents_test_2953() {
    Container instance;
    instance.getComponents();
}

void preferredSize_test_2954() {
    Container instance;
    instance.preferredSize();
}

void minimumSize_test_2955() {
    Container instance;
    instance.minimumSize();
}

void insets_test_2956() {
    Container instance;
    instance.insets();
}

void isValidateRoot_test_2957() {
    Container instance;
    instance.isValidateRoot();
}

void countComponents_test_2958() {
    Container instance;
    instance.countComponents();
}

void getComponentZOrder_test_2959(Component* p0) {
    (void)p0;
    Container instance;
    instance.getComponentZOrder(p0);
}

void layout_test_2960() {
    Container instance;
    instance.layout();
}

void doLayout_test_2961() {
    Container instance;
    instance.doLayout();
}

void getComponentAt_test_2962(Point* p0) {
    (void)p0;
    Container instance;
    instance.getComponentAt(p0);
}

void getComponentAt_test_2963(int p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.getComponentAt(p0, p1);
}

void deliverEvent_test_2964(Event* p0) {
    (void)p0;
    Container instance;
    instance.deliverEvent(p0);
}

void locate_test_2965(int p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.locate(p0, p1);
}

void findComponentAt_test_2966(int p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.findComponentAt(p0, p1);
}

void findComponentAt_test_2967(Point* p0) {
    (void)p0;
    Container instance;
    instance.findComponentAt(p0);
}

void isFocusTraversalPolicyProvider_test_2968() {
    Container instance;
    instance.isFocusTraversalPolicyProvider();
}

void applyComponentOrientation_test_2969(ComponentOrientation* p0) {
    (void)p0;
    Container instance;
    instance.applyComponentOrientation(p0);
}

void addContainerListener_test_2970(ContainerListener* p0) {
    (void)p0;
    Container instance;
    instance.addContainerListener(p0);
}

void getLayout_test_2971() {
    Container instance;
    instance.getLayout();
}

void setComponentZOrder_test_2972(Component* p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.setComponentZOrder(p0, p1);
}

void setLayout_test_2973(LayoutManager* p0) {
    (void)p0;
    Container instance;
    instance.setLayout(p0);
}

void paintComponents_test_2974(Graphics* p0) {
    (void)p0;
    Container instance;
    instance.paintComponents(p0);
}

void printComponents_test_2975(Graphics* p0) {
    (void)p0;
    Container instance;
    instance.printComponents(p0);
}

void removeContainerListener_test_2976(ContainerListener* p0) {
    (void)p0;
    Container instance;
    instance.removeContainerListener(p0);
}

void getContainerListeners_test_2977() {
    Container instance;
    instance.getContainerListeners();
}

void getMousePosition_test_2978(bool p0) {
    (void)p0;
    Container instance;
    instance.getMousePosition(p0);
}

void isAncestorOf_test_2979(Component* p0) {
    (void)p0;
    Container instance;
    instance.isAncestorOf(p0);
}

void getFocusTraversalKeys_test_2980(int p0) {
    (void)p0;
    Container instance;
    instance.getFocusTraversalKeys(p0);
}

void areFocusTraversalKeysSet_test_2981(int p0) {
    (void)p0;
    Container instance;
    instance.areFocusTraversalKeysSet(p0);
}

void isFocusTraversalPolicySet_test_2982() {
    Container instance;
    instance.isFocusTraversalPolicySet();
}

void setFocusCycleRoot_test_2983(bool p0) {
    (void)p0;
    Container instance;
    instance.setFocusCycleRoot(p0);
}

void setFocusTraversalPolicyProvider_test_2984(bool p0) {
    (void)p0;
    Container instance;
    instance.setFocusTraversalPolicyProvider(p0);
}

void transferFocusDownCycle_test_2985() {
    Container instance;
    instance.transferFocusDownCycle();
}

void remove_test_2986(int p0) {
    (void)p0;
    Container instance;
    instance.remove(p0);
}

void remove_test_2987(Component* p0) {
    (void)p0;
    Container instance;
    instance.remove(p0);
}

void update_test_2988(Graphics* p0) {
    (void)p0;
    Container instance;
    instance.update(p0);
}

void add_test_2989(Component* p0) {
    (void)p0;
    Container instance;
    instance.add(p0);
}

void add_test_2990(String p0, Component* p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.add(p0, p1);
}

void add_test_2991(Component* p0, Object* p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.add(p0, p1);
}

void add_test_2992(Component* p0, Object* p1, int p2) {
    (void)p0;
    (void)p1;
    (void)p2;
    Container instance;
    instance.add(p0, p1, p2);
}

void add_test_2993(Component* p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.add(p0, p1);
}

void list_test_2994(PrintWriter* p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.list(p0, p1);
}

void list_test_2995(PrintStream* p0, int p1) {
    (void)p0;
    (void)p1;
    Container instance;
    instance.list(p0, p1);
}

void validate_test_2996() {
    Container instance;
    instance.validate();
}

void print_test_2997(Graphics* p0) {
    (void)p0;
    Container instance;
    instance.print(p0);
}

void removeAll_test_2998() {
    Container instance;
    instance.removeAll();
}

void getComponent_test_2999(int p0) {
    (void)p0;
    Container instance;
    instance.getComponent(p0);
}

void invalidate_test_3000() {
    Container instance;
    instance.invalidate();
}