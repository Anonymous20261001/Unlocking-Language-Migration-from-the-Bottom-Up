#include <string>
#include <vector>

class URI {
public:
    std::string value;
    URI() {}
    explicit URI(const std::string& v) : value(v) {}
};

class CatalogFeatures {
public:
    CatalogFeatures() {}
};

class Catalog {
public:
    Catalog() {}
};

class CatalogResolver {
public:
    enum class NotFoundAction {
        THROW,
        CONTINUE,
        IGNORE
    };
    CatalogResolver() {}
};

class CatalogManager {
public:
    static CatalogResolver catalogResolver(Catalog p0, CatalogResolver::NotFoundAction p1) {
        return CatalogResolver();
    }

    static CatalogResolver catalogResolver(CatalogFeatures p0, std::vector<URI> p1) {
        return CatalogResolver();
    }

    static CatalogResolver catalogResolver(Catalog p0) {
        return CatalogResolver();
    }

    static Catalog catalog(CatalogFeatures p0, std::vector<URI> p1) {
        return Catalog();
    }
};

void catalogResolver_test_2082(Catalog p0, CatalogResolver::NotFoundAction p1) {
    CatalogManager::catalogResolver(p0, p1);
}

void catalogResolver_test_2083(CatalogFeatures p0, std::vector<URI> p1) {
    CatalogManager::catalogResolver(p0, p1);
}

void catalogResolver_test_2084(Catalog p0) {
    CatalogManager::catalogResolver(p0);
}

void catalog_test_2085(CatalogFeatures p0, std::vector<URI> p1) {
    CatalogManager::catalog(p0, p1);
}