class InputContext {
public:
    static InputContext getInstance() {
        return InputContext();
    }

private:
    InputContext() = default;
};

void getInstance_test_5830() {
    InputContext::getInstance();
}
