namespace javax {
namespace imageio {
namespace spi {

class IIORegistry {
public:
    static IIORegistry& getDefaultInstance() {
        static IIORegistry instance;
        return instance;
    }

private:
    IIORegistry() = default;
    IIORegistry(const IIORegistry&) = delete;
    IIORegistry& operator=(const IIORegistry&) = delete;
};

} // namespace spi
} // namespace imageio
} // namespace javax

void getDefaultInstance_test_5617() {
    javax::imageio::spi::IIORegistry::getDefaultInstance();
}