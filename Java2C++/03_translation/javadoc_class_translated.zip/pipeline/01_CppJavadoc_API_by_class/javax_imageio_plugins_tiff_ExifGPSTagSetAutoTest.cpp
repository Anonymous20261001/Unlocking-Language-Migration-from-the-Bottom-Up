#include <cstddef>

class ExifGPSTagSet {
public:
    static ExifGPSTagSet& getInstance() {
        static ExifGPSTagSet instance;
        return instance;
    }

    ExifGPSTagSet(const ExifGPSTagSet&) = delete;
    ExifGPSTagSet& operator=(const ExifGPSTagSet&) = delete;

private:
    ExifGPSTagSet() {}
};

void getInstance_test_4661() {
    ExifGPSTagSet::getInstance();
}