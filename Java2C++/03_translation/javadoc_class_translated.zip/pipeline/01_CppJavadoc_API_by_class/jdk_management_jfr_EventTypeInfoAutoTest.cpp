#include <string>
#include <map>
#include <stdexcept>
#include <utility>

class CompositeData {
public:
    CompositeData() = default;
    CompositeData(const std::map<std::string, std::string>& values) : values_(values) {}
    virtual ~CompositeData() = default;

    bool containsKey(const std::string& key) const {
        return values_.find(key) != values_.end();
    }

    std::string get(const std::string& key) const {
        auto it = values_.find(key);
        if (it == values_.end()) {
            throw std::invalid_argument("Key not found: " + key);
        }
        return it->second;
    }

private:
    std::map<std::string, std::string> values_;
};

class EventTypeInfo {
public:
    EventTypeInfo() : id_(0) {}

    static EventTypeInfo from(const CompositeData& cd) {
        if (!cd.containsKey("id") || !cd.containsKey("name")) {
            throw std::invalid_argument("Missing required attributes");
        }
        EventTypeInfo info;
        info.id_ = std::stoull(cd.get("id"));
        info.name_ = cd.get("name");
        if (cd.containsKey("description")) {
            info.description_ = cd.get("description");
        }
        return info;
    }

    long long id() const { return id_; }
    const std::string& name() const { return name_; }
    const std::string& description() const { return description_; }

private:
    long long id_;
    std::string name_;
    std::string description_;
};

void from_test_4605(CompositeData p0) {
    EventTypeInfo::from(p0);
}