#include <string>

class KeyStore {
public:
    static std::string getDefaultType() {
        return "pkcs12";
    }
};

void getDefaultType_test_7636() {
    KeyStore::getDefaultType();
}