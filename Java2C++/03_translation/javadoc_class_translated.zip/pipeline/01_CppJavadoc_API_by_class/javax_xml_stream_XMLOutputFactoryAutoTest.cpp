#include <string>
#include <memory>

class ClassLoader {
public:
    ClassLoader() = default;
};

class XMLOutputFactory {
public:
    static std::unique_ptr<XMLOutputFactory> newDefaultFactory() {
        return std::unique_ptr<XMLOutputFactory>(new XMLOutputFactory());
    }

    static std::unique_ptr<XMLOutputFactory> newInstance() {
        return newDefaultFactory();
    }

    static std::unique_ptr<XMLOutputFactory> newInstance(const std::string& factoryId, const ClassLoader& classLoader) {
        (void)factoryId;
        (void)classLoader;
        return newDefaultFactory();
    }

    static std::unique_ptr<XMLOutputFactory> newFactory() {
        return newDefaultFactory();
    }

    static std::unique_ptr<XMLOutputFactory> newFactory(const std::string& factoryId, const ClassLoader& classLoader) {
        (void)factoryId;
        (void)classLoader;
        return newDefaultFactory();
    }

private:
    XMLOutputFactory() = default;
};

void newDefaultFactory_test_13639() {
    XMLOutputFactory::newDefaultFactory();
}

void newInstance_test_13640(const std::string& p0, const ClassLoader& p1) {
    XMLOutputFactory::newInstance(p0, p1);
}

void newInstance_test_13641() {
    XMLOutputFactory::newInstance();
}

void newFactory_test_13642() {
    XMLOutputFactory::newFactory();
}

void newFactory_test_13643(const std::string& p0, const ClassLoader& p1) {
    XMLOutputFactory::newFactory(p0, p1);
}