#include <exception>

class RMIFailureHandler {
public:
    virtual ~RMIFailureHandler() = default;
    virtual bool failure(const std::exception& ex) = 0;
};

class RMISocketFactory {
private:
    static RMISocketFactory* socketFactory;
    static RMISocketFactory* defaultSocketFactory;
    static RMIFailureHandler* failureHandler;

protected:
    RMISocketFactory() = default;

public:
    virtual ~RMISocketFactory() = default;

    static RMISocketFactory* getSocketFactory() {
        return socketFactory;
    }

    static RMISocketFactory* getDefaultSocketFactory() {
        if (defaultSocketFactory == nullptr) {
            defaultSocketFactory = new RMISocketFactory();
        }
        return defaultSocketFactory;
    }

    static void setFailureHandler(RMIFailureHandler* handler) {
        failureHandler = handler;
    }

    static RMIFailureHandler* getFailureHandler() {
        return failureHandler;
    }
};

RMISocketFactory* RMISocketFactory::socketFactory = nullptr;
RMISocketFactory* RMISocketFactory::defaultSocketFactory = nullptr;
RMIFailureHandler* RMISocketFactory::failureHandler = nullptr;

void getSocketFactory_test_10636() {
    RMISocketFactory::getSocketFactory();
}

void getDefaultSocketFactory_test_10637() {
    RMISocketFactory::getDefaultSocketFactory();
}

void setFailureHandler_test_10638(RMIFailureHandler* p0 = nullptr) {
    RMISocketFactory::setFailureHandler(p0);
}

void getFailureHandler_test_10639() {
    RMISocketFactory::getFailureHandler();
}