#include <string>

using CharSequence = std::string;

class TemporalAccessor {
protected:
    int monthValue;
    int dayOfMonth;

public:
    TemporalAccessor(int month = 1, int day = 1) : monthValue(month), dayOfMonth(day) {}
    virtual ~TemporalAccessor() = default;

    int getMonthValue() const { return monthValue; }
    int getDayOfMonth() const { return dayOfMonth; }
};

class ZoneId {
private:
    int monthValue;
    int dayOfMonth;

public:
    ZoneId(int month = 1, int day = 1) : monthValue(month), dayOfMonth(day) {}

    int getMonthValue() const { return monthValue; }
    int getDayOfMonth() const { return dayOfMonth; }

    static ZoneId of(const std::string& id) {
        (void)id;
        return ZoneId();
    }
};

class Clock {
private:
    int monthValue;
    int dayOfMonth;

public:
    Clock(int month = 1, int day = 1) : monthValue(month), dayOfMonth(day) {}

    int getMonthValue() const { return monthValue; }
    int getDayOfMonth() const { return dayOfMonth; }
};

class DateTimeFormatter {
private:
    std::string pattern;

public:
    DateTimeFormatter() = default;
    explicit DateTimeFormatter(const std::string& p) : pattern(p) {}

    static DateTimeFormatter ofPattern(const std::string& p) {
        return DateTimeFormatter(p);
    }
};

enum class Month {
    JANUARY = 1,
    FEBRUARY = 2,
    MARCH = 3,
    APRIL = 4,
    MAY = 5,
    JUNE = 6,
    JULY = 7,
    AUGUST = 8,
    SEPTEMBER = 9,
    OCTOBER = 10,
    NOVEMBER = 11,
    DECEMBER = 12
};

class MonthDay {
private:
    int month;
    int day;

    MonthDay(int month, int day) : month(month), day(day) {}

public:
    static MonthDay of(int month, int day) {
        return MonthDay(month, day);
    }

    static MonthDay of(Month month, int day) {
        return MonthDay(static_cast<int>(month), day);
    }

    static MonthDay from(const TemporalAccessor& temporal) {
        return MonthDay(temporal.getMonthValue(), temporal.getDayOfMonth());
    }

    static MonthDay parse(const CharSequence& text, const DateTimeFormatter& /*formatter*/) {
        return parse(text);
    }

    static MonthDay parse(const CharSequence& text) {
        int month = 1;
        int day = 1;
        std::string s = text;

        std::size_t pos = s.find_first_of("0123456789");
        if (pos != std::string::npos && pos + 1 < s.size()) {
            month = std::stoi(s.substr(pos, 2));
            pos += 2;

            while (pos < s.size() && (s[pos] == '-' || s[pos] == ' ' || s[pos] == ':' || s[pos] == '/')) {
                ++pos;
            }

            if (pos < s.size()) {
                day = std::stoi(s.substr(pos, 2));
            }
        }

        return MonthDay(month, day);
    }

    static MonthDay now(const ZoneId& zone) {
        return MonthDay(zone.getMonthValue(), zone.getDayOfMonth());
    }

    static MonthDay now() {
        return MonthDay(1, 1);
    }

    static MonthDay now(const Clock& clock) {
        return MonthDay(clock.getMonthValue(), clock.getDayOfMonth());
    }

    int getMonthValue() const { return month; }
    int getDayOfMonth() const { return day; }
};

void of_test_9004(int p0, int p1) {
    MonthDay::of(p0, p1);
}

void of_test_9005(Month p0, int p1) {
    MonthDay::of(p0, p1);
}

void from_test_9006(TemporalAccessor p0) {
    MonthDay::from(p0);
}

void parse_test_9007(CharSequence p0, DateTimeFormatter p1) {
    MonthDay::parse(p0, p1);
}

void parse_test_9008(CharSequence p0) {
    MonthDay::parse(p0);
}

void now_test_9009(ZoneId p0) {
    MonthDay::now(p0);
}

void now_test_9010() {
    MonthDay::now();
}

void now_test_9011(Clock p0) {
    MonthDay::now(p0);
}
