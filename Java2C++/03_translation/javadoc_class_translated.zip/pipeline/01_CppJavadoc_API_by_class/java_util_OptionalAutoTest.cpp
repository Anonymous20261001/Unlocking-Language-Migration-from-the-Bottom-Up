#include <cstddef>
#include <stdexcept>
#include <string>

class NullPointerException : public std::runtime_error {
public:
    explicit NullPointerException(const std::string& message)
        : std::runtime_error(message) {}
};

class NoSuchElementException : public std::runtime_error {
public:
    explicit NoSuchElementException(const std::string& message)
        : std::runtime_error(message) {}
};

class Optional {
public:
    static Optional of(void* value) {
        if (value == nullptr) {
            throw NullPointerException("Optional.of(null)");
        }
        return Optional(value, true);
    }

    static Optional empty() {
        return Optional(nullptr, false);
    }

    static Optional ofNullable(void* value) {
        return value == nullptr ? Optional(nullptr, false) : Optional(value, true);
    }

    bool isPresent() const {
        return present_;
    }

    void* get() const {
        if (!present_) {
            throw NoSuchElementException("No value present");
        }
        return value_;
    }

    void* orElse(void* other) const {
        return present_ ? value_ : other;
    }

private:
    Optional(void* value, bool present)
        : value_(value), present_(present) {}

    void* value_;
    bool present_;
};

void of_test_9689(void* p0) {
    Optional::of(p0);
}

void empty_test_9690() {
    Optional::empty();
}

void ofNullable_test_9691(void* p0) {
    Optional::ofNullable(p0);
}