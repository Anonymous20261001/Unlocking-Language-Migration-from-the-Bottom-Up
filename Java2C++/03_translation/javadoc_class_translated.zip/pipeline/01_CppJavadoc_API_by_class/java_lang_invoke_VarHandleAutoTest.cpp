#include <atomic>

class VarHandle {
public:
    static void storeStoreFence() {
        std::atomic_thread_fence(std::memory_order_release);
    }

    static void fullFence() {
        std::atomic_thread_fence(std::memory_order_seq_cst);
    }

    static void loadLoadFence() {
        std::atomic_thread_fence(std::memory_order_acquire);
    }

    static void acquireFence() {
        std::atomic_thread_fence(std::memory_order_acquire);
    }

    static void releaseFence() {
        std::atomic_thread_fence(std::memory_order_release);
    }
};

void storeStoreFence_test_13309() {
    VarHandle::storeStoreFence();
}

void fullFence_test_13310() {
    VarHandle::fullFence();
}

void loadLoadFence_test_13311() {
    VarHandle::loadLoadFence();
}

void acquireFence_test_13312() {
    VarHandle::acquireFence();
}

void releaseFence_test_13313() {
    VarHandle::releaseFence();
}