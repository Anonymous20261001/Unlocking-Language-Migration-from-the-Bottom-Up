class ExifInteroperabilityTagSet {
public:
    static constexpr int TAG_INTEROPERABILITY_INDEX = 1;
    static constexpr int TAG_INTEROPERABILITY_VERSION = 2;
    static constexpr int TAG_RELATED_IMAGE_FILE_FORMAT = 4096;
    static constexpr int TAG_RELATED_IMAGE_WIDTH = 4097;
    static constexpr int TAG_RELATED_IMAGE_LENGTH = 4098;

    static ExifInteroperabilityTagSet& getInstance() {
        static ExifInteroperabilityTagSet instance;
        return instance;
    }

private:
    ExifInteroperabilityTagSet() = default;
    ~ExifInteroperabilityTagSet() = default;
    ExifInteroperabilityTagSet(const ExifInteroperabilityTagSet&) = delete;
    ExifInteroperabilityTagSet& operator=(const ExifInteroperabilityTagSet&) = delete;
};

void getInstance_test_4662() {
    ExifInteroperabilityTagSet::getInstance();
}