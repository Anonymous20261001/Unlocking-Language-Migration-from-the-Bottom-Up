#include <vector>

class Object {
public:
    virtual ~Object() = default;
};

class Comparator {
public:
    virtual ~Comparator() = default;
    virtual int compare(Object* a, Object* b) = 0;
};

class Collection {
public:
    virtual ~Collection() = default;
};

class SequencedCollection : public Collection {
};

class List : public SequencedCollection {
};

class Set : public Collection {
};

class SequencedSet : public Set {
};

class SortedSet : public Set {
};

class NavigableSet : public SortedSet {
};

class Queue : public Collection {
};

class Deque : public Queue {
};

class Map {
public:
    virtual ~Map() = default;
};

class SequencedMap : public Map {
};

class SortedMap : public Map {
};

class NavigableMap : public SortedMap {
};

class Enumeration {
public:
    virtual ~Enumeration() = default;
    virtual bool hasMoreElements() = 0;
    virtual Object* nextElement() = 0;
};

class Random {
public:
    virtual ~Random() = default;
};

class RandomGenerator {
public:
    virtual ~RandomGenerator() = default;
};

class Class {
public:
    virtual ~Class() = default;
};

class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() = 0;
    virtual Object* next() = 0;
};

class ListIterator : public Iterator {
public:
    virtual bool hasPrevious() = 0;
    virtual Object* previous() = 0;
};

class Collections {
public:
    static Object* min(Collection* c, Comparator* cmp) { (void)c; (void)cmp; return nullptr; }
    static Object* min(Collection* c) { (void)c; return nullptr; }
    static Object* max(Collection* c) { (void)c; return nullptr; }
    static Object* max(Collection* c, Comparator* cmp) { (void)c; (void)cmp; return nullptr; }
    static void reverse(List* l) { (void)l; }
    static void sort(List* l) { (void)l; }
    static void sort(List* l, Comparator* cmp) { (void)l; (void)cmp; }
    static void copy(List* dest, List* src) { (void)dest; (void)src; }
    static bool replaceAll(List* l, Object* oldVal, Object* newVal) { (void)l; (void)oldVal; (void)newVal; return false; }
    static void fill(List* l, Object* o) { (void)l; (void)o; }
    static List* list(Enumeration* e) { (void)e; return nullptr; }
    static bool addAll(Collection* c, const std::vector<Object*>& elements) { (void)c; (void)elements; return false; }
    static Enumeration* emptyEnumeration() { return nullptr; }
    static Set* newSetFromMap(Map* m) { (void)m; return nullptr; }
    static List* emptyList() { return nullptr; }
    static Set* unmodifiableSet(Set* s) { return s; }
    static Enumeration* enumeration(Collection* c) { (void)c; return nullptr; }
    static Set* synchronizedSet(Set* s) { return s; }
    static Collection* synchronizedCollection(Collection* c) { return c; }
    static Iterator* emptyIterator() { return nullptr; }
    static List* nCopies(int n, Object* o) { (void)n; (void)o; return nullptr; }
    static Comparator* reverseOrder(Comparator* cmp) { return cmp; }
    static Comparator* reverseOrder() { return nullptr; }
    static Map* unmodifiableMap(Map* m) { return m; }
    static SortedMap* unmodifiableSortedMap(SortedMap* m) { return m; }
    static void swap(List* l, int i, int j) { (void)l; (void)i; (void)j; }
    static int binarySearch(List* l, Object* key, Comparator* cmp) { (void)l; (void)key; (void)cmp; return 0; }
    static int binarySearch(List* l, Object* key) { (void)l; (void)key; return 0; }
    static void shuffle(List* l, Random* rnd) { (void)l; (void)rnd; }
    static void shuffle(List* l) { (void)l; }
    static void shuffle(List* l, RandomGenerator* rnd) { (void)l; (void)rnd; }
    static void rotate(List* l, int distance) { (void)l; (void)distance; }
    static int indexOfSubList(List* source, List* target) { (void)source; (void)target; return 0; }
    static int lastIndexOfSubList(List* source, List* target) { (void)source; (void)target; return 0; }
    static Collection* unmodifiableCollection(Collection* c) { return c; }
    static SequencedCollection* unmodifiableSequencedCollection(SequencedCollection* c) { return c; }
    static SequencedSet* unmodifiableSequencedSet(SequencedSet* s) { return s; }
    static SortedSet* unmodifiableSortedSet(SortedSet* s) { return s; }
    static NavigableSet* unmodifiableNavigableSet(NavigableSet* s) { return s; }
    static List* unmodifiableList(List* l) { return l; }
    static SequencedMap* unmodifiableSequencedMap(SequencedMap* m) { return m; }
    static NavigableMap* unmodifiableNavigableMap(NavigableMap* m) { return m; }
    static SortedSet* synchronizedSortedSet(SortedSet* s) { return s; }
    static NavigableSet* synchronizedNavigableSet(NavigableSet* s) { return s; }
    static List* synchronizedList(List* l) { return l; }
    static Map* synchronizedMap(Map* m) { return m; }
    static SortedMap* synchronizedSortedMap(SortedMap* m) { return m; }
    static NavigableMap* synchronizedNavigableMap(NavigableMap* m) { return m; }
    static Collection* checkedCollection(Collection* c, Class* type) { (void)type; return c; }
    static Queue* checkedQueue(Queue* q, Class* type) { (void)type; return q; }
    static Set* checkedSet(Set* s, Class* type) { (void)type; return s; }
    static SortedSet* checkedSortedSet(SortedSet* s, Class* type) { (void)type; return s; }
    static NavigableSet* checkedNavigableSet(NavigableSet* s, Class* type) { (void)type; return s; }
    static List* checkedList(List* l, Class* type) { (void)type; return l; }
    static Map* checkedMap(Map* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static SortedMap* checkedSortedMap(SortedMap* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static NavigableMap* checkedNavigableMap(NavigableMap* m, Class* keyType, Class* valueType) { (void)keyType; (void)valueType; return m; }
    static ListIterator* emptyListIterator() { return nullptr; }
    static Set* emptySet() { return nullptr; }
    static SortedSet* emptySortedSet() { return nullptr; }
    static NavigableSet* emptyNavigableSet() { return nullptr; }
    static Map* emptyMap() { return nullptr; }
    static SortedMap* emptySortedMap() { return nullptr; }
    static NavigableMap* emptyNavigableMap() { return nullptr; }
    static Set* singleton(Object* o) { (void)o; return nullptr; }
    static List* singletonList(Object* o) { (void)o; return nullptr; }
    static Map* singletonMap(Object* k, Object* v) { (void)k; (void)v; return nullptr; }
    static int frequency(Collection* c, Object* o) { (void)c; (void)o; return 0; }
    static bool disjoint(Collection* c1, Collection* c2) { (void)c1; (void)c2; return false; }
    static SequencedSet* newSequencedSetFromMap(SequencedMap* m) { (void)m; return nullptr; }
    static Deque* asLifoQueue(Deque* d) { return d; }
};

void min_test_2353(Collection* p0, Comparator* p1) { Collections::min(p0, p1); }
void min_test_2354(Collection* p0) { Collections::min(p0); }
void max_test_2355(Collection* p0) { Collections::max(p0); }
void max_test_2356(Collection* p0, Comparator* p1) { Collections::max(p0, p1); }
void reverse_test_2357(List* p0) { Collections::reverse(p0); }
void sort_test_2358(List* p0) { Collections::sort(p0); }
void sort_test_2359(List* p0, Comparator* p1) { Collections::sort(p0, p1); }
void copy_test_2360(List* p0, List* p1) { Collections::copy(p0, p1); }
void replaceAll_test_2361(List* p0, Object* p1, Object* p2) { Collections::replaceAll(p0, p1, p2); }
void fill_test_2362(List* p0, Object* p1) { Collections::fill(p0, p1); }
void list_test_2363(Enumeration* p0) { Collections::list(p0); }
void addAll_test_2364(Collection* p0, std::vector<Object*> p1) { Collections::addAll(p0, p1); }
void emptyEnumeration_test_2365() { Collections::emptyEnumeration(); }
void newSetFromMap_test_2366(Map* p0) { Collections::newSetFromMap(p0); }
void emptyList_test_2367() { Collections::emptyList(); }
void unmodifiableSet_test_2368(Set* p0) { Collections::unmodifiableSet(p0); }
void enumeration_test_2369(Collection* p0) { Collections::enumeration(p0); }
void synchronizedSet_test_2370(Set* p0) { Collections::synchronizedSet(p0); }
void synchronizedCollection_test_2371(Collection* p0) { Collections::synchronizedCollection(p0); }
void emptyIterator_test_2372() { Collections::emptyIterator(); }
void nCopies_test_2373(int p0, Object* p1) { Collections::nCopies(p0, p1); }
void reverseOrder_test_2374(Comparator* p0) { Collections::reverseOrder(p0); }
void reverseOrder_test_2375() { Collections::reverseOrder(); }
void unmodifiableMap_test_2376(Map* p0) { Collections::unmodifiableMap(p0); }
void unmodifiableSortedMap_test_2377(SortedMap* p0) { Collections::unmodifiableSortedMap(p0); }
void swap_test_2378(List* p0, int p1, int p2) { Collections::swap(p0, p1, p2); }
void binarySearch_test_2379(List* p0, Object* p1, Comparator* p2) { Collections::binarySearch(p0, p1, p2); }
void binarySearch_test_2380(List* p0, Object* p1) { Collections::binarySearch(p0, p1); }
void shuffle_test_2381(List* p0, Random* p1) { Collections::shuffle(p0, p1); }
void shuffle_test_2382(List* p0) { Collections::shuffle(p0); }
void shuffle_test_2383(List* p0, RandomGenerator* p1) { Collections::shuffle(p0, p1); }
void rotate_test_2384(List* p0, int p1) { Collections::rotate(p0, p1); }
void indexOfSubList_test_2385(List* p0, List* p1) { Collections::indexOfSubList(p0, p1); }
void lastIndexOfSubList_test_2386(List* p0, List* p1) { Collections::lastIndexOfSubList(p0, p1); }
void unmodifiableCollection_test_2387(Collection* p0) { Collections::unmodifiableCollection(p0); }
void unmodifiableSequencedCollection_test_2388(SequencedCollection* p0) { Collections::unmodifiableSequencedCollection(p0); }
void unmodifiableSequencedSet_test_2389(SequencedSet* p0) { Collections::unmodifiableSequencedSet(p0); }
void unmodifiableSortedSet_test_2390(SortedSet* p0) { Collections::unmodifiableSortedSet(p0); }
void unmodifiableNavigableSet_test_2391(NavigableSet* p0) { Collections::unmodifiableNavigableSet(p0); }
void unmodifiableList_test_2392(List* p0) { Collections::unmodifiableList(p0); }
void unmodifiableSequencedMap_test_2393(SequencedMap* p0) { Collections::unmodifiableSequencedMap(p0); }
void unmodifiableNavigableMap_test_2394(NavigableMap* p0) { Collections::unmodifiableNavigableMap(p0); }
void synchronizedSortedSet_test_2395(SortedSet* p0) { Collections::synchronizedSortedSet(p0); }
void synchronizedNavigableSet_test_2396(NavigableSet* p0) { Collections::synchronizedNavigableSet(p0); }
void synchronizedList_test_2397(List* p0) { Collections::synchronizedList(p0); }
void synchronizedMap_test_2398(Map* p0) { Collections::synchronizedMap(p0); }
void synchronizedSortedMap_test_2399(SortedMap* p0) { Collections::synchronizedSortedMap(p0); }
void synchronizedNavigableMap_test_2400(NavigableMap* p0) { Collections::synchronizedNavigableMap(p0); }
void checkedCollection_test_2401(Collection* p0, Class* p1) { Collections::checkedCollection(p0, p1); }
void checkedQueue_test_2402(Queue* p0, Class* p1) { Collections::checkedQueue(p0, p1); }
void checkedSet_test_2403(Set* p0, Class* p1) { Collections::checkedSet(p0, p1); }
void checkedSortedSet_test_2404(SortedSet* p0, Class* p1) { Collections::checkedSortedSet(p0, p1); }
void checkedNavigableSet_test_2405(NavigableSet* p0, Class* p1) { Collections::checkedNavigableSet(p0, p1); }
void checkedList_test_2406(List* p0, Class* p1) { Collections::checkedList(p0, p1); }
void checkedMap_test_2407(Map* p0, Class* p1, Class* p2) { Collections::checkedMap(p0, p1, p2); }
void checkedSortedMap_test_2408(SortedMap* p0, Class* p1, Class* p2) { Collections::checkedSortedMap(p0, p1, p2); }
void checkedNavigableMap_test_2409(NavigableMap* p0, Class* p1, Class* p2) { Collections::checkedNavigableMap(p0, p1, p2); }
void emptyListIterator_test_2410() { Collections::emptyListIterator(); }
void emptySet_test_2411() { Collections::emptySet(); }
void emptySortedSet_test_2412() { Collections::emptySortedSet(); }
void emptyNavigableSet_test_2413() { Collections::emptyNavigableSet(); }
void emptyMap_test_2414() { Collections::emptyMap(); }
void emptySortedMap_test_2415() { Collections::emptySortedMap(); }
void emptyNavigableMap_test_2416() { Collections::emptyNavigableMap(); }
void singleton_test_2417(Object* p0) { Collections::singleton(p0); }
void singletonList_test_2418(Object* p0) { Collections::singletonList(p0); }
void singletonMap_test_2419(Object* p0, Object* p1) { Collections::singletonMap(p0, p1); }
void frequency_test_2420(Collection* p0, Object* p1) { Collections::frequency(p0, p1); }
void disjoint_test_2421(Collection* p0, Collection* p1) { Collections::disjoint(p0, p1); }
void newSequencedSetFromMap_test_2422(SequencedMap* p0) { Collections::newSequencedSetFromMap(p0); }
void asLifoQueue_test_2423(Deque* p0) { Collections::asLifoQueue(p0); }
