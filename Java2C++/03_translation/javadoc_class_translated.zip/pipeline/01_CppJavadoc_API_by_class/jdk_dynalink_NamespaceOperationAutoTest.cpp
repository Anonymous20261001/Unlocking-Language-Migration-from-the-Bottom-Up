#include <vector>
#include <stdexcept>
#include <string>

// Forward declarations
class Operation;
class Namespace;
class NamespaceOperation;

// Base class for operations
class Operation {
public:
    virtual ~Operation() = default;
    virtual bool equals(const Operation& other) const = 0;
    virtual std::string toString() const = 0;
};

// Namespace class (simplified enum-like)
class Namespace {
public:
    enum class Type {
        UNKNOWN,
        NAMESPACE_1,
        NAMESPACE_2,
        NAMESPACE_3
    };

    Namespace(Type type = Type::UNKNOWN) : type_(type) {}
    virtual ~Namespace() = default;

    Type getType() const { return type_; }
    bool equals(const Namespace& other) const { return type_ == other.type_; }
    std::string toString() const {
        switch (type_) {
            case Type::NAMESPACE_1: return "NAMESPACE_1";
            case Type::NAMESPACE_2: return "NAMESPACE_2";
            case Type::NAMESPACE_3: return "NAMESPACE_3";
            default: return "UNKNOWN";
        }
    }

private:
    Type type_;
};

// NamespaceOperation class
class NamespaceOperation : public Operation {
public:
    // Constructor
    NamespaceOperation(Operation* baseOperation, const std::vector<Namespace*>& namespaces)
        : baseOperation_(baseOperation), namespaces_(namespaces) {
        if (baseOperation_ == nullptr) {
            throw std::invalid_argument("baseOperation cannot be null");
        }
        if (namespaces_.empty()) {
            throw std::invalid_argument("namespaces cannot be empty");
        }
    }

    // Static method: contains
    static bool contains(Operation* op, Operation* baseOperation, Namespace* namespace) {
        if (op == nullptr || baseOperation == nullptr || namespace == nullptr) {
            return false;
        }
        // Check if op is a NamespaceOperation
        NamespaceOperation* nsOp = dynamic_cast<NamespaceOperation*>(op);
        if (nsOp == nullptr) {
            return false;
        }
        // Check if baseOperation matches
        if (!nsOp->getBaseOperation()->equals(*baseOperation)) {
            return false;
        }
        // Check if namespace is in the list
        for (auto* ns : nsOp->getNamespaces()) {
            if (ns->equals(*namespace)) {
                return true;
            }
        }
        return false;
    }

    // Instance method: contains
    bool contains(Namespace* namespace) const {
        if (namespace == nullptr) {
            return false;
        }
        for (auto* ns : namespaces_) {
            if (ns->equals(*namespace)) {
                return true;
            }
        }
        return false;
    }

    // Instance method: getNamespace
    Namespace* getNamespace(int index) const {
        if (index < 0 || index >= static_cast<int>(namespaces_.size())) {
            throw std::out_of_range("Index out of bounds");
        }
        return namespaces_[index];
    }

    // Static method: getBaseOperation
    static Operation* getBaseOperation(Operation* op) {
        if (op == nullptr) {
            return nullptr;
        }
        NamespaceOperation* nsOp = dynamic_cast<NamespaceOperation*>(op);
        if (nsOp == nullptr) {
            return nullptr;
        }
        return nsOp->getBaseOperation();
    }

    // Instance method: getBaseOperation
    Operation* getBaseOperation() const {
        return baseOperation_;
    }

    // Instance method: getNamespaces
    std::vector<Namespace*> getNamespaces() const {
        return namespaces_;
    }

    // Static method: getNamespaces
    static std::vector<Namespace*> getNamespaces(Operation* op) {
        if (op == nullptr) {
            return {};
        }
        NamespaceOperation* nsOp = dynamic_cast<NamespaceOperation*>(op);
        if (nsOp == nullptr) {
            return {};
        }
        return nsOp->getNamespaces();
    }

    // Instance method: getNamespaceCount
    int getNamespaceCount() const {
        return static_cast<int>(namespaces_.size());
    }

    // Override equals
    bool equals(const Operation& other) const override {
        const NamespaceOperation* otherNsOp = dynamic_cast<const NamespaceOperation*>(&other);
        if (otherNsOp == nullptr) {
            return false;
        }
        if (!baseOperation_->equals(*otherNsOp->baseOperation_)) {
            return false;
        }
        if (namespaces_.size() != otherNsOp->namespaces_.size()) {
            return false;
        }
        for (size_t i = 0; i < namespaces_.size(); ++i) {
            if (!namespaces_[i]->equals(*otherNsOp->namespaces_[i])) {
                return false;
            }
        }
        return true;
    }

    // Override toString
    std::string toString() const override {
        std::string result = "NamespaceOperation[base=" + baseOperation_->toString() + ", namespaces=[";
        for (size_t i = 0; i < namespaces_.size(); ++i) {
            if (i > 0) result += ", ";
            result += namespaces_[i]->toString();
        }
        result += "]]";
        return result;
    }

private:
    Operation* baseOperation_;
    std::vector<Namespace*> namespaces_;
};

// Test functions (translated from Java @Test methods)
void contains_test_9483(Operation* p0, Operation* p1, Namespace* p2) {
    NamespaceOperation::contains(p0, p1, p2);
}

void contains_test_9484(Namespace* p0, Operation* c0, std::vector<Namespace*> c1) {
    NamespaceOperation instance(c0, c1);
    instance.contains(p0);
}

void getNamespace_test_9485(int p0, Operation* c0, std::vector<Namespace*> c1) {
    NamespaceOperation instance(c0, c1);
    instance.getNamespace(p0);
}

void getBaseOperation_test_9486(Operation* p0) {
    NamespaceOperation::getBaseOperation(p0);
}

void getBaseOperation_test_9487(Operation* c0, std::vector<Namespace*> c1) {
    NamespaceOperation instance(c0, c1);
    instance.getBaseOperation();
}

void getNamespaces_test_9488(Operation* c0, std::vector<Namespace*> c1) {
    NamespaceOperation instance(c0, c1);
    instance.getNamespaces();
}

void getNamespaces_test_9489(Operation* p0) {
    NamespaceOperation::getNamespaces(p0);
}

void getNamespaceCount_test_9490(Operation* c0, std::vector<Namespace*> c1) {
    NamespaceOperation instance(c0, c1);
    instance.getNamespaceCount();
}