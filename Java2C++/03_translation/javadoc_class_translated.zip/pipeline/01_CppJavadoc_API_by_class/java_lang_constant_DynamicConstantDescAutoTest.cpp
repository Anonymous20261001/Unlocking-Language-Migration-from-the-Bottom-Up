#include <string>
#include <vector>

namespace java_lang_constant {

class ConstantDesc {
public:
    virtual ~ConstantDesc() = default;
};

class ClassDesc : public ConstantDesc {
public:
    explicit ClassDesc(const std::string& descriptor) : descriptor_(descriptor) {}
    const std::string& descriptor() const { return descriptor_; }

private:
    std::string descriptor_;
};

class DirectMethodHandleDesc : public ConstantDesc {
public:
    DirectMethodHandleDesc() = default;
};

class DynamicConstantDesc : public ConstantDesc {
public:
    static DynamicConstantDesc of(DirectMethodHandleDesc* bootstrap) {
        return DynamicConstantDesc(bootstrap);
    }

    static DynamicConstantDesc of(DirectMethodHandleDesc* bootstrap,
                                   const std::vector<ConstantDesc*>& bootstrapArgs) {
        return DynamicConstantDesc(bootstrap, bootstrapArgs);
    }

    static DynamicConstantDesc ofNamed(DirectMethodHandleDesc* bootstrap,
                                       const std::string& name,
                                       ClassDesc* type,
                                       const std::vector<ConstantDesc*>& bootstrapArgs) {
        return DynamicConstantDesc(bootstrap, name, type, bootstrapArgs);
    }

    static DynamicConstantDesc ofCanonical(DirectMethodHandleDesc* bootstrap,
                                           const std::string& name,
                                           ClassDesc* type,
                                           const std::vector<ConstantDesc*>& bootstrapArgs) {
        return DynamicConstantDesc(bootstrap, name, type, bootstrapArgs);
    }

private:
    DynamicConstantDesc(DirectMethodHandleDesc* bootstrap)
        : bootstrap_(bootstrap) {}

    DynamicConstantDesc(DirectMethodHandleDesc* bootstrap,
                        const std::vector<ConstantDesc*>& bootstrapArgs)
        : bootstrap_(bootstrap), bootstrapArgs_(bootstrapArgs) {}

    DynamicConstantDesc(DirectMethodHandleDesc* bootstrap,
                        const std::string& name,
                        ClassDesc* type,
                        const std::vector<ConstantDesc*>& bootstrapArgs)
        : bootstrap_(bootstrap), name_(name), type_(type), bootstrapArgs_(bootstrapArgs) {}

    DirectMethodHandleDesc* bootstrap_;
    std::string name_;
    ClassDesc* type_;
    std::vector<ConstantDesc*> bootstrapArgs_;
};

} // namespace java_lang_constant

void of_test_4420() {
    java_lang_constant::DirectMethodHandleDesc p0;
    java_lang_constant::ClassDesc arg("I");
    std::vector<java_lang_constant::ConstantDesc*> p1 = { &arg };
    auto d = java_lang_constant::DynamicConstantDesc::of(&p0, p1);
    (void)d;
}

void of_test_4421() {
    java_lang_constant::DirectMethodHandleDesc p0;
    auto d = java_lang_constant::DynamicConstantDesc::of(&p0);
    (void)d;
}

void ofNamed_test_4422() {
    java_lang_constant::DirectMethodHandleDesc p0;
    std::string p1 = "constantName";
    java_lang_constant::ClassDesc p2("Ljava/lang/String;");
    java_lang_constant::ClassDesc arg("I");
    std::vector<java_lang_constant::ConstantDesc*> p3 = { &arg };
    auto d = java_lang_constant::DynamicConstantDesc::ofNamed(&p0, p1, &p2, p3);
    (void)d;
}

void ofCanonical_test_4423() {
    java_lang_constant::DirectMethodHandleDesc p0;
    std::string p1 = "canonicalName";
    java_lang_constant::ClassDesc p2("I");
    java_lang_constant::ClassDesc arg("J");
    std::vector<java_lang_constant::ConstantDesc*> p3 = { &arg };
    auto d = java_lang_constant::DynamicConstantDesc::ofCanonical(&p0, p1, &p2, p3);
    (void)d;
}
