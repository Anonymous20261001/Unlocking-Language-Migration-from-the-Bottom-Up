#include <memory>
#include <cstddef>

class OutputStream {
public:
    virtual ~OutputStream() = default;

    virtual void write(int b) = 0;
    virtual void write(const char* b, size_t len) = 0;
    virtual void flush() {}
    virtual void close() {}

    static std::unique_ptr<OutputStream> nullOutputStream() {
        class NullOutputStream : public OutputStream {
            void write(int b) override {}
            void write(const char* b, size_t len) override {}
        };
        return std::make_unique<NullOutputStream>();
    }
};

void nullOutputStream_test_9700() {
    OutputStream::nullOutputStream();
}