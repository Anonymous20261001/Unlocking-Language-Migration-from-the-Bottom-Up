#include <string>

class KeyManagerFactory {
public:
    static std::string getDefaultAlgorithm() {
        return "SunX509";
    }
};

void getDefaultAlgorithm_test_7628() {
    KeyManagerFactory::getDefaultAlgorithm();
}