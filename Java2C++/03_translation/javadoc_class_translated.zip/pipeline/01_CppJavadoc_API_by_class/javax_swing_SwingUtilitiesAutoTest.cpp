#include <functional>
#include <memory>
#include <string>
#include <vector>

// Forward declarations
class Component;
class Container;
class Graphics;
class Point;
class Rectangle;
class KeyEvent;
class MouseEvent;
class Action;
class ActionMap;
class Icon;
class InputMap;
class JComponent;
class JViewport;
class KeyStroke;
class FontMetrics;
class Runnable;
class Class;

// Basic geometry classes
class Point {
public:
    int x, y;
    Point() : x(0), y(0) {}
    Point(int x, int y) : x(x), y(y) {}
};

class Rectangle {
public:
    int x, y, width, height;
    Rectangle() : x(0), y(0), width(0), height(0) {}
    Rectangle(int x, int y, int width, int height) : x(x), y(y), width(width), height(height) {}
};

// Event classes
class KeyEvent {
public:
    int keyCode;
    KeyEvent() : keyCode(0) {}
};

class MouseEvent {
public:
    int x, y;
    int button;
    MouseEvent() : x(0), y(0), button(0) {}
};

// Swing component hierarchy
class Component {
public:
    virtual ~Component() = default;
    virtual bool isShowing() const { return false; }
    virtual Component* getParent() const { return nullptr; }
    virtual std::string getName() const { return ""; }
    virtual void setBounds(int x, int y, int w, int h) {}
    virtual Rectangle getBounds() const { return Rectangle(); }
    virtual Point getLocation() const { return Point(); }
    virtual int getWidth() const { return 0; }
    virtual int getHeight() const { return 0; }
    virtual bool contains(int x, int y) const { return false; }
    virtual void paint(Graphics* g) {}
};

class Container : public Component {
public:
    std::vector<Component*> children;
    virtual void add(Component* comp) { children.push_back(comp); }
    virtual int getComponentCount() const { return children.size(); }
    virtual Component* getComponent(int index) const { return children[index]; }
};

class JComponent : public Container {
public:
    virtual void updateUI() {}
};

class JViewport : public JComponent {
public:
    Component* view;
    JViewport() : view(nullptr) {}
    virtual Component* getView() const { return view; }
    virtual void setView(Component* v) { view = v; }
};

class Window : public Container {
public:
    std::string title;
};

// Graphics class
class Graphics {
public:
    virtual ~Graphics() = default;
    virtual void drawRect(int x, int y, int w, int h) {}
    virtual void fillRect(int x, int y, int w, int h) {}
};

// Font metrics
class FontMetrics {
public:
    virtual int stringWidth(const std::string& str) const { return str.length() * 10; }
    virtual int getHeight() const { return 20; }
    virtual int getAscent() const { return 15; }
    virtual int getDescent() const { return 5; }
};

// Action and related classes
class Action {
public:
    virtual ~Action() = default;
    virtual void actionPerformed() {}
};

class ActionMap {
public:
    std::vector<std::pair<std::string, Action*>> actions;
    virtual void put(const std::string& key, Action* action) { actions.push_back({key, action}); }
    virtual Action* get(const std::string& key) const {
        for (auto& pair : actions) {
            if (pair.first == key) return pair.second;
        }
        return nullptr;
    }
};

class InputMap {
public:
    std::vector<std::pair<KeyStroke*, Action*>> bindings;
    virtual void put(KeyStroke* key, Action* action) { bindings.push_back({key, action}); }
};

class KeyStroke {
public:
    int keyCode;
    KeyStroke(int code) : keyCode(code) {}
};

class Icon {
public:
    virtual ~Icon() = default;
    virtual int getIconWidth() const { return 0; }
    virtual int getIconHeight() const { return 0; }
    virtual void paintIcon(Component* c, Graphics* g, int x, int y) {}
};

class Runnable {
public:
    virtual ~Runnable() = default;
    virtual void run() = 0;
};

class Class {
public:
    std::string name;
    Class(const std::string& n) : name(n) {}
    virtual bool isInstance(Component* c) const { return false; }
};

// SwingUtilities class
class SwingUtilities {
public:
    static Component* getUnwrappedParent(Component* p0) {
        return p0 ? p0->getParent() : nullptr;
    }

    static bool isEventDispatchThread() {
        return true;
    }

    static void updateComponentTreeUI(Component* p0) {
        if (p0) {
            JComponent* jc = dynamic_cast<JComponent*>(p0);
            if (jc) jc->updateUI();
        }
    }

    static bool isDescendingFrom(Component* p0, Component* p1) {
        if (!p0 || !p1) return false;
        Component* current = p0;
        while (current) {
            if (current == p1) return true;
            current = current->getParent();
        }
        return false;
    }

    static ActionMap* getUIActionMap(JComponent* p0) {
        return p0 ? new ActionMap() : nullptr;
    }

    static Component* getRootPane(Component* p0) {
        return p0 ? p0->getParent() : nullptr;
    }

    static Component* getWindowAncestor(Component* p0) {
        if (!p0) return nullptr;
        Component* current = p0;
        while (current) {
            if (dynamic_cast<Window*>(current)) return current;
            current = current->getParent();
        }
        return nullptr;
    }

    static Rectangle computeIntersection(int p0, int p1, int p2, int p3, Rectangle* p4) {
        if (!p4) return Rectangle();
        int x1 = std::max(p0, p4->x);
        int y1 = std::max(p1, p4->y);
        int x2 = std::min(p0 + p2, p4->x + p4->width);
        int y2 = std::min(p1 + p3, p4->y + p4->height);
        if (x2 < x1 || y2 < y1) return Rectangle();
        return Rectangle(x1, y1, x2 - x1, y2 - y1);
    }

    static void paintComponent(Graphics* p0, Component* p1, Container* p2, Rectangle* p3) {
        if (p0 && p1) p1->paint(p0);
    }

    static void paintComponent(Graphics* p0, Component* p1, Container* p2, int p3, int p4, int p5, int p6) {
        if (p0 && p1) p1->paint(p0);
    }

    static bool processKeyBindings(KeyEvent* p0) {
        return false;
    }

    static void notifyAction(Action* p0, KeyStroke* p1, KeyEvent* p2, Object* p3, int p4) {
        if (p0) p0->actionPerformed();
    }

    static Rectangle convertRectangle(Component* p0, Rectangle* p1, Component* p2) {
        return p1 ? *p1 : Rectangle();
    }

    static void invokeLater(Runnable* p0) {
        if (p0) p0->run();
    }

    static int getAccessibleChildrenCount(Component* p0) {
        Container* c = dynamic_cast<Container*>(p0);
        return c ? c->getComponentCount() : 0;
    }

    static Component* getAccessibleChild(Component* p0, int p1) {
        Container* c = dynamic_cast<Container*>(p0);
        return c ? c->getComponent(p1) : nullptr;
    }

    static Component* getAccessibleAt(Component* p0, Point* p1) {
        return p0;
    }

    static int getAccessibleIndexInParent(Component* p0) {
        return 0;
    }

    static int getAccessibleStateSet(Component* p0) {
        return 0;
    }

    static Point convertPoint(Component* p0, Point* p1, Component* p2) {
        return p1 ? *p1 : Point();
    }

    static Point convertPoint(Component* p0, int p1, int p2, Component* p3) {
        return Point(p1, p2);
    }

    static MouseEvent convertMouseEvent(Component* p0, MouseEvent* p1, Component* p2) {
        return p1 ? *p1 : MouseEvent();
    }

    static void replaceUIInputMap(JComponent* p0, int p1, InputMap* p2) {}

    static void replaceUIActionMap(JComponent* p0, ActionMap* p1) {}

    static InputMap* getUIInputMap(JComponent* p0, int p1) {
        return p0 ? new InputMap() : nullptr;
    }

    static bool isLeftMouseButton(MouseEvent* p0) {
        return p0 && p0->button == 1;
    }

    static std::string layoutCompoundLabel(FontMetrics* p0, const std::string& p1, Icon* p2, int p3, int p4, int p5, int p6, Rectangle* p7, Rectangle* p8, Rectangle* p9, int p10) {
        return p1;
    }

    static std::string layoutCompoundLabel(JComponent* p0, FontMetrics* p1, const std::string& p2, Icon* p3, int p4, int p5, int p6, int p7, Rectangle* p8, Rectangle* p9, Rectangle* p10, int p11) {
        return p2;
    }

    static Component* getAncestorOfClass(Class* p0, Component* p1) {
        if (!p1) return nullptr;
        Component* current = p1->getParent();
        while (current) {
            if (p0->isInstance(current)) return current;
            current = current->getParent();
        }
        return nullptr;
    }

    static void convertPointToScreen(Point* p0, Component* p1) {}

    static void convertPointFromScreen(Point* p0, Component* p1) {}

    static Component* getDeepestComponentAt(Component* p0, int p1, int p2) {
        return p0;
    }

    static bool isRectangleContainingRectangle(Rectangle* p0, Rectangle* p1) {
        if (!p0 || !p1) return false;
        return p0->x <= p1->x && p0->y <= p1->y &&
               (p0->x + p0->width) >= (p1->x + p1->width) &&
               (p0->y + p0->height) >= (p1->y + p1->height);
    }

    static Rectangle getLocalBounds(Component* p0) {
        return p0 ? Rectangle(0, 0, p0->getWidth(), p0->getHeight()) : Rectangle();
    }

    static Component* getAncestorNamed(const std::string& p0, Component* p1) {
        if (!p1) return nullptr;
        Component* current = p1->getParent();
        while (current) {
            if (current->getName() == p0) return current;
            current = current->getParent();
        }
        return nullptr;
    }

    static Component* windowForComponent(Component* p0) {
        return getWindowAncestor(p0);
    }

    static Rectangle computeUnion(int p0, int p1, int p2, int p3, Rectangle* p4) {
        if (!p4) return Rectangle();
        int x1 = std::min(p0, p4->x);
        int y1 = std::min(p1, p4->y);
        int x2 = std::max(p0 + p2, p4->x + p4->width);
        int y2 = std::max(p1 + p3, p4->y + p4->height);
        return Rectangle(x1, y1, x2 - x1, y2 - y1);
    }

    static std::vector<Rectangle> computeDifference(Rectangle* p0, Rectangle* p1) {
        std::vector<Rectangle> result;
        if (!p0 || !p1) return result;
        // Simple implementation - return original if no overlap
        result.push_back(*p0);
        return result;
    }

    static bool isMiddleMouseButton(MouseEvent* p0) {
        return p0 && p0->button == 2;
    }

    static bool isRightMouseButton(MouseEvent* p0) {
        return p0 && p0->button == 3;
    }

    static int computeStringWidth(FontMetrics* p0, const std::string& p1) {
        return p0 ? p0->stringWidth(p1) : 0;
    }

    static Component* findFocusOwner(Component* p0) {
        return p0;
    }

    static Rectangle calculateInnerArea(JComponent* p0, Rectangle* p1) {
        return p1 ? *p1 : Rectangle();
    }

    static Component* getUnwrappedView(JViewport* p0) {
        return p0 ? p0->getView() : nullptr;
    }

    static Component* getRoot(Component* p0) {
        if (!p0) return nullptr;
        Component* current = p0;
        while (current->getParent()) {
            current = current->getParent();
        }
        return current;
    }
};

// Test functions
void getUnwrappedParent_test_12073(Component* p0) {
    SwingUtilities::getUnwrappedParent(p0);
}

void isEventDispatchThread_test_12074() {
    SwingUtilities::isEventDispatchThread();
}

void updateComponentTreeUI_test_12075(Component* p0) {
    SwingUtilities::updateComponentTreeUI(p0);
}

void isDescendingFrom_test_12076(Component* p0, Component* p1) {
    SwingUtilities::isDescendingFrom(p0, p1);
}

void getUIActionMap_test_12077(JComponent* p0) {
    SwingUtilities::getUIActionMap(p0);
}

void getRootPane_test_12078(Component* p0) {
    SwingUtilities::getRootPane(p0);
}

void getWindowAncestor_test_12079(Component* p0) {
    SwingUtilities::getWindowAncestor(p0);
}

void computeIntersection_test_12080(int p0, int p1, int p2, int p3, Rectangle* p4) {
    SwingUtilities::computeIntersection(p0, p1, p2, p3, p4);
}

void paintComponent_test_12081(Graphics* p0, Component* p1, Container* p2, Rectangle* p3) {
    SwingUtilities::paintComponent(p0, p1, p2, p3);
}

void paintComponent_test_12082(Graphics* p0, Component* p1, Container* p2, int p3, int p4, int p5, int p6) {
    SwingUtilities::paintComponent(p0, p1, p2, p3, p4, p5, p6);
}

void processKeyBindings_test_12083(KeyEvent* p0) {
    SwingUtilities::processKeyBindings(p0);
}

void notifyAction_test_12084(Action* p0, KeyStroke* p1, KeyEvent* p2, Object* p3, int p4) {
    SwingUtilities::notifyAction(p0, p1, p2, p3, p4);
}

void convertRectangle_test_12085(Component* p0, Rectangle* p1, Component* p2) {
    SwingUtilities::convertRectangle(p0, p1, p2);
}

void invokeLater_test_12086(Runnable* p0) {
    SwingUtilities::invokeLater(p0);
}

void getAccessibleChildrenCount_test_12087(Component* p0) {
    SwingUtilities::getAccessibleChildrenCount(p0);
}

void getAccessibleChild_test_12088(Component* p0, int p1) {
    SwingUtilities::getAccessibleChild(p0, p1);
}

void getAccessibleAt_test_12089(Component* p0, Point* p1) {
    SwingUtilities::getAccessibleAt(p0, p1);
}

void getAccessibleIndexInParent_test_12090(Component* p0) {
    SwingUtilities::getAccessibleIndexInParent(p0);
}

void getAccessibleStateSet_test_12091(Component* p0) {
    SwingUtilities::getAccessibleStateSet(p0);
}

void convertPoint_test_12092(Component* p0, Point* p1, Component* p2) {
    SwingUtilities::convertPoint(p0, p1, p2);
}

void convertPoint_test_12093(Component* p0, int p1, int p2, Component* p3) {
    SwingUtilities::convertPoint(p0, p1, p2, p3);
}

void convertMouseEvent_test_12094(Component* p0, MouseEvent* p1, Component* p2) {
    SwingUtilities::convertMouseEvent(p0, p1, p2);
}

void replaceUIInputMap_test_12095(JComponent* p0, int p1, InputMap* p2) {
    SwingUtilities::replaceUIInputMap(p0, p1, p2);
}

void replaceUIActionMap_test_12096(JComponent* p0, ActionMap* p1) {
    SwingUtilities::replaceUIActionMap(p0, p1);
}

void getUIInputMap_test_12097(JComponent* p0, int p1) {
    SwingUtilities::getUIInputMap(p0, p1);
}

void isLeftMouseButton_test_12098(MouseEvent* p0) {
    SwingUtilities::isLeftMouseButton(p0);
}

void layoutCompoundLabel_test_12099(FontMetrics* p0, const std::string& p1, Icon* p2, int p3, int p4, int p5, int p6, Rectangle* p7, Rectangle* p8, Rectangle* p9, int p10) {
    SwingUtilities::layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
}

void layoutCompoundLabel_test_12100(JComponent* p0, FontMetrics* p1, const std::string& p2, Icon* p3, int p4, int p5, int p6, int p7, Rectangle* p8, Rectangle* p9, Rectangle* p10, int p11) {
    SwingUtilities::layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11);
}

void getAncestorOfClass_test_12101(Class* p0, Component* p1) {
    SwingUtilities::getAncestorOfClass(p0, p1);
}

void convertPointToScreen_test_12102(Point* p0, Component* p1) {
    SwingUtilities::convertPointToScreen(p0, p1);
}

void convertPointFromScreen_test_12103(Point* p0, Component* p1) {
    SwingUtilities::convertPointFromScreen(p0, p1);
}

void getDeepestComponentAt_test_12104(Component* p0, int p1, int p2) {
    SwingUtilities::getDeepestComponentAt(p0, p1, p2);
}

void isRectangleContainingRectangle_test_12105(Rectangle* p0, Rectangle* p1) {
    SwingUtilities::isRectangleContainingRectangle(p0, p1);
}

void getLocalBounds_test_12106(Component* p0) {
    SwingUtilities::getLocalBounds(p0);
}

void getAncestorNamed_test_12107(const std::string& p0, Component* p1) {
    SwingUtilities::getAncestorNamed(p0, p1);
}

void windowForComponent_test_12108(Component* p0) {
    SwingUtilities::windowForComponent(p0);
}

void computeUnion_test_12109(int p0, int p1, int p2, int p3, Rectangle* p4) {
    SwingUtilities::computeUnion(p0, p1, p2, p3, p4);
}

void computeDifference_test_12110(Rectangle* p0, Rectangle* p1) {
    SwingUtilities::computeDifference(p0, p1);
}

void isMiddleMouseButton_test_12111(MouseEvent* p0) {
    SwingUtilities::isMiddleMouseButton(p0);
}

void isRightMouseButton_test_12112(MouseEvent* p0) {
    SwingUtilities::isRightMouseButton(p0);
}

void computeStringWidth_test_12113(FontMetrics* p0, const std::string& p1) {
    SwingUtilities::computeStringWidth(p0, p1);
}

void findFocusOwner_test_12114(Component* p0) {
    SwingUtilities::findFocusOwner(p0);
}

void calculateInnerArea_test_12115(JComponent* p0, Rectangle* p1) {
    SwingUtilities::calculateInnerArea(p0, p1);
}

void getUnwrappedView_test_12116(JViewport* p0) {
    SwingUtilities::getUnwrappedView(p0);
}

void getRoot_test_12117(Component* p0) {
    SwingUtilities::getRoot(p0);
}