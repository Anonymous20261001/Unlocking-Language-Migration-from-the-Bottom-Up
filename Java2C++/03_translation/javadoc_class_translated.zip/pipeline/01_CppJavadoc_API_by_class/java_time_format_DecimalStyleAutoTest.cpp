#include <set>
#include <string>

class Locale {
public:
    Locale() = default;
    explicit Locale(const std::string& language) : language_(language) {}

    const std::string& getLanguage() const { return language_; }

    bool operator<(const Locale& other) const { return language_ < other.language_; }
    bool operator==(const Locale& other) const { return language_ == other.language_; }

    static Locale getDefault() {
        return Locale("en");
    }

private:
    std::string language_;
};

class DecimalStyle {
public:
    DecimalStyle() = default;
    explicit DecimalStyle(const Locale& locale) : locale_(locale) {}

    static DecimalStyle of(const Locale& locale) {
        return DecimalStyle(locale);
    }

    static std::set<Locale> getAvailableLocales() {
        std::set<Locale> locales;
        locales.insert(Locale("en"));
        locales.insert(Locale("fr"));
        locales.insert(Locale("de"));
        locales.insert(Locale("ja"));
        return locales;
    }

    static DecimalStyle ofDefaultLocale() {
        return of(Locale::getDefault());
    }

private:
    Locale locale_;
};

void of_test_3542(Locale p0) {
    DecimalStyle::of(p0);
}

void getAvailableLocales_test_3543() {
    DecimalStyle::getAvailableLocales();
}

void ofDefaultLocale_test_3544() {
    DecimalStyle::ofDefaultLocale();
}