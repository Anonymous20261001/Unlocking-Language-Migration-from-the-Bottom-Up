#include <string>
#include <stdexcept>

class RoleInfo {
public:
    RoleInfo(const std::string& name,
             const std::string& refMBeanClassName,
             bool readable,
             bool writable,
             int minDegree,
             int maxDegree,
             const std::string& description = "")
        : name_(name),
          refMBeanClassName_(refMBeanClassName),
          readable_(readable),
          writable_(writable),
          minDegree_(minDegree),
          maxDegree_(maxDegree),
          description_(description) {
        if (minDegree_ < -1 || maxDegree_ < -1) {
            throw std::invalid_argument("Degree must be -1 or greater");
        }
        if (minDegree_ != -1 && maxDegree_ != -1 && minDegree_ > maxDegree_) {
            throw std::invalid_argument("Min degree cannot exceed max degree");
        }
    }

    RoleInfo(const RoleInfo&) = default;
    RoleInfo& operator=(const RoleInfo&) = default;

    std::string getDescription() const { return description_; }
    int getMinDegree() const { return minDegree_; }
    int getMaxDegree() const { return maxDegree_; }

    void checkMinDegree(int value) const {
        if (value < -1 || (maxDegree_ != -1 && value > maxDegree_)) {
            throw std::invalid_argument("Invalid min degree");
        }
    }

    void checkMaxDegree(int value) const {
        if (value < -1 || (minDegree_ != -1 && value < minDegree_)) {
            throw std::invalid_argument("Invalid max degree");
        }
    }

    std::string getRefMBeanClassName() const { return refMBeanClassName_; }
    std::string getName() const { return name_; }
    bool isWritable() const { return writable_; }
    bool isReadable() const { return readable_; }

private:
    std::string name_;
    std::string refMBeanClassName_;
    bool readable_;
    bool writable_;
    int minDegree_;
    int maxDegree_;
    std::string description_;
};

void getDescription_test_10645(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.getDescription();
}

void getMinDegree_test_10646(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.getMinDegree();
}

void getMaxDegree_test_10647(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.getMaxDegree();
}

void checkMinDegree_test_10648(int p0, const RoleInfo& c0) {
    RoleInfo instance(c0);
    instance.checkMinDegree(p0);
}

void checkMaxDegree_test_10649(int p0, const RoleInfo& c0) {
    RoleInfo instance(c0);
    instance.checkMaxDegree(p0);
}

void getRefMBeanClassName_test_10650(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.getRefMBeanClassName();
}

void getName_test_10651(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.getName();
}

void isWritable_test_10652(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.isWritable();
}

void isReadable_test_10653(const RoleInfo& c0) {
    RoleInfo instance(c0);
    (void)instance.isReadable();
}