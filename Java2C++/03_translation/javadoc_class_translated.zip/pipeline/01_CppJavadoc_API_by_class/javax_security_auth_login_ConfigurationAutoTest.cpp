class Configuration {
public:
    static void setConfiguration(Configuration* config) {
        instance_ = config;
    }
    static Configuration* getConfiguration() {
        return instance_;
    }
    virtual ~Configuration() = default;
protected:
    Configuration() = default;
private:
    static Configuration* instance_;
};

Configuration* Configuration::instance_ = nullptr;

void setConfiguration_test_2906(Configuration* p0) {
    Configuration::setConfiguration(p0);
}

void getConfiguration_test_2907() {
    Configuration::getConfiguration();
}