#include <vector>
#include <memory>
#include <string>
#include <stdexcept>
#include <utility>

namespace javax {
namespace security {
namespace sasl {

class SaslClientFactory {
public:
    virtual ~SaslClientFactory() = default;
};

class SaslServerFactory {
public:
    virtual ~SaslServerFactory() = default;
};

template <typename T>
class Enumeration {
public:
    virtual ~Enumeration() = default;
    virtual bool hasMoreElements() const = 0;
    virtual T nextElement() = 0;
};

template <typename T>
class VectorEnumeration : public Enumeration<T> {
public:
    explicit VectorEnumeration(std::vector<T> items) : items_(std::move(items)), index_(0) {}

    bool hasMoreElements() const override {
        return index_ < items_.size();
    }

    T nextElement() override {
        if (index_ >= items_.size()) {
            throw std::out_of_range("No more elements");
        }
        return items_[index_++];
    }

private:
    std::vector<T> items_;
    std::size_t index_;
};

class Sasl {
public:
    static std::unique_ptr<Enumeration<std::shared_ptr<SaslClientFactory>>> getSaslClientFactories() {
        std::vector<std::shared_ptr<SaslClientFactory>> factories;
        return std::make_unique<VectorEnumeration<std::shared_ptr<SaslClientFactory>>>(std::move(factories));
    }

    static std::unique_ptr<Enumeration<std::shared_ptr<SaslServerFactory>>> getSaslServerFactories() {
        std::vector<std::shared_ptr<SaslServerFactory>> factories;
        return std::make_unique<VectorEnumeration<std::shared_ptr<SaslServerFactory>>>(std::move(factories));
    }
};

} // namespace sasl
} // namespace security
} // namespace javax

using namespace javax::security::sasl;

void getSaslClientFactories_test_10758() {
    Sasl::getSaslClientFactories();
}

void getSaslServerFactories_test_10759() {
    Sasl::getSaslServerFactories();
}