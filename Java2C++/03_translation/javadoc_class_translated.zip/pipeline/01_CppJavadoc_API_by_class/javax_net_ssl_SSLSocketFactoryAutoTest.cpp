class SSLSocketFactory {
public:
    static SSLSocketFactory& getDefault() {
        static SSLSocketFactory instance;
        return instance;
    }
private:
    SSLSocketFactory() = default;
    SSLSocketFactory(const SSLSocketFactory&) = delete;
    SSLSocketFactory& operator=(const SSLSocketFactory&) = delete;
};

void getDefault_test_11440() {
    SSLSocketFactory::getDefault();
}