#include <vector>
#include <cmath>

class Point2D {
public:
    double x, y;
    Point2D() : x(0), y(0) {}
    Point2D(double x, double y) : x(x), y(y) {}
};

class Rectangle2D {
public:
    double x, y, width, height;
    Rectangle2D() : x(0), y(0), width(0), height(0) {}
    Rectangle2D(double x, double y, double w, double h) : x(x), y(y), width(w), height(h) {}
};

class PathIterator {
public:
    static const int WIND_EVEN_ODD = 0;
    static const int WIND_NON_ZERO = 1;
    static const int SEG_MOVETO = 0;
    static const int SEG_LINETO = 1;
    static const int SEG_QUADTO = 2;
    static const int SEG_CUBICTO = 3;
    static const int SEG_CLOSE = 4;

    virtual ~PathIterator() {}
    virtual int getWindingRule() const = 0;
    virtual bool isDone() const = 0;
    virtual void next() = 0;
    virtual int currentSegment(double* coords) = 0;
};

namespace {
    struct LineSeg {
        double x0, y0, x1, y1;
        LineSeg(double x0_, double y0_, double x1_, double y1_)
            : x0(x0_), y0(y0_), x1(x1_), y1(y1_) {}
    };

    void addLine(std::vector<LineSeg>& segs, double x0, double y0, double x1, double y1) {
        segs.push_back(LineSeg(x0, y0, x1, y1));
    }

    void flattenQuad(std::vector<LineSeg>& segs,
                     double sx, double sy, double cx, double cy, double ex, double ey) {
        const int n = 10;
        double prevX = sx;
        double prevY = sy;
        for (int i = 1; i <= n; ++i) {
            double t = static_cast<double>(i) / n;
            double mt = 1.0 - t;
            double x = mt * mt * sx + 2.0 * mt * t * cx + t * t * ex;
            double y = mt * mt * sy + 2.0 * mt * t * cy + t * t * ey;
            addLine(segs, prevX, prevY, x, y);
            prevX = x;
            prevY = y;
        }
    }

    void flattenCubic(std::vector<LineSeg>& segs,
                      double sx, double sy,
                      double c1x, double c1y,
                      double c2x, double c2y,
                      double ex, double ey) {
        const int n = 10;
        double prevX = sx;
        double prevY = sy;
        for (int i = 1; i <= n; ++i) {
            double t = static_cast<double>(i) / n;
            double mt = 1.0 - t;
            double x = mt * mt * mt * sx + 3.0 * mt * mt * t * c1x + 3.0 * mt * t * t * c2x + t * t * t * ex;
            double y = mt * mt * mt * sy + 3.0 * mt * mt * t * c1y + 3.0 * mt * t * t * c2y + t * t * t * ey;
            addLine(segs, prevX, prevY, x, y);
            prevX = x;
            prevY = y;
        }
    }

    void flattenPath(PathIterator& pi, std::vector<LineSeg>& segs) {
        double coords[6];
        double startX = 0.0;
        double startY = 0.0;
        double curX = 0.0;
        double curY = 0.0;

        while (!pi.isDone()) {
            int seg = pi.currentSegment(coords);
            switch (seg) {
                case PathIterator::SEG_MOVETO:
                    curX = coords[0];
                    curY = coords[1];
                    startX = curX;
                    startY = curY;
                    break;
                case PathIterator::SEG_LINETO:
                    addLine(segs, curX, curY, coords[0], coords[1]);
                    curX = coords[0];
                    curY = coords[1];
                    break;
                case PathIterator::SEG_QUADTO:
                    flattenQuad(segs, curX, curY, coords[0], coords[1], coords[2], coords[3]);
                    curX = coords[2];
                    curY = coords[3];
                    break;
                case PathIterator::SEG_CUBICTO:
                    flattenCubic(segs, curX, curY,
                                 coords[0], coords[1],
                                 coords[2], coords[3],
                                 coords[4], coords[5]);
                    curX = coords[4];
                    curY = coords[5];
                    break;
                case PathIterator::SEG_CLOSE:
                    if (curX != startX || curY != startY) {
                        addLine(segs, curX, curY, startX, startY);
                    }
                    curX = startX;
                    curY = startY;
                    break;
                default:
                    break;
            }
            pi.next();
        }
    }

    bool containsPoint(const std::vector<LineSeg>& segs, int windingRule, double x, double y) {
        int winding = 0;
        for (const auto& s : segs) {
            double x0 = s.x0;
            double y0 = s.y0;
            double x1 = s.x1;
            double y1 = s.y1;

            if (y0 <= y) {
                if (y1 > y) {
                    double cross = (x1 - x0) * (y - y0) - (x - x0) * (y1 - y0);
                    if (cross > 0) ++winding;
                }
            } else {
                if (y1 <= y) {
                    double cross = (x1 - x0) * (y - y0) - (x - x0) * (y1 - y0);
                    if (cross < 0) --winding;
                }
            }
        }

        if (windingRule == PathIterator::WIND_EVEN_ODD) {
            return (winding & 1) != 0;
        }
        return winding != 0;
    }

    bool lineRectIntersect(double x0, double y0, double x1, double y1,
                           double rx, double ry, double rw, double rh) {
        double dx = x1 - x0;
        double dy = y1 - y0;
        double p[4] = {-dx, dx, -dy, dy};
        double q[4] = {x0 - rx, rx + rw - x0, y0 - ry, ry + rh - y0};
        double u1 = 0.0;
        double u2 = 1.0;

        for (int i = 0; i < 4; ++i) {
            if (p[i] == 0.0) {
                if (q[i] < 0.0) return false;
            } else {
                double t = q[i] / p[i];
                if (p[i] < 0.0) {
                    if (t > u2) return false;
                    if (t > u1) u1 = t;
                } else {
                    if (t < u1) return false;
                    if (t < u2) u2 = t;
                }
            }
        }
        return true;
    }

    bool pathIntersectsRect(const std::vector<LineSeg>& segs, int rule,
                            double rx, double ry, double rw, double rh) {
        for (const auto& s : segs) {
            if (lineRectIntersect(s.x0, s.y0, s.x1, s.y1, rx, ry, rw, rh)) {
                return true;
            }
        }
        double cx = rx + rw / 2.0;
        double cy = ry + rh / 2.0;
        return containsPoint(segs, rule, cx, cy);
    }

    bool pathContainsRect(const std::vector<LineSeg>& segs, int rule,
                          double rx, double ry, double rw, double rh) {
        for (const auto& s : segs) {
            if (lineRectIntersect(s.x0, s.y0, s.x1, s.y1, rx, ry, rw, rh)) {
                return false;
            }
        }
        if (!containsPoint(segs, rule, rx, ry)) return false;
        if (!containsPoint(segs, rule, rx + rw, ry)) return false;
        if (!containsPoint(segs, rule, rx, ry + rh)) return false;
        if (!containsPoint(segs, rule, rx + rw, ry + rh)) return false;
        return true;
    }
}

class Path2D {
public:
    static bool contains(PathIterator& pi, double x, double y) {
        int rule = pi.getWindingRule();
        std::vector<LineSeg> segs;
        flattenPath(pi, segs);
        return containsPoint(segs, rule, x, y);
    }

    static bool contains(PathIterator& pi, const Point2D& p) {
        return contains(pi, p.x, p.y);
    }

    static bool contains(PathIterator& pi, double x, double y, double w, double h) {
        int rule = pi.getWindingRule();
        std::vector<LineSeg> segs;
        flattenPath(pi, segs);
        return pathContainsRect(segs, rule, x, y, w, h);
    }

    static bool contains(PathIterator& pi, const Rectangle2D& r) {
        return contains(pi, r.x, r.y, r.width, r.height);
    }

    static bool intersects(PathIterator& pi, double x, double y, double w, double h) {
        int rule = pi.getWindingRule();
        std::vector<LineSeg> segs;
        flattenPath(pi, segs);
        return pathIntersectsRect(segs, rule, x, y, w, h);
    }

    static bool intersects(PathIterator& pi, const Rectangle2D& r) {
        return intersects(pi, r.x, r.y, r.width, r.height);
    }
};

void contains_test_9835(PathIterator& p0, double p1, double p2, double p3, double p4) {
    Path2D::contains(p0, p1, p2, p3, p4);
}

void contains_test_9836(PathIterator& p0, const Rectangle2D& p1) {
    Path2D::contains(p0, p1);
}

void contains_test_9837(PathIterator& p0, double p1, double p2) {
    Path2D::contains(p0, p1, p2);
}

void contains_test_9838(PathIterator& p0, const Point2D& p1) {
    Path2D::contains(p0, p1);
}

void intersects_test_9839(PathIterator& p0, double p1, double p2, double p3, double p4) {
    Path2D::intersects(p0, p1, p2, p3, p4);
}

void intersects_test_9840(PathIterator& p0, const Rectangle2D& p1) {
    Path2D::intersects(p0, p1);
}
