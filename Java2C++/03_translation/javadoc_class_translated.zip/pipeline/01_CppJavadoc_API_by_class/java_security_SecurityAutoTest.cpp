#include <string>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <algorithm>

using String = std::string;
using Map = std::map<String, String>;

class Provider {
public:
    Provider(const String& name, double version, const String& info)
        : name_(name), version_(version), info_(info) {}

    const String& getName() const { return name_; }
    double getVersion() const { return version_; }
    const String& getInfo() const { return info_; }

    void put(const String& key, const String& value) {
        properties_[key] = value;
    }

    String getProperty(const String& key) const {
        auto it = properties_.find(key);
        return it == properties_.end() ? String() : it->second;
    }

    const Map& getProperties() const {
        return properties_;
    }

private:
    String name_;
    double version_;
    String info_;
    Map properties_;
};

class Security {
public:
    static String getProperty(const String& key) {
        auto it = props_.find(key);
        return it == props_.end() ? String() : it->second;
    }

    static void setProperty(const String& key, const String& datum) {
        props_[key] = datum;
    }

    static int addProvider(const Provider& provider) {
        return insertProviderAt(provider, static_cast<int>(providers_.size()) + 1);
    }

    static int insertProviderAt(const Provider& provider, int position) {
        for (const auto& p : providers_) {
            if (p->getName() == provider.getName()) {
                return -1;
            }
        }

        auto ptr = std::make_shared<Provider>(provider);
        int n = static_cast<int>(providers_.size());

        if (position <= 0 || position > n + 1) {
            providers_.push_back(ptr);
            return n + 1;
        }

        providers_.insert(providers_.begin() + (position - 1), ptr);
        return position;
    }

    static std::shared_ptr<Provider> getProvider(const String& name) {
        for (const auto& p : providers_) {
            if (p->getName() == name) {
                return p;
            }
        }
        return nullptr;
    }

    static std::vector<Provider> getProviders() {
        std::vector<Provider> result;
        for (const auto& p : providers_) {
            result.push_back(*p);
        }
        return result;
    }

    static std::vector<Provider> getProviders(const Map& filter) {
        std::vector<Provider> result;
        if (filter.empty()) {
            return getProviders();
        }

        for (const auto& p : providers_) {
            bool matches = true;

            for (const auto& kv : filter) {
                const String& key = kv.first;
                const String& expected = kv.second;
                String actual = p->getProperty(key);

                if (expected.empty()) {
                    if (actual.empty() && p->getProperty("Alg.Alias." + key).empty()) {
                        bool foundPrefix = false;
                        for (const auto& prop : p->getProperties()) {
                            if (prop.first == key ||
                                prop.first.rfind(key + ".", 0) == 0 ||
                                prop.first == "Alg.Alias." + key ||
                                prop.first.rfind("Alg.Alias." + key + ".", 0) == 0) {
                                foundPrefix = true;
                                break;
                            }
                        }
                        if (!foundPrefix) {
                            matches = false;
                            break;
                        }
                    }
                } else {
                    if (actual != expected && p->getProperty("Alg.Alias." + key) != expected) {
                        matches = false;
                        break;
                    }
                }
            }

            if (matches) {
                result.push_back(*p);
            }
        }

        return result;
    }

    static std::vector<Provider> getProviders(const String& filter) {
        std::vector<Provider> result;
        if (filter.empty()) {
            return getProviders();
        }

        String prefix = filter + ".";
        String aliasPrefix = "Alg.Alias." + filter + ".";

        for (const auto& p : providers_) {
            bool found = false;
            for (const auto& prop : p->getProperties()) {
                const String& key = prop.first;
                if (key == filter ||
                    key.rfind(prefix, 0) == 0 ||
                    key == "Alg.Alias." + filter ||
                    key.rfind(aliasPrefix, 0) == 0) {
                    found = true;
                    break;
                }
            }
            if (found) {
                result.push_back(*p);
            }
        }

        return result;
    }

    static String getAlgorithmProperty(const String& algName, const String& propName) {
        String key = algName + "." + propName;
        for (const auto& p : providers_) {
            String value = p->getProperty(key);
            if (!value.empty()) {
                return value;
            }
        }
        return String();
    }

    static void removeProvider(const String& name) {
        providers_.erase(
            std::remove_if(
                providers_.begin(),
                providers_.end(),
                [&](const std::shared_ptr<Provider>& p) {
                    return p->getName() == name;
                }),
            providers_.end());
    }

    static std::set<String> getAlgorithms(const String& serviceName) {
        std::set<String> result;
        String servicePrefix = serviceName + ".";
        String aliasPrefix = "Alg.Alias." + serviceName + ".";

        for (const auto& p : providers_) {
            for (const auto& prop : p->getProperties()) {
                const String& key = prop.first;

                if (key.rfind(servicePrefix, 0) == 0) {
                    String alg = key.substr(servicePrefix.size());
                    if (!alg.empty()) {
                        result.insert(alg);
                    }
                } else if (key.rfind(aliasPrefix, 0) == 0) {
                    String alg = key.substr(aliasPrefix.size());
                    if (!alg.empty()) {
                        result.insert(alg);
                    }
                }
            }
        }

        return result;
    }

private:
    static Map props_;
    static std::vector<std::shared_ptr<Provider>> providers_;
};

Map Security::props_;
std::vector<std::shared_ptr<Provider>> Security::providers_;

void getProperty_test_10968(String p0) {
    Security::getProperty(p0);
}

void setProperty_test_10969(String p0, String p1) {
    Security::setProperty(p0, p1);
}

void addProvider_test_10970(Provider p0) {
    Security::addProvider(p0);
}

void insertProviderAt_test_10971(Provider p0, int p1) {
    Security::insertProviderAt(p0, p1);
}

void getProvider_test_10972(String p0) {
    Security::getProvider(p0);
}

void getProviders_test_10973() {
    Security::getProviders();
}

void getProviders_test_10974(Map p0) {
    Security::getProviders(p0);
}

void getProviders_test_10975(String p0) {
    Security::getProviders(p0);
}

void getAlgorithmProperty_test_10976(String p0, String p1) {
    Security::getAlgorithmProperty(p0, p1);
}

void removeProvider_test_10977(String p0) {
    Security::removeProvider(p0);
}

void getAlgorithms_test_10978(String p0) {
    Security::getAlgorithms(p0);
}
