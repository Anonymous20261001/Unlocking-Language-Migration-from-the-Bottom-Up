#include <string>

class ClassLoader {
public:
    ClassLoader() = default;
};

class SAXParserFactory {
public:
    SAXParserFactory() = default;

    static SAXParserFactory newDefaultInstance() {
        return SAXParserFactory();
    }

    static SAXParserFactory newDefaultNSInstance() {
        return SAXParserFactory();
    }

    static SAXParserFactory newNSInstance() {
        return SAXParserFactory();
    }

    static SAXParserFactory newNSInstance(const std::string&, ClassLoader*) {
        return SAXParserFactory();
    }

    static SAXParserFactory newInstance(const std::string&, ClassLoader*) {
        return SAXParserFactory();
    }

    static SAXParserFactory newInstance() {
        return SAXParserFactory();
    }
};

void newDefaultInstance_test_10762() {
    SAXParserFactory::newDefaultInstance();
}

void newDefaultNSInstance_test_10763() {
    SAXParserFactory::newDefaultNSInstance();
}

void newNSInstance_test_10764() {
    SAXParserFactory::newNSInstance();
}

void newNSInstance_test_10765(const std::string& p0, ClassLoader* p1) {
    SAXParserFactory::newNSInstance(p0, p1);
}

void newInstance_test_10766(const std::string& p0, ClassLoader* p1) {
    SAXParserFactory::newInstance(p0, p1);
}

void newInstance_test_10767() {
    SAXParserFactory::newInstance();
}
