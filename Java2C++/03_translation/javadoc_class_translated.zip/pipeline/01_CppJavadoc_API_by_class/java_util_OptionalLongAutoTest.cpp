#include <cstdint>
#include <stdexcept>

class OptionalLong {
public:
    static OptionalLong empty() noexcept {
        return OptionalLong();
    }

    static OptionalLong of(int64_t value) noexcept {
        return OptionalLong(value);
    }

    bool is_present() const noexcept {
        return has_value_;
    }

    bool is_empty() const noexcept {
        return !has_value_;
    }

    int64_t get_as_long() const {
        if (!has_value_) {
            throw std::runtime_error("No value present");
        }
        return value_;
    }

    int64_t or_else(int64_t other) const noexcept {
        return has_value_ ? value_ : other;
    }

private:
    OptionalLong() noexcept : has_value_(false), value_(0) {}
    OptionalLong(int64_t value) noexcept : has_value_(true), value_(value) {}

    bool has_value_;
    int64_t value_;
};

void of_test_9696(int64_t p0) {
    OptionalLong::of(p0);
}

void empty_test_9697() {
    OptionalLong::empty();
}