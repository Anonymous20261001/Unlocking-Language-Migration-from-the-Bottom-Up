#include <string>
#include <vector>

class Color {
public:
    Color() = default;
};

class Rectangle {
public:
    Rectangle() = default;
};

class Shape {
public:
    virtual ~Shape() = default;
};

class Image {
public:
    Image() = default;
};

class MenuComponent {
public:
    virtual ~MenuComponent() = default;
};

class MenuBar : public MenuComponent {
public:
    MenuBar() = default;
};

class Frame {
public:
    Frame() {
        frames_.push_back(this);
    }

    std::string getTitle() const {
        return title_;
    }

    void setTitle(const std::string& p0) {
        title_ = p0;
    }

    static std::vector<Frame*>& getFrames() {
        return frames_;
    }

    int getExtendedState() const {
        return extendedState_;
    }

    MenuBar* getMenuBar() const {
        return menuBar_;
    }

    void setMenuBar(MenuBar* p0) {
        menuBar_ = p0;
    }

    void setResizable(bool p0) {
        resizable_ = p0;
    }

    bool isResizable() const {
        return resizable_;
    }

    void setShape(Shape* p0) {
        shape_ = p0;
    }

    void setOpacity(float p0) {
        opacity_ = p0;
    }

    void setIconImage(Image* p0) {
        iconImage_ = p0;
    }

    void setMaximizedBounds(Rectangle* p0) {
        maximizedBounds_ = p0;
    }

    void setExtendedState(int p0) {
        extendedState_ = p0;
    }

    bool isUndecorated() const {
        return undecorated_;
    }

    Image* getIconImage() const {
        return iconImage_;
    }

    Rectangle* getMaximizedBounds() const {
        return maximizedBounds_;
    }

    int getCursorType() const {
        return cursorType_;
    }

    void setBackground(Color* p0) {
        background_ = p0;
    }

    void addNotify() {
    }

    void removeNotify() {
    }

    void* getAccessibleContext() {
        return nullptr;
    }

    void setCursor(int p0) {
        cursor_ = p0;
    }

    void setUndecorated(bool p0) {
        undecorated_ = p0;
    }

    void remove(MenuComponent* p0) {
        (void)p0;
    }

    int getState() const {
        return state_;
    }

    void setState(int p0) {
        state_ = p0;
    }

private:
    std::string title_;
    int extendedState_ = 0;
    MenuBar* menuBar_ = nullptr;
    bool resizable_ = true;
    Shape* shape_ = nullptr;
    float opacity_ = 1.0f;
    Image* iconImage_ = nullptr;
    Rectangle* maximizedBounds_ = nullptr;
    bool undecorated_ = false;
    int cursorType_ = 0;
    Color* background_ = nullptr;
    int cursor_ = 0;
    int state_ = 0;
    static std::vector<Frame*> frames_;
};

std::vector<Frame*> Frame::frames_;

void getTitle_test_5045() {
    Frame instance;
    instance.getTitle();
}

void setTitle_test_5046(const std::string& p0) {
    Frame instance;
    instance.setTitle(p0);
}

void getFrames_test_5047() {
    Frame::getFrames();
}

void getExtendedState_test_5048() {
    Frame instance;
    instance.getExtendedState();
}

void getMenuBar_test_5049() {
    Frame instance;
    instance.getMenuBar();
}

void setMenuBar_test_5050(MenuBar* p0) {
    Frame instance;
    instance.setMenuBar(p0);
}

void setResizable_test_5051(bool p0) {
    Frame instance;
    instance.setResizable(p0);
}

void isResizable_test_5052() {
    Frame instance;
    instance.isResizable();
}

void setShape_test_5053(Shape* p0) {
    Frame instance;
    instance.setShape(p0);
}

void setOpacity_test_5054(float p0) {
    Frame instance;
    instance.setOpacity(p0);
}

void setIconImage_test_5055(Image* p0) {
    Frame instance;
    instance.setIconImage(p0);
}

void setMaximizedBounds_test_5056(Rectangle* p0) {
    Frame instance;
    instance.setMaximizedBounds(p0);
}

void setExtendedState_test_5057(int p0) {
    Frame instance;
    instance.setExtendedState(p0);
}

void isUndecorated_test_5058() {
    Frame instance;
    instance.isUndecorated();
}

void getIconImage_test_5059() {
    Frame instance;
    instance.getIconImage();
}

void getMaximizedBounds_test_5060() {
    Frame instance;
    instance.getMaximizedBounds();
}

void getCursorType_test_5061() {
    Frame instance;
    instance.getCursorType();
}

void setBackground_test_5062(Color* p0) {
    Frame instance;
    instance.setBackground(p0);
}

void addNotify_test_5063() {
    Frame instance;
    instance.addNotify();
}

void removeNotify_test_5064() {
    Frame instance;
    instance.removeNotify();
}

void getAccessibleContext_test_5065() {
    Frame instance;
    instance.getAccessibleContext();
}

void setCursor_test_5066(int p0) {
    Frame instance;
    instance.setCursor(p0);
}

void setUndecorated_test_5067(bool p0) {
    Frame instance;
    instance.setUndecorated(p0);
}

void remove_test_5068(MenuComponent* p0) {
    Frame instance;
    instance.remove(p0);
}

void getState_test_5069() {
    Frame instance;
    instance.getState();
}

void setState_test_5070(int p0) {
    Frame instance;
    instance.setState(p0);
}