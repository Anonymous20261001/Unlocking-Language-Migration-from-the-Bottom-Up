namespace javax {
namespace imageio {
namespace plugins {
namespace tiff {

class FaxTIFFTagSet {
public:
    static FaxTIFFTagSet& getInstance() {
        static FaxTIFFTagSet instance;
        return instance;
    }

private:
    FaxTIFFTagSet() = default;
    FaxTIFFTagSet(const FaxTIFFTagSet&) = delete;
    FaxTIFFTagSet& operator=(const FaxTIFFTagSet&) = delete;
};

} // namespace tiff
} // namespace plugins
} // namespace imageio
} // namespace javax

void getInstance_test_4674() {
    javax::imageio::plugins::tiff::FaxTIFFTagSet::getInstance();
}