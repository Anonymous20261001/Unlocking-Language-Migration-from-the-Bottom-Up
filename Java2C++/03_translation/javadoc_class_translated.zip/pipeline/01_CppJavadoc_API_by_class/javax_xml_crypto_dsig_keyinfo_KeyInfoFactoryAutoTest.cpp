#include <string>

class Provider {
public:
    Provider() = default;
};

class KeyInfoFactory {
public:
    static KeyInfoFactory getInstance() {
        return KeyInfoFactory();
    }

    static KeyInfoFactory getInstance(const std::string& mechanism, const Provider& provider) {
        (void)mechanism;
        (void)provider;
        return KeyInfoFactory();
    }

    static KeyInfoFactory getInstance(const std::string& mechanism) {
        (void)mechanism;
        return KeyInfoFactory();
    }
};

void getInstance_test_7625() {
    KeyInfoFactory::getInstance();
}

void getInstance_test_7626(const std::string& p0, const Provider& p1) {
    KeyInfoFactory::getInstance(p0, p1);
}

void getInstance_test_7627(const std::string& p0) {
    KeyInfoFactory::getInstance(p0);
}
