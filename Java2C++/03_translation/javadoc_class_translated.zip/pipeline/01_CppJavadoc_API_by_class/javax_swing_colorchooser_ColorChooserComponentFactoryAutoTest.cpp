struct JComponent {};
struct JTabbedPane : JComponent {};

class ColorChooserComponentFactory {
public:
  static JComponent getPreviewPanel() {
    return JComponent();
  }

  static JTabbedPane getDefaultChooserPanels() {
    return JTabbedPane();
  }
};

void getPreviewPanel_test_2491() {
  ColorChooserComponentFactory::getPreviewPanel();
}

void getDefaultChooserPanels_test_2492() {
  ColorChooserComponentFactory::getDefaultChooserPanels();
}