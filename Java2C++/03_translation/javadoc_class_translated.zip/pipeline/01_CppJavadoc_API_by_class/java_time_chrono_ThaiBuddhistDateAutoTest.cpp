class ZoneId {
public:
    ZoneId() = default;
    virtual ~ZoneId() = default;
};

class Clock {
public:
    Clock() = default;
    virtual ~Clock() = default;
};

class TemporalAccessor {
public:
    TemporalAccessor() = default;
    virtual ~TemporalAccessor() = default;
};

class ThaiBuddhistDate {
public:
    ThaiBuddhistDate() = default;

    static ThaiBuddhistDate of(int year, int month, int dayOfMonth) {
        (void)year;
        (void)month;
        (void)dayOfMonth;
        return ThaiBuddhistDate();
    }

    static ThaiBuddhistDate from(const TemporalAccessor& accessor) {
        (void)accessor;
        return ThaiBuddhistDate();
    }

    static ThaiBuddhistDate now() {
        return ThaiBuddhistDate();
    }

    static ThaiBuddhistDate now(const ZoneId& zone) {
        (void)zone;
        return ThaiBuddhistDate();
    }

    static ThaiBuddhistDate now(const Clock& clock) {
        (void)clock;
        return ThaiBuddhistDate();
    }
};

void of_test_12647(int p0, int p1, int p2) {
    ThaiBuddhistDate::of(p0, p1, p2);
}

void from_test_12648(const TemporalAccessor& p0) {
    ThaiBuddhistDate::from(p0);
}

void now_test_12649() {
    ThaiBuddhistDate::now();
}

void now_test_12650(const ZoneId& p0) {
    ThaiBuddhistDate::now(p0);
}

void now_test_12651(const Clock& p0) {
    ThaiBuddhistDate::now(p0);
}