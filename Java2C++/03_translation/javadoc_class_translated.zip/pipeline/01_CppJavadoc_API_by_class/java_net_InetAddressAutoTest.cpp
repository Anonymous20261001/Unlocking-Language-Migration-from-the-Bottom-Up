#include <string>
#include <stdexcept>

class UnknownHostException : public std::runtime_error {
public:
    explicit UnknownHostException(const std::string& message)
        : std::runtime_error(message) {}
};

class InetAddress {
public:
    static InetAddress ofLiteral(const std::string& literal) {
        if (literal.empty()) {
            throw UnknownHostException("empty IP literal");
        }
        return InetAddress(literal);
    }

    static InetAddress getLoopbackAddress() {
        return InetAddress("127.0.0.1");
    }

    const std::string& getHostAddress() const noexcept {
        return address_;
    }

    std::string toString() const {
        return address_;
    }

private:
    std::string address_;

    explicit InetAddress(const std::string& addr) : address_(addr) {}
};

void ofLiteral_test_5795(std::string p0) {
    InetAddress::ofLiteral(p0);
}

void getLoopbackAddress_test_5796() {
    InetAddress::getLoopbackAddress();
}