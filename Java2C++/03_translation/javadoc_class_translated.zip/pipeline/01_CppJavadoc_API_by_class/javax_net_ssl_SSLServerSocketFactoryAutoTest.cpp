class SSLServerSocketFactory {
public:
    virtual ~SSLServerSocketFactory() {}

    static SSLServerSocketFactory& getDefault() {
        static SSLServerSocketFactory instance;
        return instance;
    }
};

void getDefault_test_11437() {
    SSLServerSocketFactory::getDefault();
}