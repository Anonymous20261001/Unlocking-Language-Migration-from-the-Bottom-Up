class JavaCompiler {};
class DocumentationTool {};
class ClassLoader {};

class ToolProvider {
public:
  static JavaCompiler getSystemJavaCompiler() {
    return JavaCompiler();
  }

  static DocumentationTool getSystemDocumentationTool() {
    return DocumentationTool();
  }

  static ClassLoader getSystemToolClassLoader() {
    return ClassLoader();
  }
};

void getSystemJavaCompiler_test_12929() {
  ToolProvider::getSystemJavaCompiler();
}

void getSystemDocumentationTool_test_12930() {
  ToolProvider::getSystemDocumentationTool();
}

void getSystemToolClassLoader_test_12931() {
  ToolProvider::getSystemToolClassLoader();
}