class ZoneOffset {
public:
    ZoneOffset() = default;
};

class List {
public:
    List() = default;
};

class ZoneRules {
public:
    ZoneRules() = default;

    static ZoneRules of(ZoneOffset baseStandardOffset, ZoneOffset baseWallOffset,
                        List standardTransitions, List transitions, List lastRules) {
        (void)baseStandardOffset;
        (void)baseWallOffset;
        (void)standardTransitions;
        (void)transitions;
        (void)lastRules;
        return ZoneRules();
    }

    static ZoneRules of(ZoneOffset offset) {
        (void)offset;
        return ZoneRules();
    }
};

void of_test_13736(ZoneOffset p0, ZoneOffset p1, List p2, List p3, List p4) {
    (void)p0; (void)p1; (void)p2; (void)p3; (void)p4;
    ZoneRules::of(p0, p1, p2, p3, p4);
}

void of_test_13737(ZoneOffset p0) {
    (void)p0;
    ZoneRules::of(p0);
}
