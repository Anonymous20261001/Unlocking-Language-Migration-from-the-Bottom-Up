#include <cstddef>

struct Object {
    virtual ~Object() = default;
};

struct Runnable {
    virtual ~Runnable() = default;
    virtual void run() = 0;
};

struct Callable {
    virtual ~Callable() = default;
    virtual void* call() = 0;
};

struct PrivilegedAction {
    virtual ~PrivilegedAction() = default;
    virtual void* run() = 0;
};

struct PrivilegedExceptionAction {
    virtual ~PrivilegedExceptionAction() = default;
    virtual void* run() = 0;
};

struct Thread {
    Runnable* target;
    explicit Thread(Runnable* r) : target(r) {}
};

struct ThreadFactory {
    virtual ~ThreadFactory() = default;
    virtual Thread* newThread(Runnable* r) = 0;
};

struct ExecutorService {
    virtual ~ExecutorService() = default;
};

struct ScheduledExecutorService : public ExecutorService {
    virtual ~ScheduledExecutorService() = default;
};

class ExecutorServiceImpl : public ExecutorService {};
class ScheduledExecutorServiceImpl : public ScheduledExecutorService {};

class DefaultThreadFactory : public ThreadFactory {
public:
    Thread* newThread(Runnable* r) override { return new Thread(r); }
};

class PrivilegedThreadFactory : public ThreadFactory {
public:
    Thread* newThread(Runnable* r) override { return new Thread(r); }
};

class UnconfigurableExecutorService : public ExecutorService {
public:
    explicit UnconfigurableExecutorService(ExecutorService* d) : delegate(d) {}
private:
    ExecutorService* delegate;
};

class UnconfigurableScheduledExecutorService : public ScheduledExecutorService {
public:
    explicit UnconfigurableScheduledExecutorService(ScheduledExecutorService* d) : delegate(d) {}
private:
    ScheduledExecutorService* delegate;
};

class RunnableCallable : public Callable {
public:
    RunnableCallable(Runnable* t, Object* r = nullptr) : task(t), result(r) {}
    void* call() override { task->run(); return result; }
private:
    Runnable* task;
    Object* result;
};

class PrivilegedActionCallable : public Callable {
public:
    explicit PrivilegedActionCallable(PrivilegedAction* a) : action(a) {}
    void* call() override { return action->run(); }
private:
    PrivilegedAction* action;
};

class PrivilegedExceptionActionCallable : public Callable {
public:
    explicit PrivilegedExceptionActionCallable(PrivilegedExceptionAction* a) : action(a) {}
    void* call() override { return action->run(); }
private:
    PrivilegedExceptionAction* action;
};

class PrivilegedCallable : public Callable {
public:
    explicit PrivilegedCallable(Callable* d) : delegate(d) {}
    void* call() override { return delegate->call(); }
private:
    Callable* delegate;
};

class Executors {
public:
    static ScheduledExecutorService* newSingleThreadScheduledExecutor() {
        return new ScheduledExecutorServiceImpl();
    }

    static ScheduledExecutorService* newSingleThreadScheduledExecutor(ThreadFactory*) {
        return new ScheduledExecutorServiceImpl();
    }

    static ThreadFactory* defaultThreadFactory() {
        return new DefaultThreadFactory();
    }

    static ExecutorService* newSingleThreadExecutor(ThreadFactory*) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newSingleThreadExecutor() {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newThreadPerTaskExecutor(ThreadFactory*) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newFixedThreadPool(int) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newFixedThreadPool(int, ThreadFactory*) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newWorkStealingPool() {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newWorkStealingPool(int) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newCachedThreadPool() {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newCachedThreadPool(ThreadFactory*) {
        return new ExecutorServiceImpl();
    }

    static ExecutorService* newVirtualThreadPerTaskExecutor() {
        return new ExecutorServiceImpl();
    }

    static ScheduledExecutorService* newScheduledThreadPool(int, ThreadFactory*) {
        return new ScheduledExecutorServiceImpl();
    }

    static ScheduledExecutorService* newScheduledThreadPool(int) {
        return new ScheduledExecutorServiceImpl();
    }

    static ExecutorService* unconfigurableExecutorService(ExecutorService* executor) {
        return new UnconfigurableExecutorService(executor);
    }

    static ScheduledExecutorService* unconfigurableScheduledExecutorService(ScheduledExecutorService* executor) {
        return new UnconfigurableScheduledExecutorService(executor);
    }

    static ThreadFactory* privilegedThreadFactory() {
        return new PrivilegedThreadFactory();
    }

    static Callable* privilegedCallable(Callable* callable) {
        return new PrivilegedCallable(callable);
    }

    static Callable* privilegedCallableUsingCurrentClassLoader(Callable* callable) {
        return new PrivilegedCallable(callable);
    }

    static Callable* callable(Runnable* task) {
        return new RunnableCallable(task);
    }

    static Callable* callable(Runnable* task, Object* result) {
        return new RunnableCallable(task, result);
    }

    static Callable* callable(PrivilegedAction* action) {
        return new PrivilegedActionCallable(action);
    }

    static Callable* callable(PrivilegedExceptionAction* action) {
        return new PrivilegedExceptionActionCallable(action);
    }
};

void newSingleThreadScheduledExecutor_test_4637() {
    Executors::newSingleThreadScheduledExecutor();
}

void newSingleThreadScheduledExecutor_test_4638(ThreadFactory* p0) {
    Executors::newSingleThreadScheduledExecutor(p0);
}

void defaultThreadFactory_test_4639() {
    Executors::defaultThreadFactory();
}

void newSingleThreadExecutor_test_4640(ThreadFactory* p0) {
    Executors::newSingleThreadExecutor(p0);
}

void newSingleThreadExecutor_test_4641() {
    Executors::newSingleThreadExecutor();
}

void newThreadPerTaskExecutor_test_4642(ThreadFactory* p0) {
    Executors::newThreadPerTaskExecutor(p0);
}

void newFixedThreadPool_test_4643(int p0) {
    Executors::newFixedThreadPool(p0);
}

void newFixedThreadPool_test_4644(int p0, ThreadFactory* p1) {
    Executors::newFixedThreadPool(p0, p1);
}

void newWorkStealingPool_test_4645() {
    Executors::newWorkStealingPool();
}

void newWorkStealingPool_test_4646(int p0) {
    Executors::newWorkStealingPool(p0);
}

void newCachedThreadPool_test_4647() {
    Executors::newCachedThreadPool();
}

void newCachedThreadPool_test_4648(ThreadFactory* p0) {
    Executors::newCachedThreadPool(p0);
}

void newVirtualThreadPerTaskExecutor_test_4649() {
    Executors::newVirtualThreadPerTaskExecutor();
}

void newScheduledThreadPool_test_4650(int p0, ThreadFactory* p1) {
    Executors::newScheduledThreadPool(p0, p1);
}

void newScheduledThreadPool_test_4651(int p0) {
    Executors::newScheduledThreadPool(p0);
}

void unconfigurableExecutorService_test_4652(ExecutorService* p0) {
    Executors::unconfigurableExecutorService(p0);
}

void unconfigurableScheduledExecutorService_test_4653(ScheduledExecutorService* p0) {
    Executors::unconfigurableScheduledExecutorService(p0);
}

void privilegedThreadFactory_test_4654() {
    Executors::privilegedThreadFactory();
}

void privilegedCallable_test_4655(Callable* p0) {
    Executors::privilegedCallable(p0);
}

void privilegedCallableUsingCurrentClassLoader_test_4656(Callable* p0) {
    Executors::privilegedCallableUsingCurrentClassLoader(p0);
}

void callable_test_4657(Runnable* p0) {
    Executors::callable(p0);
}

void callable_test_4658(Runnable* p0, Object* p1) {
    Executors::callable(p0, p1);
}

void callable_test_4659(PrivilegedAction* p0) {
    Executors::callable(p0);
}

void callable_test_4660(PrivilegedExceptionAction* p0) {
    Executors::callable(p0);
}