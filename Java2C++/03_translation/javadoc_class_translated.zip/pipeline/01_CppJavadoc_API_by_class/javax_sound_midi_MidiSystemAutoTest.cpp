#include <vector>

class Sequence {
public:
    Sequence() = default;
};

class MidiDeviceInfo {
public:
    MidiDeviceInfo() = default;
};

class MidiSystem {
public:
    static bool isFileTypeSupported(int type) {
        return type == 0 || type == 1 || type == 2;
    }

    static bool isFileTypeSupported(int type, const Sequence& sequence) {
        (void)sequence;
        return type == 0 || type == 1;
    }

    static std::vector<int> getMidiFileTypes() {
        return {0, 1, 2};
    }

    static std::vector<int> getMidiFileTypes(const Sequence& sequence) {
        (void)sequence;
        return {0, 1};
    }

    static std::vector<MidiDeviceInfo> getMidiDeviceInfo() {
        return {};
    }

private:
    MidiSystem() = default;
};

void isFileTypeSupported_test_8942(int p0) {
    MidiSystem::isFileTypeSupported(p0);
}

void isFileTypeSupported_test_8943(int p0, Sequence p1) {
    MidiSystem::isFileTypeSupported(p0, p1);
}

void getMidiFileTypes_test_8944(Sequence p0) {
    MidiSystem::getMidiFileTypes(p0);
}

void getMidiFileTypes_test_8945() {
    MidiSystem::getMidiFileTypes();
}

void getMidiDeviceInfo_test_8946() {
    MidiSystem::getMidiDeviceInfo();
}