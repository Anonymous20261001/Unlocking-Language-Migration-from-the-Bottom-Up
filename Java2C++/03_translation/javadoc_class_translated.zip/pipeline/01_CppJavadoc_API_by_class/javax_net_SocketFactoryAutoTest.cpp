namespace javax {
namespace net {

class SocketFactory {
public:
    static SocketFactory* getDefault() {
        static SocketFactory instance;
        return &instance;
    }

protected:
    SocketFactory() = default;
    virtual ~SocketFactory() = default;
};

} // namespace net
} // namespace javax

void getDefault_test_11262() {
    javax::net::SocketFactory::getDefault();
}