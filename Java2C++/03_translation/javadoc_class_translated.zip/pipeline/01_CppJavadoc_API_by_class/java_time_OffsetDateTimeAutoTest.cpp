#include <string>

class CharSequence {
private:
    std::string value_;
public:
    CharSequence() : value_() {}
    CharSequence(const std::string& value) : value_(value) {}
    CharSequence(const char* value) : value_(value) {}
    const std::string& toString() const { return value_; }
};

class TemporalAccessor {
public:
    TemporalAccessor() {}
    virtual ~TemporalAccessor() {}
};

class ZoneId {
public:
    ZoneId() {}
};

class ZoneOffset {
public:
    ZoneOffset() {}
};

class LocalDate {
public:
    LocalDate() {}
};

class LocalTime {
public:
    LocalTime() {}
};

class LocalDateTime {
public:
    LocalDateTime() {}
};

class Instant {
public:
    Instant() {}
};

class Clock {
public:
    Clock() {}
};

class DateTimeFormatter {
public:
    DateTimeFormatter() {}
};

class OffsetDateTime {
public:
    OffsetDateTime() {}

    static OffsetDateTime of(const LocalDateTime& dateTime, const ZoneOffset& offset) {
        (void)dateTime;
        (void)offset;
        return OffsetDateTime();
    }

    static OffsetDateTime of(int year, int month, int dayOfMonth,
                             int hour, int minute, int second,
                             int nanoOfSecond, const ZoneOffset& offset) {
        (void)year;
        (void)month;
        (void)dayOfMonth;
        (void)hour;
        (void)minute;
        (void)second;
        (void)nanoOfSecond;
        (void)offset;
        return OffsetDateTime();
    }

    static OffsetDateTime of(const LocalDate& date, const LocalTime& time,
                             const ZoneOffset& offset) {
        (void)date;
        (void)time;
        (void)offset;
        return OffsetDateTime();
    }

    static OffsetDateTime from(const TemporalAccessor& temporal) {
        (void)temporal;
        return OffsetDateTime();
    }

    static OffsetDateTime parse(const CharSequence& text) {
        (void)text;
        return OffsetDateTime();
    }

    static OffsetDateTime parse(const CharSequence& text,
                                const DateTimeFormatter& formatter) {
        (void)text;
        (void)formatter;
        return OffsetDateTime();
    }

    static OffsetDateTime now() {
        return OffsetDateTime();
    }

    static OffsetDateTime now(const Clock& clock) {
        (void)clock;
        return OffsetDateTime();
    }

    static OffsetDateTime now(const ZoneId& zone) {
        (void)zone;
        return OffsetDateTime();
    }

    static OffsetDateTime ofInstant(const Instant& instant, const ZoneId& zone) {
        (void)instant;
        (void)zone;
        return OffsetDateTime();
    }

    struct Comparator {
        bool operator()(const OffsetDateTime&, const OffsetDateTime&) const {
            return false;
        }
    };

    static Comparator timeLineOrder() {
        return Comparator();
    }
};

void of_test_9640() {
    LocalDateTime p0;
    ZoneOffset p1;
    OffsetDateTime::of(p0, p1);
}

void of_test_9641() {
    int p0 = 2020;
    int p1 = 1;
    int p2 = 1;
    int p3 = 0;
    int p4 = 0;
    int p5 = 0;
    int p6 = 0;
    ZoneOffset p7;
    OffsetDateTime::of(p0, p1, p2, p3, p4, p5, p6, p7);
}

void of_test_9642() {
    LocalDate p0;
    LocalTime p1;
    ZoneOffset p2;
    OffsetDateTime::of(p0, p1, p2);
}

void from_test_9643() {
    TemporalAccessor p0;
    OffsetDateTime::from(p0);
}

void parse_test_9644() {
    CharSequence p0("2021-01-01T00:00:00+01:00");
    DateTimeFormatter p1;
    OffsetDateTime::parse(p0, p1);
}

void parse_test_9645() {
    CharSequence p0("2021-01-01T00:00:00+01:00");
    OffsetDateTime::parse(p0);
}

void now_test_9646() {
    OffsetDateTime::now();
}

void now_test_9647() {
    Clock p0;
    OffsetDateTime::now(p0);
}

void now_test_9648() {
    ZoneId p0;
    OffsetDateTime::now(p0);
}

void ofInstant_test_9649() {
    Instant p0;
    ZoneId p1;
    OffsetDateTime::ofInstant(p0, p1);
}

void timeLineOrder_test_9650() {
    OffsetDateTime::timeLineOrder();
}
