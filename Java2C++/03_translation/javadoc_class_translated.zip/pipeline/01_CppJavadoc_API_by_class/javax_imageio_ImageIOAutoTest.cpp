#include <string>
#include <vector>

class Object {};
class File {
public:
    File() = default;
    explicit File(const std::string& path) : path_(path) {}
    const std::string& getPath() const { return path_; }
private:
    std::string path_;
};

class ImageTypeSpecifier {};
class ImageReader {};
class ImageWriter {};

class ImageIO {
public:
    static void setUseCache(bool useCache) { s_useCache = useCache; }
    static bool getUseCache() { return s_useCache; }
    static void setCacheDirectory(File* cacheDir) { s_cacheDir = cacheDir; }
    static File* getCacheDirectory() { return s_cacheDir; }

    static std::vector<ImageReader*> getImageReaders(Object* input) {
        (void)input;
        return std::vector<ImageReader*>();
    }

    static std::vector<ImageWriter*> getImageWriters(ImageTypeSpecifier* type, const std::string& formatName) {
        (void)type;
        (void)formatName;
        return std::vector<ImageWriter*>();
    }

    static void scanForPlugins() {}

    static std::vector<std::string> getReaderFormatNames() {
        return std::vector<std::string>();
    }

    static std::vector<std::string> getReaderMIMETypes() {
        return std::vector<std::string>();
    }

    static std::vector<std::string> getReaderFileSuffixes() {
        return std::vector<std::string>();
    }

    static std::vector<ImageReader*> getImageReadersByFormatName(const std::string& formatName) {
        (void)formatName;
        return std::vector<ImageReader*>();
    }

    static std::vector<ImageReader*> getImageReadersBySuffix(const std::string& suffix) {
        (void)suffix;
        return std::vector<ImageReader*>();
    }

    static std::vector<ImageReader*> getImageReadersByMIMEType(const std::string& mimeType) {
        (void)mimeType;
        return std::vector<ImageReader*>();
    }

    static std::vector<std::string> getWriterFormatNames() {
        return std::vector<std::string>();
    }

    static std::vector<std::string> getWriterMIMETypes() {
        return std::vector<std::string>();
    }

    static std::vector<std::string> getWriterFileSuffixes() {
        return std::vector<std::string>();
    }

    static std::vector<ImageWriter*> getImageWritersByFormatName(const std::string& formatName) {
        (void)formatName;
        return std::vector<ImageWriter*>();
    }

    static std::vector<ImageWriter*> getImageWritersBySuffix(const std::string& suffix) {
        (void)suffix;
        return std::vector<ImageWriter*>();
    }

    static std::vector<ImageWriter*> getImageWritersByMIMEType(const std::string& mimeType) {
        (void)mimeType;
        return std::vector<ImageWriter*>();
    }

    static ImageWriter* getImageWriter(ImageReader* reader) {
        (void)reader;
        return nullptr;
    }

    static std::vector<ImageWriter*> getImageTranscoders(ImageReader* reader, ImageWriter* writer) {
        (void)reader;
        (void)writer;
        return std::vector<ImageWriter*>();
    }

    static ImageReader* getImageReader(ImageWriter* writer) {
        (void)writer;
        return nullptr;
    }

private:
    static bool s_useCache;
    static File* s_cacheDir;
};

bool ImageIO::s_useCache = true;
File* ImageIO::s_cacheDir = nullptr;

void setUseCache_test_5658(bool p0) {
    ImageIO::setUseCache(p0);
}

void getUseCache_test_5659() {
    ImageIO::getUseCache();
}

void setCacheDirectory_test_5660(File* p0) {
    ImageIO::setCacheDirectory(p0);
}

void getCacheDirectory_test_5661() {
    ImageIO::getCacheDirectory();
}

void getImageReaders_test_5662(Object* p0) {
    ImageIO::getImageReaders(p0);
}

void getImageWriters_test_5663(ImageTypeSpecifier* p0, const std::string& p1) {
    ImageIO::getImageWriters(p0, p1);
}

void scanForPlugins_test_5664() {
    ImageIO::scanForPlugins();
}

void getReaderFormatNames_test_5665() {
    ImageIO::getReaderFormatNames();
}

void getReaderMIMETypes_test_5666() {
    ImageIO::getReaderMIMETypes();
}

void getReaderFileSuffixes_test_5667() {
    ImageIO::getReaderFileSuffixes();
}

void getImageReadersByFormatName_test_5668(const std::string& p0) {
    ImageIO::getImageReadersByFormatName(p0);
}

void getImageReadersBySuffix_test_5669(const std::string& p0) {
    ImageIO::getImageReadersBySuffix(p0);
}

void getImageReadersByMIMEType_test_5670(const std::string& p0) {
    ImageIO::getImageReadersByMIMEType(p0);
}

void getWriterFormatNames_test_5671() {
    ImageIO::getWriterFormatNames();
}

void getWriterMIMETypes_test_5672() {
    ImageIO::getWriterMIMETypes();
}

void getWriterFileSuffixes_test_5673() {
    ImageIO::getWriterFileSuffixes();
}

void getImageWritersByFormatName_test_5674(const std::string& p0) {
    ImageIO::getImageWritersByFormatName(p0);
}

void getImageWritersBySuffix_test_5675(const std::string& p0) {
    ImageIO::getImageWritersBySuffix(p0);
}

void getImageWritersByMIMEType_test_5676(const std::string& p0) {
    ImageIO::getImageWritersByMIMEType(p0);
}

void getImageWriter_test_5677(ImageReader* p0) {
    ImageIO::getImageWriter(p0);
}

void getImageTranscoders_test_5678(ImageReader* p0, ImageWriter* p1) {
    ImageIO::getImageTranscoders(p0, p1);
}

void getImageReader_test_5679(ImageWriter* p0) {
    ImageIO::getImageReader(p0);
}