class ColorModel {
public:
    static ColorModel& getRGBdefault() {
        static ColorModel instance;
        return instance;
    }
private:
    ColorModel() {}
};

void getRGBdefault_test_2502() {
    ColorModel::getRGBdefault();
}