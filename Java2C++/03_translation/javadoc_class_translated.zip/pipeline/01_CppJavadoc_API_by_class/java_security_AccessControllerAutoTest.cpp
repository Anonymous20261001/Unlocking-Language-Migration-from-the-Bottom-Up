#include <vector>

class Permission {
public:
    Permission() = default;
    virtual ~Permission() = default;
};

class AccessControlContext {
public:
    AccessControlContext() = default;
    AccessControlContext(const AccessControlContext&) = default;
    AccessControlContext& operator=(const AccessControlContext&) = default;
    virtual ~AccessControlContext() = default;
};

class PrivilegedAction {
public:
    virtual ~PrivilegedAction() = default;
    virtual void* run() = 0;
};

class AccessController {
public:
    static void checkPermission(const Permission& perm) {
        (void)perm;
    }

    static void* doPrivileged(PrivilegedAction& action) {
        return action.run();
    }

    static void* doPrivileged(PrivilegedAction& action, const AccessControlContext& context) {
        (void)context;
        return doPrivileged(action);
    }

    static void* doPrivileged(PrivilegedAction& action, const AccessControlContext& context,
                              const std::vector<Permission>& perms) {
        (void)context;
        (void)perms;
        return doPrivileged(action);
    }

    static void* doPrivilegedWithCombiner(PrivilegedAction& action) {
        return doPrivileged(action);
    }

    static void* doPrivilegedWithCombiner(PrivilegedAction& action, const AccessControlContext& context,
                                          const std::vector<Permission>& perms) {
        (void)context;
        (void)perms;
        return doPrivileged(action);
    }

    static AccessControlContext getContext() {
        return AccessControlContext();
    }
};

void checkPermission_test_28(Permission& p0) {
    AccessController::checkPermission(p0);
}

void doPrivileged_test_29(PrivilegedAction& p0) {
    AccessController::doPrivileged(p0);
}

void doPrivileged_test_30(PrivilegedAction& p0, AccessControlContext& p1,
                          const std::vector<Permission>& p2) {
    AccessController::doPrivileged(p0, p1, p2);
}

void doPrivileged_test_31(PrivilegedAction& p0, AccessControlContext& p1) {
    AccessController::doPrivileged(p0, p1);
}

void doPrivilegedWithCombiner_test_32(PrivilegedAction& p0) {
    AccessController::doPrivilegedWithCombiner(p0);
}

void doPrivilegedWithCombiner_test_33(PrivilegedAction& p0, AccessControlContext& p1,
                                      const std::vector<Permission>& p2) {
    AccessController::doPrivilegedWithCombiner(p0, p1, p2);
}

void getContext_test_34() {
    AccessControlContext ctx = AccessController::getContext();
    (void)ctx;
}