#include <string>
#include <vector>
#include <any>
#include <map>
#include <sstream>
#include <stdexcept>

class DescriptorSupport {
public:
    DescriptorSupport() = default;

    std::vector<std::string> getFieldNames() const {
        std::vector<std::string> names;
        for (const auto& [key, value] : fields_) {
            names.push_back(key);
        }
        return names;
    }

    std::vector<std::any> getFieldValues(const std::vector<std::string>& fieldNames) const {
        std::vector<std::any> values;
        for (const auto& name : fieldNames) {
            auto it = fields_.find(name);
            if (it != fields_.end()) {
                values.push_back(it->second);
            } else {
                values.push_back(std::any());
            }
        }
        return values;
    }

    void setField(const std::string& fieldName, const std::any& fieldValue) {
        fields_[fieldName] = fieldValue;
    }

    std::any getFieldValue(const std::string& fieldName) const {
        auto it = fields_.find(fieldName);
        if (it != fields_.end()) {
            return it->second;
        }
        return std::any();
    }

    void removeField(const std::string& fieldName) {
        fields_.erase(fieldName);
    }

    std::string toXMLString() const {
        std::ostringstream oss;
        oss << "<Descriptor>";
        for (const auto& [key, value] : fields_) {
            oss << "<field name=\"" << key << "\">";
            if (value.has_value()) {
                try {
                    oss << std::any_cast<std::string>(value);
                } catch (const std::bad_any_cast&) {
                    try {
                        oss << std::any_cast<int>(value);
                    } catch (const std::bad_any_cast&) {
                        oss << "?";
                    }
                }
            }
            oss << "</field>";
        }
        oss << "</Descriptor>";
        return oss.str();
    }

    std::vector<std::string> getFields() const {
        std::vector<std::string> result;
        for (const auto& [key, value] : fields_) {
            std::ostringstream oss;
            oss << key << "=";
            if (value.has_value()) {
                try {
                    oss << std::any_cast<std::string>(value);
                } catch (const std::bad_any_cast&) {
                    try {
                        oss << std::any_cast<int>(value);
                    } catch (const std::bad_any_cast&) {
                        oss << "?";
                    }
                }
            }
            result.push_back(oss.str());
        }
        return result;
    }

    bool isValid() const {
        for (const auto& [key, value] : fields_) {
            if (key.empty()) {
                return false;
            }
        }
        return true;
    }

    void setFields(const std::vector<std::string>& fieldNames,
                   const std::vector<std::any>& fieldValues) {
        if (fieldNames.size() != fieldValues.size()) {
            throw std::invalid_argument("Field names and values must have same length");
        }
        for (size_t i = 0; i < fieldNames.size(); ++i) {
            setField(fieldNames[i], fieldValues[i]);
        }
    }

private:
    std::map<std::string, std::any> fields_;
};

void getFieldNames_test_4099() {
    DescriptorSupport instance;
    instance.getFieldNames();
}

void getFieldValues_test_4100(std::vector<std::string> p0) {
    DescriptorSupport instance;
    instance.getFieldValues(p0);
}

void setField_test_4101(std::string p0, std::any p1) {
    DescriptorSupport instance;
    instance.setField(p0, p1);
}

void getFieldValue_test_4102(std::string p0) {
    DescriptorSupport instance;
    instance.getFieldValue(p0);
}

void removeField_test_4103(std::string p0) {
    DescriptorSupport instance;
    instance.removeField(p0);
}

void toXMLString_test_4104() {
    DescriptorSupport instance;
    instance.toXMLString();
}

void getFields_test_4105() {
    DescriptorSupport instance;
    instance.getFields();
}

void isValid_test_4106() {
    DescriptorSupport instance;
    instance.isValid();
}

void setFields_test_4107(std::vector<std::string> p0, std::vector<std::any> p1) {
    DescriptorSupport instance;
    instance.setFields(p0, p1);
}