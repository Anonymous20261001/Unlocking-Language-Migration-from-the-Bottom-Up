#include <stdexcept>

namespace jdk {
namespace jshell {
namespace spi {

class SPIResolutionException : public std::runtime_error {
public:
    explicit SPIResolutionException(int id)
        : std::runtime_error("SPIResolutionException"), id_(id) {}

    int id() const {
        return id_;
    }

private:
    int id_;
};

} // namespace spi
} // namespace jshell
} // namespace jdk

using jdk::jshell::spi::SPIResolutionException;

void id_test_11312() {
    int c0 = 0;
    SPIResolutionException instance(c0);
    instance.id();
}