#include <iostream>

class ToolTipManager {
public:
    static ToolTipManager& sharedInstance() {
        static ToolTipManager instance;
        return instance;
    }

private:
    ToolTipManager() = default;
    ToolTipManager(const ToolTipManager&) = delete;
    ToolTipManager& operator=(const ToolTipManager&) = delete;
};

void sharedInstance_test_12932() {
    ToolTipManager::sharedInstance();
}