#include <string>
#include <vector>
#include <stdexcept>
#include <utility>

class RandomGeneratorFactory {
public:
    RandomGeneratorFactory() = default;

    explicit RandomGeneratorFactory(std::string name) : name_(std::move(name)) {}

    const std::string& name() const {
        return name_;
    }

    static RandomGeneratorFactory of(const std::string& name) {
        if (name.empty()) {
            throw std::invalid_argument("RandomGeneratorFactory.of: empty algorithm name");
        }
        return RandomGeneratorFactory(name);
    }

    static RandomGeneratorFactory getDefault() {
        return RandomGeneratorFactory("Random");
    }

    static std::vector<RandomGeneratorFactory> all() {
        return {
            RandomGeneratorFactory("Random"),
            RandomGeneratorFactory("SplittableRandom"),
            RandomGeneratorFactory("Xoshiro256PlusPlus")
        };
    }

private:
    std::string name_;
};

void of_test_10322(const std::string& p0) {
    RandomGeneratorFactory::of(p0);
}

void getDefault_test_10323() {
    RandomGeneratorFactory::getDefault();
}

void all_test_10324() {
    RandomGeneratorFactory::all();
}