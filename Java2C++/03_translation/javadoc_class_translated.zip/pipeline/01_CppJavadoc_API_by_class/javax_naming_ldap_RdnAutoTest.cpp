#include <string>
#include <sstream>
#include <cstdlib>

class Rdn {
public:
    static std::string escapeValue(const std::string& value) {
        std::ostringstream out;
        std::size_t len = value.size();
        for (std::size_t i = 0; i < len; ++i) {
            char c = value[i];
            if (c == ',' || c == '+' || c == '"' || c == '\\' ||
                c == '<' || c == '>' || c == ';' || c == '=') {
                out << '\\' << c;
            } else if (c == '\0') {
                out << "\\00";
            } else if (c == ' ' && (i == 0 || i == len - 1)) {
                out << "\\ ";
            } else if (c == '#' && i == 0) {
                out << "\\#";
            } else {
                out << c;
            }
        }
        return out.str();
    }

    static std::string unescapeValue(const std::string& value) {
        if (!value.empty() && value[0] == '#') {
            return hexToBinary(value.substr(1));
        }
        std::string out;
        std::size_t len = value.size();
        for (std::size_t i = 0; i < len; ++i) {
            char c = value[i];
            if (c == '\\' && i + 1 < len) {
                if (i + 2 < len && isHexDigit(value[i + 1]) && isHexDigit(value[i + 2])) {
                    std::string hex = value.substr(i + 1, 2);
                    int code = std::strtol(hex.c_str(), nullptr, 16);
                    out.push_back(static_cast<char>(code));
                    i += 2;
                } else {
                    out.push_back(value[i + 1]);
                    i += 1;
                }
            } else {
                out.push_back(c);
            }
        }
        return out;
    }

private:
    static bool isHexDigit(char c) {
        return (c >= '0' && c <= '9') ||
               (c >= 'a' && c <= 'f') ||
               (c >= 'A' && c <= 'F');
    }

    static std::string hexToBinary(const std::string& hex) {
        if (hex.size() % 2 != 0) return std::string();
        std::string out;
        for (std::size_t i = 0; i < hex.size(); i += 2) {
            std::string byte = hex.substr(i, 2);
            char ch = static_cast<char>(std::strtol(byte.c_str(), nullptr, 16));
            out.push_back(ch);
        }
        return out;
    }
};

void escapeValue_test_10344() {
    std::string p0 = "test";
    Rdn::escapeValue(p0);
}

void unescapeValue_test_10345() {
    std::string p0 = "test";
    Rdn::unescapeValue(p0);
}