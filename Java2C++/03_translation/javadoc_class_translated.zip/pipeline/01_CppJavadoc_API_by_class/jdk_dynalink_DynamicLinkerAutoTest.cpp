#include <cstddef>

namespace jdk {
namespace dynalink {

struct StackTraceElement {
    // Minimal stand-in for java.lang.StackTraceElement
};

class DynamicLinker {
public:
    static StackTraceElement getLinkedCallSiteLocation() {
        return StackTraceElement{};
    }
};

} // namespace dynalink
} // namespace jdk

void getLinkedCallSiteLocation_test_4424() {
    jdk::dynalink::DynamicLinker::getLinkedCallSiteLocation();
}