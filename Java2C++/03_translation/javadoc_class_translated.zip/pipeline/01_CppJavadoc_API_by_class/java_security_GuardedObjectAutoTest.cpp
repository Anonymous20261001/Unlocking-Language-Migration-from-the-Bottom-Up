#include <exception>

class Object {
public:
    virtual ~Object() = default;
};

class Guard {
public:
    virtual ~Guard() = default;
    virtual void checkGuard(Object* object) = 0;
};

class GuardedObject {
private:
    Object* object_;
    Guard* guard_;

public:
    GuardedObject(Object* object, Guard* guard)
        : object_(object), guard_(guard) {}

    Object* getObject() {
        if (guard_ != nullptr) {
            guard_->checkGuard(object_);
        }
        return object_;
    }
};

void getObject_test_5247(Object* c0, Guard* c1) {
    GuardedObject instance(c0, c1);
    instance.getObject();
}