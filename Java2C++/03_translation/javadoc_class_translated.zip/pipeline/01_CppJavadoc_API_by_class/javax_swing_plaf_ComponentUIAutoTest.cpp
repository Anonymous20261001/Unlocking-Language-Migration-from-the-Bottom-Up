class JComponent {
public:
    virtual ~JComponent() = default;
};

class ComponentUI {
public:
    virtual ~ComponentUI() = default;
    static ComponentUI* createUI(const JComponent&) {
        return nullptr;
    }
};

void createUI_test_2673(JComponent p0) {
    ComponentUI::createUI(p0);
}