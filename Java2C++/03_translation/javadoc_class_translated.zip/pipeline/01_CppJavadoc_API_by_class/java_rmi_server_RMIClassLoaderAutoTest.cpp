#include <string>

namespace java {
namespace lang {

class Class {
public:
    Class() : name_() {}
    explicit Class(const std::string& name) : name_(name) {}
    const std::string& getName() const { return name_; }
private:
    std::string name_;
};

class ClassLoader {
public:
    ClassLoader() = default;
    virtual ~ClassLoader() = default;
};

class Object {
public:
    virtual ~Object() = default;
};

} // namespace lang

namespace rmi {
namespace server {

class RMIClassLoader {
public:
    static std::string getClassAnnotation(const java::lang::Class& cl) {
        (void)cl;
        return std::string();
    }

    static java::lang::ClassLoader& getDefaultProviderInstance() {
        static java::lang::ClassLoader instance;
        return instance;
    }

    static java::lang::Object getSecurityContext(const java::lang::ClassLoader& loader) {
        (void)loader;
        return java::lang::Object();
    }
};

} // namespace server
} // namespace rmi
} // namespace java

void getClassAnnotation_test_10630(java::lang::Class p0) {
    java::rmi::server::RMIClassLoader::getClassAnnotation(p0);
}

void getDefaultProviderInstance_test_10631() {
    java::rmi::server::RMIClassLoader::getDefaultProviderInstance();
}

void getSecurityContext_test_10632(java::lang::ClassLoader p0) {
    java::rmi::server::RMIClassLoader::getSecurityContext(p0);
}