#include <string>

class CertStore {
public:
    static std::string getDefaultType() {
        return "LDAP";
    }
};

void getDefaultType_test_2105() {
    CertStore::getDefaultType();
}