class ExifTIFFTagSet {
public:
    static ExifTIFFTagSet& getInstance() {
        static ExifTIFFTagSet instance;
        return instance;
    }

private:
    ExifTIFFTagSet() = default;
    ~ExifTIFFTagSet() = default;
    ExifTIFFTagSet(const ExifTIFFTagSet&) = delete;
    ExifTIFFTagSet& operator=(const ExifTIFFTagSet&) = delete;
};

void getInstance_test_4664() {
    ExifTIFFTagSet::getInstance();
}