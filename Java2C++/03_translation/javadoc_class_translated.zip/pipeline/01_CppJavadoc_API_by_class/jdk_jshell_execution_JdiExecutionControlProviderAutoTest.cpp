#include <string>
#include <map>

class JdiExecutionControlProvider {
public:
    std::string name() {
        return "jdi";
    }

    std::map<std::string, std::string> defaultParameters() {
        return {
            {"launch", "true"},
            {"remoteAgent", "org.jshell.remote.RemoteExecutionControl"},
            {"timeout", "5000"}
        };
    }
};

void name_test_6148() {
    JdiExecutionControlProvider instance;
    instance.name();
}

void defaultParameters_test_6149() {
    JdiExecutionControlProvider instance;
    instance.defaultParameters();
}