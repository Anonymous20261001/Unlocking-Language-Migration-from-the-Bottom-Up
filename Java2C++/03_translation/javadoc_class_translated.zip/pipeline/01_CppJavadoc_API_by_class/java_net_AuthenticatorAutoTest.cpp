#include <string>

class InetAddress {
public:
    InetAddress() = default;
    explicit InetAddress(const std::string& address) : address_(address) {}
private:
    std::string address_;
};

class URL {
public:
    URL() = default;
    explicit URL(const std::string& url) : url_(url) {}
private:
    std::string url_;
};

class PasswordAuthentication {
public:
    PasswordAuthentication() = default;
    PasswordAuthentication(const std::string& user, const std::string& password)
        : user_(user), password_(password) {}
private:
    std::string user_;
    std::string password_;
};

class Authenticator {
public:
    enum class RequestorType {
        PROXY,
        SERVER
    };

    virtual ~Authenticator() = default;

    static PasswordAuthentication requestPasswordAuthentication(
        InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme) {
        (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme) {
        (void)host; (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        Authenticator* authenticator,
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme,
        URL url, RequestorType reqType) {
        (void)authenticator; (void)host; (void)addr; (void)port; (void)protocol;
        (void)prompt; (void)scheme; (void)url; (void)reqType;
        return PasswordAuthentication();
    }

    static PasswordAuthentication requestPasswordAuthentication(
        const std::string& host, InetAddress addr, int port,
        const std::string& protocol,
        const std::string& prompt,
        const std::string& scheme,
        URL url, RequestorType reqType) {
        (void)host; (void)addr; (void)port; (void)protocol; (void)prompt; (void)scheme;
        (void)url; (void)reqType;
        return PasswordAuthentication();
    }

    static Authenticator* getDefault() {
        return defaultAuthenticator;
    }

    static void setDefault(Authenticator* authenticator) {
        defaultAuthenticator = authenticator;
    }

private:
    static Authenticator* defaultAuthenticator;
};

Authenticator* Authenticator::defaultAuthenticator = nullptr;

void requestPasswordAuthentication_test_897(InetAddress p0, int p1, std::string p2,
                                            std::string p3, std::string p4) {
    Authenticator::requestPasswordAuthentication(p0, p1, p2, p3, p4);
}

void requestPasswordAuthentication_test_898(std::string p0, InetAddress p1, int p2,
                                            std::string p3, std::string p4, std::string p5) {
    Authenticator::requestPasswordAuthentication(p0, p1, p2, p3, p4, p5);
}

void requestPasswordAuthentication_test_899(Authenticator* p0, std::string p1, InetAddress p2,
                                            int p3, std::string p4, std::string p5,
                                            std::string p6, URL p7,
                                            Authenticator::RequestorType p8) {
    Authenticator::requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7, p8);
}

void requestPasswordAuthentication_test_900(std::string p0, InetAddress p1, int p2,
                                            std::string p3, std::string p4, std::string p5,
                                            URL p6, Authenticator::RequestorType p7) {
    Authenticator::requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7);
}

void getDefault_test_901() {
    Authenticator::getDefault();
}

void setDefault_test_902(Authenticator* p0) {
    Authenticator::setDefault(p0);
}
