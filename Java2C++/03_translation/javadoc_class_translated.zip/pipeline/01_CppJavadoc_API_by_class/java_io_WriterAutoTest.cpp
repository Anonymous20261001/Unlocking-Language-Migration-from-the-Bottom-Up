#include <cstddef>
#include <memory>

class Writer {
public:
    virtual ~Writer() = default;

    virtual void write(char c) = 0;
    virtual void write(const char* data, std::size_t length) = 0;
    virtual void flush() = 0;
    virtual void close() = 0;

    static std::unique_ptr<Writer> nullWriter() {
        return std::make_unique<NullWriter>();
    }

private:
    class NullWriter final : public Writer {
    public:
        void write(char) override {}
        void write(const char*, std::size_t) override {}
        void flush() override {}
        void close() override {}
    };
};

void nullWriter_test_13550() {
    Writer::nullWriter();
}
