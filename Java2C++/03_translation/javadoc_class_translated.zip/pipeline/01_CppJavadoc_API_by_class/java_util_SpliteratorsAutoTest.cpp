#include <vector>
#include <iterator>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <memory>

// Forward declarations
class Spliterator;
class SpliteratorOfInt;
class SpliteratorOfLong;
class SpliteratorOfDouble;
class Iterator;
class PrimitiveIteratorOfInt;
class PrimitiveIteratorOfLong;
class PrimitiveIteratorOfDouble;
class Collection;

// Base Spliterator interface
class Spliterator {
public:
    virtual ~Spliterator() = default;
    virtual bool tryAdvance(std::function<void(void*)> action) = 0;
    virtual Spliterator* trySplit() = 0;
    virtual long estimateSize() = 0;
    virtual int characteristics() = 0;
};

// Primitive Spliterator interfaces
class SpliteratorOfInt : public Spliterator {
public:
    virtual bool tryAdvance(std::function<void(int)> action) = 0;
    virtual SpliteratorOfInt* trySplit() = 0;
};

class SpliteratorOfLong : public Spliterator {
public:
    virtual bool tryAdvance(std::function<void(long)> action) = 0;
    virtual SpliteratorOfLong* trySplit() = 0;
};

class SpliteratorOfDouble : public Spliterator {
public:
    virtual bool tryAdvance(std::function<void(double)> action) = 0;
    virtual SpliteratorOfDouble* trySplit() = 0;
};

// Iterator interface
class Iterator {
public:
    virtual ~Iterator() = default;
    virtual bool hasNext() = 0;
    virtual void* next() = 0;
};

// Primitive Iterator interfaces
class PrimitiveIteratorOfInt : public Iterator {
public:
    virtual int nextInt() = 0;
};

class PrimitiveIteratorOfLong : public Iterator {
public:
    virtual long nextLong() = 0;
};

class PrimitiveIteratorOfDouble : public Iterator {
public:
    virtual double nextDouble() = 0;
};

// Collection interface (simplified)
class Collection {
public:
    virtual ~Collection() = default;
    virtual size_t size() = 0;
    virtual Iterator* iterator() = 0;
};

// Spliterators utility class
class Spliterators {
public:
    // Static methods for creating iterators from spliterators
    static Iterator* iterator(SpliteratorOfDouble* p0) {
        // Implementation would create an iterator from the spliterator
        return nullptr; // Placeholder
    }

    static Iterator* iterator(Spliterator* p0) {
        return nullptr; // Placeholder
    }

    static Iterator* iterator(SpliteratorOfInt* p0) {
        return nullptr; // Placeholder
    }

    static Iterator* iterator(SpliteratorOfLong* p0) {
        return nullptr; // Placeholder
    }

    // Static methods for creating spliterators from iterators
    static SpliteratorOfInt* spliteratorUnknownSize(PrimitiveIteratorOfInt* p0, int p1) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfLong* spliteratorUnknownSize(PrimitiveIteratorOfLong* p0, int p1) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfDouble* spliteratorUnknownSize(PrimitiveIteratorOfDouble* p0, int p1) {
        return nullptr; // Placeholder
    }

    static Spliterator* spliteratorUnknownSize(Iterator* p0, int p1) {
        return nullptr; // Placeholder
    }

    // Static methods for creating spliterators from arrays and collections
    static Spliterator* spliterator(void** p0, int p1) {
        return nullptr; // Placeholder
    }

    static Spliterator* spliterator(Iterator* p0, long p1, int p2) {
        return nullptr; // Placeholder
    }

    static Spliterator* spliterator(Collection* p0, int p1) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfInt* spliterator(PrimitiveIteratorOfInt* p0, long p1, int p2) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfLong* spliterator(PrimitiveIteratorOfLong* p0, long p1, int p2) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfDouble* spliterator(PrimitiveIteratorOfDouble* p0, long p1, int p2) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfLong* spliterator(long* p0, int p1, int p2, int p3) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfLong* spliterator(long* p0, int p1) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfInt* spliterator(int* p0, int p1, int p2, int p3) {
        return nullptr; // Placeholder
    }

    static Spliterator* spliterator(void** p0, int p1, int p2, int p3) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfInt* spliterator(int* p0, int p1) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfDouble* spliterator(double* p0, int p1, int p2, int p3) {
        return nullptr; // Placeholder
    }

    static SpliteratorOfDouble* spliterator(double* p0, int p1) {
        return nullptr; // Placeholder
    }

    // Empty spliterator factories
    static Spliterator* emptySpliterator() {
        return nullptr; // Placeholder
    }

    static SpliteratorOfInt* emptyIntSpliterator() {
        return nullptr; // Placeholder
    }

    static SpliteratorOfLong* emptyLongSpliterator() {
        return nullptr; // Placeholder
    }

    static SpliteratorOfDouble* emptyDoubleSpliterator() {
        return nullptr; // Placeholder
    }
};

// Test functions
void iterator_test_11314(SpliteratorOfDouble* p0) {
    Spliterators::iterator(p0);
}

void iterator_test_11315(Spliterator* p0) {
    Spliterators::iterator(p0);
}

void iterator_test_11316(SpliteratorOfInt* p0) {
    Spliterators::iterator(p0);
}

void iterator_test_11317(SpliteratorOfLong* p0) {
    Spliterators::iterator(p0);
}

void spliteratorUnknownSize_test_11318(PrimitiveIteratorOfInt* p0, int p1) {
    Spliterators::spliteratorUnknownSize(p0, p1);
}

void spliteratorUnknownSize_test_11319(PrimitiveIteratorOfLong* p0, int p1) {
    Spliterators::spliteratorUnknownSize(p0, p1);
}

void spliteratorUnknownSize_test_11320(PrimitiveIteratorOfDouble* p0, int p1) {
    Spliterators::spliteratorUnknownSize(p0, p1);
}

void spliteratorUnknownSize_test_11321(Iterator* p0, int p1) {
    Spliterators::spliteratorUnknownSize(p0, p1);
}

void spliterator_test_11322(void** p0, int p1) {
    Spliterators::spliterator(p0, p1);
}

void spliterator_test_11323(Iterator* p0, long p1, int p2) {
    Spliterators::spliterator(p0, p1, p2);
}

void spliterator_test_11324(Collection* p0, int p1) {
    Spliterators::spliterator(p0, p1);
}

void spliterator_test_11325(PrimitiveIteratorOfInt* p0, long p1, int p2) {
    Spliterators::spliterator(p0, p1, p2);
}

void spliterator_test_11326(PrimitiveIteratorOfLong* p0, long p1, int p2) {
    Spliterators::spliterator(p0, p1, p2);
}

void spliterator_test_11327(PrimitiveIteratorOfDouble* p0, long p1, int p2) {
    Spliterators::spliterator(p0, p1, p2);
}

void spliterator_test_11328(long* p0, int p1, int p2, int p3) {
    Spliterators::spliterator(p0, p1, p2, p3);
}

void spliterator_test_11329(long* p0, int p1) {
    Spliterators::spliterator(p0, p1);
}

void spliterator_test_11330(int* p0, int p1, int p2, int p3) {
    Spliterators::spliterator(p0, p1, p2, p3);
}

void spliterator_test_11331(void** p0, int p1, int p2, int p3) {
    Spliterators::spliterator(p0, p1, p2, p3);
}

void spliterator_test_11332(int* p0, int p1) {
    Spliterators::spliterator(p0, p1);
}

void spliterator_test_11333(double* p0, int p1, int p2, int p3) {
    Spliterators::spliterator(p0, p1, p2, p3);
}

void spliterator_test_11334(double* p0, int p1) {
    Spliterators::spliterator(p0, p1);
}

void emptySpliterator_test_11335() {
    Spliterators::emptySpliterator();
}

void emptyIntSpliterator_test_11336() {
    Spliterators::emptyIntSpliterator();
}

void emptyLongSpliterator_test_11337() {
    Spliterators::emptyLongSpliterator();
}

void emptyDoubleSpliterator_test_11338() {
    Spliterators::emptyDoubleSpliterator();
}