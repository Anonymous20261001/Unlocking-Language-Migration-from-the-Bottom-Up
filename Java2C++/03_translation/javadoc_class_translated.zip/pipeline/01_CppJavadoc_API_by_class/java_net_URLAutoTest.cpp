#include <string>
#include <stdexcept>

class URLStreamHandlerFactory {
public:
    virtual ~URLStreamHandlerFactory() = default;
    virtual std::string createURLStreamHandler(const std::string& protocol) = 0;
};

class TestURLStreamHandlerFactory : public URLStreamHandlerFactory {
public:
    std::string createURLStreamHandler(const std::string& protocol) override {
        return "";
    }
};

class URL {
public:
    static void setURLStreamHandlerFactory(URLStreamHandlerFactory* factory) {
        if (factory_ != nullptr) {
            throw std::runtime_error("factory already defined");
        }
        factory_ = factory;
    }

private:
    static URLStreamHandlerFactory* factory_;
};

URLStreamHandlerFactory* URL::factory_ = nullptr;

void setURLStreamHandlerFactory_test_13249() {
    URLStreamHandlerFactory* factory = new TestURLStreamHandlerFactory();
    URL::setURLStreamHandlerFactory(factory);
}
