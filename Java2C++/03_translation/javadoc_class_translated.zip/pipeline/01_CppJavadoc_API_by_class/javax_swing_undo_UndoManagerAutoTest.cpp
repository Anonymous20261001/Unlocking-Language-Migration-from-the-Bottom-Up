#include <string>
#include <vector>
#include <algorithm>

class UndoableEdit {
public:
    virtual ~UndoableEdit() = default;

    virtual void undo() {}
    virtual void redo() {}
    virtual bool canUndo() const { return true; }
    virtual bool canRedo() const { return true; }

    virtual std::string getPresentationName() const { return ""; }
    virtual std::string getUndoPresentationName() const { return "Undo"; }
    virtual std::string getRedoPresentationName() const { return "Redo"; }

    virtual void die() {}
    virtual bool addEdit(UndoableEdit* anEdit) { (void)anEdit; return false; }
    virtual bool replaceEdit(UndoableEdit* anEdit) { (void)anEdit; return false; }
    virtual bool isSignificant() const { return true; }
};

class UndoableEditEvent {
    void* source;
    UndoableEdit* edit;
public:
    UndoableEditEvent(void* source, UndoableEdit* edit)
        : source(source), edit(edit) {}

    void* getSource() const { return source; }
    UndoableEdit* getEdit() const { return edit; }
};

class UndoManager {
private:
    std::vector<UndoableEdit*> edits;
    int limit;
    int index;

public:
    UndoManager() : limit(100), index(0) {}

    void undoableEditHappened(UndoableEditEvent* e) {
        if (e != nullptr) {
            addEdit(e->getEdit());
        }
    }

    bool addEdit(UndoableEdit* edit) {
        if (edit == nullptr) {
            return false;
        }

        if (index < static_cast<int>(edits.size())) {
            edits.erase(edits.begin() + index, edits.end());
        }

        edits.push_back(edit);

        if (limit >= 0 && static_cast<int>(edits.size()) > limit) {
            int overflow = static_cast<int>(edits.size()) - limit;
            edits.erase(edits.begin(), edits.begin() + overflow);
            index -= overflow;
            if (index < 0) {
                index = 0;
            }
        }

        return true;
    }

    void redo() {
        if (canRedo()) {
            UndoableEdit* edit = edits[index];
            ++index;
            edit->redo();
        }
    }

    void undo() {
        if (canUndo()) {
            --index;
            UndoableEdit* edit = edits[index];
            edit->undo();
        }
    }

    std::string getUndoPresentationName() {
        if (canUndo()) {
            return edits[index - 1]->getUndoPresentationName();
        }
        return "Undo";
    }

    std::string getRedoPresentationName() {
        if (canRedo()) {
            return edits[index]->getRedoPresentationName();
        }
        return "Redo";
    }

    bool canUndo() const {
        return index > 0 && edits[index - 1]->canUndo();
    }

    bool canRedo() const {
        return index < static_cast<int>(edits.size()) && edits[index]->canRedo();
    }

    int getLimit() const {
        return limit;
    }

    void discardAllEdits() {
        edits.clear();
        index = 0;
    }

    void setLimit(int l) {
        limit = l;
        if (limit >= 0 && static_cast<int>(edits.size()) > limit) {
            int overflow = static_cast<int>(edits.size()) - limit;
            edits.erase(edits.begin(), edits.begin() + overflow);
            index -= overflow;
            if (index < 0) {
                index = 0;
            }
        }
    }

    void undoOrRedo() {
        if (index == static_cast<int>(edits.size())) {
            undo();
        } else {
            redo();
        }
    }

    bool canUndoOrRedo() const {
        return canUndo() || canRedo();
    }

    std::string getUndoOrRedoPresentationName() {
        if (index == static_cast<int>(edits.size())) {
            return getUndoPresentationName();
        } else {
            return getRedoPresentationName();
        }
    }

    void end() {}
};

void undoableEditHappened_test_13193(UndoableEditEvent* p0) {
    UndoManager instance;
    instance.undoableEditHappened(p0);
}

void addEdit_test_13194(UndoableEdit* p0) {
    UndoManager instance;
    instance.addEdit(p0);
}

void redo_test_13195() {
    UndoManager instance;
    instance.redo();
}

void undo_test_13196() {
    UndoManager instance;
    instance.undo();
}

void getUndoPresentationName_test_13197() {
    UndoManager instance;
    instance.getUndoPresentationName();
}

void getRedoPresentationName_test_13198() {
    UndoManager instance;
    instance.getRedoPresentationName();
}

void canUndo_test_13199() {
    UndoManager instance;
    instance.canUndo();
}

void canRedo_test_13200() {
    UndoManager instance;
    instance.canRedo();
}

void getLimit_test_13201() {
    UndoManager instance;
    instance.getLimit();
}

void discardAllEdits_test_13202() {
    UndoManager instance;
    instance.discardAllEdits();
}

void setLimit_test_13203(int p0) {
    UndoManager instance;
    instance.setLimit(p0);
}

void undoOrRedo_test_13204() {
    UndoManager instance;
    instance.undoOrRedo();
}

void canUndoOrRedo_test_13205() {
    UndoManager instance;
    instance.canUndoOrRedo();
}

void getUndoOrRedoPresentationName_test_13206() {
    UndoManager instance;
    instance.getUndoOrRedoPresentationName();
}

void end_test_13207() {
    UndoManager instance;
    instance.end();
}
