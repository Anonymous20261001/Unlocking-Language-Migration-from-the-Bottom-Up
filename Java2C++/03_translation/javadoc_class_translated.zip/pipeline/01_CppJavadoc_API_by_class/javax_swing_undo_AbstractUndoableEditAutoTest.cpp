#include <string>
#include <stdexcept>

class UndoableEdit {
public:
    virtual ~UndoableEdit() = default;
    virtual void undo() = 0;
    virtual bool canUndo() const = 0;
    virtual void redo() = 0;
    virtual bool canRedo() const = 0;
    virtual void die() = 0;
    virtual bool addEdit(UndoableEdit& anEdit) = 0;
    virtual bool replaceEdit(UndoableEdit& anEdit) = 0;
    virtual bool isSignificant() const = 0;
    virtual std::string getPresentationName() const = 0;
    virtual std::string getUndoPresentationName() const = 0;
    virtual std::string getRedoPresentationName() const = 0;
};

class CannotUndoException : public std::runtime_error {
public:
    CannotUndoException() : std::runtime_error("Cannot undo") {}
};

class CannotRedoException : public std::runtime_error {
public:
    CannotRedoException() : std::runtime_error("Cannot redo") {}
};

class AbstractUndoableEdit : public UndoableEdit {
protected:
    bool hasBeenDone;
    bool alive;

public:
    AbstractUndoableEdit()
        : hasBeenDone(true), alive(true) {}

    bool canUndo() const override {
        return alive && hasBeenDone;
    }

    bool canRedo() const override {
        return alive && !hasBeenDone;
    }

    void undo() override {
        if (!canUndo()) {
            throw CannotUndoException();
        }
        hasBeenDone = false;
    }

    void redo() override {
        if (!canRedo()) {
            throw CannotRedoException();
        }
        hasBeenDone = true;
    }

    void die() override {
        alive = false;
    }

    bool addEdit(UndoableEdit& anEdit) override {
        (void)anEdit;
        return false;
    }

    bool replaceEdit(UndoableEdit& anEdit) override {
        (void)anEdit;
        return false;
    }

    bool isSignificant() const override {
        return true;
    }

    std::string getPresentationName() const override {
        return "";
    }

    std::string getUndoPresentationName() const override {
        return "Undo";
    }

    std::string getRedoPresentationName() const override {
        return "Redo";
    }
};

void addEdit_test_14() {
    AbstractUndoableEdit instance;
    AbstractUndoableEdit p0;
    instance.addEdit(p0);
}

void redo_test_15() {
    AbstractUndoableEdit instance;
    instance.redo();
}

void undo_test_16() {
    AbstractUndoableEdit instance;
    instance.undo();
}

void getPresentationName_test_17() {
    AbstractUndoableEdit instance;
    instance.getPresentationName();
}

void isSignificant_test_18() {
    AbstractUndoableEdit instance;
    instance.isSignificant();
}

void getUndoPresentationName_test_19() {
    AbstractUndoableEdit instance;
    instance.getUndoPresentationName();
}

void getRedoPresentationName_test_20() {
    AbstractUndoableEdit instance;
    instance.getRedoPresentationName();
}

void die_test_21() {
    AbstractUndoableEdit instance;
    instance.die();
}

void replaceEdit_test_22() {
    AbstractUndoableEdit instance;
    AbstractUndoableEdit p0;
    instance.replaceEdit(p0);
}

void canUndo_test_23() {
    AbstractUndoableEdit instance;
    instance.canUndo();
}

void canRedo_test_24() {
    AbstractUndoableEdit instance;
    instance.canRedo();
}