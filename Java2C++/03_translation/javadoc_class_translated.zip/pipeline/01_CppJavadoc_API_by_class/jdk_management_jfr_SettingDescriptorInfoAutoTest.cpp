#include <any>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>

class CompositeData {
public:
    virtual ~CompositeData() = default;
    virtual bool containsKey(const std::string& key) const = 0;
    virtual const std::any& get(const std::string& key) const = 0;
};

class MapCompositeData : public CompositeData {
public:
    explicit MapCompositeData(std::unordered_map<std::string, std::any> values)
        : values_(std::move(values)) {}

    bool containsKey(const std::string& key) const override {
        return values_.find(key) != values_.end();
    }

    const std::any& get(const std::string& key) const override {
        auto it = values_.find(key);
        if (it == values_.end()) {
            throw std::invalid_argument("CompositeData has no key: " + key);
        }
        return it->second;
    }

private:
    std::unordered_map<std::string, std::any> values_;
};

class SettingDescriptorInfo {
public:
    SettingDescriptorInfo(std::string name, std::string label, std::string description,
                          std::string typeName, std::string contentType, std::string defaultValue)
        : name_(std::move(name)), label_(std::move(label)), description_(std::move(description)),
          typeName_(std::move(typeName)), contentType_(std::move(contentType)),
          defaultValue_(std::move(defaultValue)) {}

    static SettingDescriptorInfo from(const CompositeData& cd) {
        return SettingDescriptorInfo(
            getString(cd, "name"),
            getString(cd, "label"),
            getString(cd, "description"),
            getString(cd, "typeName"),
            getString(cd, "contentType"),
            getString(cd, "defaultValue"));
    }

    const std::string& name() const { return name_; }
    const std::string& label() const { return label_; }
    const std::string& description() const { return description_; }
    const std::string& typeName() const { return typeName_; }
    const std::string& contentType() const { return contentType_; }
    const std::string& defaultValue() const { return defaultValue_; }

private:
    static std::string getString(const CompositeData& cd, const std::string& key) {
        if (!cd.containsKey(key)) {
            return std::string();
        }
        const std::any& value = cd.get(key);
        if (value.has_value()) {
            if (value.type() == typeid(std::string)) {
                return std::any_cast<std::string>(value);
            }
            if (value.type() == typeid(const char*)) {
                return std::any_cast<const char*>(value);
            }
        }
        return std::string();
    }

    std::string name_;
    std::string label_;
    std::string description_;
    std::string typeName_;
    std::string contentType_;
    std::string defaultValue_;
};

void from_test_11072(const CompositeData& p0) {
    SettingDescriptorInfo::from(p0);
}