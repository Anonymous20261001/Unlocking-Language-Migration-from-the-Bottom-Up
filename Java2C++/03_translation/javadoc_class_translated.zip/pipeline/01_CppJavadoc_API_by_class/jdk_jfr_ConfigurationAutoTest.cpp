#include <vector>

namespace jdk {
namespace jfr {

class Configuration {
public:
    Configuration() = default;

    static std::vector<Configuration> getConfigurations() {
        return std::vector<Configuration>{};
    }
};

} // namespace jfr
} // namespace jdk

void getConfigurations_test_2908() {
    jdk::jfr::Configuration::getConfigurations();
}