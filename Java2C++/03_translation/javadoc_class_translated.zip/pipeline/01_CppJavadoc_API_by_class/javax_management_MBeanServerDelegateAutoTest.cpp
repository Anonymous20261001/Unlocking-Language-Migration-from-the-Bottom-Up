#include <string>
#include <vector>

class Object {
public:
    virtual ~Object() = default;
};

class Notification {
public:
    virtual ~Notification() = default;
};

class NotificationFilter {
public:
    virtual ~NotificationFilter() = default;
    virtual bool isNotificationEnabled(Notification* notification) = 0;
};

class NotificationListener {
public:
    virtual ~NotificationListener() = default;
    virtual void handleNotification(Notification* notification, Object* handback) = 0;
};

class MBeanNotificationInfo {
public:
    std::string type;
    std::string description;
    std::vector<std::string> notifTypes;
};

class MBeanServerDelegate : public Object {
public:
    std::vector<MBeanNotificationInfo> getNotificationInfo() {
        return {};
    }

    void sendNotification(Notification& p0) {
        (void)p0;
    }

    std::string getMBeanServerId() {
        return "MBeanServerDelegate";
    }

    std::string getSpecificationName() {
        return "JMX";
    }

    std::string getImplementationName() {
        return "MBeanServerDelegate";
    }

    void addNotificationListener(NotificationListener& p0, NotificationFilter& p1, Object& p2) {
        (void)p0;
        (void)p1;
        (void)p2;
    }

    std::string getSpecificationVersion() {
        return "1.4";
    }

    std::string getSpecificationVendor() {
        return "Java Management Extensions";
    }

    std::string getImplementationVersion() {
        return "1.0";
    }

    std::string getImplementationVendor() {
        return "Oracle";
    }
};

void getNotificationInfo_test_8432() {
    MBeanServerDelegate instance;
    instance.getNotificationInfo();
}

void sendNotification_test_8433(Notification& p0) {
    MBeanServerDelegate instance;
    instance.sendNotification(p0);
}

void getMBeanServerId_test_8434() {
    MBeanServerDelegate instance;
    instance.getMBeanServerId();
}

void getSpecificationName_test_8435() {
    MBeanServerDelegate instance;
    instance.getSpecificationName();
}

void getImplementationName_test_8436() {
    MBeanServerDelegate instance;
    instance.getImplementationName();
}

void addNotificationListener_test_8437(NotificationListener& p0, NotificationFilter& p1, Object& p2) {
    MBeanServerDelegate instance;
    instance.addNotificationListener(p0, p1, p2);
}

void getSpecificationVersion_test_8438() {
    MBeanServerDelegate instance;
    instance.getSpecificationVersion();
}

void getSpecificationVendor_test_8439() {
    MBeanServerDelegate instance;
    instance.getSpecificationVendor();
}

void getImplementationVersion_test_8440() {
    MBeanServerDelegate instance;
    instance.getImplementationVersion();
}

void getImplementationVendor_test_8441() {
    MBeanServerDelegate instance;
    instance.getImplementationVendor();
}