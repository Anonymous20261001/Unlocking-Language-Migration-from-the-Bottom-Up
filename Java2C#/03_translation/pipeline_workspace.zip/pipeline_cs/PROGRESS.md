# Pipeline Final Results (2026-08-07)

## Summary

| Stage | Count | Rate |
|---|---|---|
| Total methods | 1754 | 100% |
| Step 1: Classes translated | 306/306 | 100% |
| Step 2: Methods split | 1754/1754 | 100% |
| Step 2.5: Skeleton compile PASS | 1017 | 58.0% |
| Step 3: Test bodies translated | 1017/1017 | 100% |
| **Step 4: Final compile PASS** | **1013/1017** | **99.6%** |
| **Step 4: Run PASS** | **847/1017** | **83.3%** |
| **End-to-end** | **847/1754** | **48.3%** |

## Retry Rounds

| Round | Strategy | Compile OK | Run OK | E2E |
|---|---|---|---|---|
| R0 | Initial translation | 505 | 446 | 25.4% |
| R1 | Retry 512 failures | 616 | 524 | 29.9% |
| R2 | Retry 401 failures | 716 | 595 | 33.9% |
| R3 | Retry 301 failures | 716 | 595 | 33.9% |
| R4 | Retry 301 failures | 882 | 751 | 42.8% |
| R5 | Retry 135 failures | 888 | 755 | 43.0% |
| R6 | Retry 129 failures | 898 | 763 | 43.5% |
| R7 | Retry 119 failures | 900 | 768 | 43.8% |
| **Manual fix** | 5 agents fix 69 files | **1013** | **847** | **48.3%** |

## Key Files

| File | Description |
|---|---|
| `method_report.csv` | Per-method details (1754 rows) |
| `PROMPTS.md` | LLM prompts for each stage |
| `01_translate.log` | Step 1 translation log (JSONL) |
| `02_split.log` | Step 2 split log |
| `02.5_compile_check.csv` | Skeleton compile results |
| `03_translate_bodies.log` | Test body translation log |
| `03_retry_compile.log` | Retry translation log |
| `04_test_results/cs_test_results.csv` | Final compile + run results |
