# LLM Prompts

## Stage 1: Class-Level Translation (step1_translate_class.py)

**Model**: `deepseek-v4-flash` (主), `deepseek-chat` (补漏)

**Temperature**: 0.1, **max_tokens**: 16384

### System Prompt

```
You are a professional Java and C# developer.

Below is a Java test file. Each @Test method creates an instance of a Java class
and exercises one of its API methods.

Your task:
1. Translate every Java @Test method into exactly one C# test method with the
SAME name (e.g., equals_test_6446 -> public void equals_test_6446()).
2. For each Java class used in the tests, implement a C# equivalent class whose
API behaves identically to the original Java API.

Important:
- Keep the EXACT same method naming: {method}_test_{number}
- Every @Test method in the Java file MUST have a corresponding C# test method
- Use namespace Generated.Test
- Do NOT use NUnit/XUnit/MSTest attributes — test methods are plain void methods
- Java String -> C# string, boolean -> bool, Object -> object
- The code must compile with: mcs -target:library
- Output only the complete C# code. No explanation, no markdown fences.
```

### User Prompt (first attempt)

The raw Java test file content (e.g., `new_Java_class_tests/java_awt_ButtonAutoTest.java`).

### Retry Prompt (when methods are missing)

```
{original_java_code}

=== IMPORTANT: MISSING TEST METHODS ===
The following test methods were NOT found in your previous output:
  {missing_methods_list}

Please translate the ENTIRE Java file again, making sure ALL @Test methods
(including those listed above) are translated to C# test methods
with the EXACT same names (e.g., public void methodName_test_N()).
```

### Verification

Regex: `void\s+{method_name}_test_{number}\s*\(` against the LLM output.
Max retries: 3. If all 3 retries fail, mark as `incomplete` or `empty_response`.

---

## Stage 3: Test Body Translation (step3_translate_bodies.py)

**Model**: `deepseek-chat`

**Temperature**: 0.1, **max_tokens**: 4096

### System Prompt

```
You translate Java test code to C#.

Given C# class definitions and a Java test method body,
output ONLY the C# function body (lines between { and }).

Mapping rules:
- Assert.assertTrue(msg, cond) -> System.Diagnostics.Debug.Assert(cond);
- Assert.assertFalse(msg, cond) -> System.Diagnostics.Debug.Assert(!cond);
- Assert.assertEquals(msg, expected, actual) -> if (!object.Equals(expected, actual)) throw new Exception("Expected " + expected + " but got " + actual);
- Assert.assertNull(msg, obj) -> System.Diagnostics.Debug.Assert(obj == null);
- Assert.assertNotNull(msg, obj) -> // removed (null check not needed in C#)
- Assert.fail(msg) -> throw new Exception(msg);
- Assert.assertArrayEquals(msg, a, b) -> // collection comparison, use manual check
- Assert.assertSame(msg, a, b) -> System.Diagnostics.Debug.Assert(ReferenceEquals(a, b));
- Assert.assertNotSame(msg, a, b) -> System.Diagnostics.Debug.Assert(!ReferenceEquals(a, b));
- try { ... } catch (SomeException e) { } -> try { ... } catch (Exception) { }
- new Type(args) -> new Type(args)
- null -> null
- boolean -> bool
- String -> string
- Integer/long/double/float literals stay as-is
- Use the EXACT types and method names from the class definitions provided

Important: Do NOT modify the wrapper class unless it has a compile error.
Only the test body should be translated.

Output ONLY the function body lines. No explanation, no markdown fences,
no using, no namespace, no class definitions, no function signature.
```

### User Prompt

```
=== C# Class Definitions (DO NOT MODIFY THESE) ===
{class_definitions_header}

=== Java Test Case ===
{java_test_file_content}

Output ONLY the C# function body for {function_name}.
Use the EXACT C# types from the class definitions above.
```

### Output Assembly

```python
out_code = class_defs
if "Debug.Assert" in body and "using System.Diagnostics" not in out_code:
    out_code = "using System.Diagnostics;\n" + out_code
out_code += f"\n\npublic void {func_name}() {{\n{body}\n}}\n    }}\n}}"
```

---

## Stage 3 Retry (step3_retry_compile.py)

**Model**: `deepseek-chat`

**Temperature**: 0.1, **max_tokens**: 4096

Same system prompt as Stage 3, plus these additions:

```
IMPORTANT: You may ADD or MODIFY wrapper class methods if needed to compile.
If the test calls a method that doesn't exist, ADD a stub for it.
TOP PRIORITY: make the code COMPILE successfully.

Output the COMPLETE C# file (wrapper + test + closing braces). No markdown, no explanation.
```

### Retry User Prompt (with compile error feedback)

```
=== C# Class Definitions ===
{class_definitions}

=== Java Test Case ===
{java_code}

=== Your Previous Translation Had This Compile Error ===
{compile_error_message}

Fix the compile error and output ONLY the corrected C# function body for {func_name}.
Use EXACT C# types and member names from the class definitions.
```

Max retries: 4, with incremental compile error feedback.
