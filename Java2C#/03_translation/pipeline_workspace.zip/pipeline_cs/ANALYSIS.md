# Java→C# 非LLM翻译瓶颈分析

## 方法

手工分析了来自8个不同包（java.util, java.awt, java.time, java.lang.reflect, java.util.concurrent, javax.sound.sampled, java.nio, java.lang）的15个代表性Java Randoop测试用例。对每个文件识别了阻碍基于规则（非LLM）翻译的具体问题，分为6类。

## 统计总结

| 类别 | 命中文件数 | 占比 |
|---|---|---|
| A) C#缺少等价API | 15/15 | 100% |
| D) 语义不匹配 | 12/15 | 80% |
| E) 依赖链 | 12/15 | 80% |
| C) 重载/签名决议 | 6/15 | 40% |
| B) 类型系统不匹配 | 5/15 | 33% |
| F) 其他（如数学语义） | 1/15 | 7% |

## 各类别详解

### A) C#缺少等价API — 100%命中
每个测试类都包装了没有BCL对应物的JDK API：
- java.util.Arrays.stream() → DoubleStream（无.NET等价）
- java.util.concurrent.Executors/ExecutorService/ThreadFactory/Callable（整个并发框架无对应）
- javax.sound.sampled.AudioSystem/AudioFormat（整个音频API无对应）
- java.nio.ByteBuffer（position/limit/flip语义无.NET对应）
- java.time.LocalDateTime（纳秒精度，.NET DateTime仅100ns）
- java.lang.reflect.Array.get/setInt（反射入口完全不同）
- java.awt.Color.decode()（System.Drawing.Color无Decode方法）
- java.lang.Math.multiplyHigh()（无.NET对应）

### D) 语义不匹配 — 80%命中（最关键的子模式）
**异常类型+消息字面断言**是最主要的子模式。Randoop生成精确的异常类型和JDK消息：
- `"Zero length string"` — Color.decode("")时NumberFormatException的消息
- `"offset"` — Objects.requireNonNull的消息
- `"Argument is not an array"` — Array.get参数非数组时的消息
- `"Cannot read the array length because \"buf\" is null"` — JVM层面的NPE消息
- `"fromIndex(10) > toIndex(-2)"` — Array.binarySearch的rangeCheck消息

翻译器无法从JDK源码推导出这些字面消息字符串。

**字符串格式化语义**：
- `Arrays.toString(double[])` → `[100.0]`（Java格式化）
- `Thread.toString()` → `Thread[pool-250-thread-1,5,main]`
- `Encoding.toString()` → `PCM_FLOAT`

### E) 依赖链 — 80%命中
`Executors` → `ExecutorService` → `ThreadFactory` → `Runnable` → `Thread` → `Callable<T>`，五层类链必须在编译前全部实现。排序很重要。

### C) 重载决议 — 40%命中
JDK有大量重载族：
- JUnit `assertArrayEquals`/`assertEquals` 6+重载
- `Arrays.binarySearch` 19个重载
- `ByteBuffer.wrap` 2参数 vs 3参数
- `AudioSystem.getAudioInputStream` 4个重载

### B) 类型系统不匹配 — 33%命中
- 泛型接口不存在于C#：`List<Runnable>`, `Callable<Object>`
- LocalDateTime vs DateTime：精度（纳秒 vs 100ns ticks）、时区标记（无时区 vs Kind）
- 原始类型装箱：`(Object) '4'` 与 `Array` 类型层级的交互

## 7大失败类别（来自34个文件、20+包的详细分析）

### 1. 完全没有.NET等价API — 100%命中
- java.awt.*（System.Drawing ≠ AWT）
- javax.sound.sampled.*（整个音频API）
- javax.swing.* / javax.swing.undo / javax.swing.text
- java.beans.*
- java.util.concurrent（ExecutorService/Callable/Runnable）
- java.nio.ByteBuffer（position/limit/flip）
- java.lang.invoke.MethodHandles
- java.lang.reflect.Proxy/Array

### 2. 异常精确性陷阱 — 493个Assert.fail
Java异常类型+JDK消息必须完全匹配：
- NPE消息是JVM生成的（"Cannot invoke X because Y is null"）
- IAE消息是JDK源码写死的（"Zero length string", "Argument is not an array"）
- C#异常类型不同（ArgumentNullException ≠ NullPointerException）
- C#异常消息不同（"Object reference not set" ≠ JDK消息）

### 3. 类型系统不匹配
- `byte`签名差异（Java signed vs C# unsigned）
- `Float.valueOf(31.0f) == 31.0f` — 装箱比较在C#中不编译
- `Class<?>` 通配符在C#泛型中不可表达
- Enum vs static-final-class-instance（Locale.ITALIAN, Level.FINER）— 行为不同
- `CharSequence`接口无C#对应

### 4. 重载决议
- Arrays.binarySearch有~20个重载
- 6种JUnit assert方法，参数顺序和语义与.NET框架不同
- ByteBuffer.wrap 2参数vs 3参数
- AudioSystem.getAudioInputStream 4个重载

### 5. 构造函数和值创建链
- `new Path2D.Float()` — 嵌套类
- `new Locale.Builder().setLocale(...).build()` — fluent链
- `new TabSet(new TabStop[0])` — 参数类型也需要映射
- `Locale.ITALIAN`/`Level.FINER` — 静态字段的引用标识语义

### 6. 断言语义陷阱
- `Debug.Assert`在Release模式下被编译掉
- `assertTrue("'" + x + "' != '" + y + "'", x == y)` — 消息格式是Java风格
- `assertEquals`参数顺序（expected vs actual）
- `assertArrayEquals`需要内容相等而非引用相等
- `toString()`精确格式断言（"PCM_FLOAT", "[100.0]", "Thread[...]"）

### 7. 即使是"等价"API也存在语义差异
- Base64 MIME编码换行规则不同
- Duration纳秒精度 vs TimeSpan 100ns
- YearMonth/DateTimeFormatter没有.NET对应
- Math.multiplyHigh不存在，手动实现需匹配Java的128位算术语义
- 时区数据（getAvailableIDs）在不同平台上不同

## 结论

基于规则的Java→C#翻译在Randoop测试用例上的**根本瓶颈**不是语法转换（如markdown、括号匹配），而是：

1. **API完整性鸿沟** — 每个测试依赖的JDK API在.NET中没有对应物，必须构建完整的wrapper库
2. **异常精确性** — Randoop生成的测试断言了JDK层面的精确异常类型和消息字符串，基于规则的翻译无法推导
3. **类型和语义差异** — 即使有"等价"API，byte签名、泛型约束、枚举语义、时间精度等差异使直译结果不正确
4. **依赖链** — wrapper类之间存在深层的编译依赖（Executors→ExecutorService→Runnable→Thread），排序和完整性无法自动保证

LLM翻译能够工作（达到48.3%端到端通过率）正是因为LLM隐式地：
- 生成了wrapper类实现
- 为缺失的API添加了stub
- 近似了异常类型和消息
- 处理了类型转换和适配

要达到比LLM更好的结果，基于规则的翻译器需要一个**完整的手工JDK→.NET API映射表**，每条映射包含：类型映射、方法签名转换、异常类型映射、以及精确的语义等价实现。
