# Java→C# 规则翻译的语法层面障碍分析

基于 38 个 Java 测试文件的逐行分析 + 20 对 Java/C# 文件的逐行对比 + 1017 个 PASS 方法的全量统计。

## 核心结论

每8-12个翻译决策中：
- **63%** 可机械化（类型去限定、断言改写、变量保留）
- **22%** 需要 wrapper 内省（方法名、返回类型、异常行为）
- **15% 不可机械化**（wrapper 缺失静态字段/方法、Java语义差异）

## 八类翻译决策（按频率排序）

### 1. 类型适配（100%文件命中）
- FQCN → 短名：`java.awt.geom.Point2D` → `Point2D`（每个文件3-7次）
- `Class<?>` → `Type`（301次）
- 泛型擦除：`Optional<String>` → `Optional`，`List<Runnable>` → `List<Runnable>`
- `?` 通配符（321次）必须丢弃或用 `object` 替代

### 2. 参数输入（~70%文件命中）
- null 字面量（110次）→ 直接保留
- 嵌套强转：`(int)(byte)10`、`(double)0.0f`、`(long)'4'` — **语法完全相同**
- 负数字面量：`(-1)`、`(-1L)`（238次）
- 空数组 `new T[] {}`（146次）、单元素数组 `{ '4' }`（20次）
- 枚举类静态字段：`Locale.KOREA`、`AlphaComposite.SrcIn` — **wrapper 缺失，无法翻译**

### 3. 方法调用映射（~60%文件命中）
- `.getClass()`→`.GetType()`、`.toString()`→`.ToString()` — **固定4项表**
- `.equals()`→`.Equals()`（71次）— 但 C# `==` 是引用比较，需用 `object.Equals()`
- **Java自动拆箱陷阱**：`byte1 == (byte)0` 中 `byte1` 是 wrapper 对象，Java 自动拆箱为 byte 比较。C# 必须改为 `byte1.byteValue() == (byte)0`
- wrapper 方法命名不一致：有的 camelCase `decode()`，有的 PascalCase `CheckedQueue()` — **必须解析 wrapper 源码**

### 4. 异常处理（288个文件包含 try/catch）
- 13种 Java 异常需映射到 C#：NPE→NullReferenceException，IAE→ArgumentException，IOOBE→IndexOutOfRangeException
- javax.* 异常（CannotUndoException, RuntimeOperationsException）无 C# 对应 → 退化为 `Exception`
- fail 消息是 **JDK源码字面量**（"Zero length string", "Argument is not an array"），直接复制

### 5. 断言翻译（6种JUnit断言，全部出现）
- `assertNotNull` ×1342 → 直接删除（"null check not needed in C#"）
- `assertTrue("msg", expr)` ×283 → `Debug.Assert(expr)` 或 `if (!expr) throw new Exception("msg")`
- `assertEquals` ×241 → 消息格式 `"'" + x + "' != '" + y + "'"` 可模式匹配
- `assertArrayEquals` ×119 → **必须逐元素比较**，不能 `object.Equals`（引用比较）
- **LLM不一致**：同一断言有时丢消息有时保留，有时用 `Debug.Assert` 有时用 `if-throw`

### 6. 对象构造（~30文件）
- `new Locale.Builder()` — 嵌套类
- 链式 builder：`builder0.setLocale(...).build()` — **需要知道 setLocale 返回 Builder 类型**
- 泛型构造：`new ArrayDeque<Comparator<String>>()` — 擦除为 `new ArrayDeque()`

### 7. 变量命名（100%文件命中）
- Randoop 编号风格：`wildcardClass4`, `strComparatorQueue0`, `uRL0`
- 必须逐字保留，大小写不能变

### 8. 边界情况
- void 方法调用作裸语句（38次）
- flaky 注释掉的断言，带 `// flaky` 前缀（30次）— 规则：跳过
- `assertArrayEquals(double[], double[], 1.0E-15)` — delta 容差参数（8次），LLM 有时丢弃

## 规则翻译 CAN vs CANNOT

### CAN（100%机械化，~63%决策）
| 模式 | 规则 |
|---|---|
| FQCN→短名 | 从 wrapper 文件解析类型表 |
| char→int 强转 | `(int)'#'` C# 语法相同，保留 |
| getClass/toString/equals | 固定4项映射表 |
| assertNotNull/assertNull | 直接删除或 `!= null` |
| fail → throw | 消息字面量复制 |
| 空数组/单元素数组 | 语法相同 |
| Class<?> → Type | 全量替换 |

### HARD-CAN（需要wrapper内省，~22%决策）
| 模式 | 方案 |
|---|---|
| wrapper方法名 | 从 wrapper 解析方法签名表 |
| 返回类型（builer链） | 从 wrapper 解析返回类型 |
| 异常类型（wrapper扔什么） | 分析 wrapper 源码 |
| 自动拆箱 | `byte1 == (byte)0` → `byte1.byteValue() == (byte)0` |
| assertArrayEquals | 生成逐元素比较代码 |

### CANNOT（规则翻译不可能，~15%决策）
| 模式 | 影响 | 原因 |
|---|---|---|
| **wrapper缺失静态字段** | **230文件** | Locale.KOREA、AlphaComposite.SrcIn等不在wrapper中 |
| **wrapper缺失方法** | ~10文件 | Comparator.reverseOrder()等 |
| **JVM异常消息** | 167文件 | "Cannot invoke X because Y is null"是JVM生成的 |
| **语义不匹配** | ~45文件 | Collections.CheckedQueue不抛NPE，Java却期望NPE |
| **object.Equals在数组上** | ~35文件 | LLM自己也搞错了 |

## 关键数据

- 每个测试文件平均 **8-12** 个翻译决策
- **没有任何一个文件** 是纯字符串替换可完成的
- 最大单一障碍：wrapper API覆盖率不足（静态字段缺失影响 230/1017 = 23% 的文件）
- 第二大障碍：Java自动拆箱/数组equals/异常行为的语义差异
