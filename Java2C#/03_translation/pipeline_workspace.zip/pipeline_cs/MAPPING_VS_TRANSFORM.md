# Mapping vs Code Transformation 统计（两层判定）

## 判定方法

### 层1：测试体层面
提取 Java 测试体的 API 调用名（方法/构造，排除断言、Object 通用方法、注释、测试方法自身），
与 C# 测试体调用名（小写归一化）比对：
- mapping: Java 所有调用都在 C# 出现
- partial: 部分出现
- transformation: 一个都没有

### 层2：wrapper 方法体层面（对层1 mapping 的文件）
在骨架文件中定位 wrapper 方法定义，分类其方法体：
- delegation: 单条点调用（`_list.Remove(item)`）或 ≤3 条语句的守卫式委托 → 直接映射到 BCL
- reimplementation: 含循环/手工逻辑 → 代码重新生成
- stub: `return null` / 空体 → 占位

## 结果

### 层1：测试体层面（5053 个翻译产物）

| 类别 | 数量 | 占比 |
|---|---|---|
| 直接 mapping | 4156 | 82.2% |
| partial | 670 | 13.3% |
| 代码转换 | 94 | 1.9% |
| 无法判定 | 133 | 2.6% |

### 层2：加入 wrapper 方法体判定（4920 个）

| 类别 | 数量 | 占比 | 含义 |
|---|---|---|---|
| **true_mapping** | 2932 | **59.6%** | 测试体映射 + wrapper 委托 BCL |
| mixed_wrapper | 622 | 12.6% | 部分调用委托、部分重写/占位 |
| partial_mapping | 670 | 13.6% | 测试体只映射了部分调用 |
| wrapper_not_found | 324 | 6.6% | 无法定位 wrapper 方法 |
| **wrapped_transformation** | 278 | **5.7%** | 测试体同名调用，但 wrapper 重写(155)/占位(116) |
| test_body_transformation | 94 | 1.9% | 测试体层面就重写了 |

## 结论

1. 测试体层面 82.2% 是"看起来的 mapping"；但深入 wrapper 方法体后，
   真正"测试体映射 + wrapper 委托 BCL"的完整 mapping 只有 **~59.6%**
2. 代码转换发生在三个层面：
   - wrapper 方法体重写行为：~5.7%（纯）+ 12.6%（混合）
   - 测试体层面直接重写：1.9%
3. 用户假设成立：约 **15-18%** 的"mapping 外壳"底下是代码重新生成（含 stub），
   另有 6.6% 无法定位，13.6% 部分映射
