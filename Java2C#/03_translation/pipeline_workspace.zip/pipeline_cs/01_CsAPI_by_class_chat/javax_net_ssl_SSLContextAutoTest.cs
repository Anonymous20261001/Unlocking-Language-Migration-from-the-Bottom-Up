namespace Generated.Test
{
    using System;
    using System.Security.Authentication;
    using System.Security.Cryptography.X509Certificates;

    public class SSLContext : IDisposable
    {
        private static SSLContext _default;

        public static SSLContext Default
        {
            get { return _default; }
            set { _default = value; }
        }

        public static void SetDefault(SSLContext context)
        {
            _default = context;
        }

        public void Dispose()
        {
            // Dispose implementation
        }
    }

    public class javax_net_ssl_SSLContextAutoTest
    {
        public void setDefault_test_11400(SSLContext p0)
        {
            SSLContext.SetDefault(p0);
        }
    }
}