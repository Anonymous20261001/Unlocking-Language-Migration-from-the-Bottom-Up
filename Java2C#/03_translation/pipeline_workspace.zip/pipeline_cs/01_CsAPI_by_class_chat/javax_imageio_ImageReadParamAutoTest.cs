using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;

namespace Generated.Test
{
    // C# equivalent of java.awt.Dimension
    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public Dimension() : this(0, 0) { }
        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    // C# equivalent of java.awt.image.BufferedImage
    public class BufferedImage
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        public Bitmap Bitmap { get; private set; }

        public BufferedImage(int width, int height)
        {
            Width = width;
            Height = height;
            Bitmap = new Bitmap(width, height);
        }

        public BufferedImage(Bitmap bitmap)
        {
            Bitmap = bitmap;
            Width = bitmap.Width;
            Height = bitmap.Height;
        }
    }

    // C# equivalent of javax.imageio.ImageTypeSpecifier
    public class ImageTypeSpecifier
    {
        public int DataType { get; private set; }
        public int NumBands { get; private set; }

        public ImageTypeSpecifier(int dataType, int numBands)
        {
            DataType = dataType;
            NumBands = numBands;
        }

        public static ImageTypeSpecifier CreateFromBufferedImageType(int bufferedImageType)
        {
            return new ImageTypeSpecifier(bufferedImageType, 4);
        }
    }

    // C# equivalent of javax.imageio.ImageReadParam
    public class ImageReadParam
    {
        private BufferedImage destination;
        private int[] destinationBands;
        private ImageTypeSpecifier destinationType;
        private Dimension sourceRenderSize;
        private int sourceMinProgressivePass = 0;
        private int sourceMaxProgressivePass = int.MaxValue;
        private int sourceNumProgressivePasses = int.MaxValue;

        public int[] GetDestinationBands()
        {
            return destinationBands;
        }

        public BufferedImage GetDestination()
        {
            return destination;
        }

        public void SetDestination(BufferedImage destination)
        {
            this.destination = destination;
        }

        public bool CanSetSourceRenderSize()
        {
            return true;
        }

        public void SetDestinationBands(int[] destinationBands)
        {
            this.destinationBands = destinationBands;
        }

        public void SetSourceRenderSize(Dimension sourceRenderSize)
        {
            this.sourceRenderSize = sourceRenderSize;
        }

        public Dimension GetSourceRenderSize()
        {
            return sourceRenderSize;
        }

        public void SetSourceProgressivePasses(int minPass, int numPasses)
        {
            sourceMinProgressivePass = minPass;
            sourceNumProgressivePasses = numPasses;
            if (numPasses == int.MaxValue)
            {
                sourceMaxProgressivePass = int.MaxValue;
            }
            else
            {
                sourceMaxProgressivePass = minPass + numPasses - 1;
            }
        }

        public int GetSourceMinProgressivePass()
        {
            return sourceMinProgressivePass;
        }

        public int GetSourceMaxProgressivePass()
        {
            return sourceMaxProgressivePass;
        }

        public int GetSourceNumProgressivePasses()
        {
            return sourceNumProgressivePasses;
        }

        public void SetDestinationType(ImageTypeSpecifier destinationType)
        {
            this.destinationType = destinationType;
        }
    }

    public class javax_imageio_ImageReadParamAutoTest
    {
        public void getDestinationBands_test_5680()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetDestinationBands();
        }

        public void getDestination_test_5681()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetDestination();
        }

        public void setDestination_test_5682(BufferedImage p0)
        {
            ImageReadParam instance = new ImageReadParam();
            instance.SetDestination(p0);
        }

        public void canSetSourceRenderSize_test_5683()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.CanSetSourceRenderSize();
        }

        public void setDestinationBands_test_5684(int[] p0)
        {
            ImageReadParam instance = new ImageReadParam();
            instance.SetDestinationBands(p0);
        }

        public void setSourceRenderSize_test_5685(Dimension p0)
        {
            ImageReadParam instance = new ImageReadParam();
            instance.SetSourceRenderSize(p0);
        }

        public void getSourceRenderSize_test_5686()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetSourceRenderSize();
        }

        public void setSourceProgressivePasses_test_5687(int p0, int p1)
        {
            ImageReadParam instance = new ImageReadParam();
            instance.SetSourceProgressivePasses(p0, p1);
        }

        public void getSourceMinProgressivePass_test_5688()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetSourceMinProgressivePass();
        }

        public void getSourceMaxProgressivePass_test_5689()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetSourceMaxProgressivePass();
        }

        public void getSourceNumProgressivePasses_test_5690()
        {
            ImageReadParam instance = new ImageReadParam();
            instance.GetSourceNumProgressivePasses();
        }

        public void setDestinationType_test_5691(ImageTypeSpecifier p0)
        {
            ImageReadParam instance = new ImageReadParam();
            instance.SetDestinationType(p0);
        }
    }
}