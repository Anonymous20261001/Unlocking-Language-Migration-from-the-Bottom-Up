namespace Generated.Test
{
    public class jdk_javadoc_doclet_StandardDocletAutoTest
    {
        public void getName_test_11482()
        {
            StandardDoclet instance = new StandardDoclet();
            instance.GetName();
        }

        public void run_test_11483(DocletEnvironment p0)
        {
            StandardDoclet instance = new StandardDoclet();
            instance.Run(p0);
        }

        public void init_test_11484(Locale p0, Reporter p1)
        {
            StandardDoclet instance = new StandardDoclet();
            instance.Init(p0, p1);
        }

        public void getLocale_test_11485()
        {
            StandardDoclet instance = new StandardDoclet();
            instance.GetLocale();
        }

        public void getReporter_test_11486()
        {
            StandardDoclet instance = new StandardDoclet();
            instance.GetReporter();
        }

        public void getSupportedOptions_test_11487()
        {
            StandardDoclet instance = new StandardDoclet();
            instance.GetSupportedOptions();
        }

        public void getSupportedSourceVersion_test_11488()
        {
            StandardDoclet instance = new StandardDoclet();
            instance.GetSupportedSourceVersion();
        }
    }

    public class StandardDoclet
    {
        public string GetName()
        {
            return "StandardDoclet";
        }

        public bool Run(DocletEnvironment environment)
        {
            return true;
        }

        public void Init(Locale locale, Reporter reporter)
        {
        }

        public Locale GetLocale()
        {
            return null;
        }

        public Reporter GetReporter()
        {
            return null;
        }

        public System.Collections.Generic.List<DocletOption> GetSupportedOptions()
        {
            return new System.Collections.Generic.List<DocletOption>();
        }

        public SourceVersion GetSupportedSourceVersion()
        {
            return SourceVersion.RELEASE_8;
        }
    }

    public class DocletEnvironment
    {
    }

    public class Locale
    {
    }

    public class Reporter
    {
    }

    public class DocletOption
    {
    }

    public enum SourceVersion
    {
        RELEASE_0,
        RELEASE_1,
        RELEASE_2,
        RELEASE_3,
        RELEASE_4,
        RELEASE_5,
        RELEASE_6,
        RELEASE_7,
        RELEASE_8,
        RELEASE_9,
        RELEASE_10,
        RELEASE_11,
        RELEASE_12,
        RELEASE_13,
        RELEASE_14,
        RELEASE_15,
        RELEASE_16,
        RELEASE_17,
        RELEASE_18,
        RELEASE_19,
        RELEASE_20,
        RELEASE_21,
        RELEASE_22,
        RELEASE_23,
        RELEASE_24,
        RELEASE_25
    }
}