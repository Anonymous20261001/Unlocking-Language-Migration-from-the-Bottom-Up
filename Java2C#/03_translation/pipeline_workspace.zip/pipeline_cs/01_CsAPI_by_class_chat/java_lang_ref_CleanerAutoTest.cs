namespace Generated.Test
{
    using System;

    public class java_lang_ref_CleanerAutoTest
    {
        public void create_test_2319()
        {
            Cleaner.Create();
        }

        public void create_test_2320(ThreadFactory p0)
        {
            Cleaner.Create(p0);
        }
    }

    public class Cleaner
    {
        public static Cleaner Create()
        {
            return new Cleaner();
        }

        public static Cleaner Create(ThreadFactory threadFactory)
        {
            return new Cleaner();
        }
    }

    public class ThreadFactory
    {
        // Placeholder for Java's ThreadFactory interface
    }
}