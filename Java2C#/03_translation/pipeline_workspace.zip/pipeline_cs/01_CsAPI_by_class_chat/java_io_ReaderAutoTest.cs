namespace Generated.Test
{
    public class java_io_ReaderAutoTest
    {
        public void nullReader_test_10346()
        {
            Reader.NullReader();
        }

        public void of_test_10347(System.ICharSequence p0)
        {
            Reader.Of(p0);
        }
    }

    public static class Reader
    {
        public static Reader NullReader()
        {
            return new Reader();
        }

        public static Reader Of(System.ICharSequence p0)
        {
            return new Reader();
        }
    }
}

namespace System
{
    public interface ICharSequence
    {
        int Length();
        char CharAt(int index);
        ICharSequence SubSequence(int start, int end);
        string ToString();
    }
}