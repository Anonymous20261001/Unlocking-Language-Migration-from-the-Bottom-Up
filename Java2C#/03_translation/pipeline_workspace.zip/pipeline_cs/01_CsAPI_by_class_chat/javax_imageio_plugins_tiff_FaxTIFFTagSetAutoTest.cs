namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_FaxTIFFTagSetAutoTest
    {
        public void getInstance_test_4674()
        {
            FaxTIFFTagSet.getInstance();
        }
    }

    public class FaxTIFFTagSet
    {
        private static FaxTIFFTagSet instance;

        private FaxTIFFTagSet()
        {
        }

        public static FaxTIFFTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new FaxTIFFTagSet();
            }
            return instance;
        }
    }
}