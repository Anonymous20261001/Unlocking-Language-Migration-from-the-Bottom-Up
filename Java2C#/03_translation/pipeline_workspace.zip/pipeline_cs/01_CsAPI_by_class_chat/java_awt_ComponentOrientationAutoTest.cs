using System;
using System.Globalization;
using System.Resources;

namespace Generated.Test
{
    public class ComponentOrientation
    {
        public static ComponentOrientation GetOrientation(Locale locale)
        {
            // Java's ComponentOrientation.getOrientation(Locale) returns based on locale language
            // For simplicity, we'll return based on the locale's language
            if (locale != null && (locale.Language == "ar" || locale.Language == "he" || locale.Language == "fa" || locale.Language == "ur"))
            {
                return new ComponentOrientation(true);
            }
            return new ComponentOrientation(false);
        }

        public static ComponentOrientation GetOrientation(ResourceBundle resourceBundle)
        {
            // Java's ComponentOrientation.getOrientation(ResourceBundle) checks for "Orientation" key
            // If the key exists and is "RightToLeft", returns right-to-left orientation
            if (resourceBundle != null)
            {
                try
                {
                    string orientation = resourceBundle.GetString("Orientation");
                    if (orientation == "RightToLeft")
                    {
                        return new ComponentOrientation(true);
                    }
                }
                catch (Exception)
                {
                    // Key not found, default to left-to-right
                }
            }
            return new ComponentOrientation(false);
        }

        private bool isLeftToRight;

        private ComponentOrientation(bool isLeftToRight)
        {
            this.isLeftToRight = isLeftToRight;
        }

        public bool IsLeftToRight()
        {
            return isLeftToRight;
        }

        public bool IsHorizontal()
        {
            return true; // Java's ComponentOrientation always has horizontal orientation
        }
    }

    public class Locale
    {
        public string Language { get; private set; }
        public string Country { get; private set; }
        public string Variant { get; private set; }

        public Locale(string language, string country = "", string variant = "")
        {
            Language = language ?? "";
            Country = country ?? "";
            Variant = variant ?? "";
        }

        public static Locale GetDefault()
        {
            return new Locale(CultureInfo.CurrentCulture.TwoLetterISOLanguageName);
        }

        public override string ToString()
        {
            return Language + "_" + Country + "_" + Variant;
        }
    }

    public class ResourceBundle
    {
        private ResourceManager resourceManager;

        public ResourceBundle(ResourceManager resourceManager)
        {
            this.resourceManager = resourceManager;
        }

        public string GetString(string key)
        {
            return resourceManager.GetString(key);
        }

        public static ResourceBundle GetBundle(string baseName, Locale locale)
        {
            // Simplified implementation - in real usage, this would load from resource files
            // For testing purposes, we'll create a simple ResourceBundle
            ResourceManager rm = new ResourceManager(baseName, System.Reflection.Assembly.GetExecutingAssembly());
            return new ResourceBundle(rm);
        }
    }

    public class java_awt_ComponentOrientationAutoTest
    {
        public void getOrientation_test_2645(Locale p0)
        {
            ComponentOrientation.GetOrientation(p0);
        }

        public void getOrientation_test_2646(ResourceBundle p0)
        {
            ComponentOrientation.GetOrientation(p0);
        }
    }
}