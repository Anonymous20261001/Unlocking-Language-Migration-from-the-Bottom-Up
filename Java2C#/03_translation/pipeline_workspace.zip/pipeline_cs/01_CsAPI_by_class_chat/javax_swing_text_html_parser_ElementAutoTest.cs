namespace Generated.Test
{
    public class javax_swing_text_html_parser_ElementAutoTest
    {
        public void name2type_test_4462(string p0)
        {
            Element.name2type(p0);
        }
    }

    public static class Element
    {
        public static int name2type(string name)
        {
            // Implementation based on HTML element name to type mapping
            if (name == null)
                return 0;
            
            switch (name.ToLowerInvariant())
            {
                case "a": return 1;
                case "abbr": return 1;
                case "acronym": return 1;
                case "address": return 1;
                case "applet": return 1;
                case "area": return 1;
                case "article": return 1;
                case "aside": return 1;
                case "audio": return 1;
                case "b": return 1;
                case "base": return 1;
                case "basefont": return 1;
                case "bdi": return 1;
                case "bdo": return 1;
                case "bgsound": return 1;
                case "big": return 1;
                case "blink": return 1;
                case "blockquote": return 1;
                case "body": return 1;
                case "br": return 1;
                case "button": return 1;
                case "canvas": return 1;
                case "caption": return 1;
                case "center": return 1;
                case "cite": return 1;
                case "code": return 1;
                case "col": return 1;
                case "colgroup": return 1;
                case "command": return 1;
                case "datalist": return 1;
                case "dd": return 1;
                case "del": return 1;
                case "details": return 1;
                case "dfn": return 1;
                case "dialog": return 1;
                case "dir": return 1;
                case "div": return 1;
                case "dl": return 1;
                case "dt": return 1;
                case "em": return 1;
                case "embed": return 1;
                case "fieldset": return 1;
                case "figcaption": return 1;
                case "figure": return 1;
                case "font": return 1;
                case "footer": return 1;
                case "form": return 1;
                case "frame": return 1;
                case "frameset": return 1;
                case "h1": return 1;
                case "h2": return 1;
                case "h3": return 1;
                case "h4": return 1;
                case "h5": return 1;
                case "h6": return 1;
                case "head": return 1;
                case "header": return 1;
                case "hgroup": return 1;
                case "hr": return 1;
                case "html": return 1;
                case "i": return 1;
                case "iframe": return 1;
                case "img": return 1;
                case "input": return 1;
                case "ins": return 1;
                case "isindex": return 1;
                case "kbd": return 1;
                case "keygen": return 1;
                case "label": return 1;
                case "legend": return 1;
                case "li": return 1;
                case "link": return 1;
                case "listing": return 1;
                case "main": return 1;
                case "map": return 1;
                case "mark": return 1;
                case "marquee": return 1;
                case "menu": return 1;
                case "menuitem": return 1;
                case "meta": return 1;
                case "meter": return 1;
                case "nav": return 1;
                case "nobr": return 1;
                case "noframes": return 1;
                case "noscript": return 1;
                case "object": return 1;
                case "ol": return 1;
                case "optgroup": return 1;
                case "option": return 1;
                case "output": return 1;
                case "p": return 1;
                case "param": return 1;
                case "picture": return 1;
                case "plaintext": return 1;
                case "pre": return 1;
                case "progress": return 1;
                case "q": return 1;
                case "rp": return 1;
                case "rt": return 1;
                case "ruby": return 1;
                case "s": return 1;
                case "samp": return 1;
                case "script": return 1;
                case "section": return 1;
                case "select": return 1;
                case "small": return 1;
                case "source": return 1;
                case "span": return 1;
                case "strike": return 1;
                case "strong": return 1;
                case "style": return 1;
                case "sub": return 1;
                case "summary": return 1;
                case "sup": return 1;
                case "table": return 1;
                case "tbody": return 1;
                case "td": return 1;
                case "template": return 1;
                case "textarea": return 1;
                case "tfoot": return 1;
                case "th": return 1;
                case "thead": return 1;
                case "time": return 1;
                case "title": return 1;
                case "tr": return 1;
                case "track": return 1;
                case "tt": return 1;
                case "u": return 1;
                case "ul": return 1;
                case "var": return 1;
                case "video": return 1;
                case "wbr": return 1;
                case "xmp": return 1;
                default: return 0;
            }
        }
    }
}