namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class ObjectName
    {
        public ObjectName(string name)
        {
            // Constructor for ObjectName
        }
    }

    public abstract class Number
    {
        // Base class for numeric types
    }

    public class GaugeMonitor
    {
        private bool differenceMode;
        private bool notifyHigh;
        private bool notifyLow;
        private Number highThreshold;
        private Number lowThreshold;
        private Dictionary<ObjectName, Number> derivedGauges = new Dictionary<ObjectName, Number>();
        private Dictionary<ObjectName, long> derivedGaugeTimeStamps = new Dictionary<ObjectName, long>();
        private long derivedGaugeTimeStamp;
        private Number derivedGauge;

        public bool GetDifferenceMode()
        {
            return differenceMode;
        }

        public void SetDifferenceMode(bool value)
        {
            differenceMode = value;
        }

        public string[] GetNotificationInfo()
        {
            return new string[] { };
        }

        public Number GetDerivedGauge()
        {
            return derivedGauge;
        }

        public Number GetDerivedGauge(ObjectName objectName)
        {
            if (derivedGauges.ContainsKey(objectName))
            {
                return derivedGauges[objectName];
            }
            return null;
        }

        public long GetDerivedGaugeTimeStamp()
        {
            return derivedGaugeTimeStamp;
        }

        public long GetDerivedGaugeTimeStamp(ObjectName objectName)
        {
            if (derivedGaugeTimeStamps.ContainsKey(objectName))
            {
                return derivedGaugeTimeStamps[objectName];
            }
            return 0;
        }

        public Number GetHighThreshold()
        {
            return highThreshold;
        }

        public Number GetLowThreshold()
        {
            return lowThreshold;
        }

        public void SetThresholds(Number highValue, Number lowValue)
        {
            highThreshold = highValue;
            lowThreshold = lowValue;
        }

        public bool GetNotifyHigh()
        {
            return notifyHigh;
        }

        public void SetNotifyHigh(bool value)
        {
            notifyHigh = value;
        }

        public bool GetNotifyLow()
        {
            return notifyLow;
        }

        public void SetNotifyLow(bool value)
        {
            notifyLow = value;
        }

        public void Start()
        {
            // Start monitoring
        }

        public void Stop()
        {
            // Stop monitoring
        }
    }

    public class javax_management_monitor_GaugeMonitorAutoTest
    {
        public void getDifferenceMode_test_5084()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetDifferenceMode();
        }

        public void setDifferenceMode_test_5085(bool p0)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.SetDifferenceMode(p0);
        }

        public void getNotificationInfo_test_5086()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetNotificationInfo();
        }

        public void getDerivedGauge_test_5087()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetDerivedGauge();
        }

        public void getDerivedGauge_test_5088(ObjectName p0)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetDerivedGauge(p0);
        }

        public void getDerivedGaugeTimeStamp_test_5089()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetDerivedGaugeTimeStamp();
        }

        public void getDerivedGaugeTimeStamp_test_5090(ObjectName p0)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetDerivedGaugeTimeStamp(p0);
        }

        public void getHighThreshold_test_5091()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetHighThreshold();
        }

        public void getLowThreshold_test_5092()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetLowThreshold();
        }

        public void setThresholds_test_5093(Number p0, Number p1)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.SetThresholds(p0, p1);
        }

        public void getNotifyHigh_test_5094()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetNotifyHigh();
        }

        public void setNotifyHigh_test_5095(bool p0)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.SetNotifyHigh(p0);
        }

        public void getNotifyLow_test_5096()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.GetNotifyLow();
        }

        public void setNotifyLow_test_5097(bool p0)
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.SetNotifyLow(p0);
        }

        public void start_test_5098()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.Start();
        }

        public void stop_test_5099()
        {
            GaugeMonitor instance = new GaugeMonitor();
            instance.Stop();
        }
    }
}