namespace Generated.Test
{
    using System.Security.Cryptography.X509Certificates;

    public class java_security_cert_CertPathBuilderAutoTest
    {
        public void getDefaultType_test_2099()
        {
            CertPathBuilder.GetDefaultType();
        }
    }

    public static class CertPathBuilder
    {
        public static string GetDefaultType()
        {
            return "PKIX";
        }
    }
}