using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class ZoneRules
    {
        public static ZoneRules Of(ZoneOffset p0, ZoneOffset p1, List<ZoneOffsetTransition> p2, List<ZoneOffsetTransition> p3, List<ZoneOffsetTransitionRule> p4)
        {
            return new ZoneRules();
        }

        public static ZoneRules Of(ZoneOffset p0)
        {
            return new ZoneRules();
        }
    }

    public class ZoneOffset
    {
        // Simplified representation of ZoneOffset
        public static ZoneOffset UTC = new ZoneOffset(0);
        private int totalSeconds;

        public ZoneOffset(int totalSeconds)
        {
            this.totalSeconds = totalSeconds;
        }

        public int GetTotalSeconds()
        {
            return totalSeconds;
        }
    }

    public class ZoneOffsetTransition
    {
        // Simplified representation
    }

    public class ZoneOffsetTransitionRule
    {
        // Simplified representation
    }

    public class java_time_zone_ZoneRulesAutoTest
    {
        public void of_test_13736(ZoneOffset p0, ZoneOffset p1, List<ZoneOffsetTransition> p2, List<ZoneOffsetTransition> p3, List<ZoneOffsetTransitionRule> p4)
        {
            ZoneRules.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_13737(ZoneOffset p0)
        {
            ZoneRules.Of(p0);
        }
    }
}