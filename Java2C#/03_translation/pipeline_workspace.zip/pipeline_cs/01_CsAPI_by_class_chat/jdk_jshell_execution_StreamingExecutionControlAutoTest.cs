using System;
using System.IO;

namespace Generated.Test
{
    public class StreamingExecutionControl : IDisposable
    {
        private ObjectOutput _out;
        private ObjectInput _in;
        private bool _closed;

        public StreamingExecutionControl(ObjectOutput out, ObjectInput input)
        {
            _out = out;
            _in = input;
            _closed = false;
        }

        public void close()
        {
            if (_closed)
                return;
            _closed = true;
            try
            {
                _out?.close();
            }
            finally
            {
                _in?.close();
            }
        }

        public void Dispose()
        {
            close();
        }
    }

    public abstract class ObjectOutput
    {
        public abstract void close();
    }

    public abstract class ObjectInput
    {
        public abstract void close();
    }

    public class jdk_jshell_execution_StreamingExecutionControlAutoTest
    {
        public void close_test_11512(ObjectOutput c0, ObjectInput c1)
        {
            StreamingExecutionControl instance = new StreamingExecutionControl(c0, c1);
            instance.close();
        }
    }
}