namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class Logger
    {
        public string Name { get; set; }
        public Level Level { get; set; }

        public Logger(string name)
        {
            Name = name;
            Level = Level.INFO;
        }

        public static Logger GetLogger(string name)
        {
            return new Logger(name);
        }
    }

    public class Level
    {
        public static readonly Level OFF = new Level("OFF", int.MaxValue);
        public static readonly Level SEVERE = new Level("SEVERE", 1000);
        public static readonly Level WARNING = new Level("WARNING", 900);
        public static readonly Level INFO = new Level("INFO", 800);
        public static readonly Level CONFIG = new Level("CONFIG", 700);
        public static readonly Level FINE = new Level("FINE", 500);
        public static readonly Level FINER = new Level("FINER", 400);
        public static readonly Level FINEST = new Level("FINEST", 300);
        public static readonly Level ALL = new Level("ALL", int.MinValue);

        public string Name { get; }
        public int Value { get; }

        private Level(string name, int value)
        {
            Name = name;
            Value = value;
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public class SyncFactory
    {
        private static SyncFactory _instance;
        private static Logger _logger;
        private static Level _level;
        private static readonly Dictionary<string, object> _syncProviders = new Dictionary<string, object>();

        private SyncFactory()
        {
        }

        public static SyncFactory GetSyncFactory()
        {
            if (_instance == null)
            {
                _instance = new SyncFactory();
            }
            return _instance;
        }

        public static void SetLogger(Logger logger)
        {
            _logger = logger;
        }

        public static void SetLogger(Logger logger, Level level)
        {
            _logger = logger;
            _level = level;
        }
    }

    public class javax_sql_rowset_spi_SyncFactoryAutoTest
    {
        public void getSyncFactory_test_12123()
        {
            SyncFactory.GetSyncFactory();
        }

        public void setLogger_test_12124(Logger p0)
        {
            SyncFactory.SetLogger(p0);
        }

        public void setLogger_test_12125(Logger p0, Level p1)
        {
            SyncFactory.SetLogger(p0, p1);
        }
    }
}