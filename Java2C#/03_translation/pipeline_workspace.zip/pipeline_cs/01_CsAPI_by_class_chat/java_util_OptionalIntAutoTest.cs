namespace Generated.Test
{
    using System;

    public class OptionalInt
    {
        private readonly bool _hasValue;
        private readonly int _value;

        private OptionalInt(bool hasValue, int value)
        {
            _hasValue = hasValue;
            _value = value;
        }

        public static OptionalInt Of(int value)
        {
            return new OptionalInt(true, value);
        }

        public static OptionalInt Empty()
        {
            return new OptionalInt(false, 0);
        }

        public bool IsPresent
        {
            get { return _hasValue; }
        }

        public int GetAsInt()
        {
            if (!_hasValue)
            {
                throw new InvalidOperationException("No value present");
            }
            return _value;
        }

        public int OrElse(int other)
        {
            return _hasValue ? _value : other;
        }

        public override bool Equals(object obj)
        {
            if (obj is OptionalInt other)
            {
                if (_hasValue != other._hasValue)
                {
                    return false;
                }
                return !_hasValue || _value == other._value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _hasValue ? _value.GetHashCode() : 0;
        }

        public override string ToString()
        {
            return _hasValue ? $"OptionalInt[{_value}]" : "OptionalInt.empty";
        }
    }

    public class java_util_OptionalIntAutoTest
    {
        public void of_test_9694(int p0)
        {
            OptionalInt.Of(p0);
        }

        public void empty_test_9695()
        {
            OptionalInt.Empty();
        }
    }
}