using System;
using System.Threading;

namespace Generated.Test
{
    public class java_lang_invoke_VarHandleAutoTest
    {
        public void storeStoreFence_test_13309()
        {
            VarHandle.storeStoreFence();
        }

        public void fullFence_test_13310()
        {
            VarHandle.fullFence();
        }

        public void loadLoadFence_test_13311()
        {
            VarHandle.loadLoadFence();
        }

        public void acquireFence_test_13312()
        {
            VarHandle.acquireFence();
        }

        public void releaseFence_test_13313()
        {
            VarHandle.releaseFence();
        }
    }

    public static class VarHandle
    {
        public static void storeStoreFence()
        {
            Thread.MemoryBarrier();
        }

        public static void fullFence()
        {
            Thread.MemoryBarrier();
        }

        public static void loadLoadFence()
        {
            Thread.MemoryBarrier();
        }

        public static void acquireFence()
        {
            Thread.MemoryBarrier();
        }

        public static void releaseFence()
        {
            Thread.MemoryBarrier();
        }
    }
}