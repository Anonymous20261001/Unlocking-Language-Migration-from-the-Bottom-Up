namespace Generated.Test
{
    public class java_awt_GraphicsEnvironmentAutoTest
    {
        public void isHeadless_test_5148()
        {
            GraphicsEnvironment.IsHeadless();
        }

        public void getLocalGraphicsEnvironment_test_5149()
        {
            GraphicsEnvironment.GetLocalGraphicsEnvironment();
        }
    }

    public static class GraphicsEnvironment
    {
        public static bool IsHeadless()
        {
            return true;
        }

        public static object GetLocalGraphicsEnvironment()
        {
            return new object();
        }
    }
}