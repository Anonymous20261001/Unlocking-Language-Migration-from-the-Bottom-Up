namespace Generated.Test
{
    public class java_awt_MouseInfoAutoTest
    {
        public void getNumberOfButtons_test_9025()
        {
            MouseInfo.GetNumberOfButtons();
        }

        public void getPointerInfo_test_9026()
        {
            MouseInfo.GetPointerInfo();
        }
    }

    public static class MouseInfo
    {
        public static int GetNumberOfButtons()
        {
            // Simulate Java's MouseInfo.getNumberOfButtons()
            // In .NET, we can use System.Windows.Forms.SystemInformation.MouseButtons
            return System.Windows.Forms.SystemInformation.MouseButtons;
        }

        public static object GetPointerInfo()
        {
            // Simulate Java's MouseInfo.getPointerInfo()
            // In .NET, we can use System.Windows.Forms.Cursor.Position
            var position = System.Windows.Forms.Cursor.Position;
            return new PointerInfo(position.X, position.Y);
        }
    }

    public class PointerInfo
    {
        public int X { get; }
        public int Y { get; }

        public PointerInfo(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}