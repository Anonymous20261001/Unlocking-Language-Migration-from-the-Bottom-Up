using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_lang_ModuleLayerAutoTest
    {
        public void empty_test_8996()
        {
            ModuleLayer.Empty();
        }

        public void boot_test_8997()
        {
            ModuleLayer.Boot();
        }

        public void defineModules_test_8998(Configuration p0, List<object> p1, Func<object, object> p2)
        {
            ModuleLayer.DefineModules(p0, p1, p2);
        }

        public void defineModulesWithOneLoader_test_8999(Configuration p0, List<object> p1, ClassLoader p2)
        {
            ModuleLayer.DefineModulesWithOneLoader(p0, p1, p2);
        }

        public void defineModulesWithManyLoaders_test_9000(Configuration p0, List<object> p1, ClassLoader p2)
        {
            ModuleLayer.DefineModulesWithManyLoaders(p0, p1, p2);
        }
    }

    public class ModuleLayer
    {
        public static ModuleLayer Empty()
        {
            return new ModuleLayer();
        }

        public static ModuleLayer Boot()
        {
            return new ModuleLayer();
        }

        public static ModuleLayer DefineModules(Configuration configuration, List<object> list, Func<object, object> function)
        {
            return new ModuleLayer();
        }

        public static ModuleLayer DefineModulesWithOneLoader(Configuration configuration, List<object> list, ClassLoader classLoader)
        {
            return new ModuleLayer();
        }

        public static ModuleLayer DefineModulesWithManyLoaders(Configuration configuration, List<object> list, ClassLoader classLoader)
        {
            return new ModuleLayer();
        }
    }

    public class Configuration
    {
    }

    public class ClassLoader
    {
    }
}