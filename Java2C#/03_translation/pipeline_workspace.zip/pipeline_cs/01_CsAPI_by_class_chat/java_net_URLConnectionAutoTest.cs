namespace Generated.Test
{
    public class java_net_URLConnectionAutoTest
    {
        public void getDefaultUseCaches_test_13255(string p0)
        {
            URLConnection.GetDefaultUseCaches(p0);
        }

        public void getFileNameMap_test_13256()
        {
            URLConnection.GetFileNameMap();
        }

        public void setFileNameMap_test_13257(FileNameMap p0)
        {
            URLConnection.SetFileNameMap(p0);
        }

        public void setDefaultAllowUserInteraction_test_13258(bool p0)
        {
            URLConnection.SetDefaultAllowUserInteraction(p0);
        }

        public void getDefaultAllowUserInteraction_test_13259()
        {
            URLConnection.GetDefaultAllowUserInteraction();
        }

        public void setDefaultUseCaches_test_13260(string p0, bool p1)
        {
            URLConnection.SetDefaultUseCaches(p0, p1);
        }

        public void setDefaultRequestProperty_test_13261(string p0, string p1)
        {
            URLConnection.SetDefaultRequestProperty(p0, p1);
        }

        public void getDefaultRequestProperty_test_13262(string p0)
        {
            URLConnection.GetDefaultRequestProperty(p0);
        }

        public void setContentHandlerFactory_test_13263(ContentHandlerFactory p0)
        {
            URLConnection.SetContentHandlerFactory(p0);
        }

        public void guessContentTypeFromName_test_13264(string p0)
        {
            URLConnection.GuessContentTypeFromName(p0);
        }
    }

    public class URLConnection
    {
        public static bool GetDefaultUseCaches(string protocol)
        {
            return false;
        }

        public static FileNameMap GetFileNameMap()
        {
            return null;
        }

        public static void SetFileNameMap(FileNameMap map)
        {
        }

        public static void SetDefaultAllowUserInteraction(bool defaultAllowUserInteraction)
        {
        }

        public static bool GetDefaultAllowUserInteraction()
        {
            return false;
        }

        public static void SetDefaultUseCaches(string protocol, bool defaultUseCaches)
        {
        }

        public static void SetDefaultRequestProperty(string key, string value)
        {
        }

        public static string GetDefaultRequestProperty(string key)
        {
            return null;
        }

        public static void SetContentHandlerFactory(ContentHandlerFactory contentHandlerFactory)
        {
        }

        public static string GuessContentTypeFromName(string fname)
        {
            return null;
        }
    }

    public class FileNameMap
    {
    }

    public class ContentHandlerFactory
    {
    }
}