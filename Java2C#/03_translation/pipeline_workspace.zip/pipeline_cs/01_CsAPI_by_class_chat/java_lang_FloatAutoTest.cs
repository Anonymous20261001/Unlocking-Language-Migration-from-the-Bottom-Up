using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_lang_FloatAutoTest
    {
        public void min_test_4825(float p0, float p1)
        {
            MathF.Min(p0, p1);
        }

        public void max_test_4826(float p0, float p1)
        {
            MathF.Max(p0, p1);
        }

        public void isInfinite_test_4827(float p0)
        {
            float.IsInfinity(p0);
        }

        public void isInfinite_test_4828(string c0)
        {
            Float instance = new Float(c0);
            instance.isInfinite();
        }

        public void isFinite_test_4829(float p0)
        {
            float.IsFinite(p0);
        }

        public void floatToRawIntBits_test_4830(float p0)
        {
            Float.floatToRawIntBits(p0);
        }

        public void floatToIntBits_test_4831(float p0)
        {
            Float.floatToIntBits(p0);
        }

        public void intBitsToFloat_test_4832(int p0)
        {
            Float.intBitsToFloat(p0);
        }

        public void float16ToFloat_test_4833(short p0)
        {
            Float.float16ToFloat(p0);
        }

        public void floatToFloat16_test_4834(float p0)
        {
            Float.floatToFloat16(p0);
        }

        public void compareTo_test_4835(Float p0, string c0)
        {
            Float instance = new Float(c0);
            instance.compareTo(p0);
        }

        public void compare_test_4836(float p0, float p1)
        {
            Float.compare(p0, p1);
        }

        public void byteValue_test_4837(string c0)
        {
            Float instance = new Float(c0);
            instance.byteValue();
        }

        public void shortValue_test_4838(string c0)
        {
            Float instance = new Float(c0);
            instance.shortValue();
        }

        public void intValue_test_4839(string c0)
        {
            Float instance = new Float(c0);
            instance.intValue();
        }

        public void longValue_test_4840(string c0)
        {
            Float instance = new Float(c0);
            instance.longValue();
        }

        public void floatValue_test_4841(string c0)
        {
            Float instance = new Float(c0);
            instance.floatValue();
        }

        public void doubleValue_test_4842(string c0)
        {
            Float instance = new Float(c0);
            instance.doubleValue();
        }

        public void valueOf_test_4843(float p0)
        {
            Float.valueOf(p0);
        }

        public void valueOf_test_4844(string p0)
        {
            Float.valueOf(p0);
        }

        public void toHexString_test_4845(float p0)
        {
            Float.toHexString(p0);
        }

        public void resolveConstantDesc_test_4846(MethodHandles.Lookup p0, string c0)
        {
            Float instance = new Float(c0);
            instance.resolveConstantDesc(p0);
        }

        public void describeConstable_test_4847(string c0)
        {
            Float instance = new Float(c0);
            instance.describeConstable();
        }

        public void isNaN_test_4848(float p0)
        {
            float.IsNaN(p0);
        }

        public void isNaN_test_4849(string c0)
        {
            Float instance = new Float(c0);
            instance.isNaN();
        }

        public void sum_test_4850(float p0, float p1)
        {
            Float.sum(p0, p1);
        }

        public void parseFloat_test_4851(string p0)
        {
            Float.parseFloat(p0);
        }
    }

    public class Float
    {
        private float value;

        public Float(string s)
        {
            value = float.Parse(s, CultureInfo.InvariantCulture);
        }

        public Float(float v)
        {
            value = v;
        }

        public static float min(float a, float b)
        {
            return MathF.Min(a, b);
        }

        public static float max(float a, float b)
        {
            return MathF.Max(a, b);
        }

        public static bool isInfinite(float v)
        {
            return float.IsInfinity(v);
        }

        public bool isInfinite()
        {
            return float.IsInfinity(value);
        }

        public static bool isFinite(float v)
        {
            return float.IsFinite(v);
        }

        public static int floatToRawIntBits(float v)
        {
            byte[] bytes = BitConverter.GetBytes(v);
            return BitConverter.ToInt32(bytes, 0);
        }

        public static int floatToIntBits(float v)
        {
            if (float.IsNaN(v))
                return 0x7fc00000;
            return floatToRawIntBits(v);
        }

        public static float intBitsToFloat(int bits)
        {
            byte[] bytes = BitConverter.GetBytes(bits);
            return BitConverter.ToSingle(bytes, 0);
        }

        public static float float16ToFloat(short half)
        {
            int sign = (half >> 15) & 0x1;
            int exponent = (half >> 10) & 0x1f;
            int mantissa = half & 0x3ff;

            int fbits;
            if (exponent == 0)
            {
                if (mantissa == 0)
                {
                    fbits = sign << 31;
                }
                else
                {
                    // Subnormal
                    exponent = 127 - 15 + 1;
                    while ((mantissa & 0x400) == 0)
                    {
                        mantissa <<= 1;
                        exponent--;
                    }
                    mantissa &= 0x3ff;
                    fbits = (sign << 31) | (exponent << 23) | (mantissa << 13);
                }
            }
            else if (exponent == 0x1f)
            {
                fbits = (sign << 31) | (0xff << 23) | (mantissa << 13);
            }
            else
            {
                fbits = (sign << 31) | ((exponent - 15 + 127) << 23) | (mantissa << 13);
            }

            return intBitsToFloat(fbits);
        }

        public static short floatToFloat16(float f)
        {
            int bits = floatToRawIntBits(f);
            int sign = (bits >> 31) & 0x1;
            int exponent = (bits >> 23) & 0xff;
            int mantissa = bits & 0x7fffff;

            int half;
            if (exponent == 0xff)
            {
                // NaN or Infinity
                half = (sign << 15) | (0x1f << 10) | (mantissa != 0 ? 0x200 : 0);
            }
            else
            {
                int newExp = exponent - 127 + 15;
                if (newExp >= 0x1f)
                {
                    // Overflow to infinity
                    half = (sign << 15) | (0x1f << 10);
                }
                else if (newExp <= 0)
                {
                    // Subnormal or zero
                    if (newExp < -10)
                    {
                        half = sign << 15;
                    }
                    else
                    {
                        mantissa |= 0x800000;
                        int shift = 14 - newExp;
                        half = (sign << 15) | (mantissa >> shift);
                    }
                }
                else
                {
                    half = (sign << 15) | (newExp << 10) | (mantissa >> 13);
                }
            }

            return (short)half;
        }

        public int compareTo(Float other)
        {
            return compare(value, other.value);
        }

        public static int compare(float f1, float f2)
        {
            if (f1 < f2) return -1;
            if (f1 > f2) return 1;
            if (f1 == f2) return 0;

            // Handle NaN
            if (float.IsNaN(f1))
            {
                if (float.IsNaN(f2)) return 0;
                return 1;
            }
            if (float.IsNaN(f2)) return -1;

            // Handle -0.0 and +0.0
            if (f1 == 0.0f && f2 == 0.0f)
            {
                if (float.IsNegative(f1) && !float.IsNegative(f2)) return -1;
                if (!float.IsNegative(f1) && float.IsNegative(f2)) return 1;
            }

            return 0;
        }

        public byte byteValue()
        {
            return (byte)value;
        }

        public short shortValue()
        {
            return (short)value;
        }

        public int intValue()
        {
            return (int)value;
        }

        public long longValue()
        {
            return (long)value;
        }

        public float floatValue()
        {
            return value;
        }

        public double doubleValue()
        {
            return (double)value;
        }

        public static Float valueOf(float v)
        {
            return new Float(v);
        }

        public static Float valueOf(string s)
        {
            return new Float(s);
        }

        public static string toHexString(float v)
        {
            if (float.IsNaN(v)) return "NaN";
            if (float.IsPositiveInfinity(v)) return "Infinity";
            if (float.IsNegativeInfinity(v)) return "-Infinity";
            if (v == 0.0f)
            {
                return float.IsNegative(v) ? "-0x0.0p0" : "0x0.0p0";
            }

            int bits = floatToRawIntBits(v);
            int sign = (bits >> 31) & 0x1;
            int exponent = (bits >> 23) & 0xff;
            int mantissa = bits & 0x7fffff;

            string signStr = sign == 1 ? "-" : "";
            if (exponent == 0)
            {
                // Subnormal
                return signStr + "0x0." + mantissa.ToString("x6") + "p-126";
            }
            else
            {
                int exp = exponent - 127;
                return signStr + "0x1." + mantissa.ToString("x6") + "p" + exp;
            }
        }

        public object resolveConstantDesc(MethodHandles.Lookup lookup)
        {
            return value;
        }

        public object describeConstable()
        {
            return value;
        }

        public bool isNaN()
        {
            return float.IsNaN(value);
        }

        public static bool isNaN(float v)
        {
            return float.IsNaN(v);
        }

        public static float sum(float a, float b)
        {
            return a + b;
        }

        public static float parseFloat(string s)
        {
            return float.Parse(s, CultureInfo.InvariantCulture);
        }
    }

    public class MethodHandles
    {
        public class Lookup
        {
        }
    }
}