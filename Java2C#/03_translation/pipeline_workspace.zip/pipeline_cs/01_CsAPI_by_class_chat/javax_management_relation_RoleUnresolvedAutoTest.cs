namespace Generated.Test
{
    using System.Collections.Generic;

    public class RoleUnresolved
    {
        private string roleName;
        private List<object> roleValue;
        private int problemType;

        public RoleUnresolved(string roleName, List<object> roleValue, int problemType)
        {
            this.roleName = roleName;
            this.roleValue = roleValue;
            this.problemType = problemType;
        }

        public void SetRoleName(string roleName)
        {
            this.roleName = roleName;
        }

        public void SetRoleValue(List<object> roleValue)
        {
            this.roleValue = roleValue;
        }

        public void SetProblemType(int problemType)
        {
            this.problemType = problemType;
        }

        public int GetProblemType()
        {
            return this.problemType;
        }

        public string GetRoleName()
        {
            return this.roleName;
        }

        public List<object> GetRoleValue()
        {
            return this.roleValue;
        }
    }

    public class javax_management_relation_RoleUnresolvedAutoTest
    {
        public void setRoleName_test_10670(string p0, string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.SetRoleName(p0);
        }

        public void setRoleValue_test_10671(List<object> p0, string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.SetRoleValue(p0);
        }

        public void setProblemType_test_10672(int p0, string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.SetProblemType(p0);
        }

        public void getProblemType_test_10673(string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.GetProblemType();
        }

        public void getRoleName_test_10674(string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.GetRoleName();
        }

        public void getRoleValue_test_10675(string c0, List<object> c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.GetRoleValue();
        }
    }
}