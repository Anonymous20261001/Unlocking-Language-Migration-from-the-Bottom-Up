using System;
using System.Text.RegularExpressions;

namespace Generated.Test
{
    public class java_util_regex_MatcherAutoTest
    {
        public void quoteReplacement_test_8295(string p0)
        {
            Regex.Escape(p0);
        }
    }
}