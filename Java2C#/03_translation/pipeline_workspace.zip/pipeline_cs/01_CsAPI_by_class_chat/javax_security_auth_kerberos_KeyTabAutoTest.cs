using System;
using System.IO;

namespace Generated.Test
{
    public class KerberosPrincipal
    {
        public KerberosPrincipal(string name)
        {
            Name = name;
        }

        public string Name { get; }
    }

    public class KeyTab
    {
        private readonly string _filePath;
        private readonly KerberosPrincipal _principal;

        private KeyTab(string filePath, KerberosPrincipal principal)
        {
            _filePath = filePath;
            _principal = principal;
        }

        public static KeyTab GetInstance(KerberosPrincipal principal)
        {
            return new KeyTab(null, principal);
        }

        public static KeyTab GetInstance(File file)
        {
            return new KeyTab(file?.Path, null);
        }

        public static KeyTab GetInstance()
        {
            return new KeyTab(null, null);
        }

        public static KeyTab GetInstance(KerberosPrincipal principal, File file)
        {
            return new KeyTab(file?.Path, principal);
        }

        public static KeyTab GetUnboundInstance()
        {
            return new KeyTab(null, null);
        }

        public static KeyTab GetUnboundInstance(File file)
        {
            return new KeyTab(file?.Path, null);
        }
    }

    public class File
    {
        public string Path { get; }

        public File(string path)
        {
            Path = path;
        }
    }

    public class javax_security_auth_kerberos_KeyTabAutoTest
    {
        public void getInstance_test_7662(KerberosPrincipal p0)
        {
            KeyTab.GetInstance(p0);
        }

        public void getInstance_test_7663(File p0)
        {
            KeyTab.GetInstance(p0);
        }

        public void getInstance_test_7664()
        {
            KeyTab.GetInstance();
        }

        public void getInstance_test_7665(KerberosPrincipal p0, File p1)
        {
            KeyTab.GetInstance(p0, p1);
        }

        public void getUnboundInstance_test_7666()
        {
            KeyTab.GetUnboundInstance();
        }

        public void getUnboundInstance_test_7667(File p0)
        {
            KeyTab.GetUnboundInstance(p0);
        }
    }
}