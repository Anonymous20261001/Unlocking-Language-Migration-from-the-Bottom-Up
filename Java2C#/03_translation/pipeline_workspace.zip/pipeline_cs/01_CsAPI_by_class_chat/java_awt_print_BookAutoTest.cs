namespace Generated.Test
{
    public class Book
    {
        private System.Collections.Generic.List<Printable> printables = new System.Collections.Generic.List<Printable>();
        private System.Collections.Generic.List<PageFormat> pageFormats = new System.Collections.Generic.List<PageFormat>();
        private System.Collections.Generic.List<int> pageCounts = new System.Collections.Generic.List<int>();

        public Printable GetPrintable(int pageIndex)
        {
            if (pageIndex < 0 || pageIndex >= GetNumberOfPages())
            {
                throw new System.IndexOutOfRangeException("Invalid page index");
            }

            int currentPage = 0;
            for (int i = 0; i < printables.Count; i++)
            {
                if (pageIndex < currentPage + pageCounts[i])
                {
                    return printables[i];
                }
                currentPage += pageCounts[i];
            }
            return null;
        }

        public PageFormat GetPageFormat(int pageIndex)
        {
            if (pageIndex < 0 || pageIndex >= GetNumberOfPages())
            {
                throw new System.IndexOutOfRangeException("Invalid page index");
            }

            int currentPage = 0;
            for (int i = 0; i < pageFormats.Count; i++)
            {
                if (pageIndex < currentPage + pageCounts[i])
                {
                    return pageFormats[i];
                }
                currentPage += pageCounts[i];
            }
            return null;
        }

        public int GetNumberOfPages()
        {
            int total = 0;
            foreach (int count in pageCounts)
            {
                total += count;
            }
            return total;
        }

        public void SetPage(int pageIndex, Printable painter, PageFormat page)
        {
            if (pageIndex < 0 || pageIndex >= GetNumberOfPages())
            {
                throw new System.IndexOutOfRangeException("Invalid page index");
            }

            int currentPage = 0;
            for (int i = 0; i < pageCounts.Count; i++)
            {
                if (pageIndex < currentPage + pageCounts[i])
                {
                    printables[i] = painter;
                    pageFormats[i] = page;
                    return;
                }
                currentPage += pageCounts[i];
            }
        }

        public void Append(Printable painter, PageFormat page, int numPages)
        {
            if (numPages <= 0)
            {
                throw new System.ArgumentException("Number of pages must be positive");
            }

            printables.Add(painter);
            pageFormats.Add(page);
            pageCounts.Add(numPages);
        }

        public void Append(Printable painter, PageFormat page)
        {
            Append(painter, page, 1);
        }
    }

    public interface Printable
    {
        int Print(System.Drawing.Printing.PrintPageEventArgs e);
    }

    public class PageFormat
    {
        // Simplified PageFormat class for testing purposes
        public double Width { get; set; }
        public double Height { get; set; }
    }

    public class java_awt_print_BookAutoTest
    {
        public void getPrintable_test_1763(int p0)
        {
            Book instance = new Book();
            instance.GetPrintable(p0);
        }

        public void getPageFormat_test_1764(int p0)
        {
            Book instance = new Book();
            instance.GetPageFormat(p0);
        }

        public void getNumberOfPages_test_1765()
        {
            Book instance = new Book();
            instance.GetNumberOfPages();
        }

        public void setPage_test_1766(int p0, Printable p1, PageFormat p2)
        {
            Book instance = new Book();
            instance.SetPage(p0, p1, p2);
        }

        public void append_test_1767(Printable p0, PageFormat p1, int p2)
        {
            Book instance = new Book();
            instance.Append(p0, p1, p2);
        }

        public void append_test_1768(Printable p0, PageFormat p1)
        {
            Book instance = new Book();
            instance.Append(p0, p1);
        }
    }
}