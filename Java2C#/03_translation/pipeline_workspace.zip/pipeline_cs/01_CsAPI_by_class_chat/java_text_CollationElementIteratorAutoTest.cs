namespace Generated.Test
{
    public class java_text_CollationElementIteratorAutoTest
    {
        public void primaryOrder_test_2346(int p0)
        {
            CollationElementIterator.primaryOrder(p0);
        }

        public void secondaryOrder_test_2347(int p0)
        {
            CollationElementIterator.secondaryOrder(p0);
        }

        public void tertiaryOrder_test_2348(int p0)
        {
            CollationElementIterator.tertiaryOrder(p0);
        }
    }

    public class CollationElementIterator
    {
        public static int primaryOrder(int order)
        {
            // Java's primaryOrder returns the primary order component (bits 16-31)
            return (order >> 16) & 0xFFFF;
        }

        public static short secondaryOrder(int order)
        {
            // Java's secondaryOrder returns the secondary order component (bits 8-15)
            return (short)((order >> 8) & 0xFF);
        }

        public static short tertiaryOrder(int order)
        {
            // Java's tertiaryOrder returns the tertiary order component (bits 0-7)
            return (short)(order & 0xFF);
        }
    }
}