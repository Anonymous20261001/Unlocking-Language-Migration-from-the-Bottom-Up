using System;
using System.IO;

namespace Generated.Test
{
    public class LogStream
    {
        private static TextWriter defaultStream = Console.Error;
        private static int defaultLevel = 0;

        public static TextWriter GetDefaultStream()
        {
            return defaultStream;
        }

        public static void SetDefaultStream(TextWriter p0)
        {
            defaultStream = p0;
        }

        public static int ParseLevel(string p0)
        {
            if (p0 == null)
                return 0;
            switch (p0.ToLower())
            {
                case "silent":
                    return 0;
                case "brief":
                    return 1;
                case "verbose":
                    return 2;
                default:
                    return 0;
            }
        }

        public static void Log(string p0)
        {
            defaultStream.WriteLine(p0);
        }
    }

    public class java_rmi_server_LogStreamAutoTest
    {
        public void getDefaultStream_test_8139()
        {
            LogStream.GetDefaultStream();
        }

        public void setDefaultStream_test_8140(TextWriter p0)
        {
            LogStream.SetDefaultStream(p0);
        }

        public void parseLevel_test_8141(string p0)
        {
            LogStream.ParseLevel(p0);
        }

        public void log_test_8142(string p0)
        {
            LogStream.Log(p0);
        }
    }
}