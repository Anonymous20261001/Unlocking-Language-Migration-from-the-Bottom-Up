namespace Generated.Test
{
    public interface UndoableEdit
    {
        bool AddEdit(UndoableEdit anEdit);
        bool ReplaceEdit(UndoableEdit anEdit);
        bool IsSignificant();
        string GetPresentationName();
        string GetUndoPresentationName();
        string GetRedoPresentationName();
        void Undo();
        bool CanUndo();
        void Redo();
        bool CanRedo();
        void Die();
    }

    public abstract class AbstractUndoableEdit : UndoableEdit
    {
        protected bool hasBeenDone = true;
        protected bool alive = true;

        public virtual bool AddEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual bool ReplaceEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual bool IsSignificant()
        {
            return true;
        }

        public virtual string GetPresentationName()
        {
            return "";
        }

        public virtual string GetUndoPresentationName()
        {
            return "Undo " + GetPresentationName();
        }

        public virtual string GetRedoPresentationName()
        {
            return "Redo " + GetPresentationName();
        }

        public virtual void Undo()
        {
            if (!CanUndo())
            {
                throw new CannotUndoException();
            }
            hasBeenDone = false;
        }

        public virtual bool CanUndo()
        {
            return alive && hasBeenDone;
        }

        public virtual void Redo()
        {
            if (!CanRedo())
            {
                throw new CannotRedoException();
            }
            hasBeenDone = true;
        }

        public virtual bool CanRedo()
        {
            return alive && !hasBeenDone;
        }

        public virtual void Die()
        {
            alive = false;
        }
    }

    public class CannotUndoException : System.Exception
    {
        public CannotUndoException() : base() { }
        public CannotUndoException(string message) : base(message) { }
    }

    public class CannotRedoException : System.Exception
    {
        public CannotRedoException() : base() { }
        public CannotRedoException(string message) : base(message) { }
    }

    public class javax_swing_undo_AbstractUndoableEditAutoTest
    {
        public void addEdit_test_14(UndoableEdit p0)
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.AddEdit(p0);
        }

        public void redo_test_15()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.Redo();
        }

        public void undo_test_16()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.Undo();
        }

        public void getPresentationName_test_17()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.GetPresentationName();
        }

        public void isSignificant_test_18()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.IsSignificant();
        }

        public void getUndoPresentationName_test_19()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.GetUndoPresentationName();
        }

        public void getRedoPresentationName_test_20()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.GetRedoPresentationName();
        }

        public void die_test_21()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.Die();
        }

        public void replaceEdit_test_22(UndoableEdit p0)
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.ReplaceEdit(p0);
        }

        public void canUndo_test_23()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.CanUndo();
        }

        public void canRedo_test_24()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.CanRedo();
        }
    }
}