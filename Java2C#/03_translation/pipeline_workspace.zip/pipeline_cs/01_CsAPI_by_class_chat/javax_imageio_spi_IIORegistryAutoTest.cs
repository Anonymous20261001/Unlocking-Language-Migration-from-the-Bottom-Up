namespace Generated.Test
{
    public class javax_imageio_spi_IIORegistryAutoTest
    {
        public void getDefaultInstance_test_5617()
        {
            IIORegistry.GetDefaultInstance();
        }
    }

    public class IIORegistry
    {
        private static IIORegistry _defaultInstance;

        public static IIORegistry GetDefaultInstance()
        {
            if (_defaultInstance == null)
            {
                _defaultInstance = new IIORegistry();
            }
            return _defaultInstance;
        }
    }
}