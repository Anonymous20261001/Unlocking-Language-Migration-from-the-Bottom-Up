using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Minimal Component class to satisfy the test signatures
    public class Component
    {
        // No specific implementation needed for these tests
    }

    // DataFlavor equivalent
    public class DataFlavor
    {
        // No specific implementation needed for these tests
    }

    // Transferable interface
    public interface Transferable
    {
        // No specific implementation needed for these tests
    }

    // TransferHandler class with nested TransferSupport
    public class TransferHandler
    {
        public class TransferSupport
        {
            private Component component;
            private Transferable transferable;
            private bool isDrop;
            private int dropAction;
            private int sourceDropActions;
            private int userDropAction;
            private bool showDropLocation;
            private object dropLocation;

            public TransferSupport(Component component, Transferable transferable)
            {
                this.component = component;
                this.transferable = transferable;
                this.isDrop = false;
                this.dropAction = 0;
                this.sourceDropActions = 0;
                this.userDropAction = 0;
                this.showDropLocation = false;
                this.dropLocation = null;
            }

            public Transferable GetTransferable()
            {
                return transferable;
            }

            public DataFlavor[] GetDataFlavors()
            {
                // Return empty array as no data flavors are specified
                return new DataFlavor[0];
            }

            public object GetDropLocation()
            {
                return dropLocation;
            }

            public bool IsDrop()
            {
                return isDrop;
            }

            public int GetDropAction()
            {
                return dropAction;
            }

            public int GetSourceDropActions()
            {
                return sourceDropActions;
            }

            public int GetUserDropAction()
            {
                return userDropAction;
            }

            public void SetShowDropLocation(bool showDropLocation)
            {
                this.showDropLocation = showDropLocation;
            }

            public void SetDropAction(int dropAction)
            {
                this.dropAction = dropAction;
            }

            public bool IsDataFlavorSupported(DataFlavor flavor)
            {
                // Return false as no data flavors are supported
                return false;
            }

            public Component GetComponent()
            {
                return component;
            }
        }
    }

    public class javax_swing_TransferHandler_TransferSupportAutoTest
    {
        public void getTransferable_test_12948(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetTransferable();
        }

        public void getDataFlavors_test_12949(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetDataFlavors();
        }

        public void getDropLocation_test_12950(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetDropLocation();
        }

        public void isDrop_test_12951(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.IsDrop();
        }

        public void getDropAction_test_12952(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetDropAction();
        }

        public void getSourceDropActions_test_12953(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetSourceDropActions();
        }

        public void getUserDropAction_test_12954(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetUserDropAction();
        }

        public void setShowDropLocation_test_12955(bool p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.SetShowDropLocation(p0);
        }

        public void setDropAction_test_12956(int p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.SetDropAction(p0);
        }

        public void isDataFlavorSupported_test_12957(DataFlavor p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.IsDataFlavorSupported(p0);
        }

        public void getComponent_test_12958(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.GetComponent();
        }
    }
}