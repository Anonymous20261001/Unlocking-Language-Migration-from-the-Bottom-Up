namespace Generated.Test
{
    public class javax_management_relation_RelationServiceAutoTest
    {
        public void getNotificationInfo_test_10508(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getNotificationInfo();
        }

        public void postRegister_test_10509(bool? p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.postRegister(p0);
        }

        public void postDeregister_test_10510(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.postDeregister();
        }

        public void handleNotification_test_10511(Notification p0, object p1, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.handleNotification(p0, p1);
        }

        public void getAllRelationTypeNames_test_10512(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getAllRelationTypeNames();
        }

        public void isRelation_test_10513(ObjectName p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.isRelation(p0);
        }

        public void hasRelation_test_10514(string p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.hasRelation(p0);
        }

        public void getAllRelationIds_test_10515(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getAllRelationIds();
        }

        public void findAssociatedMBeans_test_10516(ObjectName p0, string p1, string p2, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.findAssociatedMBeans(p0, p1, p2);
        }

        public void setPurgeFlag_test_10517(bool p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.setPurgeFlag(p0);
        }

        public void findReferencingRelations_test_10518(ObjectName p0, string p1, string p2, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.findReferencingRelations(p0, p1, p2);
        }

        public void getPurgeFlag_test_10519(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getPurgeFlag();
        }
    }

    public class RelationService
    {
        private bool _purgeFlag;

        public RelationService(bool purgeFlag)
        {
            _purgeFlag = purgeFlag;
        }

        public object getNotificationInfo()
        {
            return null;
        }

        public void postRegister(bool? p0)
        {
        }

        public void postDeregister()
        {
        }

        public void handleNotification(Notification p0, object p1)
        {
        }

        public object getAllRelationTypeNames()
        {
            return null;
        }

        public bool isRelation(ObjectName p0)
        {
            return false;
        }

        public bool hasRelation(string p0)
        {
            return false;
        }

        public object getAllRelationIds()
        {
            return null;
        }

        public object findAssociatedMBeans(ObjectName p0, string p1, string p2)
        {
            return null;
        }

        public void setPurgeFlag(bool p0)
        {
            _purgeFlag = p0;
        }

        public object findReferencingRelations(ObjectName p0, string p1, string p2)
        {
            return null;
        }

        public bool getPurgeFlag()
        {
            return _purgeFlag;
        }
    }

    public class Notification
    {
    }

    public class ObjectName
    {
    }
}