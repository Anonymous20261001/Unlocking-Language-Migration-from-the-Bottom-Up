using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class MethodType
    {
        public static MethodType MethodType_0()
        {
            return new MethodType();
        }
    }

    public class MethodHandle
    {
    }

    public class VarHandle
    {
        public enum AccessMode
        {
            READ,
            WRITE,
            COMPARE_AND_SET,
            COMPARE_AND_EXCHANGE,
            COMPARE_AND_EXCHANGE_ACQUIRE,
            COMPARE_AND_EXCHANGE_RELEASE,
            GET,
            SET,
            GET_ACQUIRE,
            SET_RELEASE,
            GET_OPAQUE,
            SET_OPAQUE,
            GET_VOLATILE,
            SET_VOLATILE,
            GET_AND_ADD,
            GET_AND_ADD_ACQUIRE,
            GET_AND_ADD_RELEASE,
            GET_AND_BITWISE_OR,
            GET_AND_BITWISE_OR_ACQUIRE,
            GET_AND_BITWISE_OR_RELEASE,
            GET_AND_BITWISE_AND,
            GET_AND_BITWISE_AND_ACQUIRE,
            GET_AND_BITWISE_AND_RELEASE,
            GET_AND_BITWISE_XOR,
            GET_AND_BITWISE_XOR_ACQUIRE,
            GET_AND_BITWISE_XOR_RELEASE,
            GET_AND_SET,
            GET_AND_SET_ACQUIRE,
            GET_AND_SET_RELEASE
        }
    }

    public static class MethodHandles
    {
        public static MethodHandle throwException(Type p0, Type p1)
        {
            return new MethodHandle();
        }

        public static MethodHandles.Lookup lookup()
        {
            return new MethodHandles.Lookup();
        }

        public static MethodHandle empty(MethodType p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle constant(Type p0, object p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle identity(Type p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle spreadInvoker(MethodType p0, int p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayLength(Type p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle varHandleInvoker(VarHandle.AccessMode p0, MethodType p1)
        {
            return new MethodHandle();
        }

        public static MethodHandles.Lookup publicLookup()
        {
            return new MethodHandles.Lookup();
        }

        public static MethodHandle tryFinally(MethodHandle p0, MethodHandle p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle loop(MethodHandle[][] p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle tableSwitch(MethodHandle p0, MethodHandle[] p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayConstructor(Type p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle exactInvoker(MethodType p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle foldArguments(MethodHandle p0, MethodHandle p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle foldArguments(MethodHandle p0, int p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle invoker(MethodType p0)
        {
            return new MethodHandle();
        }

        public static object reflectAs(Type p0, MethodHandle p1)
        {
            return new object();
        }

        public static MethodHandle zero(Type p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArgumentsToMatch(MethodHandle p0, int p1, List<Type> p2, int p3)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArguments(MethodHandle p0, int p1, List<Type> p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArguments(MethodHandle p0, int p1, Type[] p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle countedLoop(MethodHandle p0, MethodHandle p1, MethodHandle p2, MethodHandle p3)
        {
            return new MethodHandle();
        }

        public static MethodHandle countedLoop(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle permuteArguments(MethodHandle p0, MethodType p1, int[] p2)
        {
            return new MethodHandle();
        }

        public static VarHandle filterValue(VarHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new VarHandle();
        }

        public static VarHandle filterCoordinates(VarHandle p0, int p1, MethodHandle[] p2)
        {
            return new VarHandle();
        }

        public static VarHandle insertCoordinates(VarHandle p0, int p1, object[] p2)
        {
            return new VarHandle();
        }

        public static VarHandle permuteCoordinates(VarHandle p0, List<Type> p1, int[] p2)
        {
            return new VarHandle();
        }

        public static VarHandle collectCoordinates(VarHandle p0, int p1, MethodHandle p2)
        {
            return new VarHandle();
        }

        public static VarHandle dropCoordinates(VarHandle p0, int p1, Type[] p2)
        {
            return new VarHandle();
        }

        public static MethodHandle arrayElementGetter(Type p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayElementSetter(Type p0)
        {
            return new MethodHandle();
        }

        public static VarHandle arrayElementVarHandle(Type p0)
        {
            return new VarHandle();
        }

        public static VarHandle byteArrayViewVarHandle(Type p0, ByteOrder p1)
        {
            return new VarHandle();
        }

        public static VarHandle byteBufferViewVarHandle(Type p0, ByteOrder p1)
        {
            return new VarHandle();
        }

        public static MethodHandle varHandleExactInvoker(VarHandle.AccessMode p0, MethodType p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle explicitCastArguments(MethodHandle p0, MethodType p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle insertArguments(MethodHandle p0, int p1, object[] p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropReturn(MethodHandle p0)
        {
            return new MethodHandle();
        }

        public static MethodHandle filterArguments(MethodHandle p0, int p1, MethodHandle[] p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle collectArguments(MethodHandle p0, int p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle filterReturnValue(MethodHandle p0, MethodHandle p1)
        {
            return new MethodHandle();
        }

        public static MethodHandle guardWithTest(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle catchException(MethodHandle p0, Type p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle whileLoop(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle doWhileLoop(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public static MethodHandle iteratedLoop(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            return new MethodHandle();
        }

        public class Lookup
        {
        }
    }

    public enum ByteOrder
    {
        BIG_ENDIAN,
        LITTLE_ENDIAN
    }

    public class java_lang_invoke_MethodHandlesAutoTest
    {
        public void throwException_test_8874(Type p0, Type p1)
        {
            MethodHandles.throwException(p0, p1);
        }

        public void lookup_test_8875()
        {
            MethodHandles.lookup();
        }

        public void empty_test_8876(MethodType p0)
        {
            MethodHandles.empty(p0);
        }

        public void constant_test_8877(Type p0, object p1)
        {
            MethodHandles.constant(p0, p1);
        }

        public void identity_test_8878(Type p0)
        {
            MethodHandles.identity(p0);
        }

        public void spreadInvoker_test_8879(MethodType p0, int p1)
        {
            MethodHandles.spreadInvoker(p0, p1);
        }

        public void arrayLength_test_8880(Type p0)
        {
            MethodHandles.arrayLength(p0);
        }

        public void varHandleInvoker_test_8881(VarHandle.AccessMode p0, MethodType p1)
        {
            MethodHandles.varHandleInvoker(p0, p1);
        }

        public void publicLookup_test_8882()
        {
            MethodHandles.publicLookup();
        }

        public void tryFinally_test_8883(MethodHandle p0, MethodHandle p1)
        {
            MethodHandles.tryFinally(p0, p1);
        }

        public void loop_test_8884(MethodHandle[][] p0)
        {
            MethodHandles.loop(p0);
        }

        public void tableSwitch_test_8885(MethodHandle p0, MethodHandle[] p1)
        {
            MethodHandles.tableSwitch(p0, p1);
        }

        public void arrayConstructor_test_8886(Type p0)
        {
            MethodHandles.arrayConstructor(p0);
        }

        public void exactInvoker_test_8887(MethodType p0)
        {
            MethodHandles.exactInvoker(p0);
        }

        public void foldArguments_test_8888(MethodHandle p0, MethodHandle p1)
        {
            MethodHandles.foldArguments(p0, p1);
        }

        public void foldArguments_test_8889(MethodHandle p0, int p1, MethodHandle p2)
        {
            MethodHandles.foldArguments(p0, p1, p2);
        }

        public void invoker_test_8890(MethodType p0)
        {
            MethodHandles.invoker(p0);
        }

        public void reflectAs_test_8891(Type p0, MethodHandle p1)
        {
            MethodHandles.reflectAs(p0, p1);
        }

        public void zero_test_8892(Type p0)
        {
            MethodHandles.zero(p0);
        }

        public void dropArgumentsToMatch_test_8893(MethodHandle p0, int p1, List<Type> p2, int p3)
        {
            MethodHandles.dropArgumentsToMatch(p0, p1, p2, p3);
        }

        public void dropArguments_test_8894(MethodHandle p0, int p1, List<Type> p2)
        {
            MethodHandles.dropArguments(p0, p1, p2);
        }

        public void dropArguments_test_8895(MethodHandle p0, int p1, Type[] p2)
        {
            MethodHandles.dropArguments(p0, p1, p2);
        }

        public void countedLoop_test_8896(MethodHandle p0, MethodHandle p1, MethodHandle p2, MethodHandle p3)
        {
            MethodHandles.countedLoop(p0, p1, p2, p3);
        }

        public void countedLoop_test_8897(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.countedLoop(p0, p1, p2);
        }

        public void permuteArguments_test_8898(MethodHandle p0, MethodType p1, int[] p2)
        {
            MethodHandles.permuteArguments(p0, p1, p2);
        }

        public void filterValue_test_8899(VarHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.filterValue(p0, p1, p2);
        }

        public void filterCoordinates_test_8900(VarHandle p0, int p1, MethodHandle[] p2)
        {
            MethodHandles.filterCoordinates(p0, p1, p2);
        }

        public void insertCoordinates_test_8901(VarHandle p0, int p1, object[] p2)
        {
            MethodHandles.insertCoordinates(p0, p1, p2);
        }

        public void permuteCoordinates_test_8902(VarHandle p0, List<Type> p1, int[] p2)
        {
            MethodHandles.permuteCoordinates(p0, p1, p2);
        }

        public void collectCoordinates_test_8903(VarHandle p0, int p1, MethodHandle p2)
        {
            MethodHandles.collectCoordinates(p0, p1, p2);
        }

        public void dropCoordinates_test_8904(VarHandle p0, int p1, Type[] p2)
        {
            MethodHandles.dropCoordinates(p0, p1, p2);
        }

        public void arrayElementGetter_test_8905(Type p0)
        {
            MethodHandles.arrayElementGetter(p0);
        }

        public void arrayElementSetter_test_8906(Type p0)
        {
            MethodHandles.arrayElementSetter(p0);
        }

        public void arrayElementVarHandle_test_8907(Type p0)
        {
            MethodHandles.arrayElementVarHandle(p0);
        }

        public void byteArrayViewVarHandle_test_8908(Type p0, ByteOrder p1)
        {
            MethodHandles.byteArrayViewVarHandle(p0, p1);
        }

        public void byteBufferViewVarHandle_test_8909(Type p0, ByteOrder p1)
        {
            MethodHandles.byteBufferViewVarHandle(p0, p1);
        }

        public void varHandleExactInvoker_test_8910(VarHandle.AccessMode p0, MethodType p1)
        {
            MethodHandles.varHandleExactInvoker(p0, p1);
        }

        public void explicitCastArguments_test_8911(MethodHandle p0, MethodType p1)
        {
            MethodHandles.explicitCastArguments(p0, p1);
        }

        public void insertArguments_test_8912(MethodHandle p0, int p1, object[] p2)
        {
            MethodHandles.insertArguments(p0, p1, p2);
        }

        public void dropReturn_test_8913(MethodHandle p0)
        {
            MethodHandles.dropReturn(p0);
        }

        public void filterArguments_test_8914(MethodHandle p0, int p1, MethodHandle[] p2)
        {
            MethodHandles.filterArguments(p0, p1, p2);
        }

        public void collectArguments_test_8915(MethodHandle p0, int p1, MethodHandle p2)
        {
            MethodHandles.collectArguments(p0, p1, p2);
        }

        public void filterReturnValue_test_8916(MethodHandle p0, MethodHandle p1)
        {
            MethodHandles.filterReturnValue(p0, p1);
        }

        public void guardWithTest_test_8917(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.guardWithTest(p0, p1, p2);
        }

        public void catchException_test_8918(MethodHandle p0, Type p1, MethodHandle p2)
        {
            MethodHandles.catchException(p0, p1, p2);
        }

        public void whileLoop_test_8919(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.whileLoop(p0, p1, p2);
        }

        public void doWhileLoop_test_8920(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.doWhileLoop(p0, p1, p2);
        }

        public void iteratedLoop_test_8921(MethodHandle p0, MethodHandle p1, MethodHandle p2)
        {
            MethodHandles.iteratedLoop(p0, p1, p2);
        }
    }
}