namespace Generated.Test
{
    public class javax_swing_plaf_ComponentUIAutoTest
    {
        public void createUI_test_2673(JComponent p0)
        {
            ComponentUI.CreateUI(p0);
        }
    }

    public class JComponent
    {
    }

    public class ComponentUI
    {
        public static void CreateUI(JComponent component)
        {
        }
    }
}