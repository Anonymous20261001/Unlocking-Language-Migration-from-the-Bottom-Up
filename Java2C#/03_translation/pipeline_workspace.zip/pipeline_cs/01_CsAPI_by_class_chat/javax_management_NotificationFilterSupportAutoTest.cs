using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Notification
    {
        public string Type { get; set; }
        
        public Notification(string type)
        {
            Type = type;
        }
    }

    public class NotificationFilterSupport
    {
        private List<string> enabledTypes = new List<string>();

        public void enableType(string type)
        {
            if (!enabledTypes.Contains(type))
            {
                enabledTypes.Add(type);
            }
        }

        public List<string> getEnabledTypes()
        {
            return new List<string>(enabledTypes);
        }

        public void disableType(string type)
        {
            enabledTypes.Remove(type);
        }

        public void disableAllTypes()
        {
            enabledTypes.Clear();
        }

        public bool isNotificationEnabled(Notification notification)
        {
            if (enabledTypes.Count == 0)
            {
                return false;
            }
            
            foreach (string type in enabledTypes)
            {
                if (notification.Type.StartsWith(type))
                {
                    return true;
                }
            }
            
            return false;
        }
    }

    public class javax_management_NotificationFilterSupportAutoTest
    {
        public void enableType_test_9547(string p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.enableType(p0);
        }

        public void getEnabledTypes_test_9548()
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.getEnabledTypes();
        }

        public void disableType_test_9549(string p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.disableType(p0);
        }

        public void disableAllTypes_test_9550()
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.disableAllTypes();
        }

        public void isNotificationEnabled_test_9551(Notification p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.isNotificationEnabled(p0);
        }
    }
}