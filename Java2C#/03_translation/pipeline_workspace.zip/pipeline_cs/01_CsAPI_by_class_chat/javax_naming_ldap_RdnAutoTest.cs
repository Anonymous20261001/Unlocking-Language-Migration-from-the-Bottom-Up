using System;
using System.Collections.Generic;
using System.Text;

namespace Generated.Test
{
    public class Rdn
    {
        public static string escapeValue(object value)
        {
            if (value == null)
            {
                return null;
            }
            
            string str = value.ToString();
            StringBuilder sb = new StringBuilder();
            
            foreach (char c in str)
            {
                switch (c)
                {
                    case ',':
                    case '+':
                    case '"':
                    case '\\':
                    case '<':
                    case '>':
                    case ';':
                        sb.Append('\\');
                        sb.Append(c);
                        break;
                    case '#':
                        if (sb.Length == 0)
                        {
                            sb.Append("\\#");
                        }
                        else
                        {
                            sb.Append(c);
                        }
                        break;
                    case ' ':
                        if (sb.Length == 0 || sb[sb.Length - 1] == ' ')
                        {
                            sb.Append("\\ ");
                        }
                        else
                        {
                            sb.Append(c);
                        }
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            
            return sb.ToString();
        }

        public static object unescapeValue(string value)
        {
            if (value == null)
            {
                return null;
            }
            
            StringBuilder sb = new StringBuilder();
            bool escaped = false;
            
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                
                if (escaped)
                {
                    sb.Append(c);
                    escaped = false;
                }
                else if (c == '\\')
                {
                    escaped = true;
                }
                else
                {
                    sb.Append(c);
                }
            }
            
            if (escaped)
            {
                throw new ArgumentException("Invalid escape sequence at end of string");
            }
            
            return sb.ToString();
        }
    }

    public class javax_naming_ldap_RdnAutoTest
    {
        public void escapeValue_test_10344(object p0)
        {
            Rdn.escapeValue(p0);
        }

        public void unescapeValue_test_10345(string p0)
        {
            Rdn.unescapeValue(p0);
        }
    }
}