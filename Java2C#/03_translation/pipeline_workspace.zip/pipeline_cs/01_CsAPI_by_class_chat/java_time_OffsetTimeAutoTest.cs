using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_time_OffsetTimeAutoTest
    {
        public void of_test_9651(LocalTime p0, ZoneOffset p1)
        {
            OffsetTime.Of(p0, p1);
        }

        public void of_test_9652(int p0, int p1, int p2, int p3, ZoneOffset p4)
        {
            OffsetTime.Of(p0, p1, p2, p3, p4);
        }

        public void from_test_9653(TemporalAccessor p0)
        {
            OffsetTime.From(p0);
        }

        public void parse_test_9654(string p0)
        {
            OffsetTime.Parse(p0);
        }

        public void parse_test_9655(string p0, DateTimeFormatter p1)
        {
            OffsetTime.Parse(p0, p1);
        }

        public void now_test_9656()
        {
            OffsetTime.Now();
        }

        public void now_test_9657(Clock p0)
        {
            OffsetTime.Now(p0);
        }

        public void now_test_9658(ZoneId p0)
        {
            OffsetTime.Now(p0);
        }

        public void ofInstant_test_9659(Instant p0, ZoneId p1)
        {
            OffsetTime.OfInstant(p0, p1);
        }
    }

    public class OffsetTime : IComparable<OffsetTime>, IEquatable<OffsetTime>
    {
        private readonly LocalTime _time;
        private readonly ZoneOffset _offset;

        public OffsetTime(LocalTime time, ZoneOffset offset)
        {
            _time = time;
            _offset = offset;
        }

        public static OffsetTime Of(LocalTime time, ZoneOffset offset)
        {
            return new OffsetTime(time, offset);
        }

        public static OffsetTime Of(int hour, int minute, int second, int nanoOfSecond, ZoneOffset offset)
        {
            return new OffsetTime(LocalTime.Of(hour, minute, second, nanoOfSecond), offset);
        }

        public static OffsetTime From(TemporalAccessor temporal)
        {
            if (temporal is OffsetTime offsetTime)
                return offsetTime;
            if (temporal is LocalTime localTime)
                return new OffsetTime(localTime, ZoneOffset.UTC);
            throw new ArgumentException("Unable to obtain OffsetTime from TemporalAccessor");
        }

        public static OffsetTime Parse(string text)
        {
            return Parse(text, DateTimeFormatter.ISO_OFFSET_TIME);
        }

        public static OffsetTime Parse(string text, DateTimeFormatter formatter)
        {
            return formatter.ParseOffsetTime(text);
        }

        public static OffsetTime Now()
        {
            return Now(Clock.SystemUTC());
        }

        public static OffsetTime Now(Clock clock)
        {
            return new OffsetTime(LocalTime.Now(clock), ZoneOffset.UTC);
        }

        public static OffsetTime Now(ZoneId zone)
        {
            return Now(Clock.System(zone));
        }

        public static OffsetTime OfInstant(Instant instant, ZoneId zone)
        {
            var offset = zone.GetRules().GetOffset(instant);
            var localTime = LocalTime.OfInstant(instant, zone);
            return new OffsetTime(localTime, offset);
        }

        public LocalTime ToLocalTime() => _time;
        public ZoneOffset GetOffset() => _offset;

        public int CompareTo(OffsetTime other)
        {
            if (other == null) return 1;
            int timeComparison = _time.CompareTo(other._time);
            if (timeComparison != 0) return timeComparison;
            return _offset.CompareTo(other._offset);
        }

        public bool Equals(OffsetTime other)
        {
            if (other == null) return false;
            return _time.Equals(other._time) && _offset.Equals(other._offset);
        }

        public override bool Equals(object obj) => obj is OffsetTime other && Equals(other);

        public override int GetHashCode() => HashCode.Combine(_time, _offset);

        public override string ToString() => $"{_time}{_offset}";
    }

    public class LocalTime : IComparable<LocalTime>, IEquatable<LocalTime>
    {
        private readonly TimeSpan _timeOfDay;

        public LocalTime(TimeSpan timeOfDay)
        {
            _timeOfDay = timeOfDay;
        }

        public static LocalTime Of(int hour, int minute, int second, int nanoOfSecond)
        {
            long ticks = ((hour * 60L + minute) * 60L + second) * TimeSpan.TicksPerSecond + nanoOfSecond / 100;
            return new LocalTime(TimeSpan.FromTicks(ticks));
        }

        public static LocalTime Now(Clock clock)
        {
            return new LocalTime(clock.Instant().ToLocalTime().TimeOfDay);
        }

        public static LocalTime OfInstant(Instant instant, ZoneId zone)
        {
            var offset = zone.GetRules().GetOffset(instant);
            var localDateTime = instant.ToLocalDateTime(offset);
            return new LocalTime(localDateTime.TimeOfDay);
        }

        public int CompareTo(LocalTime other)
        {
            if (other == null) return 1;
            return _timeOfDay.CompareTo(other._timeOfDay);
        }

        public bool Equals(LocalTime other)
        {
            if (other == null) return false;
            return _timeOfDay.Equals(other._timeOfDay);
        }

        public override bool Equals(object obj) => obj is LocalTime other && Equals(other);

        public override int GetHashCode() => _timeOfDay.GetHashCode();

        public override string ToString() => _timeOfDay.ToString(@"hh\:mm\:ss");
    }

    public class ZoneOffset : IComparable<ZoneOffset>, IEquatable<ZoneOffset>
    {
        public static readonly ZoneOffset UTC = new ZoneOffset(TimeSpan.Zero);

        private readonly TimeSpan _totalSeconds;

        public ZoneOffset(TimeSpan totalSeconds)
        {
            _totalSeconds = totalSeconds;
        }

        public int CompareTo(ZoneOffset other)
        {
            if (other == null) return 1;
            return _totalSeconds.CompareTo(other._totalSeconds);
        }

        public bool Equals(ZoneOffset other)
        {
            if (other == null) return false;
            return _totalSeconds.Equals(other._totalSeconds);
        }

        public override bool Equals(object obj) => obj is ZoneOffset other && Equals(other);

        public override int GetHashCode() => _totalSeconds.GetHashCode();

        public override string ToString()
        {
            if (_totalSeconds == TimeSpan.Zero) return "Z";
            var sign = _totalSeconds < TimeSpan.Zero ? "-" : "+";
            var abs = _totalSeconds.Duration();
            var hours = abs.Hours;
            var minutes = abs.Minutes;
            var seconds = abs.Seconds;
            if (seconds == 0)
                return $"{sign}{hours:D2}:{minutes:D2}";
            return $"{sign}{hours:D2}:{minutes:D2}:{seconds:D2}";
        }
    }

    public class ZoneId
    {
        private readonly string _id;

        public ZoneId(string id)
        {
            _id = id;
        }

        public string Id => _id;

        public ZoneRules GetRules()
        {
            return new ZoneRules(this);
        }

        public override string ToString() => _id;
    }

    public class ZoneRules
    {
        private readonly ZoneId _zoneId;

        public ZoneRules(ZoneId zoneId)
        {
            _zoneId = zoneId;
        }

        public ZoneOffset GetOffset(Instant instant)
        {
            // Simplified: use UTC offset for all zones
            return ZoneOffset.UTC;
        }
    }

    public class Instant : IComparable<Instant>, IEquatable<Instant>
    {
        private readonly DateTime _utcDateTime;

        public Instant(DateTime utcDateTime)
        {
            _utcDateTime = DateTime.SpecifyKind(utcDateTime, DateTimeKind.Utc);
        }

        public static Instant Now()
        {
            return new Instant(DateTime.UtcNow);
        }

        public DateTime ToLocalDateTime(ZoneOffset offset)
        {
            return _utcDateTime.Add(offset.GetTotalSeconds());
        }

        public int CompareTo(Instant other)
        {
            if (other == null) return 1;
            return _utcDateTime.CompareTo(other._utcDateTime);
        }

        public bool Equals(Instant other)
        {
            if (other == null) return false;
            return _utcDateTime.Equals(other._utcDateTime);
        }

        public override bool Equals(object obj) => obj is Instant other && Equals(other);

        public override int GetHashCode() => _utcDateTime.GetHashCode();
    }

    public class Clock
    {
        private readonly ZoneId _zone;

        public Clock(ZoneId zone)
        {
            _zone = zone;
        }

        public static Clock SystemUTC()
        {
            return new Clock(new ZoneId("UTC"));
        }

        public static Clock System(ZoneId zone)
        {
            return new Clock(zone);
        }

        public Instant Instant()
        {
            return Instant.Now();
        }

        public ZoneId GetZone() => _zone;
    }

    public class TemporalAccessor
    {
        // Base class for temporal accessors
    }

    public class DateTimeFormatter
    {
        public static readonly DateTimeFormatter ISO_OFFSET_TIME = new DateTimeFormatter("HH:mm:ssXXX");

        private readonly string _pattern;

        public DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public OffsetTime ParseOffsetTime(string text)
        {
            // Simplified parsing: assume format "HH:mm:ssZ" or "HH:mm:ss+HH:mm"
            var parts = text.Split('T');
            var timePart = parts[0];
            var offsetPart = parts.Length > 1 ? parts[1] : "Z";

            var timeParts = timePart.Split(':');
            int hour = int.Parse(timeParts[0]);
            int minute = int.Parse(timeParts[1]);
            int second = timeParts.Length > 2 ? int.Parse(timeParts[2]) : 0;

            ZoneOffset offset;
            if (offsetPart == "Z")
            {
                offset = ZoneOffset.UTC;
            }
            else
            {
                var sign = offsetPart[0] == '-' ? -1 : 1;
                var offsetParts = offsetPart.Substring(1).Split(':');
                int offsetHours = int.Parse(offsetParts[0]);
                int offsetMinutes = offsetParts.Length > 1 ? int.Parse(offsetParts[1]) : 0;
                offset = new ZoneOffset(TimeSpan.FromMinutes(sign * (offsetHours * 60 + offsetMinutes)));
            }

            return OffsetTime.Of(hour, minute, second, 0, offset);
        }
    }

    public static class ZoneOffsetExtensions
    {
        public static TimeSpan GetTotalSeconds(this ZoneOffset offset)
        {
            // This is a placeholder - in real implementation we'd store the total seconds
            return TimeSpan.Zero;
        }
    }
}