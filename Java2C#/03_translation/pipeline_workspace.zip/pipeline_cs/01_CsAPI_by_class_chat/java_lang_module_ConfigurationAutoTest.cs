using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_lang_module_ConfigurationAutoTest
    {
        public void empty_test_2903()
        {
            Configuration.Empty();
        }

        public void resolve_test_2904(ModuleFinder p0, List p1, ModuleFinder p2, Collection p3)
        {
            Configuration.Resolve(p0, p1, p2, p3);
        }

        public void resolveAndBind_test_2905(ModuleFinder p0, List p1, ModuleFinder p2, Collection p3)
        {
            Configuration.ResolveAndBind(p0, p1, p2, p3);
        }
    }

    public class Configuration
    {
        public static Configuration Empty()
        {
            return new Configuration();
        }

        public static Configuration Resolve(ModuleFinder before, List roots, ModuleFinder after, Collection others)
        {
            return new Configuration();
        }

        public static Configuration ResolveAndBind(ModuleFinder before, List roots, ModuleFinder after, Collection others)
        {
            return new Configuration();
        }
    }

    public class ModuleFinder
    {
    }

    public class Collection
    {
    }
}