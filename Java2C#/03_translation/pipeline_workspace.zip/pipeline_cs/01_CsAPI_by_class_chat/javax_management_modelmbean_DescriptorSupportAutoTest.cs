using System;
using System.Collections.Generic;
using System.Text;

namespace Generated.Test
{
    public class DescriptorSupport
    {
        private Dictionary<string, object> fields = new Dictionary<string, object>();

        public DescriptorSupport()
        {
        }

        public string[] GetFieldNames()
        {
            string[] names = new string[fields.Count];
            fields.Keys.CopyTo(names, 0);
            return names;
        }

        public object[] GetFieldValues(string[] fieldNames)
        {
            if (fieldNames == null)
            {
                return new object[0];
            }

            object[] values = new object[fieldNames.Length];
            for (int i = 0; i < fieldNames.Length; i++)
            {
                if (fieldNames[i] != null && fields.ContainsKey(fieldNames[i]))
                {
                    values[i] = fields[fieldNames[i]];
                }
                else
                {
                    values[i] = null;
                }
            }
            return values;
        }

        public void SetField(string fieldName, object fieldValue)
        {
            if (fieldName == null)
            {
                throw new ArgumentNullException("fieldName");
            }
            fields[fieldName] = fieldValue;
        }

        public object GetFieldValue(string fieldName)
        {
            if (fieldName == null)
            {
                return null;
            }
            if (fields.ContainsKey(fieldName))
            {
                return fields[fieldName];
            }
            return null;
        }

        public void RemoveField(string fieldName)
        {
            if (fieldName != null && fields.ContainsKey(fieldName))
            {
                fields.Remove(fieldName);
            }
        }

        public string ToXMLString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<Descriptor>");
            foreach (KeyValuePair<string, object> entry in fields)
            {
                sb.Append("<field name=\"");
                sb.Append(entry.Key);
                sb.Append("\" value=\"");
                if (entry.Value != null)
                {
                    sb.Append(entry.Value.ToString());
                }
                sb.Append("\"/>");
            }
            sb.Append("</Descriptor>");
            return sb.ToString();
        }

        public string[] GetFields()
        {
            string[] result = new string[fields.Count];
            int index = 0;
            foreach (KeyValuePair<string, object> entry in fields)
            {
                result[index] = entry.Key + "=" + (entry.Value != null ? entry.Value.ToString() : "null");
                index++;
            }
            return result;
        }

        public bool IsValid()
        {
            return true;
        }

        public void SetFields(string[] fieldNames, object[] fieldValues)
        {
            if (fieldNames == null)
            {
                throw new ArgumentNullException("fieldNames");
            }
            if (fieldValues == null)
            {
                throw new ArgumentNullException("fieldValues");
            }
            if (fieldNames.Length != fieldValues.Length)
            {
                throw new ArgumentException("fieldNames and fieldValues must have the same length");
            }

            for (int i = 0; i < fieldNames.Length; i++)
            {
                if (fieldNames[i] != null)
                {
                    fields[fieldNames[i]] = fieldValues[i];
                }
            }
        }
    }

    public class javax_management_modelmbean_DescriptorSupportAutoTest
    {
        public void getFieldNames_test_4099()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.GetFieldNames();
        }

        public void getFieldValues_test_4100(string[] p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.GetFieldValues(p0);
        }

        public void setField_test_4101(string p0, object p1)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.SetField(p0, p1);
        }

        public void getFieldValue_test_4102(string p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.GetFieldValue(p0);
        }

        public void removeField_test_4103(string p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.RemoveField(p0);
        }

        public void toXMLString_test_4104()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.ToXMLString();
        }

        public void getFields_test_4105()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.GetFields();
        }

        public void isValid_test_4106()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.IsValid();
        }

        public void setFields_test_4107(string[] p0, object[] p1)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.SetFields(p0, p1);
        }
    }
}