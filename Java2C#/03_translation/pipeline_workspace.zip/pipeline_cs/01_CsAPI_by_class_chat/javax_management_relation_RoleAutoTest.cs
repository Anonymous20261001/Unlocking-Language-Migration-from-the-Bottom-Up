namespace Generated.Test
{
    using System.Collections.Generic;

    public class Role
    {
        private string roleName;
        private List<object> roleValue;

        public Role(string roleName, List<object> roleValue)
        {
            this.roleName = roleName;
            this.roleValue = roleValue;
        }

        public void setRoleName(string roleName)
        {
            this.roleName = roleName;
        }

        public void setRoleValue(List<object> roleValue)
        {
            this.roleValue = roleValue;
        }

        public string getRoleName()
        {
            return roleName;
        }

        public List<object> getRoleValue()
        {
            return roleValue;
        }

        public static string roleValueToString(List<object> roleValue)
        {
            return string.Join(", ", roleValue);
        }
    }

    public class javax_management_relation_RoleAutoTest
    {
        public void setRoleName_test_10640(string p0, string c0, List<object> c1)
        {
            Role instance = new Role(c0, c1);
            instance.setRoleName(p0);
        }

        public void setRoleValue_test_10641(List<object> p0, string c0, List<object> c1)
        {
            Role instance = new Role(c0, c1);
            instance.setRoleValue(p0);
        }

        public void getRoleName_test_10642(string c0, List<object> c1)
        {
            Role instance = new Role(c0, c1);
            instance.getRoleName();
        }

        public void getRoleValue_test_10643(string c0, List<object> c1)
        {
            Role instance = new Role(c0, c1);
            instance.getRoleValue();
        }

        public void roleValueToString_test_10644(List<object> p0)
        {
            Role.roleValueToString(p0);
        }
    }
}