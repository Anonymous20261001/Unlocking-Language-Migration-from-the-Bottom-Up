namespace Generated.Test
{
    using System;
    using System.Globalization;

    public class java_time_YearAutoTest
    {
        public void of_test_13666(int p0)
        {
            Year.Of(p0);
        }

        public void from_test_13667(TemporalAccessor p0)
        {
            Year.From(p0);
        }

        public void parse_test_13668(CharSequence p0, DateTimeFormatter p1)
        {
            Year.Parse(p0, p1);
        }

        public void parse_test_13669(CharSequence p0)
        {
            Year.Parse(p0);
        }

        public void now_test_13670()
        {
            Year.Now();
        }

        public void now_test_13671(Clock p0)
        {
            Year.Now(p0);
        }

        public void now_test_13672(ZoneId p0)
        {
            Year.Now(p0);
        }

        public void isLeap_test_13673(long p0)
        {
            Year.IsLeap(p0);
        }
    }

    public class Year
    {
        private readonly int _year;

        private Year(int year)
        {
            _year = year;
        }

        public static Year Of(int year)
        {
            if (year < -999999999 || year > 999999999)
                throw new ArgumentOutOfRangeException(nameof(year), "Year must be in range [-999999999, 999999999]");
            return new Year(year);
        }

        public static Year From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return Of(temporal.GetYear());
        }

        public static Year Parse(CharSequence text, DateTimeFormatter formatter)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            if (formatter == null)
                throw new ArgumentNullException(nameof(formatter));
            return Parse(text.ToString(), formatter);
        }

        public static Year Parse(CharSequence text)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            return Parse(text.ToString(), DateTimeFormatter.OfPattern("yyyy"));
        }

        private static Year Parse(string text, DateTimeFormatter formatter)
        {
            if (string.IsNullOrWhiteSpace(text))
                throw new FormatException("Text cannot be empty");
            int year;
            if (!int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out year))
                throw new FormatException($"Text '{text}' could not be parsed to a Year");
            return Of(year);
        }

        public static Year Now()
        {
            return Now(Clock.SystemDefaultZone());
        }

        public static Year Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            return Of(clock.GetZone().GetCurrentYear());
        }

        public static Year Now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException(nameof(zone));
            return Now(Clock.Of(zone));
        }

        public static bool IsLeap(long year)
        {
            return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        }

        public int GetValue()
        {
            return _year;
        }
    }

    public class TemporalAccessor
    {
        public virtual int GetYear()
        {
            return DateTime.Now.Year;
        }
    }

    public class CharSequence
    {
        private readonly string _value;

        public CharSequence(string value)
        {
            _value = value ?? throw new ArgumentNullException(nameof(value));
        }

        public override string ToString()
        {
            return _value;
        }

        public static implicit operator CharSequence(string value)
        {
            return new CharSequence(value);
        }

        public static implicit operator string(CharSequence value)
        {
            return value?._value;
        }
    }

    public class DateTimeFormatter
    {
        private readonly string _pattern;

        private DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public static DateTimeFormatter OfPattern(string pattern)
        {
            return new DateTimeFormatter(pattern);
        }

        public string Format(Year year)
        {
            return year.GetValue().ToString(_pattern, CultureInfo.InvariantCulture);
        }
    }

    public class Clock
    {
        private readonly ZoneId _zone;

        private Clock(ZoneId zone)
        {
            _zone = zone;
        }

        public static Clock SystemDefaultZone()
        {
            return new Clock(ZoneId.SystemDefault());
        }

        public static Clock Of(ZoneId zone)
        {
            return new Clock(zone);
        }

        public ZoneId GetZone()
        {
            return _zone;
        }
    }

    public class ZoneId
    {
        private readonly string _id;

        private ZoneId(string id)
        {
            _id = id;
        }

        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }

        public int GetCurrentYear()
        {
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(_id)).Year;
        }
    }
}