namespace Generated.Test
{
    public class jdk_jshell_execution_UtilAutoTest
    {
        public void detectJdiExitEvent_test_13273(VirtualMachine p0, Consumer p1)
        {
            Util.detectJdiExitEvent(p0, p1);
        }

        public void forwardExecutionControl_test_13274(ExecutionControl p0, ObjectInput p1, ObjectOutput p2)
        {
            Util.forwardExecutionControl(p0, p1, p2);
        }
    }

    public class VirtualMachine
    {
        // Placeholder for VirtualMachine class
    }

    public class Consumer
    {
        // Placeholder for Consumer class
    }

    public class ExecutionControl
    {
        // Placeholder for ExecutionControl class
    }

    public class ObjectInput
    {
        // Placeholder for ObjectInput class
    }

    public class ObjectOutput
    {
        // Placeholder for ObjectOutput class
    }

    public static class Util
    {
        public static void detectJdiExitEvent(VirtualMachine vm, Consumer consumer)
        {
            // Implementation
        }

        public static void forwardExecutionControl(ExecutionControl ec, ObjectInput input, ObjectOutput output)
        {
            // Implementation
        }
    }
}