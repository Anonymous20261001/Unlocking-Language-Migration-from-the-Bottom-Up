namespace Generated.Test
{
    public class RoleInfo
    {
        private string description;
        private int minDegree;
        private int maxDegree;
        private string refMBeanClassName;
        private string name;
        private bool writable;
        private bool readable;

        public RoleInfo(RoleInfo other)
        {
            if (other == null)
            {
                throw new System.ArgumentException("RoleInfo cannot be null");
            }
            this.description = other.description;
            this.minDegree = other.minDegree;
            this.maxDegree = other.maxDegree;
            this.refMBeanClassName = other.refMBeanClassName;
            this.name = other.name;
            this.writable = other.writable;
            this.readable = other.readable;
        }

        public string GetDescription()
        {
            return description;
        }

        public int GetMinDegree()
        {
            return minDegree;
        }

        public int GetMaxDegree()
        {
            return maxDegree;
        }

        public void CheckMinDegree(int value)
        {
            if (value < 0)
            {
                throw new System.ArgumentException("Min degree cannot be negative");
            }
        }

        public void CheckMaxDegree(int value)
        {
            if (value < -1)
            {
                throw new System.ArgumentException("Max degree cannot be less than -1");
            }
        }

        public string GetRefMBeanClassName()
        {
            return refMBeanClassName;
        }

        public string GetName()
        {
            return name;
        }

        public bool IsWritable()
        {
            return writable;
        }

        public bool IsReadable()
        {
            return readable;
        }
    }

    public class javax_management_relation_RoleInfoAutoTest
    {
        public void getDescription_test_10645(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.GetDescription();
        }

        public void getMinDegree_test_10646(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.GetMinDegree();
        }

        public void getMaxDegree_test_10647(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.GetMaxDegree();
        }

        public void checkMinDegree_test_10648(int p0, RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.CheckMinDegree(p0);
        }

        public void checkMaxDegree_test_10649(int p0, RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.CheckMaxDegree(p0);
        }

        public void getRefMBeanClassName_test_10650(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.GetRefMBeanClassName();
        }

        public void getName_test_10651(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.GetName();
        }

        public void isWritable_test_10652(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.IsWritable();
        }

        public void isReadable_test_10653(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.IsReadable();
        }
    }
}