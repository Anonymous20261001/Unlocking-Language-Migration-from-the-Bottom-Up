namespace Generated.Test
{
    public class java_rmi_server_RMISocketFactoryAutoTest
    {
        public void getSocketFactory_test_10636()
        {
            RMISocketFactory.GetSocketFactory();
        }

        public void getDefaultSocketFactory_test_10637()
        {
            RMISocketFactory.GetDefaultSocketFactory();
        }

        public void setFailureHandler_test_10638(RMIFailureHandler p0)
        {
            RMISocketFactory.SetFailureHandler(p0);
        }

        public void getFailureHandler_test_10639()
        {
            RMISocketFactory.GetFailureHandler();
        }
    }

    public class RMIFailureHandler
    {
        public bool Failure(Exception ex)
        {
            return false;
        }
    }

    public class RMISocketFactory
    {
        private static RMISocketFactory factory = null;
        private static RMISocketFactory defaultFactory = new RMISocketFactory();
        private static RMIFailureHandler failureHandler = null;

        public static RMISocketFactory GetSocketFactory()
        {
            return factory;
        }

        public static RMISocketFactory GetDefaultSocketFactory()
        {
            return defaultFactory;
        }

        public static void SetFailureHandler(RMIFailureHandler handler)
        {
            failureHandler = handler;
        }

        public static RMIFailureHandler GetFailureHandler()
        {
            return failureHandler;
        }
    }
}