using System;
using System.Globalization;
using Generated.Test;

namespace Generated.Test
{
    // DateTimeFormatter equivalent
    public class DateTimeFormatter
    {
        public string Pattern { get; }
        
        public DateTimeFormatter(string pattern)
        {
            Pattern = pattern;
        }
        
        public static DateTimeFormatter OfPattern(string pattern)
        {
            return new DateTimeFormatter(pattern);
        }
        
        public string Format(DateTime date)
        {
            return date.ToString(Pattern, CultureInfo.InvariantCulture);
        }
        
        public DateTime Parse(string text)
        {
            return DateTime.ParseExact(text, Pattern, CultureInfo.InvariantCulture);
        }
    }
    
    // TemporalAccessor equivalent - simplified to DateTime
    public class TemporalAccessor
    {
        public DateTime Value { get; }
        
        public TemporalAccessor(DateTime value)
        {
            Value = value;
        }
        
        public static implicit operator TemporalAccessor(DateTime value)
        {
            return new TemporalAccessor(value);
        }
    }
    
    // Clock equivalent
    public class Clock
    {
        public DateTime Now { get; }
        
        public Clock(DateTime now)
        {
            Now = now;
        }
        
        public static Clock SystemDefaultZone()
        {
            return new Clock(DateTime.Now);
        }
        
        public static Clock Fixed(DateTime fixedInstant, ZoneId zone)
        {
            return new Clock(fixedInstant);
        }
    }
    
    // ZoneId equivalent
    public class ZoneId
    {
        public string Id { get; }
        
        public ZoneId(string id)
        {
            Id = id;
        }
        
        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }
        
        public static ZoneId Of(string id)
        {
            return new ZoneId(id);
        }
    }
    
    // Instant equivalent
    public class Instant
    {
        public DateTime Value { get; }
        
        public Instant(DateTime value)
        {
            Value = value;
        }
        
        public static Instant Now()
        {
            return new Instant(DateTime.UtcNow);
        }
    }
    
    // Month equivalent
    public enum Month
    {
        January = 1,
        February = 2,
        March = 3,
        April = 4,
        May = 5,
        June = 6,
        July = 7,
        August = 8,
        September = 9,
        October = 10,
        November = 11,
        December = 12
    }
    
    // LocalDate equivalent
    public class LocalDate
    {
        public int Year { get; }
        public int MonthValue { get; }
        public int DayOfMonth { get; }
        public long ToEpochDay { get; }
        
        public LocalDate(int year, int month, int day)
        {
            Year = year;
            MonthValue = month;
            DayOfMonth = day;
            ToEpochDay = (long)(new DateTime(year, month, day) - new DateTime(1970, 1, 1)).TotalDays;
        }
        
        public static LocalDate Of(int year, int month, int day)
        {
            return new LocalDate(year, month, day);
        }
        
        public static LocalDate Of(int year, Month month, int day)
        {
            return new LocalDate(year, (int)month, day);
        }
        
        public static LocalDate From(TemporalAccessor temporal)
        {
            return new LocalDate(temporal.Value.Year, temporal.Value.Month, temporal.Value.Day);
        }
        
        public static LocalDate Parse(string text)
        {
            DateTime dt = DateTime.Parse(text, CultureInfo.InvariantCulture);
            return new LocalDate(dt.Year, dt.Month, dt.Day);
        }
        
        public static LocalDate Parse(string text, DateTimeFormatter formatter)
        {
            DateTime dt = formatter.Parse(text);
            return new LocalDate(dt.Year, dt.Month, dt.Day);
        }
        
        public static LocalDate Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDate(now.Year, now.Month, now.Day);
        }
        
        public static LocalDate Now(Clock clock)
        {
            DateTime now = clock.Now;
            return new LocalDate(now.Year, now.Month, now.Day);
        }
        
        public static LocalDate Now(ZoneId zone)
        {
            DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(zone.Id));
            return new LocalDate(now.Year, now.Month, now.Day);
        }
        
        public static LocalDate OfInstant(Instant instant, ZoneId zone)
        {
            DateTime localTime = TimeZoneInfo.ConvertTime(instant.Value, TimeZoneInfo.FindSystemTimeZoneById(zone.Id));
            return new LocalDate(localTime.Year, localTime.Month, localTime.Day);
        }
        
        public static LocalDate OfEpochDay(long epochDay)
        {
            DateTime dt = new DateTime(1970, 1, 1).AddDays(epochDay);
            return new LocalDate(dt.Year, dt.Month, dt.Day);
        }
        
        public static LocalDate OfYearDay(int year, int dayOfYear)
        {
            DateTime dt = new DateTime(year, 1, 1).AddDays(dayOfYear - 1);
            return new LocalDate(dt.Year, dt.Month, dt.Day);
        }
    }
    
    public class java_time_LocalDateAutoTest
    {
        public void of_test_7988(int p0, int p1, int p2)
        {
            LocalDate.Of(p0, p1, p2);
        }
        
        public void of_test_7989(int p0, Month p1, int p2)
        {
            LocalDate.Of(p0, p1, p2);
        }
        
        public void from_test_7990(TemporalAccessor p0)
        {
            LocalDate.From(p0);
        }
        
        public void parse_test_7991(string p0)
        {
            LocalDate.Parse(p0);
        }
        
        public void parse_test_7992(string p0, DateTimeFormatter p1)
        {
            LocalDate.Parse(p0, p1);
        }
        
        public void now_test_7993()
        {
            LocalDate.Now();
        }
        
        public void now_test_7994(Clock p0)
        {
            LocalDate.Now(p0);
        }
        
        public void now_test_7995(ZoneId p0)
        {
            LocalDate.Now(p0);
        }
        
        public void ofInstant_test_7996(Instant p0, ZoneId p1)
        {
            LocalDate.OfInstant(p0, p1);
        }
        
        public void ofEpochDay_test_7997(long p0)
        {
            LocalDate.OfEpochDay(p0);
        }
        
        public void ofYearDay_test_7998(int p0, int p1)
        {
            LocalDate.OfYearDay(p0, p1);
        }
    }
}