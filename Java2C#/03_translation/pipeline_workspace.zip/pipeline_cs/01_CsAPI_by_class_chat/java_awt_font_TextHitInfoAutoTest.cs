namespace Generated.Test
{
    public class TextHitInfo
    {
        private int charIndex;
        private bool isLeadingEdge;

        private TextHitInfo(int charIndex, bool isLeadingEdge)
        {
            this.charIndex = charIndex;
            this.isLeadingEdge = isLeadingEdge;
        }

        public static TextHitInfo leading(int charIndex)
        {
            return new TextHitInfo(charIndex, true);
        }

        public static TextHitInfo trailing(int charIndex)
        {
            return new TextHitInfo(charIndex, false);
        }

        public static TextHitInfo beforeOffset(int offset)
        {
            return new TextHitInfo(offset - 1, false);
        }

        public static TextHitInfo afterOffset(int offset)
        {
            return new TextHitInfo(offset, true);
        }

        public int GetCharIndex()
        {
            return charIndex;
        }

        public bool IsLeadingEdge()
        {
            return isLeadingEdge;
        }

        public int GetInsertionIndex()
        {
            return isLeadingEdge ? charIndex : charIndex + 1;
        }

        public int GetOffsetHit(int offset)
        {
            if (offset < charIndex)
                return 0;
            else if (offset > charIndex + 1)
                return 1;
            else
                return isLeadingEdge ? 0 : 1;
        }

        public bool Equals(TextHitInfo hitInfo)
        {
            if (hitInfo == null)
                return false;
            return charIndex == hitInfo.charIndex && isLeadingEdge == hitInfo.isLeadingEdge;
        }

        public override bool Equals(object obj)
        {
            return obj is TextHitInfo && Equals((TextHitInfo)obj);
        }

        public override int GetHashCode()
        {
            return charIndex ^ (isLeadingEdge ? 0x80000000 : 0);
        }

        public override string ToString()
        {
            return isLeadingEdge ? "Leading(" + charIndex + ")" : "Trailing(" + charIndex + ")";
        }
    }

    public class java_awt_font_TextHitInfoAutoTest
    {
        public void trailing_test_12587(int p0)
        {
            TextHitInfo.trailing(p0);
        }

        public void leading_test_12588(int p0)
        {
            TextHitInfo.leading(p0);
        }

        public void beforeOffset_test_12589(int p0)
        {
            TextHitInfo.beforeOffset(p0);
        }

        public void afterOffset_test_12590(int p0)
        {
            TextHitInfo.afterOffset(p0);
        }
    }
}