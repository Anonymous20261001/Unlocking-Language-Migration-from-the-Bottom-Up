namespace Generated.Test
{
    public class java_nio_charset_CoderResultAutoTest
    {
        public void malformedForLength_test_2338(int p0)
        {
            CoderResult.MalformedForLength(p0);
        }

        public void unmappableForLength_test_2339(int p0)
        {
            CoderResult.UnmappableForLength(p0);
        }
    }

    public class CoderResult
    {
        public static CoderResult MalformedForLength(int length)
        {
            return new CoderResult(CoderResultType.Malformed, length);
        }

        public static CoderResult UnmappableForLength(int length)
        {
            return new CoderResult(CoderResultType.Unmappable, length);
        }

        private CoderResultType _type;
        private int _length;

        private CoderResult(CoderResultType type, int length)
        {
            _type = type;
            _length = length;
        }

        public bool IsMalformed()
        {
            return _type == CoderResultType.Malformed;
        }

        public bool IsUnmappable()
        {
            return _type == CoderResultType.Unmappable;
        }

        public bool IsUnderflow()
        {
            return _type == CoderResultType.Underflow;
        }

        public bool IsOverflow()
        {
            return _type == CoderResultType.Overflow;
        }

        public int Length()
        {
            return _length;
        }

        public override string ToString()
        {
            return _type.ToString() + "[" + _length + "]";
        }

        private enum CoderResultType
        {
            Underflow,
            Overflow,
            Malformed,
            Unmappable
        }
    }
}