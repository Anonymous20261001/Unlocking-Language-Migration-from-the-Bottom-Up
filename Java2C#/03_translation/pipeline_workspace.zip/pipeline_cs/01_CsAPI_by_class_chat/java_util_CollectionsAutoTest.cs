using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    public class java_util_CollectionsAutoTest
    {
        public void min_test_2353(Collection p0, Comparator p1)
        {
            Collections.min(p0, p1);
        }

        public void min_test_2354(Collection p0)
        {
            Collections.min(p0);
        }

        public void max_test_2355(Collection p0)
        {
            Collections.max(p0);
        }

        public void max_test_2356(Collection p0, Comparator p1)
        {
            Collections.max(p0, p1);
        }

        public void reverse_test_2357(List p0)
        {
            Collections.reverse(p0);
        }

        public void sort_test_2358(List p0)
        {
            Collections.sort(p0);
        }

        public void sort_test_2359(List p0, Comparator p1)
        {
            Collections.sort(p0, p1);
        }

        public void copy_test_2360(List p0, List p1)
        {
            Collections.copy(p0, p1);
        }

        public void replaceAll_test_2361(List p0, object p1, object p2)
        {
            Collections.replaceAll(p0, p1, p2);
        }

        public void fill_test_2362(List p0, object p1)
        {
            Collections.fill(p0, p1);
        }

        public void list_test_2363(Enumeration p0)
        {
            Collections.list(p0);
        }

        public void addAll_test_2364(Collection p0, object[] p1)
        {
            Collections.addAll(p0, p1);
        }

        public void emptyEnumeration_test_2365()
        {
            Collections.emptyEnumeration();
        }

        public void newSetFromMap_test_2366(Map p0)
        {
            Collections.newSetFromMap(p0);
        }

        public void emptyList_test_2367()
        {
            Collections.emptyList();
        }

        public void unmodifiableSet_test_2368(Set p0)
        {
            Collections.unmodifiableSet(p0);
        }

        public void enumeration_test_2369(Collection p0)
        {
            Collections.enumeration(p0);
        }

        public void synchronizedSet_test_2370(Set p0)
        {
            Collections.synchronizedSet(p0);
        }

        public void synchronizedCollection_test_2371(Collection p0)
        {
            Collections.synchronizedCollection(p0);
        }

        public void emptyIterator_test_2372()
        {
            Collections.emptyIterator();
        }

        public void nCopies_test_2373(int p0, object p1)
        {
            Collections.nCopies(p0, p1);
        }

        public void reverseOrder_test_2374(Comparator p0)
        {
            Collections.reverseOrder(p0);
        }

        public void reverseOrder_test_2375()
        {
            Collections.reverseOrder();
        }

        public void unmodifiableMap_test_2376(Map p0)
        {
            Collections.unmodifiableMap(p0);
        }

        public void unmodifiableSortedMap_test_2377(SortedMap p0)
        {
            Collections.unmodifiableSortedMap(p0);
        }

        public void swap_test_2378(List p0, int p1, int p2)
        {
            Collections.swap(p0, p1, p2);
        }

        public void binarySearch_test_2379(List p0, object p1, Comparator p2)
        {
            Collections.binarySearch(p0, p1, p2);
        }

        public void binarySearch_test_2380(List p0, object p1)
        {
            Collections.binarySearch(p0, p1);
        }

        public void shuffle_test_2381(List p0, Random p1)
        {
            Collections.shuffle(p0, p1);
        }

        public void shuffle_test_2382(List p0)
        {
            Collections.shuffle(p0);
        }

        public void shuffle_test_2383(List p0, RandomGenerator p1)
        {
            Collections.shuffle(p0, p1);
        }

        public void rotate_test_2384(List p0, int p1)
        {
            Collections.rotate(p0, p1);
        }

        public void indexOfSubList_test_2385(List p0, List p1)
        {
            Collections.indexOfSubList(p0, p1);
        }

        public void lastIndexOfSubList_test_2386(List p0, List p1)
        {
            Collections.lastIndexOfSubList(p0, p1);
        }

        public void unmodifiableCollection_test_2387(Collection p0)
        {
            Collections.unmodifiableCollection(p0);
        }

        public void unmodifiableSequencedCollection_test_2388(SequencedCollection p0)
        {
            Collections.unmodifiableSequencedCollection(p0);
        }

        public void unmodifiableSequencedSet_test_2389(SequencedSet p0)
        {
            Collections.unmodifiableSequencedSet(p0);
        }

        public void unmodifiableSortedSet_test_2390(SortedSet p0)
        {
            Collections.unmodifiableSortedSet(p0);
        }

        public void unmodifiableNavigableSet_test_2391(NavigableSet p0)
        {
            Collections.unmodifiableNavigableSet(p0);
        }

        public void unmodifiableList_test_2392(List p0)
        {
            Collections.unmodifiableList(p0);
        }

        public void unmodifiableSequencedMap_test_2393(SequencedMap p0)
        {
            Collections.unmodifiableSequencedMap(p0);
        }

        public void unmodifiableNavigableMap_test_2394(NavigableMap p0)
        {
            Collections.unmodifiableNavigableMap(p0);
        }

        public void synchronizedSortedSet_test_2395(SortedSet p0)
        {
            Collections.synchronizedSortedSet(p0);
        }

        public void synchronizedNavigableSet_test_2396(NavigableSet p0)
        {
            Collections.synchronizedNavigableSet(p0);
        }

        public void synchronizedList_test_2397(List p0)
        {
            Collections.synchronizedList(p0);
        }

        public void synchronizedMap_test_2398(Map p0)
        {
            Collections.synchronizedMap(p0);
        }

        public void synchronizedSortedMap_test_2399(SortedMap p0)
        {
            Collections.synchronizedSortedMap(p0);
        }

        public void synchronizedNavigableMap_test_2400(NavigableMap p0)
        {
            Collections.synchronizedNavigableMap(p0);
        }

        public void checkedCollection_test_2401(Collection p0, Class p1)
        {
            Collections.checkedCollection(p0, p1);
        }

        public void checkedQueue_test_2402(Queue p0, Class p1)
        {
            Collections.checkedQueue(p0, p1);
        }

        public void checkedSet_test_2403(Set p0, Class p1)
        {
            Collections.checkedSet(p0, p1);
        }

        public void checkedSortedSet_test_2404(SortedSet p0, Class p1)
        {
            Collections.checkedSortedSet(p0, p1);
        }

        public void checkedNavigableSet_test_2405(NavigableSet p0, Class p1)
        {
            Collections.checkedNavigableSet(p0, p1);
        }

        public void checkedList_test_2406(List p0, Class p1)
        {
            Collections.checkedList(p0, p1);
        }

        public void checkedMap_test_2407(Map p0, Class p1, Class p2)
        {
            Collections.checkedMap(p0, p1, p2);
        }

        public void checkedSortedMap_test_2408(SortedMap p0, Class p1, Class p2)
        {
            Collections.checkedSortedMap(p0, p1, p2);
        }

        public void checkedNavigableMap_test_2409(NavigableMap p0, Class p1, Class p2)
        {
            Collections.checkedNavigableMap(p0, p1, p2);
        }

        public void emptyListIterator_test_2410()
        {
            Collections.emptyListIterator();
        }

        public void emptySet_test_2411()
        {
            Collections.emptySet();
        }

        public void emptySortedSet_test_2412()
        {
            Collections.emptySortedSet();
        }

        public void emptyNavigableSet_test_2413()
        {
            Collections.emptyNavigableSet();
        }

        public void emptyMap_test_2414()
        {
            Collections.emptyMap();
        }

        public void emptySortedMap_test_2415()
        {
            Collections.emptySortedMap();
        }

        public void emptyNavigableMap_test_2416()
        {
            Collections.emptyNavigableMap();
        }

        public void singleton_test_2417(object p0)
        {
            Collections.singleton(p0);
        }

        public void singletonList_test_2418(object p0)
        {
            Collections.singletonList(p0);
        }

        public void singletonMap_test_2419(object p0, object p1)
        {
            Collections.singletonMap(p0, p1);
        }

        public void frequency_test_2420(Collection p0, object p1)
        {
            Collections.frequency(p0, p1);
        }

        public void disjoint_test_2421(Collection p0, Collection p1)
        {
            Collections.disjoint(p0, p1);
        }

        public void newSequencedSetFromMap_test_2422(SequencedMap p0)
        {
            Collections.newSequencedSetFromMap(p0);
        }

        public void asLifoQueue_test_2423(Deque p0)
        {
            Collections.asLifoQueue(p0);
        }
    }

    // Collection interface
    public interface Collection : IEnumerable
    {
        int size();
        bool isEmpty();
        bool contains(object o);
        object[] toArray();
        bool add(object e);
        bool remove(object o);
        bool containsAll(Collection c);
        bool addAll(Collection c);
        bool removeAll(Collection c);
        bool retainAll(Collection c);
        void clear();
        bool equals(object o);
        int hashCode();
    }

    // List interface
    public interface List : Collection
    {
        object get(int index);
        object set(int index, object element);
        void add(int index, object element);
        object remove(int index);
        int indexOf(object o);
        int lastIndexOf(object o);
        List subList(int fromIndex, int toIndex);
    }

    // Set interface
    public interface Set : Collection
    {
    }

    // SortedSet interface
    public interface SortedSet : Set
    {
        Comparator comparator();
        SortedSet subSet(object fromElement, object toElement);
        SortedSet headSet(object toElement);
        SortedSet tailSet(object fromElement);
        object first();
        object last();
    }

    // NavigableSet interface
    public interface NavigableSet : SortedSet
    {
        object lower(object e);
        object floor(object e);
        object ceiling(object e);
        object higher(object e);
        object pollFirst();
        object pollLast();
        NavigableSet descendingSet();
    }

    // SequencedSet interface
    public interface SequencedSet : Set
    {
    }

    // Map interface
    public interface Map
    {
        int size();
        bool isEmpty();
        bool containsKey(object key);
        bool containsValue(object value);
        object get(object key);
        object put(object key, object value);
        object remove(object key);
        void putAll(Map m);
        void clear();
        Set keySet();
        Collection values();
        Set entrySet();
        bool equals(object o);
        int hashCode();
    }

    // SortedMap interface
    public interface SortedMap : Map
    {
        Comparator comparator();
        SortedMap subMap(object fromKey, object toKey);
        SortedMap headMap(object toKey);
        SortedMap tailMap(object fromKey);
        object firstKey();
        object lastKey();
    }

    // NavigableMap interface
    public interface NavigableMap : SortedMap
    {
        object lowerKey(object key);
        object floorKey(object key);
        object ceilingKey(object key);
        object higherKey(object key);
        object firstEntry();
        object lastEntry();
        object pollFirstEntry();
        object pollLastEntry();
        NavigableMap descendingMap();
        NavigableMap subMap(object fromKey, bool fromInclusive, object toKey, bool toInclusive);
        NavigableMap headMap(object toKey, bool inclusive);
        NavigableMap tailMap(object fromKey, bool inclusive);
    }

    // SequencedMap interface
    public interface SequencedMap : Map
    {
    }

    // Queue interface
    public interface Queue : Collection
    {
        bool offer(object e);
        object poll();
        object peek();
    }

    // Deque interface
    public interface Deque : Queue
    {
        void addFirst(object e);
        void addLast(object e);
        bool offerFirst(object e);
        bool offerLast(object e);
        object removeFirst();
        object removeLast();
        object pollFirst();
        object pollLast();
        object getFirst();
        object getLast();
        object peekFirst();
        object peekLast();
        bool removeFirstOccurrence(object o);
        bool removeLastOccurrence(object o);
    }

    // SequencedCollection interface
    public interface SequencedCollection : Collection
    {
    }

    // Enumeration interface
    public interface Enumeration
    {
        bool hasMoreElements();
        object nextElement();
    }

    // Comparator interface
    public interface Comparator
    {
        int compare(object o1, object o2);
        bool equals(object obj);
    }

    // Class class (simplified)
    public class Class
    {
        private Type type;
        public Class(Type type) { this.type = type; }
        public static Class forName(string name) { return new Class(Type.GetType(name)); }
        public Type getType() { return type; }
    }

    // Random class
    public class Random
    {
        private System.Random random = new System.Random();
        public int nextInt() { return random.Next(); }
        public int nextInt(int bound) { return random.Next(bound); }
        public bool nextBoolean() { return random.Next(2) == 1; }
        public double nextDouble() { return random.NextDouble(); }
    }

    // RandomGenerator interface
    public interface RandomGenerator
    {
        int nextInt();
        int nextInt(int bound);
        bool nextBoolean();
        double nextDouble();
    }

    // Collections class with all static methods
    public static class Collections
    {
        public static object min(Collection coll, Comparator comp)
        {
            object min = null;
            bool first = true;
            foreach (object o in coll)
            {
                if (first)
                {
                    min = o;
                    first = false;
                }
                else if (comp.compare(o, min) < 0)
                {
                    min = o;
                }
            }
            return min;
        }

        public static object min(Collection coll)
        {
            return min(coll, new NaturalOrderComparator());
        }

        public static object max(Collection coll)
        {
            return max(coll, new NaturalOrderComparator());
        }

        public static object max(Collection coll, Comparator comp)
        {
            object max = null;
            bool first = true;
            foreach (object o in coll)
            {
                if (first)
                {
                    max = o;
                    first = false;
                }
                else if (comp.compare(o, max) > 0)
                {
                    max = o;
                }
            }
            return max;
        }

        public static void reverse(List list)
        {
            int size = list.size();
            for (int i = 0; i < size / 2; i++)
            {
                object temp = list.get(i);
                list.set(i, list.get(size - 1 - i));
                list.set(size - 1 - i, temp);
            }
        }

        public static void sort(List list)
        {
            sort(list, new NaturalOrderComparator());
        }

        public static void sort(List list, Comparator c)
        {
            object[] array = list.toArray();
            Array.Sort(array, (x, y) => c.compare(x, y));
            for (int i = 0; i < array.Length; i++)
            {
                list.set(i, array[i]);
            }
        }

        public static void copy(List dest, List src)
        {
            if (src.size() > dest.size())
                throw new ArgumentException("Source does not fit in dest");
            for (int i = 0; i < src.size(); i++)
            {
                dest.set(i, src.get(i));
            }
        }

        public static bool replaceAll(List list, object oldVal, object newVal)
        {
            bool replaced = false;
            for (int i = 0; i < list.size(); i++)
            {
                if (Equals(list.get(i), oldVal))
                {
                    list.set(i, newVal);
                    replaced = true;
                }
            }
            return replaced;
        }

        public static void fill(List list, object obj)
        {
            for (int i = 0; i < list.size(); i++)
            {
                list.set(i, obj);
            }
        }

        public static List list(Enumeration e)
        {
            List result = new ArrayList();
            while (e.hasMoreElements())
            {
                result.add(e.nextElement());
            }
            return result;
        }

        public static bool addAll(Collection c, object[] elements)
        {
            bool changed = false;
            foreach (object element in elements)
            {
                changed |= c.add(element);
            }
            return changed;
        }

        public static Enumeration emptyEnumeration()
        {
            return new EmptyEnumeration();
        }

        public static Set newSetFromMap(Map map)
        {
            return new SetFromMap(map);
        }

        public static List emptyList()
        {
            return new EmptyList();
        }

        public static Set unmodifiableSet(Set s)
        {
            return new UnmodifiableSet(s);
        }

        public static Enumeration enumeration(Collection c)
        {
            return new CollectionEnumeration(c);
        }

        public static Set synchronizedSet(Set s)
        {
            return new SynchronizedSet(s);
        }

        public static Collection synchronizedCollection(Collection c)
        {
            return new SynchronizedCollection(c);
        }

        public static IEnumerator emptyIterator()
        {
            return new EmptyIterator();
        }

        public static List nCopies(int n, object o)
        {
            return new NCopiesList(n, o);
        }

        public static Comparator reverseOrder(Comparator cmp)
        {
            return new ReverseComparator(cmp);
        }

        public static Comparator reverseOrder()
        {
            return new ReverseComparator(new NaturalOrderComparator());
        }

        public static Map unmodifiableMap(Map m)
        {
            return new UnmodifiableMap(m);
        }

        public static SortedMap unmodifiableSortedMap(SortedMap m)
        {
            return new UnmodifiableSortedMap(m);
        }

        public static void swap(List list, int i, int j)
        {
            object temp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, temp);
        }

        public static int binarySearch(List list, object key, Comparator c)
        {
            int low = 0;
            int high = list.size() - 1;
            while (low <= high)
            {
                int mid = (low + high) / 2;
                int cmp = c.compare(list.get(mid), key);
                if (cmp < 0)
                    low = mid + 1;
                else if (cmp > 0)
                    high = mid - 1;
                else
                    return mid;
            }
            return -(low + 1);
        }

        public static int binarySearch(List list, object key)
        {
            return binarySearch(list, key, new NaturalOrderComparator());
        }

        public static void shuffle(List list, Random rnd)
        {
            for (int i = list.size(); i > 1; i--)
            {
                int j = rnd.nextInt(i);
                swap(list, i - 1, j);
            }
        }

        public static void shuffle(List list)
        {
            shuffle(list, new Random());
        }

        public static void shuffle(List list, RandomGenerator rnd)
        {
            for (int i = list.size(); i > 1; i--)
            {
                int j = rnd.nextInt(i);
                swap(list, i - 1, j);
            }
        }

        public static void rotate(List list, int distance)
        {
            int size = list.size();
            if (size == 0)
                return;
            distance = distance % size;
            if (distance < 0)
                distance += size;
            if (distance == 0)
                return;
            reverse(list.subList(0, size - distance));
            reverse(list.subList(size - distance, size));
            reverse(list);
        }

        public static int indexOfSubList(List source, List target)
        {
            if (target.size() == 0)
                return 0;
            for (int i = 0; i <= source.size() - target.size(); i++)
            {
                bool match = true;
                for (int j = 0; j < target.size(); j++)
                {
                    if (!Equals(source.get(i + j), target.get(j)))
                    {
                        match = false;
                        break;
                    }
                }
                if (match)
                    return i;
            }
            return -1;
        }

        public static int lastIndexOfSubList(List source, List target)
        {
            if (target.size() == 0)
                return source.size();
            for (int i = source.size() - target.size(); i >= 0; i--)
            {
                bool match = true;
                for (int j = 0; j < target.size(); j++)
                {
                    if (!Equals(source.get(i + j), target.get(j)))
                    {
                        match = false;
                        break;
                    }
                }
                if (match)
                    return i;
            }
            return -1;
        }

        public static Collection unmodifiableCollection(Collection c)
        {
            return new UnmodifiableCollection(c);
        }

        public static SequencedCollection unmodifiableSequencedCollection(SequencedCollection c)
        {
            return new UnmodifiableSequencedCollection(c);
        }

        public static SequencedSet unmodifiableSequencedSet(SequencedSet s)
        {
            return new UnmodifiableSequencedSet(s);
        }

        public static SortedSet unmodifiableSortedSet(SortedSet s)
        {
            return new UnmodifiableSortedSet(s);
        }

        public static NavigableSet unmodifiableNavigableSet(NavigableSet s)
        {
            return new UnmodifiableNavigableSet(s);
        }

        public static List unmodifiableList(List list)
        {
            return new UnmodifiableList(list);
        }

        public static SequencedMap unmodifiableSequencedMap(SequencedMap m)
        {
            return new UnmodifiableSequencedMap(m);
        }

        public static NavigableMap unmodifiableNavigableMap(NavigableMap m)
        {
            return new UnmodifiableNavigableMap(m);
        }

        public static SortedSet synchronizedSortedSet(SortedSet s)
        {
            return new SynchronizedSortedSet(s);
        }

        public static NavigableSet synchronizedNavigableSet(NavigableSet s)
        {
            return new SynchronizedNavigableSet(s);
        }

        public static List synchronizedList(List list)
        {
            return new SynchronizedList(list);
        }

        public static Map synchronizedMap(Map m)
        {
            return new SynchronizedMap(m);
        }

        public static SortedMap synchronizedSortedMap(SortedMap m)
        {
            return new SynchronizedSortedMap(m);
        }

        public static NavigableMap synchronizedNavigableMap(NavigableMap m)
        {
            return new SynchronizedNavigableMap(m);
        }

        public static Collection checkedCollection(Collection c, Class type)
        {
            return new CheckedCollection(c, type);
        }

        public static Queue checkedQueue(Queue q, Class type)
        {
            return new CheckedQueue(q, type);
        }

        public static Set checkedSet(Set s, Class type)
        {
            return new CheckedSet(s, type);
        }

        public static SortedSet checkedSortedSet(SortedSet s, Class type)
        {
            return new CheckedSortedSet(s, type);
        }

        public static NavigableSet checkedNavigableSet(NavigableSet s, Class type)
        {
            return new CheckedNavigableSet(s, type);
        }

        public static List checkedList(List list, Class type)
        {
            return new CheckedList(list, type);
        }

        public static Map checkedMap(Map m, Class keyType, Class valueType)
        {
            return new CheckedMap(m, keyType, valueType);
        }

        public static SortedMap checkedSortedMap(SortedMap m, Class keyType, Class valueType)
        {
            return new CheckedSortedMap(m, keyType, valueType);
        }

        public static NavigableMap checkedNavigableMap(NavigableMap m, Class keyType, Class valueType)
        {
            return new CheckedNavigableMap(m, keyType, valueType);
        }

        public static IEnumerator emptyListIterator()
        {
            return new EmptyListIterator();
        }

        public static Set emptySet()
        {
            return new EmptySet();
        }

        public static SortedSet emptySortedSet()
        {
            return new EmptySortedSet();
        }

        public static NavigableSet emptyNavigableSet()
        {
            return new EmptyNavigableSet();
        }

        public static Map emptyMap()
        {
            return new EmptyMap();
        }

        public static SortedMap emptySortedMap()
        {
            return new EmptySortedMap();
        }

        public static NavigableMap emptyNavigableMap()
        {
            return new EmptyNavigableMap();
        }

        public static Set singleton(object o)
        {
            return new SingletonSet(o);
        }

        public static List singletonList(object o)
        {
            return new SingletonList(o);
        }

        public static Map singletonMap(object key, object value)
        {
            return new SingletonMap(key, value);
        }

        public static int frequency(Collection c, object o)
        {
            int count = 0;
            foreach (object item in c)
            {
                if (Equals(item, o))
                    count++;
            }
            return count;
        }

        public static bool disjoint(Collection c1, Collection c2)
        {
            foreach (object o in c1)
            {
                if (c2.contains(o))
                    return false;
            }
            return true;
        }

        public static Set newSequencedSetFromMap(SequencedMap map)
        {
            return new SetFromMap(map);
        }

        public static Queue asLifoQueue(Deque deque)
        {
            return new LifoQueue(deque);
        }

        // Helper classes
        private class NaturalOrderComparator : Comparator
        {
            public int compare(object o1, object o2)
            {
                return ((IComparable)o1).CompareTo(o2);
            }

            public bool equals(object obj)
            {
                return obj is NaturalOrderComparator;
            }
        }

        private class ReverseComparator : Comparator
        {
            private Comparator cmp;
            public ReverseComparator(Comparator cmp) { this.cmp = cmp; }
            public int compare(object o1, object o2) { return cmp.compare(o2, o1); }
            public bool equals(object obj) { return obj is ReverseComparator && ((ReverseComparator)obj).cmp.Equals(cmp); }
        }

        private class EmptyEnumeration : Enumeration
        {
            public bool hasMoreElements() { return false; }
            public object nextElement() { throw new InvalidOperationException(); }
        }

        private class CollectionEnumeration : Enumeration
        {
            private IEnumerator enumerator;
            public CollectionEnumeration(Collection c) { enumerator = c.GetEnumerator(); }
            public bool hasMoreElements() { return enumerator.MoveNext(); }
            public object nextElement() { return enumerator.Current; }
        }

        private class EmptyIterator : IEnumerator
        {
            public bool MoveNext() { return false; }
            public object Current { get { throw new InvalidOperationException(); } }
            public void Reset() { }
        }

        private class EmptyListIterator : IEnumerator
        {
            public bool MoveNext() { return false; }
            public object Current { get { throw new InvalidOperationException(); } }
            public void Reset() { }
        }

        private class EmptyList : List
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool contains(object o) { return false; }
            public object[] toArray() { return new object[0]; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { return c.size() == 0; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { }
            public bool equals(object o) { return o is List && ((List)o).size() == 0; }
            public int hashCode() { return 1; }
            public object get(int index) { throw new IndexOutOfRangeException(); }
            public object set(int index, object element) { throw new NotSupportedException(); }
            public void add(int index, object element) { throw new NotSupportedException(); }
            public object remove(int index) { throw new NotSupportedException(); }
            public int indexOf(object o) { return -1; }
            public int lastIndexOf(object o) { return -1; }
            public List subList(int fromIndex, int toIndex) { return this; }
            public IEnumerator GetEnumerator() { yield break; }
        }

        private class EmptySet : Set
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool contains(object o) { return false; }
            public object[] toArray() { return new object[0]; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { return c.size() == 0; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { }
            public bool equals(object o) { return o is Set && ((Set)o).size() == 0; }
            public int hashCode() { return 0; }
            public IEnumerator GetEnumerator() { yield break; }
        }

        private class EmptySortedSet : SortedSet
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool contains(object o) { return false; }
            public object[] toArray() { return new object[0]; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { return c.size() == 0; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { }
            public bool equals(object o) { return o is SortedSet && ((SortedSet)o).size() == 0; }
            public int hashCode() { return 0; }
            public Comparator comparator() { return null; }
            public SortedSet subSet(object fromElement, object toElement) { return this; }
            public SortedSet headSet(object toElement) { return this; }
            public SortedSet tailSet(object fromElement) { return this; }
            public object first() { throw new InvalidOperationException(); }
            public object last() { throw new InvalidOperationException(); }
            public IEnumerator GetEnumerator() { yield break; }
        }

        private class EmptyNavigableSet : NavigableSet
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool contains(object o) { return false; }
            public object[] toArray() { return new object[0]; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { return c.size() == 0; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { }
            public bool equals(object o) { return o is NavigableSet && ((NavigableSet)o).size() == 0; }
            public int hashCode() { return 0; }
            public Comparator comparator() { return null; }
            public SortedSet subSet(object fromElement, object toElement) { return this; }
            public SortedSet headSet(object toElement) { return this; }
            public SortedSet tailSet(object fromElement) { return this; }
            public object first() { throw new InvalidOperationException(); }
            public object last() { throw new InvalidOperationException(); }
            public object lower(object e) { return null; }
            public object floor(object e) { return null; }
            public object ceiling(object e) { return null; }
            public object higher(object e) { return null; }
            public object pollFirst() { return null; }
            public object pollLast() { return null; }
            public NavigableSet descendingSet() { return this; }
            public IEnumerator GetEnumerator() { yield break; }
        }

        private class EmptyMap : Map
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool containsKey(object key) { return false; }
            public bool containsValue(object value) { return false; }
            public object get(object key) { return null; }
            public object put(object key, object value) { throw new NotSupportedException(); }
            public object remove(object key) { throw new NotSupportedException(); }
            public void putAll(Map m) { throw new NotSupportedException(); }
            public void clear() { }
            public Set keySet() { return emptySet(); }
            public Collection values() { return emptyList(); }
            public Set entrySet() { return emptySet(); }
            public bool equals(object o) { return o is Map && ((Map)o).size() == 0; }
            public int hashCode() { return 0; }
        }

        private class EmptySortedMap : SortedMap
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool containsKey(object key) { return false; }
            public bool containsValue(object value) { return false; }
            public object get(object key) { return null; }
            public object put(object key, object value) { throw new NotSupportedException(); }
            public object remove(object key) { throw new NotSupportedException(); }
            public void putAll(Map m) { throw new NotSupportedException(); }
            public void clear() { }
            public Set keySet() { return emptySet(); }
            public Collection values() { return emptyList(); }
            public Set entrySet() { return emptySet(); }
            public bool equals(object o) { return o is SortedMap && ((SortedMap)o).size() == 0; }
            public int hashCode() { return 0; }
            public Comparator comparator() { return null; }
            public SortedMap subMap(object fromKey, object toKey) { return this; }
            public SortedMap headMap(object toKey) { return this; }
            public SortedMap tailMap(object fromKey) { return this; }
            public object firstKey() { throw new InvalidOperationException(); }
            public object lastKey() { throw new InvalidOperationException(); }
        }

        private class EmptyNavigableMap : NavigableMap
        {
            public int size() { return 0; }
            public bool isEmpty() { return true; }
            public bool containsKey(object key) { return false; }
            public bool containsValue(object value) { return false; }
            public object get(object key) { return null; }
            public object put(object key, object value) { throw new NotSupportedException(); }
            public object remove(object key) { throw new NotSupportedException(); }
            public void putAll(Map m) { throw new NotSupportedException(); }
            public void clear() { }
            public Set keySet() { return emptySet(); }
            public Collection values() { return emptyList(); }
            public Set entrySet() { return emptySet(); }
            public bool equals(object o) { return o is NavigableMap && ((NavigableMap)o).size() == 0; }
            public int hashCode() { return 0; }
            public Comparator comparator() { return null; }
            public SortedMap subMap(object fromKey, object toKey) { return this; }
            public SortedMap headMap(object toKey) { return this; }
            public SortedMap tailMap(object fromKey) { return this; }
            public object firstKey() { throw new InvalidOperationException(); }
            public object lastKey() { throw new InvalidOperationException(); }
            public object lowerKey(object key) { return null; }
            public object floorKey(object key) { return null; }
            public object ceilingKey(object key) { return null; }
            public object higherKey(object key) { return null; }
            public object firstEntry() { return null; }
            public object lastEntry() { return null; }
            public object pollFirstEntry() { return null; }
            public object pollLastEntry() { return null; }
            public NavigableMap descendingMap() { return this; }
            public NavigableMap subMap(object fromKey, bool fromInclusive, object toKey, bool toInclusive) { return this; }
            public NavigableMap headMap(object toKey, bool inclusive) { return this; }
            public NavigableMap tailMap(object fromKey, bool inclusive) { return this; }
        }

        private class SingletonSet : Set
        {
            private object element;
            public SingletonSet(object o) { element = o; }
            public int size() { return 1; }
            public bool isEmpty() { return false; }
            public bool contains(object o) { return Equals(o, element); }
            public object[] toArray() { return new object[] { element }; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { foreach (object o in c) if (!Equals(o, element)) return false; return true; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public bool equals(object o) { if (!(o is Set)) return false; Set s = (Set)o; return s.size() == 1 && s.contains(element); }
            public int hashCode() { return element == null ? 0 : element.GetHashCode(); }
            public IEnumerator GetEnumerator() { yield return element; }
        }

        private class SingletonList : List
        {
            private object element;
            public SingletonList(object o) { element = o; }
            public int size() { return 1; }
            public bool isEmpty() { return false; }
            public bool contains(object o) { return Equals(o, element); }
            public object[] toArray() { return new object[] { element }; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { foreach (object o in c) if (!Equals(o, element)) return false; return true; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public bool equals(object o) { if (!(o is List)) return false; List l = (List)o; return l.size() == 1 && Equals(l.get(0), element); }
            public int hashCode() { return element == null ? 0 : element.GetHashCode(); }
            public object get(int index) { if (index != 0) throw new IndexOutOfRangeException(); return element; }
            public object set(int index, object element) { throw new NotSupportedException(); }
            public void add(int index, object element) { throw new NotSupportedException(); }
            public object remove(int index) { throw new NotSupportedException(); }
            public int indexOf(object o) { return Equals(o, element) ? 0 : -1; }
            public int lastIndexOf(object o) { return Equals(o, element) ? 0 : -1; }
            public List subList(int fromIndex, int toIndex) { if (fromIndex == 0 && toIndex == 1) return this; throw new IndexOutOfRangeException(); }
            public IEnumerator GetEnumerator() { yield return element; }
        }

        private class SingletonMap : Map
        {
            private object key;
            private object value;
            public SingletonMap(object k, object v) { key = k; value = v; }
            public int size() { return 1; }
            public bool isEmpty() { return false; }
            public bool containsKey(object k) { return Equals(k, key); }
            public bool containsValue(object v) { return Equals(v, value); }
            public object get(object k) { return Equals(k, key) ? value : null; }
            public object put(object k, object v) { throw new NotSupportedException(); }
            public object remove(object k) { throw new NotSupportedException(); }
            public void putAll(Map m) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public Set keySet() { return singleton(key); }
            public Collection values() { return singletonList(value); }
            public Set entrySet() { return singleton(new SimpleEntry(key, value)); }
            public bool equals(object o) { if (!(o is Map)) return false; Map m = (Map)o; return m.size() == 1 && Equals(m.get(key), value); }
            public int hashCode() { return (key == null ? 0 : key.GetHashCode()) ^ (value == null ? 0 : value.GetHashCode()); }
        }

        private class SimpleEntry
        {
            public object Key { get; set; }
            public object Value { get; set; }
            public SimpleEntry(object k, object v) { Key = k; Value = v; }
        }

        private class NCopiesList : List
        {
            private int n;
            private object element;
            public NCopiesList(int n, object o) { this.n = n; element = o; }
            public int size() { return n; }
            public bool isEmpty() { return n == 0; }
            public bool contains(object o) { return n > 0 && Equals(o, element); }
            public object[] toArray() { object[] arr = new object[n]; for (int i = 0; i < n; i++) arr[i] = element; return arr; }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection c) { foreach (object o in c) if (!Equals(o, element)) return false; return true; }
            public bool addAll(Collection c) { throw new NotSupportedException(); }
            public bool removeAll(Collection c) { throw new NotSupportedException(); }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public bool equals(object o) { if (!(o is List)) return false; List l = (List)o; if (l.size() != n) return false; for (int i = 0; i < n; i++) if (!Equals(l.get(i), element)) return false; return true; }
            public int hashCode() { return n * (element == null ? 0 : element.GetHashCode()); }
            public object get(int index) { if (index < 0 || index >= n) throw new IndexOutOfRangeException(); return element; }
            public object set(int index, object element) { throw new NotSupportedException(); }
            public void add(int index, object element) { throw new NotSupportedException(); }
            public object remove(int index) { throw new NotSupportedException(); }
            public int indexOf(object o) { return Equals(o, element) ? 0 : -1; }
            public int lastIndexOf(object o) { return Equals(o, element) ? n - 1 : -1; }
            public List subList(int fromIndex, int toIndex) { return new NCopiesList(toIndex - fromIndex, element); }
            public IEnumerator GetEnumerator() { for (int i = 0; i < n; i++) yield return element; }
        }

        private class SetFromMap : Set
        {
            private Map map;
            public SetFromMap(Map m) { map = m; }
            public int size() { return map.size(); }
            public bool isEmpty() { return map.isEmpty(); }
            public bool contains(object o) { return map.containsKey(o); }
            public object[] toArray() { return map.keySet().toArray(); }
            public bool add(object e) { return map.put(e, Boolean.True) == null; }
            public bool remove(object o) { return map.remove(o) != null; }
            public bool containsAll(Collection c) { foreach (object o in c) if (!contains(o)) return false; return true; }
            public bool addAll(Collection c) { bool changed = false; foreach (object o in c) changed |= add(o); return changed; }
            public bool removeAll(Collection c) { bool changed = false; foreach (object o in c) changed |= remove(o); return changed; }
            public bool retainAll(Collection c) { throw new NotSupportedException(); }
            public void clear() { map.clear(); }
            public bool equals(object o) { return map.keySet().equals(o); }
            public int hashCode() { return map.keySet().hashCode(); }
            public IEnumerator GetEnumerator() { return map.keySet().GetEnumerator(); }
        }

        private class UnmodifiableCollection : Collection
        {
            protected Collection c;
            public UnmodifiableCollection(Collection c) { this.c = c; }
            public int size() { return c.size(); }
            public bool isEmpty() { return c.isEmpty(); }
            public bool contains(object o) { return c.contains(o); }
            public object[] toArray() { return c.toArray(); }
            public bool add(object e) { throw new NotSupportedException(); }
            public bool remove(object o) { throw new NotSupportedException(); }
            public bool containsAll(Collection coll) { return c.containsAll(coll); }
            public bool addAll(Collection coll) { throw new NotSupportedException(); }
            public bool removeAll(Collection coll) { throw new NotSupportedException(); }
            public bool retainAll(Collection coll) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public bool equals(object o) { return c.equals(o); }
            public int hashCode() { return c.hashCode(); }
            public IEnumerator GetEnumerator() { return c.GetEnumerator(); }
        }

        private class UnmodifiableSet : UnmodifiableCollection, Set
        {
            public UnmodifiableSet(Set s) : base(s) { }
        }

        private class UnmodifiableList : UnmodifiableCollection, List
        {
            private List list;
            public UnmodifiableList(List l) : base(l) { list = l; }
            public object get(int index) { return list.get(index); }
            public object set(int index, object element) { throw new NotSupportedException(); }
            public void add(int index, object element) { throw new NotSupportedException(); }
            public object remove(int index) { throw new NotSupportedException(); }
            public int indexOf(object o) { return list.indexOf(o); }
            public int lastIndexOf(object o) { return list.lastIndexOf(o); }
            public List subList(int fromIndex, int toIndex) { return new UnmodifiableList(list.subList(fromIndex, toIndex)); }
        }

        private class UnmodifiableMap : Map
        {
            protected Map m;
            public UnmodifiableMap(Map m) { this.m = m; }
            public int size() { return m.size(); }
            public bool isEmpty() { return m.isEmpty(); }
            public bool containsKey(object key) { return m.containsKey(key); }
            public bool containsValue(object value) { return m.containsValue(value); }
            public object get(object key) { return m.get(key); }
            public object put(object key, object value) { throw new NotSupportedException(); }
            public object remove(object key) { throw new NotSupportedException(); }
            public void putAll(Map map) { throw new NotSupportedException(); }
            public void clear() { throw new NotSupportedException(); }
            public Set keySet() { return unmodifiableSet(m.keySet()); }
            public Collection values() { return unmodifiableCollection(m.values()); }
            public Set entrySet() { return unmodifiableSet(m.entrySet()); }
            public bool equals(object o) { return m.equals(o); }
            public int hashCode() { return m.hashCode(); }
        }

        private class UnmodifiableSortedMap : UnmodifiableMap, SortedMap
        {
            private SortedMap sm;
            public UnmodifiableSortedMap(SortedMap m) : base(m) { sm = m; }
            public Comparator comparator() { return sm.comparator(); }
            public SortedMap subMap(object fromKey, object toKey) { return new UnmodifiableSortedMap(sm.subMap(fromKey, toKey)); }
            public SortedMap headMap(object toKey) { return new UnmodifiableSortedMap(sm.headMap(toKey)); }
            public SortedMap tailMap(object fromKey) { return new UnmodifiableSortedMap(sm.tailMap(fromKey)); }
            public object firstKey() { return sm.firstKey(); }
            public object lastKey() { return sm.lastKey(); }
        }

        private class UnmodifiableNavigableMap : UnmodifiableSortedMap, NavigableMap
        {
            private NavigableMap nm;
            public UnmodifiableNavigableMap(NavigableMap m) : base(m) { nm = m; }
            public object lowerKey(object key) { return nm.lowerKey(key); }
            public object floorKey(object key) { return nm.floorKey(key); }
            public object ceilingKey(object key) { return nm.ceilingKey(key); }
            public object higherKey(object key) { return nm.higherKey(key); }
            public object firstEntry() { return nm.firstEntry(); }
            public object lastEntry() { return nm.lastEntry(); }
            public object pollFirstEntry() { throw new NotSupportedException(); }
            public object pollLastEntry() { throw new NotSupportedException(); }
            public NavigableMap descendingMap() { return new UnmodifiableNavigableMap(nm.descendingMap()); }
            public NavigableMap subMap(object fromKey, bool fromInclusive, object toKey, bool toInclusive) { return new UnmodifiableNavigableMap(nm.subMap(fromKey, fromInclusive, toKey, toInclusive)); }
            public NavigableMap headMap(object toKey, bool inclusive) { return new UnmodifiableNavigableMap(nm.headMap(toKey, inclusive)); }
            public NavigableMap tailMap(object fromKey, bool inclusive) { return new UnmodifiableNavigableMap(nm.tailMap(fromKey, inclusive)); }
        }

        private class UnmodifiableSortedSet : UnmodifiableSet, SortedSet
        {
            private SortedSet ss;
            public UnmodifiableSortedSet(SortedSet s) : base(s) { ss = s; }
            public Comparator comparator() { return ss.comparator(); }
            public SortedSet subSet(object fromElement, object toElement) { return new UnmodifiableSortedSet(ss.subSet(fromElement, toElement)); }
            public SortedSet headSet(object toElement) { return new UnmodifiableSortedSet(ss.headSet(toElement)); }
            public SortedSet tailSet(object fromElement) { return new UnmodifiableSortedSet(ss.tailSet(fromElement)); }
            public object first() { return ss.first(); }
            public object last() { return ss.last(); }
        }

        private class UnmodifiableNavigableSet : UnmodifiableSortedSet, NavigableSet
        {
            private NavigableSet ns;
            public UnmodifiableNavigableSet(NavigableSet s) : base(s) { ns = s; }
            public object lower(object e) { return ns.lower(e); }
            public object floor(object e) { return ns.floor(e); }
            public object ceiling(object e) { return ns.ceiling(e); }
            public object higher(object e) { return ns.higher(e); }
            public object pollFirst() { throw new NotSupportedException(); }
            public object pollLast() { throw new NotSupportedException(); }
            public NavigableSet descendingSet() { return new UnmodifiableNavigableSet(ns.descendingSet()); }
        }

        private class UnmodifiableSequencedCollection : UnmodifiableCollection, SequencedCollection
        {
            public UnmodifiableSequencedCollection(SequencedCollection c) : base(c) { }
        }

        private class UnmodifiableSequencedSet : UnmodifiableSet, SequencedSet
        {
            public UnmodifiableSequencedSet(SequencedSet s) : base(s) { }
        }

        private class UnmodifiableSequencedMap : UnmodifiableMap, SequencedMap
        {
            public UnmodifiableSequencedMap(SequencedMap m) : base(m) { }
        }

        private class SynchronizedCollection : Collection
        {
            protected Collection c;
            protected object mutex;
            public SynchronizedCollection(Collection c) { this.c = c; mutex = this; }
            public int size() { lock (mutex) return c.size(); }
            public bool isEmpty() { lock (mutex) return c.isEmpty(); }
            public bool contains(object o) { lock (mutex) return c.contains(o); }
            public object[] toArray() { lock (mutex) return c.toArray(); }
            public bool add(object e) { lock (mutex) return c.add(e); }
            public bool remove(object o) { lock (mutex) return c.remove(o); }
            public bool containsAll(Collection coll) { lock (mutex) return c.containsAll(coll); }
            public bool addAll(Collection coll) { lock (mutex) return c.addAll(coll); }
            public bool removeAll(Collection coll) { lock (mutex) return c.removeAll(coll); }
            public bool retainAll(Collection coll) { lock (mutex) return c.retainAll(coll); }
            public void clear() { lock (mutex) c.clear(); }
            public bool equals(object o) { lock (mutex) return c.equals(o); }
            public int hashCode() { lock (mutex) return c.hashCode(); }
            public IEnumerator GetEnumerator() { lock (mutex) return c.GetEnumerator(); }
        }

        private class SynchronizedSet : SynchronizedCollection, Set
        {
            public SynchronizedSet(Set s) : base(s) { }
        }

        private class SynchronizedList : SynchronizedCollection, List
        {
            private List list;
            public SynchronizedList(List l) : base(l) { list = l; }
            public object get(int index) { lock (mutex) return list.get(index); }
            public object set(int index, object element) { lock (mutex) return list.set(index, element); }
            public void add(int index, object element) { lock (mutex) list.add(index, element); }
            public object remove(int index) { lock (mutex) return list.remove(index); }
            public int indexOf(object o) { lock (mutex) return list.indexOf(o); }
            public int lastIndexOf(object o) { lock (mutex) return list.lastIndexOf(o); }
            public List subList(int fromIndex, int toIndex) { lock (mutex) return new SynchronizedList(list.subList(fromIndex, toIndex)); }
        }

        private class SynchronizedMap : Map
        {
            protected Map m;
            protected object mutex;
            public SynchronizedMap(Map m) { this.m = m; mutex = this; }
            public int size() { lock (mutex) return m.size(); }
            public bool isEmpty() { lock (mutex) return m.isEmpty(); }
            public bool containsKey(object key) { lock (mutex) return m.containsKey(key); }
            public bool containsValue(object value) { lock (mutex) return m.containsValue(value); }
            public object get(object key) { lock (mutex) return m.get(key); }
            public object put(object key, object value) { lock (mutex) return m.put(key, value); }
            public object remove(object key) { lock (mutex) return m.remove(key); }
            public void putAll(Map map) { lock (mutex) m.putAll(map); }
            public void clear() { lock (mutex) m.clear(); }
            public Set keySet() { lock (mutex) return new SynchronizedSet(m.keySet()); }
            public Collection values() { lock (mutex) return new SynchronizedCollection(m.values()); }
            public Set entrySet() { lock (mutex) return new SynchronizedSet(m.entrySet()); }
            public bool equals(object o) { lock (mutex) return m.equals(o); }
            public int hashCode() { lock (mutex) return m.hashCode(); }
        }

        private class SynchronizedSortedMap : SynchronizedMap, SortedMap
        {
            private SortedMap sm;
            public SynchronizedSortedMap(SortedMap m) : base(m) { sm = m; }
            public Comparator comparator() { lock (mutex) return sm.comparator(); }
            public SortedMap subMap(object fromKey, object toKey) { lock (mutex) return new SynchronizedSortedMap(sm.subMap(fromKey, toKey)); }
            public SortedMap headMap(object toKey) { lock (mutex) return new SynchronizedSortedMap(sm.headMap(toKey)); }
            public SortedMap tailMap(object fromKey) { lock (mutex) return new SynchronizedSortedMap(sm.tailMap(fromKey)); }
            public object firstKey() { lock (mutex) return sm.firstKey(); }
            public object lastKey() { lock (mutex) return sm.lastKey(); }
        }

        private class SynchronizedNavigableMap : SynchronizedSortedMap, NavigableMap
        {
            private NavigableMap nm;
            public SynchronizedNavigableMap(NavigableMap m) : base(m) { nm = m; }
            public object lowerKey(object key) { lock (mutex) return nm.lowerKey(key); }
            public object floorKey(object key) { lock (mutex) return nm.floorKey(key); }
            public object ceilingKey(object key) { lock (mutex) return nm.ceilingKey(key); }
            public object higherKey(object key) { lock (mutex) return nm.higherKey(key); }
            public object firstEntry() { lock (mutex) return nm.firstEntry(); }
            public object lastEntry() { lock (mutex) return nm.lastEntry(); }
            public object pollFirstEntry() { lock (mutex) return nm.pollFirstEntry(); }
            public object pollLastEntry() { lock (mutex) return nm.pollLastEntry(); }
            public NavigableMap descendingMap() { lock (mutex) return new SynchronizedNavigableMap(nm.descendingMap()); }
            public NavigableMap subMap(object fromKey, bool fromInclusive, object toKey, bool toInclusive) { lock (mutex) return new SynchronizedNavigableMap(nm.subMap(fromKey, fromInclusive, toKey, toInclusive)); }
            public NavigableMap headMap(object toKey, bool inclusive) { lock (mutex) return new SynchronizedNavigableMap(nm.headMap(toKey, inclusive)); }
            public NavigableMap tailMap(object fromKey, bool inclusive) { lock (mutex) return new SynchronizedNavigableMap(nm.tailMap(fromKey, inclusive)); }
        }

        private class SynchronizedSortedSet : SynchronizedSet, SortedSet
        {
            private SortedSet ss;
            public SynchronizedSortedSet(SortedSet s) : base(s) { ss = s; }
            public Comparator comparator() { lock (mutex) return ss.comparator(); }
            public SortedSet subSet(object fromElement, object toElement) { lock (mutex) return new SynchronizedSortedSet(ss.subSet(fromElement, toElement)); }
            public SortedSet headSet(object toElement) { lock (mutex) return new SynchronizedSortedSet(ss.headSet(toElement)); }
            public SortedSet tailSet(object fromElement) { lock (mutex) return new SynchronizedSortedSet(ss.tailSet(fromElement)); }
            public object first() { lock (mutex) return ss.first(); }
            public object last() { lock (mutex) return ss.last(); }
        }

        private class SynchronizedNavigableSet : SynchronizedSortedSet, NavigableSet
        {
            private NavigableSet ns;
            public SynchronizedNavigableSet(NavigableSet s) : base(s) { ns = s; }
            public object lower(object e) { lock (mutex) return ns.lower(e); }
            public object floor(object e) { lock (mutex) return ns.floor(e); }
            public object ceiling(object e) { lock (mutex) return ns.ceiling(e); }
            public object higher(object e) { lock (mutex) return ns.higher(e); }
            public object pollFirst() { lock (mutex) return ns.pollFirst(); }
            public object pollLast() { lock (mutex) return ns.pollLast(); }
            public NavigableSet descendingSet() { lock (mutex) return new SynchronizedNavigableSet(ns.descendingSet()); }
        }

        private class CheckedCollection : UnmodifiableCollection
        {
            private Class type;
            public CheckedCollection(Collection c, Class type) : base(c) { this.type = type; }
            public override bool add(object e) { CheckType(e); return c.add(e); }
            public override bool addAll(Collection coll) { foreach (object o in coll) CheckType(o); return c.addAll(coll); }
            private void CheckType(object o) { if (o != null && !type.getType().IsInstanceOfType(o)) throw new ArgumentException("Invalid type"); }
        }

        private class CheckedQueue : CheckedCollection, Queue
        {
            private Queue q;
            public CheckedQueue(Queue q, Class type) : base(q, type) { this.q = q; }
            public bool offer(object e) { CheckType(e); return q.offer(e); }
            public object poll() { return q.poll(); }
            public object peek() { return q.peek(); }
        }

        private class CheckedSet : CheckedCollection, Set
        {
            public CheckedSet(Set s, Class type) : base(s, type) { }
        }

        private class CheckedSortedSet : CheckedSet, SortedSet
        {
            private SortedSet ss;
            public CheckedSortedSet(SortedSet s, Class type) : base(s, type) { ss = s; }
            public Comparator comparator() { return ss.comparator(); }
            public SortedSet subSet(object fromElement, object toElement) { return new CheckedSortedSet(ss.subSet(fromElement, toElement), type); }
            public SortedSet headSet(object toElement) { return new CheckedSortedSet(ss.headSet(toElement), type); }
            public SortedSet tailSet(object fromElement) { return new CheckedSortedSet(ss.tailSet(fromElement), type); }
            public object first() { return ss.first(); }
            public object last() { return ss.last(); }
        }

        private class CheckedNavigableSet : CheckedSortedSet, NavigableSet
        {
            private NavigableSet ns;
            public CheckedNavigableSet(NavigableSet s, Class type) : base(s, type) { ns = s; }
            public object lower(object e) { return ns.lower(e); }
            public object floor(object e) { return ns.floor(e); }
            public object ceiling(object e) { return ns.ceiling(e); }
            public object higher(object e) { return ns.higher(e); }
            public object pollFirst() { return ns.pollFirst(); }
            public object pollLast() { return ns.pollLast(); }
            public NavigableSet descendingSet() { return new CheckedNavigableSet(ns.descendingSet(), type); }
        }

        private class CheckedList : CheckedCollection, List
        {
            private List list;
            public CheckedList(List l, Class type) : base(l, type) { list = l; }
            public object get(int index) { return list.get(index); }
            public object set(int index, object element) { CheckType(element); return list.set(index, element); }
            public void add(int index, object element) { CheckType(element); list.add(index, element); }
            public object remove(int index) { return list.remove(index); }
            public int indexOf(object o) { return list.indexOf(o); }
            public int lastIndexOf(object o) { return list.lastIndexOf(o); }
            public List subList(int fromIndex, int toIndex) { return new CheckedList(list.subList(fromIndex, toIndex), type); }
        }

        private class CheckedMap : Map
        {
            private Map m;
            private Class keyType;
            private Class valueType;
            public CheckedMap(Map m, Class keyType, Class valueType) { this.m = m; this.keyType = keyType; this.valueType = valueType; }
            public int size() { return m.size(); }
            public bool isEmpty() { return m.isEmpty(); }
            public bool containsKey(object key) { return m.containsKey(key); }
            public bool containsValue(object value) { return m.containsValue(value); }
            public object get(object key) { return m.get(key); }
            public object put(object key, object value) { CheckKey(key); CheckValue(value); return m.put(key, value); }
            public object remove(object key) { return m.remove(key); }
            public void putAll(Map map) { foreach (var entry in map.entrySet()) { var e = (SimpleEntry)entry; CheckKey(e.Key); CheckValue(e.Value); } m.putAll(map); }
            public void clear() { m.clear(); }
            public Set keySet() { return m.keySet(); }
            public Collection values() { return m.values(); }
            public Set entrySet() { return m.entrySet(); }
            public bool equals(object o) { return m.equals(o); }
            public int hashCode() { return m.hashCode(); }
            private void CheckKey(object key) { if (key != null && !keyType.getType().IsInstanceOfType(key)) throw new ArgumentException("Invalid key type"); }
            private void CheckValue(object value) { if (value != null && !valueType.getType().IsInstanceOfType(value)) throw new ArgumentException("Invalid value type"); }
        }

        private class CheckedSortedMap : CheckedMap, SortedMap
        {
            private SortedMap sm;
            public CheckedSortedMap(SortedMap m, Class keyType, Class valueType) : base(m, keyType, valueType) { sm = m; }
            public Comparator comparator() { return sm.comparator(); }
            public SortedMap subMap(object fromKey, object toKey) { return new CheckedSortedMap(sm.subMap(fromKey, toKey), keyType, valueType); }
            public SortedMap headMap(object toKey) { return new CheckedSortedMap(sm.headMap(toKey), keyType, valueType); }
            public SortedMap tailMap(object fromKey) { return new CheckedSortedMap(sm.tailMap(fromKey), keyType, valueType); }
            public object firstKey() { return sm.firstKey(); }
            public object lastKey() { return sm.lastKey(); }
        }

        private class CheckedNavigableMap : CheckedSortedMap, NavigableMap
        {
            private NavigableMap nm;
            public CheckedNavigableMap(NavigableMap m, Class keyType, Class valueType) : base(m, keyType, valueType) { nm = m; }
            public object lowerKey(object key) { return nm.lowerKey(key); }
            public object floorKey(object key) { return nm.floorKey(key); }
            public object ceilingKey(object key) { return nm.ceilingKey(key); }
            public object higherKey(object key) { return nm.higherKey(key); }
            public object firstEntry() { return nm.firstEntry(); }
            public object lastEntry() { return nm.lastEntry(); }
            public object pollFirstEntry() { return nm.pollFirstEntry(); }
            public object pollLastEntry() { return nm.pollLastEntry(); }
            public NavigableMap descendingMap() { return new CheckedNavigableMap(nm.descendingMap(), keyType, valueType); }
            public NavigableMap subMap(object fromKey, bool fromInclusive, object toKey, bool toInclusive) { return new CheckedNavigableMap(nm.subMap(fromKey, fromInclusive, toKey, toInclusive), keyType, valueType); }
            public NavigableMap headMap(object toKey, bool inclusive) { return new CheckedNavigableMap(nm.headMap(toKey, inclusive), keyType, valueType); }
            public NavigableMap tailMap(object fromKey, bool inclusive) { return new CheckedNavigableMap(nm.tailMap(fromKey, inclusive), keyType, valueType); }
        }

        private class LifoQueue : Queue
        {
            private Deque deque;
            public LifoQueue(Deque d) { deque = d; }
            public int size() { return deque.size(); }
            public bool isEmpty() { return deque.isEmpty(); }
            public bool contains(object o) { return deque.contains(o); }
            public object[] toArray() { return deque.toArray(); }
            public bool add(object e) { return deque.add(e); }
            public bool remove(object o) { return deque.remove(o); }
            public bool containsAll(Collection c) { return deque.containsAll(c); }
            public bool addAll(Collection c) { return deque.addAll(c); }
            public bool removeAll(Collection c) { return deque.removeAll(c); }
            public bool retainAll(Collection c) { return deque.retainAll(c); }
            public void clear() { deque.clear(); }
            public bool equals(object o) { return deque.equals(o); }
            public int hashCode() { return deque.hashCode(); }
            public bool offer(object e) { return deque.offerFirst(e); }
            public object poll() { return deque.pollFirst(); }
            public object peek() { return deque.peekFirst(); }
            public IEnumerator GetEnumerator() { return deque.GetEnumerator(); }
        }
    }

    // Simple ArrayList implementation for testing
    public class ArrayList : List
    {
        private List<object> items = new List<object>();
        public int size() { return items.Count; }
        public bool isEmpty() { return items.Count == 0; }
        public bool contains(object o) { return items.Contains(o); }
        public object[] toArray() { return items.ToArray(); }
        public bool add(object e) { items.Add(e); return true; }
        public bool remove(object o) { return items.Remove(o); }
        public bool containsAll(Collection c) { foreach (object o in c) if (!items.Contains(o)) return false; return true; }
        public bool addAll(Collection c) { bool changed = false; foreach (object o in c) { items.Add(o); changed = true; } return changed; }
        public bool removeAll(Collection c) { bool changed = false; foreach (object o in c) changed |= items.Remove(o); return changed; }
        public bool retainAll(Collection c) { var toRemove = items.Where(x => !c.contains(x)).ToList(); foreach (var o in toRemove) items.Remove(o); return toRemove.Count > 0; }
        public void clear() { items.Clear(); }
        public bool equals(object o) { if (!(o is List)) return false; List l = (List)o; if (l.size() != items.Count) return false; for (int i = 0; i < items.Count; i++) if (!Equals(items[i], l.get(i))) return false; return true; }
        public int hashCode() { int h = 1; foreach (var o in items) h = 31 * h + (o == null ? 0 : o.GetHashCode()); return h; }
        public object get(int index) { return items[index]; }
        public object set(int index, object element) { object old = items[index]; items[index] = element; return old; }
        public void add(int index, object element) { items.Insert(index, element); }
        public object remove(int index) { object old = items[index]; items.RemoveAt(index); return old; }
        public int indexOf(object o) { return items.IndexOf(o); }
        public int lastIndexOf(object o) { return items.LastIndexOf(o); }
        public List subList(int fromIndex, int toIndex) { ArrayList sub = new ArrayList(); for (int i = fromIndex; i < toIndex; i++) sub.add(items[i]); return sub; }
        public IEnumerator GetEnumerator() { return items.GetEnumerator(); }
    }

    // Boolean helper class
    public static class Boolean
    {
        public static readonly object True = new object();
        public static readonly object False = new object();
    }
}