using System;
using System.Collections.Generic;
using System.Text;

namespace Generated.Test
{
    public class Charset
    {
        private string name;
        private static Dictionary<string, Charset> charsets = new Dictionary<string, Charset>();
        private static Charset defaultCharset = new Charset("UTF-8");

        static Charset()
        {
            // Register common charsets
            RegisterCharset(new Charset("UTF-8"));
            RegisterCharset(new Charset("UTF-16"));
            RegisterCharset(new Charset("ISO-8859-1"));
            RegisterCharset(new Charset("US-ASCII"));
            RegisterCharset(new Charset("UTF-16BE"));
            RegisterCharset(new Charset("UTF-16LE"));
        }

        private Charset(string name)
        {
            this.name = name;
        }

        private static void RegisterCharset(Charset charset)
        {
            charsets[charset.name] = charset;
        }

        public static Charset ForName(string charsetName, Charset fallback)
        {
            if (charsetName == null)
                throw new ArgumentNullException("charsetName");
            
            Charset result;
            if (charsets.TryGetValue(charsetName, out result))
                return result;
            
            if (fallback != null)
                return fallback;
            
            throw new ArgumentException("Unsupported charset: " + charsetName);
        }

        public static Charset ForName(string charsetName)
        {
            return ForName(charsetName, null);
        }

        public static Charset DefaultCharset()
        {
            return defaultCharset;
        }

        public static bool IsSupported(string charsetName)
        {
            if (charsetName == null)
                return false;
            return charsets.ContainsKey(charsetName);
        }

        public static Dictionary<string, Charset> AvailableCharsets()
        {
            return new Dictionary<string, Charset>(charsets);
        }

        public string Name()
        {
            return name;
        }

        public override string ToString()
        {
            return name;
        }
    }

    public class java_nio_charset_CharsetAutoTest
    {
        public void forName_test_2235(string p0, Charset p1)
        {
            Charset.ForName(p0, p1);
        }

        public void forName_test_2236(string p0)
        {
            Charset.ForName(p0);
        }

        public void defaultCharset_test_2237()
        {
            Charset.DefaultCharset();
        }

        public void isSupported_test_2238(string p0)
        {
            Charset.IsSupported(p0);
        }

        public void availableCharsets_test_2239()
        {
            Charset.AvailableCharsets();
        }
    }
}