using System;
using System.Collections.Generic;
using Generated.Test;

namespace Generated.Test
{
    // DateTimeFormatter equivalent
    public class DateTimeFormatter
    {
        public static DateTimeFormatter ISO_OFFSET_DATE_TIME = new DateTimeFormatter();
        public static DateTimeFormatter ISO_LOCAL_DATE_TIME = new DateTimeFormatter();
        
        public string Format(TemporalAccessor temporal)
        {
            return temporal.ToString();
        }
        
        public TemporalAccessor Parse(string text)
        {
            return TemporalAccessor.Parse(text);
        }
    }
    
    // TemporalAccessor equivalent
    public class TemporalAccessor
    {
        public virtual string ToString()
        {
            return "";
        }
        
        public static TemporalAccessor Parse(string text)
        {
            return new TemporalAccessor();
        }
    }
    
    // ZoneOffset equivalent
    public class ZoneOffset
    {
        public static ZoneOffset UTC = new ZoneOffset(0);
        public int TotalSeconds { get; }
        
        public ZoneOffset(int totalSeconds)
        {
            TotalSeconds = totalSeconds;
        }
        
        public static ZoneOffset OfHours(int hours)
        {
            return new ZoneOffset(hours * 3600);
        }
        
        public static ZoneOffset OfHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(hours * 3600 + minutes * 60);
        }
        
        public static ZoneOffset OfTotalSeconds(int totalSeconds)
        {
            return new ZoneOffset(totalSeconds);
        }
        
        public override string ToString()
        {
            int hours = TotalSeconds / 3600;
            int minutes = (Math.Abs(TotalSeconds) % 3600) / 60;
            int seconds = Math.Abs(TotalSeconds) % 60;
            
            if (TotalSeconds == 0) return "Z";
            if (seconds == 0 && minutes == 0) return string.Format("{0}{1:D2}:00", hours >= 0 ? "+" : "-", Math.Abs(hours));
            if (seconds == 0) return string.Format("{0}{1:D2}:{2:D2}", hours >= 0 ? "+" : "-", Math.Abs(hours), minutes);
            return string.Format("{0}{1:D2}:{2:D2}:{3:D2}", hours >= 0 ? "+" : "-", Math.Abs(hours), minutes, seconds);
        }
    }
    
    // ZoneId equivalent
    public class ZoneId
    {
        public string Id { get; }
        
        public ZoneId(string id)
        {
            Id = id;
        }
        
        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }
        
        public static ZoneId Of(string zoneId)
        {
            return new ZoneId(zoneId);
        }
        
        public override string ToString()
        {
            return Id;
        }
    }
    
    // Clock equivalent
    public class Clock
    {
        public virtual Instant Instant()
        {
            return Instant.Now();
        }
        
        public virtual ZoneId Zone()
        {
            return ZoneId.SystemDefault();
        }
        
        public static Clock SystemUTC()
        {
            return new Clock();
        }
        
        public static Clock SystemDefaultZone()
        {
            return new Clock();
        }
    }
    
    // Instant equivalent
    public class Instant
    {
        public long EpochSecond { get; }
        public int Nano { get; }
        
        public Instant(long epochSecond, int nano)
        {
            EpochSecond = epochSecond;
            Nano = nano;
        }
        
        public static Instant Now()
        {
            DateTime utcNow = DateTime.UtcNow;
            long epochSecond = (long)(utcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            int nano = utcNow.Millisecond * 1000000;
            return new Instant(epochSecond, nano);
        }
        
        public static Instant OfEpochSecond(long epochSecond)
        {
            return new Instant(epochSecond, 0);
        }
        
        public static Instant OfEpochMilli(long epochMilli)
        {
            return new Instant(epochMilli / 1000, (int)(epochMilli % 1000) * 1000000);
        }
        
        public long ToEpochMilli()
        {
            return EpochSecond * 1000 + Nano / 1000000;
        }
        
        public override string ToString()
        {
            DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(EpochSecond);
            return dt.ToString("yyyy-MM-dd'T'HH:mm:ss") + "." + (Nano / 1000000).ToString("D3") + "Z";
        }
    }
    
    // LocalDate equivalent
    public class LocalDate
    {
        public int Year { get; }
        public int Month { get; }
        public int Day { get; }
        
        public LocalDate(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }
        
        public static LocalDate Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDate(now.Year, now.Month, now.Day);
        }
        
        public static LocalDate Of(int year, int month, int day)
        {
            return new LocalDate(year, month, day);
        }
        
        public override string ToString()
        {
            return string.Format("{0:D4}-{1:D2}-{2:D2}", Year, Month, Day);
        }
    }
    
    // LocalTime equivalent
    public class LocalTime
    {
        public int Hour { get; }
        public int Minute { get; }
        public int Second { get; }
        public int Nano { get; }
        
        public LocalTime(int hour, int minute, int second, int nano)
        {
            Hour = hour;
            Minute = minute;
            Second = second;
            Nano = nano;
        }
        
        public static LocalTime Now()
        {
            DateTime now = DateTime.Now;
            return new LocalTime(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }
        
        public static LocalTime Of(int hour, int minute, int second, int nano)
        {
            return new LocalTime(hour, minute, second, nano);
        }
        
        public override string ToString()
        {
            return string.Format("{0:D2}:{1:D2}:{2:D2}", Hour, Minute, Second);
        }
    }
    
    // LocalDateTime equivalent
    public class LocalDateTime
    {
        public LocalDate Date { get; }
        public LocalTime Time { get; }
        
        public LocalDateTime(LocalDate date, LocalTime time)
        {
            Date = date;
            Time = time;
        }
        
        public LocalDateTime(int year, int month, int day, int hour, int minute, int second, int nano)
        {
            Date = new LocalDate(year, month, day);
            Time = new LocalTime(hour, minute, second, nano);
        }
        
        public static LocalDateTime Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }
        
        public static LocalDateTime Of(LocalDate date, LocalTime time)
        {
            return new LocalDateTime(date, time);
        }
        
        public static LocalDateTime Of(int year, int month, int day, int hour, int minute, int second, int nano)
        {
            return new LocalDateTime(year, month, day, hour, minute, second, nano);
        }
        
        public override string ToString()
        {
            return Date.ToString() + "T" + Time.ToString();
        }
    }
    
    // OffsetDateTime equivalent
    public class OffsetDateTime
    {
        public LocalDateTime DateTime { get; }
        public ZoneOffset Offset { get; }
        
        public OffsetDateTime(LocalDateTime dateTime, ZoneOffset offset)
        {
            DateTime = dateTime;
            Offset = offset;
        }
        
        public static OffsetDateTime Of(LocalDateTime dateTime, ZoneOffset offset)
        {
            return new OffsetDateTime(dateTime, offset);
        }
        
        public static OffsetDateTime Of(int year, int month, int day, int hour, int minute, int second, int nano, ZoneOffset offset)
        {
            return new OffsetDateTime(new LocalDateTime(year, month, day, hour, minute, second, nano), offset);
        }
        
        public static OffsetDateTime Of(LocalDate date, LocalTime time, ZoneOffset offset)
        {
            return new OffsetDateTime(new LocalDateTime(date, time), offset);
        }
        
        public static OffsetDateTime From(TemporalAccessor temporal)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime Parse(string text, DateTimeFormatter formatter)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime Parse(string text)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime Now()
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime Now(Clock clock)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime Now(ZoneId zone)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static OffsetDateTime OfInstant(Instant instant, ZoneId zone)
        {
            return new OffsetDateTime(LocalDateTime.Now(), ZoneOffset.UTC);
        }
        
        public static IComparer<OffsetDateTime> TimeLineOrder()
        {
            return new OffsetDateTimeComparer();
        }
        
        public override string ToString()
        {
            return DateTime.ToString() + Offset.ToString();
        }
        
        private class OffsetDateTimeComparer : IComparer<OffsetDateTime>
        {
            public int Compare(OffsetDateTime x, OffsetDateTime y)
            {
                if (x == null && y == null) return 0;
                if (x == null) return -1;
                if (y == null) return 1;
                
                // Compare by instant (convert to UTC)
                DateTime xUtc = new DateTime(x.DateTime.Date.Year, x.DateTime.Date.Month, x.DateTime.Date.Day,
                    x.DateTime.Time.Hour, x.DateTime.Time.Minute, x.DateTime.Time.Second, DateTimeKind.Utc)
                    .AddSeconds(-x.Offset.TotalSeconds);
                DateTime yUtc = new DateTime(y.DateTime.Date.Year, y.DateTime.Date.Month, y.DateTime.Date.Day,
                    y.DateTime.Time.Hour, y.DateTime.Time.Minute, y.DateTime.Time.Second, DateTimeKind.Utc)
                    .AddSeconds(-y.Offset.TotalSeconds);
                
                return xUtc.CompareTo(yUtc);
            }
        }
    }
    
    // Test class
    public class java_time_OffsetDateTimeAutoTest
    {
        public void of_test_9640(LocalDateTime p0, ZoneOffset p1)
        {
            OffsetDateTime.Of(p0, p1);
        }
        
        public void of_test_9641(int p0, int p1, int p2, int p3, int p4, int p5, int p6, ZoneOffset p7)
        {
            OffsetDateTime.Of(p0, p1, p2, p3, p4, p5, p6, p7);
        }
        
        public void of_test_9642(LocalDate p0, LocalTime p1, ZoneOffset p2)
        {
            OffsetDateTime.Of(p0, p1, p2);
        }
        
        public void from_test_9643(TemporalAccessor p0)
        {
            OffsetDateTime.From(p0);
        }
        
        public void parse_test_9644(string p0, DateTimeFormatter p1)
        {
            OffsetDateTime.Parse(p0, p1);
        }
        
        public void parse_test_9645(string p0)
        {
            OffsetDateTime.Parse(p0);
        }
        
        public void now_test_9646()
        {
            OffsetDateTime.Now();
        }
        
        public void now_test_9647(Clock p0)
        {
            OffsetDateTime.Now(p0);
        }
        
        public void now_test_9648(ZoneId p0)
        {
            OffsetDateTime.Now(p0);
        }
        
        public void ofInstant_test_9649(Instant p0, ZoneId p1)
        {
            OffsetDateTime.OfInstant(p0, p1);
        }
        
        public void timeLineOrder_test_9650()
        {
            OffsetDateTime.TimeLineOrder();
        }
    }
}