namespace Generated.Test
{
    public class java_awt_im_InputContextAutoTest
    {
        public void getInstance_test_5830()
        {
            InputContext.GetInstance();
        }
    }

    public class InputContext
    {
        public static InputContext GetInstance()
        {
            return new InputContext();
        }
    }
}