namespace Generated.Test
{
    public class java_time_temporal_TemporalQueriesAutoTest
    {
        public void offset_test_12534()
        {
            TemporalQueries.Offset();
        }

        public void zone_test_12535()
        {
            TemporalQueries.Zone();
        }

        public void precision_test_12536()
        {
            TemporalQueries.Precision();
        }

        public void chronology_test_12537()
        {
            TemporalQueries.Chronology();
        }

        public void zoneId_test_12538()
        {
            TemporalQueries.ZoneId();
        }

        public void localDate_test_12539()
        {
            TemporalQueries.LocalDate();
        }

        public void localTime_test_12540()
        {
            TemporalQueries.LocalTime();
        }
    }

    public static class TemporalQueries
    {
        public static object Offset()
        {
            return null;
        }

        public static object Zone()
        {
            return null;
        }

        public static object Precision()
        {
            return null;
        }

        public static object Chronology()
        {
            return null;
        }

        public static object ZoneId()
        {
            return null;
        }

        public static object LocalDate()
        {
            return null;
        }

        public static object LocalTime()
        {
            return null;
        }
    }
}