using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Generated.Test
{
    // C# equivalent of java.awt.Graphics (minimal stub)
    public class Graphics
    {
    }

    // C# equivalent of java.awt.Rectangle (minimal stub)
    public class Rectangle
    {
    }

    // C# equivalent of java.beans.PropertyChangeListener
    public interface PropertyChangeListener
    {
        void PropertyChange(object evt);
    }

    // C# equivalent of java.beans.PropertyEditorSupport
    public class PropertyEditorSupport
    {
        private object source;
        private object value;
        private List<PropertyChangeListener> listeners = new List<PropertyChangeListener>();

        public PropertyEditorSupport()
        {
        }

        public PropertyEditorSupport(object source)
        {
            this.source = source;
        }

        public void FirePropertyChange()
        {
            // Fire property change event to all listeners
            foreach (var listener in listeners)
            {
                listener.PropertyChange(new PropertyChangedEventArgs("value"));
            }
        }

        public void AddPropertyChangeListener(PropertyChangeListener listener)
        {
            if (listener != null && !listeners.Contains(listener))
            {
                listeners.Add(listener);
            }
        }

        public void RemovePropertyChangeListener(PropertyChangeListener listener)
        {
            if (listener != null)
            {
                listeners.Remove(listener);
            }
        }

        public void SetSource(object source)
        {
            this.source = source;
        }

        public object GetSource()
        {
            return source;
        }

        public bool IsPaintable()
        {
            return false;
        }

        public void PaintValue(Graphics gfx, Rectangle box)
        {
            // Default implementation does nothing
        }

        public string GetJavaInitializationString()
        {
            return "null";
        }

        public string GetAsText()
        {
            return value != null ? value.ToString() : "null";
        }

        public void SetAsText(string text)
        {
            if (text == null)
            {
                value = null;
            }
            else
            {
                value = text;
            }
        }

        public string[] GetTags()
        {
            return null;
        }

        public object GetCustomEditor()
        {
            return null;
        }

        public bool SupportsCustomEditor()
        {
            return false;
        }

        public object GetValue()
        {
            return value;
        }

        public void SetValue(object value)
        {
            this.value = value;
            FirePropertyChange();
        }
    }

    public class java_beans_PropertyEditorSupportAutoTest
    {
        public void firePropertyChange_test_10182()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.FirePropertyChange();
        }

        public void addPropertyChangeListener_test_10183(PropertyChangeListener p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.AddPropertyChangeListener(p0);
        }

        public void removePropertyChangeListener_test_10184(PropertyChangeListener p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.RemovePropertyChangeListener(p0);
        }

        public void setSource_test_10185(object p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.SetSource(p0);
        }

        public void isPaintable_test_10186()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.IsPaintable();
        }

        public void paintValue_test_10187(Graphics p0, Rectangle p1)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.PaintValue(p0, p1);
        }

        public void getJavaInitializationString_test_10188()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetJavaInitializationString();
        }

        public void getAsText_test_10189()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetAsText();
        }

        public void setAsText_test_10190(string p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.SetAsText(p0);
        }

        public void getTags_test_10191()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetTags();
        }

        public void getCustomEditor_test_10192()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetCustomEditor();
        }

        public void supportsCustomEditor_test_10193()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.SupportsCustomEditor();
        }

        public void getValue_test_10194()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetValue();
        }

        public void setValue_test_10195(object p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.SetValue(p0);
        }

        public void getSource_test_10196()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.GetSource();
        }
    }
}