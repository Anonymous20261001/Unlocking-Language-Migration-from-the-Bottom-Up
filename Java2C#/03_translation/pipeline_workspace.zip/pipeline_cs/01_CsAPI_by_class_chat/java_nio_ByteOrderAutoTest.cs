namespace Generated.Test
{
    public class java_nio_ByteOrderAutoTest
    {
        public void nativeOrder_test_2007()
        {
            ByteOrder.NativeOrder();
        }
    }

    public class ByteOrder
    {
        public static ByteOrder NativeOrder()
        {
            return System.BitConverter.IsLittleEndian ? LittleEndian : BigEndian;
        }

        public static readonly ByteOrder BigEndian = new ByteOrder("BIG_ENDIAN");
        public static readonly ByteOrder LittleEndian = new ByteOrder("LITTLE_ENDIAN");

        private readonly string _name;

        private ByteOrder(string name)
        {
            _name = name;
        }

        public override string ToString()
        {
            return _name;
        }
    }
}