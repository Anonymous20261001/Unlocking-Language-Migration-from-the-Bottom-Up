using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Notification
    {
        public string Type { get; set; }
        public object Source { get; set; }
        public long SequenceNumber { get; set; }
        public long TimeStamp { get; set; }
        public string Message { get; set; }
        public object UserData { get; set; }

        public Notification(string type, object source, long sequenceNumber)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = DateTime.Now.Ticks;
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message, object userData)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
            UserData = userData;
        }
    }

    public class AttributeChangeNotificationFilter
    {
        private HashSet<string> enabledAttributes;

        public AttributeChangeNotificationFilter()
        {
            enabledAttributes = new HashSet<string>();
        }

        public bool IsNotificationEnabled(Notification notification)
        {
            if (notification == null)
            {
                return false;
            }

            if (notification is AttributeChangeNotification)
            {
                AttributeChangeNotification acn = (AttributeChangeNotification)notification;
                return enabledAttributes.Contains(acn.AttributeName);
            }

            return false;
        }

        public void EnableAttribute(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }
            enabledAttributes.Add(name);
        }

        public void DisableAttribute(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }
            enabledAttributes.Remove(name);
        }

        public void DisableAllAttributes()
        {
            enabledAttributes.Clear();
        }

        public string[] GetEnabledAttributes()
        {
            string[] result = new string[enabledAttributes.Count];
            enabledAttributes.CopyTo(result);
            return result;
        }
    }

    public class AttributeChangeNotification : Notification
    {
        public string AttributeName { get; private set; }
        public string AttributeType { get; private set; }
        public object OldValue { get; private set; }
        public object NewValue { get; private set; }

        public AttributeChangeNotification(object source, long sequenceNumber, long timeStamp, string msg, string attributeName, string attributeType, object oldValue, object newValue)
            : base("jmx.attribute.change", source, sequenceNumber, timeStamp, msg)
        {
            AttributeName = attributeName;
            AttributeType = attributeType;
            OldValue = oldValue;
            NewValue = newValue;
        }
    }

    public class javax_management_AttributeChangeNotificationFilterAutoTest
    {
        public void isNotificationEnabled_test_762(Notification p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.IsNotificationEnabled(p0);
        }

        public void enableAttribute_test_763(string p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.EnableAttribute(p0);
        }

        public void disableAttribute_test_764(string p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.DisableAttribute(p0);
        }

        public void disableAllAttributes_test_765()
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.DisableAllAttributes();
        }

        public void getEnabledAttributes_test_766()
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.GetEnabledAttributes();
        }
    }
}