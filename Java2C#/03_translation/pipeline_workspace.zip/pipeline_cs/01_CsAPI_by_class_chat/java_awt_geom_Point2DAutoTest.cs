namespace Generated.Test
{
    public class java_awt_geom_Point2DAutoTest
    {
        public void distanceSq_test_9956(double p0, double p1, double p2, double p3)
        {
            Point2D.DistanceSq(p0, p1, p2, p3);
        }

        public void distance_test_9957(double p0, double p1, double p2, double p3)
        {
            Point2D.Distance(p0, p1, p2, p3);
        }
    }

    public static class Point2D
    {
        public static double DistanceSq(double x1, double y1, double x2, double y2)
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            return dx * dx + dy * dy;
        }

        public static double Distance(double x1, double y1, double x2, double y2)
        {
            return System.Math.Sqrt(DistanceSq(x1, y1, x2, y2));
        }
    }
}