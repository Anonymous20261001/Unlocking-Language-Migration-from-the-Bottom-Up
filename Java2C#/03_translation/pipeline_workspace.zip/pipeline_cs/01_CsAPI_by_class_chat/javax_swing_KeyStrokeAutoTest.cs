namespace Generated.Test
{
    public class KeyEvent
    {
        // Minimal KeyEvent class to support the test
        public int KeyCode { get; set; }
        public int Modifiers { get; set; }
        public char KeyChar { get; set; }
        
        public KeyEvent(int keyCode, int modifiers, char keyChar)
        {
            KeyCode = keyCode;
            Modifiers = modifiers;
            KeyChar = keyChar;
        }
    }

    public class KeyStroke
    {
        private int _keyCode;
        private int _modifiers;
        private char _keyChar;
        private string _keyString;

        private KeyStroke(int keyCode, int modifiers, char keyChar, string keyString)
        {
            _keyCode = keyCode;
            _modifiers = modifiers;
            _keyChar = keyChar;
            _keyString = keyString;
        }

        public static KeyStroke GetKeyStrokeForEvent(KeyEvent anEvent)
        {
            return new KeyStroke(anEvent.KeyCode, anEvent.Modifiers, anEvent.KeyChar, null);
        }

        public static KeyStroke GetKeyStroke(char keyChar, bool onKeyRelease)
        {
            return new KeyStroke(0, onKeyRelease ? 1 : 0, keyChar, null);
        }

        public static KeyStroke GetKeyStroke(Character keyChar, int modifiers)
        {
            return new KeyStroke(0, modifiers, keyChar.Value, null);
        }

        public static KeyStroke GetKeyStroke(int keyCode, int modifiers)
        {
            return new KeyStroke(keyCode, modifiers, '\0', null);
        }

        public static KeyStroke GetKeyStroke(char keyChar)
        {
            return new KeyStroke(0, 0, keyChar, null);
        }

        public static KeyStroke GetKeyStroke(string keyStroke)
        {
            return new KeyStroke(0, 0, '\0', keyStroke);
        }

        public static KeyStroke GetKeyStroke(int keyCode, int modifiers, bool onKeyRelease)
        {
            return new KeyStroke(keyCode, modifiers | (onKeyRelease ? 1 : 0), '\0', null);
        }
    }

    public class Character
    {
        public char Value { get; private set; }
        
        public Character(char value)
        {
            Value = value;
        }
    }

    public class javax_swing_KeyStrokeAutoTest
    {
        public void getKeyStrokeForEvent_test_7655(KeyEvent p0)
        {
            KeyStroke.GetKeyStrokeForEvent(p0);
        }

        public void getKeyStroke_test_7656(char p0, bool p1)
        {
            KeyStroke.GetKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7657(Character p0, int p1)
        {
            KeyStroke.GetKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7658(int p0, int p1)
        {
            KeyStroke.GetKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7659(char p0)
        {
            KeyStroke.GetKeyStroke(p0);
        }

        public void getKeyStroke_test_7660(string p0)
        {
            KeyStroke.GetKeyStroke(p0);
        }

        public void getKeyStroke_test_7661(int p0, int p1, bool p2)
        {
            KeyStroke.GetKeyStroke(p0, p1, p2);
        }
    }
}