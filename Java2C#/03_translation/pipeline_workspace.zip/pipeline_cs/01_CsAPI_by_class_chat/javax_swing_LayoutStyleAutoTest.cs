namespace Generated.Test
{
    public class LayoutStyle
    {
        private static LayoutStyle _instance;

        public static void SetInstance(LayoutStyle instance)
        {
            _instance = instance;
        }

        public static LayoutStyle GetInstance()
        {
            return _instance;
        }
    }

    public class javax_swing_LayoutStyleAutoTest
    {
        public void setInstance_test_7711(LayoutStyle p0)
        {
            LayoutStyle.SetInstance(p0);
        }

        public void getInstance_test_7712()
        {
            LayoutStyle.GetInstance();
        }
    }
}