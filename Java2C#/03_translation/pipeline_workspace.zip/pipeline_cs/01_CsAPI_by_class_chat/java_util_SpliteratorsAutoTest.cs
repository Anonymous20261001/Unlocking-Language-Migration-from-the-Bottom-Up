using System;
using System.Collections;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface ISpliterator
    {
        bool TryAdvance(IConsumer action);
        ISpliterator TrySplit();
        long EstimateSize();
        int Characteristics();
    }

    public interface IConsumer
    {
        void Accept(object value);
    }

    public interface IOfInt : ISpliterator
    {
        bool TryAdvance(IConsumerInt action);
        IOfInt TrySplit();
    }

    public interface IConsumerInt
    {
        void Accept(int value);
    }

    public interface IOfLong : ISpliterator
    {
        bool TryAdvance(IConsumerLong action);
        IOfLong TrySplit();
    }

    public interface IConsumerLong
    {
        void Accept(long value);
    }

    public interface IOfDouble : ISpliterator
    {
        bool TryAdvance(IConsumerDouble action);
        IOfDouble TrySplit();
    }

    public interface IConsumerDouble
    {
        void Accept(double value);
    }

    public interface IPrimitiveIterator : IEnumerator
    {
    }

    public interface IPrimitiveIteratorOfInt : IPrimitiveIterator
    {
        int NextInt();
        bool HasNext();
    }

    public interface IPrimitiveIteratorOfLong : IPrimitiveIterator
    {
        long NextLong();
        bool HasNext();
    }

    public interface IPrimitiveIteratorOfDouble : IPrimitiveIterator
    {
        double NextDouble();
        bool HasNext();
    }

    public static class Spliterators
    {
        public static IEnumerator Iterator(ISpliterator spliterator)
        {
            return new SpliteratorIterator(spliterator);
        }

        public static IEnumerator Iterator(IOfInt spliterator)
        {
            return new SpliteratorIteratorInt(spliterator);
        }

        public static IEnumerator Iterator(IOfLong spliterator)
        {
            return new SpliteratorIteratorLong(spliterator);
        }

        public static IEnumerator Iterator(IOfDouble spliterator)
        {
            return new SpliteratorIteratorDouble(spliterator);
        }

        public static ISpliterator SpliteratorUnknownSize(IEnumerator iterator, int characteristics)
        {
            return new IteratorSpliterator(iterator, characteristics);
        }

        public static ISpliterator SpliteratorUnknownSize(IPrimitiveIteratorOfInt iterator, int characteristics)
        {
            return new IteratorSpliteratorInt(iterator, characteristics);
        }

        public static ISpliterator SpliteratorUnknownSize(IPrimitiveIteratorOfLong iterator, int characteristics)
        {
            return new IteratorSpliteratorLong(iterator, characteristics);
        }

        public static ISpliterator SpliteratorUnknownSize(IPrimitiveIteratorOfDouble iterator, int characteristics)
        {
            return new IteratorSpliteratorDouble(iterator, characteristics);
        }

        public static ISpliterator Spliterator(object[] array, int characteristics)
        {
            return new ArraySpliterator(array, characteristics);
        }

        public static ISpliterator Spliterator(IEnumerator iterator, long size, int characteristics)
        {
            return new IteratorSpliterator(iterator, size, characteristics);
        }

        public static ISpliterator Spliterator(ICollection collection, int characteristics)
        {
            return new CollectionSpliterator(collection, characteristics);
        }

        public static ISpliterator Spliterator(IPrimitiveIteratorOfInt iterator, long size, int characteristics)
        {
            return new IteratorSpliteratorInt(iterator, size, characteristics);
        }

        public static ISpliterator Spliterator(IPrimitiveIteratorOfLong iterator, long size, int characteristics)
        {
            return new IteratorSpliteratorLong(iterator, size, characteristics);
        }

        public static ISpliterator Spliterator(IPrimitiveIteratorOfDouble iterator, long size, int characteristics)
        {
            return new IteratorSpliteratorDouble(iterator, size, characteristics);
        }

        public static ISpliterator Spliterator(long[] array, int fromIndex, int toIndex, int characteristics)
        {
            return new LongArraySpliterator(array, fromIndex, toIndex, characteristics);
        }

        public static ISpliterator Spliterator(long[] array, int characteristics)
        {
            return new LongArraySpliterator(array, 0, array.Length, characteristics);
        }

        public static ISpliterator Spliterator(int[] array, int fromIndex, int toIndex, int characteristics)
        {
            return new IntArraySpliterator(array, fromIndex, toIndex, characteristics);
        }

        public static ISpliterator Spliterator(object[] array, int fromIndex, int toIndex, int characteristics)
        {
            return new ArraySpliterator(array, fromIndex, toIndex, characteristics);
        }

        public static ISpliterator Spliterator(int[] array, int characteristics)
        {
            return new IntArraySpliterator(array, 0, array.Length, characteristics);
        }

        public static ISpliterator Spliterator(double[] array, int fromIndex, int toIndex, int characteristics)
        {
            return new DoubleArraySpliterator(array, fromIndex, toIndex, characteristics);
        }

        public static ISpliterator Spliterator(double[] array, int characteristics)
        {
            return new DoubleArraySpliterator(array, 0, array.Length, characteristics);
        }

        public static ISpliterator EmptySpliterator()
        {
            return new EmptySpliterator();
        }

        public static IOfInt EmptyIntSpliterator()
        {
            return new EmptyIntSpliterator();
        }

        public static IOfLong EmptyLongSpliterator()
        {
            return new EmptyLongSpliterator();
        }

        public static IOfDouble EmptyDoubleSpliterator()
        {
            return new EmptyDoubleSpliterator();
        }
    }

    internal class SpliteratorIterator : IEnumerator
    {
        private readonly ISpliterator _spliterator;
        private object _current;
        private bool _hasNext;

        public SpliteratorIterator(ISpliterator spliterator)
        {
            _spliterator = spliterator;
            _hasNext = false;
        }

        public bool MoveNext()
        {
            _hasNext = _spliterator.TryAdvance(new Consumer(value => _current = value));
            return _hasNext;
        }

        public void Reset() { throw new NotSupportedException(); }

        public object Current => _current;

        public void Dispose() { }
    }

    internal class SpliteratorIteratorInt : IEnumerator
    {
        private readonly IOfInt _spliterator;
        private object _current;
        private bool _hasNext;

        public SpliteratorIteratorInt(IOfInt spliterator)
        {
            _spliterator = spliterator;
            _hasNext = false;
        }

        public bool MoveNext()
        {
            _hasNext = _spliterator.TryAdvance(new ConsumerInt(value => _current = value));
            return _hasNext;
        }

        public void Reset() { throw new NotSupportedException(); }

        public object Current => _current;

        public void Dispose() { }
    }

    internal class SpliteratorIteratorLong : IEnumerator
    {
        private readonly IOfLong _spliterator;
        private object _current;
        private bool _hasNext;

        public SpliteratorIteratorLong(IOfLong spliterator)
        {
            _spliterator = spliterator;
            _hasNext = false;
        }

        public bool MoveNext()
        {
            _hasNext = _spliterator.TryAdvance(new ConsumerLong(value => _current = value));
            return _hasNext;
        }

        public void Reset() { throw new NotSupportedException(); }

        public object Current => _current;

        public void Dispose() { }
    }

    internal class SpliteratorIteratorDouble : IEnumerator
    {
        private readonly IOfDouble _spliterator;
        private object _current;
        private bool _hasNext;

        public SpliteratorIteratorDouble(IOfDouble spliterator)
        {
            _spliterator = spliterator;
            _hasNext = false;
        }

        public bool MoveNext()
        {
            _hasNext = _spliterator.TryAdvance(new ConsumerDouble(value => _current = value));
            return _hasNext;
        }

        public void Reset() { throw new NotSupportedException(); }

        public object Current => _current;

        public void Dispose() { }
    }

    internal class Consumer : IConsumer
    {
        private readonly Action<object> _action;
        public Consumer(Action<object> action) { _action = action; }
        public void Accept(object value) => _action(value);
    }

    internal class ConsumerInt : IConsumerInt
    {
        private readonly Action<int> _action;
        public ConsumerInt(Action<int> action) { _action = action; }
        public void Accept(int value) => _action(value);
    }

    internal class ConsumerLong : IConsumerLong
    {
        private readonly Action<long> _action;
        public ConsumerLong(Action<long> action) { _action = action; }
        public void Accept(long value) => _action(value);
    }

    internal class ConsumerDouble : IConsumerDouble
    {
        private readonly Action<double> _action;
        public ConsumerDouble(Action<double> action) { _action = action; }
        public void Accept(double value) => _action(value);
    }

    internal class IteratorSpliterator : ISpliterator
    {
        private readonly IEnumerator _iterator;
        private readonly int _characteristics;
        private long _size;

        public IteratorSpliterator(IEnumerator iterator, int characteristics)
        {
            _iterator = iterator;
            _characteristics = characteristics;
            _size = long.MaxValue;
        }

        public IteratorSpliterator(IEnumerator iterator, long size, int characteristics)
        {
            _iterator = iterator;
            _size = size;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_iterator.MoveNext())
            {
                action.Accept(_iterator.Current);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit() => null;

        public long EstimateSize() => _size;

        public int Characteristics() => _characteristics;
    }

    internal class IteratorSpliteratorInt : ISpliterator
    {
        private readonly IPrimitiveIteratorOfInt _iterator;
        private readonly int _characteristics;
        private long _size;

        public IteratorSpliteratorInt(IPrimitiveIteratorOfInt iterator, int characteristics)
        {
            _iterator = iterator;
            _characteristics = characteristics;
            _size = long.MaxValue;
        }

        public IteratorSpliteratorInt(IPrimitiveIteratorOfInt iterator, long size, int characteristics)
        {
            _iterator = iterator;
            _size = size;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_iterator.HasNext())
            {
                action.Accept(_iterator.NextInt());
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit() => null;

        public long EstimateSize() => _size;

        public int Characteristics() => _characteristics;
    }

    internal class IteratorSpliteratorLong : ISpliterator
    {
        private readonly IPrimitiveIteratorOfLong _iterator;
        private readonly int _characteristics;
        private long _size;

        public IteratorSpliteratorLong(IPrimitiveIteratorOfLong iterator, int characteristics)
        {
            _iterator = iterator;
            _characteristics = characteristics;
            _size = long.MaxValue;
        }

        public IteratorSpliteratorLong(IPrimitiveIteratorOfLong iterator, long size, int characteristics)
        {
            _iterator = iterator;
            _size = size;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_iterator.HasNext())
            {
                action.Accept(_iterator.NextLong());
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit() => null;

        public long EstimateSize() => _size;

        public int Characteristics() => _characteristics;
    }

    internal class IteratorSpliteratorDouble : ISpliterator
    {
        private readonly IPrimitiveIteratorOfDouble _iterator;
        private readonly int _characteristics;
        private long _size;

        public IteratorSpliteratorDouble(IPrimitiveIteratorOfDouble iterator, int characteristics)
        {
            _iterator = iterator;
            _characteristics = characteristics;
            _size = long.MaxValue;
        }

        public IteratorSpliteratorDouble(IPrimitiveIteratorOfDouble iterator, long size, int characteristics)
        {
            _iterator = iterator;
            _size = size;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_iterator.HasNext())
            {
                action.Accept(_iterator.NextDouble());
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit() => null;

        public long EstimateSize() => _size;

        public int Characteristics() => _characteristics;
    }

    internal class ArraySpliterator : ISpliterator
    {
        private readonly object[] _array;
        private int _index;
        private readonly int _toIndex;
        private readonly int _characteristics;

        public ArraySpliterator(object[] array, int characteristics)
            : this(array, 0, array.Length, characteristics) { }

        public ArraySpliterator(object[] array, int fromIndex, int toIndex, int characteristics)
        {
            _array = array;
            _index = fromIndex;
            _toIndex = toIndex;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_index < _toIndex)
            {
                action.Accept(_array[_index++]);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit()
        {
            int mid = (_index + _toIndex) / 2;
            if (mid <= _index) return null;
            var split = new ArraySpliterator(_array, _index, mid, _characteristics);
            _index = mid;
            return split;
        }

        public long EstimateSize() => _toIndex - _index;

        public int Characteristics() => _characteristics;
    }

    internal class IntArraySpliterator : ISpliterator
    {
        private readonly int[] _array;
        private int _index;
        private readonly int _toIndex;
        private readonly int _characteristics;

        public IntArraySpliterator(int[] array, int characteristics)
            : this(array, 0, array.Length, characteristics) { }

        public IntArraySpliterator(int[] array, int fromIndex, int toIndex, int characteristics)
        {
            _array = array;
            _index = fromIndex;
            _toIndex = toIndex;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_index < _toIndex)
            {
                action.Accept(_array[_index++]);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit()
        {
            int mid = (_index + _toIndex) / 2;
            if (mid <= _index) return null;
            var split = new IntArraySpliterator(_array, _index, mid, _characteristics);
            _index = mid;
            return split;
        }

        public long EstimateSize() => _toIndex - _index;

        public int Characteristics() => _characteristics;
    }

    internal class LongArraySpliterator : ISpliterator
    {
        private readonly long[] _array;
        private int _index;
        private readonly int _toIndex;
        private readonly int _characteristics;

        public LongArraySpliterator(long[] array, int characteristics)
            : this(array, 0, array.Length, characteristics) { }

        public LongArraySpliterator(long[] array, int fromIndex, int toIndex, int characteristics)
        {
            _array = array;
            _index = fromIndex;
            _toIndex = toIndex;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_index < _toIndex)
            {
                action.Accept(_array[_index++]);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit()
        {
            int mid = (_index + _toIndex) / 2;
            if (mid <= _index) return null;
            var split = new LongArraySpliterator(_array, _index, mid, _characteristics);
            _index = mid;
            return split;
        }

        public long EstimateSize() => _toIndex - _index;

        public int Characteristics() => _characteristics;
    }

    internal class DoubleArraySpliterator : ISpliterator
    {
        private readonly double[] _array;
        private int _index;
        private readonly int _toIndex;
        private readonly int _characteristics;

        public DoubleArraySpliterator(double[] array, int characteristics)
            : this(array, 0, array.Length, characteristics) { }

        public DoubleArraySpliterator(double[] array, int fromIndex, int toIndex, int characteristics)
        {
            _array = array;
            _index = fromIndex;
            _toIndex = toIndex;
            _characteristics = characteristics;
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_index < _toIndex)
            {
                action.Accept(_array[_index++]);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit()
        {
            int mid = (_index + _toIndex) / 2;
            if (mid <= _index) return null;
            var split = new DoubleArraySpliterator(_array, _index, mid, _characteristics);
            _index = mid;
            return split;
        }

        public long EstimateSize() => _toIndex - _index;

        public int Characteristics() => _characteristics;
    }

    internal class CollectionSpliterator : ISpliterator
    {
        private readonly ICollection _collection;
        private readonly int _characteristics;
        private IEnumerator _enumerator;

        public CollectionSpliterator(ICollection collection, int characteristics)
        {
            _collection = collection;
            _characteristics = characteristics;
            _enumerator = collection.GetEnumerator();
        }

        public bool TryAdvance(IConsumer action)
        {
            if (_enumerator.MoveNext())
            {
                action.Accept(_enumerator.Current);
                return true;
            }
            return false;
        }

        public ISpliterator TrySplit() => null;

        public long EstimateSize() => _collection.Count;

        public int Characteristics() => _characteristics;
    }

    internal class EmptySpliterator : ISpliterator
    {
        public bool TryAdvance(IConsumer action) => false;
        public ISpliterator TrySplit() => null;
        public long EstimateSize() => 0;
        public int Characteristics() => 0;
    }

    internal class EmptyIntSpliterator : IOfInt
    {
        public bool TryAdvance(IConsumer action) => false;
        public bool TryAdvance(IConsumerInt action) => false;
        public ISpliterator TrySplit() => null;
        public IOfInt TrySplitInt() => null;
        public long EstimateSize() => 0;
        public int Characteristics() => 0;
    }

    internal class EmptyLongSpliterator : IOfLong
    {
        public bool TryAdvance(IConsumer action) => false;
        public bool TryAdvance(IConsumerLong action) => false;
        public ISpliterator TrySplit() => null;
        public IOfLong TrySplitLong() => null;
        public long EstimateSize() => 0;
        public int Characteristics() => 0;
    }

    internal class EmptyDoubleSpliterator : IOfDouble
    {
        public bool TryAdvance(IConsumer action) => false;
        public bool TryAdvance(IConsumerDouble action) => false;
        public ISpliterator TrySplit() => null;
        public IOfDouble TrySplitDouble() => null;
        public long EstimateSize() => 0;
        public int Characteristics() => 0;
    }

    public class java_util_SpliteratorsAutoTest
    {
        public void iterator_test_11314(IOfDouble p0)
        {
            Spliterators.Iterator(p0);
        }

        public void iterator_test_11315(ISpliterator p0)
        {
            Spliterators.Iterator(p0);
        }

        public void iterator_test_11316(IOfInt p0)
        {
            Spliterators.Iterator(p0);
        }

        public void iterator_test_11317(IOfLong p0)
        {
            Spliterators.Iterator(p0);
        }

        public void spliteratorUnknownSize_test_11318(IPrimitiveIteratorOfInt p0, int p1)
        {
            Spliterators.SpliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11319(IPrimitiveIteratorOfLong p0, int p1)
        {
            Spliterators.SpliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11320(IPrimitiveIteratorOfDouble p0, int p1)
        {
            Spliterators.SpliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11321(IEnumerator p0, int p1)
        {
            Spliterators.SpliteratorUnknownSize(p0, p1);
        }

        public void spliterator_test_11322(object[] p0, int p1)
        {
            Spliterators.Spliterator(p0, p1);
        }

        public void spliterator_test_11323(IEnumerator p0, long p1, int p2)
        {
            Spliterators.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_11324(ICollection p0, int p1)
        {
            Spliterators.Spliterator(p0, p1);
        }

        public void spliterator_test_11325(IPrimitiveIteratorOfInt p0, long p1, int p2)
        {
            Spliterators.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_11326(IPrimitiveIteratorOfLong p0, long p1, int p2)
        {
            Spliterators.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_11327(IPrimitiveIteratorOfDouble p0, long p1, int p2)
        {
            Spliterators.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_11328(long[] p0, int p1, int p2, int p3)
        {
            Spliterators.Spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11329(long[] p0, int p1)
        {
            Spliterators.Spliterator(p0, p1);
        }

        public void spliterator_test_11330(int[] p0, int p1, int p2, int p3)
        {
            Spliterators.Spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11331(object[] p0, int p1, int p2, int p3)
        {
            Spliterators.Spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11332(int[] p0, int p1)
        {
            Spliterators.Spliterator(p0, p1);
        }

        public void spliterator_test_11333(double[] p0, int p1, int p2, int p3)
        {
            Spliterators.Spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11334(double[] p0, int p1)
        {
            Spliterators.Spliterator(p0, p1);
        }

        public void emptySpliterator_test_11335()
        {
            Spliterators.EmptySpliterator();
        }

        public void emptyIntSpliterator_test_11336()
        {
            Spliterators.EmptyIntSpliterator();
        }

        public void emptyLongSpliterator_test_11337()
        {
            Spliterators.EmptyLongSpliterator();
        }

        public void emptyDoubleSpliterator_test_11338()
        {
            Spliterators.EmptyDoubleSpliterator();
        }
    }
}