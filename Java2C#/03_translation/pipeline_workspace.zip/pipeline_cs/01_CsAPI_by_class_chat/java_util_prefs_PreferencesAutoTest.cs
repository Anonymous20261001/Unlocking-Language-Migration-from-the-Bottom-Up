using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_util_prefs_PreferencesAutoTest
    {
        public void userRoot_test_10000()
        {
            Preferences.UserRoot();
        }

        public void systemRoot_test_10001()
        {
            Preferences.SystemRoot();
        }

        public void userNodeForPackage_test_10002(Type p0)
        {
            Preferences.UserNodeForPackage(p0);
        }

        public void systemNodeForPackage_test_10003(Type p0)
        {
            Preferences.SystemNodeForPackage(p0);
        }
    }

    public class Preferences
    {
        private static Preferences userRootInstance;
        private static Preferences systemRootInstance;
        private Dictionary<string, string> values = new Dictionary<string, string>();
        private Dictionary<string, Preferences> children = new Dictionary<string, Preferences>();
        private string name;

        private Preferences(string name)
        {
            this.name = name;
        }

        public static Preferences UserRoot()
        {
            if (userRootInstance == null)
            {
                userRootInstance = new Preferences("/");
            }
            return userRootInstance;
        }

        public static Preferences SystemRoot()
        {
            if (systemRootInstance == null)
            {
                systemRootInstance = new Preferences("/");
            }
            return systemRootInstance;
        }

        public static Preferences UserNodeForPackage(Type c)
        {
            return GetNodeForPackage(c, true);
        }

        public static Preferences SystemNodeForPackage(Type c)
        {
            return GetNodeForPackage(c, false);
        }

        private static Preferences GetNodeForPackage(Type c, bool user)
        {
            Preferences root = user ? UserRoot() : SystemRoot();
            string packageName = c.Namespace ?? "";
            string[] parts = packageName.Split('.');
            Preferences current = root;
            foreach (string part in parts)
            {
                if (!current.children.ContainsKey(part))
                {
                    current.children[part] = new Preferences(part);
                }
                current = current.children[part];
            }
            return current;
        }

        public string Get(string key, string def)
        {
            return values.ContainsKey(key) ? values[key] : def;
        }

        public void Put(string key, string value)
        {
            values[key] = value;
        }

        public void Remove(string key)
        {
            values.Remove(key);
        }

        public void Clear()
        {
            values.Clear();
        }

        public void Flush()
        {
            // No-op for in-memory implementation
        }

        public void Sync()
        {
            // No-op for in-memory implementation
        }
    }
}