namespace Generated.Test
{
    using System;

    public class AclEntry
    {
        public static AclEntryBuilder newBuilder(AclEntry p0)
        {
            return new AclEntryBuilder(p0);
        }

        public static AclEntryBuilder newBuilder()
        {
            return new AclEntryBuilder();
        }
    }

    public class AclEntryBuilder
    {
        public AclEntryBuilder(AclEntry p0)
        {
            // Copy constructor behavior
        }

        public AclEntryBuilder()
        {
        }
    }

    public class java_nio_file_attribute_AclEntryAutoTest
    {
        public void newBuilder_test_55(AclEntry p0)
        {
            AclEntry.newBuilder(p0);
        }

        public void newBuilder_test_56()
        {
            AclEntry.newBuilder();
        }
    }
}