namespace Generated.Test
{
    public class CubicCurve2D
    {
        public static double GetFlatnessSq(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3)
        {
            return Math.Max(Math.Abs(x0 - 2 * x1 + x2), Math.Abs(x2 - 2 * x3 + x0)) * Math.Max(Math.Abs(y0 - 2 * y1 + y2), Math.Abs(y2 - 2 * y3 + y0));
        }

        public static double GetFlatnessSq(double[] coords, int offset)
        {
            return GetFlatnessSq(coords[offset], coords[offset + 1], coords[offset + 2], coords[offset + 3], coords[offset + 4], coords[offset + 5], coords[offset + 6], coords[offset + 7]);
        }

        public static double GetFlatness(double[] coords, int offset)
        {
            return Math.Sqrt(GetFlatnessSq(coords, offset));
        }

        public static double GetFlatness(double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3)
        {
            return Math.Sqrt(GetFlatnessSq(x0, y0, x1, y1, x2, y2, x3, y3));
        }

        public static void Subdivide(double[] src, int srcOff, double[] left, int leftOff, double[] right, int rightOff)
        {
            double x0 = src[srcOff];
            double y0 = src[srcOff + 1];
            double x1 = src[srcOff + 2];
            double y1 = src[srcOff + 3];
            double x2 = src[srcOff + 4];
            double y2 = src[srcOff + 5];
            double x3 = src[srcOff + 6];
            double y3 = src[srcOff + 7];

            double cx = (x0 + x1) / 2;
            double cy = (y0 + y1) / 2;
            double dx = (x1 + x2) / 2;
            double dy = (y1 + y2) / 2;
            double ex = (x2 + x3) / 2;
            double ey = (y2 + y3) / 2;

            double fx = (cx + dx) / 2;
            double fy = (cy + dy) / 2;
            double gx = (dx + ex) / 2;
            double gy = (dy + ey) / 2;

            double hx = (fx + gx) / 2;
            double hy = (fy + gy) / 2;

            if (left != null)
            {
                left[leftOff] = x0;
                left[leftOff + 1] = y0;
                left[leftOff + 2] = cx;
                left[leftOff + 3] = cy;
                left[leftOff + 4] = fx;
                left[leftOff + 5] = fy;
                left[leftOff + 6] = hx;
                left[leftOff + 7] = hy;
            }

            if (right != null)
            {
                right[rightOff] = hx;
                right[rightOff + 1] = hy;
                right[rightOff + 2] = gx;
                right[rightOff + 3] = gy;
                right[rightOff + 4] = ex;
                right[rightOff + 5] = ey;
                right[rightOff + 6] = x3;
                right[rightOff + 7] = y3;
            }
        }

        public static void Subdivide(CubicCurve2D src, CubicCurve2D left, CubicCurve2D right)
        {
            double[] srcCoords = new double[8];
            src.GetCoords(srcCoords);
            double[] leftCoords = new double[8];
            double[] rightCoords = new double[8];
            Subdivide(srcCoords, 0, leftCoords, 0, rightCoords, 0);
            if (left != null)
            {
                left.SetCoords(leftCoords);
            }
            if (right != null)
            {
                right.SetCoords(rightCoords);
            }
        }

        public static int SolveCubic(double[] eqn, double[] res)
        {
            double a = eqn[0];
            double b = eqn[1];
            double c = eqn[2];
            double d = eqn[3];

            if (a == 0)
            {
                if (b == 0)
                {
                    if (c == 0)
                    {
                        return 0;
                    }
                    res[0] = -d / c;
                    return 1;
                }
                double disc = c * c - 4 * b * d;
                if (disc < 0)
                {
                    return 0;
                }
                if (disc == 0)
                {
                    res[0] = -c / (2 * b);
                    return 1;
                }
                res[0] = (-c + Math.Sqrt(disc)) / (2 * b);
                res[1] = (-c - Math.Sqrt(disc)) / (2 * b);
                return 2;
            }

            double invA = 1 / a;
            double p = (3 * a * c - b * b) * invA * invA / 3;
            double q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) * invA * invA * invA / 27;

            double offset = b * invA / 3;
            double discrim = q * q / 4 + p * p * p / 27;

            if (discrim > 0)
            {
                double sqrtDisc = Math.Sqrt(discrim);
                double u = Math.Cbrt(-q / 2 + sqrtDisc);
                double v = Math.Cbrt(-q / 2 - sqrtDisc);
                res[0] = u + v - offset;
                return 1;
            }
            else if (discrim == 0)
            {
                double u = Math.Cbrt(-q / 2);
                res[0] = 2 * u - offset;
                res[1] = -u - offset;
                return 2;
            }
            else
            {
                double r = Math.Sqrt(-p * p * p / 27);
                double theta = Math.Acos(-q / (2 * r));
                double sqrtP = Math.Sqrt(-p / 3);
                res[0] = 2 * sqrtP * Math.Cos(theta / 3) - offset;
                res[1] = 2 * sqrtP * Math.Cos((theta + 2 * Math.PI) / 3) - offset;
                res[2] = 2 * sqrtP * Math.Cos((theta + 4 * Math.PI) / 3) - offset;
                return 3;
            }
        }

        public static int SolveCubic(double[] eqn)
        {
            double[] res = new double[3];
            int count = SolveCubic(eqn, res);
            for (int i = 0; i < count; i++)
            {
                eqn[i] = res[i];
            }
            return count;
        }

        private double[] coords = new double[8];

        public void SetCoords(double[] coords)
        {
            Array.Copy(coords, this.coords, 8);
        }

        public void GetCoords(double[] coords)
        {
            Array.Copy(this.coords, coords, 8);
        }
    }

    public class java_awt_geom_CubicCurve2DAutoTest
    {
        public void getFlatnessSq_test_3126(double p0, double p1, double p2, double p3, double p4,
            double p5, double p6, double p7)
        {
            CubicCurve2D.GetFlatnessSq(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void getFlatnessSq_test_3127(double[] p0, int p1)
        {
            CubicCurve2D.GetFlatnessSq(p0, p1);
        }

        public void getFlatness_test_3128(double[] p0, int p1)
        {
            CubicCurve2D.GetFlatness(p0, p1);
        }

        public void getFlatness_test_3129(double p0, double p1, double p2, double p3, double p4,
            double p5, double p6, double p7)
        {
            CubicCurve2D.GetFlatness(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void subdivide_test_3130(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5)
        {
            CubicCurve2D.Subdivide(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_3131(CubicCurve2D p0, CubicCurve2D p1, CubicCurve2D p2)
        {
            CubicCurve2D.Subdivide(p0, p1, p2);
        }

        public void solveCubic_test_3132(double[] p0, double[] p1)
        {
            CubicCurve2D.SolveCubic(p0, p1);
        }

        public void solveCubic_test_3133(double[] p0)
        {
            CubicCurve2D.SolveCubic(p0);
        }
    }
}