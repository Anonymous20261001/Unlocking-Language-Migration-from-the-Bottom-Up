namespace Generated.Test
{
    public class javax_management_ObjectNameAutoTest
    {
        public void unquote_test_9594(string p0)
        {
            ObjectName.Unquote(p0);
        }

        public void getInstance_test_9595(ObjectName p0)
        {
            ObjectName.GetInstance(p0);
        }

        public void quote_test_9596(string p0)
        {
            ObjectName.Quote(p0);
        }
    }

    public class ObjectName
    {
        public static string Unquote(string quoted)
        {
            if (quoted == null)
                throw new System.ArgumentNullException(nameof(quoted));

            if (quoted.Length < 2 || quoted[0] != '"' || quoted[quoted.Length - 1] != '"')
                return quoted;

            var sb = new System.Text.StringBuilder();
            for (int i = 1; i < quoted.Length - 1; i++)
            {
                char c = quoted[i];
                if (c == '\\' && i + 1 < quoted.Length - 1)
                {
                    char next = quoted[i + 1];
                    switch (next)
                    {
                        case '\\':
                            sb.Append('\\');
                            i++;
                            break;
                        case '"':
                            sb.Append('"');
                            i++;
                            break;
                        case 'n':
                            sb.Append('\n');
                            i++;
                            break;
                        case 't':
                            sb.Append('\t');
                            i++;
                            break;
                        case 'r':
                            sb.Append('\r');
                            i++;
                            break;
                        default:
                            sb.Append(c);
                            break;
                    }
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static ObjectName GetInstance(ObjectName name)
        {
            if (name == null)
                throw new System.ArgumentNullException(nameof(name));
            return name;
        }

        public static string Quote(string value)
        {
            if (value == null)
                throw new System.ArgumentNullException(nameof(value));

            var sb = new System.Text.StringBuilder();
            sb.Append('"');
            foreach (char c in value)
            {
                switch (c)
                {
                    case '"':
                        sb.Append("\\\"");
                        break;
                    case '\\':
                        sb.Append("\\\\");
                        break;
                    case '\n':
                        sb.Append("\\n");
                        break;
                    case '\t':
                        sb.Append("\\t");
                        break;
                    case '\r':
                        sb.Append("\\r");
                        break;
                    default:
                        sb.Append(c);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }
    }
}