namespace Generated.Test
{
    public class java_time_InstantAutoTest
    {
        public void from_test_5857(TemporalAccessor p0)
        {
            Instant.From(p0);
        }

        public void parse_test_5858(string p0)
        {
            Instant.Parse(p0);
        }

        public void now_test_5859()
        {
            Instant.Now();
        }

        public void now_test_5860(Clock p0)
        {
            Instant.Now(p0);
        }

        public void ofEpochSecond_test_5861(long p0, long p1)
        {
            Instant.OfEpochSecond(p0, p1);
        }

        public void ofEpochSecond_test_5862(long p0)
        {
            Instant.OfEpochSecond(p0);
        }

        public void ofEpochMilli_test_5863(long p0)
        {
            Instant.OfEpochMilli(p0);
        }
    }

    public class Instant
    {
        public static Instant From(TemporalAccessor temporal)
        {
            return new Instant();
        }

        public static Instant Parse(string text)
        {
            return new Instant();
        }

        public static Instant Now()
        {
            return new Instant();
        }

        public static Instant Now(Clock clock)
        {
            return new Instant();
        }

        public static Instant OfEpochSecond(long epochSecond, long nanoAdjustment)
        {
            return new Instant();
        }

        public static Instant OfEpochSecond(long epochSecond)
        {
            return new Instant();
        }

        public static Instant OfEpochMilli(long epochMilli)
        {
            return new Instant();
        }
    }

    public class TemporalAccessor
    {
    }

    public class Clock
    {
    }
}