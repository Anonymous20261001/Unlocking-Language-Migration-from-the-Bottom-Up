using System;
using System.Collections;
using System.Collections.Generic;

namespace Generated.Test
{
    // Attribute interface
    public interface Attribute
    {
        // Marker interface
    }

    // AttributeSet interface
    public interface AttributeSet : IEnumerable
    {
        bool Add(Attribute attribute);
        bool Add(Attribute category, object value);
        bool AddAll(AttributeSet attributes);
        void Clear();
        bool ContainsKey(Attribute category);
        bool ContainsValue(Attribute attribute);
        bool Equals(object obj);
        int GetHashCode();
        Attribute Get(Attribute category);
        bool IsEmpty();
        bool Remove(Attribute attribute);
        bool Remove(Attribute category);
        bool RemoveAll(AttributeSet attributes);
        int Size();
        Attribute[] ToArray();
    }

    // DocAttributeSet interface
    public interface DocAttributeSet : AttributeSet
    {
    }

    // PrintJobAttributeSet interface
    public interface PrintJobAttributeSet : AttributeSet
    {
    }

    // PrintRequestAttributeSet interface
    public interface PrintRequestAttributeSet : AttributeSet
    {
    }

    // PrintServiceAttributeSet interface
    public interface PrintServiceAttributeSet : AttributeSet
    {
    }

    // AttributeSetUtilities class
    public static class AttributeSetUtilities
    {
        public static AttributeSet unmodifiableView(AttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new UnmodifiableAttributeSet(attributeSet);
        }

        public static PrintServiceAttributeSet unmodifiableView(PrintServiceAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new UnmodifiablePrintServiceAttributeSet(attributeSet);
        }

        public static PrintRequestAttributeSet unmodifiableView(PrintRequestAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new UnmodifiablePrintRequestAttributeSet(attributeSet);
        }

        public static DocAttributeSet unmodifiableView(DocAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new UnmodifiableDocAttributeSet(attributeSet);
        }

        public static PrintJobAttributeSet unmodifiableView(PrintJobAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new UnmodifiablePrintJobAttributeSet(attributeSet);
        }

        public static AttributeSet synchronizedView(AttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new SynchronizedAttributeSet(attributeSet);
        }

        public static PrintServiceAttributeSet synchronizedView(PrintServiceAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new SynchronizedPrintServiceAttributeSet(attributeSet);
        }

        public static PrintRequestAttributeSet synchronizedView(PrintRequestAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new SynchronizedPrintRequestAttributeSet(attributeSet);
        }

        public static DocAttributeSet synchronizedView(DocAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new SynchronizedDocAttributeSet(attributeSet);
        }

        public static PrintJobAttributeSet synchronizedView(PrintJobAttributeSet attributeSet)
        {
            if (attributeSet == null)
                throw new ArgumentNullException(nameof(attributeSet));
            return new SynchronizedPrintJobAttributeSet(attributeSet);
        }

        public static void verifyAttributeCategory(object category, Type categoryClass)
        {
            if (category == null)
                throw new ArgumentNullException(nameof(category));
            if (categoryClass == null)
                throw new ArgumentNullException(nameof(categoryClass));
            if (!categoryClass.IsInstanceOfType(category))
                throw new ArgumentException("Category is not an instance of the specified class");
        }

        public static void verifyAttributeValue(object value, Type valueClass)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value));
            if (valueClass == null)
                throw new ArgumentNullException(nameof(valueClass));
            if (!valueClass.IsInstanceOfType(value))
                throw new ArgumentException("Value is not an instance of the specified class");
        }

        public static void verifyCategoryForValue(Type category, Attribute attribute)
        {
            if (category == null)
                throw new ArgumentNullException(nameof(category));
            if (attribute == null)
                throw new ArgumentNullException(nameof(attribute));
            // Additional verification logic would go here
        }

        // Unmodifiable wrapper classes
        private class UnmodifiableAttributeSet : AttributeSet
        {
            private readonly AttributeSet _inner;

            public UnmodifiableAttributeSet(AttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) => throw new NotSupportedException();
            public bool Add(Attribute category, object value) => throw new NotSupportedException();
            public bool AddAll(AttributeSet attributes) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool ContainsKey(Attribute category) => _inner.ContainsKey(category);
            public bool ContainsValue(Attribute attribute) => _inner.ContainsValue(attribute);
            public bool Equals(object obj) => _inner.Equals(obj);
            public int GetHashCode() => _inner.GetHashCode();
            public Attribute Get(Attribute category) => _inner.Get(category);
            public bool IsEmpty() => _inner.IsEmpty();
            public bool Remove(Attribute attribute) => throw new NotSupportedException();
            public bool Remove(Attribute category) => throw new NotSupportedException();
            public bool RemoveAll(AttributeSet attributes) => throw new NotSupportedException();
            public int Size() => _inner.Size();
            public Attribute[] ToArray() => _inner.ToArray();
            public IEnumerator GetEnumerator() => _inner.GetEnumerator();
        }

        private class UnmodifiablePrintServiceAttributeSet : PrintServiceAttributeSet
        {
            private readonly PrintServiceAttributeSet _inner;

            public UnmodifiablePrintServiceAttributeSet(PrintServiceAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) => throw new NotSupportedException();
            public bool Add(Attribute category, object value) => throw new NotSupportedException();
            public bool AddAll(AttributeSet attributes) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool ContainsKey(Attribute category) => _inner.ContainsKey(category);
            public bool ContainsValue(Attribute attribute) => _inner.ContainsValue(attribute);
            public bool Equals(object obj) => _inner.Equals(obj);
            public int GetHashCode() => _inner.GetHashCode();
            public Attribute Get(Attribute category) => _inner.Get(category);
            public bool IsEmpty() => _inner.IsEmpty();
            public bool Remove(Attribute attribute) => throw new NotSupportedException();
            public bool Remove(Attribute category) => throw new NotSupportedException();
            public bool RemoveAll(AttributeSet attributes) => throw new NotSupportedException();
            public int Size() => _inner.Size();
            public Attribute[] ToArray() => _inner.ToArray();
            public IEnumerator GetEnumerator() => _inner.GetEnumerator();
        }

        private class UnmodifiablePrintRequestAttributeSet : PrintRequestAttributeSet
        {
            private readonly PrintRequestAttributeSet _inner;

            public UnmodifiablePrintRequestAttributeSet(PrintRequestAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) => throw new NotSupportedException();
            public bool Add(Attribute category, object value) => throw new NotSupportedException();
            public bool AddAll(AttributeSet attributes) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool ContainsKey(Attribute category) => _inner.ContainsKey(category);
            public bool ContainsValue(Attribute attribute) => _inner.ContainsValue(attribute);
            public bool Equals(object obj) => _inner.Equals(obj);
            public int GetHashCode() => _inner.GetHashCode();
            public Attribute Get(Attribute category) => _inner.Get(category);
            public bool IsEmpty() => _inner.IsEmpty();
            public bool Remove(Attribute attribute) => throw new NotSupportedException();
            public bool Remove(Attribute category) => throw new NotSupportedException();
            public bool RemoveAll(AttributeSet attributes) => throw new NotSupportedException();
            public int Size() => _inner.Size();
            public Attribute[] ToArray() => _inner.ToArray();
            public IEnumerator GetEnumerator() => _inner.GetEnumerator();
        }

        private class UnmodifiableDocAttributeSet : DocAttributeSet
        {
            private readonly DocAttributeSet _inner;

            public UnmodifiableDocAttributeSet(DocAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) => throw new NotSupportedException();
            public bool Add(Attribute category, object value) => throw new NotSupportedException();
            public bool AddAll(AttributeSet attributes) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool ContainsKey(Attribute category) => _inner.ContainsKey(category);
            public bool ContainsValue(Attribute attribute) => _inner.ContainsValue(attribute);
            public bool Equals(object obj) => _inner.Equals(obj);
            public int GetHashCode() => _inner.GetHashCode();
            public Attribute Get(Attribute category) => _inner.Get(category);
            public bool IsEmpty() => _inner.IsEmpty();
            public bool Remove(Attribute attribute) => throw new NotSupportedException();
            public bool Remove(Attribute category) => throw new NotSupportedException();
            public bool RemoveAll(AttributeSet attributes) => throw new NotSupportedException();
            public int Size() => _inner.Size();
            public Attribute[] ToArray() => _inner.ToArray();
            public IEnumerator GetEnumerator() => _inner.GetEnumerator();
        }

        private class UnmodifiablePrintJobAttributeSet : PrintJobAttributeSet
        {
            private readonly PrintJobAttributeSet _inner;

            public UnmodifiablePrintJobAttributeSet(PrintJobAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) => throw new NotSupportedException();
            public bool Add(Attribute category, object value) => throw new NotSupportedException();
            public bool AddAll(AttributeSet attributes) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool ContainsKey(Attribute category) => _inner.ContainsKey(category);
            public bool ContainsValue(Attribute attribute) => _inner.ContainsValue(attribute);
            public bool Equals(object obj) => _inner.Equals(obj);
            public int GetHashCode() => _inner.GetHashCode();
            public Attribute Get(Attribute category) => _inner.Get(category);
            public bool IsEmpty() => _inner.IsEmpty();
            public bool Remove(Attribute attribute) => throw new NotSupportedException();
            public bool Remove(Attribute category) => throw new NotSupportedException();
            public bool RemoveAll(AttributeSet attributes) => throw new NotSupportedException();
            public int Size() => _inner.Size();
            public Attribute[] ToArray() => _inner.ToArray();
            public IEnumerator GetEnumerator() => _inner.GetEnumerator();
        }

        // Synchronized wrapper classes
        private class SynchronizedAttributeSet : AttributeSet
        {
            private readonly AttributeSet _inner;
            private readonly object _lock = new object();

            public SynchronizedAttributeSet(AttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) { lock (_lock) return _inner.Add(attribute); }
            public bool Add(Attribute category, object value) { lock (_lock) return _inner.Add(category, value); }
            public bool AddAll(AttributeSet attributes) { lock (_lock) return _inner.AddAll(attributes); }
            public void Clear() { lock (_lock) _inner.Clear(); }
            public bool ContainsKey(Attribute category) { lock (_lock) return _inner.ContainsKey(category); }
            public bool ContainsValue(Attribute attribute) { lock (_lock) return _inner.ContainsValue(attribute); }
            public bool Equals(object obj) { lock (_lock) return _inner.Equals(obj); }
            public int GetHashCode() { lock (_lock) return _inner.GetHashCode(); }
            public Attribute Get(Attribute category) { lock (_lock) return _inner.Get(category); }
            public bool IsEmpty() { lock (_lock) return _inner.IsEmpty(); }
            public bool Remove(Attribute attribute) { lock (_lock) return _inner.Remove(attribute); }
            public bool Remove(Attribute category) { lock (_lock) return _inner.Remove(category); }
            public bool RemoveAll(AttributeSet attributes) { lock (_lock) return _inner.RemoveAll(attributes); }
            public int Size() { lock (_lock) return _inner.Size(); }
            public Attribute[] ToArray() { lock (_lock) return _inner.ToArray(); }
            public IEnumerator GetEnumerator() { lock (_lock) return _inner.GetEnumerator(); }
        }

        private class SynchronizedPrintServiceAttributeSet : PrintServiceAttributeSet
        {
            private readonly PrintServiceAttributeSet _inner;
            private readonly object _lock = new object();

            public SynchronizedPrintServiceAttributeSet(PrintServiceAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) { lock (_lock) return _inner.Add(attribute); }
            public bool Add(Attribute category, object value) { lock (_lock) return _inner.Add(category, value); }
            public bool AddAll(AttributeSet attributes) { lock (_lock) return _inner.AddAll(attributes); }
            public void Clear() { lock (_lock) _inner.Clear(); }
            public bool ContainsKey(Attribute category) { lock (_lock) return _inner.ContainsKey(category); }
            public bool ContainsValue(Attribute attribute) { lock (_lock) return _inner.ContainsValue(attribute); }
            public bool Equals(object obj) { lock (_lock) return _inner.Equals(obj); }
            public int GetHashCode() { lock (_lock) return _inner.GetHashCode(); }
            public Attribute Get(Attribute category) { lock (_lock) return _inner.Get(category); }
            public bool IsEmpty() { lock (_lock) return _inner.IsEmpty(); }
            public bool Remove(Attribute attribute) { lock (_lock) return _inner.Remove(attribute); }
            public bool Remove(Attribute category) { lock (_lock) return _inner.Remove(category); }
            public bool RemoveAll(AttributeSet attributes) { lock (_lock) return _inner.RemoveAll(attributes); }
            public int Size() { lock (_lock) return _inner.Size(); }
            public Attribute[] ToArray() { lock (_lock) return _inner.ToArray(); }
            public IEnumerator GetEnumerator() { lock (_lock) return _inner.GetEnumerator(); }
        }

        private class SynchronizedPrintRequestAttributeSet : PrintRequestAttributeSet
        {
            private readonly PrintRequestAttributeSet _inner;
            private readonly object _lock = new object();

            public SynchronizedPrintRequestAttributeSet(PrintRequestAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) { lock (_lock) return _inner.Add(attribute); }
            public bool Add(Attribute category, object value) { lock (_lock) return _inner.Add(category, value); }
            public bool AddAll(AttributeSet attributes) { lock (_lock) return _inner.AddAll(attributes); }
            public void Clear() { lock (_lock) _inner.Clear(); }
            public bool ContainsKey(Attribute category) { lock (_lock) return _inner.ContainsKey(category); }
            public bool ContainsValue(Attribute attribute) { lock (_lock) return _inner.ContainsValue(attribute); }
            public bool Equals(object obj) { lock (_lock) return _inner.Equals(obj); }
            public int GetHashCode() { lock (_lock) return _inner.GetHashCode(); }
            public Attribute Get(Attribute category) { lock (_lock) return _inner.Get(category); }
            public bool IsEmpty() { lock (_lock) return _inner.IsEmpty(); }
            public bool Remove(Attribute attribute) { lock (_lock) return _inner.Remove(attribute); }
            public bool Remove(Attribute category) { lock (_lock) return _inner.Remove(category); }
            public bool RemoveAll(AttributeSet attributes) { lock (_lock) return _inner.RemoveAll(attributes); }
            public int Size() { lock (_lock) return _inner.Size(); }
            public Attribute[] ToArray() { lock (_lock) return _inner.ToArray(); }
            public IEnumerator GetEnumerator() { lock (_lock) return _inner.GetEnumerator(); }
        }

        private class SynchronizedDocAttributeSet : DocAttributeSet
        {
            private readonly DocAttributeSet _inner;
            private readonly object _lock = new object();

            public SynchronizedDocAttributeSet(DocAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) { lock (_lock) return _inner.Add(attribute); }
            public bool Add(Attribute category, object value) { lock (_lock) return _inner.Add(category, value); }
            public bool AddAll(AttributeSet attributes) { lock (_lock) return _inner.AddAll(attributes); }
            public void Clear() { lock (_lock) _inner.Clear(); }
            public bool ContainsKey(Attribute category) { lock (_lock) return _inner.ContainsKey(category); }
            public bool ContainsValue(Attribute attribute) { lock (_lock) return _inner.ContainsValue(attribute); }
            public bool Equals(object obj) { lock (_lock) return _inner.Equals(obj); }
            public int GetHashCode() { lock (_lock) return _inner.GetHashCode(); }
            public Attribute Get(Attribute category) { lock (_lock) return _inner.Get(category); }
            public bool IsEmpty() { lock (_lock) return _inner.IsEmpty(); }
            public bool Remove(Attribute attribute) { lock (_lock) return _inner.Remove(attribute); }
            public bool Remove(Attribute category) { lock (_lock) return _inner.Remove(category); }
            public bool RemoveAll(AttributeSet attributes) { lock (_lock) return _inner.RemoveAll(attributes); }
            public int Size() { lock (_lock) return _inner.Size(); }
            public Attribute[] ToArray() { lock (_lock) return _inner.ToArray(); }
            public IEnumerator GetEnumerator() { lock (_lock) return _inner.GetEnumerator(); }
        }

        private class SynchronizedPrintJobAttributeSet : PrintJobAttributeSet
        {
            private readonly PrintJobAttributeSet _inner;
            private readonly object _lock = new object();

            public SynchronizedPrintJobAttributeSet(PrintJobAttributeSet inner)
            {
                _inner = inner;
            }

            public bool Add(Attribute attribute) { lock (_lock) return _inner.Add(attribute); }
            public bool Add(Attribute category, object value) { lock (_lock) return _inner.Add(category, value); }
            public bool AddAll(AttributeSet attributes) { lock (_lock) return _inner.AddAll(attributes); }
            public void Clear() { lock (_lock) _inner.Clear(); }
            public bool ContainsKey(Attribute category) { lock (_lock) return _inner.ContainsKey(category); }
            public bool ContainsValue(Attribute attribute) { lock (_lock) return _inner.ContainsValue(attribute); }
            public bool Equals(object obj) { lock (_lock) return _inner.Equals(obj); }
            public int GetHashCode() { lock (_lock) return _inner.GetHashCode(); }
            public Attribute Get(Attribute category) { lock (_lock) return _inner.Get(category); }
            public bool IsEmpty() { lock (_lock) return _inner.IsEmpty(); }
            public bool Remove(Attribute attribute) { lock (_lock) return _inner.Remove(attribute); }
            public bool Remove(Attribute category) { lock (_lock) return _inner.Remove(category); }
            public bool RemoveAll(AttributeSet attributes) { lock (_lock) return _inner.RemoveAll(attributes); }
            public int Size() { lock (_lock) return _inner.Size(); }
            public Attribute[] ToArray() { lock (_lock) return _inner.ToArray(); }
            public IEnumerator GetEnumerator() { lock (_lock) return _inner.GetEnumerator(); }
        }
    }

    // Test class
    public class javax_print_attribute_AttributeSetUtilitiesAutoTest
    {
        public void unmodifiableView_test_845(PrintServiceAttributeSet p0)
        {
            AttributeSetUtilities.unmodifiableView(p0);
        }

        public void unmodifiableView_test_846(PrintRequestAttributeSet p0)
        {
            AttributeSetUtilities.unmodifiableView(p0);
        }

        public void unmodifiableView_test_847(DocAttributeSet p0)
        {
            AttributeSetUtilities.unmodifiableView(p0);
        }

        public void unmodifiableView_test_848(PrintJobAttributeSet p0)
        {
            AttributeSetUtilities.unmodifiableView(p0);
        }

        public void unmodifiableView_test_849(AttributeSet p0)
        {
            AttributeSetUtilities.unmodifiableView(p0);
        }

        public void synchronizedView_test_850(PrintRequestAttributeSet p0)
        {
            AttributeSetUtilities.synchronizedView(p0);
        }

        public void synchronizedView_test_851(PrintJobAttributeSet p0)
        {
            AttributeSetUtilities.synchronizedView(p0);
        }

        public void synchronizedView_test_852(PrintServiceAttributeSet p0)
        {
            AttributeSetUtilities.synchronizedView(p0);
        }

        public void synchronizedView_test_853(DocAttributeSet p0)
        {
            AttributeSetUtilities.synchronizedView(p0);
        }

        public void synchronizedView_test_854(AttributeSet p0)
        {
            AttributeSetUtilities.synchronizedView(p0);
        }

        public void verifyAttributeCategory_test_855(object p0, Type p1)
        {
            AttributeSetUtilities.verifyAttributeCategory(p0, p1);
        }

        public void verifyAttributeValue_test_856(object p0, Type p1)
        {
            AttributeSetUtilities.verifyAttributeValue(p0, p1);
        }

        public void verifyCategoryForValue_test_857(Type p0, Attribute p1)
        {
            AttributeSetUtilities.verifyCategoryForValue(p0, p1);
        }
    }
}