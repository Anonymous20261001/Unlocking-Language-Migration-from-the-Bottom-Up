using System;
using System.Collections.Generic;
using System.Xml;

namespace Generated.Test
{
    // C# equivalent of javax.xml.stream.XMLEventReader
    public interface XMLEventReader : IDisposable
    {
        object Next();
        bool HasNext();
        object GetProperty(string name);
        void Remove();
        object GetElementText();
        object NextEvent();
        object NextTag();
        object GetAttributeValue(string namespaceUri, string localName);
        object GetAttributeValue(string localName);
        object Peek();
        void Close();
    }

    // C# equivalent of javax.xml.stream.util.EventReaderDelegate
    public class EventReaderDelegate : XMLEventReader
    {
        private XMLEventReader parent;

        public EventReaderDelegate()
        {
            parent = null;
        }

        public EventReaderDelegate(XMLEventReader reader)
        {
            parent = reader;
        }

        public void SetParent(XMLEventReader reader)
        {
            parent = reader;
        }

        public XMLEventReader GetParent()
        {
            return parent;
        }

        public object Next()
        {
            if (parent != null)
                return parent.Next();
            throw new InvalidOperationException("No parent reader set");
        }

        public bool HasNext()
        {
            if (parent != null)
                return parent.HasNext();
            throw new InvalidOperationException("No parent reader set");
        }

        public object GetProperty(string name)
        {
            if (parent != null)
                return parent.GetProperty(name);
            throw new InvalidOperationException("No parent reader set");
        }

        public void Remove()
        {
            if (parent != null)
                parent.Remove();
            throw new InvalidOperationException("No parent reader set");
        }

        public object GetElementText()
        {
            if (parent != null)
                return parent.GetElementText();
            throw new InvalidOperationException("No parent reader set");
        }

        public object NextEvent()
        {
            if (parent != null)
                return parent.NextEvent();
            throw new InvalidOperationException("No parent reader set");
        }

        public object NextTag()
        {
            if (parent != null)
                return parent.NextTag();
            throw new InvalidOperationException("No parent reader set");
        }

        public object GetAttributeValue(string namespaceUri, string localName)
        {
            if (parent != null)
                return parent.GetAttributeValue(namespaceUri, localName);
            throw new InvalidOperationException("No parent reader set");
        }

        public object GetAttributeValue(string localName)
        {
            if (parent != null)
                return parent.GetAttributeValue(localName);
            throw new InvalidOperationException("No parent reader set");
        }

        public object Peek()
        {
            if (parent != null)
                return parent.Peek();
            throw new InvalidOperationException("No parent reader set");
        }

        public void Close()
        {
            if (parent != null)
                parent.Close();
            throw new InvalidOperationException("No parent reader set");
        }

        public void Dispose()
        {
            Close();
        }
    }

    public class javax_xml_stream_util_EventReaderDelegateAutoTest
    {
        public void remove_test_4598()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.Remove();
        }

        public void getProperty_test_4599(string p0)
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.GetProperty(p0);
        }

        public void hasNext_test_4600()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.HasNext();
        }

        public void next_test_4601()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.Next();
        }

        public void getParent_test_4602()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.GetParent();
        }

        public void setParent_test_4603(XMLEventReader p0)
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.SetParent(p0);
        }
    }
}