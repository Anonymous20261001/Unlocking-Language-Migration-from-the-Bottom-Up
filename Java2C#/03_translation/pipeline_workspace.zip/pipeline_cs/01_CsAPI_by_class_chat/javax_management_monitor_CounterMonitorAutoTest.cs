using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Minimal Number abstraction (Java's java.lang.Number)
    public abstract class Number
    {
        public abstract int IntValue();
        public abstract long LongValue();
        public abstract float FloatValue();
        public abstract double DoubleValue();
    }

    // Minimal ObjectName (Java's javax.management.ObjectName)
    public class ObjectName
    {
        private string _name;
        public ObjectName(string name) { _name = name; }
        public override string ToString() { return _name; }
    }

    // Minimal NotificationInfo (Java's javax.management.NotificationInfo)
    public class NotificationInfo
    {
        public string[] Types { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }

    // Minimal MBeanNotificationInfo (Java's javax.management.MBeanNotificationInfo)
    public class MBeanNotificationInfo : NotificationInfo
    {
        public MBeanNotificationInfo(string[] types, string name, string description)
        {
            Types = types;
            Name = name;
            Description = description;
        }
    }

    // Minimal Monitor (base class for CounterMonitor)
    public abstract class Monitor
    {
        public virtual void Start() { }
        public virtual void Stop() { }
        public virtual NotificationInfo[] GetNotificationInfo() { return new NotificationInfo[0]; }
    }

    // CounterMonitor equivalent (Java's javax.management.monitor.CounterMonitor)
    public class CounterMonitor : Monitor
    {
        private Number _initThreshold;
        private Number _modulus;
        private bool _notify;
        private bool _differenceMode;
        private Number _offset;
        private Number _threshold;
        private Dictionary<ObjectName, Number> _derivedGauges = new Dictionary<ObjectName, Number>();
        private Dictionary<ObjectName, long> _derivedGaugeTimeStamps = new Dictionary<ObjectName, long>();
        private Dictionary<ObjectName, Number> _thresholds = new Dictionary<ObjectName, Number>();

        public Number GetInitThreshold() { return _initThreshold; }
        public Number GetModulus() { return _modulus; }
        public void SetModulus(Number p0) { _modulus = p0; }
        public bool GetNotify() { return _notify; }
        public void SetNotify(bool p0) { _notify = p0; }
        public bool GetDifferenceMode() { return _differenceMode; }
        public void SetDifferenceMode(bool p0) { _differenceMode = p0; }

        public override NotificationInfo[] GetNotificationInfo()
        {
            return new NotificationInfo[]
            {
                new MBeanNotificationInfo(
                    new string[] { "jmx.monitor.error.runtime", "jmx.monitor.error.mbean", "jmx.monitor.error.attribute", "jmx.monitor.error.type", "jmx.monitor.counter.threshold" },
                    "javax.management.monitor.CounterMonitorNotification",
                    "CounterMonitor notifications")
            };
        }

        public Number GetDerivedGauge(ObjectName p0)
        {
            if (_derivedGauges.ContainsKey(p0))
                return _derivedGauges[p0];
            return null;
        }

        public Number GetDerivedGauge()
        {
            // Return first derived gauge or null
            foreach (var kvp in _derivedGauges)
                return kvp.Value;
            return null;
        }

        public long GetDerivedGaugeTimeStamp(ObjectName p0)
        {
            if (_derivedGaugeTimeStamps.ContainsKey(p0))
                return _derivedGaugeTimeStamps[p0];
            return 0;
        }

        public long GetDerivedGaugeTimeStamp()
        {
            // Return first timestamp or 0
            foreach (var kvp in _derivedGaugeTimeStamps)
                return kvp.Value;
            return 0;
        }

        public Number GetThreshold(ObjectName p0)
        {
            if (_thresholds.ContainsKey(p0))
                return _thresholds[p0];
            return null;
        }

        public Number GetThreshold()
        {
            // Return first threshold or null
            foreach (var kvp in _thresholds)
                return kvp.Value;
            return null;
        }

        public void SetInitThreshold(Number p0) { _initThreshold = p0; }

        public override void Start() { base.Start(); }
        public override void Stop() { base.Stop(); }

        public Number GetOffset() { return _offset; }
        public void SetOffset(Number p0) { _offset = p0; }
        public void SetThreshold(Number p0) { _threshold = p0; }
    }

    // Test class
    public class javax_management_monitor_CounterMonitorAutoTest
    {
        public void getInitThreshold_test_3090()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetInitThreshold();
        }

        public void getModulus_test_3091()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetModulus();
        }

        public void setModulus_test_3092(Number p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetModulus(p0);
        }

        public void getNotify_test_3093()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetNotify();
        }

        public void setNotify_test_3094(bool p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetNotify(p0);
        }

        public void getDifferenceMode_test_3095()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetDifferenceMode();
        }

        public void setDifferenceMode_test_3096(bool p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetDifferenceMode(p0);
        }

        public void getNotificationInfo_test_3097()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetNotificationInfo();
        }

        public void getDerivedGauge_test_3098(ObjectName p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetDerivedGauge(p0);
        }

        public void getDerivedGauge_test_3099()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetDerivedGauge();
        }

        public void getDerivedGaugeTimeStamp_test_3100(ObjectName p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetDerivedGaugeTimeStamp(p0);
        }

        public void getDerivedGaugeTimeStamp_test_3101()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetDerivedGaugeTimeStamp();
        }

        public void getThreshold_test_3102(ObjectName p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetThreshold(p0);
        }

        public void getThreshold_test_3103()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetThreshold();
        }

        public void setInitThreshold_test_3104(Number p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetInitThreshold(p0);
        }

        public void start_test_3105()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.Start();
        }

        public void stop_test_3106()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.Stop();
        }

        public void getOffset_test_3107()
        {
            CounterMonitor instance = new CounterMonitor();
            instance.GetOffset();
        }

        public void setOffset_test_3108(Number p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetOffset(p0);
        }

        public void setThreshold_test_3109(Number p0)
        {
            CounterMonitor instance = new CounterMonitor();
            instance.SetThreshold(p0);
        }
    }
}