namespace Generated.Test
{
    public class java_lang_ref_ReferenceAutoTest
    {
        public void reachabilityFence_test_10486(object p0)
        {
            System.GC.KeepAlive(p0);
        }
    }
}