namespace Generated.Test
{
    public class java_lang_ByteAutoTest
    {
        public void compareUnsigned_test_1967(byte p0, byte p1)
        {
            ByteHelper.compareUnsigned(p0, p1);
        }

        public void compareTo_test_1968(Byte p0, byte c0)
        {
            Byte instance = new Byte(c0);
            instance.compareTo(p0);
        }

        public void compare_test_1969(byte p0, byte p1)
        {
            ByteHelper.compare(p0, p1);
        }

        public void byteValue_test_1970(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.byteValue();
        }

        public void shortValue_test_1971(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.shortValue();
        }

        public void intValue_test_1972(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.intValue();
        }

        public void longValue_test_1973(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.longValue();
        }

        public void floatValue_test_1974(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.floatValue();
        }

        public void doubleValue_test_1975(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.doubleValue();
        }

        public void valueOf_test_1976(string p0)
        {
            ByteHelper.valueOf(p0);
        }

        public void valueOf_test_1977(string p0, int p1)
        {
            ByteHelper.valueOf(p0, p1);
        }

        public void valueOf_test_1978(byte p0)
        {
            ByteHelper.valueOf(p0);
        }

        public void decode_test_1979(string p0)
        {
            ByteHelper.decode(p0);
        }

        public void describeConstable_test_1980(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.describeConstable();
        }

        public void toUnsignedLong_test_1981(byte p0)
        {
            ByteHelper.toUnsignedLong(p0);
        }

        public void toUnsignedInt_test_1982(byte p0)
        {
            ByteHelper.toUnsignedInt(p0);
        }

        public void parseByte_test_1983(string p0)
        {
            ByteHelper.parseByte(p0);
        }

        public void parseByte_test_1984(string p0, int p1)
        {
            ByteHelper.parseByte(p0, p1);
        }
    }

    public class Byte
    {
        private byte value;

        public Byte(byte value)
        {
            this.value = value;
        }

        public int compareTo(Byte other)
        {
            return ByteHelper.compare(this.value, other.value);
        }

        public byte byteValue()
        {
            return value;
        }

        public short shortValue()
        {
            return value;
        }

        public int intValue()
        {
            return value;
        }

        public long longValue()
        {
            return value;
        }

        public float floatValue()
        {
            return value;
        }

        public double doubleValue()
        {
            return value;
        }

        public object describeConstable()
        {
            return this;
        }
    }

    public static class ByteHelper
    {
        public static int compareUnsigned(byte x, byte y)
        {
            return (int)(x & 0xFF) - (int)(y & 0xFF);
        }

        public static int compare(byte x, byte y)
        {
            return x - y;
        }

        public static Byte valueOf(string s)
        {
            return new Byte(parseByte(s));
        }

        public static Byte valueOf(string s, int radix)
        {
            return new Byte(parseByte(s, radix));
        }

        public static Byte valueOf(byte b)
        {
            return new Byte(b);
        }

        public static Byte decode(string nm)
        {
            return new Byte(parseByte(nm));
        }

        public static long toUnsignedLong(byte x)
        {
            return (long)(x & 0xFF);
        }

        public static int toUnsignedInt(byte x)
        {
            return x & 0xFF;
        }

        public static byte parseByte(string s)
        {
            return byte.Parse(s);
        }

        public static byte parseByte(string s, int radix)
        {
            return (byte)System.Convert.ToInt32(s, radix);
        }
    }
}