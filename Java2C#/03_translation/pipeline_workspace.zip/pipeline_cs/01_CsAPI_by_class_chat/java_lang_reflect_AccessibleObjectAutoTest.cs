namespace Generated.Test
{
    public class java_lang_reflect_AccessibleObjectAutoTest
    {
        public void setAccessible_test_35(AccessibleObject[] p0, bool p1)
        {
            AccessibleObject.SetAccessible(p0, p1);
        }
    }

    public class AccessibleObject
    {
        public static void SetAccessible(AccessibleObject[] array, bool flag)
        {
            foreach (var obj in array)
            {
                obj.SetAccessible(flag);
            }
        }

        public virtual void SetAccessible(bool flag)
        {
            // Base implementation - no-op
        }
    }
}