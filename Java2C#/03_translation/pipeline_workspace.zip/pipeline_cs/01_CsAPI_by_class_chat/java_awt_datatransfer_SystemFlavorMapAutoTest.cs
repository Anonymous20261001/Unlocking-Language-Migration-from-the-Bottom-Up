namespace Generated.Test
{
    public class java_awt_datatransfer_SystemFlavorMapAutoTest
    {
        public void isJavaMIMEType_test_12438(string p0)
        {
            SystemFlavorMap.isJavaMIMEType(p0);
        }

        public void decodeJavaMIMEType_test_12439(string p0)
        {
            SystemFlavorMap.decodeJavaMIMEType(p0);
        }

        public void encodeDataFlavor_test_12440(DataFlavor p0)
        {
            SystemFlavorMap.encodeDataFlavor(p0);
        }

        public void encodeJavaMIMEType_test_12441(string p0)
        {
            SystemFlavorMap.encodeJavaMIMEType(p0);
        }

        public void getDefaultFlavorMap_test_12442()
        {
            SystemFlavorMap.getDefaultFlavorMap();
        }
    }

    public class SystemFlavorMap
    {
        public static bool isJavaMIMEType(string mimeType)
        {
            // Implementation based on Java's SystemFlavorMap.isJavaMIMEType
            return mimeType != null && mimeType.StartsWith("application/x-java-");
        }

        public static string decodeJavaMIMEType(string mimeType)
        {
            // Implementation based on Java's SystemFlavorMap.decodeJavaMIMEType
            if (mimeType == null)
                return null;
            if (mimeType.StartsWith("application/x-java-serialized-object"))
                return mimeType;
            if (mimeType.StartsWith("application/x-java-"))
                return mimeType.Substring("application/x-java-".Length);
            return mimeType;
        }

        public static string encodeDataFlavor(DataFlavor flavor)
        {
            // Implementation based on Java's SystemFlavorMap.encodeDataFlavor
            if (flavor == null)
                return null;
            return "application/x-java-serialized-object; class=" + flavor.GetType().FullName;
        }

        public static string encodeJavaMIMEType(string mimeType)
        {
            // Implementation based on Java's SystemFlavorMap.encodeJavaMIMEType
            if (mimeType == null)
                return null;
            return "application/x-java-" + mimeType;
        }

        public static object getDefaultFlavorMap()
        {
            // Implementation based on Java's SystemFlavorMap.getDefaultFlavorMap
            return new SystemFlavorMap();
        }
    }

    public class DataFlavor
    {
        // Minimal DataFlavor class for testing purposes
        public string MimeType { get; set; }
        public string HumanPresentableName { get; set; }

        public DataFlavor(string mimeType, string humanPresentableName)
        {
            MimeType = mimeType;
            HumanPresentableName = humanPresentableName;
        }

        public DataFlavor()
        {
        }

        public override string ToString()
        {
            return MimeType;
        }
    }
}