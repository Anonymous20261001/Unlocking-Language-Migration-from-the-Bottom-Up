namespace Generated.Test;

using System;

public class Short
{
    private readonly short value;

    public Short(short value)
    {
        this.value = value;
    }

    public static int CompareUnsigned(short x, short y)
    {
        return (int)((ushort)x - (ushort)y);
    }

    public static short ReverseBytes(short value)
    {
        return (short)(((value & 0xFF) << 8) | ((value >> 8) & 0xFF));
    }

    public int CompareTo(Short other)
    {
        if (other == null) return 1;
        return value.CompareTo(other.value);
    }

    public static int Compare(short x, short y)
    {
        return x.CompareTo(y);
    }

    public byte ByteValue()
    {
        return (byte)value;
    }

    public short ShortValue()
    {
        return value;
    }

    public int IntValue()
    {
        return value;
    }

    public long LongValue()
    {
        return value;
    }

    public float FloatValue()
    {
        return value;
    }

    public double DoubleValue()
    {
        return value;
    }

    public static Short ValueOf(string s, int radix)
    {
        return new Short(ParseShort(s, radix));
    }

    public static Short ValueOf(string s)
    {
        return new Short(ParseShort(s));
    }

    public static Short ValueOf(short value)
    {
        return new Short(value);
    }

    public static Short Decode(string nm)
    {
        if (nm == null) throw new ArgumentNullException(nameof(nm));
        int radix = 10;
        string s = nm;
        int index = 0;
        bool negative = false;

        if (s.StartsWith("-"))
        {
            negative = true;
            index++;
        }
        else if (s.StartsWith("+"))
        {
            index++;
        }

        if (s.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || s.StartsWith("#", StringComparison.OrdinalIgnoreCase))
        {
            index += 2;
            radix = 16;
        }
        else if (s.StartsWith("0", StringComparison.Ordinal) && s.Length > index + 1)
        {
            index++;
            radix = 8;
        }

        string sub = s.Substring(index);
        if (sub.Length == 0) throw new FormatException("Invalid short format: " + nm);

        short result = ParseShort(sub, radix);
        return new Short(negative ? (short)-result : result);
    }

    public object DescribeConstable()
    {
        return this;
    }

    public static long ToUnsignedLong(short value)
    {
        return (ushort)value;
    }

    public static int ToUnsignedInt(short value)
    {
        return (ushort)value;
    }

    public static short ParseShort(string s)
    {
        return ParseShort(s, 10);
    }

    public static short ParseShort(string s, int radix)
    {
        if (s == null) throw new ArgumentNullException(nameof(s));
        if (radix < 2 || radix > 36) throw new FormatException("Invalid radix: " + radix);

        int result = 0;
        bool negative = false;
        int i = 0;
        int len = s.Length;
        int limit = -short.MaxValue;

        if (len > 0)
        {
            char firstChar = s[0];
            if (firstChar < '0')
            {
                if (firstChar == '-')
                {
                    negative = true;
                    limit = short.MinValue;
                }
                else if (firstChar != '+')
                {
                    throw new FormatException("Invalid short: " + s);
                }
                if (len == 1)
                {
                    throw new FormatException("Invalid short: " + s);
                }
                i++;
            }
            int multmin = limit / radix;
            int digit;
            while (i < len)
            {
                digit = Character.Digit(s[i++], radix);
                if (digit < 0)
                {
                    throw new FormatException("Invalid short: " + s);
                }
                if (result < multmin)
                {
                    throw new FormatException("Invalid short: " + s);
                }
                result *= radix;
                if (result < limit + digit)
                {
                    throw new FormatException("Invalid short: " + s);
                }
                result -= digit;
            }
        }
        else
        {
            throw new FormatException("Invalid short: " + s);
        }
        return negative ? (short)result : (short)-result;
    }

    public override string ToString()
    {
        return value.ToString();
    }

    public override bool Equals(object obj)
    {
        if (obj is Short other)
        {
            return value == other.value;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return value.GetHashCode();
    }
}

public static class Character
{
    public static int Digit(char ch, int radix)
    {
        int val;
        if (ch >= '0' && ch <= '9')
        {
            val = ch - '0';
        }
        else if (ch >= 'a' && ch <= 'z')
        {
            val = ch - 'a' + 10;
        }
        else if (ch >= 'A' && ch <= 'Z')
        {
            val = ch - 'A' + 10;
        }
        else
        {
            return -1;
        }
        return val < radix ? val : -1;
    }
}

public class java_lang_ShortAutoTest
{
    public void compareUnsigned_test_11079(short p0, short p1)
    {
        Short.CompareUnsigned(p0, p1);
    }

    public void reverseBytes_test_11080(short p0)
    {
        Short.ReverseBytes(p0);
    }

    public void compareTo_test_11081(Short p0, short c0)
    {
        Short instance = new Short(c0);
        instance.CompareTo(p0);
    }

    public void compare_test_11082(short p0, short p1)
    {
        Short.Compare(p0, p1);
    }

    public void byteValue_test_11083(short c0)
    {
        Short instance = new Short(c0);
        instance.ByteValue();
    }

    public void shortValue_test_11084(short c0)
    {
        Short instance = new Short(c0);
        instance.ShortValue();
    }

    public void intValue_test_11085(short c0)
    {
        Short instance = new Short(c0);
        instance.IntValue();
    }

    public void longValue_test_11086(short c0)
    {
        Short instance = new Short(c0);
        instance.LongValue();
    }

    public void floatValue_test_11087(short c0)
    {
        Short instance = new Short(c0);
        instance.FloatValue();
    }

    public void doubleValue_test_11088(short c0)
    {
        Short instance = new Short(c0);
        instance.DoubleValue();
    }

    public void valueOf_test_11089(string p0, int p1)
    {
        Short.ValueOf(p0, p1);
    }

    public void valueOf_test_11090(string p0)
    {
        Short.ValueOf(p0);
    }

    public void valueOf_test_11091(short p0)
    {
        Short.ValueOf(p0);
    }

    public void decode_test_11092(string p0)
    {
        Short.Decode(p0);
    }

    public void describeConstable_test_11093(short c0)
    {
        Short instance = new Short(c0);
        instance.DescribeConstable();
    }

    public void toUnsignedLong_test_11094(short p0)
    {
        Short.ToUnsignedLong(p0);
    }

    public void toUnsignedInt_test_11095(short p0)
    {
        Short.ToUnsignedInt(p0);
    }

    public void parseShort_test_11096(string p0)
    {
        Short.ParseShort(p0);
    }

    public void parseShort_test_11097(string p0, int p1)
    {
        Short.ParseShort(p0, p1);
    }
}