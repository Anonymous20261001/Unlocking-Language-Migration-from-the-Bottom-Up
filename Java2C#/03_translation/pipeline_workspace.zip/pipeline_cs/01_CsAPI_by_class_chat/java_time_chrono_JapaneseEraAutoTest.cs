namespace Generated.Test
{
    public class java_time_chrono_JapaneseEraAutoTest
    {
        public void values_test_5974()
        {
            JapaneseEra.Values();
        }

        public void valueOf_test_5975(string p0)
        {
            JapaneseEra.ValueOf(p0);
        }

        public void of_test_5976(int p0)
        {
            JapaneseEra.Of(p0);
        }
    }

    public class JapaneseEra
    {
        public static JapaneseEra[] Values()
        {
            // Return all Japanese eras
            return new JapaneseEra[]
            {
                new JapaneseEra("Meiji", 1),
                new JapaneseEra("Taisho", 2),
                new JapaneseEra("Showa", 3),
                new JapaneseEra("Heisei", 4),
                new JapaneseEra("Reiwa", 5)
            };
        }

        public static JapaneseEra ValueOf(string name)
        {
            foreach (var era in Values())
            {
                if (era.Name == name)
                {
                    return era;
                }
            }
            throw new System.ArgumentException("Invalid era name: " + name);
        }

        public static JapaneseEra Of(int eraValue)
        {
            foreach (var era in Values())
            {
                if (era.Value == eraValue)
                {
                    return era;
                }
            }
            throw new System.ArgumentException("Invalid era value: " + eraValue);
        }

        public string Name { get; private set; }
        public int Value { get; private set; }

        private JapaneseEra(string name, int value)
        {
            Name = name;
            Value = value;
        }
    }
}