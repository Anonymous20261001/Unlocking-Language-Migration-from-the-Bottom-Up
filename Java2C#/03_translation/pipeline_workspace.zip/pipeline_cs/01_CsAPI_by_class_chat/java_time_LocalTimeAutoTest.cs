namespace Generated.Test
{
    public class java_time_LocalTimeAutoTest
    {
        public void of_test_8080(int p0, int p1, int p2, int p3)
        {
            LocalTime.Of(p0, p1, p2, p3);
        }

        public void of_test_8081(int p0, int p1)
        {
            LocalTime.Of(p0, p1);
        }

        public void of_test_8082(int p0, int p1, int p2)
        {
            LocalTime.Of(p0, p1, p2);
        }

        public void from_test_8083(TemporalAccessor p0)
        {
            LocalTime.From(p0);
        }

        public void parse_test_8084(CharSequence p0)
        {
            LocalTime.Parse(p0);
        }

        public void parse_test_8085(CharSequence p0, DateTimeFormatter p1)
        {
            LocalTime.Parse(p0, p1);
        }

        public void now_test_8086()
        {
            LocalTime.Now();
        }

        public void now_test_8087(Clock p0)
        {
            LocalTime.Now(p0);
        }

        public void now_test_8088(ZoneId p0)
        {
            LocalTime.Now(p0);
        }

        public void ofInstant_test_8089(Instant p0, ZoneId p1)
        {
            LocalTime.OfInstant(p0, p1);
        }

        public void ofNanoOfDay_test_8090(long p0)
        {
            LocalTime.OfNanoOfDay(p0);
        }

        public void ofSecondOfDay_test_8091(long p0)
        {
            LocalTime.OfSecondOfDay(p0);
        }
    }

    public class LocalTime
    {
        public static LocalTime Of(int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalTime(hour, minute, second, nanoOfSecond);
        }

        public static LocalTime Of(int hour, int minute)
        {
            return new LocalTime(hour, minute, 0, 0);
        }

        public static LocalTime Of(int hour, int minute, int second)
        {
            return new LocalTime(hour, minute, second, 0);
        }

        public static LocalTime From(TemporalAccessor temporal)
        {
            return new LocalTime(temporal.Hour, temporal.Minute, temporal.Second, temporal.Nano);
        }

        public static LocalTime Parse(CharSequence text)
        {
            return Parse(text, DateTimeFormatter.ISO_LOCAL_TIME);
        }

        public static LocalTime Parse(CharSequence text, DateTimeFormatter formatter)
        {
            return formatter.Parse(text);
        }

        public static LocalTime Now()
        {
            return Now(Clock.SystemUTC);
        }

        public static LocalTime Now(Clock clock)
        {
            return OfInstant(clock.Instant(), clock.Zone);
        }

        public static LocalTime Now(ZoneId zone)
        {
            return Now(Clock.System(zone));
        }

        public static LocalTime OfInstant(Instant instant, ZoneId zone)
        {
            long epochDay = instant.EpochSecond / 86400;
            long nanoOfDay = (instant.EpochSecond % 86400) * 1000000000L + instant.Nano;
            return OfNanoOfDay(nanoOfDay);
        }

        public static LocalTime OfNanoOfDay(long nanoOfDay)
        {
            int hour = (int)(nanoOfDay / 3600000000000L);
            int minute = (int)((nanoOfDay % 3600000000000L) / 60000000000L);
            int second = (int)((nanoOfDay % 60000000000L) / 1000000000L);
            int nano = (int)(nanoOfDay % 1000000000L);
            return new LocalTime(hour, minute, second, nano);
        }

        public static LocalTime OfSecondOfDay(long secondOfDay)
        {
            return OfNanoOfDay(secondOfDay * 1000000000L);
        }

        private int hour;
        private int minute;
        private int second;
        private int nano;

        private LocalTime(int hour, int minute, int second, int nano)
        {
            this.hour = hour;
            this.minute = minute;
            this.second = second;
            this.nano = nano;
        }
    }

    public class TemporalAccessor
    {
        public virtual int Hour { get; }
        public virtual int Minute { get; }
        public virtual int Second { get; }
        public virtual int Nano { get; }
    }

    public class DateTimeFormatter
    {
        public static DateTimeFormatter ISO_LOCAL_TIME = new DateTimeFormatter();

        public LocalTime Parse(CharSequence text)
        {
            string[] parts = text.ToString().Split(':');
            int hour = int.Parse(parts[0]);
            int minute = int.Parse(parts[1]);
            int second = parts.Length > 2 ? int.Parse(parts[2].Split('.')[0]) : 0;
            int nano = 0;
            if (parts.Length > 2 && parts[2].Contains("."))
            {
                string nanoPart = parts[2].Split('.')[1];
                nano = int.Parse(nanoPart.PadRight(9, '0').Substring(0, 9));
            }
            return new LocalTime(hour, minute, second, nano);
        }
    }

    public class Clock
    {
        public static Clock SystemUTC = new Clock(Instant.Now, ZoneId.UTC);

        public static Clock System(ZoneId zone)
        {
            return new Clock(Instant.Now, zone);
        }

        public Instant Instant { get; }
        public ZoneId Zone { get; }

        private Clock(Instant instant, ZoneId zone)
        {
            Instant = instant;
            Zone = zone;
        }
    }

    public class Instant
    {
        public static Instant Now => new Instant(DateTimeOffset.UtcNow.ToUnixTimeSeconds(), DateTimeOffset.UtcNow.Nanosecond);

        public long EpochSecond { get; }
        public int Nano { get; }

        public Instant(long epochSecond, int nano)
        {
            EpochSecond = epochSecond;
            Nano = nano;
        }
    }

    public class ZoneId
    {
        public static ZoneId UTC = new ZoneId("UTC");

        public string Id { get; }

        public ZoneId(string id)
        {
            Id = id;
        }
    }

    public class CharSequence
    {
        private string value;

        public CharSequence(string value)
        {
            this.value = value;
        }

        public override string ToString()
        {
            return value;
        }
    }
}