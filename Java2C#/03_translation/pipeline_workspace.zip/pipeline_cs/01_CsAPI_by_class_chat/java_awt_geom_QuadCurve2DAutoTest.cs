using System;

namespace Generated.Test
{
    public class QuadCurve2D
    {
        public static double GetFlatnessSq(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            double dx = ctrlx - (x1 + x2) / 2.0;
            double dy = ctrly - (y1 + y2) / 2.0;
            return dx * dx + dy * dy;
        }

        public static double GetFlatnessSq(double[] coords, int offset)
        {
            return GetFlatnessSq(coords[offset], coords[offset + 1], coords[offset + 2], coords[offset + 3], coords[offset + 4], coords[offset + 5]);
        }

        public static double GetFlatness(double[] coords, int offset)
        {
            return Math.Sqrt(GetFlatnessSq(coords, offset));
        }

        public static double GetFlatness(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            return Math.Sqrt(GetFlatnessSq(x1, y1, ctrlx, ctrly, x2, y2));
        }

        public static void Subdivide(double[] src, int srcoff, double[] left, int leftoff, double[] right, int rightoff)
        {
            double x1 = src[srcoff];
            double y1 = src[srcoff + 1];
            double ctrlx = src[srcoff + 2];
            double ctrly = src[srcoff + 3];
            double x2 = src[srcoff + 4];
            double y2 = src[srcoff + 5];

            if (left != null)
            {
                left[leftoff] = x1;
                left[leftoff + 1] = y1;
            }
            if (right != null)
            {
                right[rightoff + 4] = x2;
                right[rightoff + 5] = y2;
            }

            double ctrlx1 = (x1 + ctrlx) / 2.0;
            double ctrly1 = (y1 + ctrly) / 2.0;
            double ctrlx2 = (x2 + ctrlx) / 2.0;
            double ctrly2 = (y2 + ctrly) / 2.0;

            double ctrlx12 = (ctrlx1 + ctrlx2) / 2.0;
            double ctrly12 = (ctrly1 + ctrly2) / 2.0;

            if (left != null)
            {
                left[leftoff + 2] = ctrlx1;
                left[leftoff + 3] = ctrly1;
                left[leftoff + 4] = ctrlx12;
                left[leftoff + 5] = ctrly12;
            }
            if (right != null)
            {
                right[rightoff] = ctrlx12;
                right[rightoff + 1] = ctrly12;
                right[rightoff + 2] = ctrlx2;
                right[rightoff + 3] = ctrly2;
            }
        }

        public static void Subdivide(QuadCurve2D src, QuadCurve2D left, QuadCurve2D right)
        {
            double x1 = src.GetX1();
            double y1 = src.GetY1();
            double ctrlx = src.GetCtrlX();
            double ctrly = src.GetCtrlY();
            double x2 = src.GetX2();
            double y2 = src.GetY2();

            double ctrlx1 = (x1 + ctrlx) / 2.0;
            double ctrly1 = (y1 + ctrly) / 2.0;
            double ctrlx2 = (x2 + ctrlx) / 2.0;
            double ctrly2 = (y2 + ctrly) / 2.0;

            double ctrlx12 = (ctrlx1 + ctrlx2) / 2.0;
            double ctrly12 = (ctrly1 + ctrly2) / 2.0;

            if (left != null)
            {
                left.SetCurve(x1, y1, ctrlx1, ctrly1, ctrlx12, ctrly12);
            }
            if (right != null)
            {
                right.SetCurve(ctrlx12, ctrly12, ctrlx2, ctrly2, x2, y2);
            }
        }

        public static int SolveQuadratic(double[] eqn, double[] res)
        {
            double a = eqn[2];
            double b = eqn[1];
            double c = eqn[0];
            int roots = 0;

            if (a == 0.0)
            {
                if (b == 0.0)
                {
                    return 0;
                }
                if (res != null)
                {
                    res[roots++] = -c / b;
                }
                return roots;
            }

            double dis = b * b - 4.0 * a * c;
            if (dis < 0.0)
            {
                return 0;
            }

            dis = Math.Sqrt(dis);
            double a2 = 2.0 * a;
            if (res != null)
            {
                res[roots++] = (-b + dis) / a2;
                if (dis != 0.0)
                {
                    res[roots++] = (-b - dis) / a2;
                }
            }
            else
            {
                roots = (dis == 0.0) ? 1 : 2;
            }
            return roots;
        }

        public static int SolveQuadratic(double[] eqn)
        {
            return SolveQuadratic(eqn, null);
        }

        // Instance members for the QuadCurve2D class
        private double x1, y1, ctrlx, ctrly, x2, y2;

        public double GetX1() { return x1; }
        public double GetY1() { return y1; }
        public double GetCtrlX() { return ctrlx; }
        public double GetCtrlY() { return ctrly; }
        public double GetX2() { return x2; }
        public double GetY2() { return y2; }

        public void SetCurve(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.ctrlx = ctrlx;
            this.ctrly = ctrly;
            this.x2 = x2;
            this.y2 = y2;
        }
    }

    public class java_awt_geom_QuadCurve2DAutoTest
    {
        public void getFlatnessSq_test_10235(double p0, double p1, double p2, double p3, double p4, double p5)
        {
            QuadCurve2D.GetFlatnessSq(p0, p1, p2, p3, p4, p5);
        }

        public void getFlatnessSq_test_10236(double[] p0, int p1)
        {
            QuadCurve2D.GetFlatnessSq(p0, p1);
        }

        public void getFlatness_test_10237(double[] p0, int p1)
        {
            QuadCurve2D.GetFlatness(p0, p1);
        }

        public void getFlatness_test_10238(double p0, double p1, double p2, double p3, double p4, double p5)
        {
            QuadCurve2D.GetFlatness(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_10239(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5)
        {
            QuadCurve2D.Subdivide(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_10240(QuadCurve2D p0, QuadCurve2D p1, QuadCurve2D p2)
        {
            QuadCurve2D.Subdivide(p0, p1, p2);
        }

        public void solveQuadratic_test_10241(double[] p0, double[] p1)
        {
            QuadCurve2D.SolveQuadratic(p0, p1);
        }

        public void solveQuadratic_test_10242(double[] p0)
        {
            QuadCurve2D.SolveQuadratic(p0);
        }
    }
}