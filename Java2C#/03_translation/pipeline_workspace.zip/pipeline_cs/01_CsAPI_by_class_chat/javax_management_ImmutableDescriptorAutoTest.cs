using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    public interface Descriptor
    {
        string[] GetFieldNames();
        object[] GetFieldValues(string[] fieldNames);
        void SetField(string fieldName, object fieldValue);
        object GetFieldValue(string fieldName);
        void RemoveField(string fieldName);
        string GetFields();
        bool IsValid();
        void SetFields(string[] fieldNames, object[] fieldValues);
    }

    public class ImmutableDescriptor : Descriptor
    {
        private readonly Dictionary<string, object> _fields;

        public ImmutableDescriptor(string[] fields)
        {
            _fields = new Dictionary<string, object>();
            if (fields != null)
            {
                for (int i = 0; i < fields.Length; i += 2)
                {
                    if (i + 1 < fields.Length)
                    {
                        _fields[fields[i]] = fields[i + 1];
                    }
                }
            }
        }

        public ImmutableDescriptor(string[] fieldNames, object[] fieldValues)
        {
            _fields = new Dictionary<string, object>();
            if (fieldNames != null && fieldValues != null)
            {
                for (int i = 0; i < fieldNames.Length && i < fieldValues.Length; i++)
                {
                    _fields[fieldNames[i]] = fieldValues[i];
                }
            }
        }

        public string[] GetFieldNames()
        {
            return _fields.Keys.ToArray();
        }

        public object[] GetFieldValues(string[] fieldNames)
        {
            if (fieldNames == null)
            {
                return _fields.Values.ToArray();
            }
            var result = new object[fieldNames.Length];
            for (int i = 0; i < fieldNames.Length; i++)
            {
                result[i] = _fields.ContainsKey(fieldNames[i]) ? _fields[fieldNames[i]] : null;
            }
            return result;
        }

        public void SetField(string fieldName, object fieldValue)
        {
            throw new InvalidOperationException("ImmutableDescriptor cannot be modified");
        }

        public object GetFieldValue(string fieldName)
        {
            return _fields.ContainsKey(fieldName) ? _fields[fieldName] : null;
        }

        public void RemoveField(string fieldName)
        {
            throw new InvalidOperationException("ImmutableDescriptor cannot be modified");
        }

        public string GetFields()
        {
            var parts = new List<string>();
            foreach (var kvp in _fields)
            {
                parts.Add(kvp.Key + "=" + (kvp.Value?.ToString() ?? "null"));
            }
            return string.Join(",", parts);
        }

        public bool IsValid()
        {
            return true;
        }

        public void SetFields(string[] fieldNames, object[] fieldValues)
        {
            throw new InvalidOperationException("ImmutableDescriptor cannot be modified");
        }

        public static ImmutableDescriptor Union(Descriptor[] descriptors)
        {
            var merged = new Dictionary<string, object>();
            if (descriptors != null)
            {
                foreach (var descriptor in descriptors)
                {
                    if (descriptor != null)
                    {
                        var names = descriptor.GetFieldNames();
                        var values = descriptor.GetFieldValues(names);
                        for (int i = 0; i < names.Length; i++)
                        {
                            merged[names[i]] = values[i];
                        }
                    }
                }
            }
            var result = new ImmutableDescriptor(new string[0]);
            foreach (var kvp in merged)
            {
                result._fields[kvp.Key] = kvp.Value;
            }
            return result;
        }
    }

    public class javax_management_ImmutableDescriptorAutoTest
    {
        public void getFieldNames_test_5753(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.GetFieldNames();
        }

        public void getFieldValues_test_5754(string[] p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.GetFieldValues(p0);
        }

        public void setField_test_5755(string p0, object p1, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.SetField(p0, p1);
        }

        public void getFieldValue_test_5756(string p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.GetFieldValue(p0);
        }

        public void removeField_test_5757(string p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.RemoveField(p0);
        }

        public void getFields_test_5758(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.GetFields();
        }

        public void isValid_test_5759(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.IsValid();
        }

        public void setFields_test_5760(string[] p0, object[] p1, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.SetFields(p0, p1);
        }

        public void union_test_5761(Descriptor[] p0)
        {
            ImmutableDescriptor.Union(p0);
        }
    }
}