namespace Generated.Test
{
    public class FloatBuffer
    {
        private float[] _buffer;
        private int _position;
        private int _limit;
        private int _capacity;

        private FloatBuffer(float[] buffer, int offset, int length)
        {
            if (buffer == null)
                throw new System.ArgumentNullException(nameof(buffer));
            if (offset < 0 || length < 0 || offset + length > buffer.Length)
                throw new System.ArgumentOutOfRangeException();
            
            _buffer = buffer;
            _position = offset;
            _limit = offset + length;
            _capacity = buffer.Length;
        }

        private FloatBuffer(int capacity)
        {
            if (capacity < 0)
                throw new System.ArgumentException("Negative capacity");
            
            _buffer = new float[capacity];
            _position = 0;
            _limit = capacity;
            _capacity = capacity;
        }

        public static FloatBuffer Wrap(float[] array)
        {
            return new FloatBuffer(array, 0, array.Length);
        }

        public static FloatBuffer Wrap(float[] array, int offset, int length)
        {
            return new FloatBuffer(array, offset, length);
        }

        public static FloatBuffer Allocate(int capacity)
        {
            return new FloatBuffer(capacity);
        }
    }

    public class java_nio_FloatBufferAutoTest
    {
        public void wrap_test_4883(float[] p0)
        {
            FloatBuffer.Wrap(p0);
        }

        public void wrap_test_4884(float[] p0, int p1, int p2)
        {
            FloatBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_4885(int p0)
        {
            FloatBuffer.Allocate(p0);
        }
    }
}