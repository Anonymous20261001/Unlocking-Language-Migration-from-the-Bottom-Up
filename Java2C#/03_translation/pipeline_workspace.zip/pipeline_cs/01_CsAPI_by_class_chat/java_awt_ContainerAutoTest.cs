using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_awt_ContainerAutoTest
    {
        public void addPropertyChangeListener_test_2934(PropertyChangeListener p0)
        {
            Container instance = new Container();
            instance.addPropertyChangeListener(p0);
        }

        public void addPropertyChangeListener_test_2935(string p0, PropertyChangeListener p1)
        {
            Container instance = new Container();
            instance.addPropertyChangeListener(p0, p1);
        }

        public void setFont_test_2936(Font p0)
        {
            Container instance = new Container();
            instance.setFont(p0);
        }

        public void getComponentCount_test_2937()
        {
            Container instance = new Container();
            instance.getComponentCount();
        }

        public void paint_test_2938(Graphics p0)
        {
            Container instance = new Container();
            instance.paint(p0);
        }

        public void isFocusCycleRoot_test_2939()
        {
            Container instance = new Container();
            instance.isFocusCycleRoot();
        }

        public void isFocusCycleRoot_test_2940(Container p0)
        {
            Container instance = new Container();
            instance.isFocusCycleRoot(p0);
        }

        public void getFocusTraversalPolicy_test_2941()
        {
            Container instance = new Container();
            instance.getFocusTraversalPolicy();
        }

        public void setFocusTraversalPolicy_test_2942(FocusTraversalPolicy p0)
        {
            Container instance = new Container();
            instance.setFocusTraversalPolicy(p0);
        }

        public void getPreferredSize_test_2943()
        {
            Container instance = new Container();
            instance.getPreferredSize();
        }

        public void getMaximumSize_test_2944()
        {
            Container instance = new Container();
            instance.getMaximumSize();
        }

        public void getMinimumSize_test_2945()
        {
            Container instance = new Container();
            instance.getMinimumSize();
        }

        public void getInsets_test_2946()
        {
            Container instance = new Container();
            instance.getInsets();
        }

        public void getAlignmentY_test_2947()
        {
            Container instance = new Container();
            instance.getAlignmentY();
        }

        public void getAlignmentX_test_2948()
        {
            Container instance = new Container();
            instance.getAlignmentX();
        }

        public void setFocusTraversalKeys_test_2949(int p0, Set p1)
        {
            Container instance = new Container();
            instance.setFocusTraversalKeys(p0, p1);
        }

        public void getListeners_test_2950(Class p0)
        {
            Container instance = new Container();
            instance.getListeners(p0);
        }

        public void addNotify_test_2951()
        {
            Container instance = new Container();
            instance.addNotify();
        }

        public void removeNotify_test_2952()
        {
            Container instance = new Container();
            instance.removeNotify();
        }

        public void getComponents_test_2953()
        {
            Container instance = new Container();
            instance.getComponents();
        }

        public void preferredSize_test_2954()
        {
            Container instance = new Container();
            instance.preferredSize();
        }

        public void minimumSize_test_2955()
        {
            Container instance = new Container();
            instance.minimumSize();
        }

        public void insets_test_2956()
        {
            Container instance = new Container();
            instance.insets();
        }

        public void isValidateRoot_test_2957()
        {
            Container instance = new Container();
            instance.isValidateRoot();
        }

        public void countComponents_test_2958()
        {
            Container instance = new Container();
            instance.countComponents();
        }

        public void getComponentZOrder_test_2959(Component p0)
        {
            Container instance = new Container();
            instance.getComponentZOrder(p0);
        }

        public void layout_test_2960()
        {
            Container instance = new Container();
            instance.layout();
        }

        public void doLayout_test_2961()
        {
            Container instance = new Container();
            instance.doLayout();
        }

        public void getComponentAt_test_2962(Point p0)
        {
            Container instance = new Container();
            instance.getComponentAt(p0);
        }

        public void getComponentAt_test_2963(int p0, int p1)
        {
            Container instance = new Container();
            instance.getComponentAt(p0, p1);
        }

        public void deliverEvent_test_2964(Event p0)
        {
            Container instance = new Container();
            instance.deliverEvent(p0);
        }

        public void locate_test_2965(int p0, int p1)
        {
            Container instance = new Container();
            instance.locate(p0, p1);
        }

        public void findComponentAt_test_2966(int p0, int p1)
        {
            Container instance = new Container();
            instance.findComponentAt(p0, p1);
        }

        public void findComponentAt_test_2967(Point p0)
        {
            Container instance = new Container();
            instance.findComponentAt(p0);
        }

        public void isFocusTraversalPolicyProvider_test_2968()
        {
            Container instance = new Container();
            instance.isFocusTraversalPolicyProvider();
        }

        public void applyComponentOrientation_test_2969(ComponentOrientation p0)
        {
            Container instance = new Container();
            instance.applyComponentOrientation(p0);
        }

        public void addContainerListener_test_2970(ContainerListener p0)
        {
            Container instance = new Container();
            instance.addContainerListener(p0);
        }

        public void getLayout_test_2971()
        {
            Container instance = new Container();
            instance.getLayout();
        }

        public void setComponentZOrder_test_2972(Component p0, int p1)
        {
            Container instance = new Container();
            instance.setComponentZOrder(p0, p1);
        }

        public void setLayout_test_2973(LayoutManager p0)
        {
            Container instance = new Container();
            instance.setLayout(p0);
        }

        public void paintComponents_test_2974(Graphics p0)
        {
            Container instance = new Container();
            instance.paintComponents(p0);
        }

        public void printComponents_test_2975(Graphics p0)
        {
            Container instance = new Container();
            instance.printComponents(p0);
        }

        public void removeContainerListener_test_2976(ContainerListener p0)
        {
            Container instance = new Container();
            instance.removeContainerListener(p0);
        }

        public void getContainerListeners_test_2977()
        {
            Container instance = new Container();
            instance.getContainerListeners();
        }

        public void getMousePosition_test_2978(bool p0)
        {
            Container instance = new Container();
            instance.getMousePosition(p0);
        }

        public void isAncestorOf_test_2979(Component p0)
        {
            Container instance = new Container();
            instance.isAncestorOf(p0);
        }

        public void getFocusTraversalKeys_test_2980(int p0)
        {
            Container instance = new Container();
            instance.getFocusTraversalKeys(p0);
        }

        public void areFocusTraversalKeysSet_test_2981(int p0)
        {
            Container instance = new Container();
            instance.areFocusTraversalKeysSet(p0);
        }

        public void isFocusTraversalPolicySet_test_2982()
        {
            Container instance = new Container();
            instance.isFocusTraversalPolicySet();
        }

        public void setFocusCycleRoot_test_2983(bool p0)
        {
            Container instance = new Container();
            instance.setFocusCycleRoot(p0);
        }

        public void setFocusTraversalPolicyProvider_test_2984(bool p0)
        {
            Container instance = new Container();
            instance.setFocusTraversalPolicyProvider(p0);
        }

        public void transferFocusDownCycle_test_2985()
        {
            Container instance = new Container();
            instance.transferFocusDownCycle();
        }

        public void remove_test_2986(int p0)
        {
            Container instance = new Container();
            instance.remove(p0);
        }

        public void remove_test_2987(Component p0)
        {
            Container instance = new Container();
            instance.remove(p0);
        }

        public void update_test_2988(Graphics p0)
        {
            Container instance = new Container();
            instance.update(p0);
        }

        public void add_test_2989(Component p0)
        {
            Container instance = new Container();
            instance.add(p0);
        }

        public void add_test_2990(string p0, Component p1)
        {
            Container instance = new Container();
            instance.add(p0, p1);
        }

        public void add_test_2991(Component p0, object p1)
        {
            Container instance = new Container();
            instance.add(p0, p1);
        }

        public void add_test_2992(Component p0, object p1, int p2)
        {
            Container instance = new Container();
            instance.add(p0, p1, p2);
        }

        public void add_test_2993(Component p0, int p1)
        {
            Container instance = new Container();
            instance.add(p0, p1);
        }

        public void list_test_2994(PrintWriter p0, int p1)
        {
            Container instance = new Container();
            instance.list(p0, p1);
        }

        public void list_test_2995(PrintStream p0, int p1)
        {
            Container instance = new Container();
            instance.list(p0, p1);
        }

        public void validate_test_2996()
        {
            Container instance = new Container();
            instance.validate();
        }

        public void print_test_2997(Graphics p0)
        {
            Container instance = new Container();
            instance.print(p0);
        }

        public void removeAll_test_2998()
        {
            Container instance = new Container();
            instance.removeAll();
        }

        public void getComponent_test_2999(int p0)
        {
            Container instance = new Container();
            instance.getComponent(p0);
        }

        public void invalidate_test_3000()
        {
            Container instance = new Container();
            instance.invalidate();
        }
    }

    // Supporting classes
    public class Container
    {
        public void addPropertyChangeListener(PropertyChangeListener p0) { }
        public void addPropertyChangeListener(string p0, PropertyChangeListener p1) { }
        public void setFont(Font p0) { }
        public int getComponentCount() { return 0; }
        public void paint(Graphics p0) { }
        public bool isFocusCycleRoot() { return false; }
        public bool isFocusCycleRoot(Container p0) { return false; }
        public FocusTraversalPolicy getFocusTraversalPolicy() { return null; }
        public void setFocusTraversalPolicy(FocusTraversalPolicy p0) { }
        public object getPreferredSize() { return null; }
        public object getMaximumSize() { return null; }
        public object getMinimumSize() { return null; }
        public object getInsets() { return null; }
        public float getAlignmentY() { return 0; }
        public float getAlignmentX() { return 0; }
        public void setFocusTraversalKeys(int p0, Set p1) { }
        public object[] getListeners(Class p0) { return null; }
        public void addNotify() { }
        public void removeNotify() { }
        public Component[] getComponents() { return null; }
        public object preferredSize() { return null; }
        public object minimumSize() { return null; }
        public object insets() { return null; }
        public bool isValidateRoot() { return false; }
        public int countComponents() { return 0; }
        public int getComponentZOrder(Component p0) { return 0; }
        public void layout() { }
        public void doLayout() { }
        public Component getComponentAt(Point p0) { return null; }
        public Component getComponentAt(int p0, int p1) { return null; }
        public void deliverEvent(Event p0) { }
        public Component locate(int p0, int p1) { return null; }
        public Component findComponentAt(int p0, int p1) { return null; }
        public Component findComponentAt(Point p0) { return null; }
        public bool isFocusTraversalPolicyProvider() { return false; }
        public void applyComponentOrientation(ComponentOrientation p0) { }
        public void addContainerListener(ContainerListener p0) { }
        public LayoutManager getLayout() { return null; }
        public void setComponentZOrder(Component p0, int p1) { }
        public void setLayout(LayoutManager p0) { }
        public void paintComponents(Graphics p0) { }
        public void printComponents(Graphics p0) { }
        public void removeContainerListener(ContainerListener p0) { }
        public ContainerListener[] getContainerListeners() { return null; }
        public Point getMousePosition(bool p0) { return null; }
        public bool isAncestorOf(Component p0) { return false; }
        public Set getFocusTraversalKeys(int p0) { return null; }
        public bool areFocusTraversalKeysSet(int p0) { return false; }
        public bool isFocusTraversalPolicySet() { return false; }
        public void setFocusCycleRoot(bool p0) { }
        public void setFocusTraversalPolicyProvider(bool p0) { }
        public void transferFocusDownCycle() { }
        public void remove(int p0) { }
        public void remove(Component p0) { }
        public void update(Graphics p0) { }
        public Component add(Component p0) { return p0; }
        public Component add(string p0, Component p1) { return p1; }
        public Component add(Component p0, object p1) { return p0; }
        public Component add(Component p0, object p1, int p2) { return p0; }
        public Component add(Component p0, int p1) { return p0; }
        public void list(PrintWriter p0, int p1) { }
        public void list(PrintStream p0, int p1) { }
        public void validate() { }
        public void print(Graphics p0) { }
        public void removeAll() { }
        public Component getComponent(int p0) { return null; }
        public void invalidate() { }
    }

    public class Component { }
    public class ComponentOrientation { }
    public class Event { }
    public class FocusTraversalPolicy { }
    public class Font { }
    public class Graphics { }
    public class LayoutManager { }
    public class Point { }
    public class PropertyChangeListener { }
    public class ContainerListener { }
    public class PrintStream { }
    public class PrintWriter { }
    public class Set { }
    public class Class { }
}