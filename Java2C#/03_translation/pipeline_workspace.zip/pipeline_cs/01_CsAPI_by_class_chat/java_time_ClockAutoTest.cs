using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_time_ClockAutoTest
    {
        public void offset_test_2329(Clock p0, Duration p1)
        {
            Clock.Offset(p0, p1);
        }

        public void system_test_2330(ZoneId p0)
        {
            Clock.System(p0);
        }

        public void fixed_test_2331(Instant p0, ZoneId p1)
        {
            Clock.Fixed(p0, p1);
        }

        public void systemUTC_test_2332()
        {
            Clock.SystemUTC();
        }

        public void systemDefaultZone_test_2333()
        {
            Clock.SystemDefaultZone();
        }

        public void tickMillis_test_2334(ZoneId p0)
        {
            Clock.TickMillis(p0);
        }

        public void tickSeconds_test_2335(ZoneId p0)
        {
            Clock.TickSeconds(p0);
        }

        public void tickMinutes_test_2336(ZoneId p0)
        {
            Clock.TickMinutes(p0);
        }

        public void tick_test_2337(Clock p0, Duration p1)
        {
            Clock.Tick(p0, p1);
        }
    }

    public class Clock
    {
        public static Clock Offset(Clock clock, Duration offset)
        {
            return new OffsetClock(clock, offset);
        }

        public static Clock System(ZoneId zone)
        {
            return new SystemClock(zone);
        }

        public static Clock Fixed(Instant fixedInstant, ZoneId zone)
        {
            return new FixedClock(fixedInstant, zone);
        }

        public static Clock SystemUTC()
        {
            return new SystemClock(ZoneId.UTC);
        }

        public static Clock SystemDefaultZone()
        {
            return new SystemClock(ZoneId.SystemDefault);
        }

        public static Clock TickMillis(ZoneId zone)
        {
            return new TickClock(System(zone), TimeSpan.FromMilliseconds(1));
        }

        public static Clock TickSeconds(ZoneId zone)
        {
            return new TickClock(System(zone), TimeSpan.FromSeconds(1));
        }

        public static Clock TickMinutes(ZoneId zone)
        {
            return new TickClock(System(zone), TimeSpan.FromMinutes(1));
        }

        public static Clock Tick(Clock baseClock, Duration tickDuration)
        {
            return new TickClock(baseClock, tickDuration.ToTimeSpan());
        }

        public virtual Instant Instant()
        {
            return Instant.Now;
        }

        public virtual ZoneId Zone()
        {
            return ZoneId.SystemDefault;
        }

        public virtual long Millis()
        {
            return Instant().ToUnixTimeMilliseconds();
        }
    }

    public class OffsetClock : Clock
    {
        private readonly Clock _baseClock;
        private readonly TimeSpan _offset;

        public OffsetClock(Clock baseClock, Duration offset)
        {
            _baseClock = baseClock;
            _offset = offset.ToTimeSpan();
        }

        public override Instant Instant()
        {
            return _baseClock.Instant().Plus(_offset);
        }

        public override ZoneId Zone()
        {
            return _baseClock.Zone();
        }
    }

    public class SystemClock : Clock
    {
        private readonly ZoneId _zone;

        public SystemClock(ZoneId zone)
        {
            _zone = zone;
        }

        public override Instant Instant()
        {
            return Instant.Now;
        }

        public override ZoneId Zone()
        {
            return _zone;
        }
    }

    public class FixedClock : Clock
    {
        private readonly Instant _fixedInstant;
        private readonly ZoneId _zone;

        public FixedClock(Instant fixedInstant, ZoneId zone)
        {
            _fixedInstant = fixedInstant;
            _zone = zone;
        }

        public override Instant Instant()
        {
            return _fixedInstant;
        }

        public override ZoneId Zone()
        {
            return _zone;
        }
    }

    public class TickClock : Clock
    {
        private readonly Clock _baseClock;
        private readonly TimeSpan _tickDuration;

        public TickClock(Clock baseClock, TimeSpan tickDuration)
        {
            _baseClock = baseClock;
            _tickDuration = tickDuration;
        }

        public override Instant Instant()
        {
            long baseMillis = _baseClock.Millis();
            long tickMillis = (long)_tickDuration.TotalMilliseconds;
            long roundedMillis = (baseMillis / tickMillis) * tickMillis;
            return Instant.FromUnixTimeMilliseconds(roundedMillis);
        }

        public override ZoneId Zone()
        {
            return _baseClock.Zone();
        }
    }

    public class Instant
    {
        public static Instant Now => FromUnixTimeMilliseconds(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());

        private readonly long _epochMilli;

        private Instant(long epochMilli)
        {
            _epochMilli = epochMilli;
        }

        public static Instant FromUnixTimeMilliseconds(long epochMilli)
        {
            return new Instant(epochMilli);
        }

        public long ToUnixTimeMilliseconds()
        {
            return _epochMilli;
        }

        public Instant Plus(TimeSpan duration)
        {
            return new Instant(_epochMilli + (long)duration.TotalMilliseconds);
        }
    }

    public class ZoneId
    {
        public static ZoneId UTC { get; } = new ZoneId("UTC");
        public static ZoneId SystemDefault { get; } = new ZoneId(TimeZoneInfo.Local.Id);

        private readonly string _id;

        private ZoneId(string id)
        {
            _id = id;
        }

        public string Id => _id;
    }

    public class Duration
    {
        private readonly TimeSpan _timeSpan;

        public Duration(TimeSpan timeSpan)
        {
            _timeSpan = timeSpan;
        }

        public TimeSpan ToTimeSpan()
        {
            return _timeSpan;
        }
    }
}