using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace Generated.Test
{
    public class XMLEventFactory
    {
        public static XMLEventFactory NewDefaultFactory()
        {
            return new XMLEventFactory();
        }

        public static XMLEventFactory NewInstance(string factoryId, object classLoader)
        {
            return new XMLEventFactory();
        }

        public static XMLEventFactory NewInstance()
        {
            return new XMLEventFactory();
        }

        public static XMLEventFactory NewFactory(string factoryId, object classLoader)
        {
            return new XMLEventFactory();
        }

        public static XMLEventFactory NewFactory()
        {
            return new XMLEventFactory();
        }
    }

    public class javax_xml_stream_XMLEventFactoryAutoTest
    {
        public void newDefaultFactory_test_13626()
        {
            XMLEventFactory.NewDefaultFactory();
        }

        public void newInstance_test_13627(string p0, object p1)
        {
            XMLEventFactory.NewInstance(p0, p1);
        }

        public void newInstance_test_13628()
        {
            XMLEventFactory.NewInstance();
        }

        public void newFactory_test_13629(string p0, object p1)
        {
            XMLEventFactory.NewFactory(p0, p1);
        }

        public void newFactory_test_13630()
        {
            XMLEventFactory.NewFactory();
        }
    }
}