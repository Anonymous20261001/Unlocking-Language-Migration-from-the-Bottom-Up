namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public static class Objects
    {
        public static int CheckIndex(int index, int length)
        {
            if (index < 0 || index >= length)
                throw new IndexOutOfRangeException("Index out of bounds");
            return index;
        }

        public static long CheckIndex(long index, long length)
        {
            if (index < 0 || index >= length)
                throw new IndexOutOfRangeException("Index out of bounds");
            return index;
        }

        public static int Compare<T>(T a, T b, IComparer<T> cmp)
        {
            if (cmp == null)
                throw new ArgumentNullException(nameof(cmp));
            return cmp.Compare(a, b);
        }

        public static int Hash(params object[] values)
        {
            if (values == null)
                return 0;
            unchecked
            {
                int hash = 17;
                foreach (var v in values)
                {
                    hash = hash * 31 + (v?.GetHashCode() ?? 0);
                }
                return hash;
            }
        }

        public static T RequireNonNull<T>(T obj, Func<string> messageSupplier)
        {
            if (obj == null)
                throw new NullReferenceException(messageSupplier?.Invoke() ?? "Object is null");
            return obj;
        }

        public static T RequireNonNull<T>(T obj, string message)
        {
            if (obj == null)
                throw new NullReferenceException(message ?? "Object is null");
            return obj;
        }

        public static T RequireNonNull<T>(T obj)
        {
            if (obj == null)
                throw new NullReferenceException("Object is null");
            return obj;
        }

        public static long CheckFromToIndex(long fromIndex, long toIndex, long length)
        {
            if (fromIndex < 0 || toIndex < fromIndex || toIndex > length)
                throw new IndexOutOfRangeException("Range out of bounds");
            return fromIndex;
        }

        public static int CheckFromToIndex(int fromIndex, int toIndex, int length)
        {
            if (fromIndex < 0 || toIndex < fromIndex || toIndex > length)
                throw new IndexOutOfRangeException("Range out of bounds");
            return fromIndex;
        }

        public static int CheckFromIndexSize(int fromIndex, int size, int length)
        {
            if (fromIndex < 0 || size < 0 || fromIndex + size > length)
                throw new IndexOutOfRangeException("Range out of bounds");
            return fromIndex;
        }

        public static long CheckFromIndexSize(long fromIndex, long size, long length)
        {
            if (fromIndex < 0 || size < 0 || fromIndex + size > length)
                throw new IndexOutOfRangeException("Range out of bounds");
            return fromIndex;
        }

        public static bool DeepEquals(object a, object b)
        {
            if (a == b)
                return true;
            if (a == null || b == null)
                return false;
            if (a is Array arrA && b is Array arrB)
            {
                if (arrA.Length != arrB.Length)
                    return false;
                for (int i = 0; i < arrA.Length; i++)
                {
                    if (!DeepEquals(arrA.GetValue(i), arrB.GetValue(i)))
                        return false;
                }
                return true;
            }
            return a.Equals(b);
        }

        public static string ToIdentityString(object obj)
        {
            if (obj == null)
                return "null";
            return obj.GetType().FullName + "@" + System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(obj).ToString("x");
        }

        public static bool IsNull(object obj)
        {
            return obj == null;
        }

        public static bool NonNull(object obj)
        {
            return obj != null;
        }

        public static T RequireNonNullElse<T>(T obj, T defaultObj)
        {
            return obj != null ? obj : defaultObj;
        }

        public static T RequireNonNullElseGet<T>(T obj, Func<T> supplier)
        {
            if (obj != null)
                return obj;
            if (supplier == null)
                throw new ArgumentNullException(nameof(supplier));
            return supplier();
        }
    }

    public class java_util_ObjectsAutoTest
    {
        public void checkIndex_test_9597(int p0, int p1)
        {
            Objects.CheckIndex(p0, p1);
        }

        public void checkIndex_test_9598(long p0, long p1)
        {
            Objects.CheckIndex(p0, p1);
        }

        public void compare_test_9599(object p0, object p1, IComparer<object> p2)
        {
            Objects.Compare(p0, p1, p2);
        }

        public void hash_test_9600(object[] p0)
        {
            Objects.Hash(p0);
        }

        public void requireNonNull_test_9601(object p0, Func<string> p1)
        {
            Objects.RequireNonNull(p0, p1);
        }

        public void requireNonNull_test_9602(object p0, string p1)
        {
            Objects.RequireNonNull(p0, p1);
        }

        public void requireNonNull_test_9603(object p0)
        {
            Objects.RequireNonNull(p0);
        }

        public void checkFromToIndex_test_9604(long p0, long p1, long p2)
        {
            Objects.CheckFromToIndex(p0, p1, p2);
        }

        public void checkFromToIndex_test_9605(int p0, int p1, int p2)
        {
            Objects.CheckFromToIndex(p0, p1, p2);
        }

        public void checkFromIndexSize_test_9606(int p0, int p1, int p2)
        {
            Objects.CheckFromIndexSize(p0, p1, p2);
        }

        public void checkFromIndexSize_test_9607(long p0, long p1, long p2)
        {
            Objects.CheckFromIndexSize(p0, p1, p2);
        }

        public void deepEquals_test_9608(object p0, object p1)
        {
            Objects.DeepEquals(p0, p1);
        }

        public void toIdentityString_test_9609(object p0)
        {
            Objects.ToIdentityString(p0);
        }

        public void isNull_test_9610(object p0)
        {
            Objects.IsNull(p0);
        }

        public void nonNull_test_9611(object p0)
        {
            Objects.NonNull(p0);
        }

        public void requireNonNullElse_test_9612(object p0, object p1)
        {
            Objects.RequireNonNullElse(p0, p1);
        }

        public void requireNonNullElseGet_test_9613(object p0, Func<object> p1)
        {
            Objects.RequireNonNullElseGet(p0, p1);
        }
    }
}