using System;
using System.Net;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_net_ProxySelectorAutoTest
    {
        public void of_test_10219(InetSocketAddress p0)
        {
            ProxySelector.Of(p0);
        }

        public void getDefault_test_10220()
        {
            ProxySelector.GetDefault();
        }

        public void setDefault_test_10221(ProxySelector p0)
        {
            ProxySelector.SetDefault(p0);
        }
    }

    public class ProxySelector
    {
        private static ProxySelector defaultSelector;
        private List<Proxy> proxies;

        public ProxySelector()
        {
            proxies = new List<Proxy>();
        }

        public static ProxySelector Of(InetSocketAddress address)
        {
            ProxySelector selector = new ProxySelector();
            if (address != null)
            {
                selector.proxies.Add(new Proxy(ProxyType.Http, address));
            }
            else
            {
                selector.proxies.Add(Proxy.NO_PROXY);
            }
            return selector;
        }

        public static ProxySelector GetDefault()
        {
            return defaultSelector;
        }

        public static void SetDefault(ProxySelector selector)
        {
            defaultSelector = selector;
        }

        public List<Proxy> Select(Uri uri)
        {
            return proxies;
        }

        public void ConnectFailed(Uri uri, SocketAddress sa, IOException ioe)
        {
            // No-op implementation
        }
    }

    public class InetSocketAddress
    {
        public string Host { get; }
        public int Port { get; }

        public InetSocketAddress(string host, int port)
        {
            Host = host;
            Port = port;
        }

        public InetSocketAddress(int port)
        {
            Host = null;
            Port = port;
        }

        public static InetSocketAddress CreateUnresolved(string host, int port)
        {
            return new InetSocketAddress(host, port);
        }

        public override string ToString()
        {
            return Host + ":" + Port;
        }
    }

    public enum ProxyType
    {
        Direct,
        Http,
        Socks
    }

    public class Proxy
    {
        public static readonly Proxy NO_PROXY = new Proxy(ProxyType.Direct, null);

        public ProxyType Type { get; }
        public SocketAddress Address { get; }

        public Proxy(ProxyType type, SocketAddress address)
        {
            Type = type;
            Address = address;
        }

        public override bool Equals(object obj)
        {
            if (obj is Proxy other)
            {
                return Type == other.Type && 
                       ((Address == null && other.Address == null) || 
                        (Address != null && Address.Equals(other.Address)));
            }
            return false;
        }

        public override int GetHashCode()
        {
            return (Type, Address).GetHashCode();
        }
    }

    public class SocketAddress
    {
        public override string ToString()
        {
            return base.ToString();
        }
    }

    public class IOException : Exception
    {
        public IOException() : base() { }
        public IOException(string message) : base(message) { }
        public IOException(string message, Exception innerException) : base(message, innerException) { }
    }
}