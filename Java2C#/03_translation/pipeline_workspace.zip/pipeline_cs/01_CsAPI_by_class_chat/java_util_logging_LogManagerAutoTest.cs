namespace Generated.Test
{
    public class java_util_logging_LogManagerAutoTest
    {
        public void getLogManager_test_8109()
        {
            LogManager.GetLogManager();
        }

        public void getLoggingMXBean_test_8110()
        {
            LogManager.GetLoggingMXBean();
        }
    }

    public class LogManager
    {
        public static LogManager GetLogManager()
        {
            return new LogManager();
        }

        public static object GetLoggingMXBean()
        {
            return new object();
        }
    }
}