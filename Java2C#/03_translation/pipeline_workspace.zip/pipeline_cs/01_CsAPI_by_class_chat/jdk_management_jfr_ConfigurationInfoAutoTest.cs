using System;
using System.Collections.Generic;
using javax.management.openmbean;

namespace Generated.Test
{
    // C# equivalent of javax.management.openmbean.CompositeData
    public interface CompositeData
    {
        object Get(string key);
        object[] GetAll();
        bool ContainsKey(string key);
        bool ContainsValue(object value);
        ICollection<string> GetCompositeType();
        string ToString();
    }

    // C# equivalent of jdk.management.jfr.ConfigurationInfo
    public class ConfigurationInfo
    {
        private readonly string _name;
        private readonly string _label;
        private readonly string _description;
        private readonly string _provider;
        private readonly string _settings;
        private readonly string _contents;

        public ConfigurationInfo(string name, string label, string description, string provider, string settings, string contents)
        {
            _name = name;
            _label = label;
            _description = description;
            _provider = provider;
            _settings = settings;
            _contents = contents;
        }

        public string GetName() => _name;
        public string GetLabel() => _label;
        public string GetDescription() => _description;
        public string GetProvider() => _provider;
        public string GetSettings() => _settings;
        public string GetContents() => _contents;

        public static ConfigurationInfo From(CompositeData cd)
        {
            if (cd == null)
                throw new ArgumentNullException(nameof(cd));

            string name = (string)cd.Get("name");
            string label = (string)cd.Get("label");
            string description = (string)cd.Get("description");
            string provider = (string)cd.Get("provider");
            string settings = (string)cd.Get("settings");
            string contents = (string)cd.Get("contents");

            return new ConfigurationInfo(name, label, description, provider, settings, contents);
        }

        public override string ToString()
        {
            return $"ConfigurationInfo[name={_name}, label={_label}, description={_description}, provider={_provider}, settings={_settings}, contents={_contents}]";
        }
    }

    public class jdk_management_jfr_ConfigurationInfoAutoTest
    {
        public void from_test_2909(CompositeData p0)
        {
            ConfigurationInfo.From(p0);
        }
    }
}