using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Simplified representations of the Java constant descriptors
    public abstract class ConstantDesc
    {
    }

    public class ClassDesc : ConstantDesc
    {
        public static ClassDesc Of(string name)
        {
            return new ClassDesc();
        }
    }

    public class DirectMethodHandleDesc : ConstantDesc
    {
    }

    public class DynamicConstantDesc : ConstantDesc
    {
        private DirectMethodHandleDesc _bootstrapMethod;
        private string _constantName;
        private ClassDesc _constantType;
        private ConstantDesc[] _bootstrapArgs;

        public DirectMethodHandleDesc BootstrapMethod => _bootstrapMethod;
        public string ConstantName => _constantName;
        public ClassDesc ConstantType => _constantType;
        public ConstantDesc[] BootstrapArgs => _bootstrapArgs;

        public static DynamicConstantDesc Of(DirectMethodHandleDesc bootstrapMethod, ConstantDesc[] bootstrapArgs)
        {
            var desc = new DynamicConstantDesc();
            desc._bootstrapMethod = bootstrapMethod;
            desc._bootstrapArgs = bootstrapArgs;
            return desc;
        }

        public static DynamicConstantDesc Of(DirectMethodHandleDesc bootstrapMethod)
        {
            return Of(bootstrapMethod, new ConstantDesc[0]);
        }

        public static DynamicConstantDesc OfNamed(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, ConstantDesc[] bootstrapArgs)
        {
            var desc = new DynamicConstantDesc();
            desc._bootstrapMethod = bootstrapMethod;
            desc._constantName = constantName;
            desc._constantType = constantType;
            desc._bootstrapArgs = bootstrapArgs;
            return desc;
        }

        public static DynamicConstantDesc OfCanonical(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, ConstantDesc[] bootstrapArgs)
        {
            return OfNamed(bootstrapMethod, constantName, constantType, bootstrapArgs);
        }
    }

    public class java_lang_constant_DynamicConstantDescAutoTest
    {
        public void of_test_4420(DirectMethodHandleDesc p0, ConstantDesc[] p1)
        {
            DynamicConstantDesc.Of(p0, p1);
        }

        public void of_test_4421(DirectMethodHandleDesc p0)
        {
            DynamicConstantDesc.Of(p0);
        }

        public void ofNamed_test_4422(DirectMethodHandleDesc p0, string p1, ClassDesc p2, ConstantDesc[] p3)
        {
            DynamicConstantDesc.OfNamed(p0, p1, p2, p3);
        }

        public void ofCanonical_test_4423(DirectMethodHandleDesc p0, string p1, ClassDesc p2, ConstantDesc[] p3)
        {
            DynamicConstantDesc.OfCanonical(p0, p1, p2, p3);
        }
    }
}