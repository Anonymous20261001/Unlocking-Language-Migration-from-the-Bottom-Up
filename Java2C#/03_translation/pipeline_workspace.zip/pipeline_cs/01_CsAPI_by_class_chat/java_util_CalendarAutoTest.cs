using System;
using System.Collections.Generic;
using System.Globalization;

namespace Generated.Test
{
    public class java_util_CalendarAutoTest
    {
        public void getInstance_test_2021()
        {
            Calendar.GetInstance();
        }

        public void getInstance_test_2022(Locale p0)
        {
            Calendar.GetInstance(p0);
        }

        public void getInstance_test_2023(TimeZone p0)
        {
            Calendar.GetInstance(p0);
        }

        public void getInstance_test_2024(TimeZone p0, Locale p1)
        {
            Calendar.GetInstance(p0, p1);
        }

        public void getAvailableLocales_test_2025()
        {
            Calendar.GetAvailableLocales();
        }

        public void getAvailableCalendarTypes_test_2026()
        {
            Calendar.GetAvailableCalendarTypes();
        }
    }

    public class Calendar
    {
        public static Calendar GetInstance()
        {
            return new Calendar();
        }

        public static Calendar GetInstance(Locale locale)
        {
            return new Calendar();
        }

        public static Calendar GetInstance(TimeZone timeZone)
        {
            return new Calendar();
        }

        public static Calendar GetInstance(TimeZone timeZone, Locale locale)
        {
            return new Calendar();
        }

        public static Locale[] GetAvailableLocales()
        {
            return new Locale[0];
        }

        public static string[] GetAvailableCalendarTypes()
        {
            return new string[0];
        }
    }

    public class Locale
    {
        public static Locale GetDefault()
        {
            return new Locale();
        }
    }

    public class TimeZone
    {
        public static TimeZone GetDefault()
        {
            return new TimeZone();
        }
    }
}