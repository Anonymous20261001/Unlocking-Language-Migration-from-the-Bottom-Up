using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // C# equivalent of javax.swing.FocusManager
    public class FocusManager
    {
        private static FocusManager _currentManager;
        private static bool _focusManagerEnabled = true;

        // Static method to check if focus manager is enabled
        public static bool isFocusManagerEnabled()
        {
            return _focusManagerEnabled;
        }

        // Static method to set the current manager
        public static void setCurrentManager(FocusManager manager)
        {
            _currentManager = manager;
        }

        // Static method to get the current manager
        public static FocusManager getCurrentManager()
        {
            return _currentManager;
        }

        // Static method to disable the swing focus manager
        public static void disableSwingFocusManager()
        {
            _focusManagerEnabled = false;
        }
    }

    public class javax_swing_FocusManagerAutoTest
    {
        public void isFocusManagerEnabled_test_4917()
        {
            FocusManager.isFocusManagerEnabled();
        }

        public void setCurrentManager_test_4918(FocusManager p0)
        {
            FocusManager.setCurrentManager(p0);
        }

        public void getCurrentManager_test_4919()
        {
            FocusManager.getCurrentManager();
        }

        public void disableSwingFocusManager_test_4920()
        {
            FocusManager.disableSwingFocusManager();
        }
    }
}