namespace Generated.Test
{
    public class java_lang_reflect_ArrayAutoTest
    {
        public void get_test_232(object p0, int p1)
        {
            Array.Get(p0, p1);
        }

        public void getLength_test_233(object p0)
        {
            Array.GetLength(p0);
        }

        public void getBoolean_test_234(object p0, int p1)
        {
            Array.GetBoolean(p0, p1);
        }

        public void getByte_test_235(object p0, int p1)
        {
            Array.GetByte(p0, p1);
        }

        public void getShort_test_236(object p0, int p1)
        {
            Array.GetShort(p0, p1);
        }

        public void getChar_test_237(object p0, int p1)
        {
            Array.GetChar(p0, p1);
        }

        public void getInt_test_238(object p0, int p1)
        {
            Array.GetInt(p0, p1);
        }

        public void getLong_test_239(object p0, int p1)
        {
            Array.GetLong(p0, p1);
        }

        public void getFloat_test_240(object p0, int p1)
        {
            Array.GetFloat(p0, p1);
        }

        public void getDouble_test_241(object p0, int p1)
        {
            Array.GetDouble(p0, p1);
        }

        public void newInstance_test_242(System.Type p0, int p1)
        {
            Array.NewInstance(p0, p1);
        }

        public void newInstance_test_243(System.Type p0, int[] p1)
        {
            Array.NewInstance(p0, p1);
        }

        public void set_test_244(object p0, int p1, object p2)
        {
            Array.Set(p0, p1, p2);
        }

        public void setBoolean_test_245(object p0, int p1, bool p2)
        {
            Array.SetBoolean(p0, p1, p2);
        }

        public void setByte_test_246(object p0, int p1, byte p2)
        {
            Array.SetByte(p0, p1, p2);
        }

        public void setChar_test_247(object p0, int p1, char p2)
        {
            Array.SetChar(p0, p1, p2);
        }

        public void setShort_test_248(object p0, int p1, short p2)
        {
            Array.SetShort(p0, p1, p2);
        }

        public void setInt_test_249(object p0, int p1, int p2)
        {
            Array.SetInt(p0, p1, p2);
        }

        public void setLong_test_250(object p0, int p1, long p2)
        {
            Array.SetLong(p0, p1, p2);
        }

        public void setFloat_test_251(object p0, int p1, float p2)
        {
            Array.SetFloat(p0, p1, p2);
        }

        public void setDouble_test_252(object p0, int p1, double p2)
        {
            Array.SetDouble(p0, p1, p2);
        }
    }

    public static class Array
    {
        public static object Get(object array, int index)
        {
            return ((System.Array)array).GetValue(index);
        }

        public static int GetLength(object array)
        {
            return ((System.Array)array).Length;
        }

        public static bool GetBoolean(object array, int index)
        {
            return (bool)((System.Array)array).GetValue(index);
        }

        public static byte GetByte(object array, int index)
        {
            return (byte)((System.Array)array).GetValue(index);
        }

        public static short GetShort(object array, int index)
        {
            return (short)((System.Array)array).GetValue(index);
        }

        public static char GetChar(object array, int index)
        {
            return (char)((System.Array)array).GetValue(index);
        }

        public static int GetInt(object array, int index)
        {
            return (int)((System.Array)array).GetValue(index);
        }

        public static long GetLong(object array, int index)
        {
            return (long)((System.Array)array).GetValue(index);
        }

        public static float GetFloat(object array, int index)
        {
            return (float)((System.Array)array).GetValue(index);
        }

        public static double GetDouble(object array, int index)
        {
            return (double)((System.Array)array).GetValue(index);
        }

        public static object NewInstance(System.Type componentType, int length)
        {
            return System.Array.CreateInstance(componentType, length);
        }

        public static object NewInstance(System.Type componentType, int[] lengths)
        {
            return System.Array.CreateInstance(componentType, lengths);
        }

        public static void Set(object array, int index, object value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetBoolean(object array, int index, bool value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetByte(object array, int index, byte value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetChar(object array, int index, char value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetShort(object array, int index, short value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetInt(object array, int index, int value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetLong(object array, int index, long value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetFloat(object array, int index, float value)
        {
            ((System.Array)array).SetValue(value, index);
        }

        public static void SetDouble(object array, int index, double value)
        {
            ((System.Array)array).SetValue(value, index);
        }
    }
}