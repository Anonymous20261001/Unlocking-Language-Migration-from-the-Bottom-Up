namespace Generated.Test
{
    public class javax_security_auth_login_ConfigurationAutoTest
    {
        public void setConfiguration_test_2906(Configuration p0)
        {
            Configuration.SetConfiguration(p0);
        }

        public void getConfiguration_test_2907()
        {
            Configuration.GetConfiguration();
        }
    }

    public class Configuration
    {
        private static Configuration _configuration;

        public static void SetConfiguration(Configuration configuration)
        {
            _configuration = configuration;
        }

        public static Configuration GetConfiguration()
        {
            return _configuration;
        }
    }
}