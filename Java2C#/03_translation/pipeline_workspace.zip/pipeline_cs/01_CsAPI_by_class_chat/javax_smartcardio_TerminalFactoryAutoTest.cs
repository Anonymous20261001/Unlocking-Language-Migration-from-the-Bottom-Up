namespace Generated.Test
{
    public class javax_smartcardio_TerminalFactoryAutoTest
    {
        public void getDefaultType_test_12541()
        {
            TerminalFactory.GetDefaultType();
        }

        public void getDefault_test_12542()
        {
            TerminalFactory.GetDefault();
        }
    }

    public class TerminalFactory
    {
        public static string GetDefaultType()
        {
            return "PC/SC";
        }

        public static TerminalFactory GetDefault()
        {
            return new TerminalFactory();
        }
    }
}