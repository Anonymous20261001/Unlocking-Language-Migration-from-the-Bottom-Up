using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Generated.Test
{
    // Simplified AttributeSet interface
    public interface AttributeSet
    {
        object GetAttribute(object key);
        bool ContainsAttribute(object key);
        int GetAttributeCount();
        System.Collections.IEnumerator GetAttributeNames();
        bool IsDefined(object attrName);
        bool IsEqual(AttributeSet attr);
    }

    // Simplified MutableAttributeSet interface
    public interface MutableAttributeSet : AttributeSet
    {
        void AddAttribute(object name, object value);
        void AddAttributes(AttributeSet attributes);
        void RemoveAttribute(object name);
        void RemoveAttributes(System.Collections.IEnumerator names);
        void RemoveAttributes(AttributeSet attributes);
        void SetResolveParent(AttributeSet parent);
    }

    // Simple implementation of MutableAttributeSet
    public class SimpleAttributeSet : MutableAttributeSet
    {
        private Dictionary<object, object> attributes = new Dictionary<object, object>();
        private AttributeSet resolveParent;

        public object GetAttribute(object key)
        {
            if (attributes.ContainsKey(key))
                return attributes[key];
            if (resolveParent != null)
                return resolveParent.GetAttribute(key);
            return null;
        }

        public bool ContainsAttribute(object key)
        {
            return attributes.ContainsKey(key) || (resolveParent != null && resolveParent.ContainsAttribute(key));
        }

        public int GetAttributeCount()
        {
            return attributes.Count;
        }

        public System.Collections.IEnumerator GetAttributeNames()
        {
            return attributes.Keys.GetEnumerator();
        }

        public bool IsDefined(object attrName)
        {
            return attributes.ContainsKey(attrName);
        }

        public bool IsEqual(AttributeSet attr)
        {
            if (attr == null || attr.GetAttributeCount() != attributes.Count)
                return false;
            foreach (var key in attributes.Keys)
            {
                if (!attr.ContainsAttribute(key) || !Equals(attr.GetAttribute(key), attributes[key]))
                    return false;
            }
            return true;
        }

        public void AddAttribute(object name, object value)
        {
            attributes[name] = value;
        }

        public void AddAttributes(AttributeSet attributes)
        {
            if (attributes != null)
            {
                var names = attributes.GetAttributeNames();
                while (names.MoveNext())
                {
                    object name = names.Current;
                    AddAttribute(name, attributes.GetAttribute(name));
                }
            }
        }

        public void RemoveAttribute(object name)
        {
            attributes.Remove(name);
        }

        public void RemoveAttributes(System.Collections.IEnumerator names)
        {
            while (names.MoveNext())
            {
                attributes.Remove(names.Current);
            }
        }

        public void RemoveAttributes(AttributeSet attributes)
        {
            if (attributes != null)
            {
                var names = attributes.GetAttributeNames();
                while (names.MoveNext())
                {
                    this.attributes.Remove(names.Current);
                }
            }
        }

        public void SetResolveParent(AttributeSet parent)
        {
            resolveParent = parent;
        }
    }

    // Simplified TabSet class
    public class TabSet
    {
        private TabStop[] tabs;

        public TabSet(TabStop[] tabs)
        {
            this.tabs = tabs != null ? tabs : new TabStop[0];
        }

        public int GetTabCount()
        {
            return tabs.Length;
        }

        public TabStop GetTab(int index)
        {
            if (index < 0 || index >= tabs.Length)
                return null;
            return tabs[index];
        }

        public TabStop GetTabAfter(float location)
        {
            foreach (var tab in tabs)
            {
                if (tab.Position > location)
                    return tab;
            }
            return null;
        }

        public int GetTabIndex(TabStop tab)
        {
            for (int i = 0; i < tabs.Length; i++)
            {
                if (tabs[i] == tab)
                    return i;
            }
            return -1;
        }

        public int GetTabIndexAfter(float location)
        {
            for (int i = 0; i < tabs.Length; i++)
            {
                if (tabs[i].Position > location)
                    return i;
            }
            return -1;
        }

        public override bool Equals(object obj)
        {
            if (obj is TabSet other)
            {
                if (tabs.Length != other.tabs.Length)
                    return false;
                for (int i = 0; i < tabs.Length; i++)
                {
                    if (!tabs[i].Equals(other.tabs[i]))
                        return false;
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 0;
            foreach (var tab in tabs)
                hash = hash * 31 + tab.GetHashCode();
            return hash;
        }
    }

    // Simplified TabStop class
    public class TabStop
    {
        public float Position { get; }
        public int Alignment { get; }
        public int Leader { get; }

        public TabStop(float pos, int align, int leader)
        {
            Position = pos;
            Alignment = align;
            Leader = leader;
        }

        public override bool Equals(object obj)
        {
            if (obj is TabStop other)
            {
                return Position == other.Position && Alignment == other.Alignment && Leader == other.Leader;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Position.GetHashCode() * 31 + Alignment * 7 + Leader;
        }
    }

    // Simplified Icon interface
    public interface Icon
    {
        int IconWidth { get; }
        int IconHeight { get; }
        void PaintIcon(Component c, Graphics g, int x, int y);
    }

    // StyleConstants class with all the static methods
    public static class StyleConstants
    {
        // Attribute keys
        public static readonly object FontFamily = "font-family";
        public static readonly object FontSize = "font-size";
        public static readonly object Bold = "bold";
        public static readonly object Italic = "italic";
        public static readonly object Underline = "underline";
        public static readonly object StrikeThrough = "strikethrough";
        public static readonly object Superscript = "superscript";
        public static readonly object Subscript = "subscript";
        public static readonly object Foreground = "foreground";
        public static readonly object Background = "background";
        public static readonly object ComponentAttribute = "component";
        public static readonly object IconAttribute = "icon";
        public static readonly object FirstLineIndent = "FirstLineIndent";
        public static readonly object LeftIndent = "LeftIndent";
        public static readonly object RightIndent = "RightIndent";
        public static readonly object LineSpacing = "LineSpacing";
        public static readonly object SpaceAbove = "SpaceAbove";
        public static readonly object SpaceBelow = "SpaceBelow";
        public static readonly object Alignment = "alignment";
        public static readonly object TabSetAttribute = "tabset";
        public static readonly object BidiLevel = "bidiLevel";

        // Alignment constants
        public const int ALIGN_LEFT = 0;
        public const int ALIGN_CENTER = 1;
        public const int ALIGN_RIGHT = 2;
        public const int ALIGN_JUSTIFIED = 3;

        // Font family
        public static void SetFontFamily(MutableAttributeSet a, string fam)
        {
            a.AddAttribute(FontFamily, fam);
        }

        public static string GetFontFamily(AttributeSet a)
        {
            return (string)a.GetAttribute(FontFamily);
        }

        // Font size
        public static void SetFontSize(MutableAttributeSet a, int sz)
        {
            a.AddAttribute(FontSize, sz);
        }

        public static int GetFontSize(AttributeSet a)
        {
            object value = a.GetAttribute(FontSize);
            return value is int ? (int)value : 0;
        }

        // Bold
        public static void SetBold(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(Bold, b);
        }

        public static bool IsBold(AttributeSet a)
        {
            object value = a.GetAttribute(Bold);
            return value is bool && (bool)value;
        }

        // Italic
        public static void SetItalic(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(Italic, b);
        }

        public static bool IsItalic(AttributeSet a)
        {
            object value = a.GetAttribute(Italic);
            return value is bool && (bool)value;
        }

        // Underline
        public static void SetUnderline(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(Underline, b);
        }

        public static bool IsUnderline(AttributeSet a)
        {
            object value = a.GetAttribute(Underline);
            return value is bool && (bool)value;
        }

        // StrikeThrough
        public static void SetStrikeThrough(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(StrikeThrough, b);
        }

        public static bool IsStrikeThrough(AttributeSet a)
        {
            object value = a.GetAttribute(StrikeThrough);
            return value is bool && (bool)value;
        }

        // Superscript
        public static void SetSuperscript(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(Superscript, b);
        }

        public static bool IsSuperscript(AttributeSet a)
        {
            object value = a.GetAttribute(Superscript);
            return value is bool && (bool)value;
        }

        // Subscript
        public static void SetSubscript(MutableAttributeSet a, bool b)
        {
            a.AddAttribute(Subscript, b);
        }

        public static bool IsSubscript(AttributeSet a)
        {
            object value = a.GetAttribute(Subscript);
            return value is bool && (bool)value;
        }

        // Foreground
        public static void SetForeground(MutableAttributeSet a, Color fg)
        {
            a.AddAttribute(Foreground, fg);
        }

        public static Color GetForeground(AttributeSet a)
        {
            object value = a.GetAttribute(Foreground);
            return value is Color ? (Color)value : Color.Black;
        }

        // Background
        public static void SetBackground(MutableAttributeSet a, Color bg)
        {
            a.AddAttribute(Background, bg);
        }

        public static Color GetBackground(AttributeSet a)
        {
            object value = a.GetAttribute(Background);
            return value is Color ? (Color)value : Color.White;
        }

        // Component
        public static void SetComponent(MutableAttributeSet a, Component c)
        {
            a.AddAttribute(ComponentAttribute, c);
        }

        public static Component GetComponent(AttributeSet a)
        {
            return a.GetAttribute(ComponentAttribute) as Component;
        }

        // Icon
        public static void SetIcon(MutableAttributeSet a, Icon c)
        {
            a.AddAttribute(IconAttribute, c);
        }

        public static Icon GetIcon(AttributeSet a)
        {
            return a.GetAttribute(IconAttribute) as Icon;
        }

        // FirstLineIndent
        public static void SetFirstLineIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(FirstLineIndent, indent);
        }

        public static float GetFirstLineIndent(AttributeSet a)
        {
            object value = a.GetAttribute(FirstLineIndent);
            return value is float ? (float)value : 0f;
        }

        // LeftIndent
        public static void SetLeftIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(LeftIndent, indent);
        }

        public static float GetLeftIndent(AttributeSet a)
        {
            object value = a.GetAttribute(LeftIndent);
            return value is float ? (float)value : 0f;
        }

        // RightIndent
        public static void SetRightIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(RightIndent, indent);
        }

        public static float GetRightIndent(AttributeSet a)
        {
            object value = a.GetAttribute(RightIndent);
            return value is float ? (float)value : 0f;
        }

        // LineSpacing
        public static void SetLineSpacing(MutableAttributeSet a, float spacing)
        {
            a.AddAttribute(LineSpacing, spacing);
        }

        public static float GetLineSpacing(AttributeSet a)
        {
            object value = a.GetAttribute(LineSpacing);
            return value is float ? (float)value : 0f;
        }

        // SpaceAbove
        public static void SetSpaceAbove(MutableAttributeSet a, float space)
        {
            a.AddAttribute(SpaceAbove, space);
        }

        public static float GetSpaceAbove(AttributeSet a)
        {
            object value = a.GetAttribute(SpaceAbove);
            return value is float ? (float)value : 0f;
        }

        // SpaceBelow
        public static void SetSpaceBelow(MutableAttributeSet a, float space)
        {
            a.AddAttribute(SpaceBelow, space);
        }

        public static float GetSpaceBelow(AttributeSet a)
        {
            object value = a.GetAttribute(SpaceBelow);
            return value is float ? (float)value : 0f;
        }

        // Alignment
        public static void SetAlignment(MutableAttributeSet a, int align)
        {
            a.AddAttribute(Alignment, align);
        }

        public static int GetAlignment(AttributeSet a)
        {
            object value = a.GetAttribute(Alignment);
            return value is int ? (int)value : ALIGN_LEFT;
        }

        // TabSet
        public static void SetTabSet(MutableAttributeSet a, TabSet tabs)
        {
            a.AddAttribute(TabSetAttribute, tabs);
        }

        public static TabSet GetTabSet(AttributeSet a)
        {
            return a.GetAttribute(TabSetAttribute) as TabSet;
        }

        // BidiLevel
        public static void SetBidiLevel(MutableAttributeSet a, int level)
        {
            a.AddAttribute(BidiLevel, level);
        }

        public static int GetBidiLevel(AttributeSet a)
        {
            object value = a.GetAttribute(BidiLevel);
            return value is int ? (int)value : 0;
        }
    }

    // Test class
    public class javax_swing_text_StyleConstantsAutoTest
    {
        public void setFontFamily_test_11929(MutableAttributeSet p0, string p1)
        {
            StyleConstants.SetFontFamily(p0, p1);
        }

        public void setFontSize_test_11930(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetFontSize(p0, p1);
        }

        public void isBold_test_11931(AttributeSet p0)
        {
            StyleConstants.IsBold(p0);
        }

        public void setBold_test_11932(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetBold(p0, p1);
        }

        public void isItalic_test_11933(AttributeSet p0)
        {
            StyleConstants.IsItalic(p0);
        }

        public void setItalic_test_11934(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetItalic(p0, p1);
        }

        public void setBidiLevel_test_11935(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetBidiLevel(p0, p1);
        }

        public void isUnderline_test_11936(AttributeSet p0)
        {
            StyleConstants.IsUnderline(p0);
        }

        public void isStrikeThrough_test_11937(AttributeSet p0)
        {
            StyleConstants.IsStrikeThrough(p0);
        }

        public void setStrikeThrough_test_11938(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetStrikeThrough(p0, p1);
        }

        public void setSubscript_test_11939(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetSubscript(p0, p1);
        }

        public void getFirstLineIndent_test_11940(AttributeSet p0)
        {
            StyleConstants.GetFirstLineIndent(p0);
        }

        public void setFirstLineIndent_test_11941(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetFirstLineIndent(p0, p1);
        }

        public void setRightIndent_test_11942(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetRightIndent(p0, p1);
        }

        public void setLeftIndent_test_11943(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetLeftIndent(p0, p1);
        }

        public void getLineSpacing_test_11944(AttributeSet p0)
        {
            StyleConstants.GetLineSpacing(p0);
        }

        public void setLineSpacing_test_11945(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetLineSpacing(p0, p1);
        }

        public void setSpaceAbove_test_11946(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetSpaceAbove(p0, p1);
        }

        public void setSpaceBelow_test_11947(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetSpaceBelow(p0, p1);
        }

        public void setAlignment_test_11948(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetAlignment(p0, p1);
        }

        public void getTabSet_test_11949(AttributeSet p0)
        {
            StyleConstants.GetTabSet(p0);
        }

        public void setTabSet_test_11950(MutableAttributeSet p0, TabSet p1)
        {
            StyleConstants.SetTabSet(p0, p1);
        }

        public void setSuperscript_test_11951(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetSuperscript(p0, p1);
        }

        public void setUnderline_test_11952(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetUnderline(p0, p1);
        }

        public void getSpaceAbove_test_11953(AttributeSet p0)
        {
            StyleConstants.GetSpaceAbove(p0);
        }

        public void getLeftIndent_test_11954(AttributeSet p0)
        {
            StyleConstants.GetLeftIndent(p0);
        }

        public void getSpaceBelow_test_11955(AttributeSet p0)
        {
            StyleConstants.GetSpaceBelow(p0);
        }

        public void getRightIndent_test_11956(AttributeSet p0)
        {
            StyleConstants.GetRightIndent(p0);
        }

        public void getForeground_test_11957(AttributeSet p0)
        {
            StyleConstants.GetForeground(p0);
        }

        public void setForeground_test_11958(MutableAttributeSet p0, Color p1)
        {
            StyleConstants.SetForeground(p0, p1);
        }

        public void getBackground_test_11959(AttributeSet p0)
        {
            StyleConstants.GetBackground(p0);
        }

        public void setBackground_test_11960(MutableAttributeSet p0, Color p1)
        {
            StyleConstants.SetBackground(p0, p1);
        }

        public void setComponent_test_11961(MutableAttributeSet p0, Component p1)
        {
            StyleConstants.SetComponent(p0, p1);
        }

        public void getIcon_test_11962(AttributeSet p0)
        {
            StyleConstants.GetIcon(p0);
        }

        public void setIcon_test_11963(MutableAttributeSet p0, Icon p1)
        {
            StyleConstants.SetIcon(p0, p1);
        }

        public void getBidiLevel_test_11964(AttributeSet p0)
        {
            StyleConstants.GetBidiLevel(p0);
        }

        public void getAlignment_test_11965(AttributeSet p0)
        {
            StyleConstants.GetAlignment(p0);
        }

        public void getFontFamily_test_11966(AttributeSet p0)
        {
            StyleConstants.GetFontFamily(p0);
        }

        public void getFontSize_test_11967(AttributeSet p0)
        {
            StyleConstants.GetFontSize(p0);
        }

        public void isSuperscript_test_11968(AttributeSet p0)
        {
            StyleConstants.IsSuperscript(p0);
        }

        public void isSubscript_test_11969(AttributeSet p0)
        {
            StyleConstants.IsSubscript(p0);
        }

        public void getComponent_test_11970(AttributeSet p0)
        {
            StyleConstants.GetComponent(p0);
        }
    }
}