using System;

namespace Generated.Test
{
    public class java_net_URIAutoTest
    {
        public void create_test_13237(string p0)
        {
            Uri.Create(p0);
        }
    }
}