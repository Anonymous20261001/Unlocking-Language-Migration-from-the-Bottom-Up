namespace Generated.Test
{
    public class java_text_NormalizerAutoTest
    {
        public void normalize_test_9529(CharSequence p0, Normalizer.Form p1)
        {
            Normalizer.Normalize(p0, p1);
        }

        public void isNormalized_test_9530(CharSequence p0, Normalizer.Form p1)
        {
            Normalizer.IsNormalized(p0, p1);
        }
    }

    public class CharSequence
    {
        private string value;

        public CharSequence(string value)
        {
            this.value = value;
        }

        public override string ToString()
        {
            return value;
        }

        public static implicit operator CharSequence(string s)
        {
            return new CharSequence(s);
        }

        public static implicit operator string(CharSequence cs)
        {
            return cs.value;
        }
    }

    public static class Normalizer
    {
        public enum Form
        {
            NFC,
            NFD,
            NFKC,
            NFKD
        }

        public static string Normalize(CharSequence str, Form form)
        {
            string s = str.ToString();
            switch (form)
            {
                case Form.NFC:
                    return s.Normalize(System.Text.NormalizationForm.FormC);
                case Form.NFD:
                    return s.Normalize(System.Text.NormalizationForm.FormD);
                case Form.NFKC:
                    return s.Normalize(System.Text.NormalizationForm.FormKC);
                case Form.NFKD:
                    return s.Normalize(System.Text.NormalizationForm.FormKD);
                default:
                    return s;
            }
        }

        public static bool IsNormalized(CharSequence str, Form form)
        {
            string s = str.ToString();
            switch (form)
            {
                case Form.NFC:
                    return s.IsNormalized(System.Text.NormalizationForm.FormC);
                case Form.NFD:
                    return s.IsNormalized(System.Text.NormalizationForm.FormD);
                case Form.NFKC:
                    return s.IsNormalized(System.Text.NormalizationForm.FormKC);
                case Form.NFKD:
                    return s.IsNormalized(System.Text.NormalizationForm.FormKD);
                default:
                    return true;
            }
        }
    }
}