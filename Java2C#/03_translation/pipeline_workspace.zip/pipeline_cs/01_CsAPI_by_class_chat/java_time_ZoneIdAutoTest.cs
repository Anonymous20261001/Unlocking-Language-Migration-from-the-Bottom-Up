using System;
using System.Collections.Generic;
using System.Globalization;

namespace Generated.Test
{
    // Simplified ZoneOffset equivalent
    public class ZoneOffset
    {
        public static ZoneOffset UTC = new ZoneOffset(TimeSpan.Zero);
        private TimeSpan _offset;
        
        public ZoneOffset(TimeSpan offset)
        {
            _offset = offset;
        }
        
        public TimeSpan GetOffset()
        {
            return _offset;
        }
    }
    
    // Simplified TemporalAccessor equivalent
    public interface TemporalAccessor
    {
    }
    
    // Simplified ZoneId equivalent
    public class ZoneId
    {
        private string _id;
        private static Dictionary<string, ZoneId> _zones = new Dictionary<string, ZoneId>();
        
        public ZoneId(string id)
        {
            _id = id;
        }
        
        public static ZoneId Of(string zoneId, Dictionary<string, string> aliasMap)
        {
            if (aliasMap != null && aliasMap.ContainsKey(zoneId))
            {
                zoneId = aliasMap[zoneId];
            }
            return new ZoneId(zoneId);
        }
        
        public static ZoneId Of(string zoneId)
        {
            return new ZoneId(zoneId);
        }
        
        public static ZoneId From(TemporalAccessor temporalAccessor)
        {
            // Simplified implementation
            return new ZoneId("UTC");
        }
        
        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }
        
        public static HashSet<string> GetAvailableZoneIds()
        {
            HashSet<string> zoneIds = new HashSet<string>();
            foreach (TimeZoneInfo tz in TimeZoneInfo.GetSystemTimeZones())
            {
                zoneIds.Add(tz.Id);
            }
            return zoneIds;
        }
        
        public static ZoneId OfOffset(string prefix, ZoneOffset offset)
        {
            string id = prefix + offset.GetOffset().ToString(@"hh\:mm");
            return new ZoneId(id);
        }
        
        public override string ToString()
        {
            return _id;
        }
    }
    
    public class java_time_ZoneIdAutoTest
    {
        public void of_test_13722(string p0, Dictionary<string, string> p1)
        {
            ZoneId.Of(p0, p1);
        }
        
        public void of_test_13723(string p0)
        {
            ZoneId.Of(p0);
        }
        
        public void from_test_13724(TemporalAccessor p0)
        {
            ZoneId.From(p0);
        }
        
        public void systemDefault_test_13725()
        {
            ZoneId.SystemDefault();
        }
        
        public void getAvailableZoneIds_test_13726()
        {
            ZoneId.GetAvailableZoneIds();
        }
        
        public void ofOffset_test_13727(string p0, ZoneOffset p1)
        {
            ZoneId.OfOffset(p0, p1);
        }
    }
}