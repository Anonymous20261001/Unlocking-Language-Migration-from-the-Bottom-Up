namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public class java_beans_IntrospectorAutoTest
    {
        public void getBeanInfoSearchPath_test_5924()
        {
            Introspector.GetBeanInfoSearchPath();
        }

        public void setBeanInfoSearchPath_test_5925(string[] p0)
        {
            Introspector.SetBeanInfoSearchPath(p0);
        }

        public void flushCaches_test_5926()
        {
            Introspector.FlushCaches();
        }

        public void flushFromCaches_test_5927(Type p0)
        {
            Introspector.FlushFromCaches(p0);
        }

        public void decapitalize_test_5928(string p0)
        {
            Introspector.Decapitalize(p0);
        }
    }

    public static class Introspector
    {
        private static string[] _searchPath = new string[] { };

        public static string[] GetBeanInfoSearchPath()
        {
            return _searchPath;
        }

        public static void SetBeanInfoSearchPath(string[] path)
        {
            _searchPath = path ?? new string[0];
        }

        public static void FlushCaches()
        {
            // Clear any cached bean info
            _beanInfoCache.Clear();
        }

        public static void FlushFromCaches(Type type)
        {
            if (type != null)
            {
                _beanInfoCache.Remove(type);
            }
        }

        public static string Decapitalize(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                return name;
            }

            // If the first two characters are both uppercase, return the string unchanged
            if (name.Length > 1 && char.IsUpper(name[0]) && char.IsUpper(name[1]))
            {
                return name;
            }

            // Otherwise, decapitalize the first character
            char[] chars = name.ToCharArray();
            chars[0] = char.ToLower(chars[0]);
            return new string(chars);
        }

        private static Dictionary<Type, object> _beanInfoCache = new Dictionary<Type, object>();
    }
}