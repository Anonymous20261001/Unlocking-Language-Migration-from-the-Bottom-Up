namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class PosixFilePermission
    {
        public string Name { get; private set; }

        public PosixFilePermission(string name)
        {
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }

        public override bool Equals(object obj)
        {
            if (obj is PosixFilePermission other)
            {
                return Name == other.Name;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Name != null ? Name.GetHashCode() : 0;
        }
    }

    public static class PosixFilePermissions
    {
        public static readonly PosixFilePermission OWNER_READ = new PosixFilePermission("OWNER_READ");
        public static readonly PosixFilePermission OWNER_WRITE = new PosixFilePermission("OWNER_WRITE");
        public static readonly PosixFilePermission OWNER_EXECUTE = new PosixFilePermission("OWNER_EXECUTE");
        public static readonly PosixFilePermission GROUP_READ = new PosixFilePermission("GROUP_READ");
        public static readonly PosixFilePermission GROUP_WRITE = new PosixFilePermission("GROUP_WRITE");
        public static readonly PosixFilePermission GROUP_EXECUTE = new PosixFilePermission("GROUP_EXECUTE");
        public static readonly PosixFilePermission OTHERS_READ = new PosixFilePermission("OTHERS_READ");
        public static readonly PosixFilePermission OTHERS_WRITE = new PosixFilePermission("OTHERS_WRITE");
        public static readonly PosixFilePermission OTHERS_EXECUTE = new PosixFilePermission("OTHERS_EXECUTE");

        public static FileAttribute<ISet<PosixFilePermission>> AsFileAttribute(ISet<PosixFilePermission> perms)
        {
            if (perms == null)
                throw new ArgumentNullException("perms");
            return new FileAttribute<ISet<PosixFilePermission>>("posix:permissions", perms);
        }

        public static ISet<PosixFilePermission> FromString(string perms)
        {
            if (perms == null)
                throw new ArgumentNullException("perms");
            if (perms.Length != 9)
                throw new ArgumentException("Invalid mode: " + perms);

            var result = new HashSet<PosixFilePermission>();
            char[] chars = perms.ToCharArray();

            if (chars[0] == 'r') result.Add(OWNER_READ);
            if (chars[1] == 'w') result.Add(OWNER_WRITE);
            if (chars[2] == 'x') result.Add(OWNER_EXECUTE);
            if (chars[3] == 'r') result.Add(GROUP_READ);
            if (chars[4] == 'w') result.Add(GROUP_WRITE);
            if (chars[5] == 'x') result.Add(GROUP_EXECUTE);
            if (chars[6] == 'r') result.Add(OTHERS_READ);
            if (chars[7] == 'w') result.Add(OTHERS_WRITE);
            if (chars[8] == 'x') result.Add(OTHERS_EXECUTE);

            return result;
        }
    }

    public class FileAttribute<T>
    {
        public string Name { get; private set; }
        public T Value { get; private set; }

        public FileAttribute(string name, T value)
        {
            Name = name;
            Value = value;
        }
    }

    public class java_nio_file_attribute_PosixFilePermissionsAutoTest
    {
        public void asFileAttribute_test_9995(ISet<PosixFilePermission> p0)
        {
            PosixFilePermissions.AsFileAttribute(p0);
        }

        public void fromString_test_9996(string p0)
        {
            PosixFilePermissions.FromString(p0);
        }
    }
}