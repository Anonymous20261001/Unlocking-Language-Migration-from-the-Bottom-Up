namespace Generated.Test
{
    public class java_lang_MathAutoTest
    {
        public void abs_test_8296(float p0)
        {
            System.Math.Abs(p0);
        }

        public void abs_test_8297(long p0)
        {
            System.Math.Abs(p0);
        }

        public void abs_test_8298(int p0)
        {
            System.Math.Abs(p0);
        }

        public void abs_test_8299(double p0)
        {
            System.Math.Abs(p0);
        }

        public void sin_test_8300(double p0)
        {
            System.Math.Sin(p0);
        }

        public void cos_test_8301(double p0)
        {
            System.Math.Cos(p0);
        }

        public void tan_test_8302(double p0)
        {
            System.Math.Tan(p0);
        }

        public void atan2_test_8303(double p0, double p1)
        {
            System.Math.Atan2(p0, p1);
        }

        public void sqrt_test_8304(double p0)
        {
            System.Math.Sqrt(p0);
        }

        public void log_test_8305(double p0)
        {
            System.Math.Log(p0);
        }

        public void log10_test_8306(double p0)
        {
            System.Math.Log10(p0);
        }

        public void pow_test_8307(double p0, double p1)
        {
            System.Math.Pow(p0, p1);
        }

        public void exp_test_8308(double p0)
        {
            System.Math.Exp(p0);
        }

        public void min_test_8309(int p0, int p1)
        {
            System.Math.Min(p0, p1);
        }

        public void min_test_8310(long p0, long p1)
        {
            System.Math.Min(p0, p1);
        }

        public void min_test_8311(double p0, double p1)
        {
            System.Math.Min(p0, p1);
        }

        public void min_test_8312(float p0, float p1)
        {
            System.Math.Min(p0, p1);
        }

        public void max_test_8313(long p0, long p1)
        {
            System.Math.Max(p0, p1);
        }

        public void max_test_8314(int p0, int p1)
        {
            System.Math.Max(p0, p1);
        }

        public void max_test_8315(double p0, double p1)
        {
            System.Math.Max(p0, p1);
        }

        public void max_test_8316(float p0, float p1)
        {
            System.Math.Max(p0, p1);
        }

        public void floor_test_8317(double p0)
        {
            System.Math.Floor(p0);
        }

        public void ceil_test_8318(double p0)
        {
            System.Math.Ceiling(p0);
        }

        public void rint_test_8319(double p0)
        {
            System.Math.Round(p0);
        }

        public void round_test_8320(double p0)
        {
            System.Math.Round(p0);
        }

        public void round_test_8321(float p0)
        {
            System.Math.Round(p0);
        }

        public void tanh_test_8322(double p0)
        {
            System.Math.Tanh(p0);
        }

        public void cbrt_test_8323(double p0)
        {
            System.Math.Cbrt(p0);
        }

        public void addExact_test_8324(int p0, int p1)
        {
            checked(p0 + p1);
        }

        public void addExact_test_8325(long p0, long p1)
        {
            checked(p0 + p1);
        }

        public void decrementExact_test_8326(int p0)
        {
            checked(p0 - 1);
        }

        public void decrementExact_test_8327(long p0)
        {
            checked(p0 - 1);
        }

        public void incrementExact_test_8328(long p0)
        {
            checked(p0 + 1);
        }

        public void incrementExact_test_8329(int p0)
        {
            checked(p0 + 1);
        }

        public void multiplyExact_test_8330(long p0, long p1)
        {
            checked(p0 * p1);
        }

        public void multiplyExact_test_8331(int p0, int p1)
        {
            checked(p0 * p1);
        }

        public void multiplyExact_test_8332(long p0, int p1)
        {
            checked(p0 * p1);
        }

        public void multiplyHigh_test_8333(long p0, long p1)
        {
            // Java's Math.multiplyHigh returns the high 64 bits of the 128-bit product
            // In C#, we can use BigInteger for this
            System.Numerics.BigInteger result = (System.Numerics.BigInteger)p0 * p1;
            result >>= 64;
        }

        public void unsignedMultiplyHigh_test_8334(long p0, long p1)
        {
            // Java's Math.unsignedMultiplyHigh returns the high 64 bits of the unsigned 128-bit product
            // In C#, we can use BigInteger with unsigned interpretation
            System.Numerics.BigInteger a = (System.Numerics.BigInteger)(ulong)p0;
            System.Numerics.BigInteger b = (System.Numerics.BigInteger)(ulong)p1;
            System.Numerics.BigInteger result = a * b;
            result >>= 64;
        }

        public void negateExact_test_8335(long p0)
        {
            checked(-p0);
        }

        public void negateExact_test_8336(int p0)
        {
            checked(-p0);
        }

        public void subtractExact_test_8337(int p0, int p1)
        {
            checked(p0 - p1);
        }

        public void subtractExact_test_8338(long p0, long p1)
        {
            checked(p0 - p1);
        }

        public void fma_test_8339(double p0, double p1, double p2)
        {
            // C# doesn't have a built-in FMA for double, use Math.FusedMultiplyAdd if available
            // For .NET Core 3.0+, use Math.FusedMultiplyAdd
            // For older versions, approximate with p0 * p1 + p2
            System.Math.FusedMultiplyAdd(p0, p1, p2);
        }

        public void fma_test_8340(float p0, float p1, float p2)
        {
            // C# doesn't have a built-in FMA for float, use MathF.FusedMultiplyAdd if available
            // For .NET Core 3.0+, use MathF.FusedMultiplyAdd
            // For older versions, approximate with p0 * p1 + p2
            System.MathF.FusedMultiplyAdd(p0, p1, p2);
        }

        public void copySign_test_8341(double p0, double p1)
        {
            // Java's Math.copySign returns the first argument with the sign of the second
            if (double.IsNaN(p1))
                p1 = 1.0;
            if (p1 < 0)
                System.Math.Abs(p0) * -1;
            else
                System.Math.Abs(p0);
        }

        public void copySign_test_8342(float p0, float p1)
        {
            // Java's Math.copySign returns the first argument with the sign of the second
            if (float.IsNaN(p1))
                p1 = 1.0f;
            if (p1 < 0)
                System.Math.Abs(p0) * -1;
            else
                System.Math.Abs(p0);
        }

        public void signum_test_8343(float p0)
        {
            System.Math.Sign(p0);
        }

        public void signum_test_8344(double p0)
        {
            System.Math.Sign(p0);
        }

        public void clamp_test_8345(float p0, float p1, float p2)
        {
            System.Math.Clamp(p0, p1, p2);
        }

        public void clamp_test_8346(long p0, int p1, int p2)
        {
            System.Math.Clamp(p0, p1, p2);
        }

        public void clamp_test_8347(double p0, double p1, double p2)
        {
            System.Math.Clamp(p0, p1, p2);
        }

        public void clamp_test_8348(long p0, long p1, long p2)
        {
            System.Math.Clamp(p0, p1, p2);
        }

        public void scalb_test_8349(float p0, int p1)
        {
            // Java's Math.scalb returns p0 * 2^p1
            p0 * System.Math.Pow(2, p1);
        }

        public void scalb_test_8350(double p0, int p1)
        {
            // Java's Math.scalb returns p0 * 2^p1
            p0 * System.Math.Pow(2, p1);
        }

        public void getExponent_test_8351(float p0)
        {
            // Java's Math.getExponent returns the unbiased exponent of the float
            // In C#, we can use BitConverter to extract the exponent
            int bits = System.BitConverter.SingleToInt32Bits(p0);
            int exponent = ((bits >> 23) & 0xFF) - 127;
            if (exponent == -127 && (bits & 0x7FFFFF) == 0)
                exponent = -127; // zero
            else if (exponent == 128)
                exponent = 128; // infinity or NaN
        }

        public void getExponent_test_8352(double p0)
        {
            // Java's Math.getExponent returns the unbiased exponent of the double
            // In C#, we can use BitConverter to extract the exponent
            long bits = System.BitConverter.DoubleToInt64Bits(p0);
            int exponent = (int)((bits >> 52) & 0x7FF) - 1023;
            if (exponent == -1023 && (bits & 0xFFFFFFFFFFFFF) == 0)
                exponent = -1023; // zero
            else if (exponent == 1024)
                exponent = 1024; // infinity or NaN
        }

        public void floorMod_test_8353(long p0, long p1)
        {
            // Java's Math.floorMod returns the floor modulus
            long mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) != (mod < 0)))
                mod += p1;
        }

        public void floorMod_test_8354(int p0, int p1)
        {
            // Java's Math.floorMod returns the floor modulus
            int mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) != (mod < 0)))
                mod += p1;
        }

        public void floorMod_test_8355(long p0, int p1)
        {
            // Java's Math.floorMod returns the floor modulus
            long mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) != (mod < 0)))
                mod += p1;
        }

        public void asin_test_8356(double p0)
        {
            System.Math.Asin(p0);
        }

        public void acos_test_8357(double p0)
        {
            System.Math.Acos(p0);
        }

        public void atan_test_8358(double p0)
        {
            System.Math.Atan(p0);
        }

        public void IEEEremainder_test_8359(double p0, double p1)
        {
            // Java's Math.IEEEremainder computes the remainder per IEEE 754
            // C# doesn't have a direct equivalent, but we can implement it
            double result = p0 - (p1 * System.Math.Round(p0 / p1));
        }

        public void floorDiv_test_8360(long p0, long p1)
        {
            // Java's Math.floorDiv returns the floor division
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) != (p1 < 0)))
                div--;
        }

        public void floorDiv_test_8361(long p0, int p1)
        {
            // Java's Math.floorDiv returns the floor division
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) != (p1 < 0)))
                div--;
        }

        public void floorDiv_test_8362(int p0, int p1)
        {
            // Java's Math.floorDiv returns the floor division
            int div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) != (p1 < 0)))
                div--;
        }

        public void ceilDiv_test_8363(long p0, long p1)
        {
            // Java's Math.ceilDiv returns the ceiling division
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) == (p1 < 0)))
                div++;
        }

        public void ceilDiv_test_8364(long p0, int p1)
        {
            // Java's Math.ceilDiv returns the ceiling division
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) == (p1 < 0)))
                div++;
        }

        public void ceilDiv_test_8365(int p0, int p1)
        {
            // Java's Math.ceilDiv returns the ceiling division
            int div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) == (p1 < 0)))
                div++;
        }

        public void ceilMod_test_8366(int p0, int p1)
        {
            // Java's Math.ceilMod returns the ceiling modulus
            int mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) == (mod < 0)))
                mod -= p1;
        }

        public void ceilMod_test_8367(long p0, long p1)
        {
            // Java's Math.ceilMod returns the ceiling modulus
            long mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) == (mod < 0)))
                mod -= p1;
        }

        public void ceilMod_test_8368(long p0, int p1)
        {
            // Java's Math.ceilMod returns the ceiling modulus
            long mod = p0 % p1;
            if (mod != 0 && ((p1 < 0) == (mod < 0)))
                mod -= p1;
        }

        public void sinh_test_8369(double p0)
        {
            System.Math.Sinh(p0);
        }

        public void cosh_test_8370(double p0)
        {
            System.Math.Cosh(p0);
        }

        public void hypot_test_8371(double p0, double p1)
        {
            // Java's Math.hypot returns sqrt(p0^2 + p1^2) without overflow/underflow
            System.Math.Sqrt(p0 * p0 + p1 * p1);
        }

        public void expm1_test_8372(double p0)
        {
            // Java's Math.expm1 returns e^x - 1
            System.Math.Exp(p0) - 1;
        }

        public void log1p_test_8373(double p0)
        {
            // Java's Math.log1p returns ln(1 + x)
            System.Math.Log(1 + p0);
        }

        public void unsignedMultiplyExact_test_8374(int p0, int p1)
        {
            // Java's Math.unsignedMultiplyExact returns the unsigned product
            // In C#, we can use BigInteger for this
            System.Numerics.BigInteger a = (System.Numerics.BigInteger)(uint)p0;
            System.Numerics.BigInteger b = (System.Numerics.BigInteger)(uint)p1;
            System.Numerics.BigInteger result = a * b;
            // Check if it fits in 32 bits
            if (result > uint.MaxValue)
                throw new System.OverflowException();
        }

        public void unsignedMultiplyExact_test_8375(long p0, long p1)
        {
            // Java's Math.unsignedMultiplyExact returns the unsigned product
            // In C#, we can use BigInteger for this
            System.Numerics.BigInteger a = (System.Numerics.BigInteger)(ulong)p0;
            System.Numerics.BigInteger b = (System.Numerics.BigInteger)(ulong)p1;
            System.Numerics.BigInteger result = a * b;
            // Check if it fits in 64 bits
            if (result > ulong.MaxValue)
                throw new System.OverflowException();
        }

        public void unsignedMultiplyExact_test_8376(long p0, int p1)
        {
            // Java's Math.unsignedMultiplyExact returns the unsigned product
            // In C#, we can use BigInteger for this
            System.Numerics.BigInteger a = (System.Numerics.BigInteger)(ulong)p0;
            System.Numerics.BigInteger b = (System.Numerics.BigInteger)(uint)p1;
            System.Numerics.BigInteger result = a * b;
            // Check if it fits in 64 bits
            if (result > ulong.MaxValue)
                throw new System.OverflowException();
        }

        public void toRadians_test_8377(double p0)
        {
            // Java's Math.toRadians converts degrees to radians
            p0 * System.Math.PI / 180.0;
        }

        public void toDegrees_test_8378(double p0)
        {
            // Java's Math.toDegrees converts radians to degrees
            p0 * 180.0 / System.Math.PI;
        }

        public void random_test_8379()
        {
            // Java's Math.random returns a double between 0.0 and 1.0
            System.Random rand = new System.Random();
            rand.NextDouble();
        }

        public void divideExact_test_8380(int p0, int p1)
        {
            // Java's Math.divideExact throws ArithmeticException if the result overflows
            if (p0 == int.MinValue && p1 == -1)
                throw new System.OverflowException();
            p0 / p1;
        }

        public void divideExact_test_8381(long p0, long p1)
        {
            // Java's Math.divideExact throws ArithmeticException if the result overflows
            if (p0 == long.MinValue && p1 == -1)
                throw new System.OverflowException();
            p0 / p1;
        }

        public void floorDivExact_test_8382(int p0, int p1)
        {
            // Java's Math.floorDivExact returns the floor division and throws on overflow
            if (p0 == int.MinValue && p1 == -1)
                throw new System.OverflowException();
            int div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) != (p1 < 0)))
                div--;
        }

        public void floorDivExact_test_8383(long p0, long p1)
        {
            // Java's Math.floorDivExact returns the floor division and throws on overflow
            if (p0 == long.MinValue && p1 == -1)
                throw new System.OverflowException();
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) != (p1 < 0)))
                div--;
        }

        public void ceilDivExact_test_8384(long p0, long p1)
        {
            // Java's Math.ceilDivExact returns the ceiling division and throws on overflow
            if (p0 == long.MinValue && p1 == -1)
                throw new System.OverflowException();
            long div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) == (p1 < 0)))
                div++;
        }

        public void ceilDivExact_test_8385(int p0, int p1)
        {
            // Java's Math.ceilDivExact returns the ceiling division and throws on overflow
            if (p0 == int.MinValue && p1 == -1)
                throw new System.OverflowException();
            int div = p0 / p1;
            if ((p0 % p1 != 0) && ((p0 < 0) == (p1 < 0)))
                div++;
        }

        public void toIntExact_test_8386(long p0)
        {
            // Java's Math.toIntExact converts long to int, throwing on overflow
            if (p0 < int.MinValue || p0 > int.MaxValue)
                throw new System.OverflowException();
            (int)p0;
        }

        public void multiplyFull_test_8387(int p0, int p1)
        {
            // Java's Math.multiplyFull returns the full 64-bit product of two ints
            (long)p0 * p1;
        }

        public void absExact_test_8388(long p0)
        {
            // Java's Math.absExact throws on overflow for long.MinValue
            if (p0 == long.MinValue)
                throw new System.OverflowException();
            System.Math.Abs(p0);
        }

        public void absExact_test_8389(int p0)
        {
            // Java's Math.absExact throws on overflow for int.MinValue
            if (p0 == int.MinValue)
                throw new System.OverflowException();
            System.Math.Abs(p0);
        }

        public void ulp_test_8390(float p0)
        {
            // Java's Math.ulp returns the size of an ulp of the argument
            // In C#, we can use BitConverter to compute this
            if (float.IsNaN(p0))
                return;
            if (float.IsInfinity(p0))
                return;
            int bits = System.BitConverter.SingleToInt32Bits(p0);
            if ((bits & 0x7FFFFFFF) == 0)
                return; // zero
            if ((bits & 0x7F800000) == 0x7F800000)
                return; // infinity or NaN
            int exponent = ((bits >> 23) & 0xFF) - 127;
            if (exponent == -127)
                exponent = -126;
            float ulp = (float)System.Math.Pow(2, exponent - 23);
        }

        public void ulp_test_8391(double p0)
        {
            // Java's Math.ulp returns the size of an ulp of the argument
            // In C#, we can use BitConverter to compute this
            if (double.IsNaN(p0))
                return;
            if (double.IsInfinity(p0))
                return;
            long bits = System.BitConverter.DoubleToInt64Bits(p0);
            if ((bits & 0x7FFFFFFFFFFFFFFF) == 0)
                return; // zero
            if ((bits & 0x7FF0000000000000) == 0x7FF0000000000000)
                return; // infinity or NaN
            int exponent = (int)((bits >> 52) & 0x7FF) - 1023;
            if (exponent == -1023)
                exponent = -1022;
            double ulp = System.Math.Pow(2, exponent - 52);
        }

        public void nextAfter_test_8392(double p0, double p1)
        {
            // Java's Math.nextAfter returns the adjacent floating-point number
            // In C#, we can use BitConverter to compute this
            if (double.IsNaN(p0) || double.IsNaN(p1))
                return;
            if (p0 == p1)
                return;
            if (p0 == 0)
            {
                if (p1 > 0)
                    return double.Epsilon;
                else
                    return -double.Epsilon;
            }
            long bits = System.BitConverter.DoubleToInt64Bits(p0);
            if ((p0 > 0 && p1 > p0) || (p0 < 0 && p1 < p0))
                bits++;
            else
                bits--;
            System.BitConverter.Int64BitsToDouble(bits);
        }

        public void nextAfter_test_8393(float p0, double p1)
        {
            // Java's Math.nextAfter returns the adjacent floating-point number
            // In C#, we can use BitConverter to compute this
            if (float.IsNaN(p0) || double.IsNaN(p1))
                return;
            if (p0 == p1)
                return;
            if (p0 == 0)
            {
                if (p1 > 0)
                    return float.Epsilon;
                else
                    return -float.Epsilon;
            }
            int bits = System.BitConverter.SingleToInt32Bits(p0);
            if ((p0 > 0 && p1 > p0) || (p0 < 0 && p1 < p0))
                bits++;
            else
                bits--;
            System.BitConverter.Int32BitsToSingle(bits);
        }

        public void nextUp_test_8394(float p0)
        {
            // Java's Math.nextUp returns the adjacent floating-point number in the direction of positive infinity
            if (float.IsNaN(p0))
                return;
            if (p0 == float.PositiveInfinity)
                return;
            if (p0 == 0)
                return float.Epsilon;
            int bits = System.BitConverter.SingleToInt32Bits(p0);
            if (p0 > 0)
                bits++;
            else
                bits--;
            System.BitConverter.Int32BitsToSingle(bits);
        }

        public void nextUp_test_8395(double p0)
        {
            // Java's Math.nextUp returns the adjacent floating-point number in the direction of positive infinity
            if (double.IsNaN(p0))
                return;
            if (p0 == double.PositiveInfinity)
                return;
            if (p0 == 0)
                return double.Epsilon;
            long bits = System.BitConverter.DoubleToInt64Bits(p0);
            if (p0 > 0)
                bits++;
            else
                bits--;
            System.BitConverter.Int64BitsToDouble(bits);
        }

        public void nextDown_test_8396(float p0)
        {
            // Java's Math.nextDown returns the adjacent floating-point number in the direction of negative infinity
            if (float.IsNaN(p0))
                return;
            if (p0 == float.NegativeInfinity)
                return;
            if (p0 == 0)
                return -float.Epsilon;
            int bits = System.BitConverter.SingleToInt32Bits(p0);
            if (p0 > 0)
                bits--;
            else
                bits++;
            System.BitConverter.Int32BitsToSingle(bits);
        }

        public void nextDown_test_8397(double p0)
        {
            // Java's Math.nextDown returns the adjacent floating-point number in the direction of negative infinity
            if (double.IsNaN(p0))
                return;
            if (p0 == double.NegativeInfinity)
                return;
            if (p0 == 0)
                return -double.Epsilon;
            long bits = System.BitConverter.DoubleToInt64Bits(p0);
            if (p0 > 0)
                bits--;
            else
                bits++;
            System.BitConverter.Int64BitsToDouble(bits);
        }

        public void powExact_test_8398(int p0, int p1)
        {
            // Java's Math.powExact computes p0^p1 exactly, throwing on overflow
            if (p1 < 0)
                throw new System.ArithmeticException("Negative exponent");
            System.Numerics.BigInteger result = 1;
            System.Numerics.BigInteger base_val = p0;
            int exp = p1;
            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result *= base_val;
                base_val *= base_val;
                exp >>= 1;
            }
            if (result > int.MaxValue || result < int.MinValue)
                throw new System.OverflowException();
        }

        public void powExact_test_8399(long p0, int p1)
        {
            // Java's Math.powExact computes p0^p1 exactly, throwing on overflow
            if (p1 < 0)
                throw new System.ArithmeticException("Negative exponent");
            System.Numerics.BigInteger result = 1;
            System.Numerics.BigInteger base_val = p0;
            int exp = p1;
            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result *= base_val;
                base_val *= base_val;
                exp >>= 1;
            }
            if (result > long.MaxValue || result < long.MinValue)
                throw new System.OverflowException();
        }

        public void unsignedPowExact_test_8400(long p0, int p1)
        {
            // Java's Math.unsignedPowExact computes p0^p1 exactly, throwing on overflow
            if (p1 < 0)
                throw new System.ArithmeticException("Negative exponent");
            System.Numerics.BigInteger result = 1;
            System.Numerics.BigInteger base_val = (System.Numerics.BigInteger)(ulong)p0;
            int exp = p1;
            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result *= base_val;
                base_val *= base_val;
                exp >>= 1;
            }
            if (result > ulong.MaxValue)
                throw new System.OverflowException();
        }

        public void unsignedPowExact_test_8401(int p0, int p1)
        {
            // Java's Math.unsignedPowExact computes p0^p1 exactly, throwing on overflow
            if (p1 < 0)
                throw new System.ArithmeticException("Negative exponent");
            System.Numerics.BigInteger result = 1;
            System.Numerics.BigInteger base_val = (System.Numerics.BigInteger)(uint)p0;
            int exp = p1;
            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result *= base_val;
                base_val *= base_val;
                exp >>= 1;
            }
            if (result > uint.MaxValue)
                throw new System.OverflowException();
        }
    }
}