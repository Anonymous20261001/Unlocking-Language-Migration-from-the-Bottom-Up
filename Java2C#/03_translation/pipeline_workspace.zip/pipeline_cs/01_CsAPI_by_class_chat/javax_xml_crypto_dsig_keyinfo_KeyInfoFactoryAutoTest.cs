using System;
using System.Security.Cryptography;

namespace Generated.Test
{
    public class javax_xml_crypto_dsig_keyinfo_KeyInfoFactoryAutoTest
    {
        public void getInstance_test_7625()
        {
            KeyInfoFactory.GetInstance();
        }

        public void getInstance_test_7626(string p0, Provider p1)
        {
            KeyInfoFactory.GetInstance(p0, p1);
        }

        public void getInstance_test_7627(string p0)
        {
            KeyInfoFactory.GetInstance(p0);
        }
    }

    public class KeyInfoFactory
    {
        public static KeyInfoFactory GetInstance()
        {
            return new KeyInfoFactory();
        }

        public static KeyInfoFactory GetInstance(string algorithm, Provider provider)
        {
            return new KeyInfoFactory();
        }

        public static KeyInfoFactory GetInstance(string algorithm)
        {
            return new KeyInfoFactory();
        }
    }

    public class Provider
    {
        public string Name { get; set; }
        public double Version { get; set; }
        public string Info { get; set; }

        public Provider(string name, double version, string info)
        {
            Name = name;
            Version = version;
            Info = info;
        }
    }
}