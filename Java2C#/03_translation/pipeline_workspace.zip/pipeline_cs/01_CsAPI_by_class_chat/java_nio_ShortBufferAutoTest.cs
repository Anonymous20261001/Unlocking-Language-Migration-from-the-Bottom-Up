namespace Generated.Test
{
    public class java_nio_ShortBufferAutoTest
    {
        public void wrap_test_11098(short[] p0)
        {
            ShortBuffer.Wrap(p0);
        }

        public void wrap_test_11099(short[] p0, int p1, int p2)
        {
            ShortBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_11100(int p0)
        {
            ShortBuffer.Allocate(p0);
        }
    }

    public class ShortBuffer
    {
        private short[] _array;
        private int _offset;
        private int _length;

        private ShortBuffer(short[] array, int offset, int length)
        {
            _array = array;
            _offset = offset;
            _length = length;
        }

        public static ShortBuffer Wrap(short[] array)
        {
            return new ShortBuffer(array, 0, array.Length);
        }

        public static ShortBuffer Wrap(short[] array, int offset, int length)
        {
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new System.ArgumentOutOfRangeException();
            return new ShortBuffer(array, offset, length);
        }

        public static ShortBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new System.ArgumentOutOfRangeException();
            return new ShortBuffer(new short[capacity], 0, capacity);
        }
    }
}