namespace Generated.Test
{
    public class java_awt_DesktopAutoTest
    {
        public void getDesktop_test_4108()
        {
            Desktop.GetDesktop();
        }

        public void isDesktopSupported_test_4109()
        {
            Desktop.IsDesktopSupported();
        }
    }

    public class Desktop
    {
        public static Desktop GetDesktop()
        {
            return new Desktop();
        }

        public static bool IsDesktopSupported()
        {
            return true;
        }
    }
}