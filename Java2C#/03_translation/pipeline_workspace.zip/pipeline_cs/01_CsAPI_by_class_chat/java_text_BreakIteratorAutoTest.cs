namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;

    public class java_text_BreakIteratorAutoTest
    {
        public void getAvailableLocales_test_1878()
        {
            BreakIterator.GetAvailableLocales();
        }

        public void getWordInstance_test_1879()
        {
            BreakIterator.GetWordInstance();
        }

        public void getWordInstance_test_1880(Locale p0)
        {
            BreakIterator.GetWordInstance(p0);
        }

        public void getLineInstance_test_1881(Locale p0)
        {
            BreakIterator.GetLineInstance(p0);
        }

        public void getLineInstance_test_1882()
        {
            BreakIterator.GetLineInstance();
        }

        public void getCharacterInstance_test_1883(Locale p0)
        {
            BreakIterator.GetCharacterInstance(p0);
        }

        public void getCharacterInstance_test_1884()
        {
            BreakIterator.GetCharacterInstance();
        }

        public void getSentenceInstance_test_1885(Locale p0)
        {
            BreakIterator.GetSentenceInstance(p0);
        }

        public void getSentenceInstance_test_1886()
        {
            BreakIterator.GetSentenceInstance();
        }
    }

    public class Locale
    {
        public static Locale Default { get; } = new Locale(CultureInfo.CurrentCulture);

        public CultureInfo Culture { get; }

        public Locale(CultureInfo culture)
        {
            Culture = culture;
        }

        public static Locale GetDefault()
        {
            return Default;
        }
    }

    public class BreakIterator
    {
        public static Locale[] GetAvailableLocales()
        {
            var cultures = CultureInfo.GetCultures(CultureTypes.AllCultures);
            var locales = new Locale[cultures.Length];
            for (int i = 0; i < cultures.Length; i++)
            {
                locales[i] = new Locale(cultures[i]);
            }
            return locales;
        }

        public static BreakIterator GetWordInstance()
        {
            return GetWordInstance(Locale.Default);
        }

        public static BreakIterator GetWordInstance(Locale locale)
        {
            return new BreakIterator(locale, BreakIteratorType.Word);
        }

        public static BreakIterator GetLineInstance()
        {
            return GetLineInstance(Locale.Default);
        }

        public static BreakIterator GetLineInstance(Locale locale)
        {
            return new BreakIterator(locale, BreakIteratorType.Line);
        }

        public static BreakIterator GetCharacterInstance()
        {
            return GetCharacterInstance(Locale.Default);
        }

        public static BreakIterator GetCharacterInstance(Locale locale)
        {
            return new BreakIterator(locale, BreakIteratorType.Character);
        }

        public static BreakIterator GetSentenceInstance()
        {
            return GetSentenceInstance(Locale.Default);
        }

        public static BreakIterator GetSentenceInstance(Locale locale)
        {
            return new BreakIterator(locale, BreakIteratorType.Sentence);
        }

        private enum BreakIteratorType
        {
            Character,
            Word,
            Line,
            Sentence
        }

        private readonly Locale _locale;
        private readonly BreakIteratorType _type;

        private BreakIterator(Locale locale, BreakIteratorType type)
        {
            _locale = locale;
            _type = type;
        }
    }
}