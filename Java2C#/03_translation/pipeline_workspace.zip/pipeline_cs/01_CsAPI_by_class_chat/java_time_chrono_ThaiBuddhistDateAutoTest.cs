using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_time_chrono_ThaiBuddhistDateAutoTest
    {
        public void of_test_12647(int p0, int p1, int p2)
        {
            ThaiBuddhistDate.Of(p0, p1, p2);
        }

        public void from_test_12648(TemporalAccessor p0)
        {
            ThaiBuddhistDate.From(p0);
        }

        public void now_test_12649()
        {
            ThaiBuddhistDate.Now();
        }

        public void now_test_12650(ZoneId p0)
        {
            ThaiBuddhistDate.Now(p0);
        }

        public void now_test_12651(Clock p0)
        {
            ThaiBuddhistDate.Now(p0);
        }
    }

    public class ThaiBuddhistDate
    {
        private DateTime _dateTime;

        private ThaiBuddhistDate(DateTime dateTime)
        {
            _dateTime = dateTime;
        }

        public static ThaiBuddhistDate Of(int year, int month, int day)
        {
            // Thai Buddhist year is 543 years ahead of Gregorian year
            int gregorianYear = year - 543;
            return new ThaiBuddhistDate(new DateTime(gregorianYear, month, day));
        }

        public static ThaiBuddhistDate From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return new ThaiBuddhistDate(temporal.ToDateTime());
        }

        public static ThaiBuddhistDate Now()
        {
            return new ThaiBuddhistDate(DateTime.Now);
        }

        public static ThaiBuddhistDate Now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException(nameof(zone));
            return new ThaiBuddhistDate(TimeZoneInfo.ConvertTime(DateTime.UtcNow, zone.ToTimeZoneInfo()));
        }

        public static ThaiBuddhistDate Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            return new ThaiBuddhistDate(clock.GetCurrentDateTime());
        }

        public DateTime ToDateTime()
        {
            return _dateTime;
        }
    }

    public abstract class TemporalAccessor
    {
        public abstract DateTime ToDateTime();
    }

    public class ZoneId
    {
        private string _id;

        public ZoneId(string id)
        {
            _id = id;
        }

        public static ZoneId Of(string id)
        {
            return new ZoneId(id);
        }

        public TimeZoneInfo ToTimeZoneInfo()
        {
            return TimeZoneInfo.FindSystemTimeZoneById(_id);
        }
    }

    public class Clock
    {
        private Func<DateTime> _currentTimeProvider;

        public Clock(Func<DateTime> currentTimeProvider)
        {
            _currentTimeProvider = currentTimeProvider;
        }

        public static Clock SystemDefaultZone()
        {
            return new Clock(() => DateTime.Now);
        }

        public static Clock SystemUTC()
        {
            return new Clock(() => DateTime.UtcNow);
        }

        public DateTime GetCurrentDateTime()
        {
            return _currentTimeProvider();
        }
    }
}