namespace Generated.Test
{
    public class DrbgParameters
    {
        public enum Capability
        {
            PR_AND_RESEED,
            RESEED_ONLY,
            NONE
        }

        public class Reseed
        {
            public bool PredictionResistance { get; }
            public byte[] AdditionalInput { get; }

            public Reseed(bool predictionResistance, byte[] additionalInput)
            {
                PredictionResistance = predictionResistance;
                AdditionalInput = additionalInput;
            }
        }

        public class Instantiation
        {
            public int Strength { get; }
            public Capability CapabilityValue { get; }
            public byte[] AdditionalInput { get; }

            public Instantiation(int strength, Capability capability, byte[] additionalInput)
            {
                Strength = strength;
                CapabilityValue = capability;
                AdditionalInput = additionalInput;
            }
        }

        public class NextBytes
        {
            public int Length { get; }
            public bool PredictionResistance { get; }
            public byte[] AdditionalInput { get; }

            public NextBytes(int length, bool predictionResistance, byte[] additionalInput)
            {
                Length = length;
                PredictionResistance = predictionResistance;
                AdditionalInput = additionalInput;
            }
        }

        public static Reseed reseed(bool predictionResistance, byte[] additionalInput)
        {
            return new Reseed(predictionResistance, additionalInput);
        }

        public static Instantiation instantiation(int strength, Capability capability, byte[] additionalInput)
        {
            return new Instantiation(strength, capability, additionalInput);
        }

        public static NextBytes nextBytes(int length, bool predictionResistance, byte[] additionalInput)
        {
            return new NextBytes(length, predictionResistance, additionalInput);
        }
    }

    public class java_security_DrbgParametersAutoTest
    {
        public void reseed_test_4339(bool p0, byte[] p1)
        {
            DrbgParameters.reseed(p0, p1);
        }

        public void instantiation_test_4340(int p0, DrbgParameters.Capability p1, byte[] p2)
        {
            DrbgParameters.instantiation(p0, p1, p2);
        }

        public void nextBytes_test_4341(int p0, bool p1, byte[] p2)
        {
            DrbgParameters.nextBytes(p0, p1, p2);
        }
    }
}