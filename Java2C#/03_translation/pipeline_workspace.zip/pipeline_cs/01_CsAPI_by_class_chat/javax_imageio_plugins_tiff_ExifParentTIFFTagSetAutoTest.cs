namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_ExifParentTIFFTagSetAutoTest
    {
        public void getInstance_test_4663()
        {
            ExifParentTIFFTagSet.getInstance();
        }
    }

    public class ExifParentTIFFTagSet
    {
        private static ExifParentTIFFTagSet instance;

        private ExifParentTIFFTagSet()
        {
        }

        public static ExifParentTIFFTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new ExifParentTIFFTagSet();
            }
            return instance;
        }
    }
}