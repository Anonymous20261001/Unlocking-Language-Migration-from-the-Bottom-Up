using System;
using System.Reflection;
using System.Linq.Expressions;

namespace Generated.Test
{
    public class MethodHandle
    {
        // Simplified representation of a method handle
        public Delegate Target { get; set; }
        
        public MethodHandle(Delegate target)
        {
            Target = target;
        }
    }

    public static class MethodHandleProxies
    {
        public static bool isWrapperInstance(object p0)
        {
            return p0 is IMethodHandleWrapper;
        }

        public static object asInterfaceInstance(Type p0, MethodHandle p1)
        {
            if (!p0.IsInterface)
                throw new ArgumentException("Type must be an interface");
            
            if (p1 == null)
                throw new ArgumentNullException(nameof(p1));

            // Create a dynamic proxy that implements the interface
            var proxy = DispatchProxy.Create(p0, typeof(MethodHandleProxy));
            ((MethodHandleProxy)(object)proxy).Handle = p1;
            return proxy;
        }

        public static object wrapperInstanceTarget(object p0)
        {
            if (p0 is IMethodHandleWrapper wrapper)
                return wrapper.GetTarget();
            throw new ArgumentException("Object is not a wrapper instance");
        }

        public static Type wrapperInstanceType(object p0)
        {
            if (p0 is IMethodHandleWrapper wrapper)
                return wrapper.GetWrapperType();
            throw new ArgumentException("Object is not a wrapper instance");
        }
    }

    public interface IMethodHandleWrapper
    {
        object GetTarget();
        Type GetWrapperType();
    }

    public class MethodHandleProxy : DispatchProxy, IMethodHandleWrapper
    {
        public MethodHandle Handle { get; set; }

        protected override object Invoke(MethodInfo targetMethod, object[] args)
        {
            if (Handle?.Target == null)
                throw new InvalidOperationException("No method handle target set");

            // Invoke the delegate with the provided arguments
            return Handle.Target.DynamicInvoke(args);
        }

        public object GetTarget()
        {
            return Handle?.Target;
        }

        public Type GetWrapperType()
        {
            return GetType().GetInterfaces()[0];
        }
    }

    public class java_lang_invoke_MethodHandleProxiesAutoTest
    {
        public void isWrapperInstance_test_8870(object p0)
        {
            MethodHandleProxies.isWrapperInstance(p0);
        }

        public void asInterfaceInstance_test_8871(Type p0, MethodHandle p1)
        {
            MethodHandleProxies.asInterfaceInstance(p0, p1);
        }

        public void wrapperInstanceTarget_test_8872(object p0)
        {
            MethodHandleProxies.wrapperInstanceTarget(p0);
        }

        public void wrapperInstanceType_test_8873(object p0)
        {
            MethodHandleProxies.wrapperInstanceType(p0);
        }
    }
}