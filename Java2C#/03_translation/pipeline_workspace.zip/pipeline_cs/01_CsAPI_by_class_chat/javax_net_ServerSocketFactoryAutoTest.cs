namespace Generated.Test
{
    using System.Net.Sockets;

    public class javax_net_ServerSocketFactoryAutoTest
    {
        public void getDefault_test_11047()
        {
            ServerSocketFactory.GetDefault();
        }
    }

    public class ServerSocketFactory
    {
        public static ServerSocketFactory GetDefault()
        {
            return new ServerSocketFactory();
        }
    }
}