namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class HttpHeaders
    {
        private readonly Dictionary<string, List<string>> _headers;

        private HttpHeaders(Dictionary<string, List<string>> headers)
        {
            _headers = headers;
        }

        public static HttpHeaders Of(IDictionary<string, List<string>> headers, Func<string, string, bool> filter)
        {
            if (headers == null)
                throw new ArgumentNullException(nameof(headers));
            if (filter == null)
                throw new ArgumentNullException(nameof(filter));

            var result = new Dictionary<string, List<string>>();
            foreach (var kvp in headers)
            {
                var filteredValues = new List<string>();
                foreach (var value in kvp.Value)
                {
                    if (filter(kvp.Key, value))
                    {
                        filteredValues.Add(value);
                    }
                }
                if (filteredValues.Count > 0)
                {
                    result[kvp.Key] = filteredValues;
                }
            }
            return new HttpHeaders(result);
        }

        public static HttpHeaders Of(IDictionary<string, List<string>> headers)
        {
            return Of(headers, (name, value) => true);
        }
    }

    public class java_net_http_HttpHeadersAutoTest
    {
        public void of_test_5437(IDictionary<string, List<string>> p0, Func<string, string, bool> p1)
        {
            HttpHeaders.Of(p0, p1);
        }
    }
}