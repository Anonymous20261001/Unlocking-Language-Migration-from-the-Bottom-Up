using System;
using System.Net.Http;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_net_http_HttpRequestAutoTest
    {
        public void newBuilder_test_5438(HttpRequest p0, Func<string, string, bool> p1)
        {
            HttpRequest.NewBuilder(p0, p1);
        }

        public void newBuilder_test_5439(Uri p0)
        {
            HttpRequest.NewBuilder(p0);
        }

        public void newBuilder_test_5440()
        {
            HttpRequest.NewBuilder();
        }
    }

    public class HttpRequest
    {
        public static HttpRequestBuilder NewBuilder()
        {
            return new HttpRequestBuilder();
        }

        public static HttpRequestBuilder NewBuilder(Uri uri)
        {
            return new HttpRequestBuilder().Uri(uri);
        }

        public static HttpRequestBuilder NewBuilder(HttpRequest request, Func<string, string, bool> filter)
        {
            return new HttpRequestBuilder().CopyFrom(request, filter);
        }
    }

    public class HttpRequestBuilder
    {
        private Uri _uri;
        private string _method = "GET";
        private HttpContent _content;
        private Dictionary<string, string> _headers = new Dictionary<string, string>();
        private Func<string, string, bool> _filter;

        public HttpRequestBuilder Uri(Uri uri)
        {
            _uri = uri;
            return this;
        }

        public HttpRequestBuilder Method(string method, HttpContent content)
        {
            _method = method;
            _content = content;
            return this;
        }

        public HttpRequestBuilder Header(string name, string value)
        {
            _headers[name] = value;
            return this;
        }

        public HttpRequestBuilder CopyFrom(HttpRequest request, Func<string, string, bool> filter)
        {
            _uri = request.Uri;
            _method = request.Method;
            _content = request.Content;
            _filter = filter;
            foreach (var header in request.Headers)
            {
                if (filter == null || filter(header.Key, header.Value))
                {
                    _headers[header.Key] = header.Value;
                }
            }
            return this;
        }

        public HttpRequest Build()
        {
            return new HttpRequest(_uri, _method, _content, _headers);
        }
    }

    public class HttpRequest
    {
        public Uri Uri { get; }
        public string Method { get; }
        public HttpContent Content { get; }
        public Dictionary<string, string> Headers { get; }

        public HttpRequest(Uri uri, string method, HttpContent content, Dictionary<string, string> headers)
        {
            Uri = uri;
            Method = method;
            Content = content;
            Headers = headers;
        }
    }
}