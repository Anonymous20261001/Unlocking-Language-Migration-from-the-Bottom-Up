using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Sequence
    {
        // Minimal representation of a MIDI sequence
        public float DivisionType { get; set; }
        public int Resolution { get; set; }
        
        public Sequence(float divisionType, int resolution)
        {
            DivisionType = divisionType;
            Resolution = resolution;
        }
    }

    public class MidiDeviceInfo
    {
        public string Name { get; }
        public string Vendor { get; }
        public string Description { get; }
        public string Version { get; }
        
        public MidiDeviceInfo(string name, string vendor, string description, string version)
        {
            Name = name;
            Vendor = vendor;
            Description = description;
            Version = version;
        }
    }

    public static class MidiSystem
    {
        private static readonly int[] SupportedFileTypes = new int[] { 0, 1, 2 };
        private static readonly List<MidiDeviceInfo> DeviceInfoList = new List<MidiDeviceInfo>();

        public static bool isFileTypeSupported(int fileType)
        {
            return Array.IndexOf(SupportedFileTypes, fileType) >= 0;
        }

        public static bool isFileTypeSupported(int fileType, Sequence sequence)
        {
            // In Java, this checks if the file type is supported for the given sequence
            // For simplicity, we'll check the file type and that sequence is not null
            return sequence != null && Array.IndexOf(SupportedFileTypes, fileType) >= 0;
        }

        public static int[] getMidiFileTypes(Sequence sequence)
        {
            // Returns file types supported for the given sequence
            if (sequence == null)
            {
                return new int[0];
            }
            return (int[])SupportedFileTypes.Clone();
        }

        public static int[] getMidiFileTypes()
        {
            return (int[])SupportedFileTypes.Clone();
        }

        public static MidiDeviceInfo[] getMidiDeviceInfo()
        {
            return DeviceInfoList.ToArray();
        }
    }

    public class javax_sound_midi_MidiSystemAutoTest
    {
        public void isFileTypeSupported_test_8942(int p0)
        {
            MidiSystem.isFileTypeSupported(p0);
        }

        public void isFileTypeSupported_test_8943(int p0, Sequence p1)
        {
            MidiSystem.isFileTypeSupported(p0, p1);
        }

        public void getMidiFileTypes_test_8944(Sequence p0)
        {
            MidiSystem.getMidiFileTypes(p0);
        }

        public void getMidiFileTypes_test_8945()
        {
            MidiSystem.getMidiFileTypes();
        }

        public void getMidiDeviceInfo_test_8946()
        {
            MidiSystem.getMidiDeviceInfo();
        }
    }
}