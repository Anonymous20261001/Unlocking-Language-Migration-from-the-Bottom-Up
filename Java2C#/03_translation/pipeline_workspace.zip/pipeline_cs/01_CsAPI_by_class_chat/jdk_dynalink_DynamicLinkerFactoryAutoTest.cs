using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class jdk_dynalink_DynamicLinkerFactoryAutoTest
    {
        public void setFallbackLinkers_test_4425(List<object> p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetFallbackLinkers(p0);
        }

        public void setFallbackLinkers_test_4426(GuardingDynamicLinker[] p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetFallbackLinkers(p0);
        }

        public void setClassLoader_test_4427(ClassLoader p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetClassLoader(p0);
        }

        public void setSyncOnRelink_test_4428(bool p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetSyncOnRelink(p0);
        }

        public void createLinker_test_4429()
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.CreateLinker();
        }

        public void setPrioritizedLinkers_test_4430(List<object> p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetPrioritizedLinkers(p0);
        }

        public void setPrioritizedLinkers_test_4431(GuardingDynamicLinker[] p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetPrioritizedLinkers(p0);
        }

        public void setPrioritizedLinker_test_4432(GuardingDynamicLinker p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetPrioritizedLinker(p0);
        }

        public void setUnstableRelinkThreshold_test_4433(int p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetUnstableRelinkThreshold(p0);
        }

        public void setPrelinkTransformer_test_4434(GuardedInvocationTransformer p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetPrelinkTransformer(p0);
        }

        public void setAutoConversionStrategy_test_4435(MethodTypeConversionStrategy p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetAutoConversionStrategy(p0);
        }

        public void setInternalObjectsFilter_test_4436(MethodHandleTransformer p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.SetInternalObjectsFilter(p0);
        }

        public void getAutoLoadingErrors_test_4437()
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.GetAutoLoadingErrors();
        }
    }

    public class DynamicLinkerFactory
    {
        public void SetFallbackLinkers(List<object> linkers) { }
        public void SetFallbackLinkers(GuardingDynamicLinker[] linkers) { }
        public void SetClassLoader(ClassLoader classLoader) { }
        public void SetSyncOnRelink(bool syncOnRelink) { }
        public object CreateLinker() { return null; }
        public void SetPrioritizedLinkers(List<object> linkers) { }
        public void SetPrioritizedLinkers(GuardingDynamicLinker[] linkers) { }
        public void SetPrioritizedLinker(GuardingDynamicLinker linker) { }
        public void SetUnstableRelinkThreshold(int threshold) { }
        public void SetPrelinkTransformer(GuardedInvocationTransformer transformer) { }
        public void SetAutoConversionStrategy(MethodTypeConversionStrategy strategy) { }
        public void SetInternalObjectsFilter(MethodHandleTransformer filter) { }
        public List<object> GetAutoLoadingErrors() { return null; }
    }

    public class ClassLoader
    {
    }

    public class GuardingDynamicLinker
    {
    }

    public class GuardedInvocationTransformer
    {
    }

    public class MethodTypeConversionStrategy
    {
    }

    public class MethodHandleTransformer
    {
    }
}