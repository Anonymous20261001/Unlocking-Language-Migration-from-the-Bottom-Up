using System;
using System.Collections.Generic;
using javax.management.openmbean;

namespace Generated.Test
{
    // C# equivalent of jdk.management.jfr.EventTypeInfo
    public class EventTypeInfo
    {
        public static EventTypeInfo from(CompositeData cd)
        {
            // Implementation based on Java API behavior
            if (cd == null)
            {
                throw new ArgumentNullException(nameof(cd));
            }

            // Validate required composite data items
            if (!cd.ContainsKey("id") || !cd.ContainsKey("name") || !cd.ContainsKey("description") ||
                !cd.ContainsKey("label") || !cd.ContainsKey("contentType") || !cd.ContainsKey("settings"))
            {
                throw new ArgumentException("Composite data does not contain all required items for EventTypeInfo");
            }

            // Extract values from composite data
            long id = Convert.ToInt64(cd.Get("id"));
            string name = (string)cd.Get("name");
            string description = (string)cd.Get("description");
            string label = (string)cd.Get("label");
            string contentType = (string)cd.Get("contentType");
            object[] settingsArray = (object[])cd.Get("settings");

            // Convert settings array to list of SettingDescriptorInfo
            List<SettingDescriptorInfo> settings = new List<SettingDescriptorInfo>();
            if (settingsArray != null)
            {
                foreach (object settingObj in settingsArray)
                {
                    if (settingObj is CompositeData settingCd)
                    {
                        settings.Add(SettingDescriptorInfo.from(settingCd));
                    }
                }
            }

            return new EventTypeInfo(id, name, description, label, contentType, settings);
        }

        private long id;
        private string name;
        private string description;
        private string label;
        private string contentType;
        private List<SettingDescriptorInfo> settings;

        private EventTypeInfo(long id, string name, string description, string label, string contentType, List<SettingDescriptorInfo> settings)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.label = label;
            this.contentType = contentType;
            this.settings = settings;
        }

        public long getId() => id;
        public string getName() => name;
        public string getDescription() => description;
        public string getLabel() => label;
        public string getContentType() => contentType;
        public IList<SettingDescriptorInfo> getSettings() => settings.AsReadOnly();
    }

    // C# equivalent of jdk.management.jfr.SettingDescriptorInfo (helper class)
    public class SettingDescriptorInfo
    {
        public static SettingDescriptorInfo from(CompositeData cd)
        {
            if (cd == null)
            {
                throw new ArgumentNullException(nameof(cd));
            }

            if (!cd.ContainsKey("name") || !cd.ContainsKey("label") || !cd.ContainsKey("description") ||
                !cd.ContainsKey("typeName") || !cd.ContainsKey("contentType") || !cd.ContainsKey("defaultValue"))
            {
                throw new ArgumentException("Composite data does not contain all required items for SettingDescriptorInfo");
            }

            string name = (string)cd.Get("name");
            string label = (string)cd.Get("label");
            string description = (string)cd.Get("description");
            string typeName = (string)cd.Get("typeName");
            string contentType = (string)cd.Get("contentType");
            string defaultValue = (string)cd.Get("defaultValue");

            return new SettingDescriptorInfo(name, label, description, typeName, contentType, defaultValue);
        }

        private string name;
        private string label;
        private string description;
        private string typeName;
        private string contentType;
        private string defaultValue;

        private SettingDescriptorInfo(string name, string label, string description, string typeName, string contentType, string defaultValue)
        {
            this.name = name;
            this.label = label;
            this.description = description;
            this.typeName = typeName;
            this.contentType = contentType;
            this.defaultValue = defaultValue;
        }

        public string getName() => name;
        public string getLabel() => label;
        public string getDescription() => description;
        public string getTypeName() => typeName;
        public string getContentType() => contentType;
        public string getDefaultValue() => defaultValue;
    }

    // C# equivalent of javax.management.openmbean.CompositeData (simplified)
    public class CompositeData
    {
        private Dictionary<string, object> items;

        public CompositeData(Dictionary<string, object> items)
        {
            this.items = items ?? new Dictionary<string, object>();
        }

        public bool ContainsKey(string key) => items.ContainsKey(key);
        public object Get(string key) => items.TryGetValue(key, out var value) ? value : null;
    }

    // Test class
    public class jdk_management_jfr_EventTypeInfoAutoTest
    {
        public void from_test_4605(CompositeData p0)
        {
            EventTypeInfo.from(p0);
        }
    }
}