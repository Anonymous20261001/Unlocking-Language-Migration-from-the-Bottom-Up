namespace Generated.Test
{
    public class java_io_OutputStreamAutoTest
    {
        public void nullOutputStream_test_9700()
        {
            System.IO.Stream.Null;
        }
    }
}