using System;
using System.Text;

namespace Generated.Test
{
    public class java_net_URLDecoderAutoTest
    {
        public void decode_test_13265(string p0, Encoding p1)
        {
            URLDecoder.Decode(p0, p1);
        }

        public void decode_test_13266(string p0)
        {
            URLDecoder.Decode(p0);
        }
    }

    public static class URLDecoder
    {
        public static string Decode(string s, Encoding encoding)
        {
            if (s == null)
                return null;
            
            // Replace '+' with space as per URL decoding convention
            string decoded = s.Replace('+', ' ');
            
            // Decode percent-encoded sequences
            var bytes = new System.Collections.Generic.List<byte>();
            for (int i = 0; i < decoded.Length; i++)
            {
                if (decoded[i] == '%' && i + 2 < decoded.Length)
                {
                    string hex = decoded.Substring(i + 1, 2);
                    try
                    {
                        bytes.Add(Convert.ToByte(hex, 16));
                        i += 2;
                    }
                    catch (FormatException)
                    {
                        bytes.Add((byte)decoded[i]);
                    }
                }
                else
                {
                    // Convert character to bytes using the specified encoding
                    byte[] charBytes = encoding.GetBytes(decoded[i].ToString());
                    bytes.AddRange(charBytes);
                }
            }
            
            return encoding.GetString(bytes.ToArray());
        }

        public static string Decode(string s)
        {
            return Decode(s, Encoding.UTF8);
        }
    }
}