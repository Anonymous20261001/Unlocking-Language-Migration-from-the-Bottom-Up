using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Generated.Test
{
    public class ModuleDescriptor
    {
        public string Name { get; private set; }
        public bool IsOpen { get; private set; }
        public bool IsAutomatic { get; private set; }
        public ISet<string> Packages { get; private set; }
        public ISet<ModuleDescriptor.Requires> Requires { get; private set; }
        public ISet<ModuleDescriptor.Exports> Exports { get; private set; }
        public ISet<ModuleDescriptor.Opens> Opens { get; private set; }
        public ISet<string> Uses { get; private set; }
        public ISet<ModuleDescriptor.Provides> Provides { get; private set; }
        public string MainClass { get; private set; }
        public Version Version { get; private set; }

        private ModuleDescriptor(string name, bool isOpen, bool isAutomatic, ISet<string> packages)
        {
            Name = name;
            IsOpen = isOpen;
            IsAutomatic = isAutomatic;
            Packages = packages ?? new HashSet<string>();
            Requires = new HashSet<ModuleDescriptor.Requires>();
            Exports = new HashSet<ModuleDescriptor.Exports>();
            Opens = new HashSet<ModuleDescriptor.Opens>();
            Uses = new HashSet<string>();
            Provides = new HashSet<ModuleDescriptor.Provides>();
        }

        public static ModuleDescriptor Read(byte[] buffer, Func<string, string> supplier)
        {
            // Simplified implementation - in real usage this would parse the module descriptor
            // For testing purposes, we'll create a basic descriptor
            string name = "test.module";
            return new ModuleDescriptor(name, false, false, new HashSet<string>());
        }

        public static ModuleDescriptor Read(byte[] buffer)
        {
            return Read(buffer, null);
        }

        public static ModuleDescriptor.Builder NewModule(string name, ISet<string> packages)
        {
            return new ModuleDescriptor.Builder(name, false, false, packages);
        }

        public static ModuleDescriptor.Builder NewModule(string name)
        {
            return NewModule(name, new HashSet<string>());
        }

        public static ModuleDescriptor.Builder NewOpenModule(string name)
        {
            return new ModuleDescriptor.Builder(name, true, false, new HashSet<string>());
        }

        public static ModuleDescriptor.Builder NewAutomaticModule(string name)
        {
            return new ModuleDescriptor.Builder(name, false, true, new HashSet<string>());
        }

        public class Builder
        {
            private ModuleDescriptor _descriptor;

            internal Builder(string name, bool isOpen, bool isAutomatic, ISet<string> packages)
            {
                _descriptor = new ModuleDescriptor(name, isOpen, isAutomatic, packages);
            }

            public Builder Requires(string moduleName)
            {
                _descriptor.Requires.Add(new ModuleDescriptor.Requires(moduleName));
                return this;
            }

            public Builder Exports(string packageName)
            {
                _descriptor.Exports.Add(new ModuleDescriptor.Exports(packageName));
                return this;
            }

            public Builder Opens(string packageName)
            {
                _descriptor.Opens.Add(new ModuleDescriptor.Opens(packageName));
                return this;
            }

            public Builder Uses(string serviceName)
            {
                _descriptor.Uses.Add(serviceName);
                return this;
            }

            public Builder Provides(string serviceName, string implementationName)
            {
                _descriptor.Provides.Add(new ModuleDescriptor.Provides(serviceName, implementationName));
                return this;
            }

            public Builder MainClass(string mainClass)
            {
                _descriptor.MainClass = mainClass;
                return this;
            }

            public Builder Version(Version version)
            {
                _descriptor.Version = version;
                return this;
            }

            public ModuleDescriptor Build()
            {
                return _descriptor;
            }
        }

        public class Requires
        {
            public string Name { get; private set; }
            public Requires(string name)
            {
                Name = name;
            }
        }

        public class Exports
        {
            public string PackageName { get; private set; }
            public Exports(string packageName)
            {
                PackageName = packageName;
            }
        }

        public class Opens
        {
            public string PackageName { get; private set; }
            public Opens(string packageName)
            {
                PackageName = packageName;
            }
        }

        public class Provides
        {
            public string ServiceName { get; private set; }
            public string ImplementationName { get; private set; }
            public Provides(string serviceName, string implementationName)
            {
                ServiceName = serviceName;
                ImplementationName = implementationName;
            }
        }
    }

    public class java_lang_module_ModuleDescriptorAutoTest
    {
        public void read_test_8989(byte[] p0, Func<string, string> p1)
        {
            ModuleDescriptor.Read(p0, p1);
        }

        public void read_test_8990(byte[] p0)
        {
            ModuleDescriptor.Read(p0);
        }

        public void newModule_test_8991(string p0, ISet<string> p1)
        {
            ModuleDescriptor.NewModule(p0, p1);
        }

        public void newModule_test_8992(string p0)
        {
            ModuleDescriptor.NewModule(p0);
        }

        public void newOpenModule_test_8993(string p0)
        {
            ModuleDescriptor.NewOpenModule(p0);
        }

        public void newAutomaticModule_test_8994(string p0)
        {
            ModuleDescriptor.NewAutomaticModule(p0);
        }
    }
}