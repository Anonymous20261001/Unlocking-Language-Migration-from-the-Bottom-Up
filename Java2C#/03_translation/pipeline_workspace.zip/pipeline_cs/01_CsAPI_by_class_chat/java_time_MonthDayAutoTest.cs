namespace Generated.Test
{
    using System;
    using System.Globalization;

    public class MonthDay : IComparable<MonthDay>, IEquatable<MonthDay>
    {
        private readonly int _month;
        private readonly int _day;

        private MonthDay(int month, int day)
        {
            _month = month;
            _day = day;
        }

        public static MonthDay Of(int month, int day)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month), "Month must be between 1 and 12");
            if (day < 1 || day > 31)
                throw new ArgumentOutOfRangeException(nameof(day), "Day must be between 1 and 31");
            return new MonthDay(month, day);
        }

        public static MonthDay Of(Month month, int day)
        {
            return Of((int)month, day);
        }

        public static MonthDay From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return Of(temporal.Month, temporal.Day);
        }

        public static MonthDay Parse(string text, DateTimeFormatter formatter)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            if (formatter == null)
                throw new ArgumentNullException(nameof(formatter));
            return formatter.ParseMonthDay(text);
        }

        public static MonthDay Parse(string text)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            return Parse(text, DateTimeFormatter.ISO_MONTH_DAY);
        }

        public static MonthDay Now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException(nameof(zone));
            var now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, zone.ToTimeZoneInfo());
            return Of(now.Month, now.Day);
        }

        public static MonthDay Now()
        {
            var now = DateTime.Now;
            return Of(now.Month, now.Day);
        }

        public static MonthDay Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            var now = clock.GetCurrentDateTime();
            return Of(now.Month, now.Day);
        }

        public int Month => _month;
        public int Day => _day;

        public int CompareTo(MonthDay other)
        {
            if (other == null)
                return 1;
            int monthCompare = _month.CompareTo(other._month);
            if (monthCompare != 0)
                return monthCompare;
            return _day.CompareTo(other._day);
        }

        public bool Equals(MonthDay other)
        {
            if (other == null)
                return false;
            return _month == other._month && _day == other._day;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as MonthDay);
        }

        public override int GetHashCode()
        {
            return (_month * 31) + _day;
        }

        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "--{0:D2}-{1:D2}", _month, _day);
        }
    }

    public enum Month
    {
        January = 1,
        February = 2,
        March = 3,
        April = 4,
        May = 5,
        June = 6,
        July = 7,
        August = 8,
        September = 9,
        October = 10,
        November = 11,
        December = 12
    }

    public abstract class TemporalAccessor
    {
        public abstract int Month { get; }
        public abstract int Day { get; }
    }

    public class DateTimeFormatter
    {
        public static readonly DateTimeFormatter ISO_MONTH_DAY = new DateTimeFormatter("--MM-dd");

        private readonly string _pattern;

        private DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public MonthDay ParseMonthDay(string text)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            try
            {
                var dateTime = DateTime.ParseExact(text, _pattern, CultureInfo.InvariantCulture);
                return MonthDay.Of(dateTime.Month, dateTime.Day);
            }
            catch (FormatException)
            {
                throw new FormatException($"Text '{text}' could not be parsed as MonthDay with pattern '{_pattern}'");
            }
        }
    }

    public class ZoneId
    {
        private readonly string _id;

        private ZoneId(string id)
        {
            _id = id;
        }

        public static ZoneId Of(string id)
        {
            if (string.IsNullOrEmpty(id))
                throw new ArgumentNullException(nameof(id));
            return new ZoneId(id);
        }

        public TimeZoneInfo ToTimeZoneInfo()
        {
            return TimeZoneInfo.FindSystemTimeZoneById(_id);
        }
    }

    public class Clock
    {
        private readonly Func<DateTime> _currentTimeProvider;

        private Clock(Func<DateTime> currentTimeProvider)
        {
            _currentTimeProvider = currentTimeProvider;
        }

        public static Clock SystemDefaultZone()
        {
            return new Clock(() => DateTime.Now);
        }

        public static Clock SystemUTC()
        {
            return new Clock(() => DateTime.UtcNow);
        }

        public DateTime GetCurrentDateTime()
        {
            return _currentTimeProvider();
        }
    }

    public class java_time_MonthDayAutoTest
    {
        public void of_test_9004(int p0, int p1)
        {
            MonthDay.Of(p0, p1);
        }

        public void of_test_9005(Month p0, int p1)
        {
            MonthDay.Of(p0, p1);
        }

        public void from_test_9006(TemporalAccessor p0)
        {
            MonthDay.From(p0);
        }

        public void parse_test_9007(string p0, DateTimeFormatter p1)
        {
            MonthDay.Parse(p0, p1);
        }

        public void parse_test_9008(string p0)
        {
            MonthDay.Parse(p0);
        }

        public void now_test_9009(ZoneId p0)
        {
            MonthDay.Now(p0);
        }

        public void now_test_9010()
        {
            MonthDay.Now();
        }

        public void now_test_9011(Clock p0)
        {
            MonthDay.Now(p0);
        }
    }
}