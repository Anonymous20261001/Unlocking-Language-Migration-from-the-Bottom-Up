using System;
using System.Text;

namespace Generated.Test
{
    public class HexFormat
    {
        private string delimiter;
        private bool upperCase;

        private HexFormat(string delimiter, bool upperCase)
        {
            this.delimiter = delimiter;
            this.upperCase = upperCase;
        }

        public static HexFormat Of()
        {
            return new HexFormat("", false);
        }

        public static HexFormat OfDelimiter(string delimiter)
        {
            if (delimiter == null)
                throw new ArgumentNullException(nameof(delimiter));
            return new HexFormat(delimiter, false);
        }

        public static int FromHexDigit(int digit)
        {
            if (digit >= '0' && digit <= '9')
                return digit - '0';
            if (digit >= 'A' && digit <= 'F')
                return digit - 'A' + 10;
            if (digit >= 'a' && digit <= 'f')
                return digit - 'a' + 10;
            throw new ArgumentException("Invalid hex digit: " + (char)digit);
        }

        public static int FromHexDigits(string sequence)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            return FromHexDigits(sequence, 0, sequence.Length);
        }

        public static int FromHexDigits(string sequence, int start, int end)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            if (start < 0 || end > sequence.Length || start > end)
                throw new ArgumentOutOfRangeException();
            int result = 0;
            for (int i = start; i < end; i++)
            {
                result = (result << 4) | FromHexDigit(sequence[i]);
            }
            return result;
        }

        public static long FromHexDigitsToLong(string sequence)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            return FromHexDigitsToLong(sequence, 0, sequence.Length);
        }

        public static long FromHexDigitsToLong(string sequence, int start, int end)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            if (start < 0 || end > sequence.Length || start > end)
                throw new ArgumentOutOfRangeException();
            long result = 0;
            for (int i = start; i < end; i++)
            {
                result = (result << 4) | (long)FromHexDigit(sequence[i]);
            }
            return result;
        }

        public static bool IsHexDigit(int digit)
        {
            return (digit >= '0' && digit <= '9') ||
                   (digit >= 'A' && digit <= 'F') ||
                   (digit >= 'a' && digit <= 'f');
        }
    }

    public class java_util_HexFormatAutoTest
    {
        public void of_test_5337()
        {
            HexFormat.Of();
        }

        public void fromHexDigits_test_5338(string p0)
        {
            HexFormat.FromHexDigits(p0);
        }

        public void fromHexDigits_test_5339(string p0, int p1, int p2)
        {
            HexFormat.FromHexDigits(p0, p1, p2);
        }

        public void fromHexDigit_test_5340(int p0)
        {
            HexFormat.FromHexDigit(p0);
        }

        public void fromHexDigitsToLong_test_5341(string p0, int p1, int p2)
        {
            HexFormat.FromHexDigitsToLong(p0, p1, p2);
        }

        public void fromHexDigitsToLong_test_5342(string p0)
        {
            HexFormat.FromHexDigitsToLong(p0);
        }

        public void ofDelimiter_test_5343(string p0)
        {
            HexFormat.OfDelimiter(p0);
        }

        public void isHexDigit_test_5344(int p0)
        {
            HexFormat.IsHexDigit(p0);
        }
    }
}