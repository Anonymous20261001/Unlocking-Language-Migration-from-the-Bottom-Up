namespace Generated.Test
{
    public class javax_swing_JComponentAutoTest
    {
        public void getDefaultLocale_test_6106()
        {
            JComponent.GetDefaultLocale();
        }

        public void isLightweightComponent_test_6107(Component p0)
        {
            JComponent.IsLightweightComponent(p0);
        }

        public void setDefaultLocale_test_6108(Locale p0)
        {
            JComponent.SetDefaultLocale(p0);
        }
    }

    public class JComponent
    {
        private static Locale defaultLocale;

        public static Locale GetDefaultLocale()
        {
            return defaultLocale;
        }

        public static bool IsLightweightComponent(Component c)
        {
            return c != null && c.IsLightweight;
        }

        public static void SetDefaultLocale(Locale locale)
        {
            defaultLocale = locale;
        }
    }

    public class Component
    {
        public virtual bool IsLightweight { get { return false; } }
    }

    public class Locale
    {
        // Simplified Locale class for testing purposes
        public string Language { get; set; }
        public string Country { get; set; }

        public Locale(string language, string country)
        {
            Language = language;
            Country = country;
        }
    }
}