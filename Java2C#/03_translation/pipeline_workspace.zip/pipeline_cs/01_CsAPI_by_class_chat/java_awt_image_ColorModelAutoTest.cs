namespace Generated.Test
{
    public class java_awt_image_ColorModelAutoTest
    {
        public void getRGBdefault_test_2502()
        {
            ColorModel.GetRGBdefault();
        }
    }

    public class ColorModel
    {
        public static ColorModel GetRGBdefault()
        {
            return new ColorModel();
        }
    }
}