using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    // Simplified Spliterator interface for C#
    public interface Spliterator<T>
    {
        bool TryAdvance(out T item);
        Spliterator<T> TrySplit();
        long EstimateSize();
        int Characteristics();
    }

    // Specialized Spliterator interfaces
    public interface OfInt : Spliterator<int> { }
    public interface OfLong : Spliterator<long> { }
    public interface OfDouble : Spliterator<double> { }

    // Simplified Stream class
    public class Stream<T>
    {
        private IEnumerable<T> _source;
        public Stream(IEnumerable<T> source) { _source = source; }
        public IEnumerable<T> GetEnumerator() { return _source; }
    }

    // IntStream, LongStream, DoubleStream classes
    public class IntStream : Stream<int>
    {
        public IntStream(IEnumerable<int> source) : base(source) { }
    }

    public class LongStream : Stream<long>
    {
        public LongStream(IEnumerable<long> source) : base(source) { }
    }

    public class DoubleStream : Stream<double>
    {
        public DoubleStream(IEnumerable<double> source) : base(source) { }
    }

    // StreamSupport equivalent class
    public static class StreamSupport
    {
        // Helper to convert Spliterator to IEnumerable
        private static IEnumerable<T> SpliteratorToEnumerable<T>(Spliterator<T> spliterator)
        {
            T item;
            while (spliterator.TryAdvance(out item))
            {
                yield return item;
            }
        }

        // stream(Supplier, int, boolean)
        public static Stream<object> stream(Supplier p0, int p1, bool p2)
        {
            var spliterator = p0.Get() as Spliterator<object>;
            if (spliterator == null)
                throw new InvalidCastException("Supplier must return a Spliterator<object>");
            return new Stream<object>(SpliteratorToEnumerable(spliterator));
        }

        // stream(Spliterator, boolean)
        public static Stream<object> stream(Spliterator<object> p0, bool p1)
        {
            return new Stream<object>(SpliteratorToEnumerable(p0));
        }

        // intStream(Supplier, int, boolean)
        public static IntStream intStream(Supplier p0, int p1, bool p2)
        {
            var spliterator = p0.Get() as OfInt;
            if (spliterator == null)
                throw new InvalidCastException("Supplier must return a Spliterator.OfInt");
            return new IntStream(SpliteratorToEnumerable(spliterator));
        }

        // intStream(Spliterator.OfInt, boolean)
        public static IntStream intStream(OfInt p0, bool p1)
        {
            return new IntStream(SpliteratorToEnumerable(p0));
        }

        // longStream(Supplier, int, boolean)
        public static LongStream longStream(Supplier p0, int p1, bool p2)
        {
            var spliterator = p0.Get() as OfLong;
            if (spliterator == null)
                throw new InvalidCastException("Supplier must return a Spliterator.OfLong");
            return new LongStream(SpliteratorToEnumerable(spliterator));
        }

        // longStream(Spliterator.OfLong, boolean)
        public static LongStream longStream(OfLong p0, bool p1)
        {
            return new LongStream(SpliteratorToEnumerable(p0));
        }

        // doubleStream(Spliterator.OfDouble, boolean)
        public static DoubleStream doubleStream(OfDouble p0, bool p1)
        {
            return new DoubleStream(SpliteratorToEnumerable(p0));
        }

        // doubleStream(Supplier, int, boolean)
        public static DoubleStream doubleStream(Supplier p0, int p1, bool p2)
        {
            var spliterator = p0.Get() as OfDouble;
            if (spliterator == null)
                throw new InvalidCastException("Supplier must return a Spliterator.OfDouble");
            return new DoubleStream(SpliteratorToEnumerable(spliterator));
        }
    }

    // Supplier interface
    public interface Supplier
    {
        object Get();
    }

    // Test class
    public class java_util_stream_StreamSupportAutoTest
    {
        public void stream_test_11571(Supplier p0, int p1, bool p2)
        {
            StreamSupport.stream(p0, p1, p2);
        }

        public void stream_test_11572(Spliterator<object> p0, bool p1)
        {
            StreamSupport.stream(p0, p1);
        }

        public void intStream_test_11573(Supplier p0, int p1, bool p2)
        {
            StreamSupport.intStream(p0, p1, p2);
        }

        public void intStream_test_11574(OfInt p0, bool p1)
        {
            StreamSupport.intStream(p0, p1);
        }

        public void longStream_test_11575(Supplier p0, int p1, bool p2)
        {
            StreamSupport.longStream(p0, p1, p2);
        }

        public void longStream_test_11576(OfLong p0, bool p1)
        {
            StreamSupport.longStream(p0, p1);
        }

        public void doubleStream_test_11577(OfDouble p0, bool p1)
        {
            StreamSupport.doubleStream(p0, p1);
        }

        public void doubleStream_test_11578(Supplier p0, int p1, bool p2)
        {
            StreamSupport.doubleStream(p0, p1, p2);
        }
    }
}