namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class java_util_stream_CollectorsAutoTest
    {
        public void joining_test_2424(CharSequence p0, CharSequence p1, CharSequence p2)
        {
            Collectors.joining(p0, p1, p2);
        }

        public void joining_test_2425()
        {
            Collectors.joining();
        }

        public void joining_test_2426(CharSequence p0)
        {
            Collectors.joining(p0);
        }

        public void toList_test_2427()
        {
            Collectors.toList();
        }

        public void toMap_test_2428(Function p0, Function p1, BinaryOperator p2)
        {
            Collectors.toMap(p0, p1, p2);
        }

        public void toMap_test_2429(Function p0, Function p1)
        {
            Collectors.toMap(p0, p1);
        }

        public void toMap_test_2430(Function p0, Function p1, BinaryOperator p2, Supplier p3)
        {
            Collectors.toMap(p0, p1, p2, p3);
        }

        public void toSet_test_2431()
        {
            Collectors.toSet();
        }

        public void maxBy_test_2432(Comparator p0)
        {
            Collectors.maxBy(p0);
        }

        public void minBy_test_2433(Comparator p0)
        {
            Collectors.minBy(p0);
        }

        public void mapping_test_2434(Function p0, Collector p1)
        {
            Collectors.mapping(p0, p1);
        }

        public void groupingBy_test_2435(Function p0)
        {
            Collectors.groupingBy(p0);
        }

        public void groupingBy_test_2436(Function p0, Supplier p1, Collector p2)
        {
            Collectors.groupingBy(p0, p1, p2);
        }

        public void groupingBy_test_2437(Function p0, Collector p1)
        {
            Collectors.groupingBy(p0, p1);
        }

        public void toCollection_test_2438(Supplier p0)
        {
            Collectors.toCollection(p0);
        }

        public void summingLong_test_2439(ToLongFunction p0)
        {
            Collectors.summingLong(p0);
        }

        public void reducing_test_2440(BinaryOperator p0)
        {
            Collectors.reducing(p0);
        }

        public void reducing_test_2441(object p0, Function p1, BinaryOperator p2)
        {
            Collectors.reducing(p0, p1, p2);
        }

        public void reducing_test_2442(object p0, BinaryOperator p1)
        {
            Collectors.reducing(p0, p1);
        }

        public void groupingByConcurrent_test_2443(Function p0, Collector p1)
        {
            Collectors.groupingByConcurrent(p0, p1);
        }

        public void groupingByConcurrent_test_2444(Function p0, Supplier p1, Collector p2)
        {
            Collectors.groupingByConcurrent(p0, p1, p2);
        }

        public void groupingByConcurrent_test_2445(Function p0)
        {
            Collectors.groupingByConcurrent(p0);
        }

        public void partitioningBy_test_2446(Predicate p0)
        {
            Collectors.partitioningBy(p0);
        }

        public void partitioningBy_test_2447(Predicate p0, Collector p1)
        {
            Collectors.partitioningBy(p0, p1);
        }

        public void collectingAndThen_test_2448(Collector p0, Function p1)
        {
            Collectors.collectingAndThen(p0, p1);
        }

        public void toConcurrentMap_test_2449(Function p0, Function p1)
        {
            Collectors.toConcurrentMap(p0, p1);
        }

        public void toConcurrentMap_test_2450(Function p0, Function p1, BinaryOperator p2, Supplier p3)
        {
            Collectors.toConcurrentMap(p0, p1, p2, p3);
        }

        public void toConcurrentMap_test_2451(Function p0, Function p1, BinaryOperator p2)
        {
            Collectors.toConcurrentMap(p0, p1, p2);
        }

        public void toUnmodifiableList_test_2452()
        {
            Collectors.toUnmodifiableList();
        }

        public void toUnmodifiableSet_test_2453()
        {
            Collectors.toUnmodifiableSet();
        }

        public void flatMapping_test_2454(Function p0, Collector p1)
        {
            Collectors.flatMapping(p0, p1);
        }

        public void filtering_test_2455(Predicate p0, Collector p1)
        {
            Collectors.filtering(p0, p1);
        }

        public void counting_test_2456()
        {
            Collectors.counting();
        }

        public void summingInt_test_2457(ToIntFunction p0)
        {
            Collectors.summingInt(p0);
        }

        public void summingDouble_test_2458(ToDoubleFunction p0)
        {
            Collectors.summingDouble(p0);
        }

        public void averagingInt_test_2459(ToIntFunction p0)
        {
            Collectors.averagingInt(p0);
        }

        public void averagingLong_test_2460(ToLongFunction p0)
        {
            Collectors.averagingLong(p0);
        }

        public void averagingDouble_test_2461(ToDoubleFunction p0)
        {
            Collectors.averagingDouble(p0);
        }

        public void toUnmodifiableMap_test_2462(Function p0, Function p1)
        {
            Collectors.toUnmodifiableMap(p0, p1);
        }

        public void toUnmodifiableMap_test_2463(Function p0, Function p1, BinaryOperator p2)
        {
            Collectors.toUnmodifiableMap(p0, p1, p2);
        }

        public void summarizingInt_test_2464(ToIntFunction p0)
        {
            Collectors.summarizingInt(p0);
        }

        public void summarizingLong_test_2465(ToLongFunction p0)
        {
            Collectors.summarizingLong(p0);
        }

        public void summarizingDouble_test_2466(ToDoubleFunction p0)
        {
            Collectors.summarizingDouble(p0);
        }

        public void teeing_test_2467(Collector p0, Collector p1, BiFunction p2)
        {
            Collectors.teeing(p0, p1, p2);
        }
    }

    // Supporting classes/interfaces
    public class CharSequence
    {
        public string Value { get; set; }
        public CharSequence(string value) { Value = value; }
        public override string ToString() => Value;
    }

    public class Function
    {
        public Func<object, object> Func { get; set; }
        public Function(Func<object, object> func) { Func = func; }
        public object Apply(object input) => Func(input);
    }

    public class BinaryOperator
    {
        public Func<object, object, object> Func { get; set; }
        public BinaryOperator(Func<object, object, object> func) { Func = func; }
        public object Apply(object a, object b) => Func(a, b);
    }

    public class Supplier
    {
        public Func<object> Func { get; set; }
        public Supplier(Func<object> func) { Func = func; }
        public object Get() => Func();
    }

    public class Predicate
    {
        public Func<object, bool> Func { get; set; }
        public Predicate(Func<object, bool> func) { Func = func; }
        public bool Test(object input) => Func(input);
    }

    public class Comparator
    {
        public Func<object, object, int> Func { get; set; }
        public Comparator(Func<object, object, int> func) { Func = func; }
        public int Compare(object a, object b) => Func(a, b);
    }

    public class ToIntFunction
    {
        public Func<object, int> Func { get; set; }
        public ToIntFunction(Func<object, int> func) { Func = func; }
        public int ApplyAsInt(object input) => Func(input);
    }

    public class ToLongFunction
    {
        public Func<object, long> Func { get; set; }
        public ToLongFunction(Func<object, long> func) { Func = func; }
        public long ApplyAsLong(object input) => Func(input);
    }

    public class ToDoubleFunction
    {
        public Func<object, double> Func { get; set; }
        public ToDoubleFunction(Func<object, double> func) { Func = func; }
        public double ApplyAsDouble(object input) => Func(input);
    }

    public class BiFunction
    {
        public Func<object, object, object> Func { get; set; }
        public BiFunction(Func<object, object, object> func) { Func = func; }
        public object Apply(object a, object b) => Func(a, b);
    }

    public class Collector
    {
        // Simplified collector representation
        public object Supplier { get; set; }
        public object Accumulator { get; set; }
        public object Combiner { get; set; }
        public object Finisher { get; set; }
    }

    public static class Collectors
    {
        public static Collector joining(CharSequence delimiter, CharSequence prefix, CharSequence suffix)
        {
            return new Collector();
        }

        public static Collector joining()
        {
            return new Collector();
        }

        public static Collector joining(CharSequence delimiter)
        {
            return new Collector();
        }

        public static Collector toList()
        {
            return new Collector();
        }

        public static Collector toMap(Function keyMapper, Function valueMapper, BinaryOperator mergeFunction)
        {
            return new Collector();
        }

        public static Collector toMap(Function keyMapper, Function valueMapper)
        {
            return new Collector();
        }

        public static Collector toMap(Function keyMapper, Function valueMapper, BinaryOperator mergeFunction, Supplier mapSupplier)
        {
            return new Collector();
        }

        public static Collector toSet()
        {
            return new Collector();
        }

        public static Collector maxBy(Comparator comparator)
        {
            return new Collector();
        }

        public static Collector minBy(Comparator comparator)
        {
            return new Collector();
        }

        public static Collector mapping(Function mapper, Collector downstream)
        {
            return new Collector();
        }

        public static Collector groupingBy(Function classifier)
        {
            return new Collector();
        }

        public static Collector groupingBy(Function classifier, Supplier mapFactory, Collector downstream)
        {
            return new Collector();
        }

        public static Collector groupingBy(Function classifier, Collector downstream)
        {
            return new Collector();
        }

        public static Collector toCollection(Supplier collectionFactory)
        {
            return new Collector();
        }

        public static Collector summingLong(ToLongFunction mapper)
        {
            return new Collector();
        }

        public static Collector reducing(BinaryOperator op)
        {
            return new Collector();
        }

        public static Collector reducing(object identity, Function mapper, BinaryOperator op)
        {
            return new Collector();
        }

        public static Collector reducing(object identity, BinaryOperator op)
        {
            return new Collector();
        }

        public static Collector groupingByConcurrent(Function classifier, Collector downstream)
        {
            return new Collector();
        }

        public static Collector groupingByConcurrent(Function classifier, Supplier mapFactory, Collector downstream)
        {
            return new Collector();
        }

        public static Collector groupingByConcurrent(Function classifier)
        {
            return new Collector();
        }

        public static Collector partitioningBy(Predicate predicate)
        {
            return new Collector();
        }

        public static Collector partitioningBy(Predicate predicate, Collector downstream)
        {
            return new Collector();
        }

        public static Collector collectingAndThen(Collector downstream, Function finisher)
        {
            return new Collector();
        }

        public static Collector toConcurrentMap(Function keyMapper, Function valueMapper)
        {
            return new Collector();
        }

        public static Collector toConcurrentMap(Function keyMapper, Function valueMapper, BinaryOperator mergeFunction, Supplier mapSupplier)
        {
            return new Collector();
        }

        public static Collector toConcurrentMap(Function keyMapper, Function valueMapper, BinaryOperator mergeFunction)
        {
            return new Collector();
        }

        public static Collector toUnmodifiableList()
        {
            return new Collector();
        }

        public static Collector toUnmodifiableSet()
        {
            return new Collector();
        }

        public static Collector flatMapping(Function mapper, Collector downstream)
        {
            return new Collector();
        }

        public static Collector filtering(Predicate predicate, Collector downstream)
        {
            return new Collector();
        }

        public static Collector counting()
        {
            return new Collector();
        }

        public static Collector summingInt(ToIntFunction mapper)
        {
            return new Collector();
        }

        public static Collector summingDouble(ToDoubleFunction mapper)
        {
            return new Collector();
        }

        public static Collector averagingInt(ToIntFunction mapper)
        {
            return new Collector();
        }

        public static Collector averagingLong(ToLongFunction mapper)
        {
            return new Collector();
        }

        public static Collector averagingDouble(ToDoubleFunction mapper)
        {
            return new Collector();
        }

        public static Collector toUnmodifiableMap(Function keyMapper, Function valueMapper)
        {
            return new Collector();
        }

        public static Collector toUnmodifiableMap(Function keyMapper, Function valueMapper, BinaryOperator mergeFunction)
        {
            return new Collector();
        }

        public static Collector summarizingInt(ToIntFunction mapper)
        {
            return new Collector();
        }

        public static Collector summarizingLong(ToLongFunction mapper)
        {
            return new Collector();
        }

        public static Collector summarizingDouble(ToDoubleFunction mapper)
        {
            return new Collector();
        }

        public static Collector teeing(Collector downstream1, Collector downstream2, BiFunction merger)
        {
            return new Collector();
        }
    }
}