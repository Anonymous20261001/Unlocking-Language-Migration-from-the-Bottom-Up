namespace Generated.Test
{
    public class java_io_WriterAutoTest
    {
        public void nullWriter_test_13550()
        {
            System.IO.TextWriter.Null;
        }
    }
}