namespace Generated.Test
{
    public class java_nio_IntBufferAutoTest
    {
        public void wrap_test_5864(int[] p0)
        {
            IntBuffer.Wrap(p0);
        }

        public void wrap_test_5865(int[] p0, int p1, int p2)
        {
            IntBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_5866(int p0)
        {
            IntBuffer.Allocate(p0);
        }
    }

    public class IntBuffer
    {
        private int[] _buffer;
        private int _position;
        private int _limit;
        private int _capacity;

        private IntBuffer(int capacity)
        {
            _buffer = new int[capacity];
            _capacity = capacity;
            _limit = capacity;
            _position = 0;
        }

        private IntBuffer(int[] array, int offset, int length)
        {
            _buffer = array;
            _capacity = array.Length;
            _limit = offset + length;
            _position = offset;
        }

        public static IntBuffer Wrap(int[] array)
        {
            return new IntBuffer(array, 0, array.Length);
        }

        public static IntBuffer Wrap(int[] array, int offset, int length)
        {
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new System.IndexOutOfRangeException();
            return new IntBuffer(array, offset, length);
        }

        public static IntBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new System.ArgumentException("Negative capacity");
            return new IntBuffer(capacity);
        }
    }
}