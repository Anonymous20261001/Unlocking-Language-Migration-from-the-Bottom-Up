namespace Generated.Test
{
    public class java_awt_print_PrinterJobAutoTest
    {
        public void getPrinterJob_test_10008()
        {
            PrinterJob.GetPrinterJob();
        }

        public void lookupPrintServices_test_10009()
        {
            PrinterJob.LookupPrintServices();
        }

        public void lookupStreamPrintServices_test_10010(string p0)
        {
            PrinterJob.LookupStreamPrintServices(p0);
        }
    }

    public class PrinterJob
    {
        public static PrinterJob GetPrinterJob()
        {
            return new PrinterJob();
        }

        public static object[] LookupPrintServices()
        {
            return new object[0];
        }

        public static object[] LookupStreamPrintServices(string mimeType)
        {
            return new object[0];
        }
    }
}