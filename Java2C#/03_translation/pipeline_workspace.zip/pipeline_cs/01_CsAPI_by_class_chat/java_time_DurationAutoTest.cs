using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Minimal TemporalUnit interface equivalent
    public interface TemporalUnit
    {
    }

    // Minimal TemporalAmount interface equivalent
    public interface TemporalAmount
    {
    }

    // Minimal Temporal interface equivalent
    public interface Temporal
    {
    }

    // Duration class equivalent to java.time.Duration
    public class Duration
    {
        private readonly long _seconds;
        private readonly int _nanos;

        private Duration(long seconds, int nanos)
        {
            _seconds = seconds;
            _nanos = nanos;
        }

        public static Duration Of(long amount, TemporalUnit unit)
        {
            // Simplified: treat as seconds
            return new Duration(amount, 0);
        }

        public static Duration From(TemporalAmount amount)
        {
            // Simplified: return zero duration
            return new Duration(0, 0);
        }

        public static Duration Parse(string text)
        {
            // Simplified: parse "PTnS" format
            if (text.StartsWith("PT") && text.EndsWith("S"))
            {
                string numStr = text.Substring(2, text.Length - 3);
                if (long.TryParse(numStr, out long seconds))
                {
                    return new Duration(seconds, 0);
                }
            }
            return new Duration(0, 0);
        }

        public static Duration Between(Temporal startInclusive, Temporal endExclusive)
        {
            // Simplified: return zero duration
            return new Duration(0, 0);
        }

        public static Duration OfSeconds(long seconds, long nanoAdjustment)
        {
            return new Duration(seconds, (int)nanoAdjustment);
        }

        public static Duration OfSeconds(long seconds)
        {
            return new Duration(seconds, 0);
        }

        public static Duration OfNanos(long nanos)
        {
            long seconds = nanos / 1000000000L;
            int nanoPart = (int)(nanos % 1000000000L);
            return new Duration(seconds, nanoPart);
        }

        public static Duration OfDays(long days)
        {
            return new Duration(days * 86400L, 0);
        }

        public static Duration OfHours(long hours)
        {
            return new Duration(hours * 3600L, 0);
        }

        public static Duration OfMinutes(long minutes)
        {
            return new Duration(minutes * 60L, 0);
        }

        public static Duration OfMillis(long millis)
        {
            long seconds = millis / 1000L;
            int nanoPart = (int)((millis % 1000L) * 1000000L);
            return new Duration(seconds, nanoPart);
        }
    }

    public class java_time_DurationAutoTest
    {
        public void of_test_4406(long p0, TemporalUnit p1)
        {
            Duration.Of(p0, p1);
        }

        public void from_test_4407(TemporalAmount p0)
        {
            Duration.From(p0);
        }

        public void parse_test_4408(string p0)
        {
            Duration.Parse(p0);
        }

        public void between_test_4409(Temporal p0, Temporal p1)
        {
            Duration.Between(p0, p1);
        }

        public void ofSeconds_test_4410(long p0, long p1)
        {
            Duration.OfSeconds(p0, p1);
        }

        public void ofSeconds_test_4411(long p0)
        {
            Duration.OfSeconds(p0);
        }

        public void ofNanos_test_4412(long p0)
        {
            Duration.OfNanos(p0);
        }

        public void ofDays_test_4413(long p0)
        {
            Duration.OfDays(p0);
        }

        public void ofHours_test_4414(long p0)
        {
            Duration.OfHours(p0);
        }

        public void ofMinutes_test_4415(long p0)
        {
            Duration.OfMinutes(p0);
        }

        public void ofMillis_test_4416(long p0)
        {
            Duration.OfMillis(p0);
        }
    }
}