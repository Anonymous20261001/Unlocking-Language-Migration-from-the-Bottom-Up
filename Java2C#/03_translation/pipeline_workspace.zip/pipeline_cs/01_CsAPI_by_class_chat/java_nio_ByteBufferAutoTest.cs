using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_nio_ByteBufferAutoTest
    {
        public void wrap_test_2000(byte[] p0, int p1, int p2)
        {
            ByteBuffer.Wrap(p0, p1, p2);
        }

        public void wrap_test_2001(byte[] p0)
        {
            ByteBuffer.Wrap(p0);
        }

        public void allocate_test_2002(int p0)
        {
            ByteBuffer.Allocate(p0);
        }

        public void allocateDirect_test_2003(int p0)
        {
            ByteBuffer.AllocateDirect(p0);
        }
    }

    public class ByteBuffer
    {
        private byte[] _buffer;
        private int _position;
        private int _limit;
        private int _capacity;
        private bool _isDirect;

        private ByteBuffer(byte[] buffer, int offset, int length, bool isDirect)
        {
            if (buffer == null)
                throw new ArgumentNullException(nameof(buffer));
            if (offset < 0 || length < 0 || offset + length > buffer.Length)
                throw new IndexOutOfRangeException("Invalid offset or length");

            _buffer = buffer;
            _position = offset;
            _limit = offset + length;
            _capacity = buffer.Length;
            _isDirect = isDirect;
        }

        public static ByteBuffer Wrap(byte[] array)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));
            return new ByteBuffer(array, 0, array.Length, false);
        }

        public static ByteBuffer Wrap(byte[] array, int offset, int length)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new IndexOutOfRangeException("Invalid offset or length");
            return new ByteBuffer(array, offset, length, false);
        }

        public static ByteBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");
            return new ByteBuffer(new byte[capacity], 0, capacity, false);
        }

        public static ByteBuffer AllocateDirect(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");
            return new ByteBuffer(new byte[capacity], 0, capacity, true);
        }

        public int Position
        {
            get { return _position; }
            set
            {
                if (value < 0 || value > _limit)
                    throw new ArgumentOutOfRangeException(nameof(value));
                _position = value;
            }
        }

        public int Limit
        {
            get { return _limit; }
            set
            {
                if (value < 0 || value > _capacity)
                    throw new ArgumentOutOfRangeException(nameof(value));
                _limit = value;
                if (_position > _limit)
                    _position = _limit;
            }
        }

        public int Capacity
        {
            get { return _capacity; }
        }

        public bool IsDirect
        {
            get { return _isDirect; }
        }

        public byte Get()
        {
            if (_position >= _limit)
                throw new InvalidOperationException("Buffer underflow");
            return _buffer[_position++];
        }

        public byte Get(int index)
        {
            if (index < 0 || index >= _limit)
                throw new IndexOutOfRangeException("Index out of bounds");
            return _buffer[index];
        }

        public ByteBuffer Put(byte value)
        {
            if (_position >= _limit)
                throw new InvalidOperationException("Buffer overflow");
            _buffer[_position++] = value;
            return this;
        }

        public ByteBuffer Put(int index, byte value)
        {
            if (index < 0 || index >= _limit)
                throw new IndexOutOfRangeException("Index out of bounds");
            _buffer[index] = value;
            return this;
        }

        public ByteBuffer Flip()
        {
            _limit = _position;
            _position = 0;
            return this;
        }

        public ByteBuffer Clear()
        {
            _position = 0;
            _limit = _capacity;
            return this;
        }

        public ByteBuffer Rewind()
        {
            _position = 0;
            return this;
        }

        public int Remaining
        {
            get { return _limit - _position; }
        }

        public bool HasRemaining
        {
            get { return _position < _limit; }
        }

        public byte[] ToArray()
        {
            byte[] result = new byte[_limit - 0];
            Array.Copy(_buffer, 0, result, 0, _limit);
            return result;
        }
    }
}