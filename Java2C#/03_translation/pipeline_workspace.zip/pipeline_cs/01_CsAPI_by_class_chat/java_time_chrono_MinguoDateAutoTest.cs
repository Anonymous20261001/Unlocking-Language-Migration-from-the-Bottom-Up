using System;
using System.Globalization;
using Generated.Test;

namespace Generated.Test
{
    public class MinguoDate
    {
        private readonly DateTime _dateTime;

        public MinguoDate(DateTime dateTime)
        {
            _dateTime = dateTime;
        }

        public static MinguoDate Of(int year, int month, int day)
        {
            // Minguo year = Gregorian year - 1911
            int gregorianYear = year + 1911;
            return new MinguoDate(new DateTime(gregorianYear, month, day));
        }

        public static MinguoDate From(TemporalAccessor temporalAccessor)
        {
            if (temporalAccessor == null)
                throw new ArgumentNullException(nameof(temporalAccessor));
            
            // Extract date from TemporalAccessor
            var dateTime = temporalAccessor.GetDateTime();
            return new MinguoDate(dateTime);
        }

        public static MinguoDate Now()
        {
            return new MinguoDate(DateTime.Now);
        }

        public static MinguoDate Now(ZoneId zoneId)
        {
            if (zoneId == null)
                throw new ArgumentNullException(nameof(zoneId));
            
            var dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, zoneId.ToTimeZoneInfo());
            return new MinguoDate(dateTime);
        }

        public static MinguoDate Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            
            return new MinguoDate(clock.GetCurrentDateTime());
        }

        public DateTime ToDateTime()
        {
            return _dateTime;
        }

        public int GetYear()
        {
            return _dateTime.Year - 1911;
        }

        public int GetMonth()
        {
            return _dateTime.Month;
        }

        public int GetDay()
        {
            return _dateTime.Day;
        }

        public override string ToString()
        {
            return $"{GetYear()}-{GetMonth():D2}-{GetDay():D2}";
        }
    }

    public class TemporalAccessor
    {
        private readonly DateTime _dateTime;

        public TemporalAccessor(DateTime dateTime)
        {
            _dateTime = dateTime;
        }

        public DateTime GetDateTime()
        {
            return _dateTime;
        }
    }

    public class ZoneId
    {
        private readonly string _zoneId;

        public ZoneId(string zoneId)
        {
            _zoneId = zoneId;
        }

        public TimeZoneInfo ToTimeZoneInfo()
        {
            return TimeZoneInfo.FindSystemTimeZoneById(_zoneId);
        }
    }

    public class Clock
    {
        private readonly DateTime _currentDateTime;

        public Clock(DateTime currentDateTime)
        {
            _currentDateTime = currentDateTime;
        }

        public DateTime GetCurrentDateTime()
        {
            return _currentDateTime;
        }
    }

    public class java_time_chrono_MinguoDateAutoTest
    {
        public void of_test_8947(int p0, int p1, int p2)
        {
            MinguoDate.Of(p0, p1, p2);
        }

        public void from_test_8948(TemporalAccessor p0)
        {
            MinguoDate.From(p0);
        }

        public void now_test_8949()
        {
            MinguoDate.Now();
        }

        public void now_test_8950(ZoneId p0)
        {
            MinguoDate.Now(p0);
        }

        public void now_test_8951(Clock p0)
        {
            MinguoDate.Now(p0);
        }
    }
}