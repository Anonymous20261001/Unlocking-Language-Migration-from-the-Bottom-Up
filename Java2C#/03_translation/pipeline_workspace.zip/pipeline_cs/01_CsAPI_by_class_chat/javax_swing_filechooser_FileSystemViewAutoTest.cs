namespace Generated.Test
{
    public class javax_swing_filechooser_FileSystemViewAutoTest
    {
        public void getFileSystemView_test_4781()
        {
            FileSystemView.GetFileSystemView();
        }
    }

    public class FileSystemView
    {
        public static FileSystemView GetFileSystemView()
        {
            return new FileSystemView();
        }
    }
}