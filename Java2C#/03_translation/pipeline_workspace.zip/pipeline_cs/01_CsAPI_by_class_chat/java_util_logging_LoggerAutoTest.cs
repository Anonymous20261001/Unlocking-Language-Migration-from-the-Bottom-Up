using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Logger
    {
        private static readonly Dictionary<string, Logger> loggers = new Dictionary<string, Logger>();
        private static readonly Logger globalLogger = new Logger("global");
        private readonly string name;
        private readonly string resourceBundleName;

        private Logger(string name, string resourceBundleName = null)
        {
            this.name = name;
            this.resourceBundleName = resourceBundleName;
        }

        public static Logger GetLogger(string name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            
            if (!loggers.ContainsKey(name))
                loggers[name] = new Logger(name);
            
            return loggers[name];
        }

        public static Logger GetLogger(string name, string resourceBundleName)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            if (resourceBundleName == null)
                throw new ArgumentNullException(nameof(resourceBundleName));
            
            string key = name + ":" + resourceBundleName;
            if (!loggers.ContainsKey(key))
                loggers[key] = new Logger(name, resourceBundleName);
            
            return loggers[key];
        }

        public static Logger GetAnonymousLogger()
        {
            return new Logger(null);
        }

        public static Logger GetAnonymousLogger(string resourceBundleName)
        {
            if (resourceBundleName == null)
                throw new ArgumentNullException(nameof(resourceBundleName));
            
            return new Logger(null, resourceBundleName);
        }

        public static Logger GetGlobal()
        {
            return globalLogger;
        }
    }

    public class java_util_logging_LoggerAutoTest
    {
        public void getLogger_test_8104(string p0)
        {
            Logger.GetLogger(p0);
        }

        public void getLogger_test_8105(string p0, string p1)
        {
            Logger.GetLogger(p0, p1);
        }

        public void getAnonymousLogger_test_8106()
        {
            Logger.GetAnonymousLogger();
        }

        public void getAnonymousLogger_test_8107(string p0)
        {
            Logger.GetAnonymousLogger(p0);
        }

        public void getGlobal_test_8108()
        {
            Logger.GetGlobal();
        }
    }
}