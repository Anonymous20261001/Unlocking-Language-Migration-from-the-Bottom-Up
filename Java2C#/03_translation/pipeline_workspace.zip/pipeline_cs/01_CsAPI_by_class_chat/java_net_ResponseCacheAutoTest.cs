using System;
using System.Net;

namespace Generated.Test
{
    public class java_net_ResponseCacheAutoTest
    {
        public void getDefault_test_10628()
        {
            ResponseCache.GetDefault();
        }

        public void setDefault_test_10629(ResponseCache p0)
        {
            ResponseCache.SetDefault(p0);
        }
    }

    public class ResponseCache
    {
        private static ResponseCache _defaultCache;

        public static ResponseCache GetDefault()
        {
            return _defaultCache;
        }

        public static void SetDefault(ResponseCache cache)
        {
            _defaultCache = cache;
        }
    }
}