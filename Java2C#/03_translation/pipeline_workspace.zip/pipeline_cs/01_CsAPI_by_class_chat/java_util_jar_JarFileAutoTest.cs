namespace Generated.Test
{
    public class java_util_jar_JarFileAutoTest
    {
        public void runtimeVersion_test_5997()
        {
            JarFile.runtimeVersion();
        }

        public void baseVersion_test_5998()
        {
            JarFile.baseVersion();
        }
    }

    public class JarFile
    {
        public static RuntimeVersion runtimeVersion()
        {
            return RuntimeVersion.VERSION_17;
        }

        public static RuntimeVersion baseVersion()
        {
            return RuntimeVersion.VERSION_8;
        }
    }

    public class RuntimeVersion
    {
        public static readonly RuntimeVersion VERSION_8 = new RuntimeVersion(8);
        public static readonly RuntimeVersion VERSION_17 = new RuntimeVersion(17);

        private int _feature;

        private RuntimeVersion(int feature)
        {
            _feature = feature;
        }

        public int feature()
        {
            return _feature;
        }

        public override string ToString()
        {
            return _feature.ToString();
        }
    }
}