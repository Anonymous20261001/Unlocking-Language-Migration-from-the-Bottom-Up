namespace Generated.Test
{
    using System.Net.Sockets;

    public class javax_net_SocketFactoryAutoTest
    {
        public void getDefault_test_11262()
        {
            SocketFactory.GetDefault();
        }
    }

    public static class SocketFactory
    {
        public static Socket GetDefault()
        {
            return new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }
    }
}