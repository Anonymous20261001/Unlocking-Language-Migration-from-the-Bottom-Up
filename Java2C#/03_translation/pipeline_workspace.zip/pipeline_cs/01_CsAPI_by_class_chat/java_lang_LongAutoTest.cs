namespace Generated.Test;

using System;
using System.Globalization;
using System.Text;

public class java_lang_LongAutoTest
{
    public void numberOfLeadingZeros_test_8143(long p0)
    {
        LongClass.NumberOfLeadingZeros(p0);
    }

    public void numberOfTrailingZeros_test_8144(long p0)
    {
        LongClass.NumberOfTrailingZeros(p0);
    }

    public void bitCount_test_8145(long p0)
    {
        LongClass.BitCount(p0);
    }

    public void min_test_8146(long p0, long p1)
    {
        LongClass.Min(p0, p1);
    }

    public void max_test_8147(long p0, long p1)
    {
        LongClass.Max(p0, p1);
    }

    public void signum_test_8148(long p0)
    {
        LongClass.Signum(p0);
    }

    public void expand_test_8149(long p0, long p1)
    {
        LongClass.Expand(p0, p1);
    }

    public void compareUnsigned_test_8150(long p0, long p1)
    {
        LongClass.CompareUnsigned(p0, p1);
    }

    public void divideUnsigned_test_8151(long p0, long p1)
    {
        LongClass.DivideUnsigned(p0, p1);
    }

    public void remainderUnsigned_test_8152(long p0, long p1)
    {
        LongClass.RemainderUnsigned(p0, p1);
    }

    public void reverse_test_8153(long p0)
    {
        LongClass.Reverse(p0);
    }

    public void reverseBytes_test_8154(long p0)
    {
        LongClass.ReverseBytes(p0);
    }

    public void compress_test_8155(long p0, long p1)
    {
        LongClass.Compress(p0, p1);
    }

    public void compareTo_test_8156(LongClass p0, string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.CompareTo(p0);
    }

    public void getLong_test_8157(string p0, LongClass p1)
    {
        LongClass.GetLong(p0, p1);
    }

    public void getLong_test_8158(string p0)
    {
        LongClass.GetLong(p0);
    }

    public void getLong_test_8159(string p0, long p1)
    {
        LongClass.GetLong(p0, p1);
    }

    public void compare_test_8160(long p0, long p1)
    {
        LongClass.Compare(p0, p1);
    }

    public void byteValue_test_8161(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.ByteValue();
    }

    public void shortValue_test_8162(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.ShortValue();
    }

    public void intValue_test_8163(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.IntValue();
    }

    public void longValue_test_8164(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.LongValue();
    }

    public void floatValue_test_8165(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.FloatValue();
    }

    public void doubleValue_test_8166(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.DoubleValue();
    }

    public void valueOf_test_8167(long p0)
    {
        LongClass.ValueOf(p0);
    }

    public void valueOf_test_8168(string p0)
    {
        LongClass.ValueOf(p0);
    }

    public void valueOf_test_8169(string p0, int p1)
    {
        LongClass.ValueOf(p0, p1);
    }

    public void toHexString_test_8170(long p0)
    {
        LongClass.ToHexString(p0);
    }

    public void decode_test_8171(string p0)
    {
        LongClass.Decode(p0);
    }

    public void resolveConstantDesc_test_8172(object p0, string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.ResolveConstantDesc(p0);
    }

    public void describeConstable_test_8173(string c0)
    {
        LongClass instance = new LongClass(c0);
        instance.DescribeConstable();
    }

    public void sum_test_8174(long p0, long p1)
    {
        LongClass.Sum(p0, p1);
    }

    public void toUnsignedString_test_8175(long p0)
    {
        LongClass.ToUnsignedString(p0);
    }

    public void toUnsignedString_test_8176(long p0, int p1)
    {
        LongClass.ToUnsignedString(p0, p1);
    }

    public void toOctalString_test_8177(long p0)
    {
        LongClass.ToOctalString(p0);
    }

    public void toBinaryString_test_8178(long p0)
    {
        LongClass.ToBinaryString(p0);
    }

    public void highestOneBit_test_8179(long p0)
    {
        LongClass.HighestOneBit(p0);
    }

    public void lowestOneBit_test_8180(long p0)
    {
        LongClass.LowestOneBit(p0);
    }

    public void rotateLeft_test_8181(long p0, int p1)
    {
        LongClass.RotateLeft(p0, p1);
    }

    public void rotateRight_test_8182(long p0, int p1)
    {
        LongClass.RotateRight(p0, p1);
    }

    public void parseLong_test_8183(string p0)
    {
        LongClass.ParseLong(p0);
    }

    public void parseLong_test_8184(string p0, int p1)
    {
        LongClass.ParseLong(p0, p1);
    }

    public void parseLong_test_8185(CharSequence p0, int p1, int p2, int p3)
    {
        LongClass.ParseLong(p0, p1, p2, p3);
    }

    public void parseUnsignedLong_test_8186(string p0)
    {
        LongClass.ParseUnsignedLong(p0);
    }

    public void parseUnsignedLong_test_8187(string p0, int p1)
    {
        LongClass.ParseUnsignedLong(p0, p1);
    }

    public void parseUnsignedLong_test_8188(CharSequence p0, int p1, int p2, int p3)
    {
        LongClass.ParseUnsignedLong(p0, p1, p2, p3);
    }
}

public class LongClass : IComparable<LongClass>
{
    private readonly long _value;

    public LongClass(long value)
    {
        _value = value;
    }

    public LongClass(string s)
    {
        _value = ParseLong(s);
    }

    public long Value => _value;

    public static int NumberOfLeadingZeros(long i)
    {
        if (i == 0) return 64;
        int n = 0;
        for (int bit = 63; bit >= 0; bit--)
        {
            if ((i & (1L << bit)) != 0) break;
            n++;
        }
        return n;
    }

    public static int NumberOfTrailingZeros(long i)
    {
        if (i == 0) return 64;
        int n = 0;
        while ((i & 1L) == 0)
        {
            n++;
            i >>= 1;
        }
        return n;
    }

    public static int BitCount(long i)
    {
        int count = 0;
        while (i != 0)
        {
            count += (int)(i & 1L);
            i >>= 1;
        }
        return count;
    }

    public static long Min(long a, long b) => Math.Min(a, b);

    public static long Max(long a, long b) => Math.Max(a, b);

    public static int Signum(long i) => Math.Sign(i);

    public static long Expand(long i, long mask)
    {
        long result = 0;
        int bit = 0;
        for (int m = 0; m < 64; m++)
        {
            if ((mask & (1L << m)) != 0)
            {
                if ((i & (1L << bit)) != 0)
                    result |= (1L << m);
                bit++;
            }
        }
        return result;
    }

    public static int CompareUnsigned(long x, long y)
    {
        return ((ulong)x).CompareTo((ulong)y);
    }

    public static long DivideUnsigned(long dividend, long divisor)
    {
        if (divisor == 0) throw new DivideByZeroException();
        return (long)((ulong)dividend / (ulong)divisor);
    }

    public static long RemainderUnsigned(long dividend, long divisor)
    {
        if (divisor == 0) throw new DivideByZeroException();
        return (long)((ulong)dividend % (ulong)divisor);
    }

    public static long Reverse(long i)
    {
        ulong value = (ulong)i;
        ulong result = 0;
        for (int bit = 0; bit < 64; bit++)
        {
            if ((value & (1UL << bit)) != 0)
                result |= (1UL << (63 - bit));
        }
        return (long)result;
    }

    public static long ReverseBytes(long i)
    {
        byte[] bytes = BitConverter.GetBytes(i);
        Array.Reverse(bytes);
        return BitConverter.ToInt64(bytes, 0);
    }

    public static long Compress(long i, long mask)
    {
        long result = 0;
        int bit = 0;
        for (int m = 0; m < 64; m++)
        {
            if ((mask & (1L << m)) != 0)
            {
                if ((i & (1L << m)) != 0)
                    result |= (1L << bit);
                bit++;
            }
        }
        return result;
    }

    public int CompareTo(LongClass other)
    {
        if (other == null) return 1;
        return _value.CompareTo(other._value);
    }

    public static LongClass GetLong(string nm, LongClass val)
    {
        string value = Environment.GetEnvironmentVariable(nm);
        if (value == null) return val;
        try
        {
            return new LongClass(ParseLong(value));
        }
        catch
        {
            return val;
        }
    }

    public static LongClass GetLong(string nm)
    {
        return GetLong(nm, null);
    }

    public static LongClass GetLong(string nm, long val)
    {
        return GetLong(nm, new LongClass(val));
    }

    public static int Compare(long x, long y) => x.CompareTo(y);

    public byte ByteValue() => (byte)_value;

    public short ShortValue() => (short)_value;

    public int IntValue() => (int)_value;

    public long LongValue() => _value;

    public float FloatValue() => (float)_value;

    public double DoubleValue() => (double)_value;

    public static LongClass ValueOf(long i) => new LongClass(i);

    public static LongClass ValueOf(string s) => new LongClass(ParseLong(s));

    public static LongClass ValueOf(string s, int radix) => new LongClass(ParseLong(s, radix));

    public static string ToHexString(long i) => Convert.ToString(i, 16);

    public static LongClass Decode(string nm)
    {
        if (nm == null) throw new ArgumentNullException(nameof(nm));
        string value = nm.Trim();
        int radix = 10;
        int index = 0;
        bool negative = false;

        if (value.StartsWith("-"))
        {
            negative = true;
            index = 1;
        }
        else if (value.StartsWith("+"))
        {
            index = 1;
        }

        if (value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || value.StartsWith("#"))
        {
            radix = 16;
            index += 2;
        }
        else if (value.StartsWith("0", StringComparison.Ordinal) && value.Length > index + 1)
        {
            radix = 8;
            index += 1;
        }

        string digits = value.Substring(index);
        long result = ParseLong(digits, radix);
        return new LongClass(negative ? -result : result);
    }

    public object ResolveConstantDesc(object lookup) => this;

    public object DescribeConstable() => this;

    public static long Sum(long a, long b) => a + b;

    public static string ToUnsignedString(long i)
    {
        return ((ulong)i).ToString();
    }

    public static string ToUnsignedString(long i, int radix)
    {
        if (radix < 2 || radix > 36) radix = 10;
        ulong value = (ulong)i;
        if (value == 0) return "0";
        StringBuilder sb = new StringBuilder();
        while (value > 0)
        {
            int digit = (int)(value % (ulong)radix);
            sb.Insert(0, digit < 10 ? (char)('0' + digit) : (char)('a' + digit - 10));
            value /= (ulong)radix;
        }
        return sb.ToString();
    }

    public static string ToOctalString(long i) => Convert.ToString(i, 8);

    public static string ToBinaryString(long i) => Convert.ToString(i, 2);

    public static long HighestOneBit(long i)
    {
        if (i == 0) return 0;
        ulong value = (ulong)i;
        for (int bit = 63; bit >= 0; bit--)
        {
            if ((value & (1UL << bit)) != 0)
                return (long)(1UL << bit);
        }
        return 0;
    }

    public static long LowestOneBit(long i)
    {
        if (i == 0) return 0;
        ulong value = (ulong)i;
        for (int bit = 0; bit < 64; bit++)
        {
            if ((value & (1UL << bit)) != 0)
                return (long)(1UL << bit);
        }
        return 0;
    }

    public static long RotateLeft(long i, int distance)
    {
        distance &= 63;
        if (distance == 0) return i;
        return (long)(((ulong)i << distance) | ((ulong)i >> (64 - distance)));
    }

    public static long RotateRight(long i, int distance)
    {
        distance &= 63;
        if (distance == 0) return i;
        return (long)(((ulong)i >> distance) | ((ulong)i << (64 - distance)));
    }

    public static long ParseLong(string s)
    {
        return long.Parse(s, CultureInfo.InvariantCulture);
    }

    public static long ParseLong(string s, int radix)
    {
        if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
        if (string.IsNullOrEmpty(s)) throw new FormatException("Empty string");
        
        bool negative = false;
        int index = 0;
        if (s[0] == '-')
        {
            negative = true;
            index = 1;
        }
        else if (s[0] == '+')
        {
            index = 1;
        }

        long result = 0;
        for (int i = index; i < s.Length; i++)
        {
            char c = s[i];
            int digit;
            if (c >= '0' && c <= '9')
                digit = c - '0';
            else if (c >= 'a' && c <= 'z')
                digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z')
                digit = c - 'A' + 10;
            else
                throw new FormatException("Invalid character");

            if (digit >= radix) throw new FormatException("Digit out of range");
            result = result * radix + digit;
        }
        return negative ? -result : result;
    }

    public static long ParseLong(CharSequence s, int beginIndex, int endIndex, int radix)
    {
        if (s == null) throw new ArgumentNullException(nameof(s));
        if (beginIndex < 0 || endIndex > s.Length || beginIndex > endIndex)
            throw new IndexOutOfRangeException();
        return ParseLong(s.SubSequence(beginIndex, endIndex).ToString(), radix);
    }

    public static long ParseUnsignedLong(string s)
    {
        return (long)ulong.Parse(s, CultureInfo.InvariantCulture);
    }

    public static long ParseUnsignedLong(string s, int radix)
    {
        if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
        if (string.IsNullOrEmpty(s)) throw new FormatException("Empty string");
        
        ulong result = 0;
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            int digit;
            if (c >= '0' && c <= '9')
                digit = c - '0';
            else if (c >= 'a' && c <= 'z')
                digit = c - 'a' + 10;
            else if (c >= 'A' && c <= 'Z')
                digit = c - 'A' + 10;
            else
                throw new FormatException("Invalid character");

            if (digit >= radix) throw new FormatException("Digit out of range");
            result = result * (ulong)radix + (ulong)digit;
        }
        return (long)result;
    }

    public static long ParseUnsignedLong(CharSequence s, int beginIndex, int endIndex, int radix)
    {
        if (s == null) throw new ArgumentNullException(nameof(s));
        if (beginIndex < 0 || endIndex > s.Length || beginIndex > endIndex)
            throw new IndexOutOfRangeException();
        return ParseUnsignedLong(s.SubSequence(beginIndex, endIndex).ToString(), radix);
    }
}

public class CharSequence
{
    private readonly string _value;

    public CharSequence(string value)
    {
        _value = value ?? throw new ArgumentNullException(nameof(value));
    }

    public int Length => _value.Length;

    public char CharAt(int index) => _value[index];

    public CharSequence SubSequence(int start, int end)
    {
        if (start < 0 || end > _value.Length || start > end)
            throw new IndexOutOfRangeException();
        return new CharSequence(_value.Substring(start, end - start));
    }

    public override string ToString() => _value;
}