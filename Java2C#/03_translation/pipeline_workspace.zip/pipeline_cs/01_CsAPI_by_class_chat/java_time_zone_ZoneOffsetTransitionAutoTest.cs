namespace Generated.Test
{
    using System;

    public class java_time_zone_ZoneOffsetTransitionAutoTest
    {
        public void of_test_13734(LocalDateTime p0, ZoneOffset p1, ZoneOffset p2)
        {
            ZoneOffsetTransition.Of(p0, p1, p2);
        }
    }

    public class LocalDateTime
    {
        // Simplified representation of Java's LocalDateTime
        public DateTime Value { get; private set; }

        public LocalDateTime(DateTime value)
        {
            Value = value;
        }

        public static LocalDateTime Of(int year, int month, int day, int hour, int minute, int second)
        {
            return new LocalDateTime(new DateTime(year, month, day, hour, minute, second));
        }

        public static LocalDateTime Of(int year, int month, int day, int hour, int minute, int second, int nano)
        {
            return new LocalDateTime(new DateTime(year, month, day, hour, minute, second).AddTicks(nano / 100));
        }

        public static LocalDateTime Parse(string value)
        {
            return new LocalDateTime(DateTime.Parse(value));
        }

        public override string ToString()
        {
            return Value.ToString("yyyy-MM-ddTHH:mm:ss");
        }
    }

    public class ZoneOffset
    {
        public TimeSpan Offset { get; private set; }

        public ZoneOffset(TimeSpan offset)
        {
            Offset = offset;
        }

        public static ZoneOffset OfHours(int hours)
        {
            return new ZoneOffset(TimeSpan.FromHours(hours));
        }

        public static ZoneOffset OfHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(new TimeSpan(hours, minutes, 0));
        }

        public static ZoneOffset OfHoursMinutesSeconds(int hours, int minutes, int seconds)
        {
            return new ZoneOffset(new TimeSpan(hours, minutes, seconds));
        }

        public static ZoneOffset OfTotalSeconds(int totalSeconds)
        {
            return new ZoneOffset(TimeSpan.FromSeconds(totalSeconds));
        }

        public static ZoneOffset Utc
        {
            get { return new ZoneOffset(TimeSpan.Zero); }
        }

        public override string ToString()
        {
            if (Offset == TimeSpan.Zero)
                return "Z";
            string sign = Offset < TimeSpan.Zero ? "-" : "+";
            TimeSpan abs = Offset.Duration();
            return string.Format("{0}{1:D2}:{2:D2}", sign, abs.Hours, abs.Minutes);
        }
    }

    public class ZoneOffsetTransition
    {
        public LocalDateTime Transition { get; private set; }
        public ZoneOffset OffsetBefore { get; private set; }
        public ZoneOffset OffsetAfter { get; private set; }

        public ZoneOffsetTransition(LocalDateTime transition, ZoneOffset offsetBefore, ZoneOffset offsetAfter)
        {
            Transition = transition;
            OffsetBefore = offsetBefore;
            OffsetAfter = offsetAfter;
        }

        public static ZoneOffsetTransition Of(LocalDateTime transition, ZoneOffset offsetBefore, ZoneOffset offsetAfter)
        {
            return new ZoneOffsetTransition(transition, offsetBefore, offsetAfter);
        }

        public LocalDateTime GetDateTimeBefore()
        {
            return Transition;
        }

        public LocalDateTime GetDateTimeAfter()
        {
            return Transition;
        }

        public ZoneOffset GetOffsetBefore()
        {
            return OffsetBefore;
        }

        public ZoneOffset GetOffsetAfter()
        {
            return OffsetAfter;
        }

        public long GetInstant()
        {
            DateTime utc = Transition.Value.ToUniversalTime();
            return (long)(utc - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
        }

        public long GetDurationSeconds()
        {
            return (long)(OffsetAfter.Offset - OffsetBefore.Offset).TotalSeconds;
        }

        public bool IsGap()
        {
            return OffsetAfter.Offset > OffsetBefore.Offset;
        }

        public bool IsOverlap()
        {
            return OffsetAfter.Offset < OffsetBefore.Offset;
        }

        public bool IsValidOffset(ZoneOffset offset)
        {
            return offset.Offset == OffsetBefore.Offset || offset.Offset == OffsetAfter.Offset;
        }

        public override string ToString()
        {
            return string.Format("Transition[{0} {1} -> {2}]", Transition, OffsetBefore, OffsetAfter);
        }
    }
}