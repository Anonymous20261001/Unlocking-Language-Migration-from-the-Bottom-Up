using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface UndoableEdit
    {
        bool AddEdit(UndoableEdit anEdit);
        bool ReplaceEdit(UndoableEdit anEdit);
        bool IsSignificant();
        string GetPresentationName();
        string GetUndoPresentationName();
        string GetRedoPresentationName();
        void Undo();
        void Redo();
        bool CanUndo();
        bool CanRedo();
        void Die();
        bool IsAlive();
    }

    public class UndoableEditEvent : EventArgs
    {
        public object Source { get; }
        public UndoableEdit Edit { get; }

        public UndoableEditEvent(object source, UndoableEdit edit)
        {
            Source = source;
            Edit = edit;
        }
    }

    public class UndoManager
    {
        private List<UndoableEdit> edits = new List<UndoableEdit>();
        private int index = 0;
        private int limit = 100;
        private bool inProgress = false;

        public void UndoableEditHappened(UndoableEditEvent e)
        {
            if (e?.Edit != null)
            {
                AddEdit(e.Edit);
            }
        }

        public bool AddEdit(UndoableEdit anEdit)
        {
            if (anEdit == null)
                return false;

            if (inProgress)
            {
                // If in progress, just add to the list
                edits.Add(anEdit);
                return true;
            }

            // Trim any redoable edits
            if (index < edits.Count)
            {
                edits.RemoveRange(index, edits.Count - index);
            }

            edits.Add(anEdit);
            index = edits.Count;

            // Enforce limit
            if (edits.Count > limit)
            {
                int excess = edits.Count - limit;
                edits.RemoveRange(0, excess);
                index -= excess;
            }

            return true;
        }

        public void Redo()
        {
            if (CanRedo())
            {
                UndoableEdit edit = edits[index];
                edit.Redo();
                index++;
            }
        }

        public void Undo()
        {
            if (CanUndo())
            {
                index--;
                UndoableEdit edit = edits[index];
                edit.Undo();
            }
        }

        public string GetUndoPresentationName()
        {
            if (CanUndo())
            {
                return edits[index - 1].GetUndoPresentationName();
            }
            return "Undo";
        }

        public string GetRedoPresentationName()
        {
            if (CanRedo())
            {
                return edits[index].GetRedoPresentationName();
            }
            return "Redo";
        }

        public bool CanUndo()
        {
            return index > 0 && edits[index - 1].IsAlive() && edits[index - 1].CanUndo();
        }

        public bool CanRedo()
        {
            return index < edits.Count && edits[index].IsAlive() && edits[index].CanRedo();
        }

        public int GetLimit()
        {
            return limit;
        }

        public void DiscardAllEdits()
        {
            foreach (var edit in edits)
            {
                edit.Die();
            }
            edits.Clear();
            index = 0;
        }

        public void SetLimit(int l)
        {
            limit = l;
            if (limit >= 0)
            {
                if (edits.Count > limit)
                {
                    int excess = edits.Count - limit;
                    for (int i = 0; i < excess; i++)
                    {
                        edits[i].Die();
                    }
                    edits.RemoveRange(0, excess);
                    index = Math.Max(0, index - excess);
                }
            }
        }

        public void UndoOrRedo()
        {
            if (CanUndo())
                Undo();
            else if (CanRedo())
                Redo();
        }

        public bool CanUndoOrRedo()
        {
            return CanUndo() || CanRedo();
        }

        public string GetUndoOrRedoPresentationName()
        {
            if (CanUndo())
                return GetUndoPresentationName();
            else if (CanRedo())
                return GetRedoPresentationName();
            return "Undo or Redo";
        }

        public void End()
        {
            inProgress = false;
        }

        // Test methods
        public void undoableEditHappened_test_13193(UndoableEditEvent p0)
        {
            UndoManager instance = new UndoManager();
            instance.UndoableEditHappened(p0);
        }

        public void addEdit_test_13194(UndoableEdit p0)
        {
            UndoManager instance = new UndoManager();
            instance.AddEdit(p0);
        }

        public void redo_test_13195()
        {
            UndoManager instance = new UndoManager();
            instance.Redo();
        }

        public void undo_test_13196()
        {
            UndoManager instance = new UndoManager();
            instance.Undo();
        }

        public void getUndoPresentationName_test_13197()
        {
            UndoManager instance = new UndoManager();
            instance.GetUndoPresentationName();
        }

        public void getRedoPresentationName_test_13198()
        {
            UndoManager instance = new UndoManager();
            instance.GetRedoPresentationName();
        }

        public void canUndo_test_13199()
        {
            UndoManager instance = new UndoManager();
            instance.CanUndo();
        }

        public void canRedo_test_13200()
        {
            UndoManager instance = new UndoManager();
            instance.CanRedo();
        }

        public void getLimit_test_13201()
        {
            UndoManager instance = new UndoManager();
            instance.GetLimit();
        }

        public void discardAllEdits_test_13202()
        {
            UndoManager instance = new UndoManager();
            instance.DiscardAllEdits();
        }

        public void setLimit_test_13203(int p0)
        {
            UndoManager instance = new UndoManager();
            instance.SetLimit(p0);
        }

        public void undoOrRedo_test_13204()
        {
            UndoManager instance = new UndoManager();
            instance.UndoOrRedo();
        }

        public void canUndoOrRedo_test_13205()
        {
            UndoManager instance = new UndoManager();
            instance.CanUndoOrRedo();
        }

        public void getUndoOrRedoPresentationName_test_13206()
        {
            UndoManager instance = new UndoManager();
            instance.GetUndoOrRedoPresentationName();
        }

        public void end_test_13207()
        {
            UndoManager instance = new UndoManager();
            instance.End();
        }
    }
}