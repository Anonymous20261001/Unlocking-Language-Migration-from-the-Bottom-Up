namespace Generated.Test
{
    public class java_net_HttpURLConnectionAutoTest
    {
        public void setFollowRedirects_test_5493(bool p0)
        {
            HttpURLConnection.SetFollowRedirects(p0);
        }

        public void getFollowRedirects_test_5494()
        {
            HttpURLConnection.GetFollowRedirects();
        }
    }

    public static class HttpURLConnection
    {
        private static bool followRedirects = true;

        public static void SetFollowRedirects(bool set)
        {
            followRedirects = set;
        }

        public static bool GetFollowRedirects()
        {
            return followRedirects;
        }
    }
}