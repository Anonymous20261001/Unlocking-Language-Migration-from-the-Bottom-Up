using System;
using System.Collections.Generic;
using System.Globalization;

namespace Generated.Test
{
    public enum Month
    {
        JANUARY = 1,
        FEBRUARY = 2,
        MARCH = 3,
        APRIL = 4,
        MAY = 5,
        JUNE = 6,
        JULY = 7,
        AUGUST = 8,
        SEPTEMBER = 9,
        OCTOBER = 10,
        NOVEMBER = 11,
        DECEMBER = 12
    }

    public class ZoneOffset
    {
        public int TotalSeconds { get; }
        public static ZoneOffset UTC { get; } = new ZoneOffset(0);

        public ZoneOffset(int totalSeconds)
        {
            TotalSeconds = totalSeconds;
        }

        public static ZoneOffset OfHours(int hours)
        {
            return new ZoneOffset(hours * 3600);
        }

        public static ZoneOffset OfHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(hours * 3600 + minutes * 60);
        }

        public static ZoneOffset OfTotalSeconds(int totalSeconds)
        {
            return new ZoneOffset(totalSeconds);
        }

        public override string ToString()
        {
            if (TotalSeconds == 0) return "Z";
            int hours = TotalSeconds / 3600;
            int minutes = (TotalSeconds % 3600) / 60;
            int seconds = TotalSeconds % 60;
            string sign = TotalSeconds < 0 ? "-" : "+";
            return string.Format("{0}{1:D2}:{2:D2}:{3:D2}", sign, Math.Abs(hours), Math.Abs(minutes), Math.Abs(seconds));
        }
    }

    public class ZoneId
    {
        public string Id { get; }
        public static ZoneId Utc { get; } = new ZoneId("UTC");

        public ZoneId(string id)
        {
            Id = id;
        }

        public static ZoneId Of(string id)
        {
            return new ZoneId(id);
        }

        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }

        public override string ToString()
        {
            return Id;
        }
    }

    public class Instant
    {
        public long EpochSecond { get; }
        public int Nano { get; }

        public Instant(long epochSecond, int nano)
        {
            EpochSecond = epochSecond;
            Nano = nano;
        }

        public static Instant OfEpochSecond(long epochSecond)
        {
            return new Instant(epochSecond, 0);
        }

        public static Instant OfEpochSecond(long epochSecond, long nanoAdjustment)
        {
            long secs = epochSecond + Math.Floor((double)nanoAdjustment / 1000000000);
            int nanos = (int)(nanoAdjustment % 1000000000);
            if (nanos < 0)
            {
                nanos += 1000000000;
                secs--;
            }
            return new Instant(secs, nanos);
        }

        public static Instant Now()
        {
            DateTime utcNow = DateTime.UtcNow;
            long epochSecond = (long)(utcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
            return new Instant(epochSecond, utcNow.Millisecond * 1000000);
        }
    }

    public class Clock
    {
        public ZoneId Zone { get; }
        private readonly DateTimeOffset _currentTime;

        public Clock(ZoneId zone, DateTimeOffset currentTime)
        {
            Zone = zone;
            _currentTime = currentTime;
        }

        public static Clock SystemDefaultZone()
        {
            return new Clock(ZoneId.SystemDefault(), DateTimeOffset.Now);
        }

        public static Clock SystemUTC()
        {
            return new Clock(ZoneId.Utc, DateTimeOffset.UtcNow);
        }

        public static Clock Fixed(Instant fixedInstant, ZoneId zone)
        {
            DateTimeOffset dt = DateTimeOffset.FromUnixTimeSeconds(fixedInstant.EpochSecond).ToOffset(TimeSpan.Zero);
            return new Clock(zone, dt);
        }

        public Instant Instant()
        {
            return Instant.OfEpochSecond(_currentTime.ToUnixTimeSeconds(), _currentTime.Millisecond * 1000000);
        }
    }

    public class DateTimeFormatter
    {
        public string Pattern { get; }
        public static DateTimeFormatter ISO_LOCAL_DATE_TIME { get; } = new DateTimeFormatter("yyyy-MM-dd'T'HH:mm:ss");

        public DateTimeFormatter(string pattern)
        {
            Pattern = pattern;
        }

        public static DateTimeFormatter OfPattern(string pattern)
        {
            return new DateTimeFormatter(pattern);
        }

        public string Format(LocalDateTime dateTime)
        {
            return dateTime.ToString(Pattern);
        }

        public LocalDateTime Parse(string text)
        {
            return LocalDateTime.Parse(text, this);
        }
    }

    public interface TemporalAccessor
    {
        int GetYear();
        int GetMonthValue();
        int GetDayOfMonth();
        int GetHour();
        int GetMinute();
        int GetSecond();
        int GetNano();
    }

    public class LocalDate : TemporalAccessor
    {
        public int Year { get; }
        public int MonthValue { get; }
        public int DayOfMonth { get; }

        public LocalDate(int year, int month, int dayOfMonth)
        {
            Year = year;
            MonthValue = month;
            DayOfMonth = dayOfMonth;
        }

        public static LocalDate Of(int year, int month, int dayOfMonth)
        {
            return new LocalDate(year, month, dayOfMonth);
        }

        public static LocalDate Of(int year, Month month, int dayOfMonth)
        {
            return new LocalDate(year, (int)month, dayOfMonth);
        }

        public static LocalDate Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDate(now.Year, now.Month, now.Day);
        }

        public static LocalDate Now(ZoneId zone)
        {
            DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(zone.Id));
            return new LocalDate(now.Year, now.Month, now.Day);
        }

        public static LocalDate Now(Clock clock)
        {
            DateTimeOffset now = clock._currentTime;
            return new LocalDate(now.Year, now.Month, now.Day);
        }

        public static LocalDate Parse(string text)
        {
            DateTime dt = DateTime.Parse(text);
            return new LocalDate(dt.Year, dt.Month, dt.Day);
        }

        public static LocalDate From(TemporalAccessor temporal)
        {
            return new LocalDate(temporal.GetYear(), temporal.GetMonthValue(), temporal.GetDayOfMonth());
        }

        public int GetYear() => Year;
        public int GetMonthValue() => MonthValue;
        public int GetDayOfMonth() => DayOfMonth;
        public int GetHour() => 0;
        public int GetMinute() => 0;
        public int GetSecond() => 0;
        public int GetNano() => 0;

        public LocalDateTime AtTime(LocalTime time)
        {
            return LocalDateTime.Of(this, time);
        }

        public LocalDateTime AtTime(int hour, int minute)
        {
            return LocalDateTime.Of(this, LocalTime.Of(hour, minute));
        }

        public LocalDateTime AtTime(int hour, int minute, int second)
        {
            return LocalDateTime.Of(this, LocalTime.Of(hour, minute, second));
        }

        public LocalDateTime AtTime(int hour, int minute, int second, int nanoOfSecond)
        {
            return LocalDateTime.Of(this, LocalTime.Of(hour, minute, second, nanoOfSecond));
        }

        public override string ToString()
        {
            return string.Format("{0:D4}-{1:D2}-{2:D2}", Year, MonthValue, DayOfMonth);
        }
    }

    public class LocalTime : TemporalAccessor
    {
        public int Hour { get; }
        public int Minute { get; }
        public int Second { get; }
        public int Nano { get; }

        public LocalTime(int hour, int minute, int second, int nano)
        {
            Hour = hour;
            Minute = minute;
            Second = second;
            Nano = nano;
        }

        public static LocalTime Of(int hour, int minute)
        {
            return new LocalTime(hour, minute, 0, 0);
        }

        public static LocalTime Of(int hour, int minute, int second)
        {
            return new LocalTime(hour, minute, second, 0);
        }

        public static LocalTime Of(int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalTime(hour, minute, second, nanoOfSecond);
        }

        public static LocalTime Now()
        {
            DateTime now = DateTime.Now;
            return new LocalTime(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }

        public static LocalTime Now(ZoneId zone)
        {
            DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(zone.Id));
            return new LocalTime(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }

        public static LocalTime Now(Clock clock)
        {
            DateTimeOffset now = clock._currentTime;
            return new LocalTime(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }

        public static LocalTime Parse(string text)
        {
            DateTime dt = DateTime.Parse(text);
            return new LocalTime(dt.Hour, dt.Minute, dt.Second, dt.Millisecond * 1000000);
        }

        public static LocalTime From(TemporalAccessor temporal)
        {
            return new LocalTime(temporal.GetHour(), temporal.GetMinute(), temporal.GetSecond(), temporal.GetNano());
        }

        public int GetYear() => 0;
        public int GetMonthValue() => 0;
        public int GetDayOfMonth() => 0;
        public int GetHour() => Hour;
        public int GetMinute() => Minute;
        public int GetSecond() => Second;
        public int GetNano() => Nano;

        public override string ToString()
        {
            return string.Format("{0:D2}:{1:D2}:{2:D2}", Hour, Minute, Second);
        }
    }

    public class LocalDateTime : TemporalAccessor
    {
        public LocalDate Date { get; }
        public LocalTime Time { get; }

        public LocalDateTime(LocalDate date, LocalTime time)
        {
            Date = date;
            Time = time;
        }

        public int Year => Date.Year;
        public int MonthValue => Date.MonthValue;
        public int DayOfMonth => Date.DayOfMonth;
        public int Hour => Time.Hour;
        public int Minute => Time.Minute;
        public int Second => Time.Second;
        public int Nano => Time.Nano;

        public static LocalDateTime Of(LocalDate date, LocalTime time)
        {
            return new LocalDateTime(date, time);
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute)
        {
            return new LocalDateTime(LocalDate.Of(year, month, dayOfMonth), LocalTime.Of(hour, minute));
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalDateTime(LocalDate.Of(year, (int)month, dayOfMonth), LocalTime.Of(hour, minute, second, nanoOfSecond));
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute, int second)
        {
            return new LocalDateTime(LocalDate.Of(year, (int)month, dayOfMonth), LocalTime.Of(hour, minute, second));
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute)
        {
            return new LocalDateTime(LocalDate.Of(year, (int)month, dayOfMonth), LocalTime.Of(hour, minute));
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalDateTime(LocalDate.Of(year, month, dayOfMonth), LocalTime.Of(hour, minute, second, nanoOfSecond));
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute, int second)
        {
            return new LocalDateTime(LocalDate.Of(year, month, dayOfMonth), LocalTime.Of(hour, minute, second));
        }

        public static LocalDateTime From(TemporalAccessor temporal)
        {
            return new LocalDateTime(LocalDate.From(temporal), LocalTime.From(temporal));
        }

        public static LocalDateTime Parse(string text)
        {
            DateTime dt = DateTime.Parse(text);
            return new LocalDateTime(LocalDate.Of(dt.Year, dt.Month, dt.Day), LocalTime.Of(dt.Hour, dt.Minute, dt.Second, dt.Millisecond * 1000000));
        }

        public static LocalDateTime Parse(string text, DateTimeFormatter formatter)
        {
            DateTime dt = DateTime.ParseExact(text, formatter.Pattern, CultureInfo.InvariantCulture);
            return new LocalDateTime(LocalDate.Of(dt.Year, dt.Month, dt.Day), LocalTime.Of(dt.Hour, dt.Minute, dt.Second, dt.Millisecond * 1000000));
        }

        public static LocalDateTime Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDateTime(LocalDate.Of(now.Year, now.Month, now.Day), LocalTime.Of(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000));
        }

        public static LocalDateTime Now(ZoneId zone)
        {
            DateTime now = TimeZoneInfo.ConvertTime(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(zone.Id));
            return new LocalDateTime(LocalDate.Of(now.Year, now.Month, now.Day), LocalTime.Of(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000));
        }

        public static LocalDateTime Now(Clock clock)
        {
            DateTimeOffset now = clock._currentTime;
            return new LocalDateTime(LocalDate.Of(now.Year, now.Month, now.Day), LocalTime.Of(now.Hour, now.Minute, now.Second, now.Millisecond * 1000000));
        }

        public static LocalDateTime OfEpochSecond(long epochSecond, int nanoOfSecond, ZoneOffset offset)
        {
            long localSecond = epochSecond + offset.TotalSeconds;
            DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(localSecond);
            return new LocalDateTime(LocalDate.Of(dt.Year, dt.Month, dt.Day), LocalTime.Of(dt.Hour, dt.Minute, dt.Second, nanoOfSecond));
        }

        public static LocalDateTime OfInstant(Instant instant, ZoneId zone)
        {
            DateTime dt = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(instant.EpochSecond);
            if (zone.Id != "UTC")
            {
                TimeZoneInfo tz = TimeZoneInfo.FindSystemTimeZoneById(zone.Id);
                dt = TimeZoneInfo.ConvertTimeFromUtc(dt, tz);
            }
            return new LocalDateTime(LocalDate.Of(dt.Year, dt.Month, dt.Day), LocalTime.Of(dt.Hour, dt.Minute, dt.Second, instant.Nano));
        }

        public int GetYear() => Year;
        public int GetMonthValue() => MonthValue;
        public int GetDayOfMonth() => DayOfMonth;
        public int GetHour() => Hour;
        public int GetMinute() => Minute;
        public int GetSecond() => Second;
        public int GetNano() => Nano;

        public override string ToString()
        {
            return Date.ToString() + "T" + Time.ToString();
        }

        public string ToString(string pattern)
        {
            return DateTime.Parse(ToString()).ToString(pattern);
        }
    }

    public class java_time_LocalDateTimeAutoTest
    {
        public void of_test_7999(LocalDate p0, LocalTime p1)
        {
            LocalDateTime.Of(p0, p1);
        }

        public void of_test_8000(int p0, int p1, int p2, int p3, int p4)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_8001(int p0, Month p1, int p2, int p3, int p4, int p5, int p6)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5, p6);
        }

        public void of_test_8002(int p0, Month p1, int p2, int p3, int p4, int p5)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5);
        }

        public void of_test_8003(int p0, Month p1, int p2, int p3, int p4)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_8004(int p0, int p1, int p2, int p3, int p4, int p5, int p6)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5, p6);
        }

        public void of_test_8005(int p0, int p1, int p2, int p3, int p4, int p5)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5);
        }

        public void from_test_8006(TemporalAccessor p0)
        {
            LocalDateTime.From(p0);
        }

        public void parse_test_8007(string p0)
        {
            LocalDateTime.Parse(p0);
        }

        public void parse_test_8008(string p0, DateTimeFormatter p1)
        {
            LocalDateTime.Parse(p0, p1);
        }

        public void now_test_8009()
        {
            LocalDateTime.Now();
        }

        public void now_test_8010(ZoneId p0)
        {
            LocalDateTime.Now(p0);
        }

        public void now_test_8011(Clock p0)
        {
            LocalDateTime.Now(p0);
        }

        public void ofEpochSecond_test_8012(long p0, int p1, ZoneOffset p2)
        {
            LocalDateTime.OfEpochSecond(p0, p1, p2);
        }

        public void ofInstant_test_8013(Instant p0, ZoneId p1)
        {
            LocalDateTime.OfInstant(p0, p1);
        }
    }
}