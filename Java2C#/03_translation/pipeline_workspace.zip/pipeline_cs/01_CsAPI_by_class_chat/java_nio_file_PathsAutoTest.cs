namespace Generated.Test
{
    using System;
    using System.IO;

    public class java_nio_file_PathsAutoTest
    {
        public void get_test_9863(string p0, string[] p1)
        {
            Paths.get(p0, p1);
        }

        public void get_test_9864(Uri p0)
        {
            Paths.get(p0);
        }
    }

    public static class Paths
    {
        public static string get(string first, string[] more)
        {
            if (more == null || more.Length == 0)
            {
                return first;
            }

            string combined = first;
            foreach (string part in more)
            {
                combined = Path.Combine(combined, part);
            }
            return combined;
        }

        public static string get(Uri uri)
        {
            if (uri == null)
            {
                throw new ArgumentNullException(nameof(uri));
            }

            if (uri.IsAbsoluteUri)
            {
                return uri.LocalPath;
            }

            return uri.OriginalString;
        }
    }
}