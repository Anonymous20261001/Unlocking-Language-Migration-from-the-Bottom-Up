using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_nio_CharBufferAutoTest
    {
        public void wrap_test_2230(CharSequence p0, int p1, int p2)
        {
            CharBuffer.Wrap(p0, p1, p2);
        }

        public void wrap_test_2231(char[] p0)
        {
            CharBuffer.Wrap(p0);
        }

        public void wrap_test_2232(CharSequence p0)
        {
            CharBuffer.Wrap(p0);
        }

        public void wrap_test_2233(char[] p0, int p1, int p2)
        {
            CharBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_2234(int p0)
        {
            CharBuffer.Allocate(p0);
        }
    }

    public class CharSequence
    {
        private string _value;

        public CharSequence(string value)
        {
            _value = value;
        }

        public static implicit operator CharSequence(string value)
        {
            return new CharSequence(value);
        }

        public static implicit operator string(CharSequence value)
        {
            return value._value;
        }

        public override string ToString()
        {
            return _value;
        }
    }

    public class CharBuffer
    {
        private char[] _buffer;
        private int _position;
        private int _limit;
        private int _mark;

        private CharBuffer(char[] buffer, int offset, int length)
        {
            _buffer = buffer;
            _position = offset;
            _limit = offset + length;
            _mark = -1;
        }

        public static CharBuffer Wrap(CharSequence sequence, int start, int end)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            if (start < 0 || end < start || end > sequence.ToString().Length)
                throw new IndexOutOfRangeException();
            return new CharBuffer(sequence.ToString().ToCharArray(), start, end - start);
        }

        public static CharBuffer Wrap(char[] array)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));
            return new CharBuffer(array, 0, array.Length);
        }

        public static CharBuffer Wrap(CharSequence sequence)
        {
            if (sequence == null)
                throw new ArgumentNullException(nameof(sequence));
            return new CharBuffer(sequence.ToString().ToCharArray(), 0, sequence.ToString().Length);
        }

        public static CharBuffer Wrap(char[] array, int offset, int length)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new IndexOutOfRangeException();
            return new CharBuffer(array, offset, length);
        }

        public static CharBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");
            return new CharBuffer(new char[capacity], 0, capacity);
        }

        public int Position
        {
            get { return _position; }
            set
            {
                if (value < 0 || value > _limit)
                    throw new IndexOutOfRangeException();
                _position = value;
            }
        }

        public int Limit
        {
            get { return _limit; }
            set
            {
                if (value < 0 || value > _buffer.Length)
                    throw new IndexOutOfRangeException();
                _limit = value;
            }
        }

        public int Capacity
        {
            get { return _buffer.Length; }
        }

        public int Remaining
        {
            get { return _limit - _position; }
        }

        public bool HasRemaining
        {
            get { return _position < _limit; }
        }

        public CharBuffer Get(char[] dst, int offset, int length)
        {
            if (dst == null)
                throw new ArgumentNullException(nameof(dst));
            if (offset < 0 || length < 0 || offset + length > dst.Length)
                throw new IndexOutOfRangeException();
            if (length > Remaining)
                throw new InvalidOperationException("Underflow");
            Array.Copy(_buffer, _position, dst, offset, length);
            _position += length;
            return this;
        }

        public CharBuffer Get(char[] dst)
        {
            return Get(dst, 0, dst.Length);
        }

        public char Get()
        {
            if (!HasRemaining)
                throw new InvalidOperationException("Underflow");
            return _buffer[_position++];
        }

        public char Get(int index)
        {
            if (index < 0 || index >= _limit)
                throw new IndexOutOfRangeException();
            return _buffer[index];
        }

        public CharBuffer Put(char c)
        {
            if (!HasRemaining)
                throw new InvalidOperationException("Overflow");
            _buffer[_position++] = c;
            return this;
        }

        public CharBuffer Put(int index, char c)
        {
            if (index < 0 || index >= _limit)
                throw new IndexOutOfRangeException();
            _buffer[index] = c;
            return this;
        }

        public CharBuffer Put(char[] src, int offset, int length)
        {
            if (src == null)
                throw new ArgumentNullException(nameof(src));
            if (offset < 0 || length < 0 || offset + length > src.Length)
                throw new IndexOutOfRangeException();
            if (length > Remaining)
                throw new InvalidOperationException("Overflow");
            Array.Copy(src, offset, _buffer, _position, length);
            _position += length;
            return this;
        }

        public CharBuffer Put(char[] src)
        {
            return Put(src, 0, src.Length);
        }

        public CharBuffer Put(CharBuffer src)
        {
            if (src == null)
                throw new ArgumentNullException(nameof(src));
            if (src.Remaining > Remaining)
                throw new InvalidOperationException("Overflow");
            while (src.HasRemaining)
            {
                Put(src.Get());
            }
            return this;
        }

        public CharBuffer Put(string src, int start, int end)
        {
            if (src == null)
                throw new ArgumentNullException(nameof(src));
            if (start < 0 || end < start || end > src.Length)
                throw new IndexOutOfRangeException();
            int length = end - start;
            if (length > Remaining)
                throw new InvalidOperationException("Overflow");
            for (int i = start; i < end; i++)
            {
                Put(src[i]);
            }
            return this;
        }

        public CharBuffer Put(string src)
        {
            return Put(src, 0, src.Length);
        }

        public CharBuffer Flip()
        {
            _limit = _position;
            _position = 0;
            _mark = -1;
            return this;
        }

        public CharBuffer Rewind()
        {
            _position = 0;
            _mark = -1;
            return this;
        }

        public CharBuffer Clear()
        {
            _position = 0;
            _limit = _buffer.Length;
            _mark = -1;
            return this;
        }

        public CharBuffer Compact()
        {
            int remaining = Remaining;
            Array.Copy(_buffer, _position, _buffer, 0, remaining);
            _position = remaining;
            _limit = _buffer.Length;
            _mark = -1;
            return this;
        }

        public CharBuffer Mark()
        {
            _mark = _position;
            return this;
        }

        public CharBuffer Reset()
        {
            if (_mark < 0)
                throw new InvalidOperationException("Invalid mark");
            _position = _mark;
            return this;
        }

        public CharBuffer Duplicate()
        {
            CharBuffer copy = new CharBuffer((char[])_buffer.Clone(), 0, _buffer.Length);
            copy._position = _position;
            copy._limit = _limit;
            copy._mark = _mark;
            return copy;
        }

        public CharBuffer Slice()
        {
            CharBuffer slice = new CharBuffer(_buffer, _position, Remaining);
            slice._position = 0;
            slice._limit = Remaining;
            slice._mark = -1;
            return slice;
        }

        public override string ToString()
        {
            return new string(_buffer, _position, Remaining);
        }

        public int Length
        {
            get { return Remaining; }
        }

        public char CharAt(int index)
        {
            if (index < 0 || index >= Remaining)
                throw new IndexOutOfRangeException();
            return _buffer[_position + index];
        }

        public CharSequence SubSequence(int start, int end)
        {
            if (start < 0 || end < start || end > Remaining)
                throw new IndexOutOfRangeException();
            return new CharSequence(new string(_buffer, _position + start, end - start));
        }

        public static CharBuffer Wrap(string str)
        {
            return Wrap(new CharSequence(str));
        }
    }
}