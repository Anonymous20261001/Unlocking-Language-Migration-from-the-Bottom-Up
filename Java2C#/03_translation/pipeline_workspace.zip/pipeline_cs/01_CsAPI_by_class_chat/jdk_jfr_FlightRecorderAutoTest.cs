namespace Generated.Test
{
    public interface FlightRecorderListener
    {
    }

    public static class FlightRecorder
    {
        public static void addListener(FlightRecorderListener listener)
        {
        }

        public static void removeListener(FlightRecorderListener listener)
        {
        }

        public static bool isAvailable()
        {
            return false;
        }

        public static FlightRecorder getFlightRecorder()
        {
            return new FlightRecorder();
        }

        public static void addPeriodicEvent(System.Type eventType, System.Action runnable)
        {
        }

        public static void removePeriodicEvent(System.Action runnable)
        {
        }

        public static void register(System.Type eventType)
        {
        }

        public static void unregister(System.Type eventType)
        {
        }

        public static bool isInitialized()
        {
            return false;
        }
    }

    public class jdk_jfr_FlightRecorderAutoTest
    {
        public void addListener_test_4816(FlightRecorderListener p0)
        {
            FlightRecorder.addListener(p0);
        }

        public void removeListener_test_4817(FlightRecorderListener p0)
        {
            FlightRecorder.removeListener(p0);
        }

        public void isAvailable_test_4818()
        {
            FlightRecorder.isAvailable();
        }

        public void getFlightRecorder_test_4819()
        {
            FlightRecorder.getFlightRecorder();
        }

        public void addPeriodicEvent_test_4820(System.Type p0, System.Action p1)
        {
            FlightRecorder.addPeriodicEvent(p0, p1);
        }

        public void removePeriodicEvent_test_4821(System.Action p0)
        {
            FlightRecorder.removePeriodicEvent(p0);
        }

        public void register_test_4822(System.Type p0)
        {
            FlightRecorder.register(p0);
        }

        public void unregister_test_4823(System.Type p0)
        {
            FlightRecorder.unregister(p0);
        }

        public void isInitialized_test_4824()
        {
            FlightRecorder.isInitialized();
        }
    }
}