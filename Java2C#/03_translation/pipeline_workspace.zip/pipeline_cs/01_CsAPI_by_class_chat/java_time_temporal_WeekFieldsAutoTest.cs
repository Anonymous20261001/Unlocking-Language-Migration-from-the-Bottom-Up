using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_time_temporal_WeekFieldsAutoTest
    {
        public void of_test_13452(CultureInfo p0)
        {
            WeekFields.Of(p0);
        }

        public void of_test_13453(DayOfWeek p0, int p1)
        {
            WeekFields.Of(p0, p1);
        }
    }

    public class WeekFields
    {
        public static WeekFields Of(CultureInfo locale)
        {
            return new WeekFields(locale);
        }

        public static WeekFields Of(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek)
        {
            return new WeekFields(firstDayOfWeek, minimalDaysInFirstWeek);
        }

        private WeekFields(CultureInfo locale)
        {
            // Implementation based on locale
        }

        private WeekFields(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek)
        {
            // Implementation
        }
    }
}