using System;

namespace Generated.Test
{
    public class Taskbar
    {
        private static Taskbar _instance;
        private static bool _isSupported = true;

        public static Taskbar GetTaskbar()
        {
            if (_instance == null)
            {
                _instance = new Taskbar();
            }
            return _instance;
        }

        public static bool IsTaskbarSupported()
        {
            return _isSupported;
        }
    }

    public class java_awt_TaskbarAutoTest
    {
        public void getTaskbar_test_12518()
        {
            Taskbar.GetTaskbar();
        }

        public void isTaskbarSupported_test_12519()
        {
            Taskbar.IsTaskbarSupported();
        }
    }
}