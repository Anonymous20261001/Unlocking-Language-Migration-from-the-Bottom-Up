using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Equivalent of jdk.dynalink.Operation (simplified interface)
    public interface Operation
    {
    }

    // Equivalent of jdk.dynalink.NamedOperation
    public class NamedOperation : Operation
    {
        private readonly Operation baseOperation;
        private readonly object name;

        public NamedOperation(Operation baseOperation, object name)
        {
            this.baseOperation = baseOperation ?? throw new ArgumentNullException(nameof(baseOperation));
            this.name = name ?? throw new ArgumentNullException(nameof(name));
        }

        public object GetName()
        {
            return name;
        }

        public static object GetName(Operation operation)
        {
            if (operation is NamedOperation namedOp)
            {
                return namedOp.GetName();
            }
            throw new ArgumentException("Operation is not a NamedOperation", nameof(operation));
        }

        public NamedOperation ChangeName(string newName)
        {
            return new NamedOperation(baseOperation, newName);
        }

        public Operation GetBaseOperation()
        {
            return baseOperation;
        }

        public static Operation GetBaseOperation(Operation operation)
        {
            if (operation is NamedOperation namedOp)
            {
                return namedOp.GetBaseOperation();
            }
            throw new ArgumentException("Operation is not a NamedOperation", nameof(operation));
        }
    }

    public class jdk_dynalink_NamedOperationAutoTest
    {
        public void getName_test_9477(Operation p0)
        {
            NamedOperation.GetName(p0);
        }

        public void getName_test_9478(Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.GetName();
        }

        public void changeName_test_9479(string p0, Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.ChangeName(p0);
        }

        public void getBaseOperation_test_9480(Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.GetBaseOperation();
        }

        public void getBaseOperation_test_9481(Operation p0)
        {
            NamedOperation.GetBaseOperation(p0);
        }
    }
}