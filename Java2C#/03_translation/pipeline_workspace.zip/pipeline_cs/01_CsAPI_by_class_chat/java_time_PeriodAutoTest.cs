using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Period
    {
        private int years;
        private int months;
        private int days;

        public Period(int years, int months, int days)
        {
            this.years = years;
            this.months = months;
            this.days = days;
        }

        public int Years => years;
        public int Months => months;
        public int Days => days;

        public static Period Of(int years, int months, int days)
        {
            return new Period(years, months, days);
        }

        public static Period From(TemporalAmount amount)
        {
            if (amount == null)
                throw new ArgumentNullException(nameof(amount));
            return amount.ToPeriod();
        }

        public static Period Parse(string text)
        {
            if (string.IsNullOrEmpty(text))
                throw new ArgumentException("Text cannot be null or empty", nameof(text));

            // Simple parser for ISO-8601 period format like "P1Y2M3D"
            string trimmed = text.Trim();
            if (!trimmed.StartsWith("P"))
                throw new FormatException("Invalid period format");

            int years = 0, months = 0, days = 0;
            int index = 1;
            string number = "";

            while (index < trimmed.Length)
            {
                char c = trimmed[index];
                if (char.IsDigit(c) || c == '-')
                {
                    number += c;
                }
                else if (c == 'Y' || c == 'M' || c == 'D' || c == 'W')
                {
                    if (number.Length == 0)
                        throw new FormatException("Invalid period format");

                    int value = int.Parse(number);
                    switch (c)
                    {
                        case 'Y':
                            years = value;
                            break;
                        case 'M':
                            months = value;
                            break;
                        case 'D':
                            days = value;
                            break;
                        case 'W':
                            days = value * 7;
                            break;
                    }
                    number = "";
                }
                else if (c == 'T')
                {
                    // Time part - not supported in this simple implementation
                    throw new FormatException("Time part not supported");
                }
                else
                {
                    throw new FormatException("Invalid period format");
                }
                index++;
            }

            if (number.Length > 0)
                throw new FormatException("Invalid period format");

            return new Period(years, months, days);
        }

        public static Period Between(LocalDate startDate, LocalDate endDate)
        {
            if (startDate == null)
                throw new ArgumentNullException(nameof(startDate));
            if (endDate == null)
                throw new ArgumentNullException(nameof(endDate));

            int years = endDate.Year - startDate.Year;
            int months = endDate.Month - startDate.Month;
            int days = endDate.Day - startDate.Day;

            if (days < 0)
            {
                months--;
                days += DateTime.DaysInMonth(startDate.Year, startDate.Month);
            }

            if (months < 0)
            {
                years--;
                months += 12;
            }

            return new Period(years, months, days);
        }

        public static Period OfDays(int days)
        {
            return new Period(0, 0, days);
        }

        public static Period OfYears(int years)
        {
            return new Period(years, 0, 0);
        }

        public static Period OfMonths(int months)
        {
            return new Period(0, months, 0);
        }

        public static Period OfWeeks(int weeks)
        {
            return new Period(0, 0, weeks * 7);
        }

        public override bool Equals(object obj)
        {
            if (obj is Period other)
            {
                return years == other.years && months == other.months && days == other.days;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(years, months, days);
        }

        public override string ToString()
        {
            return $"P{years}Y{months}M{days}D";
        }
    }

    public abstract class TemporalAmount
    {
        public abstract Period ToPeriod();
    }

    public class LocalDate
    {
        public int Year { get; }
        public int Month { get; }
        public int Day { get; }

        public LocalDate(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        public static LocalDate Of(int year, int month, int day)
        {
            return new LocalDate(year, month, day);
        }

        public override bool Equals(object obj)
        {
            if (obj is LocalDate other)
            {
                return Year == other.Year && Month == other.Month && Day == other.Day;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Year, Month, Day);
        }

        public override string ToString()
        {
            return $"{Year:D4}-{Month:D2}-{Day:D2}";
        }
    }

    public class java_time_PeriodAutoTest
    {
        public void of_test_9886(int p0, int p1, int p2)
        {
            Period.Of(p0, p1, p2);
        }

        public void from_test_9887(TemporalAmount p0)
        {
            Period.From(p0);
        }

        public void parse_test_9888(string p0)
        {
            Period.Parse(p0);
        }

        public void between_test_9889(LocalDate p0, LocalDate p1)
        {
            Period.Between(p0, p1);
        }

        public void ofDays_test_9890(int p0)
        {
            Period.OfDays(p0);
        }

        public void ofYears_test_9891(int p0)
        {
            Period.OfYears(p0);
        }

        public void ofMonths_test_9892(int p0)
        {
            Period.OfMonths(p0);
        }

        public void ofWeeks_test_9893(int p0)
        {
            Period.OfWeeks(p0);
        }
    }
}