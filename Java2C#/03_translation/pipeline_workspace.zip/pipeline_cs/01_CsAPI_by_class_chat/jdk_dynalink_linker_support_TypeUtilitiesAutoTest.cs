using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class TypeUtilities
    {
        private static readonly Dictionary<Type, Type> PrimitiveToWrapper = new Dictionary<Type, Type>
        {
            { typeof(bool), typeof(Boolean) },
            { typeof(byte), typeof(Byte) },
            { typeof(char), typeof(Char) },
            { typeof(short), typeof(Int16) },
            { typeof(int), typeof(Int32) },
            { typeof(long), typeof(Int64) },
            { typeof(float), typeof(Single) },
            { typeof(double), typeof(Double) },
            { typeof(sbyte), typeof(SByte) },
            { typeof(ushort), typeof(UInt16) },
            { typeof(uint), typeof(UInt32) },
            { typeof(ulong), typeof(UInt64) }
        };

        private static readonly Dictionary<Type, Type> WrapperToPrimitive = new Dictionary<Type, Type>
        {
            { typeof(Boolean), typeof(bool) },
            { typeof(Byte), typeof(byte) },
            { typeof(Char), typeof(char) },
            { typeof(Int16), typeof(short) },
            { typeof(Int32), typeof(int) },
            { typeof(Int64), typeof(long) },
            { typeof(Single), typeof(float) },
            { typeof(Double), typeof(double) },
            { typeof(SByte), typeof(sbyte) },
            { typeof(UInt16), typeof(ushort) },
            { typeof(UInt32), typeof(uint) },
            { typeof(UInt64), typeof(ulong) }
        };

        public static bool isWrapperType(Type type)
        {
            return WrapperToPrimitive.ContainsKey(type);
        }

        public static Type getPrimitiveType(Type type)
        {
            if (WrapperToPrimitive.TryGetValue(type, out Type primitive))
            {
                return primitive;
            }
            return null;
        }

        public static bool isSubtype(Type subType, Type superType)
        {
            if (subType == null || superType == null)
            {
                return false;
            }
            return superType.IsAssignableFrom(subType);
        }

        public static Type getWrapperType(Type type)
        {
            if (PrimitiveToWrapper.TryGetValue(type, out Type wrapper))
            {
                return wrapper;
            }
            return null;
        }

        public static bool isConvertibleWithoutLoss(Type sourceType, Type targetType)
        {
            if (sourceType == null || targetType == null)
            {
                return false;
            }
            if (sourceType == targetType)
            {
                return true;
            }
            if (sourceType == typeof(string) || targetType == typeof(string))
            {
                return false;
            }
            if (isWrapperType(sourceType))
            {
                sourceType = getPrimitiveType(sourceType);
            }
            if (isWrapperType(targetType))
            {
                targetType = getPrimitiveType(targetType);
            }
            if (sourceType == targetType)
            {
                return true;
            }
            if (sourceType == typeof(bool) || targetType == typeof(bool))
            {
                return false;
            }
            if (sourceType == typeof(char) || targetType == typeof(char))
            {
                return false;
            }
            if (sourceType == typeof(byte))
            {
                return targetType == typeof(short) || targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(short))
            {
                return targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(int))
            {
                return targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(long))
            {
                return targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(float))
            {
                return targetType == typeof(double);
            }
            if (sourceType == typeof(ushort))
            {
                return targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(uint))
            {
                return targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(ulong))
            {
                return targetType == typeof(float) || targetType == typeof(double);
            }
            return false;
        }

        public static bool isMethodInvocationConvertible(Type sourceType, Type targetType)
        {
            if (sourceType == null || targetType == null)
            {
                return false;
            }
            if (sourceType == targetType)
            {
                return true;
            }
            if (isWrapperType(sourceType))
            {
                sourceType = getPrimitiveType(sourceType);
            }
            if (isWrapperType(targetType))
            {
                targetType = getPrimitiveType(targetType);
            }
            if (sourceType == targetType)
            {
                return true;
            }
            if (sourceType == typeof(bool) || targetType == typeof(bool))
            {
                return false;
            }
            if (sourceType == typeof(char))
            {
                return targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(byte))
            {
                return targetType == typeof(short) || targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(short))
            {
                return targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(int))
            {
                return targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(long))
            {
                return targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(float))
            {
                return targetType == typeof(double);
            }
            if (sourceType == typeof(ushort))
            {
                return targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(uint))
            {
                return targetType == typeof(long) || targetType == typeof(float) || targetType == typeof(double);
            }
            if (sourceType == typeof(ulong))
            {
                return targetType == typeof(float) || targetType == typeof(double);
            }
            return false;
        }

        public static Type getPrimitiveTypeByName(string name)
        {
            switch (name)
            {
                case "boolean": return typeof(bool);
                case "byte": return typeof(byte);
                case "char": return typeof(char);
                case "short": return typeof(short);
                case "int": return typeof(int);
                case "long": return typeof(long);
                case "float": return typeof(float);
                case "double": return typeof(double);
                case "void": return typeof(void);
                default: return null;
            }
        }
    }

    public class jdk_dynalink_linker_support_TypeUtilitiesAutoTest
    {
        public void isWrapperType_test_13103(Type p0)
        {
            TypeUtilities.isWrapperType(p0);
        }

        public void getPrimitiveType_test_13104(Type p0)
        {
            TypeUtilities.getPrimitiveType(p0);
        }

        public void isSubtype_test_13105(Type p0, Type p1)
        {
            TypeUtilities.isSubtype(p0, p1);
        }

        public void getWrapperType_test_13106(Type p0)
        {
            TypeUtilities.getWrapperType(p0);
        }

        public void isConvertibleWithoutLoss_test_13107(Type p0, Type p1)
        {
            TypeUtilities.isConvertibleWithoutLoss(p0, p1);
        }

        public void isMethodInvocationConvertible_test_13108(Type p0, Type p1)
        {
            TypeUtilities.isMethodInvocationConvertible(p0, p1);
        }

        public void getPrimitiveTypeByName_test_13109(string p0)
        {
            TypeUtilities.getPrimitiveTypeByName(p0);
        }
    }
}