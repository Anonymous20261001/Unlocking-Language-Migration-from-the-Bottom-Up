namespace Generated.Test
{
    using System;
    using System.IO;

    public class java_nio_file_FileSystemsAutoTest
    {
        public void getDefault_test_4779()
        {
            FileSystems.GetDefault();
        }

        public void getFileSystem_test_4780(Uri p0)
        {
            FileSystems.GetFileSystem(p0);
        }
    }

    public static class FileSystems
    {
        public static FileSystem GetDefault()
        {
            return new FileSystem(Path.GetTempPath());
        }

        public static FileSystem GetFileSystem(Uri uri)
        {
            if (uri == null)
                throw new ArgumentNullException(nameof(uri));
            return new FileSystem(uri.LocalPath);
        }
    }

    public class FileSystem
    {
        public string RootPath { get; }

        public FileSystem(string rootPath)
        {
            RootPath = rootPath ?? throw new ArgumentNullException(nameof(rootPath));
        }
    }
}