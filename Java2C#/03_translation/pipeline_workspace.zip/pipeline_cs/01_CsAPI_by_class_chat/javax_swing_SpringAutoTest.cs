namespace Generated.Test
{
    public class Component
    {
        // Placeholder for Java's java.awt.Component
    }

    public abstract class Spring
    {
        public static Spring Height(Component c)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Max(Spring s1, Spring s2)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Scale(Spring s, float factor)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Constant(int pref)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Constant(int min, int pref, int max)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Sum(Spring s1, Spring s2)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Width(Component c)
        {
            // Placeholder implementation
            return null;
        }

        public static Spring Minus(Spring s)
        {
            // Placeholder implementation
            return null;
        }
    }

    public class javax_swing_SpringAutoTest
    {
        public void height_test_11360(Component p0)
        {
            Spring.Height(p0);
        }

        public void max_test_11361(Spring p0, Spring p1)
        {
            Spring.Max(p0, p1);
        }

        public void scale_test_11362(Spring p0, float p1)
        {
            Spring.Scale(p0, p1);
        }

        public void constant_test_11363(int p0)
        {
            Spring.Constant(p0);
        }

        public void constant_test_11364(int p0, int p1, int p2)
        {
            Spring.Constant(p0, p1, p2);
        }

        public void sum_test_11365(Spring p0, Spring p1)
        {
            Spring.Sum(p0, p1);
        }

        public void width_test_11366(Component p0)
        {
            Spring.Width(p0);
        }

        public void minus_test_11367(Spring p0)
        {
            Spring.Minus(p0);
        }
    }
}