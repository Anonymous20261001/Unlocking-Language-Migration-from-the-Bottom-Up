namespace Generated.Test
{
    using System.Security.Cryptography.X509Certificates;

    public class java_security_cert_CertPathValidatorAutoTest
    {
        public void getDefaultType_test_2101()
        {
            CertPathValidator.GetDefaultType();
        }
    }

    public static class CertPathValidator
    {
        public static string GetDefaultType()
        {
            return "PKIX";
        }
    }
}