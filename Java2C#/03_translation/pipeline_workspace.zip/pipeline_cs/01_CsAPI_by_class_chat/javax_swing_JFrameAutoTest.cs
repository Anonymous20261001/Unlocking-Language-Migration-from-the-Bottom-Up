using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Generated.Test
{
    // Minimal stubs for Java AWT/Swing types used in the tests
    public class Component : System.Windows.Forms.Control
    {
        public Component() : base() { }
    }

    public class Container : Component
    {
        public Container() : base() { }
    }

    public class Graphics
    {
        public Graphics() { }
    }

    public class Image
    {
        public Image() { }
    }

    public interface LayoutManager
    {
    }

    public class JMenuBar : Component
    {
        public JMenuBar() : base() { }
    }

    public class JLayeredPane : Container
    {
        public JLayeredPane() : base() { }
    }

    public class TransferHandler
    {
        public TransferHandler() { }
    }

    public class JRootPane : Component
    {
        public JRootPane() : base() { }
    }

    public class AccessibleContext
    {
        public AccessibleContext() { }
    }

    public class JFrame : System.Windows.Forms.Form
    {
        private static bool defaultLookAndFeelDecorated;
        private Container contentPane;
        private JMenuBar menuBar;
        private JLayeredPane layeredPane;
        private Component glassPane;
        private int defaultCloseOperation;
        private Image iconImage;
        private JRootPane rootPane;
        private TransferHandler transferHandler;
        private AccessibleContext accessibleContext;
        private LayoutManager layoutManager;

        public JFrame() : base()
        {
            contentPane = new Container();
            menuBar = new JMenuBar();
            layeredPane = new JLayeredPane();
            glassPane = new Component();
            rootPane = new JRootPane();
            accessibleContext = new AccessibleContext();
        }

        public Container GetContentPane()
        {
            return contentPane;
        }

        public static bool IsDefaultLookAndFeelDecorated()
        {
            return defaultLookAndFeelDecorated;
        }

        public JMenuBar GetJMenuBar()
        {
            return menuBar;
        }

        public void SetJMenuBar(JMenuBar menuBar)
        {
            this.menuBar = menuBar;
        }

        public void SetContentPane(Container contentPane)
        {
            this.contentPane = contentPane;
        }

        public JLayeredPane GetLayeredPane()
        {
            return layeredPane;
        }

        public void SetLayeredPane(JLayeredPane layeredPane)
        {
            this.layeredPane = layeredPane;
        }

        public Component GetGlassPane()
        {
            return glassPane;
        }

        public void SetGlassPane(Component glassPane)
        {
            this.glassPane = glassPane;
        }

        public void SetDefaultCloseOperation(int operation)
        {
            defaultCloseOperation = operation;
        }

        public int GetDefaultCloseOperation()
        {
            return defaultCloseOperation;
        }

        public void SetIconImage(Image iconImage)
        {
            this.iconImage = iconImage;
        }

        public static void SetDefaultLookAndFeelDecorated(bool decorated)
        {
            defaultLookAndFeelDecorated = decorated;
        }

        public Graphics GetGraphics()
        {
            return new Graphics();
        }

        public JRootPane GetRootPane()
        {
            return rootPane;
        }

        public void Repaint(long tm, int x, int y, int width, int height)
        {
            // No-op implementation
        }

        public void SetTransferHandler(TransferHandler transferHandler)
        {
            this.transferHandler = transferHandler;
        }

        public TransferHandler GetTransferHandler()
        {
            return transferHandler;
        }

        public AccessibleContext GetAccessibleContext()
        {
            return accessibleContext;
        }

        public void SetLayout(LayoutManager layoutManager)
        {
            this.layoutManager = layoutManager;
        }

        public void Remove(Component component)
        {
            // No-op implementation
        }

        public void Update(Graphics graphics)
        {
            // No-op implementation
        }
    }

    public class javax_swing_JFrameAutoTest
    {
        public void getContentPane_test_6253()
        {
            JFrame instance = new JFrame();
            instance.GetContentPane();
        }

        public void isDefaultLookAndFeelDecorated_test_6254()
        {
            JFrame.IsDefaultLookAndFeelDecorated();
        }

        public void getJMenuBar_test_6255()
        {
            JFrame instance = new JFrame();
            instance.GetJMenuBar();
        }

        public void setJMenuBar_test_6256(JMenuBar p0)
        {
            JFrame instance = new JFrame();
            instance.SetJMenuBar(p0);
        }

        public void setContentPane_test_6257(Container p0)
        {
            JFrame instance = new JFrame();
            instance.SetContentPane(p0);
        }

        public void getLayeredPane_test_6258()
        {
            JFrame instance = new JFrame();
            instance.GetLayeredPane();
        }

        public void setLayeredPane_test_6259(JLayeredPane p0)
        {
            JFrame instance = new JFrame();
            instance.SetLayeredPane(p0);
        }

        public void getGlassPane_test_6260()
        {
            JFrame instance = new JFrame();
            instance.GetGlassPane();
        }

        public void setGlassPane_test_6261(Component p0)
        {
            JFrame instance = new JFrame();
            instance.SetGlassPane(p0);
        }

        public void setDefaultCloseOperation_test_6262(int p0)
        {
            JFrame instance = new JFrame();
            instance.SetDefaultCloseOperation(p0);
        }

        public void getDefaultCloseOperation_test_6263()
        {
            JFrame instance = new JFrame();
            instance.GetDefaultCloseOperation();
        }

        public void setIconImage_test_6264(Image p0)
        {
            JFrame instance = new JFrame();
            instance.SetIconImage(p0);
        }

        public void setDefaultLookAndFeelDecorated_test_6265(bool p0)
        {
            JFrame.SetDefaultLookAndFeelDecorated(p0);
        }

        public void getGraphics_test_6266()
        {
            JFrame instance = new JFrame();
            instance.GetGraphics();
        }

        public void getRootPane_test_6267()
        {
            JFrame instance = new JFrame();
            instance.GetRootPane();
        }

        public void repaint_test_6268(long p0, int p1, int p2, int p3, int p4)
        {
            JFrame instance = new JFrame();
            instance.Repaint(p0, p1, p2, p3, p4);
        }

        public void setTransferHandler_test_6269(TransferHandler p0)
        {
            JFrame instance = new JFrame();
            instance.SetTransferHandler(p0);
        }

        public void getTransferHandler_test_6270()
        {
            JFrame instance = new JFrame();
            instance.GetTransferHandler();
        }

        public void getAccessibleContext_test_6271()
        {
            JFrame instance = new JFrame();
            instance.GetAccessibleContext();
        }

        public void setLayout_test_6272(LayoutManager p0)
        {
            JFrame instance = new JFrame();
            instance.SetLayout(p0);
        }

        public void remove_test_6273(Component p0)
        {
            JFrame instance = new JFrame();
            instance.Remove(p0);
        }

        public void update_test_6274(Graphics p0)
        {
            JFrame instance = new JFrame();
            instance.Update(p0);
        }
    }
}