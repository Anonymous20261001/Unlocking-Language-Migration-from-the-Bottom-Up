using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    // C# equivalent of Java's RandomGeneratorFactory
    public class RandomGeneratorFactory
    {
        private readonly string _name;

        private RandomGeneratorFactory(string name)
        {
            _name = name;
        }

        // Static method to get a factory by name
        public static RandomGeneratorFactory Of(string name)
        {
            // Simulate the behavior - return a factory with the given name
            return new RandomGeneratorFactory(name);
        }

        // Static method to get the default factory
        public static RandomGeneratorFactory GetDefault()
        {
            // Return a default factory (e.g., "L64X128MixRandom" as a common default)
            return new RandomGeneratorFactory("L64X128MixRandom");
        }

        // Static method to get all available factories
        public static IEnumerable<RandomGeneratorFactory> All()
        {
            // Return a list of common random generator factories
            return new List<RandomGeneratorFactory>
            {
                new RandomGeneratorFactory("L64X128MixRandom"),
                new RandomGeneratorFactory("L128X256MixRandom"),
                new RandomGeneratorFactory("Xoshiro256PlusPlus"),
                new RandomGeneratorFactory("SplittableRandom")
            };
        }

        // Property to get the name (for completeness)
        public string Name => _name;
    }

    public class java_util_random_RandomGeneratorFactoryAutoTest
    {
        public void of_test_10322(string p0)
        {
            RandomGeneratorFactory.Of(p0);
        }

        public void getDefault_test_10323()
        {
            RandomGeneratorFactory.GetDefault();
        }

        public void all_test_10324()
        {
            RandomGeneratorFactory.All();
        }
    }
}