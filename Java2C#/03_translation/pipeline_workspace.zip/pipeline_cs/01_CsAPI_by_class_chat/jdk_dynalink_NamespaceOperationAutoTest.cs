using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Minimal stubs for the dynalink types
    public interface Operation { }
    public interface Namespace { }

    public class NamespaceOperation : Operation
    {
        private Operation baseOperation;
        private Namespace[] namespaces;

        public NamespaceOperation(Operation baseOperation, Namespace[] namespaces)
        {
            if (baseOperation == null)
                throw new ArgumentNullException(nameof(baseOperation));
            if (namespaces == null)
                throw new ArgumentNullException(nameof(namespaces));
            if (namespaces.Length == 0)
                throw new ArgumentException("namespaces must not be empty", nameof(namespaces));

            this.baseOperation = baseOperation;
            this.namespaces = namespaces;
        }

        public static bool contains(Operation op, Operation baseOperation, Namespace namespace)
        {
            if (op == null)
                throw new ArgumentNullException(nameof(op));
            if (baseOperation == null)
                throw new ArgumentNullException(nameof(baseOperation));
            if (namespace == null)
                throw new ArgumentNullException(nameof(namespace));

            if (op is NamespaceOperation nsOp)
            {
                if (nsOp.baseOperation.Equals(baseOperation))
                {
                    foreach (var ns in nsOp.namespaces)
                    {
                        if (ns.Equals(namespace))
                            return true;
                    }
                }
            }
            return false;
        }

        public bool contains(Namespace namespace)
        {
            if (namespace == null)
                throw new ArgumentNullException(nameof(namespace));

            foreach (var ns in namespaces)
            {
                if (ns.Equals(namespace))
                    return true;
            }
            return false;
        }

        public Namespace getNamespace(int index)
        {
            if (index < 0 || index >= namespaces.Length)
                throw new IndexOutOfRangeException("Index out of bounds");
            return namespaces[index];
        }

        public static Operation getBaseOperation(Operation op)
        {
            if (op == null)
                throw new ArgumentNullException(nameof(op));

            if (op is NamespaceOperation nsOp)
                return nsOp.baseOperation;
            return op;
        }

        public Operation getBaseOperation()
        {
            return baseOperation;
        }

        public Namespace[] getNamespaces()
        {
            return namespaces;
        }

        public static Namespace[] getNamespaces(Operation op)
        {
            if (op == null)
                throw new ArgumentNullException(nameof(op));

            if (op is NamespaceOperation nsOp)
                return nsOp.namespaces;
            return new Namespace[0];
        }

        public int getNamespaceCount()
        {
            return namespaces.Length;
        }
    }

    // Test class
    public class jdk_dynalink_NamespaceOperationAutoTest
    {
        public void contains_test_9483(Operation p0, Operation p1, Namespace p2)
        {
            NamespaceOperation.contains(p0, p1, p2);
        }

        public void contains_test_9484(Namespace p0, Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.contains(p0);
        }

        public void getNamespace_test_9485(int p0, Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespace(p0);
        }

        public void getBaseOperation_test_9486(Operation p0)
        {
            NamespaceOperation.getBaseOperation(p0);
        }

        public void getBaseOperation_test_9487(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getBaseOperation();
        }

        public void getNamespaces_test_9488(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespaces();
        }

        public void getNamespaces_test_9489(Operation p0)
        {
            NamespaceOperation.getNamespaces(p0);
        }

        public void getNamespaceCount_test_9490(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespaceCount();
        }
    }
}