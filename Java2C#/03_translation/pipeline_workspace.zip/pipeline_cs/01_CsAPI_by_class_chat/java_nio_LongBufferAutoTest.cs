namespace Generated.Test
{
    public class java_nio_LongBufferAutoTest
    {
        public void wrap_test_8207(long[] p0)
        {
            LongBuffer.Wrap(p0);
        }

        public void wrap_test_8208(long[] p0, int p1, int p2)
        {
            LongBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_8209(int p0)
        {
            LongBuffer.Allocate(p0);
        }
    }

    public class LongBuffer
    {
        private long[] _buffer;
        private int _position;
        private int _limit;
        private int _offset;

        private LongBuffer(long[] buffer, int offset, int length)
        {
            _buffer = buffer;
            _offset = offset;
            _position = offset;
            _limit = offset + length;
        }

        public static LongBuffer Wrap(long[] array)
        {
            return new LongBuffer(array, 0, array.Length);
        }

        public static LongBuffer Wrap(long[] array, int offset, int length)
        {
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new ArgumentOutOfRangeException();
            return new LongBuffer(array, offset, length);
        }

        public static LongBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentOutOfRangeException();
            return new LongBuffer(new long[capacity], 0, capacity);
        }
    }
}