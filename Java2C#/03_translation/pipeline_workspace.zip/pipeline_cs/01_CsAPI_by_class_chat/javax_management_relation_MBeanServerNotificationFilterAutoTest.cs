using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class ObjectName
    {
        public string Name { get; set; }

        public ObjectName(string name)
        {
            Name = name;
        }

        public override bool Equals(object obj)
        {
            if (obj is ObjectName other)
            {
                return Name == other.Name;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Name?.GetHashCode() ?? 0;
        }
    }

    public class Notification
    {
        public string Type { get; set; }
        public object Source { get; set; }
        public long SequenceNumber { get; set; }
        public long TimeStamp { get; set; }
        public string Message { get; set; }
        public object UserData { get; set; }

        public Notification(string type, object source, long sequenceNumber)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message, object userData)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
            UserData = userData;
        }
    }

    public class MBeanServerNotificationFilter
    {
        private bool _enableAllObjectNames;
        private bool _disableAllObjectNames;
        private HashSet<ObjectName> _enabledObjectNames;
        private HashSet<ObjectName> _disabledObjectNames;

        public MBeanServerNotificationFilter()
        {
            _enableAllObjectNames = false;
            _disableAllObjectNames = false;
            _enabledObjectNames = new HashSet<ObjectName>();
            _disabledObjectNames = new HashSet<ObjectName>();
        }

        public void disableAllObjectNames()
        {
            _disableAllObjectNames = true;
            _enableAllObjectNames = false;
            _enabledObjectNames.Clear();
            _disabledObjectNames.Clear();
        }

        public void disableObjectName(ObjectName objectName)
        {
            if (objectName == null)
            {
                throw new ArgumentNullException(nameof(objectName));
            }

            if (_enableAllObjectNames)
            {
                _disabledObjectNames.Add(objectName);
            }
            else if (_disableAllObjectNames)
            {
                _disabledObjectNames.Remove(objectName);
            }
            else
            {
                _enabledObjectNames.Remove(objectName);
                _disabledObjectNames.Add(objectName);
            }
        }

        public void enableAllObjectNames()
        {
            _enableAllObjectNames = true;
            _disableAllObjectNames = false;
            _enabledObjectNames.Clear();
            _disabledObjectNames.Clear();
        }

        public void enableObjectName(ObjectName objectName)
        {
            if (objectName == null)
            {
                throw new ArgumentNullException(nameof(objectName));
            }

            if (_disableAllObjectNames)
            {
                _enabledObjectNames.Add(objectName);
            }
            else if (_enableAllObjectNames)
            {
                _enabledObjectNames.Remove(objectName);
            }
            else
            {
                _disabledObjectNames.Remove(objectName);
                _enabledObjectNames.Add(objectName);
            }
        }

        public List<ObjectName> getEnabledObjectNames()
        {
            if (_enableAllObjectNames)
            {
                return new List<ObjectName>();
            }
            return new List<ObjectName>(_enabledObjectNames);
        }

        public List<ObjectName> getDisabledObjectNames()
        {
            if (_disableAllObjectNames)
            {
                return new List<ObjectName>();
            }
            return new List<ObjectName>(_disabledObjectNames);
        }

        public bool isNotificationEnabled(Notification notification)
        {
            if (notification == null)
            {
                throw new ArgumentNullException(nameof(notification));
            }

            // Check if the notification is an MBeanServerNotification
            if (!(notification is MBeanServerNotification mbeanNotification))
            {
                return false;
            }

            ObjectName objectName = mbeanNotification.MBeanName;

            if (_enableAllObjectNames)
            {
                return !_disabledObjectNames.Contains(objectName);
            }
            else if (_disableAllObjectNames)
            {
                return _enabledObjectNames.Contains(objectName);
            }
            else
            {
                return _enabledObjectNames.Contains(objectName);
            }
        }
    }

    public class MBeanServerNotification : Notification
    {
        public ObjectName MBeanName { get; set; }

        public MBeanServerNotification(string type, object source, long sequenceNumber, ObjectName mbeanName)
            : base(type, source, sequenceNumber)
        {
            MBeanName = mbeanName;
        }
    }

    public class javax_management_relation_MBeanServerNotificationFilterAutoTest
    {
        public void disableAllObjectNames_test_8454()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.disableAllObjectNames();
        }

        public void disableObjectName_test_8455(ObjectName p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.disableObjectName(p0);
        }

        public void enableAllObjectNames_test_8456()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.enableAllObjectNames();
        }

        public void enableObjectName_test_8457(ObjectName p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.enableObjectName(p0);
        }

        public void getEnabledObjectNames_test_8458()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.getEnabledObjectNames();
        }

        public void getDisabledObjectNames_test_8459()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.getDisabledObjectNames();
        }

        public void isNotificationEnabled_test_8460(Notification p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.isNotificationEnabled(p0);
        }
    }
}