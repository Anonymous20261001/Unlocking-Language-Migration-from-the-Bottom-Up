namespace Generated.Test
{
    using System;

    public class java_nio_channels_spi_SelectorProviderAutoTest
    {
        public void provider_test_11022()
        {
            SelectorProvider.Provider();
        }
    }

    public abstract class SelectorProvider
    {
        private static SelectorProvider _provider;

        public static SelectorProvider Provider()
        {
            if (_provider == null)
            {
                _provider = new DefaultSelectorProvider();
            }
            return _provider;
        }
    }

    internal class DefaultSelectorProvider : SelectorProvider
    {
    }
}