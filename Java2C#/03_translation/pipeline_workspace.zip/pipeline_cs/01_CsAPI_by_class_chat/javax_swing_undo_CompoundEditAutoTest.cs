namespace Generated.Test
{
    public interface UndoableEdit
    {
        bool AddEdit(UndoableEdit anEdit);
        bool ReplaceEdit(UndoableEdit anEdit);
        bool AddEdit2(UndoableEdit anEdit);
        bool Significant { get; }
        string PresentationName { get; }
        string UndoPresentationName { get; }
        string RedoPresentationName { get; }
        void Undo();
        bool CanUndo();
        void Redo();
        bool CanRedo();
        void Die();
    }

    public class CompoundEdit : UndoableEdit
    {
        private System.Collections.Generic.List<UndoableEdit> edits = new System.Collections.Generic.List<UndoableEdit>();
        private bool inProgress = true;
        private bool hasBeenDone = false;
        private bool alive = true;

        public virtual bool AddEdit(UndoableEdit anEdit)
        {
            if (!inProgress)
            {
                return false;
            }
            edits.Add(anEdit);
            return true;
        }

        public virtual bool ReplaceEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual bool AddEdit2(UndoableEdit anEdit)
        {
            return AddEdit(anEdit);
        }

        public virtual bool Significant
        {
            get
            {
                foreach (UndoableEdit edit in edits)
                {
                    if (edit.Significant)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public virtual string PresentationName
        {
            get { return ""; }
        }

        public virtual string UndoPresentationName
        {
            get { return "Undo " + PresentationName; }
        }

        public virtual string RedoPresentationName
        {
            get { return "Redo " + PresentationName; }
        }

        public virtual void Undo()
        {
            if (!CanUndo())
            {
                throw new System.InvalidOperationException("Cannot undo");
            }
            for (int i = edits.Count - 1; i >= 0; i--)
            {
                edits[i].Undo();
            }
            hasBeenDone = false;
        }

        public virtual bool CanUndo()
        {
            return alive && !inProgress && hasBeenDone;
        }

        public virtual void Redo()
        {
            if (!CanRedo())
            {
                throw new System.InvalidOperationException("Cannot redo");
            }
            foreach (UndoableEdit edit in edits)
            {
                edit.Redo();
            }
            hasBeenDone = true;
        }

        public virtual bool CanRedo()
        {
            return alive && !inProgress && !hasBeenDone;
        }

        public virtual void Die()
        {
            alive = false;
            foreach (UndoableEdit edit in edits)
            {
                edit.Die();
            }
        }

        public virtual bool IsInProgress()
        {
            return inProgress;
        }

        public virtual void End()
        {
            inProgress = false;
        }

        // Explicit interface implementations to match Java interface
        bool UndoableEdit.AddEdit(UndoableEdit anEdit) => AddEdit(anEdit);
        bool UndoableEdit.ReplaceEdit(UndoableEdit anEdit) => ReplaceEdit(anEdit);
        bool UndoableEdit.AddEdit2(UndoableEdit anEdit) => AddEdit2(anEdit);
        bool UndoableEdit.Significant => Significant;
        string UndoableEdit.PresentationName => PresentationName;
        string UndoableEdit.UndoPresentationName => UndoPresentationName;
        string UndoableEdit.RedoPresentationName => RedoPresentationName;
        void UndoableEdit.Undo() => Undo();
        bool UndoableEdit.CanUndo() => CanUndo();
        void UndoableEdit.Redo() => Redo();
        bool UndoableEdit.CanRedo() => CanRedo();
        void UndoableEdit.Die() => Die();
    }

    public class javax_swing_undo_CompoundEditAutoTest
    {
        public void addEdit_test_2699(UndoableEdit p0)
        {
            CompoundEdit instance = new CompoundEdit();
            instance.AddEdit(p0);
        }

        public void redo_test_2700()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.Redo();
        }

        public void undo_test_2701()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.Undo();
        }

        public void getPresentationName_test_2702()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.PresentationName.ToString();
        }

        public void isSignificant_test_2703()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.Significant.ToString();
        }

        public void getUndoPresentationName_test_2704()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.UndoPresentationName.ToString();
        }

        public void getRedoPresentationName_test_2705()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.RedoPresentationName.ToString();
        }

        public void die_test_2706()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.Die();
        }

        public void isInProgress_test_2707()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.IsInProgress();
        }

        public void canUndo_test_2708()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.CanUndo();
        }

        public void canRedo_test_2709()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.CanRedo();
        }

        public void end_test_2710()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.End();
        }
    }
}