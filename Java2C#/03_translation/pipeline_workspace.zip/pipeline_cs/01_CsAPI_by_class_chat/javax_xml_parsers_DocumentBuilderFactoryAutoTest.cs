using System;
using System.Xml;

namespace Generated.Test
{
    public class javax_xml_parsers_DocumentBuilderFactoryAutoTest
    {
        public void newDefaultInstance_test_4194()
        {
            DocumentBuilderFactory.NewDefaultInstance();
        }

        public void newDefaultNSInstance_test_4195()
        {
            DocumentBuilderFactory.NewDefaultNSInstance();
        }

        public void newNSInstance_test_4196()
        {
            DocumentBuilderFactory.NewNSInstance();
        }

        public void newNSInstance_test_4197(string p0, ClassLoader p1)
        {
            DocumentBuilderFactory.NewNSInstance(p0, p1);
        }

        public void newInstance_test_4198(string p0, ClassLoader p1)
        {
            DocumentBuilderFactory.NewInstance(p0, p1);
        }

        public void newInstance_test_4199()
        {
            DocumentBuilderFactory.NewInstance();
        }
    }

    public class DocumentBuilderFactory
    {
        public static DocumentBuilderFactory NewDefaultInstance()
        {
            return new DocumentBuilderFactory();
        }

        public static DocumentBuilderFactory NewDefaultNSInstance()
        {
            return new DocumentBuilderFactory();
        }

        public static DocumentBuilderFactory NewNSInstance()
        {
            return new DocumentBuilderFactory();
        }

        public static DocumentBuilderFactory NewNSInstance(string factoryId, ClassLoader classLoader)
        {
            return new DocumentBuilderFactory();
        }

        public static DocumentBuilderFactory NewInstance(string factoryId, ClassLoader classLoader)
        {
            return new DocumentBuilderFactory();
        }

        public static DocumentBuilderFactory NewInstance()
        {
            return new DocumentBuilderFactory();
        }
    }

    public class ClassLoader
    {
        // Placeholder class for ClassLoader
    }
}