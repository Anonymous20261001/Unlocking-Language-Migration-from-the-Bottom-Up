namespace Generated.Test
{
    public class javax_imageio_ImageIOAutoTest
    {
        public void setUseCache_test_5658(bool p0)
        {
            ImageIO.SetUseCache(p0);
        }

        public void getUseCache_test_5659()
        {
            ImageIO.GetUseCache();
        }

        public void setCacheDirectory_test_5660(File p0)
        {
            ImageIO.SetCacheDirectory(p0);
        }

        public void getCacheDirectory_test_5661()
        {
            ImageIO.GetCacheDirectory();
        }

        public void getImageReaders_test_5662(object p0)
        {
            ImageIO.GetImageReaders(p0);
        }

        public void getImageWriters_test_5663(ImageTypeSpecifier p0, string p1)
        {
            ImageIO.GetImageWriters(p0, p1);
        }

        public void scanForPlugins_test_5664()
        {
            ImageIO.ScanForPlugins();
        }

        public void getReaderFormatNames_test_5665()
        {
            ImageIO.GetReaderFormatNames();
        }

        public void getReaderMIMETypes_test_5666()
        {
            ImageIO.GetReaderMIMETypes();
        }

        public void getReaderFileSuffixes_test_5667()
        {
            ImageIO.GetReaderFileSuffixes();
        }

        public void getImageReadersByFormatName_test_5668(string p0)
        {
            ImageIO.GetImageReadersByFormatName(p0);
        }

        public void getImageReadersBySuffix_test_5669(string p0)
        {
            ImageIO.GetImageReadersBySuffix(p0);
        }

        public void getImageReadersByMIMEType_test_5670(string p0)
        {
            ImageIO.GetImageReadersByMIMEType(p0);
        }

        public void getWriterFormatNames_test_5671()
        {
            ImageIO.GetWriterFormatNames();
        }

        public void getWriterMIMETypes_test_5672()
        {
            ImageIO.GetWriterMIMETypes();
        }

        public void getWriterFileSuffixes_test_5673()
        {
            ImageIO.GetWriterFileSuffixes();
        }

        public void getImageWritersByFormatName_test_5674(string p0)
        {
            ImageIO.GetImageWritersByFormatName(p0);
        }

        public void getImageWritersBySuffix_test_5675(string p0)
        {
            ImageIO.GetImageWritersBySuffix(p0);
        }

        public void getImageWritersByMIMEType_test_5676(string p0)
        {
            ImageIO.GetImageWritersByMIMEType(p0);
        }

        public void getImageWriter_test_5677(ImageReader p0)
        {
            ImageIO.GetImageWriter(p0);
        }

        public void getImageTranscoders_test_5678(ImageReader p0, ImageWriter p1)
        {
            ImageIO.GetImageTranscoders(p0, p1);
        }

        public void getImageReader_test_5679(ImageWriter p0)
        {
            ImageIO.GetImageReader(p0);
        }
    }

    public class ImageIO
    {
        public static void SetUseCache(bool useCache) { }
        public static bool GetUseCache() { return false; }
        public static void SetCacheDirectory(File cacheDirectory) { }
        public static File GetCacheDirectory() { return null; }
        public static System.Collections.IEnumerator GetImageReaders(object input) { return null; }
        public static System.Collections.IEnumerator GetImageWriters(ImageTypeSpecifier type, string formatName) { return null; }
        public static void ScanForPlugins() { }
        public static string[] GetReaderFormatNames() { return null; }
        public static string[] GetReaderMIMETypes() { return null; }
        public static string[] GetReaderFileSuffixes() { return null; }
        public static System.Collections.IEnumerator GetImageReadersByFormatName(string formatName) { return null; }
        public static System.Collections.IEnumerator GetImageReadersBySuffix(string fileSuffix) { return null; }
        public static System.Collections.IEnumerator GetImageReadersByMIMEType(string mimeType) { return null; }
        public static string[] GetWriterFormatNames() { return null; }
        public static string[] GetWriterMIMETypes() { return null; }
        public static string[] GetWriterFileSuffixes() { return null; }
        public static System.Collections.IEnumerator GetImageWritersByFormatName(string formatName) { return null; }
        public static System.Collections.IEnumerator GetImageWritersBySuffix(string fileSuffix) { return null; }
        public static System.Collections.IEnumerator GetImageWritersByMIMEType(string mimeType) { return null; }
        public static ImageWriter GetImageWriter(ImageReader reader) { return null; }
        public static System.Collections.IEnumerator GetImageTranscoders(ImageReader reader, ImageWriter writer) { return null; }
        public static ImageReader GetImageReader(ImageWriter writer) { return null; }
    }

    public class File
    {
        public File(string path) { }
    }

    public class ImageTypeSpecifier
    {
    }

    public class ImageReader
    {
    }

    public class ImageWriter
    {
    }
}