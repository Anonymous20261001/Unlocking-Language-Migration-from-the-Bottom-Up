using System;

namespace Generated.Test
{
    public class java_util_OptionalAutoTest
    {
        public void of_test_9689(object p0)
        {
            Optional.Of(p0);
        }

        public void empty_test_9690()
        {
            Optional.Empty();
        }

        public void ofNullable_test_9691(object p0)
        {
            Optional.OfNullable(p0);
        }
    }

    public class Optional
    {
        private readonly object _value;
        private readonly bool _hasValue;

        private Optional(object value, bool hasValue)
        {
            _value = value;
            _hasValue = hasValue;
        }

        public static Optional Of(object value)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value));
            return new Optional(value, true);
        }

        public static Optional Empty()
        {
            return new Optional(null, false);
        }

        public static Optional OfNullable(object value)
        {
            return value == null ? Empty() : Of(value);
        }

        public bool IsPresent => _hasValue;
        public object Value => _hasValue ? _value : throw new InvalidOperationException("No value present");
    }
}