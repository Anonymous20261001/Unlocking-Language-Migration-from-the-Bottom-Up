using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Simplified C# equivalents of the Java classes
    public class Notification
    {
        // Minimal implementation for testing purposes
    }

    public interface NotificationFilter
    {
        bool IsNotificationEnabled(Notification notification);
    }

    public interface NotificationListener
    {
        void HandleNotification(Notification notification, object handback);
    }

    public class MBeanServerDelegate
    {
        private List<NotificationListener> listeners = new List<NotificationListener>();
        private List<NotificationFilter> filters = new List<NotificationFilter>();
        private List<object> handbacks = new List<object>();

        public string GetMBeanServerId()
        {
            return "default-server-id";
        }

        public string GetSpecificationName()
        {
            return "JMX";
        }

        public string GetSpecificationVersion()
        {
            return "1.4";
        }

        public string GetSpecificationVendor()
        {
            return "Oracle Corporation";
        }

        public string GetImplementationName()
        {
            return "Default MBeanServer";
        }

        public string GetImplementationVersion()
        {
            return "1.0";
        }

        public string GetImplementationVendor()
        {
            return "Default Vendor";
        }

        public void SendNotification(Notification notification)
        {
            for (int i = 0; i < listeners.Count; i++)
            {
                if (filters[i] == null || filters[i].IsNotificationEnabled(notification))
                {
                    listeners[i].HandleNotification(notification, handbacks[i]);
                }
            }
        }

        public void AddNotificationListener(NotificationListener listener, NotificationFilter filter, object handback)
        {
            listeners.Add(listener);
            filters.Add(filter);
            handbacks.Add(handback);
        }

        public string[] GetNotificationInfo()
        {
            return new string[] { "notification.info" };
        }
    }

    public class javax_management_MBeanServerDelegateAutoTest
    {
        public void getNotificationInfo_test_8432()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetNotificationInfo();
        }

        public void sendNotification_test_8433(Notification p0)
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.SendNotification(p0);
        }

        public void getMBeanServerId_test_8434()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetMBeanServerId();
        }

        public void getSpecificationName_test_8435()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationName();
        }

        public void getImplementationName_test_8436()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationName();
        }

        public void addNotificationListener_test_8437(NotificationListener p0, NotificationFilter p1, object p2)
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.AddNotificationListener(p0, p1, p2);
        }

        public void getSpecificationVersion_test_8438()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationVersion();
        }

        public void getSpecificationVendor_test_8439()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationVendor();
        }

        public void getImplementationVersion_test_8440()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationVersion();
        }

        public void getImplementationVendor_test_8441()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationVendor();
        }
    }
}