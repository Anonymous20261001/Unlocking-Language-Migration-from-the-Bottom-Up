namespace Generated.Test
{
    using System;
    using System.IO;

    public class UnixDomainSocketAddress
    {
        public string Path { get; private set; }

        private UnixDomainSocketAddress(string path)
        {
            Path = path;
        }

        public static UnixDomainSocketAddress Of(string path)
        {
            if (path == null)
                throw new ArgumentNullException(nameof(path));
            return new UnixDomainSocketAddress(path);
        }

        public static UnixDomainSocketAddress Of(Path path)
        {
            if (path == null)
                throw new ArgumentNullException(nameof(path));
            return new UnixDomainSocketAddress(path.ToString());
        }

        public override string ToString()
        {
            return Path;
        }
    }

    public class java_net_UnixDomainSocketAddressAutoTest
    {
        public void of_test_13210(Path p0)
        {
            UnixDomainSocketAddress.Of(p0);
        }

        public void of_test_13211(string p0)
        {
            UnixDomainSocketAddress.Of(p0);
        }
    }
}