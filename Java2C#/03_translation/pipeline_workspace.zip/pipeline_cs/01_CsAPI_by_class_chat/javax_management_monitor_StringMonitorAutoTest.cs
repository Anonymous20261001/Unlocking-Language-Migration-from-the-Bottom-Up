using System;
using System.Collections.Generic;
using System.Collections;

namespace Generated.Test
{
    // Simplified ObjectName equivalent
    public class ObjectName
    {
        private string _name;
        
        public ObjectName(string name)
        {
            _name = name;
        }
        
        public override string ToString()
        {
            return _name;
        }
    }
    
    // Simplified NotificationInfo equivalent
    public class NotificationInfo
    {
        public string[] Types { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        
        public NotificationInfo(string[] types, string name, string description)
        {
            Types = types;
            Name = name;
            Description = description;
        }
    }
    
    // Simplified Notification equivalent
    public class Notification
    {
        public string Type { get; set; }
        public object Source { get; set; }
        public long SequenceNumber { get; set; }
        public long TimeStamp { get; set; }
        public string Message { get; set; }
        
        public Notification(string type, object source, long sequenceNumber)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = DateTime.UtcNow.Ticks;
        }
        
        public Notification(string type, object source, long sequenceNumber, long timeStamp)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
        }
        
        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
        }
    }
    
    // Simplified NotificationBroadcasterSupport equivalent
    public class NotificationBroadcasterSupport
    {
        protected List<NotificationListener> _listeners = new List<NotificationListener>();
        protected List<NotificationFilter> _filters = new List<NotificationFilter>();
        protected List<object> _handbacks = new List<object>();
        protected long _sequenceNumber = 0;
        
        public void AddNotificationListener(NotificationListener listener, NotificationFilter filter, object handback)
        {
            _listeners.Add(listener);
            _filters.Add(filter);
            _handbacks.Add(handback);
        }
        
        public void RemoveNotificationListener(NotificationListener listener)
        {
            int index = _listeners.IndexOf(listener);
            if (index >= 0)
            {
                _listeners.RemoveAt(index);
                _filters.RemoveAt(index);
                _handbacks.RemoveAt(index);
            }
        }
        
        public void RemoveNotificationListener(NotificationListener listener, NotificationFilter filter, object handback)
        {
            for (int i = _listeners.Count - 1; i >= 0; i--)
            {
                if (_listeners[i] == listener && _filters[i] == filter && _handbacks[i] == handback)
                {
                    _listeners.RemoveAt(i);
                    _filters.RemoveAt(i);
                    _handbacks.RemoveAt(i);
                }
            }
        }
        
        protected void SendNotification(Notification notification)
        {
            notification.SequenceNumber = ++_sequenceNumber;
            for (int i = 0; i < _listeners.Count; i++)
            {
                if (_filters[i] == null || _filters[i].IsNotificationEnabled(notification))
                {
                    _listeners[i].HandleNotification(notification, _handbacks[i]);
                }
            }
        }
        
        public virtual NotificationInfo[] GetNotificationInfo()
        {
            return new NotificationInfo[0];
        }
    }
    
    // Simplified NotificationListener equivalent
    public interface NotificationListener
    {
        void HandleNotification(Notification notification, object handback);
    }
    
    // Simplified NotificationFilter equivalent
    public interface NotificationFilter
    {
        bool IsNotificationEnabled(Notification notification);
    }
    
    // Simplified Monitor equivalent
    public abstract class Monitor : NotificationBroadcasterSupport
    {
        protected ObjectName _observedObject;
        protected string _observedAttribute;
        protected int _granularityPeriod = 10000;
        protected bool _isActive = false;
        
        public ObjectName ObservedObject
        {
            get { return _observedObject; }
            set { _observedObject = value; }
        }
        
        public string ObservedAttribute
        {
            get { return _observedAttribute; }
            set { _observedAttribute = value; }
        }
        
        public int GranularityPeriod
        {
            get { return _granularityPeriod; }
            set { _granularityPeriod = value; }
        }
        
        public bool IsActive
        {
            get { return _isActive; }
        }
        
        public virtual void Start()
        {
            _isActive = true;
        }
        
        public virtual void Stop()
        {
            _isActive = false;
        }
    }
    
    // Simplified StringMonitor equivalent
    public class StringMonitor : Monitor
    {
        private string _stringToCompare;
        private bool _notifyMatch = false;
        private bool _notifyDiffer = false;
        private object _derivedGauge;
        private long _derivedGaugeTimeStamp;
        
        public string StringToCompare
        {
            get { return _stringToCompare; }
            set { _stringToCompare = value; }
        }
        
        public bool NotifyMatch
        {
            get { return _notifyMatch; }
            set { _notifyMatch = value; }
        }
        
        public bool NotifyDiffer
        {
            get { return _notifyDiffer; }
            set { _notifyDiffer = value; }
        }
        
        public object GetDerivedGauge()
        {
            return _derivedGauge;
        }
        
        public object GetDerivedGauge(ObjectName objectName)
        {
            return _derivedGauge;
        }
        
        public long GetDerivedGaugeTimeStamp()
        {
            return _derivedGaugeTimeStamp;
        }
        
        public long GetDerivedGaugeTimeStamp(ObjectName objectName)
        {
            return _derivedGaugeTimeStamp;
        }
        
        public string GetStringToCompare()
        {
            return _stringToCompare;
        }
        
        public void SetStringToCompare(string value)
        {
            _stringToCompare = value;
        }
        
        public bool GetNotifyMatch()
        {
            return _notifyMatch;
        }
        
        public void SetNotifyMatch(bool value)
        {
            _notifyMatch = value;
        }
        
        public bool GetNotifyDiffer()
        {
            return _notifyDiffer;
        }
        
        public void SetNotifyDiffer(bool value)
        {
            _notifyDiffer = value;
        }
        
        public override NotificationInfo[] GetNotificationInfo()
        {
            return new NotificationInfo[]
            {
                new NotificationInfo(new string[] { "jmx.monitor.string.matches" }, "StringMonitor matches notification", "The observed string matches the string to compare"),
                new NotificationInfo(new string[] { "jmx.monitor.string.differs" }, "StringMonitor differs notification", "The observed string differs from the string to compare"),
                new NotificationInfo(new string[] { "jmx.monitor.error.mbean" }, "MBean error notification", "An error occurred while trying to access the MBean"),
                new NotificationInfo(new string[] { "jmx.monitor.error.attribute" }, "Attribute error notification", "An error occurred while trying to access the attribute"),
                new NotificationInfo(new string[] { "jmx.monitor.error.runtime" }, "Runtime error notification", "A runtime error occurred"),
                new NotificationInfo(new string[] { "jmx.monitor.error.threshold" }, "Threshold error notification", "The threshold value is invalid")
            };
        }
        
        public void Start()
        {
            base.Start();
        }
        
        public void Stop()
        {
            base.Stop();
        }
    }
    
    public class javax_management_monitor_StringMonitorAutoTest
    {
        public void getNotificationInfo_test_11889()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetNotificationInfo();
        }
        
        public void getDerivedGauge_test_11890()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetDerivedGauge();
        }
        
        public void getDerivedGauge_test_11891(ObjectName p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.GetDerivedGauge(p0);
        }
        
        public void getDerivedGaugeTimeStamp_test_11892(ObjectName p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.GetDerivedGaugeTimeStamp(p0);
        }
        
        public void getDerivedGaugeTimeStamp_test_11893()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetDerivedGaugeTimeStamp();
        }
        
        public void getStringToCompare_test_11894()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetStringToCompare();
        }
        
        public void setStringToCompare_test_11895(string p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.SetStringToCompare(p0);
        }
        
        public void getNotifyMatch_test_11896()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetNotifyMatch();
        }
        
        public void setNotifyMatch_test_11897(bool p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.SetNotifyMatch(p0);
        }
        
        public void getNotifyDiffer_test_11898()
        {
            StringMonitor instance = new StringMonitor();
            instance.GetNotifyDiffer();
        }
        
        public void setNotifyDiffer_test_11899(bool p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.SetNotifyDiffer(p0);
        }
        
        public void start_test_11900()
        {
            StringMonitor instance = new StringMonitor();
            instance.Start();
        }
        
        public void stop_test_11901()
        {
            StringMonitor instance = new StringMonitor();
            instance.Stop();
        }
    }
}