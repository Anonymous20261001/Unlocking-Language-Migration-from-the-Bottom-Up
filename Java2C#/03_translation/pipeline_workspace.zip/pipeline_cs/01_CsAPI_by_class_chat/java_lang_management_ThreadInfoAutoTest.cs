namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class CompositeData
    {
        private readonly Dictionary<string, object> _items;

        public CompositeData()
        {
            _items = new Dictionary<string, object>();
        }

        public object Get(string key)
        {
            if (_items.TryGetValue(key, out var value))
            {
                return value;
            }
            return null;
        }

        public void Put(string key, object value)
        {
            _items[key] = value;
        }

        public bool ContainsKey(string key)
        {
            return _items.ContainsKey(key);
        }

        public string[] GetKeys()
        {
            return new List<string>(_items.Keys).ToArray();
        }
    }

    public class ThreadInfo
    {
        public static ThreadInfo From(CompositeData data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(nameof(data));
            }

            var threadName = data.Get("threadName") as string;
            var threadId = data.Get("threadId") is long ? (long)data.Get("threadId") : 0;
            var threadState = data.Get("threadState") as string;
            var blockedTime = data.Get("blockedTime") is long ? (long)data.Get("blockedTime") : 0;
            var blockedCount = data.Get("blockedCount") is long ? (long)data.Get("blockedCount") : 0;
            var waitedTime = data.Get("waitedTime") is long ? (long)data.Get("waitedTime") : 0;
            var waitedCount = data.Get("waitedCount") is long ? (long)data.Get("waitedCount") : 0;
            var lockName = data.Get("lockName") as string;
            var lockOwnerName = data.Get("lockOwnerName") as string;
            var lockOwnerId = data.Get("lockOwnerId") is long ? (long)data.Get("lockOwnerId") : 0;
            var inNative = data.Get("inNative") is bool ? (bool)data.Get("inNative") : false;
            var suspended = data.Get("suspended") is bool ? (bool)data.Get("suspended") : false;
            var stackTrace = data.Get("stackTrace") as object[];

            return new ThreadInfo(
                threadName,
                threadId,
                threadState,
                blockedTime,
                blockedCount,
                waitedTime,
                waitedCount,
                lockName,
                lockOwnerName,
                lockOwnerId,
                inNative,
                suspended,
                stackTrace);
        }

        public string ThreadName { get; }
        public long ThreadId { get; }
        public string ThreadState { get; }
        public long BlockedTime { get; }
        public long BlockedCount { get; }
        public long WaitedTime { get; }
        public long WaitedCount { get; }
        public string LockName { get; }
        public string LockOwnerName { get; }
        public long LockOwnerId { get; }
        public bool InNative { get; }
        public bool Suspended { get; }
        public object[] StackTrace { get; }

        public ThreadInfo(
            string threadName,
            long threadId,
            string threadState,
            long blockedTime,
            long blockedCount,
            long waitedTime,
            long waitedCount,
            string lockName,
            string lockOwnerName,
            long lockOwnerId,
            bool inNative,
            bool suspended,
            object[] stackTrace)
        {
            ThreadName = threadName;
            ThreadId = threadId;
            ThreadState = threadState;
            BlockedTime = blockedTime;
            BlockedCount = blockedCount;
            WaitedTime = waitedTime;
            WaitedCount = waitedCount;
            LockName = lockName;
            LockOwnerName = lockOwnerName;
            LockOwnerId = lockOwnerId;
            InNative = inNative;
            Suspended = suspended;
            StackTrace = stackTrace;
        }
    }

    public class java_lang_management_ThreadInfoAutoTest
    {
        public void from_test_12708(CompositeData p0)
        {
            ThreadInfo.From(p0);
        }
    }
}