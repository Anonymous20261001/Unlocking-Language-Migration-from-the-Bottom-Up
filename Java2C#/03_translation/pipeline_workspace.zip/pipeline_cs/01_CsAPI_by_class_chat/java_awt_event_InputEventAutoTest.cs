namespace Generated.Test
{
    public class java_awt_event_InputEventAutoTest
    {
        public void getModifiersExText_test_5831(int p0)
        {
            InputEvent.GetModifiersExText(p0);
        }

        public void getMaskForButton_test_5832(int p0)
        {
            InputEvent.GetMaskForButton(p0);
        }
    }

    public static class InputEvent
    {
        public static string GetModifiersExText(int modifiers)
        {
            // Java's InputEvent.getModifiersExText returns a string describing the extended modifier keys
            // and mouse buttons (e.g., "Ctrl+Shift", "Button1", etc.)
            // This is a simplified implementation covering common modifiers.
            var parts = new System.Collections.Generic.List<string>();

            if ((modifiers & 0x40) != 0) // SHIFT_DOWN_MASK
                parts.Add("Shift");
            if ((modifiers & 0x80) != 0) // CTRL_DOWN_MASK
                parts.Add("Ctrl");
            if ((modifiers & 0x100) != 0) // META_DOWN_MASK
                parts.Add("Meta");
            if ((modifiers & 0x200) != 0) // ALT_DOWN_MASK
                parts.Add("Alt");
            if ((modifiers & 0x400) != 0) // ALT_GRAPH_DOWN_MASK
                parts.Add("Alt Graph");
            if ((modifiers & 0x1000) != 0) // BUTTON1_DOWN_MASK
                parts.Add("Button1");
            if ((modifiers & 0x2000) != 0) // BUTTON2_DOWN_MASK
                parts.Add("Button2");
            if ((modifiers & 0x4000) != 0) // BUTTON3_DOWN_MASK
                parts.Add("Button3");

            return string.Join("+", parts);
        }

        public static int GetMaskForButton(int button)
        {
            // Java's InputEvent.getMaskForButton returns the mask for the given button number
            // Button 1 -> BUTTON1_DOWN_MASK (0x1000)
            // Button 2 -> BUTTON2_DOWN_MASK (0x2000)
            // Button 3 -> BUTTON3_DOWN_MASK (0x4000)
            // Other buttons are not supported in Java's standard implementation
            switch (button)
            {
                case 1:
                    return 0x1000;
                case 2:
                    return 0x2000;
                case 3:
                    return 0x4000;
                default:
                    return 0;
            }
        }
    }
}