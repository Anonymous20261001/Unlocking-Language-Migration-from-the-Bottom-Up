using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Event listener interfaces (simplified equivalents)
    public interface EventListener { }
    public interface ActionListener : EventListener { }
    public interface AdjustmentListener : EventListener { }
    public interface ComponentListener : EventListener { }
    public interface ContainerListener : EventListener { }
    public interface FocusListener : EventListener { }
    public interface HierarchyBoundsListener : EventListener { }
    public interface HierarchyListener : EventListener { }
    public interface InputMethodListener : EventListener { }
    public interface ItemListener : EventListener { }
    public interface KeyListener : EventListener { }
    public interface MouseListener : EventListener { }
    public interface MouseMotionListener : EventListener { }
    public interface MouseWheelListener : EventListener { }
    public interface TextListener : EventListener { }
    public interface WindowFocusListener : EventListener { }
    public interface WindowListener : EventListener { }
    public interface WindowStateListener : EventListener { }

    // AWTEventMulticaster equivalent
    public static class AWTEventMulticaster
    {
        // Generic getListeners method
        public static EventListener[] getListeners(EventListener l, Type listenerType)
        {
            if (l == null)
                return new EventListener[0];
            
            var result = new List<EventListener>();
            CollectListeners(l, listenerType, result);
            return result.ToArray();
        }

        private static void CollectListeners(EventListener l, Type listenerType, List<EventListener> result)
        {
            if (l == null)
                return;

            // Check if this is a multicaster (has a and b fields)
            var type = l.GetType();
            var aField = type.GetField("a");
            var bField = type.GetField("b");
            
            if (aField != null && bField != null)
            {
                var a = aField.GetValue(l) as EventListener;
                var b = bField.GetValue(l) as EventListener;
                CollectListeners(a, listenerType, result);
                CollectListeners(b, listenerType, result);
            }
            else if (listenerType.IsInstanceOfType(l))
            {
                result.Add(l);
            }
        }

        // Generic remove method
        public static EventListener remove(EventListener l, EventListener oldl)
        {
            if (l == oldl || l == null)
                return null;
            if (oldl == null)
                return l;

            var type = l.GetType();
            var aField = type.GetField("a");
            var bField = type.GetField("b");
            
            if (aField != null && bField != null)
            {
                var a = aField.GetValue(l) as EventListener;
                var b = bField.GetValue(l) as EventListener;
                
                var a2 = remove(a, oldl);
                var b2 = remove(b, oldl);
                
                if (a2 == a && b2 == b)
                    return l;
                if (a2 == null)
                    return b2;
                if (b2 == null)
                    return a2;
                
                // Create new multicaster
                return CreateMulticaster(a2, b2);
            }
            
            return l;
        }

        // Generic add method
        public static EventListener add(EventListener l, EventListener newl)
        {
            if (l == null)
                return newl;
            if (newl == null)
                return l;
            return CreateMulticaster(l, newl);
        }

        private static EventListener CreateMulticaster(EventListener a, EventListener b)
        {
            // Create a simple multicaster wrapper
            return new MulticasterWrapper(a, b);
        }

        // Typed add methods
        public static ComponentListener add(ComponentListener l, ComponentListener newl)
        {
            return (ComponentListener)add((EventListener)l, (EventListener)newl);
        }

        public static ContainerListener add(ContainerListener l, ContainerListener newl)
        {
            return (ContainerListener)add((EventListener)l, (EventListener)newl);
        }

        public static KeyListener add(KeyListener l, KeyListener newl)
        {
            return (KeyListener)add((EventListener)l, (EventListener)newl);
        }

        public static FocusListener add(FocusListener l, FocusListener newl)
        {
            return (FocusListener)add((EventListener)l, (EventListener)newl);
        }

        public static MouseListener add(MouseListener l, MouseListener newl)
        {
            return (MouseListener)add((EventListener)l, (EventListener)newl);
        }

        public static MouseMotionListener add(MouseMotionListener l, MouseMotionListener newl)
        {
            return (MouseMotionListener)add((EventListener)l, (EventListener)newl);
        }

        public static TextListener add(TextListener l, TextListener newl)
        {
            return (TextListener)add((EventListener)l, (EventListener)newl);
        }

        public static AdjustmentListener add(AdjustmentListener l, AdjustmentListener newl)
        {
            return (AdjustmentListener)add((EventListener)l, (EventListener)newl);
        }

        public static ItemListener add(ItemListener l, ItemListener newl)
        {
            return (ItemListener)add((EventListener)l, (EventListener)newl);
        }

        public static ActionListener add(ActionListener l, ActionListener newl)
        {
            return (ActionListener)add((EventListener)l, (EventListener)newl);
        }

        public static WindowFocusListener add(WindowFocusListener l, WindowFocusListener newl)
        {
            return (WindowFocusListener)add((EventListener)l, (EventListener)newl);
        }

        public static WindowStateListener add(WindowStateListener l, WindowStateListener newl)
        {
            return (WindowStateListener)add((EventListener)l, (EventListener)newl);
        }

        public static WindowListener add(WindowListener l, WindowListener newl)
        {
            return (WindowListener)add((EventListener)l, (EventListener)newl);
        }

        public static MouseWheelListener add(MouseWheelListener l, MouseWheelListener newl)
        {
            return (MouseWheelListener)add((EventListener)l, (EventListener)newl);
        }

        public static HierarchyBoundsListener add(HierarchyBoundsListener l, HierarchyBoundsListener newl)
        {
            return (HierarchyBoundsListener)add((EventListener)l, (EventListener)newl);
        }

        public static HierarchyListener add(HierarchyListener l, HierarchyListener newl)
        {
            return (HierarchyListener)add((EventListener)l, (EventListener)newl);
        }

        public static InputMethodListener add(InputMethodListener l, InputMethodListener newl)
        {
            return (InputMethodListener)add((EventListener)l, (EventListener)newl);
        }

        // Typed remove methods
        public static MouseMotionListener remove(MouseMotionListener l, MouseMotionListener oldl)
        {
            return (MouseMotionListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static HierarchyListener remove(HierarchyListener l, HierarchyListener oldl)
        {
            return (HierarchyListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static WindowListener remove(WindowListener l, WindowListener oldl)
        {
            return (WindowListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static MouseListener remove(MouseListener l, MouseListener oldl)
        {
            return (MouseListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static KeyListener remove(KeyListener l, KeyListener oldl)
        {
            return (KeyListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static FocusListener remove(FocusListener l, FocusListener oldl)
        {
            return (FocusListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static InputMethodListener remove(InputMethodListener l, InputMethodListener oldl)
        {
            return (InputMethodListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static TextListener remove(TextListener l, TextListener oldl)
        {
            return (TextListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static AdjustmentListener remove(AdjustmentListener l, AdjustmentListener oldl)
        {
            return (AdjustmentListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static ItemListener remove(ItemListener l, ItemListener oldl)
        {
            return (ItemListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static ActionListener remove(ActionListener l, ActionListener oldl)
        {
            return (ActionListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static WindowFocusListener remove(WindowFocusListener l, WindowFocusListener oldl)
        {
            return (WindowFocusListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static WindowStateListener remove(WindowStateListener l, WindowStateListener oldl)
        {
            return (WindowStateListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static MouseWheelListener remove(MouseWheelListener l, MouseWheelListener oldl)
        {
            return (MouseWheelListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static ContainerListener remove(ContainerListener l, ContainerListener oldl)
        {
            return (ContainerListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static ComponentListener remove(ComponentListener l, ComponentListener oldl)
        {
            return (ComponentListener)remove((EventListener)l, (EventListener)oldl);
        }

        public static HierarchyBoundsListener remove(HierarchyBoundsListener l, HierarchyBoundsListener oldl)
        {
            return (HierarchyBoundsListener)remove((EventListener)l, (EventListener)oldl);
        }
    }

    // Simple multicaster wrapper class
    public class MulticasterWrapper : EventListener
    {
        public EventListener a;
        public EventListener b;

        public MulticasterWrapper(EventListener a, EventListener b)
        {
            this.a = a;
            this.b = b;
        }
    }

    public class java_awt_AWTEventMulticasterAutoTest
    {
        public void getListeners_test_911(EventListener p0, Type p1)
        {
            AWTEventMulticaster.getListeners(p0, p1);
        }

        public void remove_test_912(MouseMotionListener p0, MouseMotionListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_913(HierarchyListener p0, HierarchyListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_914(WindowListener p0, WindowListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_915(MouseListener p0, MouseListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_916(KeyListener p0, KeyListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_917(FocusListener p0, FocusListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_918(InputMethodListener p0, InputMethodListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_919(TextListener p0, TextListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_920(AdjustmentListener p0, AdjustmentListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_921(ItemListener p0, ItemListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_922(ActionListener p0, ActionListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_923(WindowFocusListener p0, WindowFocusListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_924(WindowStateListener p0, WindowStateListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_925(MouseWheelListener p0, MouseWheelListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_926(ContainerListener p0, ContainerListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_927(ComponentListener p0, ComponentListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_928(HierarchyBoundsListener p0, HierarchyBoundsListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void add_test_929(ComponentListener p0, ComponentListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_930(ContainerListener p0, ContainerListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_931(KeyListener p0, KeyListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_932(FocusListener p0, FocusListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_933(MouseListener p0, MouseListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_934(MouseMotionListener p0, MouseMotionListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_935(TextListener p0, TextListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_936(AdjustmentListener p0, AdjustmentListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_937(ItemListener p0, ItemListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_938(ActionListener p0, ActionListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_939(WindowFocusListener p0, WindowFocusListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_940(WindowStateListener p0, WindowStateListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_941(WindowListener p0, WindowListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_942(MouseWheelListener p0, MouseWheelListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_943(HierarchyBoundsListener p0, HierarchyBoundsListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_944(HierarchyListener p0, HierarchyListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_945(InputMethodListener p0, InputMethodListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }
    }
}