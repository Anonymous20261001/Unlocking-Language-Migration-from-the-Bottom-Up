namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_ExifGPSTagSetAutoTest
    {
        public void getInstance_test_4661()
        {
            ExifGPSTagSet.getInstance();
        }
    }

    public class ExifGPSTagSet
    {
        private static ExifGPSTagSet instance;

        private ExifGPSTagSet()
        {
        }

        public static ExifGPSTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new ExifGPSTagSet();
            }
            return instance;
        }
    }
}