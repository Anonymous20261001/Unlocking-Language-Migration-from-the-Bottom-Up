namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;

    public class DecimalStyle
    {
        private readonly string zeroDigit;
        private readonly char positiveSign;
        private readonly char negativeSign;
        private readonly char decimalSeparator;
        private readonly char groupingSeparator;

        public DecimalStyle(string zeroDigit, char positiveSign, char negativeSign, char decimalSeparator, char groupingSeparator)
        {
            this.zeroDigit = zeroDigit;
            this.positiveSign = positiveSign;
            this.negativeSign = negativeSign;
            this.decimalSeparator = decimalSeparator;
            this.groupingSeparator = groupingSeparator;
        }

        public static DecimalStyle Of(CultureInfo locale)
        {
            // Simplified mapping based on locale
            string zeroDigit = "0";
            char positiveSign = '+';
            char negativeSign = '-';
            char decimalSeparator = locale.NumberFormat.NumberDecimalSeparator[0];
            char groupingSeparator = locale.NumberFormat.NumberGroupSeparator[0];
            return new DecimalStyle(zeroDigit, positiveSign, negativeSign, decimalSeparator, groupingSeparator);
        }

        public static CultureInfo[] GetAvailableLocales()
        {
            return CultureInfo.GetCultures(CultureTypes.AllCultures);
        }

        public static DecimalStyle OfDefaultLocale()
        {
            return Of(CultureInfo.CurrentCulture);
        }
    }

    public class java_time_format_DecimalStyleAutoTest
    {
        public void of_test_3542(CultureInfo p0)
        {
            DecimalStyle.Of(p0);
        }

        public void getAvailableLocales_test_3543()
        {
            DecimalStyle.GetAvailableLocales();
        }

        public void ofDefaultLocale_test_3544()
        {
            DecimalStyle.OfDefaultLocale();
        }
    }
}