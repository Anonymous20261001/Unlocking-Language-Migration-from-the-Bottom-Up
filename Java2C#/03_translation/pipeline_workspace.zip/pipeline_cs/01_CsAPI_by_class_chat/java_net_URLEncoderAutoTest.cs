namespace Generated.Test
{
    using System;
    using System.Text;

    public class java_net_URLEncoderAutoTest
    {
        public void encode_test_13267(string p0)
        {
            URLEncoder.Encode(p0);
        }

        public void encode_test_13268(string p0, Encoding p1)
        {
            URLEncoder.Encode(p0, p1);
        }
    }

    public static class URLEncoder
    {
        public static string Encode(string s)
        {
            return Encode(s, Encoding.UTF8);
        }

        public static string Encode(string s, Encoding encoding)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (encoding == null)
                throw new ArgumentNullException(nameof(encoding));

            // Java URLEncoder encodes spaces as '+', and encodes all characters except
            // letters, digits, and the characters ".", "-", "*", "_".
            // It uses the specified encoding to convert the string to bytes.
            var bytes = encoding.GetBytes(s);
            var sb = new StringBuilder();
            foreach (byte b in bytes)
            {
                char c = (char)b;
                if (IsUnreserved(c))
                {
                    sb.Append(c);
                }
                else if (c == ' ')
                {
                    sb.Append('+');
                }
                else
                {
                    sb.Append('%');
                    sb.Append(b.ToString("X2"));
                }
            }
            return sb.ToString();
        }

        private static bool IsUnreserved(char c)
        {
            return (c >= 'a' && c <= 'z') ||
                   (c >= 'A' && c <= 'Z') ||
                   (c >= '0' && c <= '9') ||
                   c == '.' || c == '-' || c == '*' || c == '_';
        }
    }
}