namespace Generated.Test
{
    public class java_util_OptionalDoubleAutoTest
    {
        public void of_test_9692(double p0)
        {
            OptionalDouble.Of(p0);
        }

        public void empty_test_9693()
        {
            OptionalDouble.Empty();
        }
    }

    public class OptionalDouble
    {
        private readonly bool hasValue;
        private readonly double value;

        private OptionalDouble(bool hasValue, double value)
        {
            this.hasValue = hasValue;
            this.value = value;
        }

        public static OptionalDouble Of(double value)
        {
            return new OptionalDouble(true, value);
        }

        public static OptionalDouble Empty()
        {
            return new OptionalDouble(false, 0);
        }

        public bool IsPresent
        {
            get { return hasValue; }
        }

        public double GetAsDouble()
        {
            if (!hasValue)
            {
                throw new System.InvalidOperationException("No value present");
            }
            return value;
        }

        public double OrElse(double other)
        {
            return hasValue ? value : other;
        }

        public override bool Equals(object obj)
        {
            if (obj is OptionalDouble other)
            {
                if (this.hasValue && other.hasValue)
                {
                    return this.value == other.value;
                }
                return this.hasValue == other.hasValue;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return hasValue ? value.GetHashCode() : 0;
        }

        public override string ToString()
        {
            return hasValue ? string.Format("OptionalDouble[{0}]", value) : "OptionalDouble.empty";
        }
    }
}