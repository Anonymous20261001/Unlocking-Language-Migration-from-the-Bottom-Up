namespace Generated.Test
{
    using System.Security.Cryptography.X509Certificates;

    public class javax_net_ssl_KeyManagerFactoryAutoTest
    {
        public void getDefaultAlgorithm_test_7628()
        {
            KeyManagerFactory.GetDefaultAlgorithm();
        }
    }

    public static class KeyManagerFactory
    {
        public static string GetDefaultAlgorithm()
        {
            return "SunX509";
        }
    }
}