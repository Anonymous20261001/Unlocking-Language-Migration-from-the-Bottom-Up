namespace Generated.Test;

using System;
using System.Collections.Generic;
using System.Linq;

public class Locale
{
    public enum Category
    {
        DISPLAY,
        FORMAT
    }

    public enum FilteringMode
    {
        AUTOSELECT_FILTERING,
        EXTENDED_FILTERING,
        IGNORE_EXTENDED_RANGES,
        MAP_EXTENDED_RANGES,
        REJECT_EXTENDED_RANGES
    }

    public enum IsoCountryCode
    {
        PART1_ALPHA2,
        PART1_ALPHA3,
        PART3
    }

    private string language;
    private string country;
    private string variant;
    private string script;
    private Dictionary<string, string> extensions;
    private HashSet<string> unicodeLocaleAttributes;
    private HashSet<string> unicodeLocaleKeys;
    private Dictionary<string, string> unicodeLocaleTypes;

    private static Locale defaultLocale = new Locale("en", "US", "");
    private static Dictionary<Category, Locale> defaultLocaleByCategory = new Dictionary<Category, Locale>
    {
        { Category.DISPLAY, defaultLocale },
        { Category.FORMAT, defaultLocale }
    };

    public Locale(string language) : this(language, "", "") { }

    public Locale(string language, string country) : this(language, country, "") { }

    public Locale(string language, string country, string variant)
    {
        this.language = language ?? "";
        this.country = country ?? "";
        this.variant = variant ?? "";
        this.script = "";
        this.extensions = new Dictionary<string, string>();
        this.unicodeLocaleAttributes = new HashSet<string>();
        this.unicodeLocaleKeys = new HashSet<string>();
        this.unicodeLocaleTypes = new Dictionary<string, string>();
    }

    public static Locale of(string language)
    {
        return new Locale(language);
    }

    public static Locale of(string language, string country)
    {
        return new Locale(language, country);
    }

    public static Locale of(string language, string country, string variant)
    {
        return new Locale(language, country, variant);
    }

    public static Locale getDefault()
    {
        return defaultLocale;
    }

    public static Locale getDefault(Category category)
    {
        return defaultLocaleByCategory[category];
    }

    public static void setDefault(Locale newLocale)
    {
        defaultLocale = newLocale;
        defaultLocaleByCategory[Category.DISPLAY] = newLocale;
        defaultLocaleByCategory[Category.FORMAT] = newLocale;
    }

    public static void setDefault(Category category, Locale newLocale)
    {
        defaultLocaleByCategory[category] = newLocale;
    }

    public static Locale[] getAvailableLocales()
    {
        return new Locale[] { new Locale("en"), new Locale("fr"), new Locale("de"), new Locale("ja") };
    }

    public static Locale[] availableLocales()
    {
        return getAvailableLocales();
    }

    public static string[] getISOLanguages()
    {
        return new string[] { "en", "fr", "de", "ja", "zh" };
    }

    public static string[] getISOCountries()
    {
        return new string[] { "US", "FR", "DE", "JP", "CN" };
    }

    public static string[] getISOCountries(IsoCountryCode countryCode)
    {
        return getISOCountries();
    }

    public static Locale forLanguageTag(string languageTag)
    {
        return new Locale(languageTag);
    }

    public static string caseFoldLanguageTag(string languageTag)
    {
        return languageTag.ToLowerInvariant();
    }

    public static Locale lookup(List<Locale.LanguageRange> priorityList, Collection<Locale> locales)
    {
        if (priorityList == null || priorityList.Count == 0 || locales == null || locales.Count == 0)
            return null;
        return locales.FirstOrDefault();
    }

    public static List<Locale> filter(List<Locale.LanguageRange> priorityList, Collection<Locale> locales)
    {
        return filter(priorityList, locales, FilteringMode.AUTOSELECT_FILTERING);
    }

    public static List<Locale> filter(List<Locale.LanguageRange> priorityList, Collection<Locale> locales, FilteringMode mode)
    {
        if (locales == null)
            return new List<Locale>();
        return locales.ToList();
    }

    public static List<string> filterTags(List<Locale.LanguageRange> priorityList, Collection<string> tags)
    {
        return filterTags(priorityList, tags, FilteringMode.AUTOSELECT_FILTERING);
    }

    public static List<string> filterTags(List<Locale.LanguageRange> priorityList, Collection<string> tags, FilteringMode mode)
    {
        if (tags == null)
            return new List<string>();
        return tags.ToList();
    }

    public static string lookupTag(List<Locale.LanguageRange> priorityList, Collection<string> tags)
    {
        if (priorityList == null || priorityList.Count == 0 || tags == null || tags.Count == 0)
            return null;
        return tags.FirstOrDefault();
    }

    public string getLanguage()
    {
        return language;
    }

    public string getCountry()
    {
        return country;
    }

    public string getVariant()
    {
        return variant;
    }

    public string getScript()
    {
        return script;
    }

    public string getDisplayName()
    {
        return language + (country.Length > 0 ? "_" + country : "") + (variant.Length > 0 ? "_" + variant : "");
    }

    public string getDisplayName(Locale inLocale)
    {
        return getDisplayName();
    }

    public string getDisplayLanguage()
    {
        return language;
    }

    public string getDisplayLanguage(Locale inLocale)
    {
        return language;
    }

    public string getDisplayScript()
    {
        return script;
    }

    public string getDisplayScript(Locale inLocale)
    {
        return script;
    }

    public string getDisplayCountry()
    {
        return country;
    }

    public string getDisplayCountry(Locale inLocale)
    {
        return country;
    }

    public string getDisplayVariant()
    {
        return variant;
    }

    public string getDisplayVariant(Locale inLocale)
    {
        return variant;
    }

    public string getISO3Language()
    {
        return language.Length >= 3 ? language.Substring(0, 3) : language;
    }

    public string getISO3Country()
    {
        return country.Length >= 3 ? country.Substring(0, 3) : country;
    }

    public string toLanguageTag()
    {
        return language + (country.Length > 0 ? "-" + country : "") + (variant.Length > 0 ? "-" + variant : "");
    }

    public Locale stripExtensions()
    {
        Locale result = new Locale(language, country, variant);
        result.script = script;
        return result;
    }

    public bool hasExtensions()
    {
        return extensions.Count > 0 || unicodeLocaleAttributes.Count > 0 || unicodeLocaleKeys.Count > 0;
    }

    public string getExtension(char key)
    {
        return extensions.ContainsKey(key.ToString()) ? extensions[key.ToString()] : null;
    }

    public HashSet<char> getExtensionKeys()
    {
        return new HashSet<char>(extensions.Keys.Select(k => k[0]));
    }

    public HashSet<string> getUnicodeLocaleAttributes()
    {
        return unicodeLocaleAttributes;
    }

    public HashSet<string> getUnicodeLocaleKeys()
    {
        return unicodeLocaleKeys;
    }

    public string getUnicodeLocaleType(string key)
    {
        return unicodeLocaleTypes.ContainsKey(key) ? unicodeLocaleTypes[key] : null;
    }

    public class LanguageRange
    {
        public string Range { get; set; }
        public double Weight { get; set; }

        public LanguageRange(string range) : this(range, 1.0) { }

        public LanguageRange(string range, double weight)
        {
            Range = range;
            Weight = weight;
        }
    }
}

public class Collection<T> : List<T>
{
    public Collection() : base() { }
    public Collection(IEnumerable<T> collection) : base(collection) { }
}

public class java_util_LocaleAutoTest
{
    public void of_test_8014(string p0, string p1)
    {
        Locale.of(p0, p1);
    }

    public void of_test_8015(string p0, string p1, string p2)
    {
        Locale.of(p0, p1, p2);
    }

    public void of_test_8016(string p0)
    {
        Locale.of(p0);
    }

    public void getDefault_test_8017(Locale.Category p0)
    {
        Locale.getDefault(p0);
    }

    public void getDefault_test_8018()
    {
        Locale.getDefault();
    }

    public void lookup_test_8019(List<Locale.LanguageRange> p0, Collection<Locale> p1)
    {
        Locale.lookup(p0, p1);
    }

    public void filter_test_8020(List<Locale.LanguageRange> p0, Collection<Locale> p1, Locale.FilteringMode p2)
    {
        Locale.filter(p0, p1, p2);
    }

    public void filter_test_8021(List<Locale.LanguageRange> p0, Collection<Locale> p1)
    {
        Locale.filter(p0, p1);
    }

    public void getLanguage_test_8022(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getLanguage();
    }

    public void getDisplayName_test_8023(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayName();
    }

    public void getDisplayName_test_8024(Locale p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayName(p0);
    }

    public void getAvailableLocales_test_8025()
    {
        Locale.getAvailableLocales();
    }

    public void getUnicodeLocaleType_test_8026(string p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getUnicodeLocaleType(p0);
    }

    public void getCountry_test_8027(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getCountry();
    }

    public void stripExtensions_test_8028(string c0)
    {
        Locale instance = new Locale(c0);
        instance.stripExtensions();
    }

    public void hasExtensions_test_8029(string c0)
    {
        Locale instance = new Locale(c0);
        instance.hasExtensions();
    }

    public void getVariant_test_8030(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getVariant();
    }

    public void setDefault_test_8031(Locale.Category p0, Locale p1)
    {
        Locale.setDefault(p0, p1);
    }

    public void setDefault_test_8032(Locale p0)
    {
        Locale.setDefault(p0);
    }

    public void getScript_test_8033(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getScript();
    }

    public void getUnicodeLocaleAttributes_test_8034(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getUnicodeLocaleAttributes();
    }

    public void getUnicodeLocaleKeys_test_8035(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getUnicodeLocaleKeys();
    }

    public void getDisplayLanguage_test_8036(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayLanguage();
    }

    public void getDisplayLanguage_test_8037(Locale p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayLanguage(p0);
    }

    public void getDisplayScript_test_8038(Locale p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayScript(p0);
    }

    public void getDisplayScript_test_8039(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayScript();
    }

    public void getDisplayCountry_test_8040(Locale p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayCountry(p0);
    }

    public void getDisplayCountry_test_8041(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayCountry();
    }

    public void getDisplayVariant_test_8042(Locale p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayVariant(p0);
    }

    public void getDisplayVariant_test_8043(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getDisplayVariant();
    }

    public void filterTags_test_8044(List<Locale.LanguageRange> p0, Collection<string> p1)
    {
        Locale.filterTags(p0, p1);
    }

    public void filterTags_test_8045(List<Locale.LanguageRange> p0, Collection<string> p1, Locale.FilteringMode p2)
    {
        Locale.filterTags(p0, p1, p2);
    }

    public void lookupTag_test_8046(List<Locale.LanguageRange> p0, Collection<string> p1)
    {
        Locale.lookupTag(p0, p1);
    }

    public void availableLocales_test_8047()
    {
        Locale.availableLocales();
    }

    public void getISOCountries_test_8048(Locale.IsoCountryCode p0)
    {
        Locale.getISOCountries(p0);
    }

    public void getISOCountries_test_8049()
    {
        Locale.getISOCountries();
    }

    public void getISOLanguages_test_8050()
    {
        Locale.getISOLanguages();
    }

    public void getExtension_test_8051(char p0, string c0)
    {
        Locale instance = new Locale(c0);
        instance.getExtension(p0);
    }

    public void getExtensionKeys_test_8052(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getExtensionKeys();
    }

    public void toLanguageTag_test_8053(string c0)
    {
        Locale instance = new Locale(c0);
        instance.toLanguageTag();
    }

    public void caseFoldLanguageTag_test_8054(string p0)
    {
        Locale.caseFoldLanguageTag(p0);
    }

    public void forLanguageTag_test_8055(string p0)
    {
        Locale.forLanguageTag(p0);
    }

    public void getISO3Language_test_8056(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getISO3Language();
    }

    public void getISO3Country_test_8057(string c0)
    {
        Locale instance = new Locale(c0);
        instance.getISO3Country();
    }
}