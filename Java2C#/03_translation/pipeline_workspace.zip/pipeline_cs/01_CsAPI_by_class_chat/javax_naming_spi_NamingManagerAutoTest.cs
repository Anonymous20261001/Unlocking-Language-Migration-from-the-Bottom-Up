namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;

    public class NamingManager
    {
        private static bool hasInitialContextFactoryBuilder = false;

        public static bool HasInitialContextFactoryBuilder()
        {
            return hasInitialContextFactoryBuilder;
        }
    }

    public class javax_naming_spi_NamingManagerAutoTest
    {
        public void hasInitialContextFactoryBuilder_test_9513()
        {
            NamingManager.HasInitialContextFactoryBuilder();
        }
    }
}