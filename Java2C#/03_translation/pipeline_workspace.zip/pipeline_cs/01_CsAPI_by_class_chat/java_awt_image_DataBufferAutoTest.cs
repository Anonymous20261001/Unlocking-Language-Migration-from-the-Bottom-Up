namespace Generated.Test
{
    public class java_awt_image_DataBufferAutoTest
    {
        public void getDataTypeSize_test_3173(int p0)
        {
            DataBuffer.GetDataTypeSize(p0);
        }
    }

    public class DataBuffer
    {
        public static int GetDataTypeSize(int dataType)
        {
            switch (dataType)
            {
                case 0: // TYPE_BYTE
                    return 8;
                case 1: // TYPE_USHORT
                    return 16;
                case 2: // TYPE_SHORT
                    return 16;
                case 3: // TYPE_INT
                    return 32;
                case 4: // TYPE_FLOAT
                    return 32;
                case 5: // TYPE_DOUBLE
                    return 64;
                case 6: // TYPE_UNDEFINED
                    return 32;
                default:
                    throw new System.ArgumentException("Unknown data type: " + dataType);
            }
        }
    }
}