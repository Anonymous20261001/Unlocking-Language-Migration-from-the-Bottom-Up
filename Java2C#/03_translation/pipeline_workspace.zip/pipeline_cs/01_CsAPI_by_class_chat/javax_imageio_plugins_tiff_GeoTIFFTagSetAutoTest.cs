namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_GeoTIFFTagSetAutoTest
    {
        public void getInstance_test_5102()
        {
            GeoTIFFTagSet.getInstance();
        }
    }

    public class GeoTIFFTagSet
    {
        private static GeoTIFFTagSet instance;

        private GeoTIFFTagSet()
        {
        }

        public static GeoTIFFTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new GeoTIFFTagSet();
            }
            return instance;
        }
    }
}