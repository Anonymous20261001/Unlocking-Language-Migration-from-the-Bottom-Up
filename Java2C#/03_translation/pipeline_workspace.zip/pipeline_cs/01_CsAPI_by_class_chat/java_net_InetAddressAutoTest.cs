namespace Generated.Test
{
    using System.Net;

    public class java_net_InetAddressAutoTest
    {
        public void ofLiteral_test_5795(string p0)
        {
            InetAddress.OfLiteral(p0);
        }

        public void getLoopbackAddress_test_5796()
        {
            InetAddress.GetLoopbackAddress();
        }
    }

    public class InetAddress
    {
        public static System.Net.IPAddress OfLiteral(string literal)
        {
            return System.Net.IPAddress.Parse(literal);
        }

        public static System.Net.IPAddress GetLoopbackAddress()
        {
            return System.Net.IPAddress.Loopback;
        }
    }
}