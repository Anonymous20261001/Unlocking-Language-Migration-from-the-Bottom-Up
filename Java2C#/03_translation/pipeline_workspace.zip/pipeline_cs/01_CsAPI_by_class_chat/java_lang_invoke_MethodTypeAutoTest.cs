using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Generated.Test
{
    public class MethodType
    {
        public Type ReturnType { get; }
        public Type[] ParameterTypes { get; }

        private MethodType(Type returnType, Type[] parameterTypes)
        {
            ReturnType = returnType;
            ParameterTypes = parameterTypes ?? new Type[0];
        }

        public static MethodType MethodType(Type returnType, List<Type> parameterTypes)
        {
            return new MethodType(returnType, parameterTypes?.ToArray());
        }

        public static MethodType MethodType(Type returnType)
        {
            return new MethodType(returnType, new Type[0]);
        }

        public static MethodType MethodType(Type returnType, Type parameterType, Type[] parameterTypes)
        {
            var allParams = new List<Type>();
            if (parameterType != null) allParams.Add(parameterType);
            if (parameterTypes != null) allParams.AddRange(parameterTypes);
            return new MethodType(returnType, allParams.ToArray());
        }

        public static MethodType MethodType(Type returnType, Type[] parameterTypes)
        {
            return new MethodType(returnType, parameterTypes);
        }

        public static MethodType MethodType(Type returnType, Type parameterType)
        {
            return new MethodType(returnType, new[] { parameterType });
        }

        public static MethodType MethodType(Type returnType, MethodType parameterTypes)
        {
            return new MethodType(returnType, parameterTypes?.ParameterTypes);
        }

        public static MethodType GenericMethodType(int parameterCount, bool objectArg)
        {
            var paramTypes = new Type[parameterCount];
            for (int i = 0; i < parameterCount; i++)
            {
                paramTypes[i] = objectArg ? typeof(object) : typeof(object);
            }
            return new MethodType(typeof(object), paramTypes);
        }

        public static MethodType GenericMethodType(int parameterCount)
        {
            return GenericMethodType(parameterCount, true);
        }

        public static MethodType FromMethodDescriptorString(string descriptor, ClassLoader loader)
        {
            // Parse descriptor like (Ljava/lang/String;I)V
            var returnType = ParseType(descriptor.Substring(descriptor.IndexOf(')') + 1));
            var paramPart = descriptor.Substring(1, descriptor.IndexOf(')') - 1);
            var paramTypes = new List<Type>();
            int i = 0;
            while (i < paramPart.Length)
            {
                var type = ParseType(paramPart.Substring(i));
                paramTypes.Add(type);
                i += GetTypeLength(paramPart.Substring(i));
            }
            return new MethodType(returnType, paramTypes.ToArray());
        }

        private static Type ParseType(string typeStr)
        {
            if (string.IsNullOrEmpty(typeStr)) return typeof(void);
            switch (typeStr[0])
            {
                case 'V': return typeof(void);
                case 'Z': return typeof(bool);
                case 'B': return typeof(sbyte);
                case 'C': return typeof(char);
                case 'S': return typeof(short);
                case 'I': return typeof(int);
                case 'J': return typeof(long);
                case 'F': return typeof(float);
                case 'D': return typeof(double);
                case 'L':
                    var endIndex = typeStr.IndexOf(';');
                    var className = typeStr.Substring(1, endIndex - 1).Replace('/', '.');
                    return Type.GetType(className) ?? typeof(object);
                case '[':
                    var elementType = ParseType(typeStr.Substring(1));
                    return elementType.MakeArrayType();
                default:
                    return typeof(object);
            }
        }

        private static int GetTypeLength(string typeStr)
        {
            if (string.IsNullOrEmpty(typeStr)) return 0;
            switch (typeStr[0])
            {
                case 'V':
                case 'Z':
                case 'B':
                case 'C':
                case 'S':
                case 'I':
                case 'J':
                case 'F':
                case 'D':
                    return 1;
                case 'L':
                    return typeStr.IndexOf(';') + 1;
                case '[':
                    return 1 + GetTypeLength(typeStr.Substring(1));
                default:
                    return 1;
            }
        }
    }

    public class ClassLoader
    {
        public static ClassLoader GetSystemClassLoader()
        {
            return new ClassLoader();
        }
    }

    public class java_lang_invoke_MethodTypeAutoTest
    {
        public void methodType_test_8922(Type p0, List<Type> p1)
        {
            MethodType.MethodType(p0, p1);
        }

        public void methodType_test_8923(Type p0)
        {
            MethodType.MethodType(p0);
        }

        public void methodType_test_8924(Type p0, Type p1, Type[] p2)
        {
            MethodType.MethodType(p0, p1, p2);
        }

        public void methodType_test_8925(Type p0, Type[] p1)
        {
            MethodType.MethodType(p0, p1);
        }

        public void methodType_test_8926(Type p0, Type p1)
        {
            MethodType.MethodType(p0, p1);
        }

        public void methodType_test_8927(Type p0, MethodType p1)
        {
            MethodType.MethodType(p0, p1);
        }

        public void genericMethodType_test_8928(int p0, bool p1)
        {
            MethodType.GenericMethodType(p0, p1);
        }

        public void genericMethodType_test_8929(int p0)
        {
            MethodType.GenericMethodType(p0);
        }

        public void fromMethodDescriptorString_test_8930(string p0, ClassLoader p1)
        {
            MethodType.FromMethodDescriptorString(p0, p1);
        }
    }
}