namespace Generated.Test
{
    using System;

    public class DatatypeFactory
    {
        public static DatatypeFactory NewDefaultInstance()
        {
            return new DatatypeFactory();
        }
    }

    public class javax_xml_datatype_DatatypeFactoryAutoTest
    {
        public void newDefaultInstance_test_3280()
        {
            DatatypeFactory.NewDefaultInstance();
        }
    }
}