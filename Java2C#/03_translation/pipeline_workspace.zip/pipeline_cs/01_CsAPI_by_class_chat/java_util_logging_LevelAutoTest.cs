using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Level
    {
        private readonly string name;
        private readonly int value;

        private static readonly Dictionary<string, Level> knownLevels = new Dictionary<string, Level>(StringComparer.Ordinal)
        {
            { "OFF", new Level("OFF", int.MaxValue) },
            { "SEVERE", new Level("SEVERE", 1000) },
            { "WARNING", new Level("WARNING", 900) },
            { "INFO", new Level("INFO", 800) },
            { "CONFIG", new Level("CONFIG", 700) },
            { "FINE", new Level("FINE", 500) },
            { "FINER", new Level("FINER", 400) },
            { "FINEST", new Level("FINEST", 300) },
            { "ALL", new Level("ALL", int.MinValue) }
        };

        private Level(string name, int value)
        {
            this.name = name;
            this.value = value;
        }

        public string Name => name;
        public int Value => value;

        public static Level Parse(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            if (knownLevels.TryGetValue(name, out Level level))
            {
                return level;
            }

            throw new ArgumentException($"Unknown level name: {name}", nameof(name));
        }

        public override string ToString()
        {
            return name;
        }

        public override bool Equals(object obj)
        {
            if (obj is Level other)
            {
                return value == other.value && name == other.name;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return value.GetHashCode() ^ name.GetHashCode();
        }
    }

    public class java_util_logging_LevelAutoTest
    {
        public void parse_test_7719(string p0)
        {
            Level.Parse(p0);
        }
    }
}