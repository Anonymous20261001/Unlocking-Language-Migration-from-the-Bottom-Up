using System;
using System.Collections.Generic;
using System.Globalization;

namespace Generated.Test
{
    // Simplified TemporalAccessor interface for demonstration
    public interface TemporalAccessor
    {
        // Minimal interface - actual implementation would be more complex
        object Get(object field);
    }

    // Simplified ZoneOffset class
    public class ZoneOffset
    {
        private readonly int _totalSeconds;
        private readonly string _id;

        private ZoneOffset(int totalSeconds, string id)
        {
            _totalSeconds = totalSeconds;
            _id = id;
        }

        public static ZoneOffset Of(string offsetId)
        {
            if (string.IsNullOrEmpty(offsetId))
                throw new ArgumentException("Invalid offset ID");

            // Parse offset like "+HH:MM", "+HHMM", "+HH", "-HH:MM", etc.
            string normalized = offsetId.Trim();
            if (normalized == "Z" || normalized == "z")
                return new ZoneOffset(0, "Z");

            bool negative = normalized.StartsWith("-");
            if (!negative && !normalized.StartsWith("+"))
                throw new ArgumentException("Invalid offset ID: " + offsetId);

            string digits = normalized.Substring(1);
            int hours = 0, minutes = 0, seconds = 0;

            if (digits.Contains(":"))
            {
                string[] parts = digits.Split(':');
                if (parts.Length < 2 || parts.Length > 3)
                    throw new ArgumentException("Invalid offset ID: " + offsetId);
                hours = int.Parse(parts[0]);
                minutes = int.Parse(parts[1]);
                if (parts.Length == 3)
                    seconds = int.Parse(parts[2]);
            }
            else if (digits.Length == 2)
            {
                hours = int.Parse(digits);
            }
            else if (digits.Length == 4)
            {
                hours = int.Parse(digits.Substring(0, 2));
                minutes = int.Parse(digits.Substring(2, 2));
            }
            else if (digits.Length == 6)
            {
                hours = int.Parse(digits.Substring(0, 2));
                minutes = int.Parse(digits.Substring(2, 2));
                seconds = int.Parse(digits.Substring(4, 2));
            }
            else
            {
                throw new ArgumentException("Invalid offset ID: " + offsetId);
            }

            int totalSeconds = hours * 3600 + minutes * 60 + seconds;
            if (negative)
                totalSeconds = -totalSeconds;

            return new ZoneOffset(totalSeconds, normalized);
        }

        public static ZoneOffset From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));

            // Simplified - in real implementation would extract offset from temporal
            object offsetObj = temporal.Get("offset");
            if (offsetObj is ZoneOffset offset)
                return offset;
            if (offsetObj is string offsetStr)
                return Of(offsetStr);

            throw new DateTimeException("Unable to obtain ZoneOffset from TemporalAccessor");
        }

        public static ZoneOffset OfHours(int hours)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentException("Zone offset hours must be in range -18 to 18");
            return new ZoneOffset(hours * 3600, FormatOffset(hours, 0, 0));
        }

        public static ZoneOffset OfHoursMinutes(int hours, int minutes)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentException("Zone offset hours must be in range -18 to 18");
            if (minutes < 0 || minutes > 59)
                throw new ArgumentException("Zone offset minutes must be in range 0 to 59");
            if (hours == 18 && minutes != 0)
                throw new ArgumentException("Zone offset not in valid range");

            int totalSeconds = hours * 3600 + minutes * 60;
            return new ZoneOffset(totalSeconds, FormatOffset(hours, minutes, 0));
        }

        public static ZoneOffset OfHoursMinutesSeconds(int hours, int minutes, int seconds)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentException("Zone offset hours must be in range -18 to 18");
            if (minutes < 0 || minutes > 59)
                throw new ArgumentException("Zone offset minutes must be in range 0 to 59");
            if (seconds < 0 || seconds > 59)
                throw new ArgumentException("Zone offset seconds must be in range 0 to 59");
            if (hours == 18 && (minutes != 0 || seconds != 0))
                throw new ArgumentException("Zone offset not in valid range");

            int totalSeconds = hours * 3600 + minutes * 60 + seconds;
            return new ZoneOffset(totalSeconds, FormatOffset(hours, minutes, seconds));
        }

        public static ZoneOffset OfTotalSeconds(int totalSeconds)
        {
            if (totalSeconds < -64800 || totalSeconds > 64800)
                throw new ArgumentException("Zone offset not in valid range");

            int hours = totalSeconds / 3600;
            int remaining = totalSeconds % 3600;
            int minutes = remaining / 60;
            int seconds = remaining % 60;

            return new ZoneOffset(totalSeconds, FormatOffset(hours, minutes, seconds));
        }

        private static string FormatOffset(int hours, int minutes, int seconds)
        {
            if (hours == 0 && minutes == 0 && seconds == 0)
                return "Z";

            string sign = hours < 0 ? "-" : "+";
            int absHours = Math.Abs(hours);
            int absMinutes = Math.Abs(minutes);
            int absSeconds = Math.Abs(seconds);

            if (absSeconds == 0)
            {
                if (absMinutes == 0)
                    return string.Format("{0}{1:D2}", sign, absHours);
                return string.Format("{0}{1:D2}:{2:D2}", sign, absHours, absMinutes);
            }
            return string.Format("{0}{1:D2}:{2:D2}:{3:D2}", sign, absHours, absMinutes, absSeconds);
        }

        public int TotalSeconds => _totalSeconds;
        public string Id => _id;

        public override string ToString() => _id;
    }

    // Custom exception for date/time issues
    public class DateTimeException : Exception
    {
        public DateTimeException(string message) : base(message) { }
    }

    public class java_time_ZoneOffsetAutoTest
    {
        public void of_test_13728(string p0)
        {
            ZoneOffset.Of(p0);
        }

        public void from_test_13729(TemporalAccessor p0)
        {
            ZoneOffset.From(p0);
        }

        public void ofHours_test_13730(int p0)
        {
            ZoneOffset.OfHours(p0);
        }

        public void ofHoursMinutesSeconds_test_13731(int p0, int p1, int p2)
        {
            ZoneOffset.OfHoursMinutesSeconds(p0, p1, p2);
        }

        public void ofTotalSeconds_test_13732(int p0)
        {
            ZoneOffset.OfTotalSeconds(p0);
        }

        public void ofHoursMinutes_test_13733(int p0, int p1)
        {
            ZoneOffset.OfHoursMinutes(p0, p1);
        }
    }
}