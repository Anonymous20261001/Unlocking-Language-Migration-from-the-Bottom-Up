namespace Generated.Test
{
    public class java_security_PolicyAutoTest
    {
        public void setPolicy_test_9965(Policy p0)
        {
            Policy.SetPolicy(p0);
        }

        public void getPolicy_test_9966()
        {
            Policy.GetPolicy();
        }
    }

    public class Policy
    {
        private static Policy currentPolicy;

        public static void SetPolicy(Policy policy)
        {
            currentPolicy = policy;
        }

        public static Policy GetPolicy()
        {
            return currentPolicy;
        }
    }
}