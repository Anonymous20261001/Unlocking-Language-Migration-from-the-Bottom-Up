using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {
        public void compareUnsigned_test_344(byte[] p0, byte[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_345(short[] p0, short[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_346(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_347(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_348(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_349(long[] p0, long[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_350(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_351(int[] p0, int[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void copyOf_test_352(double[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_353(int[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_354(byte[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_355(object[] p0, int p1, Type p2)
        {
            Arrays.CopyOf(p0, p1, p2);
        }

        public void copyOf_test_356(object[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_357(bool[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_358(float[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_359(char[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_360(long[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_361(short[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void sort_test_362(object[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_363(long[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_364(long[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_365(short[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_366(object[] p0, int p1, int p2, IComparer<object> p3)
        {
            Arrays.Sort(p0, p1, p2, p3);
        }

        public void sort_test_367(object[] p0, IComparer<object> p1)
        {
            Arrays.Sort(p0, p1);
        }

        public void sort_test_368(object[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_369(int[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_370(double[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_371(double[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_372(float[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_373(float[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_374(byte[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_375(short[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_376(char[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_377(char[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_378(byte[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_379(int[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void copyOfRange_test_380(bool[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_381(char[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_382(long[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_383(float[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_384(double[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_385(object[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_386(object[] p0, int p1, int p2, Type p3)
        {
            Arrays.CopyOfRange(p0, p1, p2, p3);
        }

        public void copyOfRange_test_387(byte[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_388(short[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_389(int[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void compare_test_390(char[] p0, int p1, int p2, char[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_391(int[] p0, int[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_392(char[] p0, char[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_393(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_394(long[] p0, long[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_395(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_396(double[] p0, double[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_397(float[] p0, int p1, int p2, float[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_398(short[] p0, short[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_399(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_400(bool[] p0, bool[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_401(bool[] p0, int p1, int p2, bool[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_402(byte[] p0, byte[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_403(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_404(IComparable[] p0, int p1, int p2, IComparable[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_405(IComparable[] p0, IComparable[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_406(object[] p0, object[] p1, IComparer<object> p2)
        {
            Arrays.Compare(p0, p1, p2);
        }

        public void compare_test_407(double[] p0, int p1, int p2, double[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_408(object[] p0, int p1, int p2, object[] p3, int p4, int p5, IComparer<object> p6)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5, p6);
        }

        public void compare_test_409(float[] p0, float[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void mismatch_test_410(long[] p0, long[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_411(float[] p0, float[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_412(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_413(object[] p0, object[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_414(object[] p0, int p1, int p2, object[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_415(object[] p0, object[] p1, IComparer<object> p2)
        {
            Arrays.Mismatch(p0, p1, p2);
        }

        public void mismatch_test_416(object[] p0, int p1, int p2, object[] p3, int p4, int p5, IComparer<object> p6)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5, p6);
        }

        public void mismatch_test_417(double[] p0, int p1, int p2, double[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_418(double[] p0, double[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_419(float[] p0, int p1, int p2, float[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_420(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_421(char[] p0, char[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_422(char[] p0, int p1, int p2, char[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_423(int[] p0, int[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_424(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_425(short[] p0, short[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_426(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_427(bool[] p0, bool[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_428(bool[] p0, int p1, int p2, bool[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_429(byte[] p0, byte[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void stream_test_430(object[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_431(long[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_432(int[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_433(int[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_434(object[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_435(double[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_436(double[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_437(long[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void fill_test_438(object[] p0, int p1, int p2, object p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_439(long[] p0, long p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_440(bool[] p0, bool p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_441(short[] p0, short p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_442(int[] p0, int p1, int p2, int p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_443(int[] p0, int p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_444(bool[] p0, int p1, int p2, bool p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_445(byte[] p0, byte p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_446(char[] p0, char p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_447(short[] p0, int p1, int p2, short p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_448(byte[] p0, int p1, int p2, byte p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_449(double[] p0, int p1, int p2, double p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_450(float[] p0, float p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_451(float[] p0, int p1, int p2, float p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_452(object[] p0, object p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_453(char[] p0, int p1, int p2, char p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_454(long[] p0, int p1, int p2, long p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_455(double[] p0, double p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void spliterator_test_456(int[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_457(long[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_458(int[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_459(object[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_460(double[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_461(object[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_462(long[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_463(double[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void asList_test_464(object[] p0)
        {
            Arrays.AsList(p0);
        }

        public void deepEquals_test_465(object[] p0, object[] p1)
        {
            Arrays.DeepEquals(p0, p1);
        }

        public void deepHashCode_test_466(object[] p0)
        {
            Arrays.DeepHashCode(p0);
        }

        public void deepToString_test_467(object[] p0)
        {
            Arrays.DeepToString(p0);
        }

        public void parallelSort_test_468(int[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_469(int[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_470(long[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_471(object[] p0, int p1, int p2, IComparer<object> p3)
        {
            Arrays.ParallelSort(p0, p1, p2, p3);
        }

        public void parallelSort_test_472(short[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_473(object[] p0, IComparer<object> p1)
        {
            Arrays.ParallelSort(p0, p1);
        }

        public void parallelSort_test_474(short[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_475(double[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_476(double[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_477(float[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_478(float[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_479(IComparable[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_480(IComparable[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_481(byte[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_482(byte[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_483(char[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_484(char[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_485(long[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelPrefix_test_486(double[] p0, int p1, int p2, Func<double, double, double> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_487(double[] p0, Func<double, double, double> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_488(int[] p0, Func<int, int, int> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_489(int[] p0, int p1, int p2, Func<int, int, int> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_490(long[] p0, int p1, int p2, Func<long, long, long> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_491(long[] p0, Func<long, long, long> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_492(object[] p0, int p1, int p2, Func<object, object, object> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_493(object[] p0, Func<object, object, object> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void binarySearch_test_494(float[] p0, int p1, int p2, float p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_495(float[] p0, float p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_496(short[] p0, short p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_497(short[] p0, int p1, int p2, short p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_498(object[] p0, object p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_499(object[] p0, int p1, int p2, object p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_500(object[] p0, object p1, IComparer<object> p2)
        {
            Arrays.BinarySearch(p0, p1, p2);
        }

        public void binarySearch_test_501(double[] p0, int p1, int p2, double p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_502(double[] p0, double p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_503(byte[] p0, int p1, int p2, byte p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_504(byte[] p0, byte p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_505(char[] p0, int p1, int p2, char p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_506(char[] p0, char p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_507(int[] p0, int p1, int p2, int p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_508(long[] p0, long p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_509(long[] p0, int p1, int p2, long p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_510(int[] p0, int p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_511(object[] p0, int p1, int p2, object p3, IComparer<object> p4)
        {
            Arrays.BinarySearch(p0, p1, p2, p3, p4);
        }

        public void setAll_test_512(double[] p0, Func<int, double> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_513(int[] p0, Func<int, int> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_514(long[] p0, Func<int, long> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_515(object[] p0, Func<int, object> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void parallelSetAll_test_516(double[] p0, Func<int, double> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_517(long[] p0, Func<int, long> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_518(object[] p0, Func<int, object> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_519(int[] p0, Func<int, int> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }
    }

    public static class Arrays
    {
        public static int CompareUnsigned(byte[] a, byte[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((int)a[i] & 0xFF).CompareTo((int)b[i] & 0xFF);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(short[] a, short[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((int)a[i] & 0xFFFF).CompareTo((int)b[i] & 0xFFFF);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((int)a[aFrom + i] & 0xFF).CompareTo((int)b[bFrom + i] & 0xFF);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(long[] a, int aFrom, int aTo, long[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((ulong)a[aFrom + i]).CompareTo((ulong)b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(short[] a, int aFrom, int aTo, short[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((int)a[aFrom + i] & 0xFFFF).CompareTo((int)b[bFrom + i] & 0xFFFF);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(long[] a, long[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((ulong)a[i]).CompareTo((ulong)b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(int[] a, int aFrom, int aTo, int[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((uint)a[aFrom + i]).CompareTo((uint)b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(int[] a, int[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = ((uint)a[i]).CompareTo((uint)b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static double[] CopyOf(double[] original, int newLength)
        {
            double[] result = new double[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static int[] CopyOf(int[] original, int newLength)
        {
            int[] result = new int[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static byte[] CopyOf(byte[] original, int newLength)
        {
            byte[] result = new byte[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static T[] CopyOf<T>(T[] original, int newLength, Type newType)
        {
            T[] result = (T[])Array.CreateInstance(newType, newLength);
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static T[] CopyOf<T>(T[] original, int newLength)
        {
            T[] result = new T[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static bool[] CopyOf(bool[] original, int newLength)
        {
            bool[] result = new bool[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static float[] CopyOf(float[] original, int newLength)
        {
            float[] result = new float[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static char[] CopyOf(char[] original, int newLength)
        {
            char[] result = new char[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static long[] CopyOf(long[] original, int newLength)
        {
            long[] result = new long[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static short[] CopyOf(short[] original, int newLength)
        {
            short[] result = new short[newLength];
            Array.Copy(original, result, Math.Min(original.Length, newLength));
            return result;
        }

        public static void Sort(object[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(long[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(long[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(short[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(object[] a, int fromIndex, int toIndex, IComparer<object> c)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex, c);
        }

        public static void Sort(object[] a, IComparer<object> c)
        {
            Array.Sort(a, c);
        }

        public static void Sort(object[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(int[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(double[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(double[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(float[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(float[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(byte[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(short[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(char[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(char[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void Sort(byte[] a)
        {
            Array.Sort(a);
        }

        public static void Sort(int[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static bool[] CopyOfRange(bool[] original, int from, int to)
        {
            bool[] result = new bool[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static char[] CopyOfRange(char[] original, int from, int to)
        {
            char[] result = new char[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static long[] CopyOfRange(long[] original, int from, int to)
        {
            long[] result = new long[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static float[] CopyOfRange(float[] original, int from, int to)
        {
            float[] result = new float[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static double[] CopyOfRange(double[] original, int from, int to)
        {
            double[] result = new double[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static T[] CopyOfRange<T>(T[] original, int from, int to)
        {
            T[] result = new T[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static T[] CopyOfRange<T>(T[] original, int from, int to, Type newType)
        {
            T[] result = (T[])Array.CreateInstance(newType, to - from);
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static byte[] CopyOfRange(byte[] original, int from, int to)
        {
            byte[] result = new byte[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static short[] CopyOfRange(short[] original, int from, int to)
        {
            short[] result = new short[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static int[] CopyOfRange(int[] original, int from, int to)
        {
            int[] result = new int[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static int Compare(char[] a, int aFrom, int aTo, char[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(int[] a, int[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(char[] a, char[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(int[] a, int aFrom, int aTo, int[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(long[] a, long[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(long[] a, int aFrom, int aTo, long[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(double[] a, double[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(float[] a, int aFrom, int aTo, float[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(short[] a, short[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(short[] a, int aFrom, int aTo, short[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(bool[] a, bool[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(bool[] a, int aFrom, int aTo, bool[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(byte[] a, byte[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(IComparable[] a, int aFrom, int aTo, IComparable[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(IComparable[] a, IComparable[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(object[] a, object[] b, IComparer<object> c)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = c.Compare(a[i], b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(double[] a, int aFrom, int aTo, double[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[aFrom + i].CompareTo(b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(object[] a, int aFrom, int aTo, object[] b, int bFrom, int bTo, IComparer<object> c)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = c.Compare(a[aFrom + i], b[bFrom + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(float[] a, float[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Mismatch(long[] a, long[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(float[] a, float[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(long[] a, int aFrom, int aTo, long[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(object[] a, object[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (!Equals(a[i], b[i])) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(object[] a, int aFrom, int aTo, object[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (!Equals(a[aFrom + i], b[bFrom + i])) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(object[] a, object[] b, IComparer<object> c)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (c.Compare(a[i], b[i]) != 0) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(object[] a, int aFrom, int aTo, object[] b, int bFrom, int bTo, IComparer<object> c)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (c.Compare(a[aFrom + i], b[bFrom + i]) != 0) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(double[] a, int aFrom, int aTo, double[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(double[] a, double[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(float[] a, int aFrom, int aTo, float[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(byte[] a, int aFrom, int aTo, byte[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(char[] a, char[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(char[] a, int aFrom, int aTo, char[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(int[] a, int[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(short[] a, int aFrom, int aTo, short[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(short[] a, short[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(int[] a, int aFrom, int aTo, int[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(bool[] a, bool[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static int Mismatch(bool[] a, int aFrom, int aTo, bool[] b, int bFrom, int bTo)
        {
            int aLen = aTo - aFrom;
            int bLen = bTo - bFrom;
            int minLen = Math.Min(aLen, bLen);
            for (int i = 0; i < minLen; i++)
            {
                if (a[aFrom + i] != b[bFrom + i]) return i;
            }
            return aLen == bLen ? -1 : minLen;
        }

        public static int Mismatch(byte[] a, byte[] b)
        {
            int minLen = Math.Min(a.Length, b.Length);
            for (int i = 0; i < minLen; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : minLen;
        }

        public static IEnumerable<T> Stream<T>(T[] array)
        {
            return array;
        }

        public static IEnumerable<long> Stream(long[] array)
        {
            return array;
        }

        public static IEnumerable<int> Stream(int[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static IEnumerable<int> Stream(int[] array)
        {
            return array;
        }

        public static IEnumerable<T> Stream<T>(T[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static IEnumerable<double> Stream(double[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static IEnumerable<double> Stream(double[] array)
        {
            return array;
        }

        public static IEnumerable<long> Stream(long[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static void Fill(object[] a, int fromIndex, int toIndex, object val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(long[] a, long val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(bool[] a, bool val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(short[] a, short val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(int[] a, int fromIndex, int toIndex, int val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(int[] a, int val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(bool[] a, int fromIndex, int toIndex, bool val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(byte[] a, byte val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(char[] a, char val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(short[] a, int fromIndex, int toIndex, short val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(byte[] a, int fromIndex, int toIndex, byte val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(double[] a, int fromIndex, int toIndex, double val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(float[] a, float val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(float[] a, int fromIndex, int toIndex, float val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(object[] a, object val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static void Fill(char[] a, int fromIndex, int toIndex, char val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(long[] a, int fromIndex, int toIndex, long val)
        {
            for (int i = fromIndex; i < toIndex; i++)
                a[i] = val;
        }

        public static void Fill(double[] a, double val)
        {
            for (int i = 0; i < a.Length; i++)
                a[i] = val;
        }

        public static object Spliterator(int[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(long[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(int[] array, int startInclusive, int endExclusive)
        {
            return array.Skip(startInclusive).Take(endExclusive - startInclusive).GetEnumerator();
        }

        public static object Spliterator(object[] array, int startInclusive, int endExclusive)
        {
            return array.Skip(startInclusive).Take(endExclusive - startInclusive).GetEnumerator();
        }

        public static object Spliterator(double[] array, int startInclusive, int endExclusive)
        {
            return array.Skip(startInclusive).Take(endExclusive - startInclusive).GetEnumerator();
        }

        public static object Spliterator(object[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(long[] array, int startInclusive, int endExclusive)
        {
            return array.Skip(startInclusive).Take(endExclusive - startInclusive).GetEnumerator();
        }

        public static object Spliterator(double[] array)
        {
            return array.GetEnumerator();
        }

        public static List<T> AsList<T>(T[] array)
        {
            return new List<T>(array);
        }

        public static bool DeepEquals(object[] a1, object[] a2)
        {
            if (a1 == a2) return true;
            if (a1 == null || a2 == null) return false;
            if (a1.Length != a2.Length) return false;
            for (int i = 0; i < a1.Length; i++)
            {
                if (!Equals(a1[i], a2[i])) return false;
            }
            return true;
        }

        public static int DeepHashCode(object[] a)
        {
            int result = 1;
            foreach (var element in a)
                result = 31 * result + (element?.GetHashCode() ?? 0);
            return result;
        }

        public static string DeepToString(object[] a)
        {
            return "[" + string.Join(", ", a) + "]";
        }

        public static void ParallelSort(int[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(int[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(long[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(object[] a, int fromIndex, int toIndex, IComparer<object> c)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex, c);
        }

        public static void ParallelSort(short[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(object[] a, IComparer<object> c)
        {
            Array.Sort(a, c);
        }

        public static void ParallelSort(short[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(double[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(double[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(float[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(float[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(IComparable[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(IComparable[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(byte[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(byte[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(char[] a)
        {
            Array.Sort(a);
        }

        public static void ParallelSort(char[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelSort(long[] a, int fromIndex, int toIndex)
        {
            Array.Sort(a, fromIndex, toIndex - fromIndex);
        }

        public static void ParallelPrefix(double[] array, int fromIndex, int toIndex, Func<double, double, double> op)
        {
            for (int i = fromIndex + 1; i < toIndex; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(double[] array, Func<double, double, double> op)
        {
            for (int i = 1; i < array.Length; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(int[] array, Func<int, int, int> op)
        {
            for (int i = 1; i < array.Length; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(int[] array, int fromIndex, int toIndex, Func<int, int, int> op)
        {
            for (int i = fromIndex + 1; i < toIndex; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(long[] array, int fromIndex, int toIndex, Func<long, long, long> op)
        {
            for (int i = fromIndex + 1; i < toIndex; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(long[] array, Func<long, long, long> op)
        {
            for (int i = 1; i < array.Length; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(object[] array, int fromIndex, int toIndex, Func<object, object, object> op)
        {
            for (int i = fromIndex + 1; i < toIndex; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static void ParallelPrefix(object[] array, Func<object, object, object> op)
        {
            for (int i = 1; i < array.Length; i++)
                array[i] = op(array[i - 1], array[i]);
        }

        public static int BinarySearch(float[] a, int fromIndex, int toIndex, float key)
        {
            return Array.BinarySearch(a, fromIndex, toIndex - fromIndex, key);
        }

        public static int BinarySearch(float[] a, float key)
        {
            return Array.BinarySearch(a, key);
        }

        public static int BinarySearch(short[] a, short key)
        {
            return Array.BinarySearch(a, key);
        }

        public static int BinarySearch(short[] a, int fromIndex, int toIndex, short key)
        {
            return Array.BinarySearch(a, fromIndex, toIndex - fromIndex, key);
        }

        public static int BinarySearch(object[] a, object key)
        {
            return Array.BinarySearch(a, key);
        }

        public static int BinarySearch(object[] a, int fromIndex