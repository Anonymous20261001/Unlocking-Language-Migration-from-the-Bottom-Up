using System;

namespace Generated.Test
{
    public class ValueRange
    {
        private readonly long minSmallest;
        private readonly long minLargest;
        private readonly long maxSmallest;
        private readonly long maxLargest;

        private ValueRange(long minSmallest, long minLargest, long maxSmallest, long maxLargest)
        {
            this.minSmallest = minSmallest;
            this.minLargest = minLargest;
            this.maxSmallest = maxSmallest;
            this.maxLargest = maxLargest;
        }

        public static ValueRange Of(long min, long max)
        {
            if (min > max)
            {
                throw new ArgumentException("Minimum value must be less than or equal to maximum value");
            }
            return new ValueRange(min, min, max, max);
        }

        public static ValueRange Of(long min, long maxSmallest, long maxLargest)
        {
            if (min > maxSmallest || maxSmallest > maxLargest)
            {
                throw new ArgumentException("Invalid range parameters");
            }
            return new ValueRange(min, min, maxSmallest, maxLargest);
        }

        public static ValueRange Of(long minSmallest, long minLargest, long maxSmallest, long maxLargest)
        {
            if (minSmallest > minLargest || minLargest > maxSmallest || maxSmallest > maxLargest)
            {
                throw new ArgumentException("Invalid range parameters");
            }
            return new ValueRange(minSmallest, minLargest, maxSmallest, maxLargest);
        }

        public long GetMinimum()
        {
            return minSmallest;
        }

        public long GetLargestMinimum()
        {
            return minLargest;
        }

        public long GetSmallestMaximum()
        {
            return maxSmallest;
        }

        public long GetMaximum()
        {
            return maxLargest;
        }

        public bool IsFixed()
        {
            return minSmallest == minLargest && maxSmallest == maxLargest;
        }

        public bool IsIntValue()
        {
            return GetMinimum() >= int.MinValue && GetMaximum() <= int.MaxValue;
        }

        public bool IsValidValue(long value)
        {
            return value >= GetMinimum() && value <= GetMaximum();
        }

        public bool IsValidIntValue(int value)
        {
            return IsIntValue() && IsValidValue(value);
        }

        public int CheckValidIntValue(long value, string field)
        {
            if (!IsValidIntValue(value))
            {
                throw new ArgumentOutOfRangeException(field, "Invalid int value for " + field + ": " + value);
            }
            return (int)value;
        }

        public long CheckValidValue(long value, string field)
        {
            if (!IsValidValue(value))
            {
                throw new ArgumentOutOfRangeException(field, "Invalid value for " + field + ": " + value);
            }
            return value;
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
            {
                return true;
            }
            if (obj is ValueRange other)
            {
                return minSmallest == other.minSmallest &&
                       minLargest == other.minLargest &&
                       maxSmallest == other.maxSmallest &&
                       maxLargest == other.maxLargest;
            }
            return false;
        }

        public override int GetHashCode()
        {
            long hash = minSmallest + minLargest * 37 + maxSmallest * 37 * 37 + maxLargest * 37 * 37 * 37;
            return (int)(hash ^ (hash >> 32));
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(minSmallest);
            if (minSmallest != minLargest)
            {
                sb.Append('/').Append(minLargest);
            }
            sb.Append(" - ");
            sb.Append(maxSmallest);
            if (maxSmallest != maxLargest)
            {
                sb.Append('/').Append(maxLargest);
            }
            return sb.ToString();
        }
    }

    public class java_time_temporal_ValueRangeAutoTest
    {
        public void of_test_13306(long p0, long p1)
        {
            ValueRange.Of(p0, p1);
        }

        public void of_test_13307(long p0, long p1, long p2, long p3)
        {
            ValueRange.Of(p0, p1, p2, p3);
        }

        public void of_test_13308(long p0, long p1, long p2)
        {
            ValueRange.Of(p0, p1, p2);
        }
    }
}