namespace Generated.Test
{
    public class java_awt_AlphaCompositeAutoTest
    {
        public void getInstance_test_144(int p0)
        {
            AlphaComposite.getInstance(p0);
        }

        public void getInstance_test_145(int p0, float p1)
        {
            AlphaComposite.getInstance(p0, p1);
        }
    }

    public class AlphaComposite
    {
        public static AlphaComposite getInstance(int rule)
        {
            return new AlphaComposite(rule, 1.0f);
        }

        public static AlphaComposite getInstance(int rule, float alpha)
        {
            return new AlphaComposite(rule, alpha);
        }

        private int rule;
        private float alpha;

        private AlphaComposite(int rule, float alpha)
        {
            this.rule = rule;
            this.alpha = alpha;
        }
    }
}