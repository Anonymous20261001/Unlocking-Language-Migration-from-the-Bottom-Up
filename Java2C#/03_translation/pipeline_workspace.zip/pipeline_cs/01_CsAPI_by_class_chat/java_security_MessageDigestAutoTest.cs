namespace Generated.Test
{
    using System;
    using System.Security.Cryptography;

    public class java_security_MessageDigestAutoTest
    {
        public void isEqual_test_8592(byte[] p0, byte[] p1)
        {
            // Java's MessageDigest.isEqual performs constant-time comparison
            // C# equivalent using CryptographicOperations.FixedTimeEquals
            // Note: Java's isEqual returns boolean, but here we just call it
            // to match the test behavior (no assertion)
            bool result = CryptographicOperations.FixedTimeEquals(p0, p1);
        }
    }
}