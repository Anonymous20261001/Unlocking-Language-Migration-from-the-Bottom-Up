namespace Generated.Test
{
    using System;
    using System.Net.Http;

    public class java_net_http_HttpClientAutoTest
    {
        public void newBuilder_test_5409()
        {
            HttpClient.NewBuilder();
        }

        public void newHttpClient_test_5410()
        {
            HttpClient.NewHttpClient();
        }
    }

    public class HttpClient
    {
        public static HttpClient NewBuilder()
        {
            return new HttpClient();
        }

        public static HttpClient NewHttpClient()
        {
            return new HttpClient();
        }
    }
}