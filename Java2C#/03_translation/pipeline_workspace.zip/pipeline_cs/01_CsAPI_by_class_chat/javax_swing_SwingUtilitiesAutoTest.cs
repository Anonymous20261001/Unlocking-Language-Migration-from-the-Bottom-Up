using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Generated.Test
{
    // Minimal stubs for Java AWT/Swing types
    public class Component
    {
        public Component Parent { get; set; }
        public string Name { get; set; }
        public Rectangle Bounds { get; set; }
        public bool Visible { get; set; }
        public bool Enabled { get; set; }
        public bool Focusable { get; set; }
        public bool FocusOwner { get; set; }
        public int X { get { return Bounds.X; } }
        public int Y { get { return Bounds.Y; } }
        public int Width { get { return Bounds.Width; } }
        public int Height { get { return Bounds.Height; } }
        public Component ParentComponent { get { return Parent; } }
        public virtual object GetAccessibleContext() { return null; }
        public virtual int GetAccessibleChildrenCount() { return 0; }
        public virtual object GetAccessibleChild(int index) { return null; }
        public virtual object GetAccessibleAt(Point p) { return null; }
        public virtual int GetAccessibleIndexInParent() { return -1; }
        public virtual object GetAccessibleStateSet() { return null; }
        public virtual bool Contains(Point p) { return Bounds.Contains(p); }
        public virtual Component GetComponentAt(int x, int y) { return this; }
        public virtual void UpdateUI() { }
        public virtual bool IsDescendingFrom(Component comp) 
        { 
            Component current = this;
            while (current != null)
            {
                if (current == comp) return true;
                current = current.Parent;
            }
            return false;
        }
    }

    public class Container : Component
    {
        public List<Component> Components { get; } = new List<Component>();
        public void Add(Component comp) { Components.Add(comp); comp.Parent = this; }
        public void Remove(Component comp) { Components.Remove(comp); comp.Parent = null; }
        public Component GetComponent(int index) { return Components[index]; }
        public int ComponentCount { get { return Components.Count; } }
    }

    public class JComponent : Container
    {
        public InputMap InputMap { get; set; }
        public ActionMap ActionMap { get; set; }
        public Rectangle VisibleRect { get; set; }
        public virtual Rectangle GetVisibleRect() { return VisibleRect; }
        public virtual void UpdateUI() { }
    }

    public class JViewport : JComponent
    {
        public Component View { get; set; }
    }

    public class Window : Container
    {
        public string Title { get; set; }
    }

    public class Frame : Window { }
    public class Dialog : Window { }

    public class Graphics
    {
        public void DrawRect(int x, int y, int width, int height) { }
        public void FillRect(int x, int y, int width, int height) { }
        public void DrawString(string str, int x, int y) { }
        public void ClipRect(int x, int y, int width, int height) { }
        public Rectangle ClipBounds { get; set; }
    }

    public class FontMetrics
    {
        public virtual int StringWidth(string str) { return str.Length * 10; }
        public virtual int GetHeight() { return 20; }
        public virtual int GetAscent() { return 15; }
        public virtual int GetDescent() { return 5; }
        public virtual int GetLeading() { return 0; }
    }

    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }
        public Point() { }
        public Point(int x, int y) { X = x; Y = y; }
        public void SetLocation(int x, int y) { X = x; Y = y; }
        public void Translate(int dx, int dy) { X += dx; Y += dy; }
        public override bool Equals(object obj)
        {
            Point p = obj as Point;
            return p != null && p.X == X && p.Y == Y;
        }
        public override int GetHashCode() { return X * 31 + Y; }
    }

    public class Rectangle
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Rectangle() { }
        public Rectangle(int x, int y, int width, int height) { X = x; Y = y; Width = width; Height = height; }
        public Rectangle(Point location, Size size) { X = location.X; Y = location.Y; Width = size.Width; Height = size.Height; }
        public Point Location { get { return new Point(X, Y); } set { X = value.X; Y = value.Y; } }
        public Size Size { get { return new Size(Width, Height); } set { Width = value.Width; Height = value.Height; } }
        public bool Contains(Point p) { return p.X >= X && p.X < X + Width && p.Y >= Y && p.Y < Y + Height; }
        public bool Contains(Rectangle r) { return r.X >= X && r.Y >= Y && r.X + r.Width <= X + Width && r.Y + r.Height <= Y + Height; }
        public bool Intersects(Rectangle r) { return X < r.X + r.Width && X + Width > r.X && Y < r.Y + r.Height && Y + Height > r.Y; }
        public Rectangle Intersection(Rectangle r)
        {
            int x1 = Math.Max(X, r.X);
            int y1 = Math.Max(Y, r.Y);
            int x2 = Math.Min(X + Width, r.X + r.Width);
            int y2 = Math.Min(Y + Height, r.Y + r.Height);
            if (x2 <= x1 || y2 <= y1) return new Rectangle();
            return new Rectangle(x1, y1, x2 - x1, y2 - y1);
        }
        public Rectangle Union(Rectangle r)
        {
            int x1 = Math.Min(X, r.X);
            int y1 = Math.Min(Y, r.Y);
            int x2 = Math.Max(X + Width, r.X + r.Width);
            int y2 = Math.Max(Y + Height, r.Y + r.Height);
            return new Rectangle(x1, y1, x2 - x1, y2 - y1);
        }
        public void Add(Rectangle r)
        {
            Rectangle union = Union(r);
            X = union.X; Y = union.Y; Width = union.Width; Height = union.Height;
        }
        public void Translate(int dx, int dy) { X += dx; Y += dy; }
        public void Grow(int h, int v) { X -= h; Y -= v; Width += 2 * h; Height += 2 * v; }
        public override bool Equals(object obj)
        {
            Rectangle r = obj as Rectangle;
            return r != null && r.X == X && r.Y == Y && r.Width == Width && r.Height == Height;
        }
        public override int GetHashCode() { return X * 31 * 31 + Y * 31 + Width * 7 + Height; }
        public override string ToString() { return $"Rectangle[x={X},y={Y},width={Width},height={Height}]"; }
    }

    public class Size
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public Size() { }
        public Size(int width, int height) { Width = width; Height = height; }
    }

    public class KeyEvent
    {
        public int KeyCode { get; set; }
        public char KeyChar { get; set; }
        public int Modifiers { get; set; }
        public Component Source { get; set; }
        public bool Consumed { get; private set; }
        public void Consume() { Consumed = true; }
    }

    public class MouseEvent
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Button { get; set; }
        public int ClickCount { get; set; }
        public int Modifiers { get; set; }
        public Component Source { get; set; }
        public bool Consumed { get; private set; }
        public void Consume() { Consumed = true; }
        public Point GetPoint() { return new Point(X, Y); }
    }

    public class KeyStroke
    {
        public int KeyCode { get; set; }
        public int Modifiers { get; set; }
        public static KeyStroke GetKeyStroke(int keyCode, int modifiers) { return new KeyStroke { KeyCode = keyCode, Modifiers = modifiers }; }
    }

    public class Action
    {
        public string Name { get; set; }
        public virtual void ActionPerformed(KeyEvent e) { }
    }

    public class ActionMap
    {
        private Dictionary<object, Action> actions = new Dictionary<object, Action>();
        public void Put(object key, Action action) { actions[key] = action; }
        public Action Get(object key) { return actions.ContainsKey(key) ? actions[key] : null; }
        public void Clear() { actions.Clear(); }
    }

    public class InputMap
    {
        private Dictionary<KeyStroke, object> bindings = new Dictionary<KeyStroke, object>();
        public void Put(KeyStroke keyStroke, object actionMapKey) { bindings[keyStroke] = actionMapKey; }
        public object Get(KeyStroke keyStroke) { return bindings.ContainsKey(keyStroke) ? bindings[keyStroke] : null; }
        public void Clear() { bindings.Clear(); }
    }

    public class Icon
    {
        public int IconWidth { get; set; }
        public int IconHeight { get; set; }
        public virtual void PaintIcon(Component c, Graphics g, int x, int y) { }
    }

    public class Class
    {
        public string Name { get; set; }
        public static Class ForName(string name) { return new Class { Name = name }; }
        public bool IsInstance(object obj) { return obj != null && obj.GetType().Name == Name; }
    }

    public class Runnable
    {
        public Action RunAction { get; set; }
        public void Run() { RunAction?.Invoke(); }
    }

    public class SwingUtilities
    {
        public static Component GetUnwrappedParent(Component component)
        {
            return component?.Parent;
        }

        public static bool IsEventDispatchThread()
        {
            return true;
        }

        public static void UpdateComponentTreeUI(Component c)
        {
            if (c is JComponent jc)
                jc.UpdateUI();
            if (c is Container container)
            {
                foreach (var child in container.Components)
                    UpdateComponentTreeUI(child);
            }
        }

        public static bool IsDescendingFrom(Component a, Component b)
        {
            return a != null && b != null && a.IsDescendingFrom(b);
        }

        public static ActionMap GetUIActionMap(JComponent component)
        {
            return component?.ActionMap;
        }

        public static Component GetRootPane(Component c)
        {
            Component current = c;
            while (current != null && !(current is JComponent && current.Name == "rootPane"))
                current = current.Parent;
            return current;
        }

        public static Window GetWindowAncestor(Component c)
        {
            Component current = c;
            while (current != null && !(current is Window))
                current = current.Parent;
            return current as Window;
        }

        public static Rectangle ComputeIntersection(int x, int y, int width, int height, Rectangle rect)
        {
            Rectangle r = new Rectangle(x, y, width, height);
            Rectangle intersection = r.Intersection(rect);
            rect.X = intersection.X;
            rect.Y = intersection.Y;
            rect.Width = intersection.Width;
            rect.Height = intersection.Height;
            return rect;
        }

        public static void PaintComponent(Graphics g, Component c, Container p, Rectangle r)
        {
            PaintComponent(g, c, p, r.X, r.Y, r.Width, r.Height);
        }

        public static void PaintComponent(Graphics g, Component c, Container p, int x, int y, int w, int h)
        {
            // Stub implementation
        }

        public static bool ProcessKeyBindings(KeyEvent e)
        {
            return false;
        }

        public static void NotifyAction(Action action, KeyStroke ks, KeyEvent e, object sender, int modifiers)
        {
            action?.ActionPerformed(e);
        }

        public static Rectangle ConvertRectangle(Component source, Rectangle rect, Component target)
        {
            return new Rectangle(rect.X, rect.Y, rect.Width, rect.Height);
        }

        public static void InvokeLater(Runnable runnable)
        {
            runnable?.Run();
        }

        public static int GetAccessibleChildrenCount(Component c)
        {
            return c?.GetAccessibleChildrenCount() ?? 0;
        }

        public static object GetAccessibleChild(Component c, int i)
        {
            return c?.GetAccessibleChild(i);
        }

        public static object GetAccessibleAt(Component c, Point p)
        {
            return c?.GetAccessibleAt(p);
        }

        public static int GetAccessibleIndexInParent(Component c)
        {
            return c?.GetAccessibleIndexInParent() ?? -1;
        }

        public static object GetAccessibleStateSet(Component c)
        {
            return c?.GetAccessibleStateSet();
        }

        public static Point ConvertPoint(Component source, Point aPoint, Component target)
        {
            return new Point(aPoint.X, aPoint.Y);
        }

        public static Point ConvertPoint(Component source, int x, int y, Component target)
        {
            return new Point(x, y);
        }

        public static MouseEvent ConvertMouseEvent(Component source, MouseEvent sourceEvent, Component destination)
        {
            return sourceEvent;
        }

        public static void ReplaceUIInputMap(JComponent component, int type, InputMap map)
        {
            component.InputMap = map;
        }

        public static void ReplaceUIActionMap(JComponent component, ActionMap map)
        {
            component.ActionMap = map;
        }

        public static InputMap GetUIInputMap(JComponent component, int type)
        {
            return component?.InputMap;
        }

        public static bool IsLeftMouseButton(MouseEvent anEvent)
        {
            return anEvent.Button == 1;
        }

        public static string LayoutCompoundLabel(FontMetrics fm, string text, Icon icon, int verticalAlignment,
            int horizontalAlignment, int verticalTextPosition, int horizontalTextPosition,
            Rectangle viewR, Rectangle iconR, Rectangle textR, int textIconGap)
        {
            // Stub implementation
            return text;
        }

        public static string LayoutCompoundLabel(JComponent c, FontMetrics fm, string text, Icon icon,
            int verticalAlignment, int horizontalAlignment, int verticalTextPosition, int horizontalTextPosition,
            Rectangle viewR, Rectangle iconR, Rectangle textR, int textIconGap)
        {
            // Stub implementation
            return text;
        }

        public static Component GetAncestorOfClass(Class c, Component comp)
        {
            Component current = comp?.Parent;
            while (current != null)
            {
                if (c.IsInstance(current))
                    return current;
                current = current.Parent;
            }
            return null;
        }

        public static void ConvertPointToScreen(Point p, Component c)
        {
            // Stub implementation
        }

        public static void ConvertPointFromScreen(Point p, Component c)
        {
            // Stub implementation
        }

        public static Component GetDeepestComponentAt(Component parent, int x, int y)
        {
            if (parent is Container container)
            {
                foreach (var child in container.Components)
                {
                    if (child.Bounds.Contains(new Point(x, y)))
                    {
                        Component deeper = GetDeepestComponentAt(child, x - child.X, y - child.Y);
                        return deeper ?? child;
                    }
                }
            }
            return parent;
        }

        public static bool IsRectangleContainingRectangle(Rectangle r1, Rectangle r2)
        {
            return r1.Contains(r2);
        }

        public static Rectangle GetLocalBounds(Component aComponent)
        {
            return new Rectangle(0, 0, aComponent.Width, aComponent.Height);
        }

        public static Component GetAncestorNamed(string name, Component comp)
        {
            Component current = comp?.Parent;
            while (current != null)
            {
                if (current.Name == name)
                    return current;
                current = current.Parent;
            }
            return null;
        }

        public static Window WindowForComponent(Component c)
        {
            return GetWindowAncestor(c);
        }

        public static Rectangle ComputeUnion(int x, int y, int width, int height, Rectangle rect)
        {
            Rectangle r = new Rectangle(x, y, width, height);
            Rectangle union = r.Union(rect);
            rect.X = union.X;
            rect.Y = union.Y;
            rect.Width = union.Width;
            rect.Height = union.Height;
            return rect;
        }

        public static Rectangle[] ComputeDifference(Rectangle rectA, Rectangle rectB)
        {
            List<Rectangle> result = new List<Rectangle>();
            Rectangle intersection = rectA.Intersection(rectB);
            if (intersection.Width <= 0 || intersection.Height <= 0)
            {
                result.Add(rectA);
                return result.ToArray();
            }

            // Top
            if (rectA.Y < intersection.Y)
                result.Add(new Rectangle(rectA.X, rectA.Y, rectA.Width, intersection.Y - rectA.Y));
            // Bottom
            if (rectA.Y + rectA.Height > intersection.Y + intersection.Height)
                result.Add(new Rectangle(rectA.X, intersection.Y + intersection.Height, rectA.Width,
                    rectA.Y + rectA.Height - intersection.Y - intersection.Height));
            // Left
            if (rectA.X < intersection.X)
                result.Add(new Rectangle(rectA.X, intersection.Y, intersection.X - rectA.X, intersection.Height));
            // Right
            if (rectA.X + rectA.Width > intersection.X + intersection.Width)
                result.Add(new Rectangle(intersection.X + intersection.Width, intersection.Y,
                    rectA.X + rectA.Width - intersection.X - intersection.Width, intersection.Height));

            return result.ToArray();
        }

        public static bool IsMiddleMouseButton(MouseEvent anEvent)
        {
            return anEvent.Button == 2;
        }

        public static bool IsRightMouseButton(MouseEvent anEvent)
        {
            return anEvent.Button == 3;
        }

        public static int ComputeStringWidth(FontMetrics fm, string str)
        {
            return fm?.StringWidth(str) ?? 0;
        }

        public static Component FindFocusOwner(Component c)
        {
            if (c is Container container)
            {
                foreach (var child in container.Components)
                {
                    if (child.FocusOwner)
                        return child;
                    Component found = FindFocusOwner(child);
                    if (found != null)
                        return found;
                }
            }
            return null;
        }

        public static Rectangle CalculateInnerArea(JComponent c, Rectangle r)
        {
            Rectangle bounds = c.Bounds;
            r.X = 0;
            r.Y = 0;
            r.Width = bounds.Width;
            r.Height = bounds.Height;
            return r;
        }

        public static Component GetUnwrappedView(JViewport viewport)
        {
            return viewport?.View;
        }

        public static Component GetRoot(Component c)
        {
            Component current = c;
            while (current?.Parent != null)
                current = current.Parent;
            return current;
        }
    }

    public class javax_swing_SwingUtilitiesAutoTest
    {
        public void getUnwrappedParent_test_12073(Component p0)
        {
            SwingUtilities.GetUnwrappedParent(p0);
        }

        public void isEventDispatchThread_test_12074()
        {
            SwingUtilities.IsEventDispatchThread();
        }

        public void updateComponentTreeUI_test_12075(Component p0)
        {
            SwingUtilities.UpdateComponentTreeUI(p0);
        }

        public void isDescendingFrom_test_12076(Component p0, Component p1)
        {
            SwingUtilities.IsDescendingFrom(p0, p1);
        }

        public void getUIActionMap_test_12077(JComponent p0)
        {
            SwingUtilities.GetUIActionMap(p0);
        }

        public void getRootPane_test_12078(Component p0)
        {
            SwingUtilities.GetRootPane(p0);
        }

        public void getWindowAncestor_test_12079(Component p0)
        {
            SwingUtilities.GetWindowAncestor(p0);
        }

        public void computeIntersection_test_12080(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            SwingUtilities.ComputeIntersection(p0, p1, p2, p3, p4);
        }

        public void paintComponent_test_12081(Graphics p0, Component p1, Container p2, Rectangle p3)
        {
            SwingUtilities.PaintComponent(p0, p1, p2, p3);
        }

        public void paintComponent_test_12082(Graphics p0, Component p1, Container p2, int p3, int p4,
            int p5, int p6)
        {
            SwingUtilities.PaintComponent(p0, p1, p2, p3, p4, p5, p6);
        }

        public void processKeyBindings_test_12083(KeyEvent p0)
        {
            SwingUtilities.ProcessKeyBindings(p0);
        }

        public void notifyAction_test_12084(Action p0, KeyStroke p1, KeyEvent p2, object p3, int p4)
        {
            SwingUtilities.NotifyAction(p0, p1, p2, p3, p4);
        }

        public void convertRectangle_test_12085(Component p0, Rectangle p1, Component p2)
        {
            SwingUtilities.ConvertRectangle(p0, p1, p2);
        }

        public void invokeLater_test_12086(Runnable p0)
        {
            SwingUtilities.InvokeLater(p0);
        }

        public void getAccessibleChildrenCount_test_12087(Component p0)
        {
            SwingUtilities.GetAccessibleChildrenCount(p0);
        }

        public void getAccessibleChild_test_12088(Component p0, int p1)
        {
            SwingUtilities.GetAccessibleChild(p0, p1);
        }

        public void getAccessibleAt_test_12089(Component p0, Point p1)
        {
            SwingUtilities.GetAccessibleAt(p0, p1);
        }

        public void getAccessibleIndexInParent_test_12090(Component p0)
        {
            SwingUtilities.GetAccessibleIndexInParent(p0);
        }

        public void getAccessibleStateSet_test_12091(Component p0)
        {
            SwingUtilities.GetAccessibleStateSet(p0);
        }

        public void convertPoint_test_12092(Component p0, Point p1, Component p2)
        {
            SwingUtilities.ConvertPoint(p0, p1, p2);
        }

        public void convertPoint_test_12093(Component p0, int p1, int p2, Component p3)
        {
            SwingUtilities.ConvertPoint(p0, p1, p2, p3);
        }

        public void convertMouseEvent_test_12094(Component p0, MouseEvent p1, Component p2)
        {
            SwingUtilities.ConvertMouseEvent(p0, p1, p2);
        }

        public void replaceUIInputMap_test_12095(JComponent p0, int p1, InputMap p2)
        {
            SwingUtilities.ReplaceUIInputMap(p0, p1, p2);
        }

        public void replaceUIActionMap_test_12096(JComponent p0, ActionMap p1)
        {
            SwingUtilities.ReplaceUIActionMap(p0, p1);
        }

        public void getUIInputMap_test_12097(JComponent p0, int p1)
        {
            SwingUtilities.GetUIInputMap(p0, p1);
        }

        public void isLeftMouseButton_test_12098(MouseEvent p0)
        {
            SwingUtilities.IsLeftMouseButton(p0);
        }

        public void layoutCompoundLabel_test_12099(FontMetrics p0, string p1, Icon p2, int p3, int p4,
            int p5, int p6, Rectangle p7, Rectangle p8, Rectangle p9, int p10)
        {
            SwingUtilities.LayoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
        }

        public void layoutCompoundLabel_test_12100(JComponent p0, FontMetrics p1, string p2, Icon p3,
            int p4, int p5, int p6, int p7, Rectangle p8, Rectangle p9, Rectangle p10, int p11)
        {
            SwingUtilities.LayoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11);
        }

        public void getAncestorOfClass_test_12101(Class p0, Component p1)
        {
            SwingUtilities.GetAncestorOfClass(p0, p1);
        }

        public void convertPointToScreen_test_12102(Point p0, Component p1)
        {
            SwingUtilities.ConvertPointToScreen(p0, p1);
        }

        public void convertPointFromScreen_test_12103(Point p0, Component p1)
        {
            SwingUtilities.ConvertPointFromScreen(p0, p1);
        }

        public void getDeepestComponentAt_test_12104(Component p0, int p1, int p2)
        {
            SwingUtilities.GetDeepestComponentAt(p0, p1, p2);
        }

        public void isRectangleContainingRectangle_test_12105(Rectangle p0, Rectangle p1)
        {
            SwingUtilities.IsRectangleContainingRectangle(p0, p1);
        }

        public void getLocalBounds_test_12106(Component p0)
        {
            SwingUtilities.GetLocalBounds(p0);
        }

        public void getAncestorNamed_test_12107(string p0, Component p1)
        {
            SwingUtilities.GetAncestorNamed(p0, p1);
        }

        public void windowForComponent_test_12108(Component p0)
        {
            SwingUtilities.WindowForComponent(p0);
        }

        public void computeUnion_test_12109(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            SwingUtilities.ComputeUnion(p0, p1, p2, p3, p4);
        }

        public void computeDifference_test_12110(Rectangle p0, Rectangle p1)
        {
            SwingUtilities.ComputeDifference(p0, p1);
        }

        public void isMiddleMouseButton_test_12111(MouseEvent p0)
        {
            SwingUtilities.IsMiddleMouseButton(p0);
        }

        public void isRightMouseButton_test_12112(MouseEvent p0)
        {
            SwingUtilities.IsRightMouseButton(p0);
        }

        public void computeStringWidth_test_12113(FontMetrics p0, string p1)
        {
            SwingUtilities.ComputeStringWidth(p0, p1);
        }

        public void findFocusOwner_test_12114(Component p0)
        {
            SwingUtilities.FindFocusOwner(p0);
        }

        public void calculateInnerArea_test_12115(JComponent p0, Rectangle p1)
        {
            SwingUtilities.CalculateInnerArea(p0, p1);
        }

        public void getUnwrappedView_test_12116(JViewport p0)
        {
            SwingUtilities.GetUnwrappedView(p0);
        }

        public void getRoot_test_12117(Component p0)
        {
            SwingUtilities.GetRoot(p0);
        }
    }
}