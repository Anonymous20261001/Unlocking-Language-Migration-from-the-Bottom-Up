namespace Generated.Test
{
    using System;
    using System.Globalization;

    public class java_time_YearMonthAutoTest
    {
        public void of_test_13674(int p0, int p1)
        {
            YearMonth.Of(p0, p1);
        }

        public void of_test_13675(int p0, Month p1)
        {
            YearMonth.Of(p0, p1);
        }

        public void from_test_13676(TemporalAccessor p0)
        {
            YearMonth.From(p0);
        }

        public void parse_test_13677(CharSequence p0, DateTimeFormatter p1)
        {
            YearMonth.Parse(p0, p1);
        }

        public void parse_test_13678(CharSequence p0)
        {
            YearMonth.Parse(p0);
        }

        public void now_test_13679()
        {
            YearMonth.Now();
        }

        public void now_test_13680(ZoneId p0)
        {
            YearMonth.Now(p0);
        }

        public void now_test_13681(Clock p0)
        {
            YearMonth.Now(p0);
        }
    }

    public class YearMonth
    {
        private readonly int _year;
        private readonly int _month;

        private YearMonth(int year, int month)
        {
            _year = year;
            _month = month;
        }

        public static YearMonth Of(int year, int month)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month), "Month must be between 1 and 12");
            return new YearMonth(year, month);
        }

        public static YearMonth Of(int year, Month month)
        {
            return Of(year, (int)month);
        }

        public static YearMonth From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return temporal.ToYearMonth();
        }

        public static YearMonth Parse(CharSequence text, DateTimeFormatter formatter)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            if (formatter == null)
                throw new ArgumentNullException(nameof(formatter));
            return formatter.ParseYearMonth(text.ToString());
        }

        public static YearMonth Parse(CharSequence text)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            return Parse(text, DateTimeFormatter.ISO_LOCAL_DATE);
        }

        public static YearMonth Now()
        {
            return Now(Clock.SystemDefaultZone());
        }

        public static YearMonth Now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException(nameof(zone));
            return Now(Clock.System(zone));
        }

        public static YearMonth Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            var now = clock.Instant();
            var dateTime = now.ToDateTime(clock.Zone);
            return new YearMonth(dateTime.Year, dateTime.Month);
        }

        public int Year => _year;
        public int MonthValue => _month;
    }

    public enum Month
    {
        January = 1,
        February = 2,
        March = 3,
        April = 4,
        May = 5,
        June = 6,
        July = 7,
        August = 8,
        September = 9,
        October = 10,
        November = 11,
        December = 12
    }

    public class CharSequence
    {
        private readonly string _value;

        public CharSequence(string value)
        {
            _value = value ?? throw new ArgumentNullException(nameof(value));
        }

        public static implicit operator CharSequence(string value) => new CharSequence(value);
        public static implicit operator string(CharSequence value) => value?._value;

        public override string ToString() => _value;
    }

    public class TemporalAccessor
    {
        public virtual YearMonth ToYearMonth()
        {
            throw new NotSupportedException("This TemporalAccessor does not support conversion to YearMonth");
        }
    }

    public class DateTimeFormatter
    {
        public static DateTimeFormatter ISO_LOCAL_DATE { get; } = new DateTimeFormatter("yyyy-MM");

        private readonly string _pattern;

        private DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public YearMonth ParseYearMonth(string text)
        {
            if (DateTime.TryParseExact(text, _pattern, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dateTime))
            {
                return YearMonth.Of(dateTime.Year, dateTime.Month);
            }
            throw new FormatException($"Text '{text}' could not be parsed as YearMonth with pattern '{_pattern}'");
        }
    }

    public class ZoneId
    {
        public string Id { get; }

        private ZoneId(string id)
        {
            Id = id;
        }

        public static ZoneId Of(string id)
        {
            return new ZoneId(id);
        }

        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }
    }

    public class Clock
    {
        private readonly DateTimeOffset _now;
        private readonly ZoneId _zone;

        private Clock(DateTimeOffset now, ZoneId zone)
        {
            _now = now;
            _zone = zone;
        }

        public static Clock SystemDefaultZone()
        {
            return System(ZoneId.SystemDefault());
        }

        public static Clock System(ZoneId zone)
        {
            return new Clock(DateTimeOffset.Now, zone);
        }

        public DateTimeOffset Instant() => _now;
        public ZoneId Zone => _zone;
    }

    public static class ClockExtensions
    {
        public static DateTime ToDateTime(this DateTimeOffset offset, ZoneId zone)
        {
            return offset.ToOffset(TimeSpan.Zero).DateTime;
        }
    }
}