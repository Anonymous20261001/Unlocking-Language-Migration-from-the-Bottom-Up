namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Cryptography;

    public class Provider
    {
        public string Name { get; set; }
        public double Version { get; set; }
        public string Info { get; set; }
        private Dictionary<string, string> properties = new Dictionary<string, string>();

        public Provider(string name, double version, string info)
        {
            Name = name;
            Version = version;
            Info = info;
        }

        public string GetProperty(string key)
        {
            return properties.ContainsKey(key) ? properties[key] : null;
        }

        public void SetProperty(string key, string value)
        {
            properties[key] = value;
        }

        public override string ToString()
        {
            return Name + " version " + Version;
        }
    }

    public static class Security
    {
        private static Dictionary<string, string> properties = new Dictionary<string, string>();
        private static List<Provider> providers = new List<Provider>();

        public static string GetProperty(string key)
        {
            return properties.ContainsKey(key) ? properties[key] : null;
        }

        public static void SetProperty(string key, string value)
        {
            properties[key] = value;
        }

        public static int AddProvider(Provider provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");
            if (providers.Any(p => p.Name == provider.Name))
                return -1;
            providers.Add(provider);
            return providers.Count;
        }

        public static int InsertProviderAt(Provider provider, int position)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");
            if (position < 1 || position > providers.Count + 1)
                throw new ArgumentException("position out of range");
            if (providers.Any(p => p.Name == provider.Name))
                return -1;
            providers.Insert(position - 1, provider);
            return position;
        }

        public static Provider GetProvider(string name)
        {
            return providers.FirstOrDefault(p => p.Name == name);
        }

        public static Provider[] GetProviders()
        {
            return providers.ToArray();
        }

        public static Provider[] GetProviders(Dictionary<string, string> filter)
        {
            if (filter == null || filter.Count == 0)
                return GetProviders();
            return providers.Where(p =>
            {
                foreach (var kvp in filter)
                {
                    string value = p.GetProperty(kvp.Key);
                    if (value == null || !value.Equals(kvp.Value, StringComparison.OrdinalIgnoreCase))
                        return false;
                }
                return true;
            }).ToArray();
        }

        public static Provider[] GetProviders(string filter)
        {
            if (string.IsNullOrEmpty(filter))
                return GetProviders();
            // Parse filter like "Key" or "Key:Value"
            string[] parts = filter.Split(':');
            if (parts.Length == 1)
            {
                return providers.Where(p => p.GetProperty(parts[0]) != null).ToArray();
            }
            else if (parts.Length == 2)
            {
                return providers.Where(p =>
                {
                    string value = p.GetProperty(parts[0]);
                    return value != null && value.Equals(parts[1], StringComparison.OrdinalIgnoreCase);
                }).ToArray();
            }
            return new Provider[0];
        }

        public static string GetAlgorithmProperty(string algName, string propName)
        {
            foreach (var provider in providers)
            {
                string value = provider.GetProperty("Alg." + algName + "." + propName);
                if (value != null)
                    return value;
            }
            return null;
        }

        public static void RemoveProvider(string name)
        {
            var provider = providers.FirstOrDefault(p => p.Name == name);
            if (provider != null)
                providers.Remove(provider);
        }

        public static HashSet<string> GetAlgorithms(string serviceName)
        {
            var result = new HashSet<string>();
            foreach (var provider in providers)
            {
                foreach (var key in provider.GetAllPropertyKeys())
                {
                    if (key.StartsWith("Alg." + serviceName + "."))
                    {
                        string algName = key.Substring(("Alg." + serviceName + ".").Length);
                        int dotIndex = algName.IndexOf('.');
                        if (dotIndex > 0)
                            algName = algName.Substring(0, dotIndex);
                        result.Add(algName);
                    }
                }
            }
            return result;
        }
    }

    public static class ProviderExtensions
    {
        public static IEnumerable<string> GetAllPropertyKeys(this Provider provider)
        {
            // This is a simplified implementation; in real usage, we'd need to expose the properties dictionary
            // For this test, we'll return an empty collection
            return new List<string>();
        }
    }

    public class java_security_SecurityAutoTest
    {
        public void getProperty_test_10968(string p0)
        {
            Security.GetProperty(p0);
        }

        public void setProperty_test_10969(string p0, string p1)
        {
            Security.SetProperty(p0, p1);
        }

        public void addProvider_test_10970(Provider p0)
        {
            Security.AddProvider(p0);
        }

        public void insertProviderAt_test_10971(Provider p0, int p1)
        {
            Security.InsertProviderAt(p0, p1);
        }

        public void getProvider_test_10972(string p0)
        {
            Security.GetProvider(p0);
        }

        public void getProviders_test_10973()
        {
            Security.GetProviders();
        }

        public void getProviders_test_10974(Dictionary<string, string> p0)
        {
            Security.GetProviders(p0);
        }

        public void getProviders_test_10975(string p0)
        {
            Security.GetProviders(p0);
        }

        public void getAlgorithmProperty_test_10976(string p0, string p1)
        {
            Security.GetAlgorithmProperty(p0, p1);
        }

        public void removeProvider_test_10977(string p0)
        {
            Security.RemoveProvider(p0);
        }

        public void getAlgorithms_test_10978(string p0)
        {
            Security.GetAlgorithms(p0);
        }
    }
}