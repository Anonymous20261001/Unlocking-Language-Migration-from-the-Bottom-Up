namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;

    public class Currency
    {
        private readonly string _currencyCode;
        private readonly string _symbol;
        private readonly int _numericCode;
        private readonly int _fractionDigits;
        private readonly string _displayName;

        private Currency(string currencyCode, string symbol, int numericCode, int fractionDigits, string displayName)
        {
            _currencyCode = currencyCode;
            _symbol = symbol;
            _numericCode = numericCode;
            _fractionDigits = fractionDigits;
            _displayName = displayName;
        }

        public string GetCurrencyCode()
        {
            return _currencyCode;
        }

        public string GetSymbol()
        {
            return _symbol;
        }

        public string GetSymbol(Locale locale)
        {
            return _symbol;
        }

        public int GetNumericCode()
        {
            return _numericCode;
        }

        public int GetDefaultFractionDigits()
        {
            return _fractionDigits;
        }

        public string GetDisplayName()
        {
            return _displayName;
        }

        public string GetDisplayName(Locale locale)
        {
            return _displayName;
        }

        public override string ToString()
        {
            return _currencyCode;
        }

        public static ISet<Currency> GetAvailableCurrencies()
        {
            return new HashSet<Currency>(GetAllCurrencies());
        }

        public static ISet<Currency> AvailableCurrencies()
        {
            return GetAvailableCurrencies();
        }

        public static Currency GetInstance(Locale locale)
        {
            if (locale == null)
            {
                throw new ArgumentNullException(nameof(locale));
            }

            string currencyCode = GetCurrencyCodeFromLocale(locale);
            return GetInstance(currencyCode);
        }

        public static Currency GetInstance(string currencyCode)
        {
            if (string.IsNullOrEmpty(currencyCode))
            {
                throw new ArgumentNullException(nameof(currencyCode));
            }

            currencyCode = currencyCode.ToUpperInvariant();
            foreach (var currency in GetAllCurrencies())
            {
                if (currency.GetCurrencyCode() == currencyCode)
                {
                    return currency;
                }
            }

            throw new ArgumentException($"Unknown currency code: {currencyCode}");
        }

        private static string GetCurrencyCodeFromLocale(Locale locale)
        {
            // Simplified mapping based on common locales
            string country = locale.GetCountry();
            if (string.IsNullOrEmpty(country))
            {
                throw new ArgumentException("Locale must have a country specified");
            }

            switch (country.ToUpperInvariant())
            {
                case "US": return "USD";
                case "GB": return "GBP";
                case "JP": return "JPY";
                case "DE": return "EUR";
                case "FR": return "EUR";
                case "IT": return "EUR";
                case "ES": return "EUR";
                case "CN": return "CNY";
                case "CA": return "CAD";
                case "AU": return "AUD";
                case "CH": return "CHF";
                case "SE": return "SEK";
                case "NO": return "NOK";
                case "DK": return "DKK";
                case "IN": return "INR";
                case "BR": return "BRL";
                case "RU": return "RUB";
                case "KR": return "KRW";
                case "MX": return "MXN";
                case "ZA": return "ZAR";
                case "NZ": return "NZD";
                case "SG": return "SGD";
                case "HK": return "HKD";
                case "NL": return "EUR";
                case "BE": return "EUR";
                case "AT": return "EUR";
                case "PT": return "EUR";
                case "IE": return "EUR";
                case "FI": return "EUR";
                case "GR": return "EUR";
                case "LU": return "EUR";
                case "CY": return "EUR";
                case "MT": return "EUR";
                case "SK": return "EUR";
                case "SI": return "EUR";
                case "EE": return "EUR";
                case "LV": return "EUR";
                case "LT": return "EUR";
                default: throw new ArgumentException($"No currency found for country: {country}");
            }
        }

        private static List<Currency> GetAllCurrencies()
        {
            return new List<Currency>
            {
                new Currency("USD", "$", 840, 2, "US Dollar"),
                new Currency("GBP", "£", 826, 2, "British Pound"),
                new Currency("JPY", "¥", 392, 0, "Japanese Yen"),
                new Currency("EUR", "€", 978, 2, "Euro"),
                new Currency("CNY", "¥", 156, 2, "Chinese Yuan"),
                new Currency("CAD", "$", 124, 2, "Canadian Dollar"),
                new Currency("AUD", "$", 36, 2, "Australian Dollar"),
                new Currency("CHF", "Fr", 756, 2, "Swiss Franc"),
                new Currency("SEK", "kr", 752, 2, "Swedish Krona"),
                new Currency("NOK", "kr", 578, 2, "Norwegian Krone"),
                new Currency("DKK", "kr", 208, 2, "Danish Krone"),
                new Currency("INR", "₹", 356, 2, "Indian Rupee"),
                new Currency("BRL", "R$", 986, 2, "Brazilian Real"),
                new Currency("RUB", "₽", 643, 2, "Russian Ruble"),
                new Currency("KRW", "₩", 410, 0, "South Korean Won"),
                new Currency("MXN", "$", 484, 2, "Mexican Peso"),
                new Currency("ZAR", "R", 710, 2, "South African Rand"),
                new Currency("NZD", "$", 554, 2, "New Zealand Dollar"),
                new Currency("SGD", "$", 702, 2, "Singapore Dollar"),
                new Currency("HKD", "$", 344, 2, "Hong Kong Dollar")
            };
        }
    }

    public class Locale
    {
        private readonly string _language;
        private readonly string _country;

        public Locale(string language, string country)
        {
            _language = language ?? string.Empty;
            _country = country ?? string.Empty;
        }

        public string GetLanguage()
        {
            return _language;
        }

        public string GetCountry()
        {
            return _country;
        }

        public static Locale US => new Locale("en", "US");
        public static Locale UK => new Locale("en", "GB");
        public static Locale JAPAN => new Locale("ja", "JP");
        public static Locale GERMANY => new Locale("de", "DE");
        public static Locale FRANCE => new Locale("fr", "FR");
        public static Locale CHINA => new Locale("zh", "CN");
        public static Locale CANADA => new Locale("en", "CA");
        public static Locale AUSTRALIA => new Locale("en", "AU");
        public static Locale SWITZERLAND => new Locale("de", "CH");
        public static Locale SWEDEN => new Locale("sv", "SE");
        public static Locale NORWAY => new Locale("no", "NO");
        public static Locale DENMARK => new Locale("da", "DK");
        public static Locale INDIA => new Locale("hi", "IN");
        public static Locale BRAZIL => new Locale("pt", "BR");
        public static Locale RUSSIA => new Locale("ru", "RU");
        public static Locale KOREA => new Locale("ko", "KR");
        public static Locale MEXICO => new Locale("es", "MX");
        public static Locale SOUTH_AFRICA => new Locale("en", "ZA");
        public static Locale NEW_ZEALAND => new Locale("en", "NZ");
        public static Locale SINGAPORE => new Locale("en", "SG");
        public static Locale HONG_KONG => new Locale("zh", "HK");
    }

    public class java_util_CurrencyAutoTest
    {
        public void getAvailableCurrencies_test_3161()
        {
            Currency.GetAvailableCurrencies();
        }

        public void availableCurrencies_test_3162()
        {
            Currency.AvailableCurrencies();
        }

        public void getInstance_test_3163(Locale p0)
        {
            Currency.GetInstance(p0);
        }

        public void getInstance_test_3164(string p0)
        {
            Currency.GetInstance(p0);
        }
    }
}