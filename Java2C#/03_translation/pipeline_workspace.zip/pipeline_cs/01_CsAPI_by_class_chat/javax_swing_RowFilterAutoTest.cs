namespace Generated.Test
{
    using System;
    using System.Collections;

    public class RowFilter
    {
        public enum ComparisonType
        {
            BEFORE,
            AFTER,
            EQUALS,
            NOT_EQUALS,
            BEFORE_OR_EQUAL,
            AFTER_OR_EQUAL
        }

        public static RowFilter RegexFilter(string p0, int[] p1)
        {
            return new RowFilter();
        }

        public static RowFilter DateFilter(ComparisonType p0, DateTime p1, int[] p2)
        {
            return new RowFilter();
        }

        public static RowFilter NumberFilter(ComparisonType p0, object p1, int[] p2)
        {
            return new RowFilter();
        }

        public static RowFilter OrFilter(IEnumerable p0)
        {
            return new RowFilter();
        }

        public static RowFilter AndFilter(IEnumerable p0)
        {
            return new RowFilter();
        }

        public static RowFilter NotFilter(RowFilter p0)
        {
            return new RowFilter();
        }
    }

    public class javax_swing_RowFilterAutoTest
    {
        public void regexFilter_test_10708(string p0, int[] p1)
        {
            RowFilter.RegexFilter(p0, p1);
        }

        public void dateFilter_test_10709(RowFilter.ComparisonType p0, DateTime p1, int[] p2)
        {
            RowFilter.DateFilter(p0, p1, p2);
        }

        public void numberFilter_test_10710(RowFilter.ComparisonType p0, object p1, int[] p2)
        {
            RowFilter.NumberFilter(p0, p1, p2);
        }

        public void orFilter_test_10711(IEnumerable p0)
        {
            RowFilter.OrFilter(p0);
        }

        public void andFilter_test_10712(IEnumerable p0)
        {
            RowFilter.AndFilter(p0);
        }

        public void notFilter_test_10713(RowFilter p0)
        {
            RowFilter.NotFilter(p0);
        }
    }
}