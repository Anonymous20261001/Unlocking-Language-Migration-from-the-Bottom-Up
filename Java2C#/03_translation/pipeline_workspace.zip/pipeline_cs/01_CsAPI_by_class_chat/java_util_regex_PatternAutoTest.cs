using System;
using System.Text.RegularExpressions;

namespace Generated.Test
{
    public class java_util_regex_PatternAutoTest
    {
        public void matches_test_9865(string p0, string p1)
        {
            Pattern.matches(p0, p1);
        }

        public void compile_test_9866(string p0)
        {
            Pattern.compile(p0);
        }

        public void compile_test_9867(string p0, int p1)
        {
            Pattern.compile(p0, p1);
        }

        public void quote_test_9868(string p0)
        {
            Pattern.quote(p0);
        }
    }

    public static class Pattern
    {
        public static bool matches(string regex, string input)
        {
            return Regex.IsMatch(input, regex);
        }

        public static Regex compile(string pattern)
        {
            return new Regex(pattern);
        }

        public static Regex compile(string pattern, int flags)
        {
            RegexOptions options = RegexOptions.None;
            if ((flags & 2) != 0) // CASE_INSENSITIVE
                options |= RegexOptions.IgnoreCase;
            if ((flags & 8) != 0) // MULTILINE
                options |= RegexOptions.Multiline;
            if ((flags & 32) != 0) // DOTALL
                options |= RegexOptions.Singleline;
            if ((flags & 256) != 0) // COMMENTS
                options |= RegexOptions.IgnorePatternWhitespace;
            return new Regex(pattern, options);
        }

        public static string quote(string s)
        {
            return Regex.Escape(s);
        }
    }
}