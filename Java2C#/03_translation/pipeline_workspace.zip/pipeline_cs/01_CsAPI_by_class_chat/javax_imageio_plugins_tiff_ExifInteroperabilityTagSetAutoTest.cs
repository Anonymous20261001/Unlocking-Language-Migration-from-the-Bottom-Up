namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_ExifInteroperabilityTagSetAutoTest
    {
        public void getInstance_test_4662()
        {
            ExifInteroperabilityTagSet.getInstance();
        }
    }

    public class ExifInteroperabilityTagSet
    {
        private static ExifInteroperabilityTagSet instance;

        private ExifInteroperabilityTagSet()
        {
        }

        public static ExifInteroperabilityTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new ExifInteroperabilityTagSet();
            }
            return instance;
        }
    }
}