namespace Generated.Test
{
    using System;
    using System.Globalization;
    using System.Collections.Generic;

    public class java_text_CollatorAutoTest
    {
        public void getInstance_test_2349(Locale p0)
        {
            Collator.GetInstance(p0);
        }

        public void getInstance_test_2350()
        {
            Collator.GetInstance();
        }

        public void getAvailableLocales_test_2351()
        {
            Collator.GetAvailableLocales();
        }
    }

    public class Collator
    {
        public static Collator GetInstance()
        {
            return new Collator(CultureInfo.CurrentCulture);
        }

        public static Collator GetInstance(Locale locale)
        {
            return new Collator(locale.ToCultureInfo());
        }

        public static Locale[] GetAvailableLocales()
        {
            var cultures = CultureInfo.GetCultures(CultureTypes.AllCultures);
            var locales = new List<Locale>();
            foreach (var culture in cultures)
            {
                locales.Add(Locale.FromCultureInfo(culture));
            }
            return locales.ToArray();
        }

        private CultureInfo culture;

        private Collator(CultureInfo culture)
        {
            this.culture = culture;
        }
    }

    public class Locale
    {
        public string Language { get; private set; }
        public string Country { get; private set; }
        public string Variant { get; private set; }

        public Locale(string language, string country, string variant)
        {
            Language = language;
            Country = country;
            Variant = variant;
        }

        public CultureInfo ToCultureInfo()
        {
            string name = Language;
            if (!string.IsNullOrEmpty(Country))
            {
                name += "-" + Country;
            }
            if (!string.IsNullOrEmpty(Variant))
            {
                name += "-" + Variant;
            }
            return new CultureInfo(name);
        }

        public static Locale FromCultureInfo(CultureInfo culture)
        {
            string[] parts = culture.Name.Split('-');
            string language = parts.Length > 0 ? parts[0] : "";
            string country = parts.Length > 1 ? parts[1] : "";
            string variant = parts.Length > 2 ? parts[2] : "";
            return new Locale(language, country, variant);
        }
    }
}