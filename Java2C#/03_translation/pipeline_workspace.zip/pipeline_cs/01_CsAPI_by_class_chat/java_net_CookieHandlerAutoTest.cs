namespace Generated.Test
{
    public class java_net_CookieHandlerAutoTest
    {
        public void getDefault_test_3025()
        {
            CookieHandler.GetDefault();
        }

        public void setDefault_test_3026(CookieHandler p0)
        {
            CookieHandler.SetDefault(p0);
        }
    }

    public abstract class CookieHandler
    {
        private static CookieHandler _default;

        public static CookieHandler GetDefault()
        {
            return _default;
        }

        public static void SetDefault(CookieHandler value)
        {
            _default = value;
        }
    }
}