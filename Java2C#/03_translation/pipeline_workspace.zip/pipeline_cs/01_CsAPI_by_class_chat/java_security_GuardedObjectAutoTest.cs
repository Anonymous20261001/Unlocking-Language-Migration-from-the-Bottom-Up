namespace Generated.Test
{
    using System;

    public interface Guard
    {
        void CheckGuard(object obj);
    }

    public class GuardedObject
    {
        private object obj;
        private Guard guard;

        public GuardedObject(object obj, Guard guard)
        {
            this.obj = obj;
            this.guard = guard;
        }

        public object GetObject()
        {
            if (guard != null)
            {
                guard.CheckGuard(obj);
            }
            return obj;
        }
    }

    public class java_security_GuardedObjectAutoTest
    {
        public void getObject_test_5247(object c0, Guard c1)
        {
            GuardedObject instance = new GuardedObject(c0, c1);
            instance.GetObject();
        }
    }
}