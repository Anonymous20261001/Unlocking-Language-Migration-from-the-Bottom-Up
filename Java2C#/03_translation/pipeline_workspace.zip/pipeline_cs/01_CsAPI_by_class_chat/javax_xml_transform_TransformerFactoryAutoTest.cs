using System;
using System.Xml.Xsl;

namespace Generated.Test
{
    public class javax_xml_transform_TransformerFactoryAutoTest
    {
        public void newDefaultInstance_test_12971()
        {
            TransformerFactory.NewDefaultInstance();
        }

        public void newInstance_test_12972(string p0, System.Security.Policy.Evidence p1)
        {
            TransformerFactory.NewInstance(p0, p1);
        }

        public void newInstance_test_12973()
        {
            TransformerFactory.NewInstance();
        }
    }

    public class TransformerFactory
    {
        public static TransformerFactory NewDefaultInstance()
        {
            return new TransformerFactory();
        }

        public static TransformerFactory NewInstance(string factoryClassName, System.Security.Policy.Evidence classLoader)
        {
            return new TransformerFactory();
        }

        public static TransformerFactory NewInstance()
        {
            return new TransformerFactory();
        }
    }
}