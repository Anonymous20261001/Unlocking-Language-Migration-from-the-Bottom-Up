using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Generated.Test
{
    public class Component
    {
        public Component() { }
    }

    public class Frame : Component
    {
        public Frame() { }
    }

    public interface Icon
    {
    }

    public class OptionPaneUI
    {
        public OptionPaneUI() { }
    }

    public class JOptionPane
    {
        public const int DEFAULT_OPTION = -1;
        public const int YES_NO_OPTION = 0;
        public const int YES_NO_CANCEL_OPTION = 1;
        public const int OK_CANCEL_OPTION = 2;
        public const int ERROR_MESSAGE = 0;
        public const int INFORMATION_MESSAGE = 1;
        public const int WARNING_MESSAGE = 2;
        public const int QUESTION_MESSAGE = 3;
        public const int PLAIN_MESSAGE = -1;
        public const int OK_OPTION = 0;
        public const int YES_OPTION = 0;
        public const int NO_OPTION = 1;
        public const int CANCEL_OPTION = 2;
        public const int CLOSED_OPTION = -1;
        public const int UNINITIALIZED_VALUE = 0;

        private OptionPaneUI ui;
        private Icon icon;
        private object message;
        private object[] options;
        private object initialValue;
        private object value;
        private object inputValue;
        private object[] selectionValues;
        private object initialSelectionValue;
        private int messageType = PLAIN_MESSAGE;
        private int optionType = DEFAULT_OPTION;
        private bool wantsInput;
        private static Frame rootFrame;

        public JOptionPane()
        {
            ui = new OptionPaneUI();
        }

        public string GetUIClassID()
        {
            return "OptionPaneUI";
        }

        public void UpdateUI()
        {
            ui = new OptionPaneUI();
        }

        public OptionPaneUI GetUI()
        {
            return ui;
        }

        public void SetUI(OptionPaneUI newUI)
        {
            ui = newUI;
        }

        public object GetAccessibleContext()
        {
            return new object();
        }

        public Icon GetIcon()
        {
            return icon;
        }

        public void SetIcon(Icon newIcon)
        {
            icon = newIcon;
        }

        public Dialog CreateDialog(Component parentComponent, string title)
        {
            return new Dialog();
        }

        public Dialog CreateDialog(string title)
        {
            return new Dialog();
        }

        public int GetMaxCharactersPerLineCount()
        {
            return 0;
        }

        public bool GetWantsInput()
        {
            return wantsInput;
        }

        public object[] GetSelectionValues()
        {
            return selectionValues;
        }

        public object GetInitialSelectionValue()
        {
            return initialSelectionValue;
        }

        public int GetMessageType()
        {
            return messageType;
        }

        public int GetOptionType()
        {
            return optionType;
        }

        public object GetInitialValue()
        {
            return initialValue;
        }

        public void SetInputValue(object newValue)
        {
            inputValue = newValue;
        }

        public void SelectInitialValue()
        {
        }

        public static object ShowInputDialog(object message)
        {
            return null;
        }

        public static object ShowInputDialog(Component parentComponent, object message, string title, int messageType)
        {
            return null;
        }

        public static object ShowInputDialog(Component parentComponent, object message, string title, int messageType, Icon icon, object[] selectionValues, object initialSelectionValue)
        {
            return null;
        }

        public static object ShowInputDialog(Component parentComponent, object message)
        {
            return null;
        }

        public static object ShowInputDialog(object message, object initialSelectionValue)
        {
            return null;
        }

        public static object ShowInputDialog(Component parentComponent, object message, object initialSelectionValue)
        {
            return null;
        }

        public void SetWantsInput(bool newValue)
        {
            wantsInput = newValue;
        }

        public void SetSelectionValues(object[] newValues)
        {
            selectionValues = newValues;
        }

        public void SetInitialSelectionValue(object newValue)
        {
            initialSelectionValue = newValue;
        }

        public static Frame GetRootFrame()
        {
            if (rootFrame == null)
            {
                rootFrame = new Frame();
            }
            return rootFrame;
        }

        public object GetInputValue()
        {
            return inputValue;
        }

        public static void ShowMessageDialog(Component parentComponent, object message, string title, int messageType, Icon icon)
        {
        }

        public static void ShowMessageDialog(Component parentComponent, object message)
        {
        }

        public static void ShowMessageDialog(Component parentComponent, object message, string title, int messageType)
        {
        }

        public static int ShowOptionDialog(Component parentComponent, object message, string title, int optionType, int messageType, Icon icon, object[] options, object initialValue)
        {
            return 0;
        }

        public static int ShowConfirmDialog(Component parentComponent, object message, string title, int optionType)
        {
            return 0;
        }

        public static int ShowConfirmDialog(Component parentComponent, object message)
        {
            return 0;
        }

        public static int ShowConfirmDialog(Component parentComponent, object message, string title, int optionType, int messageType, Icon icon)
        {
            return 0;
        }

        public static int ShowConfirmDialog(Component parentComponent, object message, string title, int optionType, int messageType)
        {
            return 0;
        }

        public static void ShowInternalMessageDialog(Component parentComponent, object message, string title, int messageType, Icon icon)
        {
        }

        public static void ShowInternalMessageDialog(Component parentComponent, object message, string title, int messageType)
        {
        }

        public static void ShowInternalMessageDialog(Component parentComponent, object message)
        {
        }

        public static int ShowInternalOptionDialog(Component parentComponent, object message, string title, int optionType, int messageType, Icon icon, object[] options, object initialValue)
        {
            return 0;
        }

        public static int ShowInternalConfirmDialog(Component parentComponent, object message, string title, int optionType)
        {
            return 0;
        }

        public static int ShowInternalConfirmDialog(Component parentComponent, object message, string title, int optionType, int messageType, Icon icon)
        {
            return 0;
        }

        public static int ShowInternalConfirmDialog(Component parentComponent, object message, string title, int optionType, int messageType)
        {
            return 0;
        }

        public static int ShowInternalConfirmDialog(Component parentComponent, object message)
        {
            return 0;
        }

        public JInternalFrame CreateInternalFrame(Component parentComponent, string title)
        {
            return new JInternalFrame();
        }

        public static object ShowInternalInputDialog(Component parentComponent, object message)
        {
            return null;
        }

        public static object ShowInternalInputDialog(Component parentComponent, object message, string title, int messageType)
        {
            return null;
        }

        public static object ShowInternalInputDialog(Component parentComponent, object message, string title, int messageType, Icon icon, object[] selectionValues, object initialSelectionValue)
        {
            return null;
        }

        public static Component GetDesktopPaneForComponent(Component parentComponent)
        {
            return new Component();
        }

        public static Frame GetFrameForComponent(Component parentComponent)
        {
            return new Frame();
        }

        public void SetMessageType(int newType)
        {
            messageType = newType;
        }

        public void SetOptionType(int newType)
        {
            optionType = newType;
        }

        public static void SetRootFrame(Frame newRootFrame)
        {
            rootFrame = newRootFrame;
        }

        public void SetMessage(object newMessage)
        {
            message = newMessage;
        }

        public void SetOptions(object[] newOptions)
        {
            options = newOptions;
        }

        public object GetValue()
        {
            return value;
        }

        public object GetMessage()
        {
            return message;
        }

        public void SetValue(object newValue)
        {
            value = newValue;
        }

        public void SetInitialValue(object newValue)
        {
            initialValue = newValue;
        }

        public object[] GetOptions()
        {
            return options;
        }
    }

    public class Dialog : Component
    {
        public Dialog() { }
    }

    public class JInternalFrame : Component
    {
        public JInternalFrame() { }
    }

    public class javax_swing_JOptionPaneAutoTest
    {
        public void getUIClassID_test_6663()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetUIClassID();
        }

        public void updateUI_test_6664()
        {
            JOptionPane instance = new JOptionPane();
            instance.UpdateUI();
        }

        public void getUI_test_6665()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetUI();
        }

        public void setUI_test_6666(OptionPaneUI p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetUI(p0);
        }

        public void getAccessibleContext_test_6667()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetAccessibleContext();
        }

        public void getIcon_test_6668()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetIcon();
        }

        public void setIcon_test_6669(Icon p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetIcon(p0);
        }

        public void createDialog_test_6670(Component p0, string p1)
        {
            JOptionPane instance = new JOptionPane();
            instance.CreateDialog(p0, p1);
        }

        public void createDialog_test_6671(string p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.CreateDialog(p0);
        }

        public void getMaxCharactersPerLineCount_test_6672()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetMaxCharactersPerLineCount();
        }

        public void getWantsInput_test_6673()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetWantsInput();
        }

        public void getSelectionValues_test_6674()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetSelectionValues();
        }

        public void getInitialSelectionValue_test_6675()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetInitialSelectionValue();
        }

        public void getMessageType_test_6676()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetMessageType();
        }

        public void getOptionType_test_6677()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetOptionType();
        }

        public void getInitialValue_test_6678()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetInitialValue();
        }

        public void setInputValue_test_6679(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetInputValue(p0);
        }

        public void selectInitialValue_test_6680()
        {
            JOptionPane instance = new JOptionPane();
            instance.SelectInitialValue();
        }

        public void showInputDialog_test_6681(object p0)
        {
            JOptionPane.ShowInputDialog(p0);
        }

        public void showInputDialog_test_6682(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowInputDialog(p0, p1, p2, p3);
        }

        public void showInputDialog_test_6683(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6)
        {
            JOptionPane.ShowInputDialog(p0, p1, p2, p3, p4, p5, p6);
        }

        public void showInputDialog_test_6684(Component p0, object p1)
        {
            JOptionPane.ShowInputDialog(p0, p1);
        }

        public void showInputDialog_test_6685(object p0, object p1)
        {
            JOptionPane.ShowInputDialog(p0, p1);
        }

        public void showInputDialog_test_6686(Component p0, object p1, object p2)
        {
            JOptionPane.ShowInputDialog(p0, p1, p2);
        }

        public void setWantsInput_test_6687(bool p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetWantsInput(p0);
        }

        public void setSelectionValues_test_6688(object[] p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetSelectionValues(p0);
        }

        public void setInitialSelectionValue_test_6689(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetInitialSelectionValue(p0);
        }

        public void getRootFrame_test_6690()
        {
            JOptionPane.GetRootFrame();
        }

        public void getInputValue_test_6691()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetInputValue();
        }

        public void showMessageDialog_test_6692(Component p0, object p1, string p2, int p3, Icon p4)
        {
            JOptionPane.ShowMessageDialog(p0, p1, p2, p3, p4);
        }

        public void showMessageDialog_test_6693(Component p0, object p1)
        {
            JOptionPane.ShowMessageDialog(p0, p1);
        }

        public void showMessageDialog_test_6694(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowMessageDialog(p0, p1, p2, p3);
        }

        public void showOptionDialog_test_6695(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7)
        {
            JOptionPane.ShowOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void showConfirmDialog_test_6696(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowConfirmDialog(p0, p1, p2, p3);
        }

        public void showConfirmDialog_test_6697(Component p0, object p1)
        {
            JOptionPane.ShowConfirmDialog(p0, p1);
        }

        public void showConfirmDialog_test_6698(Component p0, object p1, string p2, int p3, int p4, Icon p5)
        {
            JOptionPane.ShowConfirmDialog(p0, p1, p2, p3, p4, p5);
        }

        public void showConfirmDialog_test_6699(Component p0, object p1, string p2, int p3, int p4)
        {
            JOptionPane.ShowConfirmDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalMessageDialog_test_6700(Component p0, object p1, string p2, int p3, Icon p4)
        {
            JOptionPane.ShowInternalMessageDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalMessageDialog_test_6701(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowInternalMessageDialog(p0, p1, p2, p3);
        }

        public void showInternalMessageDialog_test_6702(Component p0, object p1)
        {
            JOptionPane.ShowInternalMessageDialog(p0, p1);
        }

        public void showInternalOptionDialog_test_6703(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7)
        {
            JOptionPane.ShowInternalOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void showInternalConfirmDialog_test_6704(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowInternalConfirmDialog(p0, p1, p2, p3);
        }

        public void showInternalConfirmDialog_test_6705(Component p0, object p1, string p2, int p3, int p4, Icon p5)
        {
            JOptionPane.ShowInternalConfirmDialog(p0, p1, p2, p3, p4, p5);
        }

        public void showInternalConfirmDialog_test_6706(Component p0, object p1, string p2, int p3, int p4)
        {
            JOptionPane.ShowInternalConfirmDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalConfirmDialog_test_6707(Component p0, object p1)
        {
            JOptionPane.ShowInternalConfirmDialog(p0, p1);
        }

        public void createInternalFrame_test_6708(Component p0, string p1)
        {
            JOptionPane instance = new JOptionPane();
            instance.CreateInternalFrame(p0, p1);
        }

        public void showInternalInputDialog_test_6709(Component p0, object p1)
        {
            JOptionPane.ShowInternalInputDialog(p0, p1);
        }

        public void showInternalInputDialog_test_6710(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.ShowInternalInputDialog(p0, p1, p2, p3);
        }

        public void showInternalInputDialog_test_6711(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6)
        {
            JOptionPane.ShowInternalInputDialog(p0, p1, p2, p3, p4, p5, p6);
        }

        public void getDesktopPaneForComponent_test_6712(Component p0)
        {
            JOptionPane.GetDesktopPaneForComponent(p0);
        }

        public void getFrameForComponent_test_6713(Component p0)
        {
            JOptionPane.GetFrameForComponent(p0);
        }

        public void setMessageType_test_6714(int p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetMessageType(p0);
        }

        public void setOptionType_test_6715(int p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetOptionType(p0);
        }

        public void setRootFrame_test_6716(Frame p0)
        {
            JOptionPane.SetRootFrame(p0);
        }

        public void setMessage_test_6717(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetMessage(p0);
        }

        public void setOptions_test_6718(object[] p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetOptions(p0);
        }

        public void getValue_test_6719()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetValue();
        }

        public void getMessage_test_6720()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetMessage();
        }

        public void setValue_test_6721(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetValue(p0);
        }

        public void setInitialValue_test_6722(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.SetInitialValue(p0);
        }

        public void getOptions_test_6723()
        {
            JOptionPane instance = new JOptionPane();
            instance.GetOptions();
        }
    }
}