using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    public class TimeZone
    {
        private static TimeZone _defaultTimeZone = new TimeZone("UTC");
        private string _id;
        private int _rawOffset;

        public TimeZone(string id)
        {
            _id = id;
            _rawOffset = 0;
        }

        public TimeZone(string id, int rawOffset)
        {
            _id = id;
            _rawOffset = rawOffset;
        }

        public string GetID()
        {
            return _id;
        }

        public int GetRawOffset()
        {
            return _rawOffset;
        }

        public static TimeZone GetDefault()
        {
            return _defaultTimeZone;
        }

        public static TimeZone GetTimeZone(string id)
        {
            return new TimeZone(id);
        }

        public static TimeZone GetTimeZone(ZoneId zoneId)
        {
            return new TimeZone(zoneId.GetId());
        }

        public static void SetDefault(TimeZone timeZone)
        {
            _defaultTimeZone = timeZone;
        }

        public static string[] GetAvailableIDs()
        {
            return new string[] { "UTC", "GMT", "America/New_York", "Europe/London", "Asia/Tokyo" };
        }

        public static string[] GetAvailableIDs(int rawOffset)
        {
            return new string[] { "UTC", "GMT" };
        }

        public static string[] AvailableIDs(int rawOffset)
        {
            return GetAvailableIDs(rawOffset);
        }

        public static string[] AvailableIDs()
        {
            return GetAvailableIDs();
        }
    }

    public class ZoneId
    {
        private string _id;

        public ZoneId(string id)
        {
            _id = id;
        }

        public string GetId()
        {
            return _id;
        }

        public static ZoneId Of(string id)
        {
            return new ZoneId(id);
        }
    }

    public class java_util_TimeZoneAutoTest
    {
        public void getDefault_test_12901()
        {
            TimeZone.GetDefault();
        }

        public void getTimeZone_test_12902(string p0)
        {
            TimeZone.GetTimeZone(p0);
        }

        public void getTimeZone_test_12903(ZoneId p0)
        {
            TimeZone.GetTimeZone(p0);
        }

        public void setDefault_test_12904(TimeZone p0)
        {
            TimeZone.SetDefault(p0);
        }

        public void getAvailableIDs_test_12905()
        {
            TimeZone.GetAvailableIDs();
        }

        public void getAvailableIDs_test_12906(int p0)
        {
            TimeZone.GetAvailableIDs(p0);
        }

        public void availableIDs_test_12907(int p0)
        {
            TimeZone.AvailableIDs(p0);
        }

        public void availableIDs_test_12908()
        {
            TimeZone.AvailableIDs();
        }
    }
}