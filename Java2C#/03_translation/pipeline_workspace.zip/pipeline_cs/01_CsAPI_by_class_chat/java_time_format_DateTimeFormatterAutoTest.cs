using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_time_format_DateTimeFormatterAutoTest
    {
        public void ofPattern_test_3355(string p0)
        {
            DateTimeFormatter.OfPattern(p0);
        }

        public void ofPattern_test_3356(string p0, Locale p1)
        {
            DateTimeFormatter.OfPattern(p0, p1);
        }

        public void ofLocalizedDate_test_3357(FormatStyle p0)
        {
            DateTimeFormatter.OfLocalizedDate(p0);
        }

        public void ofLocalizedTime_test_3358(FormatStyle p0)
        {
            DateTimeFormatter.OfLocalizedTime(p0);
        }

        public void ofLocalizedDateTime_test_3359(FormatStyle p0)
        {
            DateTimeFormatter.OfLocalizedDateTime(p0);
        }

        public void ofLocalizedDateTime_test_3360(FormatStyle p0, FormatStyle p1)
        {
            DateTimeFormatter.OfLocalizedDateTime(p0, p1);
        }

        public void ofLocalizedPattern_test_3361(string p0)
        {
            DateTimeFormatter.OfLocalizedPattern(p0);
        }

        public void parsedExcessDays_test_3362()
        {
            DateTimeFormatter.ParsedExcessDays();
        }

        public void parsedLeapSecond_test_3363()
        {
            DateTimeFormatter.ParsedLeapSecond();
        }
    }

    public enum FormatStyle
    {
        SHORT,
        MEDIUM,
        LONG,
        FULL
    }

    public class Locale
    {
        public string Name { get; }
        public CultureInfo Culture { get; }

        public Locale(string name)
        {
            Name = name;
            Culture = new CultureInfo(name);
        }

        public static Locale GetDefault()
        {
            return new Locale(CultureInfo.CurrentCulture.Name);
        }

        public static Locale GetCulture(string name)
        {
            return new Locale(name);
        }
    }

    public class DateTimeFormatter
    {
        private string _pattern;
        private Locale _locale;
        private FormatStyle? _dateStyle;
        private FormatStyle? _timeStyle;
        private string _localizedPattern;

        private DateTimeFormatter() { }

        public static DateTimeFormatter OfPattern(string pattern)
        {
            var formatter = new DateTimeFormatter();
            formatter._pattern = pattern;
            return formatter;
        }

        public static DateTimeFormatter OfPattern(string pattern, Locale locale)
        {
            var formatter = new DateTimeFormatter();
            formatter._pattern = pattern;
            formatter._locale = locale;
            return formatter;
        }

        public static DateTimeFormatter OfLocalizedDate(FormatStyle dateStyle)
        {
            var formatter = new DateTimeFormatter();
            formatter._dateStyle = dateStyle;
            return formatter;
        }

        public static DateTimeFormatter OfLocalizedTime(FormatStyle timeStyle)
        {
            var formatter = new DateTimeFormatter();
            formatter._timeStyle = timeStyle;
            return formatter;
        }

        public static DateTimeFormatter OfLocalizedDateTime(FormatStyle dateTimeStyle)
        {
            var formatter = new DateTimeFormatter();
            formatter._dateStyle = dateTimeStyle;
            formatter._timeStyle = dateTimeStyle;
            return formatter;
        }

        public static DateTimeFormatter OfLocalizedDateTime(FormatStyle dateStyle, FormatStyle timeStyle)
        {
            var formatter = new DateTimeFormatter();
            formatter._dateStyle = dateStyle;
            formatter._timeStyle = timeStyle;
            return formatter;
        }

        public static DateTimeFormatter OfLocalizedPattern(string pattern)
        {
            var formatter = new DateTimeFormatter();
            formatter._localizedPattern = pattern;
            return formatter;
        }

        public static object ParsedExcessDays()
        {
            return new object();
        }

        public static object ParsedLeapSecond()
        {
            return new object();
        }
    }
}