namespace Generated.Test
{
    public class java_util_concurrent_ThreadLocalRandomAutoTest
    {
        public void current_test_12713()
        {
            System.Threading.ThreadLocalRandom.Current();
        }
    }
}