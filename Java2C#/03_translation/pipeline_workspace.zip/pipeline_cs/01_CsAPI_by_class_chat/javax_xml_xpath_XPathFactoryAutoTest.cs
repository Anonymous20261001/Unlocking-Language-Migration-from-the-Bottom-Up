namespace Generated.Test
{
    using System.Xml.XPath;

    public class javax_xml_xpath_XPathFactoryAutoTest
    {
        public void newDefaultInstance_test_13657()
        {
            XPathFactory.NewDefaultInstance();
        }

        public void newInstance_test_13658()
        {
            XPathFactory.NewInstance();
        }
    }

    public static class XPathFactory
    {
        public static XPathFactory NewDefaultInstance()
        {
            return new XPathFactory();
        }

        public static XPathFactory NewInstance()
        {
            return new XPathFactory();
        }
    }
}