namespace Generated.Test
{
    public class java_io_InputStreamAutoTest
    {
        public void nullInputStream_test_5854()
        {
            InputStream.NullInputStream();
        }
    }

    public class InputStream
    {
        public static System.IO.Stream NullInputStream()
        {
            return System.IO.Stream.Null;
        }
    }
}