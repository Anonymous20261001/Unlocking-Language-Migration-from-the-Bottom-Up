using System;
using System.Collections.Generic;
using javax.management;

namespace Generated.Test
{
    public class javax_management_QueryEvalAutoTest
    {
        public void getMBeanServer_test_10293()
        {
            QueryEval.getMBeanServer();
        }
    }
}

namespace javax.management
{
    public class QueryEval
    {
        private static MBeanServer mbeanServer;

        public static MBeanServer getMBeanServer()
        {
            return mbeanServer;
        }

        public static void setMBeanServer(MBeanServer server)
        {
            mbeanServer = server;
        }
    }

    public class MBeanServer
    {
        // Minimal placeholder for MBeanServer
        // In a real implementation, this would contain methods for managing MBeans
    }
}