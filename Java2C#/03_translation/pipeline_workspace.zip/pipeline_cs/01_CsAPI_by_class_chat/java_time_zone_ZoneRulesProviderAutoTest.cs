using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Generated.Test
{
    // C# equivalent of Java's ZoneRulesProvider
    public abstract class ZoneRulesProvider
    {
        private static readonly Dictionary<string, ZoneRulesProvider> Providers = new Dictionary<string, ZoneRulesProvider>();
        private static readonly object LockObject = new object();

        // Static method to refresh all providers
        public static void Refresh()
        {
            lock (LockObject)
            {
                foreach (var provider in Providers.Values)
                {
                    provider.RefreshProvider();
                }
            }
        }

        // Static method to get versions for a zone ID
        public static SortedDictionary<string, string> GetVersions(string zoneId)
        {
            lock (LockObject)
            {
                if (Providers.TryGetValue(zoneId, out var provider))
                {
                    return provider.GetVersionsProvider(zoneId);
                }
                throw new ArgumentException($"Unknown zone ID: {zoneId}");
            }
        }

        // Static method to get rules for a zone ID
        public static object GetRules(string zoneId, bool forCaching)
        {
            lock (LockObject)
            {
                if (Providers.TryGetValue(zoneId, out var provider))
                {
                    return provider.GetRulesProvider(zoneId, forCaching);
                }
                throw new ArgumentException($"Unknown zone ID: {zoneId}");
            }
        }

        // Static method to get all available zone IDs
        public static ReadOnlyCollection<string> GetAvailableZoneIds()
        {
            lock (LockObject)
            {
                return new ReadOnlyCollection<string>(new List<string>(Providers.Keys));
            }
        }

        // Static method to register a provider
        public static void RegisterProvider(ZoneRulesProvider provider)
        {
            if (provider == null)
            {
                throw new ArgumentNullException(nameof(provider));
            }

            lock (LockObject)
            {
                foreach (var zoneId in provider.ProvideZoneIds())
                {
                    if (Providers.ContainsKey(zoneId))
                    {
                        throw new InvalidOperationException($"Zone ID already registered: {zoneId}");
                    }
                    Providers[zoneId] = provider;
                }
            }
        }

        // Abstract methods to be implemented by subclasses
        protected abstract void RefreshProvider();
        protected abstract SortedDictionary<string, string> GetVersionsProvider(string zoneId);
        protected abstract object GetRulesProvider(string zoneId, bool forCaching);
        protected abstract IEnumerable<string> ProvideZoneIds();
    }

    // Test class
    public class java_time_zone_ZoneRulesProviderAutoTest
    {
        public void refresh_test_13738()
        {
            ZoneRulesProvider.Refresh();
        }

        public void getVersions_test_13739(string p0)
        {
            ZoneRulesProvider.GetVersions(p0);
        }

        public void getRules_test_13740(string p0, bool p1)
        {
            ZoneRulesProvider.GetRules(p0, p1);
        }

        public void getAvailableZoneIds_test_13741()
        {
            ZoneRulesProvider.GetAvailableZoneIds();
        }

        public void registerProvider_test_13742(ZoneRulesProvider p0)
        {
            ZoneRulesProvider.RegisterProvider(p0);
        }
    }
}