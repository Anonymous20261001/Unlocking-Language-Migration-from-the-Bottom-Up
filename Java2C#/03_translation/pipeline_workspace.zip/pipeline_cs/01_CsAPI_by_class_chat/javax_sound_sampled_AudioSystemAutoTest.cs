namespace Generated.Test
{
    public class javax_sound_sampled_AudioSystemAutoTest
    {
        public void getAudioInputStream_test_881(AudioFormat.Encoding p0, AudioInputStream p1)
        {
            AudioSystem.getAudioInputStream(p0, p1);
        }

        public void getAudioInputStream_test_882(AudioFormat p0, AudioInputStream p1)
        {
            AudioSystem.getAudioInputStream(p0, p1);
        }

        public void getAudioFileTypes_test_883(AudioInputStream p0)
        {
            AudioSystem.getAudioFileTypes(p0);
        }

        public void getAudioFileTypes_test_884()
        {
            AudioSystem.getAudioFileTypes();
        }

        public void isFileTypeSupported_test_885(AudioFileFormat.Type p0)
        {
            AudioSystem.isFileTypeSupported(p0);
        }

        public void isFileTypeSupported_test_886(AudioFileFormat.Type p0, AudioInputStream p1)
        {
            AudioSystem.isFileTypeSupported(p0, p1);
        }

        public void getMixer_test_887(Mixer.Info p0)
        {
            AudioSystem.getMixer(p0);
        }

        public void getMixerInfo_test_888()
        {
            AudioSystem.getMixerInfo();
        }

        public void getSourceLineInfo_test_889(Line.Info p0)
        {
            AudioSystem.getSourceLineInfo(p0);
        }

        public void getTargetLineInfo_test_890(Line.Info p0)
        {
            AudioSystem.getTargetLineInfo(p0);
        }

        public void isLineSupported_test_891(Line.Info p0)
        {
            AudioSystem.isLineSupported(p0);
        }

        public void getTargetEncodings_test_892(AudioFormat.Encoding p0)
        {
            AudioSystem.getTargetEncodings(p0);
        }

        public void getTargetEncodings_test_893(AudioFormat p0)
        {
            AudioSystem.getTargetEncodings(p0);
        }

        public void isConversionSupported_test_894(AudioFormat p0, AudioFormat p1)
        {
            AudioSystem.isConversionSupported(p0, p1);
        }

        public void isConversionSupported_test_895(AudioFormat.Encoding p0, AudioFormat p1)
        {
            AudioSystem.isConversionSupported(p0, p1);
        }

        public void getTargetFormats_test_896(AudioFormat.Encoding p0, AudioFormat p1)
        {
            AudioSystem.getTargetFormats(p0, p1);
        }
    }

    public static class AudioSystem
    {
        public static AudioInputStream getAudioInputStream(AudioFormat.Encoding p0, AudioInputStream p1)
        {
            return null;
        }

        public static AudioInputStream getAudioInputStream(AudioFormat p0, AudioInputStream p1)
        {
            return null;
        }

        public static AudioFileFormat.Type[] getAudioFileTypes(AudioInputStream p0)
        {
            return null;
        }

        public static AudioFileFormat.Type[] getAudioFileTypes()
        {
            return null;
        }

        public static bool isFileTypeSupported(AudioFileFormat.Type p0)
        {
            return false;
        }

        public static bool isFileTypeSupported(AudioFileFormat.Type p0, AudioInputStream p1)
        {
            return false;
        }

        public static Mixer getMixer(Mixer.Info p0)
        {
            return null;
        }

        public static Mixer.Info[] getMixerInfo()
        {
            return null;
        }

        public static Line.Info[] getSourceLineInfo(Line.Info p0)
        {
            return null;
        }

        public static Line.Info[] getTargetLineInfo(Line.Info p0)
        {
            return null;
        }

        public static bool isLineSupported(Line.Info p0)
        {
            return false;
        }

        public static AudioFormat.Encoding[] getTargetEncodings(AudioFormat.Encoding p0)
        {
            return null;
        }

        public static AudioFormat.Encoding[] getTargetEncodings(AudioFormat p0)
        {
            return null;
        }

        public static bool isConversionSupported(AudioFormat p0, AudioFormat p1)
        {
            return false;
        }

        public static bool isConversionSupported(AudioFormat.Encoding p0, AudioFormat p1)
        {
            return false;
        }

        public static AudioFormat[] getTargetFormats(AudioFormat.Encoding p0, AudioFormat p1)
        {
            return null;
        }
    }

    public class AudioInputStream
    {
    }

    public class AudioFormat
    {
        public class Encoding
        {
        }
    }

    public class AudioFileFormat
    {
        public class Type
        {
        }
    }

    public class Mixer
    {
        public class Info
        {
        }
    }

    public class Line
    {
        public class Info
        {
        }
    }
}