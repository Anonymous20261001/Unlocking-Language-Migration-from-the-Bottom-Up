using System;
using System.Reflection;

namespace Generated.Test
{
    public class MethodType
    {
        public static MethodType MethodType_FromMethodInfo(MethodInfo method)
        {
            return new MethodType();
        }
    }

    public class Lookup
    {
        private object _lookup;

        public Lookup(object lookup)
        {
            _lookup = lookup;
        }

        public object FindVirtual(Type p0, string p1, MethodType p2)
        {
            return null;
        }

        public object FindStatic(Type p0, string p1, MethodType p2)
        {
            return null;
        }

        public object Unreflect(MethodInfo p0)
        {
            return null;
        }

        public static object Unreflect(object p0, MethodInfo p1)
        {
            return null;
        }

        public static object UnreflectConstructor(object p0, ConstructorInfo p1)
        {
            return null;
        }

        public object UnreflectConstructor(ConstructorInfo p0)
        {
            return null;
        }

        public object FindSpecial(Type p0, string p1, MethodType p2)
        {
            return null;
        }

        public object FindGetter(Type p0, string p1, Type p2)
        {
            return null;
        }

        public object UnreflectGetter(FieldInfo p0)
        {
            return null;
        }

        public object UnreflectSetter(FieldInfo p0)
        {
            return null;
        }

        public object FindOwnSpecial(string p0, Type p1, Type[] p2)
        {
            return null;
        }

        public static object FindOwnSpecial(object p0, string p1, Type p2, Type[] p3)
        {
            return null;
        }

        public static object FindOwnStatic(object p0, string p1, Type p2, Type[] p3)
        {
            return null;
        }

        public object FindOwnStatic(string p0, Type p1, Type[] p2)
        {
            return null;
        }
    }

    public class jdk_dynalink_linker_support_LookupAutoTest
    {
        public void findVirtual_test_8237(Type p0, string p1, MethodType p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindVirtual(p0, p1, p2);
        }

        public void findStatic_test_8238(Type p0, string p1, MethodType p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindStatic(p0, p1, p2);
        }

        public void unreflect_test_8239(MethodInfo p0, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.Unreflect(p0);
        }

        public void unreflect_test_8240(object p0, MethodInfo p1)
        {
            Lookup.Unreflect(p0, p1);
        }

        public void unreflectConstructor_test_8241(object p0, ConstructorInfo p1)
        {
            Lookup.UnreflectConstructor(p0, p1);
        }

        public void unreflectConstructor_test_8242(ConstructorInfo p0, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.UnreflectConstructor(p0);
        }

        public void findSpecial_test_8243(Type p0, string p1, MethodType p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindSpecial(p0, p1, p2);
        }

        public void findGetter_test_8244(Type p0, string p1, Type p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindGetter(p0, p1, p2);
        }

        public void unreflectGetter_test_8245(FieldInfo p0, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.UnreflectGetter(p0);
        }

        public void unreflectSetter_test_8246(FieldInfo p0, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.UnreflectSetter(p0);
        }

        public void findOwnSpecial_test_8247(string p0, Type p1, Type[] p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindOwnSpecial(p0, p1, p2);
        }

        public void findOwnSpecial_test_8248(object p0, string p1, Type p2, Type[] p3)
        {
            Lookup.FindOwnSpecial(p0, p1, p2, p3);
        }

        public void findOwnStatic_test_8249(object p0, string p1, Type p2, Type[] p3)
        {
            Lookup.FindOwnStatic(p0, p1, p2, p3);
        }

        public void findOwnStatic_test_8250(string p0, Type p1, Type[] p2, object c0)
        {
            Lookup instance = new Lookup(c0);
            instance.FindOwnStatic(p0, p1, p2);
        }
    }
}