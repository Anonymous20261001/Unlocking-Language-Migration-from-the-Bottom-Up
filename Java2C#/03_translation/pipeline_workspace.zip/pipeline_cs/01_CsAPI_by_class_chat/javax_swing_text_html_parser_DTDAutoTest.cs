using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class DTD
    {
        private static Dictionary<string, DTD> dtdHash = new Dictionary<string, DTD>();

        public static void putDTDHash(string name, DTD dtd)
        {
            dtdHash[name] = dtd;
        }
    }

    public class javax_swing_text_html_parser_DTDAutoTest
    {
        public void putDTDHash_test_4403(string p0, DTD p1)
        {
            DTD.putDTDHash(p0, p1);
        }
    }
}