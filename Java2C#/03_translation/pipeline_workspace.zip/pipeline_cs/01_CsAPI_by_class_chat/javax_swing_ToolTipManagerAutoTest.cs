namespace Generated.Test
{
    public class javax_swing_ToolTipManagerAutoTest
    {
        public void sharedInstance_test_12932()
        {
            ToolTipManager.SharedInstance();
        }
    }

    public class ToolTipManager
    {
        private static ToolTipManager _sharedInstance;

        public static ToolTipManager SharedInstance()
        {
            if (_sharedInstance == null)
            {
                _sharedInstance = new ToolTipManager();
            }
            return _sharedInstance;
        }
    }
}