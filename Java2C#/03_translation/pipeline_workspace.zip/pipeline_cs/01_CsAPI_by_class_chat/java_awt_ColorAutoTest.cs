using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class ColorSpace
    {
        public static readonly ColorSpace CS_sRGB = new ColorSpace(1000);
        public static readonly ColorSpace CS_LINEAR_RGB = new ColorSpace(1004);
        public static readonly ColorSpace CS_GRAY = new ColorSpace(1003);
        public static readonly ColorSpace CS_CIEXYZ = new ColorSpace(1001);
        public static readonly ColorSpace CS_PYCC = new ColorSpace(1002);

        private int type;
        private int numComponents;

        public ColorSpace(int type, int numComponents)
        {
            this.type = type;
            this.numComponents = numComponents;
        }

        private ColorSpace(int type) : this(type, 3) { }

        public int getType() { return type; }
        public int getNumComponents() { return numComponents; }
        public string getName(int idx) { return "Component " + idx; }
        public float[] toRGB(float[] colorvalue) { return colorvalue; }
        public float[] fromRGB(float[] rgbvalue) { return rgbvalue; }
        public float[] toCIEXYZ(float[] colorvalue) { return colorvalue; }
        public float[] fromCIEXYZ(float[] colorvalue) { return colorvalue; }
        public bool isCS_sRGB() { return type == 1000; }
        public static ColorSpace getInstance(int colorspace)
        {
            switch (colorspace)
            {
                case 0: return CS_sRGB;
                case 1: return CS_LINEAR_RGB;
                case 2: return CS_GRAY;
                case 3: return CS_CIEXYZ;
                case 4: return CS_PYCC;
                default: return CS_sRGB;
            }
        }
    }

    public class Rectangle
    {
        public int x, y, width, height;
        public Rectangle() { }
        public Rectangle(int x, int y, int width, int height)
        {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
    }

    public class Rectangle2D
    {
        public double x, y, width, height;
        public Rectangle2D() { }
        public Rectangle2D(double x, double y, double width, double height)
        {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
    }

    public class AffineTransform
    {
        public double m00, m10, m01, m11, m02, m12;
        public AffineTransform() { }
        public AffineTransform(double m00, double m10, double m01, double m11, double m02, double m12)
        {
            this.m00 = m00; this.m10 = m10; this.m01 = m01; this.m11 = m11; this.m02 = m02; this.m12 = m12;
        }
    }

    public class RenderingHints
    {
        private Dictionary<object, object> hints = new Dictionary<object, object>();
        public RenderingHints() { }
        public RenderingHints(Dictionary<object, object> init)
        {
            if (init != null)
            {
                foreach (var kv in init) hints[kv.Key] = kv.Value;
            }
        }
        public object get(object key) { return hints.ContainsKey(key) ? hints[key] : null; }
        public object put(object key, object value) { object old = get(key); hints[key] = value; return old; }
        public void add(RenderingHints hints) { foreach (var kv in hints.hints) this.hints[kv.Key] = kv.Value; }
        public void clear() { hints.Clear(); }
        public bool isEmpty() { return hints.Count == 0; }
        public int size() { return hints.Count; }
    }

    public class ColorModel
    {
        public ColorModel() { }
        public ColorModel(int bits) { }
    }

    public class PaintContext
    {
        public PaintContext() { }
    }

    public class Color
    {
        private int value;
        private ColorSpace colorSpace;

        public static readonly Color WHITE = new Color(255, 255, 255);
        public static readonly Color LIGHT_GRAY = new Color(192, 192, 192);
        public static readonly Color GRAY = new Color(128, 128, 128);
        public static readonly Color DARK_GRAY = new Color(64, 64, 64);
        public static readonly Color BLACK = new Color(0, 0, 0);
        public static readonly Color RED = new Color(255, 0, 0);
        public static readonly Color PINK = new Color(255, 175, 175);
        public static readonly Color ORANGE = new Color(255, 200, 0);
        public static readonly Color YELLOW = new Color(255, 255, 0);
        public static readonly Color GREEN = new Color(0, 255, 0);
        public static readonly Color MAGENTA = new Color(255, 0, 255);
        public static readonly Color CYAN = new Color(0, 255, 255);
        public static readonly Color BLUE = new Color(0, 0, 255);

        public const int OPAQUE = 1;
        public const int BITMASK = 2;
        public const int TRANSLUCENT = 3;

        public Color(int r, int g, int b) : this(r, g, b, 255) { }

        public Color(int r, int g, int b, int a)
        {
            value = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
            colorSpace = ColorSpace.CS_sRGB;
        }

        public Color(int rgb) : this((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, (rgb >> 24) & 0xFF) { }

        public Color(float r, float g, float b) : this((int)(r * 255 + 0.5f), (int)(g * 255 + 0.5f), (int)(b * 255 + 0.5f)) { }

        public Color(float r, float g, float b, float a) : this((int)(r * 255 + 0.5f), (int)(g * 255 + 0.5f), (int)(b * 255 + 0.5f), (int)(a * 255 + 0.5f)) { }

        public Color(ColorSpace cspace, float[] components, float alpha)
        {
            colorSpace = cspace;
            float[] rgb = cspace.toRGB(components);
            int r = (int)(rgb[0] * 255 + 0.5f);
            int g = (int)(rgb[1] * 255 + 0.5f);
            int b = (int)(rgb[2] * 255 + 0.5f);
            int a = (int)(alpha * 255 + 0.5f);
            value = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
        }

        public int getRed() { return (value >> 16) & 0xFF; }
        public int getGreen() { return (value >> 8) & 0xFF; }
        public int getBlue() { return value & 0xFF; }
        public int getAlpha() { return (value >> 24) & 0xFF; }
        public int getRGB() { return value; }

        public Color brighter()
        {
            int r = getRed();
            int g = getGreen();
            int b = getBlue();
            int alpha = getAlpha();
            int i = (int)(1.0 / 1.0);
            if (r == 0 && g == 0 && b == 0)
            {
                return new Color(i, i, i, alpha);
            }
            if (r > 0 && r < i) r = i;
            if (g > 0 && g < i) g = i;
            if (b > 0 && b < i) b = i;
            return new Color(Math.Min(255, (int)(r / 0.7)), Math.Min(255, (int)(g / 0.7)), Math.Min(255, (int)(b / 0.7)), alpha);
        }

        public Color darker()
        {
            int r = getRed();
            int g = getGreen();
            int b = getBlue();
            int alpha = getAlpha();
            return new Color(Math.Max(0, (int)(r * 0.7)), Math.Max(0, (int)(g * 0.7)), Math.Max(0, (int)(b * 0.7)), alpha);
        }

        public int getTransparency()
        {
            int alpha = getAlpha();
            if (alpha == 255) return OPAQUE;
            if (alpha == 0) return BITMASK;
            return TRANSLUCENT;
        }

        public ColorSpace getColorSpace() { return colorSpace; }

        public float[] getComponents(float[] compArray)
        {
            if (compArray == null || compArray.Length < 4)
                compArray = new float[4];
            compArray[0] = getRed() / 255.0f;
            compArray[1] = getGreen() / 255.0f;
            compArray[2] = getBlue() / 255.0f;
            compArray[3] = getAlpha() / 255.0f;
            return compArray;
        }

        public float[] getComponents(ColorSpace cspace, float[] compArray)
        {
            if (compArray == null || compArray.Length < cspace.getNumComponents() + 1)
                compArray = new float[cspace.getNumComponents() + 1];
            float[] rgb = new float[] { getRed() / 255.0f, getGreen() / 255.0f, getBlue() / 255.0f };
            float[] comps = cspace.fromRGB(rgb);
            for (int i = 0; i < comps.Length; i++)
                compArray[i] = comps[i];
            compArray[comps.Length] = getAlpha() / 255.0f;
            return compArray;
        }

        public float[] getColorComponents(float[] compArray)
        {
            if (compArray == null || compArray.Length < 3)
                compArray = new float[3];
            compArray[0] = getRed() / 255.0f;
            compArray[1] = getGreen() / 255.0f;
            compArray[2] = getBlue() / 255.0f;
            return compArray;
        }

        public float[] getColorComponents(ColorSpace cspace, float[] compArray)
        {
            if (compArray == null || compArray.Length < cspace.getNumComponents())
                compArray = new float[cspace.getNumComponents()];
            float[] rgb = new float[] { getRed() / 255.0f, getGreen() / 255.0f, getBlue() / 255.0f };
            float[] comps = cspace.fromRGB(rgb);
            for (int i = 0; i < comps.Length; i++)
                compArray[i] = comps[i];
            return compArray;
        }

        public float[] getRGBComponents(float[] compArray)
        {
            if (compArray == null || compArray.Length < 4)
                compArray = new float[4];
            compArray[0] = getRed() / 255.0f;
            compArray[1] = getGreen() / 255.0f;
            compArray[2] = getBlue() / 255.0f;
            compArray[3] = getAlpha() / 255.0f;
            return compArray;
        }

        public float[] getRGBColorComponents(float[] compArray)
        {
            if (compArray == null || compArray.Length < 3)
                compArray = new float[3];
            compArray[0] = getRed() / 255.0f;
            compArray[1] = getGreen() / 255.0f;
            compArray[2] = getBlue() / 255.0f;
            return compArray;
        }

        public static int HSBtoRGB(float hue, float saturation, float brightness)
        {
            int r = 0, g = 0, b = 0;
            if (saturation == 0)
            {
                r = g = b = (int)(brightness * 255.0f + 0.5f);
            }
            else
            {
                float h = (hue - (float)Math.Floor(hue)) * 6.0f;
                float f = h - (float)Math.Floor(h);
                float p = brightness * (1.0f - saturation);
                float q = brightness * (1.0f - saturation * f);
                float t = brightness * (1.0f - saturation * (1.0f - f));
                switch ((int)h)
                {
                    case 0: r = (int)(brightness * 255.0f + 0.5f); g = (int)(t * 255.0f + 0.5f); b = (int)(p * 255.0f + 0.5f); break;
                    case 1: r = (int)(q * 255.0f + 0.5f); g = (int)(brightness * 255.0f + 0.5f); b = (int)(p * 255.0f + 0.5f); break;
                    case 2: r = (int)(p * 255.0f + 0.5f); g = (int)(brightness * 255.0f + 0.5f); b = (int)(t * 255.0f + 0.5f); break;
                    case 3: r = (int)(p * 255.0f + 0.5f); g = (int)(q * 255.0f + 0.5f); b = (int)(brightness * 255.0f + 0.5f); break;
                    case 4: r = (int)(t * 255.0f + 0.5f); g = (int)(p * 255.0f + 0.5f); b = (int)(brightness * 255.0f + 0.5f); break;
                    case 5: r = (int)(brightness * 255.0f + 0.5f); g = (int)(p * 255.0f + 0.5f); b = (int)(q * 255.0f + 0.5f); break;
                }
            }
            return 0xff000000 | (r << 16) | (g << 8) | (b << 0);
        }

        public static float[] RGBtoHSB(int r, int g, int b, float[] hsbvals)
        {
            if (hsbvals == null || hsbvals.Length < 3)
                hsbvals = new float[3];
            float hue, saturation, brightness;
            int cmax = (r > g) ? r : g;
            if (b > cmax) cmax = b;
            int cmin = (r < g) ? r : g;
            if (b < cmin) cmin = b;

            brightness = cmax / 255.0f;
            if (cmax != 0)
                saturation = (float)(cmax - cmin) / (float)cmax;
            else
                saturation = 0;
            if (saturation == 0)
                hue = 0;
            else
            {
                float redc = (float)(cmax - r) / (float)(cmax - cmin);
                float greenc = (float)(cmax - g) / (float)(cmax - cmin);
                float bluec = (float)(cmax - b) / (float)(cmax - cmin);
                if (r == cmax)
                    hue = bluec - greenc;
                else if (g == cmax)
                    hue = 2.0f + redc - bluec;
                else
                    hue = 4.0f + greenc - redc;
                hue = hue / 6.0f;
                if (hue < 0)
                    hue = hue + 1.0f;
            }
            hsbvals[0] = hue;
            hsbvals[1] = saturation;
            hsbvals[2] = brightness;
            return hsbvals;
        }

        public static Color getHSBColor(float h, float s, float b)
        {
            return new Color(HSBtoRGB(h, s, b));
        }

        public static Color getColor(string nm)
        {
            return getColor(nm, null);
        }

        public static Color getColor(string nm, Color fallback)
        {
            if (nm == null) return fallback;
            string prop = Environment.GetEnvironmentVariable(nm);
            if (prop == null) return fallback;
            try
            {
                return decode(prop);
            }
            catch
            {
                return fallback;
            }
        }

        public static Color getColor(string nm, int v)
        {
            Color fallback = new Color(v);
            return getColor(nm, fallback);
        }

        public static Color decode(string nm)
        {
            if (nm == null) throw new ArgumentNullException("nm");
            string s = nm.Trim();
            if (s.StartsWith("#"))
                s = s.Substring(1);
            else if (s.StartsWith("0x") || s.StartsWith("0X"))
                s = s.Substring(2);
            else if (s.StartsWith("0") && s.Length > 1)
                s = s.Substring(1);
            int val;
            try
            {
                val = Convert.ToInt32(s, 16);
            }
            catch
            {
                throw new ArgumentException("Invalid color string: " + nm);
            }
            return new Color(val);
        }

        public PaintContext createContext(ColorModel cm, Rectangle r, Rectangle2D r2d, AffineTransform xform, RenderingHints hints)
        {
            return new PaintContext();
        }

        public override bool Equals(object obj)
        {
            if (obj is Color)
            {
                Color c = (Color)obj;
                return c.value == value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return value;
        }

        public override string ToString()
        {
            return "Color[r=" + getRed() + ",g=" + getGreen() + ",b=" + getBlue() + ",a=" + getAlpha() + "]";
        }
    }

    public class java_awt_ColorAutoTest
    {
        public void getComponents_test_2468(ColorSpace p0, float[] p1, int c0)
        {
            Color instance = new Color(c0);
            instance.getComponents(p0, p1);
        }

        public void getComponents_test_2469(float[] p0, int c0)
        {
            Color instance = new Color(c0);
            instance.getComponents(p0);
        }

        public void getColor_test_2470(string p0, Color p1)
        {
            Color.getColor(p0, p1);
        }

        public void getColor_test_2471(string p0)
        {
            Color.getColor(p0);
        }

        public void getColor_test_2472(string p0, int p1)
        {
            Color.getColor(p0, p1);
        }

        public void brighter_test_2473(int c0)
        {
            Color instance = new Color(c0);
            instance.brighter();
        }

        public void darker_test_2474(int c0)
        {
            Color instance = new Color(c0);
            instance.darker();
        }

        public void getRGB_test_2475(int c0)
        {
            Color instance = new Color(c0);
            instance.getRGB();
        }

        public void getRed_test_2476(int c0)
        {
            Color instance = new Color(c0);
            instance.getRed();
        }

        public void getGreen_test_2477(int c0)
        {
            Color instance = new Color(c0);
            instance.getGreen();
        }

        public void getBlue_test_2478(int c0)
        {
            Color instance = new Color(c0);
            instance.getBlue();
        }

        public void getAlpha_test_2479(int c0)
        {
            Color instance = new Color(c0);
            instance.getAlpha();
        }

        public void HSBtoRGB_test_2480(float p0, float p1, float p2)
        {
            Color.HSBtoRGB(p0, p1, p2);
        }

        public void getRGBComponents_test_2481(float[] p0, int c0)
        {
            Color instance = new Color(c0);
            instance.getRGBComponents(p0);
        }

        public void getRGBColorComponents_test_2482(float[] p0, int c0)
        {
            Color instance = new Color(c0);
            instance.getRGBColorComponents(p0);
        }

        public void RGBtoHSB_test_2483(int p0, int p1, int p2, float[] p3)
        {
            Color.RGBtoHSB(p0, p1, p2, p3);
        }

        public void getHSBColor_test_2484(float p0, float p1, float p2)
        {
            Color.getHSBColor(p0, p1, p2);
        }

        public void getColorComponents_test_2485(float[] p0, int c0)
        {
            Color instance = new Color(c0);
            instance.getColorComponents(p0);
        }

        public void getColorComponents_test_2486(ColorSpace p0, float[] p1, int c0)
        {
            Color instance = new Color(c0);
            instance.getColorComponents(p0, p1);
        }

        public void getColorSpace_test_2487(int c0)
        {
            Color instance = new Color(c0);
            instance.getColorSpace();
        }

        public void createContext_test_2488(ColorModel p0, Rectangle p1, Rectangle2D p2,
            AffineTransform p3, RenderingHints p4, int c0)
        {
            Color instance = new Color(c0);
            instance.createContext(p0, p1, p2, p3, p4);
        }

        public void getTransparency_test_2489(int c0)
        {
            Color instance = new Color(c0);
            instance.getTransparency();
        }

        public void decode_test_2490(string p0)
        {
            Color.decode(p0);
        }
    }
}