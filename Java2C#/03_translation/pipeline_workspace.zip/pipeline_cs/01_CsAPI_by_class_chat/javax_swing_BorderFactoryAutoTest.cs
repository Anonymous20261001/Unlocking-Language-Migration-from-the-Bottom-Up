using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Generated.Test
{
    public interface Border { }
    public interface Icon { }

    public class Color
    {
        public static readonly Color Black = new Color(0, 0, 0);
        public static readonly Color White = new Color(255, 255, 255);
        public static readonly Color Gray = new Color(128, 128, 128);
        public static readonly Color LightGray = new Color(192, 192, 192);
        public static readonly Color DarkGray = new Color(64, 64, 64);

        public int R { get; }
        public int G { get; }
        public int B { get; }

        public Color(int r, int g, int b)
        {
            R = r;
            G = g;
            B = b;
        }

        public override bool Equals(object obj)
        {
            if (obj is Color other)
                return R == other.R && G == other.G && B == other.B;
            return false;
        }

        public override int GetHashCode()
        {
            return (R << 16) | (G << 8) | B;
        }
    }

    public class Font
    {
        public string Name { get; }
        public int Style { get; }
        public int Size { get; }

        public Font(string name, int style, int size)
        {
            Name = name;
            Style = style;
            Size = size;
        }
    }

    public class BasicStroke
    {
        public float Width { get; }
        public int Cap { get; }
        public int Join { get; }
        public float MiterLimit { get; }
        public float[] Dash { get; }
        public float DashPhase { get; }

        public BasicStroke(float width, int cap, int join, float miterLimit, float[] dash, float dashPhase)
        {
            Width = width;
            Cap = cap;
            Join = join;
            MiterLimit = miterLimit;
            Dash = dash;
            DashPhase = dashPhase;
        }

        public BasicStroke(float width)
        {
            Width = width;
            Cap = 0;
            Join = 0;
            MiterLimit = 10.0f;
            Dash = null;
            DashPhase = 0.0f;
        }
    }

    public interface Paint { }

    public class BorderFactory
    {
        public const int RAISED = 0;
        public const int LOWERED = 1;
        public const int ETCHED = 2;

        public const int TOP = 1;
        public const int LEFT = 2;
        public const int BOTTOM = 4;
        public const int RIGHT = 8;
        public const int CENTER = 16;

        public const int PLAIN = 0;
        public const int BOLD = 1;
        public const int ITALIC = 2;

        public static Border createLoweredBevelBorder()
        {
            return new BevelBorder(LOWERED);
        }

        public static Border createBevelBorder(int type)
        {
            return new BevelBorder(type);
        }

        public static Border createBevelBorder(int type, Color highlight, Color shadow)
        {
            return new BevelBorder(type, highlight, shadow);
        }

        public static Border createBevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
        {
            return new BevelBorder(type, highlightOuter, highlightInner, shadowOuter, shadowInner);
        }

        public static Border createSoftBevelBorder(int type)
        {
            return new SoftBevelBorder(type);
        }

        public static Border createSoftBevelBorder(int type, Color highlight, Color shadow)
        {
            return new SoftBevelBorder(type, highlight, shadow);
        }

        public static Border createSoftBevelBorder(int type, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
        {
            return new SoftBevelBorder(type, highlightOuter, highlightInner, shadowOuter, shadowInner);
        }

        public static Border createEtchedBorder(Color highlight, Color shadow)
        {
            return new EtchedBorder(highlight, shadow);
        }

        public static Border createEtchedBorder(int type)
        {
            return new EtchedBorder(type);
        }

        public static Border createEtchedBorder()
        {
            return new EtchedBorder();
        }

        public static Border createEtchedBorder(int type, Color highlight, Color shadow)
        {
            return new EtchedBorder(type, highlight, shadow);
        }

        public static Border createTitledBorder(Border border, string title, int titleJustification, int titlePosition, Font titleFont)
        {
            return new TitledBorder(border, title, titleJustification, titlePosition, titleFont);
        }

        public static Border createTitledBorder(Border border, string title, int titleJustification, int titlePosition, Font titleFont, Color titleColor)
        {
            return new TitledBorder(border, title, titleJustification, titlePosition, titleFont, titleColor);
        }

        public static Border createTitledBorder(string title)
        {
            return new TitledBorder(title);
        }

        public static Border createTitledBorder(Border border)
        {
            return new TitledBorder(border);
        }

        public static Border createTitledBorder(Border border, string title)
        {
            return new TitledBorder(border, title);
        }

        public static Border createTitledBorder(Border border, string title, int titleJustification, int titlePosition)
        {
            return new TitledBorder(border, title, titleJustification, titlePosition);
        }

        public static Border createCompoundBorder()
        {
            return new CompoundBorder();
        }

        public static Border createCompoundBorder(Border outsideBorder, Border insideBorder)
        {
            return new CompoundBorder(outsideBorder, insideBorder);
        }

        public static Border createMatteBorder(int top, int left, int bottom, int right, Color color)
        {
            return new MatteBorder(top, left, bottom, right, color);
        }

        public static Border createMatteBorder(int top, int left, int bottom, int right, Icon tileIcon)
        {
            return new MatteBorder(top, left, bottom, right, tileIcon);
        }

        public static Border createRaisedBevelBorder()
        {
            return new BevelBorder(RAISED);
        }

        public static Border createRaisedSoftBevelBorder()
        {
            return new SoftBevelBorder(RAISED);
        }

        public static Border createLoweredSoftBevelBorder()
        {
            return new SoftBevelBorder(LOWERED);
        }

        public static Border createDashedBorder(Paint paint)
        {
            return new DashedBorder(paint);
        }

        public static Border createDashedBorder(Paint paint, float thickness, float length)
        {
            return new DashedBorder(paint, thickness, length);
        }

        public static Border createDashedBorder(Paint paint, float thickness, float length, float spacing, bool rounded)
        {
            return new DashedBorder(paint, thickness, length, spacing, rounded);
        }

        public static Border createStrokeBorder(BasicStroke stroke, Paint paint)
        {
            return new StrokeBorder(stroke, paint);
        }

        public static Border createStrokeBorder(BasicStroke stroke)
        {
            return new StrokeBorder(stroke);
        }

        public static Border createEmptyBorder()
        {
            return new EmptyBorder();
        }

        public static Border createEmptyBorder(int top, int left, int bottom, int right)
        {
            return new EmptyBorder(top, left, bottom, right);
        }

        public static Border createLineBorder(Color color, int thickness, bool rounded)
        {
            return new LineBorder(color, thickness, rounded);
        }

        public static Border createLineBorder(Color color)
        {
            return new LineBorder(color);
        }

        public static Border createLineBorder(Color color, int thickness)
        {
            return new LineBorder(color, thickness);
        }
    }

    public class BevelBorder : Border
    {
        public int BevelType { get; }
        public Color HighlightOuter { get; }
        public Color HighlightInner { get; }
        public Color ShadowOuter { get; }
        public Color ShadowInner { get; }

        public BevelBorder(int bevelType)
        {
            BevelType = bevelType;
            HighlightOuter = Color.LightGray;
            HighlightInner = Color.White;
            ShadowOuter = Color.Gray;
            ShadowInner = Color.DarkGray;
        }

        public BevelBorder(int bevelType, Color highlight, Color shadow)
        {
            BevelType = bevelType;
            HighlightOuter = highlight;
            HighlightInner = highlight;
            ShadowOuter = shadow;
            ShadowInner = shadow;
        }

        public BevelBorder(int bevelType, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
        {
            BevelType = bevelType;
            HighlightOuter = highlightOuter;
            HighlightInner = highlightInner;
            ShadowOuter = shadowOuter;
            ShadowInner = shadowInner;
        }
    }

    public class SoftBevelBorder : BevelBorder
    {
        public SoftBevelBorder(int bevelType) : base(bevelType) { }
        public SoftBevelBorder(int bevelType, Color highlight, Color shadow) : base(bevelType, highlight, shadow) { }
        public SoftBevelBorder(int bevelType, Color highlightOuter, Color highlightInner, Color shadowOuter, Color shadowInner)
            : base(bevelType, highlightOuter, highlightInner, shadowOuter, shadowInner) { }
    }

    public class EtchedBorder : Border
    {
        public int EtchType { get; }
        public Color Highlight { get; }
        public Color Shadow { get; }

        public EtchedBorder()
        {
            EtchType = BorderFactory.LOWERED;
            Highlight = Color.LightGray;
            Shadow = Color.Gray;
        }

        public EtchedBorder(int etchType)
        {
            EtchType = etchType;
            Highlight = Color.LightGray;
            Shadow = Color.Gray;
        }

        public EtchedBorder(Color highlight, Color shadow)
        {
            EtchType = BorderFactory.LOWERED;
            Highlight = highlight;
            Shadow = shadow;
        }

        public EtchedBorder(int etchType, Color highlight, Color shadow)
        {
            EtchType = etchType;
            Highlight = highlight;
            Shadow = shadow;
        }
    }

    public class TitledBorder : Border
    {
        public Border Border { get; }
        public string Title { get; }
        public int TitleJustification { get; }
        public int TitlePosition { get; }
        public Font TitleFont { get; }
        public Color TitleColor { get; }

        public TitledBorder(Border border, string title, int titleJustification, int titlePosition, Font titleFont)
        {
            Border = border;
            Title = title;
            TitleJustification = titleJustification;
            TitlePosition = titlePosition;
            TitleFont = titleFont;
            TitleColor = Color.Gray;
        }

        public TitledBorder(Border border, string title, int titleJustification, int titlePosition, Font titleFont, Color titleColor)
        {
            Border = border;
            Title = title;
            TitleJustification = titleJustification;
            TitlePosition = titlePosition;
            TitleFont = titleFont;
            TitleColor = titleColor;
        }

        public TitledBorder(string title)
        {
            Border = null;
            Title = title;
            TitleJustification = BorderFactory.CENTER;
            TitlePosition = BorderFactory.TOP;
            TitleFont = null;
            TitleColor = Color.Gray;
        }

        public TitledBorder(Border border)
        {
            Border = border;
            Title = "";
            TitleJustification = BorderFactory.CENTER;
            TitlePosition = BorderFactory.TOP;
            TitleFont = null;
            TitleColor = Color.Gray;
        }

        public TitledBorder(Border border, string title)
        {
            Border = border;
            Title = title;
            TitleJustification = BorderFactory.CENTER;
            TitlePosition = BorderFactory.TOP;
            TitleFont = null;
            TitleColor = Color.Gray;
        }

        public TitledBorder(Border border, string title, int titleJustification, int titlePosition)
        {
            Border = border;
            Title = title;
            TitleJustification = titleJustification;
            TitlePosition = titlePosition;
            TitleFont = null;
            TitleColor = Color.Gray;
        }
    }

    public class CompoundBorder : Border
    {
        public Border OutsideBorder { get; }
        public Border InsideBorder { get; }

        public CompoundBorder()
        {
            OutsideBorder = null;
            InsideBorder = null;
        }

        public CompoundBorder(Border outsideBorder, Border insideBorder)
        {
            OutsideBorder = outsideBorder;
            InsideBorder = insideBorder;
        }
    }

    public class MatteBorder : Border
    {
        public int Top { get; }
        public int Left { get; }
        public int Bottom { get; }
        public int Right { get; }
        public Color Color { get; }
        public Icon TileIcon { get; }

        public MatteBorder(int top, int left, int bottom, int right, Color color)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
            Color = color;
            TileIcon = null;
        }

        public MatteBorder(int top, int left, int bottom, int right, Icon tileIcon)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
            Color = null;
            TileIcon = tileIcon;
        }
    }

    public class DashedBorder : Border
    {
        public Paint Paint { get; }
        public float Thickness { get; }
        public float Length { get; }
        public float Spacing { get; }
        public bool Rounded { get; }

        public DashedBorder(Paint paint)
        {
            Paint = paint;
            Thickness = 1.0f;
            Length = 1.0f;
            Spacing = 2.0f;
            Rounded = false;
        }

        public DashedBorder(Paint paint, float thickness, float length)
        {
            Paint = paint;
            Thickness = thickness;
            Length = length;
            Spacing = 2.0f;
            Rounded = false;
        }

        public DashedBorder(Paint paint, float thickness, float length, float spacing, bool rounded)
        {
            Paint = paint;
            Thickness = thickness;
            Length = length;
            Spacing = spacing;
            Rounded = rounded;
        }
    }

    public class StrokeBorder : Border
    {
        public BasicStroke Stroke { get; }
        public Paint Paint { get; }

        public StrokeBorder(BasicStroke stroke, Paint paint)
        {
            Stroke = stroke;
            Paint = paint;
        }

        public StrokeBorder(BasicStroke stroke)
        {
            Stroke = stroke;
            Paint = null;
        }
    }

    public class EmptyBorder : Border
    {
        public int Top { get; }
        public int Left { get; }
        public int Bottom { get; }
        public int Right { get; }

        public EmptyBorder()
        {
            Top = 0;
            Left = 0;
            Bottom = 0;
            Right = 0;
        }

        public EmptyBorder(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    public class LineBorder : Border
    {
        public Color LineColor { get; }
        public int Thickness { get; }
        public bool RoundedCorners { get; }

        public LineBorder(Color color, int thickness, bool rounded)
        {
            LineColor = color;
            Thickness = thickness;
            RoundedCorners = rounded;
        }

        public LineBorder(Color color)
        {
            LineColor = color;
            Thickness = 1;
            RoundedCorners = false;
        }

        public LineBorder(Color color, int thickness)
        {
            LineColor = color;
            Thickness = thickness;
            RoundedCorners = false;
        }
    }

    public class javax_swing_BorderFactoryAutoTest
    {
        public void createLoweredBevelBorder_test_1780()
        {
            BorderFactory.createLoweredBevelBorder();
        }

        public void createBevelBorder_test_1781(int p0)
        {
            BorderFactory.createBevelBorder(p0);
        }

        public void createBevelBorder_test_1782(int p0, Color p1, Color p2)
        {
            BorderFactory.createBevelBorder(p0, p1, p2);
        }

        public void createBevelBorder_test_1783(int p0, Color p1, Color p2, Color p3, Color p4)
        {
            BorderFactory.createBevelBorder(p0, p1, p2, p3, p4);
        }

        public void createSoftBevelBorder_test_1784(int p0)
        {
            BorderFactory.createSoftBevelBorder(p0);
        }

        public void createSoftBevelBorder_test_1785(int p0, Color p1, Color p2)
        {
            BorderFactory.createSoftBevelBorder(p0, p1, p2);
        }

        public void createSoftBevelBorder_test_1786(int p0, Color p1, Color p2, Color p3, Color p4)
        {
            BorderFactory.createSoftBevelBorder(p0, p1, p2, p3, p4);
        }

        public void createEtchedBorder_test_1787(Color p0, Color p1)
        {
            BorderFactory.createEtchedBorder(p0, p1);
        }

        public void createEtchedBorder_test_1788(int p0)
        {
            BorderFactory.createEtchedBorder(p0);
        }

        public void createEtchedBorder_test_1789()
        {
            BorderFactory.createEtchedBorder();
        }

        public void createEtchedBorder_test_1790(int p0, Color p1, Color p2)
        {
            BorderFactory.createEtchedBorder(p0, p1, p2);
        }

        public void createTitledBorder_test_1791(Border p0, string p1, int p2, int p3, Font p4)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3, p4);
        }

        public void createTitledBorder_test_1792(Border p0, string p1, int p2, int p3, Font p4, Color p5)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3, p4, p5);
        }

        public void createTitledBorder_test_1793(string p0)
        {
            BorderFactory.createTitledBorder(p0);
        }

        public void createTitledBorder_test_1794(Border p0)
        {
            BorderFactory.createTitledBorder(p0);
        }

        public void createTitledBorder_test_1795(Border p0, string p1)
        {
            BorderFactory.createTitledBorder(p0, p1);
        }

        public void createTitledBorder_test_1796(Border p0, string p1, int p2, int p3)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3);
        }

        public void createCompoundBorder_test_1797()
        {
            BorderFactory.createCompoundBorder();
        }

        public void createCompoundBorder_test_1798(Border p0, Border p1)
        {
            BorderFactory.createCompoundBorder(p0, p1);
        }

        public void createMatteBorder_test_1799(int p0, int p1, int p2, int p3, Color p4)
        {
            BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
        }

        public void createMatteBorder_test_1800(int p0, int p1, int p2, int p3, Icon p4)
        {
            BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
        }

        public void createRaisedBevelBorder_test_1801()
        {
            BorderFactory.createRaisedBevelBorder();
        }

        public void createRaisedSoftBevelBorder_test_1802()
        {
            BorderFactory.createRaisedSoftBevelBorder();
        }

        public void createLoweredSoftBevelBorder_test_1803()
        {
            BorderFactory.createLoweredSoftBevelBorder();
        }

        public void createDashedBorder_test_1804(Paint p0)
        {
            BorderFactory.createDashedBorder(p0);
        }

        public void createDashedBorder_test_1805(Paint p0, float p1, float p2)
        {
            BorderFactory.createDashedBorder(p0, p1, p2);
        }

        public void createDashedBorder_test_1806(Paint p0, float p1, float p2, float p3, bool p4)
        {
            BorderFactory.createDashedBorder(p0, p1, p2, p3, p4);
        }

        public void createStrokeBorder_test_1807(BasicStroke p0, Paint p1)
        {
            BorderFactory.createStrokeBorder(p0, p1);
        }

        public void createStrokeBorder_test_1808(BasicStroke p0)
        {
            BorderFactory.createStrokeBorder(p0);
        }

        public void createEmptyBorder_test_1809()
        {
            BorderFactory.createEmptyBorder();
        }

        public void createEmptyBorder_test_1810(int p0, int p1, int p2, int p3)
        {
            BorderFactory.createEmptyBorder(p0, p1, p2, p3);
        }

        public void createLineBorder_test_1811(Color p0, int p1, bool p2)
        {
            BorderFactory.createLineBorder(p0, p1, p2);
        }

        public void createLineBorder_test_1812(Color p0)
        {
            BorderFactory.createLineBorder(p0);
        }

        public void createLineBorder_test_1813(Color p0, int p1)
        {
            BorderFactory.createLineBorder(p0, p1);
        }
    }
}