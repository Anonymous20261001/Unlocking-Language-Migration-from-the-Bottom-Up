namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class CompositeData
    {
        public object Get(string key)
        {
            throw new NotImplementedException();
        }

        public bool ContainsKey(string key)
        {
            throw new NotImplementedException();
        }

        public string[] GetCompositeType()
        {
            throw new NotImplementedException();
        }
    }

    public class RecordingInfo
    {
        public static RecordingInfo From(CompositeData p0)
        {
            throw new NotImplementedException();
        }
    }

    public class jdk_management_jfr_RecordingInfoAutoTest
    {
        public void from_test_10377(CompositeData p0)
        {
            RecordingInfo.From(p0);
        }
    }
}