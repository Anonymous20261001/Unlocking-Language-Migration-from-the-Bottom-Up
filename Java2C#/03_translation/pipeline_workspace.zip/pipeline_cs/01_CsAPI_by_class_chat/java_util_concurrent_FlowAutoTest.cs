namespace Generated.Test
{
    public class java_util_concurrent_FlowAutoTest
    {
        public void defaultBufferSize_test_4895()
        {
            Flow.defaultBufferSize();
        }
    }

    public static class Flow
    {
        public static int defaultBufferSize()
        {
            return 256;
        }
    }
}