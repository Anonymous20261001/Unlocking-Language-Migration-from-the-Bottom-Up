namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_BaselineTIFFTagSetAutoTest
    {
        public void getInstance_test_984()
        {
            BaselineTIFFTagSet.getInstance();
        }
    }

    public class BaselineTIFFTagSet
    {
        private static BaselineTIFFTagSet instance;

        private BaselineTIFFTagSet()
        {
        }

        public static BaselineTIFFTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new BaselineTIFFTagSet();
            }
            return instance;
        }
    }
}