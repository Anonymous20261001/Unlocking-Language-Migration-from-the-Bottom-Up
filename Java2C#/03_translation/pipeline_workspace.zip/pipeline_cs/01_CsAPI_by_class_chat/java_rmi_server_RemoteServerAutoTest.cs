namespace Generated.Test
{
    using System.IO;

    public class java_rmi_server_RemoteServerAutoTest
    {
        public void setLog_test_10522(Stream p0)
        {
            RemoteServer.SetLog(p0);
        }

        public void getLog_test_10523()
        {
            RemoteServer.GetLog();
        }
    }

    public static class RemoteServer
    {
        private static Stream logStream;

        public static void SetLog(Stream stream)
        {
            logStream = stream;
        }

        public static Stream GetLog()
        {
            return logStream;
        }
    }
}