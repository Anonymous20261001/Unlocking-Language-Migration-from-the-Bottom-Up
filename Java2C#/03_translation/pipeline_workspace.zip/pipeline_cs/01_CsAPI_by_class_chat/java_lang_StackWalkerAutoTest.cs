using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class StackWalker
    {
        public enum Option
        {
            RETAIN_CLASS_REFERENCE,
            SHOW_HIDDEN_FRAMES,
            SHOW_REFLECT_FRAMES
        }

        public static StackWalker GetInstance(Option option)
        {
            return new StackWalker();
        }

        public static StackWalker GetInstance(Set<Option> options)
        {
            return new StackWalker();
        }

        public static StackWalker GetInstance(Set<Option> options, int estimate)
        {
            return new StackWalker();
        }

        public static StackWalker GetInstance()
        {
            return new StackWalker();
        }
    }

    public class Set<T> : HashSet<T>
    {
    }

    public class java_lang_StackWalkerAutoTest
    {
        public void getInstance_test_11454(StackWalker.Option p0)
        {
            StackWalker.GetInstance(p0);
        }

        public void getInstance_test_11455(Set<StackWalker.Option> p0)
        {
            StackWalker.GetInstance(p0);
        }

        public void getInstance_test_11456(Set<StackWalker.Option> p0, int p1)
        {
            StackWalker.GetInstance(p0, p1);
        }

        public void getInstance_test_11457()
        {
            StackWalker.GetInstance();
        }
    }
}