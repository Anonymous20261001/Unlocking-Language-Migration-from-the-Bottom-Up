namespace Generated.Test
{
    public class java_text_NumberFormatAutoTest
    {
        public void getInstance_test_9557(Locale p0)
        {
            NumberFormat.GetInstance(p0);
        }

        public void getInstance_test_9558()
        {
            NumberFormat.GetInstance();
        }

        public void getAvailableLocales_test_9559()
        {
            NumberFormat.GetAvailableLocales();
        }

        public void getCurrencyInstance_test_9560(Locale p0)
        {
            NumberFormat.GetCurrencyInstance(p0);
        }

        public void getCurrencyInstance_test_9561()
        {
            NumberFormat.GetCurrencyInstance();
        }

        public void getPercentInstance_test_9562()
        {
            NumberFormat.GetPercentInstance();
        }

        public void getPercentInstance_test_9563(Locale p0)
        {
            NumberFormat.GetPercentInstance(p0);
        }

        public void getIntegerInstance_test_9564(Locale p0)
        {
            NumberFormat.GetIntegerInstance(p0);
        }

        public void getIntegerInstance_test_9565()
        {
            NumberFormat.GetIntegerInstance();
        }

        public void getCompactNumberInstance_test_9566(Locale p0, NumberFormat.Style p1)
        {
            NumberFormat.GetCompactNumberInstance(p0, p1);
        }

        public void getCompactNumberInstance_test_9567()
        {
            NumberFormat.GetCompactNumberInstance();
        }

        public void getNumberInstance_test_9568()
        {
            NumberFormat.GetNumberInstance();
        }

        public void getNumberInstance_test_9569(Locale p0)
        {
            NumberFormat.GetNumberInstance(p0);
        }
    }

    public class Locale
    {
        public static Locale GetDefault()
        {
            return new Locale();
        }

        public static Locale[] GetAvailableLocales()
        {
            return new Locale[0];
        }
    }

    public class NumberFormat
    {
        public enum Style
        {
            SHORT,
            LONG
        }

        public static NumberFormat GetInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetInstance(Locale locale)
        {
            return new NumberFormat();
        }

        public static Locale[] GetAvailableLocales()
        {
            return Locale.GetAvailableLocales();
        }

        public static NumberFormat GetCurrencyInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetCurrencyInstance(Locale locale)
        {
            return new NumberFormat();
        }

        public static NumberFormat GetPercentInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetPercentInstance(Locale locale)
        {
            return new NumberFormat();
        }

        public static NumberFormat GetIntegerInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetIntegerInstance(Locale locale)
        {
            return new NumberFormat();
        }

        public static NumberFormat GetCompactNumberInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetCompactNumberInstance(Locale locale, Style style)
        {
            return new NumberFormat();
        }

        public static NumberFormat GetNumberInstance()
        {
            return new NumberFormat();
        }

        public static NumberFormat GetNumberInstance(Locale locale)
        {
            return new NumberFormat();
        }
    }
}