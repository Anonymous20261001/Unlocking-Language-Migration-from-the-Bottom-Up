using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

namespace Generated.Test
{
    // C# equivalent of java.lang.reflect.InvocationHandler
    public interface InvocationHandler
    {
        object Invoke(object proxy, MethodInfo method, object[] args);
    }

    // C# equivalent of java.lang.reflect.Proxy
    public class Proxy
    {
        // Simulates java.lang.reflect.Proxy.getProxyClass
        public static Type GetProxyClass(TypeLoader classLoader, Type[] interfaces)
        {
            if (interfaces == null || interfaces.Length == 0)
                throw new ArgumentException("interfaces must not be empty");

            foreach (Type iface in interfaces)
            {
                if (!iface.IsInterface)
                    throw new ArgumentException(iface.FullName + " is not an interface");
            }

            // Create a dynamic proxy type
            AssemblyName assemblyName = new AssemblyName("ProxyAssembly_" + Guid.NewGuid().ToString("N"));
            AssemblyBuilder assemblyBuilder = AssemblyBuilder.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule("ProxyModule");

            TypeBuilder typeBuilder = moduleBuilder.DefineType("Proxy_" + Guid.NewGuid().ToString("N"),
                TypeAttributes.Public | TypeAttributes.Class);

            // Implement all interfaces
            foreach (Type iface in interfaces)
            {
                typeBuilder.AddInterfaceImplementation(iface);
            }

            // Add a field to hold the InvocationHandler
            FieldBuilder handlerField = typeBuilder.DefineField("_handler", typeof(InvocationHandler), FieldAttributes.Private);

            // Add constructor
            ConstructorBuilder ctorBuilder = typeBuilder.DefineConstructor(
                MethodAttributes.Public, CallingConventions.Standard, new Type[] { typeof(InvocationHandler) });
            ILGenerator ctorIL = ctorBuilder.GetILGenerator();
            ctorIL.Emit(OpCodes.Ldarg_0);
            ctorIL.Emit(OpCodes.Call, typeof(object).GetConstructor(Type.EmptyTypes));
            ctorIL.Emit(OpCodes.Ldarg_0);
            ctorIL.Emit(OpCodes.Ldarg_1);
            ctorIL.Emit(OpCodes.Stfld, handlerField);
            ctorIL.Emit(OpCodes.Ret);

            // For each interface method, create a proxy implementation
            foreach (Type iface in interfaces)
            {
                foreach (MethodInfo method in iface.GetMethods())
                {
                    MethodBuilder methodBuilder = typeBuilder.DefineMethod(
                        method.Name,
                        MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final,
                        method.ReturnType,
                        Array.ConvertAll(method.GetParameters(), p => p.ParameterType));

                    ILGenerator il = methodBuilder.GetILGenerator();

                    // Load this
                    il.Emit(OpCodes.Ldarg_0);
                    // Load handler field
                    il.Emit(OpCodes.Ldfld, handlerField);
                    // Load this (proxy)
                    il.Emit(OpCodes.Ldarg_0);
                    // Load method info
                    il.Emit(OpCodes.Ldtoken, method);
                    il.Emit(OpCodes.Call, typeof(MethodBase).GetMethod("GetMethodFromHandle", new Type[] { typeof(RuntimeMethodHandle) }));
                    // Create args array
                    ParameterInfo[] parameters = method.GetParameters();
                    il.Emit(OpCodes.Ldc_I4, parameters.Length);
                    il.Emit(OpCodes.Newarr, typeof(object));
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        il.Emit(OpCodes.Dup);
                        il.Emit(OpCodes.Ldc_I4, i);
                        il.Emit(OpCodes.Ldarg, i + 1);
                        if (parameters[i].ParameterType.IsValueType)
                        {
                            il.Emit(OpCodes.Box, parameters[i].ParameterType);
                        }
                        il.Emit(OpCodes.Stelem_Ref);
                    }
                    // Call Invoke
                    il.Emit(OpCodes.Callvirt, typeof(InvocationHandler).GetMethod("Invoke"));

                    // Handle return value
                    if (method.ReturnType == typeof(void))
                    {
                        il.Emit(OpCodes.Pop);
                        il.Emit(OpCodes.Ret);
                    }
                    else if (method.ReturnType.IsValueType)
                    {
                        il.Emit(OpCodes.Unbox_Any, method.ReturnType);
                        il.Emit(OpCodes.Ret);
                    }
                    else
                    {
                        il.Emit(OpCodes.Castclass, method.ReturnType);
                        il.Emit(OpCodes.Ret);
                    }

                    typeBuilder.DefineMethodOverride(methodBuilder, method);
                }
            }

            return typeBuilder.CreateType();
        }

        // Simulates java.lang.reflect.Proxy.getInvocationHandler
        public static InvocationHandler GetInvocationHandler(object proxy)
        {
            if (proxy == null)
                throw new ArgumentNullException("proxy");

            FieldInfo handlerField = proxy.GetType().GetField("_handler", BindingFlags.NonPublic | BindingFlags.Instance);
            if (handlerField == null)
                throw new ArgumentException("not a proxy instance");

            return (InvocationHandler)handlerField.GetValue(proxy);
        }

        // Simulates java.lang.reflect.Proxy.isProxyClass
        public static bool IsProxyClass(Type clazz)
        {
            if (clazz == null)
                throw new ArgumentNullException("clazz");

            return clazz.Name.StartsWith("Proxy_") && clazz.GetField("_handler", BindingFlags.NonPublic | BindingFlags.Instance) != null;
        }

        // Simulates java.lang.reflect.Proxy.newProxyInstance
        public static object NewProxyInstance(TypeLoader classLoader, Type[] interfaces, InvocationHandler handler)
        {
            if (handler == null)
                throw new ArgumentNullException("handler");

            Type proxyType = GetProxyClass(classLoader, interfaces);
            return Activator.CreateInstance(proxyType, handler);
        }
    }

    // C# equivalent of java.lang.ClassLoader (simplified)
    public class TypeLoader
    {
        // Simplified - just a placeholder
    }

    // Test class
    public class java_lang_reflect_ProxyAutoTest
    {
        public void getProxyClass_test_10213(TypeLoader p0, Type[] p1)
        {
            Proxy.GetProxyClass(p0, p1);
        }

        public void getInvocationHandler_test_10214(object p0)
        {
            Proxy.GetInvocationHandler(p0);
        }

        public void isProxyClass_test_10215(Type p0)
        {
            Proxy.IsProxyClass(p0);
        }

        public void newProxyInstance_test_10216(TypeLoader p0, Type[] p1, InvocationHandler p2)
        {
            Proxy.NewProxyInstance(p0, p1, p2);
        }
    }
}