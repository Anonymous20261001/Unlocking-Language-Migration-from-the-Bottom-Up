namespace Generated.Test
{
    public class javax_imageio_metadata_IIOMetadataNodeAutoTest
    {
        public void getTagName_test_5556()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getTagName();
        }

        public void getAttributeNode_test_5557(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNode(p0);
        }

        public void setAttributeNode_test_5558(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNode(p0);
        }

        public void removeAttributeNode_test_5559(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttributeNode(p0);
        }

        public void setAttributeNS_test_5560(string p0, string p1, string p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNS(p0, p1, p2);
        }

        public void removeAttributeNS_test_5561(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttributeNS(p0, p1);
        }

        public void getAttributeNodeNS_test_5562(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNodeNS(p0, p1);
        }

        public void setAttributeNodeNS_test_5563(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNodeNS(p0);
        }

        public void hasAttribute_test_5564(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttribute(p0);
        }

        public void hasAttributeNS_test_5565(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttributeNS(p0, p1);
        }

        public void getSchemaTypeInfo_test_5566()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getSchemaTypeInfo();
        }

        public void setIdAttribute_test_5567(string p0, bool p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttribute(p0, p1);
        }

        public void setIdAttributeNode_test_5568(Attr p0, bool p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttributeNode(p0, p1);
        }

        public void getNamespaceURI_test_5569()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNamespaceURI();
        }

        public void removeAttribute_test_5570(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttribute(p0);
        }

        public void getUserObject_test_5571()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getUserObject();
        }

        public void getNextSibling_test_5572()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNextSibling();
        }

        public void getPreviousSibling_test_5573()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getPreviousSibling();
        }

        public void getFirstChild_test_5574()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getFirstChild();
        }

        public void getLastChild_test_5575()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLastChild();
        }

        public void setUserObject_test_5576(object p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setUserObject(p0);
        }

        public void getUserData_test_5577(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getUserData(p0);
        }

        public void setUserData_test_5578(string p0, object p1, UserDataHandler p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setUserData(p0, p1, p2);
        }

        public void getPrefix_test_5579()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getPrefix();
        }

        public void getElementsByTagName_test_5580(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getElementsByTagName(p0);
        }

        public void getElementsByTagNameNS_test_5581(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getElementsByTagNameNS(p0, p1);
        }

        public void getNodeName_test_5582()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeName();
        }

        public void getNodeValue_test_5583()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeValue();
        }

        public void setNodeValue_test_5584(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setNodeValue(p0);
        }

        public void getParentNode_test_5585()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getParentNode();
        }

        public void getChildNodes_test_5586()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getChildNodes();
        }

        public void getOwnerDocument_test_5587()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getOwnerDocument();
        }

        public void insertBefore_test_5588(Node p0, Node p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.insertBefore(p0, p1);
        }

        public void replaceChild_test_5589(Node p0, Node p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.replaceChild(p0, p1);
        }

        public void removeChild_test_5590(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeChild(p0);
        }

        public void appendChild_test_5591(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.appendChild(p0);
        }

        public void hasChildNodes_test_5592()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasChildNodes();
        }

        public void cloneNode_test_5593(bool p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.cloneNode(p0);
        }

        public void setPrefix_test_5594(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setPrefix(p0);
        }

        public void getLocalName_test_5595()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLocalName();
        }

        public void hasAttributes_test_5596()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttributes();
        }

        public void getBaseURI_test_5597()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getBaseURI();
        }

        public void compareDocumentPosition_test_5598(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.compareDocumentPosition(p0);
        }

        public void getTextContent_test_5599()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getTextContent();
        }

        public void setTextContent_test_5600(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setTextContent(p0);
        }

        public void isSameNode_test_5601(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isSameNode(p0);
        }

        public void lookupPrefix_test_5602(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.lookupPrefix(p0);
        }

        public void isDefaultNamespace_test_5603(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isDefaultNamespace(p0);
        }

        public void lookupNamespaceURI_test_5604(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.lookupNamespaceURI(p0);
        }

        public void isEqualNode_test_5605(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isEqualNode(p0);
        }

        public void getLength_test_5606()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLength();
        }

        public void isSupported_test_5607(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isSupported(p0, p1);
        }

        public void getAttributes_test_5608()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributes();
        }

        public void normalize_test_5609()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.normalize();
        }

        public void setAttribute_test_5610(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttribute(p0, p1);
        }

        public void getAttribute_test_5611(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttribute(p0);
        }

        public void item_test_5612(int p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.item(p0);
        }

        public void getNodeType_test_5613()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeType();
        }

        public void getFeature_test_5614(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getFeature(p0, p1);
        }

        public void getAttributeNS_test_5615(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNS(p0, p1);
        }

        public void setIdAttributeNS_test_5616(string p0, string p1, bool p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttributeNS(p0, p1, p2);
        }
    }

    public class IIOMetadataNode
    {
        private string tagName;
        private object userObject;
        private string nodeValue;
        private string prefix;
        private string localName;
        private string namespaceURI;
        private IIOMetadataNode parentNode;
        private IIOMetadataNode firstChild;
        private IIOMetadataNode lastChild;
        private IIOMetadataNode previousSibling;
        private IIOMetadataNode nextSibling;
        private System.Collections.Generic.List<IIOMetadataNode> children = new System.Collections.Generic.List<IIOMetadataNode>();
        private System.Collections.Generic.Dictionary<string, string> attributes = new System.Collections.Generic.Dictionary<string, string>();
        private System.Collections.Generic.Dictionary<string, object> userData = new System.Collections.Generic.Dictionary<string, object>();

        public IIOMetadataNode()
        {
        }

        public IIOMetadataNode(string tagName)
        {
            this.tagName = tagName;
        }

        public string getTagName()
        {
            return tagName;
        }

        public Attr getAttributeNode(string name)
        {
            return null;
        }

        public Attr setAttributeNode(Attr attr)
        {
            return null;
        }

        public Attr removeAttributeNode(Attr attr)
        {
            return null;
        }

        public void setAttributeNS(string namespaceURI, string qualifiedName, string value)
        {
        }

        public void removeAttributeNS(string namespaceURI, string localName)
        {
        }

        public Attr getAttributeNodeNS(string namespaceURI, string localName)
        {
            return null;
        }

        public Attr setAttributeNodeNS(Attr attr)
        {
            return null;
        }

        public bool hasAttribute(string name)
        {
            return attributes.ContainsKey(name);
        }

        public bool hasAttributeNS(string namespaceURI, string localName)
        {
            return false;
        }

        public object getSchemaTypeInfo()
        {
            return null;
        }

        public void setIdAttribute(string name, bool isId)
        {
        }

        public void setIdAttributeNode(Attr attr, bool isId)
        {
        }

        public string getNamespaceURI()
        {
            return namespaceURI;
        }

        public void removeAttribute(string name)
        {
            attributes.Remove(name);
        }

        public object getUserObject()
        {
            return userObject;
        }

        public IIOMetadataNode getNextSibling()
        {
            return nextSibling;
        }

        public IIOMetadataNode getPreviousSibling()
        {
            return previousSibling;
        }

        public IIOMetadataNode getFirstChild()
        {
            return firstChild;
        }

        public IIOMetadataNode getLastChild()
        {
            return lastChild;
        }

        public void setUserObject(object userObject)
        {
            this.userObject = userObject;
        }

        public object getUserData(string key)
        {
            if (userData.ContainsKey(key))
                return userData[key];
            return null;
        }

        public object setUserData(string key, object data, UserDataHandler handler)
        {
            object old = getUserData(key);
            userData[key] = data;
            return old;
        }

        public string getPrefix()
        {
            return prefix;
        }

        public NodeList getElementsByTagName(string name)
        {
            return new NodeList();
        }

        public NodeList getElementsByTagNameNS(string namespaceURI, string localName)
        {
            return new NodeList();
        }

        public string getNodeName()
        {
            return tagName;
        }

        public string getNodeValue()
        {
            return nodeValue;
        }

        public void setNodeValue(string nodeValue)
        {
            this.nodeValue = nodeValue;
        }

        public IIOMetadataNode getParentNode()
        {
            return parentNode;
        }

        public NodeList getChildNodes()
        {
            NodeList list = new NodeList();
            foreach (var child in children)
                list.add(child);
            return list;
        }

        public object getOwnerDocument()
        {
            return null;
        }

        public Node insertBefore(Node newChild, Node refChild)
        {
            return newChild;
        }

        public Node replaceChild(Node newChild, Node oldChild)
        {
            return oldChild;
        }

        public Node removeChild(Node oldChild)
        {
            return oldChild;
        }

        public Node appendChild(Node newChild)
        {
            if (newChild is IIOMetadataNode)
            {
                IIOMetadataNode child = (IIOMetadataNode)newChild;
                child.parentNode = this;
                if (firstChild == null)
                    firstChild = child;
                child.previousSibling = lastChild;
                if (lastChild != null)
                    lastChild.nextSibling = child;
                lastChild = child;
                children.Add(child);
            }
            return newChild;
        }

        public bool hasChildNodes()
        {
            return children.Count > 0;
        }

        public object cloneNode(bool deep)
        {
            IIOMetadataNode clone = new IIOMetadataNode(tagName);
            clone.nodeValue = nodeValue;
            clone.prefix = prefix;
            clone.localName = localName;
            clone.namespaceURI = namespaceURI;
            clone.userObject = userObject;
            if (deep)
            {
                foreach (var child in children)
                {
                    IIOMetadataNode childClone = (IIOMetadataNode)child.cloneNode(true);
                    clone.appendChild(childClone);
                }
            }
            return clone;
        }

        public void setPrefix(string prefix)
        {
            this.prefix = prefix;
        }

        public string getLocalName()
        {
            return localName;
        }

        public bool hasAttributes()
        {
            return attributes.Count > 0;
        }

        public string getBaseURI()
        {
            return null;
        }

        public short compareDocumentPosition(Node other)
        {
            return 0;
        }

        public string getTextContent()
        {
            return nodeValue;
        }

        public void setTextContent(string textContent)
        {
            this.nodeValue = textContent;
        }

        public bool isSameNode(Node other)
        {
            return this == other;
        }

        public string lookupPrefix(string namespaceURI)
        {
            return null;
        }

        public bool isDefaultNamespace(string namespaceURI)
        {
            return false;
        }

        public string lookupNamespaceURI(string prefix)
        {
            return null;
        }

        public bool isEqualNode(Node other)
        {
            return this == other;
        }

        public int getLength()
        {
            return children.Count;
        }

        public bool isSupported(string feature, string version)
        {
            return false;
        }

        public NamedNodeMap getAttributes()
        {
            return new NamedNodeMap();
        }

        public void normalize()
        {
        }

        public void setAttribute(string name, string value)
        {
            attributes[name] = value;
        }

        public string getAttribute(string name)
        {
            if (attributes.ContainsKey(name))
                return attributes[name];
            return "";
        }

        public Node item(int index)
        {
            if (index >= 0 && index < children.Count)
                return children[index];
            return null;
        }

        public short getNodeType()
        {
            return 1;
        }

        public object getFeature(string feature, string version)
        {
            return null;
        }

        public string getAttributeNS(string namespaceURI, string localName)
        {
            return "";
        }

        public void setIdAttributeNS(string namespaceURI, string localName, bool isId)
        {
        }
    }

    public class Attr
    {
        private string name;
        private string value;

        public Attr(string name, string value)
        {
            this.name = name;
            this.value = value;
        }

        public string getName()
        {
            return name;
        }

        public string getValue()
        {
            return value;
        }
    }

    public class Node
    {
    }

    public class NodeList
    {
        private System.Collections.Generic.List<Node> nodes = new System.Collections.Generic.List<Node>();

        public void add(Node node)
        {
            nodes.Add(node);
        }

        public int getLength()
        {
            return nodes.Count;
        }

        public Node item(int index)
        {
            if (index >= 0 && index < nodes.Count)
                return nodes[index];
            return null;
        }
    }

    public class NamedNodeMap
    {
        private System.Collections.Generic.List<Attr> attrs = new System.Collections.Generic.List<Attr>();

        public int getLength()
        {
            return attrs.Count;
        }

        public Attr item(int index)
        {
            if (index >= 0 && index < attrs.Count)
                return attrs[index];
            return null;
        }
    }

    public class UserDataHandler
    {
    }
}