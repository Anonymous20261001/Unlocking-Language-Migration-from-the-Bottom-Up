namespace Generated.Test
{
    public class java_awt_KeyboardFocusManagerAutoTest
    {
        public void setCurrentKeyboardFocusManager_test_7611(KeyboardFocusManager p0)
        {
            KeyboardFocusManager.SetCurrentKeyboardFocusManager(p0);
        }

        public void getCurrentKeyboardFocusManager_test_7612()
        {
            KeyboardFocusManager.GetCurrentKeyboardFocusManager();
        }
    }

    public class KeyboardFocusManager
    {
        private static KeyboardFocusManager _current;

        public static void SetCurrentKeyboardFocusManager(KeyboardFocusManager manager)
        {
            _current = manager;
        }

        public static KeyboardFocusManager GetCurrentKeyboardFocusManager()
        {
            return _current;
        }
    }
}