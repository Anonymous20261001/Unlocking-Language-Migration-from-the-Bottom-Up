namespace Generated.Test
{
    using System;

    public class OptionalLong
    {
        private readonly bool _hasValue;
        private readonly long _value;

        private OptionalLong(bool hasValue, long value)
        {
            _hasValue = hasValue;
            _value = value;
        }

        public static OptionalLong Of(long value)
        {
            return new OptionalLong(true, value);
        }

        public static OptionalLong Empty()
        {
            return new OptionalLong(false, 0);
        }

        public bool HasValue => _hasValue;
        public long Value => _value;
    }

    public class java_util_OptionalLongAutoTest
    {
        public void of_test_9696(long p0)
        {
            OptionalLong.Of(p0);
        }

        public void empty_test_9697()
        {
            OptionalLong.Empty();
        }
    }
}