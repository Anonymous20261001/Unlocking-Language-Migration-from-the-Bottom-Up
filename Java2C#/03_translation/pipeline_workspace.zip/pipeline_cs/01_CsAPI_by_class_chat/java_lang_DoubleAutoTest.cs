namespace Generated.Test
{
    public class java_lang_DoubleAutoTest
    {
        public void min_test_4224(double p0, double p1)
        {
            DoubleHelper.Min(p0, p1);
        }

        public void max_test_4225(double p0, double p1)
        {
            DoubleHelper.Max(p0, p1);
        }

        public void isInfinite_test_4226(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.IsInfinite();
        }

        public void isInfinite_test_4227(double p0)
        {
            DoubleHelper.IsInfinite(p0);
        }

        public void isFinite_test_4228(double p0)
        {
            DoubleHelper.IsFinite(p0);
        }

        public void doubleToRawLongBits_test_4229(double p0)
        {
            DoubleHelper.DoubleToRawLongBits(p0);
        }

        public void doubleToLongBits_test_4230(double p0)
        {
            DoubleHelper.DoubleToLongBits(p0);
        }

        public void longBitsToDouble_test_4231(long p0)
        {
            DoubleHelper.LongBitsToDouble(p0);
        }

        public void compareTo_test_4232(DoubleHelper p0, double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.CompareTo(p0);
        }

        public void compare_test_4233(double p0, double p1)
        {
            DoubleHelper.Compare(p0, p1);
        }

        public void byteValue_test_4234(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.ByteValue();
        }

        public void shortValue_test_4235(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.ShortValue();
        }

        public void intValue_test_4236(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.IntValue();
        }

        public void longValue_test_4237(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.LongValue();
        }

        public void floatValue_test_4238(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.FloatValue();
        }

        public void doubleValue_test_4239(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.DoubleValue();
        }

        public void valueOf_test_4240(string p0)
        {
            DoubleHelper.ValueOf(p0);
        }

        public void valueOf_test_4241(double p0)
        {
            DoubleHelper.ValueOf(p0);
        }

        public void toHexString_test_4242(double p0)
        {
            DoubleHelper.ToHexString(p0);
        }

        public void resolveConstantDesc_test_4243(object p0, double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.ResolveConstantDesc(p0);
        }

        public void describeConstable_test_4244(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.DescribeConstable();
        }

        public void isNaN_test_4245(double c0)
        {
            DoubleHelper instance = new DoubleHelper(c0);
            instance.IsNaN();
        }

        public void isNaN_test_4246(double p0)
        {
            DoubleHelper.IsNaN(p0);
        }

        public void sum_test_4247(double p0, double p1)
        {
            DoubleHelper.Sum(p0, p1);
        }

        public void parseDouble_test_4248(string p0)
        {
            DoubleHelper.ParseDouble(p0);
        }
    }

    public class DoubleHelper
    {
        private double value;

        public DoubleHelper(double value)
        {
            this.value = value;
        }

        public static double Min(double a, double b)
        {
            return System.Math.Min(a, b);
        }

        public static double Max(double a, double b)
        {
            return System.Math.Max(a, b);
        }

        public bool IsInfinite()
        {
            return double.IsInfinity(value);
        }

        public static bool IsInfinite(double d)
        {
            return double.IsInfinity(d);
        }

        public static bool IsFinite(double d)
        {
            return !double.IsInfinity(d) && !double.IsNaN(d);
        }

        public static long DoubleToRawLongBits(double value)
        {
            return System.BitConverter.DoubleToInt64Bits(value);
        }

        public static long DoubleToLongBits(double value)
        {
            return System.BitConverter.DoubleToInt64Bits(value);
        }

        public static double LongBitsToDouble(long bits)
        {
            return System.BitConverter.Int64BitsToDouble(bits);
        }

        public int CompareTo(DoubleHelper other)
        {
            return value.CompareTo(other.value);
        }

        public static int Compare(double d1, double d2)
        {
            return d1.CompareTo(d2);
        }

        public byte ByteValue()
        {
            return (byte)value;
        }

        public short ShortValue()
        {
            return (short)value;
        }

        public int IntValue()
        {
            return (int)value;
        }

        public long LongValue()
        {
            return (long)value;
        }

        public float FloatValue()
        {
            return (float)value;
        }

        public double DoubleValue()
        {
            return value;
        }

        public static DoubleHelper ValueOf(string s)
        {
            return new DoubleHelper(double.Parse(s));
        }

        public static DoubleHelper ValueOf(double d)
        {
            return new DoubleHelper(d);
        }

        public static string ToHexString(double d)
        {
            return d.ToString("X");
        }

        public object ResolveConstantDesc(object lookup)
        {
            return this;
        }

        public object DescribeConstable()
        {
            return this;
        }

        public bool IsNaN()
        {
            return double.IsNaN(value);
        }

        public static bool IsNaN(double d)
        {
            return double.IsNaN(d);
        }

        public static double Sum(double a, double b)
        {
            return a + b;
        }

        public static double ParseDouble(string s)
        {
            return double.Parse(s);
        }
    }
}