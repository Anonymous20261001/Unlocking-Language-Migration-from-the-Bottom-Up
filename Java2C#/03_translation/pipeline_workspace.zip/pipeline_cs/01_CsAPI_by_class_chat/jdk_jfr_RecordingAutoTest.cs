namespace Generated.Test;

using System;
using System.Collections.Generic;

public class Recording : IDisposable
{
    private Dictionary<string, string> settings = new Dictionary<string, string>();
    private TimeSpan? maxAge;
    private bool toDisk = true;
    private DateTime? startTime;
    private DateTime? stopTime;
    private string destination;
    private long maxSize;
    private bool dumpOnExit;
    private TimeSpan? duration;
    private string name;
    private long id;
    private string state = "NEW";
    private long size;
    private bool started;
    private bool stopped;

    public Recording()
    {
        id = DateTime.Now.Ticks;
    }

    public Dictionary<string, string> GetSettings()
    {
        return settings;
    }

    public void SetMaxAge(TimeSpan? maxAge)
    {
        this.maxAge = maxAge;
    }

    public TimeSpan? GetMaxAge()
    {
        return maxAge;
    }

    public void SetSettings(Dictionary<string, string> settings)
    {
        this.settings = settings ?? new Dictionary<string, string>();
    }

    public bool IsToDisk()
    {
        return toDisk;
    }

    public DateTime? GetStartTime()
    {
        return startTime;
    }

    public DateTime? GetStopTime()
    {
        return stopTime;
    }

    public string GetDestination()
    {
        return destination;
    }

    public long GetMaxSize()
    {
        return maxSize;
    }

    public void SetMaxSize(long maxSize)
    {
        this.maxSize = maxSize;
    }

    public bool GetDumpOnExit()
    {
        return dumpOnExit;
    }

    public void SetDumpOnExit(bool dumpOnExit)
    {
        this.dumpOnExit = dumpOnExit;
    }

    public void SetToDisk(bool toDisk)
    {
        this.toDisk = toDisk;
    }

    public void ScheduleStart(TimeSpan? delay)
    {
        // Schedule start after delay
        startTime = DateTime.Now + (delay ?? TimeSpan.Zero);
    }

    public void SetDuration(TimeSpan? duration)
    {
        this.duration = duration;
    }

    public string GetName()
    {
        return name;
    }

    public Recording Copy(bool stop)
    {
        Recording copy = new Recording();
        copy.settings = new Dictionary<string, string>(settings);
        copy.maxAge = maxAge;
        copy.toDisk = toDisk;
        copy.startTime = startTime;
        copy.stopTime = stopTime;
        copy.destination = destination;
        copy.maxSize = maxSize;
        copy.dumpOnExit = dumpOnExit;
        copy.duration = duration;
        copy.name = name;
        copy.state = state;
        copy.size = size;
        return copy;
    }

    public void Start()
    {
        if (!started)
        {
            started = true;
            state = "RUNNING";
            startTime = DateTime.Now;
        }
    }

    public void Stop()
    {
        if (started && !stopped)
        {
            stopped = true;
            state = "STOPPED";
            stopTime = DateTime.Now;
        }
    }

    public void SetName(string name)
    {
        this.name = name;
    }

    public long GetId()
    {
        return id;
    }

    public string GetState()
    {
        return state;
    }

    public void Close()
    {
        if (started && !stopped)
        {
            Stop();
        }
        state = "CLOSED";
    }

    public long GetSize()
    {
        return size;
    }

    public object Enable(Type eventType)
    {
        // Enable event by type
        return new object();
    }

    public object Enable(string eventName)
    {
        // Enable event by name
        return new object();
    }

    public TimeSpan? GetDuration()
    {
        return duration;
    }

    public void Disable(string eventName)
    {
        // Disable event by name
    }

    public void Disable(Type eventType)
    {
        // Disable event by type
    }

    public void Dispose()
    {
        Close();
    }
}

public class jdk_jfr_RecordingAutoTest
{
    public void getSettings_test_10348()
    {
        Recording instance = new Recording();
        instance.GetSettings();
    }

    public void setMaxAge_test_10349(TimeSpan? p0)
    {
        Recording instance = new Recording();
        instance.SetMaxAge(p0);
    }

    public void getMaxAge_test_10350()
    {
        Recording instance = new Recording();
        instance.GetMaxAge();
    }

    public void setSettings_test_10351(Dictionary<string, string> p0)
    {
        Recording instance = new Recording();
        instance.SetSettings(p0);
    }

    public void isToDisk_test_10352()
    {
        Recording instance = new Recording();
        instance.IsToDisk();
    }

    public void getStartTime_test_10353()
    {
        Recording instance = new Recording();
        instance.GetStartTime();
    }

    public void getStopTime_test_10354()
    {
        Recording instance = new Recording();
        instance.GetStopTime();
    }

    public void getDestination_test_10355()
    {
        Recording instance = new Recording();
        instance.GetDestination();
    }

    public void getMaxSize_test_10356()
    {
        Recording instance = new Recording();
        instance.GetMaxSize();
    }

    public void setMaxSize_test_10357(long p0)
    {
        Recording instance = new Recording();
        instance.SetMaxSize(p0);
    }

    public void getDumpOnExit_test_10358()
    {
        Recording instance = new Recording();
        instance.GetDumpOnExit();
    }

    public void setDumpOnExit_test_10359(bool p0)
    {
        Recording instance = new Recording();
        instance.SetDumpOnExit(p0);
    }

    public void setToDisk_test_10360(bool p0)
    {
        Recording instance = new Recording();
        instance.SetToDisk(p0);
    }

    public void scheduleStart_test_10361(TimeSpan? p0)
    {
        Recording instance = new Recording();
        instance.ScheduleStart(p0);
    }

    public void setDuration_test_10362(TimeSpan? p0)
    {
        Recording instance = new Recording();
        instance.SetDuration(p0);
    }

    public void getName_test_10363()
    {
        Recording instance = new Recording();
        instance.GetName();
    }

    public void copy_test_10364(bool p0)
    {
        Recording instance = new Recording();
        instance.Copy(p0);
    }

    public void start_test_10365()
    {
        Recording instance = new Recording();
        instance.Start();
    }

    public void stop_test_10366()
    {
        Recording instance = new Recording();
        instance.Stop();
    }

    public void setName_test_10367(string p0)
    {
        Recording instance = new Recording();
        instance.SetName(p0);
    }

    public void getId_test_10368()
    {
        Recording instance = new Recording();
        instance.GetId();
    }

    public void getState_test_10369()
    {
        Recording instance = new Recording();
        instance.GetState();
    }

    public void close_test_10370()
    {
        Recording instance = new Recording();
        instance.Close();
    }

    public void getSize_test_10371()
    {
        Recording instance = new Recording();
        instance.GetSize();
    }

    public void enable_test_10372(Type p0)
    {
        Recording instance = new Recording();
        instance.Enable(p0);
    }

    public void enable_test_10373(string p0)
    {
        Recording instance = new Recording();
        instance.Enable(p0);
    }

    public void getDuration_test_10374()
    {
        Recording instance = new Recording();
        instance.GetDuration();
    }

    public void disable_test_10375(string p0)
    {
        Recording instance = new Recording();
        instance.Disable(p0);
    }

    public void disable_test_10376(Type p0)
    {
        Recording instance = new Recording();
        instance.Disable(p0);
    }
}