namespace Generated.Test
{
    public class javax_swing_plaf_synth_SynthInternalFrameUIAutoTest
    {
        public void createUI_test_12212(JComponent p0)
        {
            SynthInternalFrameUI.createUI(p0);
        }
    }

    public class SynthInternalFrameUI
    {
        public static object createUI(JComponent p0)
        {
            return null;
        }
    }

    public class JComponent
    {
    }
}