namespace Generated.Test
{
    public class java_awt_print_PageFormatAutoTest
    {
        public void getWidth_test_9735()
        {
            PageFormat instance = new PageFormat();
            instance.GetWidth();
        }

        public void getHeight_test_9736()
        {
            PageFormat instance = new PageFormat();
            instance.GetHeight();
        }

        public void getOrientation_test_9737()
        {
            PageFormat instance = new PageFormat();
            instance.GetOrientation();
        }

        public void getMatrix_test_9738()
        {
            PageFormat instance = new PageFormat();
            instance.GetMatrix();
        }

        public void setOrientation_test_9739(int p0)
        {
            PageFormat instance = new PageFormat();
            instance.SetOrientation(p0);
        }

        public void getImageableY_test_9740()
        {
            PageFormat instance = new PageFormat();
            instance.GetImageableY();
        }

        public void getImageableHeight_test_9741()
        {
            PageFormat instance = new PageFormat();
            instance.GetImageableHeight();
        }

        public void getImageableX_test_9742()
        {
            PageFormat instance = new PageFormat();
            instance.GetImageableX();
        }

        public void getImageableWidth_test_9743()
        {
            PageFormat instance = new PageFormat();
            instance.GetImageableWidth();
        }

        public void getPaper_test_9744()
        {
            PageFormat instance = new PageFormat();
            instance.GetPaper();
        }

        public void setPaper_test_9745(Paper p0)
        {
            PageFormat instance = new PageFormat();
            instance.SetPaper(p0);
        }
    }

    public class PageFormat
    {
        public const int LANDSCAPE = 0;
        public const int PORTRAIT = 1;
        public const int REVERSE_LANDSCAPE = 2;

        private Paper paper;
        private int orientation = PORTRAIT;

        public PageFormat()
        {
            paper = new Paper();
        }

        public double GetWidth()
        {
            return paper.GetWidth();
        }

        public double GetHeight()
        {
            return paper.GetHeight();
        }

        public int GetOrientation()
        {
            return orientation;
        }

        public double[] GetMatrix()
        {
            double[] matrix = new double[6];
            if (orientation == PORTRAIT)
            {
                matrix[0] = 1.0;
                matrix[1] = 0.0;
                matrix[2] = 0.0;
                matrix[3] = 1.0;
                matrix[4] = 0.0;
                matrix[5] = 0.0;
            }
            else if (orientation == LANDSCAPE)
            {
                matrix[0] = 0.0;
                matrix[1] = -1.0;
                matrix[2] = 1.0;
                matrix[3] = 0.0;
                matrix[4] = 0.0;
                matrix[5] = paper.GetHeight();
            }
            else // REVERSE_LANDSCAPE
            {
                matrix[0] = 0.0;
                matrix[1] = 1.0;
                matrix[2] = -1.0;
                matrix[3] = 0.0;
                matrix[4] = paper.GetWidth();
                matrix[5] = 0.0;
            }
            return matrix;
        }

        public void SetOrientation(int orientation)
        {
            if (orientation != LANDSCAPE && orientation != PORTRAIT && orientation != REVERSE_LANDSCAPE)
            {
                throw new System.ArgumentException("Invalid orientation");
            }
            this.orientation = orientation;
        }

        public double GetImageableY()
        {
            return paper.GetImageableY();
        }

        public double GetImageableHeight()
        {
            return paper.GetImageableHeight();
        }

        public double GetImageableX()
        {
            return paper.GetImageableX();
        }

        public double GetImageableWidth()
        {
            return paper.GetImageableWidth();
        }

        public Paper GetPaper()
        {
            return paper;
        }

        public void SetPaper(Paper paper)
        {
            this.paper = paper;
        }
    }

    public class Paper
    {
        private double width;
        private double height;
        private double imageableX;
        private double imageableY;
        private double imageableWidth;
        private double imageableHeight;

        public Paper()
        {
            // Default A4 size in points (595 x 842)
            width = 595.0;
            height = 842.0;
            imageableX = 72.0;
            imageableY = 72.0;
            imageableWidth = width - 2 * imageableX;
            imageableHeight = height - 2 * imageableY;
        }

        public double GetWidth()
        {
            return width;
        }

        public double GetHeight()
        {
            return height;
        }

        public double GetImageableX()
        {
            return imageableX;
        }

        public double GetImageableY()
        {
            return imageableY;
        }

        public double GetImageableWidth()
        {
            return imageableWidth;
        }

        public double GetImageableHeight()
        {
            return imageableHeight;
        }

        public void SetSize(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public void SetImageableArea(double x, double y, double width, double height)
        {
            this.imageableX = x;
            this.imageableY = y;
            this.imageableWidth = width;
            this.imageableHeight = height;
        }
    }
}