using System;
using System.Text;

namespace Generated.Test
{
    public class java_util_Base64AutoTest
    {
        public void getEncoder_test_977()
        {
            Base64.GetEncoder();
        }

        public void getUrlEncoder_test_978()
        {
            Base64.GetUrlEncoder();
        }

        public void getMimeEncoder_test_979()
        {
            Base64.GetMimeEncoder();
        }

        public void getMimeEncoder_test_980(int p0, byte[] p1)
        {
            Base64.GetMimeEncoder(p0, p1);
        }

        public void getDecoder_test_981()
        {
            Base64.GetDecoder();
        }

        public void getUrlDecoder_test_982()
        {
            Base64.GetUrlDecoder();
        }

        public void getMimeDecoder_test_983()
        {
            Base64.GetMimeDecoder();
        }
    }

    public static class Base64
    {
        public static Base64Encoder GetEncoder()
        {
            return new Base64Encoder(Base64FormattingInfo.None);
        }

        public static Base64Encoder GetUrlEncoder()
        {
            return new Base64Encoder(Base64FormattingInfo.None, true);
        }

        public static Base64Encoder GetMimeEncoder()
        {
            return new Base64Encoder(Base64FormattingInfo.InsertLineBreaks);
        }

        public static Base64Encoder GetMimeEncoder(int lineLength, byte[] lineSeparator)
        {
            return new Base64Encoder(Base64FormattingInfo.InsertLineBreaks, false, lineLength, lineSeparator);
        }

        public static Base64Decoder GetDecoder()
        {
            return new Base64Decoder(false);
        }

        public static Base64Decoder GetUrlDecoder()
        {
            return new Base64Decoder(true);
        }

        public static Base64Decoder GetMimeDecoder()
        {
            return new Base64Decoder(false);
        }
    }

    public class Base64Encoder
    {
        private readonly Base64FormattingInfo _formattingInfo;
        private readonly bool _urlSafe;
        private readonly int _lineLength;
        private readonly byte[] _lineSeparator;

        internal Base64Encoder(Base64FormattingInfo formattingInfo, bool urlSafe = false, int lineLength = 76, byte[] lineSeparator = null)
        {
            _formattingInfo = formattingInfo;
            _urlSafe = urlSafe;
            _lineLength = lineLength;
            _lineSeparator = lineSeparator ?? Encoding.ASCII.GetBytes("\r\n");
        }

        public string EncodeToString(byte[] src)
        {
            string base64 = Convert.ToBase64String(src);
            if (_urlSafe)
            {
                base64 = base64.Replace('+', '-').Replace('/', '_');
            }
            if (_formattingInfo == Base64FormattingInfo.InsertLineBreaks)
            {
                var sb = new StringBuilder();
                for (int i = 0; i < base64.Length; i += _lineLength)
                {
                    if (i > 0)
                    {
                        sb.Append(Encoding.ASCII.GetString(_lineSeparator));
                    }
                    int length = Math.Min(_lineLength, base64.Length - i);
                    sb.Append(base64, i, length);
                }
                return sb.ToString();
            }
            return base64;
        }

        public byte[] Encode(byte[] src)
        {
            return Encoding.ASCII.GetBytes(EncodeToString(src));
        }
    }

    public class Base64Decoder
    {
        private readonly bool _urlSafe;

        internal Base64Decoder(bool urlSafe)
        {
            _urlSafe = urlSafe;
        }

        public byte[] Decode(string src)
        {
            if (_urlSafe)
            {
                src = src.Replace('-', '+').Replace('_', '/');
            }
            return Convert.FromBase64String(src);
        }

        public byte[] Decode(byte[] src)
        {
            return Decode(Encoding.ASCII.GetString(src));
        }
    }

    internal enum Base64FormattingInfo
    {
        None,
        InsertLineBreaks
    }
}