namespace Generated.Test
{
    public class javax_imageio_metadata_IIOMetadataFormatImplAutoTest
    {
        public void getStandardFormatInstance_test_5555()
        {
            IIOMetadataFormatImpl.GetStandardFormatInstance();
        }
    }

    public class IIOMetadataFormatImpl
    {
        public static object GetStandardFormatInstance()
        {
            return new IIOMetadataFormatImpl();
        }
    }
}