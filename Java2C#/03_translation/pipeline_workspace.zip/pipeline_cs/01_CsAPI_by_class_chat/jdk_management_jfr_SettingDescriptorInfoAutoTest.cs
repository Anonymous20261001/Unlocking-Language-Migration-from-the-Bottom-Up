namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class CompositeData
    {
        public object Get(string key)
        {
            throw new NotImplementedException();
        }

        public bool ContainsKey(string key)
        {
            throw new NotImplementedException();
        }

        public string[] GetCompositeType()
        {
            throw new NotImplementedException();
        }
    }

    public class SettingDescriptorInfo
    {
        private string name;
        private string label;
        private string description;
        private string typeName;
        private string contentType;
        private string defaultValue;

        public SettingDescriptorInfo(string name, string label, string description, string typeName, string contentType, string defaultValue)
        {
            this.name = name;
            this.label = label;
            this.description = description;
            this.typeName = typeName;
            this.contentType = contentType;
            this.defaultValue = defaultValue;
        }

        public string GetName()
        {
            return name;
        }

        public string GetLabel()
        {
            return label;
        }

        public string GetDescription()
        {
            return description;
        }

        public string GetTypeName()
        {
            return typeName;
        }

        public string GetContentType()
        {
            return contentType;
        }

        public string GetDefaultValue()
        {
            return defaultValue;
        }

        public static SettingDescriptorInfo From(CompositeData cd)
        {
            if (cd == null)
            {
                throw new ArgumentNullException(nameof(cd));
            }

            string name = (string)cd.Get("name");
            string label = (string)cd.Get("label");
            string description = (string)cd.Get("description");
            string typeName = (string)cd.Get("typeName");
            string contentType = (string)cd.Get("contentType");
            string defaultValue = (string)cd.Get("defaultValue");

            return new SettingDescriptorInfo(name, label, description, typeName, contentType, defaultValue);
        }
    }

    public class jdk_management_jfr_SettingDescriptorInfoAutoTest
    {
        public void from_test_11072(CompositeData p0)
        {
            SettingDescriptorInfo.From(p0);
        }
    }
}