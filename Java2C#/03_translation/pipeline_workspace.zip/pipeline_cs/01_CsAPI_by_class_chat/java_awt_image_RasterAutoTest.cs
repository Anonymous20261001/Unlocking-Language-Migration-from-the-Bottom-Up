using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Point class equivalent
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public Point()
        {
            X = 0;
            Y = 0;
        }
    }

    // DataBuffer class equivalent
    public class DataBuffer
    {
        public int Size { get; set; }
        public int[] Data { get; set; }

        public DataBuffer(int size)
        {
            Size = size;
            Data = new int[size];
        }

        public DataBuffer(int[] data)
        {
            Data = data;
            Size = data.Length;
        }
    }

    // SampleModel class equivalent
    public class SampleModel
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public int NumBands { get; set; }

        public SampleModel(int width, int height, int numBands)
        {
            Width = width;
            Height = height;
            NumBands = numBands;
        }
    }

    // Raster class equivalent
    public class Raster
    {
        public SampleModel SampleModel { get; set; }
        public DataBuffer DataBuffer { get; set; }
        public Point Origin { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        protected Raster(SampleModel sampleModel, Point origin)
        {
            SampleModel = sampleModel;
            Origin = origin;
            Width = sampleModel.Width;
            Height = sampleModel.Height;
        }

        protected Raster(SampleModel sampleModel, DataBuffer dataBuffer, Point origin)
        {
            SampleModel = sampleModel;
            DataBuffer = dataBuffer;
            Origin = origin;
            Width = sampleModel.Width;
            Height = sampleModel.Height;
        }

        // Static factory methods
        public static Raster CreateInterleavedRaster(int dataType, int w, int h, int bands, int scanlineStride, int[] bandOffsets, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bands);
            DataBuffer db = new DataBuffer(w * h * bands);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreateInterleavedRaster(int dataType, int w, int h, int bands, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bands);
            DataBuffer db = new DataBuffer(w * h * bands);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreateInterleavedRaster(DataBuffer dataBuffer, int w, int h, int scanlineStride, int pixelStride, int[] bandOffsets, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bandOffsets.Length);
            return new Raster(sm, dataBuffer, location ?? new Point(0, 0));
        }

        public static Raster CreatePackedRaster(int dataType, int w, int h, int[] bandMasks, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bandMasks.Length);
            DataBuffer db = new DataBuffer(w * h * bandMasks.Length);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreatePackedRaster(int dataType, int w, int h, int bands, int bitsPerBand, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bands);
            DataBuffer db = new DataBuffer(w * h * bands);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreatePackedRaster(DataBuffer dataBuffer, int w, int h, int bitsPerPixel, int[] bandMasks, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bandMasks.Length);
            return new Raster(sm, dataBuffer, location ?? new Point(0, 0));
        }

        public static Raster CreatePackedRaster(DataBuffer dataBuffer, int w, int h, int bitsPerPixel, Point location)
        {
            SampleModel sm = new SampleModel(w, h, 1);
            return new Raster(sm, dataBuffer, location ?? new Point(0, 0));
        }

        public static Raster CreateWritableRaster(SampleModel sampleModel, Point location)
        {
            DataBuffer db = new DataBuffer(sampleModel.Width * sampleModel.Height * sampleModel.NumBands);
            return new Raster(sampleModel, db, location ?? new Point(0, 0));
        }

        public static Raster CreateWritableRaster(SampleModel sampleModel, DataBuffer dataBuffer, Point location)
        {
            return new Raster(sampleModel, dataBuffer, location ?? new Point(0, 0));
        }

        public static Raster CreateBandedRaster(DataBuffer dataBuffer, int w, int h, int scanlineStride, int[] bankIndices, int[] bandOffsets, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bandOffsets.Length);
            return new Raster(sm, dataBuffer, location ?? new Point(0, 0));
        }

        public static Raster CreateBandedRaster(int dataType, int w, int h, int bands, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bands);
            DataBuffer db = new DataBuffer(w * h * bands);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreateBandedRaster(int dataType, int w, int h, int bands, int[] bankIndices, int[] bandOffsets, Point location)
        {
            SampleModel sm = new SampleModel(w, h, bands);
            DataBuffer db = new DataBuffer(w * h * bands);
            return new Raster(sm, db, location ?? new Point(0, 0));
        }

        public static Raster CreateRaster(SampleModel sampleModel, DataBuffer dataBuffer, Point location)
        {
            return new Raster(sampleModel, dataBuffer, location ?? new Point(0, 0));
        }
    }

    // Test class
    public class java_awt_image_RasterAutoTest
    {
        public void createInterleavedRaster_test_10325(int p0, int p1, int p2, int p3, int p4, int[] p5, Point p6)
        {
            Raster.CreateInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createInterleavedRaster_test_10326(int p0, int p1, int p2, int p3, Point p4)
        {
            Raster.CreateInterleavedRaster(p0, p1, p2, p3, p4);
        }

        public void createInterleavedRaster_test_10327(DataBuffer p0, int p1, int p2, int p3, int p4, int[] p5, Point p6)
        {
            Raster.CreateInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createPackedRaster_test_10328(int p0, int p1, int p2, int[] p3, Point p4)
        {
            Raster.CreatePackedRaster(p0, p1, p2, p3, p4);
        }

        public void createPackedRaster_test_10329(int p0, int p1, int p2, int p3, int p4, Point p5)
        {
            Raster.CreatePackedRaster(p0, p1, p2, p3, p4, p5);
        }

        public void createPackedRaster_test_10330(DataBuffer p0, int p1, int p2, int p3, int[] p4, Point p5)
        {
            Raster.CreatePackedRaster(p0, p1, p2, p3, p4, p5);
        }

        public void createPackedRaster_test_10331(DataBuffer p0, int p1, int p2, int p3, Point p4)
        {
            Raster.CreatePackedRaster(p0, p1, p2, p3, p4);
        }

        public void createWritableRaster_test_10332(SampleModel p0, Point p1)
        {
            Raster.CreateWritableRaster(p0, p1);
        }

        public void createWritableRaster_test_10333(SampleModel p0, DataBuffer p1, Point p2)
        {
            Raster.CreateWritableRaster(p0, p1, p2);
        }

        public void createBandedRaster_test_10334(DataBuffer p0, int p1, int p2, int p3, int[] p4, int[] p5, Point p6)
        {
            Raster.CreateBandedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createBandedRaster_test_10335(int p0, int p1, int p2, int p3, Point p4)
        {
            Raster.CreateBandedRaster(p0, p1, p2, p3, p4);
        }

        public void createBandedRaster_test_10336(int p0, int p1, int p2, int p3, int[] p4, int[] p5, Point p6)
        {
            Raster.CreateBandedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createRaster_test_10337(SampleModel p0, DataBuffer p1, Point p2)
        {
            Raster.CreateRaster(p0, p1, p2);
        }
    }
}