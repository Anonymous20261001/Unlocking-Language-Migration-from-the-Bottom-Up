namespace Generated.Test
{
    public class java_nio_DoubleBufferAutoTest
    {
        public void wrap_test_4265(double[] p0)
        {
            DoubleBuffer.Wrap(p0);
        }

        public void wrap_test_4266(double[] p0, int p1, int p2)
        {
            DoubleBuffer.Wrap(p0, p1, p2);
        }

        public void allocate_test_4267(int p0)
        {
            DoubleBuffer.Allocate(p0);
        }
    }

    public class DoubleBuffer
    {
        private double[] _buffer;
        private int _position;
        private int _limit;
        private int _offset;

        private DoubleBuffer(double[] buffer, int offset, int length)
        {
            _buffer = buffer;
            _offset = offset;
            _position = offset;
            _limit = offset + length;
        }

        public static DoubleBuffer Wrap(double[] array)
        {
            return new DoubleBuffer(array, 0, array.Length);
        }

        public static DoubleBuffer Wrap(double[] array, int offset, int length)
        {
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new ArgumentOutOfRangeException();
            return new DoubleBuffer(array, offset, length);
        }

        public static DoubleBuffer Allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentOutOfRangeException();
            return new DoubleBuffer(new double[capacity], 0, capacity);
        }

        public int Position
        {
            get { return _position - _offset; }
            set
            {
                if (value < 0 || value > Limit)
                    throw new ArgumentOutOfRangeException();
                _position = _offset + value;
            }
        }

        public int Limit
        {
            get { return _limit - _offset; }
            set
            {
                if (value < 0 || value > Capacity)
                    throw new ArgumentOutOfRangeException();
                _limit = _offset + value;
            }
        }

        public int Capacity
        {
            get { return _buffer.Length - _offset; }
        }

        public double Get()
        {
            if (_position >= _limit)
                throw new InvalidOperationException("Buffer underflow");
            return _buffer[_position++];
        }

        public double Get(int index)
        {
            if (index < 0 || index >= Limit)
                throw new ArgumentOutOfRangeException();
            return _buffer[_offset + index];
        }

        public DoubleBuffer Put(double value)
        {
            if (_position >= _limit)
                throw new InvalidOperationException("Buffer overflow");
            _buffer[_position++] = value;
            return this;
        }

        public DoubleBuffer Put(int index, double value)
        {
            if (index < 0 || index >= Limit)
                throw new ArgumentOutOfRangeException();
            _buffer[_offset + index] = value;
            return this;
        }

        public DoubleBuffer Flip()
        {
            _limit = _position;
            _position = _offset;
            return this;
        }

        public DoubleBuffer Clear()
        {
            _position = _offset;
            _limit = _offset + Capacity;
            return this;
        }

        public DoubleBuffer Rewind()
        {
            _position = _offset;
            return this;
        }

        public int Remaining
        {
            get { return _limit - _position; }
        }

        public bool HasRemaining
        {
            get { return _position < _limit; }
        }

        public double[] ToArray()
        {
            double[] result = new double[Remaining];
            for (int i = 0; i < Remaining; i++)
                result[i] = _buffer[_offset + i];
            return result;
        }
    }
}