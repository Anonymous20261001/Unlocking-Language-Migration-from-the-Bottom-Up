namespace Generated.Test
{
    using System;
    using System.Security.Cryptography;

    public class javax_xml_crypto_KeySelectorAutoTest
    {
        public void singletonKeySelector_test_7631(Key p0)
        {
            KeySelector.SingletonKeySelector(p0);
        }
    }

    public abstract class Key
    {
        public abstract string Algorithm { get; }
        public abstract string Format { get; }
        public abstract byte[] GetEncoded();
    }

    public abstract class KeySelector
    {
        public static KeySelector SingletonKeySelector(Key key)
        {
            if (key == null)
            {
                throw new ArgumentNullException(nameof(key));
            }
            return new SingletonKeySelectorImpl(key);
        }

        private class SingletonKeySelectorImpl : KeySelector
        {
            private readonly Key _key;

            public SingletonKeySelectorImpl(Key key)
            {
                _key = key;
            }

            public Key Key => _key;
        }
    }
}