using System;
using System.Xml;
using System.IO;

namespace Generated.Test
{
    public class javax_xml_stream_XMLInputFactoryAutoTest
    {
        public void newDefaultFactory_test_13634()
        {
            XMLInputFactory.NewDefaultFactory();
        }

        public void newInstance_test_13635()
        {
            XMLInputFactory.NewInstance();
        }

        public void newInstance_test_13636(string p0, ClassLoader p1)
        {
            XMLInputFactory.NewInstance(p0, p1);
        }

        public void newFactory_test_13637(string p0, ClassLoader p1)
        {
            XMLInputFactory.NewFactory(p0, p1);
        }

        public void newFactory_test_13638()
        {
            XMLInputFactory.NewFactory();
        }
    }

    public class XMLInputFactory
    {
        public static XMLInputFactory NewDefaultFactory()
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory NewInstance()
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory NewInstance(string factoryId, ClassLoader classLoader)
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory NewFactory(string factoryId, ClassLoader classLoader)
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory NewFactory()
        {
            return new XMLInputFactory();
        }
    }

    public class ClassLoader
    {
        // Placeholder class for ClassLoader
    }
}