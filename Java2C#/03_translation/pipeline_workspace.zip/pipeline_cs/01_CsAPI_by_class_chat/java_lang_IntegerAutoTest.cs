using System;
using System.Text;

namespace Generated.Test
{
    public class Integer
    {
        private int value;

        public Integer(int value)
        {
            this.value = value;
        }

        public static int numberOfLeadingZeros(int i)
        {
            if (i == 0) return 32;
            int n = 1;
            if (i >>> 16 == 0) { n += 16; i <<= 16; }
            if (i >>> 24 == 0) { n += 8; i <<= 8; }
            if (i >>> 28 == 0) { n += 4; i <<= 4; }
            if (i >>> 30 == 0) { n += 2; i <<= 2; }
            n -= i >>> 31;
            return n;
        }

        public static int numberOfTrailingZeros(int i)
        {
            if (i == 0) return 32;
            int n = 31;
            int y = i << 16; if (y != 0) { n -= 16; i = y; }
            y = i << 8; if (y != 0) { n -= 8; i = y; }
            y = i << 4; if (y != 0) { n -= 4; i = y; }
            y = i << 2; if (y != 0) { n -= 2; i = y; }
            return n - ((i << 1) >>> 31);
        }

        public static int bitCount(int i)
        {
            i = i - ((i >>> 1) & 0x55555555);
            i = (i & 0x33333333) + ((i >>> 2) & 0x33333333);
            i = (i + (i >>> 4)) & 0x0f0f0f0f;
            i = i + (i >>> 8);
            i = i + (i >>> 16);
            return i & 0x3f;
        }

        public static int min(int a, int b)
        {
            return Math.Min(a, b);
        }

        public static int max(int a, int b)
        {
            return Math.Max(a, b);
        }

        public static int signum(int i)
        {
            return (i >> 31) | (-i >>> 31);
        }

        public static int expand(int i, int mask)
        {
            int result = 0;
            int m = 0;
            for (int bit = 0; bit < 32; bit++)
            {
                if ((mask & (1 << bit)) != 0)
                {
                    if ((i & (1 << m)) != 0)
                        result |= (1 << bit);
                    m++;
                }
            }
            return result;
        }

        public static int compareUnsigned(int x, int y)
        {
            return CompareUnsigned(x, y);
        }

        private static int CompareUnsigned(int x, int y)
        {
            return (int)(((long)x & 0xFFFFFFFFL) - ((long)y & 0xFFFFFFFFL));
        }

        public static int divideUnsigned(int dividend, int divisor)
        {
            if (divisor == 0) throw new DivideByZeroException();
            return (int)(((long)dividend & 0xFFFFFFFFL) / ((long)divisor & 0xFFFFFFFFL));
        }

        public static int remainderUnsigned(int dividend, int divisor)
        {
            if (divisor == 0) throw new DivideByZeroException();
            return (int)(((long)dividend & 0xFFFFFFFFL) % ((long)divisor & 0xFFFFFFFFL));
        }

        public static int reverse(int i)
        {
            i = (i & 0x55555555) << 1 | (i >>> 1) & 0x55555555;
            i = (i & 0x33333333) << 2 | (i >>> 2) & 0x33333333;
            i = (i & 0x0f0f0f0f) << 4 | (i >>> 4) & 0x0f0f0f0f;
            i = (i << 24) | ((i & 0xff00) << 8) | ((i >>> 8) & 0xff00) | (i >>> 24);
            return i;
        }

        public static int reverseBytes(int i)
        {
            return (int)(((uint)i & 0x000000FF) << 24 | ((uint)i & 0x0000FF00) << 8 | ((uint)i & 0x00FF0000) >> 8 | ((uint)i & 0xFF000000) >> 24);
        }

        public static int compress(int i, int mask)
        {
            int result = 0;
            int m = 0;
            for (int bit = 0; bit < 32; bit++)
            {
                if ((mask & (1 << bit)) != 0)
                {
                    if ((i & (1 << bit)) != 0)
                        result |= (1 << m);
                    m++;
                }
            }
            return result;
        }

        public int compareTo(Integer anotherInteger)
        {
            return Compare(this.value, anotherInteger.value);
        }

        public static int compare(int x, int y)
        {
            return (x < y) ? -1 : ((x == y) ? 0 : 1);
        }

        public byte byteValue()
        {
            return (byte)value;
        }

        public short shortValue()
        {
            return (short)value;
        }

        public int intValue()
        {
            return value;
        }

        public long longValue()
        {
            return value;
        }

        public float floatValue()
        {
            return value;
        }

        public double doubleValue()
        {
            return value;
        }

        public static Integer valueOf(string s)
        {
            return new Integer(ParseInt(s));
        }

        public static Integer valueOf(int i)
        {
            return new Integer(i);
        }

        public static Integer valueOf(string s, int radix)
        {
            return new Integer(ParseInt(s, radix));
        }

        public static string toHexString(int i)
        {
            return Convert.ToString(i, 16);
        }

        public static Integer decode(string nm)
        {
            int radix = 10;
            int index = 0;
            bool negative = false;
            if (nm.Length > 0 && nm[0] == '-')
            {
                negative = true;
                index++;
            }
            if (nm.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || nm.StartsWith("#"))
            {
                index += (nm[index] == 'x' || nm[index] == 'X') ? 2 : 1;
                radix = 16;
            }
            else if (nm.StartsWith("0", StringComparison.Ordinal) && nm.Length > 1)
            {
                index++;
                radix = 8;
            }
            string sub = nm.Substring(index);
            int result = ParseInt(sub, radix);
            return new Integer(negative ? -result : result);
        }

        public object resolveConstantDesc(object lookup)
        {
            return this;
        }

        public object describeConstable()
        {
            return this;
        }

        public static int parseInt(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            if (s == null) throw new ArgumentNullException("s");
            if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
            if (beginIndex < 0 || endIndex > s.Length || beginIndex > endIndex) throw new IndexOutOfRangeException();
            int result = 0;
            bool negative = false;
            int i = beginIndex;
            if (i < endIndex && s[i] == '-')
            {
                negative = true;
                i++;
            }
            if (i >= endIndex) throw new FormatException("Empty string");
            while (i < endIndex)
            {
                int digit = CharToDigit(s[i]);
                if (digit < 0 || digit >= radix) throw new FormatException("Invalid digit");
                result = result * radix + digit;
                i++;
            }
            return negative ? -result : result;
        }

        public static int parseInt(string s)
        {
            return ParseInt(s, 10);
        }

        public static int parseInt(string s, int radix)
        {
            return ParseInt(s, radix);
        }

        private static int ParseInt(string s, int radix)
        {
            if (s == null) throw new ArgumentNullException("s");
            if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
            int result = 0;
            bool negative = false;
            int i = 0;
            if (s.Length > 0 && s[0] == '-')
            {
                negative = true;
                i++;
            }
            if (i >= s.Length) throw new FormatException("Empty string");
            while (i < s.Length)
            {
                int digit = CharToDigit(s[i]);
                if (digit < 0 || digit >= radix) throw new FormatException("Invalid digit");
                result = result * radix + digit;
                i++;
            }
            return negative ? -result : result;
        }

        private static int CharToDigit(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'z') return c - 'a' + 10;
            if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
            return -1;
        }

        public static long toUnsignedLong(int x)
        {
            return (long)x & 0xFFFFFFFFL;
        }

        public static int sum(int a, int b)
        {
            return a + b;
        }

        public static string toUnsignedString(int i)
        {
            return ToUnsignedString(i, 10);
        }

        public static string toUnsignedString(int i, int radix)
        {
            return ToUnsignedString(i, radix);
        }

        private static string ToUnsignedString(int i, int radix)
        {
            if (radix < 2 || radix > 36) radix = 10;
            long value = (long)i & 0xFFFFFFFFL;
            if (value == 0) return "0";
            StringBuilder sb = new StringBuilder();
            while (value > 0)
            {
                int digit = (int)(value % radix);
                sb.Insert(0, DigitToChar(digit));
                value /= radix;
            }
            return sb.ToString();
        }

        private static char DigitToChar(int digit)
        {
            if (digit < 10) return (char)('0' + digit);
            return (char)('a' + digit - 10);
        }

        public static int parseUnsignedInt(string s, int radix)
        {
            return ParseUnsignedInt(s, radix);
        }

        public static int parseUnsignedInt(string s)
        {
            return ParseUnsignedInt(s, 10);
        }

        public static int parseUnsignedInt(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            if (s == null) throw new ArgumentNullException("s");
            if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
            if (beginIndex < 0 || endIndex > s.Length || beginIndex > endIndex) throw new IndexOutOfRangeException();
            long result = 0;
            for (int i = beginIndex; i < endIndex; i++)
            {
                int digit = CharToDigit(s[i]);
                if (digit < 0 || digit >= radix) throw new FormatException("Invalid digit");
                result = result * radix + digit;
                if (result > 0xFFFFFFFFL) throw new OverflowException();
            }
            return (int)result;
        }

        private static int ParseUnsignedInt(string s, int radix)
        {
            if (s == null) throw new ArgumentNullException("s");
            if (radix < 2 || radix > 36) throw new FormatException("Invalid radix");
            long result = 0;
            for (int i = 0; i < s.Length; i++)
            {
                int digit = CharToDigit(s[i]);
                if (digit < 0 || digit >= radix) throw new FormatException("Invalid digit");
                result = result * radix + digit;
                if (result > 0xFFFFFFFFL) throw new OverflowException();
            }
            return (int)result;
        }

        public static Integer getInteger(string nm, Integer val)
        {
            string v = Environment.GetEnvironmentVariable(nm);
            if (v == null) return val;
            try { return valueOf(v); }
            catch { return val; }
        }

        public static Integer getInteger(string nm)
        {
            return getInteger(nm, null);
        }

        public static Integer getInteger(string nm, int val)
        {
            return getInteger(nm, new Integer(val));
        }

        public static string toOctalString(int i)
        {
            return Convert.ToString(i, 8);
        }

        public static string toBinaryString(int i)
        {
            return Convert.ToString(i, 2);
        }

        public static int highestOneBit(int i)
        {
            i |= (i >> 1);
            i |= (i >> 2);
            i |= (i >> 4);
            i |= (i >> 8);
            i |= (i >> 16);
            return i - (i >> 1);
        }

        public static int lowestOneBit(int i)
        {
            return i & -i;
        }

        public static int rotateLeft(int i, int distance)
        {
            return (int)(((uint)i << distance) | ((uint)i >> (32 - distance)));
        }

        public static int rotateRight(int i, int distance)
        {
            return (int)(((uint)i >> distance) | ((uint)i << (32 - distance)));
        }
    }

    public class CharSequence
    {
        private string str;

        public CharSequence(string s)
        {
            str = s;
        }

        public int Length { get { return str.Length; } }

        public char this[int index] { get { return str[index]; } }
    }

    public class MethodHandles
    {
        public class Lookup
        {
        }
    }

    public class java_lang_IntegerAutoTest
    {
        public void numberOfLeadingZeros_test_5867(int p0)
        {
            Integer.numberOfLeadingZeros(p0);
        }

        public void numberOfTrailingZeros_test_5868(int p0)
        {
            Integer.numberOfTrailingZeros(p0);
        }

        public void bitCount_test_5869(int p0)
        {
            Integer.bitCount(p0);
        }

        public void min_test_5870(int p0, int p1)
        {
            Integer.min(p0, p1);
        }

        public void max_test_5871(int p0, int p1)
        {
            Integer.max(p0, p1);
        }

        public void signum_test_5872(int p0)
        {
            Integer.signum(p0);
        }

        public void expand_test_5873(int p0, int p1)
        {
            Integer.expand(p0, p1);
        }

        public void compareUnsigned_test_5874(int p0, int p1)
        {
            Integer.compareUnsigned(p0, p1);
        }

        public void divideUnsigned_test_5875(int p0, int p1)
        {
            Integer.divideUnsigned(p0, p1);
        }

        public void remainderUnsigned_test_5876(int p0, int p1)
        {
            Integer.remainderUnsigned(p0, p1);
        }

        public void reverse_test_5877(int p0)
        {
            Integer.reverse(p0);
        }

        public void reverseBytes_test_5878(int p0)
        {
            Integer.reverseBytes(p0);
        }

        public void compress_test_5879(int p0, int p1)
        {
            Integer.compress(p0, p1);
        }

        public void compareTo_test_5880(Integer p0, int c0)
        {
            Integer instance = new Integer(c0);
            instance.compareTo(p0);
        }

        public void compare_test_5881(int p0, int p1)
        {
            Integer.compare(p0, p1);
        }

        public void byteValue_test_5882(int c0)
        {
            Integer instance = new Integer(c0);
            instance.byteValue();
        }

        public void shortValue_test_5883(int c0)
        {
            Integer instance = new Integer(c0);
            instance.shortValue();
        }

        public void intValue_test_5884(int c0)
        {
            Integer instance = new Integer(c0);
            instance.intValue();
        }

        public void longValue_test_5885(int c0)
        {
            Integer instance = new Integer(c0);
            instance.longValue();
        }

        public void floatValue_test_5886(int c0)
        {
            Integer instance = new Integer(c0);
            instance.floatValue();
        }

        public void doubleValue_test_5887(int c0)
        {
            Integer instance = new Integer(c0);
            instance.doubleValue();
        }

        public void valueOf_test_5888(string p0)
        {
            Integer.valueOf(p0);
        }

        public void valueOf_test_5889(int p0)
        {
            Integer.valueOf(p0);
        }

        public void valueOf_test_5890(string p0, int p1)
        {
            Integer.valueOf(p0, p1);
        }

        public void toHexString_test_5891(int p0)
        {
            Integer.toHexString(p0);
        }

        public void decode_test_5892(string p0)
        {
            Integer.decode(p0);
        }

        public void resolveConstantDesc_test_5893(MethodHandles.Lookup p0, int c0)
        {
            Integer instance = new Integer(c0);
            instance.resolveConstantDesc(p0);
        }

        public void describeConstable_test_5894(int c0)
        {
            Integer instance = new Integer(c0);
            instance.describeConstable();
        }

        public void parseInt_test_5895(CharSequence p0, int p1, int p2, int p3)
        {
            Integer.parseInt(p0, p1, p2, p3);
        }

        public void parseInt_test_5896(string p0)
        {
            Integer.parseInt(p0);
        }

        public void parseInt_test_5897(string p0, int p1)
        {
            Integer.parseInt(p0, p1);
        }

        public void toUnsignedLong_test_5898(int p0)
        {
            Integer.toUnsignedLong(p0);
        }

        public void sum_test_5899(int p0, int p1)
        {
            Integer.sum(p0, p1);
        }

        public void toUnsignedString_test_5900(int p0)
        {
            Integer.toUnsignedString(p0);
        }

        public void toUnsignedString_test_5901(int p0, int p1)
        {
            Integer.toUnsignedString(p0, p1);
        }

        public void parseUnsignedInt_test_5902(string p0, int p1)
        {
            Integer.parseUnsignedInt(p0, p1);
        }

        public void parseUnsignedInt_test_5903(string p0)
        {
            Integer.parseUnsignedInt(p0);
        }

        public void parseUnsignedInt_test_5904(CharSequence p0, int p1, int p2, int p3)
        {
            Integer.parseUnsignedInt(p0, p1, p2, p3);
        }

        public void getInteger_test_5905(string p0, Integer p1)
        {
            Integer.getInteger(p0, p1);
        }

        public void getInteger_test_5906(string p0)
        {
            Integer.getInteger(p0);
        }

        public void getInteger_test_5907(string p0, int p1)
        {
            Integer.getInteger(p0, p1);
        }

        public void toOctalString_test_5908(int p0)
        {
            Integer.toOctalString(p0);
        }

        public void toBinaryString_test_5909(int p0)
        {
            Integer.toBinaryString(p0);
        }

        public void highestOneBit_test_5910(int p0)
        {
            Integer.highestOneBit(p0);
        }

        public void lowestOneBit_test_5911(int p0)
        {
            Integer.lowestOneBit(p0);
        }

        public void rotateLeft_test_5912(int p0, int p1)
        {
            Integer.rotateLeft(p0, p1);
        }

        public void rotateRight_test_5913(int p0, int p1)
        {
            Integer.rotateRight(p0, p1);
        }
    }
}