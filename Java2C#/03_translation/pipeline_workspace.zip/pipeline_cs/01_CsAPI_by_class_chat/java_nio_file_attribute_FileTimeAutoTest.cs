namespace Generated.Test
{
    using System;

    public class FileTime
    {
        private readonly long _millis;

        private FileTime(long millis)
        {
            _millis = millis;
        }

        public static FileTime From(DateTime instant)
        {
            long millis = (instant.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).Ticks / TimeSpan.TicksPerMillisecond;
            return new FileTime(millis);
        }

        public static FileTime From(long value, TimeUnit unit)
        {
            long millis;
            switch (unit)
            {
                case TimeUnit.Nanoseconds:
                    millis = value / 1000000;
                    break;
                case TimeUnit.Microseconds:
                    millis = value / 1000;
                    break;
                case TimeUnit.Milliseconds:
                    millis = value;
                    break;
                case TimeUnit.Seconds:
                    millis = value * 1000;
                    break;
                case TimeUnit.Minutes:
                    millis = value * 60 * 1000;
                    break;
                case TimeUnit.Hours:
                    millis = value * 60 * 60 * 1000;
                    break;
                case TimeUnit.Days:
                    millis = value * 24 * 60 * 60 * 1000;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(unit));
            }
            return new FileTime(millis);
        }

        public static FileTime FromMillis(long millis)
        {
            return new FileTime(millis);
        }
    }

    public enum TimeUnit
    {
        Nanoseconds,
        Microseconds,
        Milliseconds,
        Seconds,
        Minutes,
        Hours,
        Days
    }

    public class java_nio_file_attribute_FileTimeAutoTest
    {
        public void from_test_4782(DateTime p0)
        {
            FileTime.From(p0);
        }

        public void from_test_4783(long p0, TimeUnit p1)
        {
            FileTime.From(p0, p1);
        }

        public void fromMillis_test_4784(long p0)
        {
            FileTime.FromMillis(p0);
        }
    }
}