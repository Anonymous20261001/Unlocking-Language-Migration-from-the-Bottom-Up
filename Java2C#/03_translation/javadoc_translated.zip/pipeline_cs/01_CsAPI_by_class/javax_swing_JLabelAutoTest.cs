namespace Generated.Test
{
    public interface Icon { }
    public class LabelUI { }
    public class Image { }
    public class Component
    {
        public bool imageUpdate(Image p0, int p1, int p2, int p3, int p4, int p5)
        {
            return false;
        }
    }
    public class AccessibleContext { }

    public class JLabel : Component
    {
        private int displayedMnemonic;
        private Component labelFor;
        private LabelUI ui;
        private string text;
        private Icon icon;
        private Icon disabledIcon;
        private int iconTextGap;
        private int verticalAlignment;
        private int horizontalAlignment;
        private int verticalTextPosition;
        private int horizontalTextPosition;
        private int displayedMnemonicIndex;

        public JLabel()
        {
        }

        public int getDisplayedMnemonic()
        {
            return displayedMnemonic;
        }

        public void setDisplayedMnemonic(int p0)
        {
            displayedMnemonic = p0;
        }

        public void setDisplayedMnemonic(char p0)
        {
            displayedMnemonic = (int)p0;
        }

        public Component getLabelFor()
        {
            return labelFor;
        }

        public void setLabelFor(Component p0)
        {
            labelFor = p0;
        }

        public string getUIClassID()
        {
            return "LabelUI";
        }

        public void updateUI()
        {
            ui = new LabelUI();
        }

        public LabelUI getUI()
        {
            return ui;
        }

        public void setUI(LabelUI p0)
        {
            ui = p0;
        }

        public AccessibleContext getAccessibleContext()
        {
            return new AccessibleContext();
        }

        public Icon getIcon()
        {
            return icon;
        }

        public Icon getDisabledIcon()
        {
            return disabledIcon;
        }

        public void setDisplayedMnemonicIndex(int p0)
        {
            displayedMnemonicIndex = p0;
        }

        public void setText(string p0)
        {
            text = p0;
        }

        public void setIcon(Icon p0)
        {
            icon = p0;
        }

        public void setDisabledIcon(Icon p0)
        {
            disabledIcon = p0;
        }

        public void setIconTextGap(int p0)
        {
            iconTextGap = p0;
        }

        public int getVerticalAlignment()
        {
            return verticalAlignment;
        }

        public void setVerticalAlignment(int p0)
        {
            verticalAlignment = p0;
        }

        public int getHorizontalAlignment()
        {
            return horizontalAlignment;
        }

        public void setHorizontalAlignment(int p0)
        {
            horizontalAlignment = p0;
        }

        public int getVerticalTextPosition()
        {
            return verticalTextPosition;
        }

        public void setVerticalTextPosition(int p0)
        {
            verticalTextPosition = p0;
        }

        public int getHorizontalTextPosition()
        {
            return horizontalTextPosition;
        }

        public void setHorizontalTextPosition(int p0)
        {
            horizontalTextPosition = p0;
        }

        public int getIconTextGap()
        {
            return iconTextGap;
        }

        public int getDisplayedMnemonicIndex()
        {
            return displayedMnemonicIndex;
        }

        public string getText()
        {
            return text;
        }
    }

    public class javax_swing_JLabelAutoTest
    {
        public void getDisplayedMnemonic_test_6349()
        {
            JLabel instance = new JLabel();
            instance.getDisplayedMnemonic();
        }

        public void setDisplayedMnemonic_test_6350(int p0)
        {
            JLabel instance = new JLabel();
            instance.setDisplayedMnemonic(p0);
        }

        public void setDisplayedMnemonic_test_6351(char p0)
        {
            JLabel instance = new JLabel();
            instance.setDisplayedMnemonic(p0);
        }

        public void getLabelFor_test_6352()
        {
            JLabel instance = new JLabel();
            instance.getLabelFor();
        }

        public void setLabelFor_test_6353(Component p0)
        {
            JLabel instance = new JLabel();
            instance.setLabelFor(p0);
        }

        public void getUIClassID_test_6354()
        {
            JLabel instance = new JLabel();
            instance.getUIClassID();
        }

        public void updateUI_test_6355()
        {
            JLabel instance = new JLabel();
            instance.updateUI();
        }

        public void getUI_test_6356()
        {
            JLabel instance = new JLabel();
            instance.getUI();
        }

        public void setUI_test_6357(LabelUI p0)
        {
            JLabel instance = new JLabel();
            instance.setUI(p0);
        }

        public void getAccessibleContext_test_6358()
        {
            JLabel instance = new JLabel();
            instance.getAccessibleContext();
        }

        public void imageUpdate_test_6359(Image p0, int p1, int p2, int p3, int p4, int p5)
        {
            JLabel instance = new JLabel();
            instance.imageUpdate(p0, p1, p2, p3, p4, p5);
        }

        public void getIcon_test_6360()
        {
            JLabel instance = new JLabel();
            instance.getIcon();
        }

        public void getDisabledIcon_test_6361()
        {
            JLabel instance = new JLabel();
            instance.getDisabledIcon();
        }

        public void setDisplayedMnemonicIndex_test_6362(int p0)
        {
            JLabel instance = new JLabel();
            instance.setDisplayedMnemonicIndex(p0);
        }

        public void setText_test_6363(string p0)
        {
            JLabel instance = new JLabel();
            instance.setText(p0);
        }

        public void setIcon_test_6364(Icon p0)
        {
            JLabel instance = new JLabel();
            instance.setIcon(p0);
        }

        public void setDisabledIcon_test_6365(Icon p0)
        {
            JLabel instance = new JLabel();
            instance.setDisabledIcon(p0);
        }

        public void setIconTextGap_test_6366(int p0)
        {
            JLabel instance = new JLabel();
            instance.setIconTextGap(p0);
        }

        public void getVerticalAlignment_test_6367()
        {
            JLabel instance = new JLabel();
            instance.getVerticalAlignment();
        }

        public void setVerticalAlignment_test_6368(int p0)
        {
            JLabel instance = new JLabel();
            instance.setVerticalAlignment(p0);
        }

        public void getHorizontalAlignment_test_6369()
        {
            JLabel instance = new JLabel();
            instance.getHorizontalAlignment();
        }

        public void setHorizontalAlignment_test_6370(int p0)
        {
            JLabel instance = new JLabel();
            instance.setHorizontalAlignment(p0);
        }

        public void getVerticalTextPosition_test_6371()
        {
            JLabel instance = new JLabel();
            instance.getVerticalTextPosition();
        }

        public void setVerticalTextPosition_test_6372(int p0)
        {
            JLabel instance = new JLabel();
            instance.setVerticalTextPosition(p0);
        }

        public void getHorizontalTextPosition_test_6373()
        {
            JLabel instance = new JLabel();
            instance.getHorizontalTextPosition();
        }

        public void setHorizontalTextPosition_test_6374(int p0)
        {
            JLabel instance = new JLabel();
            instance.setHorizontalTextPosition(p0);
        }

        public void getIconTextGap_test_6375()
        {
            JLabel instance = new JLabel();
            instance.getIconTextGap();
        }

        public void getDisplayedMnemonicIndex_test_6376()
        {
            JLabel instance = new JLabel();
            instance.getDisplayedMnemonicIndex();
        }

        public void getText_test_6377()
        {
            JLabel instance = new JLabel();
            instance.getText();
        }
    }
}