namespace Generated.Test
{
    public class javax_xml_parsers_SAXParserFactoryAutoTest
    {
        public void newDefaultInstance_test_10762()
        {
            SAXParserFactory.NewDefaultInstance();
        }

        public void newDefaultNSInstance_test_10763()
        {
            SAXParserFactory.NewDefaultNSInstance();
        }

        public void newNSInstance_test_10764()
        {
            SAXParserFactory.NewNSInstance();
        }

        public void newNSInstance_test_10765(string p0, ClassLoader p1)
        {
            SAXParserFactory.NewNSInstance(p0, p1);
        }

        public void newInstance_test_10766(string p0, ClassLoader p1)
        {
            SAXParserFactory.NewInstance(p0, p1);
        }

        public void newInstance_test_10767()
        {
            SAXParserFactory.NewInstance();
        }
    }

    public class SAXParserFactory
    {
        public static SAXParserFactory NewDefaultInstance()
        {
            return new SAXParserFactory();
        }

        public static SAXParserFactory NewDefaultNSInstance()
        {
            return new SAXParserFactory();
        }

        public static SAXParserFactory NewNSInstance()
        {
            return new SAXParserFactory();
        }

        public static SAXParserFactory NewNSInstance(string factoryClassName, ClassLoader classLoader)
        {
            return new SAXParserFactory();
        }

        public static SAXParserFactory NewInstance(string factoryClassName, ClassLoader classLoader)
        {
            return new SAXParserFactory();
        }

        public static SAXParserFactory NewInstance()
        {
            return new SAXParserFactory();
        }
    }

    public class ClassLoader
    {
    }
}