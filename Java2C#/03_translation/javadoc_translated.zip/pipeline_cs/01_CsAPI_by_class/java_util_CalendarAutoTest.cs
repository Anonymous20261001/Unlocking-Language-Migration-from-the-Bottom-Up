using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Locale
    {
        private readonly string language;
        private readonly string country;
        private readonly string variant;

        public Locale(string language)
            : this(language, "", "")
        {
        }

        public Locale(string language, string country)
            : this(language, country, "")
        {
        }

        public Locale(string language, string country, string variant)
        {
            this.language = language ?? "";
            this.country = country ?? "";
            this.variant = variant ?? "";
        }

        public static Locale getDefault()
        {
            string name = System.Globalization.CultureInfo.CurrentCulture.Name;
            if (string.IsNullOrEmpty(name))
                return new Locale("en");

            string[] parts = name.Split('-');
            if (parts.Length >= 2)
                return new Locale(parts[0], parts[1]);

            return new Locale(parts[0]);
        }

        public string getLanguage()
        {
            return language;
        }

        public string getCountry()
        {
            return country;
        }

        public string getVariant()
        {
            return variant;
        }

        public override string ToString()
        {
            return language + "_" + country + "_" + variant;
        }
    }

    public class TimeZone
    {
        private readonly string id;

        public TimeZone(string id)
        {
            this.id = id ?? "";
        }

        public static TimeZone getDefault()
        {
            return new TimeZone(System.TimeZoneInfo.Local.Id);
        }

        public string getID()
        {
            return id;
        }
    }

    public class Set<T> : HashSet<T>
    {
        public Set()
        {
        }

        public Set(IEnumerable<T> collection)
            : base(collection)
        {
        }
    }

    public class Calendar
    {
        private readonly TimeZone timeZone;
        private readonly Locale locale;

        private Calendar(TimeZone timeZone, Locale locale)
        {
            this.timeZone = timeZone ?? TimeZone.getDefault();
            this.locale = locale ?? Locale.getDefault();
        }

        public static Calendar getInstance()
        {
            return new Calendar(TimeZone.getDefault(), Locale.getDefault());
        }

        public static Calendar getInstance(Locale p0)
        {
            return new Calendar(TimeZone.getDefault(), p0);
        }

        public static Calendar getInstance(TimeZone p0)
        {
            return new Calendar(p0, Locale.getDefault());
        }

        public static Calendar getInstance(TimeZone p0, Locale p1)
        {
            return new Calendar(p0, p1);
        }

        public static Locale[] getAvailableLocales()
        {
            return new Locale[]
            {
                new Locale("en"),
                new Locale("en", "US"),
                new Locale("fr", "FR"),
                new Locale("de", "DE"),
                new Locale("ja", "JP"),
                new Locale("zh", "CN")
            };
        }

        public static Set<string> getAvailableCalendarTypes()
        {
            Set<string> types = new Set<string>();
            types.Add("gregory");
            types.Add("buddhist");
            types.Add("japanese");
            types.Add("islamic");
            types.Add("hebrew");
            types.Add("indian");
            types.Add("roc");
            return types;
        }

        public TimeZone getTimeZone()
        {
            return timeZone;
        }

        public Locale getLocale()
        {
            return locale;
        }
    }

    public class java_util_CalendarAutoTest
    {
        public void getInstance_test_2021()
        {
            Calendar.getInstance();
        }

        public void getInstance_test_2022(Locale p0)
        {
            Calendar.getInstance(p0);
        }

        public void getInstance_test_2023(TimeZone p0)
        {
            Calendar.getInstance(p0);
        }

        public void getInstance_test_2024(TimeZone p0, Locale p1)
        {
            Calendar.getInstance(p0, p1);
        }

        public void getAvailableLocales_test_2025()
        {
            Calendar.getAvailableLocales();
        }

        public void getAvailableCalendarTypes_test_2026()
        {
            Calendar.getAvailableCalendarTypes();
        }
    }
}