using System;

namespace Generated.Test
{
    public interface FlightRecorderListener
    {
    }

    public class FlightRecorder
    {
        private static readonly FlightRecorder instance = new FlightRecorder();

        private FlightRecorder()
        {
        }

        public static void addListener(FlightRecorderListener listener)
        {
        }

        public static void removeListener(FlightRecorderListener listener)
        {
        }

        public static bool isAvailable()
        {
            return true;
        }

        public static FlightRecorder getFlightRecorder()
        {
            return instance;
        }

        public static void addPeriodicEvent(Type eventClass, Action runnable)
        {
        }

        public static void removePeriodicEvent(Action runnable)
        {
        }

        public static void register(Type eventClass)
        {
        }

        public static void unregister(Type eventClass)
        {
        }

        public static bool isInitialized()
        {
            return true;
        }
    }

    public class jdk_jfr_FlightRecorderAutoTest
    {
        public void addListener_test_4816(FlightRecorderListener p0)
        {
            FlightRecorder.addListener(p0);
        }

        public void removeListener_test_4817(FlightRecorderListener p0)
        {
            FlightRecorder.removeListener(p0);
        }

        public void isAvailable_test_4818()
        {
            FlightRecorder.isAvailable();
        }

        public void getFlightRecorder_test_4819()
        {
            FlightRecorder.getFlightRecorder();
        }

        public void addPeriodicEvent_test_4820(Type p0, Action p1)
        {
            FlightRecorder.addPeriodicEvent(p0, p1);
        }

        public void removePeriodicEvent_test_4821(Action p0)
        {
            FlightRecorder.removePeriodicEvent(p0);
        }

        public void register_test_4822(Type p0)
        {
            FlightRecorder.register(p0);
        }

        public void unregister_test_4823(Type p0)
        {
            FlightRecorder.unregister(p0);
        }

        public void isInitialized_test_4824()
        {
            FlightRecorder.isInitialized();
        }
    }
}