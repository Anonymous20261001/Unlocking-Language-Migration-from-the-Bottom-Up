namespace Generated.Test
{
    using System;

    public class Provider
    {
        public string Name { get; set; }
        public double Version { get; set; }
        public string Info { get; set; }

        public Provider()
        {
        }

        public Provider(string name, double version, string info)
        {
            Name = name;
            Version = version;
            Info = info;
        }
    }

    public class KeyInfoFactory
    {
        public string MechanismType { get; set; }
        public Provider Provider { get; set; }

        protected KeyInfoFactory()
        {
        }

        public static KeyInfoFactory getInstance()
        {
            return new KeyInfoFactory();
        }

        public static KeyInfoFactory getInstance(string mechanismType)
        {
            return new KeyInfoFactory() { MechanismType = mechanismType };
        }

        public static KeyInfoFactory getInstance(string mechanismType, Provider provider)
        {
            if (provider == null)
                throw new ArgumentNullException(nameof(provider));

            return new KeyInfoFactory()
            {
                MechanismType = mechanismType,
                Provider = provider
            };
        }
    }

    public class javax_xml_crypto_dsig_keyinfo_KeyInfoFactoryAutoTest
    {
        public void getInstance_test_7625()
        {
            KeyInfoFactory.getInstance();
        }

        public void getInstance_test_7626(string p0, Provider p1)
        {
            KeyInfoFactory.getInstance(p0, p1);
        }

        public void getInstance_test_7627(string p0)
        {
            KeyInfoFactory.getInstance(p0);
        }
    }
}