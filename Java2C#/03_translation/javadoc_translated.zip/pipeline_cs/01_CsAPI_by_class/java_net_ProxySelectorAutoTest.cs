namespace Generated.Test
{
    public class InetSocketAddress
    {
        private readonly string host;
        private readonly int port;

        public InetSocketAddress(string host, int port)
        {
            this.host = host;
            this.port = port;
        }

        public InetSocketAddress(int port)
        {
            this.host = null;
            this.port = port;
        }

        public string Host
        {
            get { return host; }
        }

        public int Port
        {
            get { return port; }
        }
    }

    public abstract class ProxySelector
    {
        private static ProxySelector defaultSelector = null;

        public static ProxySelector of(InetSocketAddress address)
        {
            return new StaticProxySelector(address);
        }

        public static ProxySelector getDefault()
        {
            return defaultSelector;
        }

        public static void setDefault(ProxySelector selector)
        {
            defaultSelector = selector;
        }

        private class StaticProxySelector : ProxySelector
        {
            private readonly InetSocketAddress address;

            public StaticProxySelector(InetSocketAddress address)
            {
                this.address = address;
            }
        }
    }

    public class java_net_ProxySelectorAutoTest
    {
        public void of_test_10219(InetSocketAddress p0)
        {
            ProxySelector.of(p0);
        }

        public void getDefault_test_10220()
        {
            ProxySelector.getDefault();
        }

        public void setDefault_test_10221(ProxySelector p0)
        {
            ProxySelector.setDefault(p0);
        }
    }
}