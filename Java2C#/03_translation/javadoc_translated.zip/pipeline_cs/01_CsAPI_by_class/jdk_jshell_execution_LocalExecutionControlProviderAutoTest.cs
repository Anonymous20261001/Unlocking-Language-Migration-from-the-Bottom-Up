using System.Collections.Generic;
using System.IO;

namespace Generated.Test
{
    public interface ExecutionEnv
    {
        object userProcess();
        Stream input();
        void closeStreams();
    }

    public interface ExecutionControl
    {
    }

    public class LocalExecutionControl : ExecutionControl
    {
    }

    public interface ExecutionControlProvider
    {
        string name();
        ExecutionControl generate(ExecutionEnv env, IDictionary<string, string> parameters);
        IDictionary<string, string> defaultParameters();
    }

    public class LocalExecutionControlProvider : ExecutionControlProvider
    {
        public string name()
        {
            return "local";
        }

        public ExecutionControl generate(ExecutionEnv env, IDictionary<string, string> parameters)
        {
            return createExecutionControl(env, parameters);
        }

        public IDictionary<string, string> defaultParameters()
        {
            return new Dictionary<string, string>();
        }

        public ExecutionControl createExecutionControl(ExecutionEnv env, IDictionary<string, string> parameters)
        {
            return new LocalExecutionControl();
        }
    }

    public class jdk_jshell_execution_LocalExecutionControlProviderAutoTest
    {
        public void name_test_8076()
        {
            LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
            instance.name();
        }

        public void generate_test_8077(ExecutionEnv p0, IDictionary<string, string> p1)
        {
            LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
            instance.generate(p0, p1);
        }

        public void defaultParameters_test_8078()
        {
            LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
            instance.defaultParameters();
        }

        public void createExecutionControl_test_8079(ExecutionEnv p0, IDictionary<string, string> p1)
        {
            LocalExecutionControlProvider instance = new LocalExecutionControlProvider();
            instance.createExecutionControl(p0, p1);
        }
    }
}