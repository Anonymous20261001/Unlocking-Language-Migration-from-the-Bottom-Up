namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_BaselineTIFFTagSetAutoTest
    {
        public void getInstance_test_984()
        {
            BaselineTIFFTagSet.getInstance();
        }
    }

    public class BaselineTIFFTagSet
    {
        private static readonly BaselineTIFFTagSet instance = new BaselineTIFFTagSet();

        private BaselineTIFFTagSet()
        {
        }

        public static BaselineTIFFTagSet getInstance()
        {
            return instance;
        }
    }
}