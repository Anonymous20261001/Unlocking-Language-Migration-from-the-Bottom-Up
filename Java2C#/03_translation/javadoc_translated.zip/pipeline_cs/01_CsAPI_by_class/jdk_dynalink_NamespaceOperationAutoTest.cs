namespace Generated.Test
{
    public interface Operation
    {
    }

    public interface Namespace : Operation
    {
    }

    public sealed class NamespaceOperation : Operation
    {
        private readonly Operation baseOperation;
        private readonly Namespace[] namespaces;

        public NamespaceOperation(Operation baseOperation, params Namespace[] namespaces)
        {
            this.baseOperation = baseOperation;
            this.namespaces = (Namespace[])namespaces.Clone();
        }

        public Operation getBaseOperation()
        {
            return baseOperation;
        }

        public int getNamespaceCount()
        {
            return namespaces.Length;
        }

        public Namespace getNamespace(int i)
        {
            return namespaces[i];
        }

        public Namespace[] getNamespaces()
        {
            return (Namespace[])namespaces.Clone();
        }

        public bool contains(Namespace ns)
        {
            foreach (Namespace n in namespaces)
            {
                if (object.Equals(n, ns))
                {
                    return true;
                }
            }
            return false;
        }

        public static Operation getBaseOperation(Operation op)
        {
            if (op is NamespaceOperation)
            {
                return ((NamespaceOperation)op).baseOperation;
            }
            return op;
        }

        public static Namespace[] getNamespaces(Operation op)
        {
            if (op is NamespaceOperation)
            {
                return ((NamespaceOperation)op).getNamespaces();
            }
            return null;
        }

        public static bool contains(Operation op, Operation baseOperation, Namespace ns)
        {
            if (op is NamespaceOperation)
            {
                NamespaceOperation nop = (NamespaceOperation)op;
                return object.Equals(nop.baseOperation, baseOperation) && nop.contains(ns);
            }
            return false;
        }
    }

    public class jdk_dynalink_NamespaceOperationAutoTest
    {
        public void contains_test_9483(Operation p0, Operation p1, Namespace p2)
        {
            NamespaceOperation.contains(p0, p1, p2);
        }

        public void contains_test_9484(Namespace p0, Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.contains(p0);
        }

        public void getNamespace_test_9485(int p0, Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespace(p0);
        }

        public void getBaseOperation_test_9486(Operation p0)
        {
            NamespaceOperation.getBaseOperation(p0);
        }

        public void getBaseOperation_test_9487(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getBaseOperation();
        }

        public void getNamespaces_test_9488(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespaces();
        }

        public void getNamespaces_test_9489(Operation p0)
        {
            NamespaceOperation.getNamespaces(p0);
        }

        public void getNamespaceCount_test_9490(Operation c0, Namespace[] c1)
        {
            NamespaceOperation instance = new NamespaceOperation(c0, c1);
            instance.getNamespaceCount();
        }
    }
}