namespace javax.swing
{
    public class JComponent
    {
    }
}

namespace javax.swing.plaf.synth
{
    public class SynthInternalFrameUI
    {
        public static SynthInternalFrameUI createUI(javax.swing.JComponent c)
        {
            return new SynthInternalFrameUI();
        }
    }
}

namespace Generated.Test
{
    public class javax_swing_plaf_synth_SynthInternalFrameUIAutoTest
    {
        public void createUI_test_12212(javax.swing.JComponent p0)
        {
            javax.swing.plaf.synth.SynthInternalFrameUI.createUI(p0);
        }
    }
}