namespace Generated.Test
{
    public class ToolTipManager
    {
        private static readonly ToolTipManager _sharedInstance = new ToolTipManager();

        private ToolTipManager()
        {
        }

        public static ToolTipManager sharedInstance()
        {
            return _sharedInstance;
        }
    }

    public class javax_swing_ToolTipManagerAutoTest
    {
        public void sharedInstance_test_12932()
        {
            ToolTipManager.sharedInstance();
        }
    }
}