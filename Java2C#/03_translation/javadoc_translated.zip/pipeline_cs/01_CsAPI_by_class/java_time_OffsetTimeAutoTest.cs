```csharp
using System;

namespace Generated.Test
{
    public sealed class CharSequence
    {
        private readonly string _value;

        public CharSequence(string value)
        {
            _value = value ?? string.Empty;
        }

        public static implicit operator CharSequence(string value)
        {
            return new CharSequence(value);
        }

        public static implicit operator string(CharSequence value)
        {
            return value == null ? string.Empty : value._value;
        }

        public override string ToString()
        {
            return _value;
        }
    }

    public interface TemporalAccessor
    {
    }

    public abstract class ZoneId
    {
    }

    public sealed class ZoneOffset : ZoneId
    {
        public ZoneOffset()
        {
        }
    }

    public sealed class LocalTime : TemporalAccessor
    {
        public LocalTime()
        {
        }
    }

    public sealed class Instant
    {
        public Instant()
        {
        }
    }

    public abstract class Clock
    {
    }

    public sealed class DateTimeFormatter
    {
        public DateTimeFormatter()
        {
        }
    }

    public sealed class OffsetTime : TemporalAccessor
    {
        public OffsetTime()
        {
        }

        public static OffsetTime of(LocalTime time, ZoneOffset offset)
        {
            return new OffsetTime();
        }

        public static OffsetTime of(int hour, int minute, int second, int nanoOfSecond, ZoneOffset offset)
        {
            return new OffsetTime();
        }

        public static OffsetTime from(TemporalAccessor temporal)
        {
            return new OffsetTime();
        }

        public static OffsetTime parse(CharSequence text)
        {
            return new OffsetTime();
        }

        public static OffsetTime parse(CharSequence text, DateTimeFormatter formatter)
        {
            return new OffsetTime();
        }

        public static OffsetTime now()
        {
            return new OffsetTime();
        }

        public static OffsetTime now(Clock clock)
        {
            return new OffsetTime();
        }

        public static OffsetTime now(ZoneId zone)
        {
            return new OffsetTime();
        }

        public static OffsetTime ofInstant(Instant instant, ZoneId zone)
        {
            return new OffsetTime();
        }
    }

    public class java_time_OffsetTimeAutoTest
    {
        public void of_test_9651(LocalTime p0, ZoneOffset p1)
        {
            OffsetTime.of(p0, p1);
        }

        public void of_test_9652(int p0, int p1, int p2, int p3, ZoneOffset p4)
        {
            OffsetTime.of(p0, p1, p2, p3, p4);
        }

        public void from_test_9653(TemporalAccessor p0)
        {
            OffsetTime.from(p0);
        }

        public void parse_test_9654(CharSequence p0)
        {
            OffsetTime.parse(p0);
        }

        public void parse_test_9655(CharSequence p0, DateTimeFormatter p1)
        {
            OffsetTime.parse(p0, p1);
        }

        public void now_test_9656()
        {
            OffsetTime.now();
        }

        public void now_test_9657(Clock p0)
        {
            OffsetTime.now(p0);
        }

        public void now_test_9658(ZoneId p0)
        {
            OffsetTime.now(p0);
        }

        public void ofInstant_test_9659(Instant p0, ZoneId p1)
        {
            OffsetTime.ofInstant(p0, p1);
        }
    }
}
```