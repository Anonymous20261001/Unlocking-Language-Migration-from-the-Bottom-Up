using System;
using System.Collections.Generic;

namespace java.util.random
{
    public class RandomGeneratorFactory
    {
        private static readonly string[] KnownNames = {
            "L128X1024MixRandom",
            "L128X128MixRandom",
            "L128X256MixRandom",
            "L32X64MixRandom",
            "L64X1024MixRandom",
            "L64X128MixRandom",
            "L64X128StarStarRandom",
            "L64X256MixRandom",
            "Random",
            "SecureRandom",
            "SplittableRandom",
            "Xoroshiro128PlusPlus",
            "Xoshiro256PlusPlus"
        };

        private readonly string _name;

        private RandomGeneratorFactory(string name)
        {
            _name = name;
        }

        public static RandomGeneratorFactory of(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException(nameof(name));
            }

            foreach (string knownName in KnownNames)
            {
                if (knownName == name)
                {
                    return new RandomGeneratorFactory(name);
                }
            }

            throw new ArgumentException("Unknown RandomGeneratorFactory: " + name, nameof(name));
        }

        public static RandomGeneratorFactory getDefault()
        {
            return new RandomGeneratorFactory("Random");
        }

        public static IEnumerable<RandomGeneratorFactory> all()
        {
            foreach (string knownName in KnownNames)
            {
                yield return new RandomGeneratorFactory(knownName);
            }
        }

        public string name()
        {
            return _name;
        }
    }
}

namespace Generated.Test
{
    using java.util.random;

    public class java_util_random_RandomGeneratorFactoryAutoTest
    {
        public void of_test_10322(string p0)
        {
            RandomGeneratorFactory.of(p0);
        }

        public void getDefault_test_10323()
        {
            RandomGeneratorFactory.getDefault();
        }

        public void all_test_10324()
        {
            RandomGeneratorFactory.all();
        }
    }
}