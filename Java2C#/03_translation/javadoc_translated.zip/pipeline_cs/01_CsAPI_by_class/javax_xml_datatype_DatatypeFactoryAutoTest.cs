namespace Generated.Test
{
    public class DatatypeFactory
    {
        public static DatatypeFactory newDefaultInstance()
        {
            return new DatatypeFactory();
        }
    }

    public class javax_xml_datatype_DatatypeFactoryAutoTest
    {
        public void newDefaultInstance_test_3280()
        {
            DatatypeFactory.newDefaultInstance();
        }
    }
}