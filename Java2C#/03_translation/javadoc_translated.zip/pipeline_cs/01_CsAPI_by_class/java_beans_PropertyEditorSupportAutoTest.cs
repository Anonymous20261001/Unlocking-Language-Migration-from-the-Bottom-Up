```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_beans_PropertyEditorSupportAutoTest
    {
        public void firePropertyChange_test_10182()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.firePropertyChange();
        }

        public void addPropertyChangeListener_test_10183(PropertyChangeListener p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.addPropertyChangeListener(p0);
        }

        public void removePropertyChangeListener_test_10184(PropertyChangeListener p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.removePropertyChangeListener(p0);
        }

        public void setSource_test_10185(object p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.setSource(p0);
        }

        public void isPaintable_test_10186()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.isPaintable();
        }

        public void paintValue_test_10187(Graphics p0, Rectangle p1)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.paintValue(p0, p1);
        }

        public void getJavaInitializationString_test_10188()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getJavaInitializationString();
        }

        public void getAsText_test_10189()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getAsText();
        }

        public void setAsText_test_10190(string p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.setAsText(p0);
        }

        public void getTags_test_10191()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getTags();
        }

        public void getCustomEditor_test_10192()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getCustomEditor();
        }

        public void supportsCustomEditor_test_10193()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.supportsCustomEditor();
        }

        public void getValue_test_10194()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getValue();
        }

        public void setValue_test_10195(object p0)
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.setValue(p0);
        }

        public void getSource_test_10196()
        {
            PropertyEditorSupport instance = new PropertyEditorSupport();
            instance.getSource();
        }
    }

    public class PropertyChangeEvent
    {
        private object _source;
        private string _propertyName;
        private object _oldValue;
        private object _newValue;

        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            _source = source;
            _propertyName = propertyName;
            _oldValue = oldValue;
            _newValue = newValue;
        }

        public object getSource()
        {
            return _source;
        }

        public string getPropertyName()
        {
            return _propertyName;
        }

        public object getOldValue()
        {
            return _oldValue;
        }

        public object getNewValue()
        {
            return _newValue;
        }
    }

    public delegate void PropertyChangeListener(PropertyChangeEvent evt);

    public class PropertyEditorSupport
    {
        private object _source;
        private object _value;
        private List<PropertyChangeListener> _listeners = new List<PropertyChangeListener>();

        public PropertyEditorSupport()
        {
        }

        public PropertyEditorSupport(object source)
        {
            _source = source;
        }

        public void firePropertyChange()
        {
            PropertyChangeEvent evt = new PropertyChangeEvent(_source, null, null, null);
            foreach (PropertyChangeListener listener in new List<PropertyChangeListener>(_listeners))
            {
                listener(evt);
            }
        }

        public void addPropertyChangeListener(PropertyChangeListener listener)
        {
            if (listener != null)
            {
                _listeners.Add(listener);
            }
        }

        public void removePropertyChangeListener(PropertyChangeListener listener)
        {
            _listeners.Remove(listener);
        }

        public void setSource(object source)
        {
            _source = source;
        }

        public object getSource()
        {
            return _source;
        }

        public bool isPaintable()
        {
            return false;
        }

        public void paintValue(Graphics g, Rectangle r)
        {
        }

        public string getJavaInitializationString()
        {
            return "null";
        }

        public string getAsText()
        {
            return _value != null ? _value.ToString() : "null";
        }

        public void setAsText(string text)
        {
            if (_value is string)
            {
                setValue(text);
            }
            else
            {
                throw new ArgumentException(text);
            }
        }

        public string[] getTags()
        {
            return null;
        }

        public object getCustomEditor()
        {
            return null;
        }

        public bool supportsCustomEditor()
        {
            return false;
        }

        public object getValue()
        {
            return _value;
        }

        public void setValue(object value)
        {
            _value = value;
        }
    }

    public class Graphics
    {
    }

    public class Rectangle
    {
        public int x;
        public int y;
        public int width;
        public int height;

        public Rectangle()
        {
        }

        public Rectangle(int x, int y, int width, int height)
        {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }
}
```