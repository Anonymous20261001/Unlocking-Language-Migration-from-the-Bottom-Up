namespace Generated.Test
{
    public abstract class Configuration
    {
        private static Configuration currentConfiguration;

        protected Configuration()
        {
        }

        public static void setConfiguration(Configuration config)
        {
            currentConfiguration = config;
        }

        public static Configuration getConfiguration()
        {
            if (currentConfiguration == null)
            {
                currentConfiguration = new DefaultConfiguration();
            }
            return currentConfiguration;
        }

        private sealed class DefaultConfiguration : Configuration
        {
            public DefaultConfiguration() : base()
            {
            }
        }
    }

    public class javax_security_auth_login_ConfigurationAutoTest
    {
        public void setConfiguration_test_2906(Configuration p0)
        {
            Configuration.setConfiguration(p0);
        }

        public void getConfiguration_test_2907()
        {
            Configuration.getConfiguration();
        }
    }
}