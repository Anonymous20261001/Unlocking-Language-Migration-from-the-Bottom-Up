using javax.net.ssl;

namespace Generated.Test
{
    public class javax_net_ssl_SSLServerSocketFactoryAutoTest
    {
        public void getDefault_test_11437()
        {
            SSLServerSocketFactory.GetDefault();
        }
    }
}

namespace javax.net.ssl
{
    public class SSLServerSocketFactory
    {
        public static SSLServerSocketFactory GetDefault()
        {
            return new SSLServerSocketFactory();
        }
    }
}