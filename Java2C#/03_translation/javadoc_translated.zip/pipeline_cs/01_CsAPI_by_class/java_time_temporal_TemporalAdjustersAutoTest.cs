namespace Generated.Test
{
    public enum DayOfWeek
    {
        Monday = 1,
        Tuesday = 2,
        Wednesday = 3,
        Thursday = 4,
        Friday = 5,
        Saturday = 6,
        Sunday = 7
    }

    public delegate object UnaryOperator(object obj);

    public abstract class TemporalAdjuster
    {
    }

    public static class TemporalAdjusters
    {
        public static TemporalAdjuster dayOfWeekInMonth(int ordinal, DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster ofDateAdjuster(UnaryOperator dateBasedAdjuster)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster firstDayOfMonth()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster firstDayOfNextMonth()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster lastDayOfYear()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster firstDayOfNextYear()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster firstInMonth(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster lastInMonth(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster next(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster previous(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster firstDayOfYear()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster lastDayOfMonth()
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster nextOrSame(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        public static TemporalAdjuster previousOrSame(DayOfWeek dayOfWeek)
        {
            return new SimpleAdjuster();
        }

        private sealed class SimpleAdjuster : TemporalAdjuster
        {
        }
    }

    public class java_time_temporal_TemporalAdjustersAutoTest
    {
        public void dayOfWeekInMonth_test_12520(int p0, DayOfWeek p1)
        {
            TemporalAdjusters.dayOfWeekInMonth(p0, p1);
        }

        public void ofDateAdjuster_test_12521(UnaryOperator p0)
        {
            TemporalAdjusters.ofDateAdjuster(p0);
        }

        public void firstDayOfMonth_test_12522()
        {
            TemporalAdjusters.firstDayOfMonth();
        }

        public void firstDayOfNextMonth_test_12523()
        {
            TemporalAdjusters.firstDayOfNextMonth();
        }

        public void lastDayOfYear_test_12524()
        {
            TemporalAdjusters.lastDayOfYear();
        }

        public void firstDayOfNextYear_test_12525()
        {
            TemporalAdjusters.firstDayOfNextYear();
        }

        public void firstInMonth_test_12526(DayOfWeek p0)
        {
            TemporalAdjusters.firstInMonth(p0);
        }

        public void lastInMonth_test_12527(DayOfWeek p0)
        {
            TemporalAdjusters.lastInMonth(p0);
        }

        public void next_test_12528(DayOfWeek p0)
        {
            TemporalAdjusters.next(p0);
        }

        public void previous_test_12529(DayOfWeek p0)
        {
            TemporalAdjusters.previous(p0);
        }

        public void firstDayOfYear_test_12530()
        {
            TemporalAdjusters.firstDayOfYear();
        }

        public void lastDayOfMonth_test_12531()
        {
            TemporalAdjusters.lastDayOfMonth();
        }

        public void nextOrSame_test_12532(DayOfWeek p0)
        {
            TemporalAdjusters.nextOrSame(p0);
        }

        public void previousOrSame_test_12533(DayOfWeek p0)
        {
            TemporalAdjusters.previousOrSame(p0);
        }
    }
}