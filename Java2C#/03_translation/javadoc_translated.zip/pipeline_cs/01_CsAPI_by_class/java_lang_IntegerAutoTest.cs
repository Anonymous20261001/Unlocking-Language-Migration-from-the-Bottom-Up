using System;
using System.Globalization;
using System.Text;

namespace Generated.Test
{
    public class Integer
    {
        private readonly int _value;

        public Integer(int value)
        {
            _value = value;
        }

        public static int numberOfLeadingZeros(int i)
        {
            if (i == 0) return 32;
            int n = 1;
            if (i >>> 16 == 0) { n += 16; i <<= 16; }
            if (i >>> 24 == 0) { n += 8; i <<= 8; }
            if (i >>> 28 == 0) { n += 4; i <<= 4; }
            if (i >>> 30 == 0) { n += 2; i <<= 2; }
            n -= (int)((uint)i >> 31);
            return n;
        }

        public static int numberOfTrailingZeros(int i)
        {
            if (i == 0) return 32;
            int n = 31;
            int y = i << 16;
            if (y != 0) { n -= 16; i = y; }
            y = i << 8;
            if (y != 0) { n -= 8; i = y; }
            y = i << 4;
            if (y != 0) { n -= 4; i = y; }
            y = i << 2;
            if (y != 0) { n -= 2; i = y; }
            return n - (int)(((uint)(i << 1)) >> 31);
        }

        public static int bitCount(int i)
        {
            i = i - ((int)((uint)i >> 1) & 0x55555555);
            i = (i & 0x33333333) + ((int)((uint)i >> 2) & 0x33333333);
            i = (i + ((int)((uint)i >> 4))) & 0x0f0f0f0f;
            i = i + ((int)((uint)i >> 8));
            i = i + ((int)((uint)i >> 16));
            return i & 0x3f;
        }

        public static int min(int a, int b)
        {
            return Math.Min(a, b);
        }

        public static int max(int a, int b)
        {
            return Math.Max(a, b);
        }

        public static int signum(int i)
        {
            return (i >> 31) | ((int)((uint)(-i) >> 31));
        }

        public static int expand(int i, int mask)
        {
            int result = 0;
            int m = 0;
            for (int bit = 0; bit < 32; bit++)
            {
                if ((mask & (1 << bit)) != 0)
                {
                    if ((i & (1 << m)) != 0)
                        result |= (1 << bit);
                    m++;
                }
            }
            return result;
        }

        public static int compareUnsigned(int x, int y)
        {
            return (int)(((uint)x) - ((uint)y));
        }

        public static int divideUnsigned(int dividend, int divisor)
        {
            if (divisor == 0)
                throw new DivideByZeroException();
            uint udividend = (uint)dividend;
            uint udivisor = (uint)divisor;
            return (int)(udividend / udivisor);
        }

        public static int remainderUnsigned(int dividend, int divisor)
        {
            if (divisor == 0)
                throw new DivideByZeroException();
            uint udividend = (uint)dividend;
            uint udivisor = (uint)divisor;
            return (int)(udividend % udivisor);
        }

        public static int reverse(int i)
        {
            i = (i & 0x55555555) << 1 | (int)((uint)i >> 1) & 0x55555555;
            i = (i & 0x33333333) << 2 | (int)((uint)i >> 2) & 0x33333333;
            i = (i & 0x0f0f0f0f) << 4 | (int)((uint)i >> 4) & 0x0f0f0f0f;
            i = (i << 24) | ((i & 0xff00) << 8) | ((int)((uint)i >> 8) & 0xff00) | (int)((uint)i >> 24);
            return i;
        }

        public static int reverseBytes(int i)
        {
            return (int)(((uint)i & 0x000000FF) << 24) |
                   (int)(((uint)i & 0x0000FF00) << 8) |
                   (int)(((uint)i & 0x00FF0000) >> 8) |
                   (int)(((uint)i & 0xFF000000) >> 24);
        }

        public static int compress(int i, int mask)
        {
            int result = 0;
            int m = 0;
            for (int bit = 0; bit < 32; bit++)
            {
                if ((mask & (1 << bit)) != 0)
                {
                    if ((i & (1 << bit)) != 0)
                        result |= (1 << m);
                    m++;
                }
            }
            return result;
        }

        public int compareTo(Integer anotherInteger)
        {
            return compare(_value, anotherInteger._value);
        }

        public static int compare(int x, int y)
        {
            return (x < y) ? -1 : ((x == y) ? 0 : 1);
        }

        public byte byteValue()
        {
            return (byte)_value;
        }

        public short shortValue()
        {
            return (short)_value;
        }

        public int intValue()
        {
            return _value;
        }

        public long longValue()
        {
            return _value;
        }

        public float floatValue()
        {
            return _value;
        }

        public double doubleValue()
        {
            return _value;
        }

        public static Integer valueOf(string s)
        {
            return new Integer(parseInt(s));
        }

        public static Integer valueOf(int i)
        {
            return new Integer(i);
        }

        public static Integer valueOf(string s, int radix)
        {
            return new Integer(parseInt(s, radix));
        }

        public static string toHexString(int i)
        {
            return Convert.ToString(i, 16);
        }

        public static Integer decode(string nm)
        {
            if (nm == null)
                throw new ArgumentNullException(nameof(nm));
            int index = 0;
            bool negative = false;
            if (nm.Length > 0 && nm[0] == '-')
            {
                negative = true;
                index++;
            }
            else if (nm.Length > 0 && nm[0] == '+')
            {
                index++;
            }

            int radix = 10;
            if (nm.Length > index + 1 && nm[index] == '0')
            {
                if (nm[index + 1] == 'x' || nm[index + 1] == 'X')
                {
                    radix = 16;
                    index += 2;
                }
                else if (nm[index + 1] == '#')
                {
                    radix = 16;
                    index += 2;
                }
                else
                {
                    radix = 8;
                    index++;
                }
            }
            else if (nm.Length > index + 1 && (nm[index] == '#'))
            {
                radix = 16;
                index++;
            }

            string sub = nm.Substring(index);
            int result = parseInt(sub, radix);
            return negative ? new Integer(-result) : new Integer(result);
        }

        public object resolveConstantDesc(object lookup)
        {
            return this;
        }

        public object describeConstable()
        {
            return this;
        }

        public static int parseInt(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
                throw new FormatException("Invalid radix: " + radix);
            if (beginIndex < 0 || endIndex < beginIndex || endIndex > s.Length)
                throw new IndexOutOfRangeException();

            int result = 0;
            bool negative = false;
            int i = beginIndex;
            int limit = -int.MaxValue;

            if (i < endIndex)
            {
                char firstChar = s.charAt(i);
                if (firstChar < '0')
                {
                    if (firstChar == '-')
                    {
                        negative = true;
                        limit = int.MinValue;
                    }
                    else if (firstChar != '+')
                    {
                        throw new FormatException("Invalid character: " + firstChar);
                    }
                    i++;
                }
            }

            int multmin = limit / radix;
            while (i < endIndex)
            {
                int digit = Character.digit(s.charAt(i), radix);
                if (digit < 0)
                    throw new FormatException("Invalid digit");
                if (result < multmin)
                    throw new OverflowException();
                result *= radix;
                if (result < limit + digit)
                    throw new OverflowException();
                result -= digit;
                i++;
            }

            return negative ? result : -result;
        }

        public static int parseInt(string s)
        {
            return parseInt(s, 10);
        }

        public static int parseInt(string s, int radix)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
                throw new FormatException("Invalid radix: " + radix);

            int result = 0;
            bool negative = false;
            int i = 0;
            int len = s.Length;
            int limit = -int.MaxValue;

            if (len > 0)
            {
                char firstChar = s[0];
                if (firstChar < '0')
                {
                    if (firstChar == '-')
                    {
                        negative = true;
                        limit = int.MinValue;
                    }
                    else if (firstChar != '+')
                    {
                        throw new FormatException("Invalid character: " + firstChar);
                    }
                    if (len == 1)
                        throw new FormatException("Invalid string");
                    i++;
                }
            }

            int multmin = limit / radix;
            while (i < len)
            {
                int digit = Character.digit(s[i], radix);
                if (digit < 0)
                    throw new FormatException("Invalid digit");
                if (result < multmin)
                    throw new OverflowException();
                result *= radix;
                if (result < limit + digit)
                    throw new OverflowException();
                result -= digit;
                i++;
            }

            return negative ? result : -result;
        }

        public static long toUnsignedLong(int x)
        {
            return (uint)x;
        }

        public static int sum(int a, int b)
        {
            return a + b;
        }

        public static string toUnsignedString(int i)
        {
            return ((uint)i).ToString();
        }

        public static string toUnsignedString(int i, int radix)
        {
            if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
                radix = 10;
            uint ui = (uint)i;
            if (ui == 0)
                return "0";
            StringBuilder sb = new StringBuilder();
            while (ui > 0)
            {
                sb.Insert(0, Character.forDigit((int)(ui % (uint)radix), radix));
                ui /= (uint)radix;
            }
            return sb.ToString();
        }

        public static int parseUnsignedInt(string s, int radix)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            int len = s.Length;
            if (len > 0)
            {
                char firstChar = s[0];
                if (firstChar == '-')
                    throw new FormatException("Negative value");
            }
            return (int)parseUnsignedLong(s, radix);
        }

        public static int parseUnsignedInt(string s)
        {
            return parseUnsignedInt(s, 10);
        }

        public static int parseUnsignedInt(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
                throw new FormatException("Invalid radix: " + radix);
            if (beginIndex < 0 || endIndex < beginIndex || endIndex > s.Length)
                throw new IndexOutOfRangeException();

            long result = 0;
            for (int i = beginIndex; i < endIndex; i++)
            {
                int digit = Character.digit(s.charAt(i), radix);
                if (digit < 0)
                    throw new FormatException("Invalid digit");
                result = result * radix + digit;
                if (result > uint.MaxValue)
                    throw new OverflowException();
            }
            return (int)result;
        }

        private static long parseUnsignedLong(string s, int radix)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (radix < Character.MIN_RADIX || radix > Character.MAX_RADIX)
                throw new FormatException("Invalid radix: " + radix);

            long result = 0;
            for (int i = 0; i < s.Length; i++)
            {
                int digit = Character.digit(s[i], radix);
                if (digit < 0)
                    throw new FormatException("Invalid digit");
                result = result * radix + digit;
                if (result > uint.MaxValue)
                    throw new OverflowException();
            }
            return result;
        }

        public static Integer getInteger(string nm, Integer val)
        {
            string v = Environment.GetEnvironmentVariable(nm);
            if (v != null)
            {
                try
                {
                    return decode(v);
                }
                catch (Exception)
                {
                    // ignore
                }
            }
            return val;
        }

        public static Integer getInteger(string nm)
        {
            return getInteger(nm, null);
        }

        public static Integer getInteger(string nm, int val)
        {
            return getInteger(nm, new Integer(val));
        }

        public static string toOctalString(int i)
        {
            return Convert.ToString(i, 8);
        }

        public static string toBinaryString(int i)
        {
            return Convert.ToString(i, 2);
        }

        public static int highestOneBit(int i)
        {
            i |= (int)((uint)i >> 1);
            i |= (int)((uint)i >> 2);
            i |= (int)((uint)i >> 4);
            i |= (int)((uint)i >> 8);
            i |= (int)((uint)i >> 16);
            return i - (int)((uint)i >> 1);
        }

        public static int lowestOneBit(int i)
        {
            return i & -i;
        }

        public static int rotateLeft(int i, int distance)
        {
            return (i << distance) | (int)((uint)i >> (32 - distance));
        }

        public static int rotateRight(int i, int distance)
        {
            return (int)((uint)i >> distance) | (i << (32 - distance));
        }
    }

    public class CharSequence
    {
        public string Value { get; }

        public CharSequence(string value)
        {
            Value = value;
        }

        public int Length => Value.Length;

        public char charAt(int index)
        {
            return Value[index];
        }
    }

    public static class Character
    {
        public const int MIN_RADIX = 2;
        public const int MAX_RADIX = 36;

        public static int digit(char ch, int radix)
        {
            if (radix < MIN_RADIX || radix > MAX_RADIX)
                return -1;
            int value = -1;
            if (ch >= '0' && ch <= '9')
                value = ch - '0';
            else if (ch >= 'a' && ch <= 'z')
                value = ch - 'a' + 10;
            else if (ch >= 'A' && ch <= 'Z')
                value = ch - 'A' + 10;
            return value < radix ? value : -1;
        }

        public static char forDigit(int digit, int radix)
        {
            if (digit < 0 || digit >= radix || radix < MIN_RADIX || radix > MAX_RADIX)
                return '\0';
            if (digit < 10)
                return (char)('0' + digit);
            return (char)('a' + digit - 10);
        }
    }

    public class MethodHandles
    {
        public class Lookup
        {
        }
    }

    public class java_lang_IntegerAutoTest
    {
        public void numberOfLeadingZeros_test_5867(int p0)
        {
            Integer.numberOfLeadingZeros(p0);
        }

        public void numberOfTrailingZeros_test_5868(int p0)
        {
            Integer.numberOfTrailingZeros(p0);
        }

        public void bitCount_test_5869(int p0)
        {
            Integer.bitCount(p0);
        }

        public void min_test_5870(int p0, int p1)
        {
            Integer.min(p0, p1);
        }

        public void max_test_5871(int p0, int p1)
        {
            Integer.max(p0, p1);
        }

        public void signum_test_5872(int p0)
        {
            Integer.signum(p0);
        }

        public void expand_test_5873(int p0, int p1)
        {
            Integer.expand(p0, p1);
        }

        public void compareUnsigned_test_5874(int p0, int p1)
        {
            Integer.compareUnsigned(p0, p1);
        }

        public void divideUnsigned_test_5875(int p0, int p1)
        {
            Integer.divideUnsigned(p0, p1);
        }

        public void remainderUnsigned_test_5876(int p0, int p1)
        {
            Integer.remainderUnsigned(p0, p1);
        }

        public void reverse_test_5877(int p0)
        {
            Integer.reverse(p0);
        }

        public void reverseBytes_test_5878(int p0)
        {
            Integer.reverseBytes(p0);
        }

        public void compress_test_5879(int p0, int p1)
        {
            Integer.compress(p0, p1);
        }

        public void compareTo_test_5880(Integer p0, int c0)
        {
            Integer instance = new Integer(c0);
            instance.compareTo(p0);
        }

        public void compare_test_5881(int p0, int p1)
        {
            Integer.compare(p0, p1);
        }

        public void byteValue_test_5882(int c0)
        {
            Integer instance = new Integer(c0);
            instance.byteValue();
        }

        public void shortValue_test_5883(int c0)
        {
            Integer instance = new Integer(c0);
            instance.shortValue();
        }

        public void intValue_test_5884(int c0)
        {
            Integer instance = new Integer(c0);
            instance.intValue();
        }

        public void longValue_test_5885(int c0)
        {
            Integer instance = new Integer(c0);
            instance.longValue();
        }

        public void floatValue_test_5886(int c0)
        {
            Integer instance = new Integer(c0);
            instance.floatValue();
        }

        public void doubleValue_test_5887(int c0)
        {
            Integer instance = new Integer(c0);
            instance.doubleValue();
        }

        public void valueOf_test_5888(string p0)
        {
            Integer.valueOf(p0);
        }

        public void valueOf_test_5889(int p0)
        {
            Integer.valueOf(p0);
        }

        public void valueOf_test_5890(string p0, int p1)
        {
            Integer.valueOf(p0, p1);
        }

        public void toHexString_test_5891(int p0)
        {
            Integer.toHexString(p0);
        }

        public void decode_test_5892(string p0)
        {
            Integer.decode(p0);
        }

        public void resolveConstantDesc_test_5893(MethodHandles.Lookup p0, int c0)
        {
            Integer instance = new Integer(c0);
            instance.resolveConstantDesc(p0);
        }

        public void describeConstable_test_5894(int c0)
        {
            Integer instance = new Integer(c0);
            instance.describeConstable();
        }

        public void parseInt_test_5895(CharSequence p0, int p1, int p2, int p3)
        {
            Integer.parseInt(p0, p1, p2, p3);
        }

        public void parseInt_test_5896(string p0)
        {
            Integer.parseInt(p0);
        }

        public void parseInt_test_5897(string p0, int p1)
        {
            Integer.parseInt(p0, p1);
        }

        public void toUnsignedLong_test_5898(int p0)
        {
            Integer.toUnsignedLong(p0);
        }

        public void sum_test_5899(int p0, int p1)
        {
            Integer.sum(p0, p1);
        }

        public void toUnsignedString_test_5900(int p0)
        {
            Integer.toUnsignedString(p0);
        }

        public void toUnsignedString_test_5901(int p0, int p1)
        {
            Integer.toUnsignedString(p0, p1);
        }

        public void parseUnsignedInt_test_5902(string p0, int p1)
        {
            Integer.parseUnsignedInt(p0, p1);
        }

        public void parseUnsignedInt_test_5903(string p0)
        {
            Integer.parseUnsignedInt(p0);
        }

        public void parseUnsignedInt_test_5904(CharSequence p0, int p1, int p2, int p3)
        {
            Integer.parseUnsignedInt(p0, p1, p2, p3);
        }

        public void getInteger_test_5905(string p0, Integer p1)
        {
            Integer.getInteger(p0, p1);
        }

        public void getInteger_test_5906(string p0)
        {
            Integer.getInteger(p0);
        }

        public void getInteger_test_5907(string p0, int p1)
        {
            Integer.getInteger(p0, p1);
        }

        public void toOctalString_test_5908(int p0)
        {
            Integer.toOctalString(p0);
        }

        public void toBinaryString_test_5909(int p0)
        {
            Integer.toBinaryString(p0);
        }

        public void highestOneBit_test_5910(int p0)
        {
            Integer.highestOneBit(p0);
        }

        public void lowestOneBit_test_5911(int p0)
        {
            Integer.lowestOneBit(p0);
        }

        public void rotateLeft_test_5912(int p0, int p1)
        {
            Integer.rotateLeft(p0, p1);
        }

        public void rotateRight_test_5913(int p0, int p1)
        {
            Integer.rotateRight(p0, p1);
        }
    }
}