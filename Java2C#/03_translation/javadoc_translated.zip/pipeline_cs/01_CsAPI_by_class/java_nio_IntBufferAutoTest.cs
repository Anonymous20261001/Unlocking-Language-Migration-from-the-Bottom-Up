using System;
using java.nio;

namespace java.nio
{
    public class IntBuffer
    {
        private readonly int[] _array;
        private readonly int _capacity;
        private readonly bool _readOnly;
        private int _position;
        private int _limit;
        private int _mark = -1;

        private IntBuffer(int[] array, int position, int limit, int capacity, bool readOnly)
        {
            _array = array;
            _position = position;
            _limit = limit;
            _capacity = capacity;
            _readOnly = readOnly;
        }

        public static IntBuffer wrap(int[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            return new IntBuffer(array, 0, array.Length, array.Length, false);
        }

        public static IntBuffer wrap(int[] array, int offset, int length)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            if (offset < 0 || length < 0 || offset > array.Length - length)
            {
                throw new IndexOutOfRangeException();
            }
            return new IntBuffer(array, offset, offset + length, array.Length, false);
        }

        public static IntBuffer allocate(int capacity)
        {
            if (capacity < 0)
            {
                throw new ArgumentOutOfRangeException("capacity");
            }
            return new IntBuffer(new int[capacity], 0, capacity, capacity, false);
        }

        public int capacity()
        {
            return _capacity;
        }

        public int position()
        {
            return _position;
        }

        public IntBuffer position(int newPosition)
        {
            if (newPosition < 0 || newPosition > _limit)
            {
                throw new ArgumentOutOfRangeException("newPosition");
            }
            _position = newPosition;
            if (_mark > _position)
            {
                _mark = -1;
            }
            return this;
        }

        public int limit()
        {
            return _limit;
        }

        public IntBuffer limit(int newLimit)
        {
            if (newLimit < 0 || newLimit > _capacity)
            {
                throw new ArgumentOutOfRangeException("newLimit");
            }
            _limit = newLimit;
            if (_position > _limit)
            {
                _position = _limit;
            }
            if (_mark > _limit)
            {
                _mark = -1;
            }
            return this;
        }

        public int get()
        {
            if (_position >= _limit)
            {
                throw new InvalidOperationException("Buffer underflow");
            }
            return _array[_position++];
        }

        public IntBuffer put(int value)
        {
            if (_readOnly)
            {
                throw new InvalidOperationException("Read-only buffer");
            }
            if (_position >= _limit)
            {
                throw new InvalidOperationException("Buffer overflow");
            }
            _array[_position++] = value;
            return this;
        }

        public int get(int index)
        {
            if (index < 0 || index >= _limit)
            {
                throw new IndexOutOfRangeException();
            }
            return _array[index];
        }

        public IntBuffer put(int index, int value)
        {
            if (_readOnly)
            {
                throw new InvalidOperationException("Read-only buffer");
            }
            if (index < 0 || index >= _limit)
            {
                throw new IndexOutOfRangeException();
            }
            _array[index] = value;
            return this;
        }

        public int[] array()
        {
            if (!hasArray())
            {
                throw new InvalidOperationException("No backing array");
            }
            return _array;
        }

        public bool hasArray()
        {
            return _array != null;
        }

        public IntBuffer flip()
        {
            _limit = _position;
            _position = 0;
            _mark = -1;
            return this;
        }

        public IntBuffer clear()
        {
            _position = 0;
            _limit = _capacity;
            _mark = -1;
            return this;
        }

        public int remaining()
        {
            return _limit - _position;
        }

        public bool hasRemaining()
        {
            return _position < _limit;
        }
    }
}

namespace Generated.Test
{
    public class java_nio_IntBufferAutoTest
    {
        public void wrap_test_5864(int[] p0)
        {
            IntBuffer.wrap(p0);
        }

        public void wrap_test_5865(int[] p0, int p1, int p2)
        {
            IntBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_5866(int p0)
        {
            IntBuffer.allocate(p0);
        }
    }
}