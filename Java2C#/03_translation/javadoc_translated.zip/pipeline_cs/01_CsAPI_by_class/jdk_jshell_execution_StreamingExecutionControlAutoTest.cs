namespace Generated.Test
{
    public interface ObjectInput
    {
        int Available();
        void Close();
        int Read();
        int Read(byte[] b);
        int Read(byte[] b, int off, int len);
        object ReadObject();
        long Skip(long n);
    }

    public interface ObjectOutput
    {
        void Close();
        void Flush();
        void Write(int b);
        void Write(byte[] b);
        void Write(byte[] b, int off, int len);
        void WriteObject(object obj);
    }

    public class StreamingExecutionControl
    {
        private readonly ObjectOutput output;
        private readonly ObjectInput input;

        public StreamingExecutionControl(ObjectOutput output, ObjectInput input)
        {
            this.output = output;
            this.input = input;
        }

        public void Close()
        {
            if (output != null) output.Close();
            if (input != null) input.Close();
        }
    }

    public class jdk_jshell_execution_StreamingExecutionControlAutoTest
    {
        public void close_test_11512(ObjectOutput c0, ObjectInput c1)
        {
            StreamingExecutionControl instance = new StreamingExecutionControl(c0, c1);
            instance.Close();
        }
    }
}