namespace Generated.Test
{
    using System;
    using System.Globalization;

    public class Locale
    {
        private readonly string language;
        private readonly string country;
        private readonly string variant;

        public Locale(string language, string country = "", string variant = "")
        {
            this.language = language ?? "";
            this.country = country ?? "";
            this.variant = variant ?? "";
        }

        public string getLanguage()
        {
            return language;
        }

        public string getCountry()
        {
            return country;
        }

        public string getVariant()
        {
            return variant;
        }

        public static Locale getDefault()
        {
            CultureInfo culture = CultureInfo.CurrentCulture;
            string country = "";
            try
            {
                RegionInfo region = new RegionInfo(culture.Name);
                country = region.TwoLetterISORegionName;
            }
            catch
            {
            }
            return new Locale(culture.TwoLetterISOLanguageName, country);
        }

        public static Locale[] getAvailableLocales()
        {
            CultureInfo[] cultures = CultureInfo.GetCultures(CultureTypes.AllCultures);
            Locale[] locales = new Locale[cultures.Length];
            for (int i = 0; i < cultures.Length; i++)
            {
                string language = cultures[i].TwoLetterISOLanguageName;
                string country = "";
                try
                {
                    RegionInfo region = new RegionInfo(cultures[i].Name);
                    country = region.TwoLetterISORegionName;
                }
                catch
                {
                }
                locales[i] = new Locale(language, country);
            }
            return locales;
        }
    }

    public class Collator
    {
        private readonly Locale locale;

        public Collator(Locale locale)
        {
            this.locale = locale ?? Locale.getDefault();
        }

        public static Collator getInstance()
        {
            return new Collator(Locale.getDefault());
        }

        public static Collator getInstance(Locale locale)
        {
            return new Collator(locale);
        }

        public static Locale[] getAvailableLocales()
        {
            return Locale.getAvailableLocales();
        }
    }

    public class java_text_CollatorAutoTest
    {
        public void getInstance_test_2349(Locale p0)
        {
            Collator.getInstance(p0);
        }

        public void getInstance_test_2350()
        {
            Collator.getInstance();
        }

        public void getAvailableLocales_test_2351()
        {
            Collator.getAvailableLocales();
        }
    }
}