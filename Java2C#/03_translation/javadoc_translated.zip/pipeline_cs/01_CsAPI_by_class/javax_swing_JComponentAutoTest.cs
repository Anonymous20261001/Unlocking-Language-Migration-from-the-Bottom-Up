using System;

namespace Generated.Test
{
    public class Locale
    {
        public string Language { get; }
        public string Country { get; }
        public string Variant { get; }

        public Locale(string language) : this(language, "", "") { }
        public Locale(string language, string country) : this(language, country, "") { }
        public Locale(string language, string country, string variant)
        {
            Language = language ?? "";
            Country = country ?? "";
            Variant = variant ?? "";
        }

        private static Locale _default = new Locale("en", "US", "");

        public static Locale getDefault()
        {
            return _default;
        }

        public static void setDefault(Locale newLocale)
        {
            _default = newLocale ?? throw new ArgumentNullException(nameof(newLocale));
        }
    }

    public class Component
    {
    }

    public class JComponent : Component
    {
        private static Locale _defaultLocale = Locale.getDefault();

        public static Locale getDefaultLocale()
        {
            return _defaultLocale;
        }

        public static void setDefaultLocale(Locale newLocale)
        {
            _defaultLocale = newLocale ?? throw new ArgumentNullException(nameof(newLocale));
        }

        public static bool isLightweightComponent(Component component)
        {
            return component is JComponent;
        }
    }

    public class javax_swing_JComponentAutoTest
    {
        public void getDefaultLocale_test_6106()
        {
            JComponent.getDefaultLocale();
        }

        public void isLightweightComponent_test_6107(Component p0)
        {
            JComponent.isLightweightComponent(p0);
        }

        public void setDefaultLocale_test_6108(Locale p0)
        {
            JComponent.setDefaultLocale(p0);
        }
    }
}