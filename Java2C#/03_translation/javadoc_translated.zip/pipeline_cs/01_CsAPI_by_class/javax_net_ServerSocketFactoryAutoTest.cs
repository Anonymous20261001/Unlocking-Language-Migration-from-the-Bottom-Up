```csharp
using System;

namespace Generated.Test
{
    public class ServerSocketFactory
    {
        public static ServerSocketFactory getDefault()
        {
            return new ServerSocketFactory();
        }
    }

    public class javax_net_ServerSocketFactoryAutoTest
    {
        public void getDefault_test_11047()
        {
            ServerSocketFactory.getDefault();
        }
    }
}
```