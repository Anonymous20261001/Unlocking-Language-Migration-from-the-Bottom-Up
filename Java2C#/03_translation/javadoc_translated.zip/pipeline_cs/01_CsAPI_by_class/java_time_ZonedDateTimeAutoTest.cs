```csharp
using System;
using System.Globalization;

namespace Generated.Test
{
    public class java_time_ZonedDateTimeAutoTest
    {
        public void ofLocal_test_13709(LocalDateTime p0, ZoneId p1, ZoneOffset p2)
        {
            ZonedDateTime.ofLocal(p0, p1, p2);
        }

        public void ofStrict_test_13710(LocalDateTime p0, ZoneOffset p1, ZoneId p2)
        {
            ZonedDateTime.ofStrict(p0, p1, p2);
        }

        public void of_test_13711(int p0, int p1, int p2, int p3, int p4, int p5, int p6, ZoneId p7)
        {
            ZonedDateTime.of(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void of_test_13712(LocalDate p0, LocalTime p1, ZoneId p2)
        {
            ZonedDateTime.of(p0, p1, p2);
        }

        public void of_test_13713(LocalDateTime p0, ZoneId p1)
        {
            ZonedDateTime.of(p0, p1);
        }

        public void from_test_13714(TemporalAccessor p0)
        {
            ZonedDateTime.from(p0);
        }

        public void parse_test_13715(string p0, DateTimeFormatter p1)
        {
            ZonedDateTime.parse(p0, p1);
        }

        public void parse_test_13716(string p0)
        {
            ZonedDateTime.parse(p0);
        }

        public void now_test_13717()
        {
            ZonedDateTime.now();
        }

        public void now_test_13718(Clock p0)
        {
            ZonedDateTime.now(p0);
        }

        public void now_test_13719(ZoneId p0)
        {
            ZonedDateTime.now(p0);
        }

        public void ofInstant_test_13720(LocalDateTime p0, ZoneOffset p1, ZoneId p2)
        {
            ZonedDateTime.ofInstant(p0, p1, p2);
        }

        public void ofInstant_test_13721(Instant p0, ZoneId p1)
        {
            ZonedDateTime.ofInstant(p0, p1);
        }
    }

    public interface TemporalAccessor
    {
    }

    public class DateTimeException : Exception
    {
        public DateTimeException(string message) : base(message)
        {
        }
    }

    public class ZoneId
    {
        private readonly string _id;
        private readonly TimeZoneInfo _timeZone;

        internal ZoneId(string id, TimeZoneInfo timeZone)
        {
            _id = id;
            _timeZone = timeZone;
        }

        public string Id
        {
            get { return _id; }
        }

        internal TimeZoneInfo TimeZone
        {
            get { return _timeZone; }
        }

        public static ZoneId systemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id, TimeZoneInfo.Local);
        }

        public static ZoneId of(string id)
        {
            if (id == "UTC" || id == "Z")
            {
                return ZoneOffset.UTC;
            }

            if (id.StartsWith("+") || id.StartsWith("-"))
            {
                return ZoneOffset.of(id);
            }

            try
            {
                TimeZoneInfo tz = TimeZoneInfo.FindSystemTimeZoneById(id);
                return new ZoneId(id, tz);
            }
            catch (TimeZoneNotFoundException)
            {
                return ZoneOffset.UTC;
            }
        }

        public override string ToString()
        {
            return _id;
        }

        public override bool Equals(object obj)
        {
            ZoneId other = obj as ZoneId;
            return other != null && _id == other._id;
        }

        public override int GetHashCode()
        {
            return _id.GetHashCode();
        }
    }

    public sealed class ZoneOffset : ZoneId
    {
        private readonly int _totalSeconds;

        internal ZoneOffset(int totalSeconds)
            : base(FormatOffset(totalSeconds), CreateTimeZone(totalSeconds))
        {
            _totalSeconds = totalSeconds;
        }

        public int TotalSeconds
        {
            get { return _totalSeconds; }
        }

        public static ZoneOffset UTC
        {
            get { return new ZoneOffset(0); }
        }

        public static ZoneOffset of(string id)
        {
            if (id == "Z")
            {
                return UTC;
            }

            bool negative = id.StartsWith("-");
            if (!(id.StartsWith("+") || negative))
            {
                throw new FormatException("Invalid offset: " + id);
            }

            string[] parts = id.Substring(1).Split(':');
            int hours = int.Parse(parts[0], CultureInfo.InvariantCulture);
            int minutes = parts.Length > 1 ? int.Parse(parts[1], CultureInfo.InvariantCulture) : 0;
            int totalSeconds = hours * 3600 + minutes * 60;
            if (negative)
            {
                totalSeconds = -totalSeconds;
            }

            return new ZoneOffset(totalSeconds);
        }

        public static ZoneOffset ofHours(int hours)
        {
            return new ZoneOffset(hours * 3600);
        }

        public static ZoneOffset ofHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(hours * 3600 + minutes * 60);
        }

        public override string ToString()
        {
            return FormatOffset(_totalSeconds);
        }

        private static string FormatOffset(int totalSeconds)
        {
            if (totalSeconds == 0)
            {
                return "Z";
            }

            int totalMinutes = totalSeconds / 60;
            char sign = totalMinutes < 0 ? '-' : '+';
            int absolute = Math.Abs(totalMinutes);
            int hours = absolute / 60;
            int minutes = absolute % 60;
            return sign + hours.ToString("00", CultureInfo.InvariantCulture) + ":" + minutes.ToString("00", CultureInfo.InvariantCulture);
        }

        private static TimeZoneInfo CreateTimeZone(int totalSeconds)
        {
            TimeSpan offset = TimeSpan.FromSeconds(totalSeconds);
            string id = "UTC" + FormatOffset(totalSeconds);
            return TimeZoneInfo.CreateCustomTimeZone(id, offset, id, id);
        }
    }

    public class LocalDate : TemporalAccessor
    {
        private readonly DateTime _date;

        public LocalDate(int year, int month, int day)
        {
            _date = new DateTime(year, month, day);
        }

        public int Year
        {
            get { return _date.Year; }
        }

        public int Month
        {
            get { return _date.Month; }
        }

        public int Day
        {
            get { return _date.Day; }
        }

        public static LocalDate now()
        {
            DateTime current = DateTime.Now;
            return new LocalDate(current.Year, current.Month, current.Day);
        }

        public override string ToString()
        {
            return _date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public DateTime ToDateTime()
        {
            return _date;
        }
    }

    public class LocalTime : TemporalAccessor
    {
        private readonly DateTime _time;
        private readonly int _nano;

        public LocalTime(int hour, int minute, int second, int nanoOfSecond)
        {
            if (hour < 0 || hour > 23)
            {
                throw new ArgumentOutOfRangeException("hour");
            }

            if (minute < 0 || minute > 59)
            {
                throw new ArgumentOutOfRangeException("minute");
            }

            if (second < 0 || second > 59)
            {
                throw new ArgumentOutOfRangeException("second");
            }

            if (nanoOfSecond < 0 || nanoOfSecond > 999999999)
            {
                throw new ArgumentOutOfRangeException("nanoOfSecond");
            }

            _time = new DateTime(1, 1, 1, hour, minute, second, 0, DateTimeKind.Unspecified);
            _nano = nanoOfSecond;
        }

        public int Hour
        {
            get { return _time.Hour; }
        }

        public int Minute
        {
            get { return _time.Minute; }
        }

        public int Second
        {
            get { return _time.Second; }
        }

        public int Nano
        {
            get { return _nano; }
        }

        public long ToNanoOfDay()
        {
            long seconds = Hour * 3600L + Minute * 60L + Second;
            return seconds * 1000000000L + _nano;
        }

        public static LocalTime now()
        {
            DateTime current = DateTime.Now;
            return new LocalTime(current.Hour, current.Minute, current.Second, 0);
        }

        public override string ToString()
        {
            string result = _time.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
            if (_nano != 0)
            {
                result += "." + _nano.ToString("D9", CultureInfo.InvariantCulture).TrimEnd('0');
            }

            return result;
        }
    }

    public class LocalDateTime : TemporalAccessor
    {
        private readonly LocalDate _date;
        private readonly LocalTime _time;

        public LocalDateTime(int year, int month, int day, int hour, int minute, int second, int nanoOfSecond)
        {
            _date = new LocalDate(year, month, day);
            _time = new LocalTime(hour, minute, second, nanoOfSecond);
        }

        public LocalDateTime(LocalDate date, LocalTime time)
        {
            _date = date;
            _time = time;
        }

        public LocalDate Date
        {
            get { return _date; }
        }

        public LocalTime Time
        {
            get { return _time; }
        }

        public int Year
        {
            get { return _date.Year; }
        }

        public int Month
        {
            get { return _date.Month; }
        }

        public int Day
        {
            get { return _date.Day; }
        }

        public int Hour
        {
            get { return _time.Hour; }
        }

        public int Minute
        {
            get { return _time.Minute; }
        }

        public int Second
        {
            get { return _time.Second; }
        }

        public int Nano
        {
            get { return _time.Nano; }
        }

        public static LocalDateTime now()
        {
            return new LocalDateTime(LocalDate.now(), LocalTime.now());
        }

        public override string ToString()
        {
            return _date.ToString() + "T" + _time.ToString();
        }

        public DateTime ToDateTime()
        {
            DateTime date = _date.ToDateTime();
            long ticks = _time.ToNanoOfDay() / 100;
            return date.AddTicks(ticks);
        }
    }

    public class Instant
    {
        private readonly DateTime _utc;

        public Instant(DateTime utc)
        {
            _utc = DateTime.SpecifyKind(utc, DateTimeKind.Utc);
        }

        public static Instant now()
        {
            return new Instant(DateTime.UtcNow);
        }

        public DateTime ToDateTimeUtc()
        {
            return _utc;
        }

        public long ToUnixTimeMilliseconds()
        {
            return new DateTimeOffset(_utc).ToUnixTimeMilliseconds();
        }

        public override string ToString()
        {
            return _utc.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture);
        }
    }

    public abstract class Clock
    {
        public abstract Instant instant();
        public abstract ZoneId zone();

        public static Clock systemDefaultZone()
        {
            return new SystemClock(ZoneId.systemDefault());
        }

        public static Clock systemUTC()
        {
            return new SystemClock(ZoneOffset.UTC);
        }

        private sealed class SystemClock : Clock
        {
            private readonly ZoneId _zone;

            public SystemClock(ZoneId zone)
            {
                _zone = zone;
            }

            public override Instant instant()
            {
                return Instant.now();
            }

            public override ZoneId zone()
            {
                return _zone;
            }
        }
    }

    public class DateTimeFormatter
    {
        private readonly string _pattern;

        public DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public static DateTimeFormatter ofPattern(string pattern)
        {
            return new DateTimeFormatter(pattern);
        }

        public static DateTimeFormatter ISO_LOCAL_DATE_TIME
        {
            get { return new DateTimeFormatter("yyyy-MM-dd'T'HH:mm:ss"); }
        }

        public static DateTimeFormatter ISO_ZONED_DATE_TIME
        {
            get { return new DateTimeFormatter("yyyy-MM-dd'T'HH:mm:ss'Z'"); }
        }

        public TemporalAccessor parse(string text)
        {
            DateTimeOffset parsed;
            if (!DateTimeOffset.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out parsed))
            {
                throw new FormatException("Could not parse: " + text);
            }

            LocalDateTime ldt = new LocalDateTime(
                parsed.Year,
                parsed.Month,
                parsed.Day,
                parsed.Hour,
                parsed.Minute,
                parsed.Second,
                parsed.Millisecond * 1000000);

            ZoneOffset offset = new ZoneOffset((int)parsed.Offset.TotalSeconds);
            return new ZonedDateTime(ldt, offset);
        }

        public string pattern()
        {
            return _pattern;
        }
    }

    public class ZonedDateTime : TemporalAccessor
    {
        private readonly LocalDateTime _localDateTime;
        private readonly ZoneId _zone;

        public ZonedDateTime(LocalDateTime localDateTime, ZoneId zone)
        {
            _localDateTime = localDateTime;
            _zone = zone;
        }

        public LocalDateTime toLocalDateTime()
        {
            return _localDateTime;
        }

        public ZoneId zone()
        {
            return _zone;
        }

        public override string ToString()
        {
            return _localDateTime.ToString() + " " + _zone.ToString();
        }

        public static ZonedDateTime of(LocalDateTime localDateTime, ZoneId zone)
        {
            return new ZonedDateTime(localDateTime, zone);
        }

        public static ZonedDateTime of(LocalDate date, LocalTime time, ZoneId zone)
        {
            return new ZonedDateTime(new LocalDateTime(date, time), zone);
        }

        public static ZonedDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond, ZoneId zone)
        {
            return new ZonedDateTime(new LocalDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond), zone);
        }

        public static ZonedDateTime ofLocal(LocalDateTime localDateTime, ZoneId zone, ZoneOffset preferredOffset)
        {
            return new ZonedDateTime(localDateTime, zone);
        }

        public static ZonedDateTime ofStrict(LocalDateTime localDateTime, ZoneOffset offset, ZoneId zone)
        {
            ZoneOffset zoneOffset = zone as ZoneOffset;
            if (zoneOffset != null && zoneOffset.TotalSeconds != offset.TotalSeconds)
            {
                throw new DateTimeException("ZoneOffset does not match zone: " + zone + " vs " + offset);
            }

            return new ZonedDateTime(localDateTime, zone);
        }

        public static ZonedDateTime from(TemporalAccessor temporal)
        {
            ZonedDateTime zoned = temporal as ZonedDateTime;
            if (zoned != null)
            {
                return zoned;
            }

            if (temporal is LocalDateTime)
            {
                throw new DateTimeException("Unable to obtain ZonedDateTime from LocalDateTime: need a ZoneId");
            }

            throw new DateTimeException("Unable to obtain ZonedDateTime from TemporalAccessor: " + temporal);
        }

        public static ZonedDateTime parse(string text)
        {
            return parse(text, DateTimeFormatter.ISO_ZONED_DATE_TIME);
        }

        public static ZonedDateTime parse(string text, DateTimeFormatter formatter)
        {
            if (formatter == null)
            {
                formatter = DateTimeFormatter.ISO_ZONED_DATE_TIME;
            }

            TemporalAccessor parsed = formatter.parse(text);
            ZonedDateTime zoned = parsed as ZonedDateTime;
            if (zoned != null)
            {
                return zoned;
            }

            throw new FormatException("Formatted parse did not produce ZonedDateTime: " + text);
        }

        public static ZonedDateTime now()
        {
            return now(ZoneId.systemDefault());
        }

        public static ZonedDateTime now(ZoneId zone)
        {
            DateTime utcNow = DateTime.UtcNow;