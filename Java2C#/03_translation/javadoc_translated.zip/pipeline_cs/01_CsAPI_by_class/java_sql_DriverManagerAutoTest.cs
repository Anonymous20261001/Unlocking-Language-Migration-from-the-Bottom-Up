namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class PrintStream
    {
        private TextWriter _writer;

        public PrintStream(TextWriter writer)
        {
            _writer = writer ?? throw new ArgumentNullException(nameof(writer));
        }

        public PrintStream(Stream stream)
        {
            _writer = new StreamWriter(stream);
        }

        public void println(string s)
        {
            _writer.WriteLine(s ?? "null");
        }

        public void print(string s)
        {
            _writer.Write(s ?? "null");
        }
    }

    public class PrintWriter
    {
        private TextWriter _writer;

        public PrintWriter(TextWriter writer)
        {
            _writer = writer ?? throw new ArgumentNullException(nameof(writer));
        }

        public PrintWriter(Stream stream)
        {
            _writer = new StreamWriter(stream);
        }

        public void println(string s)
        {
            _writer.WriteLine(s ?? "null");
        }

        public void print(string s)
        {
            _writer.Write(s ?? "null");
        }
    }

    public class Driver
    {
    }

    public class Enumeration<T>
    {
        private readonly List<T> items;
        private int index;

        public Enumeration(IEnumerable<T> source)
        {
            items = new List<T>(source ?? throw new ArgumentNullException(nameof(source)));
        }

        public bool hasMoreElements()
        {
            return index < items.Count;
        }

        public T nextElement()
        {
            if (index >= items.Count)
                throw new InvalidOperationException("No more elements");
            return items[index++];
        }
    }

    public static class DriverManager
    {
        private static PrintStream logStream;
        private static PrintWriter logWriter;
        private static int loginTimeout;
        private static readonly List<Driver> registeredDrivers = new List<Driver>();

        public static void setLogStream(PrintStream p0)
        {
            logStream = p0;
        }

        public static void println(string p0)
        {
            if (logWriter != null)
                logWriter.println(p0);
            else if (logStream != null)
                logStream.println(p0);
            else
                Console.WriteLine(p0);
        }

        public static PrintWriter getLogWriter()
        {
            return logWriter;
        }

        public static Enumeration<Driver> getDrivers()
        {
            return new Enumeration<Driver>(registeredDrivers);
        }

        public static void setLogWriter(PrintWriter p0)
        {
            logWriter = p0;
        }

        public static IEnumerable<Driver> drivers()
        {
            return registeredDrivers;
        }

        public static void setLoginTimeout(int p0)
        {
            loginTimeout = p0;
        }

        public static int getLoginTimeout()
        {
            return loginTimeout;
        }

        public static PrintStream getLogStream()
        {
            return logStream;
        }
    }

    public class java_sql_DriverManagerAutoTest
    {
        public void setLogStream_test_4342(PrintStream p0)
        {
            DriverManager.setLogStream(p0);
        }

        public void println_test_4343(string p0)
        {
            DriverManager.println(p0);
        }

        public void getLogWriter_test_4344()
        {
            DriverManager.getLogWriter();
        }

        public void getDrivers_test_4345()
        {
            DriverManager.getDrivers();
        }

        public void setLogWriter_test_4346(PrintWriter p0)
        {
            DriverManager.setLogWriter(p0);
        }

        public void drivers_test_4347()
        {
            DriverManager.drivers();
        }

        public void setLoginTimeout_test_4348(int p0)
        {
            DriverManager.setLoginTimeout(p0);
        }

        public void getLoginTimeout_test_4349()
        {
            DriverManager.getLoginTimeout();
        }

        public void getLogStream_test_4350()
        {
            DriverManager.getLogStream();
        }
    }
}