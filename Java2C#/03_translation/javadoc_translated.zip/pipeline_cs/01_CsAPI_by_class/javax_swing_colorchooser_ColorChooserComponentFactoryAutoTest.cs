namespace Generated.Test
{
    public class Component
    {
    }

    public static class ColorChooserComponentFactory
    {
        public static Component getPreviewPanel()
        {
            return new Component();
        }

        public static Component[] getDefaultChooserPanels()
        {
            return new Component[] { new Component(), new Component() };
        }
    }

    public class javax_swing_colorchooser_ColorChooserComponentFactoryAutoTest
    {
        public void getPreviewPanel_test_2491()
        {
            ColorChooserComponentFactory.getPreviewPanel();
        }

        public void getDefaultChooserPanels_test_2492()
        {
            ColorChooserComponentFactory.getDefaultChooserPanels();
        }
    }
}