namespace Generated.Test
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;

    public class Locale
    {
        public enum Category
        {
            DISPLAY,
            FORMAT
        }

        public enum FilteringMode
        {
            AUTOSELECT_FILTERING,
            EXTENDED_FILTERING,
            IGNORE_EXTENDED_RANGES,
            MAP_EXTENDED_RANGES,
            REJECT_EXTENDED_RANGES
        }

        public enum IsoCountryCode
        {
            PART1_ALPHA2,
            PART1_ALPHA3,
            PART3
        }

        private static Locale defaultLocale = new Locale("en", "US", "");

        private string language;
        private string country;
        private string variant;
        private string script;
        private Dictionary<char, string> extensions = new Dictionary<char, string>();
        private List<string> unicodeLocaleAttributes = new List<string>();
        private Dictionary<string, string> unicodeLocaleKeys = new Dictionary<string, string>();

        public Locale(string language)
            : this(language, "", "")
        {
        }

        public Locale(string language, string country)
            : this(language, country, "")
        {
        }

        public Locale(string language, string country, string variant)
        {
            this.language = language ?? "";
            this.country = country ?? "";
            this.variant = variant ?? "";
            this.script = "";
        }

        public static Locale of(string language)
        {
            return new Locale(language);
        }

        public static Locale of(string language, string country)
        {
            return new Locale(language, country);
        }

        public static Locale of(string language, string country, string variant)
        {
            return new Locale(language, country, variant);
        }

        public static Locale getDefault()
        {
            return defaultLocale;
        }

        public static Locale getDefault(Category category)
        {
            return defaultLocale;
        }

        public static void setDefault(Locale newLocale)
        {
            defaultLocale = newLocale ?? new Locale("en", "US", "");
        }

        public static void setDefault(Category category, Locale newLocale)
        {
            defaultLocale = newLocale ?? new Locale("en", "US", "");
        }

        public static Locale[] getAvailableLocales()
        {
            return new Locale[]
            {
                new Locale("en", "US", ""),
                new Locale("fr", "FR", ""),
                new Locale("de", "DE", ""),
                new Locale("es", "ES", "")
            };
        }

        public static IEnumerable<Locale> availableLocales()
        {
            return getAvailableLocales();
        }

        public static string[] getISOLanguages()
        {
            return new string[] { "en", "fr", "de", "es" };
        }

        public static string[] getISOCountries()
        {
            return new string[] { "US", "GB", "FR", "DE" };
        }

        public static ICollection<string> getISOCountries(IsoCountryCode code)
        {
            return new List<string>(getISOCountries());
        }

        public string getLanguage()
        {
            return language;
        }

        public string getCountry()
        {
            return country;
        }

        public string getVariant()
        {
            return variant;
        }

        public string getScript()
        {
            return script;
        }

        public bool hasExtensions()
        {
            return extensions.Count > 0 || unicodeLocaleKeys.Count > 0;
        }

        public Locale stripExtensions()
        {
            return new Locale(language, country, variant);
        }

        public string getExtension(char key)
        {
            return extensions.ContainsKey(key) ? extensions[key] : null;
        }

        public ICollection<char> getExtensionKeys()
        {
            return new List<char>(extensions.Keys);
        }

        public string getUnicodeLocaleType(string key)
        {
            return unicodeLocaleKeys.ContainsKey(key) ? unicodeLocaleKeys[key] : null;
        }

        public ICollection<string> getUnicodeLocaleAttributes()
        {
            return unicodeLocaleAttributes.AsReadOnly();
        }

        public ICollection<string> getUnicodeLocaleKeys()
        {
            return unicodeLocaleKeys.Keys.ToList().AsReadOnly();
        }

        public string getISO3Language()
        {
            var map = new Dictionary<string, string>
            {
                { "en", "eng" },
                { "fr", "fra" },
                { "de", "deu" },
                { "es", "spa" }
            };
            return map.ContainsKey(language) ? map[language] : language + "??";
        }

        public string getISO3Country()
        {
            var map = new Dictionary<string, string>
            {
                { "US", "USA" },
                { "GB", "GBR" },
                { "FR", "FRA" },
                { "DE", "DEU" }
            };
            return map.ContainsKey(country) ? map[country] : country + "??";
        }

        public string getDisplayName()
        {
            return ToString();
        }

        public string getDisplayName(Locale inLocale)
        {
            return ToString();
        }

        public string getDisplayLanguage()
        {
            return language;
        }

        public string getDisplayLanguage(Locale inLocale)
        {
            return language;
        }

        public string getDisplayScript()
        {
            return script;
        }

        public string getDisplayScript(Locale inLocale)
        {
            return script;
        }

        public string getDisplayCountry()
        {
            return country;
        }

        public string getDisplayCountry(Locale inLocale)
        {
            return country;
        }

        public string getDisplayVariant()
        {
            return variant;
        }

        public string getDisplayVariant(Locale inLocale)
        {
            return variant;
        }

        public string toLanguageTag()
        {
            string tag = language;
            if (!string.IsNullOrEmpty(script))
            {
                tag += "-" + script;
            }
            if (!string.IsNullOrEmpty(country))
            {
                tag += "-" + country;
            }
            if (!string.IsNullOrEmpty(variant))
            {
                tag += "-" + variant;
            }
            return tag;
        }

        public override string ToString()
        {
            string s = language;
            if (!string.IsNullOrEmpty(country))
            {
                s += "_" + country;
            }
            if (!string.IsNullOrEmpty(variant))
            {
                s += "_" + variant;
            }
            return s;
        }

        public static string caseFoldLanguageTag(string tag)
        {
            return tag == null ? null : tag.ToLowerInvariant();
        }

        public static Locale forLanguageTag(string tag)
        {
            Locale locale = new Locale("en", "US", "");
            if (!string.IsNullOrEmpty(tag))
            {
                string[] parts = tag.Split('-');
                if (parts.Length > 0 && parts[0].Length == 2)
                {
                    locale.language = parts[0].ToLowerInvariant();
                }
                if (parts.Length > 1 && parts[1].Length == 2)
                {
                    locale.country = parts[1].ToUpperInvariant();
                }
                if (parts.Length > 2)
                {
                    locale.variant = string.Join("-", parts.Skip(2));
                }
            }
            return locale;
        }

        public static Locale lookup(IList languageRange, ICollection locales)
        {
            if (locales == null)
            {
                return null;
            }
            foreach (object obj in locales)
            {
                if (obj is Locale)
                {
                    return (Locale)obj;
                }
            }
            return null;
        }

        public static IList<Locale> filter(IList languageRange, ICollection locales, FilteringMode mode)
        {
            List<Locale> result = new List<Locale>();
            if (locales == null)
            {
                return result;
            }
            foreach (object obj in locales)
            {
                if (obj is Locale)
                {
                    result.Add((Locale)obj);
                }
            }
            return result;
        }

        public static IList<Locale> filter(IList languageRange, ICollection locales)
        {
            return filter(languageRange, locales, FilteringMode.AUTOSELECT_FILTERING);
        }

        public static IList<string> filterTags(IList languageRange, ICollection tags, FilteringMode mode)
        {
            List<string> result = new List<string>();
            if (tags == null)
            {
                return result;
            }
            foreach (object obj in tags)
            {
                if (obj is string)
                {
                    result.Add((string)obj);
                }
            }
            return result;
        }

        public static IList<string> filterTags(IList languageRange, ICollection tags)
        {
            return filterTags(languageRange, tags, FilteringMode.AUTOSELECT_FILTERING);
        }

        public static string lookupTag(IList languageRange, ICollection tags)
        {
            if (tags == null)
            {
                return null;
            }
            foreach (object obj in tags)
            {
                if (obj is string)
                {
                    return (string)obj;
                }
            }
            return null;
        }
    }

    public class java_util_LocaleAutoTest
    {
        public void of_test_8014(string p0, string p1)
        {
            Locale.of(p0, p1);
        }

        public void of_test_8015(string p0, string p1, string p2)
        {
            Locale.of(p0, p1, p2);
        }

        public void of_test_8016(string p0)
        {
            Locale.of(p0);
        }

        public void getDefault_test_8017(Locale.Category p0)
        {
            Locale.getDefault(p0);
        }

        public void getDefault_test_8018()
        {
            Locale.getDefault();
        }

        public void lookup_test_8019(IList p0, ICollection p1)
        {
            Locale.lookup(p0, p1);
        }

        public void filter_test_8020(IList p0, ICollection p1, Locale.FilteringMode p2)
        {
            Locale.filter(p0, p1, p2);
        }

        public void filter_test_8021(IList p0, ICollection p1)
        {
            Locale.filter(p0, p1);
        }

        public void getLanguage_test_8022(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getLanguage();
        }

        public void getDisplayName_test_8023(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayName();
        }

        public void getDisplayName_test_8024(Locale p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayName(p0);
        }

        public void getAvailableLocales_test_8025()
        {
            Locale.getAvailableLocales();
        }

        public void getUnicodeLocaleType_test_8026(string p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getUnicodeLocaleType(p0);
        }

        public void getCountry_test_8027(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getCountry();
        }

        public void stripExtensions_test_8028(string c0)
        {
            Locale instance = new Locale(c0);
            instance.stripExtensions();
        }

        public void hasExtensions_test_8029(string c0)
        {
            Locale instance = new Locale(c0);
            instance.hasExtensions();
        }

        public void getVariant_test_8030(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getVariant();
        }

        public void setDefault_test_8031(Locale.Category p0, Locale p1)
        {
            Locale.setDefault(p0, p1);
        }

        public void setDefault_test_8032(Locale p0)
        {
            Locale.setDefault(p0);
        }

        public void getScript_test_8033(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getScript();
        }

        public void getUnicodeLocaleAttributes_test_8034(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getUnicodeLocaleAttributes();
        }

        public void getUnicodeLocaleKeys_test_8035(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getUnicodeLocaleKeys();
        }

        public void getDisplayLanguage_test_8036(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayLanguage();
        }

        public void getDisplayLanguage_test_8037(Locale p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayLanguage(p0);
        }

        public void getDisplayScript_test_8038(Locale p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayScript(p0);
        }

        public void getDisplayScript_test_8039(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayScript();
        }

        public void getDisplayCountry_test_8040(Locale p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayCountry(p0);
        }

        public void getDisplayCountry_test_8041(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayCountry();
        }

        public void getDisplayVariant_test_8042(Locale p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayVariant(p0);
        }

        public void getDisplayVariant_test_8043(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getDisplayVariant();
        }

        public void filterTags_test_8044(IList p0, ICollection p1)
        {
            Locale.filterTags(p0, p1);
        }

        public void filterTags_test_8045(IList p0, ICollection p1, Locale.FilteringMode p2)
        {
            Locale.filterTags(p0, p1, p2);
        }

        public void lookupTag_test_8046(IList p0, ICollection p1)
        {
            Locale.lookupTag(p0, p1);
        }

        public void availableLocales_test_8047()
        {
            Locale.availableLocales();
        }

        public void getISOCountries_test_8048(Locale.IsoCountryCode p0)
        {
            Locale.getISOCountries(p0);
        }

        public void getISOCountries_test_8049()
        {
            Locale.getISOCountries();
        }

        public void getISOLanguages_test_8050()
        {
            Locale.getISOLanguages();
        }

        public void getExtension_test_8051(char p0, string c0)
        {
            Locale instance = new Locale(c0);
            instance.getExtension(p0);
        }

        public void getExtensionKeys_test_8052(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getExtensionKeys();
        }

        public void toLanguageTag_test_8053(string c0)
        {
            Locale instance = new Locale(c0);
            instance.toLanguageTag();
        }

        public void caseFoldLanguageTag_test_8054(string p0)
        {
            Locale.caseFoldLanguageTag(p0);
        }

        public void forLanguageTag_test_8055(string p0)
        {
            Locale.forLanguageTag(p0);
        }

        public void getISO3Language_test_8056(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getISO3Language();
        }

        public void getISO3Country_test_8057(string c0)
        {
            Locale instance = new Locale(c0);
            instance.getISO3Country();
        }
    }
}