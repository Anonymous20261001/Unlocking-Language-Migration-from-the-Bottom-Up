```csharp
using System;

namespace Generated.Test
{
    public interface TemporalAccessor
    {
        int Year { get; }
        int Month { get; }
        int Day { get; }
    }

    public class ZoneId
    {
        public string Id { get; private set; }

        public ZoneId(string id)
        {
            Id = id;
        }

        public static ZoneId SystemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }

        public override string ToString()
        {
            return Id;
        }
    }

    public class Clock
    {
        public DateTime Instant { get; private set; }

        public Clock(DateTime instant)
        {
            Instant = instant;
        }

        public static Clock SystemUTC()
        {
            return new Clock(DateTime.UtcNow);
        }

        public static Clock SystemDefaultZone()
        {
            return new Clock(DateTime.Now);
        }
    }

    public class HijrahDate : TemporalAccessor
    {
        public int Year { get; private set; }
        public int Month { get; private set; }
        public int Day { get; private set; }

        private HijrahDate(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        public static HijrahDate Of(int year, int month, int day)
        {
            if (year < 1)
                throw new ArgumentOutOfRangeException("year");
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException("month");
            if (day < 1 || day > 30)
                throw new ArgumentOutOfRangeException("day");

            return new HijrahDate(year, month, day);
        }

        public static HijrahDate From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException("temporal");

            return new HijrahDate(temporal.Year, temporal.Month, temporal.Day);
        }

        public static HijrahDate Now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException("zone");

            return FromDateTime(DateTime.Now);
        }

        public static HijrahDate Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException("clock");

            return FromDateTime(clock.Instant);
        }

        public static HijrahDate Now()
        {
            return Now(ZoneId.SystemDefault());
        }

        private static HijrahDate FromDateTime(DateTime dt)
        {
            return new HijrahDate(dt.Year, dt.Month, dt.Day);
        }
    }

    public class java_time_chrono_HijrahDateAutoTest
    {
        public void of_test_5350(int p0, int p1, int p2)
        {
            HijrahDate.Of(p0, p1, p2);
        }

        public void from_test_5351(TemporalAccessor p0)
        {
            HijrahDate.From(p0);
        }

        public void now_test_5352(ZoneId p0)
        {
            HijrahDate.Now(p0);
        }

        public void now_test_5353(Clock p0)
        {
            HijrahDate.Now(p0);
        }

        public void now_test_5354()
        {
            HijrahDate.Now();
        }
    }
}
```