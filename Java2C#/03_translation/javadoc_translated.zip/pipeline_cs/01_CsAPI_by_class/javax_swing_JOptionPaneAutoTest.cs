using System;

namespace Generated.Test
{
    public class Component { }

    public class Frame : Component { }

    public class JDialog : Component { }

    public class JInternalFrame : Component { }

    public class JDesktopPane : Component { }

    public class Icon { }

    public class OptionPaneUI { }

    public class AccessibleContext { }

    public class JOptionPane
    {
        private OptionPaneUI ui;
        private Icon icon;
        private bool wantsInput;
        private object[] selectionValues;
        private object initialSelectionValue;
        private int messageType;
        private int optionType;
        private object initialValue;
        private object inputValue;
        private object message;
        private object[] options;
        private object value;
        private static Frame rootFrame;

        public JOptionPane() { }

        public string getUIClassID() { return "OptionPaneUI"; }

        public void updateUI() { ui = new OptionPaneUI(); }

        public OptionPaneUI getUI() { return ui; }

        public void setUI(OptionPaneUI p0) { ui = p0; }

        public AccessibleContext getAccessibleContext() { return new AccessibleContext(); }

        public Icon getIcon() { return icon; }

        public void setIcon(Icon p0) { icon = p0; }

        public JDialog createDialog(Component p0, string p1) { return new JDialog(); }

        public JDialog createDialog(string p0) { return new JDialog(); }

        public int getMaxCharactersPerLineCount() { return 0; }

        public bool getWantsInput() { return wantsInput; }

        public object[] getSelectionValues() { return selectionValues; }

        public object getInitialSelectionValue() { return initialSelectionValue; }

        public int getMessageType() { return messageType; }

        public int getOptionType() { return optionType; }

        public object getInitialValue() { return initialValue; }

        public void setInputValue(object p0) { inputValue = p0; }

        public void selectInitialValue() { }

        public void setWantsInput(bool p0) { wantsInput = p0; }

        public void setSelectionValues(object[] p0) { selectionValues = p0; }

        public void setInitialSelectionValue(object p0) { initialSelectionValue = p0; }

        public object getInputValue() { return inputValue; }

        public void setMessageType(int p0) { messageType = p0; }

        public void setOptionType(int p0) { optionType = p0; }

        public static void setRootFrame(Frame p0) { rootFrame = p0; }

        public void setMessage(object p0) { message = p0; }

        public void setOptions(object[] p0) { options = p0; }

        public object getValue() { return value; }

        public object getMessage() { return message; }

        public void setValue(object p0) { value = p0; }

        public void setInitialValue(object p0) { initialValue = p0; }

        public object[] getOptions() { return options; }

        public static string showInputDialog(object p0) { return null; }

        public static string showInputDialog(Component p0, object p1, string p2, int p3) { return null; }

        public static string showInputDialog(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6) { return null; }

        public static string showInputDialog(Component p0, object p1) { return null; }

        public static string showInputDialog(object p0, object p1) { return null; }

        public static string showInputDialog(Component p0, object p1, object p2) { return null; }

        public static void showMessageDialog(Component p0, object p1, string p2, int p3, Icon p4) { }

        public static void showMessageDialog(Component p0, object p1) { }

        public static void showMessageDialog(Component p0, object p1, string p2, int p3) { }

        public static int showOptionDialog(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7) { return 0; }

        public static int showConfirmDialog(Component p0, object p1, string p2, int p3) { return 0; }

        public static int showConfirmDialog(Component p0, object p1) { return 0; }

        public static int showConfirmDialog(Component p0, object p1, string p2, int p3, int p4, Icon p5) { return 0; }

        public static int showConfirmDialog(Component p0, object p1, string p2, int p3, int p4) { return 0; }

        public static void showInternalMessageDialog(Component p0, object p1, string p2, int p3, Icon p4) { }

        public static void showInternalMessageDialog(Component p0, object p1, string p2, int p3) { }

        public static void showInternalMessageDialog(Component p0, object p1) { }

        public static int showInternalOptionDialog(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7) { return 0; }

        public static int showInternalConfirmDialog(Component p0, object p1, string p2, int p3) { return 0; }

        public static int showInternalConfirmDialog(Component p0, object p1, string p2, int p3, int p4, Icon p5) { return 0; }

        public static int showInternalConfirmDialog(Component p0, object p1, string p2, int p3, int p4) { return 0; }

        public static int showInternalConfirmDialog(Component p0, object p1) { return 0; }

        public JInternalFrame createInternalFrame(Component p0, string p1) { return new JInternalFrame(); }

        public static object showInternalInputDialog(Component p0, object p1) { return null; }

        public static object showInternalInputDialog(Component p0, object p1, string p2, int p3) { return null; }

        public static object showInternalInputDialog(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6) { return null; }

        public static JDesktopPane getDesktopPaneForComponent(Component p0) { return new JDesktopPane(); }

        public static Frame getFrameForComponent(Component p0) { return new Frame(); }

        public static Frame getRootFrame()
        {
            if (rootFrame == null) rootFrame = new Frame();
            return rootFrame;
        }
    }

    public class javax_swing_JOptionPaneAutoTest
    {
        public void getUIClassID_test_6663()
        {
            JOptionPane instance = new JOptionPane();
            instance.getUIClassID();
        }

        public void updateUI_test_6664()
        {
            JOptionPane instance = new JOptionPane();
            instance.updateUI();
        }

        public void getUI_test_6665()
        {
            JOptionPane instance = new JOptionPane();
            instance.getUI();
        }

        public void setUI_test_6666(OptionPaneUI p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setUI(p0);
        }

        public void getAccessibleContext_test_6667()
        {
            JOptionPane instance = new JOptionPane();
            instance.getAccessibleContext();
        }

        public void getIcon_test_6668()
        {
            JOptionPane instance = new JOptionPane();
            instance.getIcon();
        }

        public void setIcon_test_6669(Icon p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setIcon(p0);
        }

        public void createDialog_test_6670(Component p0, string p1)
        {
            JOptionPane instance = new JOptionPane();
            instance.createDialog(p0, p1);
        }

        public void createDialog_test_6671(string p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.createDialog(p0);
        }

        public void getMaxCharactersPerLineCount_test_6672()
        {
            JOptionPane instance = new JOptionPane();
            instance.getMaxCharactersPerLineCount();
        }

        public void getWantsInput_test_6673()
        {
            JOptionPane instance = new JOptionPane();
            instance.getWantsInput();
        }

        public void getSelectionValues_test_6674()
        {
            JOptionPane instance = new JOptionPane();
            instance.getSelectionValues();
        }

        public void getInitialSelectionValue_test_6675()
        {
            JOptionPane instance = new JOptionPane();
            instance.getInitialSelectionValue();
        }

        public void getMessageType_test_6676()
        {
            JOptionPane instance = new JOptionPane();
            instance.getMessageType();
        }

        public void getOptionType_test_6677()
        {
            JOptionPane instance = new JOptionPane();
            instance.getOptionType();
        }

        public void getInitialValue_test_6678()
        {
            JOptionPane instance = new JOptionPane();
            instance.getInitialValue();
        }

        public void setInputValue_test_6679(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setInputValue(p0);
        }

        public void selectInitialValue_test_6680()
        {
            JOptionPane instance = new JOptionPane();
            instance.selectInitialValue();
        }

        public void showInputDialog_test_6681(object p0)
        {
            JOptionPane.showInputDialog(p0);
        }

        public void showInputDialog_test_6682(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showInputDialog(p0, p1, p2, p3);
        }

        public void showInputDialog_test_6683(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6)
        {
            JOptionPane.showInputDialog(p0, p1, p2, p3, p4, p5, p6);
        }

        public void showInputDialog_test_6684(Component p0, object p1)
        {
            JOptionPane.showInputDialog(p0, p1);
        }

        public void showInputDialog_test_6685(object p0, object p1)
        {
            JOptionPane.showInputDialog(p0, p1);
        }

        public void showInputDialog_test_6686(Component p0, object p1, object p2)
        {
            JOptionPane.showInputDialog(p0, p1, p2);
        }

        public void setWantsInput_test_6687(bool p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setWantsInput(p0);
        }

        public void setSelectionValues_test_6688(object[] p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setSelectionValues(p0);
        }

        public void setInitialSelectionValue_test_6689(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setInitialSelectionValue(p0);
        }

        public void getRootFrame_test_6690()
        {
            JOptionPane.getRootFrame();
        }

        public void getInputValue_test_6691()
        {
            JOptionPane instance = new JOptionPane();
            instance.getInputValue();
        }

        public void showMessageDialog_test_6692(Component p0, object p1, string p2, int p3, Icon p4)
        {
            JOptionPane.showMessageDialog(p0, p1, p2, p3, p4);
        }

        public void showMessageDialog_test_6693(Component p0, object p1)
        {
            JOptionPane.showMessageDialog(p0, p1);
        }

        public void showMessageDialog_test_6694(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showMessageDialog(p0, p1, p2, p3);
        }

        public void showOptionDialog_test_6695(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7)
        {
            JOptionPane.showOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void showConfirmDialog_test_6696(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showConfirmDialog(p0, p1, p2, p3);
        }

        public void showConfirmDialog_test_6697(Component p0, object p1)
        {
            JOptionPane.showConfirmDialog(p0, p1);
        }

        public void showConfirmDialog_test_6698(Component p0, object p1, string p2, int p3, int p4, Icon p5)
        {
            JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4, p5);
        }

        public void showConfirmDialog_test_6699(Component p0, object p1, string p2, int p3, int p4)
        {
            JOptionPane.showConfirmDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalMessageDialog_test_6700(Component p0, object p1, string p2, int p3, Icon p4)
        {
            JOptionPane.showInternalMessageDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalMessageDialog_test_6701(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showInternalMessageDialog(p0, p1, p2, p3);
        }

        public void showInternalMessageDialog_test_6702(Component p0, object p1)
        {
            JOptionPane.showInternalMessageDialog(p0, p1);
        }

        public void showInternalOptionDialog_test_6703(Component p0, object p1, string p2, int p3, int p4, Icon p5, object[] p6, object p7)
        {
            JOptionPane.showInternalOptionDialog(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void showInternalConfirmDialog_test_6704(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3);
        }

        public void showInternalConfirmDialog_test_6705(Component p0, object p1, string p2, int p3, int p4, Icon p5)
        {
            JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4, p5);
        }

        public void showInternalConfirmDialog_test_6706(Component p0, object p1, string p2, int p3, int p4)
        {
            JOptionPane.showInternalConfirmDialog(p0, p1, p2, p3, p4);
        }

        public void showInternalConfirmDialog_test_6707(Component p0, object p1)
        {
            JOptionPane.showInternalConfirmDialog(p0, p1);
        }

        public void createInternalFrame_test_6708(Component p0, string p1)
        {
            JOptionPane instance = new JOptionPane();
            instance.createInternalFrame(p0, p1);
        }

        public void showInternalInputDialog_test_6709(Component p0, object p1)
        {
            JOptionPane.showInternalInputDialog(p0, p1);
        }

        public void showInternalInputDialog_test_6710(Component p0, object p1, string p2, int p3)
        {
            JOptionPane.showInternalInputDialog(p0, p1, p2, p3);
        }

        public void showInternalInputDialog_test_6711(Component p0, object p1, string p2, int p3, Icon p4, object[] p5, object p6)
        {
            JOptionPane.showInternalInputDialog(p0, p1, p2, p3, p4, p5, p6);
        }

        public void getDesktopPaneForComponent_test_6712(Component p0)
        {
            JOptionPane.getDesktopPaneForComponent(p0);
        }

        public void getFrameForComponent_test_6713(Component p0)
        {
            JOptionPane.getFrameForComponent(p0);
        }

        public void setMessageType_test_6714(int p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setMessageType(p0);
        }

        public void setOptionType_test_6715(int p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setOptionType(p0);
        }

        public void setRootFrame_test_6716(Frame p0)
        {
            JOptionPane.setRootFrame(p0);
        }

        public void setMessage_test_6717(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setMessage(p0);
        }

        public void setOptions_test_6718(object[] p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setOptions(p0);
        }

        public void getValue_test_6719()
        {
            JOptionPane instance = new JOptionPane();
            instance.getValue();
        }

        public void getMessage_test_6720()
        {
            JOptionPane instance = new JOptionPane();
            instance.getMessage();
        }

        public void setValue_test_6721(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setValue(p0);
        }

        public void setInitialValue_test_6722(object p0)
        {
            JOptionPane instance = new JOptionPane();
            instance.setInitialValue(p0);
        }

        public void getOptions_test_6723()
        {
            JOptionPane instance = new JOptionPane();
            instance.getOptions();
        }
    }
}