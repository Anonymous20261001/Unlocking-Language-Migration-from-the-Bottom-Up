using System;
using System.IO;

namespace Generated.Test
{
    public class java_rmi_server_RemoteServerAutoTest
    {
        public void setLog_test_10522(Stream p0)
        {
            RemoteServer.setLog(p0);
        }

        public void getLog_test_10523()
        {
            RemoteServer.getLog();
        }
    }

    public static class RemoteServer
    {
        private static Stream _log;

        public static void setLog(Stream p0)
        {
            _log = p0;
        }

        public static Stream getLog()
        {
            return _log;
        }
    }
}