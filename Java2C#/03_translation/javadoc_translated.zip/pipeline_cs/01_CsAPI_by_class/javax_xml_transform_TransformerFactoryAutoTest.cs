namespace Generated.Test
{
    public class ClassLoader
    {
    }

    public abstract class TransformerFactory
    {
        protected TransformerFactory()
        {
        }

        public static TransformerFactory newDefaultInstance()
        {
            return new DefaultTransformerFactory();
        }

        public static TransformerFactory newInstance()
        {
            return new DefaultTransformerFactory();
        }

        public static TransformerFactory newInstance(string factoryClassName, ClassLoader classLoader)
        {
            return new DefaultTransformerFactory();
        }

        private sealed class DefaultTransformerFactory : TransformerFactory
        {
        }
    }

    public class javax_xml_transform_TransformerFactoryAutoTest
    {
        public void newDefaultInstance_test_12971()
        {
            TransformerFactory.newDefaultInstance();
        }

        public void newInstance_test_12972(string p0, ClassLoader p1)
        {
            TransformerFactory.newInstance(p0, p1);
        }

        public void newInstance_test_12973()
        {
            TransformerFactory.newInstance();
        }
    }
}