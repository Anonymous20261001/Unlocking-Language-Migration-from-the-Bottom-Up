using System;

namespace Generated.Test
{
    public class CollationElementIterator
    {
        public const int PRIMARYORDERMASK = unchecked((int)0xffff0000);
        public const int SECONDARYORDERMASK = 0x0000ff00;
        public const int TERTIARYORDERMASK = 0x000000ff;
        public const int NULLORDER = -1;

        public static int primaryOrder(int order)
        {
            return (order >> 16) & 0xffff;
        }

        public static int secondaryOrder(int order)
        {
            return (order & SECONDARYORDERMASK) >> 8;
        }

        public static int tertiaryOrder(int order)
        {
            return order & TERTIARYORDERMASK;
        }
    }

    public class java_text_CollationElementIteratorAutoTest
    {
        public void primaryOrder_test_2346(int p0)
        {
            CollationElementIterator.primaryOrder(p0);
        }

        public void secondaryOrder_test_2347(int p0)
        {
            CollationElementIterator.secondaryOrder(p0);
        }

        public void tertiaryOrder_test_2348(int p0)
        {
            CollationElementIterator.tertiaryOrder(p0);
        }
    }
}