namespace Generated.Test
{
    public class JdiExecutionControlProvider
    {
        public string name()
        {
            return "jdi";
        }

        public System.Collections.Generic.Dictionary<string, string> defaultParameters()
        {
            return new System.Collections.Generic.Dictionary<string, string>();
        }
    }

    public class jdk_jshell_execution_JdiExecutionControlProviderAutoTest
    {
        public void name_test_6148()
        {
            JdiExecutionControlProvider instance = new JdiExecutionControlProvider();
            instance.name();
        }

        public void defaultParameters_test_6149()
        {
            JdiExecutionControlProvider instance = new JdiExecutionControlProvider();
            instance.defaultParameters();
        }
    }
}