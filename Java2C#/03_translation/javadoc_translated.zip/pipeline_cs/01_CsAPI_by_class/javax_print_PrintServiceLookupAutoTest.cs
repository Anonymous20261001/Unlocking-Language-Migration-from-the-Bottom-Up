using System;

namespace Generated.Test
{
    public class DocFlavor
    {
    }

    public interface AttributeSet
    {
    }

    public interface PrintService
    {
    }

    public abstract class PrintServiceLookup
    {
        public static PrintService[] lookupPrintServices(DocFlavor flavor, AttributeSet attributes)
        {
            return null;
        }

        public static PrintService[] lookupMultiDocPrintServices(DocFlavor[] flavors, AttributeSet attributes)
        {
            return null;
        }

        public static PrintService lookupDefaultPrintService()
        {
            return null;
        }

        public static bool registerService(PrintService service)
        {
            return false;
        }

        public static bool registerServiceProvider(PrintServiceLookup provider)
        {
            return false;
        }
    }

    public class javax_print_PrintServiceLookupAutoTest
    {
        public void lookupPrintServices_test_10037(DocFlavor p0, AttributeSet p1)
        {
            PrintServiceLookup.lookupPrintServices(p0, p1);
        }

        public void lookupMultiDocPrintServices_test_10038(DocFlavor[] p0, AttributeSet p1)
        {
            PrintServiceLookup.lookupMultiDocPrintServices(p0, p1);
        }

        public void lookupDefaultPrintService_test_10039()
        {
            PrintServiceLookup.lookupDefaultPrintService();
        }

        public void registerService_test_10040(PrintService p0)
        {
            PrintServiceLookup.registerService(p0);
        }

        public void registerServiceProvider_test_10041(PrintServiceLookup p0)
        {
            PrintServiceLookup.registerServiceProvider(p0);
        }
    }
}