using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class javax_management_MBeanServerFactoryAutoTest
    {
        public void createMBeanServer_test_8442()
        {
            MBeanServerFactory.createMBeanServer();
        }

        public void createMBeanServer_test_8443(string p0)
        {
            MBeanServerFactory.createMBeanServer(p0);
        }

        public void newMBeanServer_test_8444(string p0)
        {
            MBeanServerFactory.newMBeanServer(p0);
        }

        public void newMBeanServer_test_8445()
        {
            MBeanServerFactory.newMBeanServer();
        }

        public void releaseMBeanServer_test_8446(MBeanServer p0)
        {
            MBeanServerFactory.releaseMBeanServer(p0);
        }

        public void findMBeanServer_test_8447(string p0)
        {
            MBeanServerFactory.findMBeanServer(p0);
        }

        public void getClassLoaderRepository_test_8448(MBeanServer p0)
        {
            MBeanServerFactory.getClassLoaderRepository(p0);
        }
    }

    public static class MBeanServerFactory
    {
        private static List<MBeanServer> servers = new List<MBeanServer>();
        private static int serverIdCounter = 0;

        public static MBeanServer createMBeanServer()
        {
            return createMBeanServer(null);
        }

        public static MBeanServer createMBeanServer(string domain)
        {
            MBeanServer server = new MBeanServer(domain, generateAgentId());
            servers.Add(server);
            return server;
        }

        public static MBeanServer newMBeanServer(string domain)
        {
            return new MBeanServer(domain, generateAgentId());
        }

        public static MBeanServer newMBeanServer()
        {
            return newMBeanServer(null);
        }

        public static void releaseMBeanServer(MBeanServer p0)
        {
            if (p0 != null)
            {
                servers.Remove(p0);
            }
        }

        public static List<MBeanServer> findMBeanServer(string agentId)
        {
            if (agentId == null)
            {
                return new List<MBeanServer>(servers);
            }

            List<MBeanServer> result = new List<MBeanServer>();
            foreach (MBeanServer server in servers)
            {
                if (server.AgentId == agentId)
                {
                    result.Add(server);
                }
            }
            return result;
        }

        public static ClassLoaderRepository getClassLoaderRepository(MBeanServer p0)
        {
            return new ClassLoaderRepository(p0);
        }

        private static string generateAgentId()
        {
            serverIdCounter++;
            return "mbean-server-" + serverIdCounter;
        }
    }

    public class MBeanServer
    {
        public string Domain { get; private set; }
        public string AgentId { get; private set; }

        public MBeanServer(string domain, string agentId)
        {
            Domain = domain ?? "DefaultDomain";
            AgentId = agentId;
        }
    }

    public class ClassLoaderRepository
    {
        private MBeanServer _server;

        public ClassLoaderRepository(MBeanServer server)
        {
            _server = server;
        }
    }
}