namespace Generated.Test
{
    public class FocusManager
    {
        private static FocusManager _currentManager;
        private static bool _swingFocusManagerEnabled = true;

        public static bool isFocusManagerEnabled()
        {
            return _swingFocusManagerEnabled;
        }

        public static void setCurrentManager(FocusManager p0)
        {
            _currentManager = p0;
        }

        public static FocusManager getCurrentManager()
        {
            if (_currentManager == null)
            {
                _currentManager = new FocusManager();
            }
            return _currentManager;
        }

        public static void disableSwingFocusManager()
        {
            _swingFocusManagerEnabled = false;
        }
    }

    public class javax_swing_FocusManagerAutoTest
    {
        public void isFocusManagerEnabled_test_4917()
        {
            FocusManager.isFocusManagerEnabled();
        }

        public void setCurrentManager_test_4918(FocusManager p0)
        {
            FocusManager.setCurrentManager(p0);
        }

        public void getCurrentManager_test_4919()
        {
            FocusManager.getCurrentManager();
        }

        public void disableSwingFocusManager_test_4920()
        {
            FocusManager.disableSwingFocusManager();
        }
    }
}