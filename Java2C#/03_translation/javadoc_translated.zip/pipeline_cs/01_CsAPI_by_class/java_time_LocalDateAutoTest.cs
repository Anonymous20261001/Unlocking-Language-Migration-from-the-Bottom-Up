using System;

namespace Generated.Test
{
    public enum Month
    {
        JANUARY = 1,
        FEBRUARY = 2,
        MARCH = 3,
        APRIL = 4,
        MAY = 5,
        JUNE = 6,
        JULY = 7,
        AUGUST = 8,
        SEPTEMBER = 9,
        OCTOBER = 10,
        NOVEMBER = 11,
        DECEMBER = 12
    }

    public interface CharSequence { }
    public interface TemporalAccessor { }

    public class DateTimeFormatter { }
    public class Clock { }
    public class ZoneId { }
    public class Instant { }

    public class LocalDate
    {
        public int Year { get; }
        public int Month { get; }
        public int Day { get; }

        public LocalDate() { }

        public LocalDate(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        public static LocalDate of(int year, int month, int dayOfMonth)
        {
            return new LocalDate(year, month, dayOfMonth);
        }

        public static LocalDate of(int year, Month month, int dayOfMonth)
        {
            return new LocalDate(year, (int)month, dayOfMonth);
        }

        public static LocalDate from(TemporalAccessor temporal)
        {
            return new LocalDate();
        }

        public static LocalDate parse(CharSequence text)
        {
            return new LocalDate();
        }

        public static LocalDate parse(CharSequence text, DateTimeFormatter formatter)
        {
            return new LocalDate();
        }

        public static LocalDate now()
        {
            return new LocalDate(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
        }

        public static LocalDate now(Clock clock)
        {
            return now();
        }

        public static LocalDate now(ZoneId zone)
        {
            return now();
        }

        public static LocalDate ofInstant(Instant instant, ZoneId zone)
        {
            return new LocalDate();
        }

        public static LocalDate ofEpochDay(long epochDay)
        {
            var epoch = new DateTime(1970, 1, 1);
            var date = epoch.AddDays(epochDay);
            return new LocalDate(date.Year, date.Month, date.Day);
        }

        public static LocalDate ofYearDay(int year, int dayOfYear)
        {
            var date = new DateTime(year, 1, 1).AddDays(dayOfYear - 1);
            return new LocalDate(date.Year, date.Month, date.Day);
        }
    }

    public class java_time_LocalDateAutoTest
    {
        public void of_test_7988(int p0, int p1, int p2)
        {
            LocalDate.of(p0, p1, p2);
        }

        public void of_test_7989(int p0, Month p1, int p2)
        {
            LocalDate.of(p0, p1, p2);
        }

        public void from_test_7990(TemporalAccessor p0)
        {
            LocalDate.from(p0);
        }

        public void parse_test_7991(CharSequence p0)
        {
            LocalDate.parse(p0);
        }

        public void parse_test_7992(CharSequence p0, DateTimeFormatter p1)
        {
            LocalDate.parse(p0, p1);
        }

        public void now_test_7993()
        {
            LocalDate.now();
        }

        public void now_test_7994(Clock p0)
        {
            LocalDate.now(p0);
        }

        public void now_test_7995(ZoneId p0)
        {
            LocalDate.now(p0);
        }

        public void ofInstant_test_7996(Instant p0, ZoneId p1)
        {
            LocalDate.ofInstant(p0, p1);
        }

        public void ofEpochDay_test_7997(long p0)
        {
            LocalDate.ofEpochDay(p0);
        }

        public void ofYearDay_test_7998(int p0, int p1)
        {
            LocalDate.ofYearDay(p0, p1);
        }
    }
}