using System;
using System.Collections;

namespace Generated.Test
{
    public abstract class RowFilter
    {
        private sealed class DefaultRowFilter : RowFilter
        {
        }

        public enum ComparisonType
        {
            BEFORE,
            AFTER,
            EQUAL
        }

        public static RowFilter regexFilter(string regex, params int[] indices)
        {
            return new DefaultRowFilter();
        }

        public static RowFilter dateFilter(ComparisonType comparisonType, DateTime date, params int[] indices)
        {
            return new DefaultRowFilter();
        }

        public static RowFilter numberFilter(ComparisonType comparisonType, object number, params int[] indices)
        {
            return new DefaultRowFilter();
        }

        public static RowFilter orFilter(IEnumerable filters)
        {
            return new DefaultRowFilter();
        }

        public static RowFilter andFilter(IEnumerable filters)
        {
            return new DefaultRowFilter();
        }

        public static RowFilter notFilter(RowFilter filter)
        {
            return new DefaultRowFilter();
        }
    }

    public class javax_swing_RowFilterAutoTest
    {
        public void regexFilter_test_10708(string p0, int[] p1)
        {
            RowFilter.regexFilter(p0, p1);
        }

        public void dateFilter_test_10709(RowFilter.ComparisonType p0, DateTime p1, int[] p2)
        {
            RowFilter.dateFilter(p0, p1, p2);
        }

        public void numberFilter_test_10710(RowFilter.ComparisonType p0, object p1, int[] p2)
        {
            RowFilter.numberFilter(p0, p1, p2);
        }

        public void orFilter_test_10711(IEnumerable p0)
        {
            RowFilter.orFilter(p0);
        }

        public void andFilter_test_10712(IEnumerable p0)
        {
            RowFilter.andFilter(p0);
        }

        public void notFilter_test_10713(RowFilter p0)
        {
            RowFilter.notFilter(p0);
        }
    }
}