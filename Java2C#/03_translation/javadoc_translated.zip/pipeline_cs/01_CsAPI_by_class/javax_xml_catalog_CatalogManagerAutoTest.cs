using System;

namespace Generated.Test
{
    public class javax_xml_catalog_CatalogManagerAutoTest
    {
        public void catalogResolver_test_2082(Catalog p0, CatalogResolver.NotFoundAction p1)
        {
            CatalogManager.catalogResolver(p0, p1);
        }

        public void catalogResolver_test_2083(CatalogFeatures p0, Uri[] p1)
        {
            CatalogManager.catalogResolver(p0, p1);
        }

        public void catalogResolver_test_2084(Catalog p0)
        {
            CatalogManager.catalogResolver(p0);
        }

        public void catalog_test_2085(CatalogFeatures p0, Uri[] p1)
        {
            CatalogManager.catalog(p0, p1);
        }
    }

    public static class CatalogManager
    {
        public static CatalogResolver catalogResolver(Catalog catalog, CatalogResolver.NotFoundAction action)
        {
            return new CatalogResolver();
        }

        public static CatalogResolver catalogResolver(CatalogFeatures features, Uri[] uris)
        {
            return new CatalogResolver();
        }

        public static CatalogResolver catalogResolver(Catalog catalog)
        {
            return new CatalogResolver();
        }

        public static Catalog catalog(CatalogFeatures features, Uri[] uris)
        {
            return new Catalog();
        }
    }

    public class Catalog
    {
    }

    public class CatalogFeatures
    {
    }

    public class CatalogResolver
    {
        public enum NotFoundAction
        {
            CONTINUE,
            TERMINATE
        }
    }
}