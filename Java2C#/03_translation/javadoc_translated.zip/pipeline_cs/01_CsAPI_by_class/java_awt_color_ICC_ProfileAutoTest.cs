namespace Generated.Test
{
    public class ICC_Profile
    {
        private ICC_Profile()
        {
        }

        public static ICC_Profile getInstance(int p0)
        {
            const int CS_sRGB = 1000;
            const int CS_CIEXYZ = 1001;
            const int CS_PYCC = 1002;
            const int CS_GRAY = 1003;
            const int CS_LINEAR_RGB = 1004;

            if (p0 == CS_sRGB || p0 == CS_CIEXYZ || p0 == CS_PYCC || p0 == CS_GRAY || p0 == CS_LINEAR_RGB)
            {
                return new ICC_Profile();
            }

            throw new System.ArgumentException("Invalid color space: " + p0);
        }

        public static ICC_Profile getInstance(byte[] p0)
        {
            if (p0 == null)
            {
                throw new System.ArgumentException("data is null");
            }

            if (p0.Length < 128)
            {
                throw new System.ArgumentException("Invalid ICC profile data");
            }

            return new ICC_Profile();
        }
    }

    public class java_awt_color_ICC_ProfileAutoTest
    {
        public void getInstance_test_5507(int p0)
        {
            ICC_Profile.getInstance(p0);
        }

        public void getInstance_test_5508(byte[] p0)
        {
            ICC_Profile.getInstance(p0);
        }
    }
}