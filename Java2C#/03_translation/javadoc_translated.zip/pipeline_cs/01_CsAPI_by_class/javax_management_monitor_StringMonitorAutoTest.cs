namespace Generated.Test
{
    public class ObjectName
    {
    }

    public class MBeanNotificationInfo
    {
    }

    public class StringMonitor
    {
        private string stringToCompare = "";
        private bool notifyMatch = false;
        private bool notifyDiffer = false;
        private bool active = false;

        public MBeanNotificationInfo[] getNotificationInfo()
        {
            return new MBeanNotificationInfo[0];
        }

        public string getDerivedGauge()
        {
            return null;
        }

        public string getDerivedGauge(ObjectName p0)
        {
            return null;
        }

        public long getDerivedGaugeTimeStamp()
        {
            return 0L;
        }

        public long getDerivedGaugeTimeStamp(ObjectName p0)
        {
            return 0L;
        }

        public string getStringToCompare()
        {
            return stringToCompare;
        }

        public void setStringToCompare(string p0)
        {
            stringToCompare = p0;
        }

        public bool getNotifyMatch()
        {
            return notifyMatch;
        }

        public void setNotifyMatch(bool p0)
        {
            notifyMatch = p0;
        }

        public bool getNotifyDiffer()
        {
            return notifyDiffer;
        }

        public void setNotifyDiffer(bool p0)
        {
            notifyDiffer = p0;
        }

        public void start()
        {
            active = true;
        }

        public void stop()
        {
            active = false;
        }
    }

    public class javax_management_monitor_StringMonitorAutoTest
    {
        public void getNotificationInfo_test_11889()
        {
            StringMonitor instance = new StringMonitor();
            instance.getNotificationInfo();
        }

        public void getDerivedGauge_test_11890()
        {
            StringMonitor instance = new StringMonitor();
            instance.getDerivedGauge();
        }

        public void getDerivedGauge_test_11891(ObjectName p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.getDerivedGauge(p0);
        }

        public void getDerivedGaugeTimeStamp_test_11892(ObjectName p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.getDerivedGaugeTimeStamp(p0);
        }

        public void getDerivedGaugeTimeStamp_test_11893()
        {
            StringMonitor instance = new StringMonitor();
            instance.getDerivedGaugeTimeStamp();
        }

        public void getStringToCompare_test_11894()
        {
            StringMonitor instance = new StringMonitor();
            instance.getStringToCompare();
        }

        public void setStringToCompare_test_11895(string p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.setStringToCompare(p0);
        }

        public void getNotifyMatch_test_11896()
        {
            StringMonitor instance = new StringMonitor();
            instance.getNotifyMatch();
        }

        public void setNotifyMatch_test_11897(bool p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.setNotifyMatch(p0);
        }

        public void getNotifyDiffer_test_11898()
        {
            StringMonitor instance = new StringMonitor();
            instance.getNotifyDiffer();
        }

        public void setNotifyDiffer_test_11899(bool p0)
        {
            StringMonitor instance = new StringMonitor();
            instance.setNotifyDiffer(p0);
        }

        public void start_test_11900()
        {
            StringMonitor instance = new StringMonitor();
            instance.start();
        }

        public void stop_test_11901()
        {
            StringMonitor instance = new StringMonitor();
            instance.stop();
        }
    }
}