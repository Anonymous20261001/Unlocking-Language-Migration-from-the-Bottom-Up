namespace Generated.Test
{
    public abstract class JComponent
    {
    }

    public abstract class ComponentUI
    {
        public static ComponentUI createUI(JComponent c)
        {
            return null;
        }
    }

    public class javax_swing_plaf_ComponentUIAutoTest
    {
        public void createUI_test_2673(JComponent p0)
        {
            ComponentUI.createUI(p0);
        }
    }
}