using System;

namespace Generated.Test
{
    public sealed class AlphaComposite
    {
        private static readonly AlphaComposite[] StandardCache = new AlphaComposite[13];

        public static AlphaComposite getInstance(int rule)
        {
            return getInstance(rule, 1.0f);
        }

        public static AlphaComposite getInstance(int rule, float alpha)
        {
            if (rule < 1 || rule > 12)
            {
                throw new ArgumentException("Unknown rule: " + rule);
            }

            if (alpha < 0.0f || alpha > 1.0f)
            {
                throw new ArgumentException("Alpha must be between 0.0 and 1.0");
            }

            if (alpha == 1.0f)
            {
                return StandardCache[rule] ?? (StandardCache[rule] = new AlphaComposite(rule, alpha));
            }

            return new AlphaComposite(rule, alpha);
        }

        private AlphaComposite(int rule, float alpha)
        {
            Rule = rule;
            Alpha = alpha;
        }

        public int Rule { get; private set; }
        public float Alpha { get; private set; }
    }

    public class java_awt_AlphaCompositeAutoTest
    {
        public void getInstance_test_144(int p0)
        {
            AlphaComposite.getInstance(p0);
        }

        public void getInstance_test_145(int p0, float p1)
        {
            AlphaComposite.getInstance(p0, p1);
        }
    }
}