using System.Collections.Generic;

namespace Generated.Test
{
    public class Class { }

    public interface DragSourceListener { }
    public interface DragSourceMotionListener { }
    public interface DragGestureListener { }
    public interface Transferable { }
    public interface FlavorMap { }

    public class Component { }
    public class Cursor { }
    public class Image { }

    public class Point
    {
        public int x;
        public int y;
    }

    public class DragGestureEvent { }
    public class DragGestureRecognizer { }

    public class DragSource
    {
        private static DragSource defaultDragSource = new DragSource();
        private List<DragSourceListener> listeners = new List<DragSourceListener>();
        private List<DragSourceMotionListener> motionListeners = new List<DragSourceMotionListener>();

        public static DragSource getDefaultDragSource()
        {
            return defaultDragSource;
        }

        public static bool isDragImageSupported()
        {
            return false;
        }

        public static int getDragThreshold()
        {
            return 0;
        }

        public void addDragSourceListener(DragSourceListener l)
        {
            if (l != null) listeners.Add(l);
        }

        public void removeDragSourceListener(DragSourceListener l)
        {
            listeners.Remove(l);
        }

        public DragSourceListener[] getDragSourceListeners()
        {
            return listeners.ToArray();
        }

        public void addDragSourceMotionListener(DragSourceMotionListener l)
        {
            if (l != null) motionListeners.Add(l);
        }

        public void removeDragSourceMotionListener(DragSourceMotionListener l)
        {
            motionListeners.Remove(l);
        }

        public DragSourceMotionListener[] getDragSourceMotionListeners()
        {
            return motionListeners.ToArray();
        }

        public object[] getListeners(Class listenerType)
        {
            var result = new List<object>();
            result.AddRange(listeners);
            result.AddRange(motionListeners);
            return result.ToArray();
        }

        public DragGestureRecognizer createDefaultDragGestureRecognizer(Component c, int actions, DragGestureListener dgl)
        {
            return new DragGestureRecognizer();
        }

        public DragGestureRecognizer createDragGestureRecognizer(Class recognizerAbstractClass, Component c, int actions, DragGestureListener dgl)
        {
            return new DragGestureRecognizer();
        }

        public void startDrag(DragGestureEvent trigger, Cursor cursor, Image image, Point offset, Transferable transferable, DragSourceListener dsListener)
        {
        }

        public void startDrag(DragGestureEvent trigger, Cursor cursor, Transferable transferable, DragSourceListener dsListener)
        {
        }

        public void startDrag(DragGestureEvent trigger, Cursor cursor, Image image, Point offset, Transferable transferable, DragSourceListener dsListener, FlavorMap flavorMap)
        {
        }

        public void startDrag(DragGestureEvent trigger, Cursor cursor, Transferable transferable, DragSourceListener dsListener, FlavorMap flavorMap)
        {
        }

        public FlavorMap getFlavorMap()
        {
            return null;
        }
    }

    public class java_awt_dnd_DragSourceAutoTest
    {
        public void addDragSourceListener_test_4296(DragSourceListener p0)
        {
            DragSource instance = new DragSource();
            instance.addDragSourceListener(p0);
        }

        public void addDragSourceMotionListener_test_4297(DragSourceMotionListener p0)
        {
            DragSource instance = new DragSource();
            instance.addDragSourceMotionListener(p0);
        }

        public void getDefaultDragSource_test_4298()
        {
            DragSource.getDefaultDragSource();
        }

        public void isDragImageSupported_test_4299()
        {
            DragSource.isDragImageSupported();
        }

        public void createDefaultDragGestureRecognizer_test_4300(Component p0, int p1, DragGestureListener p2)
        {
            DragSource instance = new DragSource();
            instance.createDefaultDragGestureRecognizer(p0, p1, p2);
        }

        public void removeDragSourceListener_test_4301(DragSourceListener p0)
        {
            DragSource instance = new DragSource();
            instance.removeDragSourceListener(p0);
        }

        public void getDragSourceListeners_test_4302()
        {
            DragSource instance = new DragSource();
            instance.getDragSourceListeners();
        }

        public void removeDragSourceMotionListener_test_4303(DragSourceMotionListener p0)
        {
            DragSource instance = new DragSource();
            instance.removeDragSourceMotionListener(p0);
        }

        public void getDragSourceMotionListeners_test_4304()
        {
            DragSource instance = new DragSource();
            instance.getDragSourceMotionListeners();
        }

        public void getDragThreshold_test_4305()
        {
            DragSource.getDragThreshold();
        }

        public void getListeners_test_4306(Class p0)
        {
            DragSource instance = new DragSource();
            instance.getListeners(p0);
        }

        public void createDragGestureRecognizer_test_4307(Class p0, Component p1, int p2, DragGestureListener p3)
        {
            DragSource instance = new DragSource();
            instance.createDragGestureRecognizer(p0, p1, p2, p3);
        }

        public void startDrag_test_4308(DragGestureEvent p0, Cursor p1, Image p2, Point p3, Transferable p4, DragSourceListener p5)
        {
            DragSource instance = new DragSource();
            instance.startDrag(p0, p1, p2, p3, p4, p5);
        }

        public void startDrag_test_4309(DragGestureEvent p0, Cursor p1, Transferable p2, DragSourceListener p3)
        {
            DragSource instance = new DragSource();
            instance.startDrag(p0, p1, p2, p3);
        }

        public void startDrag_test_4310(DragGestureEvent p0, Cursor p1, Image p2, Point p3, Transferable p4, DragSourceListener p5, FlavorMap p6)
        {
            DragSource instance = new DragSource();
            instance.startDrag(p0, p1, p2, p3, p4, p5, p6);
        }

        public void startDrag_test_4311(DragGestureEvent p0, Cursor p1, Transferable p2, DragSourceListener p3, FlavorMap p4)
        {
            DragSource instance = new DragSource();
            instance.startDrag(p0, p1, p2, p3, p4);
        }

        public void getFlavorMap_test_4312()
        {
            DragSource instance = new DragSource();
            instance.getFlavorMap();
        }
    }
}