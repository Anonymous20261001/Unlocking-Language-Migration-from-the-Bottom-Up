using System;
using System.IO;

namespace Generated.Test
{
    public class java_lang_ClassLoaderAutoTest
    {
        public void getPlatformClassLoader_test_2314()
        {
            ClassLoader.getPlatformClassLoader();
        }

        public void getSystemClassLoader_test_2315()
        {
            ClassLoader.getSystemClassLoader();
        }

        public void getSystemResourceAsStream_test_2316(string p0)
        {
            ClassLoader.getSystemResourceAsStream(p0);
        }

        public void getSystemResource_test_2317(string p0)
        {
            ClassLoader.getSystemResource(p0);
        }
    }

    public class ClassLoader
    {
        private static readonly ClassLoader systemClassLoader = new ClassLoader();
        private static readonly ClassLoader platformClassLoader = new ClassLoader();

        private ClassLoader()
        {
        }

        public static ClassLoader getPlatformClassLoader()
        {
            return platformClassLoader;
        }

        public static ClassLoader getSystemClassLoader()
        {
            return systemClassLoader;
        }

        public static Stream getSystemResourceAsStream(string name)
        {
            return null;
        }

        public static Uri getSystemResource(string name)
        {
            return null;
        }
    }
}