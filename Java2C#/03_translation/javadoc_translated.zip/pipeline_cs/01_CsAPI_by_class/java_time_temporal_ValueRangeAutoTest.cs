```csharp
using System;

namespace Generated.Test
{
    public class ValueRange
    {
        private readonly long minSmallest;
        private readonly long minLargest;
        private readonly long maxSmallest;
        private readonly long maxLargest;

        private ValueRange(long minSmallest, long minLargest, long maxSmallest, long maxLargest)
        {
            this.minSmallest = minSmallest;
            this.minLargest = minLargest;
            this.maxSmallest = maxSmallest;
            this.maxLargest = maxLargest;
        }

        public static ValueRange of(long min, long max)
        {
            if (min > max)
            {
                throw new ArgumentException("Minimum value must be less than maximum value");
            }
            return new ValueRange(min, min, max, max);
        }

        public static ValueRange of(long min, long max, long largestMax)
        {
            return of(min, max, min, largestMax);
        }

        public static ValueRange of(long min, long max, long largestMin, long largestMax)
        {
            if (min > max)
            {
                throw new ArgumentException("Minimum value must be less than maximum value");
            }
            if (largestMin > largestMax)
            {
                throw new ArgumentException("Smallest minimum value must be less than largest maximum value");
            }
            if (largestMin < min)
            {
                throw new ArgumentException("Smallest minimum value must be less than smallest maximum value");
            }
            if (largestMax < max)
            {
                throw new ArgumentException("Largest minimum value must be less than largest maximum value");
            }
            return new ValueRange(min, largestMin, max, largestMax);
        }

        public long getMinimum()
        {
            return minSmallest;
        }

        public long getLargestMinimum()
        {
            return minLargest;
        }

        public long getSmallestMaximum()
        {
            return maxSmallest;
        }

        public long getMaximum()
        {
            return maxLargest;
        }

        public bool isFixed()
        {
            return minSmallest == minLargest && maxSmallest == maxLargest;
        }

        public bool isValidValue(long value)
        {
            return value >= getMinimum() && value <= getMaximum();
        }

        public bool isValidIntValue(long value)
        {
            return isValidValue(value) && value >= int.MinValue && value <= int.MaxValue;
        }

        public override string ToString()
        {
            if (minSmallest == minLargest && maxSmallest == maxLargest)
            {
                return minSmallest + "-" + maxSmallest;
            }
            if (minSmallest == minLargest)
            {
                return minSmallest + "-" + maxSmallest + "/" + maxLargest;
            }
            if (maxSmallest == maxLargest)
            {
                return minSmallest + "/" + minLargest + "-" + maxSmallest;
            }
            return minSmallest + "/" + minLargest + "-" + maxSmallest + "/" + maxLargest;
        }
    }

    public class java_time_temporal_ValueRangeAutoTest
    {
        public void of_test_13306(long p0, long p1)
        {
            ValueRange.of(p0, p1);
        }

        public void of_test_13307(long p0, long p1, long p2, long p3)
        {
            ValueRange.of(p0, p1, p2, p3);
        }

        public void of_test_13308(long p0, long p1, long p2)
        {
            ValueRange.of(p0, p1, p2);
        }
    }
}
```