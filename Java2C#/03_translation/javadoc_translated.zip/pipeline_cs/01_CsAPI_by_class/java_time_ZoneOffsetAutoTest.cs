using System;
using System.Globalization;
using System.Text;

namespace Generated.Test
{
    public interface TemporalAccessor
    {
    }

    public class ZoneOffset : TemporalAccessor
    {
        private readonly int _totalSeconds;
        private readonly string _id;

        private ZoneOffset(int totalSeconds, string id)
        {
            _totalSeconds = totalSeconds;
            _id = id;
        }

        public static ZoneOffset of(string offsetId)
        {
            if (offsetId == null)
                throw new ArgumentNullException("offsetId");
            if (offsetId.Length == 0)
                throw new FormatException("Invalid offset ID: " + offsetId);
            if (offsetId == "Z")
                return new ZoneOffset(0, "Z");

            if (offsetId[0] != '+' && offsetId[0] != '-')
                throw new FormatException("Invalid offset ID: " + offsetId);

            bool negative = offsetId[0] == '-';
            string numeric = offsetId.Substring(1);
            int hours = 0;
            int minutes = 0;
            int seconds = 0;

            if (numeric.IndexOf(':') >= 0)
            {
                string[] parts = numeric.Split(':');
                if (parts.Length < 2 || parts.Length > 3)
                    throw new FormatException("Invalid offset ID: " + offsetId);
                hours = int.Parse(parts[0], CultureInfo.InvariantCulture);
                minutes = int.Parse(parts[1], CultureInfo.InvariantCulture);
                if (parts.Length == 3)
                    seconds = int.Parse(parts[2], CultureInfo.InvariantCulture);
            }
            else
            {
                int n = numeric.Length;
                if (n == 1 || n == 2)
                {
                    hours = int.Parse(numeric, CultureInfo.InvariantCulture);
                }
                else if (n == 3 || n == 4)
                {
                    hours = int.Parse(numeric.Substring(0, n - 2), CultureInfo.InvariantCulture);
                    minutes = int.Parse(numeric.Substring(n - 2), CultureInfo.InvariantCulture);
                }
                else if (n == 5 || n == 6)
                {
                    hours = int.Parse(numeric.Substring(0, n - 4), CultureInfo.InvariantCulture);
                    minutes = int.Parse(numeric.Substring(n - 4, 2), CultureInfo.InvariantCulture);
                    seconds = int.Parse(numeric.Substring(n - 2), CultureInfo.InvariantCulture);
                }
                else
                {
                    throw new FormatException("Invalid offset ID: " + offsetId);
                }
            }

            int total = hours * 3600 + minutes * 60 + seconds;
            if (negative)
                total = -total;
            return ofTotalSeconds(total);
        }

        public static ZoneOffset from(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException("temporal");
            ZoneOffset offset = temporal as ZoneOffset;
            if (offset != null)
                return offset;
            throw new NotSupportedException("Unable to obtain ZoneOffset from TemporalAccessor");
        }

        public static ZoneOffset ofHours(int hours)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentOutOfRangeException("hours", "Zone offset hours must be in the range -18 to +18");
            return ofHoursMinutesSeconds(hours, 0, 0);
        }

        public static ZoneOffset ofHoursMinutes(int hours, int minutes)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentOutOfRangeException("hours", "Zone offset hours must be in the range -18 to +18");
            if (minutes < -59 || minutes > 59)
                throw new ArgumentOutOfRangeException("minutes", "Zone offset minutes must be in the range -59 to +59");
            if (hours > 0 && minutes < 0)
                throw new ArgumentException("Zone offset hours and minutes must have the same sign");
            if (hours < 0 && minutes > 0)
                throw new ArgumentException("Zone offset hours and minutes must have the same sign");

            int total = hours * 3600 + minutes * 60;
            return ofTotalSeconds(total);
        }

        public static ZoneOffset ofHoursMinutesSeconds(int hours, int minutes, int seconds)
        {
            if (hours < -18 || hours > 18)
                throw new ArgumentOutOfRangeException("hours", "Zone offset hours must be in the range -18 to +18");
            if (minutes < -59 || minutes > 59)
                throw new ArgumentOutOfRangeException("minutes", "Zone offset minutes must be in the range -59 to +59");
            if (seconds < -59 || seconds > 59)
                throw new ArgumentOutOfRangeException("seconds", "Zone offset seconds must be in the range -59 to +59");

            if (hours > 0 && (minutes < 0 || seconds < 0))
                throw new ArgumentException("Zone offset hours, minutes and seconds must have the same sign");
            if (hours < 0 && (minutes > 0 || seconds > 0))
                throw new ArgumentException("Zone offset hours, minutes and seconds must have the same sign");
            if (minutes > 0 && seconds < 0)
                throw new ArgumentException("Zone offset minutes and seconds must have the same sign");
            if (minutes < 0 && seconds > 0)
                throw new ArgumentException("Zone offset minutes and seconds must have the same sign");

            int total = hours * 3600 + minutes * 60 + seconds;
            return ofTotalSeconds(total);
        }

        public static ZoneOffset ofTotalSeconds(int totalSeconds)
        {
            if (totalSeconds < -64800 || totalSeconds > 64800)
                throw new ArgumentOutOfRangeException("totalSeconds", "Zone offset total seconds must be in the range -64800 to +64800");
            return new ZoneOffset(totalSeconds, buildId(totalSeconds));
        }

        private static string buildId(int totalSeconds)
        {
            if (totalSeconds == 0)
                return "Z";

            bool negative = totalSeconds < 0;
            int abs = Math.Abs(totalSeconds);
            int absHours = abs / 3600;
            int absMinutes = (abs / 60) % 60;
            int absSeconds = abs % 60;

            StringBuilder sb = new StringBuilder();
            sb.Append(negative ? '-' : '+');
            sb.Append(absHours.ToString("00", CultureInfo.InvariantCulture));
            sb.Append(':');
            sb.Append(absMinutes.ToString("00", CultureInfo.InvariantCulture));

            if (absSeconds != 0)
            {
                sb.Append(':');
                sb.Append(absSeconds.ToString("00", CultureInfo.InvariantCulture));
            }

            return sb.ToString();
        }

        public override string ToString()
        {
            return _id;
        }
    }

    public class java_time_ZoneOffsetAutoTest
    {
        public void of_test_13728(string p0)
        {
            ZoneOffset.of(p0);
        }

        public void from_test_13729(TemporalAccessor p0)
        {
            ZoneOffset.from(p0);
        }

        public void ofHours_test_13730(int p0)
        {
            ZoneOffset.ofHours(p0);
        }

        public void ofHoursMinutesSeconds_test_13731(int p0, int p1, int p2)
        {
            ZoneOffset.ofHoursMinutesSeconds(p0, p1, p2);
        }

        public void ofTotalSeconds_test_13732(int p0)
        {
            ZoneOffset.ofTotalSeconds(p0);
        }

        public void ofHoursMinutes_test_13733(int p0, int p1)
        {
            ZoneOffset.ofHoursMinutes(p0, p1);
        }
    }
}