using System;

namespace Generated.Test
{
    public class ClassLoader
    {
    }

    public class XMLInputFactory
    {
        private XMLInputFactory()
        {
        }

        public static XMLInputFactory newDefaultFactory()
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory newInstance()
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory newInstance(string p0, ClassLoader p1)
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory newFactory(string p0, ClassLoader p1)
        {
            return new XMLInputFactory();
        }

        public static XMLInputFactory newFactory()
        {
            return new XMLInputFactory();
        }
    }

    public class javax_xml_stream_XMLInputFactoryAutoTest
    {
        public void newDefaultFactory_test_13634()
        {
            XMLInputFactory.newDefaultFactory();
        }

        public void newInstance_test_13635()
        {
            XMLInputFactory.newInstance();
        }

        public void newInstance_test_13636(string p0, ClassLoader p1)
        {
            XMLInputFactory.newInstance(p0, p1);
        }

        public void newFactory_test_13637(string p0, ClassLoader p1)
        {
            XMLInputFactory.newFactory(p0, p1);
        }

        public void newFactory_test_13638()
        {
            XMLInputFactory.newFactory();
        }
    }
}