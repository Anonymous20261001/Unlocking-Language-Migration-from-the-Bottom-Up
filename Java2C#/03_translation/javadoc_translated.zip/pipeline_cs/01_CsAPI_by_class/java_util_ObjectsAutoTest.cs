```csharp
using System;
using System.Runtime.CompilerServices;

namespace Generated.Test
{
    public interface Comparator
    {
        int Compare(object a, object b);
    }

    public interface Supplier
    {
        object Get();
    }

    public static class Objects
    {
        public static int CheckIndex(int index, int length)
        {
            if (index < 0 || index >= length)
                throw new ArgumentOutOfRangeException("index", "Index " + index + " out of bounds for length " + length);
            return index;
        }

        public static long CheckIndex(long index, long length)
        {
            if (index < 0 || index >= length)
                throw new ArgumentOutOfRangeException("index", "Index " + index + " out of bounds for length " + length);
            return index;
        }

        public static int Compare(object a, object b, Comparator cmp)
        {
            if (cmp == null)
                throw new NullReferenceException("Comparator must not be null");
            return cmp.Compare(a, b);
        }

        public static int Hash(params object[] values)
        {
            if (values == null)
                return 0;

            int result = 1;
            foreach (object value in values)
                result = 31 * result + (value == null ? 0 : value.GetHashCode());
            return result;
        }

        public static object RequireNonNull(object obj, Supplier supplier)
        {
            if (obj == null)
            {
                string message = supplier == null ? null : Convert.ToString(supplier.Get());
                throw new NullReferenceException(message);
            }
            return obj;
        }

        public static object RequireNonNull(object obj, string message)
        {
            if (obj == null)
                throw new NullReferenceException(message);
            return obj;
        }

        public static object RequireNonNull(object obj)
        {
            if (obj == null)
                throw new NullReferenceException();
            return obj;
        }

        public static int CheckFromToIndex(int fromIndex, int toIndex, int length)
        {
            if (fromIndex < 0 || toIndex < fromIndex || toIndex > length)
                throw new ArgumentOutOfRangeException("fromIndex", "Range [" + fromIndex + ", " + toIndex + ") out of bounds for length " + length);
            return fromIndex;
        }

        public static long CheckFromToIndex(long fromIndex, long toIndex, long length)
        {
            if (fromIndex < 0 || toIndex < fromIndex || toIndex > length)
                throw new ArgumentOutOfRangeException("fromIndex", "Range [" + fromIndex + ", " + toIndex + ") out of bounds for length " + length);
            return fromIndex;
        }

        public static int CheckFromIndexSize(int fromIndex, int size, int length)
        {
            if (length < 0 || fromIndex < 0 || fromIndex > length || size < 0 || size > length - fromIndex)
                throw new ArgumentOutOfRangeException("fromIndex", "Range [" + fromIndex + ", " + (fromIndex + size) + ") out of bounds for length " + length);
            return fromIndex;
        }

        public static long CheckFromIndexSize(long fromIndex, long size, long length)
        {
            if (length < 0 || fromIndex < 0 || fromIndex > length || size < 0 || size > length - fromIndex)
                throw new ArgumentOutOfRangeException("fromIndex", "Range [" + fromIndex + ", " + (fromIndex + size) + ") out of bounds for length " + length);
            return fromIndex;
        }

        public static bool DeepEquals(object a, object b)
        {
            if (a == b)
                return true;
            if (a == null || b == null)
                return false;

            if (a is Array arrA && b is Array arrB)
            {
                if (arrA.Rank != arrB.Rank)
                    return false;

                for (int i = 0; i < arrA.Rank; i++)
                {
                    if (arrA.GetLength(i) != arrB.GetLength(i))
                        return false;
                }

                int[] indices = new int[arrA.Rank];
                return DeepEqualsArrayRecursive(arrA, arrB, indices, 0);
            }

            return a.Equals(b);
        }

        private static bool DeepEqualsArrayRecursive(Array a, Array b, int[] indices, int dim)
        {
            if (dim == a.Rank)
            {
                object va = a.GetValue(indices);
                object vb = b.GetValue(indices);
                return DeepEquals(va, vb);
            }

            for (int i = 0; i < a.GetLength(dim); i++)
            {
                indices[dim] = i;
                if (!DeepEqualsArrayRecursive(a, b, indices, dim + 1))
                    return false;
            }

            return true;
        }

        public static string ToIdentityString(object o)
        {
            if (o == null)
                return null;

            return o.GetType().ToString() + "@" + RuntimeHelpers.GetHashCode(o).ToString("x");
        }

        public static bool IsNull(object o)
        {
            return o == null;
        }

        public static bool NonNull(object o)
        {
            return o != null;
        }

        public static object RequireNonNullElse(object obj, object defaultObj)
        {
            if (obj != null)
                return obj;
            if (defaultObj == null)
                throw new NullReferenceException();
            return defaultObj;
        }

        public static object RequireNonNullElseGet(object obj, Supplier supplier)
        {
            if (obj != null)
                return obj;
            if (supplier == null)
                throw new NullReferenceException();

            object value = supplier.Get();
            if (value == null)
                throw new NullReferenceException();
            return value;
        }
    }

    public class java_util_ObjectsAutoTest
    {
        public void checkIndex_test_9597(int p0, int p1)
        {
            Objects.CheckIndex(p0, p1);
        }

        public void checkIndex_test_9598(long p0, long p1)
        {
            Objects.CheckIndex(p0, p1);
        }

        public void compare_test_9599(object p0, object p1, Comparator p2)
        {
            Objects.Compare(p0, p1, p2);
        }

        public void hash_test_9600(object[] p0)
        {
            Objects.Hash(p0);
        }

        public void requireNonNull_test_9601(object p0, Supplier p1)
        {
            Objects.RequireNonNull(p0, p1);
        }

        public void requireNonNull_test_9602(object p0, string p1)
        {
            Objects.RequireNonNull(p0, p1);
        }

        public void requireNonNull_test_9603(object p0)
        {
            Objects.RequireNonNull(p0);
        }

        public void checkFromToIndex_test_9604(long p0, long p1, long p2)
        {
            Objects.CheckFromToIndex(p0, p1, p2);
        }

        public void checkFromToIndex_test_9605(int p0, int p1, int p2)
        {
            Objects.CheckFromToIndex(p0, p1, p2);
        }

        public void checkFromIndexSize_test_9606(int p0, int p1, int p2)
        {
            Objects.CheckFromIndexSize(p0, p1, p2);
        }

        public void checkFromIndexSize_test_9607(long p0, long p1, long p2)
        {
            Objects.CheckFromIndexSize(p0, p1, p2);
        }

        public void deepEquals_test_9608(object p0, object p1)
        {
            Objects.DeepEquals(p0, p1);
        }

        public void toIdentityString_test_9609(object p0)
        {
            Objects.ToIdentityString(p0);
        }

        public void isNull_test_9610(object p0)
        {
            Objects.IsNull(p0);
        }

        public void nonNull_test_9611(object p0)
        {
            Objects.NonNull(p0);
        }

        public void requireNonNullElse_test_9612(object p0, object p1)
        {
            Objects.RequireNonNullElse(p0, p1);
        }

        public void requireNonNullElseGet_test_9613(object p0, Supplier p1)
        {
            Objects.RequireNonNullElseGet(p0, p1);
        }
    }
}
```