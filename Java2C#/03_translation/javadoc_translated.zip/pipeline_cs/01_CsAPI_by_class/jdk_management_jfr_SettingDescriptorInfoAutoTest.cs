using System;
using javax.management.openmbean;
using jdk.management.jfr;

namespace javax.management.openmbean
{
    public interface CompositeData
    {
        object get(string key);
    }
}

namespace jdk.management.jfr
{
    public class SettingDescriptorInfo
    {
        private readonly string name;
        private readonly string label;
        private readonly string description;
        private readonly string typeName;
        private readonly string contentType;
        private readonly string defaultValue;
        private readonly string value;
        private readonly long lastModified;
        private readonly string minValue;
        private readonly string maxValue;

        private SettingDescriptorInfo(
            string name,
            string label,
            string description,
            string typeName,
            string contentType,
            string defaultValue,
            string value,
            long lastModified,
            string minValue,
            string maxValue)
        {
            this.name = name;
            this.label = label;
            this.description = description;
            this.typeName = typeName;
            this.contentType = contentType;
            this.defaultValue = defaultValue;
            this.value = value;
            this.lastModified = lastModified;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        public static SettingDescriptorInfo from(CompositeData cd)
        {
            if (cd == null)
            {
                throw new ArgumentNullException("cd");
            }

            string name = cd.get("name") as string;
            string label = cd.get("label") as string;
            string description = cd.get("description") as string;
            string typeName = cd.get("typeName") as string;
            string contentType = cd.get("contentType") as string;
            string defaultValue = cd.get("defaultValue") as string;
            string value = cd.get("value") as string;
            long lastModified = (long)cd.get("lastModified");
            string minValue = cd.get("minValue") as string;
            string maxValue = cd.get("maxValue") as string;

            return new SettingDescriptorInfo(
                name,
                label,
                description,
                typeName,
                contentType,
                defaultValue,
                value,
                lastModified,
                minValue,
                maxValue);
        }

        public string getName() => name;
        public string getLabel() => label;
        public string getDescription() => description;
        public string getTypeName() => typeName;
        public string getContentType() => contentType;
        public string getDefaultValue() => defaultValue;
        public string getValue() => value;
        public long getLastModified() => lastModified;
        public string getMinValue() => minValue;
        public string getMaxValue() => maxValue;
    }
}

namespace Generated.Test
{
    public class jdk_management_jfr_SettingDescriptorInfoAutoTest
    {
        public void from_test_11072(CompositeData p0)
        {
            SettingDescriptorInfo.from(p0);
        }
    }
}