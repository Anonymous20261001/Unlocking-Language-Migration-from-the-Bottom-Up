using System;

namespace Generated.Test
{
    public sealed class CoderResult
    {
        public static readonly CoderResult UNDERFLOW = new CoderResult(0, 0);
        public static readonly CoderResult OVERFLOW = new CoderResult(1, 0);

        private const int TYPE_MALFORMED = 2;
        private const int TYPE_UNMAPPABLE = 3;

        private readonly int type;
        private readonly int length;

        private CoderResult(int type, int length)
        {
            this.type = type;
            this.length = length;
        }

        public static CoderResult malformedForLength(int length)
        {
            return new CoderResult(TYPE_MALFORMED, length);
        }

        public static CoderResult unmappableForLength(int length)
        {
            return new CoderResult(TYPE_UNMAPPABLE, length);
        }

        public bool isUnderflow()
        {
            return type == 0;
        }

        public bool isOverflow()
        {
            return type == 1;
        }

        public bool isError()
        {
            return type == TYPE_MALFORMED || type == TYPE_UNMAPPABLE;
        }

        public bool isMalformed()
        {
            return type == TYPE_MALFORMED;
        }

        public bool isUnmappable()
        {
            return type == TYPE_UNMAPPABLE;
        }

        public int length()
        {
            if (!isError())
            {
                throw new NotSupportedException();
            }
            return length;
        }

        public override string ToString()
        {
            string name;
            if (type == 0)
                name = "UNDERFLOW";
            else if (type == 1)
                name = "OVERFLOW";
            else if (type == TYPE_MALFORMED)
                name = "MALFORMED";
            else if (type == TYPE_UNMAPPABLE)
                name = "UNMAPPABLE";
            else
                name = "UNKNOWN";

            return isError() ? name + "[" + length + "]" : name;
        }
    }

    public class java_nio_charset_CoderResultAutoTest
    {
        public void malformedForLength_test_2338(int p0)
        {
            CoderResult.malformedForLength(p0);
        }

        public void unmappableForLength_test_2339(int p0)
        {
            CoderResult.unmappableForLength(p0);
        }
    }
}