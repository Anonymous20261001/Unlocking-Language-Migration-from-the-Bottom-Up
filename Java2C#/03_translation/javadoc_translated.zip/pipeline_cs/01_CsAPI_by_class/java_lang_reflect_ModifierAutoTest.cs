namespace Generated.Test
{
    public class Modifier
    {
        public const int PUBLIC = 0x00000001;
        public const int PRIVATE = 0x00000002;
        public const int PROTECTED = 0x00000004;
        public const int STATIC = 0x00000008;
        public const int FINAL = 0x00000010;
        public const int SYNCHRONIZED = 0x00000020;
        public const int VOLATILE = 0x00000040;
        public const int TRANSIENT = 0x00000080;
        public const int NATIVE = 0x00000100;
        public const int INTERFACE = 0x00000200;
        public const int ABSTRACT = 0x00000400;
        public const int STRICT = 0x00000800;

        public static bool isInterface(int mod)
        {
            return (mod & INTERFACE) != 0;
        }

        public static bool isFinal(int mod)
        {
            return (mod & FINAL) != 0;
        }

        public static bool isPublic(int mod)
        {
            return (mod & PUBLIC) != 0;
        }

        public static bool isStatic(int mod)
        {
            return (mod & STATIC) != 0;
        }

        public static bool isProtected(int mod)
        {
            return (mod & PROTECTED) != 0;
        }

        public static bool isAbstract(int mod)
        {
            return (mod & ABSTRACT) != 0;
        }

        public static bool isVolatile(int mod)
        {
            return (mod & VOLATILE) != 0;
        }

        public static bool isPrivate(int mod)
        {
            return (mod & PRIVATE) != 0;
        }

        public static bool isNative(int mod)
        {
            return (mod & NATIVE) != 0;
        }

        public static bool isSynchronized(int mod)
        {
            return (mod & SYNCHRONIZED) != 0;
        }

        public static bool isTransient(int mod)
        {
            return (mod & TRANSIENT) != 0;
        }

        public static bool isStrict(int mod)
        {
            return (mod & STRICT) != 0;
        }

        public static int classModifiers()
        {
            return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | FINAL | STRICT;
        }

        public static int interfaceModifiers()
        {
            return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | STRICT;
        }

        public static int methodModifiers()
        {
            return PUBLIC | PROTECTED | PRIVATE | ABSTRACT | STATIC | FINAL | SYNCHRONIZED | NATIVE | STRICT;
        }

        public static int constructorModifiers()
        {
            return PUBLIC | PROTECTED | PRIVATE;
        }

        public static int fieldModifiers()
        {
            return PUBLIC | PROTECTED | PRIVATE | STATIC | FINAL | TRANSIENT | VOLATILE;
        }

        public static int parameterModifiers()
        {
            return FINAL;
        }
    }

    public class java_lang_reflect_ModifierAutoTest
    {
        public void isInterface_test_8971(int p0)
        {
            Modifier.isInterface(p0);
        }

        public void classModifiers_test_8972()
        {
            Modifier.classModifiers();
        }

        public void isFinal_test_8973(int p0)
        {
            Modifier.isFinal(p0);
        }

        public void isPublic_test_8974(int p0)
        {
            Modifier.isPublic(p0);
        }

        public void isStatic_test_8975(int p0)
        {
            Modifier.isStatic(p0);
        }

        public void isProtected_test_8976(int p0)
        {
            Modifier.isProtected(p0);
        }

        public void methodModifiers_test_8977()
        {
            Modifier.methodModifiers();
        }

        public void constructorModifiers_test_8978()
        {
            Modifier.constructorModifiers();
        }

        public void isAbstract_test_8979(int p0)
        {
            Modifier.isAbstract(p0);
        }

        public void isVolatile_test_8980(int p0)
        {
            Modifier.isVolatile(p0);
        }

        public void isPrivate_test_8981(int p0)
        {
            Modifier.isPrivate(p0);
        }

        public void isNative_test_8982(int p0)
        {
            Modifier.isNative(p0);
        }

        public void isSynchronized_test_8983(int p0)
        {
            Modifier.isSynchronized(p0);
        }

        public void isTransient_test_8984(int p0)
        {
            Modifier.isTransient(p0);
        }

        public void isStrict_test_8985(int p0)
        {
            Modifier.isStrict(p0);
        }

        public void interfaceModifiers_test_8986()
        {
            Modifier.interfaceModifiers();
        }

        public void fieldModifiers_test_8987()
        {
            Modifier.fieldModifiers();
        }

        public void parameterModifiers_test_8988()
        {
            Modifier.parameterModifiers();
        }
    }
}