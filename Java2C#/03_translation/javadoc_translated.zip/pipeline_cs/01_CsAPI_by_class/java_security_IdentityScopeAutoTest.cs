using System;

namespace java.security
{
    public class IdentityScope
    {
        public static IdentityScope GetSystemScope()
        {
            return null;
        }
    }
}

namespace generated.test
{
    public class java_security_IdentityScopeAutoTest
    {
        public void getSystemScope_test_5532()
        {
            java.security.IdentityScope.GetSystemScope();
        }
    }
}