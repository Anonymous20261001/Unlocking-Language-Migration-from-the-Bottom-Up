using System;

namespace Generated.Test
{
    public class Component
    {
    }

    public class DataFlavor
    {
        private readonly string mimeType;
        private readonly string humanPresentableName;

        public DataFlavor(string mimeType, string humanPresentableName)
        {
            this.mimeType = mimeType;
            this.humanPresentableName = humanPresentableName;
        }

        public string MimeType
        {
            get { return mimeType; }
        }

        public string HumanPresentableName
        {
            get { return humanPresentableName; }
        }

        public override bool Equals(object obj)
        {
            DataFlavor other = obj as DataFlavor;
            if (other == null)
            {
                return false;
            }
            return mimeType == other.mimeType && humanPresentableName == other.humanPresentableName;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 23 + (mimeType != null ? mimeType.GetHashCode() : 0);
            hash = hash * 23 + (humanPresentableName != null ? humanPresentableName.GetHashCode() : 0);
            return hash;
        }

        public override string ToString()
        {
            return humanPresentableName;
        }
    }

    public interface Transferable
    {
        DataFlavor[] getTransferDataFlavors();
        bool isDataFlavorSupported(DataFlavor flavor);
        object getTransferData(DataFlavor flavor);
    }

    public class TransferHandler
    {
        public const int NONE = 0;
        public const int COPY = 1;
        public const int MOVE = 2;
        public const int LINK = 0x40000000;

        public class DropLocation
        {
        }

        public class TransferSupport
        {
            private readonly Component component;
            private readonly Transferable transferable;
            private bool isDrop;
            private int dropAction;
            private int sourceDropActions;
            private int userDropAction;
            private bool showDropLocation;
            private DropLocation dropLocation;

            public TransferSupport(Component component, Transferable transferable)
            {
                if (component == null)
                {
                    throw new NullReferenceException("component");
                }
                if (transferable == null)
                {
                    throw new NullReferenceException("transferable");
                }
                this.component = component;
                this.transferable = transferable;
                this.isDrop = false;
                this.dropAction = NONE;
                this.sourceDropActions = 0;
                this.userDropAction = 0;
                this.showDropLocation = false;
                this.dropLocation = null;
            }

            public TransferSupport(Component component, int dropAction, DropLocation dropLocation, Transferable transferable)
            {
                if (component == null)
                {
                    throw new NullReferenceException("component");
                }
                if (transferable == null)
                {
                    throw new NullReferenceException("transferable");
                }
                this.component = component;
                this.transferable = transferable;
                this.isDrop = true;
                this.dropAction = dropAction;
                this.dropLocation = dropLocation;
                this.sourceDropActions = 0;
                this.userDropAction = 0;
                this.showDropLocation = false;
            }

            public Transferable getTransferable()
            {
                return transferable;
            }

            public DataFlavor[] getDataFlavors()
            {
                return transferable.getTransferDataFlavors();
            }

            public DropLocation getDropLocation()
            {
                if (!isDrop)
                {
                    throw new InvalidOperationException("getDropLocation is not supported for non-drop transfers");
                }
                return dropLocation;
            }

            public bool isDrop()
            {
                return isDrop;
            }

            public int getDropAction()
            {
                return dropAction;
            }

            public int getSourceDropActions()
            {
                return sourceDropActions;
            }

            public int getUserDropAction()
            {
                return userDropAction;
            }

            public void setShowDropLocation(bool showDropLocation)
            {
                this.showDropLocation = showDropLocation;
            }

            public bool isShowDropLocation()
            {
                return showDropLocation;
            }

            public void setDropAction(int dropAction)
            {
                if (dropAction != NONE && dropAction != COPY && dropAction != MOVE && dropAction != LINK)
                {
                    throw new ArgumentException("Invalid drop action");
                }
                if (!isDrop)
                {
                    throw new InvalidOperationException("Can not set drop action on non-drop");
                }
                this.dropAction = dropAction;
            }

            public bool isDataFlavorSupported(DataFlavor flavor)
            {
                if (flavor == null)
                {
                    throw new NullReferenceException("flavor");
                }
                DataFlavor[] flavors = getDataFlavors();
                for (int i = 0; i < flavors.Length; i++)
                {
                    if (flavors[i].Equals(flavor))
                    {
                        return true;
                    }
                }
                return false;
            }

            public Component getComponent()
            {
                return component;
            }
        }
    }

    public class javax_swing_TransferHandler_TransferSupportAutoTest
    {
        public void getTransferable_test_12948(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getTransferable();
        }

        public void getDataFlavors_test_12949(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getDataFlavors();
        }

        public void getDropLocation_test_12950(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getDropLocation();
        }

        public void isDrop_test_12951(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.isDrop();
        }

        public void getDropAction_test_12952(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getDropAction();
        }

        public void getSourceDropActions_test_12953(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getSourceDropActions();
        }

        public void getUserDropAction_test_12954(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getUserDropAction();
        }

        public void setShowDropLocation_test_12955(bool p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.setShowDropLocation(p0);
        }

        public void setDropAction_test_12956(int p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.setDropAction(p0);
        }

        public void isDataFlavorSupported_test_12957(DataFlavor p0, Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.isDataFlavorSupported(p0);
        }

        public void getComponent_test_12958(Component c0, Transferable c1)
        {
            TransferHandler.TransferSupport instance = new TransferHandler.TransferSupport(c0, c1);
            instance.getComponent();
        }
    }
}