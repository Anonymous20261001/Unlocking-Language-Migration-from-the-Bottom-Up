namespace Generated.Test
{
    public class Locale
    {
        public string Language { get; private set; }
        public string Country { get; private set; }
        public string Variant { get; private set; }

        public Locale(string language)
            : this(language, "", "")
        {
        }

        public Locale(string language, string country)
            : this(language, country, "")
        {
        }

        public Locale(string language, string country, string variant)
        {
            Language = language ?? "";
            Country = country ?? "";
            Variant = variant ?? "";
        }

        public static Locale ROOT
        {
            get { return new Locale("", "", ""); }
        }

        public static Locale ENGLISH
        {
            get { return new Locale("en"); }
        }

        public static Locale US
        {
            get { return new Locale("en", "US"); }
        }
    }

    public class Module
    {
    }

    public class ClassLoader
    {
    }

    public abstract class ResourceBundle
    {
        protected ResourceBundle()
        {
        }

        public abstract class Control
        {
            protected Control()
            {
            }
        }

        private sealed class SimpleResourceBundle : ResourceBundle
        {
        }

        public static ResourceBundle getBundle(string baseName)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Locale locale)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Module module)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Control control)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Locale locale, ClassLoader loader)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Locale locale, ClassLoader loader, Control control)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Locale locale, Control control)
        {
            return new SimpleResourceBundle();
        }

        public static ResourceBundle getBundle(string baseName, Locale locale, Module module)
        {
            return new SimpleResourceBundle();
        }

        public static void clearCache()
        {
        }

        public static void clearCache(ClassLoader loader)
        {
        }
    }

    public class java_util_ResourceBundleAutoTest
    {
        public void getBundle_test_10610(string p0, Locale p1)
        {
            ResourceBundle.getBundle(p0, p1);
        }

        public void getBundle_test_10611(string p0, Module p1)
        {
            ResourceBundle.getBundle(p0, p1);
        }

        public void getBundle_test_10612(string p0, ResourceBundle.Control p1)
        {
            ResourceBundle.getBundle(p0, p1);
        }

        public void getBundle_test_10613(string p0)
        {
            ResourceBundle.getBundle(p0);
        }

        public void getBundle_test_10614(string p0, Locale p1, ClassLoader p2)
        {
            ResourceBundle.getBundle(p0, p1, p2);
        }

        public void getBundle_test_10615(string p0, Locale p1, ClassLoader p2, ResourceBundle.Control p3)
        {
            ResourceBundle.getBundle(p0, p1, p2, p3);
        }

        public void getBundle_test_10616(string p0, Locale p1, ResourceBundle.Control p2)
        {
            ResourceBundle.getBundle(p0, p1, p2);
        }

        public void getBundle_test_10617(string p0, Locale p1, Module p2)
        {
            ResourceBundle.getBundle(p0, p1, p2);
        }

        public void clearCache_test_10618(ClassLoader p0)
        {
            ResourceBundle.clearCache(p0);
        }

        public void clearCache_test_10619()
        {
            ResourceBundle.clearCache();
        }
    }
}