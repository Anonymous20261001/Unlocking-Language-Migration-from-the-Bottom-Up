using System;

namespace Generated.Test
{
    public class ByteBuffer
    {
        private readonly byte[] _array;
        private readonly int _offset;
        private readonly int _length;
        private readonly bool _isDirect;

        private ByteBuffer(byte[] array, int offset, int length, bool isDirect)
        {
            _array = array;
            _offset = offset;
            _length = length;
            _isDirect = isDirect;
        }

        public static ByteBuffer wrap(byte[] array, int offset, int length)
        {
            if (array == null)
                throw new NullReferenceException();
            if (offset < 0 || length < 0 || offset > array.Length - length)
                throw new IndexOutOfRangeException();
            return new ByteBuffer(array, offset, length, false);
        }

        public static ByteBuffer wrap(byte[] array)
        {
            if (array == null)
                throw new NullReferenceException();
            return wrap(array, 0, array.Length);
        }

        public static ByteBuffer allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");
            return new ByteBuffer(new byte[capacity], 0, capacity, false);
        }

        public static ByteBuffer allocateDirect(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");
            return new ByteBuffer(new byte[capacity], 0, capacity, true);
        }
    }

    public class java_nio_ByteBufferAutoTest
    {
        public void wrap_test_2000(byte[] p0, int p1, int p2)
        {
            ByteBuffer.wrap(p0, p1, p2);
        }

        public void wrap_test_2001(byte[] p0)
        {
            ByteBuffer.wrap(p0);
        }

        public void allocate_test_2002(int p0)
        {
            ByteBuffer.allocate(p0);
        }

        public void allocateDirect_test_2003(int p0)
        {
            ByteBuffer.allocateDirect(p0);
        }
    }
}