namespace Generated.Test
{
    public class SocketFactory
    {
        public static SocketFactory getDefault()
        {
            return new SocketFactory();
        }
    }

    public class javax_net_SocketFactoryAutoTest
    {
        public void getDefault_test_11262()
        {
            SocketFactory.getDefault();
        }
    }
}