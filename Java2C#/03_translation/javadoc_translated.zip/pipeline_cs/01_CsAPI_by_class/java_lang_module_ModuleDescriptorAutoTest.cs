using System;
using System.Collections;

namespace Generated.Test
{
    public class ByteBuffer
    {
        // Minimal placeholder for java.nio.ByteBuffer
    }

    public interface Supplier
    {
        object get();
    }

    public interface Set : IEnumerable
    {
    }

    public class ModuleDescriptor
    {
        public static ModuleDescriptor read(ByteBuffer p0, Supplier p1)
        {
            return new ModuleDescriptor();
        }

        public static ModuleDescriptor read(ByteBuffer p0)
        {
            return new ModuleDescriptor();
        }

        public static ModuleDescriptor newModule(string p0, Set p1)
        {
            return new ModuleDescriptor();
        }

        public static ModuleDescriptor newModule(string p0)
        {
            return new ModuleDescriptor();
        }

        public static ModuleDescriptor newOpenModule(string p0)
        {
            return new ModuleDescriptor();
        }

        public static ModuleDescriptor newAutomaticModule(string p0)
        {
            return new ModuleDescriptor();
        }
    }

    public class java_lang_module_ModuleDescriptorAutoTest
    {
        public void read_test_8989(ByteBuffer p0, Supplier p1)
        {
            ModuleDescriptor.read(p0, p1);
        }

        public void read_test_8990(ByteBuffer p0)
        {
            ModuleDescriptor.read(p0);
        }

        public void newModule_test_8991(string p0, Set p1)
        {
            ModuleDescriptor.newModule(p0, p1);
        }

        public void newModule_test_8992(string p0)
        {
            ModuleDescriptor.newModule(p0);
        }

        public void newOpenModule_test_8993(string p0)
        {
            ModuleDescriptor.newOpenModule(p0);
        }

        public void newAutomaticModule_test_8994(string p0)
        {
            ModuleDescriptor.newAutomaticModule(p0);
        }
    }
}