namespace Generated.Test
{
    public sealed class FileTime
    {
        private readonly long _millis;

        private FileTime(long millis)
               {
            _millis = millis;
        }

        public static FileTime from(Instant instant)
        {
            if (instant == null)
            {
                throw new System.ArgumentNullException("instant");
            }
            return new FileTime(instant.ToEpochMilli());
        }

        public static FileTime from(long value, TimeUnit unit)
        {
            if (unit == null)
            {
                throw new System.ArgumentNullException("unit");
            }
            return new FileTime(unit.ToMillis(value));
        }

        public static FileTime fromMillis(long value)
        {
            return new FileTime(value);
        }

        public long ToMillis()
        {
            return _millis;
        }
    }

    public sealed class Instant
    {
        private readonly long _epochMilli;

        private Instant(long epochMilli)
        {
            _epochMilli = epochMilli;
        }

        public static Instant OfEpochMilli(long epochMilli)
        {
            return new Instant(epochMilli);
        }

        public long ToEpochMilli()
        {
            return _epochMilli;
        }
    }

    public sealed class TimeUnit
    {
        public static readonly TimeUnit NANOSECONDS = new TimeUnit("NANOSECONDS", 1L);
        public static readonly TimeUnit MICROSECONDS = new TimeUnit("MICROSECONDS", 1000L);
        public static readonly TimeUnit MILLISECONDS = new TimeUnit("MILLISECONDS", 1000000L);
        public static readonly TimeUnit SECONDS = new TimeUnit("SECONDS", 1000000000L);
        public static readonly TimeUnit MINUTES = new TimeUnit("MINUTES", 60000000000L);
        public static readonly TimeUnit HOURS = new TimeUnit("HOURS", 3600000000000L);
        public static readonly TimeUnit DAYS = new TimeUnit("DAYS", 86400000000000L);

        private readonly string _name;
        private readonly long _nanos;

        private TimeUnit(string name, long nanos)
        {
            _name = name;
            _nanos = nanos;
        }

        public string Name
        {
            get { return _name; }
        }

        public long ToMillis(long value)
        {
            long totalNanos = checked(value * _nanos);
            return totalNanos / 1000000L;
        }

        public override string ToString()
        {
            return _name;
        }
    }

    public class java_nio_file_attribute_FileTimeAutoTest
    {
        public void from_test_4782(Instant p0)
        {
            FileTime.from(p0);
        }

        public void from_test_4783(long p0, TimeUnit p1)
        {
            FileTime.from(p0, p1);
        }

        public void fromMillis_test_4784(long p0)
        {
            FileTime.fromMillis(p0);
        }
    }
}