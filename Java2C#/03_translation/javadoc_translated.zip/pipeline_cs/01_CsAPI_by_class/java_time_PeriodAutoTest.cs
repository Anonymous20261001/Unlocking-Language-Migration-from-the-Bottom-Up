using System;

namespace Generated.Test
{
    public interface CharSequence
    {
        int Length();
        char CharAt(int index);
        CharSequence SubSequence(int start, int end);
        string ToString();
    }

    public class StringCharSequence : CharSequence
    {
        private readonly string _text;
        public StringCharSequence(string text) { _text = text ?? string.Empty; }
        public int Length() { return _text.Length; }
        public char CharAt(int index) { return _text[index]; }
        public CharSequence SubSequence(int start, int end) { return new StringCharSequence(_text.Substring(start, end - start)); }
        public override string ToString() { return _text; }
    }

    public interface TemporalAmount
    {
    }

    public class LocalDate
    {
        public int Year { get; }
        public int Month { get; }
        public int Day { get; }

        public LocalDate(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        public int GetYear() { return Year; }
        public int GetMonthValue() { return Month; }
        public int GetDayOfMonth() { return Day; }
    }

    public class Period : TemporalAmount
    {
        public int Years { get; }
        public int Months { get; }
        public int Days { get; }

        public Period(int years, int months, int days)
        {
            Years = years;
            Months = months;
            Days = days;
        }

        public static Period of(int years, int months, int days)
        {
            return new Period(years, months, days);
        }

        public static Period from(TemporalAmount amount)
        {
            if (amount is Period p)
            {
                return new Period(p.Years, p.Months, p.Days);
            }
            throw new NotSupportedException("Cannot convert TemporalAmount to Period: " + (amount != null ? amount.GetType().ToString() : "null"));
        }

        public static Period parse(CharSequence text)
        {
            if (text == null) throw new ArgumentNullException("text");
            return Parse(text.ToString());
        }

        public static Period parse(string text)
        {
            if (text == null) throw new ArgumentNullException("text");
            return Parse(text);
        }

        private static Period Parse(string text)
        {
            if (string.IsNullOrEmpty(text) || text[0] != 'P')
                throw new FormatException("Invalid period: " + text);

            int years = 0, months = 0, days = 0;
            int i = 1;
            bool negative = false;

            if (i < text.Length && (text[i] == '-' || text[i] == '+'))
            {
                negative = text[i] == '-';
                i++;
            }

            int num = 0;
            bool hasValue = false;
            bool inTime = false;

            for (; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsDigit(c))
                {
                    num = num * 10 + (c - '0');
                    hasValue = true;
                }
                else if (c == 'T')
                {
                    inTime = true;
                }
                else
                {
                    int value = negative ? -num : num;
                    switch (c)
                    {
                        case 'Y': years = value; break;
                        case 'M':
                            if (!inTime) months = value;
                            break;
                        case 'D': days = value; break;
                        case 'W': days = value * 7; break;
                        case 'H':
                        case 'S':
                            break;
                        default:
                            throw new FormatException("Invalid period: " + text);
                    }
                    num = 0;
                    hasValue = false;
                }
            }

            if (hasValue || text.Length == 1)
                throw new FormatException("Invalid period: " + text);

            return new Period(years, months, days);
        }

        public static Period between(LocalDate startInclusive, LocalDate endExclusive)
        {
            if (startInclusive == null) throw new ArgumentNullException("startInclusive");
            if (endExclusive == null) throw new ArgumentNullException("endExclusive");

            int years = endExclusive.Year - startInclusive.Year;
            int months = endExclusive.Month - startInclusive.Month;
            int days = endExclusive.Day - startInclusive.Day;

            if (days < 0)
            {
                months--;
                int prevMonth = endExclusive.Month == 1 ? 12 : endExclusive.Month - 1;
                int prevYear = endExclusive.Month == 1 ? endExclusive.Year - 1 : endExclusive.Year;
                days += DateTime.DaysInMonth(prevYear, prevMonth);
            }

            if (months < 0)
            {
                years--;
                months += 12;
            }

            return new Period(years, months, days);
        }

        public static Period ofDays(int days)
        {
            return new Period(0, 0, days);
        }

        public static Period ofYears(int years)
        {
            return new Period(years, 0, 0);
        }

        public static Period ofMonths(int months)
        {
            return new Period(0, months, 0);
        }

        public static Period ofWeeks(int weeks)
        {
            return new Period(0, 0, weeks * 7);
        }
    }

    public class java_time_PeriodAutoTest
    {
        public void of_test_9886(int p0, int p1, int p2)
        {
            Period.of(p0, p1, p2);
        }

        public void from_test_9887(TemporalAmount p0)
        {
            Period.from(p0);
        }

        public void parse_test_9888(CharSequence p0)
        {
            Period.parse(p0);
        }

        public void between_test_9889(LocalDate p0, LocalDate p1)
        {
            Period.between(p0, p1);
        }

        public void ofDays_test_9890(int p0)
        {
            Period.ofDays(p0);
        }

        public void ofYears_test_9891(int p0)
        {
            Period.ofYears(p0);
        }

        public void ofMonths_test_9892(int p0)
        {
            Period.ofMonths(p0);
        }

        public void ofWeeks_test_9893(int p0)
        {
            Period.ofWeeks(p0);
        }
    }
}