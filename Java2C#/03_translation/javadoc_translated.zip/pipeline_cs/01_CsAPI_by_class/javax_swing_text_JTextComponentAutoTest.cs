namespace Generated.Test
{
    public class javax_swing_text_JTextComponentAutoTest
    {
        public void addKeymap_test_7310(string p0, Keymap p1)
        {
            JTextComponent.addKeymap(p0, p1);
        }

        public void getKeymap_test_7311(string p0)
        {
            JTextComponent.getKeymap(p0);
        }

        public void removeKeymap_test_7312(string p0)
        {
            JTextComponent.removeKeymap(p0);
        }

        public void loadKeymap_test_7313(Keymap p0, JTextComponent.KeyBinding[] p1, Action[] p2)
        {
            JTextComponent.loadKeymap(p0, p1, p2);
        }
    }

    public class JTextComponent
    {
        public class KeyBinding
        {
            public KeyBinding(object keyStroke, string actionName)
            {
                // Implementation
            }
        }

        public static void addKeymap(string name, Keymap keymap)
        {
            // Implementation
        }

        public static Keymap getKeymap(string name)
        {
            // Implementation
            return null;
        }

        public static void removeKeymap(string name)
        {
            // Implementation
        }

        public static void loadKeymap(Keymap keymap, KeyBinding[] bindings, Action[] actions)
        {
            // Implementation
        }
    }

    public interface Keymap
    {
        // Interface members
    }

    public interface Action
    {
        // Interface members
    }
}