namespace Generated.Test
{
    public class InetAddress
    {
    }

    public class URL
    {
    }

    public class PasswordAuthentication
    {
        public string UserName { get; set; }
        public char[] Password { get; set; }

        public PasswordAuthentication(string userName, char[] password)
        {
            UserName = userName;
            Password = password;
        }
    }

    public class Authenticator
    {
        public enum RequestorType
        {
            PROXY,
            SERVER
        }

        private static Authenticator defaultAuthenticator;

        public static PasswordAuthentication requestPasswordAuthentication(InetAddress addr, int port, string protocol, string prompt, string scheme)
        {
            return defaultAuthenticator?.getPasswordAuthentication();
        }

        public static PasswordAuthentication requestPasswordAuthentication(string host, InetAddress addr, int port, string protocol, string prompt, string scheme)
        {
            return defaultAuthenticator?.getPasswordAuthentication();
        }

        public static PasswordAuthentication requestPasswordAuthentication(Authenticator authenticator, string host, InetAddress addr, int port, string protocol, string prompt, string scheme, URL url, RequestorType reqType)
        {
            return authenticator?.getPasswordAuthentication();
        }

        public static PasswordAuthentication requestPasswordAuthentication(string host, InetAddress addr, int port, string protocol, string prompt, string scheme, URL url, RequestorType reqType)
        {
            return defaultAuthenticator?.getPasswordAuthentication();
        }

        public static Authenticator getDefault()
        {
            return defaultAuthenticator;
        }

        public static void setDefault(Authenticator authenticator)
        {
            defaultAuthenticator = authenticator;
        }

        protected virtual PasswordAuthentication getPasswordAuthentication()
        {
            return null;
        }
    }

    public class java_net_AuthenticatorAutoTest
    {
        public void requestPasswordAuthentication_test_897(InetAddress p0, int p1, string p2, string p3, string p4)
        {
            Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4);
        }

        public void requestPasswordAuthentication_test_898(string p0, InetAddress p1, int p2, string p3, string p4, string p5)
        {
            Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5);
        }

        public void requestPasswordAuthentication_test_899(Authenticator p0, string p1, InetAddress p2, int p3, string p4, string p5, string p6, URL p7, Authenticator.RequestorType p8)
        {
            Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7, p8);
        }

        public void requestPasswordAuthentication_test_900(string p0, InetAddress p1, int p2, string p3, string p4, string p5, URL p6, Authenticator.RequestorType p7)
        {
            Authenticator.requestPasswordAuthentication(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void getDefault_test_901()
        {
            Authenticator.getDefault();
        }

        public void setDefault_test_902(Authenticator p0)
        {
            Authenticator.setDefault(p0);
        }
    }
}