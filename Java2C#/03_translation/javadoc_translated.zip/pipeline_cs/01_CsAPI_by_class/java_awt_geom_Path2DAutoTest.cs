```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface PathIterator
    {
        const int WIND_EVEN_ODD = 0;
        const int WIND_NON_ZERO = 1;
        const int SEG_MOVETO = 0;
        const int SEG_LINETO = 1;
        const int SEG_QUADTO = 2;
        const int SEG_CUBICTO = 3;
        const int SEG_CLOSE = 4;

        int getWindingRule();
        bool isDone();
        void next();
        int currentSegment(double[] coords);
        int currentSegment(float[] coords);
    }

    public class Point2D
    {
        private double x;
        private double y;

        public Point2D(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public double getX()
        {
            return x;
        }

        public double getY()
        {
            return y;
        }
    }

    public class Rectangle2D
    {
        private double x;
        private double y;
        private double w;
        private double h;

        public Rectangle2D(double x, double y, double w, double h)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }

        public double getX()
        {
            return x;
        }

        public double getY()
        {
            return y;
        }

        public double getWidth()
        {
            return w;
        }

        public double getHeight()
        {
            return h;
        }
    }

    public static class Path2D
    {
        private struct LineSegment
        {
            public double X0;
            public double Y0;
            public double X1;
            public double Y1;
        }

        private class PathData
        {
            public List<LineSegment> Lines = new List<LineSegment>();
        }

        public static bool contains(PathIterator pi, double x, double y)
        {
            PathData data = ReadPath(pi);
            return ContainsPoint(data, x, y);
        }

        public static bool contains(PathIterator pi, Point2D p)
        {
            return contains(pi, p.getX(), p.getY());
        }

        public static bool contains(PathIterator pi, double x, double y, double w, double h)
        {
            PathData data = ReadPath(pi);
            return ContainsRect(data, x, y, w, h);
        }

        public static bool contains(PathIterator pi, Rectangle2D r)
        {
            return contains(pi, r.getX(), r.getY(), r.getWidth(), r.getHeight());
        }

        public static bool intersects(PathIterator pi, double x, double y, double w, double h)
        {
            PathData data = ReadPath(pi);
            return IntersectsRect(data, x, y, w, h);
        }

        public static bool intersects(PathIterator pi, Rectangle2D r)
        {
            return intersects(pi, r.getX(), r.getY(), r.getWidth(), r.getHeight());
        }

        private static PathData ReadPath(PathIterator pi)
        {
            PathData data = new PathData();
            double moveX = 0, moveY = 0, curX = 0, curY = 0;
            double[] coords = new double[6];

            while (!pi.isDone())
            {
                int type = pi.currentSegment(coords);

                switch (type)
                {
                    case PathIterator.SEG_MOVETO:
                        moveX = curX = coords[0];
                        moveY = curY = coords[1];
                        break;

                    case PathIterator.SEG_LINETO:
                        data.Lines.Add(new LineSegment { X0 = curX, Y0 = curY, X1 = coords[0], Y1 = coords[1] });
                        curX = coords[0];
                        curY = coords[1];
                        break;

                    case PathIterator.SEG_QUADTO:
                        data.Lines.Add(new LineSegment { X0 = curX, Y0 = curY, X1 = coords[2], Y1 = coords[3] });
                        curX = coords[2];
                        curY = coords[3];
                        break;

                    case PathIterator.SEG_CUBICTO:
                        data.Lines.Add(new LineSegment { X0 = curX, Y0 = curY, X1 = coords[4], Y1 = coords[5] });
                        curX = coords[4];
                        curY = coords[5];
                        break;

                    case PathIterator.SEG_CLOSE:
                        data.Lines.Add(new LineSegment { X0 = curX, Y0 = curY, X1 = moveX, Y1 = moveY });
                        curX = moveX;
                        curY = moveY;
                        break;
                }

                pi.next();
            }

            return data;
        }

        private static bool ContainsPoint(PathData data, double x, double y)
        {
            bool inside = false;

            foreach (LineSegment line in data.Lines)
            {
                if (RayIntersectsSegment(x, y, line.X0, line.Y0, line.X1, line.Y1))
                {
                    inside = !inside;
                }
            }

            return inside;
        }

        private static bool ContainsRect(PathData data, double x, double y, double w, double h)
        {
            if (w <= 0 || h <= 0)
            {
                return false;
            }

            return ContainsPoint(data, x, y)
                && ContainsPoint(data, x + w, y)
                && ContainsPoint(data, x, y + h)
                && ContainsPoint(data, x + w, y + h);
        }

        private static bool IntersectsRect(PathData data, double x, double y, double w, double h)
        {
            if (w <= 0 || h <= 0)
            {
                return false;
            }

            foreach (LineSegment line in data.Lines)
            {
                if (RectContainsPoint(x, y, w, h, line.X0, line.Y0)
                    || RectContainsPoint(x, y, w, h, line.X1, line.Y1))
                {
                    return true;
                }

                if (LineIntersectsRect(line, x, y, w, h))
                {
                    return true;
                }
            }

            return ContainsPoint(data, x, y)
                || ContainsPoint(data, x + w, y)
                || ContainsPoint(data, x, y + h)
                || ContainsPoint(data, x + w, y + h);
        }

        private static bool RayIntersectsSegment(double px, double py, double x0, double y0, double x1, double y1)
        {
            if ((y0 > py) == (y1 > py))
            {
                return false;
            }

            double x = x0 + (py - y0) * (x1 - x0) / (y1 - y0);
            return x > px;
        }

        private static bool RectContainsPoint(double rx, double ry, double rw, double rh, double px, double py)
        {
            return px >= rx && px <= rx + rw && py >= ry && py <= ry + rh;
        }

        private static bool LineIntersectsRect(LineSegment line, double rx, double ry, double rw, double rh)
        {
            double ax = line.X0, ay = line.Y0, bx = line.X1, by = line.Y1;

            return SegmentsIntersect(ax, ay, bx, by, rx, ry, rx, ry + rh)
                || SegmentsIntersect(ax, ay, bx, by, rx + rw, ry, rx + rw, ry + rh)
                || SegmentsIntersect(ax, ay, bx, by, rx, ry, rx + rw, ry)
                || SegmentsIntersect(ax, ay, bx, by, rx, ry + rh, rx + rw, ry + rh);
        }

        private static bool SegmentsIntersect(
            double ax, double ay, double bx, double by,
            double cx, double cy, double dx, double dy)
        {
            const double eps = 1e-12;

            double o1 = Orientation(ax, ay, bx, by, cx, cy);
            double o2 = Orientation(ax, ay, bx, by, dx, dy);
            double o3 = Orientation(cx, cy, dx, dy, ax, ay);
            double o4 = Orientation(cx, cy, dx, dy, bx, by);

            if (o1 * o2 < 0 && o3 * o4 < 0)
            {
                return true;
            }

            if (Math.Abs(o1) < eps && OnSegment(ax, ay, cx, cy, bx, by)) return true;
            if (Math.Abs(o2) < eps && OnSegment(ax, ay, dx, dy, bx, by)) return true;
            if (Math.Abs(o3) < eps && OnSegment(cx, cy, ax, ay, dx, dy)) return true;
            if (Math.Abs(o4) < eps && OnSegment(cx, cy, bx, by, dx, dy)) return true;

            return false;
        }

        private static double Orientation(double ax, double ay, double bx, double by, double cx, double cy)
        {
            return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
        }

        private static bool OnSegment(double ax, double ay, double bx, double by, double cx, double cy)
        {
            const double eps = 1e-12;
            return bx >= Math.Min(ax, cx) - eps && bx <= Math.Max(ax, cx) + eps
                && by >= Math.Min(ay, cy) - eps && by <= Math.Max(ay, cy) + eps;
        }
    }

    public class java_awt_geom_Path2DAutoTest
    {
        public void contains_test_9835(PathIterator p0, double p1, double p2, double p3, double p4)
        {
            Path2D.contains(p0, p1, p2, p3, p4);
        }

        public void contains_test_9836(PathIterator p0, Rectangle2D p1)
        {
            Path2D.contains(p0, p1);
        }

        public void contains_test_9837(PathIterator p0, double p1, double p2)
        {
            Path2D.contains(p0, p1, p2);
        }

        public void contains_test_9838(PathIterator p0, Point2D p1)
        {
            Path2D.contains(p0, p1);
        }

        public void intersects_test_9839(PathIterator p0, double p1, double p2, double p3, double p4)
        {
            Path2D.intersects(p0, p1, p2, p3, p4);
        }

        public void intersects_test_9840(PathIterator p0, Rectangle2D p1)
        {
            Path2D.intersects(p0, p1);
        }
    }
}
```