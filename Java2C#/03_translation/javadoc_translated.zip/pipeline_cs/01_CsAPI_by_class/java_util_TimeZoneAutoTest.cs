namespace Generated.Test
{
    public class ZoneId
    {
        private string id;

        public ZoneId(string id)
        {
            this.id = id;
        }

        public string getId()
        {
            return id;
        }

        public string Id
        {
            get { return id; }
        }
    }

    public class TimeZone
    {
        private static TimeZone defaultTimeZone;
        private System.TimeZoneInfo info;
        private string id;

        private TimeZone(System.TimeZoneInfo info)
        {
            this.info = info;
            this.id = info != null ? info.Id : "GMT";
        }

        public static TimeZone getDefault()
        {
            if (defaultTimeZone == null)
            {
                defaultTimeZone = new TimeZone(System.TimeZoneInfo.Local);
            }
            return defaultTimeZone;
        }

        public static void setDefault(TimeZone timeZone)
        {
            defaultTimeZone = timeZone;
        }

        public static TimeZone getTimeZone(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return new TimeZone(System.TimeZoneInfo.Utc);
            }

            try
            {
                return new TimeZone(System.TimeZoneInfo.FindSystemTimeZoneById(id));
            }
            catch (System.TimeZoneNotFoundException)
            {
                return new TimeZone(System.TimeZoneInfo.Utc);
            }
            catch (System.InvalidTimeZoneException)
            {
                return new TimeZone(System.TimeZoneInfo.Utc);
            }
        }

        public static TimeZone getTimeZone(ZoneId zoneId)
        {
            if (zoneId == null)
            {
                return getTimeZone("GMT");
            }

            return getTimeZone(zoneId.getId());
        }

        public static string[] getAvailableIDs()
        {
            System.Collections.Generic.List<string> ids = new System.Collections.Generic.List<string>();

            foreach (System.TimeZoneInfo tz in System.TimeZoneInfo.GetSystemTimeZones())
            {
                ids.Add(tz.Id);
            }

            return ids.ToArray();
        }

        public static string[] getAvailableIDs(int rawOffset)
        {
            System.Collections.Generic.List<string> ids = new System.Collections.Generic.List<string>();

            foreach (System.TimeZoneInfo tz in System.TimeZoneInfo.GetSystemTimeZones())
            {
                double offsetMillis = tz.BaseUtcOffset.TotalMilliseconds;

                if (System.Math.Abs(offsetMillis - rawOffset) < 0.001)
                {
                    ids.Add(tz.Id);
                }
            }

            return ids.ToArray();
        }

        public static string[] availableIDs()
        {
            return getAvailableIDs();
        }

        public static string[] availableIDs(int rawOffset)
        {
            return getAvailableIDs(rawOffset);
        }

        public string getID()
        {
            return id;
        }
    }

    public class java_util_TimeZoneAutoTest
    {
        public void getDefault_test_12901()
        {
            TimeZone.getDefault();
        }

        public void getTimeZone_test_12902(string p0)
        {
            TimeZone.getTimeZone(p0);
        }

        public void getTimeZone_test_12903(ZoneId p0)
        {
            TimeZone.getTimeZone(p0);
        }

        public void setDefault_test_12904(TimeZone p0)
        {
            TimeZone.setDefault(p0);
        }

        public void getAvailableIDs_test_12905()
        {
            TimeZone.getAvailableIDs();
        }

        public void getAvailableIDs_test_12906(int p0)
        {
            TimeZone.getAvailableIDs(p0);
        }

        public void availableIDs_test_12907(int p0)
        {
            TimeZone.availableIDs(p0);
        }

        public void availableIDs_test_12908()
        {
            TimeZone.availableIDs();
        }
    }
}