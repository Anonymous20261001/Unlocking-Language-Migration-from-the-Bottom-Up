using System;

namespace java.awt
{
    public abstract class GraphicsEnvironment
    {
        protected GraphicsEnvironment() { }

        public static bool isHeadless()
        {
            if (Environment.OSVersion.Platform == PlatformID.Unix || Environment.OSVersion.Platform == PlatformID.MacOSX)
            {
                string display = Environment.GetEnvironmentVariable("DISPLAY");
                return string.IsNullOrEmpty(display);
            }
            return false;
        }

        public static GraphicsEnvironment getLocalGraphicsEnvironment()
        {
            return new LocalGraphicsEnvironment();
        }

        private sealed class LocalGraphicsEnvironment : GraphicsEnvironment
        {
        }
    }
}

namespace Generated.Test
{
    public class java_awt_GraphicsEnvironmentAutoTest
    {
        public void isHeadless_test_5148()
        {
            java.awt.GraphicsEnvironment.isHeadless();
        }

        public void getLocalGraphicsEnvironment_test_5149()
        {
            java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
        }
    }
}