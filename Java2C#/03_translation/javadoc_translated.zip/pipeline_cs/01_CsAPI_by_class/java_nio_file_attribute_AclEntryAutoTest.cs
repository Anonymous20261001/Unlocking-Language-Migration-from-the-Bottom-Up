namespace Generated.Test
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public enum AclEntryType
    {
        ALARM,
        ALLOW,
        AUDIT,
        DENY
    }

    public enum AclEntryPermission
    {
        READ_DATA,
        WRITE_DATA,
        APPEND_DATA,
        READ_NAMED_ATTRS,
        WRITE_NAMED_ATTRS,
        EXECUTE,
        DELETE_CHILD,
        READ_ATTRIBUTES,
        WRITE_ATTRIBUTES,
        DELETE,
        READ_ACL,
        WRITE_ACL,
        WRITE_OWNER,
        SYNCHRONIZE
    }

    public enum AclEntryFlag
    {
        FILE_INHERIT,
        DIRECTORY_INHERIT,
        NO_PROPAGATE_INHERIT,
        INHERIT_ONLY
    }

    public interface UserPrincipal
    {
        string Name { get; }
    }

    public abstract class AclEntry
    {
        public abstract AclEntryType type();
        public abstract UserPrincipal principal();
        public abstract ISet<AclEntryPermission> permissions();
        public abstract ISet<AclEntryFlag> flags();

        public sealed class Builder
        {
            private AclEntryType _type;
            private UserPrincipal _principal;
            private readonly ISet<AclEntryPermission> _permissions = new HashSet<AclEntryPermission>();
            private readonly ISet<AclEntryFlag> _flags = new HashSet<AclEntryFlag>();

            internal Builder()
            {
            }

            public Builder setType(AclEntryType type)
            {
                _type = type;
                return this;
            }

            public Builder setPrincipal(UserPrincipal principal)
            {
                _principal = principal;
                return this;
            }

            public Builder setPermissions(params AclEntryPermission[] perms)
            {
                _permissions.Clear();
                if (perms != null)
                {
                    foreach (AclEntryPermission p in perms)
                    {
                        _permissions.Add(p);
                    }
                }
                return this;
            }

            public Builder setPermissions(ISet<AclEntryPermission> perms)
            {
                _permissions.Clear();
                if (perms != null)
                {
                    foreach (AclEntryPermission p in perms)
                    {
                        _permissions.Add(p);
                    }
                }
                return this;
            }

            public Builder setFlags(params AclEntryFlag[] flags)
            {
                _flags.Clear();
                if (flags != null)
                {
                    foreach (AclEntryFlag f in flags)
                    {
                        _flags.Add(f);
                    }
                }
                return this;
            }

            public Builder setFlags(ISet<AclEntryFlag> flags)
            {
                _flags.Clear();
                if (flags != null)
                {
                    foreach (AclEntryFlag f in flags)
                    {
                        _flags.Add(f);
                    }
                }
                return this;
            }

            public AclEntry build()
            {
                return new AclEntryImpl(_type, _principal, _permissions, _flags);
            }
        }

        public static Builder newBuilder()
        {
            return new Builder();
        }

        public static Builder newBuilder(AclEntry entry)
        {
            if (entry == null)
            {
                throw new ArgumentNullException(nameof(entry));
            }

            Builder builder = new Builder();
            builder.setType(entry.type());
            builder.setPrincipal(entry.principal());
            builder.setPermissions(entry.permissions());
            builder.setFlags(entry.flags());
            return builder;
        }

        private sealed class AclEntryImpl : AclEntry
        {
            private readonly AclEntryType _type;
            private readonly UserPrincipal _principal;
            private readonly ISet<AclEntryPermission> _permissions;
            private readonly ISet<AclEntryFlag> _flags;

            internal AclEntryImpl(
                AclEntryType type,
                UserPrincipal principal,
                ISet<AclEntryPermission> permissions,
                ISet<AclEntryFlag> flags)
            {
                _type = type;
                _principal = principal;
                _permissions = permissions == null
                    ? new HashSet<AclEntryPermission>()
                    : new HashSet<AclEntryPermission>(permissions);
                _flags = flags == null
                    ? new HashSet<AclEntryFlag>()
                    : new HashSet<AclEntryFlag>(flags);
            }

            public override AclEntryType type()
            {
                return _type;
            }

            public override UserPrincipal principal()
            {
                return _principal;
            }

            public override ISet<AclEntryPermission> permissions()
            {
                return new HashSet<AclEntryPermission>(_permissions);
            }

            public override ISet<AclEntryFlag> flags()
            {
                return new HashSet<AclEntryFlag>(_flags);
            }

            public override bool Equals(object obj)
            {
                AclEntry other = obj as AclEntry;
                if (other == null)
                {
                    return false;
                }

                return _type == other.type() &&
                       Equals(_principal, other.principal()) &&
                       _permissions.SetEquals(other.permissions()) &&
                       _flags.SetEquals(other.flags());
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = 17;
                    hash = hash * 31 + _type.GetHashCode();
                    hash = hash * 31 + (_principal == null ? 0 : _principal.GetHashCode());

                    foreach (AclEntryPermission p in _permissions)
                    {
                        hash = hash * 31 + p.GetHashCode();
                    }

                    foreach (AclEntryFlag f in _flags)
                    {
                        hash = hash * 31 + f.GetHashCode();
                    }

                    return hash;
                }
            }

            public override string ToString()
            {
                return "AclEntry[type=" + _type +
                       ", principal=" + _principal +
                       ", permissions=" + string.Join(",", _permissions.Select(p => p.ToString())) +
                       ", flags=" + string.Join(",", _flags.Select(f => f.ToString())) + "]";
            }
        }
    }

    public class java_nio_file_attribute_AclEntryAutoTest
    {
        public void newBuilder_test_55(AclEntry p0)
        {
            AclEntry.newBuilder(p0);
        }

        public void newBuilder_test_56()
        {
            AclEntry.newBuilder();
        }
    }
}