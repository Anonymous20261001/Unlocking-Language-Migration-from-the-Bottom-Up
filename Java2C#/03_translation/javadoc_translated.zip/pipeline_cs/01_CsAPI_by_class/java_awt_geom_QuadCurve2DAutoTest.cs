using System;

namespace Generated.Test
{
    public class java_awt_geom_QuadCurve2DAutoTest
    {
        public void getFlatnessSq_test_10235(double p0, double p1, double p2, double p3, double p4, double p5)
        {
            QuadCurve2D.getFlatnessSq(p0, p1, p2, p3, p4, p5);
        }

        public void getFlatnessSq_test_10236(double[] p0, int p1)
        {
            QuadCurve2D.getFlatnessSq(p0, p1);
        }

        public void getFlatness_test_10237(double[] p0, int p1)
        {
            QuadCurve2D.getFlatness(p0, p1);
        }

        public void getFlatness_test_10238(double p0, double p1, double p2, double p3, double p4, double p5)
        {
            QuadCurve2D.getFlatness(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_10239(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5)
        {
            QuadCurve2D.subdivide(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_10240(QuadCurve2D p0, QuadCurve2D p1, QuadCurve2D p2)
        {
            QuadCurve2D.subdivide(p0, p1, p2);
        }

        public void solveQuadratic_test_10241(double[] p0, double[] p1)
        {
            QuadCurve2D.solveQuadratic(p0, p1);
        }

        public void solveQuadratic_test_10242(double[] p0)
        {
            QuadCurve2D.solveQuadratic(p0);
        }
    }

    public class QuadCurve2D
    {
        private double x1, y1, ctrlx, ctrly, x2, y2;

        public double getX1() { return x1; }
        public double getY1() { return y1; }
        public double getCtrlX() { return ctrlx; }
        public double getCtrlY() { return ctrly; }
        public double getX2() { return x2; }
        public double getY2() { return y2; }

        public void setCurve(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.ctrlx = ctrlx;
            this.ctrly = ctrly;
            this.x2 = x2;
            this.y2 = y2;
        }

        public static double getFlatnessSq(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            double lenSq = dx * dx + dy * dy;
            double px = ctrlx;
            double py = ctrly;

            if (lenSq == 0.0)
            {
                double ddx = px - x1;
                double ddy = py - y1;
                return ddx * ddx + ddy * ddy;
            }

            double t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
            if (t < 0.0) t = 0.0;
            else if (t > 1.0) t = 1.0;

            double projX = x1 + t * dx;
            double projY = y1 + t * dy;
            double ddx = px - projX;
            double ddy = py - projY;
            return ddx * ddx + ddy * ddy;
        }

        public static double getFlatnessSq(double[] coords, int offset)
        {
            return getFlatnessSq(coords[offset], coords[offset + 1], coords[offset + 2], coords[offset + 3], coords[offset + 4], coords[offset + 5]);
        }

        public static double getFlatness(double x1, double y1, double ctrlx, double ctrly, double x2, double y2)
        {
            return Math.Sqrt(getFlatnessSq(x1, y1, ctrlx, ctrly, x2, y2));
        }

        public static double getFlatness(double[] coords, int offset)
        {
            return Math.Sqrt(getFlatnessSq(coords, offset));
        }

        public static void subdivide(double[] src, int srcoff, double[] left, int leftoff, double[] right, int rightoff)
        {
            double x1 = src[srcoff + 0];
            double y1 = src[srcoff + 1];
            double ctrlx = src[srcoff + 2];
            double ctrly = src[srcoff + 3];
            double x2 = src[srcoff + 4];
            double y2 = src[srcoff + 5];

            if (left != null)
            {
                left[leftoff + 0] = x1;
                left[leftoff + 1] = y1;
            }
            if (right != null)
            {
                right[rightoff + 4] = x2;
                right[rightoff + 5] = y2;
            }

            x1 = (x1 + ctrlx) / 2.0;
            y1 = (y1 + ctrly) / 2.0;
            x2 = (x2 + ctrlx) / 2.0;
            y2 = (y2 + ctrly) / 2.0;
            ctrlx = (x1 + x2) / 2.0;
            ctrly = (y1 + y2) / 2.0;

            if (left != null)
            {
                left[leftoff + 2] = x1;
                left[leftoff + 3] = y1;
                left[leftoff + 4] = ctrlx;
                left[leftoff + 5] = ctrly;
            }
            if (right != null)
            {
                right[rightoff + 0] = ctrlx;
                right[rightoff + 1] = ctrly;
                right[rightoff + 2] = x2;
                right[rightoff + 3] = y2;
            }
        }

        public static void subdivide(QuadCurve2D src, QuadCurve2D left, QuadCurve2D right)
        {
            double x1 = src.getX1();
            double y1 = src.getY1();
            double ctrlx = src.getCtrlX();
            double ctrly = src.getCtrlY();
            double x2 = src.getX2();
            double y2 = src.getY2();
            double middleX = (x1 + 2.0 * ctrlx + x2) / 4.0;
            double middleY = (y1 + 2.0 * ctrly + y2) / 4.0;

            if (left != null)
            {
                left.setCurve(x1, y1, (x1 + ctrlx) / 2.0, (y1 + ctrly) / 2.0, middleX, middleY);
            }
            if (right != null)
            {
                right.setCurve(middleX, middleY, (ctrlx + x2) / 2.0, (ctrly + y2) / 2.0, x2, y2);
            }
        }

        public static int solveQuadratic(double[] eqn, double[] roots)
        {
            return solveQuadratic(eqn, 0, eqn.Length, roots, 0);
        }

        public static int solveQuadratic(double[] eqn)
        {
            return solveQuadratic(eqn, 0, eqn.Length, eqn, 0);
        }

        private static int solveQuadratic(double[] eqn, int off, int len, double[] roots, int rowoff)
        {
            if (len < 3)
            {
                return 0;
            }

            double a = eqn[off + 2];
            double b = eqn[off + 1];
            double c = eqn[off + 0];

            if (a == 0.0)
            {
                if (b == 0.0)
                {
                    return 0;
                }
                roots[rowoff++] = -c / b;
                return 1;
            }

            double dis = b * b - 4.0 * a * c;
            if (dis > 0.0)
            {
                dis = Math.Sqrt(dis);
                roots[rowoff++] = (-b + dis) / (2.0 * a);
                roots[rowoff++] = (-b - dis) / (2.0 * a);
                return 2;
            }
            if (dis == 0.0)
            {
                roots[rowoff++] = -b / (2.0 * a);
                return 1;
            }
            return 0;
        }
    }
}