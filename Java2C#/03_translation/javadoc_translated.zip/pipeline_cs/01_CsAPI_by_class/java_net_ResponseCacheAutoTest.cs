using System;

namespace Generated.Test
{
    public abstract class ResponseCache
    {
        private static ResponseCache _default;
        private static readonly object _lock = new object();

        protected ResponseCache()
        {
        }

        public static ResponseCache getDefault()
        {
            lock (_lock)
            {
                return _default;
            }
        }

        public static void setDefault(ResponseCache p0)
        {
            lock (_lock)
            {
                _default = p0;
            }
        }
    }

    public class java_net_ResponseCacheAutoTest
    {
        public void getDefault_test_10628()
        {
            ResponseCache.getDefault();
        }

        public void setDefault_test_10629(ResponseCache p0)
        {
            ResponseCache.setDefault(p0);
        }
    }
}