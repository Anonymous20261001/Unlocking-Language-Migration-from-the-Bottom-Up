namespace Generated.Test
{
    public class Path
    {
        private readonly string _path;

        public Path(string path)
        {
            _path = path;
        }

        public override string ToString()
        {
            return _path;
        }
    }

    public class UnixDomainSocketAddress
    {
        private readonly string _path;

        private UnixDomainSocketAddress(string path)
        {
            _path = path;
        }

        public static UnixDomainSocketAddress of(Path p0)
        {
            if (p0 == null) throw new System.ArgumentNullException("p0");
            return new UnixDomainSocketAddress(p0.ToString());
        }

        public static UnixDomainSocketAddress of(string p0)
        {
            if (p0 == null) throw new System.ArgumentNullException("p0");
            return new UnixDomainSocketAddress(p0);
        }

        public Path getPath()
        {
            return new Path(_path);
        }
    }

    public class java_net_UnixDomainSocketAddressAutoTest
    {
        public void of_test_13210(Path p0)
        {
            UnixDomainSocketAddress.of(p0);
        }

        public void of_test_13211(string p0)
        {
            UnixDomainSocketAddress.of(p0);
        }
    }
}