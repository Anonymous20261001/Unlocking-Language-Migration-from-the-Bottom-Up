using System;

namespace Generated.Test
{
    public class java_nio_FloatBufferAutoTest
    {
        public void wrap_test_4883(float[] p0)
        {
            FloatBuffer.wrap(p0);
        }

        public void wrap_test_4884(float[] p0, int p1, int p2)
        {
            FloatBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_4885(int p0)
        {
            FloatBuffer.allocate(p0);
        }
    }

    public class FloatBuffer
    {
        internal readonly int capacity;
        internal int position;
        internal int limit;

        private FloatBuffer(int capacity, int position, int limit)
        {
            this.capacity = capacity;
            this.position = position;
            this.limit = limit;
        }

        public static FloatBuffer wrap(float[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }

            return new FloatBuffer(array.Length, 0, array.Length);
        }

        public static FloatBuffer wrap(float[] array, int offset, int length)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }

            if (offset < 0 || length < 0 || offset > array.Length - length)
            {
                throw new ArgumentOutOfRangeException();
            }

            return new FloatBuffer(array.Length, offset, offset + length);
        }

        public static FloatBuffer allocate(int capacity)
        {
            if (capacity < 0)
            {
                throw new ArgumentException("Negative capacity");
            }

            return new FloatBuffer(capacity, 0, capacity);
        }
    }
}