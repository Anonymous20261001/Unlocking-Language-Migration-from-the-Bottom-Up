using System;

namespace Generated.Test
{
    public abstract class AccessibleObject
    {
        private bool _accessible;

        public bool IsAccessible
        {
            get { return _accessible; }
        }

        protected AccessibleObject()
        {
        }

        public void SetAccessible(bool flag)
        {
            _accessible = flag;
        }

        public static void SetAccessible(AccessibleObject[] array, bool flag)
        {
            if (array == null)
            {
                throw new ArgumentNullException(nameof(array));
            }

            foreach (AccessibleObject obj in array)
            {
                obj.SetAccessible(flag);
            }
        }
    }

    public class java_lang_reflect_AccessibleObjectAutoTest
    {
        public void setAccessible_test_35(AccessibleObject[] p0, bool p1)
        {
            AccessibleObject.SetAccessible(p0, p1);
        }
    }
}