namespace Generated.Test
{
    public class FailOverExecutionControlProvider
    {
        public string name()
        {
            return "failover";
        }

        public string[] defaultParameters()
        {
            return new string[] { "die", "exit" };
        }
    }

    public class jdk_jshell_execution_FailOverExecutionControlProviderAutoTest
    {
        public void name_test_4672()
        {
            FailOverExecutionControlProvider instance = new FailOverExecutionControlProvider();
            instance.name();
        }

        public void defaultParameters_test_4673()
        {
            FailOverExecutionControlProvider instance = new FailOverExecutionControlProvider();
            instance.defaultParameters();
        }
    }
}