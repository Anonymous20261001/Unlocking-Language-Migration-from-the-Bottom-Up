using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Generated.Test
{
    public interface Descriptor
    {
        string[] getFieldNames();
        object[] getFieldValues(string[] fieldNames);
        void setField(string fieldName, object fieldValue);
        object getFieldValue(string fieldName);
        object removeField(string fieldName);
        string getFields();
        bool isValid();
        void setFields(string[] fieldNames, object[] fieldValues);
        object clone();
    }

    public class ImmutableDescriptor : Descriptor
    {
        private readonly Dictionary<string, object> _fields = new Dictionary<string, object>();
        private readonly List<string> _keys = new List<string>();

        public ImmutableDescriptor() : this(new string[0])
        {
        }

        public ImmutableDescriptor(string[] fields) : this(fields, null)
        {
        }

        public ImmutableDescriptor(string[] fieldNames, object[] fieldValues)
        {
            if (fieldNames != null)
            {
                for (int i = 0; i < fieldNames.Length; i++)
                {
                    string name = fieldNames[i];
                    if (name == null) continue;

                    object value = (fieldValues != null && i < fieldValues.Length) ? fieldValues[i] : null;

                    if (!_fields.ContainsKey(name))
                    {
                        _fields.Add(name, value);
                        _keys.Add(name);
                    }
                    else
                    {
                        _fields[name] = value;
                    }
                }
            }
        }

        public string[] getFieldNames()
        {
            return _keys.ToArray();
        }

        public object[] getFieldValues(string[] fieldNames)
        {
            if (fieldNames == null) return null;

            object[] values = new object[fieldNames.Length];
            for (int i = 0; i < fieldNames.Length; i++)
            {
                string name = fieldNames[i];
                values[i] = (name != null && _fields.TryGetValue(name, out object v)) ? v : null;
            }
            return values;
        }

        public void setField(string fieldName, object fieldValue)
        {
            throw new InvalidOperationException("Immutable Descriptor");
        }

        public object getFieldValue(string fieldName)
        {
            if (fieldName != null && _fields.TryGetValue(fieldName, out object v))
            {
                return v;
            }
            return null;
        }

        public object removeField(string fieldName)
        {
            throw new InvalidOperationException("Immutable Descriptor");
        }

        public string getFields()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < _keys.Count; i++)
            {
                if (i > 0) sb.Append(',');
                string key = _keys[i];
                object val = _fields[key];
                sb.Append(key).Append('=');
                if (val == null) sb.Append("null");
                else sb.Append(val);
            }
            return sb.ToString();
        }

        public bool isValid()
        {
            foreach (string key in _keys)
            {
                object v = _fields[key];
                if (v == null) continue;
                if (v is string || v is int || v is bool || v is long || v is double ||
                    v is string[] || v is int[] || v is bool[] || v is long[] || v is double[])
                {
                    continue;
                }
                return false;
            }
            return true;
        }

        public void setFields(string[] fieldNames, object[] fieldValues)
        {
            throw new InvalidOperationException("Immutable Descriptor");
        }

        public object clone()
        {
            return new ImmutableDescriptor(getFieldNames(), getFieldValues(getFieldNames()));
        }

        public static Descriptor union(Descriptor[] descriptors)
        {
            Dictionary<string, object> map = new Dictionary<string, object>();
            List<string> order = new List<string>();

            if (descriptors != null)
            {
                foreach (Descriptor d in descriptors)
                {
                    if (d == null) continue;

                    foreach (string name in d.getFieldNames())
                    {
                        object value = d.getFieldValue(name);
                        if (!map.ContainsKey(name))
                        {
                            map.Add(name, value);
                            order.Add(name);
                        }
                        else
                        {
                            map[name] = value;
                        }
                    }
                }
            }

            string[] names = order.ToArray();
            object[] values = new object[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                values[i] = map[names[i]];
            }

            return new ImmutableDescriptor(names, values);
        }
    }

    public class javax_management_ImmutableDescriptorAutoTest
    {
        public void getFieldNames_test_5753(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.getFieldNames();
        }

        public void getFieldValues_test_5754(string[] p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.getFieldValues(p0);
        }

        public void setField_test_5755(string p0, object p1, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.setField(p0, p1);
        }

        public void getFieldValue_test_5756(string p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.getFieldValue(p0);
        }

        public void removeField_test_5757(string p0, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.removeField(p0);
        }

        public void getFields_test_5758(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.getFields();
        }

        public void isValid_test_5759(string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.isValid();
        }

        public void setFields_test_5760(string[] p0, object[] p1, string[] c0)
        {
            ImmutableDescriptor instance = new ImmutableDescriptor(c0);
            instance.setFields(p0, p1);
        }

        public void union_test_5761(Descriptor[] p0)
        {
            ImmutableDescriptor.union(p0);
        }
    }
}