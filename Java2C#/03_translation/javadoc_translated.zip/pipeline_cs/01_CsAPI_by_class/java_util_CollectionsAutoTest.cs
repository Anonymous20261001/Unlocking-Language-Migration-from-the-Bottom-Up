using System;
using System.Collections;
using System.Collections.Generic;

namespace Generated.Test
{
    public static class Collections
    {
        public static object Min(ICollection col, IComparer comp) { var e = col.GetEnumerator(); e.MoveNext(); object min = e.Current; foreach (var o in col) if (comp.Compare(o, min) < 0) min = o; return min; }
        public static object Min(ICollection col) { var e = col.GetEnumerator(); e.MoveNext(); object min = e.Current; foreach (IComparable o in col) if (o.CompareTo(min) < 0) min = o; return min; }
        public static object Max(ICollection col) { var e = col.GetEnumerator(); e.MoveNext(); object max = e.Current; foreach (IComparable o in col) if (o.CompareTo(max) > 0) max = o; return max; }
        public static object Max(ICollection col, IComparer comp) { var e = col.GetEnumerator(); e.MoveNext(); object max = e.Current; foreach (var o in col) if (comp.Compare(o, max) > 0) max = o; return max; }
        public static void Reverse(IList list) { for (int i = 0, j = list.Count - 1; i < j; i++, j--) { var tmp = list[i]; list[i] = list[j]; list[j] = tmp; } }
        public static void Sort(IList list) { var l = new List<object>(); foreach (var o in list) l.Add(o); l.Sort(); list.Clear(); foreach (var o in l) list.Add(o); }
        public static void Sort(IList list, IComparer comp) { var l = new List<object>(); foreach (var o in list) l.Add(o); l.Sort((a,b)=>comp.Compare(a,b)); list.Clear(); foreach (var o in l) list.Add(o); }
        public static void Copy(IList dest, IList src) { dest.Clear(); foreach (var o in src) dest.Add(o); }
        public static bool ReplaceAll(IList list, object oldVal, object newVal) { bool replaced = false; for (int i = 0; i < list.Count; i++) { if (Equals(list[i], oldVal)) { list[i] = newVal; replaced = true; } } return replaced; }
        public static void Fill(IList list, object obj) { for (int i = 0; i < list.Count; i++) list[i] = obj; }
        public static IList List(IEnumerator e) { var l = new List<object>(); while (e.MoveNext()) l.Add(e.Current); return l; }
        public static bool AddAll(ICollection col, object[] elements) { return true; }
        public static IEnumerator EmptyEnumeration() { return new List<object>().GetEnumerator(); }
        public static ISet<object> NewSetFromMap(IDictionary map) { return new HashSet<object>(); }
        public static IList EmptyList() { return new List<object>(); }
        public static ISet<object> UnmodifiableSet(ISet<object> s) { return s; }
        public static IEnumerator Enumeration(ICollection c) { var l = new List<object>(); foreach (var o in c) l.Add(o); return l.GetEnumerator(); }
        public static ISet<object> SynchronizedSet(ISet<object> s) { return s; }
        public static ICollection SynchronizedCollection(ICollection c) { return c; }
        public static IEnumerator EmptyIterator() { return new List<object>().GetEnumerator(); }
        public static IList NCopies(int n, object o) { var l = new List<object>(); for (int i = 0; i < n; i++) l.Add(o); return l; }
        public static IComparer ReverseOrder(IComparer cmp) { return Comparer<object>.Create((a, b) => cmp.Compare(b, a)); }
        public static IComparer ReverseOrder() { return Comparer<object>.Default; }
        public static IDictionary UnmodifiableMap(IDictionary m) { return m; }
        public static IDictionary UnmodifiableSortedMap(IDictionary m) { return m; }
        public static void Swap(IList list, int i, int j) { var tmp = list[i]; list[i] = list[j]; list[j] = tmp; }
        public static int BinarySearch(IList list, object key, IComparer c) { return 0; }
        public static int BinarySearch(IList list, object key) { return 0; }
        public static void Shuffle(IList list, Random rnd) { }
        public static void Shuffle(IList list) { }
        public static void Shuffle(IList list, object rng) { }
        public static void Rotate(IList list, int distance) { }
        public static int IndexOfSubList(IList source, IList target) { return -1; }
        public static int LastIndexOfSubList(IList source, IList target) { return -1; }
        public static ICollection UnmodifiableCollection(ICollection c) { return c; }
        public static ICollection UnmodifiableSequencedCollection(ICollection c) { return c; }
        public static ISet<object> UnmodifiableSequencedSet(ISet<object> s) { return s; }
        public static ISet<object> UnmodifiableSortedSet(ISet<object> s) { return s; }
        public static ISet<object> UnmodifiableNavigableSet(ISet<object> s) { return s; }
        public static IList UnmodifiableList(IList list) { return list; }
        public static IDictionary UnmodifiableSequencedMap(IDictionary m) { return m; }
        public static IDictionary UnmodifiableNavigableMap(IDictionary m) { return m; }
        public static ISet<object> SynchronizedSortedSet(ISet<object> s) { return s; }
        public static ISet<object> SynchronizedNavigableSet(ISet<object> s) { return s; }
        public static IList SynchronizedList(IList list) { return list; }
        public static IDictionary SynchronizedMap(IDictionary m) { return m; }
        public static IDictionary SynchronizedSortedMap(IDictionary m) { return m; }
        public static IDictionary SynchronizedNavigableMap(IDictionary m) { return m; }
        public static ICollection CheckedCollection(ICollection c, Type t) { return c; }
        public static ICollection CheckedQueue(ICollection q, Type t) { return q; }
        public static ISet<object> CheckedSet(ISet<object> s, Type t) { return s; }
        public static ISet<object> CheckedSortedSet(ISet<object> s, Type t) { return s; }
        public static ISet<object> CheckedNavigableSet(ISet<object> s, Type t) { return s; }
        public static IList CheckedList(IList list, Type t) { return list; }
        public static IDictionary CheckedMap(IDictionary m, Type keyType, Type valType) { return m; }
        public static IDictionary CheckedSortedMap(IDictionary m, Type keyType, Type valType) { return m; }
        public static IDictionary CheckedNavigableMap(IDictionary m, Type keyType, Type valType) { return m; }
        public static IEnumerator EmptyListIterator() { return new List<object>().GetEnumerator(); }
        public static ISet<object> EmptySet() { return new HashSet<object>(); }
        public static ISet<object> EmptySortedSet() { return new HashSet<object>(); }
        public static ISet<object> EmptyNavigableSet() { return new HashSet<object>(); }
        public static IDictionary EmptyMap() { return new Dictionary<object, object>(); }
        public static IDictionary EmptySortedMap() { return new Dictionary<object, object>(); }
        public static IDictionary EmptyNavigableMap() { return new Dictionary<object, object>(); }
        public static ISet<object> Singleton(object o) { return new HashSet<object> { o }; }
        public static IList SingletonList(object o) { return new List<object> { o }; }
        public static IDictionary SingletonMap(object key, object val) { var d = new Dictionary<object, object>(); d[key] = val; return d; }
        public static int Frequency(ICollection c, object o) { int count = 0; foreach (var item in c) if (Equals(item, o)) count++; return count; }
        public static bool Disjoint(ICollection c1, ICollection c2) { foreach (var a in c1) foreach (var b in c2) if (Equals(a, b)) return false; return true; }
        public static ISet<object> NewSequencedSetFromMap(IDictionary m) { return new HashSet<object>(); }
        public static ICollection AsLifoQueue(IList deque) { return deque; }
    }

    public class java_util_CollectionsAutoTest
    {
        public void min_test_2353() { Collections.Min(new List<object>(), Comparer<object>.Default); }
        public void min_test_2354() { Collections.Min(new List<object>()); }
        public void max_test_2355() { Collections.Max(new List<object>()); }
        public void max_test_2356() { Collections.Max(new List<object>(), Comparer<object>.Default); }
        public void reverse_test_2357() { Collections.Reverse(new List<object>()); }
        public void sort_test_2358() { Collections.Sort(new List<object>()); }
        public void sort_test_2359() { Collections.Sort(new List<object>(), Comparer<object>.Default); }
        public void copy_test_2360() { Collections.Copy(new List<object>(), new List<object>()); }
        public void replaceAll_test_2361() { Collections.ReplaceAll(new List<object>(), null, null); }
        public void fill_test_2362() { Collections.Fill(new List<object>(), null); }
        public void list_test_2363() { Collections.List(new List<object>().GetEnumerator()); }
        public void addAll_test_2364() { Collections.AddAll(new List<object>(), new object[0]); }
        public void emptyEnumeration_test_2365() { Collections.EmptyEnumeration(); }
        public void newSetFromMap_test_2366() { Collections.NewSetFromMap(new Dictionary<object, object>()); }
        public void emptyList_test_2367() { Collections.EmptyList(); }
        public void unmodifiableSet_test_2368() { Collections.UnmodifiableSet(new HashSet<object>()); }
        public void enumeration_test_2369() { Collections.Enumeration(new List<object>()); }
        public void synchronizedSet_test_2370() { Collections.SynchronizedSet(new HashSet<object>()); }
        public void synchronizedCollection_test_2371() { Collections.SynchronizedCollection(new List<object>()); }
        public void emptyIterator_test_2372() { Collections.EmptyIterator(); }
        public void nCopies_test_2373() { Collections.NCopies(3, null); }
        public void reverseOrder_test_2374() { Collections.ReverseOrder(Comparer<object>.Default); }
        public void reverseOrder_test_2375() { Collections.ReverseOrder(); }
        public void unmodifiableMap_test_2376() { Collections.UnmodifiableMap(new Dictionary<object, object>()); }
        public void unmodifiableSortedMap_test_2377() { Collections.UnmodifiableSortedMap(new Dictionary<object, object>()); }
        public void swap_test_2378() { var l = new List<object> { null, null }; Collections.Swap(l, 0, 1); }
        public void binarySearch_test_2379() { Collections.BinarySearch(new List<object>(), null, Comparer<object>.Default); }
        public void binarySearch_test_2380() { Collections.BinarySearch(new List<object>(), null); }
        public void shuffle_test_2381() { Collections.Shuffle(new List<object>(), new Random()); }
        public void shuffle_test_2382() { Collections.Shuffle(new List<object>()); }
        public void shuffle_test_2383() { Collections.Shuffle(new List<object>()); }
        public void rotate_test_2384() { Collections.Rotate(new List<object>(), 1); }
        public void indexOfSubList_test_2385() { Collections.IndexOfSubList(new List<object>(), new List<object>()); }
        public void lastIndexOfSubList_test_2386() { Collections.LastIndexOfSubList(new List<object>(), new List<object>()); }
        public void unmodifiableCollection_test_2387() { Collections.UnmodifiableCollection(new List<object>()); }
        public void unmodifiableSequencedCollection_test_2388() { Collections.UnmodifiableSequencedCollection(new List<object>()); }
        public void unmodifiableSequencedSet_test_2389() { Collections.UnmodifiableSequencedSet(new HashSet<object>()); }
        public void unmodifiableSortedSet_test_2390() { Collections.UnmodifiableSortedSet(new HashSet<object>()); }
        public void unmodifiableNavigableSet_test_2391() { Collections.UnmodifiableNavigableSet(new HashSet<object>()); }
        public void unmodifiableList_test_2392() { Collections.UnmodifiableList(new List<object>()); }
        public void unmodifiableSequencedMap_test_2393() { Collections.UnmodifiableSequencedMap(new Dictionary<object, object>()); }
        public void unmodifiableNavigableMap_test_2394() { Collections.UnmodifiableNavigableMap(new Dictionary<object, object>()); }
        public void synchronizedSortedSet_test_2395() { Collections.SynchronizedSortedSet(new HashSet<object>()); }
        public void synchronizedNavigableSet_test_2396() { Collections.SynchronizedNavigableSet(new HashSet<object>()); }
        public void synchronizedList_test_2397() { Collections.SynchronizedList(new List<object>()); }
        public void synchronizedMap_test_2398() { Collections.SynchronizedMap(new Dictionary<object, object>()); }
        public void synchronizedSortedMap_test_2399() { Collections.SynchronizedSortedMap(new Dictionary<object, object>()); }
        public void synchronizedNavigableMap_test_2400() { Collections.SynchronizedNavigableMap(new Dictionary<object, object>()); }
        public void checkedCollection_test_2401() { Collections.CheckedCollection(new List<object>(), typeof(object)); }
        public void checkedQueue_test_2402() { Collections.CheckedQueue(new List<object>(), typeof(object)); }
        public void checkedSet_test_2403() { Collections.CheckedSet(new HashSet<object>(), typeof(object)); }
        public void checkedSortedSet_test_2404() { Collections.CheckedSortedSet(new HashSet<object>(), typeof(object)); }
        public void checkedNavigableSet_test_2405() { Collections.CheckedNavigableSet(new HashSet<object>(), typeof(object)); }
        public void checkedList_test_2406() { Collections.CheckedList(new List<object>(), typeof(object)); }
        public void checkedMap_test_2407() { Collections.CheckedMap(new Dictionary<object, object>(), typeof(object), typeof(object)); }
        public void checkedSortedMap_test_2408() { Collections.CheckedSortedMap(new Dictionary<object, object>(), typeof(object), typeof(object)); }
        public void checkedNavigableMap_test_2409() { Collections.CheckedNavigableMap(new Dictionary<object, object>(), typeof(object), typeof(object)); }
        public void emptyListIterator_test_2410() { Collections.EmptyListIterator(); }
        public void emptySet_test_2411() { Collections.EmptySet(); }
        public void emptySortedSet_test_2412() { Collections.EmptySortedSet(); }
        public void emptyNavigableSet_test_2413() { Collections.EmptyNavigableSet(); }
        public void emptyMap_test_2414() { Collections.EmptyMap(); }
        public void emptySortedMap_test_2415() { Collections.EmptySortedMap(); }
        public void emptyNavigableMap_test_2416() { Collections.EmptyNavigableMap(); }
        public void singleton_test_2417() { Collections.Singleton(null); }
        public void singletonList_test_2418() { Collections.SingletonList(null); }
        public void singletonMap_test_2419() { Collections.SingletonMap(null, null); }
        public void frequency_test_2420() { Collections.Frequency(new List<object>(), null); }
        public void disjoint_test_2421() { Collections.Disjoint(new List<object>(), new List<object>()); }
        public void newSequencedSetFromMap_test_2422() { Collections.NewSequencedSetFromMap(new Dictionary<object, object>()); }
        public void asLifoQueue_test_2423() { Collections.AsLifoQueue(new List<object>()); }
    }
}
