using System;

namespace Generated.Test
{
    public class java_lang_ref_ReferenceAutoTest
    {
        public void reachabilityFence_test_10486(object p0)
        {
            Reference.reachabilityFence(p0);
        }
    }

    public static class Reference
    {
        public static void reachabilityFence(object obj)
        {
            GC.KeepAlive(obj);
        }
    }
}