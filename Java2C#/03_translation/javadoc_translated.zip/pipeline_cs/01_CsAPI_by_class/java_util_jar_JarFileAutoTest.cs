namespace Generated.Test
{
    public static class JarFile
    {
        public static System.Version runtimeVersion()
        {
            return System.Environment.Version;
        }

        public static System.Version baseVersion()
        {
            return new System.Version(0, 0);
        }
    }

    public class java_util_jar_JarFileAutoTest
    {
        public void runtimeVersion_test_5997()
        {
            JarFile.runtimeVersion();
        }

        public void baseVersion_test_5998()
        {
            JarFile.baseVersion();
        }
    }
}