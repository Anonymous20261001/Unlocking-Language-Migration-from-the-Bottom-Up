using System.Collections.Generic;

namespace Generated.Test
{
    public interface Action
    {
        object getValue(string key);
        void putValue(string key, object value);
        bool isEnabled();
        void setEnabled(bool b);

        const string DEFAULT = "Default";
        const string NAME = "Name";
        const string SHORT_DESCRIPTION = "ShortDescription";
        const string LONG_DESCRIPTION = "LongDescription";
        const string SMALL_ICON = "SmallIcon";
        const string LARGE_ICON_KEY = "LargeIcon";
        const string ACCELERATOR_KEY = "AcceleratorKey";
        const string MNEMONIC_KEY = "MnemonicKey";
        const string ACTION_COMMAND_KEY = "ActionCommandKey";
    }

    public abstract class TextAction
    {
        public static Action[] augmentList(Action[] list1, Action[] list2)
        {
            Dictionary<string, Action> h = new Dictionary<string, Action>();

            foreach (Action a in list1)
            {
                string cmd = (string)a.getValue(Action.NAME);
                if (cmd != null)
                {
                    h[cmd] = a;
                }
            }

            foreach (Action a in list2)
            {
                string cmd = (string)a.getValue(Action.NAME);
                if (cmd != null)
                {
                    h[cmd] = a;
                }
            }

            Action[] result = new Action[h.Count];
            int i = 0;
            foreach (Action a in h.Values)
            {
                result[i++] = a;
            }
            return result;
        }
    }

    public class javax_swing_text_TextActionAutoTest
    {
        public void augmentList_test_12543(Action[] p0, Action[] p1)
        {
            TextAction.augmentList(p0, p1);
        }
    }
}