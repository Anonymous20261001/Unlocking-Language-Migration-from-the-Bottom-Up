namespace java.awt.im
{
    public class InputContext
    {
        private static InputContext instance;
        private static readonly object lockObj = new object();

        private InputContext()
        {
        }

        public static InputContext getInstance()
        {
            lock (lockObj)
            {
                if (instance == null)
                {
                    instance = new InputContext();
                }
                return instance;
            }
        }
    }
}

namespace Generated.Test
{
    public class java_awt_im_InputContextAutoTest
    {
        public void getInstance_test_5830()
        {
            java.awt.im.InputContext.getInstance();
        }
    }
}