namespace Generated.Test
{
    public abstract class Writer
    {
        public static Writer nullWriter()
        {
            return new NullWriter();
        }

        private sealed class NullWriter : Writer
        {
        }
    }

    public class java_io_WriterAutoTest
    {
        public void nullWriter_test_13550()
        {
            Writer.nullWriter();
        }
    }
}