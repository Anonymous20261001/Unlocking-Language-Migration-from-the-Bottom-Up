using System;

namespace Generated.Test
{
    public static class Array
    {
        private static System.Array CheckArray(object array)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));
            var arr = array as System.Array;
            if (arr == null)
                throw new ArgumentException("Argument is not an array.");
            return arr;
        }

        public static object get(object array, int index)
        {
            return CheckArray(array).GetValue(index);
        }

        public static int getLength(object array)
        {
            return CheckArray(array).GetLength(0);
        }

        public static bool getBoolean(object array, int index)
        {
            return Convert.ToBoolean(get(array, index));
        }

        public static byte getByte(object array, int index)
        {
            return Convert.ToByte(get(array, index));
        }

        public static short getShort(object array, int index)
        {
            return Convert.ToInt16(get(array, index));
        }

        public static char getChar(object array, int index)
        {
            return Convert.ToChar(get(array, index));
        }

        public static int getInt(object array, int index)
        {
            return Convert.ToInt32(get(array, index));
        }

        public static long getLong(object array, int index)
        {
            return Convert.ToInt64(get(array, index));
        }

        public static float getFloat(object array, int index)
        {
            return Convert.ToSingle(get(array, index));
        }

        public static double getDouble(object array, int index)
        {
            return Convert.ToDouble(get(array, index));
        }

        public static object newInstance(Type componentType, int length)
        {
            return System.Array.CreateInstance(componentType, length);
        }

        public static object newInstance(Type componentType, int[] lengths)
        {
            if (lengths == null)
                throw new ArgumentNullException(nameof(lengths));
            if (lengths.Length == 0)
                throw new ArgumentException("Array dimensions must have at least one length.");

            if (lengths.Length == 1)
                return System.Array.CreateInstance(componentType, lengths[0]);

            Type elementType = componentType.MakeArrayType();
            System.Array array = System.Array.CreateInstance(elementType, lengths[0]);
            for (int i = 0; i < lengths[0]; i++)
            {
                int[] subLengths = new int[lengths.Length - 1];
                for (int j = 1; j < lengths.Length; j++)
                    subLengths[j - 1] = lengths[j];
                array.SetValue(newInstance(componentType, subLengths), i);
            }
            return array;
        }

        public static void set(object array, int index, object value)
        {
            CheckArray(array).SetValue(value, index);
        }

        public static void setBoolean(object array, int index, bool value)
        {
            bool[] boolArray = array as bool[];
            if (boolArray != null)
            {
                boolArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not boolean[]");
        }

        public static void setByte(object array, int index, byte value)
        {
            byte[] byteArray = array as byte[];
            if (byteArray != null)
            {
                byteArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not byte[]");
        }

        public static void setChar(object array, int index, char value)
        {
            char[] charArray = array as char[];
            if (charArray != null)
            {
                charArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not char[]");
        }

        public static void setShort(object array, int index, short value)
        {
            short[] shortArray = array as short[];
            if (shortArray != null)
            {
                shortArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not short[]");
        }

        public static void setInt(object array, int index, int value)
        {
            int[] intArray = array as int[];
            if (intArray != null)
            {
                intArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not int[]");
        }

        public static void setLong(object array, int index, long value)
        {
            long[] longArray = array as long[];
            if (longArray != null)
            {
                longArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not long[]");
        }

        public static void setFloat(object array, int index, float value)
        {
            float[] floatArray = array as float[];
            if (floatArray != null)
            {
                floatArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not float[]");
        }

        public static void setDouble(object array, int index, double value)
        {
            double[] doubleArray = array as double[];
            if (doubleArray != null)
            {
                doubleArray[index] = value;
                return;
            }
            throw new ArgumentException("Array is not double[]");
        }
    }

    public class java_lang_reflect_ArrayAutoTest
    {
        public void get_test_232(object p0, int p1)
        {
            Array.get(p0, p1);
        }

        public void getLength_test_233(object p0)
        {
            Array.getLength(p0);
        }

        public void getBoolean_test_234(object p0, int p1)
        {
            Array.getBoolean(p0, p1);
        }

        public void getByte_test_235(object p0, int p1)
        {
            Array.getByte(p0, p1);
        }

        public void getShort_test_236(object p0, int p1)
        {
            Array.getShort(p0, p1);
        }

        public void getChar_test_237(object p0, int p1)
        {
            Array.getChar(p0, p1);
        }

        public void getInt_test_238(object p0, int p1)
        {
            Array.getInt(p0, p1);
        }

        public void getLong_test_239(object p0, int p1)
        {
            Array.getLong(p0, p1);
        }

        public void getFloat_test_240(object p0, int p1)
        {
            Array.getFloat(p0, p1);
        }

        public void getDouble_test_241(object p0, int p1)
        {
            Array.getDouble(p0, p1);
        }

        public void newInstance_test_242(Type p0, int p1)
        {
            Array.newInstance(p0, p1);
        }

        public void newInstance_test_243(Type p0, int[] p1)
        {
            Array.newInstance(p0, p1);
        }

        public void set_test_244(object p0, int p1, object p2)
        {
            Array.set(p0, p1, p2);
        }

        public void setBoolean_test_245(object p0, int p1, bool p2)
        {
            Array.setBoolean(p0, p1, p2);
        }

        public void setByte_test_246(object p0, int p1, byte p2)
        {
            Array.setByte(p0, p1, p2);
        }

        public void setChar_test_247(object p0, int p1, char p2)
        {
            Array.setChar(p0, p1, p2);
        }

        public void setShort_test_248(object p0, int p1, short p2)
        {
            Array.setShort(p0, p1, p2);
        }

        public void setInt_test_249(object p0, int p1, int p2)
        {
            Array.setInt(p0, p1, p2);
        }

        public void setLong_test_250(object p0, int p1, long p2)
        {
            Array.setLong(p0, p1, p2);
        }

        public void setFloat_test_251(object p0, int p1, float p2)
        {
            Array.setFloat(p0, p1, p2);
        }

        public void setDouble_test_252(object p0, int p1, double p2)
        {
            Array.setDouble(p0, p1, p2);
        }
    }
}