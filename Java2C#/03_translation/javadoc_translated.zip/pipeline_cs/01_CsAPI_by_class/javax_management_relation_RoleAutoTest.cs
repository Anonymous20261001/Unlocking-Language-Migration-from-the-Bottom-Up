using System;
using System.Collections;
using System.Text;

namespace Generated.Test
{
    public class Role
    {
        private string roleName;
        private IList roleValue;

        public Role(string roleName, IList roleValue)
        {
            if (roleName == null)
                throw new ArgumentException("roleName is null", "roleName");
            if (roleValue == null)
                throw new ArgumentException("roleValue is null", "roleValue");
            this.roleName = roleName;
            this.roleValue = roleValue;
        }

        public void setRoleName(string roleName)
        {
            if (roleName == null)
                throw new ArgumentException("roleName is null", "roleName");
            this.roleName = roleName;
        }

        public void setRoleValue(IList roleValue)
        {
            if (roleValue == null)
                throw new ArgumentException("roleValue is null", "roleValue");
            this.roleValue = roleValue;
        }

        public string getRoleName()
        {
            return roleName;
        }

        public IList getRoleValue()
        {
            return roleValue;
        }

        public static string roleValueToString(IList roleValue)
        {
            if (roleValue == null)
                throw new ArgumentException("roleValue is null", "roleValue");

            StringBuilder sb = new StringBuilder();
            sb.Append('[');
            for (int i = 0; i < roleValue.Count; i++)
            {
                if (i > 0)
                    sb.Append(", ");
                sb.Append(roleValue[i] == null ? "null" : roleValue[i].ToString());
            }
            sb.Append(']');
            return sb.ToString();
        }
    }

    public class javax_management_relation_RoleAutoTest
    {
        public void setRoleName_test_10640(string p0, string c0, IList c1)
        {
            Role instance = new Role(c0, c1);
            instance.setRoleName(p0);
        }

        public void setRoleValue_test_10641(IList p0, string c0, IList c1)
        {
            Role instance = new Role(c0, c1);
            instance.setRoleValue(p0);
        }

        public void getRoleName_test_10642(string c0, IList c1)
        {
            Role instance = new Role(c0, c1);
            instance.getRoleName();
        }

        public void getRoleValue_test_10643(string c0, IList c1)
        {
            Role instance = new Role(c0, c1);
            instance.getRoleValue();
        }

        public void roleValueToString_test_10644(IList p0)
        {
            Role.roleValueToString(p0);
        }
    }
}