namespace Generated.Test
{
    public sealed class SplashScreen
    {
        private SplashScreen() { }

        public static SplashScreen getSplashScreen()
        {
            return null;
        }
    }

    public class java_awt_SplashScreenAutoTest
    {
        public void getSplashScreen_test_11313()
        {
            SplashScreen.getSplashScreen();
        }
    }
}