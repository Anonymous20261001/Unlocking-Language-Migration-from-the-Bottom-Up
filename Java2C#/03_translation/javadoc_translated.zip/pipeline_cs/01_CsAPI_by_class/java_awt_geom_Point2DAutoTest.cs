namespace Generated.Test
{
    public static class Point2D
    {
        public static double distanceSq(double x1, double y1, double x2, double y2)
        {
            double dx = x1 - x2;
            double dy = y1 - y2;
            return dx * dx + dy * dy;
        }

        public static double distance(double x1, double y1, double x2, double y2)
        {
            return System.Math.Sqrt(distanceSq(x1, y1, x2, y2));
        }
    }

    public class java_awt_geom_Point2DAutoTest
    {
        public void distanceSq_test_9956(double p0, double p1, double p2, double p3)
        {
            Point2D.distanceSq(p0, p1, p2, p3);
        }

        public void distance_test_9957(double p0, double p1, double p2, double p3)
        {
            Point2D.distance(p0, p1, p2, p3);
        }
    }
}