using System;
using System.Collections.Generic;
using System.Globalization;

namespace Generated.Test
{
    public class Level
    {
        public static readonly Level OFF = new Level("OFF", int.MaxValue);
        public static readonly Level SEVERE = new Level("SEVERE", 1000);
        public static readonly Level WARNING = new Level("WARNING", 900);
        public static readonly Level INFO = new Level("INFO", 800);
        public static readonly Level CONFIG = new Level("CONFIG", 700);
        public static readonly Level FINE = new Level("FINE", 500);
        public static readonly Level FINER = new Level("FINER", 400);
        public static readonly Level FINEST = new Level("FINEST", 300);
        public static readonly Level ALL = new Level("ALL", int.MinValue);

        private static readonly Dictionary<string, Level> known =
            new Dictionary<string, Level>(StringComparer.Ordinal)
            {
                { "OFF", OFF },
                { "SEVERE", SEVERE },
                { "WARNING", WARNING },
                { "INFO", INFO },
                { "CONFIG", CONFIG },
                { "FINE", FINE },
                { "FINER", FINER },
                { "FINEST", FINEST },
                { "ALL", ALL }
            };

        private readonly string name;
        private readonly int value;

        public string Name { get { return name; } }
        public int Value { get { return value; } }

        protected Level(string name, int value)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            this.name = name;
            this.value = value;
        }

        public static Level parse(string name)
        {
            if (name == null)
            {
                throw new NullReferenceException();
            }

            Level level;
            if (known.TryGetValue(name, out level))
            {
                return level;
            }

            try
            {
                int x = int.Parse(name, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture);
                return getLocalizedLevel(x);
            }
            catch (FormatException)
            {
                throw new ArgumentException("Bad level \"" + name + "\"");
            }
            catch (OverflowException)
            {
                throw new ArgumentException("Bad level \"" + name + "\"");
            }
        }

        private static Level getLocalizedLevel(int x)
        {
            if (x == OFF.Value) return OFF;
            if (x == SEVERE.Value) return SEVERE;
            if (x == WARNING.Value) return WARNING;
            if (x == INFO.Value) return INFO;
            if (x == CONFIG.Value) return CONFIG;
            if (x == FINE.Value) return FINE;
            if (x == FINER.Value) return FINER;
            if (x == FINEST.Value) return FINEST;
            if (x == ALL.Value) return ALL;

            return new Level("UNKNOWN", x);
        }

        public override string ToString()
        {
            return name;
        }
    }

    public class java_util_logging_LevelAutoTest
    {
        public void parse_test_7719(string p0)
        {
            Level.parse(p0);
        }
    }
}