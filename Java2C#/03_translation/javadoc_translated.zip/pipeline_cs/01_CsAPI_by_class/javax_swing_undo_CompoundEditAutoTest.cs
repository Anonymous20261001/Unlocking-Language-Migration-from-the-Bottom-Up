using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface UndoableEdit
    {
        bool addEdit(UndoableEdit anEdit);
        void undo();
        void redo();
        string getPresentationName();
        bool isSignificant();
        string getUndoPresentationName();
        string getRedoPresentationName();
        void die();
    }

    public class CannotUndoException : Exception
    {
        public CannotUndoException() { }
        public CannotUndoException(string message) : base(message) { }
    }

    public class CannotRedoException : Exception
    {
        public CannotRedoException() { }
        public CannotRedoException(string message) : base(message) { }
    }

    public abstract class AbstractUndoableEdit : UndoableEdit
    {
        protected bool alive = true;
        protected bool hasBeenDone = true;

        public virtual bool addEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual void undo()
        {
            if (!canUndo())
            {
                throw new CannotUndoException();
            }
            hasBeenDone = false;
        }

        public virtual void redo()
        {
            if (!canRedo())
            {
                throw new CannotRedoException();
            }
            hasBeenDone = true;
        }

        public virtual string getPresentationName()
        {
            return "AbstractUndoableEdit";
        }

        public virtual bool isSignificant()
        {
            return true;
        }

        public virtual string getUndoPresentationName()
        {
            return "Undo " + getPresentationName();
        }

        public virtual string getRedoPresentationName()
        {
            return "Redo " + getPresentationName();
        }

        public virtual void die()
        {
            alive = false;
        }

        public virtual bool canUndo()
        {
            return alive && hasBeenDone;
        }

        public virtual bool canRedo()
        {
            return alive && !hasBeenDone;
        }
    }

    public class CompoundEdit : AbstractUndoableEdit
    {
        private List<UndoableEdit> edits;
        private bool inProgress;

        public CompoundEdit()
        {
            edits = new List<UndoableEdit>();
            inProgress = true;
        }

        public override bool addEdit(UndoableEdit anEdit)
        {
            if (!inProgress)
            {
                return false;
            }
            edits.Add(anEdit);
            return true;
        }

        public override void undo()
        {
            if (!canUndo())
            {
                throw new CannotUndoException();
            }
            for (int i = edits.Count - 1; i >= 0; i--)
            {
                edits[i].undo();
            }
        }

        public override void redo()
        {
            if (!canRedo())
            {
                throw new CannotRedoException();
            }
            foreach (UndoableEdit e in edits)
            {
                e.redo();
            }
        }

        public override bool canUndo()
        {
            return !inProgress && edits.Count > 0 && edits[edits.Count - 1].canUndo();
        }

        public override bool canRedo()
        {
            return !inProgress && edits.Count > 0 && edits[edits.Count - 1].canRedo();
        }

        public override void die()
        {
            for (int i = edits.Count - 1; i >= 0; i--)
            {
                edits[i].die();
            }
            base.die();
        }

        public void end()
        {
            inProgress = false;
        }

        public bool isInProgress()
        {
            return inProgress;
        }
    }

    public class javax_swing_undo_CompoundEditAutoTest
    {
        public void addEdit_test_2699(UndoableEdit p0)
        {
            CompoundEdit instance = new CompoundEdit();
            instance.addEdit(p0);
        }

        public void redo_test_2700()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.redo();
        }

        public void undo_test_2701()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.undo();
        }

        public void getPresentationName_test_2702()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.getPresentationName();
        }

        public void isSignificant_test_2703()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.isSignificant();
        }

        public void getUndoPresentationName_test_2704()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.getUndoPresentationName();
        }

        public void getRedoPresentationName_test_2705()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.getRedoPresentationName();
        }

        public void die_test_2706()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.die();
        }

        public void isInProgress_test_2707()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.isInProgress();
        }

        public void canUndo_test_2708()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.canUndo();
        }

        public void canRedo_test_2709()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.canRedo();
        }

        public void end_test_2710()
        {
            CompoundEdit instance = new CompoundEdit();
            instance.end();
        }
    }
}