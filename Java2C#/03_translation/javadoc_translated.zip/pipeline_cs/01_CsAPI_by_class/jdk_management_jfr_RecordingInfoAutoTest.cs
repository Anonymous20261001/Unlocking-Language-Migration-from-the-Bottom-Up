namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class CompositeData
    {
        private Dictionary<string, object> _values = new Dictionary<string, object>();

        public object Get(string key)
        {
            if (_values.ContainsKey(key))
                return _values[key];
            return null;
        }

        public void Put(string key, object value)
        {
            _values[key] = value;
        }

        public bool ContainsKey(string key)
        {
            return _values.ContainsKey(key);
        }

        public string[] GetKeys()
        {
            return new List<string>(_values.Keys).ToArray();
        }
    }

    public class RecordingInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public long StartTime { get; set; }
        public long EndTime { get; set; }
        public long Duration { get; set; }
        public long Size { get; set; }
        public bool IsRunning { get; set; }
        public bool IsStopped { get; set; }
        public bool IsClosed { get; set; }
        public string Destination { get; set; }
        public string RecordingState { get; set; }

        public static RecordingInfo from(CompositeData cd)
        {
            if (cd == null)
                throw new ArgumentNullException(nameof(cd));

            RecordingInfo info = new RecordingInfo();
            info.Id = cd.Get("id")?.ToString();
            info.Name = cd.Get("name")?.ToString();
            info.StartTime = Convert.ToInt64(cd.Get("startTime") ?? 0L);
            info.EndTime = Convert.ToInt64(cd.Get("endTime") ?? 0L);
            info.Duration = Convert.ToInt64(cd.Get("duration") ?? 0L);
            info.Size = Convert.ToInt64(cd.Get("size") ?? 0L);
            info.IsRunning = Convert.ToBoolean(cd.Get("isRunning") ?? false);
            info.IsStopped = Convert.ToBoolean(cd.Get("isStopped") ?? false);
            info.IsClosed = Convert.ToBoolean(cd.Get("isClosed") ?? false);
            info.Destination = cd.Get("destination")?.ToString();
            info.RecordingState = cd.Get("recordingState")?.ToString();
            return info;
        }
    }

    public class jdk_management_jfr_RecordingInfoAutoTest
    {
        public void from_test_10377(CompositeData p0)
        {
            RecordingInfo.from(p0);
        }
    }
}