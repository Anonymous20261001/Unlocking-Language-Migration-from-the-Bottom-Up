namespace Generated.Test
{
    public abstract class OutputStream
    {
        public static OutputStream nullOutputStream()
        {
            return new NullOutputStream();
        }

        public abstract void write(int b);

        public virtual void write(byte[] b)
        {
            write(b, 0, b.Length);
        }

        public abstract void write(byte[] b, int off, int len);

        public virtual void flush()
        {
        }

        public virtual void close()
        {
        }

        private sealed class NullOutputStream : OutputStream
        {
            public override void write(int b)
            {
            }

            public override void write(byte[] b, int off, int len)
            {
            }
        }
    }

    public class java_io_OutputStreamAutoTest
    {
        public void nullOutputStream_test_9700()
        {
            OutputStream.nullOutputStream();
        }
    }
}