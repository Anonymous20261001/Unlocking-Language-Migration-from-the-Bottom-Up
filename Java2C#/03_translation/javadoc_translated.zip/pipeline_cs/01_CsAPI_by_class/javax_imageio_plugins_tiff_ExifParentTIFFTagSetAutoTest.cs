using System;

namespace Generated.Test
{
    public class ExifParentTIFFTagSet
    {
        private static readonly ExifParentTIFFTagSet instance = new ExifParentTIFFTagSet();

        private ExifParentTIFFTagSet()
        {
        }

        public static ExifParentTIFFTagSet getInstance()
        {
            return instance;
        }
    }

    public class javax_imageio_plugins_tiff_ExifParentTIFFTagSetAutoTest
    {
        public void getInstance_test_4663()
        {
            ExifParentTIFFTagSet.getInstance();
        }
    }
}