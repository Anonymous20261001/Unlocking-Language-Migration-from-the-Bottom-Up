using System;

namespace Generated.Test
{
    public interface TemporalAccessor
    {
    }

    public class ZoneId
    {
        public static ZoneId SystemDefault()
        {
            return new ZoneId();
        }
    }

    public class Clock
    {
        public static Clock SystemDefaultZone()
        {
            return new Clock();
        }

        public virtual DateTime GetDateTimeNow()
        {
            return DateTime.Now;
        }
    }

    public class ThaiBuddhistDate : TemporalAccessor
    {
        private readonly int _year;
        private readonly int _month;
        private readonly int _day;

        public ThaiBuddhistDate(int year, int month, int day)
        {
            _year = year;
            _month = month;
            _day = day;
        }

        public int Year
        {
            get { return _year; }
        }

        public int Month
        {
            get { return _month; }
        }

        public int Day
        {
            get { return _day; }
        }

        public static ThaiBuddhistDate of(int year, int month, int dayOfMonth)
        {
            return new ThaiBuddhistDate(year, month, dayOfMonth);
        }

        public static ThaiBuddhistDate from(TemporalAccessor temporal)
        {
            ThaiBuddhistDate thai = temporal as ThaiBuddhistDate;
            if (thai != null)
            {
                return thai;
            }

            throw new ArgumentException("Unsupported temporal: " + temporal);
        }

        public static ThaiBuddhistDate now()
        {
            return Now(DateTime.Now);
        }

        public static ThaiBuddhistDate now(ZoneId zone)
        {
            return Now(DateTime.Now);
        }

        public static ThaiBuddhistDate now(Clock clock)
        {
            if (clock == null)
            {
                throw new ArgumentNullException("clock");
            }

            return Now(clock.GetDateTimeNow());
        }

        private static ThaiBuddhistDate Now(DateTime value)
        {
            return new ThaiBuddhistDate(value.Year + 543, value.Month, value.Day);
        }
    }

    public class java_time_chrono_ThaiBuddhistDateAutoTest
    {
        public void of_test_12647(int p0, int p1, int p2)
        {
            ThaiBuddhistDate.of(p0, p1, p2);
        }

        public void from_test_12648(TemporalAccessor p0)
        {
            ThaiBuddhistDate.from(p0);
        }

        public void now_test_12649()
        {
            ThaiBuddhistDate.now();
        }

        public void now_test_12650(ZoneId p0)
        {
            ThaiBuddhistDate.now(p0);
        }

        public void now_test_12651(Clock p0)
        {
            ThaiBuddhistDate.now(p0);
        }
    }
}