using System;
using List = System.Collections.IList;

namespace Generated.Test
{
    public class RoleUnresolved
    {
        public const int PROBLEM_TYPE_NONE = 0;
        public const int PROBLEM_TYPE_ROLE_NOT_FOUND = 1;
        public const int PROBLEM_TYPE_ROLE_NOT_READABLE = 2;
        public const int PROBLEM_TYPE_ROLE_NOT_WRITABLE = 3;

        private string roleName;
        private List roleValue;
        private int problemType;

        public RoleUnresolved(string roleName, List roleValue, int problemType)
        {
            if (roleName == null)
                throw new ArgumentException("roleName is null");
            if (roleValue == null)
                throw new ArgumentException("roleValue is null");
            if (problemType < 0 || problemType > 3)
                throw new ArgumentException("problemType out of range");

            this.roleName = roleName;
            this.roleValue = roleValue;
            this.problemType = problemType;
        }

        public void setRoleName(string roleName)
        {
            if (roleName == null)
                throw new ArgumentException("roleName is null");
            this.roleName = roleName;
        }

        public string getRoleName()
        {
            return roleName;
        }

        public void setRoleValue(List roleValue)
        {
            if (roleValue == null)
                throw new ArgumentException("roleValue is null");
            this.roleValue = roleValue;
        }

        public List getRoleValue()
        {
            return roleValue;
        }

        public void setProblemType(int problemType)
        {
            if (problemType < 0 || problemType > 3)
                throw new ArgumentException("problemType out of range");
            this.problemType = problemType;
        }

        public int getProblemType()
        {
            return problemType;
        }
    }

    public class javax_management_relation_RoleUnresolvedAutoTest
    {
        public void setRoleName_test_10670(string p0, string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.setRoleName(p0);
        }

        public void setRoleValue_test_10671(List p0, string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.setRoleValue(p0);
        }

        public void setProblemType_test_10672(int p0, string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.setProblemType(p0);
        }

        public void getProblemType_test_10673(string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.getProblemType();
        }

        public void getRoleName_test_10674(string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.getRoleName();
        }

        public void getRoleValue_test_10675(string c0, List c1, int c2)
        {
            RoleUnresolved instance = new RoleUnresolved(c0, c1, c2);
            instance.getRoleValue();
        }
    }
}