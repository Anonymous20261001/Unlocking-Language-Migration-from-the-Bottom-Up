namespace Generated.Test
{
    public class javax_swing_JFrameAutoTest
    {
        public void getContentPane_test_6253()
        {
            JFrame instance = new JFrame();
            instance.getContentPane();
        }

        public void isDefaultLookAndFeelDecorated_test_6254()
        {
            JFrame.isDefaultLookAndFeelDecorated();
        }

        public void getJMenuBar_test_6255()
        {
            JFrame instance = new JFrame();
            instance.getJMenuBar();
        }

        public void setJMenuBar_test_6256(JMenuBar p0)
        {
            JFrame instance = new JFrame();
            instance.setJMenuBar(p0);
        }

        public void setContentPane_test_6257(Container p0)
        {
            JFrame instance = new JFrame();
            instance.setContentPane(p0);
        }

        public void getLayeredPane_test_6258()
        {
            JFrame instance = new JFrame();
            instance.getLayeredPane();
        }

        public void setLayeredPane_test_6259(JLayeredPane p0)
        {
            JFrame instance = new JFrame();
            instance.setLayeredPane(p0);
        }

        public void getGlassPane_test_6260()
        {
            JFrame instance = new JFrame();
            instance.getGlassPane();
        }

        public void setGlassPane_test_6261(Component p0)
        {
            JFrame instance = new JFrame();
            instance.setGlassPane(p0);
        }

        public void setDefaultCloseOperation_test_6262(int p0)
        {
            JFrame instance = new JFrame();
            instance.setDefaultCloseOperation(p0);
        }

        public void getDefaultCloseOperation_test_6263()
        {
            JFrame instance = new JFrame();
            instance.getDefaultCloseOperation();
        }

        public void setIconImage_test_6264(Image p0)
        {
            JFrame instance = new JFrame();
            instance.setIconImage(p0);
        }

        public void setDefaultLookAndFeelDecorated_test_6265(bool p0)
        {
            JFrame.setDefaultLookAndFeelDecorated(p0);
        }

        public void getGraphics_test_6266()
        {
            JFrame instance = new JFrame();
            instance.getGraphics();
        }

        public void getRootPane_test_6267()
        {
            JFrame instance = new JFrame();
            instance.getRootPane();
        }

        public void repaint_test_6268(long p0, int p1, int p2, int p3, int p4)
        {
            JFrame instance = new JFrame();
            instance.repaint(p0, p1, p2, p3, p4);
        }

        public void setTransferHandler_test_6269(TransferHandler p0)
        {
            JFrame instance = new JFrame();
            instance.setTransferHandler(p0);
        }

        public void getTransferHandler_test_6270()
        {
            JFrame instance = new JFrame();
            instance.getTransferHandler();
        }

        public void getAccessibleContext_test_6271()
        {
            JFrame instance = new JFrame();
            instance.getAccessibleContext();
        }

        public void setLayout_test_6272(LayoutManager p0)
        {
            JFrame instance = new JFrame();
            instance.setLayout(p0);
        }

        public void remove_test_6273(Component p0)
        {
            JFrame instance = new JFrame();
            instance.remove(p0);
        }

        public void update_test_6274(Graphics p0)
        {
            JFrame instance = new JFrame();
            instance.update(p0);
        }
    }

    public class JFrame
    {
        private Container contentPane;
        private JMenuBar menuBar;
        private JLayeredPane layeredPane;
        private Component glassPane;
        private int defaultCloseOperation;
        private Image iconImage;
        private TransferHandler transferHandler;
        private JRootPane rootPane;
        private LayoutManager layout;

        private static bool defaultLookAndFeelDecorated;

        public JFrame()
        {
            contentPane = new Container();
            layeredPane = new JLayeredPane();
            glassPane = new Component();
            rootPane = new JRootPane();
        }

        public Container getContentPane()
        {
            return contentPane;
        }

        public JMenuBar getJMenuBar()
        {
            return menuBar;
        }

        public void setJMenuBar(JMenuBar p0)
        {
            menuBar = p0;
        }

        public void setContentPane(Container p0)
        {
            contentPane = p0;
        }

        public JLayeredPane getLayeredPane()
        {
            return layeredPane;
        }

        public void setLayeredPane(JLayeredPane p0)
        {
            layeredPane = p0;
        }

        public Component getGlassPane()
        {
            return glassPane;
        }

        public void setGlassPane(Component p0)
        {
            glassPane = p0;
        }

        public void setDefaultCloseOperation(int p0)
        {
            defaultCloseOperation = p0;
        }

        public int getDefaultCloseOperation()
        {
            return defaultCloseOperation;
        }

        public void setIconImage(Image p0)
        {
            iconImage = p0;
        }

        public static bool isDefaultLookAndFeelDecorated()
        {
            return defaultLookAndFeelDecorated;
        }

        public static void setDefaultLookAndFeelDecorated(bool p0)
        {
            defaultLookAndFeelDecorated = p0;
        }

        public Graphics getGraphics()
        {
            return new Graphics();
        }

        public JRootPane getRootPane()
        {
            return rootPane;
        }

        public void repaint(long p0, int p1, int p2, int p3, int p4)
        {
        }

        public void setTransferHandler(TransferHandler p0)
        {
            transferHandler = p0;
        }

        public TransferHandler getTransferHandler()
        {
            return transferHandler;
        }

        public AccessibleContext getAccessibleContext()
        {
            return new AccessibleContext();
        }

        public void setLayout(LayoutManager p0)
        {
            layout = p0;
        }

        public void remove(Component p0)
        {
        }

        public void update(Graphics p0)
        {
        }
    }

    public class Component
    {
        public Component()
        {
        }
    }

    public class Container : Component
    {
        public Container()
        {
        }
    }

    public class JLayeredPane : Container
    {
        public JLayeredPane()
        {
        }
    }

    public class JMenuBar
    {
        public JMenuBar()
        {
        }
    }

    public class JRootPane
    {
        public JRootPane()
        {
        }
    }

    public class Image
    {
        public Image()
        {
        }
    }

    public class Graphics
    {
        public Graphics()
        {
        }
    }

    public class TransferHandler
    {
        public TransferHandler()
        {
        }
    }

    public class AccessibleContext
    {
        public AccessibleContext()
        {
        }
    }

    public interface LayoutManager
    {
    }
}