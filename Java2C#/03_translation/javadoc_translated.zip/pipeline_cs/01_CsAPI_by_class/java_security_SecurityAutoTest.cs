```csharp
using System;
using System.Collections;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_security_SecurityAutoTest
    {
        public void getProperty_test_10968(string p0)
        {
            Security.GetProperty(p0);
        }

        public void setProperty_test_10969(string p0, string p1)
        {
            Security.SetProperty(p0, p1);
        }

        public void addProvider_test_10970(Provider p0)
        {
            Security.AddProvider(p0);
        }

        public void insertProviderAt_test_10971(Provider p0, int p1)
        {
            Security.InsertProviderAt(p0, p1);
        }

        public void getProvider_test_10972(string p0)
        {
            Security.GetProvider(p0);
        }

        public void getProviders_test_10973()
        {
            Security.GetProviders();
        }

        public void getProviders_test_10974(IDictionary p0)
        {
            Security.GetProviders(p0);
        }

        public void getProviders_test_10975(string p0)
        {
            Security.GetProviders(p0);
        }

        public void getAlgorithmProperty_test_10976(string p0, string p1)
        {
            Security.GetAlgorithmProperty(p0, p1);
        }

        public void removeProvider_test_10977(string p0)
        {
            Security.RemoveProvider(p0);
        }

        public void getAlgorithms_test_10978(string p0)
        {
            Security.GetAlgorithms(p0);
        }
    }

    public class Provider
    {
        private readonly string name;
        private readonly double version;
        private readonly string info;
        private readonly Dictionary<string, string> properties = new Dictionary<string, string>();

        public Provider(string name, double version, string info)
        {
            this.name = name;
            this.version = version;
            this.info = info;
        }

        public string GetName()
        {
            return name;
        }

        public double GetVersion()
        {
            return version;
        }

        public string GetInfo()
        {
            return info;
        }

        public string GetProperty(string key)
        {
            if (key == null) throw new ArgumentNullException("key");
            string value;
            properties.TryGetValue(key, out value);
            return value;
        }

        public object Put(object key, object value)
        {
            if (key == null) throw new ArgumentNullException("key");
            if (value == null) throw new ArgumentNullException("value");
            string k = key as string;
            string v = value as string;
            if (k == null) throw new ArgumentException("key must be a String");
            if (v == null) throw new ArgumentException("value must be a String");
            string old;
            properties.TryGetValue(k, out old);
            properties[k] = v;
            return old;
        }

        public object Get(object key)
        {
            string k = key as string;
            if (k == null) return null;
            return GetProperty(k);
        }

        public IEnumerable<KeyValuePair<string, string>> Entries
        {
            get { return properties; }
        }
    }

    public static class Security
    {
        private static readonly Dictionary<string, string> securityProperties = new Dictionary<string, string>();
        private static readonly List<Provider> providers = new List<Provider>();

        public static string GetProperty(string key)
        {
            if (key == null) throw new ArgumentNullException("key");
            string value;
            securityProperties.TryGetValue(key, out value);
            return value;
        }

        public static void SetProperty(string key, string value)
        {
            if (key == null) throw new ArgumentNullException("key");
            if (value == null) throw new ArgumentNullException("value");
            securityProperties[key] = value;
        }

        public static int AddProvider(Provider provider)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            foreach (Provider p in providers)
            {
                if (p.GetName() == provider.GetName()) return -1;
            }
            providers.Add(provider);
            return providers.Count;
        }

        public static int InsertProviderAt(Provider provider, int position)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            int existingIndex = -1;
            for (int i = 0; i < providers.Count; i++)
            {
                if (providers[i].GetName() == provider.GetName())
                {
                    existingIndex = i;
                    break;
                }
            }

            if (existingIndex == -1)
            {
                int targetIndex = Math.Max(0, position - 1);
                if (targetIndex > providers.Count) targetIndex = providers.Count;
                providers.Insert(targetIndex, provider);
                return targetIndex + 1;
            }
            else
            {
                if ((existingIndex + 1) == position) return -1;
                providers.RemoveAt(existingIndex);
                int targetIndex = Math.Max(0, position - 1);
                if (targetIndex > providers.Count) targetIndex = providers.Count;
                providers.Insert(targetIndex, provider);
                return targetIndex + 1;
            }
        }

        public static Provider GetProvider(string name)
        {
            if (name == null) throw new ArgumentNullException("name");
            foreach (Provider p in providers)
            {
                if (p.GetName() == name) return p;
            }
            return null;
        }

        public static Provider[] GetProviders()
        {
            return providers.ToArray();
        }

        public static Provider[] GetProviders(IDictionary filter)
        {
            if (filter == null) return GetProviders();
            List<Provider> result = new List<Provider>();
            foreach (Provider p in providers)
            {
                if (MatchesFilter(p, filter)) result.Add(p);
            }
            return result.ToArray();
        }

        public static Provider[] GetProviders(string filter)
        {
            if (filter == null) return GetProviders();
            List<Provider> result = new List<Provider>();
            foreach (Provider p in providers)
            {
                if (MatchesFilterString(p, filter)) result.Add(p);
            }
            return result.ToArray();
        }

        public static string GetAlgorithmProperty(string algName, string propName)
        {
            if (algName == null || propName == null) return null;
            string key = algName + " " + propName;
            foreach (Provider p in providers)
            {
                string value = p.GetProperty(key);
                if (value != null) return value;
            }
            return null;
        }

        public static void RemoveProvider(string name)
        {
            if (name == null) throw new ArgumentNullException("name");
            providers.RemoveAll(p => p.GetName() == name);
        }

        public static ISet<string> GetAlgorithms(string serviceName)
        {
            if (serviceName == null) throw new ArgumentNullException("serviceName");
            HashSet<string> algorithms = new HashSet<string>();
            string prefix = serviceName + ".";
            foreach (Provider p in providers)
            {
                foreach (KeyValuePair<string, string> entry in p.Entries)
                {
                    string key = entry.Key;
                    if (key.StartsWith(prefix, StringComparison.Ordinal))
                    {
                        string rest = key.Substring(prefix.Length);
                        int dotIndex = rest.IndexOf('.');
                        string algorithm = dotIndex >= 0 ? rest.Substring(0, dotIndex) : rest;
                        if (algorithm.Length > 0) algorithms.Add(algorithm);
                    }
                }
            }
            return algorithms;
        }

        private static bool MatchesFilter(Provider p, IDictionary filter)
        {
            foreach (DictionaryEntry entry in filter)
            {
                string key = entry.Key as string;
                string value = entry.Value as string;
                if (key == null) return false;
                string providerValue = p.GetProperty(key);
                if (value == "*")
                {
                    if (providerValue == null) return false;
                }
                else
                {
                    if (!string.Equals(providerValue, value)) return false;
                }
            }
            return true;
        }

        private static bool MatchesFilterString(Provider p, string filter)
        {
            string[] parts = filter.Split('|');
            foreach (string part in parts)
            {
                string trimmed = part.Trim();
                if (trimmed.Length == 0) continue;
                string key = trimmed;
                string value = null;
                int colonIndex = trimmed.IndexOf(':');
                if (colonIndex >= 0)
                {
                    key = trimmed.Substring(0, colonIndex);
                    value = trimmed.Substring(colonIndex + 1);
                }
                string providerValue = p.GetProperty(key);
                if (value == null)
                {
                    if (providerValue == null) return false;
                }
                else if (value == "*")
                {
                    if (providerValue == null) return false;
                }
                else
                {
                    if (!string.Equals(providerValue, value)) return false;
                }
            }
            return true;
        }
    }
}
```