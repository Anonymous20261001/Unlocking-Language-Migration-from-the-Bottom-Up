using System;
using System.Text;

namespace Generated.Test
{
    public class javax_management_ObjectNameAutoTest
    {
        public void unquote_test_9594(string p0)
        {
            ObjectName.unquote(p0);
        }

        public void getInstance_test_9595(ObjectName p0)
        {
            ObjectName.getInstance(p0);
        }

        public void quote_test_9596(string p0)
        {
            ObjectName.quote(p0);
        }
    }

    public class ObjectName
    {
        public ObjectName(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }
        }

        public static string quote(string value)
        {
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }

            if (value.Length > 1 && value[0] == '"' && value[value.Length - 1] == '"')
            {
                return value;
            }

            StringBuilder buf = new StringBuilder(value.Length + 2);
            buf.Append('"');

            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (c == '"' || c == '\\' || c == '\n' || c == '\r' || c == '\t')
                {
                    buf.Append('\\');
                }
                buf.Append(c);
            }

            buf.Append('"');
            return buf.ToString();
        }

        public static string unquote(string q)
        {
            if (q == null)
            {
                throw new ArgumentNullException("q");
            }

            if (q.Length < 2 || q[0] != '"' || q[q.Length - 1] != '"')
            {
                return q;
            }

            StringBuilder sb = new StringBuilder(q.Length - 2);
            int i = 1;
            int len = q.Length - 1;

            while (i < len)
            {
                char c = q[i];

                if (c == '\\')
                {
                    i++;
                    if (i >= len)
                    {
                        break;
                    }

                    char d = q[i];
                    switch (d)
                    {
                        case 'n':
                            c = '\n';
                            break;
                        case 'r':
                            c = '\r';
                            break;
                        case 't':
                            c = '\t';
                            break;
                        default:
                            c = d;
                            break;
                    }
                }

                sb.Append(c);
                i++;
            }

            return sb.ToString();
        }

        public static ObjectName getInstance(ObjectName name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            return name;
        }
    }
}