using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Logger
    {
        private static readonly object syncRoot = new object();
        private static readonly Dictionary<string, Logger> loggers = new Dictionary<string, Logger>();
        private static readonly Logger global = new Logger("global", null);

        private string name;
        private string resourceBundleName;

        private Logger(string name, string resourceBundleName)
        {
            this.name = name;
            this.resourceBundleName = resourceBundleName;
        }

        public static Logger getLogger(string name)
        {
            if (name == null)
            {
                throw new NullReferenceException();
            }

            lock (syncRoot)
            {
                Logger logger;
                if (!loggers.TryGetValue(name, out logger))
                {
                    logger = new Logger(name, null);
                    loggers[name] = logger;
                }
                return logger;
            }
        }

        public static Logger getLogger(string name, string resourceBundleName)
        {
            if (name == null)
            {
                throw new NullReferenceException();
            }

            lock (syncRoot)
            {
                Logger logger;
                if (!loggers.TryGetValue(name, out logger))
                {
                    logger = new Logger(name, resourceBundleName);
                    loggers[name] = logger;
                }
                return logger;
            }
        }

        public static Logger getAnonymousLogger()
        {
            return new Logger(null, null);
        }

        public static Logger getAnonymousLogger(string resourceBundleName)
        {
            return new Logger(null, resourceBundleName);
        }

        public static Logger getGlobal()
        {
            return global;
        }
    }

    public class java_util_logging_LoggerAutoTest
    {
        public void getLogger_test_8104(string p0)
        {
            Logger.getLogger(p0);
        }

        public void getLogger_test_8105(string p0, string p1)
        {
            Logger.getLogger(p0, p1);
        }

        public void getAnonymousLogger_test_8106()
        {
            Logger.getAnonymousLogger();
        }

        public void getAnonymousLogger_test_8107(string p0)
        {
            Logger.getAnonymousLogger(p0);
        }

        public void getGlobal_test_8108()
        {
            Logger.getGlobal();
        }
    }
}