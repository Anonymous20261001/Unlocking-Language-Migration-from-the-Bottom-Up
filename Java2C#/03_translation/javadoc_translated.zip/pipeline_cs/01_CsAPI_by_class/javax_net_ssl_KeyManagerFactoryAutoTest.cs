using javax.net.ssl;

namespace Generated.Test
{
    public class javax_net_ssl_KeyManagerFactoryAutoTest
    {
        public void getDefaultAlgorithm_test_7628()
        {
            KeyManagerFactory.getDefaultAlgorithm();
        }
    }
}

namespace javax.net.ssl
{
    public class KeyManagerFactory
    {
        public static string getDefaultAlgorithm()
        {
            return "SunX509";
        }
    }
}