using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Currency
    {
        private static readonly Dictionary<string, Currency> instances = new Dictionary<string, Currency>();

        private readonly string _currencyCode;
        private readonly int _numericCode;
        private readonly int _defaultFractionDigits;
        private readonly string _displayName;
        private readonly string _symbol;

        private Currency(string currencyCode)
        {
            _currencyCode = currencyCode;

            switch (currencyCode)
            {
                case "USD":
                    _numericCode = 840;
                    _defaultFractionDigits = 2;
                    _displayName = "US Dollar";
                    _symbol = "$";
                    break;
                case "EUR":
                    _numericCode = 978;
                    _defaultFractionDigits = 2;
                    _displayName = "Euro";
                    _symbol = "€";
                    break;
                case "JPY":
                    _numericCode = 392;
                    _defaultFractionDigits = 0;
                    _displayName = "Japanese Yen";
                    _symbol = "¥";
                    break;
                case "GBP":
                    _numericCode = 826;
                    _defaultFractionDigits = 2;
                    _displayName = "British Pound Sterling";
                    _symbol = "£";
                    break;
                case "CNY":
                    _numericCode = 156;
                    _defaultFractionDigits = 2;
                    _displayName = "Chinese Yuan";
                    _symbol = "¥";
                    break;
                default:
                    _numericCode = 0;
                    _defaultFractionDigits = 2;
                    _displayName = currencyCode;
                    _symbol = currencyCode;
                    break;
            }
        }

        public static Currency getInstance(string currencyCode)
        {
            if (currencyCode == null)
                throw new ArgumentNullException(nameof(currencyCode));

            if (currencyCode.Length != 3)
                throw new ArgumentException("currencyCode is not a supported ISO 4217 code.", nameof(currencyCode));

            Currency existing;
            if (!instances.TryGetValue(currencyCode, out existing))
            {
                existing = new Currency(currencyCode);
                instances[currencyCode] = existing;
            }

            return existing;
        }

        public static Currency getInstance(Locale locale)
        {
            if (locale == null)
                throw new ArgumentNullException(nameof(locale));

            string country = locale.getCountry();
            if (string.IsNullOrEmpty(country))
                throw new ArgumentException("Locale does not specify a country.", nameof(locale));

            return getInstance(country);
        }

        public static ISet<Currency> getAvailableCurrencies()
        {
            return new HashSet<Currency>
            {
                getInstance("USD"),
                getInstance("EUR"),
                getInstance("JPY"),
                getInstance("GBP"),
                getInstance("CNY")
            };
        }

        public static ISet<Currency> availableCurrencies()
        {
            return getAvailableCurrencies();
        }
    }

    public class Locale
    {
        private readonly string _language;
        private readonly string _country;
        private readonly string _variant;

        public Locale(string language)
            : this(language, string.Empty, string.Empty)
        {
        }

        public Locale(string language, string country)
            : this(language, country, string.Empty)
        {
        }

        public Locale(string language, string country, string variant)
        {
            _language = language ?? string.Empty;
            _country = country ?? string.Empty;
            _variant = variant ?? string.Empty;
        }

        public string getLanguage()
        {
            return _language;
        }

        public string getCountry()
        {
            return _country;
        }

        public string getVariant()
        {
            return _variant;
        }

        public string toString()
        {
            return _language + "_" + _country + "_" + _variant;
        }
    }

    public class java_util_CurrencyAutoTest
    {
        public void getAvailableCurrencies_test_3161()
        {
            Currency.getAvailableCurrencies();
        }

        public void availableCurrencies_test_3162()
        {
            Currency.availableCurrencies();
        }

        public void getInstance_test_3163(Locale p0)
        {
            Currency.getInstance(p0);
        }

        public void getInstance_test_3164(string p0)
        {
            Currency.getInstance(p0);
        }
    }
}