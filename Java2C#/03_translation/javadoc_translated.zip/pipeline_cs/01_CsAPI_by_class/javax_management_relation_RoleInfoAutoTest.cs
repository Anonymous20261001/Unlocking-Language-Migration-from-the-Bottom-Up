using System;

namespace Generated.Test
{
    public class RoleInfo
    {
        private string description;
        private string name;
        private string refMBeanClassName;
        private bool readable;
        private bool writable;
        private int minDegree;
        private int maxDegree;

        public RoleInfo()
        {
        }

        public RoleInfo(RoleInfo roleInfo)
        {
            if (roleInfo == null)
                throw new ArgumentNullException("roleInfo");

            description = roleInfo.description;
            name = roleInfo.name;
            refMBeanClassName = roleInfo.refMBeanClassName;
            readable = roleInfo.readable;
            writable = roleInfo.writable;
            minDegree = roleInfo.minDegree;
            maxDegree = roleInfo.maxDegree;
        }

        public string getDescription()
        {
            return description;
        }

        public int getMinDegree()
        {
            return minDegree;
        }

        public int getMaxDegree()
        {
            return maxDegree;
        }

        public string getRefMBeanClassName()
        {
            return refMBeanClassName;
        }

        public string getName()
        {
            return name;
        }

        public bool isWritable()
        {
            return writable;
        }

        public bool isReadable()
        {
            return readable;
        }

        public void checkMinDegree(int value)
        {
            if (value < -1 || value > minDegree)
                throw new ArgumentException("incorrect min degree");
        }

        public void checkMaxDegree(int value)
        {
            if (value < -1 || value > maxDegree)
                throw new ArgumentException("incorrect max degree");
        }
    }

    public class javax_management_relation_RoleInfoAutoTest
    {
        public void getDescription_test_10645(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.getDescription();
        }

        public void getMinDegree_test_10646(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.getMinDegree();
        }

        public void getMaxDegree_test_10647(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.getMaxDegree();
        }

        public void checkMinDegree_test_10648(int p0, RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.checkMinDegree(p0);
        }

        public void checkMaxDegree_test_10649(int p0, RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.checkMaxDegree(p0);
        }

        public void getRefMBeanClassName_test_10650(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.getRefMBeanClassName();
        }

        public void getName_test_10651(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.getName();
        }

        public void isWritable_test_10652(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.isWritable();
        }

        public void isReadable_test_10653(RoleInfo c0)
        {
            RoleInfo instance = new RoleInfo(c0);
            instance.isReadable();
        }
    }
}