namespace Generated.Test
{
    public class InetAddress
    {
        private byte[] addressBytes;

        private InetAddress(byte[] addressBytes)
        {
            this.addressBytes = addressBytes;
        }

        public static InetAddress ofLiteral(string literal)
        {
            if (literal == null)
            {
                throw new System.ArgumentNullException("literal");
            }

            System.Net.IPAddress ip;
            if (!System.Net.IPAddress.TryParse(literal, out ip))
            {
                throw new System.ArgumentException("Invalid IP address literal", "literal");
            }

            return new InetAddress(ip.GetAddressBytes());
        }

        public static InetAddress getLoopbackAddress()
        {
            return new InetAddress(new byte[] { 127, 0, 0, 1 });
        }
    }

    public class java_net_InetAddressAutoTest
    {
        public void ofLiteral_test_5795(string p0)
        {
            InetAddress.ofLiteral(p0);
        }

        public void getLoopbackAddress_test_5796()
        {
            InetAddress.getLoopbackAddress();
        }
    }
}