using System;

namespace Generated.Test
{
    public class DoubleBuffer
    {
        private readonly double[] _array;
        private int _position;
        private int _limit;
        private int _capacity;

        private DoubleBuffer(double[] array, int position, int limit)
        {
            _array = array;
            _capacity = array.Length;
            _position = position;
            _limit = limit;
        }

        public static DoubleBuffer wrap(double[] array)
        {
            if (array == null)
                throw new ArgumentNullException("array");

            return new DoubleBuffer(array, 0, array.Length);
        }

        public static DoubleBuffer wrap(double[] array, int offset, int length)
        {
            if (array == null)
                throw new ArgumentNullException("array");

            if (offset < 0 || length < 0 || offset > array.Length - length)
                throw new IndexOutOfRangeException();

            return new DoubleBuffer(array, offset, offset + length);
        }

        public static DoubleBuffer allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity");

            return new DoubleBuffer(new double[capacity], 0, capacity);
        }

        public int Position
        {
            get { return _position; }
        }

        public int Limit
        {
            get { return _limit; }
        }

        public int Capacity
        {
            get { return _capacity; }
        }

        public int Remaining
        {
            get { return _limit - _position; }
        }

        public bool HasRemaining
        {
            get { return _position < _limit; }
        }
    }

    public class java_nio_DoubleBufferAutoTest
    {
        public void wrap_test_4265(double[] p0)
        {
            DoubleBuffer.wrap(p0);
        }

        public void wrap_test_4266(double[] p0, int p1, int p2)
        {
            DoubleBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_4267(int p0)
        {
            DoubleBuffer.allocate(p0);
        }
    }
}