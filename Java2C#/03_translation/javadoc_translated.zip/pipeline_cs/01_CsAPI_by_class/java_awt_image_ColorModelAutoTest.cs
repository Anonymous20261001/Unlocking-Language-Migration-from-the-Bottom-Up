namespace Generated.Test
{
    public class ColorModel
    {
        public static ColorModel getRGBdefault()
        {
            return new ColorModel();
        }
    }

    public class java_awt_image_ColorModelAutoTest
    {
        public void getRGBdefault_test_2502()
        {
            ColorModel.getRGBdefault();
        }
    }
}