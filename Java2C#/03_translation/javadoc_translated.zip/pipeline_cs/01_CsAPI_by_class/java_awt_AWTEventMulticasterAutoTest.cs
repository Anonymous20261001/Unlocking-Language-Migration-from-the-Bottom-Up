using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface EventListener {}
    public interface ActionListener : EventListener {}
    public interface AdjustmentListener : EventListener {}
    public interface ComponentListener : EventListener {}
    public interface ContainerListener : EventListener {}
    public interface FocusListener : EventListener {}
    public interface HierarchyBoundsListener : EventListener {}
    public interface HierarchyListener : EventListener {}
    public interface InputMethodListener : EventListener {}
    public interface ItemListener : EventListener {}
    public interface KeyListener : EventListener {}
    public interface MouseListener : EventListener {}
    public interface MouseMotionListener : EventListener {}
    public interface MouseWheelListener : EventListener {}
    public interface TextListener : EventListener {}
    public interface WindowFocusListener : EventListener {}
    public interface WindowListener : EventListener {}
    public interface WindowStateListener : EventListener {}

    public class AWTEventMulticaster : EventListener, ActionListener, AdjustmentListener, ComponentListener, ContainerListener, FocusListener, HierarchyBoundsListener, HierarchyListener, InputMethodListener, ItemListener, KeyListener, MouseListener, MouseMotionListener, MouseWheelListener, TextListener, WindowFocusListener, WindowListener, WindowStateListener
    {
        private readonly EventListener _a;
        private readonly EventListener _b;

        private AWTEventMulticaster(EventListener a, EventListener b)
        {
            _a = a;
            _b = b;
        }

        private static T AddInternal<T>(T a, T b) where T : class, EventListener
        {
            if (a == null) return b;
            if (b == null) return a;
            return (T)(object)new AWTEventMulticaster(a, b);
        }

        private static T RemoveInternal<T>(T a, T b) where T : class, EventListener
        {
            if (a == null || b == null) return a;
            if (ReferenceEquals(a, b)) return null;
            var m = a as AWTEventMulticaster;
            if (m != null) return (T)(object)m.Remove(b);
            return a;
        }

        private EventListener Remove(EventListener b)
        {
            if (ReferenceEquals(_a, b)) return _b;
            if (ReferenceEquals(_b, b)) return _a;

            var ma = _a as AWTEventMulticaster;
            if (ma != null)
            {
                var na = ma.Remove(b);
                if (!ReferenceEquals(na, _a))
                    return new AWTEventMulticaster(na, _b);
            }

            var mb = _b as AWTEventMulticaster;
            if (mb != null)
            {
                var nb = mb.Remove(b);
                if (!ReferenceEquals(nb, _b))
                    return new AWTEventMulticaster(_a, nb);
            }

            return this;
        }

        public static EventListener[] getListeners(EventListener l, Type listenerType)
        {
            var list = new List<EventListener>();
            CollectListeners(l, listenerType, list);
            return list.ToArray();
        }

        private static void CollectListeners(EventListener l, Type listenerType, List<EventListener> list)
        {
            if (l == null) return;

            var m = l as AWTEventMulticaster;
            if (m != null)
            {
                CollectListeners(m._a, listenerType, list);
                CollectListeners(m._b, listenerType, list);
            }
            else if (listenerType.IsInstanceOfType(l))
            {
                list.Add(l);
            }
        }

        public static ComponentListener add(ComponentListener a, ComponentListener b) { return AddInternal(a, b); }
        public static ContainerListener add(ContainerListener a, ContainerListener b) { return AddInternal(a, b); }
        public static KeyListener add(KeyListener a, KeyListener b) { return AddInternal(a, b); }
        public static FocusListener add(FocusListener a, FocusListener b) { return AddInternal(a, b); }
        public static MouseListener add(MouseListener a, MouseListener b) { return AddInternal(a, b); }
        public static MouseMotionListener add(MouseMotionListener a, MouseMotionListener b) { return AddInternal(a, b); }
        public static TextListener add(TextListener a, TextListener b) { return AddInternal(a, b); }
        public static AdjustmentListener add(AdjustmentListener a, AdjustmentListener b) { return AddInternal(a, b); }
        public static ItemListener add(ItemListener a, ItemListener b) { return AddInternal(a, b); }
        public static ActionListener add(ActionListener a, ActionListener b) { return AddInternal(a, b); }
        public static WindowFocusListener add(WindowFocusListener a, WindowFocusListener b) { return AddInternal(a, b); }
        public static WindowStateListener add(WindowStateListener a, WindowStateListener b) { return AddInternal(a, b); }
        public static WindowListener add(WindowListener a, WindowListener b) { return AddInternal(a, b); }
        public static MouseWheelListener add(MouseWheelListener a, MouseWheelListener b) { return AddInternal(a, b); }
        public static HierarchyBoundsListener add(HierarchyBoundsListener a, HierarchyBoundsListener b) { return AddInternal(a, b); }
        public static HierarchyListener add(HierarchyListener a, HierarchyListener b) { return AddInternal(a, b); }
        public static InputMethodListener add(InputMethodListener a, InputMethodListener b) { return AddInternal(a, b); }

        public static MouseMotionListener remove(MouseMotionListener a, MouseMotionListener b) { return RemoveInternal(a, b); }
        public static HierarchyListener remove(HierarchyListener a, HierarchyListener b) { return RemoveInternal(a, b); }
        public static WindowListener remove(WindowListener a, WindowListener b) { return RemoveInternal(a, b); }
        public static MouseListener remove(MouseListener a, MouseListener b) { return RemoveInternal(a, b); }
        public static KeyListener remove(KeyListener a, KeyListener b) { return RemoveInternal(a, b); }
        public static FocusListener remove(FocusListener a, FocusListener b) { return RemoveInternal(a, b); }
        public static InputMethodListener remove(InputMethodListener a, InputMethodListener b) { return RemoveInternal(a, b); }
        public static TextListener remove(TextListener a, TextListener b) { return RemoveInternal(a, b); }
        public static AdjustmentListener remove(AdjustmentListener a, AdjustmentListener b) { return RemoveInternal(a, b); }
        public static ItemListener remove(ItemListener a, ItemListener b) { return RemoveInternal(a, b); }
        public static ActionListener remove(ActionListener a, ActionListener b) { return RemoveInternal(a, b); }
        public static WindowFocusListener remove(WindowFocusListener a, WindowFocusListener b) { return RemoveInternal(a, b); }
        public static WindowStateListener remove(WindowStateListener a, WindowStateListener b) { return RemoveInternal(a, b); }
        public static MouseWheelListener remove(MouseWheelListener a, MouseWheelListener b) { return RemoveInternal(a, b); }
        public static ContainerListener remove(ContainerListener a, ContainerListener b) { return RemoveInternal(a, b); }
        public static ComponentListener remove(ComponentListener a, ComponentListener b) { return RemoveInternal(a, b); }
        public static HierarchyBoundsListener remove(HierarchyBoundsListener a, HierarchyBoundsListener b) { return RemoveInternal(a, b); }
    }

    public class java_awt_AWTEventMulticasterAutoTest
    {
        public void getListeners_test_911(EventListener p0, Type p1)
        {
            AWTEventMulticaster.getListeners(p0, p1);
        }

        public void remove_test_912(MouseMotionListener p0, MouseMotionListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_913(HierarchyListener p0, HierarchyListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_914(WindowListener p0, WindowListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_915(MouseListener p0, MouseListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_916(KeyListener p0, KeyListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_917(FocusListener p0, FocusListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_918(InputMethodListener p0, InputMethodListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_919(TextListener p0, TextListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_920(AdjustmentListener p0, AdjustmentListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_921(ItemListener p0, ItemListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_922(ActionListener p0, ActionListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_923(WindowFocusListener p0, WindowFocusListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_924(WindowStateListener p0, WindowStateListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_925(MouseWheelListener p0, MouseWheelListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_926(ContainerListener p0, ContainerListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_927(ComponentListener p0, ComponentListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void remove_test_928(HierarchyBoundsListener p0, HierarchyBoundsListener p1)
        {
            AWTEventMulticaster.remove(p0, p1);
        }

        public void add_test_929(ComponentListener p0, ComponentListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_930(ContainerListener p0, ContainerListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_931(KeyListener p0, KeyListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_932(FocusListener p0, FocusListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_933(MouseListener p0, MouseListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_934(MouseMotionListener p0, MouseMotionListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_935(TextListener p0, TextListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_936(AdjustmentListener p0, AdjustmentListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_937(ItemListener p0, ItemListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_938(ActionListener p0, ActionListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_939(WindowFocusListener p0, WindowFocusListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_940(WindowStateListener p0, WindowStateListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_941(WindowListener p0, WindowListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_942(MouseWheelListener p0, MouseWheelListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_943(HierarchyBoundsListener p0, HierarchyBoundsListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_944(HierarchyListener p0, HierarchyListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }

        public void add_test_945(InputMethodListener p0, InputMethodListener p1)
        {
            AWTEventMulticaster.add(p0, p1);
        }
    }
}