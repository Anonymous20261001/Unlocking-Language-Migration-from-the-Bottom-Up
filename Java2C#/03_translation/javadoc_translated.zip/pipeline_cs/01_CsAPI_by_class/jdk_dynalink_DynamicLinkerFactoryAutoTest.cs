using System.Collections.Generic;

namespace Generated.Test
{
    public class ClassLoader
    {
    }

    public class DynamicLinker
    {
    }

    public interface GuardingDynamicLinker
    {
    }

    public interface GuardedInvocationTransformer
    {
    }

    public interface MethodTypeConversionStrategy
    {
    }

    public interface MethodHandleTransformer
    {
    }

    public class DynamicLinkerFactory
    {
        private System.Collections.IList fallbackLinkers;
        private System.Collections.IList prioritizedLinkers;
        private ClassLoader classLoader;
        private bool syncOnRelink;
        private int unstableRelinkThreshold;
        private GuardedInvocationTransformer prelinkTransformer;
        private MethodTypeConversionStrategy autoConversionStrategy;
        private MethodHandleTransformer internalObjectsFilter;
        private readonly List<object> autoLoadingErrors = new List<object>();

        public void setFallbackLinkers(System.Collections.IList p0)
        {
            fallbackLinkers = p0;
        }

        public void setFallbackLinkers(GuardingDynamicLinker[] p0)
        {
        }

        public void setClassLoader(ClassLoader p0)
        {
            classLoader = p0;
        }

        public void setSyncOnRelink(bool p0)
        {
            syncOnRelink = p0;
        }

        public DynamicLinker createLinker()
        {
            return new DynamicLinker();
        }

        public void setPrioritizedLinkers(System.Collections.IList p0)
        {
            prioritizedLinkers = p0;
        }

        public void setPrioritizedLinkers(GuardingDynamicLinker[] p0)
        {
        }

        public void setPrioritizedLinker(GuardingDynamicLinker p0)
        {
        }

        public void setUnstableRelinkThreshold(int p0)
        {
            unstableRelinkThreshold = p0;
        }

        public void setPrelinkTransformer(GuardedInvocationTransformer p0)
        {
            prelinkTransformer = p0;
        }

        public void setAutoConversionStrategy(MethodTypeConversionStrategy p0)
        {
            autoConversionStrategy = p0;
        }

        public void setInternalObjectsFilter(MethodHandleTransformer p0)
        {
            internalObjectsFilter = p0;
        }

        public System.Collections.IList getAutoLoadingErrors()
        {
            return autoLoadingErrors;
        }
    }

    public class jdk_dynalink_DynamicLinkerFactoryAutoTest
    {
        public void setFallbackLinkers_test_4425(System.Collections.IList p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setFallbackLinkers(p0);
        }

        public void setFallbackLinkers_test_4426(GuardingDynamicLinker[] p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setFallbackLinkers(p0);
        }

        public void setClassLoader_test_4427(ClassLoader p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setClassLoader(p0);
        }

        public void setSyncOnRelink_test_4428(bool p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setSyncOnRelink(p0);
        }

        public void createLinker_test_4429()
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.createLinker();
        }

        public void setPrioritizedLinkers_test_4430(System.Collections.IList p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setPrioritizedLinkers(p0);
        }

        public void setPrioritizedLinkers_test_4431(GuardingDynamicLinker[] p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setPrioritizedLinkers(p0);
        }

        public void setPrioritizedLinker_test_4432(GuardingDynamicLinker p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setPrioritizedLinker(p0);
        }

        public void setUnstableRelinkThreshold_test_4433(int p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setUnstableRelinkThreshold(p0);
        }

        public void setPrelinkTransformer_test_4434(GuardedInvocationTransformer p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setPrelinkTransformer(p0);
        }

        public void setAutoConversionStrategy_test_4435(MethodTypeConversionStrategy p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setAutoConversionStrategy(p0);
        }

        public void setInternalObjectsFilter_test_4436(MethodHandleTransformer p0)
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.setInternalObjectsFilter(p0);
        }

        public void getAutoLoadingErrors_test_4437()
        {
            DynamicLinkerFactory instance = new DynamicLinkerFactory();
            instance.getAutoLoadingErrors();
        }
    }
}