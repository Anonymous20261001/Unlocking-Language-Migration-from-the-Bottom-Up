using System;

namespace Generated.Test
{
    public sealed class Class
    {
        private readonly Type type;
        public Class(Type type)
        {
            this.type = type;
        }

        public Type UnderlyingType
        {
            get { return type; }
        }
    }

    public sealed class MethodType
    {
        public Type ReturnType { get; private set; }
        public Type[] ParameterTypes { get; private set; }

        public MethodType(Type returnType, params Type[] parameterTypes)
        {
            ReturnType = returnType;
            ParameterTypes = parameterTypes;
        }
    }

    public sealed class MethodHandle
    {
    }

    public interface LinkerServices
    {
    }

    public static class Guards
    {
        public static MethodHandle isInstance(Class p0, MethodType p1)
        {
            return null;
        }

        public static MethodHandle isInstance(Class p0, int p1, MethodType p2)
        {
            return null;
        }

        public static MethodHandle isArray(int p0, MethodType p1)
        {
            return null;
        }

        public static MethodHandle asType(LinkerServices p0, MethodHandle p1, MethodType p2)
        {
            return null;
        }

        public static MethodHandle asType(MethodHandle p0, MethodType p1)
        {
            return null;
        }

        public static MethodHandle isNull()
        {
            return null;
        }

        public static MethodHandle isOfClass(Class p0, MethodType p1)
        {
            return null;
        }

        public static MethodHandle isNotNull()
        {
            return null;
        }

        public static MethodHandle getClassGuard(Class p0)
        {
            return null;
        }

        public static MethodHandle getInstanceOfGuard(Class p0)
        {
            return null;
        }

        public static MethodHandle getIdentityGuard(object p0)
        {
            return null;
        }
    }

    public class jdk_dynalink_linker_support_GuardsAutoTest
    {
        public void isInstance_test_5248(Class p0, MethodType p1)
        {
            Guards.isInstance(p0, p1);
        }

        public void isInstance_test_5249(Class p0, int p1, MethodType p2)
        {
            Guards.isInstance(p0, p1, p2);
        }

        public void isArray_test_5250(int p0, MethodType p1)
        {
            Guards.isArray(p0, p1);
        }

        public void asType_test_5251(LinkerServices p0, MethodHandle p1, MethodType p2)
        {
            Guards.asType(p0, p1, p2);
        }

        public void asType_test_5252(MethodHandle p0, MethodType p1)
        {
            Guards.asType(p0, p1);
        }

        public void isNull_test_5253()
        {
            Guards.isNull();
        }

        public void isOfClass_test_5254(Class p0, MethodType p1)
        {
            Guards.isOfClass(p0, p1);
        }

        public void isNotNull_test_5255()
        {
            Guards.isNotNull();
        }

        public void getClassGuard_test_5256(Class p0)
        {
            Guards.getClassGuard(p0);
        }

        public void getInstanceOfGuard_test_5257(Class p0)
        {
            Guards.getInstanceOfGuard(p0);
        }

        public void getIdentityGuard_test_5258(object p0)
        {
            Guards.getIdentityGuard(p0);
        }
    }
}