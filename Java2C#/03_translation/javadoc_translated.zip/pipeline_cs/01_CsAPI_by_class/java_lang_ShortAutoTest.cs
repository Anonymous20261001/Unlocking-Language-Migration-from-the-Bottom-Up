using System;

namespace Generated.Test
{
    public class Short
    {
        private readonly short value;

        public Short(short value)
        {
            this.value = value;
        }

        public static int compareUnsigned(short x, short y)
        {
            return (x & 0xFFFF) - (y & 0xFFFF);
        }

        public static short reverseBytes(short x)
        {
            return (short)(((x & 0xFF) << 8) | ((x >> 8) & 0xFF));
        }

        public int compareTo(Short anotherShort)
        {
            return (int)value - (int)anotherShort.value;
        }

        public static int compare(short x, short y)
        {
            return (int)x - (int)y;
        }

        public sbyte byteValue()
        {
            return unchecked((sbyte)value);
        }

        public short shortValue()
        {
            return value;
        }

        public int intValue()
        {
            return (int)value;
        }

        public long longValue()
        {
            return (long)value;
        }

        public float floatValue()
        {
            return (float)value;
        }

        public double doubleValue()
        {
            return (double)value;
        }

        public static Short valueOf(string s, int radix)
        {
            return new Short(parseShort(s, radix));
        }

        public static Short valueOf(string s)
        {
            return new Short(parseShort(s, 10));
        }

        public static Short valueOf(short s)
        {
            return new Short(s);
        }

        public static Short decode(string nm)
        {
            if (nm == null)
                throw new ArgumentNullException(nameof(nm));

            string str = nm.Trim();
            if (str.Length == 0)
                throw new FormatException("Cannot decode empty string");

            bool negative = false;
            if (str[0] == '+' || str[0] == '-')
            {
                negative = str[0] == '-';
                str = str.Substring(1);
                if (str.Length == 0)
                    throw new FormatException("Cannot decode sign only");
            }

            int radix;
            string digits;

            if (str.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || str.StartsWith("#", StringComparison.Ordinal))
            {
                radix = 16;
                digits = str.StartsWith("#", StringComparison.Ordinal) ? str.Substring(1) : str.Substring(2);
            }
            else if (str.Length >= 2 && str[0] == '0')
            {
                radix = 8;
                digits = str.Substring(1);
            }
            else
            {
                radix = 10;
                digits = str;
            }

            if (digits.Length == 0)
                digits = "0";

            int parsed = ParseIntInRadix(digits, radix);
            if (negative)
                parsed = -parsed;

            if (parsed < short.MinValue || parsed > short.MaxValue)
                throw new OverflowException("Value out of range for short");

            return new Short((short)parsed);
        }

        public object describeConstable()
        {
            return this;
        }

        public static long toUnsignedLong(short x)
        {
            return (long)(x & 0xFFFF);
        }

        public static int toUnsignedInt(short x)
        {
            return x & 0xFFFF;
        }

        public static short parseShort(string s)
        {
            return parseShort(s, 10);
        }

        public static short parseShort(string s, int radix)
        {
            if (radix < 2 || radix > 36)
                throw new FormatException("Radix out of range");

            if (s == null)
                throw new ArgumentNullException(nameof(s));

            string str = s;
            if (str.Length == 0)
                throw new FormatException("Cannot parse empty string");

            int index = 0;
            bool negative = false;

            if (str[0] == '+' || str[0] == '-')
            {
                negative = str[0] == '-';
                index++;
                if (index == str.Length)
                    throw new FormatException("Cannot parse sign only");
            }

            long result = 0;
            while (index < str.Length)
            {
                char c = str[index++];
                int digit = CharToDigit(c);

                if (digit < 0 || digit >= radix)
                    throw new FormatException($"Invalid digit '{c}' for radix {radix}");

                result = result * radix + digit;

                if (result > 32768L)
                    throw new OverflowException("Value out of range for short");
            }

            if (negative)
                result = -result;

            if (result < short.MinValue || result > short.MaxValue)
                throw new OverflowException("Value out of range for short");

            return (short)result;
        }

        private static int CharToDigit(char c)
        {
            if (c >= '0' && c <= '9')
                return c - '0';
            if (c >= 'a' && c <= 'z')
                return c - 'a' + 10;
            if (c >= 'A' && c <= 'Z')
                return c - 'A' + 10;
            return -1;
        }

        private static int ParseIntInRadix(string digits, int radix)
        {
            long result = 0;
            foreach (char c in digits)
            {
                int digit = CharToDigit(c);
                if (digit < 0 || digit >= radix)
                    throw new FormatException("Invalid digit");

                result = result * radix + digit;
                if (result > int.MaxValue)
                    throw new OverflowException("Value out of range");
            }

            return (int)result;
        }
    }

    public class java_lang_ShortAutoTest
    {
        public void compareUnsigned_test_11079(short p0, short p1)
        {
            Short.compareUnsigned(p0, p1);
        }

        public void reverseBytes_test_11080(short p0)
        {
            Short.reverseBytes(p0);
        }

        public void compareTo_test_11081(Short p0, short c0)
        {
            Short instance = new Short(c0);
            instance.compareTo(p0);
        }

        public void compare_test_11082(short p0, short p1)
        {
            Short.compare(p0, p1);
        }

        public void byteValue_test_11083(short c0)
        {
            Short instance = new Short(c0);
            instance.byteValue();
        }

        public void shortValue_test_11084(short c0)
        {
            Short instance = new Short(c0);
            instance.shortValue();
        }

        public void intValue_test_11085(short c0)
        {
            Short instance = new Short(c0);
            instance.intValue();
        }

        public void longValue_test_11086(short c0)
        {
            Short instance = new Short(c0);
            instance.longValue();
        }

        public void floatValue_test_11087(short c0)
        {
            Short instance = new Short(c0);
            instance.floatValue();
        }

        public void doubleValue_test_11088(short c0)
        {
            Short instance = new Short(c0);
            instance.doubleValue();
        }

        public void valueOf_test_11089(string p0, int p1)
        {
            Short.valueOf(p0, p1);
        }

        public void valueOf_test_11090(string p0)
        {
            Short.valueOf(p0);
        }

        public void valueOf_test_11091(short p0)
        {
            Short.valueOf(p0);
        }

        public void decode_test_11092(string p0)
        {
            Short.decode(p0);
        }

        public void describeConstable_test_11093(short c0)
        {
            Short instance = new Short(c0);
            instance.describeConstable();
        }

        public void toUnsignedLong_test_11094(short p0)
        {
            Short.toUnsignedLong(p0);
        }

        public void toUnsignedInt_test_11095(short p0)
        {
            Short.toUnsignedInt(p0);
        }

        public void parseShort_test_11096(string p0)
        {
            Short.parseShort(p0);
        }

        public void parseShort_test_11097(string p0, int p1)
        {
            Short.parseShort(p0, p1);
        }
    }
}