using System;

namespace java.awt.image
{
    public class DataBuffer
    {
        public const int TYPE_BYTE = 0;
        public const int TYPE_USHORT = 1;
        public const int TYPE_SHORT = 2;
        public const int TYPE_INT = 3;
        public const int TYPE_FLOAT = 4;
        public const int TYPE_DOUBLE = 5;
        public const int TYPE_UNDEFINED = 32;

        public static int getDataTypeSize(int dataType)
        {
            switch (dataType)
            {
                case TYPE_BYTE:
                    return 8;
                case TYPE_USHORT:
                case TYPE_SHORT:
                    return 16;
                case TYPE_INT:
                case TYPE_FLOAT:
                    return 32;
                case TYPE_DOUBLE:
                    return 64;
                case TYPE_UNDEFINED:
                    return 32;
                default:
                    throw new ArgumentException("Unknown data type " + dataType);
            }
        }
    }
}

namespace Generated.Test
{
    public class java_awt_image_DataBufferAutoTest
    {
        public void getDataTypeSize_test_3173(int p0)
        {
            java.awt.image.DataBuffer.getDataTypeSize(p0);
        }
    }
}