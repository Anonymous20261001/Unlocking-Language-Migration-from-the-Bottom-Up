```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Notification
    {
        private readonly string _type;
        private readonly object _source;
        private readonly long _sequenceNumber;
        private readonly long _timeStamp;
        private readonly string _message;
        private object _userData;

        public Notification(string type, object source, long sequenceNumber)
            : this(type, source, sequenceNumber, 0L, null)
        {
        }

        public Notification(string type, object source, long sequenceNumber, string message)
            : this(type, source, sequenceNumber, 0L, message)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            _type = type;
            _source = source;
            _sequenceNumber = sequenceNumber;
            _timeStamp = timeStamp;
            _message = message;
        }

        public string Type
        {
            get { return _type; }
        }

        public object Source
        {
            get { return _source; }
        }

        public long SequenceNumber
        {
            get { return _sequenceNumber; }
        }

        public long TimeStamp
        {
            get { return _timeStamp; }
        }

        public string Message
        {
            get { return _message; }
        }

        public object UserData
        {
            get { return _userData; }
            set { _userData = value; }
        }
    }

    public interface NotificationFilter
    {
        bool IsNotificationEnabled(Notification notification);
    }

    public interface NotificationListener
    {
        void HandleNotification(Notification notification, object handback);
    }

    public class MBeanNotificationInfo
    {
        private readonly string[] _notificationTypes;
        private readonly string _name;
        private readonly string _description;

        public MBeanNotificationInfo(string[] notificationTypes, string name, string description)
        {
            _notificationTypes = (string[])notificationTypes.Clone();
            _name = name;
            _description = description;
        }

        public string[] GetNotificationTypes()
        {
            return (string[])_notificationTypes.Clone();
        }

        public string GetName()
        {
            return _name;
        }

        public string GetDescription()
        {
            return _description;
        }
    }

    public interface NotificationBroadcaster
    {
        void AddNotificationListener(NotificationListener listener, NotificationFilter filter, object handback);
        void RemoveNotificationListener(NotificationListener listener);
        MBeanNotificationInfo[] GetNotificationInfo();
    }

    public interface NotificationEmitter : NotificationBroadcaster
    {
        void RemoveNotificationListener(NotificationListener listener, NotificationFilter filter, object handback);
    }

    public class MBeanServerDelegate : NotificationEmitter
    {
        private readonly List<ListenerRegistration> _listeners = new List<ListenerRegistration>();

        private class ListenerRegistration
        {
            public NotificationListener Listener;
            public NotificationFilter Filter;
            public object Handback;
        }

        public MBeanServerDelegate()
        {
        }

        public void AddNotificationListener(NotificationListener listener, NotificationFilter filter, object handback)
        {
            if (listener == null)
            {
                throw new ArgumentNullException("listener");
            }
            _listeners.Add(new ListenerRegistration { Listener = listener, Filter = filter, Handback = handback });
        }

        public void RemoveNotificationListener(NotificationListener listener)
        {
            if (listener == null)
            {
                throw new ArgumentNullException("listener");
            }
            _listeners.RemoveAll(reg => reg.Listener == listener);
        }

        public void RemoveNotificationListener(NotificationListener listener, NotificationFilter filter, object handback)
        {
            if (listener == null)
            {
                throw new ArgumentNullException("listener");
            }
            _listeners.RemoveAll(reg => reg.Listener == listener && reg.Filter == filter && Equals(reg.Handback, handback));
        }

        public void SendNotification(Notification notification)
        {
            if (notification == null)
            {
                return;
            }

            for (int i = 0; i < _listeners.Count; i++)
            {
                ListenerRegistration reg = _listeners[i];
                if (reg.Filter == null || reg.Filter.IsNotificationEnabled(notification))
                {
                    reg.Listener.HandleNotification(notification, reg.Handback);
                }
            }
        }

        public MBeanNotificationInfo[] GetNotificationInfo()
        {
            return new MBeanNotificationInfo[0];
        }

        public string GetMBeanServerId()
        {
            return "mbean-server-id";
        }

        public string GetSpecificationName()
        {
            return "Java Management Extensions";
        }

        public string GetSpecificationVersion()
        {
            return "1.4";
        }

        public string GetSpecificationVendor()
        {
            return "Oracle Corporation";
        }

        public string GetImplementationName()
        {
            return "OpenJDK";
        }

        public string GetImplementationVersion()
        {
            return "1.0";
        }

        public string GetImplementationVendor()
        {
            return "Oracle Corporation";
        }
    }

    public class javax_management_MBeanServerDelegateAutoTest
    {
        public void getNotificationInfo_test_8432()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetNotificationInfo();
        }

        public void sendNotification_test_8433(Notification p0)
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.SendNotification(p0);
        }

        public void getMBeanServerId_test_8434()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetMBeanServerId();
        }

        public void getSpecificationName_test_8435()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationName();
        }

        public void getImplementationName_test_8436()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationName();
        }

        public void addNotificationListener_test_8437(NotificationListener p0, NotificationFilter p1, object p2)
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.AddNotificationListener(p0, p1, p2);
        }

        public void getSpecificationVersion_test_8438()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationVersion();
        }

        public void getSpecificationVendor_test_8439()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetSpecificationVendor();
        }

        public void getImplementationVersion_test_8440()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationVersion();
        }

        public void getImplementationVendor_test_8441()
        {
            MBeanServerDelegate instance = new MBeanServerDelegate();
            instance.GetImplementationVendor();
        }
    }
}
```