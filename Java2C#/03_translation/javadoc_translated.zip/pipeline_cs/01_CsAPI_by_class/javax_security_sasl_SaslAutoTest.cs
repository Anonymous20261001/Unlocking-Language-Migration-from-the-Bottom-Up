using System.Collections.Generic;

namespace Generated.Test
{
    public interface SaslClientFactory { }
    public interface SaslServerFactory { }

    public static class Sasl
    {
        public static IEnumerator<SaslClientFactory> getSaslClientFactories()
        {
            yield break;
        }

        public static IEnumerator<SaslServerFactory> getSaslServerFactories()
        {
            yield break;
        }
    }

    public class javax_security_sasl_SaslAutoTest
    {
        public void getSaslClientFactories_test_10758()
        {
            Sasl.getSaslClientFactories();
        }

        public void getSaslServerFactories_test_10759()
        {
            Sasl.getSaslServerFactories();
        }
    }
}