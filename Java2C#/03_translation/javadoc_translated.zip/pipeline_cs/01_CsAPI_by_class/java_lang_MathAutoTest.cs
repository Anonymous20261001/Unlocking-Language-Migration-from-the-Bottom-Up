namespace Generated.Test;

public class java_lang_MathAutoTest
{
    public void abs_test_8296(float p0)
    {
        Math.Abs(p0);
    }

    public void abs_test_8297(long p0)
    {
        Math.Abs(p0);
    }

    public void abs_test_8298(int p0)
    {
        Math.Abs(p0);
    }

    public void abs_test_8299(double p0)
    {
        Math.Abs(p0);
    }

    public void sin_test_8300(double p0)
    {
        Math.Sin(p0);
    }

    public void cos_test_8301(double p0)
    {
        Math.Cos(p0);
    }

    public void tan_test_8302(double p0)
    {
        Math.Tan(p0);
    }

    public void atan2_test_8303(double p0, double p1)
    {
        Math.Atan2(p0, p1);
    }

    public void sqrt_test_8304(double p0)
    {
        Math.Sqrt(p0);
    }

    public void log_test_8305(double p0)
    {
        Math.Log(p0);
    }

    public void log10_test_8306(double p0)
    {
        Math.Log10(p0);
    }

    public void pow_test_8307(double p0, double p1)
    {
        Math.Pow(p0, p1);
    }

    public void exp_test_8308(double p0)
    {
        Math.Exp(p0);
    }

    public void min_test_8309(int p0, int p1)
    {
        Math.Min(p0, p1);
    }

    public void min_test_8310(long p0, long p1)
    {
        Math.Min(p0, p1);
    }

    public void min_test_8311(double p0, double p1)
    {
        Math.Min(p0, p1);
    }

    public void min_test_8312(float p0, float p1)
    {
        Math.Min(p0, p1);
    }

    public void max_test_8313(long p0, long p1)
    {
        Math.Max(p0, p1);
    }

    public void max_test_8314(int p0, int p1)
    {
        Math.Max(p0, p1);
    }

    public void max_test_8315(double p0, double p1)
    {
        Math.Max(p0, p1);
    }

    public void max_test_8316(float p0, float p1)
    {
        Math.Max(p0, p1);
    }

    public void floor_test_8317(double p0)
    {
        Math.Floor(p0);
    }

    public void ceil_test_8318(double p0)
    {
        Math.Ceiling(p0);
    }

    public void rint_test_8319(double p0)
    {
        Math.Round(p0);
    }

    public void round_test_8320(double p0)
    {
        Math.Round(p0);
    }

    public void round_test_8321(float p0)
    {
        Math.Round(p0);
    }

    public void tanh_test_8322(double p0)
    {
        Math.Tanh(p0);
    }

    public void cbrt_test_8323(double p0)
    {
        Math.Cbrt(p0);
    }

    public void addExact_test_8324(int p0, int p1)
    {
        Math.AddExact(p0, p1);
    }

    public void addExact_test_8325(long p0, long p1)
    {
        Math.AddExact(p0, p1);
    }

    public void decrementExact_test_8326(int p0)
    {
        Math.DecrementExact(p0);
    }

    public void decrementExact_test_8327(long p0)
    {
        Math.DecrementExact(p0);
    }

    public void incrementExact_test_8328(long p0)
    {
        Math.IncrementExact(p0);
    }

    public void incrementExact_test_8329(int p0)
    {
        Math.IncrementExact(p0);
    }

    public void multiplyExact_test_8330(long p0, long p1)
    {
        Math.MultiplyExact(p0, p1);
    }

    public void multiplyExact_test_8331(int p0, int p1)
    {
        Math.MultiplyExact(p0, p1);
    }

    public void multiplyExact_test_8332(long p0, int p1)
    {
        Math.MultiplyExact(p0, p1);
    }

    public void multiplyHigh_test_8333(long p0, long p1)
    {
        Math.MultiplyHigh(p0, p1);
    }

    public void unsignedMultiplyHigh_test_8334(long p0, long p1)
    {
        Math.UnsignedMultiplyHigh(p0, p1);
    }

    public void negateExact_test_8335(long p0)
    {
        Math.NegateExact(p0);
    }

    public void negateExact_test_8336(int p0)
    {
        Math.NegateExact(p0);
    }

    public void subtractExact_test_8337(int p0, int p1)
    {
        Math.SubtractExact(p0, p1);
    }

    public void subtractExact_test_8338(long p0, long p1)
    {
        Math.SubtractExact(p0, p1);
    }

    public void fma_test_8339(double p0, double p1, double p2)
    {
        Math.FusedMultiplyAdd(p0, p1, p2);
    }

    public void fma_test_8340(float p0, float p1, float p2)
    {
        Math.FusedMultiplyAdd(p0, p1, p2);
    }

    public void copySign_test_8341(double p0, double p1)
    {
        Math.CopySign(p0, p1);
    }

    public void copySign_test_8342(float p0, float p1)
    {
        Math.CopySign(p0, p1);
    }

    public void signum_test_8343(float p0)
    {
        Math.Sign(p0);
    }

    public void signum_test_8344(double p0)
    {
        Math.Sign(p0);
    }

    public void clamp_test_8345(float p0, float p1, float p2)
    {
        Math.Clamp(p0, p1, p2);
    }

    public void clamp_test_8346(long p0, int p1, int p2)
    {
        Math.Clamp(p0, p1, p2);
    }

    public void clamp_test_8347(double p0, double p1, double p2)
    {
        Math.Clamp(p0, p1, p2);
    }

    public void clamp_test_8348(long p0, long p1, long p2)
    {
        Math.Clamp(p0, p1, p2);
    }

    public void scalb_test_8349(float p0, int p1)
    {
        Math.ScaleB(p0, p1);
    }

    public void scalb_test_8350(double p0, int p1)
    {
        Math.ScaleB(p0, p1);
    }

    public void getExponent_test_8351(float p0)
    {
        Math.GetExponent(p0);
    }

    public void getExponent_test_8352(double p0)
    {
        Math.GetExponent(p0);
    }

    public void floorMod_test_8353(long p0, long p1)
    {
        Math.FloorMod(p0, p1);
    }

    public void floorMod_test_8354(int p0, int p1)
    {
        Math.FloorMod(p0, p1);
    }

    public void floorMod_test_8355(long p0, int p1)
    {
        Math.FloorMod(p0, p1);
    }

    public void asin_test_8356(double p0)
    {
        Math.Asin(p0);
    }

    public void acos_test_8357(double p0)
    {
        Math.Acos(p0);
    }

    public void atan_test_8358(double p0)
    {
        Math.Atan(p0);
    }

    public void IEEEremainder_test_8359(double p0, double p1)
    {
        Math.IEEERemainder(p0, p1);
    }

    public void floorDiv_test_8360(long p0, long p1)
    {
        Math.FloorDiv(p0, p1);
    }

    public void floorDiv_test_8361(long p0, int p1)
    {
        Math.FloorDiv(p0, p1);
    }

    public void floorDiv_test_8362(int p0, int p1)
    {
        Math.FloorDiv(p0, p1);
    }

    public void ceilDiv_test_8363(long p0, long p1)
    {
        Math.CeilingDiv(p0, p1);
    }

    public void ceilDiv_test_8364(long p0, int p1)
    {
        Math.CeilingDiv(p0, p1);
    }

    public void ceilDiv_test_8365(int p0, int p1)
    {
        Math.CeilingDiv(p0, p1);
    }

    public void ceilMod_test_8366(int p0, int p1)
    {
        Math.CeilingMod(p0, p1);
    }

    public void ceilMod_test_8367(long p0, long p1)
    {
        Math.CeilingMod(p0, p1);
    }

    public void ceilMod_test_8368(long p0, int p1)
    {
        Math.CeilingMod(p0, p1);
    }

    public void sinh_test_8369(double p0)
    {
        Math.Sinh(p0);
    }

    public void cosh_test_8370(double p0)
    {
        Math.Cosh(p0);
    }

    public void hypot_test_8371(double p0, double p1)
    {
        Math.Hypot(p0, p1);
    }

    public void expm1_test_8372(double p0)
    {
        Math.Expm1(p0);
    }

    public void log1p_test_8373(double p0)
    {
        Math.Log1p(p0);
    }

    public void unsignedMultiplyExact_test_8374(int p0, int p1)
    {
        Math.UnsignedMultiplyExact(p0, p1);
    }

    public void unsignedMultiplyExact_test_8375(long p0, long p1)
    {
        Math.UnsignedMultiplyExact(p0, p1);
    }

    public void unsignedMultiplyExact_test_8376(long p0, int p1)
    {
        Math.UnsignedMultiplyExact(p0, p1);
    }

    public void toRadians_test_8377(double p0)
    {
        Math.ToRadians(p0);
    }

    public void toDegrees_test_8378(double p0)
    {
        Math.ToDegrees(p0);
    }

    public void random_test_8379()
    {
        Math.Random();
    }

    public void divideExact_test_8380(int p0, int p1)
    {
        Math.DivideExact(p0, p1);
    }

    public void divideExact_test_8381(long p0, long p1)
    {
        Math.DivideExact(p0, p1);
    }

    public void floorDivExact_test_8382(int p0, int p1)
    {
        Math.FloorDivExact(p0, p1);
    }

    public void floorDivExact_test_8383(long p0, long p1)
    {
        Math.FloorDivExact(p0, p1);
    }

    public void ceilDivExact_test_8384(long p0, long p1)
    {
        Math.CeilingDivExact(p0, p1);
    }

    public void ceilDivExact_test_8385(int p0, int p1)
    {
        Math.CeilingDivExact(p0, p1);
    }

    public void toIntExact_test_8386(long p0)
    {
        Math.ToIntExact(p0);
    }

    public void multiplyFull_test_8387(int p0, int p1)
    {
        Math.MultiplyFull(p0, p1);
    }

    public void absExact_test_8388(long p0)
    {
        Math.AbsExact(p0);
    }

    public void absExact_test_8389(int p0)
    {
        Math.AbsExact(p0);
    }

    public void ulp_test_8390(float p0)
    {
        Math.Ulp(p0);
    }

    public void ulp_test_8391(double p0)
    {
        Math.Ulp(p0);
    }

    public void nextAfter_test_8392(double p0, double p1)
    {
        Math.NextAfter(p0, p1);
    }

    public void nextAfter_test_8393(float p0, double p1)
    {
        Math.NextAfter(p0, p1);
    }

    public void nextUp_test_8394(float p0)
    {
        Math.NextUp(p0);
    }

    public void nextUp_test_8395(double p0)
    {
        Math.NextUp(p0);
    }

    public void nextDown_test_8396(float p0)
    {
        Math.NextDown(p0);
    }

    public void nextDown_test_8397(double p0)
    {
        Math.NextDown(p0);
    }

    public void powExact_test_8398(int p0, int p1)
    {
        Math.PowExact(p0, p1);
    }

    public void powExact_test_8399(long p0, int p1)
    {
        Math.PowExact(p0, p1);
    }

    public void unsignedPowExact_test_8400(long p0, int p1)
    {
        Math.UnsignedPowExact(p0, p1);
    }

    public void unsignedPowExact_test_8401(int p0, int p1)
    {
        Math.UnsignedPowExact(p0, p1);
    }
}

public static class MathExtensions
{
    public static long MultiplyHigh(long a, long b)
    {
        // Implementation for high 64 bits of 128-bit product
        ulong a1 = (ulong)(a >> 32);
        ulong a0 = (ulong)(uint)a;
        ulong b1 = (ulong)(b >> 32);
        ulong b0 = (ulong)(uint)b;

        ulong a0b0 = a0 * b0;
        ulong a0b1 = a0 * b1;
        ulong a1b0 = a1 * b0;
        ulong a1b1 = a1 * b1;

        ulong mid = (a0b0 >> 32) + (uint)a0b1 + (uint)a1b0;
        ulong high = a1b1 + (a0b1 >> 32) + (a1b0 >> 32) + (mid >> 32);

        // Handle sign for signed multiplication
        bool negative = (a < 0) ^ (b < 0);
        if (negative)
        {
            // Compute two's complement of the 128-bit result
            ulong low = (a0b0) + (mid << 32);
            high = ~high;
            if (low == 0)
                high++;
            else
                high = ~high;
        }

        return (long)high;
    }

    public static long UnsignedMultiplyHigh(long a, long b)
    {
        ulong ua = (ulong)a;
        ulong ub = (ulong)b;
        ulong a1 = ua >> 32;
        ulong a0 = (uint)ua;
        ulong b1 = ub >> 32;
        ulong b0 = (uint)ub;

        ulong a0b0 = a0 * b0;
        ulong a0b1 = a0 * b1;
        ulong a1b0 = a1 * b0;
        ulong a1b1 = a1 * b1;

        ulong mid = (a0b0 >> 32) + (uint)a0b1 + (uint)a1b0;
        ulong high = a1b1 + (a0b1 >> 32) + (a1b0 >> 32) + (mid >> 32);

        return (long)high;
    }

    public static int GetExponent(float value)
    {
        int bits = BitConverter.SingleToInt32Bits(value);
        int exponent = (bits >> 23) & 0xFF;
        if (exponent == 0)
            return -126;
        if (exponent == 0xFF)
            return 128;
        return exponent - 127;
    }

    public static int GetExponent(double value)
    {
        long bits = BitConverter.DoubleToInt64Bits(value);
        int exponent = (int)((bits >> 52) & 0x7FF);
        if (exponent == 0)
            return -1022;
        if (exponent == 0x7FF)
            return 1024;
        return exponent - 1023;
    }

    public static float ScaleB(float value, int scale)
    {
        return (float)(value * Math.Pow(2, scale));
    }

    public static double ScaleB(double value, int scale)
    {
        return value * Math.Pow(2, scale);
    }

    public static long FloorMod(long x, long y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return r;
    }

    public static int FloorMod(int x, int y)
    {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return r;
    }

    public static int FloorMod(long x, int y)
    {
        return (int)FloorMod(x, (long)y);
    }

    public static long FloorDiv(long x, long y)
    {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0)))
            q--;
        return q;
    }

    public static int FloorDiv(int x, int y)
    {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0)))
            q--;
        return q;
    }

    public static int FloorDiv(long x, int y)
    {
        return (int)FloorDiv(x, (long)y);
    }

    public static long CeilingDiv(long x, long y)
    {
        long q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0)))
            q++;
        return q;
    }

    public static int CeilingDiv(int x, int y)
    {
        int q = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0)))
            q++;
        return q;
    }

    public static int CeilingDiv(long x, int y)
    {
        return (int)CeilingDiv(x, (long)y);
    }

    public static int CeilingMod(int x, int y)
    {
        int r = x % y;
        if (r != 0 && ((r < 0) == (y < 0)))
            r -= y;
        return r;
    }

    public static long CeilingMod(long x, long y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) == (y < 0)))
            r -= y;
        return r;
    }

    public static int CeilingMod(long x, int y)
    {
        return (int)CeilingMod(x, (long)y);
    }

    public static double Hypot(double x, double y)
    {
        return Math.Sqrt(x * x + y * y);
    }

    public static double Expm1(double x)
    {
        if (Math.Abs(x) < 1e-5)
            return x + x * x / 2;
        return Math.Exp(x) - 1;
    }

    public static double Log1p(double x)
    {
        if (Math.Abs(x) < 1e-4)
            return x - x * x / 2 + x * x * x / 3;
        return Math.Log(1 + x);
    }

    public static int UnsignedMultiplyExact(int x, int y)
    {
        long result = (long)(uint)x * (uint)y;
        if (result > int.MaxValue)
            throw new OverflowException();
        return (int)result;
    }

    public static long UnsignedMultiplyExact(long x, long y)
    {
        ulong result = (ulong)x * (ulong)y;
        if (result > long.MaxValue)
            throw new OverflowException();
        return (long)result;
    }

    public static long UnsignedMultiplyExact(long x, int y)
    {
        return UnsignedMultiplyExact(x, (long)y);
    }

    public static double ToRadians(double angdeg)
    {
        return angdeg * Math.PI / 180.0;
    }

    public static double ToDegrees(double angrad)
    {
        return angrad * 180.0 / Math.PI;
    }

    public static double Random()
    {
        return new Random().NextDouble();
    }

    public static int DivideExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return x / y;
    }

    public static long DivideExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return x / y;
    }

    public static int FloorDivExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return FloorDiv(x, y);
    }

    public static long FloorDivExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return FloorDiv(x, y);
    }

    public static long CeilingDivExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return CeilingDiv(x, y);
    }

    public static int CeilingDivExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return CeilingDiv(x, y);
    }

    public static int ToIntExact(long value)
    {
        if (value < int.MinValue || value > int.MaxValue)
            throw new OverflowException();
        return (int)value;
    }

    public static long MultiplyFull(int x, int y)
    {
        return (long)x * y;
    }

    public static long AbsExact(long a)
    {
        if (a == long.MinValue)
            throw new OverflowException();
        return Math.Abs(a);
    }

    public static int AbsExact(int a)
    {
        if (a == int.MinValue)
            throw new OverflowException();
        return Math.Abs(a);
    }

    public static float Ulp(float value)
    {
        if (float.IsNaN(value) || float.IsInfinity(value))
            return float.NaN;
        if (value == 0)
            return float.Epsilon;
        int bits = BitConverter.SingleToInt32Bits(value);
        int exponent = (bits >> 23) & 0xFF;
        if (exponent == 0)
            return BitConverter.Int32BitsToSingle(1);
        return BitConverter.Int32BitsToSingle((exponent - 1) << 23);
    }

    public static double Ulp(double value)
    {
        if (double.IsNaN(value) || double.IsInfinity(value))
            return double.NaN;
        if (value == 0)
            return double.Epsilon;
        long bits = BitConverter.DoubleToInt64Bits(value);
        int exponent = (int)((bits >> 52) & 0x7FF);
        if (exponent == 0)
            return BitConverter.Int64BitsToDouble(1);
        return BitConverter.Int64BitsToDouble((long)(exponent - 1) << 52);
    }

    public static double NextAfter(double from, double to)
    {
        if (double.IsNaN(from) || double.IsNaN(to))
            return double.NaN;
        if (from == to)
            return to;
        if (from == 0)
            return to > 0 ? double.Epsilon : -double.Epsilon;
        long bits = BitConverter.DoubleToInt64Bits(from);
        if ((from < 0 && to > from) || (from > 0 && to < from))
            bits--;
        else
            bits++;
        return BitConverter.Int64BitsToDouble(bits);
    }

    public static float NextAfter(float from, double to)
    {
        if (float.IsNaN(from) || double.IsNaN(to))
            return float.NaN;
        if (from == to)
            return (float)to;
        if (from == 0)
            return to > 0 ? float.Epsilon : -float.Epsilon;
        int bits = BitConverter.SingleToInt32Bits(from);
        if ((from < 0 && to > from) || (from > 0 && to < from))
            bits--;
        else
            bits++;
        return BitConverter.Int32BitsToSingle(bits);
    }

    public static float NextUp(float value)
    {
        return NextAfter(value, float.PositiveInfinity);
    }

    public static double NextUp(double value)
    {
        return NextAfter(value, double.PositiveInfinity);
    }

    public static float NextDown(float value)
    {
        return NextAfter(value, float.NegativeInfinity);
    }

    public static double NextDown(double value)
    {
        return NextAfter(value, double.NegativeInfinity);
    }

    public static int PowExact(int a, int b)
    {
        long result = 1;
        for (int i = 0; i < b; i++)
        {
            result *= a;
            if (result > int.MaxValue || result < int.MinValue)
                throw new OverflowException();
        }
        return (int)result;
    }

    public static long PowExact(long a, int b)
    {
        long result = 1;
        for (int i = 0; i < b; i++)
        {
            result *= a;
            if (result > long.MaxValue || result < long.MinValue)
                throw new OverflowException();
        }
        return result;
    }

    public static long UnsignedPowExact(long a, int b)
    {
        ulong result = 1;
        ulong ua = (ulong)a;
        for (int i = 0; i < b; i++)
        {
            result *= ua;
            if (result > long.MaxValue)
                throw new OverflowException();
        }
        return (long)result;
    }

    public static int UnsignedPowExact(int a, int b)
    {
        uint result = 1;
        uint ua = (uint)a;
        for (int i = 0; i < b; i++)
        {
            result *= ua;
            if (result > int.MaxValue)
                throw new OverflowException();
        }
        return (int)result;
    }
}