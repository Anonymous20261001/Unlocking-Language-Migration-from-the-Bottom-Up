```csharp
namespace Generated.Test
{
    using System;
    using System.Collections.Generic;

    public class CannotUndoException : Exception
    {
        public CannotUndoException() : base() { }
        public CannotUndoException(string message) : base(message) { }
    }

    public class CannotRedoException : Exception
    {
        public CannotRedoException() : base() { }
        public CannotRedoException(string message) : base(message) { }
    }

    public interface UndoableEdit
    {
        void undo();
        void redo();
        bool canUndo();
        bool canRedo();
        bool addEdit(UndoableEdit anEdit);
        void die();
        string getPresentationName();
        string getUndoPresentationName();
        string getRedoPresentationName();
        bool isSignificant();
        bool replaceEdit(UndoableEdit anEdit);
    }

    public class UndoableEditEvent
    {
        private object source;
        private UndoableEdit edit;

        public UndoableEditEvent(object source, UndoableEdit edit)
        {
            this.source = source;
            this.edit = edit;
        }

        public object getSource()
        {
            return source;
        }

        public UndoableEdit getEdit()
        {
            return edit;
        }
    }

    public class UndoManager
    {
        private List<UndoableEdit> edits = new List<UndoableEdit>();
        private int index = 0;
        private int limit = 100;

        public UndoManager()
        {
        }

        public bool addEdit(UndoableEdit anEdit)
        {
            if (anEdit == null)
            {
                throw new ArgumentNullException("anEdit");
            }

            if (index < edits.Count)
            {
                edits.RemoveRange(index, edits.Count - index);
            }

            edits.Add(anEdit);
            index = edits.Count;
            trimEdits();
            return true;
        }

        public void undoableEditHappened(UndoableEditEvent e)
        {
            if (e == null)
            {
                throw new ArgumentNullException("e");
            }

            addEdit(e.getEdit());
        }

        public void redo()
        {
            if (!canRedo())
            {
                throw new CannotRedoException();
            }

            UndoableEdit edit = edits[index];
            edit.redo();
            index++;
        }

        public void undo()
        {
            if (!canUndo())
            {
                throw new CannotUndoException();
            }

            UndoableEdit edit = edits[index - 1];
            edit.undo();
            index--;
        }

        public string getUndoPresentationName()
        {
            if (!canUndo())
            {
                return "Undo";
            }

            return edits[index - 1].getUndoPresentationName();
        }

        public string getRedoPresentationName()
        {
            if (!canRedo())
            {
                return "Redo";
            }

            return edits[index].getRedoPresentationName();
        }

        public bool canUndo()
        {
            return index > 0 && edits[index - 1].canUndo();
        }

        public bool canRedo()
        {
            return index < edits.Count && edits[index].canRedo();
        }

        public int getLimit()
        {
            return limit;
        }

        public void discardAllEdits()
        {
            edits.Clear();
            index = 0;
        }

        public void setLimit(int c)
        {
            if (c < 0)
            {
                throw new ArgumentException("Negative limit");
            }

            limit = c;

            if (edits.Count > limit)
            {
                int excess = edits.Count - limit;
                edits.RemoveRange(0, excess);
                index -= excess;
                if (index < 0)
                {
                    index = 0;
                }
            }
        }

        public void undoOrRedo()
        {
            if (canUndo())
            {
                undo();
            }
            else if (canRedo())
            {
                redo();
            }
            else
            {
                throw new CannotUndoException();
            }
        }

        public bool canUndoOrRedo()
        {
            return canUndo() || canRedo();
        }

        public string getUndoOrRedoPresentationName()
        {
            if (canUndo())
            {
                return getUndoPresentationName();
            }
            else if (canRedo())
            {
                return getRedoPresentationName();
            }
            else
            {
                return "Undo";
            }
        }

        public void end()
        {
        }

        private void trimEdits()
        {
            if (edits.Count > limit)
            {
                int excess = edits.Count - limit;
                edits.RemoveRange(0, excess);
                index -= excess;
                if (index < 0)
                {
                    index = 0;
                }
            }
        }
    }

    public class javax_swing_undo_UndoManagerAutoTest
    {
        public void undoableEditHappened_test_13193(UndoableEditEvent p0)
        {
            UndoManager instance = new UndoManager();
            instance.undoableEditHappened(p0);
        }

        public void addEdit_test_13194(UndoableEdit p0)
        {
            UndoManager instance = new UndoManager();
            instance.addEdit(p0);
        }

        public void redo_test_13195()
        {
            UndoManager instance = new UndoManager();
            instance.redo();
        }

        public void undo_test_13196()
        {
            UndoManager instance = new UndoManager();
            instance.undo();
        }

        public void getUndoPresentationName_test_13197()
        {
            UndoManager instance = new UndoManager();
            instance.getUndoPresentationName();
        }

        public void getRedoPresentationName_test_13198()
        {
            UndoManager instance = new UndoManager();
            instance.getRedoPresentationName();
        }

        public void canUndo_test_13199()
        {
            UndoManager instance = new UndoManager();
            instance.canUndo();
        }

        public void canRedo_test_13200()
        {
            UndoManager instance = new UndoManager();
            instance.canRedo();
        }

        public void getLimit_test_13201()
        {
            UndoManager instance = new UndoManager();
            instance.getLimit();
        }

        public void discardAllEdits_test_13202()
        {
            UndoManager instance = new UndoManager();
            instance.discardAllEdits();
        }

        public void setLimit_test_13203(int p0)
        {
            UndoManager instance = new UndoManager();
            instance.setLimit(p0);
        }

        public void undoOrRedo_test_13204()
        {
            UndoManager instance = new UndoManager();
            instance.undoOrRedo();
        }

        public void canUndoOrRedo_test_13205()
        {
            UndoManager instance = new UndoManager();
            instance.canUndoOrRedo();
        }

        public void getUndoOrRedoPresentationName_test_13206()
        {
            UndoManager instance = new UndoManager();
            instance.getUndoOrRedoPresentationName();
        }

        public void end_test_13207()
        {
            UndoManager instance = new UndoManager();
            instance.end();
        }
    }
}
```