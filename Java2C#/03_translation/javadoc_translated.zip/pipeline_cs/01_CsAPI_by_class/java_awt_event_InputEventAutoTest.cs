namespace Generated.Test
{
    public class java_awt_event_InputEventAutoTest
    {
        public void getModifiersExText_test_5831(int p0)
        {
            InputEvent.getModifiersExText(p0);
        }

        public void getMaskForButton_test_5832(int p0)
        {
            InputEvent.getMaskForButton(p0);
        }
    }

    public class InputEvent
    {
        public const int SHIFT_DOWN_MASK = 1 << 6;
        public const int CTRL_DOWN_MASK = 1 << 7;
        public const int META_DOWN_MASK = 1 << 8;
        public const int ALT_DOWN_MASK = 1 << 9;
        public const int BUTTON1_DOWN_MASK = 1 << 10;
        public const int BUTTON2_DOWN_MASK = 1 << 11;
        public const int BUTTON3_DOWN_MASK = 1 << 12;
        public const int ALT_GRAPH_DOWN_MASK = 1 << 13;

        public static string getModifiersExText(int modifiers)
        {
            var parts = new System.Collections.Generic.List<string>();
            if ((modifiers & META_DOWN_MASK) != 0) parts.Add("Meta");
            if ((modifiers & CTRL_DOWN_MASK) != 0) parts.Add("Ctrl");
            if ((modifiers & ALT_DOWN_MASK) != 0) parts.Add("Alt");
            if ((modifiers & SHIFT_DOWN_MASK) != 0) parts.Add("Shift");
            if ((modifiers & ALT_GRAPH_DOWN_MASK) != 0) parts.Add("Alt Graph");
            if ((modifiers & BUTTON1_DOWN_MASK) != 0) parts.Add("Button1");
            if ((modifiers & BUTTON2_DOWN_MASK) != 0) parts.Add("Button2");
            if ((modifiers & BUTTON3_DOWN_MASK) != 0) parts.Add("Button3");
            return string.Join("+", parts);
        }

        public static int getMaskForButton(int button)
        {
            switch (button)
            {
                case 1:
                    return BUTTON1_DOWN_MASK;
                case 2:
                    return BUTTON2_DOWN_MASK;
                case 3:
                    return BUTTON3_DOWN_MASK;
                default:
                    throw new System.ArgumentException("button must be 1, 2, or 3");
            }
        }
    }
}