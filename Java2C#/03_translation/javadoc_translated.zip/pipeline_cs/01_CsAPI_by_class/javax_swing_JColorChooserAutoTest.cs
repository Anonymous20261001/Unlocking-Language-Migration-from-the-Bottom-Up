using System;

namespace Generated.Test
{
    public class Color
    {
        public int R { get; private set; }
        public int G { get; private set; }
        public int B { get; private set; }

        public Color(int r, int g, int b)
        {
            R = r;
            G = g;
            B = b;
        }

        public Color(int rgb)
        {
            R = (rgb >> 16) & 0xFF;
            G = (rgb >> 8) & 0xFF;
            B = rgb & 0xFF;
        }
    }

    public class AccessibleContext
    {
    }

    public class Component
    {
        public virtual AccessibleContext getAccessibleContext()
        {
            return null;
        }
    }

    public class JComponent : Component
    {
    }

    public class JDialog
    {
    }

    public interface ActionListener
    {
        void actionPerformed(object e);
    }

    public class ColorChooserUI
    {
    }

    public abstract class AbstractColorChooserPanel : JComponent
    {
    }

    public interface ColorSelectionModel
    {
    }

    public class JColorChooser : JComponent
    {
        public JColorChooser()
        {
        }

        public string getUIClassID()
        {
            return "ColorChooserUI";
        }

        public void updateUI()
        {
        }

        public ColorChooserUI getUI()
        {
            return null;
        }

        public void setUI(ColorChooserUI p0)
        {
        }

        public override AccessibleContext getAccessibleContext()
        {
            return base.getAccessibleContext();
        }

        public Color getColor()
        {
            return null;
        }

        public ColorSelectionModel getSelectionModel()
        {
            return null;
        }

        public static Color showDialog(Component p0, string p1, Color p2)
        {
            return null;
        }

        public static Color showDialog(Component p0, string p1, Color p2, bool p3)
        {
            return null;
        }

        public AbstractColorChooserPanel[] getChooserPanels()
        {
            return null;
        }

        public static JDialog createDialog(Component p0, string p1, bool p2, JColorChooser p3, ActionListener p4, ActionListener p5)
        {
            return null;
        }

        public JComponent getPreviewPanel()
        {
            return null;
        }

        public void setChooserPanels(AbstractColorChooserPanel[] p0)
        {
        }

        public void setDragEnabled(bool p0)
        {
        }

        public bool getDragEnabled()
        {
            return false;
        }

        public void setPreviewPanel(JComponent p0)
        {
        }

        public void addChooserPanel(AbstractColorChooserPanel p0)
        {
        }

        public AbstractColorChooserPanel removeChooserPanel(AbstractColorChooserPanel p0)
        {
            return p0;
        }

        public void setSelectionModel(ColorSelectionModel p0)
        {
        }

        public void setColor(int p0, int p1, int p2)
        {
        }

        public void setColor(int p0)
        {
        }

        public void setColor(Color p0)
        {
        }
    }

    public class javax_swing_JColorChooserAutoTest
    {
        public void getUIClassID_test_6023()
        {
            JColorChooser instance = new JColorChooser();
            instance.getUIClassID();
        }

        public void updateUI_test_6024()
        {
            JColorChooser instance = new JColorChooser();
            instance.updateUI();
        }

        public void getUI_test_6025()
        {
            JColorChooser instance = new JColorChooser();
            instance.getUI();
        }

        public void setUI_test_6026(ColorChooserUI p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setUI(p0);
        }

        public void getAccessibleContext_test_6027()
        {
            JColorChooser instance = new JColorChooser();
            instance.getAccessibleContext();
        }

        public void getColor_test_6028()
        {
            JColorChooser instance = new JColorChooser();
            instance.getColor();
        }

        public void getSelectionModel_test_6029()
        {
            JColorChooser instance = new JColorChooser();
            instance.getSelectionModel();
        }

        public void showDialog_test_6030(Component p0, string p1, Color p2)
        {
            JColorChooser.showDialog(p0, p1, p2);
        }

        public void showDialog_test_6031(Component p0, string p1, Color p2, bool p3)
        {
            JColorChooser.showDialog(p0, p1, p2, p3);
        }

        public void getChooserPanels_test_6032()
        {
            JColorChooser instance = new JColorChooser();
            instance.getChooserPanels();
        }

        public void createDialog_test_6033(Component p0, string p1, bool p2, JColorChooser p3, ActionListener p4, ActionListener p5)
        {
            JColorChooser.createDialog(p0, p1, p2, p3, p4, p5);
        }

        public void getPreviewPanel_test_6034()
        {
            JColorChooser instance = new JColorChooser();
            instance.getPreviewPanel();
        }

        public void setChooserPanels_test_6035(AbstractColorChooserPanel[] p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setChooserPanels(p0);
        }

        public void setDragEnabled_test_6036(bool p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setDragEnabled(p0);
        }

        public void getDragEnabled_test_6037()
        {
            JColorChooser instance = new JColorChooser();
            instance.getDragEnabled();
        }

        public void setPreviewPanel_test_6038(JComponent p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setPreviewPanel(p0);
        }

        public void addChooserPanel_test_6039(AbstractColorChooserPanel p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.addChooserPanel(p0);
        }

        public void removeChooserPanel_test_6040(AbstractColorChooserPanel p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.removeChooserPanel(p0);
        }

        public void setSelectionModel_test_6041(ColorSelectionModel p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setSelectionModel(p0);
        }

        public void setColor_test_6042(int p0, int p1, int p2)
        {
            JColorChooser instance = new JColorChooser();
            instance.setColor(p0, p1, p2);
        }

        public void setColor_test_6043(int p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setColor(p0);
        }

        public void setColor_test_6044(Color p0)
        {
            JColorChooser instance = new JColorChooser();
            instance.setColor(p0);
        }
    }
}