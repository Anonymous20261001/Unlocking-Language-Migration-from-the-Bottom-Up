using System;

namespace Generated.Test
{
    public class Locale
    {
        public Locale()
        {
        }
    }

    public class BreakIterator
    {
        public static Locale[] getAvailableLocales()
        {
            return new Locale[0];
        }

        public static BreakIterator getWordInstance()
        {
            return new BreakIterator();
        }

        public static BreakIterator getWordInstance(Locale locale)
        {
            return new BreakIterator();
        }

        public static BreakIterator getLineInstance()
        {
            return new BreakIterator();
        }

        public static BreakIterator getLineInstance(Locale locale)
        {
            return new BreakIterator();
        }

        public static BreakIterator getCharacterInstance()
        {
            return new BreakIterator();
        }

        public static BreakIterator getCharacterInstance(Locale locale)
        {
            return new BreakIterator();
        }

        public static BreakIterator getSentenceInstance()
        {
            return new BreakIterator();
        }

        public static BreakIterator getSentenceInstance(Locale locale)
        {
            return new BreakIterator();
        }
    }

    public class java_text_BreakIteratorAutoTest
    {
        public void getAvailableLocales_test_1878()
        {
            BreakIterator.getAvailableLocales();
        }

        public void getWordInstance_test_1879()
        {
            BreakIterator.getWordInstance();
        }

        public void getWordInstance_test_1880(Locale p0)
        {
            BreakIterator.getWordInstance(p0);
        }

        public void getLineInstance_test_1881(Locale p0)
        {
            BreakIterator.getLineInstance(p0);
        }

        public void getLineInstance_test_1882()
        {
            BreakIterator.getLineInstance();
        }

        public void getCharacterInstance_test_1883(Locale p0)
        {
            BreakIterator.getCharacterInstance(p0);
        }

        public void getCharacterInstance_test_1884()
        {
            BreakIterator.getCharacterInstance();
        }

        public void getSentenceInstance_test_1885(Locale p0)
        {
            BreakIterator.getSentenceInstance(p0);
        }

        public void getSentenceInstance_test_1886()
        {
            BreakIterator.getSentenceInstance();
        }
    }
}