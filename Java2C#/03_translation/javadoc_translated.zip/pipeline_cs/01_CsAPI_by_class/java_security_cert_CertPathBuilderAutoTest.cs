using System;

namespace Generated.Test
{
    public class java_security_cert_CertPathBuilderAutoTest
    {
        public void getDefaultType_test_2099()
        {
            CertPathBuilder.getDefaultType();
        }
    }

    public class CertPathBuilder
    {
        public static string getDefaultType()
        {
            return "PKIX";
        }
    }
}