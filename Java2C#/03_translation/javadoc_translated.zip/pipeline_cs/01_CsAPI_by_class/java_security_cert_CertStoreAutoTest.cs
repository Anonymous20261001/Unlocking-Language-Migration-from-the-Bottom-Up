namespace Generated.Test
{
    public static class CertStore
    {
        public static string GetDefaultType()
        {
            // Mimic the Java default certificate store type.
            return "LDAP";
        }
    }

    public class java_security_cert_CertStoreAutoTest
    {
        public void getDefaultType_test_2105()
        {
            CertStore.GetDefaultType();
        }
    }
}