using System;
using System.Collections.Generic;
using System.Reflection;

namespace Generated.Test
{
    public sealed class Package
    {
        private readonly string name;

        private Package(string name)
        {
            this.name = name;
        }

        public static Package getPackage(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try
                {
                    types = assembly.GetTypes();
                }
                catch (ReflectionTypeLoadException e)
                {
                    types = e.Types;
                }
                catch
                {
                    continue;
                }

                if (types != null)
                {
                    foreach (var type in types)
                    {
                        if (type != null && string.Equals(type.Namespace, name, StringComparison.Ordinal))
                        {
                            return new Package(name);
                        }
                    }
                }
            }

            return null;
        }

        public static Package[] getPackages()
        {
            var packageNames = new HashSet<string>();

            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try
                {
                    types = assembly.GetTypes();
                }
                catch (ReflectionTypeLoadException e)
                {
                    types = e.Types;
                }
                catch
                {
                    continue;
                }

                if (types != null)
                {
                    foreach (var type in types)
                    {
                        if (type != null && !string.IsNullOrEmpty(type.Namespace))
                        {
                            packageNames.Add(type.Namespace);
                        }
                    }
                }
            }

            var result = new Package[packageNames.Count];
            int i = 0;
            foreach (var packageName in packageNames)
            {
                result[i++] = new Package(packageName);
            }

            return result;
        }
    }

    public class java_lang_PackageAutoTest
    {
        public void getPackage_test_9713(string p0)
        {
            Package.getPackage(p0);
        }

        public void getPackages_test_9714()
        {
            Package.getPackages();
        }
    }
}