using System.Collections.Generic;

namespace Generated.Test
{
    public interface Printable
    {
    }

    public class PageFormat
    {
    }

    public class Book
    {
        private sealed class Page
        {
            private readonly Printable printable;
            private readonly PageFormat pageFormat;

            public Page(Printable printable, PageFormat pageFormat)
            {
                this.printable = printable;
                this.pageFormat = pageFormat;
            }

            public Printable Printable
            {
                get { return printable; }
            }

            public PageFormat PageFormat
            {
                get { return pageFormat; }
            }
        }

        private readonly List<Page> pages = new List<Page>();

        public Book()
        {
        }

        public int getNumberOfPages()
        {
            return pages.Count;
        }

        public Printable getPrintable(int pageIndex)
        {
            return pages[pageIndex].Printable;
        }

        public PageFormat getPageFormat(int pageIndex)
        {
            return pages[pageIndex].PageFormat;
        }

        public void setPage(int pageIndex, Printable painter, PageFormat page)
        {
            if (pageIndex >= pages.Count)
            {
                while (pages.Count < pageIndex)
                {
                    pages.Add(new Page(null, new PageFormat()));
                }
                pages.Add(new Page(painter, page));
            }
            else
            {
                pages[pageIndex] = new Page(painter, page);
            }
        }

        public void append(Printable painter, PageFormat page, int numPages)
        {
            for (int i = 0; i < numPages; i++)
            {
                pages.Add(new Page(painter, page));
            }
        }

        public void append(Printable painter, PageFormat page)
        {
            append(painter, page, 1);
        }
    }

    public class java_awt_print_BookAutoTest
    {
        public void getPrintable_test_1763(int p0)
        {
            Book instance = new Book();
            instance.getPrintable(p0);
        }

        public void getPageFormat_test_1764(int p0)
        {
            Book instance = new Book();
            instance.getPageFormat(p0);
        }

        public void getNumberOfPages_test_1765()
        {
            Book instance = new Book();
            instance.getNumberOfPages();
        }

        public void setPage_test_1766(int p0, Printable p1, PageFormat p2)
        {
            Book instance = new Book();
            instance.setPage(p0, p1, p2);
        }

        public void append_test_1767(Printable p0, PageFormat p1, int p2)
        {
            Book instance = new Book();
            instance.append(p0, p1, p2);
        }

        public void append_test_1768(Printable p0, PageFormat p1)
        {
            Book instance = new Book();
            instance.append(p0, p1);
        }
    }
}