using System;
using System.Drawing.Printing;
using System.Linq;

namespace Generated.Test
{
    public class java_awt_print_PrinterJobAutoTest
    {
        public void getPrinterJob_test_10008()
        {
            PrinterJob.getPrinterJob();
        }

        public void lookupPrintServices_test_10009()
        {
            PrinterJob.lookupPrintServices();
        }

        public void lookupStreamPrintServices_test_10010(string p0)
        {
            PrinterJob.lookupStreamPrintServices(p0);
        }
    }

    public class PrinterJob
    {
        public static PrinterJob getPrinterJob()
        {
            return new PrinterJob();
        }

        public static PrintService[] lookupPrintServices()
        {
            return PrinterSettings.InstalledPrinters.Cast<string>()
                .Select(name => new PrintService(name))
                .ToArray();
        }

        public static PrintService[] lookupStreamPrintServices(string p0)
        {
            return new PrintService[0];
        }
    }

    public class PrintService
    {
        public string Name { get; private set; }

        public PrintService(string name)
        {
            Name = name;
        }
    }
}