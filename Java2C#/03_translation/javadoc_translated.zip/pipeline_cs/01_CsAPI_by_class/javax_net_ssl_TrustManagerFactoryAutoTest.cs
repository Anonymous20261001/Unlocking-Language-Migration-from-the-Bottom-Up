using System;

namespace Generated.Test
{
    public static class TrustManagerFactory
    {
        public static string getDefaultAlgorithm()
        {
            return "PKIX";
        }
    }

    public class javax_net_ssl_TrustManagerFactoryAutoTest
    {
        public void getDefaultAlgorithm_test_13101()
        {
            TrustManagerFactory.getDefaultAlgorithm();
        }
    }
}