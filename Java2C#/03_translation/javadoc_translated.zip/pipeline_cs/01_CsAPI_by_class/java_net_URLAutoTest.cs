using System;

namespace Generated.Test
{
    public class URLStreamHandler
    {
    }

    public interface URLStreamHandlerFactory
    {
        URLStreamHandler createURLStreamHandler(string protocol);
    }

    public class URL
    {
        private static URLStreamHandlerFactory factory;
        private static bool factorySet;

        public static void setURLStreamHandlerFactory(URLStreamHandlerFactory p0)
        {
            if (factorySet)
            {
                throw new InvalidOperationException("factory already defined");
            }
            factory = p0;
            factorySet = true;
        }
    }

    public class java_net_URLAutoTest
    {
        public void setURLStreamHandlerFactory_test_13249(URLStreamHandlerFactory p0)
        {
            URL.setURLStreamHandlerFactory(p0);
        }
    }
}