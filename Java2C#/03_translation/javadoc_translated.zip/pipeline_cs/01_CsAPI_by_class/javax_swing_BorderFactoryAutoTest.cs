namespace Generated.Test
{
    public interface Paint { }
    public interface Icon { }
    public interface Border { }

    public class Color : Paint
    {
        public Color() { }
        public Color(int r, int g, int b) { }
        public Color(float r, float g, float b) { }
    }

    public class Font
    {
        public Font() { }
        public Font(string name, int style, int size) { }
    }

    public class BasicStroke
    {
        public BasicStroke() { }
        public BasicStroke(float width) { }
    }

    public static class BorderFactory
    {
        private class BorderImpl : Border { }

        public static Border createLoweredBevelBorder() { return new BorderImpl(); }
        public static Border createBevelBorder(int p0) { return new BorderImpl(); }
        public static Border createBevelBorder(int p0, Color p1, Color p2) { return new BorderImpl(); }
        public static Border createBevelBorder(int p0, Color p1, Color p2, Color p3, Color p4) { return new BorderImpl(); }
        public static Border createSoftBevelBorder(int p0) { return new BorderImpl(); }
        public static Border createSoftBevelBorder(int p0, Color p1, Color p2) { return new BorderImpl(); }
        public static Border createSoftBevelBorder(int p0, Color p1, Color p2, Color p3, Color p4) { return new BorderImpl(); }
        public static Border createEtchedBorder(Color p0, Color p1) { return new BorderImpl(); }
        public static Border createEtchedBorder(int p0) { return new BorderImpl(); }
        public static Border createEtchedBorder() { return new BorderImpl(); }
        public static Border createEtchedBorder(int p0, Color p1, Color p2) { return new BorderImpl(); }
        public static Border createTitledBorder(Border p0, string p1, int p2, int p3, Font p4) { return new BorderImpl(); }
        public static Border createTitledBorder(Border p0, string p1, int p2, int p3, Font p4, Color p5) { return new BorderImpl(); }
        public static Border createTitledBorder(string p0) { return new BorderImpl(); }
        public static Border createTitledBorder(Border p0) { return new BorderImpl(); }
        public static Border createTitledBorder(Border p0, string p1) { return new BorderImpl(); }
        public static Border createTitledBorder(Border p0, string p1, int p2, int p3) { return new BorderImpl(); }
        public static Border createCompoundBorder() { return new BorderImpl(); }
        public static Border createCompoundBorder(Border p0, Border p1) { return new BorderImpl(); }
        public static Border createMatteBorder(int p0, int p1, int p2, int p3, Color p4) { return new BorderImpl(); }
        public static Border createMatteBorder(int p0, int p1, int p2, int p3, Icon p4) { return new BorderImpl(); }
        public static Border createRaisedBevelBorder() { return new BorderImpl(); }
        public static Border createRaisedSoftBevelBorder() { return new BorderImpl(); }
        public static Border createLoweredSoftBevelBorder() { return new BorderImpl(); }
        public static Border createDashedBorder(Paint p0) { return new BorderImpl(); }
        public static Border createDashedBorder(Paint p0, float p1, float p2) { return new BorderImpl(); }
        public static Border createDashedBorder(Paint p0, float p1, float p2, float p3, bool p4) { return new BorderImpl(); }
        public static Border createStrokeBorder(BasicStroke p0, Paint p1) { return new BorderImpl(); }
        public static Border createStrokeBorder(BasicStroke p0) { return new BorderImpl(); }
        public static Border createEmptyBorder() { return new BorderImpl(); }
        public static Border createEmptyBorder(int p0, int p1, int p2, int p3) { return new BorderImpl(); }
        public static Border createLineBorder(Color p0, int p1, bool p2) { return new BorderImpl(); }
        public static Border createLineBorder(Color p0) { return new BorderImpl(); }
        public static Border createLineBorder(Color p0, int p1) { return new BorderImpl(); }
    }

    public class javax_swing_BorderFactoryAutoTest
    {
        public void createLoweredBevelBorder_test_1780()
        {
            BorderFactory.createLoweredBevelBorder();
        }

        public void createBevelBorder_test_1781(int p0)
        {
            BorderFactory.createBevelBorder(p0);
        }

        public void createBevelBorder_test_1782(int p0, Color p1, Color p2)
        {
            BorderFactory.createBevelBorder(p0, p1, p2);
        }

        public void createBevelBorder_test_1783(int p0, Color p1, Color p2, Color p3, Color p4)
        {
            BorderFactory.createBevelBorder(p0, p1, p2, p3, p4);
        }

        public void createSoftBevelBorder_test_1784(int p0)
        {
            BorderFactory.createSoftBevelBorder(p0);
        }

        public void createSoftBevelBorder_test_1785(int p0, Color p1, Color p2)
        {
            BorderFactory.createSoftBevelBorder(p0, p1, p2);
        }

        public void createSoftBevelBorder_test_1786(int p0, Color p1, Color p2, Color p3, Color p4)
        {
            BorderFactory.createSoftBevelBorder(p0, p1, p2, p3, p4);
        }

        public void createEtchedBorder_test_1787(Color p0, Color p1)
        {
            BorderFactory.createEtchedBorder(p0, p1);
        }

        public void createEtchedBorder_test_1788(int p0)
        {
            BorderFactory.createEtchedBorder(p0);
        }

        public void createEtchedBorder_test_1789()
        {
            BorderFactory.createEtchedBorder();
        }

        public void createEtchedBorder_test_1790(int p0, Color p1, Color p2)
        {
            BorderFactory.createEtchedBorder(p0, p1, p2);
        }

        public void createTitledBorder_test_1791(Border p0, string p1, int p2, int p3, Font p4)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3, p4);
        }

        public void createTitledBorder_test_1792(Border p0, string p1, int p2, int p3, Font p4, Color p5)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3, p4, p5);
        }

        public void createTitledBorder_test_1793(string p0)
        {
            BorderFactory.createTitledBorder(p0);
        }

        public void createTitledBorder_test_1794(Border p0)
        {
            BorderFactory.createTitledBorder(p0);
        }

        public void createTitledBorder_test_1795(Border p0, string p1)
        {
            BorderFactory.createTitledBorder(p0, p1);
        }

        public void createTitledBorder_test_1796(Border p0, string p1, int p2, int p3)
        {
            BorderFactory.createTitledBorder(p0, p1, p2, p3);
        }

        public void createCompoundBorder_test_1797()
        {
            BorderFactory.createCompoundBorder();
        }

        public void createCompoundBorder_test_1798(Border p0, Border p1)
        {
            BorderFactory.createCompoundBorder(p0, p1);
        }

        public void createMatteBorder_test_1799(int p0, int p1, int p2, int p3, Color p4)
        {
            BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
        }

        public void createMatteBorder_test_1800(int p0, int p1, int p2, int p3, Icon p4)
        {
            BorderFactory.createMatteBorder(p0, p1, p2, p3, p4);
        }

        public void createRaisedBevelBorder_test_1801()
        {
            BorderFactory.createRaisedBevelBorder();
        }

        public void createRaisedSoftBevelBorder_test_1802()
        {
            BorderFactory.createRaisedSoftBevelBorder();
        }

        public void createLoweredSoftBevelBorder_test_1803()
        {
            BorderFactory.createLoweredSoftBevelBorder();
        }

        public void createDashedBorder_test_1804(Paint p0)
        {
            BorderFactory.createDashedBorder(p0);
        }

        public void createDashedBorder_test_1805(Paint p0, float p1, float p2)
        {
            BorderFactory.createDashedBorder(p0, p1, p2);
        }

        public void createDashedBorder_test_1806(Paint p0, float p1, float p2, float p3, bool p4)
        {
            BorderFactory.createDashedBorder(p0, p1, p2, p3, p4);
        }

        public void createStrokeBorder_test_1807(BasicStroke p0, Paint p1)
        {
            BorderFactory.createStrokeBorder(p0, p1);
        }

        public void createStrokeBorder_test_1808(BasicStroke p0)
        {
            BorderFactory.createStrokeBorder(p0);
        }

        public void createEmptyBorder_test_1809()
        {
            BorderFactory.createEmptyBorder();
        }

        public void createEmptyBorder_test_1810(int p0, int p1, int p2, int p3)
        {
            BorderFactory.createEmptyBorder(p0, p1, p2, p3);
        }

        public void createLineBorder_test_1811(Color p0, int p1, bool p2)
        {
            BorderFactory.createLineBorder(p0, p1, p2);
        }

        public void createLineBorder_test_1812(Color p0)
        {
            BorderFactory.createLineBorder(p0);
        }

        public void createLineBorder_test_1813(Color p0, int p1)
        {
            BorderFactory.createLineBorder(p0, p1);
        }
    }
}