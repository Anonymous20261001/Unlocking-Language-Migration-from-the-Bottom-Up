using System.Collections.Generic;

namespace Generated.Test
{
    public class MBeanNotificationInfo
    {
        public MBeanNotificationInfo(string[] notificationTypes, string name, string description)
        {
        }
    }

    public class Notification
    {
        public Notification(string type, object source, long sequenceNumber)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp)
        {
        }

        public Notification(string type, object source, long sequenceNumber, string message)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
        }
    }

    public class ObjectName
    {
        public ObjectName(string name)
        {
        }

        public ObjectName(string domain, string key, string value)
        {
        }
    }

    public class RelationService
    {
        private bool immediateCheck;
        private bool purgeFlag;

        public RelationService(bool immediateCheck)
        {
            this.immediateCheck = immediateCheck;
            this.purgeFlag = true;
        }

        public MBeanNotificationInfo[] getNotificationInfo()
        {
            return new MBeanNotificationInfo[0];
        }

        public void postRegister(bool? registrationDone)
        {
        }

        public void postDeregister()
        {
        }

        public void handleNotification(Notification notification, object handback)
        {
        }

        public List<string> getAllRelationTypeNames()
        {
            return new List<string>();
        }

        public bool? isRelation(ObjectName objectName)
        {
            return false;
        }

        public bool? hasRelation(string relationId)
        {
            return false;
        }

        public List<string> getAllRelationIds()
        {
            return new List<string>();
        }

        public Dictionary<ObjectName, List<string>> findAssociatedMBeans(ObjectName relationServiceName, string relationId, string roleName)
        {
            return new Dictionary<ObjectName, List<string>>();
        }

        public void setPurgeFlag(bool purgeFlag)
        {
            this.purgeFlag = purgeFlag;
        }

        public Dictionary<string, List<string>> findReferencingRelations(ObjectName relationServiceName, string relationId, string roleName)
        {
            return new Dictionary<string, List<string>>();
        }

        public bool getPurgeFlag()
        {
            return purgeFlag;
        }
    }

    public class javax_management_relation_RelationServiceAutoTest
    {
        public void getNotificationInfo_test_10508(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getNotificationInfo();
        }

        public void postRegister_test_10509(bool? p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.postRegister(p0);
        }

        public void postDeregister_test_10510(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.postDeregister();
        }

        public void handleNotification_test_10511(Notification p0, object p1, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.handleNotification(p0, p1);
        }

        public void getAllRelationTypeNames_test_10512(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getAllRelationTypeNames();
        }

        public void isRelation_test_10513(ObjectName p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.isRelation(p0);
        }

        public void hasRelation_test_10514(string p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.hasRelation(p0);
        }

        public void getAllRelationIds_test_10515(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getAllRelationIds();
        }

        public void findAssociatedMBeans_test_10516(ObjectName p0, string p1, string p2, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.findAssociatedMBeans(p0, p1, p2);
        }

        public void setPurgeFlag_test_10517(bool p0, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.setPurgeFlag(p0);
        }

        public void findReferencingRelations_test_10518(ObjectName p0, string p1, string p2, bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.findReferencingRelations(p0, p1, p2);
        }

        public void getPurgeFlag_test_10519(bool c0)
        {
            RelationService instance = new RelationService(c0);
            instance.getPurgeFlag();
        }
    }
}