namespace Generated.Test
{
    public interface CharSequence
    {
        int Length();
        char CharAt(int index);
        CharSequence SubSequence(int start, int end);
        string ToString();
    }

    public class Reader
    {
        private static readonly Reader _null = new Reader(null);
        private readonly CharSequence _cs;

        private Reader(CharSequence cs)
        {
            _cs = cs;
        }

        public static Reader NullReader()
        {
            return _null;
        }

        public static Reader Of(CharSequence cs)
        {
            return new Reader(cs);
        }

        public int Read()
        {
            if (_cs == null || _cs.Length() == 0)
            {
                return -1;
            }
            return -1;
        }

        public void Close()
        {
        }
    }

    public class java_io_ReaderAutoTest
    {
        public void nullReader_test_10346()
        {
            Reader.NullReader();
        }

        public void of_test_10347(CharSequence p0)
        {
            Reader.Of(p0);
        }
    }
}