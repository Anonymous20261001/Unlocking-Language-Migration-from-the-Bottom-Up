using System;

namespace Generated.Test
{
    public class HttpURLConnection
    {
        private static bool followRedirects = true;

        public static void setFollowRedirects(bool value)
        {
            followRedirects = value;
        }

        public static bool getFollowRedirects()
        {
            return followRedirects;
        }
    }

    public class java_net_HttpURLConnectionAutoTest
    {
        public void setFollowRedirects_test_5493(bool p0)
        {
            HttpURLConnection.setFollowRedirects(p0);
        }

        public void getFollowRedirects_test_5494()
        {
            HttpURLConnection.getFollowRedirects();
        }
    }
}