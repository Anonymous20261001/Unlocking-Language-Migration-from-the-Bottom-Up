using System;

namespace Generated.Test
{
    public interface CharSequence
    {
        int Length();
        char CharAt(int index);
        CharSequence SubSequence(int start, int end);
    }

    public interface TemporalAccessor
    {
    }

    public sealed class LocalDate
    {
        public int Year { get; }
        public int MonthValue { get; }
        public int DayOfMonth { get; }

        public LocalDate(int year, int month, int dayOfMonth)
        {
            Year = year;
            MonthValue = month;
            DayOfMonth = dayOfMonth;
        }
    }

    public sealed class LocalTime
    {
        public int Hour { get; }
        public int Minute { get; }
        public int Second { get; }
        public int NanoOfSecond { get; }

        public LocalTime(int hour, int minute, int second, int nanoOfSecond)
        {
            Hour = hour;
            Minute = minute;
            Second = second;
            NanoOfSecond = nanoOfSecond;
        }
    }

    public enum Month
    {
        JANUARY = 1,
        FEBRUARY = 2,
        MARCH = 3,
        APRIL = 4,
        MAY = 5,
        JUNE = 6,
        JULY = 7,
        AUGUST = 8,
        SEPTEMBER = 9,
        OCTOBER = 10,
        NOVEMBER = 11,
        DECEMBER = 12
    }

    public class ZoneId
    {
        public string Id { get; }

        public ZoneId(string id)
        {
            Id = id;
        }
    }

    public class ZoneOffset : ZoneId
    {
        public int TotalSeconds { get; }

        public ZoneOffset(int totalSeconds) : base("")
        {
            TotalSeconds = totalSeconds;
        }
    }

    public sealed class Instant
    {
        public long EpochSecond { get; }
        public int Nano { get; }

        public Instant(long epochSecond, int nano)
        {
            EpochSecond = epochSecond;
            Nano = nano;
        }
    }

    public sealed class Clock
    {
    }

    public sealed class DateTimeFormatter
    {
    }

    public sealed class LocalDateTime
    {
        public int Year { get; }
        public int MonthValue { get; }
        public int DayOfMonth { get; }
        public int Hour { get; }
        public int Minute { get; }
        public int Second { get; }
        public int NanoOfSecond { get; }

        private LocalDateTime(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            Year = year;
            MonthValue = month;
            DayOfMonth = dayOfMonth;
            Hour = hour;
            Minute = minute;
            Second = second;
            NanoOfSecond = nanoOfSecond;
        }

        public static LocalDateTime Of(LocalDate date, LocalTime time)
        {
            if (date == null || time == null)
                return null;

            return new LocalDateTime(date.Year, date.MonthValue, date.DayOfMonth,
                time.Hour, time.Minute, time.Second, time.NanoOfSecond);
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute)
        {
            return new LocalDateTime(year, month, dayOfMonth, hour, minute, 0, 0);
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalDateTime(year, (int)month, dayOfMonth, hour, minute, second, nanoOfSecond);
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute, int second)
        {
            return new LocalDateTime(year, (int)month, dayOfMonth, hour, minute, second, 0);
        }

        public static LocalDateTime Of(int year, Month month, int dayOfMonth, int hour, int minute)
        {
            return new LocalDateTime(year, (int)month, dayOfMonth, hour, minute, 0, 0);
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            return new LocalDateTime(year, month, dayOfMonth, hour, minute, second, nanoOfSecond);
        }

        public static LocalDateTime Of(int year, int month, int dayOfMonth, int hour, int minute, int second)
        {
            return new LocalDateTime(year, month, dayOfMonth, hour, minute, second, 0);
        }

        public static LocalDateTime From(TemporalAccessor temporal)
        {
            if (temporal == null)
                return null;

            return Now();
        }

        public static LocalDateTime Parse(CharSequence text)
        {
            if (text == null)
                return null;

            return null;
        }

        public static LocalDateTime Parse(CharSequence text, DateTimeFormatter formatter)
        {
            if (text == null)
                return null;

            return null;
        }

        public static LocalDateTime Now()
        {
            DateTime now = DateTime.Now;
            return new LocalDateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second, now.Millisecond * 1000000);
        }

        public static LocalDateTime Now(ZoneId zone)
        {
            if (zone == null)
                return null;

            return Now();
        }

        public static LocalDateTime Now(Clock clock)
        {
            if (clock == null)
                return null;

            return Now();
        }

        public static LocalDateTime OfEpochSecond(long epochSecond, int nanoOfSecond, ZoneOffset offset)
        {
            if (offset == null)
                return null;

            long localSecond = epochSecond + offset.TotalSeconds;
            DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            DateTime dt = epoch.AddSeconds(localSecond).AddTicks(nanoOfSecond / 100);
            return new LocalDateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second, nanoOfSecond);
        }

        public static LocalDateTime OfInstant(Instant instant, ZoneId zone)
        {
            if (instant == null || zone == null)
                return null;

            DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            DateTime dt = epoch.AddSeconds(instant.EpochSecond).AddTicks(instant.Nano / 100);
            return new LocalDateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second, instant.Nano);
        }
    }

    public class java_time_LocalDateTimeAutoTest
    {
        public void of_test_7999(LocalDate p0, LocalTime p1)
        {
            LocalDateTime.Of(p0, p1);
        }

        public void of_test_8000(int p0, int p1, int p2, int p3, int p4)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_8001(int p0, Month p1, int p2, int p3, int p4, int p5, int p6)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5, p6);
        }

        public void of_test_8002(int p0, Month p1, int p2, int p3, int p4, int p5)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5);
        }

        public void of_test_8003(int p0, Month p1, int p2, int p3, int p4)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_8004(int p0, int p1, int p2, int p3, int p4, int p5, int p6)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5, p6);
        }

        public void of_test_8005(int p0, int p1, int p2, int p3, int p4, int p5)
        {
            LocalDateTime.Of(p0, p1, p2, p3, p4, p5);
        }

        public void from_test_8006(TemporalAccessor p0)
        {
            LocalDateTime.From(p0);
        }

        public void parse_test_8007(CharSequence p0)
        {
            LocalDateTime.Parse(p0);
        }

        public void parse_test_8008(CharSequence p0, DateTimeFormatter p1)
        {
            LocalDateTime.Parse(p0, p1);
        }

        public void now_test_8009()
        {
            LocalDateTime.Now();
        }

        public void now_test_8010(ZoneId p0)
        {
            LocalDateTime.Now(p0);
        }

        public void now_test_8011(Clock p0)
        {
            LocalDateTime.Now(p0);
        }

        public void ofEpochSecond_test_8012(long p0, int p1, ZoneOffset p2)
        {
            LocalDateTime.OfEpochSecond(p0, p1, p2);
        }

        public void ofInstant_test_8013(Instant p0, ZoneId p1)
        {
            LocalDateTime.OfInstant(p0, p1);
        }
    }
}