namespace Generated.Test
{
    public sealed class Clock
    {
        private Clock() { }

        public static Clock offset(Clock baseClock, Duration offsetDuration)
        {
            return null;
        }

        public static Clock system(ZoneId zone)
        {
            return null;
        }

        public static Clock fixed(Instant fixedInstant, ZoneId zone)
        {
            return null;
        }

        public static Clock systemUTC()
        {
            return null;
        }

        public static Clock systemDefaultZone()
        {
            return null;
        }

        public static Clock tickMillis(ZoneId zone)
        {
            return null;
        }

        public static Clock tickSeconds(ZoneId zone)
        {
            return null;
        }

        public static Clock tickMinutes(ZoneId zone)
        {
            return null;
        }

        public static Clock tick(Clock baseClock, Duration tickDuration)
        {
            return null;
        }
    }

    public sealed class Duration
    {
    }

    public sealed class Instant
    {
    }

    public sealed class ZoneId
    {
    }

    public class java_time_ClockAutoTest
    {
        public void offset_test_2329(Clock p0, Duration p1)
        {
            Clock.offset(p0, p1);
        }

        public void system_test_2330(ZoneId p0)
        {
            Clock.system(p0);
        }

        public void fixed_test_2331(Instant p0, ZoneId p1)
        {
            Clock.fixed(p0, p1);
        }

        public void systemUTC_test_2332()
        {
            Clock.systemUTC();
        }

        public void systemDefaultZone_test_2333()
        {
            Clock.systemDefaultZone();
        }

        public void tickMillis_test_2334(ZoneId p0)
        {
            Clock.tickMillis(p0);
        }

        public void tickSeconds_test_2335(ZoneId p0)
        {
            Clock.tickSeconds(p0);
        }

        public void tickMinutes_test_2336(ZoneId p0)
        {
            Clock.tickMinutes(p0);
        }

        public void tick_test_2337(Clock p0, Duration p1)
        {
            Clock.tick(p0, p1);
        }
    }
}