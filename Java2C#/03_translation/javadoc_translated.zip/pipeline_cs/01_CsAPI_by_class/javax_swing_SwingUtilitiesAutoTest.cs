using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Generated.Test
{
    // Minimal stubs for Java AWT/Swing types
    public class Component : Control { }
    public class Container : Component { }
    public class JComponent : Container { }
    public class JViewport : JComponent { }
    public class Window : Component { }
    public class Frame : Window { }
    public class RootPane : JComponent { }
    public class Graphics { }
    public class FontMetrics { }
    public class Point
    {
        public int x, y;
        public Point() { }
        public Point(int x, int y) { this.x = x; this.y = y; }
    }
    public class Rectangle
    {
        public int x, y, width, height;
        public Rectangle() { }
        public Rectangle(int x, int y, int width, int height)
        {
            this.x = x; this.y = y; this.width = width; this.height = height;
        }
    }
    public class KeyEvent
    {
        public int keyCode;
        public char keyChar;
        public Component component;
        public KeyEvent(Component source, int id, long when, int modifiers, int keyCode, char keyChar)
        {
            this.keyCode = keyCode;
            this.keyChar = keyChar;
            this.component = source;
        }
    }
    public class MouseEvent
    {
        public int button;
        public int x, y;
        public Component component;
        public MouseEvent(Component source, int id, long when, int modifiers, int x, int y, int clickCount, bool popupTrigger, int button)
        {
            this.button = button;
            this.x = x;
            this.y = y;
            this.component = source;
        }
    }
    public class Action { }
    public class ActionMap { }
    public class InputMap { }
    public class Icon { }
    public class KeyStroke { }
    public class Runnable
    {
        public virtual void Run() { }
    }
    public class Class
    {
        public string Name;
        public Class(string name) { Name = name; }
    }

    public static class SwingUtilities
    {
        public static Component getUnwrappedParent(Component p0)
        {
            return p0.Parent as Component;
        }

        public static bool isEventDispatchThread()
        {
            return true;
        }

        public static void updateComponentTreeUI(Component p0)
        {
            // No-op
        }

        public static bool isDescendingFrom(Component p0, Component p1)
        {
            Component current = p0;
            while (current != null)
            {
                if (current == p1) return true;
                current = current.Parent as Component;
            }
            return false;
        }

        public static ActionMap getUIActionMap(JComponent p0)
        {
            return new ActionMap();
        }

        public static RootPane getRootPane(Component p0)
        {
            return new RootPane();
        }

        public static Window getWindowAncestor(Component p0)
        {
            Component current = p0;
            while (current != null)
            {
                if (current is Window) return (Window)current;
                current = current.Parent as Component;
            }
            return null;
        }

        public static Rectangle computeIntersection(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            int x1 = Math.Max(p0, p4.x);
            int y1 = Math.Max(p1, p4.y);
            int x2 = Math.Min(p0 + p2, p4.x + p4.width);
            int y2 = Math.Min(p1 + p3, p4.y + p4.height);
            if (x2 < x1 || y2 < y1)
            {
                p4.x = 0; p4.y = 0; p4.width = 0; p4.height = 0;
            }
            else
            {
                p4.x = x1; p4.y = y1; p4.width = x2 - x1; p4.height = y2 - y1;
            }
            return p4;
        }

        public static void paintComponent(Graphics p0, Component p1, Container p2, Rectangle p3)
        {
            // No-op
        }

        public static void paintComponent(Graphics p0, Component p1, Container p2, int p3, int p4, int p5, int p6)
        {
            // No-op
        }

        public static bool processKeyBindings(KeyEvent p0)
        {
            return false;
        }

        public static void notifyAction(Action p0, KeyStroke p1, KeyEvent p2, Object p3, int p4)
        {
            // No-op
        }

        public static Rectangle convertRectangle(Component p0, Rectangle p1, Component p2)
        {
            return new Rectangle(p1.x, p1.y, p1.width, p1.height);
        }

        public static void invokeLater(Runnable p0)
        {
            p0.Run();
        }

        public static int getAccessibleChildrenCount(Component p0)
        {
            return 0;
        }

        public static object getAccessibleChild(Component p0, int p1)
        {
            return null;
        }

        public static object getAccessibleAt(Component p0, Point p1)
        {
            return null;
        }

        public static int getAccessibleIndexInParent(Component p0)
        {
            return -1;
        }

        public static object getAccessibleStateSet(Component p0)
        {
            return null;
        }

        public static Point convertPoint(Component p0, Point p1, Component p2)
        {
            return new Point(p1.x, p1.y);
        }

        public static Point convertPoint(Component p0, int p1, int p2, Component p3)
        {
            return new Point(p1, p2);
        }

        public static MouseEvent convertMouseEvent(Component p0, MouseEvent p1, Component p2)
        {
            return p1;
        }

        public static void replaceUIInputMap(JComponent p0, int p1, InputMap p2)
        {
            // No-op
        }

        public static void replaceUIActionMap(JComponent p0, ActionMap p1)
        {
            // No-op
        }

        public static InputMap getUIInputMap(JComponent p0, int p1)
        {
            return new InputMap();
        }

        public static bool isLeftMouseButton(MouseEvent p0)
        {
            return p0.button == 1;
        }

        public static string layoutCompoundLabel(FontMetrics p0, string p1, Icon p2, int p3, int p4, int p5, int p6, Rectangle p7, Rectangle p8, Rectangle p9, int p10)
        {
            return p1;
        }

        public static string layoutCompoundLabel(JComponent p0, FontMetrics p1, string p2, Icon p3, int p4, int p5, int p6, int p7, Rectangle p8, Rectangle p9, Rectangle p10, int p11)
        {
            return p2;
        }

        public static Component getAncestorOfClass(Class p0, Component p1)
        {
            Component current = p1;
            while (current != null)
            {
                if (current.GetType().Name == p0.Name) return current;
                current = current.Parent as Component;
            }
            return null;
        }

        public static void convertPointToScreen(Point p0, Component p1)
        {
            // No-op
        }

        public static void convertPointFromScreen(Point p0, Component p1)
        {
            // No-op
        }

        public static Component getDeepestComponentAt(Component p0, int p1, int p2)
        {
            return p0;
        }

        public static bool isRectangleContainingRectangle(Rectangle p0, Rectangle p1)
        {
            return p0.x <= p1.x && p0.y <= p1.y &&
                   (p0.x + p0.width) >= (p1.x + p1.width) &&
                   (p0.y + p0.height) >= (p1.y + p1.height);
        }

        public static Rectangle getLocalBounds(Component p0)
        {
            return new Rectangle(0, 0, p0.Width, p0.Height);
        }

        public static Component getAncestorNamed(string p0, Component p1)
        {
            Component current = p1;
            while (current != null)
            {
                if (current.Name == p0) return current;
                current = current.Parent as Component;
            }
            return null;
        }

        public static Window windowForComponent(Component p0)
        {
            return getWindowAncestor(p0);
        }

        public static Rectangle computeUnion(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            int x1 = Math.Min(p0, p4.x);
            int y1 = Math.Min(p1, p4.y);
            int x2 = Math.Max(p0 + p2, p4.x + p4.width);
            int y2 = Math.Max(p1 + p3, p4.y + p4.height);
            p4.x = x1; p4.y = y1; p4.width = x2 - x1; p4.height = y2 - y1;
            return p4;
        }

        public static Rectangle[] computeDifference(Rectangle p0, Rectangle p1)
        {
            return new Rectangle[0];
        }

        public static bool isMiddleMouseButton(MouseEvent p0)
        {
            return p0.button == 2;
        }

        public static bool isRightMouseButton(MouseEvent p0)
        {
            return p0.button == 3;
        }

        public static int computeStringWidth(FontMetrics p0, string p1)
        {
            return p1.Length;
        }

        public static Component findFocusOwner(Component p0)
        {
            return p0;
        }

        public static Rectangle calculateInnerArea(JComponent p0, Rectangle p1)
        {
            return new Rectangle(0, 0, p0.Width, p0.Height);
        }

        public static Component getUnwrappedView(JViewport p0)
        {
            return p0;
        }

        public static Component getRoot(Component p0)
        {
            Component current = p0;
            while (current.Parent != null)
            {
                current = current.Parent as Component;
            }
            return current;
        }
    }

    public class javax_swing_SwingUtilitiesAutoTest
    {
        public void getUnwrappedParent_test_12073(Component p0)
        {
            SwingUtilities.getUnwrappedParent(p0);
        }

        public void isEventDispatchThread_test_12074()
        {
            SwingUtilities.isEventDispatchThread();
        }

        public void updateComponentTreeUI_test_12075(Component p0)
        {
            SwingUtilities.updateComponentTreeUI(p0);
        }

        public void isDescendingFrom_test_12076(Component p0, Component p1)
        {
            SwingUtilities.isDescendingFrom(p0, p1);
        }

        public void getUIActionMap_test_12077(JComponent p0)
        {
            SwingUtilities.getUIActionMap(p0);
        }

        public void getRootPane_test_12078(Component p0)
        {
            SwingUtilities.getRootPane(p0);
        }

        public void getWindowAncestor_test_12079(Component p0)
        {
            SwingUtilities.getWindowAncestor(p0);
        }

        public void computeIntersection_test_12080(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            SwingUtilities.computeIntersection(p0, p1, p2, p3, p4);
        }

        public void paintComponent_test_12081(Graphics p0, Component p1, Container p2, Rectangle p3)
        {
            SwingUtilities.paintComponent(p0, p1, p2, p3);
        }

        public void paintComponent_test_12082(Graphics p0, Component p1, Container p2, int p3, int p4, int p5, int p6)
        {
            SwingUtilities.paintComponent(p0, p1, p2, p3, p4, p5, p6);
        }

        public void processKeyBindings_test_12083(KeyEvent p0)
        {
            SwingUtilities.processKeyBindings(p0);
        }

        public void notifyAction_test_12084(Action p0, KeyStroke p1, KeyEvent p2, Object p3, int p4)
        {
            SwingUtilities.notifyAction(p0, p1, p2, p3, p4);
        }

        public void convertRectangle_test_12085(Component p0, Rectangle p1, Component p2)
        {
            SwingUtilities.convertRectangle(p0, p1, p2);
        }

        public void invokeLater_test_12086(Runnable p0)
        {
            SwingUtilities.invokeLater(p0);
        }

        public void getAccessibleChildrenCount_test_12087(Component p0)
        {
            SwingUtilities.getAccessibleChildrenCount(p0);
        }

        public void getAccessibleChild_test_12088(Component p0, int p1)
        {
            SwingUtilities.getAccessibleChild(p0, p1);
        }

        public void getAccessibleAt_test_12089(Component p0, Point p1)
        {
            SwingUtilities.getAccessibleAt(p0, p1);
        }

        public void getAccessibleIndexInParent_test_12090(Component p0)
        {
            SwingUtilities.getAccessibleIndexInParent(p0);
        }

        public void getAccessibleStateSet_test_12091(Component p0)
        {
            SwingUtilities.getAccessibleStateSet(p0);
        }

        public void convertPoint_test_12092(Component p0, Point p1, Component p2)
        {
            SwingUtilities.convertPoint(p0, p1, p2);
        }

        public void convertPoint_test_12093(Component p0, int p1, int p2, Component p3)
        {
            SwingUtilities.convertPoint(p0, p1, p2, p3);
        }

        public void convertMouseEvent_test_12094(Component p0, MouseEvent p1, Component p2)
        {
            SwingUtilities.convertMouseEvent(p0, p1, p2);
        }

        public void replaceUIInputMap_test_12095(JComponent p0, int p1, InputMap p2)
        {
            SwingUtilities.replaceUIInputMap(p0, p1, p2);
        }

        public void replaceUIActionMap_test_12096(JComponent p0, ActionMap p1)
        {
            SwingUtilities.replaceUIActionMap(p0, p1);
        }

        public void getUIInputMap_test_12097(JComponent p0, int p1)
        {
            SwingUtilities.getUIInputMap(p0, p1);
        }

        public void isLeftMouseButton_test_12098(MouseEvent p0)
        {
            SwingUtilities.isLeftMouseButton(p0);
        }

        public void layoutCompoundLabel_test_12099(FontMetrics p0, string p1, Icon p2, int p3, int p4, int p5, int p6, Rectangle p7, Rectangle p8, Rectangle p9, int p10)
        {
            SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
        }

        public void layoutCompoundLabel_test_12100(JComponent p0, FontMetrics p1, string p2, Icon p3, int p4, int p5, int p6, int p7, Rectangle p8, Rectangle p9, Rectangle p10, int p11)
        {
            SwingUtilities.layoutCompoundLabel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11);
        }

        public void getAncestorOfClass_test_12101(Class p0, Component p1)
        {
            SwingUtilities.getAncestorOfClass(p0, p1);
        }

        public void convertPointToScreen_test_12102(Point p0, Component p1)
        {
            SwingUtilities.convertPointToScreen(p0, p1);
        }

        public void convertPointFromScreen_test_12103(Point p0, Component p1)
        {
            SwingUtilities.convertPointFromScreen(p0, p1);
        }

        public void getDeepestComponentAt_test_12104(Component p0, int p1, int p2)
        {
            SwingUtilities.getDeepestComponentAt(p0, p1, p2);
        }

        public void isRectangleContainingRectangle_test_12105(Rectangle p0, Rectangle p1)
        {
            SwingUtilities.isRectangleContainingRectangle(p0, p1);
        }

        public void getLocalBounds_test_12106(Component p0)
        {
            SwingUtilities.getLocalBounds(p0);
        }

        public void getAncestorNamed_test_12107(string p0, Component p1)
        {
            SwingUtilities.getAncestorNamed(p0, p1);
        }

        public void windowForComponent_test_12108(Component p0)
        {
            SwingUtilities.windowForComponent(p0);
        }

        public void computeUnion_test_12109(int p0, int p1, int p2, int p3, Rectangle p4)
        {
            SwingUtilities.computeUnion(p0, p1, p2, p3, p4);
        }

        public void computeDifference_test_12110(Rectangle p0, Rectangle p1)
        {
            SwingUtilities.computeDifference(p0, p1);
        }

        public void isMiddleMouseButton_test_12111(MouseEvent p0)
        {
            SwingUtilities.isMiddleMouseButton(p0);
        }

        public void isRightMouseButton_test_12112(MouseEvent p0)
        {
            SwingUtilities.isRightMouseButton(p0);
        }

        public void computeStringWidth_test_12113(FontMetrics p0, string p1)
        {
            SwingUtilities.computeStringWidth(p0, p1);
        }

        public void findFocusOwner_test_12114(Component p0)
        {
            SwingUtilities.findFocusOwner(p0);
        }

        public void calculateInnerArea_test_12115(JComponent p0, Rectangle p1)
        {
            SwingUtilities.calculateInnerArea(p0, p1);
        }

        public void getUnwrappedView_test_12116(JViewport p0)
        {
            SwingUtilities.getUnwrappedView(p0);
        }

        public void getRoot_test_12117(Component p0)
        {
            SwingUtilities.getRoot(p0);
        }
    }
}