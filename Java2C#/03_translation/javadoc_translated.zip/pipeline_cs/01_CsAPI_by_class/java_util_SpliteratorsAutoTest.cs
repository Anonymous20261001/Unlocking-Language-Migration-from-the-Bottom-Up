```csharp
namespace Generated.Test
{
    public interface Iterator
    {
    }

    public interface PrimitiveIterator : Iterator
       {
        interface OfInt : PrimitiveIterator { }
        interface OfLong : PrimitiveIterator { }
        interface OfDouble : PrimitiveIterator { }
    }

    public interface Spliterator
    {
        interface OfInt : Spliterator { }
        interface OfLong : Spliterator { }
        interface OfDouble : Spliterator { }
    }

    public interface Collection
    {
    }

    public static class Spliterators
    {
        private static readonly Iterator emptyIterator = new EmptyIterator();
        private static readonly PrimitiveIterator.OfInt emptyIntIterator = new EmptyIntIterator();
        private static readonly PrimitiveIterator.OfLong emptyLongIterator = new EmptyLongIterator();
        private static readonly PrimitiveIterator.OfDouble emptyDoubleIterator = new EmptyDoubleIterator();

        private static readonly Spliterator emptySpliteratorImpl = new EmptySpliteratorImpl();
        private static readonly Spliterator.OfInt emptyIntSpliteratorImpl = new EmptyIntSpliteratorImpl();
        private static readonly Spliterator.OfLong emptyLongSpliteratorImpl = new EmptyLongSpliteratorImpl();
        private static readonly Spliterator.OfDouble emptyDoubleSpliteratorImpl = new EmptyDoubleSpliteratorImpl();

        public static Iterator iterator(Spliterator spliterator) => emptyIterator;
        public static PrimitiveIterator.OfInt iterator(Spliterator.OfInt spliterator) => emptyIntIterator;
        public static PrimitiveIterator.OfLong iterator(Spliterator.OfLong spliterator) => emptyLongIterator;
        public static PrimitiveIterator.OfDouble iterator(Spliterator.OfDouble spliterator) => emptyDoubleIterator;

        public static Spliterator spliteratorUnknownSize(Iterator iterator, int characteristics) => emptySpliteratorImpl;
        public static Spliterator.OfInt spliteratorUnknownSize(PrimitiveIterator.OfInt iterator, int characteristics) => emptyIntSpliteratorImpl;
        public static Spliterator.OfLong spliteratorUnknownSize(PrimitiveIterator.OfLong iterator, int characteristics) => emptyLongSpliteratorImpl;
        public static Spliterator.OfDouble spliteratorUnknownSize(PrimitiveIterator.OfDouble iterator, int characteristics) => emptyDoubleSpliteratorImpl;

        public static Spliterator spliterator(object[] array, int characteristics) => emptySpliteratorImpl;
        public static Spliterator spliterator(object[] array, int fromIndex, int toIndex, int characteristics) => emptySpliteratorImpl;
        public static Spliterator spliterator(Collection collection, int characteristics) => emptySpliteratorImpl;
        public static Spliterator spliterator(Iterator iterator, long size, int characteristics) => emptySpliteratorImpl;

        public static Spliterator.OfInt spliterator(int[] array, int characteristics) => emptyIntSpliteratorImpl;
        public static Spliterator.OfInt spliterator(int[] array, int fromIndex, int toIndex, int characteristics) => emptyIntSpliteratorImpl;
        public static Spliterator.OfInt spliterator(PrimitiveIterator.OfInt iterator, long size, int characteristics) => emptyIntSpliteratorImpl;

        public static Spliterator.OfLong spliterator(long[] array, int characteristics) => emptyLongSpliteratorImpl;
        public static Spliterator.OfLong spliterator(long[] array, int fromIndex, int toIndex, int characteristics) => emptyLongSpliteratorImpl;
        public static Spliterator.OfLong spliterator(PrimitiveIterator.OfLong iterator, long size, int characteristics) => emptyLongSpliteratorImpl;

        public static Spliterator.OfDouble spliterator(double[] array, int characteristics) => emptyDoubleSpliteratorImpl;
        public static Spliterator.OfDouble spliterator(double[] array, int fromIndex, int toIndex, int characteristics) => emptyDoubleSpliteratorImpl;
        public static Spliterator.OfDouble spliterator(PrimitiveIterator.OfDouble iterator, long size, int characteristics) => emptyDoubleSpliteratorImpl;

        public static Spliterator emptySpliterator() => emptySpliteratorImpl;
        public static Spliterator.OfInt emptyIntSpliterator() => emptyIntSpliteratorImpl;
        public static Spliterator.OfLong emptyLongSpliterator() => emptyLongSpliteratorImpl;
        public static Spliterator.OfDouble emptyDoubleSpliterator() => emptyDoubleSpliteratorImpl;

        private class EmptyIterator : Iterator { }
        private class EmptyIntIterator : PrimitiveIterator.OfInt { }
        private class EmptyLongIterator : PrimitiveIterator.OfLong { }
        private class EmptyDoubleIterator : PrimitiveIterator.OfDouble { }
        private class EmptySpliteratorImpl : Spliterator { }
        private class EmptyIntSpliteratorImpl : Spliterator.OfInt { }
        private class EmptyLongSpliteratorImpl : Spliterator.OfLong { }
        private class EmptyDoubleSpliteratorImpl : Spliterator.OfDouble { }
    }

    public class java_util_SpliteratorsAutoTest
    {
        public void iterator_test_11314(Spliterator.OfDouble p0)
        {
            Spliterators.iterator(p0);
        }

        public void iterator_test_11315(Spliterator p0)
        {
            Spliterators.iterator(p0);
        }

        public void iterator_test_11316(Spliterator.OfInt p0)
        {
            Spliterators.iterator(p0);
        }

        public void iterator_test_11317(Spliterator.OfLong p0)
        {
            Spliterators.iterator(p0);
        }

        public void spliteratorUnknownSize_test_11318(PrimitiveIterator.OfInt p0, int p1)
        {
            Spliterators.spliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11319(PrimitiveIterator.OfLong p0, int p1)
        {
            Spliterators.spliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11320(PrimitiveIterator.OfDouble p0, int p1)
        {
            Spliterators.spliteratorUnknownSize(p0, p1);
        }

        public void spliteratorUnknownSize_test_11321(Iterator p0, int p1)
        {
            Spliterators.spliteratorUnknownSize(p0, p1);
        }

        public void spliterator_test_11322(object[] p0, int p1)
        {
            Spliterators.spliterator(p0, p1);
        }

        public void spliterator_test_11323(Iterator p0, long p1, int p2)
        {
            Spliterators.spliterator(p0, p1, p2);
        }

        public void spliterator_test_11324(Collection p0, int p1)
        {
            Spliterators.spliterator(p0, p1);
        }

        public void spliterator_test_11325(PrimitiveIterator.OfInt p0, long p1, int p2)
        {
            Spliterators.spliterator(p0, p1, p2);
        }

        public void spliterator_test_11326(PrimitiveIterator.OfLong p0, long p1, int p2)
        {
            Spliterators.spliterator(p0, p1, p2);
        }

        public void spliterator_test_11327(PrimitiveIterator.OfDouble p0, long p1, int p2)
        {
            Spliterators.spliterator(p0, p1, p2);
        }

        public void spliterator_test_11328(long[] p0, int p1, int p2, int p3)
        {
            Spliterators.spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11329(long[] p0, int p1)
        {
            Spliterators.spliterator(p0, p1);
        }

        public void spliterator_test_11330(int[] p0, int p1, int p2, int p3)
        {
            Spliterators.spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11331(object[] p0, int p1, int p2, int p3)
        {
            Spliterators.spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11332(int[] p0, int p1)
        {
            Spliterators.spliterator(p0, p1);
        }

        public void spliterator_test_11333(double[] p0, int p1, int p2, int p3)
        {
            Spliterators.spliterator(p0, p1, p2, p3);
        }

        public void spliterator_test_11334(double[] p0, int p1)
        {
            Spliterators.spliterator(p0, p1);
        }

        public void emptySpliterator_test_11335()
        {
            Spliterators.emptySpliterator();
        }

        public void emptyIntSpliterator_test_11336()
        {
            Spliterators.emptyIntSpliterator();
        }

        public void emptyLongSpliterator_test_11337()
        {
            Spliterators.emptyLongSpliterator();
        }

        public void emptyDoubleSpliterator_test_11338()
        {
            Spliterators.emptyDoubleSpliterator();
        }
    }
}
```