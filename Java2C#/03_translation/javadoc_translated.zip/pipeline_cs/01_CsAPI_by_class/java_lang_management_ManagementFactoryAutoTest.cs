using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_lang_management_ManagementFactoryAutoTest
    {
        public void getPlatformMXBean_test_8262(Type p0)
        {
            ManagementFactory.getPlatformMXBean(p0);
        }

        public void getPlatformMXBeans_test_8263(Type p0)
        {
            ManagementFactory.getPlatformMXBeans(p0);
        }

        public void getClassLoadingMXBean_test_8264()
        {
            ManagementFactory.getClassLoadingMXBean();
        }

        public void getMemoryMXBean_test_8265()
        {
            ManagementFactory.getMemoryMXBean();
        }

        public void getThreadMXBean_test_8266()
        {
            ManagementFactory.getThreadMXBean();
        }

        public void getRuntimeMXBean_test_8267()
        {
            ManagementFactory.getRuntimeMXBean();
        }

        public void getCompilationMXBean_test_8268()
        {
            ManagementFactory.getCompilationMXBean();
        }

        public void getOperatingSystemMXBean_test_8269()
        {
            ManagementFactory.getOperatingSystemMXBean();
        }

        public void getMemoryPoolMXBeans_test_8270()
        {
            ManagementFactory.getMemoryPoolMXBeans();
        }

        public void getMemoryManagerMXBeans_test_8271()
        {
            ManagementFactory.getMemoryManagerMXBeans();
        }

        public void getGarbageCollectorMXBeans_test_8272()
        {
            ManagementFactory.getGarbageCollectorMXBeans();
        }

        public void getPlatformMBeanServer_test_8273()
        {
            ManagementFactory.getPlatformMBeanServer();
        }

        public void getPlatformManagementInterfaces_test_8274()
        {
            ManagementFactory.getPlatformManagementInterfaces();
        }
    }

    public static class ManagementFactory
    {
        public static object getPlatformMXBean(Type type)
        {
            return null;
        }

        public static T getPlatformMXBean<T>(Type type)
        {
            return default(T);
        }

        public static List<object> getPlatformMXBeans(Type type)
        {
            return new List<object>();
        }

        public static List<T> getPlatformMXBeans<T>(Type type)
        {
            return new List<T>();
        }

        public static ClassLoadingMXBean getClassLoadingMXBean()
        {
            return new ClassLoadingMXBeanImpl();
        }

        public static MemoryMXBean getMemoryMXBean()
        {
            return new MemoryMXBeanImpl();
        }

        public static ThreadMXBean getThreadMXBean()
        {
            return new ThreadMXBeanImpl();
        }

        public static RuntimeMXBean getRuntimeMXBean()
        {
            return new RuntimeMXBeanImpl();
        }

        public static CompilationMXBean getCompilationMXBean()
        {
            return new CompilationMXBeanImpl();
        }

        public static OperatingSystemMXBean getOperatingSystemMXBean()
        {
            return new OperatingSystemMXBeanImpl();
        }

        public static List<MemoryPoolMXBean> getMemoryPoolMXBeans()
        {
            return new List<MemoryPoolMXBean>();
        }

        public static List<MemoryManagerMXBean> getMemoryManagerMXBeans()
        {
            return new List<MemoryManagerMXBean>();
        }

        public static List<GarbageCollectorMXBean> getGarbageCollectorMXBeans()
        {
            return new List<GarbageCollectorMXBean>();
        }

        public static MBeanServer getPlatformMBeanServer()
        {
            return new MBeanServerImpl();
        }

        public static ISet<Type> getPlatformManagementInterfaces()
        {
            return new HashSet<Type>();
        }
    }

    public interface PlatformManagedObject
    {
    }

    public interface ClassLoadingMXBean : PlatformManagedObject
    {
    }

    public interface MemoryMXBean : PlatformManagedObject
    {
    }

    public interface ThreadMXBean : PlatformManagedObject
    {
    }

    public interface RuntimeMXBean : PlatformManagedObject
    {
    }

    public interface CompilationMXBean : PlatformManagedObject
    {
    }

    public interface OperatingSystemMXBean : PlatformManagedObject
    {
    }

    public interface MemoryPoolMXBean : PlatformManagedObject
    {
    }

    public interface MemoryManagerMXBean : PlatformManagedObject
    {
    }

    public interface GarbageCollectorMXBean : MemoryManagerMXBean
    {
    }

    public interface MBeanServer
    {
    }

    internal class ClassLoadingMXBeanImpl : ClassLoadingMXBean
    {
    }

    internal class MemoryMXBeanImpl : MemoryMXBean
    {
    }

    internal class ThreadMXBeanImpl : ThreadMXBean
    {
    }

    internal class RuntimeMXBeanImpl : RuntimeMXBean
    {
    }

    internal class CompilationMXBeanImpl : CompilationMXBean
    {
    }

    internal class OperatingSystemMXBeanImpl : OperatingSystemMXBean
    {
    }

    internal class MBeanServerImpl : MBeanServer
    {
    }
}