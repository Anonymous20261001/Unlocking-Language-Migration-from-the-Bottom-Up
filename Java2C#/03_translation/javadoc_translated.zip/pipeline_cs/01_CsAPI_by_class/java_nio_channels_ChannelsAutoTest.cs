namespace Generated.Test
{
    public interface ReadableByteChannel { }
    public interface WritableByteChannel { }
    public interface AsynchronousByteChannel { }

    public abstract class InputStream { }
    public abstract class OutputStream { }
    public abstract class Reader { }
    public abstract class Writer { }

    public class Charset { }
    public class CharsetDecoder { }
    public class CharsetEncoder { }

    public static class Channels
    {
        public static Reader newReader(ReadableByteChannel ch, CharsetDecoder dec, int minBufferCap) { return null; }
        public static Reader newReader(ReadableByteChannel ch, Charset charset) { return null; }
        public static Reader newReader(ReadableByteChannel ch, string csName) { return null; }

        public static OutputStream newOutputStream(AsynchronousByteChannel ch) { return null; }
        public static OutputStream newOutputStream(WritableByteChannel ch) { return null; }

        public static Writer newWriter(WritableByteChannel ch, CharsetEncoder enc, int minBufferCap) { return null; }
        public static Writer newWriter(WritableByteChannel ch, string csName) { return null; }
        public static Writer newWriter(WritableByteChannel ch, Charset charset) { return null; }

        public static InputStream newInputStream(ReadableByteChannel ch) { return null; }
        public static InputStream newInputStream(AsynchronousByteChannel ch) { return null; }

        public static ReadableByteChannel newChannel(InputStream in) { return null; }
        public static WritableByteChannel newChannel(OutputStream out) { return null; }
    }

    public class java_nio_channels_ChannelsAutoTest
    {
        public void newReader_test_2112(ReadableByteChannel p0, CharsetDecoder p1, int p2)
        {
            Channels.newReader(p0, p1, p2);
        }

        public void newReader_test_2113(ReadableByteChannel p0, Charset p1)
        {
            Channels.newReader(p0, p1);
        }

        public void newReader_test_2114(ReadableByteChannel p0, string p1)
        {
            Channels.newReader(p0, p1);
        }

        public void newOutputStream_test_2115(AsynchronousByteChannel p0)
        {
            Channels.newOutputStream(p0);
        }

        public void newOutputStream_test_2116(WritableByteChannel p0)
        {
            Channels.newOutputStream(p0);
        }

        public void newWriter_test_2117(WritableByteChannel p0, CharsetEncoder p1, int p2)
        {
            Channels.newWriter(p0, p1, p2);
        }

        public void newWriter_test_2118(WritableByteChannel p0, string p1)
        {
            Channels.newWriter(p0, p1);
        }

        public void newWriter_test_2119(WritableByteChannel p0, Charset p1)
        {
            Channels.newWriter(p0, p1);
        }

        public void newInputStream_test_2120(ReadableByteChannel p0)
        {
            Channels.newInputStream(p0);
        }

        public void newInputStream_test_2121(AsynchronousByteChannel p0)
        {
            Channels.newInputStream(p0);
        }

        public void newChannel_test_2122(InputStream p0)
        {
            Channels.newChannel(p0);
        }

        public void newChannel_test_2123(OutputStream p0)
        {
            Channels.newChannel(p0);
        }
    }
}