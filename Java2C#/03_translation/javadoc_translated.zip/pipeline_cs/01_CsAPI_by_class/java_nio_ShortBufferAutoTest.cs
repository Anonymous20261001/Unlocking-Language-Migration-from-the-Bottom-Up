using System;

namespace Generated.Test
{
    public class ShortBuffer
    {
        private readonly short[] _buffer;
        private int _position;
        private int _limit;

        private ShortBuffer(short[] buffer, int offset, int length)
        {
            _buffer = buffer;
            _position = offset;
            _limit = offset + length;
        }

        public static ShortBuffer wrap(short[] array)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));

            return new ShortBuffer(array, 0, array.Length);
        }

        public static ShortBuffer wrap(short[] array, int offset, int length)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array));

            if (offset < 0 || length < 0 || offset > array.Length - length)
                throw new ArgumentOutOfRangeException();

            return new ShortBuffer(array, offset, length);
        }

        public static ShortBuffer allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentOutOfRangeException(nameof(capacity));

            return new ShortBuffer(new short[capacity], 0, capacity);
        }

        public int capacity()
        {
            return _buffer.Length;
        }

        public int position()
        {
            return _position;
        }

        public int limit()
        {
            return _limit;
        }
    }

    public class java_nio_ShortBufferAutoTest
    {
        public void wrap_test_11098(short[] p0)
        {
            ShortBuffer.wrap(p0);
        }

        public void wrap_test_11099(short[] p0, int p1, int p2)
        {
            ShortBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_11100(int p0)
        {
            ShortBuffer.allocate(p0);
        }
    }
}