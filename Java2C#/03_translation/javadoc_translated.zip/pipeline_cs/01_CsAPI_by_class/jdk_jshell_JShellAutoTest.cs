namespace Generated.Test
{
    public class jdk_jshell_JShellAutoTest
    {
        public void builder_test_6941()
        {
            JShell.builder();
        }

        public void create_test_6942()
        {
            JShell.create();
        }
    }

    public class JShell
    {
        public static Builder builder()
        {
            return new Builder();
        }

        public static JShell create()
        {
            return new JShell();
        }

        public class Builder
        {
        }
    }
}