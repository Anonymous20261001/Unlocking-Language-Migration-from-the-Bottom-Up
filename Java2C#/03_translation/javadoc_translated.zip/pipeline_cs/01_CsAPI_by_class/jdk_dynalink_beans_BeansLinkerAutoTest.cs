using System;
using System.Collections.Generic;
using System.Reflection;

namespace Generated.Test
{
    public class BeansLinker
    {
        public BeansLinker()
        {
        }

        public object getLinkerForClass(Type p0)
        {
            return null;
        }

        public static bool isDynamicMethod(object p0)
        {
            return p0 != null && p0.GetType().Name == "DynamicMethod";
        }

        public static object getConstructorMethod(Type p0, string p1)
        {
            return null;
        }

        public static ISet<string> getReadableStaticPropertyNames(Type p0)
        {
            return GetPropertyNames(p0, true, true);
        }

        public static ISet<string> getWritableStaticPropertyNames(Type p0)
        {
            return GetPropertyNames(p0, true, false);
        }

        public static ISet<string> getStaticMethodNames(Type p0)
        {
            return GetMethodNames(p0, true);
        }

        public static bool isDynamicConstructor(object p0)
        {
            return p0 != null && p0.GetType().Name == "DynamicConstructor";
        }

        public static ISet<string> getReadableInstancePropertyNames(Type p0)
        {
            return GetPropertyNames(p0, false, true);
        }

        public static ISet<string> getWritableInstancePropertyNames(Type p0)
        {
            return GetPropertyNames(p0, false, false);
        }

        public static ISet<string> getInstanceMethodNames(Type p0)
        {
            return GetMethodNames(p0, false);
        }

        private static ISet<string> GetPropertyNames(Type type, bool isStatic, bool readable)
        {
            var names = new HashSet<string>();
            if (type == null)
            {
                return names;
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.FlattenHierarchy;
            flags |= isStatic ? BindingFlags.Static : BindingFlags.Instance;

            foreach (var prop in type.GetProperties(flags))
            {
                if (readable && prop.CanRead)
                {
                    names.Add(prop.Name);
                }

                if (!readable && prop.CanWrite)
                {
                    names.Add(prop.Name);
                }
            }

            foreach (var field in type.GetFields(flags))
            {
                bool include = readable || (!field.IsInitOnly && !field.IsLiteral);
                if (include)
                {
                    names.Add(field.Name);
                }
            }

            return names;
        }

        private static ISet<string> GetMethodNames(Type type, bool isStatic)
        {
            var names = new HashSet<string>();
            if (type == null)
            {
                return names;
            }

            BindingFlags flags = BindingFlags.Public;
            flags |= isStatic ? (BindingFlags.Static | BindingFlags.FlattenHierarchy) : BindingFlags.Instance;

            foreach (var method in type.GetMethods(flags))
            {
                if (!method.IsSpecialName)
                {
                    names.Add(method.Name);
                }
            }

            return names;
        }
    }

    public class jdk_dynalink_beans_BeansLinkerAutoTest
    {
        public void getLinkerForClass_test_1576(Type p0)
        {
            BeansLinker instance = new BeansLinker();
            instance.getLinkerForClass(p0);
        }

        public void isDynamicMethod_test_1577(object p0)
        {
            BeansLinker.isDynamicMethod(p0);
        }

        public void getConstructorMethod_test_1578(Type p0, string p1)
        {
            BeansLinker.getConstructorMethod(p0, p1);
        }

        public void getReadableStaticPropertyNames_test_1579(Type p0)
        {
            BeansLinker.getReadableStaticPropertyNames(p0);
        }

        public void getWritableStaticPropertyNames_test_1580(Type p0)
        {
            BeansLinker.getWritableStaticPropertyNames(p0);
        }

        public void getStaticMethodNames_test_1581(Type p0)
        {
            BeansLinker.getStaticMethodNames(p0);
        }

        public void isDynamicConstructor_test_1582(object p0)
        {
            BeansLinker.isDynamicConstructor(p0);
        }

        public void getReadableInstancePropertyNames_test_1583(Type p0)
        {
            BeansLinker.getReadableInstancePropertyNames(p0);
        }

        public void getWritableInstancePropertyNames_test_1584(Type p0)
        {
            BeansLinker.getWritableInstancePropertyNames(p0);
        }

        public void getInstanceMethodNames_test_1585(Type p0)
        {
            BeansLinker.getInstanceMethodNames(p0);
        }
    }
}