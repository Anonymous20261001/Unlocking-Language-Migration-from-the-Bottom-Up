using System;

namespace Generated.Test
{
    public interface CharSequence
    {
        int Length { get; }
        char CharAt(int index);
        CharSequence SubSequence(int start, int end);
        string ToString();
    }

    public sealed class StringCharSequence : CharSequence
    {
        private readonly string _value;

        public StringCharSequence(string value)
        {
            _value = value ?? string.Empty;
        }

        public int Length
        {
            get { return _value.Length; }
        }

        public char CharAt(int index)
        {
            return _value[index];
        }

        public CharSequence SubSequence(int start, int end)
        {
            if (start < 0 || end > _value.Length || start > end)
                throw new ArgumentOutOfRangeException();

            return new StringCharSequence(_value.Substring(start, end - start));
        }

        public override string ToString()
        {
            return _value;
        }
    }

    public static class Normalizer
    {
        public enum Form
        {
            NFD,
            NFC,
            NFKD,
            NFKC
        }

        public static string normalize(CharSequence src, Form form)
        {
            string s = ToString(src);
            return s.Normalize(ToNormalizationForm(form));
        }

        public static bool isNormalized(CharSequence src, Form form)
        {
            string s = ToString(src);
            return s.IsNormalized(ToNormalizationForm(form));
        }

        private static string ToString(CharSequence src)
        {
            if (src == null)
                return null;

            return src.ToString();
        }

        private static System.Text.NormalizationForm ToNormalizationForm(Form form)
        {
            switch (form)
            {
                case Form.NFD:
                    return System.Text.NormalizationForm.FormD;
                case Form.NFC:
                    return System.Text.NormalizationForm.FormC;
                case Form.NFKD:
                    return System.Text.NormalizationForm.FormKD;
                case Form.NFKC:
                    return System.Text.NormalizationForm.FormKC;
                default:
                    throw new ArgumentOutOfRangeException("form");
            }
        }
    }

    public class java_text_NormalizerAutoTest
    {
        public void normalize_test_9529(CharSequence p0, Normalizer.Form p1)
        {
            Normalizer.normalize(p0, p1);
        }

        public void isNormalized_test_9530(CharSequence p0, Normalizer.Form p1)
        {
            Normalizer.isNormalized(p0, p1);
        }
    }
}