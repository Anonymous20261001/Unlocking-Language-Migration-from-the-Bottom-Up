using System;

namespace Generated.Test
{
    public class Key
    {
    }

    public class KeySelector
    {
        public static KeySelector singletonKeySelector(Key key)
        {
            return new KeySelector();
        }
    }

    public class javax_xml_crypto_KeySelectorAutoTest
    {
        public void singletonKeySelector_test_7631(Key p0)
        {
            KeySelector.singletonKeySelector(p0);
        }
    }
}