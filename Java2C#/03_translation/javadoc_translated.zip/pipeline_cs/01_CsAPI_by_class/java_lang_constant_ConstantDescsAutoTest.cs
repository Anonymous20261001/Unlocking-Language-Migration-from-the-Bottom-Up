```csharp
using System;

namespace Generated.Test
{
    public interface ClassDesc
    {
        string DescriptorString { get; }
    }

    public class DirectMethodHandleDesc
    {
        public ClassDesc Owner { get; }
        public string Name { get; }
        public ClassDesc ReturnType { get; }
        public ClassDesc[] BootstrapArgs { get; }

        public DirectMethodHandleDesc(ClassDesc owner, string name, ClassDesc returnType, ClassDesc[] bootstrapArgs)
        {
            Owner = owner;
            Name = name;
            ReturnType = returnType;
            BootstrapArgs = bootstrapArgs;
        }
    }

    public static class ConstantDescs
    {
        public static DirectMethodHandleDesc ofConstantBootstrap(ClassDesc owner, string name, ClassDesc returnType, ClassDesc[] bootstrapArgs)
        {
            return new DirectMethodHandleDesc(owner, name, returnType, bootstrapArgs);
        }

        public static DirectMethodHandleDesc ofCallsiteBootstrap(ClassDesc owner, string name, ClassDesc returnType, ClassDesc[] bootstrapArgs)
        {
            return new DirectMethodHandleDesc(owner, name, returnType, bootstrapArgs);
        }
    }

    public class java_lang_constant_ConstantDescsAutoTest
    {
        public void ofConstantBootstrap_test_2932(ClassDesc p0, string p1, ClassDesc p2, ClassDesc[] p3)
        {
            ConstantDescs.ofConstantBootstrap(p0, p1, p2, p3);
        }

        public void ofCallsiteBootstrap_test_2933(ClassDesc p0, string p1, ClassDesc p2, ClassDesc[] p3)
        {
            ConstantDescs.ofCallsiteBootstrap(p0, p1, p2, p3);
        }
    }
}
```