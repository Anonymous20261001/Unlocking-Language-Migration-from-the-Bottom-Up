using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Generated.Test
{
    public class CharSequence
    {
        private readonly string _value;

        public CharSequence(string value)
        {
            _value = value ?? throw new ArgumentNullException("value");
        }

        public int Length
        {
            get { return _value.Length; }
        }

        public char CharAt(int index)
        {
            return _value[index];
        }

        public CharSequence SubSequence(int start, int end)
        {
            return new CharSequence(_value.Substring(start, end - start));
        }

        public override string ToString()
        {
            return _value;
        }

        public static implicit operator CharSequence(string s)
        {
            return new CharSequence(s);
        }

        public static implicit operator string(CharSequence cs)
        {
            return cs == null ? null : cs._value;
        }
    }

    public class Pattern
    {
        private readonly Regex _regex;

        private Pattern(Regex regex)
        {
            _regex = regex;
        }

        public static bool matches(string regex, CharSequence input)
        {
            if (regex == null)
                throw new ArgumentNullException("regex");
            if (input == null)
                throw new ArgumentNullException("input");

            string s = input.ToString();
            return Regex.IsMatch(s, "\\A(?:" + regex + ")\\z");
        }

        public static Pattern compile(string regex)
        {
            if (regex == null)
                throw new ArgumentNullException("regex");
            return new Pattern(new Regex(regex));
        }

        public static Pattern compile(string regex, int flags)
        {
            if (regex == null)
                throw new ArgumentNullException("regex");

            RegexOptions options = RegexOptions.None;
            if ((flags & 0x02) != 0)
                options |= RegexOptions.IgnoreCase;
            if ((flags & 0x08) != 0)
                options |= RegexOptions.Multiline;
            if ((flags & 0x20) != 0)
                options |= RegexOptions.Singleline;
            if ((flags & 0x04) != 0)
                options |= RegexOptions.IgnorePatternWhitespace;
            if ((flags & 0x40) != 0)
                options |= RegexOptions.IgnoreCase;

            return new Pattern(new Regex(regex, options));
        }

        public static string quote(string s)
        {
            if (s == null)
                throw new ArgumentNullException("s");

            int slashEIndex = s.IndexOf("\\E", StringComparison.Ordinal);
            if (slashEIndex == -1)
                return "\\Q" + s + "\\E";

            StringBuilder sb = new StringBuilder();
            int last = 0;
            while (slashEIndex != -1)
            {
                sb.Append("\\Q");
                sb.Append(s, last, slashEIndex - last);
                sb.Append("\\E\\\\E\\Q");
                last = slashEIndex + 2;
                slashEIndex = s.IndexOf("\\E", last, StringComparison.Ordinal);
            }

            sb.Append("\\Q");
            sb.Append(s, last, s.Length - last);
            sb.Append("\\E");
            return sb.ToString();
        }
    }

    public class java_util_regex_PatternAutoTest
    {
        public void matches_test_9865(string p0, CharSequence p1)
        {
            Pattern.matches(p0, p1);
        }

        public void compile_test_9866(string p0)
        {
            Pattern.compile(p0);
        }

        public void compile_test_9867(string p0, int p1)
        {
            Pattern.compile(p0, p1);
        }

        public void quote_test_9868(string p0)
        {
            Pattern.quote(p0);
        }
    }
}