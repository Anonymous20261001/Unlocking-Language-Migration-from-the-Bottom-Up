namespace Generated.Test
{
    public interface ConstantDesc
    {
    }

    public interface MethodTypeDesc : ConstantDesc
    {
    }

    public interface MethodHandleDesc : ConstantDesc
    {
    }

    public interface DirectMethodHandleDesc : MethodHandleDesc
    {
    }

    public class DynamicCallSiteDesc : ConstantDesc
    {
        private readonly DirectMethodHandleDesc bootstrapMethod;
        private readonly string invocationName;
        private readonly MethodTypeDesc invocationType;
        private readonly ConstantDesc[] bootstrapArgs;

        private DynamicCallSiteDesc(DirectMethodHandleDesc bootstrapMethod, string invocationName, MethodTypeDesc invocationType, ConstantDesc[] bootstrapArgs)
        {
            this.bootstrapMethod = bootstrapMethod;
            this.invocationName = invocationName;
            this.invocationType = invocationType;
            this.bootstrapArgs = bootstrapArgs;
        }

        public DirectMethodHandleDesc BootstrapMethod
        {
            get { return bootstrapMethod; }
        }

        public string InvocationName
        {
            get { return invocationName; }
        }

        public MethodTypeDesc InvocationType
        {
            get { return invocationType; }
        }

        public ConstantDesc[] BootstrapArgs
        {
            get { return bootstrapArgs; }
        }

        public static DynamicCallSiteDesc of(DirectMethodHandleDesc p0, string p1, MethodTypeDesc p2, ConstantDesc[] p3)
        {
            return new DynamicCallSiteDesc(p0, p1, p2, p3);
        }

        public static DynamicCallSiteDesc of(DirectMethodHandleDesc p0, MethodTypeDesc p1)
        {
            return new DynamicCallSiteDesc(p0, "_", p1, new ConstantDesc[0]);
        }

        public static DynamicCallSiteDesc of(DirectMethodHandleDesc p0, string p1, MethodTypeDesc p2)
        {
            return new DynamicCallSiteDesc(p0, p1, p2, new ConstantDesc[0]);
        }
    }

    public class java_lang_constant_DynamicCallSiteDescAutoTest
    {
        public void of_test_4417(DirectMethodHandleDesc p0, string p1, MethodTypeDesc p2, ConstantDesc[] p3)
        {
            DynamicCallSiteDesc.of(p0, p1, p2, p3);
        }

        public void of_test_4418(DirectMethodHandleDesc p0, MethodTypeDesc p1)
        {
            DynamicCallSiteDesc.of(p0, p1);
        }

        public void of_test_4419(DirectMethodHandleDesc p0, string p1, MethodTypeDesc p2)
        {
            DynamicCallSiteDesc.of(p0, p1, p2);
        }
    }
}