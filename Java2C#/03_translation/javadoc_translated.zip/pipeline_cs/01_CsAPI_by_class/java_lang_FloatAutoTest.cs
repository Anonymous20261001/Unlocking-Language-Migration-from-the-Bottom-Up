```csharp
using System;
using System.Globalization;

namespace Generated.Test
{
    public class MethodHandles
    {
        public class Lookup
        {
        }
    }

    public class Optional<T>
    {
        private readonly T value;

        private Optional(T value)
        {
            this.value = value;
        }

        public static Optional<T> Of(T value)
        {
            return new Optional<T>(value);
        }

        public T Get()
        {
            return value;
        }
    }

    public sealed class Float
    {
        private readonly float value;

        public Float(float value)
        {
            this.value = value;
        }

        public Float(string s)
        {
            this.value = parseFloat(s);
        }

        private static int floatToRawIntBits(float value)
        {
            byte[] bytes = BitConverter.GetBytes(value);
            return BitConverter.ToInt32(bytes, 0);
        }

        private static float intBitsToFloat(int bits)
        {
            byte[] bytes = BitConverter.GetBytes(bits);
            return BitConverter.ToSingle(bytes, 0);
        }

        public static float min(float a, float b)
        {
            if (float.IsNaN(a) || float.IsNaN(b))
                return float.NaN;

            if (a == b)
            {
                if (a == 0.0f)
                {
                    if (floatToRawIntBits(a) < 0 || floatToRawIntBits(b) < 0)
                        return -0.0f;
                    return 0.0f;
                }
                return a;
            }

            return a < b ? a : b;
        }

        public static float max(float a, float b)
        {
            if (float.IsNaN(a) || float.IsNaN(b))
                return float.NaN;

            if (a == b)
            {
                if (a == 0.0f)
                {
                    if (floatToRawIntBits(a) >= 0 || floatToRawIntBits(b) >= 0)
                        return 0.0f;
                    return -0.0f;
                }
                return a;
            }

            return a > b ? a : b;
        }

        public static bool isInfinite(float v)
        {
            return float.IsInfinity(v);
        }

        public bool isInfinite()
        {
            return float.IsInfinity(value);
        }

        public static bool isFinite(float f)
        {
            return !float.IsNaN(f) && !float.IsInfinity(f);
        }

        public static int floatToRawIntBits(float value)
        {
            return floatToRawIntBits(value);
        }

        public static int floatToIntBits(float value)
        {
            if (float.IsNaN(value))
                return 0x7fc00000;
            return floatToRawIntBits(value);
        }

        public static float intBitsToFloat(int bits)
        {
            return intBitsToFloat(bits);
        }

        public static float float16ToFloat(short halfBits)
        {
            ushort h = (ushort)halfBits;
            uint sign = (uint)((h >> 15) & 0x1);
            uint exp = (uint)((h >> 10) & 0x1f);
            uint mant = (uint)(h & 0x3ff);

            if (exp == 0)
            {
                if (mant == 0)
                    return sign == 0 ? 0.0f : -0.0f;
                else
                {
                    float val = (float)(mant * Math.Pow(2, -24));
                    return sign == 0 ? val : -val;
                }
            }
            else if (exp == 0x1f)
            {
                if (mant == 0)
                    return sign == 0 ? float.PositiveInfinity : float.NegativeInfinity;
                else
                    return float.NaN;
            }
            else
            {
                int e = (int)exp - 15 + 127;
                int bits = (int)((sign << 31) | ((uint)e << 23) | (mant << 13));
                return intBitsToFloat(bits);
            }
        }

        public static short floatToFloat16(float f)
        {
            int bits = floatToRawIntBits(f);
            int sign = (bits >> 16) & 0x8000;
            int exp = (bits >> 23) & 0xff;
            int mant = bits & 0x7fffff;

            if (exp == 0xff)
            {
                if (mant != 0)
                    return (short)(sign | 0x7e00 | (mant >> 13));
                return (short)(sign | 0x7c00);
            }

            if (exp == 0)
            {
                return (short)sign;
            }

            int halfExp = exp - 127 + 15;

            if (halfExp >= 0x1f)
            {
                return (short)(sign | 0x7c00);
            }

            if (halfExp <= 0)
            {
                if (halfExp < -10)
                    return (short)sign;

                float abs = Math.Abs(f);
                double units = abs / Math.Pow(2, -24);
                int m = (int)Math.Round(units, MidpointRounding.ToEven);

                if (m == 0x400)
                    return (short)(sign | 0x0400);
                if (m == 0x400) m = 0x3ff;
                return (short)(sign | m);
            }

            int halfMant = mant >> 13;
            int rem = mant & 0x1fff;
            int half = sign | (halfExp << 10) | halfMant;

            if (rem > 0x1000 || (rem == 0x1000 && (half & 1) == 1))
                half++;

            return (short)half;
        }

        public int compareTo(Float anotherFloat)
        {
            return compare(value, anotherFloat.value);
        }

        public static int compare(float f1, float f2)
        {
            if (f1 < f2) return -1;
            if (f1 > f2) return 1;

            int thisBits = floatToIntBits(f1);
            int anotherBits = floatToIntBits(f2);

            return thisBits < anotherBits ? -1 : (thisBits > anotherBits ? 1 : 0);
        }

        public byte byteValue()
        {
            return (byte)intValue();
        }

        public short shortValue()
        {
            return (short)intValue();
        }

        public int intValue()
        {
            if (float.IsNaN(value))
                return 0;
            if (value >= int.MaxValue)
                return int.MaxValue;
            if (value <= int.MinValue)
                return int.MinValue;
            return (int)value;
        }

        public long longValue()
        {
            if (float.IsNaN(value))
                return 0L;
            if (value >= long.MaxValue)
                return long.MaxValue;
            if (value <= long.MinValue)
                return long.MinValue;
            return (long)value;
        }

        public float floatValue()
        {
            return value;
        }

        public double doubleValue()
        {
            return (double)value;
        }

        public static Float valueOf(float f)
        {
            return new Float(f);
        }

        public static Float valueOf(string s)
        {
            return new Float(parseFloat(s));
        }

        public static string toHexString(float f)
        {
            if (float.IsNaN(f))
                return "NaN";
            if (float.IsPositiveInfinity(f))
                return "Infinity";
            if (float.IsNegativeInfinity(f))
                return "-Infinity";

            int bits = floatToRawIntBits(f);
            string sign = (bits >> 31) != 0 ? "-" : "";
            int exp = ((bits >> 23) & 0xff) - 127;
            int mant = bits & 0x7fffff;

            if (exp == -127 && mant == 0)
                return sign + "0x0.0p0";

            if (exp == -127)
            {
                return sign + "0x0." + mant.ToString("x") + "p-126";
            }

            return sign + "0x1." + mant.ToString("x") + "p" + exp.ToString(CultureInfo.InvariantCulture);
        }

        public Float resolveConstantDesc(MethodHandles.Lookup p0)
        {
            return this;
        }

        public Optional<Float> describeConstable()
        {
            return Optional<Float>.Of(this);
        }

        public static bool isNaN(float v)
        {
            return float.IsNaN(v);
        }

        public bool isNaN()
        {
            return float.IsNaN(value);
        }

        public static float sum(float a, float b)
        {
            return a + b;
        }

        public static float parseFloat(string s)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));

            string t = s.Trim();
            if (t.Equals("NaN", StringComparison.OrdinalIgnoreCase))
                return float.NaN;
            if (t.Equals("Infinity", StringComparison.OrdinalIgnoreCase))
                return float.PositiveInfinity;
            if (t.Equals("-Infinity", StringComparison.OrdinalIgnoreCase))
                return float.NegativeInfinity;

            return float.Parse(s, CultureInfo.InvariantCulture);
        }
    }

    public class java_lang_FloatAutoTest
    {
        public void min_test_4825(float p0, float p1)
        {
            Float.min(p0, p1);
        }

        public void max_test_4826(float p0, float p1)
        {
            Float.max(p0, p1);
        }

        public void isInfinite_test_4827(float p0)
        {
            Float.isInfinite(p0);
        }

        public void isInfinite_test_4828(string c0)
        {
            Float instance = new Float(c0);
            instance.isInfinite();
        }

        public void isFinite_test_4829(float p0)
        {
            Float.isFinite(p0);
        }

        public void floatToRawIntBits_test_4830(float p0)
        {
            Float.floatToRawIntBits(p0);
        }

        public void floatToIntBits_test_4831(float p0)
        {
            Float.floatToIntBits(p0);
        }

        public void intBitsToFloat_test_4832(int p0)
        {
            Float.intBitsToFloat(p0);
        }

        public void float16ToFloat_test_4833(short p0)
        {
            Float.float16ToFloat(p0);
        }

        public void floatToFloat16_test_4834(float p0)
        {
            Float.floatToFloat16(p0);
        }

        public void compareTo_test_4835(Float p0, string c0)
        {
            Float instance = new Float(c0);
            instance.compareTo(p0);
        }

        public void compare_test_4836(float p0, float p1)
        {
            Float.compare(p0, p1);
        }

        public void byteValue_test_4837(string c0)
        {
            Float instance = new Float(c0);
            instance.byteValue();
        }

        public void shortValue_test_4838(string c0)
        {
            Float instance = new Float(c0);
            instance.shortValue();
        }

        public void intValue_test_4839(string c0)
        {
            Float instance = new Float(c0);
            instance.intValue();
        }

        public void longValue_test_4840(string c0)
        {
            Float instance = new Float(c0);
            instance.longValue();
        }

        public void floatValue_test_4841(string c0)
        {
            Float instance = new Float(c0);
            instance.floatValue();
        }

        public void doubleValue_test_4842(string c0)
        {
            Float instance = new Float(c0);
            instance.doubleValue();
        }

        public void valueOf_test_4843(float p0)
        {
            Float.valueOf(p0);
        }

        public void valueOf_test_4844(string p0)
        {
            Float.valueOf(p0);
        }

        public void toHexString_test_4845(float p0)
        {
            Float.toHexString(p0);
        }

        public void resolveConstantDesc_test_4846(MethodHandles.Lookup p0, string c0)
        {
            Float instance = new Float(c0);
            instance.resolveConstantDesc(p0);
        }

        public void describeConstable_test_4847(string c0)
        {
            Float instance = new Float(c0);
            instance.describeConstable();
        }

        public void isNaN_test_4848(float p0)
        {
            Float.isNaN(p0);
        }

        public void isNaN_test_4849(string c0)
        {
            Float instance = new Float(c0);
            instance.isNaN();
        }

        public void sum_test_4850(float p0, float p1)
        {
            Float.sum(p0, p1);
        }

        public void parseFloat_test_4851(string p0)
        {
            Float.parseFloat(p0);
        }
    }
}
```