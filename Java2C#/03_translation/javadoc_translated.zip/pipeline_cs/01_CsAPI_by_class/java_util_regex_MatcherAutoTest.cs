namespace Generated.Test
{
    public static class Matcher
    {
        public static string quoteReplacement(string s)
        {
            if (s.IndexOf('\\') == -1 && s.IndexOf('$') == -1)
                return s;

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (char c in s)
            {
                if (c == '\\' || c == '$')
                    sb.Append('\\');
                sb.Append(c);
            }
            return sb.ToString();
        }
    }

    public class java_util_regex_MatcherAutoTest
    {
        public void quoteReplacement_test_8295(string p0)
        {
            Matcher.quoteReplacement(p0);
        }
    }
}