using System;

namespace Generated.Test
{
    public class java_time_chrono_MinguoDateAutoTest
    {
        public void of_test_8947(int p0, int p1, int p2)
        {
            MinguoDate.of(p0, p1, p2);
        }

        public void from_test_8948(TemporalAccessor p0)
        {
            MinguoDate.from(p0);
        }

        public void now_test_8949()
        {
            MinguoDate.now();
        }

        public void now_test_8950(ZoneId p0)
        {
            MinguoDate.now(p0);
        }

        public void now_test_8951(Clock p0)
        {
            MinguoDate.now(p0);
        }
    }

    public interface TemporalAccessor
    {
        DateTime ToDateTime();
    }

    public class MinguoDate : IEquatable<MinguoDate>
    {
        private readonly DateTime _gregorianDate;

        public MinguoDate(DateTime gregorianDate)
        {
            _gregorianDate = gregorianDate.Date;
        }

        public static MinguoDate of(int year, int month, int day)
        {
            try
            {
                return new MinguoDate(new DateTime(year + 1911, month, day));
            }
            catch (ArgumentOutOfRangeException ex)
            {
                throw new ArgumentException("Invalid Minguo date", ex);
            }
        }

        public static MinguoDate from(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return new MinguoDate(temporal.ToDateTime());
        }

        public static MinguoDate now()
        {
            return new MinguoDate(DateTime.Now);
        }

        public static MinguoDate now(ZoneId zone)
        {
            if (zone == null)
                throw new ArgumentNullException(nameof(zone));
            DateTime local = TimeZoneInfo.ConvertTime(DateTime.UtcNow, zone.ToTimeZoneInfo());
            return new MinguoDate(local);
        }

        public static MinguoDate now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            return clock.GetMinguoDate();
        }

        public int Year => _gregorianDate.Year - 1911;
        public int Month => _gregorianDate.Month;
        public int Day => _gregorianDate.Day;

        public bool Equals(MinguoDate other)
        {
            if (other is null) return false;
            return _gregorianDate == other._gregorianDate;
        }

        public override bool Equals(object obj) => Equals(obj as MinguoDate);

        public override int GetHashCode() => _gregorianDate.GetHashCode();

        public override string ToString() => $"{Year}-{Month:D2}-{Day:D2}";
    }

    public class ZoneId
    {
        private readonly TimeZoneInfo _timeZoneInfo;
        public string Id { get; }

        public ZoneId(string id)
        {
            Id = id ?? "UTC";
            try
            {
                _timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(Id);
            }
            catch (TimeZoneNotFoundException)
            {
                _timeZoneInfo = TimeZoneInfo.Utc;
            }
            catch (InvalidTimeZoneException)
            {
                _timeZoneInfo = TimeZoneInfo.Utc;
            }
        }

        public ZoneId(TimeZoneInfo timeZoneInfo)
        {
            _timeZoneInfo = timeZoneInfo ?? TimeZoneInfo.Utc;
            Id = _timeZoneInfo.Id;
        }

        public static ZoneId of(string id) => new ZoneId(id);
        public static ZoneId SystemDefault() => new ZoneId(TimeZoneInfo.Local);

        public TimeZoneInfo ToTimeZoneInfo() => _timeZoneInfo;
    }

    public class Clock
    {
        public virtual DateTime GetCurrentDateTime() => DateTime.Now;

        public MinguoDate GetMinguoDate() => new MinguoDate(GetCurrentDateTime());
    }
}