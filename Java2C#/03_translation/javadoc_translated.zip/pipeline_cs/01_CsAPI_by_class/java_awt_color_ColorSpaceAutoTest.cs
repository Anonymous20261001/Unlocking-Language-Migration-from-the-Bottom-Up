```csharp
using System;

namespace Generated.Test
{
    public class java_awt_color_ColorSpaceAutoTest
    {
        public void getInstance_test_2503(int p0)
        {
            ColorSpace.getInstance(p0);
        }
    }

    public class ColorSpace
    {
        public const int CS_sRGB = 1000;
        public const int CS_LINEAR_RGB = 1004;
        public const int CS_CIEXYZ = 1001;
        public const int CS_PYCC = 1002;
        public const int CS_GRAY = 1003;

        private readonly int type;

        private ColorSpace(int type)
        {
            this.type = type;
        }

        public static ColorSpace getInstance(int colorSpace)
        {
            switch (colorSpace)
            {
                case CS_sRGB:
                case CS_LINEAR_RGB:
                case CS_CIEXYZ:
                case CS_PYCC:
                case CS_GRAY:
                    return new ColorSpace(colorSpace);
                default:
                    throw new ArgumentException("Not a predefined color space");
            }
        }
    }
}
```