using System.Collections.Generic;

namespace Generated.Test
{
    public abstract class FileSystemProvider
    {
        protected FileSystemProvider() { }

        public static List<FileSystemProvider> installedProviders()
        {
            return new List<FileSystemProvider>();
        }
    }

    public class java_nio_file_spi_FileSystemProviderAutoTest
    {
        public void installedProviders_test_4778()
        {
            FileSystemProvider.installedProviders();
        }
    }
}