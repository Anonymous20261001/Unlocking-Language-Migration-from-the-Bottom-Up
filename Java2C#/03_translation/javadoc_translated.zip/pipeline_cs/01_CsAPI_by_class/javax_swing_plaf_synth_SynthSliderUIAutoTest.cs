namespace javax.swing
{
    public class JComponent
    {
    }
}

namespace javax.swing.plaf.synth
{
    public class SynthSliderUI
    {
        public static SynthSliderUI createUI(javax.swing.JComponent c)
        {
            return new SynthSliderUI();
        }
    }
}

namespace Generated.Test
{
    using javax.swing;
    using javax.swing.plaf.synth;

    public class javax_swing_plaf_synth_SynthSliderUIAutoTest
    {
        public void createUI_test_12334(JComponent p0)
        {
            SynthSliderUI.createUI(p0);
        }
    }
}