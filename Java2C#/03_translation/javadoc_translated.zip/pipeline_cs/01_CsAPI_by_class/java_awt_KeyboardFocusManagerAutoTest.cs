namespace Generated.Test
{
    public abstract class KeyboardFocusManager
    {
        private sealed class DefaultKeyboardFocusManager : KeyboardFocusManager
        {
        }

        private static KeyboardFocusManager current = new DefaultKeyboardFocusManager();

        protected KeyboardFocusManager()
        {
        }

        public static KeyboardFocusManager getCurrentKeyboardFocusManager()
        {
            return current;
        }

        public static void setCurrentKeyboardFocusManager(KeyboardFocusManager newManager)
        {
            current = newManager;
        }
    }

    public class java_awt_KeyboardFocusManagerAutoTest
    {
        public void setCurrentKeyboardFocusManager_test_7611(KeyboardFocusManager p0)
        {
            KeyboardFocusManager.setCurrentKeyboardFocusManager(p0);
        }

        public void getCurrentKeyboardFocusManager_test_7612()
        {
            KeyboardFocusManager.getCurrentKeyboardFocusManager();
        }
    }
}