using System;

namespace Generated.Test
{
    public interface AttributeSet
    {
        object GetAttribute(object key);
        bool IsDefined(object key);
        int GetAttributeCount();
        AttributeSet GetResolveParent();
    }

    public interface MutableAttributeSet : AttributeSet
    {
        void AddAttribute(object key, object value);
        void AddAttributes(AttributeSet attributes);
        void RemoveAttribute(object key);
    }

    public class TabSet
    {
    }

    public interface Icon
    {
        int GetIconWidth();
        int GetIconHeight();
        void PaintIcon(Component c, object g, int x, int y);
    }

    public class Color
    {
        public int R { get; private set; }
        public int G { get; private set; }
        public int B { get; private set; }

        public Color(int r, int g, int b)
        {
            R = r;
            G = g;
            B = b;
        }
    }

    public class Component
    {
    }

    public static class StyleConstants
    {
        private static readonly object FontFamilyKey = new object();
        private static readonly object FontSizeKey = new object();
        private static readonly object BoldKey = new object();
        private static readonly object ItalicKey = new object();
        private static readonly object UnderlineKey = new object();
        private static readonly object StrikeThroughKey = new object();
        private static readonly object SubscriptKey = new object();
        private static readonly object SuperscriptKey = new object();
        private static readonly object FirstLineIndentKey = new object();
        private static readonly object RightIndentKey = new object();
        private static readonly object LeftIndentKey = new object();
        private static readonly object LineSpacingKey = new object();
        private static readonly object SpaceAboveKey = new object();
        private static readonly object SpaceBelowKey = new object();
        private static readonly object AlignmentKey = new object();
        private static readonly object TabSetKey = new object();
        private static readonly object ForegroundKey = new object();
        private static readonly object BackgroundKey = new object();
        private static readonly object ComponentKey = new object();
        private static readonly object IconKey = new object();
        private static readonly object BidiLevelKey = new object();

        public static void SetFontFamily(MutableAttributeSet a, string family)
        {
            a.AddAttribute(FontFamilyKey, family);
        }

        public static void SetFontSize(MutableAttributeSet a, int size)
        {
            a.AddAttribute(FontSizeKey, size);
        }

        public static bool IsBold(AttributeSet a)
        {
            return GetBoolean(a, BoldKey);
        }

        public static void SetBold(MutableAttributeSet a, bool bold)
        {
            a.AddAttribute(BoldKey, bold);
        }

        public static bool IsItalic(AttributeSet a)
        {
            return GetBoolean(a, ItalicKey);
        }

        public static void SetItalic(MutableAttributeSet a, bool italic)
        {
            a.AddAttribute(ItalicKey, italic);
        }

        public static void SetBidiLevel(MutableAttributeSet a, int level)
        {
            a.AddAttribute(BidiLevelKey, level);
        }

        public static bool IsUnderline(AttributeSet a)
        {
            return GetBoolean(a, UnderlineKey);
        }

        public static bool IsStrikeThrough(AttributeSet a)
        {
            return GetBoolean(a, StrikeThroughKey);
        }

        public static void SetStrikeThrough(MutableAttributeSet a, bool strikeThrough)
        {
            a.AddAttribute(StrikeThroughKey, strikeThrough);
        }

        public static void SetSubscript(MutableAttributeSet a, bool subscript)
        {
            a.AddAttribute(SubscriptKey, subscript);
        }

        public static float GetFirstLineIndent(AttributeSet a)
        {
            return GetFloat(a, FirstLineIndentKey, 0f);
        }

        public static void SetFirstLineIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(FirstLineIndentKey, indent);
        }

        public static void SetRightIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(RightIndentKey, indent);
        }

        public static void SetLeftIndent(MutableAttributeSet a, float indent)
        {
            a.AddAttribute(LeftIndentKey, indent);
        }

        public static float GetLineSpacing(AttributeSet a)
        {
            return GetFloat(a, LineSpacingKey, 0f);
        }

        public static void SetLineSpacing(MutableAttributeSet a, float spacing)
        {
            a.AddAttribute(LineSpacingKey, spacing);
        }

        public static void SetSpaceAbove(MutableAttributeSet a, float space)
        {
            a.AddAttribute(SpaceAboveKey, space);
        }

        public static void SetSpaceBelow(MutableAttributeSet a, float space)
        {
            a.AddAttribute(SpaceBelowKey, space);
        }

        public static void SetAlignment(MutableAttributeSet a, int alignment)
        {
            a.AddAttribute(AlignmentKey, alignment);
        }

        public static TabSet GetTabSet(AttributeSet a)
        {
            return (TabSet)a.GetAttribute(TabSetKey);
        }

        public static void SetTabSet(MutableAttributeSet a, TabSet tabs)
        {
            a.AddAttribute(TabSetKey, tabs);
        }

        public static void SetSuperscript(MutableAttributeSet a, bool superscript)
        {
            a.AddAttribute(SuperscriptKey, superscript);
        }

        public static void SetUnderline(MutableAttributeSet a, bool underline)
        {
            a.AddAttribute(UnderlineKey, underline);
        }

        public static float GetSpaceAbove(AttributeSet a)
        {
            return GetFloat(a, SpaceAboveKey, 0f);
        }

        public static float GetLeftIndent(AttributeSet a)
        {
            return GetFloat(a, LeftIndentKey, 0f);
        }

        public static float GetSpaceBelow(AttributeSet a)
        {
            return GetFloat(a, SpaceBelowKey, 0f);
        }

        public static float GetRightIndent(AttributeSet a)
        {
            return GetFloat(a, RightIndentKey, 0f);
        }

        public static Color GetForeground(AttributeSet a)
        {
            return (Color)a.GetAttribute(ForegroundKey);
        }

        public static void SetForeground(MutableAttributeSet a, Color fg)
        {
            a.AddAttribute(ForegroundKey, fg);
        }

        public static Color GetBackground(AttributeSet a)
        {
            return (Color)a.GetAttribute(BackgroundKey);
        }

        public static void SetBackground(MutableAttributeSet a, Color bg)
        {
            a.AddAttribute(BackgroundKey, bg);
        }

        public static void SetComponent(MutableAttributeSet a, Component c)
        {
            a.AddAttribute(ComponentKey, c);
        }

        public static Icon GetIcon(AttributeSet a)
        {
            return (Icon)a.GetAttribute(IconKey);
        }

        public static void SetIcon(MutableAttributeSet a, Icon icon)
        {
            a.AddAttribute(IconKey, icon);
        }

        public static int GetBidiLevel(AttributeSet a)
        {
            return GetInt(a, BidiLevelKey, 0);
        }

        public static int GetAlignment(AttributeSet a)
        {
            return GetInt(a, AlignmentKey, 0);
        }

        public static string GetFontFamily(AttributeSet a)
        {
            return (string)a.GetAttribute(FontFamilyKey);
        }

        public static int GetFontSize(AttributeSet a)
        {
            return GetInt(a, FontSizeKey, 0);
        }

        public static bool IsSuperscript(AttributeSet a)
        {
            return GetBoolean(a, SuperscriptKey);
        }

        public static bool IsSubscript(AttributeSet a)
        {
            return GetBoolean(a, SubscriptKey);
        }

        public static Component GetComponent(AttributeSet a)
        {
            return (Component)a.GetAttribute(ComponentKey);
        }

        private static bool GetBoolean(AttributeSet a, object key)
        {
            object value = a.GetAttribute(key);
            return value is bool b && b;
        }

        private static float GetFloat(AttributeSet a, object key, float defaultValue)
        {
            object value = a.GetAttribute(key);
            if (value is float f) return f;
            if (value is int i) return (float)i;
            if (value is double d) return (float)d;
            return defaultValue;
        }

        private static int GetInt(AttributeSet a, object key, int defaultValue)
        {
            object value = a.GetAttribute(key);
            if (value is int i) return i;
            if (value is float f) return (int)f;
            if (value is double d) return (int)d;
            return defaultValue;
        }
    }

    public class javax_swing_text_StyleConstantsAutoTest
    {
        public void setFontFamily_test_11929(MutableAttributeSet p0, string p1)
        {
            StyleConstants.SetFontFamily(p0, p1);
        }

        public void setFontSize_test_11930(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetFontSize(p0, p1);
        }

        public void isBold_test_11931(AttributeSet p0)
        {
            StyleConstants.IsBold(p0);
        }

        public void setBold_test_11932(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetBold(p0, p1);
        }

        public void isItalic_test_11933(AttributeSet p0)
        {
            StyleConstants.IsItalic(p0);
        }

        public void setItalic_test_11934(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetItalic(p0, p1);
        }

        public void setBidiLevel_test_11935(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetBidiLevel(p0, p1);
        }

        public void isUnderline_test_11936(AttributeSet p0)
        {
            StyleConstants.IsUnderline(p0);
        }

        public void isStrikeThrough_test_11937(AttributeSet p0)
        {
            StyleConstants.IsStrikeThrough(p0);
        }

        public void setStrikeThrough_test_11938(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetStrikeThrough(p0, p1);
        }

        public void setSubscript_test_11939(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetSubscript(p0, p1);
        }

        public void getFirstLineIndent_test_11940(AttributeSet p0)
        {
            StyleConstants.GetFirstLineIndent(p0);
        }

        public void setFirstLineIndent_test_11941(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetFirstLineIndent(p0, p1);
        }

        public void setRightIndent_test_11942(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetRightIndent(p0, p1);
        }

        public void setLeftIndent_test_11943(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetLeftIndent(p0, p1);
        }

        public void getLineSpacing_test_11944(AttributeSet p0)
        {
            StyleConstants.GetLineSpacing(p0);
        }

        public void setLineSpacing_test_11945(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetLineSpacing(p0, p1);
        }

        public void setSpaceAbove_test_11946(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetSpaceAbove(p0, p1);
        }

        public void setSpaceBelow_test_11947(MutableAttributeSet p0, float p1)
        {
            StyleConstants.SetSpaceBelow(p0, p1);
        }

        public void setAlignment_test_11948(MutableAttributeSet p0, int p1)
        {
            StyleConstants.SetAlignment(p0, p1);
        }

        public void getTabSet_test_11949(AttributeSet p0)
        {
            StyleConstants.GetTabSet(p0);
        }

        public void setTabSet_test_11950(MutableAttributeSet p0, TabSet p1)
        {
            StyleConstants.SetTabSet(p0, p1);
        }

        public void setSuperscript_test_11951(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetSuperscript(p0, p1);
        }

        public void setUnderline_test_11952(MutableAttributeSet p0, bool p1)
        {
            StyleConstants.SetUnderline(p0, p1);
        }

        public void getSpaceAbove_test_11953(AttributeSet p0)
        {
            StyleConstants.GetSpaceAbove(p0);
        }

        public void getLeftIndent_test_11954(AttributeSet p0)
        {
            StyleConstants.GetLeftIndent(p0);
        }

        public void getSpaceBelow_test_11955(AttributeSet p0)
        {
            StyleConstants.GetSpaceBelow(p0);
        }

        public void getRightIndent_test_11956(AttributeSet p0)
        {
            StyleConstants.GetRightIndent(p0);
        }

        public void getForeground_test_11957(AttributeSet p0)
        {
            StyleConstants.GetForeground(p0);
        }

        public void setForeground_test_11958(MutableAttributeSet p0, Color p1)
        {
            StyleConstants.SetForeground(p0, p1);
        }

        public void getBackground_test_11959(AttributeSet p0)
        {
            StyleConstants.GetBackground(p0);
        }

        public void setBackground_test_11960(MutableAttributeSet p0, Color p1)
        {
            StyleConstants.SetBackground(p0, p1);
        }

        public void setComponent_test_11961(MutableAttributeSet p0, Component p1)
        {
            StyleConstants.SetComponent(p0, p1);
        }

        public void getIcon_test_11962(AttributeSet p0)
        {
            StyleConstants.GetIcon(p0);
        }

        public void setIcon_test_11963(MutableAttributeSet p0, Icon p1)
        {
            StyleConstants.SetIcon(p0, p1);
        }

        public void getBidiLevel_test_11964(AttributeSet p0)
        {
            StyleConstants.GetBidiLevel(p0);
        }

        public void getAlignment_test_11965(AttributeSet p0)
        {
            StyleConstants.GetAlignment(p0);
        }

        public void getFontFamily_test_11966(AttributeSet p0)
        {
            StyleConstants.GetFontFamily(p0);
        }

        public void getFontSize_test_11967(AttributeSet p0)
        {
            StyleConstants.GetFontSize(p0);
        }

        public void isSuperscript_test_11968(AttributeSet p0)
        {
            StyleConstants.IsSuperscript(p0);
        }

        public void isSubscript_test_11969(AttributeSet p0)
        {
            StyleConstants.IsSubscript(p0);
        }

        public void getComponent_test_11970(AttributeSet p0)
        {
            StyleConstants.GetComponent(p0);
        }
    }
}