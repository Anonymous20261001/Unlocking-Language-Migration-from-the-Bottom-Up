namespace javax.print
{
    public class DocFlavor
    {
        private readonly string mimeType;
        private readonly string encoding;

        public DocFlavor(string mimeType)
        {
            this.mimeType = mimeType;
            this.encoding = null;
        }

        public DocFlavor(string mimeType, string encoding)
        {
            this.mimeType = mimeType;
            this.encoding = encoding;
        }
    }

    public abstract class StreamPrintServiceFactory
    {
        public static StreamPrintServiceFactory[] lookupStreamPrintServiceFactories(DocFlavor flavor, string mimeType)
        {
            return new StreamPrintServiceFactory[0];
        }
    }
}

namespace Generated.Test
{
    using javax.print;

    public class javax_print_StreamPrintServiceFactoryAutoTest
    {
        public void lookupStreamPrintServiceFactories_test_11513(DocFlavor p0, string p1)
        {
            StreamPrintServiceFactory.lookupStreamPrintServiceFactories(p0, p1);
        }
    }
}