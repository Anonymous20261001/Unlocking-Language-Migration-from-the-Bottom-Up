namespace Generated.Test
{
    public class ClassLoader
    {
    }

    public class SchemaFactory
    {
        private const string W3C_XML_SCHEMA_NS_URI = "http://www.w3.org/2001/XMLSchema";

        public static SchemaFactory newDefaultInstance()
        {
            return new SchemaFactory();
        }

        public static SchemaFactory newInstance(string schemaLanguage)
        {
            if (schemaLanguage == null || schemaLanguage != W3C_XML_SCHEMA_NS_URI)
            {
                throw new System.ArgumentException("schemaLanguage");
            }

            return new SchemaFactory();
        }

        public static SchemaFactory newInstance(string schemaLanguage, string factoryClassName, ClassLoader classLoader)
        {
            if (schemaLanguage == null || schemaLanguage != W3C_XML_SCHEMA_NS_URI)
            {
                throw new System.ArgumentException("schemaLanguage");
            }

            if (factoryClassName == null)
            {
                throw new System.ArgumentException("factoryClassName");
            }

            return new SchemaFactory();
        }
    }

    public class javax_xml_validation_SchemaFactoryAutoTest
    {
        public void newDefaultInstance_test_10856()
        {
            SchemaFactory.newDefaultInstance();
        }

        public void newInstance_test_10857(string p0, string p1, ClassLoader p2)
        {
            SchemaFactory.newInstance(p0, p1, p2);
        }

        public void newInstance_test_10858(string p0)
        {
            SchemaFactory.newInstance(p0);
        }
    }
}