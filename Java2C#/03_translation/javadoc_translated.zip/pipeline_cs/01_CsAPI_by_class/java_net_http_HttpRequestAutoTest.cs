using System;

namespace Generated.Test
{
    public delegate bool BiPredicate(object obj1, object obj2);

    public class HttpRequest
    {
        public class Builder
        {
            internal Builder() { }
        }

        public static Builder newBuilder()
        {
            return new Builder();
        }

        public static Builder newBuilder(Uri uri)
        {
            return new Builder();
        }

        public static Builder newBuilder(HttpRequest request, BiPredicate filter)
        {
            return new Builder();
        }
    }

    public class java_net_http_HttpRequestAutoTest
    {
        public void newBuilder_test_5438(HttpRequest p0, BiPredicate p1)
        {
            HttpRequest.newBuilder(p0, p1);
        }

        public void newBuilder_test_5439(Uri p0)
        {
            HttpRequest.newBuilder(p0);
        }

        public void newBuilder_test_5440()
        {
            HttpRequest.newBuilder();
        }
    }
}