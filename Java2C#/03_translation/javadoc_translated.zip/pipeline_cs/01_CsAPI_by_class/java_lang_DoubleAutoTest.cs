```csharp
using System;
using System.Globalization;

namespace Generated.Test
{
    public class Double
    {
        private readonly double value;

        public Double(double value)
        {
            this.value = value;
        }

        public static double min(double a, double b)
        {
            if (double.IsNaN(a) || double.IsNaN(b))
                return double.NaN;
            return a < b ? a : b;
        }

        public static double max(double a, double b)
        {
            if (double.IsNaN(a) || double.IsNaN(b))
                return double.NaN;
            return a > b ? a : b;
        }

        public bool isInfinite()
        {
            return double.IsInfinity(value);
        }

        public static bool isInfinite(double v)
        {
            return double.IsInfinity(v);
        }

        public static bool isFinite(double v)
        {
            return !double.IsInfinity(v) && !double.IsNaN(v);
        }

        public static long doubleToRawLongBits(double v)
        {
            return BitConverter.DoubleToInt64Bits(v);
        }

        public static long doubleToLongBits(double v)
        {
            if (double.IsNaN(v))
                return 0x7ff8000000000000L;
            return BitConverter.DoubleToInt64Bits(v);
        }

        public static double longBitsToDouble(long bits)
        {
            return BitConverter.Int64BitsToDouble(bits);
        }

        public int compareTo(Double other)
        {
            if (other == null)
                throw new ArgumentNullException(nameof(other));
            return compare(value, other.value);
        }

        public static int compare(double a, double b)
        {
            if (a < b) return -1;
            if (a > b) return 1;
            long aBits = doubleToLongBits(a);
            long bBits = doubleToLongBits(b);
            return aBits == bBits ? 0 : (aBits < bBits ? -1 : 1);
        }

        public sbyte byteValue()
        {
            return unchecked((sbyte)toInt32(value));
        }

        public short shortValue()
        {
            return unchecked((short)toInt32(value));
        }

        public int intValue()
        {
            return toInt32(value);
        }

        public long longValue()
        {
            return toInt64(value);
        }

        public float floatValue()
        {
            return (float)value;
        }

        public double doubleValue()
        {
            return value;
        }

        public static Double valueOf(string s)
        {
            return new Double(parseDouble(s));
        }

        public static Double valueOf(double v)
        {
            return new Double(v);
        }

        public static string toHexString(double v)
        {
            if (double.IsNaN(v)) return "NaN";
            if (double.IsPositiveInfinity(v)) return "Infinity";
            if (double.IsNegativeInfinity(v)) return "-Infinity";

            long bits = BitConverter.DoubleToInt64Bits(v);
            string sign = (bits < 0) ? "-" : "";
            int exp = (int)((bits >> 52) & 0x7ffL);
            long frac = bits & 0xfffffffffffffL;

            if (exp == 0 && frac == 0)
                return sign + "0x0.0p0";

            string fracHex = frac.ToString("x13");
            string trimmed = fracHex.TrimEnd('0');
            if (trimmed.Length == 0)
                trimmed = "0";

            if (exp == 0)
                return sign + "0x0." + trimmed + "p-1022";

            int biasedExp = exp - 1023;
            return sign + "0x1." + trimmed + "p" + biasedExp;
        }

        public Double resolveConstantDesc(MethodHandles.Lookup lookup)
        {
            return this;
        }

        public Optional describeConstable()
        {
            return Optional.of(this);
        }

        public bool isNaN()
        {
            return double.IsNaN(value);
        }

        public static bool isNaN(double v)
        {
            return double.IsNaN(v);
        }

        public static double sum(double a, double b)
        {
            return a + b;
        }

        public static double parseDouble(string s)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));

            string t = s.Trim();
            if (t == "NaN") return double.NaN;
            if (t == "Infinity") return double.PositiveInfinity;
            if (t == "-Infinity") return double.NegativeInfinity;

            return double.Parse(t, NumberStyles.Float, CultureInfo.InvariantCulture);
        }

        private static int toInt32(double v)
        {
            if (double.IsNaN(v)) return 0;
            if (v >= int.MaxValue) return int.MaxValue;
            if (v <= int.MinValue) return int.MinValue;
            return (int)v;
        }

        private static long toInt64(double v)
        {
            if (double.IsNaN(v)) return 0;
            if (v >= long.MaxValue) return long.MaxValue;
            if (v <= long.MinValue) return long.MinValue;
            return (long)v;
        }
    }

    public class MethodHandles
    {
        public sealed class Lookup
        {
        }
    }

    public class Optional
    {
        private readonly object value;

        private Optional(object value)
        {
            this.value = value;
        }

        public static Optional of(object value)
        {
            return new Optional(value);
        }
    }

    public class java_lang_DoubleAutoTest
    {
        public void min_test_4224(double p0, double p1)
        {
            Double.min(p0, p1);
        }

        public void max_test_4225(double p0, double p1)
        {
            Double.max(p0, p1);
        }

        public void isInfinite_test_4226(double c0)
        {
            Double instance = new Double(c0);
            instance.isInfinite();
        }

        public void isInfinite_test_4227(double p0)
        {
            Double.isInfinite(p0);
        }

        public void isFinite_test_4228(double p0)
        {
            Double.isFinite(p0);
        }

        public void doubleToRawLongBits_test_4229(double p0)
        {
            Double.doubleToRawLongBits(p0);
        }

        public void doubleToLongBits_test_4230(double p0)
        {
            Double.doubleToLongBits(p0);
        }

        public void longBitsToDouble_test_4231(long p0)
        {
            Double.longBitsToDouble(p0);
        }

        public void compareTo_test_4232(Double p0, double c0)
        {
            Double instance = new Double(c0);
            instance.compareTo(p0);
        }

        public void compare_test_4233(double p0, double p1)
        {
            Double.compare(p0, p1);
        }

        public void byteValue_test_4234(double c0)
        {
            Double instance = new Double(c0);
            instance.byteValue();
        }

        public void shortValue_test_4235(double c0)
        {
            Double instance = new Double(c0);
            instance.shortValue();
        }

        public void intValue_test_4236(double c0)
        {
            Double instance = new Double(c0);
            instance.intValue();
        }

        public void longValue_test_4237(double c0)
        {
            Double instance = new Double(c0);
            instance.longValue();
        }

        public void floatValue_test_4238(double c0)
        {
            Double instance = new Double(c0);
            instance.floatValue();
        }

        public void doubleValue_test_4239(double c0)
        {
            Double instance = new Double(c0);
            instance.doubleValue();
        }

        public void valueOf_test_4240(string p0)
        {
            Double.valueOf(p0);
        }

        public void valueOf_test_4241(double p0)
        {
            Double.valueOf(p0);
        }

        public void toHexString_test_4242(double p0)
        {
            Double.toHexString(p0);
        }

        public void resolveConstantDesc_test_4243(MethodHandles.Lookup p0, double c0)
        {
            Double instance = new Double(c0);
            instance.resolveConstantDesc(p0);
        }

        public void describeConstable_test_4244(double c0)
        {
            Double instance = new Double(c0);
            instance.describeConstable();
        }

        public void isNaN_test_4245(double c0)
        {
            Double instance = new Double(c0);
            instance.isNaN();
        }

        public void isNaN_test_4246(double p0)
        {
            Double.isNaN(p0);
        }

        public void sum_test_4247(double p0, double p1)
        {
            Double.sum(p0, p1);
        }

        public void parseDouble_test_4248(string p0)
        {
            Double.parseDouble(p0);
        }
    }
}
```