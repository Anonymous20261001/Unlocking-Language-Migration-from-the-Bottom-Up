using System;

namespace Generated.Test
{
    public class TextHitInfo
    {
        private readonly int charIndex;
        private readonly bool isLeading;

        private TextHitInfo(int charIndex, bool isLeading)
        {
            this.charIndex = charIndex;
            this.isLeading = isLeading;
        }

        public static TextHitInfo leading(int charIndex)
        {
            return new TextHitInfo(charIndex, true);
        }

        public static TextHitInfo trailing(int charIndex)
        {
            return new TextHitInfo(charIndex, false);
        }

        public static TextHitInfo beforeOffset(int offset)
        {
            return new TextHitInfo(offset - 1, false);
        }

        public static TextHitInfo afterOffset(int offset)
        {
            return new TextHitInfo(offset, true);
        }

        public int GetCharIndex()
        {
            return charIndex;
        }

        public int GetInsertionIndex()
        {
            return isLeading ? charIndex : charIndex + 1;
        }

        public bool IsLeading()
        {
            return isLeading;
        }

        public override bool Equals(object obj)
        {
            TextHitInfo other = obj as TextHitInfo;
            if (other == null)
            {
                return false;
            }
            return charIndex == other.charIndex && isLeading == other.isLeading;
        }

        public override int GetHashCode()
        {
            return charIndex ^ (isLeading ? 1 : 0);
        }

        public override string ToString()
        {
            return "TextHitInfo[" + charIndex + "," + (isLeading ? "L" : "T") + "]";
        }
    }

    public class java_awt_font_TextHitInfoAutoTest
    {
        public void trailing_test_12587(int p0)
        {
            TextHitInfo.trailing(p0);
        }

        public void leading_test_12588(int p0)
        {
            TextHitInfo.leading(p0);
        }

        public void beforeOffset_test_12589(int p0)
        {
            TextHitInfo.beforeOffset(p0);
        }

        public void afterOffset_test_12590(int p0)
        {
            TextHitInfo.afterOffset(p0);
        }
    }
}