using System;

namespace Generated.Test
{
    public class java_security_KeyStoreAutoTest
    {
        public void getDefaultType_test_7636()
        {
            KeyStore.getDefaultType();
        }
    }

    public static class KeyStore
    {
        public static string getDefaultType()
        {
            return "pkcs12";
        }
    }
}