namespace Generated.Test
{
    public class javax_annotation_processing_CompletionsAutoTest
    {
        public void of_test_2610(string p0, string p1)
        {
            Completions.of(p0, p1);
        }

        public void of_test_2611(string p0)
        {
            Completions.of(p0);
        }
    }

    public static class Completions
    {
        public static Completion of(string value, string message)
        {
            return new Completion(value, message);
        }

        public static Completion of(string value)
        {
            return new Completion(value);
        }
    }

    public class Completion
    {
        public string Value { get; }
        public string Message { get; }

        public Completion(string value) : this(value, null)
        {
        }

        public Completion(string value, string message)
        {
            Value = value;
            Message = message;
        }
    }
}