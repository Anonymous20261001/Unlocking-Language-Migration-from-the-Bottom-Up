using System;
using System.Collections.Generic;
using System.Text;

namespace Generated.Test
{
    public class javax_management_modelmbean_DescriptorSupportAutoTest
    {
        public void getFieldNames_test_4099()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.getFieldNames();
        }

        public void getFieldValues_test_4100(string[] p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.getFieldValues(p0);
        }

        public void setField_test_4101(string p0, object p1)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.setField(p0, p1);
        }

        public void getFieldValue_test_4102(string p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.getFieldValue(p0);
        }

        public void removeField_test_4103(string p0)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.removeField(p0);
        }

        public void toXMLString_test_4104()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.toXMLString();
        }

        public void getFields_test_4105()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.getFields();
        }

        public void isValid_test_4106()
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.isValid();
        }

        public void setFields_test_4107(string[] p0, object[] p1)
        {
            DescriptorSupport instance = new DescriptorSupport();
            instance.setFields(p0, p1);
        }
    }

    public class DescriptorSupport
    {
        private List<string> fieldNames = new List<string>();
        private List<object> fieldValues = new List<object>();

        public DescriptorSupport()
        {
        }

        public string[] getFieldNames()
        {
            return fieldNames.ToArray();
        }

        public object[] getFieldValues(string[] requestedNames)
        {
            if (requestedNames == null || requestedNames.Length == 0)
            {
                return fieldValues.ToArray();
            }

            object[] result = new object[requestedNames.Length];
            for (int i = 0; i < requestedNames.Length; i++)
            {
                result[i] = getFieldValue(requestedNames[i]);
            }
            return result;
        }

        public void setField(string fieldName, object fieldValue)
        {
            if (fieldName == null)
            {
                throw new ArgumentException("fieldName cannot be null");
            }

            int index = fieldNames.IndexOf(fieldName);
            if (index >= 0)
            {
                fieldValues[index] = fieldValue;
            }
            else
            {
                fieldNames.Add(fieldName);
                fieldValues.Add(fieldValue);
            }
        }

        public object getFieldValue(string fieldName)
        {
            int index = fieldNames.IndexOf(fieldName);
            if (index >= 0)
            {
                return fieldValues[index];
            }
            return null;
        }

        public void removeField(string fieldName)
        {
            int index = fieldNames.IndexOf(fieldName);
            if (index >= 0)
            {
                fieldNames.RemoveAt(index);
                fieldValues.RemoveAt(index);
            }
        }

        public string toXMLString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<Descriptor>");
            for (int i = 0; i < fieldNames.Count; i++)
            {
                sb.Append("<field name=\"");
                sb.Append(EscapeXml(fieldNames[i]));
                sb.Append("\" value=\"");
                if (fieldValues[i] != null)
                {
                    sb.Append(EscapeXml(fieldValues[i].ToString()));
                }
                sb.Append("\"/>");
            }
            sb.Append("</Descriptor>");
            return sb.ToString();
        }

        public string[] getFields()
        {
            string[] result = new string[fieldNames.Count];
            for (int i = 0; i < fieldNames.Count; i++)
            {
                string value = fieldValues[i] == null ? "null" : fieldValues[i].ToString();
                result[i] = fieldNames[i] + "=" + value;
            }
            return result;
        }

        public bool isValid()
        {
            return true;
        }

        public void setFields(string[] fieldNamesArray, object[] fieldValuesArray)
        {
            if (fieldNamesArray == null)
            {
                throw new ArgumentException("fieldNames cannot be null");
            }
            if (fieldValuesArray == null)
            {
                throw new ArgumentException("fieldValues cannot be null");
            }
            if (fieldNamesArray.Length != fieldValuesArray.Length)
            {
                throw new ArgumentException("fieldNames and fieldValues must have same length");
            }

            for (int i = 0; i < fieldNamesArray.Length; i++)
            {
                setField(fieldNamesArray[i], fieldValuesArray[i]);
            }
        }

        private static string EscapeXml(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return s;
            }
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace("\"", "&quot;");
        }
    }
}