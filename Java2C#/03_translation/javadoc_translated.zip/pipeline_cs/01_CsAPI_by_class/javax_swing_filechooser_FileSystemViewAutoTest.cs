namespace Generated.Test
{
    public class FileSystemView
    {
        private FileSystemView()
        {
        }

        public static FileSystemView getFileSystemView()
        {
            return new FileSystemView();
        }
    }

    public class javax_swing_filechooser_FileSystemViewAutoTest
    {
        public void getFileSystemView_test_4781()
        {
            FileSystemView.getFileSystemView();
        }
    }
}