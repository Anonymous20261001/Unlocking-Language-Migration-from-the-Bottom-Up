using System.Collections.Generic;

namespace Generated.Test
{
    public sealed class Configuration
    {
        private Configuration() { }

        public static List<Configuration> GetConfigurations()
        {
            return new List<Configuration>();
        }
    }

    public class jdk_jfr_ConfigurationAutoTest
    {
        public void getConfigurations_test_2908()
        {
            Configuration.GetConfigurations();
        }
    }
}