using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class ClassLoader
    {
        public virtual Type LoadClass(string className)
        {
            switch (className)
            {
                case "java.lang.String": return typeof(string);
                case "java.lang.Object": return typeof(object);
                case "java.lang.Class": return typeof(Type);
                case "java.lang.Integer": return typeof(int);
                case "java.lang.Boolean": return typeof(bool);
                case "java.lang.Byte": return typeof(sbyte);
                case "java.lang.Character": return typeof(char);
                case "java.lang.Short": return typeof(short);
                case "java.lang.Long": return typeof(long);
                case "java.lang.Float": return typeof(float);
                case "java.lang.Double": return typeof(double);
                default:
                    return Type.GetType(className) ?? typeof(object);
            }
        }
    }

    public class MethodType
    {
        public Type ReturnType { get; private set; }
        public IList<Type> ParameterTypes { get; private set; }

        public MethodType(Type returnType, IList<Type> parameterTypes)
        {
            ReturnType = returnType;
            ParameterTypes = parameterTypes == null ? new List<Type>() : new List<Type>(parameterTypes);
        }

        public static MethodType methodType(Type rtype, IList<Type> ptypes)
        {
            return new MethodType(rtype, ptypes);
        }

        public static MethodType methodType(Type rtype)
        {
            return new MethodType(rtype, new Type[0]);
        }

        public static MethodType methodType(Type rtype, Type ptype0)
        {
            return new MethodType(rtype, new[] { ptype0 });
        }

        public static MethodType methodType(Type rtype, params Type[] ptypes)
        {
            return new MethodType(rtype, ptypes ?? new Type[0]);
        }

        public static MethodType methodType(Type rtype, Type ptype0, Type[] ptypes)
        {
            var list = new List<Type>();
            list.Add(ptype0);
            if (ptypes != null)
                list.AddRange(ptypes);
            return new MethodType(rtype, list);
        }

        public static MethodType methodType(Type rtype, MethodType ptypes)
        {
            return new MethodType(rtype, ptypes.ParameterTypes);
        }

        public static MethodType genericMethodType(int objectArgCount, bool finalArray)
        {
            if (objectArgCount < 0)
                throw new ArgumentOutOfRangeException(nameof(objectArgCount));
            Type[] ptypes = new Type[objectArgCount];
            for (int i = 0; i < objectArgCount; i++)
            {
                ptypes[i] = (finalArray && i == objectArgCount - 1) ? typeof(object[]) : typeof(object);
            }
            return new MethodType(typeof(object), ptypes);
        }

        public static MethodType genericMethodType(int objectArgCount)
        {
            return genericMethodType(objectArgCount, false);
        }

        public static MethodType fromMethodDescriptorString(string descriptor, ClassLoader loader)
        {
            if (descriptor == null)
                throw new ArgumentNullException(nameof(descriptor));
            if (loader == null)
                loader = new ClassLoader();
            if (descriptor.Length < 2 || descriptor[0] != '(')
                throw new ArgumentException("Invalid method descriptor", nameof(descriptor));

            int pos = 1;
            List<Type> parameterTypes = new List<Type>();
            while (descriptor[pos] != ')')
            {
                parameterTypes.Add(ParseType(descriptor, ref pos, loader));
            }
            pos++; // skip ')'

            Type returnType = ParseType(descriptor, ref pos, loader);
            if (pos != descriptor.Length)
                throw new ArgumentException("Invalid method descriptor", nameof(descriptor));

            return new MethodType(returnType, parameterTypes);
        }

        private static Type ParseType(string descriptor, ref int pos, ClassLoader loader)
        {
            char c = descriptor[pos];
            switch (c)
            {
                case 'V': pos++; return typeof(void);
                case 'Z': pos++; return typeof(bool);
                case 'B': pos++; return typeof(sbyte);
                case 'C': pos++; return typeof(char);
                case 'S': pos++; return typeof(short);
                case 'I': pos++; return typeof(int);
                case 'J': pos++; return typeof(long);
                case 'F': pos++; return typeof(float);
                case 'D': pos++; return typeof(double);
                case 'L':
                    int start = ++pos;
                    while (descriptor[pos] != ';')
                        pos++;
                    string className = descriptor.Substring(start, pos - start);
                    pos++; // skip ';'
                    return loader.LoadClass(className);
                case '[':
                    pos++; // skip '['
                    Type elementType = ParseType(descriptor, ref pos, loader);
                    return elementType.MakeArrayType();
                default:
                    throw new ArgumentException("Invalid type descriptor at position " + pos, nameof(descriptor));
            }
        }
    }

    public class java_lang_invoke_MethodTypeAutoTest
    {
        public void methodType_test_8922(Type p0, IList<Type> p1)
        {
            MethodType.methodType(p0, p1);
        }

        public void methodType_test_8923(Type p0)
        {
            MethodType.methodType(p0);
        }

        public void methodType_test_8924(Type p0, Type p1, Type[] p2)
        {
            MethodType.methodType(p0, p1, p2);
        }

        public void methodType_test_8925(Type p0, Type[] p1)
        {
            MethodType.methodType(p0, p1);
        }

        public void methodType_test_8926(Type p0, Type p1)
        {
            MethodType.methodType(p0, p1);
        }

        public void methodType_test_8927(Type p0, MethodType p1)
        {
            MethodType.methodType(p0, p1);
        }

        public void genericMethodType_test_8928(int p0, bool p1)
        {
            MethodType.genericMethodType(p0, p1);
        }

        public void genericMethodType_test_8929(int p0)
        {
            MethodType.genericMethodType(p0);
        }

        public void fromMethodDescriptorString_test_8930(string p0, ClassLoader p1)
        {
            MethodType.fromMethodDescriptorString(p0, p1);
        }
    }
}