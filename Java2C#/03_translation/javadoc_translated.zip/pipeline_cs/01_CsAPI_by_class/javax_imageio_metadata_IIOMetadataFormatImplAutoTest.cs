using System;

namespace Generated.Test
{
    public class IIOMetadataFormatImpl
    {
        private static IIOMetadataFormatImpl _standardInstance;

        public static IIOMetadataFormatImpl getStandardFormatInstance()
        {
            if (_standardInstance == null)
            {
                _standardInstance = new IIOMetadataFormatImpl();
            }
            return _standardInstance;
        }
    }

    public class javax_imageio_metadata_IIOMetadataFormatImplAutoTest
    {
        public void getStandardFormatInstance_test_5555()
        {
            IIOMetadataFormatImpl.getStandardFormatInstance();
        }
    }
}