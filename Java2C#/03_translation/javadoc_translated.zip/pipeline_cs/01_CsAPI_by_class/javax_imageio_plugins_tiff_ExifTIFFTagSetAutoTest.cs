using javax.imageio.plugins.tiff;

namespace Generated.Test
{
    public class javax_imageio_plugins_tiff_ExifTIFFTagSetAutoTest
    {
        public void getInstance_test_4664()
        {
            ExifTIFFTagSet.getInstance();
        }
    }
}

namespace javax.imageio.plugins.tiff
{
    public class ExifTIFFTagSet
    {
        private static ExifTIFFTagSet instance;
        private ExifTIFFTagSet() { }

        public static ExifTIFFTagSet getInstance()
        {
            if (instance == null)
            {
                instance = new ExifTIFFTagSet();
            }
            return instance;
        }
    }
}