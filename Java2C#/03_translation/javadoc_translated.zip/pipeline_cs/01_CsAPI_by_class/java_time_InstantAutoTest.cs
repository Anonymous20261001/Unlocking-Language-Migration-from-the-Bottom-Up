using System;

namespace Generated.Test
{
    public class java_time_InstantAutoTest
    {
        public void from_test_5857(TemporalAccessor p0)
        {
            Instant.from(p0);
        }

        public void parse_test_5858(CharSequence p0)
        {
            Instant.parse(p0);
        }

        public void now_test_5859()
        {
            Instant.now();
        }

        public void now_test_5860(Clock p0)
        {
            Instant.now(p0);
        }

        public void ofEpochSecond_test_5861(long p0, long p1)
        {
            Instant.ofEpochSecond(p0, p1);
        }

        public void ofEpochSecond_test_5862(long p0)
        {
            Instant.ofEpochSecond(p0);
        }

        public void ofEpochMilli_test_5863(long p0)
        {
            Instant.ofEpochMilli(p0);
        }
    }

    public interface CharSequence
    {
    }

    public interface TemporalAccessor
    {
    }

    public class Clock
    {
    }

    public class Instant
    {
        public static Instant from(TemporalAccessor temporal)
        {
            return new Instant();
        }

        public static Instant parse(CharSequence text)
        {
            return new Instant();
        }

        public static Instant now()
        {
            return new Instant();
        }

        public static Instant now(Clock clock)
        {
            return new Instant();
        }

        public static Instant ofEpochSecond(long epochSecond, long nanoAdjustment)
        {
            return new Instant();
        }

        public static Instant ofEpochSecond(long epochSecond)
        {
            return new Instant();
        }

        public static Instant ofEpochMilli(long epochMilli)
        {
            return new Instant();
        }
    }
}