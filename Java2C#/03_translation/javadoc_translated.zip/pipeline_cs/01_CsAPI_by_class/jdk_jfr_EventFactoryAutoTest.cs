using System.Collections;

namespace Generated.Test
{
    public class EventFactory
    {
        public static EventFactory create(IList annotations, IList fields)
        {
            return new EventFactory();
        }
    }

    public class jdk_jfr_EventFactoryAutoTest
    {
        public void create_test_4573(IList p0, IList p1)
        {
            EventFactory.create(p0, p1);
        }
    }
}