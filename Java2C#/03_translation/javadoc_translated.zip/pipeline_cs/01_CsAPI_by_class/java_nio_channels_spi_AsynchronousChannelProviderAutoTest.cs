namespace Generated.Test
{
    public class java_nio_channels_spi_AsynchronousChannelProviderAutoTest
    {
        public void provider_test_544()
        {
            AsynchronousChannelProvider.provider();
        }
    }

    public abstract class AsynchronousChannelProvider
    {
        private static readonly AsynchronousChannelProvider defaultProvider = new DefaultProvider();

        public static AsynchronousChannelProvider provider()
        {
            return defaultProvider;
        }

        protected AsynchronousChannelProvider()
        {
        }

        private sealed class DefaultProvider : AsynchronousChannelProvider
        {
        }
    }
}