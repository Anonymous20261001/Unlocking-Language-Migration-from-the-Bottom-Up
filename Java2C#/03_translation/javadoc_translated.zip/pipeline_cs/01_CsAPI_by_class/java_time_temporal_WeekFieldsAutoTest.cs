```csharp
using System;

namespace Generated.Test
{
    public sealed class Locale
    {
    }

    public sealed class WeekFields
    {
        private readonly DayOfWeek firstDayOfWeek;
        private readonly int minimalDaysInFirstWeek;

        private WeekFields(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek)
        {
            this.firstDayOfWeek = firstDayOfWeek;
            this.minimalDaysInFirstWeek = minimalDaysInFirstWeek;
        }

        public static WeekFields of(Locale locale)
        {
            if (locale == null)
            {
                throw new ArgumentNullException("locale");
            }

            System.Globalization.CultureInfo culture = System.Globalization.CultureInfo.InvariantCulture;
            DayOfWeek first = culture.DateTimeFormat.FirstDayOfWeek;
            int minimalDays = culture.DateTimeFormat.CalendarWeekRule == System.Globalization.CalendarWeekRule.FirstDay ? 1 : 4;

            return new WeekFields(first, minimalDays);
        }

        public static WeekFields of(DayOfWeek firstDayOfWeek, int minimalDaysInFirstWeek)
        {
            if (minimalDaysInFirstWeek < 1 || minimalDaysInFirstWeek > 7)
            {
                throw new ArgumentException("minimalDaysInFirstWeek must be between 1 and 7", "minimalDaysInFirstWeek");
            }

            if (!Enum.IsDefined(typeof(DayOfWeek), firstDayOfWeek))
            {
                throw new ArgumentException("firstDayOfWeek is not a valid DayOfWeek value", "firstDayOfWeek");
            }

            return new WeekFields(firstDayOfWeek, minimalDaysInFirstWeek);
        }
    }

    public class java_time_temporal_WeekFieldsAutoTest
    {
        public void of_test_13452(Locale p0)
        {
            WeekFields.of(p0);
        }

        public void of_test_13453(DayOfWeek p0, int p1)
        {
            WeekFields.of(p0, p1);
        }
    }
}
```