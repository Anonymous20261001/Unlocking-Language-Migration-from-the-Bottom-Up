namespace Generated.Test
{
    public class Toolkit
    {
        private static readonly Toolkit defaultToolkit = new Toolkit();

        public static Toolkit getDefaultToolkit()
        {
            return defaultToolkit;
        }

        public static string getProperty(string key, string defaultValue)
        {
            return defaultValue;
        }
    }

    public class java_awt_ToolkitAutoTest
    {
        public void getDefaultToolkit_test_12927()
        {
            Toolkit.getDefaultToolkit();
        }

        public void getProperty_test_12928(string p0, string p1)
        {
            Toolkit.getProperty(p0, p1);
        }
    }
}