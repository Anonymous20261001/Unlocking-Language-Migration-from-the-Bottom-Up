using System;
using System.IO;
using System.Text;

namespace Generated.Test
{
    public class URLDecoder
    {
        public static string decode(string s)
        {
            return decode(s, Encoding.UTF8);
        }

        public static string decode(string s, Encoding encoding)
        {
            if (s == null) return null;
            if (encoding == null) throw new ArgumentNullException("encoding");

            using (MemoryStream baos = new MemoryStream())
            {
                for (int i = 0; i < s.Length; i++)
                {
                    char c = s[i];
                    if (c == '+')
                    {
                        baos.WriteByte((byte)' ');
                    }
                    else if (c == '%' && i + 2 < s.Length)
                    {
                        int hi = HexDigit(s[i + 1]);
                        int lo = HexDigit(s[i + 2]);
                        if (hi != -1 && lo != -1)
                        {
                            baos.WriteByte((byte)((hi << 4) + lo));
                            i += 2;
                        }
                        else
                        {
                            throw new ArgumentException("Malformed URL encoding: % must be followed by two hex digits");
                        }
                    }
                    else if (c == '%')
                    {
                        throw new ArgumentException("Malformed URL encoding: % must be followed by two hex digits");
                    }
                    else
                    {
                        baos.WriteByte((byte)c);
                    }
                }
                return encoding.GetString(baos.ToArray());
            }
        }

        private static int HexDigit(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }
    }

    public class java_net_URLDecoderAutoTest
    {
        public void decode_test_13265(string p0, Encoding p1)
        {
            URLDecoder.decode(p0, p1);
        }

        public void decode_test_13266(string p0)
        {
            URLDecoder.decode(p0);
        }
    }
}