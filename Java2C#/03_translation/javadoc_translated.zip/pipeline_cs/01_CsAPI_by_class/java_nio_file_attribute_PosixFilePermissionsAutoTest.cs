using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public enum PosixFilePermission
    {
        OWNER_READ,
        OWNER_WRITE,
        OWNER_EXECUTE,
        GROUP_READ,
        GROUP_WRITE,
        GROUP_EXECUTE,
        OTHERS_READ,
        OTHERS_WRITE,
        OTHERS_EXECUTE
    }

    public class FileAttribute<T>
    {
        public string Name { get; }
        public T Value { get; }

        public FileAttribute(string name, T value)
        {
            Name = name;
            Value = value;
        }
    }

    public static class PosixFilePermissions
    {
        public static FileAttribute<ISet<PosixFilePermission>> asFileAttribute(ISet<PosixFilePermission> perms)
        {
            if (perms == null) throw new ArgumentNullException("perms");
            return new FileAttribute<ISet<PosixFilePermission>>("posix:permissions", new HashSet<PosixFilePermission>(perms));
        }

        public static ISet<PosixFilePermission> fromString(string permissions)
        {
            if (permissions == null) throw new ArgumentNullException("permissions");
            if (permissions.Length != 9) throw new ArgumentException("Invalid mode: " + permissions);

            var result = new HashSet<PosixFilePermission>();
            for (int i = 0; i < 9; i++)
            {
                char c = permissions[i];
                bool isRead = i % 3 == 0;
                bool isWrite = i % 3 == 1;
                bool isExecute = i % 3 == 2;
                PosixFilePermission? perm = null;

                if (c == 'r' && isRead)
                {
                    perm = PermissionFor(i);
                }
                else if (c == 'w' && isWrite)
                {
                    perm = PermissionFor(i);
                }
                else if (c == 'x' && isExecute)
                {
                    perm = PermissionFor(i);
                }
                else if (c == '-')
                {
                    // no permission
                }
                else
                {
                    throw new ArgumentException("Invalid mode: " + permissions);
                }

                if (perm.HasValue)
                {
                    result.Add(perm.Value);
                }
            }
            return result;
        }

        private static PosixFilePermission PermissionFor(int index)
        {
            switch (index)
            {
                case 0: return PosixFilePermission.OWNER_READ;
                case 1: return PosixFilePermission.OWNER_WRITE;
                case 2: return PosixFilePermission.OWNER_EXECUTE;
                case 3: return PosixFilePermission.GROUP_READ;
                case 4: return PosixFilePermission.GROUP_WRITE;
                case 5: return PosixFilePermission.GROUP_EXECUTE;
                case 6: return PosixFilePermission.OTHERS_READ;
                case 7: return PosixFilePermission.OTHERS_WRITE;
                case 8: return PosixFilePermission.OTHERS_EXECUTE;
                default: throw new ArgumentOutOfRangeException("index");
            }
        }
    }

    public class java_nio_file_attribute_PosixFilePermissionsAutoTest
    {
        public void asFileAttribute_test_9995(ISet<PosixFilePermission> p0)
        {
            PosixFilePermissions.asFileAttribute(p0);
        }

        public void fromString_test_9996(string p0)
        {
            PosixFilePermissions.fromString(p0);
        }
    }
}