namespace Generated.Test
{
    public interface CompositeData { }

    public class ThreadInfo
    {
        public static ThreadInfo from(CompositeData data)
        {
            return new ThreadInfo();
        }
    }

    public class java_lang_management_ThreadInfoAutoTest
    {
        public void from_test_12708(CompositeData p0)
        {
            ThreadInfo.from(p0);
        }
    }
}