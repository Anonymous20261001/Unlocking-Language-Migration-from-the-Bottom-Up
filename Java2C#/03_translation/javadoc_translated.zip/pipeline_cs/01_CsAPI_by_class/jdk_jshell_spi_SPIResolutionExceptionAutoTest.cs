namespace Generated.Test
{
    public class jdk_jshell_spi_SPIResolutionExceptionAutoTest
    {
        public void id_test_11312(int c0)
        {
            SPIResolutionException instance = new SPIResolutionException(c0);
            instance.id();
        }
    }

    public class SPIResolutionException : System.Exception
    {
        private int _id;

        public SPIResolutionException(int id) : base()
        {
            _id = id;
        }

        public int id()
        {
            return _id;
        }
    }
}