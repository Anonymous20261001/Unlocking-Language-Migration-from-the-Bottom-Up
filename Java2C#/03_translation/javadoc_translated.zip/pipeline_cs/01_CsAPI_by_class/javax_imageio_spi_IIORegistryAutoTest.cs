```csharp
using System;

namespace Generated.Test
{
    public class IIORegistry
    {
        private static IIORegistry defaultInstance;
        private static readonly object lockObject = new object();

        private IIORegistry()
        {
        }

        public static IIORegistry getDefaultInstance()
        {
            lock (lockObject)
            {
                if (defaultInstance == null)
                {
                    defaultInstance = new IIORegistry();
                }
                return defaultInstance;
            }
        }
    }

    public class javax_imageio_spi_IIORegistryAutoTest
    {
        public void getDefaultInstance_test_5617()
        {
            IIORegistry.getDefaultInstance();
        }
    }
}
```