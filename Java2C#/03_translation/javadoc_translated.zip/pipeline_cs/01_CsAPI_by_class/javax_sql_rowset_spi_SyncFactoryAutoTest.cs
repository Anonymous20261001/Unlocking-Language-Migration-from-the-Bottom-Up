namespace Generated.Test
{
    public class Level
    {
        public static readonly Level OFF = new Level("OFF", int.MaxValue);
        public static readonly Level SEVERE = new Level("SEVERE", 1000);
        public static readonly Level WARNING = new Level("WARNING", 900);
        public static readonly Level INFO = new Level("INFO", 800);
        public static readonly Level CONFIG = new Level("CONFIG", 700);
        public static readonly Level FINE = new Level("FINE", 500);
        public static readonly Level FINER = new Level("FINER", 400);
        public static readonly Level FINEST = new Level("FINEST", 300);
        public static readonly Level ALL = new Level("ALL", int.MinValue);

        private readonly string name;
        private readonly int value;

        private Level(string name, int value)
        {
            this.name = name;
            this.value = value;
        }

        public string getName()
        {
            return name;
        }

        public int intValue()
        {
            return value;
        }

        public override string ToString()
        {
            return name;
        }
    }

    public class Logger
    {
        private readonly string name;

        private Logger(string name)
        {
            this.name = name;
        }

        public static Logger getLogger(string name)
        {
            return new Logger(name);
        }

        public string getName()
        {
            return name;
        }
    }

    public class SyncFactory
    {
        private static SyncFactory instance;
        private static Logger logger;
        private static Level level;

        private SyncFactory()
        {
        }

        public static SyncFactory getSyncFactory()
        {
            if (instance == null)
            {
                instance = new SyncFactory();
            }
            return instance;
        }

        public static void setLogger(Logger logger)
        {
            SyncFactory.logger = logger;
        }

        public static void setLogger(Logger logger, Level level)
        {
            SyncFactory.logger = logger;
            SyncFactory.level = level;
        }
    }

    public class javax_sql_rowset_spi_SyncFactoryAutoTest
    {
        public void getSyncFactory_test_12123()
        {
            SyncFactory.getSyncFactory();
        }

        public void setLogger_test_12124(Logger p0)
        {
            SyncFactory.setLogger(p0);
        }

        public void setLogger_test_12125(Logger p0, Level p1)
        {
            SyncFactory.setLogger(p0, p1);
        }
    }
}