namespace Generated.Test
{
    public abstract class InputStream
    {
        public static InputStream nullInputStream()
        {
            return new NullInputStream();
        }

        public abstract int Read();

        private sealed class NullInputStream : InputStream
        {
            public override int Read()
            {
                return -1;
            }
        }
    }

    public class java_io_InputStreamAutoTest
    {
        public void nullInputStream_test_5854()
        {
            InputStream.nullInputStream();
        }
    }
}