using System.Collections;

namespace Generated.Test
{
    public interface Runnable
    {
        void run();
    }

    public interface Callable
    {
        object call();
    }

    public interface Collection : IEnumerable
    {
    }

    public class ForkJoinPool
    {
    }

    public abstract class ForkJoinTask
    {
        public static ForkJoinTask adapt(Runnable p0, object p1)
        {
            return new AdaptedRunnable(p0, p1);
        }

        public static ForkJoinTask adapt(Callable p0)
        {
            return new AdaptedCallable(p0);
        }

        public static ForkJoinTask adapt(Runnable p0)
        {
            return new AdaptedRunnable(p0, null);
        }

        public static int getQueuedTaskCount()
        {
            return 0;
        }

        public static ForkJoinPool getPool()
        {
            return null;
        }

        public static void invokeAll(Collection p0)
        {
            if (p0 != null)
            {
                foreach (object item in p0)
                {
                }
            }
        }

        public static void invokeAll(ForkJoinTask p0, ForkJoinTask p1)
        {
        }

        public static void invokeAll(ForkJoinTask[] p0)
        {
        }

        public static int getSurplusQueuedTaskCount()
        {
            return 0;
        }

        public static void helpQuiesce()
        {
        }

        public static bool inForkJoinPool()
        {
            return false;
        }

        public static ForkJoinTask adaptInterruptible(Runnable p0)
        {
            return new AdaptedRunnable(p0, null);
        }

        public static ForkJoinTask adaptInterruptible(Runnable p0, object p1)
        {
            return new AdaptedRunnable(p0, p1);
        }

        public static ForkJoinTask adaptInterruptible(Callable p0)
        {
            return new AdaptedCallable(p0);
        }

        private sealed class AdaptedRunnable : ForkJoinTask
        {
            private readonly Runnable runnable;
            private readonly object result;

            public AdaptedRunnable(Runnable runnable, object result)
            {
                this.runnable = runnable;
                this.result = result;
            }
        }

        private sealed class AdaptedCallable : ForkJoinTask
        {
            private readonly Callable callable;

            public AdaptedCallable(Callable callable)
            {
                this.callable = callable;
            }
        }
    }

    public class java_util_concurrent_ForkJoinTaskAutoTest
    {
        public void adapt_test_5019(Runnable p0, object p1)
        {
            ForkJoinTask.adapt(p0, p1);
        }

        public void adapt_test_5020(Callable p0)
        {
            ForkJoinTask.adapt(p0);
        }

        public void adapt_test_5021(Runnable p0)
        {
            ForkJoinTask.adapt(p0);
        }

        public void getQueuedTaskCount_test_5022()
        {
            ForkJoinTask.getQueuedTaskCount();
        }

        public void getPool_test_5023()
        {
            ForkJoinTask.getPool();
        }

        public void invokeAll_test_5024(Collection p0)
        {
            ForkJoinTask.invokeAll(p0);
        }

        public void invokeAll_test_5025(ForkJoinTask p0, ForkJoinTask p1)
        {
            ForkJoinTask.invokeAll(p0, p1);
        }

        public void invokeAll_test_5026(ForkJoinTask[] p0)
        {
            ForkJoinTask.invokeAll(p0);
        }

        public void getSurplusQueuedTaskCount_test_5027()
        {
            ForkJoinTask.getSurplusQueuedTaskCount();
        }

        public void helpQuiesce_test_5028()
        {
            ForkJoinTask.helpQuiesce();
        }

        public void inForkJoinPool_test_5029()
        {
            ForkJoinTask.inForkJoinPool();
        }

        public void adaptInterruptible_test_5030(Runnable p0)
        {
            ForkJoinTask.adaptInterruptible(p0);
        }

        public void adaptInterruptible_test_5031(Runnable p0, object p1)
        {
            ForkJoinTask.adaptInterruptible(p0, p1);
        }

        public void adaptInterruptible_test_5032(Callable p0)
        {
            ForkJoinTask.adaptInterruptible(p0);
        }
    }
}