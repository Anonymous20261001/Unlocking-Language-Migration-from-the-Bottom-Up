using System;
using System.Collections;

namespace Generated.Test
{
    public class java_lang_invoke_MethodHandlesAutoTest
    {
        public void throwException_test_8874()
        {
            MethodHandles.throwException(typeof(object), typeof(Exception));
        }

        public void lookup_test_8875()
        {
            MethodHandles.lookup();
        }

        public void empty_test_8876()
        {
            MethodHandles.empty(new MethodType());
        }

        public void constant_test_8877()
        {
            MethodHandles.constant(typeof(object), new object());
        }

        public void identity_test_8878()
        {
            MethodHandles.identity(typeof(object));
        }

        public void spreadInvoker_test_8879()
        {
            MethodHandles.spreadInvoker(new MethodType(), 0);
        }

        public void arrayLength_test_8880()
        {
            MethodHandles.arrayLength(typeof(int[]));
        }

        public void varHandleInvoker_test_8881()
        {
            MethodHandles.varHandleInvoker(VarHandle.AccessMode.GET, new MethodType());
        }

        public void publicLookup_test_8882()
        {
            MethodHandles.publicLookup();
        }

        public void tryFinally_test_8883()
        {
            MethodHandles.tryFinally(new MethodHandle(), new MethodHandle());
        }

        public void loop_test_8884()
        {
            MethodHandles.loop(new MethodHandle[0][]);
        }

        public void tableSwitch_test_8885()
        {
            MethodHandles.tableSwitch(new MethodHandle(), new MethodHandle[0]);
        }

        public void arrayConstructor_test_8886()
        {
            MethodHandles.arrayConstructor(typeof(int[]));
        }

        public void exactInvoker_test_8887()
        {
            MethodHandles.exactInvoker(new MethodType());
        }

        public void foldArguments_test_8888()
        {
            MethodHandles.foldArguments(new MethodHandle(), new MethodHandle());
        }

        public void foldArguments_test_8889()
        {
            MethodHandles.foldArguments(new MethodHandle(), 0, new MethodHandle());
        }

        public void invoker_test_8890()
        {
            MethodHandles.invoker(new MethodType());
        }

        public void reflectAs_test_8891()
        {
            MethodHandles.reflectAs(typeof(object), new MethodHandle());
        }

        public void zero_test_8892()
        {
            MethodHandles.zero(typeof(object));
        }

        public void dropArgumentsToMatch_test_8893()
        {
            MethodHandles.dropArgumentsToMatch(new MethodHandle(), 0, new ArrayList(), 0);
        }

        public void dropArguments_test_8894()
        {
            MethodHandles.dropArguments(new MethodHandle(), 0, new ArrayList());
        }

        public void dropArguments_test_8895()
        {
            MethodHandles.dropArguments(new MethodHandle(), 0, new Type[0]);
        }

        public void countedLoop_test_8896()
        {
            MethodHandles.countedLoop(new MethodHandle(), new MethodHandle(), new MethodHandle(), new MethodHandle());
        }

        public void countedLoop_test_8897()
        {
            MethodHandles.countedLoop(new MethodHandle(), new MethodHandle(), new MethodHandle());
        }

        public void permuteArguments_test_8898()
        {
            MethodHandles.permuteArguments(new MethodHandle(), new MethodType(), new int[0]);
        }

        public void filterValue_test_8899()
        {
            MethodHandles.filterValue(new VarHandle(), new MethodHandle(), new MethodHandle());
        }

        public void filterCoordinates_test_8900()
        {
            MethodHandles.filterCoordinates(new VarHandle(), 0, new MethodHandle[0]);
        }

        public void insertCoordinates_test_8901()
        {
            MethodHandles.insertCoordinates(new VarHandle(), 0, new object[0]);
        }

        public void permuteCoordinates_test_8902()
        {
            MethodHandles.permuteCoordinates(new VarHandle(), new ArrayList(), new int[0]);
        }

        public void collectCoordinates_test_8903()
        {
            MethodHandles.collectCoordinates(new VarHandle(), 0, new MethodHandle());
        }

        public void dropCoordinates_test_8904()
        {
            MethodHandles.dropCoordinates(new VarHandle(), 0, new Type[0]);
        }

        public void arrayElementGetter_test_8905()
        {
            MethodHandles.arrayElementGetter(typeof(int[]));
        }

        public void arrayElementSetter_test_8906()
        {
            MethodHandles.arrayElementSetter(typeof(int[]));
        }

        public void arrayElementVarHandle_test_8907()
        {
            MethodHandles.arrayElementVarHandle(typeof(int[]));
        }

        public void byteArrayViewVarHandle_test_8908()
        {
            MethodHandles.byteArrayViewVarHandle(typeof(int[]), ByteOrder.LITTLE_ENDIAN);
        }

        public void byteBufferViewVarHandle_test_8909()
        {
            MethodHandles.byteBufferViewVarHandle(typeof(int[]), ByteOrder.LITTLE_ENDIAN);
        }

        public void varHandleExactInvoker_test_8910()
        {
            MethodHandles.varHandleExactInvoker(VarHandle.AccessMode.GET, new MethodType());
        }

        public void explicitCastArguments_test_8911()
        {
            MethodHandles.explicitCastArguments(new MethodHandle(), new MethodType());
        }

        public void insertArguments_test_8912()
        {
            MethodHandles.insertArguments(new MethodHandle(), 0, new object[0]);
        }

        public void dropReturn_test_8913()
        {
            MethodHandles.dropReturn(new MethodHandle());
        }

        public void filterArguments_test_8914()
        {
            MethodHandles.filterArguments(new MethodHandle(), 0, new MethodHandle[0]);
        }

        public void collectArguments_test_8915()
        {
            MethodHandles.collectArguments(new MethodHandle(), 0, new MethodHandle());
        }

        public void filterReturnValue_test_8916()
        {
            MethodHandles.filterReturnValue(new MethodHandle(), new MethodHandle());
        }

        public void guardWithTest_test_8917()
        {
            MethodHandles.guardWithTest(new MethodHandle(), new MethodHandle(), new MethodHandle());
        }

        public void catchException_test_8918()
        {
            MethodHandles.catchException(new MethodHandle(), typeof(Exception), new MethodHandle());
        }

        public void whileLoop_test_8919()
        {
            MethodHandles.whileLoop(new MethodHandle(), new MethodHandle(), new MethodHandle());
        }

        public void doWhileLoop_test_8920()
        {
            MethodHandles.doWhileLoop(new MethodHandle(), new MethodHandle(), new MethodHandle());
        }

        public void iteratedLoop_test_8921()
        {
            MethodHandles.iteratedLoop(new MethodHandle(), new MethodHandle(), new MethodHandle());
        }
    }

    public static class MethodHandles
    {
        public static MethodHandle throwException(Type returnType, Type exType)
        {
            return new MethodHandle();
        }

        public static Lookup lookup()
        {
            return new Lookup();
        }

        public static MethodHandle empty(MethodType type)
        {
            return new MethodHandle();
        }

        public static MethodHandle constant(Type type, object value)
        {
            return new MethodHandle();
        }

        public static MethodHandle identity(Type type)
        {
            return new MethodHandle();
        }

        public static MethodHandle spreadInvoker(MethodType type, int leadingArgCount)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayLength(Type arrayClass)
        {
            return new MethodHandle();
        }

        public static MethodHandle varHandleInvoker(VarHandle.AccessMode accessMode, MethodType type)
        {
            return new MethodHandle();
        }

        public static Lookup publicLookup()
        {
            return new Lookup();
        }

        public static MethodHandle tryFinally(MethodHandle target, MethodHandle cleanup)
        {
            return new MethodHandle();
        }

        public static MethodHandle loop(MethodHandle[][] clauses)
        {
            return new MethodHandle();
        }

        public static MethodHandle tableSwitch(MethodHandle fallback, MethodHandle[] targets)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayConstructor(Type arrayClass)
        {
            return new MethodHandle();
        }

        public static MethodHandle exactInvoker(MethodType type)
        {
            return new MethodHandle();
        }

        public static MethodHandle foldArguments(MethodHandle target, MethodHandle combiner)
        {
            return new MethodHandle();
        }

        public static MethodHandle foldArguments(MethodHandle target, int pos, MethodHandle combiner)
        {
            return new MethodHandle();
        }

        public static MethodHandle invoker(MethodType type)
        {
            return new MethodHandle();
        }

        public static object reflectAs(Type expected, MethodHandle target)
        {
            return null;
        }

        public static MethodHandle zero(Type type)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArgumentsToMatch(MethodHandle target, int pos, IList argumentTypes, int start)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArguments(MethodHandle target, int pos, IList argumentTypes)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropArguments(MethodHandle target, int pos, Type[] argumentTypes)
        {
            return new MethodHandle();
        }

        public static MethodHandle countedLoop(MethodHandle iterations, MethodHandle init, MethodHandle body, MethodHandle pred)
        {
            return new MethodHandle();
        }

        public static MethodHandle countedLoop(MethodHandle iterations, MethodHandle init, MethodHandle body)
        {
            return new MethodHandle();
        }

        public static MethodHandle permuteArguments(MethodHandle target, MethodType newType, int[] reorder)
        {
            return new MethodHandle();
        }

        public static VarHandle filterValue(VarHandle target, MethodHandle filterToTarget, MethodHandle filterFromTarget)
        {
            return new VarHandle();
        }

        public static VarHandle filterCoordinates(VarHandle target, int pos, MethodHandle[] filters)
        {
            return new VarHandle();
        }

        public static VarHandle insertCoordinates(VarHandle target, int pos, object[] values)
        {
            return new VarHandle();
        }

        public static VarHandle permuteCoordinates(VarHandle target, IList newCoordinates, int[] reorder)
        {
            return new VarHandle();
        }

        public static VarHandle collectCoordinates(VarHandle target, int pos, MethodHandle filter)
        {
            return new VarHandle();
        }

        public static VarHandle dropCoordinates(VarHandle target, int pos, Type[] valueTypes)
        {
            return new VarHandle();
        }

        public static MethodHandle arrayElementGetter(Type arrayClass)
        {
            return new MethodHandle();
        }

        public static MethodHandle arrayElementSetter(Type arrayClass)
        {
            return new MethodHandle();
        }

        public static VarHandle arrayElementVarHandle(Type arrayClass)
        {
            return new VarHandle();
        }

        public static VarHandle byteArrayViewVarHandle(Type viewArrayClass, ByteOrder byteOrder)
        {
            return new VarHandle();
        }

        public static VarHandle byteBufferViewVarHandle(Type viewArrayClass, ByteOrder byteOrder)
        {
            return new VarHandle();
        }

        public static MethodHandle varHandleExactInvoker(VarHandle.AccessMode accessMode, MethodType type)
        {
            return new MethodHandle();
        }

        public static MethodHandle explicitCastArguments(MethodHandle target, MethodType newType)
        {
            return new MethodHandle();
        }

        public static MethodHandle insertArguments(MethodHandle target, int pos, object[] values)
        {
            return new MethodHandle();
        }

        public static MethodHandle dropReturn(MethodHandle target)
        {
            return new MethodHandle();
        }

        public static MethodHandle filterArguments(MethodHandle target, int pos, MethodHandle[] filters)
        {
            return new MethodHandle();
        }

        public static MethodHandle collectArguments(MethodHandle target, int pos, MethodHandle filter)
        {
            return new MethodHandle();
        }

        public static MethodHandle filterReturnValue(MethodHandle target, MethodHandle filter)
        {
            return new MethodHandle();
        }

        public static MethodHandle guardWithTest(MethodHandle test, MethodHandle target, MethodHandle fallback)
        {
            return new MethodHandle();
        }

        public static MethodHandle catchException(MethodHandle target, Type exceptionType, MethodHandle handler)
        {
            return new MethodHandle();
        }

        public static MethodHandle whileLoop(MethodHandle init, MethodHandle pred, MethodHandle body)
        {
            return new MethodHandle();
        }

        public static MethodHandle doWhileLoop(MethodHandle init, MethodHandle body, MethodHandle pred)
        {
            return new MethodHandle();
        }

        public static MethodHandle iteratedLoop(MethodHandle iterator, MethodHandle init, MethodHandle body)
        {
            return new MethodHandle();
        }

        public class Lookup
        {
        }
    }

    public class MethodHandle
    {
    }

    public class MethodType
    {
    }

    public class VarHandle
    {
        public enum AccessMode
        {
            GET,
            SET,
            GET_AND_SET,
            COMPARE_AND_SET,
            COMPARE_AND_EXCHANGE,
            GET_AND_ADD,
            GET_AND_BITWISE_OR,
            GET_AND_BITWISE_AND,
            GET_AND_BITWISE_XOR
        }
    }

    public sealed class ByteOrder
    {
        public static readonly ByteOrder BIG_ENDIAN = new ByteOrder();
        public static readonly ByteOrder LITTLE_ENDIAN = new ByteOrder();

        private ByteOrder()
        {
        }
    }
}