using com.sun.jdi;
using java.util.function;
using jdk.jshell.execution;
using jdk.jshell.spi;
using java.io;

namespace com.sun.jdi
{
    public interface VirtualMachine
    {
    }
}

namespace java.util.function
{
    public interface Consumer<T>
    {
        void accept(T t);
    }

    public interface Consumer : Consumer<object>
    {
    }
}

namespace java.io
{
    public interface ObjectInput
    {
        object readObject();
    }

    public interface ObjectOutput
    {
        void writeObject(object obj);
    }
}

namespace jdk.jshell.spi
{
    public interface ExecutionControl
    {
    }
}

namespace jdk.jshell.execution
{
    public static class Util
    {
        public static void detectJdiExitEvent(VirtualMachine vm, Consumer consumer)
        {
        }

        public static void forwardExecutionControl(ExecutionControl ec, ObjectInput input, ObjectOutput output)
        {
        }
    }
}

namespace Generated.Test
{
    public class jdk_jshell_execution_UtilAutoTest
    {
        public void detectJdiExitEvent_test_13273(VirtualMachine p0, Consumer p1)
        {
            Util.detectJdiExitEvent(p0, p1);
        }

        public void forwardExecutionControl_test_13274(ExecutionControl p0, ObjectInput p1, ObjectOutput p2)
        {
            Util.forwardExecutionControl(p0, p1, p2);
        }
    }
}