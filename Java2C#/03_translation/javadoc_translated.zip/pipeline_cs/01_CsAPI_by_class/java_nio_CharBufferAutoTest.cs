namespace Generated.Test
{
    public interface CharSequence
    {
        int Length { get; }
        char this[int index] { get; }
        CharSequence SubSequence(int start, int end);
    }

    public class CharBuffer
    {
        private readonly char[] _backing;
        private readonly int _offset;
        private readonly int _length;

        private CharBuffer(char[] backing, int offset, int length)
        {
            _backing = backing;
            _offset = offset;
            _length = length;
        }

        public static CharBuffer wrap(CharSequence csq, int start, int end)
        {
            if (csq == null)
                throw new System.ArgumentNullException(nameof(csq));
            if (start < 0 || end < start || end > csq.Length)
                throw new System.IndexOutOfRangeException();

            char[] arr = new char[end - start];
            for (int i = start; i < end; i++)
                arr[i - start] = csq[i];

            return new CharBuffer(arr, 0, arr.Length);
        }

        public static CharBuffer wrap(char[] array)
        {
            if (array == null)
                throw new System.ArgumentNullException(nameof(array));

            return new CharBuffer(array, 0, array.Length);
        }

        public static CharBuffer wrap(CharSequence csq)
        {
            if (csq == null)
                throw new System.ArgumentNullException(nameof(csq));

            return wrap(csq, 0, csq.Length);
        }

        public static CharBuffer wrap(char[] array, int offset, int length)
        {
            if (array == null)
                throw new System.ArgumentNullException(nameof(array));
            if (offset < 0 || length < 0 || offset + length > array.Length)
                throw new System.IndexOutOfRangeException();

            return new CharBuffer(array, offset, length);
        }

        public static CharBuffer allocate(int capacity)
        {
            if (capacity < 0)
                throw new System.ArgumentException("Negative capacity");

            return new CharBuffer(new char[capacity], 0, capacity);
        }
    }

    public class java_nio_CharBufferAutoTest
    {
        public void wrap_test_2230(CharSequence p0, int p1, int p2)
        {
            CharBuffer.wrap(p0, p1, p2);
        }

        public void wrap_test_2231(char[] p0)
        {
            CharBuffer.wrap(p0);
        }

        public void wrap_test_2232(CharSequence p0)
        {
            CharBuffer.wrap(p0);
        }

        public void wrap_test_2233(char[] p0, int p1, int p2)
        {
            CharBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_2234(int p0)
        {
            CharBuffer.allocate(p0);
        }
    }
}