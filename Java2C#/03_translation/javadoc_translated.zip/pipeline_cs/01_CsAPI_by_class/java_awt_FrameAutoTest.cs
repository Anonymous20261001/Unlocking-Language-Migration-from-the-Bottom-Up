namespace Generated.Test
{
    public interface Shape { }
    public class Color { }
    public class Image { }
    public class Rectangle : Shape { }
    public class MenuComponent { }
    public class MenuBar : MenuComponent { }
    public class AccessibleContext { }

    public class Frame
    {
        private string title;
        private MenuBar menuBar;
        private bool resizable = true;
        private int extendedState;
        private bool undecorated;
        private Image iconImage;
        private Rectangle maximizedBounds;
        private int cursorType;
        private Color background;
        private int state;
        private Shape shape;
        private float opacity = 1.0f;

        public Frame() { }

        public string getTitle() { return title; }
        public void setTitle(string p0) { title = p0; }
        public static Frame[] getFrames() { return new Frame[0]; }
        public int getExtendedState() { return extendedState; }
        public MenuBar getMenuBar() { return menuBar; }
        public void setMenuBar(MenuBar p0) { menuBar = p0; }
        public void setResizable(bool p0) { resizable = p0; }
        public bool isResizable() { return resizable; }
        public void setShape(Shape p0) { shape = p0; }
        public void setOpacity(float p0) { opacity = p0; }
        public void setIconImage(Image p0) { iconImage = p0; }
        public void setMaximizedBounds(Rectangle p0) { maximizedBounds = p0; }
        public void setExtendedState(int p0) { extendedState = p0; }
        public bool isUndecorated() { return undecorated; }
        public Image getIconImage() { return iconImage; }
        public Rectangle getMaximizedBounds() { return maximizedBounds; }
        public int getCursorType() { return cursorType; }
        public void setBackground(Color p0) { background = p0; }
        public void addNotify() { }
        public void removeNotify() { }
        public AccessibleContext getAccessibleContext() { return new AccessibleContext(); }
        public void setCursor(int p0) { cursorType = p0; }
        public void setUndecorated(bool p0) { undecorated = p0; }
        public void remove(MenuComponent p0) { }
        public int getState() { return state; }
        public void setState(int p0) { state = p0; }
    }

    public class java_awt_FrameAutoTest
    {
        public void getTitle_test_5045() {
            Frame instance = new Frame();
            instance.getTitle();
        }

        public void setTitle_test_5046(string p0) {
            Frame instance = new Frame();
            instance.setTitle(p0);
        }

        public void getFrames_test_5047() {
            Frame.getFrames();
        }

        public void getExtendedState_test_5048() {
            Frame instance = new Frame();
            instance.getExtendedState();
        }

        public void getMenuBar_test_5049() {
            Frame instance = new Frame();
            instance.getMenuBar();
        }

        public void setMenuBar_test_5050(MenuBar p0) {
            Frame instance = new Frame();
            instance.setMenuBar(p0);
        }

        public void setResizable_test_5051(bool p0) {
            Frame instance = new Frame();
            instance.setResizable(p0);
        }

        public void isResizable_test_5052() {
            Frame instance = new Frame();
            instance.isResizable();
        }

        public void setShape_test_5053(Shape p0) {
            Frame instance = new Frame();
            instance.setShape(p0);
        }

        public void setOpacity_test_5054(float p0) {
            Frame instance = new Frame();
            instance.setOpacity(p0);
        }

        public void setIconImage_test_5055(Image p0) {
            Frame instance = new Frame();
            instance.setIconImage(p0);
        }

        public void setMaximizedBounds_test_5056(Rectangle p0) {
            Frame instance = new Frame();
            instance.setMaximizedBounds(p0);
        }

        public void setExtendedState_test_5057(int p0) {
            Frame instance = new Frame();
            instance.setExtendedState(p0);
        }

        public void isUndecorated_test_5058() {
            Frame instance = new Frame();
            instance.isUndecorated();
        }

        public void getIconImage_test_5059() {
            Frame instance = new Frame();
            instance.getIconImage();
        }

        public void getMaximizedBounds_test_5060() {
            Frame instance = new Frame();
            instance.getMaximizedBounds();
        }

        public void getCursorType_test_5061() {
            Frame instance = new Frame();
            instance.getCursorType();
        }

        public void setBackground_test_5062(Color p0) {
            Frame instance = new Frame();
            instance.setBackground(p0);
        }

        public void addNotify_test_5063() {
            Frame instance = new Frame();
            instance.addNotify();
        }

        public void removeNotify_test_5064() {
            Frame instance = new Frame();
            instance.removeNotify();
        }

        public void getAccessibleContext_test_5065() {
            Frame instance = new Frame();
            instance.getAccessibleContext();
        }

        public void setCursor_test_5066(int p0) {
            Frame instance = new Frame();
            instance.setCursor(p0);
        }

        public void setUndecorated_test_5067(bool p0) {
            Frame instance = new Frame();
            instance.setUndecorated(p0);
        }

        public void remove_test_5068(MenuComponent p0) {
            Frame instance = new Frame();
            instance.remove(p0);
        }

        public void getState_test_5069() {
            Frame instance = new Frame();
            instance.getState();
        }

        public void setState_test_5070(int p0) {
            Frame instance = new Frame();
            instance.setState(p0);
        }
    }
}