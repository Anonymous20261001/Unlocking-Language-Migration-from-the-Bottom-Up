using System.Collections.Generic;

namespace Generated.Test
{
    public class StackWalker
    {
        public enum Option
        {
            RETAIN_CLASS_REFERENCE,
            SHOW_REFLECT_FRAMES,
            SHOW_HIDDEN_FRAMES
        }

        private StackWalker()
        {
        }

        public static StackWalker getInstance(params Option[] options)
        {
            return new StackWalker();
        }

        public static StackWalker getInstance(ICollection<Option> options)
        {
            return new StackWalker();
        }

        public static StackWalker getInstance(ICollection<Option> options, int estimate)
        {
            return new StackWalker();
        }
    }

    public class java_lang_StackWalkerAutoTest
    {
        public void getInstance_test_11454(StackWalker.Option p0)
        {
            StackWalker.getInstance(p0);
        }

        public void getInstance_test_11455(ICollection<StackWalker.Option> p0)
        {
            StackWalker.getInstance(p0);
        }

        public void getInstance_test_11456(ICollection<StackWalker.Option> p0, int p1)
        {
            StackWalker.getInstance(p0, p1);
        }

        public void getInstance_test_11457()
        {
            StackWalker.getInstance();
        }
    }
}