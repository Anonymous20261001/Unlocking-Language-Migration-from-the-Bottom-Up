namespace Generated.Test
{
    using System.Collections.Generic;

    public class CatalogFeatures
    {
        private readonly Dictionary<string, string> features;

        private CatalogFeatures(Dictionary<string, string> features)
        {
            this.features = new Dictionary<string, string>(features ?? new Dictionary<string, string>());
        }

        public static CatalogFeatures defaults()
        {
            return new CatalogFeatures(new Dictionary<string, string>());
        }

        public static Builder builder()
        {
            return new Builder();
        }

        public string get(string feature)
        {
            string value;
            return features.TryGetValue(feature, out value) ? value : null;
        }

        public class Builder
        {
            private readonly Dictionary<string, string> features = new Dictionary<string, string>();

            public Builder with(string feature, string value)
            {
                features[feature] = value;
                return this;
            }

            public CatalogFeatures build()
            {
                return new CatalogFeatures(features);
            }
        }
    }

    public class javax_xml_catalog_CatalogFeaturesAutoTest
    {
        public void builder_test_2080()
        {
            CatalogFeatures.builder();
        }

        public void defaults_test_2081()
        {
            CatalogFeatures.defaults();
        }
    }
}