namespace Generated.Test
{
    public class java_lang_LongAutoTest
    {
        public void numberOfLeadingZeros_test_8143(long p0)
        {
            LongHelper.NumberOfLeadingZeros(p0);
        }

        public void numberOfTrailingZeros_test_8144(long p0)
        {
            LongHelper.NumberOfTrailingZeros(p0);
        }

        public void bitCount_test_8145(long p0)
        {
            LongHelper.BitCount(p0);
        }

        public void min_test_8146(long p0, long p1)
        {
            LongHelper.Min(p0, p1);
        }

        public void max_test_8147(long p0, long p1)
        {
            LongHelper.Max(p0, p1);
        }

        public void signum_test_8148(long p0)
        {
            LongHelper.Signum(p0);
        }

        public void expand_test_8149(long p0, long p1)
        {
            LongHelper.Expand(p0, p1);
        }

        public void compareUnsigned_test_8150(long p0, long p1)
        {
            LongHelper.CompareUnsigned(p0, p1);
        }

        public void divideUnsigned_test_8151(long p0, long p1)
        {
            LongHelper.DivideUnsigned(p0, p1);
        }

        public void remainderUnsigned_test_8152(long p0, long p1)
        {
            LongHelper.RemainderUnsigned(p0, p1);
        }

        public void reverse_test_8153(long p0)
        {
            LongHelper.Reverse(p0);
        }

        public void reverseBytes_test_8154(long p0)
        {
            LongHelper.ReverseBytes(p0);
        }

        public void compress_test_8155(long p0, long p1)
        {
            LongHelper.Compress(p0, p1);
        }

        public void compareTo_test_8156(Long p0, string c0)
        {
            Long instance = new Long(c0);
            instance.CompareTo(p0);
        }

        public void getLong_test_8157(string p0, Long p1)
        {
            LongHelper.GetLong(p0, p1);
        }

        public void getLong_test_8158(string p0)
        {
            LongHelper.GetLong(p0);
        }

        public void getLong_test_8159(string p0, long p1)
        {
            LongHelper.GetLong(p0, p1);
        }

        public void compare_test_8160(long p0, long p1)
        {
            LongHelper.Compare(p0, p1);
        }

        public void byteValue_test_8161(string c0)
        {
            Long instance = new Long(c0);
            instance.ByteValue();
        }

        public void shortValue_test_8162(string c0)
        {
            Long instance = new Long(c0);
            instance.ShortValue();
        }

        public void intValue_test_8163(string c0)
        {
            Long instance = new Long(c0);
            instance.IntValue();
        }

        public void longValue_test_8164(string c0)
        {
            Long instance = new Long(c0);
            instance.LongValue();
        }

        public void floatValue_test_8165(string c0)
        {
            Long instance = new Long(c0);
            instance.FloatValue();
        }

        public void doubleValue_test_8166(string c0)
        {
            Long instance = new Long(c0);
            instance.DoubleValue();
        }

        public void valueOf_test_8167(long p0)
        {
            LongHelper.ValueOf(p0);
        }

        public void valueOf_test_8168(string p0)
        {
            LongHelper.ValueOf(p0);
        }

        public void valueOf_test_8169(string p0, int p1)
        {
            LongHelper.ValueOf(p0, p1);
        }

        public void toHexString_test_8170(long p0)
        {
            LongHelper.ToHexString(p0);
        }

        public void decode_test_8171(string p0)
        {
            LongHelper.Decode(p0);
        }

        public void resolveConstantDesc_test_8172(MethodHandles.Lookup p0, string c0)
        {
            Long instance = new Long(c0);
            instance.ResolveConstantDesc(p0);
        }

        public void describeConstable_test_8173(string c0)
        {
            Long instance = new Long(c0);
            instance.DescribeConstable();
        }

        public void sum_test_8174(long p0, long p1)
        {
            LongHelper.Sum(p0, p1);
        }

        public void toUnsignedString_test_8175(long p0)
        {
            LongHelper.ToUnsignedString(p0);
        }

        public void toUnsignedString_test_8176(long p0, int p1)
        {
            LongHelper.ToUnsignedString(p0, p1);
        }

        public void toOctalString_test_8177(long p0)
        {
            LongHelper.ToOctalString(p0);
        }

        public void toBinaryString_test_8178(long p0)
        {
            LongHelper.ToBinaryString(p0);
        }

        public void highestOneBit_test_8179(long p0)
        {
            LongHelper.HighestOneBit(p0);
        }

        public void lowestOneBit_test_8180(long p0)
        {
            LongHelper.LowestOneBit(p0);
        }

        public void rotateLeft_test_8181(long p0, int p1)
        {
            LongHelper.RotateLeft(p0, p1);
        }

        public void rotateRight_test_8182(long p0, int p1)
        {
            LongHelper.RotateRight(p0, p1);
        }

        public void parseLong_test_8183(string p0)
        {
            LongHelper.ParseLong(p0);
        }

        public void parseLong_test_8184(string p0, int p1)
        {
            LongHelper.ParseLong(p0, p1);
        }

        public void parseLong_test_8185(CharSequence p0, int p1, int p2, int p3)
        {
            LongHelper.ParseLong(p0, p1, p2, p3);
        }

        public void parseUnsignedLong_test_8186(string p0)
        {
            LongHelper.ParseUnsignedLong(p0);
        }

        public void parseUnsignedLong_test_8187(string p0, int p1)
        {
            LongHelper.ParseUnsignedLong(p0, p1);
        }

        public void parseUnsignedLong_test_8188(CharSequence p0, int p1, int p2, int p3)
        {
            LongHelper.ParseUnsignedLong(p0, p1, p2, p3);
        }
    }

    public class Long
    {
        private long value;

        public Long(string s)
        {
            value = long.Parse(s);
        }

        public Long(long v)
        {
            value = v;
        }

        public int CompareTo(Long other)
        {
            return value.CompareTo(other.value);
        }

        public byte ByteValue()
        {
            return (byte)value;
        }

        public short ShortValue()
        {
            return (short)value;
        }

        public int IntValue()
        {
            return (int)value;
        }

        public long LongValue()
        {
            return value;
        }

        public float FloatValue()
        {
            return (float)value;
        }

        public double DoubleValue()
        {
            return (double)value;
        }

        public object ResolveConstantDesc(MethodHandles.Lookup lookup)
        {
            return this;
        }

        public object DescribeConstable()
        {
            return this;
        }
    }

    public static class LongHelper
    {
        public static int NumberOfLeadingZeros(long i)
        {
            if (i == 0) return 64;
            int n = 0;
            for (int bit = 63; bit >= 0; bit--)
            {
                if ((i & (1L << bit)) != 0) break;
                n++;
            }
            return n;
        }

        public static int NumberOfTrailingZeros(long i)
        {
            if (i == 0) return 64;
            int n = 0;
            while ((i & 1L) == 0)
            {
                n++;
                i >>= 1;
            }
            return n;
        }

        public static int BitCount(long i)
        {
            int count = 0;
            while (i != 0)
            {
                count += (int)(i & 1L);
                i >>= 1;
            }
            return count;
        }

        public static long Min(long a, long b)
        {
            return System.Math.Min(a, b);
        }

        public static long Max(long a, long b)
        {
            return System.Math.Max(a, b);
        }

        public static int Signum(long i)
        {
            return System.Math.Sign(i);
        }

        public static long Expand(long i, long mask)
        {
            long result = 0;
            int bit = 0;
            for (int m = 0; m < 64; m++)
            {
                if ((mask & (1L << m)) != 0)
                {
                    if ((i & (1L << bit)) != 0)
                        result |= (1L << m);
                    bit++;
                }
            }
            return result;
        }

        public static int CompareUnsigned(long x, long y)
        {
            return (x < y) ? -1 : ((x == y) ? 0 : 1);
        }

        public static long DivideUnsigned(long dividend, long divisor)
        {
            if (divisor == 0) throw new System.DivideByZeroException();
            return (long)((ulong)dividend / (ulong)divisor);
        }

        public static long RemainderUnsigned(long dividend, long divisor)
        {
            if (divisor == 0) throw new System.DivideByZeroException();
            return (long)((ulong)dividend % (ulong)divisor);
        }

        public static long Reverse(long i)
        {
            long result = 0;
            for (int bit = 0; bit < 64; bit++)
            {
                if ((i & (1L << bit)) != 0)
                    result |= (1L << (63 - bit));
            }
            return result;
        }

        public static long ReverseBytes(long i)
        {
            return System.Net.IPAddress.HostToNetworkOrder(i);
        }

        public static long Compress(long i, long mask)
        {
            long result = 0;
            int bit = 0;
            for (int m = 0; m < 64; m++)
            {
                if ((mask & (1L << m)) != 0)
                {
                    if ((i & (1L << m)) != 0)
                        result |= (1L << bit);
                    bit++;
                }
            }
            return result;
        }

        public static Long GetLong(string nm, Long val)
        {
            string value = System.Environment.GetEnvironmentVariable(nm);
            if (value == null) return val;
            try
            {
                return new Long(value);
            }
            catch
            {
                return val;
            }
        }

        public static Long GetLong(string nm)
        {
            return GetLong(nm, null);
        }

        public static Long GetLong(string nm, long val)
        {
            return GetLong(nm, new Long(val));
        }

        public static int Compare(long x, long y)
        {
            return x.CompareTo(y);
        }

        public static Long ValueOf(long i)
        {
            return new Long(i);
        }

        public static Long ValueOf(string s)
        {
            return new Long(s);
        }

        public static Long ValueOf(string s, int radix)
        {
            return new Long(System.Convert.ToString(System.Convert.ToInt64(s, radix)));
        }

        public static string ToHexString(long i)
        {
            return System.Convert.ToString(i, 16);
        }

        public static Long Decode(string nm)
        {
            if (nm.StartsWith("0x") || nm.StartsWith("0X"))
                return new Long(System.Convert.ToInt64(nm.Substring(2), 16));
            if (nm.StartsWith("#"))
                return new Long(System.Convert.ToInt64(nm.Substring(1), 16));
            if (nm.StartsWith("0") && nm.Length > 1)
                return new Long(System.Convert.ToInt64(nm.Substring(1), 8));
            return new Long(nm);
        }

        public static long Sum(long a, long b)
        {
            return a + b;
        }

        public static string ToUnsignedString(long i)
        {
            return ((ulong)i).ToString();
        }

        public static string ToUnsignedString(long i, int radix)
        {
            return System.Convert.ToString((long)((ulong)i), radix);
        }

        public static string ToOctalString(long i)
        {
            return System.Convert.ToString(i, 8);
        }

        public static string ToBinaryString(long i)
        {
            return System.Convert.ToString(i, 2);
        }

        public static long HighestOneBit(long i)
        {
            if (i == 0) return 0;
            long highest = 1L << 63;
            while ((i & highest) == 0)
                highest >>= 1;
            return highest;
        }

        public static long LowestOneBit(long i)
        {
            return i & (-i);
        }

        public static long RotateLeft(long i, int distance)
        {
            distance &= 63;
            return (i << distance) | (long)((ulong)i >> (64 - distance));
        }

        public static long RotateRight(long i, int distance)
        {
            distance &= 63;
            return (long)((ulong)i >> distance) | (i << (64 - distance));
        }

        public static long ParseLong(string s)
        {
            return long.Parse(s);
        }

        public static long ParseLong(string s, int radix)
        {
            return System.Convert.ToInt64(s, radix);
        }

        public static long ParseLong(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            string str = s.ToString().Substring(beginIndex, endIndex - beginIndex);
            return System.Convert.ToInt64(str, radix);
        }

        public static long ParseUnsignedLong(string s)
        {
            return (long)ulong.Parse(s);
        }

        public static long ParseUnsignedLong(string s, int radix)
        {
            return (long)System.Convert.ToUInt64(s, radix);
        }

        public static long ParseUnsignedLong(CharSequence s, int beginIndex, int endIndex, int radix)
        {
            string str = s.ToString().Substring(beginIndex, endIndex - beginIndex);
            return (long)System.Convert.ToUInt64(str, radix);
        }
    }

    public class CharSequence
    {
        private string value;

        public CharSequence(string s)
        {
            value = s;
        }

        public override string ToString()
        {
            return value;
        }
    }

    public class MethodHandles
    {
        public class Lookup
        {
        }
    }
}