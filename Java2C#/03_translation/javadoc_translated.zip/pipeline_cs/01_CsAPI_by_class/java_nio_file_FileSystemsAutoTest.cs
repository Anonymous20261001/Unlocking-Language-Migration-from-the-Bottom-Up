```csharp
using System;

namespace Generated.Test
{
    public class java_nio_file_FileSystemsAutoTest
    {
        public void getDefault_test_4779()
        {
            FileSystems.getDefault();
        }

        public void getFileSystem_test_4780(Uri p0)
        {
            FileSystems.getFileSystem(p0);
        }
    }

    public class FileSystem
    {
        private FileSystem() { }

        internal static readonly FileSystem Default = new FileSystem();
    }

    public static class FileSystems
    {
        public static FileSystem getDefault()
        {
            return FileSystem.Default;
        }

        public static FileSystem getFileSystem(Uri uri)
        {
            if (uri == null)
            {
                throw new ArgumentNullException("uri");
            }

            if (!uri.IsAbsoluteUri ||
                !string.Equals(uri.Scheme, Uri.UriSchemeFile, StringComparison.OrdinalIgnoreCase))
            {
                throw new FileSystemNotFoundException(
                    "A FileSystem for the specified URI could not be found.");
            }

            return getDefault();
        }
    }

    public class FileSystemNotFoundException : Exception
    {
        public FileSystemNotFoundException(string message) : base(message) { }
    }
}
```