namespace Generated.Test
{
    public class javax_naming_spi_NamingManagerAutoTest
    {
        public void hasInitialContextFactoryBuilder_test_9513()
        {
            NamingManager.hasInitialContextFactoryBuilder();
        }
    }

    public static class NamingManager
    {
        private static bool initialContextFactoryBuilder;

        public static bool hasInitialContextFactoryBuilder()
        {
            return initialContextFactoryBuilder;
        }
    }
}