using System;

namespace Generated.Test
{
    public interface TemporalAccessor
    {
    }

    public class ZoneId
    {
    }

    public class ZoneOffset : ZoneId
    {
    }

    public interface Chronology
    {
    }

    public interface TemporalUnit
    {
    }

    public class LocalDate
    {
    }

    public class LocalTime
    {
    }

    public interface TemporalQuery<T>
    {
        T QueryFrom(TemporalAccessor temporal);
    }

    internal sealed class TemporalQueryImpl<T> : TemporalQuery<T>
    {
        private readonly Func<TemporalAccessor, T> _query;

        public TemporalQueryImpl(Func<TemporalAccessor, T> query)
        {
            _query = query;
        }

        public T QueryFrom(TemporalAccessor temporal) => _query(temporal);
    }

    public static class TemporalQueries
    {
        public static TemporalQuery<ZoneOffset> offset()
        {
            return new TemporalQueryImpl<ZoneOffset>(temporal => null);
        }

        public static TemporalQuery<ZoneId> zone()
        {
            return new TemporalQueryImpl<ZoneId>(temporal => null);
        }

        public static TemporalQuery<TemporalUnit> precision()
        {
            return new TemporalQueryImpl<TemporalUnit>(temporal => null);
        }

        public static TemporalQuery<Chronology> chronology()
        {
            return new TemporalQueryImpl<Chronology>(temporal => null);
        }

        public static TemporalQuery<ZoneId> zoneId()
        {
            return new TemporalQueryImpl<ZoneId>(temporal => null);
        }

        public static TemporalQuery<LocalDate> localDate()
        {
            return new TemporalQueryImpl<LocalDate>(temporal => null);
        }

        public static TemporalQuery<LocalTime> localTime()
        {
            return new TemporalQueryImpl<LocalTime>(temporal => null);
        }
    }

    public class java_time_temporal_TemporalQueriesAutoTest
    {
        public void offset_test_12534()
        {
            TemporalQueries.offset();
        }

        public void zone_test_12535()
        {
            TemporalQueries.zone();
        }

        public void precision_test_12536()
        {
            TemporalQueries.precision();
        }

        public void chronology_test_12537()
        {
            TemporalQueries.chronology();
        }

        public void zoneId_test_12538()
        {
            TemporalQueries.zoneId();
        }

        public void localDate_test_12539()
        {
            TemporalQueries.localDate();
        }

        public void localTime_test_12540()
        {
            TemporalQueries.localTime();
        }
    }
}