using System;

namespace java.awt
{
    public sealed class Desktop
    {
        private static readonly Desktop instance = new Desktop();

        private Desktop()
        {
        }

        public static Desktop getDesktop()
        {
            if (!isDesktopSupported())
            {
                throw new InvalidOperationException("Desktop is not supported on this platform");
            }
            return instance;
        }

        public static bool isDesktopSupported()
        {
            return true;
        }
    }
}

namespace Generated.Test
{
    using java.awt;

    public class java_awt_DesktopAutoTest
    {
        public void getDesktop_test_4108()
        {
            Desktop.getDesktop();
        }

        public void isDesktopSupported_test_4109()
        {
            Desktop.isDesktopSupported();
        }
    }
}