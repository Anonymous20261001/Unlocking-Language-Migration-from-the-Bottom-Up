using System;

namespace Generated.Test
{
    public sealed class OptionalLong
    {
        private readonly bool hasValue;
        private readonly long value;

        private OptionalLong()
        {
        }

        private OptionalLong(long value)
        {
            this.value = value;
            this.hasValue = true;
        }

        public static OptionalLong Of(long value)
        {
            return new OptionalLong(value);
        }

        public static OptionalLong Empty()
        {
            return new OptionalLong();
        }

        public bool IsPresent()
        {
            return hasValue;
        }

        public long GetAsLong()
        {
            if (!hasValue)
            {
                throw new InvalidOperationException("No value present");
            }
            return value;
        }

        public long OrElse(long other)
        {
            return hasValue ? value : other;
        }
    }

    public class java_util_OptionalLongAutoTest
    {
        public void of_test_9696(long p0)
        {
            OptionalLong.Of(p0);
        }

        public void empty_test_9697()
        {
            OptionalLong.Empty();
        }
    }
}