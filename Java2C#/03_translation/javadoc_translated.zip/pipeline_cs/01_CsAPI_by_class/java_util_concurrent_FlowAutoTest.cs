using System;

namespace Generated.Test
{
    public static class Flow
    {
        public static int defaultBufferSize()
        {
            return 256;
        }
    }

    public class java_util_concurrent_FlowAutoTest
    {
        public void defaultBufferSize_test_4895()
        {
            Flow.defaultBufferSize();
        }
    }
}