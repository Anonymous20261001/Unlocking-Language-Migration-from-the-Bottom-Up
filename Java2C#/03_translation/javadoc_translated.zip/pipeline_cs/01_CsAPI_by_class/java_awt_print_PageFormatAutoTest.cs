using System;

namespace Generated.Test
{
    public class Paper
    {
        private double width;
        private double height;
        private double imageableX;
        private double imageableY;
        private double imageableWidth;
        private double imageableHeight;

        public Paper()
        {
            width = 612.0;
            height = 792.0;
            imageableX = 72.0;
            imageableY = 72.0;
            imageableWidth = 468.0;
            imageableHeight = 648.0;
        }

        public double getWidth()
        {
            return width;
        }

        public double getHeight()
        {
            return height;
        }

        public void setSize(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public double getImageableX()
        {
            return imageableX;
        }

        public double getImageableY()
        {
            return imageableY;
        }

        public double getImageableWidth()
        {
            return imageableWidth;
        }

        public double getImageableHeight()
        {
            return imageableHeight;
        }

        public void setImageableArea(double x, double y, double width, double height)
        {
            this.imageableX = x;
            this.imageableY = y;
            this.imageableWidth = width;
            this.imageableHeight = height;
        }
    }

    public class PageFormat
    {
        public const int LANDSCAPE = 0;
        public const int PORTRAIT = 1;
        public const int REVERSE_LANDSCAPE = 2;

        private Paper paper;
        private int orientation;

        public PageFormat()
        {
            paper = new Paper();
            orientation = PORTRAIT;
        }

        public double getWidth()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getWidth();
            }
            else
            {
                return paper.getHeight();
            }
        }

        public double getHeight()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getHeight();
            }
            else
            {
                return paper.getWidth();
            }
        }

        public int getOrientation()
        {
            return orientation;
        }

        public double[] getMatrix()
        {
            double[] matrix = new double[6];
            double x = getImageableX();
            double y = getImageableY();
            double w = getImageableWidth();
            double h = getImageableHeight();

            if (orientation == PORTRAIT)
            {
                matrix[0] = 1.0;
                matrix[1] = 0.0;
                matrix[2] = 0.0;
                matrix[3] = 1.0;
                matrix[4] = x;
                matrix[5] = y;
            }
            else if (orientation == LANDSCAPE)
            {
                matrix[0] = 0.0;
                matrix[1] = -1.0;
                matrix[2] = 1.0;
                matrix[3] = 0.0;
                matrix[4] = y;
                matrix[5] = w + x;
            }
            else
            {
                matrix[0] = 0.0;
                matrix[1] = 1.0;
                matrix[2] = -1.0;
                matrix[3] = 0.0;
                matrix[4] = h + y;
                matrix[5] = x;
            }

            return matrix;
        }

        public void setOrientation(int orientation)
        {
            if (orientation != LANDSCAPE && orientation != PORTRAIT && orientation != REVERSE_LANDSCAPE)
            {
                throw new ArgumentException("Invalid orientation");
            }
            this.orientation = orientation;
        }

        public double getImageableX()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getImageableX();
            }
            else
            {
                return paper.getImageableY();
            }
        }

        public double getImageableY()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getImageableY();
            }
            else
            {
                return paper.getImageableX();
            }
        }

        public double getImageableWidth()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getImageableWidth();
            }
            else
            {
                return paper.getImageableHeight();
            }
        }

        public double getImageableHeight()
        {
            if (orientation == PORTRAIT)
            {
                return paper.getImageableHeight();
            }
            else
            {
                return paper.getImageableWidth();
            }
        }

        public Paper getPaper()
        {
            return paper;
        }

        public void setPaper(Paper paper)
        {
            this.paper = paper;
        }
    }

    public class java_awt_print_PageFormatAutoTest
    {
        public void getWidth_test_9735()
        {
            PageFormat instance = new PageFormat();
            instance.getWidth();
        }

        public void getHeight_test_9736()
        {
            PageFormat instance = new PageFormat();
            instance.getHeight();
        }

        public void getOrientation_test_9737()
        {
            PageFormat instance = new PageFormat();
            instance.getOrientation();
        }

        public void getMatrix_test_9738()
        {
            PageFormat instance = new PageFormat();
            instance.getMatrix();
        }

        public void setOrientation_test_9739(int p0)
        {
            PageFormat instance = new PageFormat();
            instance.setOrientation(p0);
        }

        public void getImageableY_test_9740()
        {
            PageFormat instance = new PageFormat();
            instance.getImageableY();
        }

        public void getImageableHeight_test_9741()
        {
            PageFormat instance = new PageFormat();
            instance.getImageableHeight();
        }

        public void getImageableX_test_9742()
        {
            PageFormat instance = new PageFormat();
            instance.getImageableX();
        }

        public void getImageableWidth_test_9743()
        {
            PageFormat instance = new PageFormat();
            instance.getImageableWidth();
        }

        public void getPaper_test_9744()
        {
            PageFormat instance = new PageFormat();
            instance.getPaper();
        }

        public void setPaper_test_9745(Paper p0)
        {
            PageFormat instance = new PageFormat();
            instance.setPaper(p0);
        }
    }
}