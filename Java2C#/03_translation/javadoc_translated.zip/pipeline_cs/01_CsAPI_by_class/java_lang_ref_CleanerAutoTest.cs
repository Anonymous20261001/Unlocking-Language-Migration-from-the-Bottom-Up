using System;
using System.Threading;

namespace Generated.Test
{
    public interface Runnable
    {
        void Run();
    }

    public interface ThreadFactory
    {
        Thread NewThread(Runnable r);
    }

    public class Cleaner
    {
        public static Cleaner Create()
        {
            return new Cleaner();
        }

        public static Cleaner Create(ThreadFactory threadFactory)
        {
            if (threadFactory == null)
            {
                throw new ArgumentNullException("threadFactory");
            }
            return new Cleaner(threadFactory);
        }

        public static Cleaner create()
        {
            return Create();
        }

        public static Cleaner create(ThreadFactory threadFactory)
        {
            return Create(threadFactory);
        }

        private Cleaner()
        {
        }

        private Cleaner(ThreadFactory threadFactory)
        {
            Runnable runnable = new NoOpRunnable();
            threadFactory.NewThread(runnable);
        }

        private sealed class NoOpRunnable : Runnable
        {
            public void Run()
            {
            }
        }
    }

    public class java_lang_ref_CleanerAutoTest
    {
        public void create_test_2319()
        {
            Cleaner.create();
        }

        public void create_test_2320(ThreadFactory p0)
        {
            Cleaner.create(p0);
        }
    }
}