namespace Generated.Test
{
    public interface Guard
    {
        void checkGuard(object obj);
    }

    public class GuardedObject
    {
        private readonly object obj;
        private readonly Guard guard;

        public GuardedObject(object obj, Guard guard)
        {
            this.obj = obj;
            this.guard = guard;
        }

        public object getObject()
        {
            if (guard != null)
            {
                guard.checkGuard(obj);
            }
            return obj;
        }
    }

    public class java_security_GuardedObjectAutoTest
    {
        public void getObject_test_5247(object c0, Guard c1)
        {
            GuardedObject instance = new GuardedObject(c0, c1);
            instance.getObject();
        }
    }
}