namespace Generated.Test
{
    public class OptionalDouble
    {
        private readonly bool _hasValue;
        private readonly double _value;

        private OptionalDouble(double value, bool hasValue)
        {
            _value = value;
            _hasValue = hasValue;
        }

        public static OptionalDouble of(double value)
        {
            return new OptionalDouble(value, true);
        }

        public static OptionalDouble empty()
        {
            return new OptionalDouble(default(double), false);
        }

        public bool isPresent()
        {
            return _hasValue;
        }

        public double getAsDouble()
        {
            if (!_hasValue)
            {
                throw new System.InvalidOperationException("No value present");
            }

            return _value;
        }

        public double orElse(double other)
        {
            return _hasValue ? _value : other;
        }
    }

    public class java_util_OptionalDoubleAutoTest
    {
        public void of_test_9692(double p0)
        {
            OptionalDouble.of(p0);
        }

        public void empty_test_9693()
        {
            OptionalDouble.empty();
        }
    }
}