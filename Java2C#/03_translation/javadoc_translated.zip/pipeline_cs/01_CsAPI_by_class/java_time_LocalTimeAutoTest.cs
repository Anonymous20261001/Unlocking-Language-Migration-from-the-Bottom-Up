using System;

namespace Generated.Test
{
    using CharSequence = System.String;

    public sealed class LocalTime : TemporalAccessor
    {
        private const long NanosPerDay = 86400L * 1_000_000_000L;
        private readonly long _nanoOfDay;

        private LocalTime(long nanoOfDay)
        {
            _nanoOfDay = nanoOfDay;
        }

        public int Hour => (int)(_nanoOfDay / 3_600_000_000L % 24);
        public int Minute => (int)(_nanoOfDay / 60_000_000L % 60);
        public int Second => (int)(_nanoOfDay / 1_000_000_000L % 60);
        public int Nano => (int)(_nanoOfDay % 1_000_000_000L);

        public static LocalTime of(int hour, int minute) => of(hour, minute, 0, 0);

        public static LocalTime of(int hour, int minute, int second) => of(hour, minute, second, 0);

        public static LocalTime of(int hour, int minute, int second, int nanoOfSecond)
        {
            if (hour < 0 || hour > 23) throw new ArgumentOutOfRangeException(nameof(hour));
            if (minute < 0 || minute > 59) throw new ArgumentOutOfRangeException(nameof(minute));
            if (second < 0 || second > 59) throw new ArgumentOutOfRangeException(nameof(second));
            if (nanoOfSecond < 0 || nanoOfSecond > 999_999_999) throw new ArgumentOutOfRangeException(nameof(nanoOfSecond));

            long nanos = ((hour * 60L + minute) * 60L + second) * 1_000_000_000L + nanoOfSecond;
            return new LocalTime(nanos);
        }

        public static LocalTime ofNanoOfDay(long nanoOfDay)
        {
            if (nanoOfDay < 0 || nanoOfDay >= NanosPerDay) throw new ArgumentOutOfRangeException(nameof(nanoOfDay));
            return new LocalTime(nanoOfDay);
        }

        public static LocalTime ofSecondOfDay(long secondOfDay)
        {
            if (secondOfDay < 0 || secondOfDay >= 86400L) throw new ArgumentOutOfRangeException(nameof(secondOfDay));
            return ofNanoOfDay(secondOfDay * 1_000_000_000L);
        }

        public static LocalTime now() => now(Clock.system());

        public static LocalTime now(Clock clock)
        {
            if (clock == null) throw new ArgumentNullException(nameof(clock));
            return ofInstant(clock.instant(), clock.zone());
        }

        public static LocalTime now(ZoneId zone)
        {
            if (zone == null) throw new ArgumentNullException(nameof(zone));
            return ofInstant(Instant.now(), zone);
        }

        public static LocalTime ofInstant(Instant instant, ZoneId zone)
        {
            if (instant == null) throw new ArgumentNullException(nameof(instant));
            if (zone == null) throw new ArgumentNullException(nameof(zone));

            long epochSecond = instant.EpochSecond;
            int nano = instant.Nano;
            long epochDay = FloorDiv(epochSecond, 86400L);
            long secsOfDay = epochSecond - epochDay * 86400L;
            long nanoOfDay = secsOfDay * 1_000_000_000L + nano;
            return new LocalTime(nanoOfDay);
        }

        public static LocalTime from(TemporalAccessor temporal)
        {
            if (temporal == null) throw new ArgumentNullException(nameof(temporal));
            return of(temporal.Hour, temporal.Minute, temporal.Second, temporal.Nano);
        }

        public static LocalTime parse(CharSequence text) => parse(text, DateTimeFormatter.ISO_LOCAL_TIME);

        public static LocalTime parse(CharSequence text, DateTimeFormatter formatter)
        {
            if (text == null) throw new ArgumentNullException(nameof(text));
            if (formatter == null) throw new ArgumentNullException(nameof(formatter));
            return formatter.parse(text);
        }

        private static long FloorDiv(long x, long y)
        {
            long q = x / y;
            if ((x % y != 0) && ((x ^ y) < 0))
            {
                q--;
            }
            return q;
        }
    }

    public interface TemporalAccessor
    {
        int Hour { get; }
        int Minute { get; }
        int Second { get; }
        int Nano { get; }
    }

    public sealed class DateTimeFormatter
    {
        public static DateTimeFormatter ISO_LOCAL_TIME { get; } = new DateTimeFormatter("HH:mm:ss");

        private readonly string _pattern;

        public DateTimeFormatter(string pattern)
        {
            _pattern = pattern ?? throw new ArgumentNullException(nameof(pattern));
        }

        public LocalTime parse(string text)
        {
            if (text == null) throw new ArgumentNullException(nameof(text));

            string s = text.Trim();
            string[] parts = s.Split(':');
            if (parts.Length < 2 || parts.Length > 3) throw new FormatException("Invalid time format: " + text);

            int hour = int.Parse(parts[0]);
            int minute = int.Parse(parts[1]);
            int second = 0;
            int nano = 0;

            if (parts.Length == 3 && parts[2].Length > 0)
            {
                string secPart = parts[2];
                int dotIndex = secPart.IndexOf('.');
                if (dotIndex >= 0)
                {
                    string sec = secPart.Substring(0, dotIndex);
                    string fraction = secPart.Substring(dotIndex + 1);
                    if (sec.Length > 0) second = int.Parse(sec);
                    if (fraction.Length > 9) fraction = fraction.Substring(0, 9);
                    fraction = fraction.PadRight(9, '0');
                    nano = int.Parse(fraction);
                }
                else
                {
                    second = int.Parse(secPart);
                }
            }

            return LocalTime.of(hour, minute, second, nano);
        }
    }

    public sealed class Clock
    {
        private readonly Instant _instant;
        private readonly ZoneId _zone;

        public Clock(Instant instant, ZoneId zone)
        {
            _instant = instant ?? throw new ArgumentNullException(nameof(instant));
            _zone = zone ?? throw new ArgumentNullException(nameof(zone));
        }

        public static Clock system() => new Clock(Instant.now(), ZoneId.utc());

        public Instant instant() => _instant;
        public ZoneId zone() => _zone;
    }

    public sealed class ZoneId
    {
        private readonly string _id;

        public ZoneId(string id)
        {
            _id = id ?? throw new ArgumentNullException(nameof(id));
        }

        public static ZoneId utc() => new ZoneId("UTC");

        public string id() => _id;
        public override string ToString() => _id;
    }

    public sealed class Instant
    {
        private static readonly DateTime UnixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        public long EpochSecond { get; }
        public int Nano { get; }

        public Instant(long epochSecond, int nano)
        {
            if (nano < 0 || nano >= 1_000_000_000) throw new ArgumentOutOfRangeException(nameof(nano));
            EpochSecond = epochSecond;
            Nano = nano;
        }

        public static Instant now()
        {
            DateTime utc = DateTime.UtcNow;
            long ticks = utc.Ticks - UnixEpoch.Ticks;
            long seconds = ticks / TimeSpan.TicksPerSecond;
            int nano = (int)((ticks % TimeSpan.TicksPerSecond) * 100);
            return new Instant(seconds, nano);
        }
    }

    public class java_time_LocalTimeAutoTest
    {
        public void of_test_8080(int p0, int p1, int p2, int p3)
        {
            LocalTime.of(p0, p1, p2, p3);
        }

        public void of_test_8081(int p0, int p1)
        {
            LocalTime.of(p0, p1);
        }

        public void of_test_8082(int p0, int p1, int p2)
        {
            LocalTime.of(p0, p1, p2);
        }

        public void from_test_8083(TemporalAccessor p0)
        {
            LocalTime.from(p0);
        }

        public void parse_test_8084(CharSequence p0)
        {
            LocalTime.parse(p0);
        }

        public void parse_test_8085(CharSequence p0, DateTimeFormatter p1)
        {
            LocalTime.parse(p0, p1);
        }

        public void now_test_8086()
        {
            LocalTime.now();
        }

        public void now_test_8087(Clock p0)
        {
            LocalTime.now(p0);
        }

        public void now_test_8088(ZoneId p0)
        {
            LocalTime.now(p0);
        }

        public void ofInstant_test_8089(Instant p0, ZoneId p1)
        {
            LocalTime.ofInstant(p0, p1);
        }

        public void ofNanoOfDay_test_8090(long p0)
        {
            LocalTime.ofNanoOfDay(p0);
        }

        public void ofSecondOfDay_test_8091(long p0)
        {
            LocalTime.ofSecondOfDay(p0);
        }
    }
}