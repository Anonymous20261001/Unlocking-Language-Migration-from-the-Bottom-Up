using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class java_awt_font_NumericShaperAutoTest
    {
        public void getShaper_test_9579(int p0)
        {
            NumericShaper.getShaper(p0);
        }

        public void getShaper_test_9580(NumericShaper.Range p0)
        {
            NumericShaper.getShaper(p0);
        }

        public void getContextualShaper_test_9581(ISet<NumericShaper.Range> p0)
        {
            NumericShaper.getContextualShaper(p0);
        }

        public void getContextualShaper_test_9582(int p0)
        {
            NumericShaper.getContextualShaper(p0);
        }

        public void getContextualShaper_test_9583(int p0, int p1)
        {
            NumericShaper.getContextualShaper(p0, p1);
        }

        public void getContextualShaper_test_9584(ISet<NumericShaper.Range> p0, NumericShaper.Range p1)
        {
            NumericShaper.getContextualShaper(p0, p1);
        }
    }

    public class NumericShaper
    {
        public enum Range
        {
            ARABIC,
            ARABIC_EXTENDED,
            BALINESE,
            BENGALI,
            CHAM,
            DEVANAGARI,
            EASTERN_ARABIC,
            ETHIOPIC,
            GUJARATI,
            GURMUKHI,
            KANNADA,
            KHMER,
            LAO,
            LATIN,
            LEPCHA,
            LIMBU,
            MALAYALAM,
            MEETEI_MAYEK,
            MONGOLIAN,
            MYANMAR,
            MYANMAR_SHAN,
            NEW_TAI_LUE,
            NKO,
            ORIYA,
            OSMANYA,
            PHAGS_PA,
            SAURASHTRA,
            SINHALA,
            SUNDANESE,
            TAI_THAM,
            TAMIL,
            TELUGU,
            THAI,
            TIBETAN,
            TIFINAGH,
            VAI
        }

        private NumericShaper()
        {
        }

        public static NumericShaper getShaper(int p0)
        {
            return new NumericShaper();
        }

        public static NumericShaper getShaper(Range p0)
        {
            return new NumericShaper();
        }

        public static NumericShaper getContextualShaper(ISet<Range> p0)
        {
            return new NumericShaper();
        }

        public static NumericShaper getContextualShaper(int p0)
        {
            return new NumericShaper();
        }

        public static NumericShaper getContextualShaper(int p0, int p1)
        {
            return new NumericShaper();
        }

        public static NumericShaper getContextualShaper(ISet<Range> p0, Range p1)
        {
            return new NumericShaper();
        }
    }
}