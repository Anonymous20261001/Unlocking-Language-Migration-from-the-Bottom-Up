using System;
using System.Collections.Generic;
using System.Text;
using javax.naming.ldap;

namespace Generated.Test
{
    public class javax_naming_ldap_RdnAutoTest
    {
        public void escapeValue_test_10344(object p0)
        {
            Rdn.escapeValue(p0);
        }

        public void unescapeValue_test_10345(string p0)
        {
            Rdn.unescapeValue(p0);
        }
    }
}

namespace javax.naming.ldap
{
    public class Rdn
    {
        private const string HEX = "0123456789ABCDEF";

        public static string escapeValue(object value)
        {
            if (value is string s)
                return EscapeString(s);
            if (value is byte[] bytes)
                return EscapeBytes(bytes);
            throw new ArgumentException("Invalid attribute value type: " + value);
        }

        public static object unescapeValue(string value)
        {
            if (value == null)
                throw new ArgumentNullException(nameof(value));
            if (value.Length == 0)
                return "";

            StringBuilder pending = new StringBuilder();
            List<byte> output = new List<byte>();
            bool binary = false;
            int i = 0;
            int len = value.Length;

            while (i < len)
            {
                char ch = value[i];
                if (ch == '\\')
                {
                    if (i + 1 >= len)
                        throw new ArgumentException("Invalid escape sequence");

                    char next = value[++i];

                    if (next == ' ' || next == '#' || next == ',' || next == '+' ||
                        next == '"' || next == '\\' || next == '<' || next == '>' || next == ';')
                    {
                        pending.Append(next);
                        i++;
                    }
                    else if (IsHex(next) && i + 1 < len && IsHex(value[i + 1]))
                    {
                        int hi = HexVal(next);
                        int lo = HexVal(value[i + 1]);
                        byte b = (byte)((hi << 4) | lo);

                        if (!binary)
                        {
                            FlushText(pending, output);
                            binary = true;
                        }
                        else
                        {
                            FlushText(pending, output);
                        }

                        output.Add(b);
                        i += 2;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid escape sequence");
                    }
                }
                else
                {
                    pending.Append(ch);
                    i++;
                }
            }

            if (!binary)
                return pending.ToString();

            FlushText(pending, output);
            return output.ToArray();
        }

        private static void FlushText(StringBuilder pending, List<byte> output)
        {
            if (pending.Length > 0)
            {
                byte[] encoded = Encoding.UTF8.GetBytes(pending.ToString());
                foreach (byte b in encoded)
                    output.Add(b);
                pending.Clear();
            }
        }

        private static string EscapeString(string s)
        {
            StringBuilder buf = new StringBuilder(s.Length);

            for (int i = 0; i < s.Length; i++)
            {
                char ch = s[i];

                if ((i == 0 && ch == ' ') || (i == s.Length - 1 && ch == ' '))
                    buf.Append("\\ ");
                else if (ch == '#' && i == 0)
                    buf.Append("\\#");
                else if (ch == ',' || ch == '+' || ch == '"' || ch == '\\' || ch == '<' || ch == '>' || ch == ';')
                    buf.Append('\\').Append(ch);
                else if (ch == '\0')
                    buf.Append("\\00");
                else
                    buf.Append(ch);
            }

            return buf.ToString();
        }

        private static string EscapeBytes(byte[] value)
        {
            StringBuilder buf = new StringBuilder(value.Length * 3);

            foreach (byte b in value)
            {
                buf.Append('\\');
                buf.Append(HEX[(b >> 4) & 0x0F]);
                buf.Append(HEX[b & 0x0F]);
            }

            return buf.ToString();
        }

        private static bool IsHex(char c)
        {
            return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }

        private static int HexVal(char c)
        {
            if (c >= '0' && c <= '9')
                return c - '0';
            if (c >= 'a' && c <= 'f')
                return c - 'a' + 10;
            if (c >= 'A' && c <= 'F')
                return c - 'A' + 10;
            throw new ArgumentException("Invalid hex digit");
        }
    }
}