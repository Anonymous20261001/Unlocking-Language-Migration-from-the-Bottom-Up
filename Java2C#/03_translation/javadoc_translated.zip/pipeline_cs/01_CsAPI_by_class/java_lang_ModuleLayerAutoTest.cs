using System;
using System.Collections;

namespace Generated.Test
{
    public sealed class Configuration
    {
    }

    public class ClassLoader
    {
    }

    public class Function
    {
        public virtual object apply(object argument)
        {
            return null;
        }
    }

    public class ModuleLayer
    {
        private ModuleLayer()
        {
        }

        public static ModuleLayer empty()
        {
            return new ModuleLayer();
        }

        public static ModuleLayer boot()
        {
            return new ModuleLayer();
        }

        public static ModuleLayer defineModules(Configuration p0, IList p1, Function p2)
        {
            return new ModuleLayer();
        }

        public static ModuleLayer defineModulesWithOneLoader(Configuration p0, IList p1, ClassLoader p2)
        {
            return new ModuleLayer();
        }

        public static ModuleLayer defineModulesWithManyLoaders(Configuration p0, IList p1, ClassLoader p2)
        {
            return new ModuleLayer();
        }
    }

    public class java_lang_ModuleLayerAutoTest
    {
        public void empty_test_8996()
        {
            ModuleLayer.empty();
        }

        public void boot_test_8997()
        {
            ModuleLayer.boot();
        }

        public void defineModules_test_8998(Configuration p0, IList p1, Function p2)
        {
            ModuleLayer.defineModules(p0, p1, p2);
        }

        public void defineModulesWithOneLoader_test_8999(Configuration p0, IList p1, ClassLoader p2)
        {
            ModuleLayer.defineModulesWithOneLoader(p0, p1, p2);
        }

        public void defineModulesWithManyLoaders_test_9000(Configuration p0, IList p1, ClassLoader p2)
        {
            ModuleLayer.defineModulesWithManyLoaders(p0, p1, p2);
        }
    }
}