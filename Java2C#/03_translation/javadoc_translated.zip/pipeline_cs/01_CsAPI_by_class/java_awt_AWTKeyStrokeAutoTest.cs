namespace Generated.Test
{
    public class AWTKeyStroke
    {
        private AWTKeyStroke()
        {
        }

        public static AWTKeyStroke getAWTKeyStroke(char keyChar)
        {
            return new AWTKeyStroke();
        }

        public static AWTKeyStroke getAWTKeyStroke(string s)
        {
            return new AWTKeyStroke();
        }

        public static AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers)
        {
            return new AWTKeyStroke();
        }

        public static AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers, bool onKeyRelease)
        {
            return new AWTKeyStroke();
        }

        public static AWTKeyStroke getAWTKeyStroke(char keyChar, int modifiers)
        {
            return new AWTKeyStroke();
        }

        public static AWTKeyStroke getAWTKeyStrokeForEvent(KeyEvent anEvent)
        {
            return new AWTKeyStroke();
        }
    }

    public class KeyEvent
    {
    }

    public class java_awt_AWTKeyStrokeAutoTest
    {
        public void getAWTKeyStroke_test_946(char p0)
        {
            AWTKeyStroke.getAWTKeyStroke(p0);
        }

        public void getAWTKeyStroke_test_947(string p0)
        {
            AWTKeyStroke.getAWTKeyStroke(p0);
        }

        public void getAWTKeyStroke_test_948(int p0, int p1)
        {
            AWTKeyStroke.getAWTKeyStroke(p0, p1);
        }

        public void getAWTKeyStroke_test_949(int p0, int p1, bool p2)
        {
            AWTKeyStroke.getAWTKeyStroke(p0, p1, p2);
        }

        public void getAWTKeyStroke_test_950(char p0, int p1)
        {
            AWTKeyStroke.getAWTKeyStroke(p0, p1);
        }

        public void getAWTKeyStrokeForEvent_test_951(KeyEvent p0)
        {
            AWTKeyStroke.getAWTKeyStrokeForEvent(p0);
        }
    }
}