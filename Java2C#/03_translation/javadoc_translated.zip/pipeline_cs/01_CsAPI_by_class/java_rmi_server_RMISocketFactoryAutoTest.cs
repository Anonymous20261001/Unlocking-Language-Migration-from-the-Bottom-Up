using System;

namespace Generated.Test
{
    public interface RMIFailureHandler
    {
        bool failure(Exception exception);
    }

    public abstract class RMISocketFactory
    {
        private static RMISocketFactory currentFactory;
        private static readonly RMISocketFactory defaultFactory = new DefaultRMISocketFactory();
        private static RMIFailureHandler failureHandler;

        public abstract object createSocket(string host, int port);
        public abstract object createServerSocket(int port);

        public static RMISocketFactory getSocketFactory()
        {
            return currentFactory;
        }

        public static RMISocketFactory getDefaultSocketFactory()
        {
            return defaultFactory;
        }

        public static void setSocketFactory(RMISocketFactory factory)
        {
            currentFactory = factory;
        }

        public static RMIFailureHandler getFailureHandler()
        {
            return failureHandler;
        }

        public static void setFailureHandler(RMIFailureHandler handler)
        {
            failureHandler = handler;
        }

        private class DefaultRMISocketFactory : RMISocketFactory
        {
            public override object createSocket(string host, int port)
            {
                return null;
            }

            public override object createServerSocket(int port)
            {
                return null;
            }
        }
    }

    public class java_rmi_server_RMISocketFactoryAutoTest
    {
        public void getSocketFactory_test_10636()
        {
            RMISocketFactory.getSocketFactory();
        }

        public void getDefaultSocketFactory_test_10637()
        {
            RMISocketFactory.getDefaultSocketFactory();
        }

        public void setFailureHandler_test_10638(RMIFailureHandler p0)
        {
            RMISocketFactory.setFailureHandler(p0);
        }

        public void getFailureHandler_test_10639()
        {
            RMISocketFactory.getFailureHandler();
        }
    }
}