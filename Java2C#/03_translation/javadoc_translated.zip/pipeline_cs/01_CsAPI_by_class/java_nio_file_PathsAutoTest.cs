using System;

namespace Generated.Test
{
    public class java_nio_file_PathsAutoTest
    {
        public void get_test_9863(string p0, string[] p1)
        {
            Paths.get(p0, p1);
        }

        public void get_test_9864(Uri p0)
        {
            Paths.get(p0);
        }
    }

    public sealed class Path
    {
        internal Path(string value)
        {
            Value = value;
        }

        public string Value { get; }
        public override string ToString() => Value;
    }

    public static class Paths
    {
        public static Path get(string first, string[] more)
        {
            string path = first;
            if (more != null)
            {
                foreach (string s in more)
                {
                    if (string.IsNullOrEmpty(path))
                    {
                        path = s;
                    }
                    else
                    {
                        path = System.IO.Path.Combine(path, s);
                    }
                }
            }
            return new Path(path);
        }

        public static Path get(Uri uri)
        {
            if (uri == null)
            {
                throw new ArgumentNullException(nameof(uri));
            }
            string localPath = uri.IsFile ? uri.LocalPath : uri.AbsolutePath;
            return new Path(localPath);
        }
    }
}