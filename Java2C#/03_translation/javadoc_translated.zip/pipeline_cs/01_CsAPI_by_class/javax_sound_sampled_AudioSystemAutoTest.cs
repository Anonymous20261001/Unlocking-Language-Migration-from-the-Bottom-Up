using javax.sound.sampled;

namespace javax.sound.sampled
{
    public class AudioFormat
    {
        public class Encoding
        {
            public string Name { get; }

            public Encoding(string name)
            {
                Name = name;
            }

            public override string ToString() => Name;

            public override bool Equals(object obj)
            {
                if (obj is Encoding other)
                {
                    return Name == other.Name;
                }
                return false;
            }

            public override int GetHashCode() => Name?.GetHashCode() ?? 0;
        }

        private readonly Encoding _encoding;
        private readonly float _sampleRate;
        private readonly int _sampleSizeInBits;
        private readonly int _channels;
        private readonly int _frameSize;
        private readonly float _frameRate;
        private readonly bool _bigEndian;

        public AudioFormat(Encoding encoding, float sampleRate, int sampleSizeInBits,
            int channels, int frameSize, float frameRate, bool bigEndian)
        {
            _encoding = encoding;
            _sampleRate = sampleRate;
            _sampleSizeInBits = sampleSizeInBits;
            _channels = channels;
            _frameSize = frameSize;
            _frameRate = frameRate;
            _bigEndian = bigEndian;
        }

        public AudioFormat(float sampleRate, int sampleSizeInBits, int channels,
            bool signed, bool bigEndian)
            : this(new Encoding(signed ? "PCM_SIGNED" : "PCM_UNSIGNED"),
                  sampleRate, sampleSizeInBits, channels,
                  (int)(sampleRate * sampleSizeInBits / 8 * channels),
                  sampleRate, bigEndian)
        {
        }
    }

    public class AudioInputStream
    {
        public AudioInputStream()
        {
        }
    }

    public class AudioFileFormat
    {
        public class Type
        {
            public string Name { get; }
            public string Extension { get; }

            public Type(string name, string extension)
            {
                Name = name;
                Extension = extension;
            }
        }
    }

    public class Line
    {
        public class Info
        {
            public Info()
            {
            }
        }
    }

    public class Mixer
    {
        public class Info
        {
            public Info()
            {
            }

            public Info(string name, string vendor, string description, string version)
            {
            }
        }
    }

    public static class AudioSystem
    {
        public static AudioInputStream getAudioInputStream(AudioFormat.Encoding targetEncoding, AudioInputStream sourceStream)
        {
            return new AudioInputStream();
        }

        public static AudioInputStream getAudioInputStream(AudioFormat targetFormat, AudioInputStream sourceStream)
        {
            return new AudioInputStream();
        }

        public static AudioFileFormat.Type[] getAudioFileTypes(AudioInputStream stream)
        {
            return new AudioFileFormat.Type[0];
        }

        public static AudioFileFormat.Type[] getAudioFileTypes()
        {
            return new AudioFileFormat.Type[0];
        }

        public static bool isFileTypeSupported(AudioFileFormat.Type fileType)
        {
            return false;
        }

        public static bool isFileTypeSupported(AudioFileFormat.Type fileType, AudioInputStream stream)
        {
            return false;
        }

        public static Mixer getMixer(Mixer.Info info)
        {
            return null;
        }

        public static Mixer.Info[] getMixerInfo()
        {
            return new Mixer.Info[0];
        }

        public static Line.Info[] getSourceLineInfo(Line.Info info)
        {
            return new Line.Info[0];
        }

        public static Line.Info[] getTargetLineInfo(Line.Info info)
        {
            return new Line.Info[0];
        }

        public static bool isLineSupported(Line.Info info)
        {
            return false;
        }

        public static AudioFormat.Encoding[] getTargetEncodings(AudioFormat.Encoding sourceEncoding)
        {
            return new AudioFormat.Encoding[0];
        }

        public static AudioFormat.Encoding[] getTargetEncodings(AudioFormat sourceFormat)
        {
            return new AudioFormat.Encoding[0];
        }

        public static bool isConversionSupported(AudioFormat targetFormat, AudioFormat sourceFormat)
        {
            return false;
        }

        public static bool isConversionSupported(AudioFormat.Encoding targetEncoding, AudioFormat sourceFormat)
        {
            return false;
        }

        public static AudioFormat[] getTargetFormats(AudioFormat.Encoding targetEncoding, AudioFormat sourceFormat)
        {
            return new AudioFormat[0];
        }
    }
}

namespace Generated.Test
{
    using javax.sound.sampled;

    public class javax_sound_sampled_AudioSystemAutoTest
    {
        public void getAudioInputStream_test_881(AudioFormat.Encoding p0, AudioInputStream p1)
        {
            AudioSystem.getAudioInputStream(p0, p1);
        }

        public void getAudioInputStream_test_882(AudioFormat p0, AudioInputStream p1)
        {
            AudioSystem.getAudioInputStream(p0, p1);
        }

        public void getAudioFileTypes_test_883(AudioInputStream p0)
        {
            AudioSystem.getAudioFileTypes(p0);
        }

        public void getAudioFileTypes_test_884()
        {
            AudioSystem.getAudioFileTypes();
        }

        public void isFileTypeSupported_test_885(AudioFileFormat.Type p0)
        {
            AudioSystem.isFileTypeSupported(p0);
        }

        public void isFileTypeSupported_test_886(AudioFileFormat.Type p0, AudioInputStream p1)
        {
            AudioSystem.isFileTypeSupported(p0, p1);
        }

        public void getMixer_test_887(Mixer.Info p0)
        {
            AudioSystem.getMixer(p0);
        }

        public void getMixerInfo_test_888()
        {
            AudioSystem.getMixerInfo();
        }

        public void getSourceLineInfo_test_889(Line.Info p0)
        {
            AudioSystem.getSourceLineInfo(p0);
        }

        public void getTargetLineInfo_test_890(Line.Info p0)
        {
            AudioSystem.getTargetLineInfo(p0);
        }

        public void isLineSupported_test_891(Line.Info p0)
        {
            AudioSystem.isLineSupported(p0);
        }

        public void getTargetEncodings_test_892(AudioFormat.Encoding p0)
        {
            AudioSystem.getTargetEncodings(p0);
        }

        public void getTargetEncodings_test_893(AudioFormat p0)
        {
            AudioSystem.getTargetEncodings(p0);
        }

        public void isConversionSupported_test_894(AudioFormat p0, AudioFormat p1)
        {
            AudioSystem.isConversionSupported(p0, p1);
        }

        public void isConversionSupported_test_895(AudioFormat.Encoding p0, AudioFormat p1)
        {
            AudioSystem.isConversionSupported(p0, p1);
        }

        public void getTargetFormats_test_896(AudioFormat.Encoding p0, AudioFormat p1)
        {
            AudioSystem.getTargetFormats(p0, p1);
        }
    }
}