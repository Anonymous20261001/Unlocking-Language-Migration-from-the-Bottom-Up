using System;
using System.Runtime.CompilerServices;

namespace Generated.Test
{
    public class DynamicLinker
    {
        public static string GetLinkedCallSiteLocation()
        {
            // In Java, this returns the location of the call site that is being linked.
            // In C#, we can use CallerFilePath, CallerLineNumber, and CallerMemberName
            // to get similar information about the caller.
            return GetCallerLocation();
        }

        private static string GetCallerLocation(
            [CallerFilePath] string filePath = "",
            [CallerLineNumber] int lineNumber = 0,
            [CallerMemberName] string memberName = "")
        {
            return $"{filePath}:{lineNumber} ({memberName})";
        }
    }

    public class jdk_dynalink_DynamicLinkerAutoTest
    {
        public void getLinkedCallSiteLocation_test_4424()
        {
            DynamicLinker.GetLinkedCallSiteLocation();
        }
    }
}