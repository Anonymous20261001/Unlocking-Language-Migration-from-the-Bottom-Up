using System;

namespace Generated.Test
{
    public class KeyEvent
    {
        public char KeyChar { get; set; }
        public int KeyCode { get; set; }
        public int Modifiers { get; set; }

        public KeyEvent() { }

        public KeyEvent(char keyChar, int keyCode, int modifiers)
        {
            KeyChar = keyChar;
            KeyCode = keyCode;
            Modifiers = modifiers;
        }
    }

    public sealed class KeyStroke
    {
        private readonly char keyChar;
        private readonly int keyCode;
        private readonly int modifiers;
        private readonly bool onKeyRelease;

        private KeyStroke(char keyChar, int keyCode, int modifiers, bool onKeyRelease)
        {
            this.keyChar = keyChar;
            this.keyCode = keyCode;
            this.modifiers = modifiers;
            this.onKeyRelease = onKeyRelease;
        }

        public static KeyStroke getKeyStrokeForEvent(KeyEvent anEvent)
        {
            if (anEvent == null)
                throw new NullReferenceException();
            return new KeyStroke(anEvent.KeyChar, anEvent.KeyCode, anEvent.Modifiers, false);
        }

        public static KeyStroke getKeyStroke(char keyChar, bool onKeyRelease)
        {
            return new KeyStroke(keyChar, 0, 0, onKeyRelease);
        }

        public static KeyStroke getKeyStroke(char? keyChar, int keyCode)
        {
            return new KeyStroke(keyChar ?? '\0', keyCode, 0, false);
        }

        public static KeyStroke getKeyStroke(int keyCode, int modifiers)
        {
            return new KeyStroke('\0', keyCode, modifiers, false);
        }

        public static KeyStroke getKeyStroke(char keyChar)
        {
            return getKeyStroke(keyChar, false);
        }

        public static KeyStroke getKeyStroke(string s)
        {
            if (s == null)
                return null;

            int code = 0;
            int mods = 0;
            bool release = false;
            string[] parts = s.Split(' ');

            foreach (string part in parts)
            {
                string lower = part.ToLowerInvariant();

                if (lower == "pressed" || lower == "released")
                {
                    release = lower == "released";
                }
                else if (lower == "shift")
                {
                    mods |= 1;
                }
                else if (lower == "ctrl" || lower == "control")
                {
                    mods |= 2;
                }
                else if (lower == "meta")
                {
                    mods |= 4;
                }
                else if (lower == "alt")
                {
                    mods |= 8;
                }
                else
                {
                    if (part.Length > 0)
                        code = part[0];
                }
            }

            return new KeyStroke('\0', code, mods, release);
        }

        public static KeyStroke getKeyStroke(int keyCode, int modifiers, bool onKeyRelease)
        {
            return new KeyStroke('\0', keyCode, modifiers, onKeyRelease);
        }

        public override bool Equals(object obj)
        {
            if (obj is KeyStroke other)
            {
                return keyChar == other.keyChar &&
                       keyCode == other.keyCode &&
                       modifiers == other.modifiers &&
                       onKeyRelease == other.onKeyRelease;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + keyChar;
            hash = hash * 31 + keyCode;
            hash = hash * 31 + modifiers;
            hash = hash * 31 + (onKeyRelease ? 1 : 0);
            return hash;
        }

        public override string ToString()
        {
            return string.Format("KeyStroke[{0},{1},{2},{3}]", keyChar, keyCode, modifiers, onKeyRelease);
        }
    }

    public class javax_swing_KeyStrokeAutoTest
    {
        public void getKeyStrokeForEvent_test_7655(KeyEvent p0)
        {
            KeyStroke.getKeyStrokeForEvent(p0);
        }

        public void getKeyStroke_test_7656(char p0, bool p1)
        {
            KeyStroke.getKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7657(char? p0, int p1)
        {
            KeyStroke.getKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7658(int p0, int p1)
        {
            KeyStroke.getKeyStroke(p0, p1);
        }

        public void getKeyStroke_test_7659(char p0)
        {
            KeyStroke.getKeyStroke(p0);
        }

        public void getKeyStroke_test_7660(string p0)
        {
            KeyStroke.getKeyStroke(p0);
        }

        public void getKeyStroke_test_7661(int p0, int p1, bool p2)
        {
            KeyStroke.getKeyStroke(p0, p1, p2);
        }
    }
}