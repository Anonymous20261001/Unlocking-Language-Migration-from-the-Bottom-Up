namespace Generated.Test
{
    public interface HostnameVerifier
    {
    }

    public abstract class SSLSocketFactory
    {
    }

    internal sealed class DefaultSSLSocketFactory : SSLSocketFactory
    {
    }

    public static class HttpsURLConnection
    {
        private static HostnameVerifier defaultHostnameVerifier;
        private static SSLSocketFactory defaultSSLSocketFactory = new DefaultSSLSocketFactory();

        public static SSLSocketFactory getDefaultSSLSocketFactory()
        {
            return defaultSSLSocketFactory;
        }

        public static void setDefaultHostnameVerifier(HostnameVerifier p0)
        {
            defaultHostnameVerifier = p0;
        }

        public static HostnameVerifier getDefaultHostnameVerifier()
        {
            return defaultHostnameVerifier;
        }

        public static void setDefaultSSLSocketFactory(SSLSocketFactory p0)
        {
            defaultSSLSocketFactory = p0;
        }
    }

    public class javax_net_ssl_HttpsURLConnectionAutoTest
    {
        public void getDefaultSSLSocketFactory_test_5489()
        {
            HttpsURLConnection.getDefaultSSLSocketFactory();
        }

        public void setDefaultHostnameVerifier_test_5490(HostnameVerifier p0)
        {
            HttpsURLConnection.setDefaultHostnameVerifier(p0);
        }

        public void getDefaultHostnameVerifier_test_5491()
        {
            HttpsURLConnection.getDefaultHostnameVerifier();
        }

        public void setDefaultSSLSocketFactory_test_5492(SSLSocketFactory p0)
        {
            HttpsURLConnection.setDefaultSSLSocketFactory(p0);
        }
    }
}