using System;

namespace Generated.Test
{
    public sealed class JapaneseEra
    {
        public static readonly JapaneseEra MEIJI = new JapaneseEra(1, "MEIJI");
        public static readonly JapaneseEra TAISHO = new JapaneseEra(2, "TAISHO");
        public static readonly JapaneseEra SHOWA = new JapaneseEra(3, "SHOWA");
        public static readonly JapaneseEra HEISEI = new JapaneseEra(4, "HEISEI");
        public static readonly JapaneseEra REIWA = new JapaneseEra(5, "REIWA");

        private static readonly JapaneseEra[] _eras = { MEIJI, TAISHO, SHOWA, HEISEI, REIWA };

        private readonly int _value;
        private readonly string _name;

        private JapaneseEra(int value, string name)
        {
            _value = value;
            _name = name;
        }

        public static JapaneseEra[] values()
        {
            return (JapaneseEra[])_eras.Clone();
        }

        public static JapaneseEra valueOf(string name)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }

            foreach (JapaneseEra era in _eras)
            {
                if (era._name == name)
                {
                    return era;
                }
            }

            throw new ArgumentException("No enum constant JapaneseEra." + name, "name");
        }

        public static JapaneseEra of(int value)
        {
            if (value < 1 || value > _eras.Length)
            {
                throw new ArgumentOutOfRangeException("value", "Invalid JapaneseEra value: " + value);
            }

            return _eras[value - 1];
        }
    }

    public class java_time_chrono_JapaneseEraAutoTest
    {
        public void values_test_5974()
        {
            JapaneseEra.values();
        }

        public void valueOf_test_5975(string p0)
        {
            JapaneseEra.valueOf(p0);
        }

        public void of_test_5976(int p0)
        {
            JapaneseEra.of(p0);
        }
    }
}