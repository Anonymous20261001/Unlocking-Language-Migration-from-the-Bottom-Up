using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Class
    {
        private string name;
        public Class(string name)
        {
            this.name = name;
        }
        public string Name
        {
            get { return name; }
        }
    }

    public class ClassLoader
    {
    }

    public class Method
    {
        private string name;
        public Method(string name)
        {
            this.name = name;
        }
        public string Name
        {
            get { return name; }
        }
    }

    public interface InvocationHandler
    {
        object Invoke(object proxy, Method method, object[] args);
    }

    public static class Proxy
    {
        private static List<Class> proxyClasses = new List<Class>();
        private static Dictionary<object, InvocationHandler> handlers = new Dictionary<object, InvocationHandler>();

        public static Class GetProxyClass(ClassLoader loader, Class[] interfaces)
        {
            if (interfaces == null)
                throw new ArgumentNullException("interfaces");
            Class proxyClass = new Class("Proxy" + proxyClasses.Count);
            proxyClasses.Add(proxyClass);
            return proxyClass;
        }

        public static InvocationHandler GetInvocationHandler(object proxy)
        {
            if (proxy == null)
                throw new ArgumentNullException("proxy");
            InvocationHandler handler;
            if (handlers.TryGetValue(proxy, out handler))
                return handler;
            throw new ArgumentException("Not a proxy instance: " + proxy.GetType());
        }

        public static bool IsProxyClass(Class clazz)
        {
            if (clazz == null)
                throw new ArgumentNullException("clazz");
            return proxyClasses.Contains(clazz);
        }

        public static object NewProxyInstance(ClassLoader loader, Class[] interfaces, InvocationHandler h)
        {
            if (interfaces == null)
                throw new ArgumentNullException("interfaces");
            if (h == null)
                throw new ArgumentNullException("h");
            GetProxyClass(loader, interfaces);
            object proxy = new object();
            handlers[proxy] = h;
            return proxy;
        }
    }

    public class java_lang_reflect_ProxyAutoTest
    {
        public void getProxyClass_test_10213(ClassLoader p0, Class[] p1)
        {
            Proxy.GetProxyClass(p0, p1);
        }

        public void getInvocationHandler_test_10214(object p0)
        {
            Proxy.GetInvocationHandler(p0);
        }

        public void isProxyClass_test_10215(Class p0)
        {
            Proxy.IsProxyClass(p0);
        }

        public void newProxyInstance_test_10216(ClassLoader p0, Class[] p1, InvocationHandler p2)
        {
            Proxy.NewProxyInstance(p0, p1, p2);
        }
    }
}