namespace Generated.Test
{
    public class LoggingMXBean
    {
    }

    public class LogManager
    {
        private static readonly LogManager instance = new LogManager();

        private LogManager()
        {
        }

        public static LogManager getLogManager()
        {
            return instance;
        }

        public static LoggingMXBean getLoggingMXBean()
        {
            return new LoggingMXBean();
        }
    }

    public class java_util_logging_LogManagerAutoTest
    {
        public void getLogManager_test_8109()
        {
            LogManager.getLogManager();
        }

        public void getLoggingMXBean_test_8110()
        {
            LogManager.getLoggingMXBean();
        }
    }
}