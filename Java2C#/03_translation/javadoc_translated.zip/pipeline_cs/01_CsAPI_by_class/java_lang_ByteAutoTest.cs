using System;

namespace Generated.Test
{
    public class Byte
    {
        private readonly byte value;

        public Byte(byte value)
        {
            this.value = value;
        }

        public static int compareUnsigned(byte x, byte y)
        {
            int ux = x & 0xFF;
            int uy = y & 0xFF;
            if (ux < uy) return -1;
            if (ux > uy) return 1;
            return 0;
        }

        public static int compare(byte x, byte y)
        {
            return x - y;
        }

        public int compareTo(Byte anotherByte)
        {
            if (anotherByte == null)
                throw new ArgumentNullException(nameof(anotherByte));
            return value.CompareTo(anotherByte.value);
        }

        public byte byteValue() { return value; }
        public short shortValue() { return (short)value; }
        public int intValue() { return (int)value; }
        public long longValue() { return (long)value; }
        public float floatValue() { return (float)value; }
        public double doubleValue() { return (double)value; }

        public static Byte valueOf(string s)
        {
            return new Byte(parseByte(s));
        }

        public static Byte valueOf(string s, int radix)
        {
            return new Byte(parseByte(s, radix));
        }

        public static Byte valueOf(byte b)
        {
            return new Byte(b);
        }

        public static Byte decode(string nm)
        {
            if (nm == null)
                throw new FormatException("null");

            string s = nm;
            int index = 0;
            bool negative = false;

            if (index < s.Length && (s[index] == '+' || s[index] == '-'))
            {
                negative = s[index] == '-';
                index++;
            }

            int radix = 10;

            if (index < s.Length && s[index] == '#')
            {
                radix = 16;
                index++;
            }
            else if (index + 1 < s.Length && s[index] == '0' && (s[index + 1] == 'x' || s[index + 1] == 'X'))
            {
                radix = 16;
                index += 2;
            }
            else if (index < s.Length && s[index] == '0' && index + 1 < s.Length)
            {
                radix = 8;
                index++;
            }

            return new Byte(ParseDigits(s.Substring(index), radix, negative));
        }

        public object describeConstable()
        {
            return this;
        }

        public static long toUnsignedLong(byte x)
        {
            return (long)(x & 0xFF);
        }

        public static int toUnsignedInt(byte x)
        {
            return x & 0xFF;
        }

        public static byte parseByte(string s)
        {
            return parseByte(s, 10);
        }

        public static byte parseByte(string s, int radix)
        {
            if (radix < 2 || radix > 36)
                throw new FormatException("radix " + radix + " out of range");
            if (s == null)
                throw new FormatException("null");
            if (s.Length == 0)
                throw new FormatException("Empty string");

            int index = 0;
            bool negative = false;

            if (s[index] == '+' || s[index] == '-')
            {
                negative = s[index] == '-';
                index++;
                if (index >= s.Length)
                    throw new FormatException("Missing digits");
            }

            return ParseDigits(s.Substring(index), radix, negative);
        }

        private static byte ParseDigits(string s, int radix, bool negative)
        {
            if (s == null || s.Length == 0)
                throw new FormatException("Missing digits");

            long magnitude = 0;

            foreach (char c in s)
            {
                int digit = DigitValue(c);
                if (digit < 0 || digit >= radix)
                    throw new FormatException("Invalid digit '" + c + "'");

                if (magnitude > (128 - digit) / radix)
                    throw new FormatException("Value out of range");

                magnitude = magnitude * radix + digit;
            }

            if (negative)
            {
                if (magnitude > 128)
                    throw new FormatException("Value out of range");
                return (byte)(-magnitude);
            }
            else
            {
                if (magnitude > 127)
                    throw new FormatException("Value out of range");
                return (byte)magnitude;
            }
        }

        private static int DigitValue(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'z') return c - 'a' + 10;
            if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
            return -1;
        }
    }

    public class java_lang_ByteAutoTest
    {
        public void compareUnsigned_test_1967(byte p0, byte p1)
        {
            Byte.compareUnsigned(p0, p1);
        }

        public void compareTo_test_1968(Byte p0, byte c0)
        {
            Byte instance = new Byte(c0);
            instance.compareTo(p0);
        }

        public void compare_test_1969(byte p0, byte p1)
        {
            Byte.compare(p0, p1);
        }

        public void byteValue_test_1970(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.byteValue();
        }

        public void shortValue_test_1971(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.shortValue();
        }

        public void intValue_test_1972(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.intValue();
        }

        public void longValue_test_1973(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.longValue();
        }

        public void floatValue_test_1974(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.floatValue();
        }

        public void doubleValue_test_1975(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.doubleValue();
        }

        public void valueOf_test_1976(string p0)
        {
            Byte.valueOf(p0);
        }

        public void valueOf_test_1977(string p0, int p1)
        {
            Byte.valueOf(p0, p1);
        }

        public void valueOf_test_1978(byte p0)
        {
            Byte.valueOf(p0);
        }

        public void decode_test_1979(string p0)
        {
            Byte.decode(p0);
        }

        public void describeConstable_test_1980(byte c0)
        {
            Byte instance = new Byte(c0);
            instance.describeConstable();
        }

        public void toUnsignedLong_test_1981(byte p0)
        {
            Byte.toUnsignedLong(p0);
        }

        public void toUnsignedInt_test_1982(byte p0)
        {
            Byte.toUnsignedInt(p0);
        }

        public void parseByte_test_1983(string p0)
        {
            Byte.parseByte(p0);
        }

        public void parseByte_test_1984(string p0, int p1)
        {
            Byte.parseByte(p0, p1);
        }
    }
}