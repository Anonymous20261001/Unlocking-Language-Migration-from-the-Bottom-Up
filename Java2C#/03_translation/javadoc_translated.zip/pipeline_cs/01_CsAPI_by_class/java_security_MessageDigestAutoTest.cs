namespace Generated.Test
{
    public class MessageDigest
    {
        public static bool isEqual(byte[] digesta, byte[] digestb)
        {
            if (ReferenceEquals(digesta, digestb))
                return true;
            if (digesta == null || digestb == null)
                return false;
            if (digesta.Length != digestb.Length)
                return false;

            int result = 0;
            for (int i = 0; i < digesta.Length; i++)
            {
                result |= digesta[i] ^ digestb[i];
            }
            return result == 0;
        }
    }

    public class java_security_MessageDigestAutoTest
    {
        public void isEqual_test_8592(byte[] p0, byte[] p1)
        {
            MessageDigest.isEqual(p0, p1);
        }
    }
}