namespace Generated.Test
{
    public class javax_net_ssl_SSLContextAutoTest
    {
        public void setDefault_test_11400(SSLContext p0)
        {
            SSLContext.SetDefault(p0);
        }
    }

    public class SSLContext
    {
        private static SSLContext _default;

        public static void SetDefault(SSLContext context)
        {
            _default = context;
        }

        public static SSLContext GetDefault()
        {
            return _default;
        }
    }
}