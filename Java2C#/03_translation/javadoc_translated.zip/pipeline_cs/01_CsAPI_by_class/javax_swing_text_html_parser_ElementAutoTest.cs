namespace Generated.Test
{
    public class Element
    {
        public const int ANY = 0;
        public const int EMPTY = 1;
        public const int CDATA = 2;
        public const int RCDATA = 3;

        public static int name2type(string name)
        {
            if (name == "CDATA") return CDATA;
            if (name == "RCDATA") return RCDATA;
            if (name == "EMPTY") return EMPTY;
            if (name == "ANY") return ANY;
            return ANY;
        }
    }

    public class javax_swing_text_html_parser_ElementAutoTest
    {
        public void name2type_test_4462(string p0)
        {
            Element.name2type(p0);
        }
    }
}