using System;
using System.Reflection;

namespace Generated.Test
{
    public class MethodType
    {
    }

    public class MethodHandles
    {
        public class Lookup
        {
        }
    }

    public class Lookup
    {
        private readonly MethodHandles.Lookup lookup;

        public Lookup(MethodHandles.Lookup lookup)
        {
            this.lookup = lookup;
        }

        public object findVirtual(Type refc, string name, MethodType type)
        {
            return null;
        }

        public object findStatic(Type refc, string name, MethodType type)
        {
            return null;
        }

        public object unreflect(MethodInfo m)
        {
            return null;
        }

        public object unreflectConstructor(ConstructorInfo c)
        {
            return null;
        }

        public object findSpecial(Type refc, string name, MethodType type)
        {
            return null;
        }

        public object findGetter(Type refc, string name, Type type)
        {
            return null;
        }

        public object unreflectGetter(FieldInfo f)
        {
            return null;
        }

        public object unreflectSetter(FieldInfo f)
        {
            return null;
        }

        public object findOwnSpecial(string name, Type rtype, Type[] ptypes)
        {
            return null;
        }

        public object findOwnStatic(string name, Type rtype, Type[] ptypes)
        {
            return null;
        }

        public static object unreflect(MethodHandles.Lookup l, MethodInfo m)
        {
            return null;
        }

        public static object unreflectConstructor(MethodHandles.Lookup l, ConstructorInfo c)
        {
            return null;
        }

        public static object findOwnSpecial(MethodHandles.Lookup l, string name, Type rtype, Type[] ptypes)
        {
            return null;
        }

        public static object findOwnStatic(MethodHandles.Lookup l, string name, Type rtype, Type[] ptypes)
        {
            return null;
        }
    }

    public class jdk_dynalink_linker_support_LookupAutoTest
    {
        public void findVirtual_test_8237(Type p0, string p1, MethodType p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findVirtual(p0, p1, p2);
        }

        public void findStatic_test_8238(Type p0, string p1, MethodType p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findStatic(p0, p1, p2);
        }

        public void unreflect_test_8239(MethodInfo p0, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.unreflect(p0);
        }

        public void unreflect_test_8240(MethodHandles.Lookup p0, MethodInfo p1)
        {
            Lookup.unreflect(p0, p1);
        }

        public void unreflectConstructor_test_8241(MethodHandles.Lookup p0, ConstructorInfo p1)
        {
            Lookup.unreflectConstructor(p0, p1);
        }

        public void unreflectConstructor_test_8242(ConstructorInfo p0, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.unreflectConstructor(p0);
        }

        public void findSpecial_test_8243(Type p0, string p1, MethodType p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findSpecial(p0, p1, p2);
        }

        public void findGetter_test_8244(Type p0, string p1, Type p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findGetter(p0, p1, p2);
        }

        public void unreflectGetter_test_8245(FieldInfo p0, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.unreflectGetter(p0);
        }

        public void unreflectSetter_test_8246(FieldInfo p0, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.unreflectSetter(p0);
        }

        public void findOwnSpecial_test_8247(string p0, Type p1, Type[] p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findOwnSpecial(p0, p1, p2);
        }

        public void findOwnSpecial_test_8248(MethodHandles.Lookup p0, string p1, Type p2, Type[] p3)
        {
            Lookup.findOwnSpecial(p0, p1, p2, p3);
        }

        public void findOwnStatic_test_8249(MethodHandles.Lookup p0, string p1, Type p2, Type[] p3)
        {
            Lookup.findOwnStatic(p0, p1, p2, p3);
        }

        public void findOwnStatic_test_8250(string p0, Type p1, Type[] p2, MethodHandles.Lookup c0)
        {
            Lookup instance = new Lookup(c0);
            instance.findOwnStatic(p0, p1, p2);
        }
    }
}