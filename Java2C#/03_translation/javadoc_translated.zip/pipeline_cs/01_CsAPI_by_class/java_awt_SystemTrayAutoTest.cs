namespace Generated.Test
{
    public class SystemTray
    {
        private static SystemTray instance;

        private SystemTray()
        {
        }

        public static SystemTray getSystemTray()
        {
            if (instance == null)
            {
                instance = new SystemTray();
            }
            return instance;
        }

        public static bool isSupported()
        {
            return true;
        }
    }

    public class java_awt_SystemTrayAutoTest
    {
        public void getSystemTray_test_12443()
        {
            SystemTray.getSystemTray();
        }

        public void isSupported_test_12444()
        {
            SystemTray.isSupported();
        }
    }
}