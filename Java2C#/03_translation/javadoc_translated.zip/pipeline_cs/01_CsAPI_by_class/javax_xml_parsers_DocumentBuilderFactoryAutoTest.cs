namespace Generated.Test
{
    public class ClassLoader
    {
    }

    public abstract class DocumentBuilderFactory
    {
        private class DefaultDocumentBuilderFactory : DocumentBuilderFactory
        {
        }

        private static DocumentBuilderFactory CreateDefault()
        {
            return new DefaultDocumentBuilderFactory();
        }

        public static DocumentBuilderFactory newDefaultInstance()
        {
            return CreateDefault();
        }

        public static DocumentBuilderFactory newDefaultNSInstance()
        {
            return CreateDefault();
        }

        public static DocumentBuilderFactory newNSInstance()
        {
            return CreateDefault();
        }

        public static DocumentBuilderFactory newNSInstance(string factoryId, ClassLoader classLoader)
        {
            return CreateDefault();
        }

        public static DocumentBuilderFactory newInstance(string factoryId, ClassLoader classLoader)
        {
            return CreateDefault();
        }

        public static DocumentBuilderFactory newInstance()
        {
            return CreateDefault();
        }
    }

    public class javax_xml_parsers_DocumentBuilderFactoryAutoTest
    {
        public void newDefaultInstance_test_4194()
        {
            DocumentBuilderFactory.newDefaultInstance();
        }

        public void newDefaultNSInstance_test_4195()
        {
            DocumentBuilderFactory.newDefaultNSInstance();
        }

        public void newNSInstance_test_4196()
        {
            DocumentBuilderFactory.newNSInstance();
        }

        public void newNSInstance_test_4197(string p0, ClassLoader p1)
        {
            DocumentBuilderFactory.newNSInstance(p0, p1);
        }

        public void newInstance_test_4198(string p0, ClassLoader p1)
        {
            DocumentBuilderFactory.newInstance(p0, p1);
        }

        public void newInstance_test_4199()
        {
            DocumentBuilderFactory.newInstance();
        }
    }
}