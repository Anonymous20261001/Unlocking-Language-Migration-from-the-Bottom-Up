using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    public interface Map
    {
        bool containsKey(object key);
        object get(object key);
    }

    public interface TemporalAccessor
    {
        ZoneId getZone();
    }

    public class ZoneOffset
    {
        public int TotalSeconds { get; private set; }

        public string Id
        {
            get { return ToString(); }
        }

        public ZoneOffset(int totalSeconds)
        {
            TotalSeconds = totalSeconds;
        }

        public static ZoneOffset ofHours(int hours)
        {
            return new ZoneOffset(hours * 3600);
        }

        public static ZoneOffset ofHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(hours * 3600 + minutes * 60);
        }

        public static ZoneOffset ofTotalSeconds(int totalSeconds)
        {
            return new ZoneOffset(totalSeconds);
        }

        public override string ToString()
        {
            if (TotalSeconds == 0)
            {
                return "Z";
            }

            int abs = Math.Abs(TotalSeconds);
            int hours = abs / 3600;
            int minutes = (abs % 3600) / 60;
            int seconds = abs % 60;
            string sign = TotalSeconds < 0 ? "-" : "+";

            if (seconds == 0)
            {
                return sign + hours.ToString("D2") + ":" + minutes.ToString("D2");
            }

            return sign + hours.ToString("D2") + ":" + minutes.ToString("D2") + ":" + seconds.ToString("D2");
        }
    }

    public class ZoneId : TemporalAccessor
    {
        private readonly string id;

        private ZoneId(string id)
        {
            this.id = id;
        }

        public string Id
        {
            get { return id; }
        }

        public static ZoneId of(string zoneId, Map aliasMap)
        {
            if (zoneId == null)
            {
                throw new ArgumentNullException("zoneId");
            }

            if (aliasMap != null && aliasMap.containsKey(zoneId))
            {
                object value = aliasMap.get(zoneId);
                string alias = value as string;
                if (alias != null)
                {
                    return of(alias);
                }
            }

            return of(zoneId);
        }

        public static ZoneId of(string zoneId)
        {
            if (zoneId == null)
            {
                throw new ArgumentNullException("zoneId");
            }

            if (zoneId.Length == 0)
            {
                throw new ArgumentException("ZoneId id may not be empty", "zoneId");
            }

            return new ZoneId(zoneId);
        }

        public static ZoneId from(TemporalAccessor temporal)
        {
            if (temporal == null)
            {
                throw new ArgumentNullException("temporal");
            }

            if (temporal is ZoneId)
            {
                return (ZoneId)temporal;
            }

            ZoneId result = temporal.getZone();
            if (result == null)
            {
                throw new ArgumentException("Unable to obtain ZoneId from TemporalAccessor");
            }

            return result;
        }

        public static ZoneId systemDefault()
        {
            return new ZoneId(TimeZoneInfo.Local.Id);
        }

        public static ISet<string> getAvailableZoneIds()
        {
            return new HashSet<string>(TimeZoneInfo.GetSystemTimeZones().Select(tz => tz.Id));
        }

        public static ZoneId ofOffset(string prefix, ZoneOffset offset)
        {
            if (prefix == null)
            {
                throw new ArgumentNullException("prefix");
            }

            if (offset == null)
            {
                throw new ArgumentNullException("offset");
            }

            if (!string.Equals(prefix, "GMT", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(prefix, "UTC", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(prefix, "UT", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("prefix must be GMT, UTC, or UT", "prefix");
            }

            string newId = offset.TotalSeconds == 0 ? prefix : prefix + offset.Id;
            return new ZoneId(newId);
        }

        public ZoneId getZone()
        {
            return this;
        }

        public override string ToString()
        {
            return id;
        }
    }

    public class java_time_ZoneIdAutoTest
    {
        public void of_test_13722(string p0, Map p1)
        {
            ZoneId.of(p0, p1);
        }

        public void of_test_13723(string p0)
        {
            ZoneId.of(p0);
        }

        public void from_test_13724(TemporalAccessor p0)
        {
            ZoneId.from(p0);
        }

        public void systemDefault_test_13725()
        {
            ZoneId.systemDefault();
        }

        public void getAvailableZoneIds_test_13726()
        {
            ZoneId.getAvailableZoneIds();
        }

        public void ofOffset_test_13727(string p0, ZoneOffset p1)
        {
            ZoneId.ofOffset(p0, p1);
        }
    }
}