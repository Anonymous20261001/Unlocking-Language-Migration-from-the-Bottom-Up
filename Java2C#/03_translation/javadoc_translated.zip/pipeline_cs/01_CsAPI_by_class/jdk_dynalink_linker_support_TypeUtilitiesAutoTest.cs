using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class TypeUtilities
    {
        private static readonly Dictionary<Type, Type> PrimitiveToWrapper = new Dictionary<Type, Type>
        {
            { typeof(bool), typeof(Boolean) },
            { typeof(byte), typeof(Byte) },
            { typeof(char), typeof(Char) },
            { typeof(short), typeof(Int16) },
            { typeof(int), typeof(Int32) },
            { typeof(long), typeof(Int64) },
            { typeof(float), typeof(Single) },
            { typeof(double), typeof(Double) },
            { typeof(void), typeof(void) }
        };

        private static readonly Dictionary<Type, Type> WrapperToPrimitive = new Dictionary<Type, Type>
        {
            { typeof(Boolean), typeof(bool) },
            { typeof(Byte), typeof(byte) },
            { typeof(Char), typeof(char) },
            { typeof(Int16), typeof(short) },
            { typeof(Int32), typeof(int) },
            { typeof(Int64), typeof(long) },
            { typeof(Single), typeof(float) },
            { typeof(Double), typeof(double) },
            { typeof(void), typeof(void) }
        };

        public static bool isWrapperType(Type type)
        {
            return WrapperToPrimitive.ContainsKey(type);
        }

        public static Type getPrimitiveType(Type type)
        {
            if (WrapperToPrimitive.TryGetValue(type, out Type primitive))
            {
                return primitive;
            }
            return null;
        }

        public static bool isSubtype(Type subType, Type superType)
        {
            if (subType == null || superType == null)
            {
                return false;
            }
            if (subType == superType)
            {
                return true;
            }
            return superType.IsAssignableFrom(subType);
        }

        public static Type getWrapperType(Type type)
        {
            if (PrimitiveToWrapper.TryGetValue(type, out Type wrapper))
            {
                return wrapper;
            }
            return null;
        }

        public static bool isConvertibleWithoutLoss(Type sourceType, Type targetType)
        {
            if (sourceType == null || targetType == null)
            {
                return false;
            }
            if (sourceType == targetType)
            {
                return true;
            }
            
            // Handle primitive/wrapper conversions
            Type sourcePrimitive = getPrimitiveType(sourceType) ?? sourceType;
            Type targetPrimitive = getPrimitiveType(targetType) ?? targetType;
            
            if (sourcePrimitive == targetPrimitive)
            {
                return true;
            }
            
            // Numeric conversions without loss
            if (IsNumericType(sourcePrimitive) && IsNumericType(targetPrimitive))
            {
                return IsNumericConversionWithoutLoss(sourcePrimitive, targetPrimitive);
            }
            
            // Reference conversions
            return targetType.IsAssignableFrom(sourceType);
        }

        public static bool isMethodInvocationConvertible(Type sourceType, Type targetType)
        {
            if (sourceType == null || targetType == null)
            {
                return false;
            }
            if (sourceType == targetType)
            {
                return true;
            }
            
            // Handle primitive/wrapper conversions
            Type sourcePrimitive = getPrimitiveType(sourceType) ?? sourceType;
            Type targetPrimitive = getPrimitiveType(targetType) ?? targetType;
            
            if (sourcePrimitive == targetPrimitive)
            {
                return true;
            }
            
            // Numeric conversions (including widening)
            if (IsNumericType(sourcePrimitive) && IsNumericType(targetPrimitive))
            {
                return IsNumericConversion(sourcePrimitive, targetPrimitive);
            }
            
            // Reference conversions
            return targetType.IsAssignableFrom(sourceType);
        }

        public static Type getPrimitiveTypeByName(string name)
        {
            switch (name)
            {
                case "boolean": return typeof(bool);
                case "byte": return typeof(byte);
                case "char": return typeof(char);
                case "short": return typeof(short);
                case "int": return typeof(int);
                case "long": return typeof(long);
                case "float": return typeof(float);
                case "double": return typeof(double);
                case "void": return typeof(void);
                default: return null;
            }
        }

        private static bool IsNumericType(Type type)
        {
            return type == typeof(byte) || type == typeof(short) || type == typeof(int) ||
                   type == typeof(long) || type == typeof(float) || type == typeof(double) ||
                   type == typeof(char);
        }

        private static bool IsNumericConversionWithoutLoss(Type source, Type target)
        {
            // Widening conversions that don't lose precision
            if (source == typeof(byte))
            {
                return target == typeof(short) || target == typeof(int) || target == typeof(long) ||
                       target == typeof(float) || target == typeof(double);
            }
            if (source == typeof(short))
            {
                return target == typeof(int) || target == typeof(long) || target == typeof(float) ||
                       target == typeof(double);
            }
            if (source == typeof(char))
            {
                return target == typeof(int) || target == typeof(long) || target == typeof(float) ||
                       target == typeof(double);
            }
            if (source == typeof(int))
            {
                return target == typeof(long) || target == typeof(float) || target == typeof(double);
            }
            if (source == typeof(long))
            {
                return target == typeof(float) || target == typeof(double);
            }
            if (source == typeof(float))
            {
                return target == typeof(double);
            }
            return false;
        }

        private static bool IsNumericConversion(Type source, Type target)
        {
            // All numeric conversions including widening and narrowing
            if (source == typeof(byte))
            {
                return target == typeof(short) || target == typeof(int) || target == typeof(long) ||
                       target == typeof(float) || target == typeof(double) || target == typeof(char);
            }
            if (source == typeof(short))
            {
                return target == typeof(int) || target == typeof(long) || target == typeof(float) ||
                       target == typeof(double) || target == typeof(byte) || target == typeof(char);
            }
            if (source == typeof(char))
            {
                return target == typeof(int) || target == typeof(long) || target == typeof(float) ||
                       target == typeof(double) || target == typeof(byte) || target == typeof(short);
            }
            if (source == typeof(int))
            {
                return target == typeof(long) || target == typeof(float) || target == typeof(double) ||
                       target == typeof(byte) || target == typeof(short) || target == typeof(char);
            }
            if (source == typeof(long))
            {
                return target == typeof(float) || target == typeof(double) ||
                       target == typeof(byte) || target == typeof(short) || target == typeof(int) || target == typeof(char);
            }
            if (source == typeof(float))
            {
                return target == typeof(double) || target == typeof(byte) || target == typeof(short) ||
                       target == typeof(int) || target == typeof(long) || target == typeof(char);
            }
            if (source == typeof(double))
            {
                return target == typeof(byte) || target == typeof(short) || target == typeof(int) ||
                       target == typeof(long) || target == typeof(float) || target == typeof(char);
            }
            return false;
        }
    }

    public class jdk_dynalink_linker_support_TypeUtilitiesAutoTest
    {
        public void isWrapperType_test_13103(Type p0)
        {
            TypeUtilities.isWrapperType(p0);
        }

        public void getPrimitiveType_test_13104(Type p0)
        {
            TypeUtilities.getPrimitiveType(p0);
        }

        public void isSubtype_test_13105(Type p0, Type p1)
        {
            TypeUtilities.isSubtype(p0, p1);
        }

        public void getWrapperType_test_13106(Type p0)
        {
            TypeUtilities.getWrapperType(p0);
        }

        public void isConvertibleWithoutLoss_test_13107(Type p0, Type p1)
        {
            TypeUtilities.isConvertibleWithoutLoss(p0, p1);
        }

        public void isMethodInvocationConvertible_test_13108(Type p0, Type p1)
        {
            TypeUtilities.isMethodInvocationConvertible(p0, p1);
        }

        public void getPrimitiveTypeByName_test_13109(string p0)
        {
            TypeUtilities.getPrimitiveTypeByName(p0);
        }
    }
}