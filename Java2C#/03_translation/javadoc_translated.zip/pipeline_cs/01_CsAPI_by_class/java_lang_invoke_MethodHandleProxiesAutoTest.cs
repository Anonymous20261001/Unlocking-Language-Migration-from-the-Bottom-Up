```csharp
using System;

namespace Generated.Test
{
    public class MethodHandle
    {
    }

    public static class MethodHandleProxies
    {
        private sealed class WrapperInstance
        {
            public Type InterfaceType { get; }
            public MethodHandle Target { get; }

            public WrapperInstance(Type interfaceType, MethodHandle target)
            {
                InterfaceType = interfaceType;
                Target = target;
            }
        }

        public static bool isWrapperInstance(object x)
        {
            return x is WrapperInstance;
        }

        public static object asInterfaceInstance(Type intf, MethodHandle target)
        {
            if (intf == null)
                throw new ArgumentNullException("intf");
            if (target == null)
                throw new ArgumentNullException("target");
            if (!intf.IsInterface)
                throw new ArgumentException("Not an interface: " + intf, "intf");
            return new WrapperInstance(intf, target);
        }

        public static MethodHandle wrapperInstanceTarget(object x)
        {
            if (x is WrapperInstance instance)
                return instance.Target;
            throw new ArgumentException("MethodHandleProxies.wrapperInstanceTarget", "x");
        }

        public static Type wrapperInstanceType(object x)
        {
            if (x is WrapperInstance instance)
                return instance.InterfaceType;
            throw new ArgumentException("MethodHandleProxies.wrapperInstanceType", "x");
        }
    }

    public class java_lang_invoke_MethodHandleProxiesAutoTest
    {
        public void isWrapperInstance_test_8870(object p0)
        {
            MethodHandleProxies.isWrapperInstance(p0);
        }

        public void asInterfaceInstance_test_8871(Type p0, MethodHandle p1)
        {
            MethodHandleProxies.asInterfaceInstance(p0, p1);
        }

        public void wrapperInstanceTarget_test_8872(object p0)
        {
            MethodHandleProxies.wrapperInstanceTarget(p0);
        }

        public void wrapperInstanceType_test_8873(object p0)
        {
            MethodHandleProxies.wrapperInstanceType(p0);
        }
    }
}
```