using javax.xml.stream;
using java.lang;

namespace Generated.Test
{
    public class javax_xml_stream_XMLEventFactoryAutoTest
    {
        public void newDefaultFactory_test_13626()
        {
            XMLEventFactory.newDefaultFactory();
        }

        public void newInstance_test_13627(string p0, ClassLoader p1)
        {
            XMLEventFactory.newInstance(p0, p1);
        }

        public void newInstance_test_13628()
        {
            XMLEventFactory.newInstance();
        }

        public void newFactory_test_13629(string p0, ClassLoader p1)
        {
            XMLEventFactory.newFactory(p0, p1);
        }

        public void newFactory_test_13630()
        {
            XMLEventFactory.newFactory();
        }
    }
}

namespace javax.xml.stream
{
    public abstract class XMLEventFactory
    {
        public static XMLEventFactory newDefaultFactory()
        {
            return new DefaultXMLEventFactory();
        }

        public static XMLEventFactory newInstance()
        {
            return newDefaultFactory();
        }

        public static XMLEventFactory newInstance(string factoryId, java.lang.ClassLoader classLoader)
        {
            return newDefaultFactory();
        }

        public static XMLEventFactory newFactory()
        {
            return newInstance();
        }

        public static XMLEventFactory newFactory(string factoryId, java.lang.ClassLoader classLoader)
        {
            return newInstance(factoryId, classLoader);
        }

        private class DefaultXMLEventFactory : XMLEventFactory
        {
        }
    }
}

namespace java.lang
{
    public class ClassLoader
    {
    }
}