namespace Generated.Test
{
    public interface XMLEventReader
    {
        bool hasNext();
        object next();
        void remove();
        object nextEvent();
        string getElementText();
        object nextTag();
        object getProperty(string name);
        void close();
    }

    public class EventReaderDelegate : XMLEventReader
    {
        private XMLEventReader parent;

        public EventReaderDelegate()
        {
            parent = null;
        }

        public EventReaderDelegate(XMLEventReader parent)
        {
            this.parent = parent;
        }

        public bool hasNext()
        {
            return parent.hasNext();
        }

        public object next()
        {
            return parent.next();
        }

        public void remove()
        {
            parent.remove();
        }

        public object nextEvent()
        {
            return parent.nextEvent();
        }

        public string getElementText()
        {
            return parent.getElementText();
        }

        public object nextTag()
        {
            return parent.nextTag();
        }

        public object getProperty(string name)
        {
            return parent.getProperty(name);
        }

        public void close()
        {
            parent.close();
        }

        public XMLEventReader getParent()
        {
            return parent;
        }

        public void setParent(XMLEventReader reader)
        {
            parent = reader;
        }
    }

    public class javax_xml_stream_util_EventReaderDelegateAutoTest
    {
        public void remove_test_4598()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.remove();
        }

        public void getProperty_test_4599(string p0)
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.getProperty(p0);
        }

        public void hasNext_test_4600()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.hasNext();
        }

        public void next_test_4601()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.next();
        }

        public void getParent_test_4602()
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.getParent();
        }

        public void setParent_test_4603(XMLEventReader p0)
        {
            EventReaderDelegate instance = new EventReaderDelegate();
            instance.setParent(p0);
        }
    }
}