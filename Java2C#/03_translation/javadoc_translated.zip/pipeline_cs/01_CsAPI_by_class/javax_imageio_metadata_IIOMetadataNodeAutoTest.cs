using System;

namespace Generated.Test
{
    public class Node { }
    public class Attr { }
    public class UserDataHandler { }
    public class NodeList { }
    public class NamedNodeMap { }
    public class Document { }
    public class TypeInfo { }

    public class IIOMetadataNode
    {
        private object userObject;

        public IIOMetadataNode()
        {
        }

        public string getTagName() { return null; }
        public Attr getAttributeNode(string name) { return null; }
        public Attr setAttributeNode(Attr newAttr) { return null; }
        public Attr removeAttributeNode(Attr oldAttr) { return null; }
        public void setAttributeNS(string namespaceURI, string qualifiedName, string value) { }
        public void removeAttributeNS(string namespaceURI, string localName) { }
        public Attr getAttributeNodeNS(string namespaceURI, string localName) { return null; }
        public Attr setAttributeNodeNS(Attr newAttr) { return null; }
        public bool hasAttribute(string name) { return false; }
        public bool hasAttributeNS(string namespaceURI, string localName) { return false; }
        public TypeInfo getSchemaTypeInfo() { return null; }
        public void setIdAttribute(string name, bool isId) { }
        public void setIdAttributeNode(Attr idAttr, bool isId) { }
        public string getNamespaceURI() { return null; }
        public void removeAttribute(string name) { }
        public object getUserObject() { return userObject; }
        public Node getNextSibling() { return null; }
        public Node getPreviousSibling() { return null; }
        public Node getFirstChild() { return null; }
        public Node getLastChild() { return null; }
        public void setUserObject(object data) { userObject = data; }
        public object getUserData(string key) { return null; }
        public object setUserData(string key, object data, UserDataHandler handler) { return null; }
        public string getPrefix() { return null; }
        public NodeList getElementsByTagName(string name) { return new NodeList(); }
        public NodeList getElementsByTagNameNS(string namespaceURI, string localName) { return new NodeList(); }
        public string getNodeName() { return null; }
        public string getNodeValue() { return null; }
        public void setNodeValue(string nodeValue) { }
        public Node getParentNode() { return null; }
        public NodeList getChildNodes() { return new NodeList(); }
        public Document getOwnerDocument() { return null; }
        public Node insertBefore(Node newChild, Node refChild) { return null; }
        public Node replaceChild(Node newChild, Node oldChild) { return null; }
        public Node removeChild(Node oldChild) { return null; }
        public Node appendChild(Node newChild) { return null; }
        public bool hasChildNodes() { return false; }
        public Node cloneNode(bool deep) { return null; }
        public void setPrefix(string prefix) { }
        public string getLocalName() { return null; }
        public bool hasAttributes() { return false; }
        public string getBaseURI() { return null; }
        public short compareDocumentPosition(Node other) { return 0; }
        public string getTextContent() { return null; }
        public void setTextContent(string textContent) { }
        public bool isSameNode(Node other) { return false; }
        public string lookupPrefix(string namespaceURI) { return null; }
        public bool isDefaultNamespace(string namespaceURI) { return false; }
        public string lookupNamespaceURI(string prefix) { return null; }
        public bool isEqualNode(Node arg) { return false; }
        public int getLength() { return 0; }
        public bool isSupported(string feature, string version) { return false; }
        public NamedNodeMap getAttributes() { return null; }
        public void normalize() { }
        public void setAttribute(string name, string value) { }
        public string getAttribute(string name) { return null; }
        public Node item(int index) { return null; }
        public short getNodeType() { return 0; }
        public object getFeature(string feature, string version) { return null; }
        public string getAttributeNS(string namespaceURI, string localName) { return null; }
        public void setIdAttributeNS(string namespaceURI, string localName, bool isId) { }
    }

    public class javax_image_metadata_IIOMetadataNodeAutoTest
    {
        public void getTagName_test_5556()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getTagName();
        }

        public void getAttributeNode_test_5557(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNode(p0);
        }

        public void setAttributeNode_test_5558(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNode(p0);
        }

        public void removeAttributeNode_test_5559(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttributeNode(p0);
        }

        public void setAttributeNS_test_5560(string p0, string p1, string p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNS(p0, p1, p2);
        }

        public void removeAttributeNS_test_5561(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttributeNS(p0, p1);
        }

        public void getAttributeNodeNS_test_5562(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNodeNS(p0, p1);
        }

        public void setAttributeNodeNS_test_5563(Attr p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttributeNodeNS(p0);
        }

        public void hasAttribute_test_5564(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttribute(p0);
        }

        public void hasAttributeNS_test_5565(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttributeNS(p0, p1);
        }

        public void getSchemaTypeInfo_test_5566()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getSchemaTypeInfo();
        }

        public void setIdAttribute_test_5567(string p0, bool p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttribute(p0, p1);
        }

        public void setIdAttributeNode_test_5568(Attr p0, bool p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttributeNode(p0, p1);
        }

        public void getNamespaceURI_test_5569()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNamespaceURI();
        }

        public void removeAttribute_test_5570(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeAttribute(p0);
        }

        public void getUserObject_test_5571()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getUserObject();
        }

        public void getNextSibling_test_5572()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNextSibling();
        }

        public void getPreviousSibling_test_5573()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getPreviousSibling();
        }

        public void getFirstChild_test_5574()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getFirstChild();
        }

        public void getLastChild_test_5575()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLastChild();
        }

        public void setUserObject_test_5576(object p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setUserObject(p0);
        }

        public void getUserData_test_5577(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getUserData(p0);
        }

        public void setUserData_test_5578(string p0, object p1, UserDataHandler p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setUserData(p0, p1, p2);
        }

        public void getPrefix_test_5579()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getPrefix();
        }

        public void getElementsByTagName_test_5580(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getElementsByTagName(p0);
        }

        public void getElementsByTagNameNS_test_5581(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getElementsByTagNameNS(p0, p1);
        }

        public void getNodeName_test_5582()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeName();
        }

        public void getNodeValue_test_5583()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeValue();
        }

        public void setNodeValue_test_5584(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setNodeValue(p0);
        }

        public void getParentNode_test_5585()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getParentNode();
        }

        public void getChildNodes_test_5586()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getChildNodes();
        }

        public void getOwnerDocument_test_5587()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getOwnerDocument();
        }

        public void insertBefore_test_5588(Node p0, Node p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.insertBefore(p0, p1);
        }

        public void replaceChild_test_5589(Node p0, Node p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.replaceChild(p0, p1);
        }

        public void removeChild_test_5590(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.removeChild(p0);
        }

        public void appendChild_test_5591(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.appendChild(p0);
        }

        public void hasChildNodes_test_5592()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasChildNodes();
        }

        public void cloneNode_test_5593(bool p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.cloneNode(p0);
        }

        public void setPrefix_test_5594(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setPrefix(p0);
        }

        public void getLocalName_test_5595()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLocalName();
        }

        public void hasAttributes_test_5596()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.hasAttributes();
        }

        public void getBaseURI_test_5597()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getBaseURI();
        }

        public void compareDocumentPosition_test_5598(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.compareDocumentPosition(p0);
        }

        public void getTextContent_test_5599()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getTextContent();
        }

        public void setTextContent_test_5600(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setTextContent(p0);
        }

        public void isSameNode_test_5601(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isSameNode(p0);
        }

        public void lookupPrefix_test_5602(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.lookupPrefix(p0);
        }

        public void isDefaultNamespace_test_5603(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isDefaultNamespace(p0);
        }

        public void lookupNamespaceURI_test_5604(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.lookupNamespaceURI(p0);
        }

        public void isEqualNode_test_5605(Node p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isEqualNode(p0);
        }

        public void getLength_test_5606()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getLength();
        }

        public void isSupported_test_5607(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.isSupported(p0, p1);
        }

        public void getAttributes_test_5608()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributes();
        }

        public void normalize_test_5609()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.normalize();
        }

        public void setAttribute_test_5610(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setAttribute(p0, p1);
        }

        public void getAttribute_test_5611(string p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttribute(p0);
        }

        public void item_test_5612(int p0)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.item(p0);
        }

        public void getNodeType_test_5613()
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getNodeType();
        }

        public void getFeature_test_5614(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getFeature(p0, p1);
        }

        public void getAttributeNS_test_5615(string p0, string p1)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.getAttributeNS(p0, p1);
        }

        public void setIdAttributeNS_test_5616(string p0, string p1, bool p2)
        {
            IIOMetadataNode instance = new IIOMetadataNode();
            instance.setIdAttributeNS(p0, p1, p2);
        }
    }
}