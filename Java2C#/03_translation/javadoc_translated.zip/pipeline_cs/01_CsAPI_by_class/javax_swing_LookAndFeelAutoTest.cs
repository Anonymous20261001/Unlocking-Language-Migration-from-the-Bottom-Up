using System;

namespace Generated.Test
{
    public class javax_swing_LookAndFeelAutoTest
    {
        public void makeIcon_test_8226(Type p0, string p1)
        {
            LookAndFeel.makeIcon(p0, p1);
        }

        public void makeComponentInputMap_test_8227(JComponent p0, object[] p1)
        {
            LookAndFeel.makeComponentInputMap(p0, p1);
        }

        public void installProperty_test_8228(JComponent p0, string p1, object p2)
        {
            LookAndFeel.installProperty(p0, p1, p2);
        }

        public void installColors_test_8229(JComponent p0, string p1, string p2)
        {
            LookAndFeel.installColors(p0, p1, p2);
        }

        public void loadKeyBindings_test_8230(InputMap p0, object[] p1)
        {
            LookAndFeel.loadKeyBindings(p0, p1);
        }

        public void makeKeyBindings_test_8231(object[] p0)
        {
            LookAndFeel.makeKeyBindings(p0);
        }

        public void makeInputMap_test_8232(object[] p0)
        {
            LookAndFeel.makeInputMap(p0);
        }

        public void getDesktopPropertyValue_test_8233(string p0, object p1)
        {
            LookAndFeel.getDesktopPropertyValue(p0, p1);
        }

        public void installColorsAndFont_test_8234(JComponent p0, string p1, string p2, string p3)
        {
            LookAndFeel.installColorsAndFont(p0, p1, p2, p3);
        }

        public void installBorder_test_8235(JComponent p0, string p1)
        {
            LookAndFeel.installBorder(p0, p1);
        }

        public void uninstallBorder_test_8236(JComponent p0)
        {
            LookAndFeel.uninstallBorder(p0);
        }
    }

    public class JComponent
    {
    }

    public class InputMap
    {
    }

    public class Icon
    {
    }

    public class KeyStroke
    {
    }

    public class LookAndFeel
    {
        public static Icon makeIcon(Type baseClass, string resource)
        {
            return null;
        }

        public static InputMap makeComponentInputMap(JComponent c, object[] bindings)
        {
            return null;
        }

        public static void installProperty(JComponent c, string propertyName, object value)
        {
        }

        public static void installColors(JComponent c, string bg, string fg)
        {
        }

        public static void loadKeyBindings(InputMap map, object[] keys)
        {
        }

        public static KeyStroke[] makeKeyBindings(object[] keys)
        {
            return null;
        }

        public static InputMap makeInputMap(object[] keys)
        {
            return null;
        }

        public static object getDesktopPropertyValue(string systemPropertyName, object fallbackValue)
        {
            return fallbackValue;
        }

        public static void installColorsAndFont(JComponent c, string background, string foreground, string font)
        {
        }

        public static void installBorder(JComponent c, string defaultBorderName)
        {
        }

        public static void uninstallBorder(JComponent c)
        {
        }
    }
}