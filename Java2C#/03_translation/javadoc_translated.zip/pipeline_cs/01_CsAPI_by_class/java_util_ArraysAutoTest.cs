namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {
        public void compareUnsigned_test_344(byte[] p0, byte[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_345(short[] p0, short[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_346(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_347(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_348(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_349(long[] p0, long[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void compareUnsigned_test_350(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }

        public void compareUnsigned_test_351(int[] p0, int[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }

        public void copyOf_test_352(double[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_353(int[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_354(byte[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_355(object[] p0, int p1, System.Type p2)
        {
            Arrays.CopyOf(p0, p1, p2);
        }

        public void copyOf_test_356(object[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_357(bool[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_358(float[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_359(char[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_360(long[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void copyOf_test_361(short[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }

        public void sort_test_362(object[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_363(long[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_364(long[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_365(short[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_366(object[] p0, int p1, int p2, System.Collections.Generic.IComparer<object> p3)
        {
            Arrays.Sort(p0, p1, p2, p3);
        }

        public void sort_test_367(object[] p0, System.Collections.Generic.IComparer<object> p1)
        {
            Arrays.Sort(p0, p1);
        }

        public void sort_test_368(object[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_369(int[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_370(double[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_371(double[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_372(float[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_373(float[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_374(byte[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_375(short[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_376(char[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_377(char[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void sort_test_378(byte[] p0)
        {
            Arrays.Sort(p0);
        }

        public void sort_test_379(int[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }

        public void copyOfRange_test_380(bool[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_381(char[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_382(long[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_383(float[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_384(double[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_385(object[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_386(object[] p0, int p1, int p2, System.Type p3)
        {
            Arrays.CopyOfRange(p0, p1, p2, p3);
        }

        public void copyOfRange_test_387(byte[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_388(short[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void copyOfRange_test_389(int[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }

        public void compare_test_390(char[] p0, int p1, int p2, char[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_391(int[] p0, int[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_392(char[] p0, char[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_393(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_394(long[] p0, long[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_395(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_396(double[] p0, double[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_397(float[] p0, int p1, int p2, float[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_398(short[] p0, short[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_399(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_400(bool[] p0, bool[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_401(bool[] p0, int p1, int p2, bool[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_402(byte[] p0, byte[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_403(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_404(System.IComparable[] p0, int p1, int p2, System.IComparable[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_405(System.IComparable[] p0, System.IComparable[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void compare_test_406(object[] p0, object[] p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.Compare(p0, p1, p2);
        }

        public void compare_test_407(double[] p0, int p1, int p2, double[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }

        public void compare_test_408(object[] p0, int p1, int p2, object[] p3, int p4, int p5, System.Collections.Generic.IComparer<object> p6)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5, p6);
        }

        public void compare_test_409(float[] p0, float[] p1)
        {
            Arrays.Compare(p0, p1);
        }

        public void mismatch_test_410(long[] p0, long[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_411(float[] p0, float[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_412(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_413(object[] p0, object[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_414(object[] p0, int p1, int p2, object[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_415(object[] p0, object[] p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.Mismatch(p0, p1, p2);
        }

        public void mismatch_test_416(object[] p0, int p1, int p2, object[] p3, int p4, int p5, System.Collections.Generic.IComparer<object> p6)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5, p6);
        }

        public void mismatch_test_417(double[] p0, int p1, int p2, double[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_418(double[] p0, double[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_419(float[] p0, int p1, int p2, float[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_420(byte[] p0, int p1, int p2, byte[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_421(char[] p0, char[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_422(char[] p0, int p1, int p2, char[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_423(int[] p0, int[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_424(short[] p0, int p1, int p2, short[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_425(short[] p0, short[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_426(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_427(bool[] p0, bool[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void mismatch_test_428(bool[] p0, int p1, int p2, bool[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }

        public void mismatch_test_429(byte[] p0, byte[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }

        public void stream_test_430(object[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_431(long[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_432(int[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_433(int[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_434(object[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_435(double[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void stream_test_436(double[] p0)
        {
            Arrays.Stream(p0);
        }

        public void stream_test_437(long[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }

        public void fill_test_438(object[] p0, int p1, int p2, object p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_439(long[] p0, long p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_440(bool[] p0, bool p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_441(short[] p0, short p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_442(int[] p0, int p1, int p2, int p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_443(int[] p0, int p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_444(bool[] p0, int p1, int p2, bool p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_445(byte[] p0, byte p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_446(char[] p0, char p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_447(short[] p0, int p1, int p2, short p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_448(byte[] p0, int p1, int p2, byte p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_449(double[] p0, int p1, int p2, double p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_450(float[] p0, float p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_451(float[] p0, int p1, int p2, float p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_452(object[] p0, object p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void fill_test_453(char[] p0, int p1, int p2, char p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_454(long[] p0, int p1, int p2, long p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }

        public void fill_test_455(double[] p0, double p1)
        {
            Arrays.Fill(p0, p1);
        }

        public void spliterator_test_456(int[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_457(long[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_458(int[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_459(object[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_460(double[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_461(object[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void spliterator_test_462(long[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }

        public void spliterator_test_463(double[] p0)
        {
            Arrays.Spliterator(p0);
        }

        public void asList_test_464(object[] p0)
        {
            Arrays.AsList(p0);
        }

        public void deepEquals_test_465(object[] p0, object[] p1)
        {
            Arrays.DeepEquals(p0, p1);
        }

        public void deepHashCode_test_466(object[] p0)
        {
            Arrays.DeepHashCode(p0);
        }

        public void deepToString_test_467(object[] p0)
        {
            Arrays.DeepToString(p0);
        }

        public void parallelSort_test_468(int[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_469(int[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_470(long[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_471(object[] p0, int p1, int p2, System.Collections.Generic.IComparer<object> p3)
        {
            Arrays.ParallelSort(p0, p1, p2, p3);
        }

        public void parallelSort_test_472(short[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_473(object[] p0, System.Collections.Generic.IComparer<object> p1)
        {
            Arrays.ParallelSort(p0, p1);
        }

        public void parallelSort_test_474(short[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_475(double[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_476(double[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_477(float[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_478(float[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_479(System.IComparable[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_480(System.IComparable[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_481(byte[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_482(byte[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_483(char[] p0)
        {
            Arrays.ParallelSort(p0);
        }

        public void parallelSort_test_484(char[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelSort_test_485(long[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }

        public void parallelPrefix_test_486(double[] p0, int p1, int p2, System.Func<double, double, double> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_487(double[] p0, System.Func<double, double, double> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_488(int[] p0, System.Func<int, int, int> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_489(int[] p0, int p1, int p2, System.Func<int, int, int> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_490(long[] p0, int p1, int p2, System.Func<long, long, long> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_491(long[] p0, System.Func<long, long, long> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void parallelPrefix_test_492(object[] p0, int p1, int p2, System.Func<object, object, object> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }

        public void parallelPrefix_test_493(object[] p0, System.Func<object, object, object> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }

        public void binarySearch_test_494(float[] p0, int p1, int p2, float p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_495(float[] p0, float p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_496(short[] p0, short p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_497(short[] p0, int p1, int p2, short p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_498(object[] p0, object p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_499(object[] p0, int p1, int p2, object p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_500(object[] p0, object p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.BinarySearch(p0, p1, p2);
        }

        public void binarySearch_test_501(double[] p0, int p1, int p2, double p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_502(double[] p0, double p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_503(byte[] p0, int p1, int p2, byte p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_504(byte[] p0, byte p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_505(char[] p0, int p1, int p2, char p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_506(char[] p0, char p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_507(int[] p0, int p1, int p2, int p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_508(long[] p0, long p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_509(long[] p0, int p1, int p2, long p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }

        public void binarySearch_test_510(int[] p0, int p1)
        {
            Arrays.BinarySearch(p0, p1);
        }

        public void binarySearch_test_511(object[] p0, int p1, int p2, object p3, System.Collections.Generic.IComparer<object> p4)
        {
            Arrays.BinarySearch(p0, p1, p2, p3, p4);
        }

        public void setAll_test_512(double[] p0, System.Func<int, double> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_513(int[] p0, System.Func<int, int> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_514(long[] p0, System.Func<int, long> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void setAll_test_515(object[] p0, System.Func<int, object> p1)
        {
            Arrays.SetAll(p0, p1);
        }

        public void parallelSetAll_test_516(double[] p0, System.Func<int, double> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_517(long[] p0, System.Func<int, long> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_518(object[] p0, System.Func<int, object> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }

        public void parallelSetAll_test_519(int[] p0, System.Func<int, int> p1)
        {
            Arrays.ParallelSetAll(p0, p1);
        }
    }

    public static class Arrays
    {
        public static int CompareUnsigned(byte[] a, byte[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = (a[i] & 0xFF).CompareTo(b[i] & 0xFF);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(short[] a, short[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = (a[i] & 0xFFFF).CompareTo(b[i] & 0xFFFF);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = (a[aFromIndex + i] & 0xFF).CompareTo(b[bFromIndex + i] & 0xFF);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = ((ulong)a[aFromIndex + i]).CompareTo((ulong)b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = (a[aFromIndex + i] & 0xFFFF).CompareTo(b[bFromIndex + i] & 0xFFFF);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(long[] a, long[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = ((ulong)a[i]).CompareTo((ulong)b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int CompareUnsigned(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = ((uint)a[aFromIndex + i]).CompareTo((uint)b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int CompareUnsigned(int[] a, int[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = ((uint)a[i]).CompareTo((uint)b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static double[] CopyOf(double[] original, int newLength)
        {
            double[] result = new double[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static int[] CopyOf(int[] original, int newLength)
        {
            int[] result = new int[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static byte[] CopyOf(byte[] original, int newLength)
        {
            byte[] result = new byte[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static T[] CopyOf<T>(T[] original, int newLength, System.Type newType)
        {
            T[] result = new T[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static T[] CopyOf<T>(T[] original, int newLength)
        {
            T[] result = new T[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static bool[] CopyOf(bool[] original, int newLength)
        {
            bool[] result = new bool[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static float[] CopyOf(float[] original, int newLength)
        {
            float[] result = new float[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static char[] CopyOf(char[] original, int newLength)
        {
            char[] result = new char[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static long[] CopyOf(long[] original, int newLength)
        {
            long[] result = new long[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static short[] CopyOf(short[] original, int newLength)
        {
            short[] result = new short[newLength];
            System.Array.Copy(original, result, System.Math.Min(original.Length, newLength));
            return result;
        }

        public static void Sort<T>(T[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(long[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(long[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(short[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort<T>(T[] array, int index, int length, System.Collections.Generic.IComparer<T> comparer)
        {
            System.Array.Sort(array, index, length, comparer);
        }

        public static void Sort<T>(T[] array, System.Collections.Generic.IComparer<T> comparer)
        {
            System.Array.Sort(array, comparer);
        }

        public static void Sort<T>(T[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(int[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(double[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(double[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(float[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(float[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(byte[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(short[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(char[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(char[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void Sort(byte[] array)
        {
            System.Array.Sort(array);
        }

        public static void Sort(int[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static bool[] CopyOfRange(bool[] original, int from, int to)
        {
            bool[] result = new bool[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static char[] CopyOfRange(char[] original, int from, int to)
        {
            char[] result = new char[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static long[] CopyOfRange(long[] original, int from, int to)
        {
            long[] result = new long[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static float[] CopyOfRange(float[] original, int from, int to)
        {
            float[] result = new float[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static double[] CopyOfRange(double[] original, int from, int to)
        {
            double[] result = new double[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static T[] CopyOfRange<T>(T[] original, int from, int to)
        {
            T[] result = new T[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static T[] CopyOfRange<T>(T[] original, int from, int to, System.Type newType)
        {
            T[] result = new T[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static byte[] CopyOfRange(byte[] original, int from, int to)
        {
            byte[] result = new byte[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static short[] CopyOfRange(short[] original, int from, int to)
        {
            short[] result = new short[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static int[] CopyOfRange(int[] original, int from, int to)
        {
            int[] result = new int[to - from];
            System.Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        public static int Compare(char[] a, int aFromIndex, int aToIndex, char[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(int[] a, int[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(char[] a, char[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(long[] a, long[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(double[] a, double[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(float[] a, int aFromIndex, int aToIndex, float[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(short[] a, short[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(bool[] a, bool[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(bool[] a, int aFromIndex, int aToIndex, bool[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(byte[] a, byte[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare<T>(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex) where T : System.IComparable<T>
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare<T>(T[] a, T[] b) where T : System.IComparable<T>
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare<T>(T[] a, T[] b, System.Collections.Generic.IComparer<T> cmp)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int c = cmp.Compare(a[i], b[i]);
                if (c != 0) return c;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Compare(double[] a, int aFromIndex, int aToIndex, double[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[aFromIndex + i].CompareTo(b[bFromIndex + i]);
                if (cmp != 0) return cmp;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare<T>(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex, System.Collections.Generic.IComparer<T> cmp)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                int c = cmp.Compare(a[aFromIndex + i], b[bFromIndex + i]);
                if (c != 0) return c;
            }
            return aLen.CompareTo(bLen);
        }

        public static int Compare(float[] a, float[] b)
        {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                int cmp = a[i].CompareTo(b[i]);
                if (cmp != 0) return cmp;
            }
            return a.Length.CompareTo(b.Length);
        }

        public static int Mismatch(long[] a, long[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(float[] a, float[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(long[] a, int aFromIndex, int aToIndex, long[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch<T>(T[] a, T[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (!object.Equals(a[i], b[i])) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch<T>(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (!object.Equals(a[aFromIndex + i], b[bFromIndex + i])) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch<T>(T[] a, T[] b, System.Collections.Generic.IComparer<T> cmp)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (cmp.Compare(a[i], b[i]) != 0) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch<T>(T[] a, int aFromIndex, int aToIndex, T[] b, int bFromIndex, int bToIndex, System.Collections.Generic.IComparer<T> cmp)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (cmp.Compare(a[aFromIndex + i], b[bFromIndex + i]) != 0) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(double[] a, int aFromIndex, int aToIndex, double[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(double[] a, double[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(float[] a, int aFromIndex, int aToIndex, float[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(byte[] a, int aFromIndex, int aToIndex, byte[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(char[] a, char[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(char[] a, int aFromIndex, int aToIndex, char[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(int[] a, int[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(short[] a, int aFromIndex, int aToIndex, short[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(short[] a, short[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(int[] a, int aFromIndex, int aToIndex, int[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(bool[] a, bool[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static int Mismatch(bool[] a, int aFromIndex, int aToIndex, bool[] b, int bFromIndex, int bToIndex)
        {
            int aLen = aToIndex - aFromIndex;
            int bLen = bToIndex - bFromIndex;
            int len = System.Math.Min(aLen, bLen);
            for (int i = 0; i < len; i++)
            {
                if (a[aFromIndex + i] != b[bFromIndex + i]) return i;
            }
            return aLen == bLen ? -1 : len;
        }

        public static int Mismatch(byte[] a, byte[] b)
        {
            if (a == null || b == null) return -1;
            int len = System.Math.Min(a.Length, b.Length);
            for (int i = 0; i < len; i++)
            {
                if (a[i] != b[i]) return i;
            }
            return a.Length == b.Length ? -1 : len;
        }

        public static System.Collections.Generic.IEnumerable<T> Stream<T>(T[] array)
        {
            return array;
        }

        public static System.Collections.Generic.IEnumerable<long> Stream(long[] array)
        {
            return array;
        }

        public static System.Collections.Generic.IEnumerable<int> Stream(int[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static System.Collections.Generic.IEnumerable<int> Stream(int[] array)
        {
            return array;
        }

        public static System.Collections.Generic.IEnumerable<T> Stream<T>(T[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static System.Collections.Generic.IEnumerable<double> Stream(double[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static System.Collections.Generic.IEnumerable<double> Stream(double[] array)
        {
            return array;
        }

        public static System.Collections.Generic.IEnumerable<long> Stream(long[] array, int startInclusive, int endExclusive)
        {
            for (int i = startInclusive; i < endExclusive; i++)
                yield return array[i];
        }

        public static void Fill<T>(T[] array, int fromIndex, int toIndex, T value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(long[] array, long value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(bool[] array, bool value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(short[] array, short value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(int[] array, int fromIndex, int toIndex, int value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(int[] array, int value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(bool[] array, int fromIndex, int toIndex, bool value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(byte[] array, byte value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(char[] array, char value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(short[] array, int fromIndex, int toIndex, short value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(byte[] array, int fromIndex, int toIndex, byte value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(double[] array, int fromIndex, int toIndex, double value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(float[] array, float value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(float[] array, int fromIndex, int toIndex, float value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill<T>(T[] array, T value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static void Fill(char[] array, int fromIndex, int toIndex, char value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(long[] array, int fromIndex, int toIndex, long value)
        {
            for (int i = fromIndex; i < toIndex; i++)
                array[i] = value;
        }

        public static void Fill(double[] array, double value)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = value;
        }

        public static object Spliterator(int[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(long[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(int[] array, int startInclusive, int endExclusive)
        {
            return System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Skip(array, startInclusive).Take(endExclusive - startInclusive)).GetEnumerator();
        }

        public static object Spliterator<T>(T[] array, int startInclusive, int endExclusive)
        {
            return System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Skip(array, startInclusive).Take(endExclusive - startInclusive)).GetEnumerator();
        }

        public static object Spliterator(double[] array, int startInclusive, int endExclusive)
        {
            return System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Skip(array, startInclusive).Take(endExclusive - startInclusive)).GetEnumerator();
        }

        public static object Spliterator<T>(T[] array)
        {
            return array.GetEnumerator();
        }

        public static object Spliterator(long[] array, int startInclusive, int endExclusive)
        {
            return System.Linq.Enumerable.ToArray(System.Linq.Enumerable.Skip(array, startInclusive).Take(endExclusive - startInclusive)).GetEnumerator();
        }

        public static object Spliterator(double[] array)
        {
            return array.GetEnumerator();
        }

        public static System.Collections.Generic.IList<T> AsList<T>(T[] array)
        {
            return new System.Collections.Generic.List<T>(array);
        }

        public static bool DeepEquals<T>(T[] a, T[] b)
        {
            if (a == null && b == null) return true;
            if (a == null || b == null) return false;
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
            {
                if (!object.Equals(a[i], b[i])) return false;
            }
            return true;
        }

        public static int DeepHashCode<T>(T[] array)
        {
            if (array == null) return 0;
            int result = 1;
            foreach (T item in array)
                result = 31 * result + (item == null ? 0 : item.GetHashCode());
            return result;
        }

        public static string DeepToString<T>(T[] array)
        {
            if (array == null) return "null";
            return "[" + string.Join(", ", array) + "]";
        }

        public static void ParallelSort(int[] array)
        {
            System.Array.Sort(array);
        }

        public static void ParallelSort(int[] array, int index, int length)
        {
            System.Array.Sort(array, index, length);
        }

        public static void ParallelSort(long[] array)
        {
            System.Array.Sort(array);
        }

        public static void Parallel