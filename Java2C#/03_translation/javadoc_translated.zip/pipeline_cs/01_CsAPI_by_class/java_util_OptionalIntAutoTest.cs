using System;

namespace Generated.Test
{
    public sealed class OptionalInt
    {
        private readonly bool isPresent;
        private readonly int value;
        private static readonly OptionalInt EMPTY = new OptionalInt(0, false);

        private OptionalInt(int value, bool isPresent)
        {
            this.value = value;
            this.isPresent = isPresent;
        }

        public static OptionalInt of(int value)
        {
            return new OptionalInt(value, true);
        }

        public static OptionalInt empty()
        {
            return EMPTY;
        }

        public bool isPresent()
        {
            return isPresent;
        }

        public bool isEmpty()
        {
            return !isPresent;
        }

        public int getAsInt()
        {
            if (!isPresent)
            {
                throw new InvalidOperationException("No value present");
            }
            return value;
        }

        public int orElse(int other)
        {
            return isPresent ? value : other;
        }

        public int orElseGet(Func<int> supplier)
        {
            if (supplier == null)
            {
                throw new ArgumentNullException("supplier");
            }
            return isPresent ? value : supplier();
        }

        public int orElseThrow()
        {
            if (!isPresent)
            {
                throw new InvalidOperationException("No value present");
            }
            return value;
        }

        public int orElseThrow(Func<Exception> exceptionSupplier)
        {
            if (exceptionSupplier == null)
            {
                throw new ArgumentNullException("exceptionSupplier");
            }
            if (isPresent)
            {
                return value;
            }
            throw exceptionSupplier();
        }

        public void ifPresent(Action<int> consumer)
        {
            if (consumer == null)
            {
                throw new ArgumentNullException("consumer");
            }
            if (isPresent)
            {
                consumer(value);
            }
        }

        public void ifPresentOrElse(Action<int> consumer, Action emptyAction)
        {
            if (consumer == null)
            {
                throw new ArgumentNullException("consumer");
            }
            if (emptyAction == null)
            {
                throw new ArgumentNullException("emptyAction");
            }
            if (isPresent)
            {
                consumer(value);
            }
            else
            {
                emptyAction();
            }
        }

        public override bool Equals(object obj)
        {
            OptionalInt other = obj as OptionalInt;
            if (other == null)
            {
                return false;
            }
            if (!isPresent && !other.isPresent)
            {
                return true;
            }
            if (isPresent && other.isPresent)
            {
                return value == other.value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return isPresent ? value : 0;
        }

        public override string ToString()
        {
            return isPresent ? "OptionalInt[" + value + "]" : "OptionalInt.empty";
        }
    }

    public class java_util_OptionalIntAutoTest
    {
        public void of_test_9694(int p0)
        {
            OptionalInt.of(p0);
        }

        public void empty_test_9695()
        {
            OptionalInt.empty();
        }
    }
}