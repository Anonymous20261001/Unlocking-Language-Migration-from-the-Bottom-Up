using System;
using System.Globalization;

namespace Generated.Test
{
    public static class IDN
    {
        public const int ALLOW_UNASSIGNED = 0x1;
        public const int USE_STD3_ASCII_RULES = 0x2;

        public static string toASCII(string input)
        {
            return toASCII(input, 0);
        }

        public static string toASCII(string input, int flag)
        {
            if ((flag & ~(ALLOW_UNASSIGNED | USE_STD3_ASCII_RULES)) != 0)
            {
                throw new ArgumentException("Invalid flag", nameof(flag));
            }

            var mapping = new IdnMapping
            {
                AllowUnassigned = (flag & ALLOW_UNASSIGNED) != 0,
                UseStd3AsciiRules = (flag & USE_STD3_ASCII_RULES) != 0
            };

            return mapping.GetAscii(input);
        }

        public static string toUnicode(string input)
        {
            return toUnicode(input, 0);
        }

        public static string toUnicode(string input, int flag)
        {
            if ((flag & ~(ALLOW_UNASSIGNED | USE_STD3_ASCII_RULES)) != 0)
            {
                throw new ArgumentException("Invalid flag", nameof(flag));
            }

            var mapping = new IdnMapping
            {
                AllowUnassigned = (flag & ALLOW_UNASSIGNED) != 0,
                UseStd3AsciiRules = (flag & USE_STD3_ASCII_RULES) != 0
            };

            return mapping.GetUnicode(input);
        }
    }

    public class java_net_IDNAutoTest
    {
        public void toASCII_test_5533(string p0, int p1)
        {
            IDN.toASCII(p0, p1);
        }

        public void toASCII_test_5534(string p0)
        {
            IDN.toASCII(p0);
        }

        public void toUnicode_test_5535(string p0)
        {
            IDN.toUnicode(p0);
        }

        public void toUnicode_test_5536(string p0, int p1)
        {
            IDN.toUnicode(p0, p1);
        }
    }
}