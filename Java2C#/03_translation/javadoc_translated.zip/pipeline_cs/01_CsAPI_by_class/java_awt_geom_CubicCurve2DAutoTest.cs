```csharp
using System;

namespace Generated.Test
{
    public class CubicCurve2D
    {
        private double x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2;

        public CubicCurve2D()
        {
        }

        public CubicCurve2D(double x1, double y1, double ctrlx1, double ctrly1, double ctrlx2, double ctrly2, double x2, double y2)
        {
            setCurve(x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2);
        }

        public double getX1()
        {
            return x1;
        }

        public double getY1()
        {
            return y1;
        }

        public double getCtrlX1()
        {
            return ctrlx1;
        }

        public double getCtrlY1()
        {
            return ctrly1;
        }

        public double getCtrlX2()
        {
            return ctrlx2;
        }

        public double getCtrlY2()
        {
            return ctrly2;
        }

        public double getX2()
        {
            return x2;
        }

        public double getY2()
        {
            return y2;
        }

        public void setCurve(double x1, double y1, double ctrlx1, double ctrly1, double ctrlx2, double ctrly2, double x2, double y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.ctrlx1 = ctrlx1;
            this.ctrly1 = ctrly1;
            this.ctrlx2 = ctrlx2;
            this.ctrly2 = ctrly2;
            this.x2 = x2;
            this.y2 = y2;
        }

        public void setCurve(double[] coords, int offset)
        {
            setCurve(coords[offset], coords[offset + 1], coords[offset + 2], coords[offset + 3],
                     coords[offset + 4], coords[offset + 5], coords[offset + 6], coords[offset + 7]);
        }

        public void subdivide(CubicCurve2D left, CubicCurve2D right)
        {
            if (left == null && right == null)
            {
                return;
            }

            double[] src = new double[] { x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2 };
            double[] l = new double[8];
            double[] r = new double[8];

            subdivide(src, 0, l, 0, r, 0);

            if (left != null)
            {
                left.setCurve(l, 0);
            }
            if (right != null)
            {
                right.setCurve(r, 0);
            }
        }

        public static void subdivide(double[] src, int srcoff, double[] left, int leftoff, double[] right, int rightoff)
        {
            double x1 = src[srcoff];
            double y1 = src[srcoff + 1];
            double ctrlx1 = src[srcoff + 2];
            double ctrly1 = src[srcoff + 3];
            double ctrlx2 = src[srcoff + 4];
            double ctrly2 = src[srcoff + 5];
            double x2 = src[srcoff + 6];
            double y2 = src[srcoff + 7];

            if (left != null)
            {
                left[leftoff] = x1;
                left[leftoff + 1] = y1;
            }
            if (right != null)
            {
                right[rightoff + 6] = x2;
                right[rightoff + 7] = y2;
            }

            x1 = (x1 + ctrlx1) / 2.0;
            y1 = (y1 + ctrly1) / 2.0;
            x2 = (x2 + ctrlx2) / 2.0;
            y2 = (y2 + ctrly2) / 2.0;

            double centerx = (ctrlx1 + ctrlx2) / 2.0;
            double centery = (ctrly1 + ctrly2) / 2.0;

            ctrlx1 = (x1 + centerx) / 2.0;
            ctrly1 = (y1 + centery) / 2.0;
            ctrlx2 = (x2 + centerx) / 2.0;
            ctrly2 = (y2 + centery) / 2.0;

            centerx = (ctrlx1 + ctrlx2) / 2.0;
            centery = (ctrly1 + ctrly2) / 2.0;

            if (left != null)
            {
                left[leftoff + 2] = x1;
                left[leftoff + 3] = y1;
                left[leftoff + 4] = ctrlx1;
                left[leftoff + 5] = ctrly1;
                left[leftoff + 6] = centerx;
                left[leftoff + 7] = centery;
            }
            if (right != null)
            {
                right[rightoff] = centerx;
                right[rightoff + 1] = centery;
                right[rightoff + 2] = ctrlx2;
                right[rightoff + 3] = ctrly2;
                right[rightoff + 4] = x2;
                right[rightoff + 5] = y2;
            }
        }

        public static void subdivide(CubicCurve2D src, CubicCurve2D left, CubicCurve2D right)
        {
            if (src == null)
            {
                return;
            }
            src.subdivide(left, right);
        }

        public static double getFlatnessSq(double x1, double y1, double ctrlx1, double ctrly1, double ctrlx2, double ctrly2, double x2, double y2)
        {
            return Math.Max(PtSegDistSq(x1, y1, x2, y2, ctrlx1, ctrly1),
                            PtSegDistSq(x1, y1, x2, y2, ctrlx2, ctrly2));
        }

        public static double getFlatnessSq(double[] coords, int offset)
        {
            return getFlatnessSq(coords[offset], coords[offset + 1], coords[offset + 2], coords[offset + 3],
                                 coords[offset + 4], coords[offset + 5], coords[offset + 6], coords[offset + 7]);
        }

        public static double getFlatness(double x1, double y1, double ctrlx1, double ctrly1, double ctrlx2, double ctrly2, double x2, double y2)
        {
            return Math.Sqrt(getFlatnessSq(x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2));
        }

        public static double getFlatness(double[] coords, int offset)
        {
            return Math.Sqrt(getFlatnessSq(coords, offset));
        }

        public static int solveCubic(double[] eqn)
        {
            return solveCubic(eqn, eqn);
        }

        public static int solveCubic(double[] eqn, double[] res)
        {
            double d = eqn[3];
            if (d == 0.0)
            {
                return solveQuadratic(eqn, res);
            }

            double a = eqn[2] / d;
            double b = eqn[1] / d;
            double c = eqn[0] / d;

            int roots = 0;
            double Q = (a * a - 3.0 * b) / 9.0;
            double R = (2.0 * a * a * a - 9.0 * a * b + 27.0 * c) / 54.0;
            double R2 = R * R;
            double Q3 = Q * Q * Q;

            a = a / 3.0;

            if (R2 < Q3)
            {
                double theta = Math.Acos(R / Math.Sqrt(Q3));
                Q = -2.0 * Math.Sqrt(Q);

                res[roots++] = Q * Math.Cos(theta / 3.0) - a;
                res[roots++] = Q * Math.Cos((theta + Math.PI * 2.0) / 3.0) - a;
                res[roots++] = Q * Math.Cos((theta - Math.PI * 2.0) / 3.0) - a;

                if (res[0] > res[1])
                {
                    double temp = res[0];
                    res[0] = res[1];
                    res[1] = temp;
                }
                if (res[0] > res[2])
                {
                    double temp = res[0];
                    res[0] = res[2];
                    res[2] = temp;
                }
                if (res[1] > res[2])
                {
                    double temp = res[1];
                    res[1] = res[2];
                    res[2] = temp;
                }
            }
            else
            {
                double A = -Math.Pow(Math.Abs(R) + Math.Sqrt(R2 - Q3), 1.0 / 3.0);
                if (R < 0.0)
                {
                    A = -A;
                }
                double B = (A == 0.0) ? 0.0 : (Q / A);
                res[roots++] = (A + B) - a;
            }

            return roots;
        }

        private static int solveQuadratic(double[] eqn, double[] res)
        {
            double a = eqn[2];
            double b = eqn[1];
            double c = eqn[0];

            int roots = 0;

            if (a == 0.0)
            {
                if (b == 0.0)
                {
                    return 0;
                }
                res[roots++] = -c / b;
            }
            else
            {
                double d = b * b - 4.0 * a * c;
                if (d < 0.0)
                {
                    return 0;
                }
                d = Math.Sqrt(d);
                res[roots++] = (-b + d) / (2.0 * a);
                res[roots++] = (-b - d) / (2.0 * a);

                if (res[0] > res[1])
                {
                    double temp = res[0];
                    res[0] = res[1];
                    res[1] = temp;
                }
            }

            return roots;
        }

        private static double PtSegDistSq(double x1, double y1, double x2, double y2, double px, double py)
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            double segLenSq = dx * dx + dy * dy;

            if (segLenSq == 0.0)
            {
                double ddx = px - x1;
                double ddy = py - y1;
                return ddx * ddx + ddy * ddy;
            }

            double t = ((px - x1) * dx + (py - y1) * dy) / segLenSq;

            if (t < 0.0)
            {
                double ddx = px - x1;
                double ddy = py - y1;
                return ddx * ddx + ddy * ddy;
            }

            if (t > 1.0)
            {
                double ddx = px - x2;
                double ddy = py - y2;
                return ddx * ddx + ddy * ddy;
            }

            double projX = x1 + t * dx;
            double projY = y1 + t * dy;
            double diffX = px - projX;
            double diffY = py - projY;
            return diffX * diffX + diffY * diffY;
        }
    }

    public class java_awt_geom_CubicCurve2DAutoTest
    {
        public void getFlatnessSq_test_3126(double p0, double p1, double p2, double p3, double p4,
            double p5, double p6, double p7)
        {
            CubicCurve2D.getFlatnessSq(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void getFlatnessSq_test_3127(double[] p0, int p1)
        {
            CubicCurve2D.getFlatnessSq(p0, p1);
        }

        public void getFlatness_test_3128(double[] p0, int p1)
        {
            CubicCurve2D.getFlatness(p0, p1);
        }

        public void getFlatness_test_3129(double p0, double p1, double p2, double p3, double p4,
            double p5, double p6, double p7)
        {
            CubicCurve2D.getFlatness(p0, p1, p2, p3, p4, p5, p6, p7);
        }

        public void subdivide_test_3130(double[] p0, int p1, double[] p2, int p3, double[] p4, int p5)
        {
            CubicCurve2D.subdivide(p0, p1, p2, p3, p4, p5);
        }

        public void subdivide_test_3131(CubicCurve2D p0, CubicCurve2D p1, CubicCurve2D p2)
        {
            CubicCurve2D.subdivide(p0, p1, p2);
        }

        public void solveCubic_test_3132(double[] p0, double[] p1)
        {
            CubicCurve2D.solveCubic(p0, p1);
        }

        public void solveCubic_test_3133(double[] p0)
        {
            CubicCurve2D.solveCubic(p0);
        }
    }
}
```