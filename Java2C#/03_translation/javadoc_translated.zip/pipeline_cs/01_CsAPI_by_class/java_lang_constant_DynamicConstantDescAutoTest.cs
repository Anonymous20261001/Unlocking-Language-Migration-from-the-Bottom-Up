namespace Generated.Test
{
    public interface ConstantDesc
    {
    }

    public interface ClassDesc : ConstantDesc
    {
    }

    public interface DirectMethodHandleDesc : ConstantDesc
    {
    }

    public abstract class DynamicConstantDesc : ConstantDesc
    {
        private sealed class Impl : DynamicConstantDesc
        {
            public Impl(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, ConstantDesc[] bootstrapArgs)
                : base(bootstrapMethod, constantName, constantType, bootstrapArgs)
            {
            }
        }

        public DirectMethodHandleDesc BootstrapMethod { get; }
        public string ConstantName { get; }
        public ClassDesc ConstantType { get; }
        public ConstantDesc[] BootstrapArgs { get; }

        protected DynamicConstantDesc(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, ConstantDesc[] bootstrapArgs)
        {
            BootstrapMethod = bootstrapMethod;
            ConstantName = constantName;
            ConstantType = constantType;
            BootstrapArgs = bootstrapArgs == null ? new ConstantDesc[0] : (ConstantDesc[])bootstrapArgs.Clone();
        }

        public static DynamicConstantDesc of(DirectMethodHandleDesc bootstrapMethod, params ConstantDesc[] bootstrapArgs)
        {
            return new Impl(bootstrapMethod, null, null, bootstrapArgs);
        }

        public static DynamicConstantDesc ofNamed(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, params ConstantDesc[] bootstrapArgs)
        {
            return new Impl(bootstrapMethod, constantName, constantType, bootstrapArgs);
        }

        public static DynamicConstantDesc ofCanonical(DirectMethodHandleDesc bootstrapMethod, string constantName, ClassDesc constantType, params ConstantDesc[] bootstrapArgs)
        {
            return new Impl(bootstrapMethod, constantName, constantType, bootstrapArgs);
        }
    }

    public class java_lang_constant_DynamicConstantDescAutoTest
    {
        public void of_test_4420(DirectMethodHandleDesc p0, ConstantDesc[] p1)
        {
            DynamicConstantDesc.of(p0, p1);
        }

        public void of_test_4421(DirectMethodHandleDesc p0)
        {
            DynamicConstantDesc.of(p0);
        }

        public void ofNamed_test_4422(DirectMethodHandleDesc p0, string p1, ClassDesc p2, ConstantDesc[] p3)
        {
            DynamicConstantDesc.ofNamed(p0, p1, p2, p3);
        }

        public void ofCanonical_test_4423(DirectMethodHandleDesc p0, string p1, ClassDesc p2, ConstantDesc[] p3)
        {
            DynamicConstantDesc.ofCanonical(p0, p1, p2, p3);
        }
    }
}