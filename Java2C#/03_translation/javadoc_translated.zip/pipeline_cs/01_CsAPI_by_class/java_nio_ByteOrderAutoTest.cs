namespace Generated.Test
{
    public class ByteOrder
    {
        public static readonly ByteOrder BIG_ENDIAN = new ByteOrder("BIG_ENDIAN");
        public static readonly ByteOrder LITTLE_ENDIAN = new ByteOrder("LITTLE_ENDIAN");

        private readonly string name;

        private ByteOrder(string name)
        {
            this.name = name;
        }

        public static ByteOrder nativeOrder()
        {
            return System.BitConverter.IsLittleEndian ? LITTLE_ENDIAN : BIG_ENDIAN;
        }

        public override string ToString()
        {
            return name;
        }
    }

    public class java_nio_ByteOrderAutoTest
    {
        public void nativeOrder_test_2007()
        {
            ByteOrder.nativeOrder();
        }
    }
}