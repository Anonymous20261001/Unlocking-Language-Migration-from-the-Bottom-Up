using System;

namespace Generated.Test
{
    public class Provider
    {
        public Provider() { }
    }

    public abstract class XMLSignatureFactory
    {
        protected XMLSignatureFactory() { }

        public static XMLSignatureFactory getInstance()
        {
            return new DefaultXMLSignatureFactory();
        }

        public static XMLSignatureFactory getInstance(string mechanism)
        {
            if (mechanism == null)
                throw new ArgumentNullException(nameof(mechanism));
            return new DefaultXMLSignatureFactory();
        }

        public static XMLSignatureFactory getInstance(string mechanism, Provider provider)
        {
            if (mechanism == null)
                throw new ArgumentNullException(nameof(mechanism));
            if (provider == null)
                throw new ArgumentNullException(nameof(provider));
            return new DefaultXMLSignatureFactory();
        }

        private sealed class DefaultXMLSignatureFactory : XMLSignatureFactory
        {
        }
    }

    public class javax_xml_crypto_dsig_XMLSignatureFactoryAutoTest
    {
        public void getInstance_test_13648(string p0)
        {
            XMLSignatureFactory.getInstance(p0);
        }

        public void getInstance_test_13649(string p0, Provider p1)
        {
            XMLSignatureFactory.getInstance(p0, p1);
        }

        public void getInstance_test_13650()
        {
            XMLSignatureFactory.getInstance();
        }
    }
}