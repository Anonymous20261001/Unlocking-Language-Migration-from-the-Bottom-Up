using System;

namespace Generated.Test
{
    public class Locale
    {
        private readonly string _language;
        private readonly string _country;
        private readonly string _variant;
        private static Locale _defaultLocale = new Locale("en", "US");

        public Locale(string language)
            : this(language, "", "")
        {
        }

        public Locale(string language, string country)
            : this(language, country, "")
        {
        }

        public Locale(string language, string country, string variant)
        {
            if (language == null) throw new ArgumentNullException("language");
            if (country == null) throw new ArgumentNullException("country");
            if (variant == null) throw new ArgumentNullException("variant");

            _language = language;
            _country = country;
            _variant = variant;
        }

        public string Language
        {
            get { return _language; }
        }

        public string Country
        {
            get { return _country; }
        }

        public string Variant
        {
            get { return _variant; }
        }

        public static Locale Default
        {
            get { return _defaultLocale; }
            set { _defaultLocale = value; }
        }

        public override bool Equals(object obj)
        {
            Locale other = obj as Locale;
            if (other == null) return false;

            return _language == other._language &&
                   _country == other._country &&
                   _variant == other._variant;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (_language != null ? _language.GetHashCode() : 0);
            hash = hash * 31 + (_country != null ? _country.GetHashCode() : 0);
            hash = hash * 31 + (_variant != null ? _variant.GetHashCode() : 0);
            return hash;
        }

        public override string ToString()
        {
            return _language + "_" + _country + "_" + _variant;
        }
    }

    public class DecimalStyle
    {
        private readonly Locale _locale;

        private DecimalStyle(Locale locale)
        {
            _locale = locale;
        }

        public static DecimalStyle of(Locale locale)
        {
            if (locale == null) throw new ArgumentNullException("locale");
            return new DecimalStyle(locale);
        }

        public static DecimalStyle ofDefaultLocale()
        {
            return new DecimalStyle(Locale.Default);
        }

        public static Locale[] getAvailableLocales()
        {
            return new Locale[]
            {
                new Locale("en", "US"),
                new Locale("en", "GB"),
                new Locale("de", "DE"),
                new Locale("fr", "FR"),
                Locale.Default
            };
        }
    }

    public class java_time_format_DecimalStyleAutoTest
    {
        public void of_test_3542()
        {
            Locale p0 = Locale.Default;
            DecimalStyle.of(p0);
        }

        public void getAvailableLocales_test_3543()
        {
            DecimalStyle.getAvailableLocales();
        }

        public void ofDefaultLocale_test_3544()
        {
            DecimalStyle.ofDefaultLocale();
        }
    }
}