namespace Generated.Test
{
    public class java_net_URIAutoTest
    {
        public void create_test_13237(string p0)
        {
            URI.create(p0);
        }
    }

    public class URI
    {
        private readonly string _value;

        private URI(string value)
        {
            _value = value;
        }

        public override string ToString()
        {
            return _value;
        }

        public static URI create(string str)
        {
            if (str == null)
            {
                throw new System.ArgumentNullException("str");
            }

            System.Uri parsedUri;
            if (!System.Uri.TryCreate(str, System.UriKind.RelativeOrAbsolute, out parsedUri))
            {
                throw new System.ArgumentException("Invalid URI");
            }

            return new URI(str);
        }
    }
}