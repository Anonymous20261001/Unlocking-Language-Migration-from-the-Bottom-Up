using System;

namespace Generated.Test
{
    public class LongBuffer
    {
        private long[] _array;
        private int _capacity;
        private int _position;
        private int _limit;

        private LongBuffer(long[] array, int capacity, int position, int limit)
        {
            _array = array;
            _capacity = capacity;
            _position = position;
            _limit = limit;
        }

        public static LongBuffer wrap(long[] array)
        {
            if (array == null)
                throw new ArgumentNullException("array");
            return new LongBuffer(array, array.Length, 0, array.Length);
        }

        public static LongBuffer wrap(long[] array, int offset, int length)
        {
            if (array == null)
                throw new ArgumentNullException("array");
            if (offset < 0 || length < 0 || offset > array.Length || length > array.Length - offset)
                throw new ArgumentOutOfRangeException();
            return new LongBuffer(array, array.Length, offset, offset + length);
        }

        public static LongBuffer allocate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentException("Negative capacity", "capacity");
            return new LongBuffer(new long[capacity], capacity, 0, capacity);
        }
    }

    public class java_nio_LongBufferAutoTest
    {
        public void wrap_test_8207(long[] p0)
        {
            LongBuffer.wrap(p0);
        }

        public void wrap_test_8208(long[] p0, int p1, int p2)
        {
            LongBuffer.wrap(p0, p1, p2);
        }

        public void allocate_test_8209(int p0)
        {
            LongBuffer.allocate(p0);
        }
    }
}