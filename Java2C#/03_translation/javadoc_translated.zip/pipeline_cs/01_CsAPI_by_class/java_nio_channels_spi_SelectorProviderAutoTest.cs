using System;

namespace Generated.Test
{
    public class java_nio_channels_spi_SelectorProviderAutoTest
    {
        public void provider_test_11022()
        {
            SelectorProvider.provider();
        }
    }

    public abstract class SelectorProvider
    {
        private static readonly SelectorProvider instance = new DefaultSelectorProvider();

        public static SelectorProvider provider()
        {
            return instance;
        }

        private class DefaultSelectorProvider : SelectorProvider
        {
        }
    }
}