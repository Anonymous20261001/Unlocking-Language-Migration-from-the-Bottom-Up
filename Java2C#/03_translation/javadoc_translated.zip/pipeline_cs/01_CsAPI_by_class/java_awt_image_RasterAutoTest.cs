namespace Generated.Test
{
    public class Point
    {
        public int x;
        public int y;

        public Point()
        {
        }

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

    public abstract class DataBuffer
    {
    }

    public abstract class SampleModel
    {
    }

    public class Raster
    {
        public static WritableRaster createInterleavedRaster(int dataType, int w, int h, int bands, int scanlineStride, int[] bandOffsets, Point location)
        {
            return null;
        }

        public static WritableRaster createInterleavedRaster(int dataType, int w, int h, int bands, Point location)
        {
            return null;
        }

        public static WritableRaster createInterleavedRaster(DataBuffer dataBuffer, int w, int h, int scanlineStride, int[] bandOffsets, Point location)
        {
            return null;
        }

        public static WritableRaster createInterleavedRaster(DataBuffer dataBuffer, int w, int h, int scanlineStride, int bands, int[] bandOffsets, Point location)
        {
            return null;
        }

        public static WritableRaster createPackedRaster(int dataType, int w, int h, int[] bandMasks, Point location)
        {
            return null;
        }

        public static WritableRaster createPackedRaster(int dataType, int w, int h, int bands, int bitsPerBand, Point location)
        {
            return null;
        }

        public static WritableRaster createPackedRaster(DataBuffer dataBuffer, int w, int h, int bitsPerPixel, int[] bandMasks, Point location)
        {
            return null;
        }

        public static WritableRaster createPackedRaster(DataBuffer dataBuffer, int w, int h, int bitsPerPixel, Point location)
        {
            return null;
        }

        public static WritableRaster createWritableRaster(SampleModel sampleModel, Point location)
        {
            return null;
        }

        public static WritableRaster createWritableRaster(SampleModel sampleModel, DataBuffer dataBuffer, Point location)
        {
            return null;
        }

        public static WritableRaster createBandedRaster(DataBuffer dataBuffer, int w, int h, int scanlineStride, int[] bankIndices, int[] bandOffsets, Point location)
        {
            return null;
        }

        public static WritableRaster createBandedRaster(int dataType, int w, int h, int bands, Point location)
        {
            return null;
        }

        public static WritableRaster createBandedRaster(int dataType, int w, int h, int bands, int[] bankIndices, int[] bandOffsets, Point location)
        {
            return null;
        }

        public static Raster createRaster(SampleModel sampleModel, DataBuffer dataBuffer, Point location)
        {
            return null;
        }
    }

    public class WritableRaster : Raster
    {
    }

    public class java_awt_image_RasterAutoTest
    {
        public void createInterleavedRaster_test_10325(int p0, int p1, int p2, int p3, int p4, int[] p5, Point p6)
        {
            Raster.createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createInterleavedRaster_test_10326(int p0, int p1, int p2, int p3, Point p4)
        {
            Raster.createInterleavedRaster(p0, p1, p2, p3, p4);
        }

        public void createInterleavedRaster_test_10327(DataBuffer p0, int p1, int p2, int p3, int p4, int[] p5, Point p6)
        {
            Raster.createInterleavedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createPackedRaster_test_10328(int p0, int p1, int p2, int[] p3, Point p4)
        {
            Raster.createPackedRaster(p0, p1, p2, p3, p4);
        }

        public void createPackedRaster_test_10329(int p0, int p1, int p2, int p3, int p4, Point p5)
        {
            Raster.createPackedRaster(p0, p1, p2, p3, p4, p5);
        }

        public void createPackedRaster_test_10330(DataBuffer p0, int p1, int p2, int p3, int[] p4, Point p5)
        {
            Raster.createPackedRaster(p0, p1, p2, p3, p4, p5);
        }

        public void createPackedRaster_test_10331(DataBuffer p0, int p1, int p2, int p3, Point p4)
        {
            Raster.createPackedRaster(p0, p1, p2, p3, p4);
        }

        public void createWritableRaster_test_10332(SampleModel p0, Point p1)
        {
            Raster.createWritableRaster(p0, p1);
        }

        public void createWritableRaster_test_10333(SampleModel p0, DataBuffer p1, Point p2)
        {
            Raster.createWritableRaster(p0, p1, p2);
        }

        public void createBandedRaster_test_10334(DataBuffer p0, int p1, int p2, int p3, int[] p4, int[] p5, Point p6)
        {
            Raster.createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createBandedRaster_test_10335(int p0, int p1, int p2, int p3, Point p4)
        {
            Raster.createBandedRaster(p0, p1, p2, p3, p4);
        }

        public void createBandedRaster_test_10336(int p0, int p1, int p2, int p3, int[] p4, int[] p5, Point p6)
        {
            Raster.createBandedRaster(p0, p1, p2, p3, p4, p5, p6);
        }

        public void createRaster_test_10337(SampleModel p0, DataBuffer p1, Point p2)
        {
            Raster.createRaster(p0, p1, p2);
        }
    }
}