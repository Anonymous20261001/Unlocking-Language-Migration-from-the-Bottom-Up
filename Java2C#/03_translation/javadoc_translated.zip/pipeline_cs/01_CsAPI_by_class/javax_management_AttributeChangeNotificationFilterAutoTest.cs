using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Notification
    {
        public string Type { get; set; }
        public object Source { get; set; }
        public long SequenceNumber { get; set; }
        public long TimeStamp { get; set; }
        public string Message { get; set; }
        public object UserData { get; set; }

        public Notification() { }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            Type = type;
            Source = source;
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            Message = message;
        }
    }

    public class AttributeChangeNotification : Notification
    {
        public string AttributeName { get; }
        public string AttributeType { get; }
        public object OldValue { get; }
        public object NewValue { get; }

        public AttributeChangeNotification(
            object source,
            long sequenceNumber,
            long timeStamp,
            string message,
            string attributeName,
            string attributeType,
            object oldValue,
            object newValue)
            : base("jmx.attribute.change", source, sequenceNumber, timeStamp, message)
        {
            AttributeName = attributeName;
            AttributeType = attributeType;
            OldValue = oldValue;
            NewValue = newValue;
        }
    }

    public class AttributeChangeNotificationFilter
    {
        private List<string> enabledAttributes = new List<string>();

        public void enableAttribute(string attributeName)
        {
            if (attributeName == null)
                throw new ArgumentNullException(nameof(attributeName));
            if (!enabledAttributes.Contains(attributeName))
                enabledAttributes.Add(attributeName);
        }

        public void disableAttribute(string attributeName)
        {
            enabledAttributes.Remove(attributeName);
        }

        public void disableAllAttributes()
        {
            enabledAttributes.Clear();
        }

        public List<string> getEnabledAttributes()
        {
            return enabledAttributes;
        }

        public bool isNotificationEnabled(Notification notification)
        {
            if (notification == null)
                return false;
            if (!(notification is AttributeChangeNotification))
                return false;
            AttributeChangeNotification acn = (AttributeChangeNotification)notification;
            return enabledAttributes.Contains(acn.AttributeName);
        }
    }

    public class javax_management_AttributeChangeNotificationFilterAutoTest
    {
        public void isNotificationEnabled_test_762(Notification p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.isNotificationEnabled(p0);
        }

        public void enableAttribute_test_763(string p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.enableAttribute(p0);
        }

        public void disableAttribute_test_764(string p0)
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.disableAttribute(p0);
        }

        public void disableAllAttributes_test_765()
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.disableAllAttributes();
        }

        public void getEnabledAttributes_test_766()
        {
            AttributeChangeNotificationFilter instance = new AttributeChangeNotificationFilter();
            instance.getEnabledAttributes();
        }
    }
}