using System;
using java.lang;
using java.rmi.server;

namespace Generated.Test
{
    public class java_rmi_server_RMIClassLoaderAutoTest
    {
        public void getClassAnnotation_test_10630(Type p0)
        {
            RMIClassLoader.getClassAnnotation(p0);
        }

        public void getDefaultProviderInstance_test_10631()
        {
            RMIClassLoader.getDefaultProviderInstance();
        }

        public void getSecurityContext_test_10632(ClassLoader p0)
        {
            RMIClassLoader.getSecurityContext(p0);
        }
    }
}

namespace java.rmi.server
{
    public class RMIClassLoader
    {
        private static readonly RMIClassLoaderSpi defaultProvider = new RMIClassLoaderSpi();

        public static string getClassAnnotation(Type cl)
        {
            return string.Empty;
        }

        public static RMIClassLoaderSpi getDefaultProviderInstance()
        {
            return defaultProvider;
        }

        public static object getSecurityContext(ClassLoader loader)
        {
            return null;
        }
    }

    public class RMIClassLoaderSpi
    {
    }
}

namespace java.lang
{
    public class ClassLoader
    {
    }
}