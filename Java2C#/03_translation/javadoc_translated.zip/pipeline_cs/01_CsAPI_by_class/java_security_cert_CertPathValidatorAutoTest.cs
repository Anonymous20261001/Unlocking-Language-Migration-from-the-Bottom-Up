using System;

namespace Generated.Test
{
    public class java_security_cert_CertPathValidatorAutoTest
    {
        public void getDefaultType_test_2101()
        {
            CertPathValidator.getDefaultType();
        }
    }

    public class CertPathValidator
    {
        public static string getDefaultType()
        {
            return "PKIX";
        }
    }
}