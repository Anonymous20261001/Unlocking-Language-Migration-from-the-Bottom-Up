using System;

namespace Generated.Test
{
    public abstract class XPathFactory
    {
        private sealed class DefaultXPathFactory : XPathFactory
        {
        }

        public static XPathFactory newDefaultInstance()
        {
            return new DefaultXPathFactory();
        }

        public static XPathFactory newInstance()
        {
            return new DefaultXPathFactory();
        }
    }

    public class javax_xml_xpath_XPathFactoryAutoTest
    {
        public void newDefaultInstance_test_13657()
        {
            XPathFactory.newDefaultInstance();
        }

        public void newInstance_test_13658()
        {
            XPathFactory.newInstance();
        }
    }
}