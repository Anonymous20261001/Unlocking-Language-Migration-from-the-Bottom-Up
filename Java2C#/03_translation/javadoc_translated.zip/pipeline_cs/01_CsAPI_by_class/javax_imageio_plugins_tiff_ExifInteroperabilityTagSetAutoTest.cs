namespace Generated.Test
{
    public class ExifInteroperabilityTagSet
    {
        private static readonly ExifInteroperabilityTagSet instance = new ExifInteroperabilityTagSet();

        private ExifInteroperabilityTagSet()
        {
        }

        public static ExifInteroperabilityTagSet getInstance()
        {
            return instance;
        }
    }

    public class javax_imageio_plugins_tiff_ExifInteroperabilityTagSetAutoTest
    {
        public void getInstance_test_4662()
        {
            ExifInteroperabilityTagSet.getInstance();
        }
    }
}