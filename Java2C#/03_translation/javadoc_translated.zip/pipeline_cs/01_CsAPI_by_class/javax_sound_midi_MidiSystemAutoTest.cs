namespace Generated.Test
{
    public static class MidiSystem
    {
        public static bool isFileTypeSupported(int fileType)
        {
            return false;
        }

        public static bool isFileTypeSupported(int fileType, Sequence sequence)
        {
            return false;
        }

        public static int[] getMidiFileTypes()
        {
            return new int[0];
        }

        public static int[] getMidiFileTypes(Sequence sequence)
        {
            return new int[0];
        }

        public static MidiDevice.Info[] getMidiDeviceInfo()
        {
            return new MidiDevice.Info[0];
        }
    }

    public class Sequence
    {
    }

    public class MidiDevice
    {
        public class Info
        {
        }
    }

    public class javax_sound_midi_MidiSystemAutoTest
    {
        public void isFileTypeSupported_test_8942(int p0)
        {
            MidiSystem.isFileTypeSupported(p0);
        }

        public void isFileTypeSupported_test_8943(int p0, Sequence p1)
        {
            MidiSystem.isFileTypeSupported(p0, p1);
        }

        public void getMidiFileTypes_test_8944(Sequence p0)
        {
            MidiSystem.getMidiFileTypes(p0);
        }

        public void getMidiFileTypes_test_8945()
        {
            MidiSystem.getMidiFileTypes();
        }

        public void getMidiDeviceInfo_test_8946()
        {
            MidiSystem.getMidiDeviceInfo();
        }
    }
}