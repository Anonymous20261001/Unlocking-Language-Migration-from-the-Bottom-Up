using System;

namespace Generated.Test
{
    public class java_util_concurrent_ThreadLocalRandomAutoTest
    {
        public void current_test_12713()
        {
            ThreadLocalRandom.current();
        }
    }

    public class ThreadLocalRandom
    {
        [ThreadStatic]
        private static ThreadLocalRandom _current;

        private ThreadLocalRandom()
        {
        }

        public static ThreadLocalRandom current()
        {
            if (_current == null)
            {
                _current = new ThreadLocalRandom();
            }
            return _current;
        }
    }
}