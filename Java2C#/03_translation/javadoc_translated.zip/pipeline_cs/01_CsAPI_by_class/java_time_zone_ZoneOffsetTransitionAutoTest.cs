using System;

namespace Generated.Test
{
    public sealed class LocalDateTime
    {
        private readonly DateTime _dateTime;

        private LocalDateTime(DateTime dateTime)
        {
            _dateTime = dateTime;
        }

        public static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute)
        {
            return new LocalDateTime(new DateTime(year, month, dayOfMonth, hour, minute, 0));
        }

        public static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second)
        {
            return new LocalDateTime(new DateTime(year, month, dayOfMonth, hour, minute, second));
        }

        public static LocalDateTime of(int year, int month, int dayOfMonth, int hour, int minute, int second, int nanoOfSecond)
        {
            DateTime dt = new DateTime(year, month, dayOfMonth, hour, minute, second);
            dt = dt.AddTicks(nanoOfSecond / 100);
            return new LocalDateTime(dt);
        }

        public DateTime ToDateTime()
        {
            return _dateTime;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != typeof(LocalDateTime))
                return false;
            LocalDateTime other = (LocalDateTime)obj;
            return _dateTime.Equals(other._dateTime);
        }

        public override int GetHashCode()
        {
            return _dateTime.GetHashCode();
        }

        public override string ToString()
        {
            return _dateTime.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff");
        }
    }

    public sealed class ZoneOffset
    {
        private readonly int _totalSeconds;

        private ZoneOffset(int totalSeconds)
        {
            _totalSeconds = totalSeconds;
        }

        public int TotalSeconds
        {
            get { return _totalSeconds; }
        }

        public static ZoneOffset ofHours(int hours)
        {
            return new ZoneOffset(hours * 3600);
        }

        public static ZoneOffset ofHoursMinutes(int hours, int minutes)
        {
            return new ZoneOffset(hours * 3600 + minutes * 60);
        }

        public static ZoneOffset ofTotalSeconds(int totalSeconds)
        {
            return new ZoneOffset(totalSeconds);
        }

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != typeof(ZoneOffset))
                return false;
            ZoneOffset other = (ZoneOffset)obj;
            return _totalSeconds == other._totalSeconds;
        }

        public override int GetHashCode()
        {
            return _totalSeconds;
        }

        public override string ToString()
        {
            if (_totalSeconds == 0)
                return "Z";

            string sign = _totalSeconds < 0 ? "-" : "+";
            int abs = Math.Abs(_totalSeconds);
            int hours = abs / 3600;
            int minutes = (abs % 3600) / 60;
            return sign + hours.ToString("00") + ":" + minutes.ToString("00");
        }
    }

    public sealed class ZoneOffsetTransition
    {
        private readonly LocalDateTime _transition;
        private readonly ZoneOffset _offsetBefore;
        private readonly ZoneOffset _offsetAfter;

        private ZoneOffsetTransition(LocalDateTime transition, ZoneOffset offsetBefore, ZoneOffset offsetAfter)
        {
            if (transition == null)
                throw new ArgumentNullException("transition");
            if (offsetBefore == null)
                throw new ArgumentNullException("offsetBefore");
            if (offsetAfter == null)
                throw new ArgumentNullException("offsetAfter");
            if (offsetBefore.Equals(offsetAfter))
                throw new ArgumentException("Offsets must be different", "offsetAfter");

            _transition = transition;
            _offsetBefore = offsetBefore;
            _offsetAfter = offsetAfter;
        }

        public static ZoneOffsetTransition of(LocalDateTime transition, ZoneOffset offsetBefore, ZoneOffset offsetAfter)
        {
            return new ZoneOffsetTransition(transition, offsetBefore, offsetAfter);
        }

        public LocalDateTime Transition
        {
            get { return _transition; }
        }

        public ZoneOffset OffsetBefore
        {
            get { return _offsetBefore; }
        }

        public ZoneOffset OffsetAfter
        {
            get { return _offsetAfter; }
        }
    }

    public class java_time_zone_ZoneOffsetTransitionAutoTest
    {
        public void of_test_13734(LocalDateTime p0, ZoneOffset p1, ZoneOffset p2)
        {
            ZoneOffsetTransition.of(p0, p1, p2);
        }
    }
}