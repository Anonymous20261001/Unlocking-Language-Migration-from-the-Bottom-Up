using System;
using System.Collections.Generic;
using System.Text;

namespace Generated.Test
{
    public class java_nio_charset_CharsetAutoTest
    {
        public void forName_test_2235(string p0, Charset p1)
        {
            Charset.forName(p0, p1);
        }

        public void forName_test_2236(string p0)
        {
            Charset.forName(p0);
        }

        public void defaultCharset_test_2237()
        {
            Charset.defaultCharset();
        }

        public void isSupported_test_2238(string p0)
        {
            Charset.isSupported(p0);
        }

        public void availableCharsets_test_2239()
        {
            Charset.availableCharsets();
        }
    }

    public class Charset
    {
        public string Name { get; private set; }
        public System.Text.Encoding CharsetEncoding { get; private set; }

        private Charset(string name, System.Text.Encoding encoding)
        {
            Name = name;
            CharsetEncoding = encoding;
        }

        private static readonly Dictionary<string, string> AliasMap =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "UTF-8", "utf-8" },
                { "UTF8", "utf-8" },
                { "US-ASCII", "us-ascii" },
                { "ASCII", "us-ascii" },
                { "ISO-8859-1", "iso-8859-1" },
                { "ISO8859_1", "iso-8859-1" },
                { "ISO8859-1", "iso-8859-1" },
                { "UTF-16", "utf-16" },
                { "UTF-16LE", "utf-16le" },
                { "UTF-16BE", "utf-16be" },
                { "UTF-32", "utf-32" },
                { "windows-1252", "windows-1252" },
                { "cp1252", "windows-1252" }
            };

        private static Charset GetCharsetFromName(string charsetName)
        {
            if (charsetName == null)
                return null;

            string netName;
            if (!AliasMap.TryGetValue(charsetName, out netName))
                netName = charsetName;

            try
            {
                Encoding enc = Encoding.GetEncoding(netName);
                return new Charset(charsetName, enc);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static Charset forName(string charsetName)
        {
            Charset cs = GetCharsetFromName(charsetName);
            if (cs == null)
                throw new ArgumentException("Unsupported charset: " + charsetName);
            return cs;
        }

        public static Charset forName(string charsetName, Charset fallback)
        {
            Charset cs = GetCharsetFromName(charsetName);
            if (cs != null)
                return cs;
            if (fallback == null)
                throw new ArgumentException("Unsupported charset: " + charsetName);
            return fallback;
        }

        public static Charset defaultCharset()
        {
            Encoding def = Encoding.Default;
            return new Charset(def.WebName, def);
        }

        public static bool isSupported(string charsetName)
        {
            return GetCharsetFromName(charsetName) != null;
        }

        public static SortedDictionary<string, Charset> availableCharsets()
        {
            SortedDictionary<string, Charset> result =
                new SortedDictionary<string, Charset>(StringComparer.Ordinal);

            string[] names =
            {
                "UTF-8",
                "US-ASCII",
                "ISO-8859-1",
                "UTF-16",
                "UTF-16LE",
                "UTF-16BE",
                "UTF-32",
                "windows-1252"
            };

            foreach (string name in names)
            {
                Charset cs = GetCharsetFromName(name);
                if (cs != null)
                    result[name] = cs;
            }

            return result;
        }
    }
}