namespace Generated.Test
{
    public class HttpClient
    {
        private HttpClient()
        {
        }

        public static HttpClient newHttpClient()
        {
            return new HttpClient();
        }

        public static Builder newBuilder()
        {
            return new Builder();
        }

        public class Builder
        {
            public HttpClient build()
            {
                return new HttpClient();
            }
        }
    }

    public class java_net_http_HttpClientAutoTest
    {
        public void newBuilder_test_5409()
        {
            HttpClient.newBuilder();
        }

        public void newHttpClient_test_5410()
        {
            HttpClient.newHttpClient();
        }
    }
}