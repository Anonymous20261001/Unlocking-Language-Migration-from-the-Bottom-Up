using System;

namespace Generated.Test
{
    public class HexFormat
    {
        private readonly string _delimiter;
        private readonly string _prefix;
        private readonly string _suffix;
        private readonly bool _upperCase;

        public HexFormat() : this("")
        {
        }

        public HexFormat(string delimiter)
        {
            if (delimiter == null)
                throw new NullReferenceException();

            if (!IsValidDelimiter(delimiter))
                throw new ArgumentException("Invalid delimiter");

            _delimiter = delimiter;
            _prefix = "";
            _suffix = "";
            _upperCase = false;
        }

        public static HexFormat of()
        {
            return new HexFormat("");
        }

        public static HexFormat ofDelimiter(string delimiter)
        {
            return new HexFormat(delimiter);
        }

        public static int fromHexDigit(int ch)
        {
            if (ch >= '0' && ch <= '9')
                return ch - '0';
            if (ch >= 'a' && ch <= 'f')
                return ch - 'a' + 10;
            if (ch >= 'A' && ch <= 'F')
                return ch - 'A' + 10;
            return -1;
        }

        public static bool isHexDigit(int ch)
        {
            return fromHexDigit(ch) >= 0;
        }

        public static int fromHexDigits(string s)
        {
            if (s == null)
                throw new NullReferenceException();
            return fromHexDigits(s, 0, s.Length);
        }

        public static int fromHexDigits(string s, int fromIndex, int toIndex)
        {
            if (s == null)
                throw new NullReferenceException();

            CheckRange(s, fromIndex, toIndex);

            int length = toIndex - fromIndex;
            if (length < 1 || length > 8)
                throw new ArgumentException("hex string length must be 1 to 8");

            int result = 0;
            for (int i = fromIndex; i < toIndex; i++)
            {
                int digit = fromHexDigit(s[i]);
                if (digit < 0)
                    throw new ArgumentException("invalid hex digit");
                result = (result << 4) | digit;
            }
            return result;
        }

        public static long fromHexDigitsToLong(string s)
        {
            if (s == null)
                throw new NullReferenceException();
            return fromHexDigitsToLong(s, 0, s.Length);
        }

        public static long fromHexDigitsToLong(string s, int fromIndex, int toIndex)
        {
            if (s == null)
                throw new NullReferenceException();

            CheckRange(s, fromIndex, toIndex);

            int length = toIndex - fromIndex;
            if (length < 1 || length > 16)
                throw new ArgumentException("hex string length must be 1 to 16");

            long result = 0;
            for (int i = fromIndex; i < toIndex; i++)
            {
                int digit = fromHexDigit(s[i]);
                if (digit < 0)
                    throw new ArgumentException("invalid hex digit");
                result = (result << 4) | digit;
            }
            return result;
        }

        private static bool IsValidDelimiter(string delimiter)
        {
            if (delimiter == null || delimiter.Length > 2)
                return false;

            foreach (char c in delimiter)
            {
                if (c < 0x20 || c > 0x7E)
                    return false;
            }
            return true;
        }

        private static void CheckRange(string s, int fromIndex, int toIndex)
        {
            if (fromIndex < 0 || fromIndex > toIndex || toIndex > s.Length)
                throw new ArgumentOutOfRangeException();
        }
    }

    public class java_util_HexFormatAutoTest
    {
        public void of_test_5337()
        {
            HexFormat.of();
        }

        public void fromHexDigits_test_5338(string p0)
        {
            HexFormat.fromHexDigits(p0);
        }

        public void fromHexDigits_test_5339(string p0, int p1, int p2)
        {
            HexFormat.fromHexDigits(p0, p1, p2);
        }

        public void fromHexDigit_test_5340(int p0)
        {
            HexFormat.fromHexDigit(p0);
        }

        public void fromHexDigitsToLong_test_5341(string p0, int p1, int p2)
        {
            HexFormat.fromHexDigitsToLong(p0, p1, p2);
        }

        public void fromHexDigitsToLong_test_5342(string p0)
        {
            HexFormat.fromHexDigitsToLong(p0);
        }

        public void ofDelimiter_test_5343(string p0)
        {
            HexFormat.ofDelimiter(p0);
        }

        public void isHexDigit_test_5344(int p0)
        {
            HexFormat.isHexDigit(p0);
        }
    }
}