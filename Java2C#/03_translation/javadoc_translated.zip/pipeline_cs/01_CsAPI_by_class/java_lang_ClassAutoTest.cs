using System;

namespace Generated.Test
{
    public sealed class Module
    {
    }

    public static class Class
    {
        public static Type forName(Module module, string name)
        {
            return Type.GetType(name, false);
        }

        public static Type forPrimitiveName(string name)
        {
            switch (name)
            {
                case "boolean": return typeof(bool);
                case "byte": return typeof(byte);
                case "char": return typeof(char);
                case "short": return typeof(short);
                case "int": return typeof(int);
                case "long": return typeof(long);
                case "float": return typeof(float);
                case "double": return typeof(double);
                case "void": return typeof(void);
                default: return null;
            }
        }
    }

    public class java_lang_ClassAutoTest
    {
        public void forName_test_2310(Module p0, string p1)
        {
            Class.forName(p0, p1);
        }

        public void forPrimitiveName_test_2311(string p0)
        {
            Class.forPrimitiveName(p0);
        }
    }
}