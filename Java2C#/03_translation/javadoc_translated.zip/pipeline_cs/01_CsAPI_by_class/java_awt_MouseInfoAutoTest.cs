namespace Generated.Test
{
    public class PointerInfo
    {
    }

    public static class MouseInfo
    {
        public static int getNumberOfButtons()
        {
            return -1;
        }

        public static PointerInfo getPointerInfo()
        {
            return new PointerInfo();
        }
    }

    public class java_awt_MouseInfoAutoTest
    {
        public void getNumberOfButtons_test_9025()
        {
            MouseInfo.getNumberOfButtons();
        }

        public void getPointerInfo_test_9026()
        {
            MouseInfo.getPointerInfo();
        }
    }
}