using System;

namespace Generated.Test
{
    public class javax_net_ssl_SSLSocketFactoryAutoTest
    {
        public void getDefault_test_11440()
        {
            javax.net.ssl.SSLSocketFactory.GetDefault();
        }
    }
}

namespace javax.net.ssl
{
    public abstract class SSLSocketFactory
    {
        public static SSLSocketFactory GetDefault()
        {
            return new DefaultSSLSocketFactory();
        }

        private sealed class DefaultSSLSocketFactory : SSLSocketFactory
        {
        }
    }
}