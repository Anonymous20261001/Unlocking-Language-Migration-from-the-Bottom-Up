namespace Generated.Test
{
    public interface CharSequence { }
    public interface TemporalAmount { }
    public interface TemporalUnit { }
    public interface Temporal { }

    public class Duration
    {
        private readonly long seconds;
        private readonly int nanos;

        private Duration(long seconds, int nanos)
        {
            this.seconds = seconds;
            this.nanos = nanos;
        }

        public static Duration of(long amount, TemporalUnit unit)
        {
            return new Duration(0, 0);
        }

        public static Duration from(TemporalAmount amount)
        {
            return new Duration(0, 0);
        }

        public static Duration parse(CharSequence text)
        {
            return new Duration(0, 0);
        }

        public static Duration between(Temporal startInclusive, Temporal endExclusive)
        {
            return new Duration(0, 0);
        }

        public static Duration ofSeconds(long seconds)
        {
            return new Duration(seconds, 0);
        }

        public static Duration ofSeconds(long seconds, long nanoAdjustment)
        {
            return new Duration(seconds, (int)nanoAdjustment);
        }

        public static Duration ofNanos(long nanos)
        {
            return new Duration(nanos / 1000000000L, (int)(nanos % 1000000000L));
        }

        public static Duration ofDays(long days)
        {
            return new Duration(days * 86400L, 0);
        }

        public static Duration ofHours(long hours)
        {
            return new Duration(hours * 3600L, 0);
        }

        public static Duration ofMinutes(long minutes)
        {
            return new Duration(minutes * 60L, 0);
        }

        public static Duration ofMillis(long millis)
        {
            return new Duration(millis / 1000L, (int)((millis % 1000L) * 1000000L));
        }
    }

    public class java_time_DurationAutoTest
    {
        public void of_test_4406(long p0, TemporalUnit p1)
        {
            Duration.of(p0, p1);
        }

        public void from_test_4407(TemporalAmount p0)
        {
            Duration.from(p0);
        }

        public void parse_test_4408(CharSequence p0)
        {
            Duration.parse(p0);
        }

        public void between_test_4409(Temporal p0, Temporal p1)
        {
            Duration.between(p0, p1);
        }

        public void ofSeconds_test_4410(long p0, long p1)
        {
            Duration.ofSeconds(p0, p1);
        }

        public void ofSeconds_test_4411(long p0)
        {
            Duration.ofSeconds(p0);
        }

        public void ofNanos_test_4412(long p0)
        {
            Duration.ofNanos(p0);
        }

        public void ofDays_test_4413(long p0)
        {
            Duration.ofDays(p0);
        }

        public void ofHours_test_4414(long p0)
        {
            Duration.ofHours(p0);
        }

        public void ofMinutes_test_4415(long p0)
        {
            Duration.ofMinutes(p0);
        }

        public void ofMillis_test_4416(long p0)
        {
            Duration.ofMillis(p0);
        }
    }
}