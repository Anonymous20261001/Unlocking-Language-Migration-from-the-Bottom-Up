namespace Generated.Test
{
    public static class QueryEval
    {
        public static object getMBeanServer()
        {
            return null;
        }
    }

    public class javax_management_QueryEvalAutoTest
    {
        public void getMBeanServer_test_10293()
        {
            QueryEval.getMBeanServer();
        }
    }
}