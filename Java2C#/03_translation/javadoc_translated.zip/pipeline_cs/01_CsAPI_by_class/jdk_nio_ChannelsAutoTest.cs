namespace Generated.Test
{
    public class FileDescriptor
    {
    }

    public class Channels
    {
        private Channels() { }

        public interface SelectableChannelCloser
        {
        }

        public static SelectableChannel readWriteSelectableChannel(FileDescriptor p0, SelectableChannelCloser p1)
        {
            return null;
        }
    }

    public class SelectableChannel
    {
    }

    public class jdk_nio_ChannelsAutoTest
    {
        public void readWriteSelectableChannel_test_2124(FileDescriptor p0, Channels.SelectableChannelCloser p1)
        {
            Channels.readWriteSelectableChannel(p0, p1);
        }
    }
}