using System;

namespace Generated.Test
{
    public class Preferences
    {
        private static readonly Preferences userRootInstance = new Preferences("/", true);
        private static readonly Preferences systemRootInstance = new Preferences("/", false);

        private readonly string absolutePath;
        private readonly bool isUserRoot;

        private Preferences(string absolutePath, bool isUserRoot)
        {
            this.absolutePath = absolutePath;
            this.isUserRoot = isUserRoot;
        }

        public static Preferences userRoot()
        {
            return userRootInstance;
        }

        public static Preferences systemRoot()
        {
            return systemRootInstance;
        }

        public static Preferences userNodeForPackage(Type p0)
        {
            return GetPackageNode(p0, true);
        }

        public static Preferences systemNodeForPackage(Type p0)
        {
            return GetPackageNode(p0, false);
        }

        private static Preferences GetPackageNode(Type p0, bool user)
        {
            if (p0 == null)
            {
                throw new ArgumentNullException(nameof(p0));
            }

            string packageName = p0.Namespace ?? string.Empty;
            string path;

            if (packageName.Length == 0)
            {
                path = "/<unnamed>";
            }
            else
            {
                path = "/" + packageName.Replace('.', '/');
            }

            return new Preferences(path, user);
        }
    }

    public class java_util_prefs_PreferencesAutoTest
    {
        public void userRoot_test_10000()
        {
            Preferences.userRoot();
        }

        public void systemRoot_test_10001()
        {
            Preferences.systemRoot();
        }

        public void userNodeForPackage_test_10002(Type p0)
        {
            Preferences.userNodeForPackage(p0);
        }

        public void systemNodeForPackage_test_10003(Type p0)
        {
            Preferences.systemNodeForPackage(p0);
        }
    }
}