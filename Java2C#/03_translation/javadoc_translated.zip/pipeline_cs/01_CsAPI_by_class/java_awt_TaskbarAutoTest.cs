namespace java.awt
{
    public class Taskbar
    {
        private static readonly Taskbar instance = new Taskbar();

        private Taskbar()
        {
        }

        public static bool isTaskbarSupported()
        {
            return true;
        }

        public static Taskbar getTaskbar()
        {
            return instance;
        }
    }
}

namespace Generated.Test
{
    using java.awt;

    public class java_awt_TaskbarAutoTest
    {
        public void getTaskbar_test_12518()
        {
            Taskbar.getTaskbar();
        }

        public void isTaskbarSupported_test_12519()
        {
            Taskbar.isTaskbarSupported();
        }
    }
}