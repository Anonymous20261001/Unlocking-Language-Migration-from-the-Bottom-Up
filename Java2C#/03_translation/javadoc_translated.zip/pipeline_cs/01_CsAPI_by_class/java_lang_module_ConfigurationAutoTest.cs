using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public interface ModuleFinder
    {
    }

    public sealed class Configuration
    {
        public static Configuration empty()
        {
            return new Configuration();
        }

        public static Configuration resolve(
            ModuleFinder before,
            IList<Configuration> parents,
            ModuleFinder after,
            ICollection<string> roots)
        {
            return new Configuration();
        }

        public static Configuration resolveAndBind(
            ModuleFinder before,
            IList<Configuration> parents,
            ModuleFinder after,
            ICollection<string> roots)
        {
            return new Configuration();
        }
    }

    public class java_lang_module_ConfigurationAutoTest
    {
        public void empty_test_2903()
        {
            Configuration.empty();
        }

        public void resolve_test_2904()
        {
            Configuration.resolve(
                null,
                new List<Configuration>(),
                null,
                new List<string>());
        }

        public void resolveAndBind_test_2905()
        {
            Configuration.resolveAndBind(
                null,
                new List<Configuration>(),
                null,
                new List<string>());
        }
    }
}