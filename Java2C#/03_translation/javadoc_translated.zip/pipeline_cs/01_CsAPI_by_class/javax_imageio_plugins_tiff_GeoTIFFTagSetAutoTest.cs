using System;

namespace Generated.Test
{
    public class GeoTIFFTagSet
    {
        private static readonly GeoTIFFTagSet instance = new GeoTIFFTagSet();

        private GeoTIFFTagSet()
        {
        }

        public static GeoTIFFTagSet getInstance()
        {
            return instance;
        }
    }

    public class javax_imageio_plugins_tiff_GeoTIFFTagSetAutoTest
    {
        public void getInstance_test_5102()
        {
            GeoTIFFTagSet.getInstance();
        }
    }
}