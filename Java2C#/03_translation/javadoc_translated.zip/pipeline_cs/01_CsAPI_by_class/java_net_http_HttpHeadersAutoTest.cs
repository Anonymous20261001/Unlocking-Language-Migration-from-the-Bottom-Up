using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class HttpHeaders
    {
        private readonly IReadOnlyDictionary<string, IReadOnlyList<string>> _headers;

        private HttpHeaders(IReadOnlyDictionary<string, IReadOnlyList<string>> headers)
        {
            _headers = headers;
        }

        public static HttpHeaders Of(IDictionary<string, List<string>> headerMap, Func<string, string, bool> filter)
        {
            if (headerMap == null) throw new ArgumentNullException(nameof(headerMap));
            if (filter == null) throw new ArgumentNullException(nameof(filter));

            var result = new Dictionary<string, IReadOnlyList<string>>();

            foreach (var entry in headerMap)
            {
                if (entry.Key == null || entry.Value == null) continue;

                var values = new List<string>();
                foreach (var value in entry.Value)
                {
                    if (value != null && filter(entry.Key, value))
                    {
                        values.Add(value);
                    }
                }

                result.Add(entry.Key, values.AsReadOnly());
            }

            return new HttpHeaders(result);
        }

        public IReadOnlyDictionary<string, IReadOnlyList<string>> Headers => _headers;
    }

    public class java_net_http_HttpHeadersAutoTest
    {
        public void of_test_5437(IDictionary<string, List<string>> p0, Func<string, string, bool> p1)
        {
            HttpHeaders.Of(p0, p1);
        }
    }
}