```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class Notification
    {
        private string _type;
        private object _source;
        private long _sequenceNumber;
        private long _timeStamp;
        private string _message;
        private object _userData;

        public Notification(string type, object source, long sequenceNumber)
            : this(type, source, sequenceNumber, CurrentTimeMillis(), null)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp)
            : this(type, source, sequenceNumber, timeStamp, null)
        {
        }

        public Notification(string type, object source, long sequenceNumber, string message)
            : this(type, source, sequenceNumber, CurrentTimeMillis(), message)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, string message)
        {
            _type = type;
            _source = source;
            _sequenceNumber = sequenceNumber;
            _timeStamp = timeStamp;
            _message = message;
        }

        public string getType()
        {
            return _type;
        }

        public object getSource()
        {
            return _source;
        }

        public long getSequenceNumber()
        {
            return _sequenceNumber;
        }

        public long getTimeStamp()
        {
            return _timeStamp;
        }

        public string getMessage()
        {
            return _message;
        }

        public object getUserData()
        {
            return _userData;
        }

        public void setUserData(object userData)
        {
            _userData = userData;
        }

        public override string ToString()
        {
            return _type + ":" + _message;
        }

        private static long CurrentTimeMillis()
        {
            return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
        }
    }

    public class NotificationFilterSupport
    {
        private List<string> _enabledTypes = new List<string>();

        public void enableType(string name)
        {
            if (name == null)
                throw new ArgumentNullException("name", "The name cannot be null.");
            if (!_enabledTypes.Contains(name))
                _enabledTypes.Add(name);
        }

        public void disableType(string name)
        {
            _enabledTypes.Remove(name);
        }

        public void disableAllTypes()
        {
            _enabledTypes.Clear();
        }

        public List<string> getEnabledTypes()
        {
            return new List<string>(_enabledTypes);
        }

        public bool isNotificationEnabled(Notification notification)
        {
            if (notification == null)
                throw new ArgumentNullException("notification", "The notification cannot be null.");
            string type = notification.getType();
            if (type == null)
                return false;
            foreach (string enabledType in _enabledTypes)
            {
                if (type.StartsWith(enabledType, StringComparison.Ordinal))
                    return true;
            }
            return false;
        }
    }

    public class javax_management_NotificationFilterSupportAutoTest
    {
        public void enableType_test_9547(string p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.enableType(p0);
        }

        public void getEnabledTypes_test_9548()
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.getEnabledTypes();
        }

        public void disableType_test_9549(string p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.disableType(p0);
        }

        public void disableAllTypes_test_9550()
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.disableAllTypes();
        }

        public void isNotificationEnabled_test_9551(Notification p0)
        {
            NotificationFilterSupport instance = new NotificationFilterSupport();
            instance.isNotificationEnabled(p0);
        }
    }
}
```