```csharp
using System;

namespace Generated.Test
{
    public delegate object Supplier();

    public interface Spliterator
    {
        interface OfInt : Spliterator { }
        interface OfLong : Spliterator { }
        interface OfDouble : Spliterator { }
    }

    public class Stream
    {
        public Stream() { }
        public Stream(Supplier supplier, int characteristics, bool parallel) { }
        public Stream(Spliterator spliterator, bool parallel) { }
    }

    public class IntStream : Stream
    {
        public IntStream() { }
        public IntStream(Supplier supplier, int characteristics, bool parallel) : base(supplier, characteristics, parallel) { }
        public IntStream(Spliterator.OfInt spliterator, bool parallel) : base(spliterator, parallel) { }
    }

    public class LongStream : Stream
    {
        public LongStream() { }
        public LongStream(Supplier supplier, int characteristics, bool parallel) : base(supplier, characteristics, parallel) { }
        public LongStream(Spliterator.OfLong spliterator, bool parallel) : base(spliterator, parallel) { }
    }

    public class DoubleStream : Stream
    {
        public DoubleStream() { }
        public DoubleStream(Supplier supplier, int characteristics, bool parallel) : base(supplier, characteristics, parallel) { }
        public DoubleStream(Spliterator.OfDouble spliterator, bool parallel) : base(spliterator, parallel) { }
    }

    public static class StreamSupport
    {
        public static Stream stream(Supplier supplier, int characteristics, bool parallel)
        {
            if (supplier == null) throw new ArgumentNullException(nameof(supplier));
            return new Stream(supplier, characteristics, parallel);
        }

        public static Stream stream(Spliterator spliterator, bool parallel)
        {
            if (spliterator == null) throw new ArgumentNullException(nameof(spliterator));
            return new Stream(spliterator, parallel);
        }

        public static IntStream intStream(Supplier supplier, int characteristics, bool parallel)
        {
            if (supplier == null) throw new ArgumentNullException(nameof(supplier));
            return new IntStream(supplier, characteristics, parallel);
        }

        public static IntStream intStream(Spliterator.OfInt spliterator, bool parallel)
        {
            if (spliterator == null) throw new ArgumentNullException(nameof(spliterator));
            return new IntStream(spliterator, parallel);
        }

        public static LongStream longStream(Supplier supplier, int characteristics, bool parallel)
        {
            if (supplier == null) throw new ArgumentNullException(nameof(supplier));
            return new LongStream(supplier, characteristics, parallel);
        }

        public static LongStream longStream(Spliterator.OfLong spliterator, bool parallel)
        {
            if (spliterator == null) throw new ArgumentNullException(nameof(spliterator));
            return new LongStream(spliterator, parallel);
        }

        public static DoubleStream doubleStream(Supplier supplier, int characteristics, bool parallel)
        {
            if (supplier == null) throw new ArgumentNullException(nameof(supplier));
            return new DoubleStream(supplier, characteristics, parallel);
        }

        public static DoubleStream doubleStream(Spliterator.OfDouble spliterator, bool parallel)
        {
            if (spliterator == null) throw new ArgumentNullException(nameof(spliterator));
            return new DoubleStream(spliterator, parallel);
        }
    }

    public class java_util_stream_StreamSupportAutoTest
    {
        public void stream_test_11571(Supplier p0, int p1, bool p2)
        {
            StreamSupport.stream(p0, p1, p2);
        }

        public void stream_test_11572(Spliterator p0, bool p1)
        {
            StreamSupport.stream(p0, p1);
        }

        public void intStream_test_11573(Supplier p0, int p1, bool p2)
        {
            StreamSupport.intStream(p0, p1, p2);
        }

        public void intStream_test_11574(Spliterator.OfInt p0, bool p1)
        {
            StreamSupport.intStream(p0, p1);
        }

        public void longStream_test_11575(Supplier p0, int p1, bool p2)
        {
            StreamSupport.longStream(p0, p1, p2);
        }

        public void longStream_test_11576(Spliterator.OfLong p0, bool p1)
        {
            StreamSupport.longStream(p0, p1);
        }

        public void doubleStream_test_11577(Spliterator.OfDouble p0, bool p1)
        {
            StreamSupport.doubleStream(p0, p1);
        }

        public void doubleStream_test_11578(Supplier p0, int p1, bool p2)
        {
            StreamSupport.doubleStream(p0, p1, p2);
        }
    }
}
```