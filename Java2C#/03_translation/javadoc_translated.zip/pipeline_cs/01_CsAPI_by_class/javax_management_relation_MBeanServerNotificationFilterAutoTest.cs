```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class ObjectName
    {
        private readonly string name;

        public ObjectName(string name)
        {
            this.name = name ?? throw new ArgumentNullException(nameof(name));
        }

        public override string ToString()
        {
            return name;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(this, obj))
                return true;
            if (obj is ObjectName other)
                return name == other.name;
            return false;
        }

        public override int GetHashCode()
        {
            return name.GetHashCode();
        }
    }

    public class Notification
    {
        public string Type { get; }
        public object Source { get; }
        public long SequenceNumber { get; }
        public long TimeStamp { get; }
        public object UserData { get; }

        public Notification(string type, object source, long sequenceNumber)
            : this(type, source, sequenceNumber, DateTime.Now.Ticks, null)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp)
            : this(type, source, sequenceNumber, timeStamp, null)
        {
        }

        public Notification(string type, object source, long sequenceNumber, long timeStamp, object userData)
        {
            Type = type ?? throw new ArgumentNullException(nameof(type));
            Source = source ?? throw new ArgumentNullException(nameof(source));
            SequenceNumber = sequenceNumber;
            TimeStamp = timeStamp;
            UserData = userData;
        }
    }

    public class MBeanServerNotification : Notification
    {
        public const string REGISTRATION_NOTIFICATION = "JMX.mbean.registered";
        public const string UNREGISTRATION_NOTIFICATION = "JMX.mbean.unregistered";

        private readonly ObjectName objectName;

        public MBeanServerNotification(string type, object source, long sequenceNumber, ObjectName objectName)
            : base(type, source, sequenceNumber)
        {
            this.objectName = objectName ?? throw new ArgumentNullException(nameof(objectName));
        }

        public ObjectName getMBeanName()
        {
            return objectName;
        }

        public ObjectName getObjectName()
        {
            return objectName;
        }
    }

    public class MBeanServerNotificationFilter
    {
        private bool allObjectNamesEnabled = true;
        private HashSet<ObjectName> enabledObjectNames = new HashSet<ObjectName>();
        private HashSet<ObjectName> disabledObjectNames = new HashSet<ObjectName>();

        public void disableAllObjectNames()
        {
            lock (this)
            {
                allObjectNamesEnabled = false;
                enabledObjectNames.Clear();
                disabledObjectNames.Clear();
            }
        }

        public void disableObjectName(ObjectName p0)
        {
            if (p0 == null)
                throw new ArgumentException("Object name cannot be null.");

            lock (this)
            {
                if (allObjectNamesEnabled)
                {
                    disabledObjectNames.Add(p0);
                }
                else
                {
                    enabledObjectNames.Remove(p0);
                }
            }
        }

        public void enableAllObjectNames()
        {
            lock (this)
            {
                allObjectNamesEnabled = true;
                enabledObjectNames.Clear();
                disabledObjectNames.Clear();
            }
        }

        public void enableObjectName(ObjectName p0)
        {
            if (p0 == null)
                throw new ArgumentException("Object name cannot be null.");

            lock (this)
            {
                if (allObjectNamesEnabled)
                {
                    disabledObjectNames.Remove(p0);
                }
                else
                {
                    enabledObjectNames.Add(p0);
                }
            }
        }

        public List<ObjectName> getEnabledObjectNames()
        {
            lock (this)
            {
                if (allObjectNamesEnabled)
                {
                    return new List<ObjectName>();
                }
                return new List<ObjectName>(enabledObjectNames);
            }
        }

        public List<ObjectName> getDisabledObjectNames()
        {
            lock (this)
            {
                if (allObjectNamesEnabled)
                {
                    return new List<ObjectName>(disabledObjectNames);
                }
                return new List<ObjectName>();
            }
        }

        public bool isNotificationEnabled(Notification notification)
        {
            if (notification == null)
                throw new ArgumentException("Notification can't be null.");

            MBeanServerNotification mbeanNotification = notification as MBeanServerNotification;
            if (mbeanNotification == null)
                throw new InvalidCastException("Notification is not an MBeanServerNotification");

            ObjectName objectName = mbeanNotification.getMBeanName();

            lock (this)
            {
                if (allObjectNamesEnabled)
                {
                    return !disabledObjectNames.Contains(objectName);
                }
                return enabledObjectNames.Contains(objectName);
            }
        }
    }

    public class javax_management_relation_MBeanServerNotificationFilterAutoTest
    {
        public void disableAllObjectNames_test_8454()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.disableAllObjectNames();
        }

        public void disableObjectName_test_8455(ObjectName p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.disableObjectName(p0);
        }

        public void enableAllObjectNames_test_8456()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.enableAllObjectNames();
        }

        public void enableObjectName_test_8457(ObjectName p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.enableObjectName(p0);
        }

        public void getEnabledObjectNames_test_8458()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.getEnabledObjectNames();
        }

        public void getDisabledObjectNames_test_8459()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.getDisabledObjectNames();
        }

        public void isNotificationEnabled_test_8460(Notification p0)
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.isNotificationEnabled(p0);
        }
    }
}
```