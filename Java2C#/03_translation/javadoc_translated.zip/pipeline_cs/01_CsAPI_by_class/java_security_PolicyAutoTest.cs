namespace Generated.Test
{
    public abstract class Policy
    {
        private static Policy currentPolicy;

        public static void setPolicy(Policy p)
        {
            currentPolicy = p;
        }

        public static Policy getPolicy()
        {
            if (currentPolicy == null)
            {
                currentPolicy = new DefaultPolicy();
            }
            return currentPolicy;
        }

        private sealed class DefaultPolicy : Policy
        {
        }
    }

    public class java_security_PolicyAutoTest
    {
        public void setPolicy_test_9965(Policy p0)
        {
            Policy.setPolicy(p0);
        }

        public void getPolicy_test_9966()
        {
            Policy.getPolicy();
        }
    }
}