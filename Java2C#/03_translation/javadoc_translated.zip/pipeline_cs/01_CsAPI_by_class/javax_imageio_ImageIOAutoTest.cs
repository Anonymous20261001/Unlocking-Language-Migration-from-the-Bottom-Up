using System.Collections.Generic;

namespace Generated.Test
{
    public class File
    {
        public string Path { get; private set; }

        public File(string path)
        {
            Path = path;
        }
    }

    public class ImageReader
    {
    }

    public class ImageWriter
    {
    }

    public class ImageTypeSpecifier
    {
    }

    public static class ImageIO
    {
        private static bool useCache = true;
        private static File cacheDirectory;

        public static void setUseCache(bool useCache)
        {
            ImageIO.useCache = useCache;
        }

        public static bool getUseCache()
        {
            return useCache;
        }

        public static void setCacheDirectory(File cacheDirectory)
        {
            ImageIO.cacheDirectory = cacheDirectory;
        }

        public static File getCacheDirectory()
        {
            return cacheDirectory;
        }

        public static IEnumerable<ImageReader> getImageReaders(object input)
        {
            yield break;
        }

        public static IEnumerable<ImageWriter> getImageWriters(ImageTypeSpecifier type, string formatName)
        {
            yield break;
        }

        public static void scanForPlugins()
        {
        }

        public static string[] getReaderFormatNames()
        {
            return new string[] { "jpg", "jpeg", "png", "gif", "bmp" };
        }

        public static string[] getReaderMIMETypes()
        {
            return new string[] { "image/jpeg", "image/png", "image/gif", "image/bmp" };
        }

        public static string[] getReaderFileSuffixes()
        {
            return new string[] { "jpg", "jpeg", "png", "gif", "bmp" };
        }

        public static IEnumerable<ImageReader> getImageReadersByFormatName(string formatName)
        {
            yield break;
        }

        public static IEnumerable<ImageReader> getImageReadersBySuffix(string fileSuffix)
        {
            yield break;
        }

        public static IEnumerable<ImageReader> getImageReadersByMIMEType(string mimeType)
        {
            yield break;
        }

        public static string[] getWriterFormatNames()
        {
            return new string[] { "jpg", "jpeg", "png", "gif", "bmp" };
        }

        public static string[] getWriterMIMETypes()
        {
            return new string[] { "image/jpeg", "image/png", "image/gif", "image/bmp" };
        }

        public static string[] getWriterFileSuffixes()
        {
            return new string[] { "jpg", "jpeg", "png", "gif", "bmp" };
        }

        public static IEnumerable<ImageWriter> getImageWritersByFormatName(string formatName)
        {
            yield break;
        }

        public static IEnumerable<ImageWriter> getImageWritersBySuffix(string fileSuffix)
        {
            yield break;
        }

        public static IEnumerable<ImageWriter> getImageWritersByMIMEType(string mimeType)
        {
            yield break;
        }

        public static ImageWriter getImageWriter(ImageReader reader)
        {
            return new ImageWriter();
        }

        public static IEnumerable<ImageWriter> getImageTranscoders(ImageReader reader, ImageWriter writer)
        {
            yield break;
        }

        public static ImageReader getImageReader(ImageWriter writer)
        {
            return new ImageReader();
        }
    }

    public class javax_imageio_ImageIOAutoTest
    {
        public void setUseCache_test_5658(bool p0)
        {
            ImageIO.setUseCache(p0);
        }

        public void getUseCache_test_5659()
        {
            ImageIO.getUseCache();
        }

        public void setCacheDirectory_test_5660(File p0)
        {
            ImageIO.setCacheDirectory(p0);
        }

        public void getCacheDirectory_test_5661()
        {
            ImageIO.getCacheDirectory();
        }

        public void getImageReaders_test_5662(object p0)
        {
            ImageIO.getImageReaders(p0);
        }

        public void getImageWriters_test_5663(ImageTypeSpecifier p0, string p1)
        {
            ImageIO.getImageWriters(p0, p1);
        }

        public void scanForPlugins_test_5664()
        {
            ImageIO.scanForPlugins();
        }

        public void getReaderFormatNames_test_5665()
        {
            ImageIO.getReaderFormatNames();
        }

        public void getReaderMIMETypes_test_5666()
        {
            ImageIO.getReaderMIMETypes();
        }

        public void getReaderFileSuffixes_test_5667()
        {
            ImageIO.getReaderFileSuffixes();
        }

        public void getImageReadersByFormatName_test_5668(string p0)
        {
            ImageIO.getImageReadersByFormatName(p0);
        }

        public void getImageReadersBySuffix_test_5669(string p0)
        {
            ImageIO.getImageReadersBySuffix(p0);
        }

        public void getImageReadersByMIMEType_test_5670(string p0)
        {
            ImageIO.getImageReadersByMIMEType(p0);
        }

        public void getWriterFormatNames_test_5671()
        {
            ImageIO.getWriterFormatNames();
        }

        public void getWriterMIMETypes_test_5672()
        {
            ImageIO.getWriterMIMETypes();
        }

        public void getWriterFileSuffixes_test_5673()
        {
            ImageIO.getWriterFileSuffixes();
        }

        public void getImageWritersByFormatName_test_5674(string p0)
        {
            ImageIO.getImageWritersByFormatName(p0);
        }

        public void getImageWritersBySuffix_test_5675(string p0)
        {
            ImageIO.getImageWritersBySuffix(p0);
        }

        public void getImageWritersByMIMEType_test_5676(string p0)
        {
            ImageIO.getImageWritersByMIMEType(p0);
        }

        public void getImageWriter_test_5677(ImageReader p0)
        {
            ImageIO.getImageWriter(p0);
        }

        public void getImageTranscoders_test_5678(ImageReader p0, ImageWriter p1)
        {
            ImageIO.getImageTranscoders(p0, p1);
        }

        public void getImageReader_test_5679(ImageWriter p0)
        {
            ImageIO.getImageReader(p0);
        }
    }
}