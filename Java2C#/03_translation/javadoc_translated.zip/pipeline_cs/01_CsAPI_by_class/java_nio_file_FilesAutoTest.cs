using System;
using System.IO;

namespace Generated.Test
{
    public class Path
    {
        public string FullPath { get; private set; }

        public Path(string path)
        {
            FullPath = path;
        }

        public override string ToString()
        {
            return FullPath;
        }
    }

    public enum LinkOption
    {
        NOFOLLOW_LINKS
    }

    public static class Files
    {
        public static bool exists(Path p0, LinkOption[] p1)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            return File.Exists(p0.FullPath) || Directory.Exists(p0.FullPath);
        }

        public static bool isDirectory(Path p0, LinkOption[] p1)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            return Directory.Exists(p0.FullPath);
        }

        public static bool isRegularFile(Path p0, LinkOption[] p1)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            return File.Exists(p0.FullPath);
        }

        public static bool notExists(Path p0, LinkOption[] p1)
        {
            return !exists(p0, p1);
        }

        public static bool isWritable(Path p0)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            try
            {
                FileAttributes attr = File.GetAttributes(p0.FullPath);
                return (attr & FileAttributes.ReadOnly) == 0;
            }
            catch
            {
                return false;
            }
        }

        public static object getFileAttributeView(Path p0, Type p1, LinkOption[] p2)
        {
            return null;
        }

        public static bool isSymbolicLink(Path p0)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            try
            {
                FileAttributes attr = File.GetAttributes(p0.FullPath);
                return (attr & FileAttributes.ReparsePoint) != 0;
            }
            catch
            {
                return false;
            }
        }

        public static bool isReadable(Path p0)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            try
            {
                FileAttributes attr = File.GetAttributes(p0.FullPath);
                return (attr & FileAttributes.Directory) == 0;
            }
            catch
            {
                return false;
            }
        }

        public static bool isExecutable(Path p0)
        {
            if (p0 == null || p0.FullPath == null)
                return false;
            try
            {
                FileAttributes attr = File.GetAttributes(p0.FullPath);
                return (attr & FileAttributes.Directory) == 0;
            }
            catch
            {
                return false;
            }
        }
    }

    public class java_nio_file_FilesAutoTest
    {
        public void exists_test_4765(Path p0, LinkOption[] p1)
        {
            Files.exists(p0, p1);
        }

        public void isDirectory_test_4766(Path p0, LinkOption[] p1)
        {
            Files.isDirectory(p0, p1);
        }

        public void isRegularFile_test_4767(Path p0, LinkOption[] p1)
        {
            Files.isRegularFile(p0, p1);
        }

        public void notExists_test_4768(Path p0, LinkOption[] p1)
        {
            Files.notExists(p0, p1);
        }

        public void isWritable_test_4769(Path p0)
        {
            Files.isWritable(p0);
        }

        public void getFileAttributeView_test_4770(Path p0, Type p1, LinkOption[] p2)
        {
            Files.getFileAttributeView(p0, p1, p2);
        }

        public void isSymbolicLink_test_4771(Path p0)
        {
            Files.isSymbolicLink(p0);
        }

        public void isReadable_test_4772(Path p0)
        {
            Files.isReadable(p0);
        }

        public void isExecutable_test_4773(Path p0)
        {
            Files.isExecutable(p0);
        }
    }
}