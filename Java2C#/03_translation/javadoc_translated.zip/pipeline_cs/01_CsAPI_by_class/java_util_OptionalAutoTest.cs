using System;

namespace Generated.Test
{
    public class Optional
    {
        private readonly object _value;
        private readonly bool _hasValue;

        private Optional()
        {
            _hasValue = false;
            _value = null;
        }

        private Optional(object value)
        {
            _hasValue = true;
            _value = value;
        }

        public static Optional of(object value)
        {
            if (value == null)
                throw new ArgumentNullException("value");
            return new Optional(value);
        }

        public static Optional empty()
        {
            return new Optional();
        }

        public static Optional ofNullable(object value)
        {
            return value == null ? empty() : new Optional(value);
        }
    }

    public class java_util_OptionalAutoTest
    {
        public void of_test_9689(object p0)
        {
            Optional.of(p0);
        }

        public void empty_test_9690()
        {
            Optional.empty();
        }

        public void ofNullable_test_9691(object p0)
        {
            Optional.ofNullable(p0);
        }
    }
}