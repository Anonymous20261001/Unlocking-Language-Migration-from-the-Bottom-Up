namespace Generated.Test
{
    public class URL
    {
        private string value;
        public URL(string value) { this.value = value; }
        public override string ToString() { return value; }
    }

    public class Dimension
    {
        public int width;
        public int height;
        public Dimension() { }
        public Dimension(int width, int height) { this.width = width; this.height = height; }
    }

    public class AppletContext { }
    public class AudioClip { }
    public class Image { }
    public class Locale { }
    public class AccessibleContext { }

    public interface AppletStub
    {
        bool isActive();
        string getParameter(string name);
        AppletContext getAppletContext();
        void appletResize(int width, int height);
        URL getCodeBase();
        URL getDocumentBase();
    }

    public class Applet
    {
        private AppletStub stub;

        public Applet() { }

        public URL getDocumentBase()
        {
            if (stub != null) return stub.getDocumentBase();
            return null;
        }

        public URL getCodeBase()
        {
            if (stub != null) return stub.getCodeBase();
            return null;
        }

        public AppletContext getAppletContext()
        {
            if (stub != null) return stub.getAppletContext();
            return null;
        }

        public void showStatus(string status) { }

        public AudioClip getAudioClip(URL url, string name) { return null; }
        public AudioClip getAudioClip(URL url) { return null; }

        public void play(URL url) { }
        public void play(URL url, string name) { }

        public void setStub(AppletStub stub) { this.stub = stub; }

        public static AudioClip newAudioClip(URL url) { return null; }

        public string getAppletInfo() { return null; }

        public string[][] getParameterInfo() { return null; }

        public bool isValidateRoot() { return false; }

        public AccessibleContext getAccessibleContext() { return null; }

        public Image getImage(URL url, string name) { return null; }
        public Image getImage(URL url) { return null; }

        public void init() { }
        public void start() { }
        public void stop() { }
        public void destroy() { }

        public bool isActive()
        {
            if (stub != null) return stub.isActive();
            return false;
        }

        public void resize(int width, int height) { }
        public void resize(Dimension d) { }

        public Locale getLocale() { return null; }

        public string getParameter(string name)
        {
            if (stub != null) return stub.getParameter(name);
            return null;
        }
    }

    public class java_applet_AppletAutoTest
    {
        public void getDocumentBase_test_163()
        {
            Applet instance = new Applet();
            instance.getDocumentBase();
        }

        public void getCodeBase_test_164()
        {
            Applet instance = new Applet();
            instance.getCodeBase();
        }

        public void getAppletContext_test_165()
        {
            Applet instance = new Applet();
            instance.getAppletContext();
        }

        public void showStatus_test_166(string p0)
        {
            Applet instance = new Applet();
            instance.showStatus(p0);
        }

        public void getAudioClip_test_167(URL p0, string p1)
        {
            Applet instance = new Applet();
            instance.getAudioClip(p0, p1);
        }

        public void getAudioClip_test_168(URL p0)
        {
            Applet instance = new Applet();
            instance.getAudioClip(p0);
        }

        public void play_test_169(URL p0)
        {
            Applet instance = new Applet();
            instance.play(p0);
        }

        public void play_test_170(URL p0, string p1)
        {
            Applet instance = new Applet();
            instance.play(p0, p1);
        }

        public void setStub_test_171(AppletStub p0)
        {
            Applet instance = new Applet();
            instance.setStub(p0);
        }

        public void newAudioClip_test_172(URL p0)
        {
            Applet.newAudioClip(p0);
        }

        public void getAppletInfo_test_173()
        {
            Applet instance = new Applet();
            instance.getAppletInfo();
        }

        public void getParameterInfo_test_174()
        {
            Applet instance = new Applet();
            instance.getParameterInfo();
        }

        public void isValidateRoot_test_175()
        {
            Applet instance = new Applet();
            instance.isValidateRoot();
        }

        public void getAccessibleContext_test_176()
        {
            Applet instance = new Applet();
            instance.getAccessibleContext();
        }

        public void getImage_test_177(URL p0, string p1)
        {
            Applet instance = new Applet();
            instance.getImage(p0, p1);
        }

        public void getImage_test_178(URL p0)
        {
            Applet instance = new Applet();
            instance.getImage(p0);
        }

        public void init_test_179()
        {
            Applet instance = new Applet();
            instance.init();
        }

        public void start_test_180()
        {
            Applet instance = new Applet();
            instance.start();
        }

        public void stop_test_181()
        {
            Applet instance = new Applet();
            instance.stop();
        }

        public void destroy_test_182()
        {
            Applet instance = new Applet();
            instance.destroy();
        }

        public void isActive_test_183()
        {
            Applet instance = new Applet();
            instance.isActive();
        }

        public void resize_test_184(int p0, int p1)
        {
            Applet instance = new Applet();
            instance.resize(p0, p1);
        }

        public void resize_test_185(Dimension p0)
        {
            Applet instance = new Applet();
            instance.resize(p0);
        }

        public void getLocale_test_186()
        {
            Applet instance = new Applet();
            instance.getLocale();
        }

        public void getParameter_test_187(string p0)
        {
            Applet instance = new Applet();
            instance.getParameter(p0);
        }
    }
}