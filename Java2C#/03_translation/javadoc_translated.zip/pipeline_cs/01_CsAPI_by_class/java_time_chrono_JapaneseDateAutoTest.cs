namespace Generated.Test
{
    public interface TemporalAccessor
    {
    }

    public abstract class ZoneId
    {
    }

    public abstract class Clock
    {
    }

    public sealed class JapaneseEra : TemporalAccessor
    {
        private JapaneseEra() { }

        public static readonly JapaneseEra MEIJI = new JapaneseEra();
        public static readonly JapaneseEra TAISHO = new JapaneseEra();
        public static readonly JapaneseEra SHOWA = new JapaneseEra();
        public static readonly JapaneseEra HEISEI = new JapaneseEra();
        public static readonly JapaneseEra REIWA = new JapaneseEra();
    }

    public sealed class JapaneseDate : TemporalAccessor
    {
        private JapaneseDate() { }

        public static JapaneseDate of(int year, int month, int day)
        {
            return new JapaneseDate();
        }

        public static JapaneseDate of(JapaneseEra era, int year, int month, int day)
        {
            return new JapaneseDate();
        }

        public static JapaneseDate from(TemporalAccessor temporal)
        {
            return new JapaneseDate();
        }

        public static JapaneseDate now()
        {
            return new JapaneseDate();
        }

        public static JapaneseDate now(ZoneId zone)
        {
            return new JapaneseDate();
        }

        public static JapaneseDate now(Clock clock)
        {
            return new JapaneseDate();
        }
    }

    public class java_time_chrono_JapaneseDateAutoTest
    {
        public void of_test_5968(int p0, int p1, int p2)
        {
            JapaneseDate.of(p0, p1, p2);
        }

        public void of_test_5969(JapaneseEra p0, int p1, int p2, int p3)
        {
            JapaneseDate.of(p0, p1, p2, p3);
        }

        public void from_test_5970(TemporalAccessor p0)
        {
            JapaneseDate.from(p0);
        }

        public void now_test_5971()
        {
            JapaneseDate.now();
        }

        public void now_test_5972(ZoneId p0)
        {
            JapaneseDate.now(p0);
        }

        public void now_test_5973(Clock p0)
        {
            JapaneseDate.now(p0);
        }
    }
}