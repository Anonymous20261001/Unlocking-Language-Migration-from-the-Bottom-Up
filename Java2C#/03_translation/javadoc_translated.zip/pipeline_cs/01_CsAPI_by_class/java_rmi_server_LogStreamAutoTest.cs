using System;
using System.Collections.Generic;
using System.IO;

namespace Generated.Test
{
    public class PrintStream
    {
        private readonly TextWriter _writer;

        public PrintStream(TextWriter writer)
        {
            if (writer == null)
                throw new ArgumentNullException(nameof(writer));
            _writer = writer;
        }

        public TextWriter Writer
        {
            get { return _writer; }
        }

        public void Write(string value)
        {
            _writer.Write(value);
        }

        public void WriteLine(string value)
        {
            _writer.WriteLine(value);
        }

        public void Flush()
        {
            _writer.Flush();
        }

        public void Close()
        {
            _writer.Close();
        }
    }

    public class LogStream : PrintStream
    {
        private readonly string _name;
        private static readonly object _lock = new object();
        private static PrintStream _defaultStream = new PrintStream(Console.Error);
        private static readonly Dictionary<string, LogStream> _logs = new Dictionary<string, LogStream>();

        public const int SILENT = 0;
        public const int BRIEF = 10;
        public const int VERBOSE = 20;

        public LogStream(string name) : base(_defaultStream.Writer)
        {
            _name = name;
        }

        public string Name
        {
            get { return _name; }
        }

        public static PrintStream getDefaultStream()
        {
            return _defaultStream;
        }

        public static void setDefaultStream(PrintStream newDefault)
        {
            if (newDefault == null)
                throw new ArgumentNullException(nameof(newDefault));
            _defaultStream = newDefault;
        }

        public static int parseLevel(string s)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));

            if (s.Equals("SILENT", StringComparison.Ordinal))
                return SILENT;
            if (s.Equals("BRIEF", StringComparison.Ordinal))
                return BRIEF;
            if (s.Equals("VERBOSE", StringComparison.Ordinal))
                return VERBOSE;

            throw new ArgumentException("Invalid log level: " + s);
        }

        public static LogStream log(string name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));

            lock (_lock)
            {
                LogStream existing;
                if (_logs.TryGetValue(name, out existing))
                    return existing;

                LogStream newStream = new LogStream(name);
                _logs.Add(name, newStream);
                return newStream;
            }
        }

        public override string ToString()
        {
            return _name;
        }
    }

    public class java_rmi_server_LogStreamAutoTest
    {
        public void getDefaultStream_test_8139()
        {
            LogStream.getDefaultStream();
        }

        public void setDefaultStream_test_8140(PrintStream p0)
        {
            LogStream.setDefaultStream(p0);
        }

        public void parseLevel_test_8141(string p0)
        {
            LogStream.parseLevel(p0);
        }

        public void log_test_8142(string p0)
        {
            LogStream.log(p0);
        }
    }
}