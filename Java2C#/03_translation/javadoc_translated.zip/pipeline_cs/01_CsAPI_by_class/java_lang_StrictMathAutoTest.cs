namespace Generated.Test;

public class StrictMath
{
    public static float Abs(float a) => Math.Abs(a);
    public static long Abs(long a) => Math.Abs(a);
    public static int Abs(int a) => Math.Abs(a);
    public static double Abs(double a) => Math.Abs(a);
    public static double Sin(double a) => Math.Sin(a);
    public static double Cos(double a) => Math.Cos(a);
    public static double Tan(double a) => Math.Tan(a);
    public static double Atan2(double y, double x) => Math.Atan2(y, x);
    public static double Sqrt(double a) => Math.Sqrt(a);
    public static double Log(double a) => Math.Log(a);
    public static double Log10(double a) => Math.Log10(a);
    public static double Pow(double x, double y) => Math.Pow(x, y);
    public static double Exp(double a) => Math.Exp(a);
    public static double Min(double a, double b) => Math.Min(a, b);
    public static float Min(float a, float b) => Math.Min(a, b);
    public static int Min(int a, int b) => Math.Min(a, b);
    public static long Min(long a, long b) => Math.Min(a, b);
    public static float Max(float a, float b) => Math.Max(a, b);
    public static long Max(long a, long b) => Math.Max(a, b);
    public static int Max(int a, int b) => Math.Max(a, b);
    public static double Max(double a, double b) => Math.Max(a, b);
    public static double Floor(double a) => Math.Floor(a);
    public static double Ceil(double a) => Math.Ceiling(a);
    public static double Rint(double a) => Math.Round(a, MidpointRounding.ToEven);
    public static long Round(double a) => (long)Math.Round(a, MidpointRounding.AwayFromZero);
    public static int Round(float a) => (int)Math.Round(a, MidpointRounding.AwayFromZero);
    public static double Tanh(double a) => Math.Tanh(a);
    public static double Cbrt(double a) => Math.Cbrt(a);
    public static int AddExact(int x, int y) => checked(x + y);
    public static long AddExact(long x, long y) => checked(x + y);
    public static long DecrementExact(long a) => checked(a - 1);
    public static int DecrementExact(int a) => checked(a - 1);
    public static int IncrementExact(int a) => checked(a + 1);
    public static long IncrementExact(long a) => checked(a + 1);
    public static int MultiplyExact(int x, int y) => checked(x * y);
    public static long MultiplyExact(long x, int y) => checked(x * y);
    public static long MultiplyExact(long x, long y) => checked(x * y);
    public static long MultiplyHigh(long x, long y)
    {
        ulong xl = (ulong)x;
        ulong yl = (ulong)y;
        ulong xlo = (uint)xl;
        ulong xhi = xl >> 32;
        ulong ylo = (uint)yl;
        ulong yhi = yl >> 32;
        ulong lolo = xlo * ylo;
        ulong lohi = xlo * yhi;
        ulong hilo = xhi * ylo;
        ulong hihi = xhi * yhi;
        ulong loResult = lolo + (lohi << 32);
        ulong hiResult = hihi + (lohi >> 32) + (hilo >> 32) + (loResult < lolo ? 1 : 0) + ((lohi << 32) != 0 && loResult < (lohi << 32) ? 1 : 0);
        return (long)hiResult;
    }
    public static long UnsignedMultiplyHigh(long x, long y)
    {
        ulong xl = (ulong)x;
        ulong yl = (ulong)y;
        ulong xlo = (uint)xl;
        ulong xhi = xl >> 32;
        ulong ylo = (uint)yl;
        ulong yhi = yl >> 32;
        ulong lolo = xlo * ylo;
        ulong lohi = xlo * yhi;
        ulong hilo = xhi * ylo;
        ulong hihi = xhi * yhi;
        ulong loResult = lolo + (lohi << 32);
        ulong hiResult = hihi + (lohi >> 32) + (hilo >> 32) + (loResult < lolo ? 1 : 0) + ((lohi << 32) != 0 && loResult < (lohi << 32) ? 1 : 0);
        return (long)hiResult;
    }
    public static long NegateExact(long a) => checked(-a);
    public static int NegateExact(int a) => checked(-a);
    public static long SubtractExact(long x, long y) => checked(x - y);
    public static int SubtractExact(int x, int y) => checked(x - y);
    public static double Fma(double a, double b, double c) => Math.FusedMultiplyAdd(a, b, c);
    public static float Fma(float a, float b, float c) => (float)Math.FusedMultiplyAdd(a, b, c);
    public static double CopySign(double magnitude, double sign)
    {
        if (double.IsNaN(magnitude) || double.IsNaN(sign))
            return double.NaN;
        if (sign < 0)
            return -Math.Abs(magnitude);
        return Math.Abs(magnitude);
    }
    public static float CopySign(float magnitude, float sign)
    {
        if (float.IsNaN(magnitude) || float.IsNaN(sign))
            return float.NaN;
        if (sign < 0)
            return -Math.Abs(magnitude);
        return Math.Abs(magnitude);
    }
    public static double Signum(double d) => d > 0 ? 1.0 : (d < 0 ? -1.0 : d);
    public static float Signum(float f) => f > 0 ? 1.0f : (f < 0 ? -1.0f : f);
    public static double Clamp(double value, double min, double max)
    {
        if (double.IsNaN(value) || double.IsNaN(min) || double.IsNaN(max))
            return double.NaN;
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    public static long Clamp(long value, long min, long max)
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    public static float Clamp(float value, float min, float max)
    {
        if (float.IsNaN(value) || float.IsNaN(min) || float.IsNaN(max))
            return float.NaN;
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    public static long Clamp(long value, int min, int max)
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }
    public static double Scalb(double d, int scaleFactor)
    {
        if (double.IsNaN(d) || double.IsInfinity(d) || d == 0)
            return d;
        return d * Math.Pow(2, scaleFactor);
    }
    public static float Scalb(float f, int scaleFactor)
    {
        if (float.IsNaN(f) || float.IsInfinity(f) || f == 0)
            return f;
        return f * (float)Math.Pow(2, scaleFactor);
    }
    public static int GetExponent(float f)
    {
        if (float.IsNaN(f) || float.IsInfinity(f))
            return float.MaxExponent + 1;
        if (f == 0)
            return float.MinExponent - 1;
        return (int)Math.Floor(Math.Log(Math.Abs(f), 2)) + 1;
    }
    public static int GetExponent(double d)
    {
        if (double.IsNaN(d) || double.IsInfinity(d))
            return double.MaxExponent + 1;
        if (d == 0)
            return double.MinExponent - 1;
        return (int)Math.Floor(Math.Log(Math.Abs(d), 2)) + 1;
    }
    public static int FloorMod(int x, int y)
    {
        int r = x % y;
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return r;
    }
    public static long FloorMod(long x, long y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return r;
    }
    public static long FloorMod(long x, int y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) != (y < 0)))
            r += y;
        return r;
    }
    public static double Asin(double a) => Math.Asin(a);
    public static double Acos(double a) => Math.Acos(a);
    public static double Atan(double a) => Math.Atan(a);
    public static double IEEEremainder(double f1, double f2)
    {
        if (double.IsNaN(f1) || double.IsNaN(f2) || double.IsInfinity(f1) || f2 == 0)
            return double.NaN;
        if (double.IsInfinity(f2))
            return f1;
        double r = f1 % f2;
        if (r != 0)
        {
            double half = Math.Abs(f2) / 2;
            if (Math.Abs(r) > half || (Math.Abs(r) == half && (r > 0) != (f2 > 0)))
                r -= f2;
        }
        return r;
    }
    public static long FloorDiv(long x, long y)
    {
        long r = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0)))
            r--;
        return r;
    }
    public static long FloorDiv(long x, int y)
    {
        long r = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0)))
            r--;
        return r;
    }
    public static int FloorDiv(int x, int y)
    {
        int r = x / y;
        if ((x % y != 0) && ((x < 0) != (y < 0)))
            r--;
        return r;
    }
    public static long CeilDiv(long x, int y)
    {
        long r = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0)))
            r++;
        return r;
    }
    public static long CeilDiv(long x, long y)
    {
        long r = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0)))
            r++;
        return r;
    }
    public static int CeilDiv(int x, int y)
    {
        int r = x / y;
        if ((x % y != 0) && ((x < 0) == (y < 0)))
            r++;
        return r;
    }
    public static int CeilMod(int x, int y)
    {
        int r = x % y;
        if (r != 0 && ((r < 0) == (y < 0)))
            r -= y;
        return r;
    }
    public static long CeilMod(long x, int y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) == (y < 0)))
            r -= y;
        return r;
    }
    public static long CeilMod(long x, long y)
    {
        long r = x % y;
        if (r != 0 && ((r < 0) == (y < 0)))
            r -= y;
        return r;
    }
    public static double Sinh(double a) => Math.Sinh(a);
    public static double Cosh(double a) => Math.Cosh(a);
    public static double Hypot(double x, double y) => Math.Sqrt(x * x + y * y);
    public static double Expm1(double x) => Math.Exp(x) - 1;
    public static double Log1p(double x) => Math.Log(1 + x);
    public static int UnsignedMultiplyExact(int x, int y)
    {
        long result = (long)(uint)x * (uint)y;
        if (result > int.MaxValue)
            throw new OverflowException();
        return (int)result;
    }
    public static long UnsignedMultiplyExact(long x, int y)
    {
        ulong result = (ulong)x * (uint)y;
        if (result > long.MaxValue)
            throw new OverflowException();
        return (long)result;
    }
    public static long UnsignedMultiplyExact(long x, long y)
    {
        ulong result = (ulong)x * (ulong)y;
        if (result > long.MaxValue)
            throw new OverflowException();
        return (long)result;
    }
    public static double ToRadians(double angdeg) => angdeg * Math.PI / 180.0;
    public static double ToDegrees(double angrad) => angrad * 180.0 / Math.PI;
    public static double Random() => new Random().NextDouble();
    public static int DivideExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return x / y;
    }
    public static long DivideExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return x / y;
    }
    public static int FloorDivExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return FloorDiv(x, y);
    }
    public static long FloorDivExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return FloorDiv(x, y);
    }
    public static long CeilDivExact(long x, long y)
    {
        if (x == long.MinValue && y == -1)
            throw new OverflowException();
        return CeilDiv(x, y);
    }
    public static int CeilDivExact(int x, int y)
    {
        if (x == int.MinValue && y == -1)
            throw new OverflowException();
        return CeilDiv(x, y);
    }
    public static int ToIntExact(long value)
    {
        if (value < int.MinValue || value > int.MaxValue)
            throw new OverflowException();
        return (int)value;
    }
    public static long MultiplyFull(int x, int y) => (long)x * y;
    public static long AbsExact(long a)
    {
        if (a == long.MinValue)
            throw new OverflowException();
        return Math.Abs(a);
    }
    public static int AbsExact(int a)
    {
        if (a == int.MinValue)
            throw new OverflowException();
        return Math.Abs(a);
    }
    public static double Ulp(double d)
    {
        if (double.IsNaN(d))
            return double.NaN;
        if (double.IsInfinity(d))
            return double.PositiveInfinity;
        if (d == 0)
            return double.Epsilon;
        int exp = GetExponent(d);
        return Math.Pow(2, exp - 52);
    }
    public static float Ulp(float f)
    {
        if (float.IsNaN(f))
            return float.NaN;
        if (float.IsInfinity(f))
            return float.PositiveInfinity;
        if (f == 0)
            return float.Epsilon;
        int exp = GetExponent(f);
        return (float)Math.Pow(2, exp - 23);
    }
    public static float NextAfter(float start, double direction)
    {
        if (float.IsNaN(start) || double.IsNaN(direction))
            return float.NaN;
        if (start == direction)
            return (float)direction;
        if (start == 0)
            return direction > 0 ? float.Epsilon : -float.Epsilon;
        if (float.IsPositiveInfinity(start) && direction < start)
            return float.MaxValue;
        if (float.IsNegativeInfinity(start) && direction > start)
            return -float.MaxValue;
        if (start > 0)
        {
            if (direction > start)
                return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(start) + 1);
            else
                return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(start) - 1);
        }
        else
        {
            if (direction > start)
                return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(start) - 1);
            else
                return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(start) + 1);
        }
    }
    public static double NextAfter(double start, double direction)
    {
        if (double.IsNaN(start) || double.IsNaN(direction))
            return double.NaN;
        if (start == direction)
            return direction;
        if (start == 0)
            return direction > 0 ? double.Epsilon : -double.Epsilon;
        if (double.IsPositiveInfinity(start) && direction < start)
            return double.MaxValue;
        if (double.IsNegativeInfinity(start) && direction > start)
            return -double.MaxValue;
        if (start > 0)
        {
            if (direction > start)
                return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(start) + 1);
            else
                return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(start) - 1);
        }
        else
        {
            if (direction > start)
                return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(start) - 1);
            else
                return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(start) + 1);
        }
    }
    public static float NextUp(float f)
    {
        if (float.IsNaN(f))
            return float.NaN;
        if (f == float.PositiveInfinity)
            return float.PositiveInfinity;
        if (f == 0)
            return float.Epsilon;
        if (f > 0)
            return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(f) + 1);
        else
            return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(f) - 1);
    }
    public static double NextUp(double d)
    {
        if (double.IsNaN(d))
            return double.NaN;
        if (d == double.PositiveInfinity)
            return double.PositiveInfinity;
        if (d == 0)
            return double.Epsilon;
        if (d > 0)
            return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(d) + 1);
        else
            return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(d) - 1);
    }
    public static double NextDown(double d)
    {
        if (double.IsNaN(d))
            return double.NaN;
        if (d == double.NegativeInfinity)
            return double.NegativeInfinity;
        if (d == 0)
            return -double.Epsilon;
        if (d > 0)
            return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(d) - 1);
        else
            return BitConverter.Int64BitsToDouble(BitConverter.DoubleToInt64Bits(d) + 1);
    }
    public static float NextDown(float f)
    {
        if (float.IsNaN(f))
            return float.NaN;
        if (f == float.NegativeInfinity)
            return float.NegativeInfinity;
        if (f == 0)
            return -float.Epsilon;
        if (f > 0)
            return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(f) - 1);
        else
            return BitConverter.Int32BitsToSingle(BitConverter.SingleToInt32Bits(f) + 1);
    }
    public static long PowExact(long x, int y)
    {
        if (y < 0)
            throw new ArithmeticException("negative exponent");
        long result = 1;
        for (int i = 0; i < y; i++)
            result = checked(result * x);
        return result;
    }
    public static int PowExact(int x, int y)
    {
        if (y < 0)
            throw new ArithmeticException("negative exponent");
        int result = 1;
        for (int i = 0; i < y; i++)
            result = checked(result * x);
        return result;
    }
    public static long UnsignedPowExact(long x, int y)
    {
        if (y < 0)
            throw new ArithmeticException("negative exponent");
        ulong result = 1;
        ulong ux = (ulong)x;
        for (int i = 0; i < y; i++)
            result = checked(result * ux);
        if (result > long.MaxValue)
            throw new OverflowException();
        return (long)result;
    }
    public static int UnsignedPowExact(int x, int y)
    {
        if (y < 0)
            throw new ArithmeticException("negative exponent");
        uint result = 1;
        uint ux = (uint)x;
        for (int i = 0; i < y; i++)
            result = checked(result * ux);
        if (result > int.MaxValue)
            throw new OverflowException();
        return (int)result;
    }
}

public class java_lang_StrictMathAutoTest
{
    public void abs_test_11593(float p0) { StrictMath.Abs(p0); }
    public void abs_test_11594(long p0) { StrictMath.Abs(p0); }
    public void abs_test_11595(int p0) { StrictMath.Abs(p0); }
    public void abs_test_11596(double p0) { StrictMath.Abs(p0); }
    public void sin_test_11597(double p0) { StrictMath.Sin(p0); }
    public void cos_test_11598(double p0) { StrictMath.Cos(p0); }
    public void tan_test_11599(double p0) { StrictMath.Tan(p0); }
    public void atan2_test_11600(double p0, double p1) { StrictMath.Atan2(p0, p1); }
    public void sqrt_test_11601(double p0) { StrictMath.Sqrt(p0); }
    public void log_test_11602(double p0) { StrictMath.Log(p0); }
    public void log10_test_11603(double p0) { StrictMath.Log10(p0); }
    public void pow_test_11604(double p0, double p1) { StrictMath.Pow(p0, p1); }
    public void exp_test_11605(double p0) { StrictMath.Exp(p0); }
    public void min_test_11606(double p0, double p1) { StrictMath.Min(p0, p1); }
    public void min_test_11607(float p0, float p1) { StrictMath.Min(p0, p1); }
    public void min_test_11608(int p0, int p1) { StrictMath.Min(p0, p1); }
    public void min_test_11609(long p0, long p1) { StrictMath.Min(p0, p1); }
    public void max_test_11610(float p0, float p1) { StrictMath.Max(p0, p1); }
    public void max_test_11611(long p0, long p1) { StrictMath.Max(p0, p1); }
    public void max_test_11612(int p0, int p1) { StrictMath.Max(p0, p1); }
    public void max_test_11613(double p0, double p1) { StrictMath.Max(p0, p1); }
    public void floor_test_11614(double p0) { StrictMath.Floor(p0); }
    public void ceil_test_11615(double p0) { StrictMath.Ceil(p0); }
    public void rint_test_11616(double p0) { StrictMath.Rint(p0); }
    public void round_test_11617(double p0) { StrictMath.Round(p0); }
    public void round_test_11618(float p0) { StrictMath.Round(p0); }
    public void tanh_test_11619(double p0) { StrictMath.Tanh(p0); }
    public void cbrt_test_11620(double p0) { StrictMath.Cbrt(p0); }
    public void addExact_test_11621(int p0, int p1) { StrictMath.AddExact(p0, p1); }
    public void addExact_test_11622(long p0, long p1) { StrictMath.AddExact(p0, p1); }
    public void decrementExact_test_11623(long p0) { StrictMath.DecrementExact(p0); }
    public void decrementExact_test_11624(int p0) { StrictMath.DecrementExact(p0); }
    public void incrementExact_test_11625(int p0) { StrictMath.IncrementExact(p0); }
    public void incrementExact_test_11626(long p0) { StrictMath.IncrementExact(p0); }
    public void multiplyExact_test_11627(int p0, int p1) { StrictMath.MultiplyExact(p0, p1); }
    public void multiplyExact_test_11628(long p0, int p1) { StrictMath.MultiplyExact(p0, p1); }
    public void multiplyExact_test_11629(long p0, long p1) { StrictMath.MultiplyExact(p0, p1); }
    public void multiplyHigh_test_11630(long p0, long p1) { StrictMath.MultiplyHigh(p0, p1); }
    public void unsignedMultiplyHigh_test_11631(long p0, long p1) { StrictMath.UnsignedMultiplyHigh(p0, p1); }
    public void negateExact_test_11632(long p0) { StrictMath.NegateExact(p0); }
    public void negateExact_test_11633(int p0) { StrictMath.NegateExact(p0); }
    public void subtractExact_test_11634(long p0, long p1) { StrictMath.SubtractExact(p0, p1); }
    public void subtractExact_test_11635(int p0, int p1) { StrictMath.SubtractExact(p0, p1); }
    public void fma_test_11636(double p0, double p1, double p2) { StrictMath.Fma(p0, p1, p2); }
    public void fma_test_11637(float p0, float p1, float p2) { StrictMath.Fma(p0, p1, p2); }
    public void copySign_test_11638(double p0, double p1) { StrictMath.CopySign(p0, p1); }
    public void copySign_test_11639(float p0, float p1) { StrictMath.CopySign(p0, p1); }
    public void signum_test_11640(double p0) { StrictMath.Signum(p0); }
    public void signum_test_11641(float p0) { StrictMath.Signum(p0); }
    public void clamp_test_11642(double p0, double p1, double p2) { StrictMath.Clamp(p0, p1, p2); }
    public void clamp_test_11643(long p0, long p1, long p2) { StrictMath.Clamp(p0, p1, p2); }
    public void clamp_test_11644(float p0, float p1, float p2) { StrictMath.Clamp(p0, p1, p2); }
    public void clamp_test_11645(long p0, int p1, int p2) { StrictMath.Clamp(p0, p1, p2); }
    public void scalb_test_11646(double p0, int p1) { StrictMath.Scalb(p0, p1); }
    public void scalb_test_11647(float p0, int p1) { StrictMath.Scalb(p0, p1); }
    public void getExponent_test_11648(float p0) { StrictMath.GetExponent(p0); }
    public void getExponent_test_11649(double p0) { StrictMath.GetExponent(p0); }
    public void floorMod_test_11650(int p0, int p1) { StrictMath.FloorMod(p0, p1); }
    public void floorMod_test_11651(long p0, long p1) { StrictMath.FloorMod(p0, p1); }
    public void floorMod_test_11652(long p0, int p1) { StrictMath.FloorMod(p0, p1); }
    public void asin_test_11653(double p0) { StrictMath.Asin(p0); }
    public void acos_test_11654(double p0) { StrictMath.Acos(p0); }
    public void atan_test_11655(double p0) { StrictMath.Atan(p0); }
    public void IEEEremainder_test_11656(double p0, double p1) { StrictMath.IEEEremainder(p0, p1); }
    public void floorDiv_test_11657(long p0, long p1) { StrictMath.FloorDiv(p0, p1); }
    public void floorDiv_test_11658(long p0, int p1) { StrictMath.FloorDiv(p0, p1); }
    public void floorDiv_test_11659(int p0, int p1) { StrictMath.FloorDiv(p0, p1); }
    public void ceilDiv_test_11660(long p0, int p1) { StrictMath.CeilDiv(p0, p1); }
    public void ceilDiv_test_11661(long p0, long p1) { StrictMath.CeilDiv(p0, p1); }
    public void ceilDiv_test_11662(int p0, int p1) { StrictMath.CeilDiv(p0, p1); }
    public void ceilMod_test_11663(int p0, int p1) { StrictMath.CeilMod(p0, p1); }
    public void ceilMod_test_11664(long p0, int p1) { StrictMath.CeilMod(p0, p1); }
    public void ceilMod_test_11665(long p0, long p1) { StrictMath.CeilMod(p0, p1); }
    public void sinh_test_11666(double p0) { StrictMath.Sinh(p0); }
    public void cosh_test_11667(double p0) { StrictMath.Cosh(p0); }
    public void hypot_test_11668(double p0, double p1) { StrictMath.Hypot(p0, p1); }
    public void expm1_test_11669(double p0) { StrictMath.Expm1(p0); }
    public void log1p_test_11670(double p0) { StrictMath.Log1p(p0); }
    public void unsignedMultiplyExact_test_11671(int p0, int p1) { StrictMath.UnsignedMultiplyExact(p0, p1); }
    public void unsignedMultiplyExact_test_11672(long p0, int p1) { StrictMath.UnsignedMultiplyExact(p0, p1); }
    public void unsignedMultiplyExact_test_11673(long p0, long p1) { StrictMath.UnsignedMultiplyExact(p0, p1); }
    public void toRadians_test_11674(double p0) { StrictMath.ToRadians(p0); }
    public void toDegrees_test_11675(double p0) { StrictMath.ToDegrees(p0); }
    public void random_test_11676() { StrictMath.Random(); }
    public void divideExact_test_11677(int p0, int p1) { StrictMath.DivideExact(p0, p1); }
    public void divideExact_test_11678(long p0, long p1) { StrictMath.DivideExact(p0, p1); }
    public void floorDivExact_test_11679(int p0, int p1) { StrictMath.FloorDivExact(p0, p1); }
    public void floorDivExact_test_11680(long p0, long p1) { StrictMath.FloorDivExact(p0, p1); }
    public void ceilDivExact_test_11681(long p0, long p1) { StrictMath.CeilDivExact(p0, p1); }
    public void ceilDivExact_test_11682(int p0, int p1) { StrictMath.CeilDivExact(p0, p1); }
    public void toIntExact_test_11683(long p0) { StrictMath.ToIntExact(p0); }
    public void multiplyFull_test_11684(int p0, int p1) { StrictMath.MultiplyFull(p0, p1); }
    public void absExact_test_11685(long p0) { StrictMath.AbsExact(p0); }
    public void absExact_test_11686(int p0) { StrictMath.AbsExact(p0); }
    public void ulp_test_11687(double p0) { StrictMath.Ulp(p0); }
    public void ulp_test_11688(float p0) { StrictMath.Ulp(p0); }
    public void nextAfter_test_11689(float p0, double p1) { StrictMath.NextAfter(p0, p1); }
    public void nextAfter_test_11690(double p0, double p1) { StrictMath.NextAfter(p0, p1); }
    public void nextUp_test_11691(float p0) { StrictMath.NextUp(p0); }
    public void nextUp_test_11692(double p0) { StrictMath.NextUp(p0); }
    public void nextDown_test_11693(double p0) { StrictMath.NextDown(p0); }
    public void nextDown_test_11694(float p0) { StrictMath.NextDown(p0); }
    public void powExact_test_11695(long p0, int p1) { StrictMath.PowExact(p0, p1); }
    public void powExact_test_11696(int p0, int p1) { StrictMath.PowExact(p0, p1); }
    public void unsignedPowExact_test_11697(long p0, int p1) { StrictMath.UnsignedPowExact(p0, p1); }
    public void unsignedPowExact_test_11698(int p0, int p1) { StrictMath.UnsignedPowExact(p0, p1); }
}