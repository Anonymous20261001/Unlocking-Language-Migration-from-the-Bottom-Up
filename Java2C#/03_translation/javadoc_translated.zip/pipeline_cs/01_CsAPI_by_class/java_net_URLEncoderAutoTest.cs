using System;
using System.Text;

namespace Generated.Test
{
    public class java_net_URLEncoderAutoTest
    {
        public void encode_test_13267(string p0)
        {
            URLEncoder.encode(p0);
        }

        public void encode_test_13268(string p0, Charset p1)
        {
            URLEncoder.encode(p0, p1);
        }
    }

    public class URLEncoder
    {
        private URLEncoder() { }

        public static string encode(string s)
        {
            return encode(s, Charset.DefaultCharset);
        }

        public static string encode(string s, Charset charset)
        {
            if (s == null) throw new ArgumentNullException(nameof(s));
            if (charset == null) throw new ArgumentNullException(nameof(charset));

            byte[] bytes = charset.GetBytes(s);
            var result = new StringBuilder();

            foreach (byte b in bytes)
            {
                int c = b & 0xff;

                if ((c >= 'a' && c <= 'z') ||
                    (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') ||
                    c == '.' || c == '-' || c == '*' || c == '_')
                {
                    result.Append((char)c);
                }
                else if (c == ' ')
                {
                    result.Append('+');
                }
                else
                {
                    result.Append('%');
                    result.Append(c.ToString("x2"));
                }
            }

            return result.ToString();
        }
    }

    public class Charset
    {
        private readonly Encoding _encoding;

        public string Name { get; }

        public Charset(Encoding encoding, string name)
        {
            _encoding = encoding ?? throw new ArgumentNullException(nameof(encoding));
            Name = name ?? throw new ArgumentNullException(nameof(name));
        }

        public static Charset DefaultCharset { get; } = new Charset(Encoding.UTF8, "UTF-8");

        public static Charset ForName(string name)
        {
            if (name == null) throw new ArgumentNullException(nameof(name));

            switch (name.ToUpperInvariant())
            {
                case "UTF-8":
                case "UTF8":
                    return new Charset(Encoding.UTF8, "UTF-8");
                case "US-ASCII":
                case "ASCII":
                    return new Charset(Encoding.ASCII, "US-ASCII");
                default:
                    try
                    {
                        Encoding enc = Encoding.GetEncoding(name);
                        return new Charset(enc, enc.WebName);
                    }
                    catch (Exception)
                    {
                        throw new ArgumentException("Unsupported charset: " + name, nameof(name));
                    }
            }
        }

        public byte[] GetBytes(string s)
        {
            return _encoding.GetBytes(s);
        }
    }
}