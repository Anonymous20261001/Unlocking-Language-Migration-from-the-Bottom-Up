```csharp
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public sealed class MonthDay
    {
        private readonly int _month;
        private readonly int _day;

        public MonthDay(int month, int day)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month));
            if (day < 1 || day > 31)
                throw new ArgumentOutOfRangeException(nameof(day));
            _month = month;
            _day = day;
        }

        public int Month => _month;
        public int Day => _day;

        public static MonthDay Of(int month, int day) => new MonthDay(month, day);

        public static MonthDay Of(Month month, int day) => new MonthDay((int)month, day);

        public static MonthDay From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            return new MonthDay(temporal.GetMonthValue(), temporal.GetDayOfMonth());
        }

        public static MonthDay Parse(string text, DateTimeFormatter formatter)
        {
            if (formatter == null)
                formatter = DateTimeFormatter.ISO_MONTH_DAY;

            var numbers = new List<int>();
            int current = 0;
            bool inNumber = false;

            foreach (char c in text)
            {
                if (c >= '0' && c <= '9')
                {
                    current = current * 10 + (c - '0');
                    inNumber = true;
                }
                else
                {
                    if (inNumber)
                    {
                        numbers.Add(current);
                        current = 0;
                        inNumber = false;
                    }
                }
            }

            if (inNumber)
                numbers.Add(current);

            if (numbers.Count >= 2)
                return new MonthDay(numbers[0], numbers[1]);

            throw new FormatException("Cannot parse MonthDay from '" + text + "'");
        }

        public static MonthDay Parse(string text) => Parse(text, DateTimeFormatter.ISO_MONTH_DAY);

        public static MonthDay Now() => Now(Clock.SystemUTC());

        public static MonthDay Now(ZoneId zone) => Now(Clock.System(zone));

        public static MonthDay Now(Clock clock)
            => new MonthDay(clock.CurrentDateTime.Month, clock.CurrentDateTime.Day);

        public override string ToString() => $"--{_month:D2}-{_day:D2}";
    }

    public enum Month
    {
        January = 1,
        February = 2,
        March = 3,
        April = 4,
        May = 5,
        June = 6,
        July = 7,
        August = 8,
        September = 9,
        October = 10,
        November = 11,
        December = 12
    }

    public interface TemporalAccessor
    {
        int GetMonthValue();
        int GetDayOfMonth();
    }

    public class DateTimeFormatter
    {
        private readonly string _pattern;

        public DateTimeFormatter(string pattern)
        {
            _pattern = pattern ?? throw new ArgumentNullException(nameof(pattern));
        }

        public string Pattern => _pattern;

        public static DateTimeFormatter OfPattern(string pattern) => new DateTimeFormatter(pattern);

        public static DateTimeFormatter ISO_MONTH_DAY { get; } = new DateTimeFormatter("--MM-dd");

        public override string ToString() => _pattern;
    }

    public class ZoneId
    {
        private readonly string _id;
        private readonly TimeZoneInfo _timeZone;

        public ZoneId(string id)
        {
            _id = id ?? throw new ArgumentNullException(nameof(id));
            try
            {
                _timeZone = TimeZoneInfo.FindSystemTimeZoneById(id);
            }
            catch (TimeZoneNotFoundException)
            {
                _timeZone = TimeZoneInfo.Utc;
            }
            catch (InvalidTimeZoneException)
            {
                _timeZone = TimeZoneInfo.Utc;
            }
        }

        public string Id => _id;
        public TimeZoneInfo TimeZone => _timeZone;

        public static ZoneId Of(string id) => new ZoneId(id);
        public static ZoneId UTC { get; } = new ZoneId("UTC");

        public override string ToString() => _id;
    }

    public abstract class Clock
    {
        public abstract ZoneId Zone { get; }
        public abstract DateTime CurrentDateTime { get; }

        public static Clock System(ZoneId zone) => new SystemClock(zone);
        public static Clock SystemUTC() => System(ZoneId.UTC);
        public static Clock Fixed(DateTime dateTime, ZoneId zone) => new FixedClock(dateTime, zone);
    }

    public sealed class SystemClock : Clock
    {
        private readonly ZoneId _zone;

        public SystemClock(ZoneId zone)
        {
            _zone = zone ?? throw new ArgumentNullException(nameof(zone));
        }

        public override ZoneId Zone => _zone;
        public override DateTime CurrentDateTime => TimeZoneInfo.ConvertTime(DateTime.UtcNow, _zone.TimeZone);
    }

    public sealed class FixedClock : Clock
    {
        private readonly DateTime _dateTime;
        private readonly ZoneId _zone;

        public FixedClock(DateTime dateTime, ZoneId zone)
        {
            _dateTime = dateTime;
            _zone = zone ?? throw new ArgumentNullException(nameof(zone));
        }

        public override ZoneId Zone => _zone;
        public override DateTime CurrentDateTime => _dateTime;
    }

    public class java_time_MonthDayAutoTest
    {
        public void of_test_9004(int p0, int p1)
        {
            MonthDay.Of(p0, p1);
        }

        public void of_test_9005(Month p0, int p1)
        {
            MonthDay.Of(p0, p1);
        }

        public void from_test_9006(TemporalAccessor p0)
        {
            MonthDay.From(p0);
        }

        public void parse_test_9007(string p0, DateTimeFormatter p1)
        {
            MonthDay.Parse(p0, p1);
        }

        public void parse_test_9008(string p0)
        {
            MonthDay.Parse(p0);
        }

        public void now_test_9009(ZoneId p0)
        {
            MonthDay.Now(p0);
        }

        public void now_test_9010()
        {
            MonthDay.Now();
        }

        public void now_test_9011(Clock p0)
        {
            MonthDay.Now(p0);
        }
    }
}
```