```csharp
using System;

namespace Generated.Test
{
    public interface CompositeData
    {
    }

    public sealed class ConfigurationInfo
    {
        private ConfigurationInfo()
        {
        }

        public static ConfigurationInfo from(CompositeData cd)
        {
            if (cd == null)
            {
                throw new ArgumentNullException("cd");
            }

            return new ConfigurationInfo();
        }
    }

    public class jdk_management_jfr_ConfigurationInfoAutoTest
    {
        public void from_test_2909(CompositeData p0)
        {
            ConfigurationInfo.from(p0);
        }
    }
}
```