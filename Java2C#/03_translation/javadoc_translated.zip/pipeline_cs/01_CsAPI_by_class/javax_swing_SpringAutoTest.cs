using System;

namespace Generated.Test
{
    public class Component
    {
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public abstract class Spring
    {
        public abstract int GetMinimumValue();
        public abstract int GetPreferredValue();
        public abstract int GetMaximumValue();

        public virtual int GetValue()
        {
            return GetPreferredValue();
        }

        public virtual void SetValue(int value)
        {
        }

        public static Spring constant(int pref)
        {
            return new ValueSpring(pref, pref, pref);
        }

        public static Spring constant(int min, int pref, int max)
        {
            return new ValueSpring(min, pref, max);
        }

        public static Spring sum(Spring s1, Spring s2)
        {
            return new SumSpring(s1, s2);
        }

        public static Spring max(Spring s1, Spring s2)
        {
            return new MaxSpring(s1, s2);
        }

        public static Spring minus(Spring s)
        {
            return new MinusSpring(s);
        }

        public static Spring scale(Spring s, float factor)
        {
            return new ScaleSpring(s, factor);
        }

        public static Spring width(Component c)
        {
            return new ComponentSpring(c, true);
        }

        public static Spring height(Component c)
        {
            return new ComponentSpring(c, false);
        }

        private class ValueSpring : Spring
        {
            private int min;
            private int pref;
            private int max;

            public ValueSpring(int min, int pref, int max)
            {
                this.min = min;
                this.pref = pref;
                this.max = max;
            }

            public override int GetMinimumValue()
            {
                return min;
            }

            public override int GetPreferredValue()
            {
                return pref;
            }

            public override int GetMaximumValue()
            {
                return max;
            }

            public override void SetValue(int value)
            {
                pref = value;
                if (pref < min) min = pref;
                if (pref > max) max = pref;
            }
        }

        private class SumSpring : Spring
        {
            private Spring s1;
            private Spring s2;

            public SumSpring(Spring s1, Spring s2)
            {
                this.s1 = s1;
                this.s2 = s2;
            }

            public override int GetMinimumValue()
            {
                return s1.GetMinimumValue() + s2.GetMinimumValue();
            }

            public override int GetPreferredValue()
            {
                return s1.GetPreferredValue() + s2.GetPreferredValue();
            }

            public override int GetMaximumValue()
            {
                return s1.GetMaximumValue() + s2.GetMaximumValue();
            }

            public override void SetValue(int value)
            {
                s1.SetValue(value - s2.GetPreferredValue());
            }
        }

        private class MaxSpring : Spring
        {
            private Spring s1;
            private Spring s2;

            public MaxSpring(Spring s1, Spring s2)
            {
                this.s1 = s1;
                this.s2 = s2;
            }

            public override int GetMinimumValue()
            {
                return Math.Max(s1.GetMinimumValue(), s2.GetMinimumValue());
            }

            public override int GetPreferredValue()
            {
                return Math.Max(s1.GetPreferredValue(), s2.GetPreferredValue());
            }

            public override int GetMaximumValue()
            {
                return Math.Max(s1.GetMaximumValue(), s2.GetMaximumValue());
            }
        }

        private class MinusSpring : Spring
        {
            private Spring s;

            public MinusSpring(Spring s)
            {
                this.s = s;
            }

            public override int GetMinimumValue()
            {
                return -s.GetMaximumValue();
            }

            public override int GetPreferredValue()
            {
                return -s.GetPreferredValue();
            }

            public override int GetMaximumValue()
            {
                return -s.GetMinimumValue();
            }
        }

        private class ScaleSpring : Spring
        {
            private Spring s;
            private float factor;

            public ScaleSpring(Spring s, float factor)
            {
                this.s = s;
                this.factor = factor;
            }

            public override int GetMinimumValue()
            {
                return (int)(s.GetMinimumValue() * factor);
            }

            public override int GetPreferredValue()
            {
                return (int)(s.GetPreferredValue() * factor);
            }

            public override int GetMaximumValue()
            {
                return (int)(s.GetMaximumValue() * factor);
            }
        }

        private class ComponentSpring : Spring
        {
            private Component component;
            private bool isWidth;

            public ComponentSpring(Component component, bool isWidth)
            {
                this.component = component;
                this.isWidth = isWidth;
            }

            public override int GetMinimumValue()
            {
                return GetComponentValue();
            }

            public override int GetPreferredValue()
            {
                return GetComponentValue();
            }

            public override int GetMaximumValue()
            {
                return GetComponentValue();
            }

            private int GetComponentValue()
            {
                return isWidth ? component.Width : component.Height;
            }
        }
    }

    public class javax_swing_SpringAutoTest
    {
        public void height_test_11360(Component p0)
        {
            Spring.height(p0);
        }

        public void max_test_11361(Spring p0, Spring p1)
        {
            Spring.max(p0, p1);
        }

        public void scale_test_11362(Spring p0, float p1)
        {
            Spring.scale(p0, p1);
        }

        public void constant_test_11363(int p0)
        {
            Spring.constant(p0);
        }

        public void constant_test_11364(int p0, int p1, int p2)
        {
            Spring.constant(p0, p1, p2);
        }

        public void sum_test_11365(Spring p0, Spring p1)
        {
            Spring.sum(p0, p1);
        }

        public void width_test_11366(Component p0)
        {
            Spring.width(p0);
        }

        public void minus_test_11367(Spring p0)
        {
            Spring.minus(p0);
        }
    }
}