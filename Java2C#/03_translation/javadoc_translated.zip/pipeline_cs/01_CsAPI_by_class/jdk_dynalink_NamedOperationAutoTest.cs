using System;

namespace Generated.Test
{
    public interface Operation
    {
    }

    public sealed class NamedOperation : Operation
    {
        private readonly Operation baseOperation;
        private readonly object name;

        public NamedOperation(Operation baseOperation, object name)
        {
            if (baseOperation == null)
            {
                throw new ArgumentNullException("baseOperation");
            }
            this.baseOperation = baseOperation;
            this.name = name;
        }

        public object getName()
        {
            return name;
        }

        public Operation getBaseOperation()
        {
            return baseOperation;
        }

        public NamedOperation changeName(string newName)
        {
            return new NamedOperation(baseOperation, newName);
        }

        public static object getName(Operation op)
        {
            NamedOperation namedOp = op as NamedOperation;
            return namedOp != null ? namedOp.getName() : null;
        }

        public static Operation getBaseOperation(Operation op)
        {
            NamedOperation namedOp = op as NamedOperation;
            return namedOp != null ? namedOp.getBaseOperation() : op;
        }
    }

    public class jdk_dynalink_NamedOperationAutoTest
    {
        public void getName_test_9477(Operation p0)
        {
            NamedOperation.getName(p0);
        }

        public void getName_test_9478(Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.getName();
        }

        public void changeName_test_9479(string p0, Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.changeName(p0);
        }

        public void getBaseOperation_test_9480(Operation c0, object c1)
        {
            NamedOperation instance = new NamedOperation(c0, c1);
            instance.getBaseOperation();
        }

        public void getBaseOperation_test_9481(Operation p0)
        {
            NamedOperation.getBaseOperation(p0);
        }
    }
}