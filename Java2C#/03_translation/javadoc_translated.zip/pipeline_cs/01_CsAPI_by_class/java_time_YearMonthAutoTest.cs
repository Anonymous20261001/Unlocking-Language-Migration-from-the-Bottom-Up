using System;
using System.Globalization;

namespace Generated.Test
{
    public enum Month
    {
        JANUARY = 1,
        FEBRUARY = 2,
        MARCH = 3,
        APRIL = 4,
        MAY = 5,
        JUNE = 6,
        JULY = 7,
        AUGUST = 8,
        SEPTEMBER = 9,
        OCTOBER = 10,
        NOVEMBER = 11,
        DECEMBER = 12
    }

    public interface TemporalAccessor
    {
        int GetYear();
        Month GetMonth();
    }

    public class YearMonth : TemporalAccessor
    {
        private readonly int _year;
        private readonly Month _month;

        public YearMonth(int year, Month month)
        {
            int monthValue = (int)month;
            if (monthValue < 1 || monthValue > 12)
                throw new ArgumentOutOfRangeException(nameof(month));
            _year = year;
            _month = month;
        }

        public int GetYear() => _year;
        public Month GetMonth() => _month;
        public int GetMonthValue() => (int)_month;

        public static YearMonth Of(int year, int month)
        {
            if (month < 1 || month > 12)
                throw new ArgumentOutOfRangeException(nameof(month));
            return new YearMonth(year, (Month)month);
        }

        public static YearMonth Of(int year, Month month)
        {
            return new YearMonth(year, month);
        }

        public static YearMonth From(TemporalAccessor temporal)
        {
            if (temporal == null)
                throw new ArgumentNullException(nameof(temporal));
            if (temporal is YearMonth ym)
                return ym;
            return new YearMonth(temporal.GetYear(), temporal.GetMonth());
        }

        public static YearMonth Parse(string text)
        {
            if (text == null)
                throw new ArgumentNullException(nameof(text));
            DateTime dt;
            string[] formats = { "yyyy-MM", "yyyy-M" };
            if (DateTime.TryParseExact(text, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
            {
                return new YearMonth(dt.Year, (Month)dt.Month);
            }
            throw new FormatException($"Text '{text}' could not be parsed as YearMonth");
        }

        public static YearMonth Parse(string text, DateTimeFormatter formatter)
        {
            if (formatter != null)
            {
                TemporalAccessor temporal = formatter.Parse(text);
                return From(temporal);
            }
            return Parse(text);
        }

        public static YearMonth Now()
        {
            DateTime now = DateTime.Now;
            return new YearMonth(now.Year, (Month)now.Month);
        }

        public static YearMonth Now(ZoneId zone)
        {
            return Now();
        }

        public static YearMonth Now(Clock clock)
        {
            if (clock == null)
                throw new ArgumentNullException(nameof(clock));
            DateTime now = clock.GetCurrentDateTime();
            return new YearMonth(now.Year, (Month)now.Month);
        }
    }

    public class DateTimeFormatter
    {
        private readonly string _pattern;

        public DateTimeFormatter(string pattern)
        {
            _pattern = pattern;
        }

        public static DateTimeFormatter OfPattern(string pattern)
        {
            return new DateTimeFormatter(pattern);
        }

        public TemporalAccessor Parse(string text)
        {
            return YearMonth.Parse(text);
        }
    }

    public class ZoneId
    {
        private readonly string _id;

        public ZoneId(string id)
        {
            _id = id;
        }

        public static ZoneId SystemDefault => new ZoneId(TimeZoneInfo.Local.Id);
        public static ZoneId Of(string id) => new ZoneId(id);
        public string Id => _id;
    }

    public class Clock
    {
        public virtual DateTime GetCurrentDateTime() => DateTime.Now;
    }

    public class java_time_YearMonthAutoTest
    {
        public void of_test_13674(int p0, int p1)
        {
            YearMonth.Of(p0, p1);
        }

        public void of_test_13675(int p0, Month p1)
        {
            YearMonth.Of(p0, p1);
        }

        public void from_test_13676(TemporalAccessor p0)
        {
            YearMonth.From(p0);
        }

        public void parse_test_13677(string p0, DateTimeFormatter p1)
        {
            YearMonth.Parse(p0, p1);
        }

        public void parse_test_13678(string p0)
        {
            YearMonth.Parse(p0);
        }

        public void now_test_13679()
        {
            YearMonth.Now();
        }

        public void now_test_13680(ZoneId p0)
        {
            YearMonth.Now(p0);
        }

        public void now_test_13681(Clock p0)
        {
            YearMonth.Now(p0);
        }
    }
}