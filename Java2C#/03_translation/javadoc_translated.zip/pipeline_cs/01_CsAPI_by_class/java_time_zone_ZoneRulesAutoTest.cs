using System;
using System.Collections;

namespace Generated.Test
{
    public class ZoneOffset
    {
        public TimeSpan Offset { get; }

        public ZoneOffset(TimeSpan offset)
        {
            Offset = offset;
        }
    }

    public class ZoneRules
    {
        private ZoneRules()
        {
        }

        public static ZoneRules Of(ZoneOffset standardOffset, ZoneOffset wallOffset, IList standardOffsetTransitionList, IList transitionList, IList lastRules)
        {
            return new ZoneRules();
        }

        public static ZoneRules Of(ZoneOffset offsetOnly)
        {
            return new ZoneRules();
        }
    }

    public class java_time_zone_ZoneRulesAutoTest
    {
        public void of_test_13736(ZoneOffset p0, ZoneOffset p1, IList p2, IList p3, IList p4)
        {
            ZoneRules.Of(p0, p1, p2, p3, p4);
        }

        public void of_test_13737(ZoneOffset p0)
        {
            ZoneRules.Of(p0);
        }
    }
}