namespace Generated.Test
{
    public class URL
    {
        private string value;
        public URL(string value) { this.value = value; }
        public override string ToString() { return value; }
    }

    public class Dimension
    {
        public int width;
        public int height;
        public Dimension() { }
        public Dimension(int width, int height) { this.width = width; this.height = height; }
    }

    public class AppletContext { }
    public class AudioClip { }
    public class Image { }
    public class Locale { }
    public class AccessibleContext { }

    public interface AppletStub
    {
        bool isActive();
        string getParameter(string name);
        AppletContext getAppletContext();
        void appletResize(int width, int height);
        URL getCodeBase();
        URL getDocumentBase();
    }

    public class Applet
    {
        private AppletStub stub;

        public Applet() { }

        public URL getDocumentBase()
        {
            if (stub != null) return stub.getDocumentBase();
            return null;
        }

        public URL getCodeBase()
        {
            if (stub != null) return stub.getCodeBase();
            return null;
        }

        public AppletContext getAppletContext()
        {
            if (stub != null) return stub.getAppletContext();
            return null;
        }

        public void showStatus(string status) { }

        public AudioClip getAudioClip(URL url, string name) { return null; }
        public AudioClip getAudioClip(URL url) { return null; }

        public void play(URL url) { }
        public void play(URL url, string name) { }

        public void setStub(AppletStub stub) { this.stub = stub; }

        public static AudioClip newAudioClip(URL url) { return null; }

        public string getAppletInfo() { return null; }

        public string[][] getParameterInfo() { return null; }

        public bool isValidateRoot() { return false; }

        public AccessibleContext getAccessibleContext() { return null; }

        public Image getImage(URL url, string name) { return null; }
        public Image getImage(URL url) { return null; }

        public void init() { }
        public void start() { }
        public void stop() { }
        public void destroy() { }

        public bool isActive()
        {
            if (stub != null) return stub.isActive();
            return false;
        }

        public void resize(int width, int height) { }
        public void resize(Dimension d) { }

        public Locale getLocale() { return null; }

        public string getParameter(string name)
        {
            if (stub != null) return stub.getParameter(name);
            return null;
        }
    }

    public class java_applet_AppletAutoTest
    {

public void newAudioClip_test_172(URL p0)
        {
            Applet.newAudioClip(p0);
        }
    }
}
