using System;
using System.Collections.Generic;

namespace Generated.Test
{
    public class AccessControlException : Exception
    {
        public Permission Permission { get; }
        public AccessControlException(string message) : base(message) { }
        public AccessControlException(string message, Permission permission) : base(message) { Permission = permission; }
    }

    public abstract class Permission
    {
        protected readonly string _name;

        protected Permission(string name)
        {
            _name = name;
        }

        public virtual string getName()
        {
            return _name;
        }

        public virtual string getActions()
        {
            return "";
        }

        public virtual bool implies(Permission permission)
        {
            return Equals(permission);
        }

        public override bool Equals(object obj)
        {
            if (obj is Permission other)
            {
                return _name == other._name && getActions() == other.getActions();
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _name.GetHashCode();
        }

        public override string ToString()
        {
            return _name;
        }
    }

    public class AllPermission : Permission
    {
        public AllPermission() : base("*") { }

        public override bool implies(Permission permission)
        {
            return true;
        }
    }

    public class PermissionCollection
    {
        private readonly List<Permission> _permissions = new List<Permission>();

        public void add(Permission permission)
        {
            _permissions.Add(permission);
        }

        public void Add(Permission permission)
        {
            add(permission);
        }

        public bool implies(Permission permission)
        {
            foreach (Permission p in _permissions)
            {
                if (p.implies(permission))
                {
                    return true;
                }
            }
            return false;
        }

        public bool Implies(Permission permission)
        {
            return implies(permission);
        }
    }

    public class ProtectionDomain
    {
        private readonly object _codeSource;
        private readonly PermissionCollection _permissions;
        private readonly object _classLoader;
        private readonly object _principals;

        public ProtectionDomain(object codeSource, PermissionCollection permissions)
        {
            _codeSource = codeSource;
            _permissions = permissions;
            _classLoader = null;
            _principals = null;
        }

        public ProtectionDomain(object codeSource, PermissionCollection permissions, object classLoader, object principals)
        {
            _codeSource = codeSource;
            _permissions = permissions;
            _classLoader = classLoader;
            _principals = principals;
        }

        public object getCodeSource()
        {
            return _codeSource;
        }

        public PermissionCollection getPermissions()
        {
            return _permissions;
        }

        public object getClassLoader()
        {
            return _classLoader;
        }

        public object getPrincipals()
        {
            return _principals;
        }

        public virtual bool implies(Permission permission)
        {
            if (_permissions == null)
            {
                return false;
            }
            return _permissions.implies(permission);
        }

        public bool Implies(Permission permission)
        {
            return implies(permission);
        }
    }

    public interface DomainCombiner
    {
        ProtectionDomain[] combine(ProtectionDomain[] currentDomains, ProtectionDomain[] assignedDomains);
    }

    public class AccessControlContext
    {
        private readonly ProtectionDomain[] _domains;
        private readonly DomainCombiner _combiner;

        public AccessControlContext(ProtectionDomain[] context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }
            _domains = context;
            _combiner = null;
        }

        public AccessControlContext(AccessControlContext acc, DomainCombiner combiner)
        {
            if (acc == null)
            {
                throw new ArgumentNullException("acc");
            }
            _domains = acc._domains;
            _combiner = combiner;
        }

        public DomainCombiner getDomainCombiner()
        {
            return _combiner;
        }

        public void checkPermission(Permission perm)
        {
            if (perm == null)
            {
                throw new ArgumentNullException("perm");
            }

            if (_domains.Length == 0)
            {
                throw new AccessControlException("access denied", perm);
            }

            foreach (ProtectionDomain domain in _domains)
            {
                if (domain == null)
                {
                    continue;
                }

                if (!domain.implies(perm))
                {
                    throw new AccessControlException("access denied " + perm, perm);
                }
            }
        }

        public DomainCombiner GetDomainCombiner()
        {
            return getDomainCombiner();
        }

        public void CheckPermission(Permission perm)
        {
            checkPermission(perm);
        }
    }

    public class java_security_AccessControlContextAutoTest
    {

public void checkPermission_test_26(Permission p0, ProtectionDomain[] c0)
        {
            AccessControlContext instance = new AccessControlContext(c0);
            instance.checkPermission(p0);
        }
    }
}
