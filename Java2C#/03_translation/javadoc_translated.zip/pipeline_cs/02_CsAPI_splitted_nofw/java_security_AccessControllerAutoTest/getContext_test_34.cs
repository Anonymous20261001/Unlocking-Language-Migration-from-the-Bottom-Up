using System;

namespace Generated.Test
{
    public class Permission
    {
    }

    public interface PrivilegedAction
    {
        object run();
    }

    public class AccessControlContext
    {
    }

    public static class AccessController
    {
        public static void checkPermission(Permission perm)
        {
        }

        public static object doPrivileged(PrivilegedAction action)
        {
            return action.run();
        }

        public static object doPrivileged(PrivilegedAction action, AccessControlContext context)
        {
            return action.run();
        }

        public static object doPrivileged(PrivilegedAction action, AccessControlContext context, params Permission[] perms)
        {
            return action.run();
        }

        public static object doPrivilegedWithCombiner(PrivilegedAction action)
        {
            return action.run();
        }

        public static object doPrivilegedWithCombiner(PrivilegedAction action, AccessControlContext context, params Permission[] perms)
        {
            return action.run();
        }

        public static AccessControlContext getContext()
        {
            return new AccessControlContext();
        }
    }

    public class java_security_AccessControllerAutoTest
    {

public void getContext_test_34()
        {
            AccessController.getContext();
        }
    }
}
