using System;

namespace Generated.Test
{
    public interface UndoableEdit
    {
        void undo();
        void redo();
        bool canUndo();
        bool canRedo();
        void die();
        bool addEdit(UndoableEdit anEdit);
        bool replaceEdit(UndoableEdit anEdit);
        bool isSignificant();
        string getPresentationName();
        string getUndoPresentationName();
        string getRedoPresentationName();
    }

    public class CannotUndoException : Exception
    {
        public CannotUndoException() : base("Cannot undo") { }
    }

    public class CannotRedoException : Exception
    {
        public CannotRedoException() : base("Cannot redo") { }
    }

    public class AbstractUndoableEdit : UndoableEdit
    {
        protected const string UndoName = "Undo";
        protected const string RedoName = "Redo";
        protected bool hasBeenDone = true;
        protected bool alive = true;
        protected string presentationName = "";

        public virtual void die()
        {
            alive = false;
        }

        public virtual bool canUndo()
        {
            return alive && hasBeenDone;
        }

        public virtual bool canRedo()
        {
            return alive && !hasBeenDone;
        }

        public virtual void undo()
        {
            if (!canUndo())
            {
                throw new CannotUndoException();
            }
            hasBeenDone = false;
        }

        public virtual void redo()
        {
            if (!canRedo())
            {
                throw new CannotRedoException();
            }
            hasBeenDone = true;
        }

        public virtual bool addEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual bool replaceEdit(UndoableEdit anEdit)
        {
            return false;
        }

        public virtual bool isSignificant()
        {
            return true;
        }

        public virtual string getPresentationName()
        {
            return presentationName;
        }

        public virtual string getUndoPresentationName()
        {
            return UndoName + " " + presentationName;
        }

        public virtual string getRedoPresentationName()
        {
            return RedoName + " " + presentationName;
        }

        public override string ToString()
        {
            return base.ToString() + " hasBeenDone: " + hasBeenDone + " alive: " + alive;
        }
    }

    public class javax_swing_undo_AbstractUndoableEditAutoTest
    {

public void redo_test_15()
        {
            AbstractUndoableEdit instance = new AbstractUndoableEdit();
            instance.redo();
        }
    }
}
