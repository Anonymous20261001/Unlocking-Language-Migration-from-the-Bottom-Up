namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_450(float[] p0, float p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
