namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_423(int[] p0, int[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
