namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_497(short[] p0, int p1, int p2, short p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }
    }
}
