namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compareUnsigned_test_345(short[] p0, short[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }
    }
}
