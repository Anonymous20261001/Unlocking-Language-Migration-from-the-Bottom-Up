namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void copyOf_test_352(double[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }
    }
}
