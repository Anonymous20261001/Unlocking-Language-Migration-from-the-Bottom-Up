namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_429(byte[] p0, byte[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
