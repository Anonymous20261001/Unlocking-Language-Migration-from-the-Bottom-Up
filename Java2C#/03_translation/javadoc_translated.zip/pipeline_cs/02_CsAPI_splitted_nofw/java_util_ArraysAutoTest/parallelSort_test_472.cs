namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_472(short[] p0, int p1, int p2)
        {
            Arrays.ParallelSort(p0, p1, p2);
        }
    }
}
