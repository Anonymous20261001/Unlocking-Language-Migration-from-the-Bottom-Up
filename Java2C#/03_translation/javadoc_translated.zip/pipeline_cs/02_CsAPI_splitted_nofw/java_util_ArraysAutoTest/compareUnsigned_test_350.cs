namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compareUnsigned_test_350(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.CompareUnsigned(p0, p1, p2, p3, p4, p5);
        }
    }
}
