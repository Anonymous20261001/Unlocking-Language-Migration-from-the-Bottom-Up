namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_455(double[] p0, double p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
