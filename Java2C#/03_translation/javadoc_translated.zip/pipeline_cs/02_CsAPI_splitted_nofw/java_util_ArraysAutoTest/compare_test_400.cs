namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_400(bool[] p0, bool[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
