namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_367(object[] p0, System.Collections.Generic.IComparer<object> p1)
        {
            Arrays.Sort(p0, p1);
        }
    }
}
