namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void stream_test_437(long[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }
    }
}
