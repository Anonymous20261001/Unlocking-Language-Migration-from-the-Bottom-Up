namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_508(long[] p0, long p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
