namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_453(char[] p0, int p1, int p2, char p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }
    }
}
