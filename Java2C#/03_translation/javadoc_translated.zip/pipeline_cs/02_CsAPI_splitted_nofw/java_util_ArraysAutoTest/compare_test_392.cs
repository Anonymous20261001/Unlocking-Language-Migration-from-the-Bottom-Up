namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_392(char[] p0, char[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
