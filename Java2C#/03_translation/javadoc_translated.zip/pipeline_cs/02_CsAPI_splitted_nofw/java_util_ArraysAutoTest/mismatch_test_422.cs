namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_422(char[] p0, int p1, int p2, char[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }
    }
}
