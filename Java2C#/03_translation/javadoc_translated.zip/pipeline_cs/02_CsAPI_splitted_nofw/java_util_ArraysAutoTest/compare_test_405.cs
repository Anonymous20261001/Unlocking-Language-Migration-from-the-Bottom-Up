namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_405(System.IComparable[] p0, System.IComparable[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
