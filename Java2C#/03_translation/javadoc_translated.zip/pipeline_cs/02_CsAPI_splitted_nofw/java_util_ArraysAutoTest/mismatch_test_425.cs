namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_425(short[] p0, short[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
