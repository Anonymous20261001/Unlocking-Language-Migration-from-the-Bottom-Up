namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_479(System.IComparable[] p0)
        {
            Arrays.ParallelSort(p0);
        }
    }
}
