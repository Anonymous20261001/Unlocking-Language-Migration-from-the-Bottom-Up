namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_476(double[] p0)
        {
            Arrays.ParallelSort(p0);
        }
    }
}
