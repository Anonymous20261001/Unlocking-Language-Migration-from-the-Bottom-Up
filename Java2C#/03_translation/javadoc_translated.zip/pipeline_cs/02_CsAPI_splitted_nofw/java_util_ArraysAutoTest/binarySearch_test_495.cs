namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_495(float[] p0, float p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
