namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void spliterator_test_461(object[] p0)
        {
            Arrays.Spliterator(p0);
        }
    }
}
