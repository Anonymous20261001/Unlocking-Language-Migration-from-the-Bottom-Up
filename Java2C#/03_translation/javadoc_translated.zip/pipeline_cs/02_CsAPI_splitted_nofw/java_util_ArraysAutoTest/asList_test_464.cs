namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void asList_test_464(object[] p0)
        {
            Arrays.AsList(p0);
        }
    }
}
