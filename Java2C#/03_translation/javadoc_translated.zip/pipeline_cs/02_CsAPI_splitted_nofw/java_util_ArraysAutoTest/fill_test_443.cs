namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_443(int[] p0, int p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
