namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_506(char[] p0, char p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
