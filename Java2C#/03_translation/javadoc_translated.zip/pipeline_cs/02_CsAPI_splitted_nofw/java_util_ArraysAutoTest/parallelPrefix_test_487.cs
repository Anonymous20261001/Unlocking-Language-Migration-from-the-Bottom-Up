namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelPrefix_test_487(double[] p0, System.Func<double, double, double> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }
    }
}
