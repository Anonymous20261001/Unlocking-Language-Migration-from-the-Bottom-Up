namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_379(int[] p0, int p1, int p2)
        {
            Arrays.Sort(p0, p1, p2);
        }
    }
}
