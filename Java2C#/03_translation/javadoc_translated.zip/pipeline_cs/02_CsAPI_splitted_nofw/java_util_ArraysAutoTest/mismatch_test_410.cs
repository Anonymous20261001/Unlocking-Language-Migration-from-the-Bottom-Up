namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_410(long[] p0, long[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
