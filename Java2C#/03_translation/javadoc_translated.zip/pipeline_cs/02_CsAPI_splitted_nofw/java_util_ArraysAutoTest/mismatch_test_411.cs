namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_411(float[] p0, float[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
