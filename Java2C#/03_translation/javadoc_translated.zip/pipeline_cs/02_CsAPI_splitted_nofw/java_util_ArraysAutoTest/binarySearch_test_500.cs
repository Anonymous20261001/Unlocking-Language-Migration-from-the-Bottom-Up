namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_500(object[] p0, object p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.BinarySearch(p0, p1, p2);
        }
    }
}
