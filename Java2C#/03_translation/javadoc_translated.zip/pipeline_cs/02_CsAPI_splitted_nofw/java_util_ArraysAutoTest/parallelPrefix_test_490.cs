namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelPrefix_test_490(long[] p0, int p1, int p2, System.Func<long, long, long> p3)
        {
            Arrays.ParallelPrefix(p0, p1, p2, p3);
        }
    }
}
