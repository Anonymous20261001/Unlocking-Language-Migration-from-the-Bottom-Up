namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compareUnsigned_test_344(byte[] p0, byte[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }
    }
}
