namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void spliterator_test_456(int[] p0)
        {
            Arrays.Spliterator(p0);
        }
    }
}
