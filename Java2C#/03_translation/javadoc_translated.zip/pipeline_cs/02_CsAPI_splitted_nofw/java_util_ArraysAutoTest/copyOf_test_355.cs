namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void copyOf_test_355(object[] p0, int p1, System.Type p2)
        {
            Arrays.CopyOf(p0, p1, p2);
        }
    }
}
