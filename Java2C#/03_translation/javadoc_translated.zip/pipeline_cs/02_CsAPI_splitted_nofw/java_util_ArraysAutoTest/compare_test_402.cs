namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_402(byte[] p0, byte[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
