namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_406(object[] p0, object[] p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.Compare(p0, p1, p2);
        }
    }
}
