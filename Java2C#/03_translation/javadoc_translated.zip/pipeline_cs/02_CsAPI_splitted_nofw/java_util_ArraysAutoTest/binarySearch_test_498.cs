namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_498(object[] p0, object p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
