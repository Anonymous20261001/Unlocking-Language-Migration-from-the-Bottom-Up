namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_366(object[] p0, int p1, int p2, System.Collections.Generic.IComparer<object> p3)
        {
            Arrays.Sort(p0, p1, p2, p3);
        }
    }
}
