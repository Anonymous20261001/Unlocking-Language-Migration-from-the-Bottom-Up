namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_418(double[] p0, double[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
