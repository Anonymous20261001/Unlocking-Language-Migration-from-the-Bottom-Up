namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_391(int[] p0, int[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
