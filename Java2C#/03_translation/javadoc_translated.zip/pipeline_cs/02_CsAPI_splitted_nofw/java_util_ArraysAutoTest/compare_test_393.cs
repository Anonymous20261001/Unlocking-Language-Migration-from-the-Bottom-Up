namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_393(int[] p0, int p1, int p2, int[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }
    }
}
