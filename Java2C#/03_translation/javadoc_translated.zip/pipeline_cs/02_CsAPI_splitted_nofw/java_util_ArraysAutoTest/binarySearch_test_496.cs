namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_496(short[] p0, short p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
