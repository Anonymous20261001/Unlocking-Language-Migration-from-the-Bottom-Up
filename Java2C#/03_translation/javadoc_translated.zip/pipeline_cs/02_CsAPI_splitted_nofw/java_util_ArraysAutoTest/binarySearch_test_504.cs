namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_504(byte[] p0, byte p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
