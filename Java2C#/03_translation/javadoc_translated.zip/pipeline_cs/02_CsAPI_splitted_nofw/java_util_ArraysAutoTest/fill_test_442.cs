namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_442(int[] p0, int p1, int p2, int p3)
        {
            Arrays.Fill(p0, p1, p2, p3);
        }
    }
}
