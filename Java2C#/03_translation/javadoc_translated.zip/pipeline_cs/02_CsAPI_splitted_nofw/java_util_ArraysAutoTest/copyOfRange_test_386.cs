namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void copyOfRange_test_386(object[] p0, int p1, int p2, System.Type p3)
        {
            Arrays.CopyOfRange(p0, p1, p2, p3);
        }
    }
}
