namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_507(int[] p0, int p1, int p2, int p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }
    }
}
