namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void stream_test_431(long[] p0)
        {
            Arrays.Stream(p0);
        }
    }
}
