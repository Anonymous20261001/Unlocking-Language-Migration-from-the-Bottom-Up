namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_468(int[] p0)
        {
            Arrays.ParallelSort(p0);
        }
    }
}
