namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_415(object[] p0, object[] p1, System.Collections.Generic.IComparer<object> p2)
        {
            Arrays.Mismatch(p0, p1, p2);
        }
    }
}
