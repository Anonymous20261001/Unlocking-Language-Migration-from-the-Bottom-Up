namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void spliterator_test_459(object[] p0, int p1, int p2)
        {
            Arrays.Spliterator(p0, p1, p2);
        }
    }
}
