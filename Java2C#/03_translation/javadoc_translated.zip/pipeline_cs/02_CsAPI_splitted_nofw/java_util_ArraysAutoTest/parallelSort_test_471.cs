namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_471(object[] p0, int p1, int p2, System.Collections.Generic.IComparer<object> p3)
        {
            Arrays.ParallelSort(p0, p1, p2, p3);
        }
    }
}
