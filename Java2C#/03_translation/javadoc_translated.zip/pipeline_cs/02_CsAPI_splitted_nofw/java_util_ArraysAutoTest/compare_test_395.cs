namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_395(long[] p0, int p1, int p2, long[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }
    }
}
