namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_441(short[] p0, short p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
