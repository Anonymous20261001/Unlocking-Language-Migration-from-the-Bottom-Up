namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_378(byte[] p0)
        {
            Arrays.Sort(p0);
        }
    }
}
