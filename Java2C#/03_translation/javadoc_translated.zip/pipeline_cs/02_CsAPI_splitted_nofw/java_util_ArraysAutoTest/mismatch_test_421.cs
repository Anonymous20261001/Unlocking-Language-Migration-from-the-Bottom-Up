namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_421(char[] p0, char[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
