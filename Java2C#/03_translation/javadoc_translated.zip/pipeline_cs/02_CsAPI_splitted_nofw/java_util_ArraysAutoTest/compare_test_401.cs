namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_401(bool[] p0, int p1, int p2, bool[] p3, int p4, int p5)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5);
        }
    }
}
