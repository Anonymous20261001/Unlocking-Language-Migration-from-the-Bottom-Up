namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelPrefix_test_488(int[] p0, System.Func<int, int, int> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }
    }
}
