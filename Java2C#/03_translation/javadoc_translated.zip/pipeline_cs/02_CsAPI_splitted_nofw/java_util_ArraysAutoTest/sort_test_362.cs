namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_362(object[] p0)
        {
            Arrays.Sort(p0);
        }
    }
}
