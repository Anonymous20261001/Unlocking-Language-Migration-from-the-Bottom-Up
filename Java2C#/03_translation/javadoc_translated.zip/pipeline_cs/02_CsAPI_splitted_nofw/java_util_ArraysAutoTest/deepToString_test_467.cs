namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void deepToString_test_467(object[] p0)
        {
            Arrays.DeepToString(p0);
        }
    }
}
