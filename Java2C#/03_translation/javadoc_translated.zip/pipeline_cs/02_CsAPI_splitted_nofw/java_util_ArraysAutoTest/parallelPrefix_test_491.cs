namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelPrefix_test_491(long[] p0, System.Func<long, long, long> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }
    }
}
