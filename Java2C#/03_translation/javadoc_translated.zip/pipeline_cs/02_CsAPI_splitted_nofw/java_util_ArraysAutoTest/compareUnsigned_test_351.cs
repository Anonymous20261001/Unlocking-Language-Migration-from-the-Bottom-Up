namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compareUnsigned_test_351(int[] p0, int[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }
    }
}
