namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_417(double[] p0, int p1, int p2, double[] p3, int p4, int p5)
        {
            Arrays.Mismatch(p0, p1, p2, p3, p4, p5);
        }
    }
}
