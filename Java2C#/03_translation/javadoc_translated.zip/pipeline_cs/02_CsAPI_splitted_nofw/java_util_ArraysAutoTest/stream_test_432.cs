namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void stream_test_432(int[] p0, int p1, int p2)
        {
            Arrays.Stream(p0, p1, p2);
        }
    }
}
