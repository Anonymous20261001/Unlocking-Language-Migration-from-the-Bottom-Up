namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void stream_test_436(double[] p0)
        {
            Arrays.Stream(p0);
        }
    }
}
