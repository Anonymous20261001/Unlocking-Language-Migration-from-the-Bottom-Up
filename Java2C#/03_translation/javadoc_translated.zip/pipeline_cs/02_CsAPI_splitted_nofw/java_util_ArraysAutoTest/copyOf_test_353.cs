namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void copyOf_test_353(int[] p0, int p1)
        {
            Arrays.CopyOf(p0, p1);
        }
    }
}
