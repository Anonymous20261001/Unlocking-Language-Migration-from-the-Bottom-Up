namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_398(short[] p0, short[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
