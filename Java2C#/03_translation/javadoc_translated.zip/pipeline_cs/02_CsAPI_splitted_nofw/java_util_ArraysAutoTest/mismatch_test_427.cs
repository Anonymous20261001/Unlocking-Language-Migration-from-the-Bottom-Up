namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_427(bool[] p0, bool[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
