namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_478(float[] p0)
        {
            Arrays.ParallelSort(p0);
        }
    }
}
