namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_396(double[] p0, double[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
