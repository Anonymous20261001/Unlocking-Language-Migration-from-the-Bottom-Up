namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void mismatch_test_413(object[] p0, object[] p1)
        {
            Arrays.Mismatch(p0, p1);
        }
    }
}
