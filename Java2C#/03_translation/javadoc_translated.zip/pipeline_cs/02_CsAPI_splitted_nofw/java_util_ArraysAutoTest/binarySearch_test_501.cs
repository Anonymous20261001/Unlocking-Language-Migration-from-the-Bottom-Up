namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_501(double[] p0, int p1, int p2, double p3)
        {
            Arrays.BinarySearch(p0, p1, p2, p3);
        }
    }
}
