namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_439(long[] p0, long p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
