namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_394(long[] p0, long[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
