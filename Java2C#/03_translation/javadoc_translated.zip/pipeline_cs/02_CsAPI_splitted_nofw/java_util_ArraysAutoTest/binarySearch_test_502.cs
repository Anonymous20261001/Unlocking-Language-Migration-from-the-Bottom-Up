namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void binarySearch_test_502(double[] p0, double p1)
        {
            Arrays.BinarySearch(p0, p1);
        }
    }
}
