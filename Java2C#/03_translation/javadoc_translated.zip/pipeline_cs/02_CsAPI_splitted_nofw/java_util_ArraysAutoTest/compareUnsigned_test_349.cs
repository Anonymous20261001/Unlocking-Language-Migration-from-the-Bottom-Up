namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compareUnsigned_test_349(long[] p0, long[] p1)
        {
            Arrays.CompareUnsigned(p0, p1);
        }
    }
}
