namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_446(char[] p0, char p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
