namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_440(bool[] p0, bool p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
