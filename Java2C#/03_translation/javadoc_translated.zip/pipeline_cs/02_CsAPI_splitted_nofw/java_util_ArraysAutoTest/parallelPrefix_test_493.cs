namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelPrefix_test_493(object[] p0, System.Func<object, object, object> p1)
        {
            Arrays.ParallelPrefix(p0, p1);
        }
    }
}
