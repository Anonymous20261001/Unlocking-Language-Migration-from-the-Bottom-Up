namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void copyOfRange_test_381(char[] p0, int p1, int p2)
        {
            Arrays.CopyOfRange(p0, p1, p2);
        }
    }
}
