namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_409(float[] p0, float[] p1)
        {
            Arrays.Compare(p0, p1);
        }
    }
}
