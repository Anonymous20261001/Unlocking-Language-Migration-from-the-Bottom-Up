namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void sort_test_365(short[] p0)
        {
            Arrays.Sort(p0);
        }
    }
}
