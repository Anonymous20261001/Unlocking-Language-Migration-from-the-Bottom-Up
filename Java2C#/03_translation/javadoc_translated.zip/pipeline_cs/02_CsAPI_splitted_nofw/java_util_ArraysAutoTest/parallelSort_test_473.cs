namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void parallelSort_test_473(object[] p0, System.Collections.Generic.IComparer<object> p1)
        {
            Arrays.ParallelSort(p0, p1);
        }
    }
}
