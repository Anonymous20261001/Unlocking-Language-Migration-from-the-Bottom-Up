namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_452(object[] p0, object p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
