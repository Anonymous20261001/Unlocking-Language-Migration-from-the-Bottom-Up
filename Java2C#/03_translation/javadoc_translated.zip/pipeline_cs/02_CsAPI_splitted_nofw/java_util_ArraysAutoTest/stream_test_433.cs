namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void stream_test_433(int[] p0)
        {
            Arrays.Stream(p0);
        }
    }
}
