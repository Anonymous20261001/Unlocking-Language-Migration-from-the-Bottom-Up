namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void compare_test_408(object[] p0, int p1, int p2, object[] p3, int p4, int p5, System.Collections.Generic.IComparer<object> p6)
        {
            Arrays.Compare(p0, p1, p2, p3, p4, p5, p6);
        }
    }
}
