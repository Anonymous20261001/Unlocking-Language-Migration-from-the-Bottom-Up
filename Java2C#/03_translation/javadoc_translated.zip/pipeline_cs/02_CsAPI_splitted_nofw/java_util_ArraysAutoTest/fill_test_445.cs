namespace Generated.Test
{
    public class java_util_ArraysAutoTest
    {

public void fill_test_445(byte[] p0, byte p1)
        {
            Arrays.Fill(p0, p1);
        }
    }
}
