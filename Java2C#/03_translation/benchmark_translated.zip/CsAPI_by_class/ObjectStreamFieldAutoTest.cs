```csharp
using System;

public class ObjectStreamField : IComparable
{
    private readonly string name;
    private readonly Type type;
    private readonly bool unshared;
    private int offset; // default 0, not exposed

    public ObjectStreamField(string name, Type type) : this(name, type, false) { }

    public ObjectStreamField(string name, Type type, bool unshared)
    {
        this.name = name;
        this.type = type;
        this.unshared = unshared;
        this.offset = 0;
    }

    public string GetName() => name;

    public override string ToString()
    {
        if (type.IsPrimitive)
            return $"{GetTypeCodeFromType(type)} {name}";
        else
            return $"{GetTypeString()} {name}";
    }

    public int CompareTo(object obj)
    {
        if (obj is ObjectStreamField other)
            return string.Compare(name, other.name, StringComparison.Ordinal);
        throw new ArgumentException("obj is not an ObjectStreamField");
    }

    public bool IsPrimitive() => type.IsPrimitive;

    public Type GetType() => type; // Important: property name would conflict, use method

    public char GetTypeCode() => GetTypeCodeFromType(type);

    public string GetTypeString()
    {
        if (type.IsPrimitive) return null;
        if (type.IsArray)
        {
            // Build internal representation like "[Lfully.qualified.ClassName;"
            string elementInternal = GetInternalTypeName(type.GetElementType());
            return $"[{GetTypeCodeFromType(type.GetElementType())}{elementInternal}";
        }
        else
        {
            // For non-array objects: "Lfully/qualified/ClassName;"
            return $"L{GetInternalTypeName(type)};";
        }
    }

    public int GetOffset() => offset;

    public bool IsUnshared() => unshared;

    private static char GetTypeCodeFromType(Type t)
    {
        if (t == typeof(byte)) return 'B';
        if (t == typeof(char)) return 'C';
        if (t == typeof(double)) return 'D';
        if (t == typeof(float)) return 'F';
        if (t == typeof(int)) return 'I';
        if (t == typeof(long)) return 'J';
        if (t == typeof(short)) return 'S';
        if (t == typeof(bool)) return 'Z';
        if (t.IsArray) return '['; // array type code (though recursive handling in GetTypeString)
        return 'L'; // object type
    }

    private static string GetInternalTypeName(Type t)
    {
        if (t.IsArray)
        {
            // Recursively build internal representation for array
            string elementName = GetInternalTypeName(t.GetElementType());
            return $"[{GetTypeCodeFromType(t.GetElementType())}{elementName}";
        }
        else
        {
            // Replace '.' with '/' and ensure no leading/trailing spaces
            return t.FullName?.Replace('.', '/') ?? t.Name;
        }
    }
}

using NUnit.Framework;
using System;

[TestFixture]
public class ObjectStreamFieldAutoTest
{
    [Test]
    public void GetName_test_1789()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.GetName();
    }

    [Test]
    public void ToString_test_1790()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.ToString();
    }

    [Test]
    public void CompareTo_test_1791()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        var other = new ObjectStreamField("otherField", typeof(double));
        instance.CompareTo(other);
    }

    [Test]
    public void IsPrimitive_test_1792()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.IsPrimitive();
    }

    [Test]
    public void GetType_test_1793()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.GetType();
    }

    [Test]
    public void GetTypeCode_test_1794()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.GetTypeCode();
    }

    [Test]
    public void GetTypeString_test_1795()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.GetTypeString();
    }

    [Test]
    public void GetOffset_test_1796()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.GetOffset();
    }

    [Test]
    public void IsUnshared_test_1797()
    {
        var instance = new ObjectStreamField("fieldName", typeof(int));
        instance.IsUnshared();
    }
}
```