```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    public class InvocationTargetExceptionAutoTest
    {
        [Test]
        public void GetCause_Test_2423()
        {
            Exception c0 = new Exception(); // Simulate the Throwable parameter
            InvocationTargetException instance = new InvocationTargetException(c0);
            instance.GetCause();
        }

        [Test]
        public void GetTargetException_Test_2424()
        {
            Exception c0 = new Exception(); // Simulate the Throwable parameter
            InvocationTargetException instance = new InvocationTargetException(c0);
            instance.GetTargetException();
        }
    }

    /// <summary>
    /// C# equivalent of java.lang.reflect.InvocationTargetException.
    /// Wraps an exception thrown by a reflected method invocation.
    /// </summary>
    public class InvocationTargetException : Exception
    {
        /// <summary>
        /// Constructs an InvocationTargetException with the specified target exception.
        /// </summary>
        /// <param name="innerException">The exception that caused the invocation to fail.</param>
        public InvocationTargetException(Exception innerException)
            : base("", innerException)
        {
        }

        /// <summary>
        /// Returns the cause of this exception (the target exception).
        /// Equivalent to Java's getCause().
        /// </summary>
        public Exception GetCause()
        {
            return this.InnerException;
        }

        /// <summary>
        /// Returns the target exception (the exception thrown by the invoked method).
        /// Equivalent to Java's getTargetException().
        /// </summary>
        public Exception GetTargetException()
        {
            return this.InnerException;
        }
    }
}
```