```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.beans.IndexedPropertyChangeEvent
    public class IndexedPropertyChangeEvent : EventArgs
    {
        private readonly object _source;
        private readonly string _propertyName;
        private readonly object _oldValue;
        private readonly object _newValue;
        private readonly int _index;

        public IndexedPropertyChangeEvent(object source, string propertyName, object oldValue, object newValue, int index)
        {
            _source = source;
            _propertyName = propertyName;
            _oldValue = oldValue;
            _newValue = newValue;
            _index = index;
        }

        public int GetIndex()
        {
            return _index;
        }
    }

    [TestFixture]
    public class IndexedPropertyChangeEventAutoTest
    {
        [Test]
        public void GetIndex_Test_1552()
        {
            // Instantiate with dummy values (same as Java test would use)
            IndexedPropertyChangeEvent instance = new IndexedPropertyChangeEvent(null, "property", null, null, 0);
            instance.GetIndex();
        }
    }
}
```