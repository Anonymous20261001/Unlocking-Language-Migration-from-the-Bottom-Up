```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class MGF1ParameterSpecAutoTest
    {
        [Test]
        public void GetDigestAlgorithm_test_2895()
        {
            // Using a default algorithm string; the original test parameter is omitted for simplicity.
            MGF1ParameterSpec instance = new MGF1ParameterSpec("SHA-256");
            instance.GetDigestAlgorithm();
        }

        [Test]
        public void ToString_test_2896()
        {
            MGF1ParameterSpec instance = new MGF1ParameterSpec("SHA-256");
            instance.ToString();
        }
    }

    /// <summary>
    /// C# equivalent of java.security.spec.MGF1ParameterSpec.
    /// </summary>
    public class MGF1ParameterSpec
    {
        private readonly string _digestAlgorithm;

        public MGF1ParameterSpec(string mdName)
        {
            if (mdName == null)
                throw new ArgumentNullException(nameof(mdName));
            _digestAlgorithm = mdName;
        }

        public string GetDigestAlgorithm()
        {
            return _digestAlgorithm;
        }

        public override string ToString()
        {
            return base.ToString(); // Mimics Java's default Object.toString() behavior.
        }
    }
}
```