```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.swing.text.ChangedCharSetException
    public class ChangedCharSetException : Exception
    {
        private readonly string charSetSpec;
        private readonly bool keyEqualsCharSet;

        public ChangedCharSetException(string charSetSpec, bool keyEqualsCharSet)
            : base("Changed character set specification exception")
        {
            this.charSetSpec = charSetSpec;
            this.keyEqualsCharSet = keyEqualsCharSet;
        }

        public string GetCharSetSpec()
        {
            return charSetSpec;
        }

        public bool KeyEqualsCharSet()
        {
            return keyEqualsCharSet;
        }
    }

    [TestFixture]
    public class ChangedCharSetExceptionAutoTest
    {
        [Test]
        public void GetCharSetSpec_test_10146()
        {
            // Using default parameters to match the intent of the original test
            var instance = new ChangedCharSetException("testSpec", true);
            instance.GetCharSetSpec();
        }

        [Test]
        public void KeyEqualsCharSet_test_10147()
        {
            var instance = new ChangedCharSetException("testSpec", false);
            instance.KeyEqualsCharSet();
        }
    }
}
```