```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

public interface IDescriptor
{
    string[] GetFieldNames();
    object[] GetFieldValues(string[] fieldNames);
    object GetFieldValue(string fieldName);
    void RemoveField(string fieldName);
    string[] GetFields();
    bool IsValid();
    object Clone();
}

public class ImmutableDescriptor : IDescriptor, IEquatable<ImmutableDescriptor>
{
    private readonly Dictionary<string, object> _fields;

    public ImmutableDescriptor(IDictionary<string, object> fields)
    {
        _fields = fields != null
            ? new Dictionary<string, object>(fields, StringComparer.Ordinal)
            : new Dictionary<string, object>();
    }

    public string[] GetFieldNames()
    {
        return _fields.Keys.ToArray();
    }

    public object[] GetFieldValues(string[] fieldNames)
    {
        if (fieldNames == null)
            throw new ArgumentNullException(nameof(fieldNames));
        var values = new object[fieldNames.Length];
        for (int i = 0; i < fieldNames.Length; i++)
        {
            _fields.TryGetValue(fieldNames[i], out values[i]);
        }
        return values;
    }

    public object GetFieldValue(string fieldName)
    {
        if (fieldName == null)
            throw new ArgumentNullException(nameof(fieldName));
        _fields.TryGetValue(fieldName, out var value);
        return value;
    }

    public void RemoveField(string fieldName)
    {
        throw new InvalidOperationException("The descriptor is immutable. Cannot remove a field.");
    }

    public string[] GetFields()
    {
        return _fields.Select(kvp => $"{kvp.Key}={kvp.Value}").ToArray();
    }

    public bool IsValid()
    {
        // In Java's ImmutableDescriptor, isValid() returns true (or checks serializability).
        // For simplicity, always return true.
        return true;
    }

    public object Clone()
    {
        return new ImmutableDescriptor(new Dictionary<string, object>(_fields));
    }

    public override bool Equals(object obj)
    {
        return Equals(obj as ImmutableDescriptor);
    }

    public bool Equals(ImmutableDescriptor other)
    {
        if (other == null)
            return false;
        if (ReferenceEquals(this, other))
            return true;
        if (_fields.Count != other._fields.Count)
            return false;
        foreach (var kvp in _fields)
        {
            if (!other._fields.TryGetValue(kvp.Key, out var otherValue))
                return false;
            if (!object.Equals(kvp.Value, otherValue))
                return false;
        }
        return true;
    }

    public override int GetHashCode()
    {
        unchecked
        {
            int hash = 17;
            foreach (var kvp in _fields.OrderBy(k => k.Key))
            {
                hash = hash * 31 + (kvp.Key?.GetHashCode() ?? 0);
                hash = hash * 31 + (kvp.Value?.GetHashCode() ?? 0);
            }
            return hash;
        }
    }

    public override string ToString()
    {
        var sb = new StringBuilder("ImmutableDescriptor[");
        bool first = true;
        foreach (var kvp in _fields)
        {
            if (!first)
                sb.Append(", ");
            sb.Append($"{kvp.Key}={kvp.Value}");
            first = false;
        }
        sb.Append(']');
        return sb.ToString();
    }

    public static ImmutableDescriptor Union(params IDescriptor[] descriptors)
    {
        if (descriptors == null)
            throw new ArgumentNullException(nameof(descriptors));
        var merged = new Dictionary<string, object>();
        foreach (var desc in descriptors)
        {
            if (desc == null) continue;
            var names = desc.GetFieldNames();
            var values = desc.GetFieldValues(names);
            for (int i = 0; i < names.Length; i++)
            {
                merged[names[i]] = values[i];
            }
        }
        return new ImmutableDescriptor(merged);
    }
}

[TestFixture]
public class ImmutableDescriptorAutoTest
{
    [Test]
    public void GetFieldNames_Test_5549()
    {
        var map = new Dictionary<string, object>
        {
            { "name", "test" },
            { "value", 42 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.GetFieldNames();
    }

    [Test]
    public void GetFieldValues_Test_5550()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 },
            { "b", "hello" }
        };
        var instance = new ImmutableDescriptor(map);
        string[] names = { "a", "c" };
        instance.GetFieldValues(names);
    }

    [Test]
    public void RemoveField_Test_5551()
    {
        var map = new Dictionary<string, object>
        {
            { "x", "y" }
        };
        var instance = new ImmutableDescriptor(map);
        Assert.Throws<InvalidOperationException>(() => instance.RemoveField("x"));
    }

    [Test]
    public void Equals_Test_5552()
    {
        var map = new Dictionary<string, object>
        {
            { "key", "value" }
        };
        var instance = new ImmutableDescriptor(map);
        instance.Equals(new object());
    }

    [Test]
    public void ToString_Test_5553()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.ToString();
    }

    [Test]
    public void HashCode_Test_5554()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.GetHashCode();
    }

    [Test]
    public void Clone_Test_5555()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.Clone();
    }

    [Test]
    public void GetFields_Test_5556()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.GetFields();
    }

    [Test]
    public void IsValid_Test_5557()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.IsValid();
    }

    [Test]
    public void Union_Test_5558()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 1 }
        };
        var instance = new ImmutableDescriptor(map);
        var descriptors = new IDescriptor[] { instance, instance };
        ImmutableDescriptor.Union(descriptors);
    }

    [Test]
    public void GetFieldValue_Test_5559()
    {
        var map = new Dictionary<string, object>
        {
            { "a", 42 }
        };
        var instance = new ImmutableDescriptor(map);
        instance.GetFieldValue("a");
    }
}
```