```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Custom exception mimicking Java's IllegalFormatFlagsException
    public class IllegalFormatFlagsException : Exception
    {
        private readonly string _flags;

        public IllegalFormatFlagsException(string flags)
        {
            if (flags == null)
                throw new ArgumentNullException(nameof(flags));
            _flags = flags;
        }

        public string Flags => _flags;

        public override string Message => $"Flags = '{_flags}'";
    }

    [TestFixture]
    public class IllegalFormatFlagsExceptionAutoTest
    {
        [TestCase("someFlag")]
        public void GetMessage_Test_3569(string c0)
        {
            var instance = new IllegalFormatFlagsException(c0);
            _ = instance.Message; // accessing property (equivalent to getMessage())
        }

        [TestCase("someFlag")]
        public void GetFlags_Test_3570(string c0)
        {
            var instance = new IllegalFormatFlagsException(c0);
            _ = instance.Flags; // accessing property (equivalent to getFlags())
        }
    }
}
```