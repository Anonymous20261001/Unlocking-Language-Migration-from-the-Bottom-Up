```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Java's Format class (minimal equivalent)
    public abstract class Format
    {
        // Java's Format.Field inner class
        public class Field
        {
            public string Name { get; }

            public Field(string name)
            {
                Name = name ?? throw new ArgumentNullException(nameof(name));
            }

            public override bool Equals(object obj)
            {
                if (obj is Field other)
                    return Name == other.Name;
                return false;
            }

            public override int GetHashCode() => Name.GetHashCode();

            public override string ToString() => Name;
        }
    }

    // Java's FieldPosition class (behaviour equivalent)
    public class FieldPosition
    {
        private int field;
        private Format.Field fieldAttribute;
        private int beginIndex;
        private int endIndex;

        // Constructor with Format.Field
        public FieldPosition(Format.Field attribute)
        {
            fieldAttribute = attribute ?? throw new ArgumentNullException(nameof(attribute));
            field = -1; // as per Java documentation when constructed with Format.Field
            beginIndex = 0;
            endIndex = 0;
        }

        public int GetField() => field;

        public Format.Field GetFieldAttribute() => fieldAttribute;

        public int GetBeginIndex() => beginIndex;

        public int GetEndIndex() => endIndex;

        public void SetBeginIndex(int index) => beginIndex = index;

        public void SetEndIndex(int index) => endIndex = index;

        public override bool Equals(object obj)
        {
            if (obj is FieldPosition other)
            {
                return field == other.field &&
                       fieldAttribute == other.fieldAttribute &&
                       beginIndex == other.beginIndex &&
                       endIndex == other.endIndex;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + field.GetHashCode();
            hash = hash * 31 + (fieldAttribute?.GetHashCode() ?? 0);
            hash = hash * 31 + beginIndex.GetHashCode();
            hash = hash * 31 + endIndex.GetHashCode();
            return hash;
        }

        public override string ToString()
        {
            return $"FieldPosition[field={field}, attribute={fieldAttribute}, begin={beginIndex}, end={endIndex}]";
        }
    }

    [TestFixture]
    public class FieldPositionAutoTest
    {
        [Test]
        public void Equals_Test_3166()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            object p0 = new object();
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_3167()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_3168()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.GetHashCode();
        }

        [Test]
        public void GetField_Test_3169()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.GetField();
        }

        [Test]
        public void SetBeginIndex_Test_3170()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            int p0 = 42;
            instance.SetBeginIndex(p0);
        }

        [Test]
        public void SetEndIndex_Test_3171()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            int p0 = 42;
            instance.SetEndIndex(p0);
        }

        [Test]
        public void GetFieldAttribute_Test_3172()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.GetFieldAttribute();
        }

        [Test]
        public void GetBeginIndex_Test_3173()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.GetBeginIndex();
        }

        [Test]
        public void GetEndIndex_Test_3174()
        {
            Format.Field c0 = new Format.Field("testField");
            FieldPosition instance = new FieldPosition(c0);
            instance.GetEndIndex();
        }
    }
}
```