```csharp
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class DataTruncationAutoTest
    {
        [Test]
        public void GetParameter_Test_2939()
        {
            DataTruncation instance = new DataTruncation(0, false, false, 0, 0);
            instance.GetParameter();
        }

        [Test]
        public void GetIndex_Test_2940()
        {
            DataTruncation instance = new DataTruncation(0, false, false, 0, 0);
            instance.GetIndex();
        }

        [Test]
        public void GetRead_Test_2941()
        {
            DataTruncation instance = new DataTruncation(0, false, false, 0, 0);
            instance.GetRead();
        }

        [Test]
        public void GetDataSize_Test_2942()
        {
            DataTruncation instance = new DataTruncation(0, false, false, 0, 0);
            instance.GetDataSize();
        }

        [Test]
        public void GetTransferSize_Test_2943()
        {
            DataTruncation instance = new DataTruncation(0, false, false, 0, 0);
            instance.GetTransferSize();
        }
    }

    public class DataTruncation
    {
        private int index;
        private bool parameter;
        private bool read;
        private int dataSize;
        private int transferSize;

        public DataTruncation(int index, bool parameter, bool read, int dataSize, int transferSize)
        {
            this.index = index;
            this.parameter = parameter;
            this.read = read;
            this.dataSize = dataSize;
            this.transferSize = transferSize;
        }

        public int GetIndex() { return index; }
        public bool GetParameter() { return parameter; }
        public bool GetRead() { return read; }
        public int GetDataSize() { return dataSize; }
        public int GetTransferSize() { return transferSize; }
    }
}
```