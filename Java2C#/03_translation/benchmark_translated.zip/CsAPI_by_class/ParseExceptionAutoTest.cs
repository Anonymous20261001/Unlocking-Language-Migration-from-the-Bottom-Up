```csharp
using System;
using NUnit.Framework;

// Equivalent of Java's java.text.ParseException
public class ParseException : Exception
{
    private int errorOffset;

    public ParseException(string message, int errorOffset) : base(message)
    {
        this.errorOffset = errorOffset;
    }

    public int GetErrorOffset()
    {
        return errorOffset;
    }
}

// Test class corresponding to Java's ParseExceptionAutoTest
[TestFixture]
public class ParseExceptionAutoTest
{
    // Translated test method: getErrorOffset_test_3195 -> GetErrorOffset_Test_3195
    // Using NUnit's TestCase for parameterized test (example data provided)
    [TestCase("test", 0)]
    public void GetErrorOffset_Test_3195(string c0, int c1)
    {
        ParseException instance = new ParseException(c0, c1);
        instance.GetErrorOffset();
    }
}
```