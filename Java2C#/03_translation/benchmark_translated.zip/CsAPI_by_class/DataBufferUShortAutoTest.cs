```csharp
using System;
using NUnit.Framework;

namespace generated.test
{
    // C# implementation of java.awt.image.DataBufferUShort
    public class DataBufferUShort
    {
        private short[][] bankData;
        private int numBanks;
        private int size;

        // Constructor: creates one bank with specified size
        public DataBufferUShort(int size)
        {
            this.size = size;
            this.numBanks = 1;
            bankData = new short[1][];
            bankData[0] = new short[size];
        }

        // Returns the entire bank data array (array of short arrays)
        public short[][] GetBankData()
        {
            return bankData;
        }

        // Returns the data array of the first bank
        public short[] GetData()
        {
            return bankData[0];
        }

        // Returns the data array of a specific bank
        public short[] GetData(int bank)
        {
            return bankData[bank];
        }

        // Gets element at index from first bank, returned as int (same as Java)
        public int GetElem(int i)
        {
            return bankData[0][i];
        }

        // Gets element at index from specified bank, returned as int
        public int GetElem(int bank, int i)
        {
            return bankData[bank][i];
        }

        // Sets element at index in first bank (value is truncated to short)
        public void SetElem(int i, int val)
        {
            bankData[0][i] = (short)val;
        }

        // Sets element at index in specified bank (value truncated to short)
        public void SetElem(int bank, int i, int val)
        {
            bankData[bank][i] = (short)val;
        }
    }

    [TestFixture]
    public class DataBufferUShortAutoTest
    {
        [Test]
        public void GetBankData_test_1234(int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.GetBankData();
        }

        [Test]
        public void GetElem_test_1235(int p0, int p1, int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.GetElem(p0, p1);
        }

        [Test]
        public void GetElem_test_1236(int p0, int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.GetElem(p0);
        }

        [Test]
        public void SetElem_test_1237(int p0, int p1, int p2, int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.SetElem(p0, p1, p2);
        }

        [Test]
        public void SetElem_test_1238(int p0, int p1, int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.SetElem(p0, p1);
        }

        [Test]
        public void GetData_test_1239(int p0, int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.GetData(p0);
        }

        [Test]
        public void GetData_test_1240(int c0)
        {
            DataBufferUShort instance = new DataBufferUShort(c0);
            instance.GetData();
        }
    }
}
```