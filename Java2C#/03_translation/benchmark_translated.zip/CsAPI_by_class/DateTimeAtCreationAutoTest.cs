```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class DateTimeAtCreation
    {
        private DateTime dateTime;

        public DateTimeAtCreation(DateTime dateTime)
        {
            this.dateTime = dateTime;
        }

        public Type GetCategory()
        {
            return typeof(DateTimeAtCreation);
        }

        public string GetName()
        {
            return "datetime-at-creation";
        }

        public override bool Equals(object obj)
        {
            if (obj is DateTimeAtCreation other)
            {
                return this.dateTime.Equals(other.dateTime);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return dateTime.GetHashCode();
        }
    }

    [TestFixture]
    public class DateTimeAtCreationAutoTest
    {
        [Test]
        public void GetCategory_Test_6106()
        {
            DateTime c0 = DateTime.Now;
            DateTimeAtCreation instance = new DateTimeAtCreation(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6107()
        {
            DateTime c0 = DateTime.Now;
            DateTimeAtCreation instance = new DateTimeAtCreation(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6108()
        {
            object p0 = new object();
            DateTime c0 = DateTime.Now;
            DateTimeAtCreation instance = new DateTimeAtCreation(c0);
            instance.Equals(p0);
        }
    }
}
```