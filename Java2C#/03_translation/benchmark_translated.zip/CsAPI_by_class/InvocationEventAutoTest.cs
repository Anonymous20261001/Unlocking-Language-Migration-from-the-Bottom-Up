```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class InvocationEventAutoTest
    {
        [Test]
        public void GetWhen_Test_772()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.GetWhen();
        }

        [Test]
        public void IsDispatched_Test_773()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.IsDispatched();
        }

        [Test]
        public void GetThrowable_Test_774()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.GetThrowable();
        }

        [Test]
        public void Dispatch_Test_775()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.Dispatch();
        }

        [Test]
        public void GetException_Test_776()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.GetException();
        }

        [Test]
        public void ParamString_Test_777()
        {
            var c0 = new object();
            var c1 = new Action(() => { });
            var instance = new InvocationEvent(c0, c1);
            instance.ParamString();
        }
    }

    /// <summary>
    /// C# equivalent of java.awt.event.InvocationEvent.
    /// Mimics the behaviour of the Java version.
    /// </summary>
    public class InvocationEvent
    {
        private readonly object source;
        private readonly Action runnable;
        private readonly long when;
        private bool dispatched;
        private Exception thrownException; // stores any exception thrown by runnable

        public InvocationEvent(object source, Action runnable)
        {
            this.source = source ?? throw new ArgumentNullException(nameof(source));
            this.runnable = runnable ?? throw new ArgumentNullException(nameof(runnable));
            this.when = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            this.dispatched = false;
            this.thrownException = null;
        }

        /// <summary>
        /// Returns the timestamp of this event (in milliseconds).
        /// </summary>
        public long GetWhen()
        {
            return when;
        }

        /// <summary>
        /// Returns true if the event has been dispatched.
        /// </summary>
        public bool IsDispatched()
        {
            return dispatched;
        }

        /// <summary>
        /// Returns any Throwable that was thrown when the runnable was executed.
        /// </summary>
        public Exception GetThrowable()
        {
            return thrownException;
        }

        /// <summary>
        /// Dispatches the runnable. Sets the dispatched flag and catches exceptions.
        /// </summary>
        public void Dispatch()
        {
            if (dispatched)
                throw new InvalidOperationException("Event already dispatched");

            dispatched = true;
            try
            {
                runnable.Invoke();
            }
            catch (Exception ex)
            {
                thrownException = ex;
            }
        }

        /// <summary>
        /// Returns the exception if it is an Exception, otherwise null (analogous to Java's getException()).
        /// </summary>
        public Exception GetException()
        {
            // In Java, getException() returns the Throwable if it is an Exception, else null.
            // Here thrownException is already an Exception (or null).
            return thrownException;
        }

        /// <summary>
        /// Returns a string representation of this event.
        /// </summary>
        public string ParamString()
        {
            // Simplified: includes class name, source, dispatched flag, and throwable info.
            return $"InvocationEvent[source={source}, dispatched={dispatched}, throwable={thrownException?.GetType().Name ?? "null"}]";
        }
    }
}
```