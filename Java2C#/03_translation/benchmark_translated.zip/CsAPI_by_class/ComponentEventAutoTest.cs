```csharp
using NUnit.Framework;

namespace GeneratedTest
{
    public class ComponentEventAutoTest
    {
        [Test]
        public void paramString_test_750()
        {
            Component c0 = new Component();
            int c1 = 0;
            ComponentEvent instance = new ComponentEvent(c0, c1);
            instance.paramString();
        }

        [Test]
        public void getComponent_test_751()
        {
            Component c0 = new Component();
            int c1 = 0;
            ComponentEvent instance = new ComponentEvent(c0, c1);
            instance.getComponent();
        }
    }

    public class Component
    {
        // Minimal implementation – can be extended as needed.
    }

    public class ComponentEvent
    {
        private Component source;
        private int id;

        public ComponentEvent(Component source, int id)
        {
            this.source = source;
            this.id = id;
        }

        public string paramString()
        {
            // Mimics Java's ComponentEvent.paramString() behavior.
            return $"ComponentEvent id={id}";
        }

        public Component getComponent()
        {
            return source;
        }
    }
}
```