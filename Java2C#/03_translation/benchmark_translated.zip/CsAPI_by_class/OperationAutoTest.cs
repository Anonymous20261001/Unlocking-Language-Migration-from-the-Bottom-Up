```csharp
using NUnit.Framework;

namespace generated.test
{
    // Equivalent of java.rmi.server.Operation
    public class Operation
    {
        private readonly string operationName;

        public Operation(string name)
        {
            operationName = name;
        }

        public string GetOperation()
        {
            return operationName;
        }

        public override string ToString()
        {
            return operationName;
        }
    }

    [TestFixture]
    public class OperationAutoTest
    {
        [TestCase("testValue")]
        public void GetOperation_test_2668(string c0)
        {
            var instance = new Operation(c0);
            instance.GetOperation();
        }

        [TestCase("testValue")]
        public void ToString_test_2669(string c0)
        {
            var instance = new Operation(c0);
            instance.ToString();
        }
    }
}
```