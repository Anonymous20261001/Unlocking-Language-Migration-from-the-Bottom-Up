```csharp
using NUnit.Framework;
using System;

namespace generated.test
{
    public class Insets : ICloneable
    {
        public int top;
        public int left;
        public int bottom;
        public int right;

        public Insets(int top, int left, int bottom, int right)
        {
            this.top = top;
            this.left = left;
            this.bottom = bottom;
            this.right = right;
        }

        public void Set(int top, int left, int bottom, int right)
        {
            this.top = top;
            this.left = left;
            this.bottom = bottom;
            this.right = right;
        }

        public object Clone()
        {
            return new Insets(top, left, bottom, right);
        }

        public override bool Equals(object obj)
        {
            if (obj is Insets other)
            {
                return top == other.top &&
                       left == other.left &&
                       bottom == other.bottom &&
                       right == other.right;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return top + left + bottom + right;
        }

        public override string ToString()
        {
            return $"{GetType().Name}[top={top},left={left},bottom={bottom},right={right}]";
        }
    }

    [TestFixture]
    public class InsetsAutoTest
    {
        [Test]
        public void Equals_Test_352()
        {
            Insets instance = new Insets(0, 0, 0, 0);
            instance.Equals(null);
        }

        [Test]
        public void ToString_Test_353()
        {
            Insets instance = new Insets(0, 0, 0, 0);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_354()
        {
            Insets instance = new Insets(0, 0, 0, 0);
            instance.GetHashCode();
        }

        [Test]
        public void Clone_Test_355()
        {
            Insets instance = new Insets(0, 0, 0, 0);
            instance.Clone();
        }

        [Test]
        public void Set_Test_356()
        {
            Insets instance = new Insets(0, 0, 0, 0);
            instance.Set(0, 0, 0, 0);
        }
    }
}
```