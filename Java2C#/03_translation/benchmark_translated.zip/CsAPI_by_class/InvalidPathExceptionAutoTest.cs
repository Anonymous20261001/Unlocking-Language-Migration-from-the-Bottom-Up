```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.nio.file.InvalidPathException
    public class InvalidPathException : Exception
    {
        private readonly string input;
        private readonly string reason;
        private readonly int index;

        public InvalidPathException(string input, string reason)
            : this(input, reason, -1)
        {
        }

        public InvalidPathException(string input, string reason, int index)
        {
            this.input = input;
            this.reason = reason;
            this.index = index;
        }

        public string GetMessage()
        {
            if (index >= 0)
                return $"{input}: {reason} at index {index}";
            else
                return $"{input}: {reason}";
        }

        public int GetIndex()
        {
            return index;
        }

        public string GetReason()
        {
            return reason;
        }

        public string GetInput()
        {
            return input;
        }
    }

    public class InvalidPathExceptionAutoTest
    {
        [Test]
        public void GetMessage_Test_2652()
        {
            string c0 = "testInput";
            string c1 = "testReason";
            InvalidPathException instance = new InvalidPathException(c0, c1);
            instance.GetMessage();
        }

        [Test]
        public void GetIndex_Test_2653()
        {
            string c0 = "testInput";
            string c1 = "testReason";
            InvalidPathException instance = new InvalidPathException(c0, c1);
            instance.GetIndex();
        }

        [Test]
        public void GetReason_Test_2654()
        {
            string c0 = "testInput";
            string c1 = "testReason";
            InvalidPathException instance = new InvalidPathException(c0, c1);
            instance.GetReason();
        }

        [Test]
        public void GetInput_Test_2655()
        {
            string c0 = "testInput";
            string c1 = "testReason";
            InvalidPathException instance = new InvalidPathException(c0, c1);
            instance.GetInput();
        }
    }
}
```