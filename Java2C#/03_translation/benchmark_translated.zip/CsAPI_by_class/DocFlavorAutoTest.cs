```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace generated.test
{
    // C# translation of Java's javax.print.DocFlavor
    public sealed class DocFlavor
    {
        private readonly string _mimeType;
        private readonly string _representationClassName;
        private readonly string _mediaType;
        private readonly string _mediaSubtype;
        private readonly Dictionary<string, string> _parameters;

        public DocFlavor(string mimeType, string representationClassName)
        {
            if (string.IsNullOrEmpty(mimeType))
                throw new ArgumentException("MIME type cannot be null or empty", nameof(mimeType));
            if (string.IsNullOrEmpty(representationClassName))
                throw new ArgumentException("Representation class name cannot be null or empty", nameof(representationClassName));

            _mimeType = mimeType;
            _representationClassName = representationClassName;

            // Parse MIME type into media type, media subtype, and parameters
            int slashIndex = mimeType.IndexOf('/');
            if (slashIndex < 0)
                throw new ArgumentException("Invalid MIME type: missing '/'", nameof(mimeType));
            _mediaType = mimeType.Substring(0, slashIndex).Trim().ToLowerInvariant();

            int semiColonIndex = mimeType.IndexOf(';', slashIndex);
            if (semiColonIndex < 0)
            {
                _mediaSubtype = mimeType.Substring(slashIndex + 1).Trim().ToLowerInvariant();
                _parameters = new Dictionary<string, string>();
            }
            else
            {
                _mediaSubtype = mimeType.Substring(slashIndex + 1, semiColonIndex - slashIndex - 1).Trim().ToLowerInvariant();
                _parameters = ParseParameters(mimeType.Substring(semiColonIndex + 1));
            }
        }

        private static Dictionary<string, string> ParseParameters(string paramString)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string[] pairs = paramString.Split(';');
            foreach (string pair in pairs)
            {
                int eq = pair.IndexOf('=');
                if (eq > 0)
                {
                    string key = pair.Substring(0, eq).Trim();
                    string value = pair.Substring(eq + 1).Trim();
                    if (value.StartsWith("\"") && value.EndsWith("\""))
                        value = value.Substring(1, value.Length - 2);
                    dict[key] = value;
                }
            }
            return dict;
        }

        public string GetMediaType()
        {
            return _mediaType;
        }

        public string GetMediaSubtype()
        {
            return _mediaSubtype;
        }

        public string GetRepresentationClassName()
        {
            return _representationClassName;
        }

        public string GetParameter(string name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));
            _parameters.TryGetValue(name, out string value);
            return value;
        }

        public string GetMimeType()
        {
            return _mimeType;
        }

        public override bool Equals(object obj)
        {
            if (obj is DocFlavor other)
            {
                return string.Equals(_mimeType, other._mimeType, StringComparison.Ordinal) &&
                       string.Equals(_representationClassName, other._representationClassName, StringComparison.Ordinal);
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (_mimeType?.GetHashCode() ?? 0);
            hash = hash * 31 + (_representationClassName?.GetHashCode() ?? 0);
            return hash;
        }

        public override string ToString()
        {
            return _mimeType;
        }
    }

    [TestFixture]
    public class DocFlavorAutoTest
    {
        [Test]
        public void getMediaType_test_6074(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetMediaType();
        }

        [Test]
        public void getMediaSubtype_test_6075(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetMediaSubtype();
        }

        [Test]
        public void getRepresentationClassName_test_6076(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetRepresentationClassName();
        }

        [Test]
        public void getParameter_test_6077(string p0, string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetParameter(p0);
        }

        [Test]
        public void getMimeType_test_6078(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetMimeType();
        }

        [Test]
        public void equals_test_6079(object p0, string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.Equals(p0);
        }

        [Test]
        public void toString_test_6080(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.ToString();
        }

        [Test]
        public void hashCode_test_6081(string c0, string c1)
        {
            DocFlavor instance = new DocFlavor(c0, c1);
            instance.GetHashCode();
        }
    }
}
```