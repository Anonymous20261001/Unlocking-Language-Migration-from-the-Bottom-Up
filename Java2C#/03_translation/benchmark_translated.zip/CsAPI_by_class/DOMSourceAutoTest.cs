```csharp
using System;
using System.Xml;
using NUnit.Framework;

namespace generated.test
{
    // C# equivalent of javax.xml.transform.dom.DOMSource
    public class DOMSource
    {
        private string systemId;
        private XmlNode node;

        public string GetSystemId() => systemId;
        public void SetSystemId(string id) => systemId = id;
        public bool IsEmpty() => node == null;
        public XmlNode GetNode() => node;
        public void SetNode(XmlNode n) => node = n;
    }

    [TestFixture]
    public class DOMSourceAutoTest
    {
        [Test]
        public void GetSystemId_test_10978()
        {
            DOMSource instance = new DOMSource();
            instance.GetSystemId();
        }

        [TestCase("")]
        public void SetSystemId_test_10979(string p0)
        {
            DOMSource instance = new DOMSource();
            instance.SetSystemId(p0);
        }

        [Test]
        public void IsEmpty_test_10980()
        {
            DOMSource instance = new DOMSource();
            instance.IsEmpty();
        }

        [Test]
        public void GetNode_test_10981()
        {
            DOMSource instance = new DOMSource();
            instance.GetNode();
        }

        [TestCase(null)]
        public void SetNode_test_10982(XmlNode p0)
        {
            DOMSource instance = new DOMSource();
            instance.SetNode(p0);
        }
    }
}
```