```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // Non‑generic HashSet that mimics Java's java.util.HashSet (raw type)
    public class HashSet : ICollection
    {
        private readonly HashSet<object> _set;

        public HashSet()
        {
            _set = new HashSet<object>();
        }

        public HashSet(int initialCapacity)
        {
            // approximate capacity: .NET HashSet uses load factor; just create with default
            _set = new HashSet<object>();
        }

        // Copy constructor used by Clone()
        private HashSet(HashSet<object> source)
        {
            _set = new HashSet<object>(source);
        }

        // ---------- API methods ----------

        public bool Remove(object o)
        {
            return _set.Remove(o);
        }

        public int Size()
        {
            return _set.Count;
        }

        public object Clone()
        {
            return new HashSet(_set);
        }

        public void Clear()
        {
            _set.Clear();
        }

        public bool IsEmpty()
        {
            return _set.Count == 0;
        }

        public bool Add(object o)
        {
            return _set.Add(o);
        }

        public object[] ToArray()
        {
            return _set.ToArray();
        }

        // Java's toArray(T[] a) returns an array of the runtime type of a,
        // filled with elements up to the size of the set; if a is too small a new array is created.
        public object[] ToArray(object[] array)
        {
            int size = _set.Count;
            if (array.Length < size)
                array = new object[size];
            _set.CopyTo(array);
            // If array is larger, remaining elements are set to null (Java behavior)
            for (int i = size; i < array.Length; i++)
                array[i] = null;
            return array;
        }

        public IEnumerator<object> Iterator()
        {
            return _set.GetEnumerator();
        }

        public bool Contains(object o)
        {
            return _set.Contains(o);
        }

        public Spliterator Spliterator()
        {
            return new Spliterator(_set);
        }

        public static HashSet NewHashSet(int initialCapacity)
        {
            return new HashSet(initialCapacity);
        }

        // ICollection implementation (required by some .NET interop, but optional here)
        public void CopyTo(Array array, int index)
        {
            (_set as ICollection).CopyTo(array, index);
        }

        public int Count => _set.Count;
        public bool IsSynchronized => false;
        public object SyncRoot => this;
        public IEnumerator GetEnumerator() => _set.GetEnumerator();
    }

    // Minimal Spliterator implementation mimicking Java's Spliterator<Object>
    public class Spliterator
    {
        private readonly HashSet<object> _set;
        private IEnumerator<object> _enumerator;
        private bool _started;
        private long _remaining;

        public Spliterator(HashSet<object> set)
        {
            _set = set;
            _remaining = set.Count;
            _enumerator = set.GetEnumerator();
            _started = false;
        }

        public bool TryAdvance(out object element)
        {
            if (!_started)
            {
                _started = true;
                _enumerator.Reset();
            }
            if (_enumerator.MoveNext())
            {
                element = _enumerator.Current;
                _remaining--;
                return true;
            }
            element = null;
            return false;
        }

        public Spliterator TrySplit()
        {
            // Simple split: not fully implemented – returns null (no split)
            return null;
        }

        public long EstimateSize()
        {
            return _remaining;
        }

        public int Characteristics()
        {
            // characteristics: SIZED (0x00000040) | SUBSIZED (0x00040000) | DISTINCT (0x00000001)
            return 0x00040041;
        }
    }

    // Auto‑generated test class (translation of HashSetAutoTest)
    [TestFixture]
    public class HashSetAutoTest
    {
        [Test]
        public void Remove_test_3503([Values(null, "test", 42)] object p0)
        {
            var instance = new HashSet();
            instance.Remove(p0);
        }

        [Test]
        public void Size_test_3504()
        {
            var instance = new HashSet();
            instance.Size();
        }

        [Test]
        public void Clone_test_3505()
        {
            var instance = new HashSet();
            instance.Clone();
        }

        [Test]
        public void Clear_test_3506()
        {
            var instance = new HashSet();
            instance.Clear();
        }

        [Test]
        public void IsEmpty_test_3507()
        {
            var instance = new HashSet();
            instance.IsEmpty();
        }

        [Test]
        public void Add_test_3508([Values(null, "test", 42)] object p0)
        {
            var instance = new HashSet();
            instance.Add(p0);
        }

        [Test]
        public void ToArray_test_3509([Values(new object[] { null }, new object[] { "a", "b" })] object[] p0)
        {
            var instance = new HashSet();
            instance.ToArray(p0);
        }

        [Test]
        public void ToArray_test_3510()
        {
            var instance = new HashSet();
            instance.ToArray();
        }

        [Test]
        public void Iterator_test_3511()
        {
            var instance = new HashSet();
            instance.Iterator();
        }

        [Test]
        public void Contains_test_3512([Values(null, "test", 42)] object p0)
        {
            var instance = new HashSet();
            instance.Contains(p0);
        }

        [Test]
        public void Spliterator_test_3513()
        {
            var instance = new HashSet();
            instance.Spliterator();
        }

        [Test]
        public void NewHashSet_test_3514([Values(0, 10, 100)] int p0)
        {
            var instance = new HashSet();
            HashSet.NewHashSet(p0);
        }
    }
}
```