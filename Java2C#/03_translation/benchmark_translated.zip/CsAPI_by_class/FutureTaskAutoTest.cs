```csharp
using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // Simple implementation of a FutureTask similar to Java's FutureTask
    public class FutureTask<T>
    {
        // State constants matching Java's FutureTask internal states
        public const int NEW = 0;
        public const int COMPLETING = 1;
        public const int NORMAL = 2;
        public const int EXCEPTIONAL = 3;
        public const int CANCELLED = 4;
        public const int INTERRUPTING = 5;
        public const int INTERRUPTED = 6;

        private readonly Func<T> _callable;
        private int _state = NEW;
        private T _result;
        private Exception _exception;
        private readonly object _lock = new object();

        public FutureTask(Func<T> callable)
        {
            _callable = callable ?? throw new ArgumentNullException(nameof(callable));
        }

        public void Run()
        {
            lock (_lock)
            {
                if (_state != NEW) return;
                _state = COMPLETING;
            }

            try
            {
                T result = _callable();
                lock (_lock)
                {
                    _result = result;
                    _state = NORMAL;
                }
            }
            catch (Exception ex)
            {
                lock (_lock)
                {
                    _exception = ex;
                    _state = EXCEPTIONAL;
                }
            }
        }

        public override string ToString()
        {
            return $"FutureTask state={_state}";
        }

        public int State()
        {
            return _state;
        }

        public bool IsDone()
        {
            return _state >= NORMAL; // NORMAL, EXCEPTIONAL, CANCELLED, INTERRUPTED
        }

        public bool Cancel(bool mayInterruptIfRunning)
        {
            lock (_lock)
            {
                if (_state != NEW)
                {
                    // If already completed or cancelled, cannot cancel
                    return false;
                }

                if (mayInterruptIfRunning)
                {
                    _state = INTERRUPTING;
                    // In a real implementation we would interrupt the thread, but for simplicity
                    // we go directly to INTERRUPTED
                    _state = INTERRUPTED;
                }
                else
                {
                    _state = CANCELLED;
                }

                return true;
            }
        }

        public bool IsCancelled()
        {
            return _state == CANCELLED || _state == INTERRUPTING || _state == INTERRUPTED;
        }

        public T ResultNow()
        {
            lock (_lock)
            {
                if (_state != NORMAL)
                    throw new InvalidOperationException("Task not completed successfully");
                return _result;
            }
        }

        public Exception ExceptionNow()
        {
            lock (_lock)
            {
                if (_state != EXCEPTIONAL)
                    throw new InvalidOperationException("Task did not complete exceptionally");
                return _exception;
            }
        }
    }

    // Test class mirroring the Java test
    [TestFixture]
    public class FutureTaskAutoTest
    {
        [Test]
        public void Run_Test_4507(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.Run();
        }

        [Test]
        public void ToString_Test_4508(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.ToString();
        }

        [Test]
        public void State_Test_4509(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.State();
        }

        [Test]
        public void IsDone_Test_4510(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.IsDone();
        }

        [Test]
        public void Cancel_Test_4511(bool p0, Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.Cancel(p0);
        }

        [Test]
        public void IsCancelled_Test_4512(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.IsCancelled();
        }

        [Test]
        public void ResultNow_Test_4513(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.ResultNow();
        }

        [Test]
        public void ExceptionNow_Test_4514(Func<object> c0)
        {
            var instance = new FutureTask<object>(c0);
            instance.ExceptionNow();
        }
    }
}
```