```csharp
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;

// ===================== Required Interfaces and Implementations =====================

/// <summary>
/// Equivalent to java.util.concurrent.Executor.
/// </summary>
public interface IExecutor
{
    void Execute(Action task);
}

/// <summary>
/// Simple synchronous executor for testing.
/// </summary>
public class InlineExecutor : IExecutor
{
    public void Execute(Action task)
    {
        task?.Invoke();
    }
}

/// <summary>
/// Equivalent to java.util.concurrent.Callable<object> (raw type).
/// </summary>
public interface ICallable
{
    object Call();
}

/// <summary>
/// Simple callable that returns a fixed object.
/// </summary>
public class SimpleCallable : ICallable
{
    private readonly object _result;

    public SimpleCallable(object result = null)
    {
        _result = result ?? new object();
    }

    public object Call()
    {
        return _result;
    }
}

/// <summary>
/// Equivalent to java.util.concurrent.ExecutorCompletionService (raw type).
/// Wraps an IExecutor and provides CompletionService‑like functionality.
/// </summary>
public class ExecutorCompletionService
{
    private readonly IExecutor _executor;
    private readonly Queue<Task<object>> _completedTasks = new Queue<Task<object>>();

    public ExecutorCompletionService(IExecutor executor)
    {
        _executor = executor ?? throw new ArgumentNullException(nameof(executor));
    }

    /// <summary>
    /// Submits a Callable task and returns a Task representing the result.
    /// </summary>
    public Task<object> Submit(ICallable callable)
    {
        if (callable == null) throw new ArgumentNullException(nameof(callable));

        var tcs = new TaskCompletionSource<object>();
        _executor.Execute(() =>
        {
            try
            {
                var result = callable.Call();
                tcs.SetResult(result);
                lock (_completedTasks)
                {
                    _completedTasks.Enqueue(tcs.Task);
                }
            }
            catch (Exception ex)
            {
                tcs.SetException(ex);
            }
        });
        return tcs.Task;
    }

    /// <summary>
    /// Submits a Runnable (Action) and returns a Task that yields the given result upon completion.
    /// </summary>
    public Task<object> Submit(Action runnable, object result)
    {
        if (runnable == null) throw new ArgumentNullException(nameof(runnable));

        var tcs = new TaskCompletionSource<object>();
        _executor.Execute(() =>
        {
            try
            {
                runnable();
                tcs.SetResult(result);
                lock (_completedTasks)
                {
                    _completedTasks.Enqueue(tcs.Task);
                }
            }
            catch (Exception ex)
            {
                tcs.SetException(ex);
            }
        });
        return tcs.Task;
    }

    /// <summary>
    /// Non‑blocking poll. Returns a completed Task if available, or null.
    /// Equivalent to Java's poll() returning a Future (or null).
    /// </summary>
    public Task<object> Poll()
    {
        lock (_completedTasks)
        {
            if (_completedTasks.Count > 0)
                return _completedTasks.Dequeue();
            return null;
        }
    }
}

// ===================== Unit Tests =====================

[TestFixture]
public class ExecutorCompletionServiceAutoTest
{
    [Test]
    public void Poll_Test_4464()
    {
        var executor = new InlineExecutor();
        var instance = new ExecutorCompletionService(executor);
        instance.Poll();
    }

    [Test]
    public void Submit_Test_4465()
    {
        var callable = new SimpleCallable("test result");
        var executor = new InlineExecutor();
        var instance = new ExecutorCompletionService(executor);
        instance.Submit(callable);
    }

    [Test]
    public void Submit_Test_4466()
    {
        var runnable = () => { /* no‑op */ };
        object result = new object();
        var executor = new InlineExecutor();
        var instance = new ExecutorCompletionService(executor);
        instance.Submit(runnable, result);
    }
}
```