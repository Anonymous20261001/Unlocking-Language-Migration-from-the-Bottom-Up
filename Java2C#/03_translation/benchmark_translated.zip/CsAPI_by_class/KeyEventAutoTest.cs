```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    // Minimal Component class to satisfy KeyEvent constructor
    public class Component
    {
        // No special behavior needed for these tests
    }

    // C# equivalent of Java KeyEvent
    public class KeyEvent
    {
        // Key event types (from Java AWT)
        public const int KEY_FIRST = 400;
        public const int KEY_LAST = 402;
        public const int KEY_TYPED = KEY_FIRST;
        public const int KEY_PRESSED = 401;
        public const int KEY_RELEASED = 402;

        // Modifier constants (bitwise flags)
        public const int SHIFT_MASK = 1;
        public const int CTRL_MASK = 2;
        public const int META_MASK = 4;
        public const int ALT_MASK = 8;

        // Virtual key codes (partial set)
        public const int VK_ENTER = '\n';
        public const int VK_BACK_SPACE = '\b';
        public const int VK_TAB = '\t';
        public const int VK_CANCEL = 3;
        public const int VK_CLEAR = 12;
        public const int VK_SHIFT = 16;
        public const int VK_CONTROL = 17;
        public const int VK_ALT = 18;
        public const int VK_PAUSE = 19;
        public const int VK_CAPS_LOCK = 20;
        public const int VK_ESCAPE = 27;
        public const int VK_SPACE = ' ';
        public const int VK_PAGE_UP = 33;
        public const int VK_PAGE_DOWN = 34;
        public const int VK_END = 35;
        public const int VK_HOME = 36;
        public const int VK_LEFT = 37;
        public const int VK_UP = 38;
        public const int VK_RIGHT = 39;
        public const int VK_DOWN = 40;
        // ... add more as needed, but not all required for tests

        // Fields
        protected Component source;
        protected int id;
        protected long when;
        protected int modifiers;
        protected int keyCode;
        protected char keyChar;
        protected int keyLocation; // For simplicity, defaults to 0

        // Constructor matching Java: KeyEvent(Component source, int id, long when, int modifiers, int keyCode)
        public KeyEvent(Component source, int id, long when, int modifiers, int keyCode)
        {
            this.source = source;
            this.id = id;
            this.when = when;
            this.modifiers = modifiers;
            this.keyCode = keyCode;
            this.keyChar = (keyCode >= 0 && keyCode <= 0xFFFF) ? (char)keyCode : (char)0;
            this.keyLocation = 0;
        }

        // Set key code
        public void SetKeyCode(int keyCode)
        {
            this.keyCode = keyCode;
            // Update keyChar if appropriate (Java does not update automatically)
        }

        // Get key location (simplified – always 0)
        public int GetKeyLocation()
        {
            return keyLocation;
        }

        // Static method: getKeyModifiersText
        public static string GetKeyModifiersText(int modifiers)
        {
            StringBuilder sb = new StringBuilder();
            if ((modifiers & SHIFT_MASK) != 0) sb.Append("Shift ");
            if ((modifiers & CTRL_MASK) != 0) sb.Append("Ctrl ");
            if ((modifiers & META_MASK) != 0) sb.Append("Meta ");
            if ((modifiers & ALT_MASK) != 0) sb.Append("Alt ");
            if (sb.Length > 0)
                sb.Length--; // remove trailing space
            return sb.ToString();
        }

        // Static method: getExtendedKeyCodeForChar (simplified return char code)
        public static int GetExtendedKeyCodeForChar(int c)
        {
            // In Java, this returns the extended key code for a Unicode char.
            // Simple implementation: return the char itself as an int.
            return c;
        }

        // Set key char
        public void SetKeyChar(char keyChar)
        {
            this.keyChar = keyChar;
        }

        // Get key char
        public char GetKeyChar()
        {
            return keyChar;
        }

        // Get key code
        public int GetKeyCode()
        {
            return keyCode;
        }

        // Get extended key code (Java: returns keyCode if >= 0, else 0)
        public int GetExtendedKeyCode()
        {
            return keyCode >= 0 ? keyCode : 0;
        }

        // Is action key? (simplified: false except for some keys)
        public bool IsActionKey()
        {
            // This is a simplification; real implementation checks specific VK_ constants.
            return (keyCode >= VK_HOME && keyCode <= VK_DOWN) ||
                   keyCode == VK_PAGE_UP ||
                   keyCode == VK_PAGE_DOWN ||
                   keyCode == VK_PAUSE ||
                   keyCode == VK_CAPS_LOCK ||
                   keyCode == VK_ESCAPE ||
                   keyCode == VK_END;
        }

        // Static method: getKeyText
        public static string GetKeyText(int keyCode)
        {
            // Very simplified; real implementation uses VK_ mapping.
            if (keyCode >= 0x20 && keyCode <= 0x7E)
                return ((char)keyCode).ToString();
            if (keyCode == VK_ENTER) return "Enter";
            if (keyCode == VK_BACK_SPACE) return "Backspace";
            if (keyCode == VK_TAB) return "Tab";
            if (keyCode == VK_SHIFT) return "Shift";
            if (keyCode == VK_CONTROL) return "Ctrl";
            if (keyCode == VK_ALT) return "Alt";
            if (keyCode == VK_ESCAPE) return "Escape";
            if (keyCode == VK_SPACE) return "Space";
            if (keyCode >= VK_PAGE_UP && keyCode <= VK_DOWN)
            {
                string[] names = { "Page Up", "Page Down", "End", "Home", "Left", "Up", "Right", "Down" };
                return names[keyCode - VK_PAGE_UP];
            }
            return "Unknown keyCode: 0x" + keyCode.ToString("X");
        }

        // paramString
        public string ParamString()
        {
            // Java: returns something like "KEY_PRESSED,keyCode=...,keyChar=...,modifiers=..."
            string typeString = (id == KEY_PRESSED) ? "KEY_PRESSED" :
                                (id == KEY_RELEASED) ? "KEY_RELEASED" :
                                (id == KEY_TYPED) ? "KEY_TYPED" : "unknown";
            return $"{typeString},keyCode={keyCode},keyChar={keyChar},modifiers={modifiers}";
        }

        // Set modifiers
        public void SetModifiers(int modifiers)
        {
            this.modifiers = modifiers;
        }

        // Override ToString (optional)
        public override string ToString()
        {
            return GetType().Name + "[" + ParamString() + "]";
        }
    }

    // Test class
    [TestFixture]
    public class KeyEventAutoTest
    {
        [Test]
        public void SetKeyCode_Test_782(
            [Random(1)] int p0,
            [Random(1)] int c0Seed, // We'll generate Component from seed (not needed)
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            // Create dummy components (no real dependency)
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.SetKeyCode(p0);
        }

        [Test]
        public void GetKeyLocation_Test_783(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.GetKeyLocation();
        }

        [Test]
        public void GetKeyModifiersText_Test_784(
            [Random(1)] int p0,
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            KeyEvent.GetKeyModifiersText(p0);
        }

        [Test]
        public void GetExtendedKeyCodeForChar_Test_785(
            [Random(1)] int p0,
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            KeyEvent.GetExtendedKeyCodeForChar(p0);
        }

        [Test]
        public void SetKeyChar_Test_786(
            [Random(1)] char p0,
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.SetKeyChar(p0);
        }

        [Test]
        public void GetKeyChar_Test_787(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.GetKeyChar();
        }

        [Test]
        public void GetKeyCode_Test_788(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.GetKeyCode();
        }

        [Test]
        public void GetExtendedKeyCode_Test_789(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.GetExtendedKeyCode();
        }

        [Test]
        public void IsActionKey_Test_790(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.IsActionKey();
        }

        [Test]
        public void GetKeyText_Test_791(
            [Random(1)] int p0,
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            KeyEvent.GetKeyText(p0);
        }

        [Test]
        public void ParamString_Test_792(
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.ParamString();
        }

        [Test]
        public void SetModifiers_Test_793(
            [Random(1)] int p0,
            [Random(1)] int c0Seed,
            [Random(1)] int c1,
            [Random(1)] long c2,
            [Random(1)] int c3,
            [Random(1)] int c4)
        {
            Component comp = new Component();
            KeyEvent instance = new KeyEvent(comp, c1, c2, c3, c4);
            instance.SetModifiers(p0);
        }
    }
}
```