```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of java.beans.BeanDescriptor.
    /// </summary>
    public class BeanDescriptor
    {
        private readonly Type beanClass;
        private readonly Type customizerClass;

        /// <summary>
        /// Creates a BeanDescriptor for a given bean class.
        /// </summary>
        /// <param name="beanClass">The class of the bean.</param>
        public BeanDescriptor(Type beanClass)
        {
            this.beanClass = beanClass ?? throw new ArgumentNullException(nameof(beanClass));
            this.customizerClass = null;
        }

        /// <summary>
        /// Creates a BeanDescriptor for a given bean class and customizer class.
        /// </summary>
        /// <param name="beanClass">The class of the bean.</param>
        /// <param name="customizerClass">The class of the customizer (can be null).</param>
        public BeanDescriptor(Type beanClass, Type customizerClass)
        {
            this.beanClass = beanClass ?? throw new ArgumentNullException(nameof(beanClass));
            this.customizerClass = customizerClass;
        }

        /// <summary>
        /// Gets the bean class.
        /// </summary>
        /// <returns>The Type of the bean.</returns>
        public Type GetBeanClass() => beanClass;

        /// <summary>
        /// Gets the customizer class.
        /// </summary>
        /// <returns>The Type of the customizer, or null if none was set.</returns>
        public Type GetCustomizerClass() => customizerClass;
    }

    /// <summary>
    /// Test class corresponding to BeanDescriptorAutoTest.
    /// </summary>
    [TestFixture]
    public class BeanDescriptorAutoTest
    {
        [Test]
        public void GetBeanClass_test_1510()
        {
            Type c0 = typeof(object);
            var instance = new BeanDescriptor(c0);
            instance.GetBeanClass();
        }

        [Test]
        public void GetCustomizerClass_test_1511()
        {
            Type c0 = typeof(object);
            var instance = new BeanDescriptor(c0);
            instance.GetCustomizerClass();
        }
    }
}
```