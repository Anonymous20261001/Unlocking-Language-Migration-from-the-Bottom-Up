Below is the complete C# translation of the provided Java test file and its supporting classes. The code uses NUnit for unit testing and replicates the API behavior of `java.awt.dnd.DragSourceContext` and `java.awt.dnd.DragSourceEvent`. The `Point` class from `System.Drawing` is used for the location.

```csharp
using System.Drawing;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of java.awt.dnd.DragSourceContext
    public class DragSourceContext
    {
        // No methods called in the tests; minimal implementation.
    }

    // Equivalent of java.awt.dnd.DragSourceEvent
    public class DragSourceEvent
    {
        private readonly DragSourceContext _context;

        public DragSourceEvent(DragSourceContext context)
        {
            _context = context;
        }

        public DragSourceContext GetDragSourceContext()
        {
            return _context;
        }

        public int GetX()
        {
            // Implementation as in Java: returns 0 by default (example)
            return 0;
        }

        public int GetY()
        {
            return 0;
        }

        public Point GetLocation()
        {
            return new Point(GetX(), GetY());
        }
    }

    [TestFixture]
    public class DragSourceEventAutoTest
    {
        private DragSourceContext CreateDefaultContext()
        {
            return new DragSourceContext();
        }

        [Test]
        public void GetDragSourceContext_test_714()
        {
            var c0 = CreateDefaultContext();
            DragSourceEvent instance = new DragSourceEvent(c0);
            instance.GetDragSourceContext();
        }

        [Test]
        public void GetX_test_715()
        {
            var c0 = CreateDefaultContext();
            DragSourceEvent instance = new DragSourceEvent(c0);
            instance.GetX();
        }

        [Test]
        public void GetY_test_716()
        {
            var c0 = CreateDefaultContext();
            DragSourceEvent instance = new DragSourceEvent(c0);
            instance.GetY();
        }

        [Test]
        public void GetLocation_test_717()
        {
            var c0 = CreateDefaultContext();
            DragSourceEvent instance = new DragSourceEvent(c0);
            instance.GetLocation();
        }
    }
}
```