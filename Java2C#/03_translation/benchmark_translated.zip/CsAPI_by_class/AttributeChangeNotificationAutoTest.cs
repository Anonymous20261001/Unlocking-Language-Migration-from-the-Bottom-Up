```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.management.AttributeChangeNotification
    public class AttributeChangeNotification
    {
        private readonly object source;
        private readonly long sequenceNumber;
        private readonly long timeStamp;
        private readonly string msg;
        private readonly string attributeName;
        private readonly string attributeType;
        private readonly object oldValue;
        private readonly object newValue;

        public AttributeChangeNotification(object source, long sequenceNumber, long timeStamp, string msg,
            string attributeName, string attributeType, object oldValue, object newValue)
        {
            this.source = source;
            this.sequenceNumber = sequenceNumber;
            this.timeStamp = timeStamp;
            this.msg = msg;
            this.attributeName = attributeName;
            this.attributeType = attributeType;
            this.oldValue = oldValue;
            this.newValue = newValue;
        }

        public object GetOldValue()
        {
            return oldValue;
        }

        public object GetNewValue()
        {
            return newValue;
        }

        public string GetAttributeName()
        {
            return attributeName;
        }

        public string GetAttributeType()
        {
            return attributeType;
        }
    }

    [TestFixture]
    public class AttributeChangeNotificationAutoTest
    {
        [Test]
        public void GetOldValue_test_5523()
        {
            // Use default placeholder values
            object c0 = null;
            long c1 = 0;
            long c2 = 0;
            string c3 = "";
            string c4 = "";
            string c5 = "";
            object c6 = null;
            object c7 = null;

            AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
            instance.GetOldValue();
        }

        [Test]
        public void GetNewValue_test_5524()
        {
            object c0 = null;
            long c1 = 0;
            long c2 = 0;
            string c3 = "";
            string c4 = "";
            string c5 = "";
            object c6 = null;
            object c7 = null;

            AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
            instance.GetNewValue();
        }

        [Test]
        public void GetAttributeName_test_5525()
        {
            object c0 = null;
            long c1 = 0;
            long c2 = 0;
            string c3 = "";
            string c4 = "";
            string c5 = "";
            object c6 = null;
            object c7 = null;

            AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
            instance.GetAttributeName();
        }

        [Test]
        public void GetAttributeType_test_5526()
        {
            object c0 = null;
            long c1 = 0;
            long c2 = 0;
            string c3 = "";
            string c4 = "";
            string c5 = "";
            object c6 = null;
            object c7 = null;

            AttributeChangeNotification instance = new AttributeChangeNotification(c0, c1, c2, c3, c4, c5, c6, c7);
            instance.GetAttributeType();
        }
    }
}
```