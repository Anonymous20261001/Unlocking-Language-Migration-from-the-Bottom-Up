```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Simple mock classes for Java AWT equivalents
    public class Component
    {
        // No specific behavior needed for these tests
    }

    public class Container : Component
    {
        // Inherits from Component, no additional members needed
    }

    public class HierarchyEvent
    {
        private readonly Component _source;
        private readonly int _id;
        private readonly Component _changed;
        private readonly Container _changedParent;

        public HierarchyEvent(Component source, int id, Component changed, Container changedParent)
        {
            _source = source;
            _id = id;
            _changed = changed;
            _changedParent = changedParent;
        }

        public Component GetChanged()
        {
            return _changed;
        }

        public Container GetChangedParent()
        {
            return _changedParent;
        }

        public int GetChangeFlags()
        {
            // In Java, this returns a bitmask; we return 0 as a stub
            return 0;
        }

        public string ParamString()
        {
            // Mimics Java's paramString() which returns a string representation
            return $"HierarchyEvent[source={_source}, id={_id}, changed={_changed}, changedParent={_changedParent}]";
        }

        public Component GetComponent()
        {
            return _source;
        }
    }

    [TestFixture]
    public class HierarchyEventAutoTest
    {
        [Test]
        public void GetChanged_test_759(Component c0, int c1, Component c2, Container c3)
        {
            HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
            instance.GetChanged();
        }

        [Test]
        public void GetChangedParent_test_760(Component c0, int c1, Component c2, Container c3)
        {
            HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
            instance.GetChangedParent();
        }

        [Test]
        public void GetChangeFlags_test_761(Component c0, int c1, Component c2, Container c3)
        {
            HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
            instance.GetChangeFlags();
        }

        [Test]
        public void ParamString_test_762(Component c0, int c1, Component c2, Container c3)
        {
            HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
            instance.ParamString();
        }

        [Test]
        public void GetComponent_test_763(Component c0, int c1, Component c2, Container c3)
        {
            HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
            instance.GetComponent();
        }
    }
}
```