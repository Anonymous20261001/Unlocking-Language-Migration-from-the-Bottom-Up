```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Custom exception mimicking Java's IllegalFormatConversionException
    public class IllegalFormatConversionException : Exception
    {
        private readonly char _conversion;
        private readonly Type _argumentClass;

        public IllegalFormatConversionException(char conversion, Type argumentClass)
        {
            _conversion = conversion;
            _argumentClass = argumentClass;
        }

        // Java-style method names to match the original API
        public char getConversion() => _conversion;
        public Type getArgumentClass() => _argumentClass;
        public string getMessage() => Message;

        public override string Message => $"Conversion = '{_conversion}', argument class = {_argumentClass.Name}";
    }

    [TestFixture]
    public class IllegalFormatConversionExceptionAutoTest
    {
        [Test]
        public void GetConversion_Test_3566()
        {
            char c0 = 'd';
            Type c1 = typeof(int);
            var instance = new IllegalFormatConversionException(c0, c1);
            instance.getConversion();
        }

        [Test]
        public void GetArgumentClass_Test_3567()
        {
            char c0 = 'd';
            Type c1 = typeof(int);
            var instance = new IllegalFormatConversionException(c0, c1);
            instance.getArgumentClass();
        }

        [Test]
        public void GetMessage_Test_3568()
        {
            char c0 = 'd';
            Type c1 = typeof(int);
            var instance = new IllegalFormatConversionException(c0, c1);
            instance.getMessage();
        }
    }
}
```