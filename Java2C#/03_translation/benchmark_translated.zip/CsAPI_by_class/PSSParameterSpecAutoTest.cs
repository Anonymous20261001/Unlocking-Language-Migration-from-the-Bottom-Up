```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class MGF1ParameterSpec
    {
        private readonly string _digestAlgorithm;
        public MGF1ParameterSpec(string digestAlgorithm)
        {
            _digestAlgorithm = digestAlgorithm;
        }

        public string GetDigestAlgorithm() => _digestAlgorithm;

        public override string ToString()
        {
            return "MGF1ParameterSpec: digestAlgorithm=" + _digestAlgorithm;
        }
    }

    public class PSSParameterSpec
    {
        private readonly string _digestAlgorithm;
        private readonly string _mgfAlgorithm;
        private readonly MGF1ParameterSpec _mgfParameters;
        private readonly int _saltLength;
        private readonly int _trailerField;

        // Deprecated constructor: only salt length provided, uses defaults
        public PSSParameterSpec(int saltLength)
        {
            _saltLength = saltLength;
            _digestAlgorithm = "SHA-1";
            _mgfAlgorithm = "MGF1";
            _mgfParameters = new MGF1ParameterSpec("SHA-1");
            _trailerField = 1;
        }

        public string GetDigestAlgorithm() => _digestAlgorithm;
        public string GetMGFAlgorithm() => _mgfAlgorithm;
        public MGF1ParameterSpec GetMGFParameters() => _mgfParameters;
        public int GetSaltLength() => _saltLength;
        public int GetTrailerField() => _trailerField;

        public override string ToString()
        {
            return $"PSSParameterSpec: digestAlgorithm={_digestAlgorithm}, mgfAlgorithm={_mgfAlgorithm}, " +
                   $"mgfParameters={_mgfParameters}, saltLength={_saltLength}, trailerField={_trailerField}";
        }
    }

    [TestFixture]
    public class PSSParameterSpecAutoTest
    {
        [Test]
        public void GetDigestAlgorithm_Test_2900()
        {
            int c0 = 0; // arbitrary default value
            var instance = new PSSParameterSpec(c0);
            instance.GetDigestAlgorithm();
        }

        [Test]
        public void GetMGFAlgorithm_Test_2901()
        {
            int c0 = 0;
            var instance = new PSSParameterSpec(c0);
            instance.GetMGFAlgorithm();
        }

        [Test]
        public void GetMGFParameters_Test_2902()
        {
            int c0 = 0;
            var instance = new PSSParameterSpec(c0);
            instance.GetMGFParameters();
        }

        [Test]
        public void GetSaltLength_Test_2903()
        {
            int c0 = 0;
            var instance = new PSSParameterSpec(c0);
            instance.GetSaltLength();
        }

        [Test]
        public void GetTrailerField_Test_2904()
        {
            int c0 = 0;
            var instance = new PSSParameterSpec(c0);
            instance.GetTrailerField();
        }

        [Test]
        public void ToString_Test_2905()
        {
            int c0 = 0;
            var instance = new PSSParameterSpec(c0);
            instance.ToString();
        }
    }
}
```