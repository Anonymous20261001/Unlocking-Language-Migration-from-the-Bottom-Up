```csharp
using NUnit.Framework;

namespace Generated.Test
{
    // Minimal C# equivalents of Java classes used in the tests
    public class Component { }
    public class MenuElement { }
    public class MenuSelectionManager { }

    public class MenuDragMouseEvent
    {
        private readonly MenuSelectionManager _manager;
        private readonly MenuElement[] _path;

        public MenuDragMouseEvent(Component source, int id, long when, int modifiers,
            int x, int y, int clickCount, bool popupTrigger,
            MenuElement[] path, MenuSelectionManager manager)
        {
            _manager = manager;
            _path = path;
        }

        public MenuSelectionManager GetMenuSelectionManager() => _manager;
        public MenuElement[] GetPath() => _path;
    }

    [TestFixture]
    public class MenuDragMouseEventAutoTest
    {
        [Test]
        public void GetMenuSelectionManager_test_8545()
        {
            Component c0 = new Component();
            int c1 = 0;
            long c2 = 0L;
            int c3 = 0;
            int c4 = 0;
            int c5 = 0;
            int c6 = 0;
            bool c7 = false;
            MenuElement[] c8 = new MenuElement[0];
            MenuSelectionManager c9 = new MenuSelectionManager();

            MenuDragMouseEvent instance = new MenuDragMouseEvent(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9);
            instance.GetMenuSelectionManager();
        }

        [Test]
        public void GetPath_test_8546()
        {
            Component c0 = new Component();
            int c1 = 0;
            long c2 = 0L;
            int c3 = 0;
            int c4 = 0;
            int c5 = 0;
            int c6 = 0;
            bool c7 = false;
            MenuElement[] c8 = new MenuElement[0];
            MenuSelectionManager c9 = new MenuSelectionManager();

            MenuDragMouseEvent instance = new MenuDragMouseEvent(c0, c1, c2, c3, c4, c5, c6, c7, c8, c9);
            instance.GetPath();
        }
    }
}
```