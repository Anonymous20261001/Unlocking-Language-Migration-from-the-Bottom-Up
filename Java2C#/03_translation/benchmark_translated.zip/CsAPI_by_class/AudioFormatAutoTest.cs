```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.sound.sampled.AudioFormat
    /// </summary>
    public class AudioFormat
    {
        public const float NOT_SPECIFIED = -1.0f;

        public class Encoding
        {
            public static readonly Encoding PCM_SIGNED = new Encoding("PCM_SIGNED");
            public static readonly Encoding PCM_UNSIGNED = new Encoding("PCM_UNSIGNED");

            private readonly string _name;

            public Encoding(string name)
            {
                _name = name;
            }

            public override bool Equals(object obj)
            {
                if (obj is Encoding other)
                    return string.Equals(_name, other._name, StringComparison.Ordinal);
                return false;
            }

            public override int GetHashCode() => _name.GetHashCode();

            public override string ToString() => _name;
        }

        private readonly Encoding _encoding;
        private readonly float _sampleRate;
        private readonly int _sampleSizeInBits;
        private readonly int _channels;
        private readonly int _frameSize;
        private readonly float _frameRate;
        private readonly bool _bigEndian;

        public AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed, bool bigEndian)
        {
            _encoding = signed ? Encoding.PCM_SIGNED : Encoding.PCM_UNSIGNED;
            _sampleRate = sampleRate;
            _sampleSizeInBits = sampleSizeInBits;
            _channels = channels;
            _bigEndian = bigEndian;

            // Frame size calculation (mimics Java's behavior)
            int bytesPerSample = (sampleSizeInBits + 7) / 8; // ceiling division
            _frameSize = bytesPerSample * channels;

            _frameRate = sampleRate;
        }

        public int GetChannels() => _channels;
        public float GetSampleRate() => _sampleRate;
        public int GetSampleSizeInBits() => _sampleSizeInBits;
        public float GetFrameRate() => _frameRate;
        public int GetFrameSize() => _frameSize;
        public bool IsBigEndian() => _bigEndian;
        public Encoding GetEncoding() => _encoding;

        public object GetProperty(string key)
        {
            // Simple constructor does not set any properties; always returns null.
            return null;
        }

        public Dictionary<string, object> Properties()
        {
            // Returns an empty dictionary (unmodifiable in Java, but we return a new one each time for simplicity)
            return new Dictionary<string, object>();
        }

        public bool Matches(AudioFormat other)
        {
            if (other == null)
                return false;

            if (!_encoding.Equals(other._encoding))
                return false;

            if (_sampleRate != NOT_SPECIFIED && other._sampleRate != NOT_SPECIFIED &&
                Math.Abs(_sampleRate - other._sampleRate) > 1.0e-6f)
                return false;

            if (_sampleSizeInBits != other._sampleSizeInBits)
                return false;

            if (_channels != other._channels)
                return false;

            if (_frameSize != other._frameSize)
                return false;

            if (_frameRate != NOT_SPECIFIED && other._frameRate != NOT_SPECIFIED &&
                Math.Abs(_frameRate - other._frameRate) > 1.0e-6f)
                return false;

            if (_bigEndian != other._bigEndian)
                return false;

            // Check properties: all keys in this format must exist in other with equal values.
            var thisProps = Properties();
            var otherProps = other.Properties();
            foreach (var kvp in thisProps)
            {
                if (!otherProps.TryGetValue(kvp.Key, out var otherValue))
                    return false;
                if (!Equals(kvp.Value, otherValue))
                    return false;
            }

            return true;
        }

        public override string ToString()
        {
            return $"{_encoding} {_sampleRate} Hz, {_sampleSizeInBits} bit, {_channels} channels, " +
                   $"{_frameSize} bytes/frame, {_frameRate} frames/second, " +
                   (_bigEndian ? "big-endian" : "little-endian");
        }
    }

    [TestFixture]
    public class AudioFormatAutoTest
    {
        [Test]
        public void GetChannels_test_6504(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetChannels();
        }

        [Test]
        public void GetSampleRate_test_6505(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetSampleRate();
        }

        [Test]
        public void GetSampleSizeInBits_test_6506(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetSampleSizeInBits();
        }

        [Test]
        public void GetFrameRate_test_6507(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetFrameRate();
        }

        [Test]
        public void GetFrameSize_test_6508(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetFrameSize();
        }

        [Test]
        public void GetProperty_test_6509(string p0, float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetProperty(p0);
        }

        [Test]
        public void ToString_test_6510(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.ToString();
        }

        [Test]
        public void Matches_test_6511(AudioFormat p0, float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.Matches(p0);
        }

        [Test]
        public void Properties_test_6512(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.Properties();
        }

        [Test]
        public void IsBigEndian_test_6513(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.IsBigEndian();
        }

        [Test]
        public void GetEncoding_test_6514(float c0, int c1, int c2, bool c3, bool c4)
        {
            AudioFormat instance = new AudioFormat(c0, c1, c2, c3, c4);
            instance.GetEncoding();
        }
    }
}
```