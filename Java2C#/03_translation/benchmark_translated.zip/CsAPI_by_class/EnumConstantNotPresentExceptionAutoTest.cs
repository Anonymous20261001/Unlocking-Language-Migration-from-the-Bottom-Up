```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class EnumConstantNotPresentExceptionAutoTest
    {
        [Test]
        public void EnumType_test_1995(Type c0, string c1)
        {
            EnumConstantNotPresentException instance = new EnumConstantNotPresentException(c0, c1);
            instance.EnumType();
        }

        [Test]
        public void ConstantName_test_1996(Type c0, string c1)
        {
            EnumConstantNotPresentException instance = new EnumConstantNotPresentException(c0, c1);
            instance.ConstantName();
        }
    }

    public class EnumConstantNotPresentException : Exception
    {
        public Type EnumType { get; }
        public string ConstantName { get; }

        public EnumConstantNotPresentException(Type enumType, string constantName)
            : base($"Enum constant '{constantName}' not present in type '{enumType?.FullName}'")
        {
            EnumType = enumType;
            ConstantName = constantName;
        }

        public Type EnumType()
        {
            return EnumType;
        }

        public string ConstantName()
        {
            return ConstantName;
        }
    }
}
```