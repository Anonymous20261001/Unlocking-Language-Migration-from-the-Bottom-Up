```csharp
using Xunit;

namespace Generated.Test
{
    // C# equivalent of javax.naming.ldap.BasicControl
    public class BasicControl
    {
        private readonly string _id;
        private readonly bool _critical;
        private readonly byte[] _encodedValue;

        // Constructor matching Java's BasicControl(String id)
        public BasicControl(string id) : this(id, false, null) { }

        // Full constructor (not used in tests but implemented for completeness)
        public BasicControl(string id, bool critical, byte[] encodedValue)
        {
            _id = id;
            _critical = critical;
            _encodedValue = encodedValue;
        }

        public string GetID() => _id;

        public bool IsCritical() => _critical;

        public byte[] GetEncodedValue() => _encodedValue;
    }

    // Test class equivalent to BasicControlAutoTest
    public class BasicControlAutoTest
    {
        [Fact]
        public void IsCritical_Test_6008()
        {
            BasicControl instance = new BasicControl("testId");
            instance.IsCritical();
        }

        [Fact]
        public void GetEncodedValue_Test_6009()
        {
            BasicControl instance = new BasicControl("testId");
            instance.GetEncodedValue();
        }

        [Fact]
        public void GetID_Test_6010()
        {
            BasicControl instance = new BasicControl("testId");
            instance.GetID();
        }
    }
}
```