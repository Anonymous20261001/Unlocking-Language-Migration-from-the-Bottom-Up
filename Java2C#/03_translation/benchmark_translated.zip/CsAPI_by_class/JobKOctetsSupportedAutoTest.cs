```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // Base class mimicking Java's SetOfIntegerSyntax
    public abstract class SetOfIntegerSyntax
    {
        public int LowerBound { get; }
        public int UpperBound { get; }

        protected SetOfIntegerSyntax(int lowerBound, int upperBound)
        {
            if (lowerBound > upperBound)
                throw new ArgumentException("Lower bound cannot be greater than upper bound.");
            LowerBound = lowerBound;
            UpperBound = upperBound;
        }

        public override bool Equals(object obj)
        {
            if (obj is SetOfIntegerSyntax other)
                return LowerBound == other.LowerBound && UpperBound == other.UpperBound;
            return false;
        }

        public override int GetHashCode() => Tuple.Create(LowerBound, UpperBound).GetHashCode();
    }

    // C# equivalent of javax.print.attribute.standard.JobKOctetsSupported
    public class JobKOctetsSupported : SetOfIntegerSyntax
    {
        public JobKOctetsSupported(int lowerBound, int upperBound) 
            : base(lowerBound, upperBound) { }

        // Mimics Java's getCategory() – returns the Type of this attribute class
        public Type GetCategory() => typeof(JobKOctetsSupported);

        // Mimics Java's getName() – returns the attribute name as defined in IPP
        public string GetName() => "job-k-octets-supported";
    }

    [TestFixture]
    public class JobKOctetsSupportedAutoTest
    {
        [Test]
        public void GetCategory_Test_6139([Values(1)] int c0, [Values(10)] int c1)
        {
            var instance = new JobKOctetsSupported(c0, c1);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6140([Values(5)] int c0, [Values(50)] int c1)
        {
            var instance = new JobKOctetsSupported(c0, c1);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6141([Values(null)] object p0, [Values(1)] int c0, [Values(10)] int c1)
        {
            var instance = new JobKOctetsSupported(c0, c1);
            instance.Equals(p0);
        }
    }
}
```