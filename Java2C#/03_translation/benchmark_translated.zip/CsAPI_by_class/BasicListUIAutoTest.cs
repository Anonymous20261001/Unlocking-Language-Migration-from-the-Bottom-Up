```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Dummy classes to mimic Java AWT/Swing types
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point() { }
        public Point(int x, int y) { X = x; Y = y; }
    }

    public class Graphics { }

    public class JComponent { }

    public class JList : JComponent { }

    public enum BaselineResizeBehavior
    {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    }

    public class BasicListUI
    {
        // Mimics Java static factory method
        public static BasicListUI CreateUI(JComponent c) => new BasicListUI();

        public void InstallUI(JComponent c) { }
        public void UninstallUI(JComponent c) { }
        public int LocationToIndex(JList list, Point location) => 0;
        public Rectangle GetCellBounds(JList list, int index1, int index2) => new Rectangle();
        public Point IndexToLocation(JList list, int index) => new Point();
        public void Paint(Graphics g, JComponent c) { }
        public Dimension GetPreferredSize(JComponent c) => new Dimension();
        public int GetBaseline(JComponent c, int width, int height) => 0;
        public BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c) => BaselineResizeBehavior.OTHER;
    }

    // Additional helper stubs used by BasicListUI (return types)
    public class Rectangle
    {
        public int X, Y, Width, Height;
    }

    public class Dimension
    {
        public int Width, Height;
    }

    [TestFixture]
    public class BasicListUIAutoTest
    {
        [Test]
        public void installUI_test_8814()
        {
            BasicListUI instance = new BasicListUI();
            instance.InstallUI(null);
        }

        [Test]
        public void uninstallUI_test_8815()
        {
            BasicListUI instance = new BasicListUI();
            instance.UninstallUI(null);
        }

        [Test]
        public void locationToIndex_test_8816()
        {
            BasicListUI instance = new BasicListUI();
            instance.LocationToIndex(null, null);
        }

        [Test]
        public void getCellBounds_test_8817()
        {
            BasicListUI instance = new BasicListUI();
            instance.GetCellBounds(null, 0, 0);
        }

        [Test]
        public void indexToLocation_test_8818()
        {
            BasicListUI instance = new BasicListUI();
            instance.IndexToLocation(null, 0);
        }

        [Test]
        public void createUI_test_8819()
        {
            BasicListUI instance = new BasicListUI();
            BasicListUI.CreateUI(null);
        }

        [Test]
        public void paint_test_8820()
        {
            BasicListUI instance = new BasicListUI();
            instance.Paint(null, null);
        }

        [Test]
        public void getPreferredSize_test_8821()
        {
            BasicListUI instance = new BasicListUI();
            instance.GetPreferredSize(null);
        }

        [Test]
        public void getBaseline_test_8822()
        {
            BasicListUI instance = new BasicListUI();
            instance.GetBaseline(null, 0, 0);
        }

        [Test]
        public void getBaselineResizeBehavior_test_8823()
        {
            BasicListUI instance = new BasicListUI();
            instance.GetBaselineResizeBehavior(null);
        }
    }
}
```