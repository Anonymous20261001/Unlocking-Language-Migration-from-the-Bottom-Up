```csharp
using NUnit.Framework;
using System;

namespace generated.tests
{
    /// <summary>
    /// C# equivalent of Java's java.awt.image.DataBufferInt.
    /// </summary>
    public class DataBufferInt
    {
        private readonly int[][] banks;

        /// <summary>
        /// Creates a DataBufferInt with a single bank of the specified size.
        /// </summary>
        /// <param name="size">The size of the bank.</param>
        public DataBufferInt(int size)
        {
            banks = new int[1][];
            banks[0] = new int[size];
        }

        /// <summary>
        /// Returns the data array for all banks.
        /// </summary>
        public int[][] GetBankData()
        {
            return banks;
        }

        /// <summary>
        /// Returns the element at the specified index in the specified bank.
        /// </summary>
        public int GetElem(int bank, int i)
        {
            return banks[bank][i];
        }

        /// <summary>
        /// Returns the element at the specified index in the first bank.
        /// </summary>
        public int GetElem(int i)
        {
            return banks[0][i];
        }

        /// <summary>
        /// Sets the element at the specified index in the specified bank.
        /// </summary>
        public void SetElem(int bank, int i, int val)
        {
            banks[bank][i] = val;
        }

        /// <summary>
        /// Sets the element at the specified index in the first bank.
        /// </summary>
        public void SetElem(int i, int val)
        {
            banks[0][i] = val;
        }

        /// <summary>
        /// Returns the data array for the specified bank.
        /// </summary>
        public int[] GetData(int bank)
        {
            return banks[bank];
        }

        /// <summary>
        /// Returns the data array for the first bank.
        /// </summary>
        public int[] GetData()
        {
            return banks[0];
        }
    }

    [TestFixture]
    public class DataBufferIntAutoTest
    {
        [TestCase(0)]
        public void GetBankData_test_1220(int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.GetBankData();
        }

        [TestCase(0, 0, 0)]
        public void GetElem_test_1221(int p0, int p1, int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.GetElem(p0, p1);
        }

        [TestCase(0, 0)]
        public void GetElem_test_1222(int p0, int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.GetElem(p0);
        }

        [TestCase(0, 0, 0, 0)]
        public void SetElem_test_1223(int p0, int p1, int p2, int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.SetElem(p0, p1, p2);
        }

        [TestCase(0, 0, 0)]
        public void SetElem_test_1224(int p0, int p1, int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.SetElem(p0, p1);
        }

        [TestCase(0, 0)]
        public void GetData_test_1225(int p0, int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.GetData(p0);
        }

        [TestCase(0)]
        public void GetData_test_1226(int c0)
        {
            var instance = new DataBufferInt(c0);
            instance.GetData();
        }
    }
}
```