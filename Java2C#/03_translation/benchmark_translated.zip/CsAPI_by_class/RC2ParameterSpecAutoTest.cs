```csharp
using System;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.crypto.spec.RC2ParameterSpec
    public class RC2ParameterSpec
    {
        private readonly int effectiveKeyBits;
        private readonly byte[] iv;

        public RC2ParameterSpec(int effectiveKeyBits) : this(effectiveKeyBits, null)
        {
        }

        public RC2ParameterSpec(int effectiveKeyBits, byte[] iv)
        {
            this.effectiveKeyBits = effectiveKeyBits;
            // Defensive copy to mimic Java's behavior
            this.iv = iv?.ToArray();
        }

        public byte[] GetIV()
        {
            // Return a copy to prevent external modification (Java style)
            return iv?.ToArray();
        }

        public int GetEffectiveKeyBits()
        {
            return effectiveKeyBits;
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;

            if (!(obj is RC2ParameterSpec other))
                return false;

            if (effectiveKeyBits != other.effectiveKeyBits)
                return false;

            return (iv == null && other.iv == null) ||
                   (iv != null && other.iv != null && iv.SequenceEqual(other.iv));
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + effectiveKeyBits;
                if (iv != null)
                {
                    foreach (byte b in iv)
                        hash = hash * 31 + b;
                }
                return hash;
            }
        }
    }

    // Test class (NUnit)
    public class RC2ParameterSpecAutoTest
    {
        [Test]
        public void GetIV_Test_5262()
        {
            int c0 = 0; // default value
            RC2ParameterSpec instance = new RC2ParameterSpec(c0);
            instance.GetIV();
        }

        [Test]
        public void GetEffectiveKeyBits_Test_5263()
        {
            int c0 = 0;
            RC2ParameterSpec instance = new RC2ParameterSpec(c0);
            instance.GetEffectiveKeyBits();
        }

        [Test]
        public void Equals_Test_5264()
        {
            object p0 = null; // default value
            int c0 = 0;
            RC2ParameterSpec instance = new RC2ParameterSpec(c0);
            instance.Equals(p0);
        }

        [Test]
        public void HashCode_Test_5265()
        {
            int c0 = 0;
            RC2ParameterSpec instance = new RC2ParameterSpec(c0);
            instance.GetHashCode();
        }
    }
}
```