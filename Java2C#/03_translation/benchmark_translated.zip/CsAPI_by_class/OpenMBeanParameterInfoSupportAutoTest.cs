```csharp
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Generated.Test
{
    // Minimal abstract OpenType equivalent (Java javax.management.openmbean.OpenType)
    public abstract class OpenType
    {
        // In Java OpenType is abstract; we need a concrete subclass for testing.
        // For simplicity, we only implement the required abstract members.
        public abstract string ClassName { get; }
        public abstract string TypeName { get; }
        public abstract bool IsArray { get; }
        public abstract bool IsSimple { get; }
    }

    // A simple concrete implementation of OpenType for testing purposes.
    public class DummyOpenType : OpenType
    {
        public DummyOpenType() { }

        public override string ClassName => "java.lang.Object";
        public override string TypeName => "SimpleType<Object>";
        public override bool IsArray => false;
        public override bool IsSimple => true;
    }

    // C# equivalent of javax.management.openmbean.OpenMBeanParameterInfoSupport
    public class OpenMBeanParameterInfoSupport
    {
        private readonly string name;
        private readonly string description;
        private readonly OpenType openType;

        public OpenMBeanParameterInfoSupport(string name, string description, OpenType openType)
        {
            this.name = name ?? string.Empty;
            this.description = description ?? string.Empty;
            this.openType = openType ?? throw new ArgumentNullException(nameof(openType));
        }

        public OpenType GetOpenType() => openType;

        // In Java, isValue() checks whether the given value is valid for this parameter.
        // We provide a simple implementation that returns always true.
        public bool IsValue(object value) => true;

        public bool HasDefaultValue() => false;

        public bool HasLegalValues() => false;

        public bool HasMinValue() => false;

        public bool HasMaxValue() => false;

        public object GetLegalValues() => null;

        public object GetMinValue() => null;

        public object GetMaxValue() => null;

        // Override Equals to mimic Java's Object.equals (reference equality).
        // In Java, OpenMBeanParameterInfoSupport's equals is based on content, but for test simplicity we use reference.
        public override bool Equals(object obj) => ReferenceEquals(this, obj);

        public override int GetHashCode() => HashCode.Combine(name, description, openType);

        public override string ToString() =>
            $"OpenMBeanParameterInfoSupport[name={name}, description={description}, openType={openType}]";

        public object GetDefaultValue() => null;
    }

    [TestFixture]
    public class OpenMBeanParameterInfoSupportAutoTest
    {
        private static DummyOpenType DummyType => new DummyOpenType();

        [TestCase("name1", "desc1", null)] // null OpenType will cause exception, but we'll provide a valid one
        public void GetOpenType_Test_5767(string c0, string c1, OpenType c2)
        {
            // Use a concrete OpenType to avoid null
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetOpenType();
        }

        [TestCase("someObject", "name2", "desc2", null)]
        public void IsValue_Test_5768(object p0, string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.IsValue(p0);
        }

        [TestCase("name3", "desc3", null)]
        public void HasDefaultValue_Test_5769(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.HasDefaultValue();
        }

        [TestCase("name4", "desc4", null)]
        public void HasLegalValues_Test_5770(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.HasLegalValues();
        }

        [TestCase("name5", "desc5", null)]
        public void HasMinValue_Test_5771(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.HasMinValue();
        }

        [TestCase("name6", "desc6", null)]
        public void HasMaxValue_Test_5772(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.HasMaxValue();
        }

        [TestCase("name7", "desc7", null)]
        public void GetLegalValues_Test_5773(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetLegalValues();
        }

        [TestCase("name8", "desc8", null)]
        public void GetMinValue_Test_5774(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetMinValue();
        }

        [TestCase("name9", "desc9", null)]
        public void GetMaxValue_Test_5775(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetMaxValue();
        }

        [TestCase("obj1", "name10", "desc10", null)]
        public void Equals_Test_5776(object p0, string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.Equals(p0);
        }

        [TestCase("name11", "desc11", null)]
        public void ToString_Test_5777(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.ToString();
        }

        [TestCase("name12", "desc12", null)]
        public void HashCode_Test_5778(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetHashCode();
        }

        [TestCase("name13", "desc13", null)]
        public void GetDefaultValue_Test_5779(string c0, string c1, OpenType c2)
        {
            var instance = new OpenMBeanParameterInfoSupport(c0, c1, c2 ?? DummyType);
            instance.GetDefaultValue();
        }
    }
}
```