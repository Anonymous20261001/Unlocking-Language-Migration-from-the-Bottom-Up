```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.print.attribute.standard.PagesPerMinute
    public class PagesPerMinute : IEquatable<PagesPerMinute>
    {
        private readonly int _value;

        public PagesPerMinute(int value)
        {
            _value = value;
        }

        public int Value => _value;

        /// <summary>
        /// Returns the category of this attribute (the class itself).
        /// Equivalent to Java's getCategory().
        /// </summary>
        public Type GetCategory()
        {
            return typeof(PagesPerMinute);
        }

        /// <summary>
        /// Returns the name of this attribute.
        /// Equivalent to Java's getName().
        /// </summary>
        public string GetName()
        {
            return "pages-per-minute";
        }

        /// <summary>
        /// Compares this PagesPerMinute with another object for equality.
        /// Two PagesPerMinute instances are equal if they have the same integer value.
        /// </summary>
        public override bool Equals(object obj)
        {
            return Equals(obj as PagesPerMinute);
        }

        public bool Equals(PagesPerMinute other)
        {
            if (other is null)
                return false;
            return _value == other._value;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }

        public override string ToString()
        {
            return $"{GetName()}: {_value}";
        }
    }

    // Test class mirroring the Java test file
    [TestFixture]
    public class PagesPerMinuteAutoTest
    {
        [Test]
        public void GetCategory_test_6204()
        {
            int c0 = 0;
            PagesPerMinute instance = new PagesPerMinute(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_test_6205()
        {
            int c0 = 0;
            PagesPerMinute instance = new PagesPerMinute(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_test_6206()
        {
            object p0 = null;
            int c0 = 0;
            PagesPerMinute instance = new PagesPerMinute(c0);
            instance.Equals(p0);
        }
    }
}
```