```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public sealed class EdDSAParameterSpec
    {
        private readonly bool _prehash;
        private readonly byte[] _context;

        public EdDSAParameterSpec(bool prehash)
        {
            _prehash = prehash;
            _context = null;
        }

        public bool IsPrehash()
        {
            return _prehash;
        }

        public byte[] GetContext()
        {
            return _context;
        }
    }

    [TestFixture]
    public class EdDSAParameterSpecAutoTest
    {
        [Test]
        public void IsPrehash_test_2881()
        {
            bool c0 = false; // default value, as the Java test had a parameter but we use a fixed value
            EdDSAParameterSpec instance = new EdDSAParameterSpec(c0);
            instance.IsPrehash();
        }

        [Test]
        public void GetContext_test_2882()
        {
            bool c0 = false; // default value
            EdDSAParameterSpec instance = new EdDSAParameterSpec(c0);
            instance.GetContext();
        }
    }
}
```