```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    public class PageRanges
    {
        private List<(int start, int end)> ranges;

        public PageRanges(int[][] ranges)
        {
            this.ranges = new List<(int, int)>();
            if (ranges == null)
                throw new ArgumentNullException(nameof(ranges));

            foreach (var pair in ranges)
            {
                if (pair == null || pair.Length != 2)
                    throw new ArgumentException("Each range must be an array of exactly two integers.");
                this.ranges.Add((pair[0], pair[1]));
            }

            // Sort by start, then end (Java's PageRanges stores sorted, non-overlapping ranges)
            this.ranges = this.ranges.OrderBy(r => r.start).ThenBy(r => r.end).ToList();
        }

        public Type GetCategory()
        {
            // In Java, returns a Class<? extends Attribute>. We use Type.
            return typeof(PageRanges);
        }

        public string GetName()
        {
            // Standard attribute name for PageRanges
            return "page-ranges";
        }

        public override bool Equals(object obj)
        {
            if (obj is PageRanges other)
            {
                if (other.ranges.Count != this.ranges.Count)
                    return false;
                for (int i = 0; i < this.ranges.Count; i++)
                {
                    if (this.ranges[i].start != other.ranges[i].start ||
                        this.ranges[i].end != other.ranges[i].end)
                        return false;
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                foreach (var r in ranges)
                {
                    hash = hash * 31 + r.start;
                    hash = hash * 31 + r.end;
                }
                return hash;
            }
        }
    }

    public class PageRangesAutoTest
    {
        [Test]
        public void GetCategory_test_6201(int[][] c0)
        {
            PageRanges instance = new PageRanges(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_test_6202(int[][] c0)
        {
            PageRanges instance = new PageRanges(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_test_6203(object p0, int[][] c0)
        {
            PageRanges instance = new PageRanges(c0);
            instance.Equals(p0);
        }
    }
}
```