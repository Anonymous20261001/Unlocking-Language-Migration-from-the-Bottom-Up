```csharp
using System;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.naming.BinaryRefAddr
    public class BinaryRefAddr
    {
        private readonly string _addrType;
        private readonly byte[] _bytes;

        public BinaryRefAddr(string addrType, byte[] bytes)
        {
            _addrType = addrType ?? throw new ArgumentNullException(nameof(addrType));
            _bytes = bytes ?? throw new ArgumentNullException(nameof(bytes));
        }

        public override bool Equals(object obj)
        {
            if (obj != null && obj is BinaryRefAddr other)
            {
                return _addrType == other._addrType && _bytes.SequenceEqual(other._bytes);
            }
            return false;
        }

        public override int GetHashCode()
        {
            // Combine hash codes: addrType hash and array content hash
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + (_addrType?.GetHashCode() ?? 0);
                hash = hash * 31 + (_bytes != null ? _bytes.Sum(b => b) : 0); // simplified; real Java uses Arrays.hashCode
                return hash;
            }
        }

        public override string ToString()
        {
            return $"BinaryRefAddr: {_addrType}: {BitConverter.ToString(_bytes)}";
        }

        public object GetContent()
        {
            return _bytes;
        }
    }

    [TestFixture]
    public class BinaryRefAddrAutoTest
    {
        [Test]
        public void Equals_test_5873()
        {
            // Dummy parameters translated to local variables
            object p0 = new object();
            string c0 = "testType";
            byte[] c1 = new byte[] { 0x01, 0x02, 0x03 };
            BinaryRefAddr instance = new BinaryRefAddr(c0, c1);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_test_5874()
        {
            string c0 = "testType";
            byte[] c1 = new byte[] { 0x01, 0x02, 0x03 };
            BinaryRefAddr instance = new BinaryRefAddr(c0, c1);
            string result = instance.ToString(); // suppress unused warning
        }

        [Test]
        public void HashCode_test_5875()
        {
            string c0 = "testType";
            byte[] c1 = new byte[] { 0x01, 0x02, 0x03 };
            BinaryRefAddr instance = new BinaryRefAddr(c0, c1);
            int hashCode = instance.GetHashCode(); // suppress unused warning
        }

        [Test]
        public void GetContent_test_5876()
        {
            string c0 = "testType";
            byte[] c1 = new byte[] { 0x01, 0x02, 0x03 };
            BinaryRefAddr instance = new BinaryRefAddr(c0, c1);
            object content = instance.GetContent(); // suppress unused warning
        }
    }
}
```