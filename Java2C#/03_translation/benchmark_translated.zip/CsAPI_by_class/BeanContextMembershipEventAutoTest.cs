```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace BeanContextTests
{
    // Dummy interface for BeanContext (equivalent to java.beans.beancontext.BeanContext)
    public interface IBeanContext
    {
        // In the tests only the type is used, no methods are called on it.
    }

    // Simple implementation of IBeanContext for test purposes
    public class DummyBeanContext : IBeanContext
    {
    }

    // C# equivalent of java.beans.beancontext.BeanContextMembershipEvent
    public class BeanContextMembershipEvent : EventArgs
    {
        private readonly IBeanContext _beanContext;
        private readonly ICollection _children;

        public BeanContextMembershipEvent(IBeanContext bc, ICollection children)
        {
            _beanContext = bc;
            _children = children;
        }

        public int Size()
        {
            return _children.Count;
        }

        public object[] ToArray()
        {
            object[] array = new object[_children.Count];
            _children.CopyTo(array, 0);
            return array;
        }

        public IEnumerator Iterator()
        {
            return _children.GetEnumerator();
        }

        public bool Contains(object o)
        {
            // The Java method uses Collection.contains, which in C# checks for equality.
            // If the collection is a generic ICollection<object>, we need explicit support.
            // Here we assume _children is a non-generic ICollection.
            foreach (object item in _children)
            {
                if (object.Equals(item, o))
                    return true;
            }
            return false;
        }
    }

    [TestFixture]
    public class BeanContextMembershipEventAutoTest
    {
        [Test]
        public void Size_Test_1642()
        {
            IBeanContext c0 = new DummyBeanContext();
            ICollection c1 = new ArrayList { 1, "two", 3.0 };
            BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
            instance.Size();
        }

        [Test]
        public void ToArray_Test_1643()
        {
            IBeanContext c0 = new DummyBeanContext();
            ICollection c1 = new ArrayList { "a", "b", "c" };
            BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
            instance.ToArray();
        }

        [Test]
        public void Iterator_Test_1644()
        {
            IBeanContext c0 = new DummyBeanContext();
            ICollection c1 = new ArrayList { 1, 2, 3 };
            BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
            instance.Iterator();
        }

        [Test]
        public void Contains_Test_1645()
        {
            object p0 = "test";
            IBeanContext c0 = new DummyBeanContext();
            ICollection c1 = new ArrayList { "test", 42, true };
            BeanContextMembershipEvent instance = new BeanContextMembershipEvent(c0, c1);
            instance.Contains(p0);
        }
    }
}
```