```csharp
using NUnit.Framework;
using System;

namespace Generated.Test
{
    [TestFixture]
    public class MenuShortcutAutoTest
    {
        [Test]
        public void UsesShiftModifier_test_409()
        {
            MenuShortcut instance = new MenuShortcut(0);
            instance.UsesShiftModifier();
        }

        [Test]
        public void Equals_test_410()
        {
            MenuShortcut instance = new MenuShortcut(0);
            MenuShortcut p0 = new MenuShortcut(1);
            instance.Equals(p0);
        }

        [Test]
        public void Equals_test_411()
        {
            MenuShortcut instance = new MenuShortcut(0);
            object p0 = new object();
            instance.Equals(p0);
        }

        [Test]
        public void ToString_test_412()
        {
            MenuShortcut instance = new MenuShortcut(0);
            instance.ToString();
        }

        [Test]
        public void HashCode_test_413()
        {
            MenuShortcut instance = new MenuShortcut(0);
            instance.GetHashCode();
        }

        [Test]
        public void GetKey_test_414()
        {
            MenuShortcut instance = new MenuShortcut(0);
            instance.GetKey();
        }
    }

    public class MenuShortcut
    {
        private readonly int key;
        private readonly bool usesShiftModifier;

        public MenuShortcut(int key)
        {
            this.key = key;
            this.usesShiftModifier = false;
        }

        public MenuShortcut(int key, bool usesShiftModifier)
        {
            this.key = key;
            this.usesShiftModifier = usesShiftModifier;
        }

        public int GetKey()
        {
            return key;
        }

        public bool UsesShiftModifier()
        {
            return usesShiftModifier;
        }

        public override bool Equals(object obj)
        {
            if (obj is MenuShortcut other)
            {
                return this.key == other.key && this.usesShiftModifier == other.usesShiftModifier;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 7;
            hash = 31 * hash + key;
            hash = 31 * hash + (usesShiftModifier ? 1 : 0);
            return hash;
        }

        public override string ToString()
        {
            if (usesShiftModifier)
                return "shift+" + key.ToString();
            return key.ToString();
        }
    }
}
```