```csharp
using System;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // C# implementation of Java's IntSummaryStatistics
    public class IntSummaryStatistics
    {
        private long count;
        private long sum;
        private int min = int.MaxValue;
        private int max = int.MinValue;

        public IntSummaryStatistics() { }

        public void Accept(int value)
        {
            count++;
            sum += value;
            min = Math.Min(min, value);
            max = Math.Max(max, value);
        }

        public void Combine(IntSummaryStatistics other)
        {
            count += other.count;
            sum += other.sum;
            min = Math.Min(min, other.min);
            max = Math.Max(max, other.max);
        }

        public long GetCount() => count;

        public long GetSum() => sum;

        public int GetMin() => count == 0 ? 0 : min; // Java returns Integer.MAX_VALUE if no values, but for consistency we match Java's behavior: min = Integer.MAX_VALUE when empty

        public int GetMax() => count == 0 ? 0 : max; // similarly

        public double GetAverage() => count == 0 ? 0.0 : (double)sum / count;

        public override string ToString()
        {
            // Mimics Java's IntSummaryStatistics.toString()
            return $"IntSummaryStatistics{{count={count}, sum={sum}, min={min}, max={max}, average={GetAverage():F6}}}";
        }
    }

    [TestFixture]
    public class IntSummaryStatisticsAutoTest
    {
        [Test]
        public void ToString_test_3576()
        {
            var instance = new IntSummaryStatistics();
            instance.ToString(); // just exercise, no assertion needed
        }

        [Test]
        public void Accept_test_3577()
        {
            var instance = new IntSummaryStatistics();
            instance.Accept(0); // test with a default value
        }

        [Test]
        public void GetCount_test_3578()
        {
            var instance = new IntSummaryStatistics();
            instance.GetCount();
        }

        [Test]
        public void Combine_test_3579()
        {
            var instance = new IntSummaryStatistics();
            var other = new IntSummaryStatistics();
            instance.Combine(other);
        }

        [Test]
        public void GetSum_test_3580()
        {
            var instance = new IntSummaryStatistics();
            instance.GetSum();
        }

        [Test]
        public void GetMin_test_3581()
        {
            var instance = new IntSummaryStatistics();
            instance.GetMin();
        }

        [Test]
        public void GetAverage_test_3582()
        {
            var instance = new IntSummaryStatistics();
            instance.GetAverage();
        }

        [Test]
        public void GetMax_test_3583()
        {
            var instance = new IntSummaryStatistics();
            instance.GetMax();
        }
    }
}
```