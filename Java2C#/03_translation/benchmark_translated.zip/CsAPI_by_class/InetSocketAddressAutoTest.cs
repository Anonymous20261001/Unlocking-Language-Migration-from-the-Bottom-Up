```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Mimics java.net.InetAddress minimally for InetSocketAddress
    public class InetAddress
    {
        public static InetAddress Any = new InetAddress("0.0.0.0");

        private readonly string _address;

        public InetAddress(string address)
        {
            _address = address;
        }

        public string GetHostAddress()
        {
            return _address;
        }

        public override bool Equals(object obj)
        {
            return obj is InetAddress other && _address == other._address;
        }

        public override int GetHashCode()
        {
            return _address?.GetHashCode() ?? 0;
        }

        public override string ToString()
        {
            return _address ?? "";
        }
    }

    // Mimics java.net.InetSocketAddress
    public class InetSocketAddress
    {
        private readonly string _hostname;
        private readonly int _port;
        private readonly bool _unresolved;
        private readonly InetAddress _address;

        // Constructor for wildcard address (port only)
        public InetSocketAddress(int port)
        {
            _port = port;
            _unresolved = false;
            _address = InetAddress.Any;
            _hostname = null;
        }

        // Constructor for resolved hostname and port
        public InetSocketAddress(string hostname, int port)
        {
            _hostname = hostname;
            _port = port;
            _unresolved = false;
            // Try to resolve (here we just create an InetAddress with the hostname as string)
            _address = new InetAddress(hostname);
        }

        // Static factory for unresolved address
        public static InetSocketAddress CreateUnresolved(string host, int port)
        {
            return new InetSocketAddress(host, port, true);
        }

        private InetSocketAddress(string hostname, int port, bool unresolved)
        {
            _hostname = hostname;
            _port = port;
            _unresolved = unresolved;
            _address = null;
        }

        public bool IsUnresolved()
        {
            return _unresolved;
        }

        public string GetHostString()
        {
            if (_unresolved)
                return _hostname;
            if (_address != null)
                return _address.GetHostAddress();
            return null;
        }

        public string GetHostName()
        {
            if (_unresolved)
                return _hostname;
            // In Java, if created with hostname, returns hostname; else does reverse lookup.
            // Simplified: return stored hostname or the address string.
            return _hostname ?? _address?.GetHostAddress();
        }

        public InetAddress GetAddress()
        {
            return _address;
        }

        public int GetPort()
        {
            return _port;
        }

        public override bool Equals(object obj)
        {
            if (obj is InetSocketAddress other)
            {
                if (_port != other._port)
                    return false;

                if (_unresolved && other._unresolved)
                    return _hostname == other._hostname;

                if (!_unresolved && !other._unresolved)
                    return object.Equals(_address, other._address);

                return false;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = _port;
            if (_unresolved)
                hash = hash * 31 + (_hostname?.GetHashCode() ?? 0);
            else
                hash = hash * 31 + (_address?.GetHashCode() ?? 0);
            return hash;
        }

        public override string ToString()
        {
            if (_unresolved)
                return $"{_hostname}:{_port}";
            return $"{_hostname ?? _address?.GetHostAddress()}:{_port}";
        }
    }

    [TestFixture]
    public class InetSocketAddressAutoTest
    {
        [Test]
        public void IsUnresolved_test_2590()
        {
            var instance = new InetSocketAddress(0);
            instance.IsUnresolved();
        }

        [Test]
        public void GetHostString_test_2591()
        {
            var instance = new InetSocketAddress(0);
            instance.GetHostString();
        }

        [Test]
        public void CreateUnresolved_test_2592()
        {
            var instance = new InetSocketAddress(0);
            InetSocketAddress.CreateUnresolved("host", 0);
        }

        [Test]
        public void Equals_test_2593()
        {
            var instance = new InetSocketAddress(0);
            instance.Equals(new object());
        }

        [Test]
        public void ToString_test_2594()
        {
            var instance = new InetSocketAddress(0);
            instance.ToString();
        }

        [Test]
        public void HashCode_test_2595()
        {
            var instance = new InetSocketAddress(0);
            instance.GetHashCode();
        }

        [Test]
        public void GetAddress_test_2596()
        {
            var instance = new InetSocketAddress(0);
            instance.GetAddress();
        }

        [Test]
        public void GetPort_test_2597()
        {
            var instance = new InetSocketAddress(0);
            instance.GetPort();
        }

        [Test]
        public void GetHostName_test_2598()
        {
            var instance = new InetSocketAddress(0);
            instance.GetHostName();
        }
    }
}
```