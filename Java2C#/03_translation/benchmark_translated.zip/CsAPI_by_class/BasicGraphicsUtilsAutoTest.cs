```csharp
using NUnit.Framework;

namespace generated.test
{
    // Stub classes for Java AWT/Swing types

    public class Color
    {
        public int R { get; }
        public int G { get; }
        public int B { get; }
        public int A { get; }

        public Color(int r, int g, int b) : this(255, r, g, b) { }

        public Color(int a, int r, int g, int b)
        {
            A = a;
            R = r;
            G = g;
            B = b;
        }
    }

    public abstract class Graphics
    {
        // Minimal stub – no actual drawing implementation
    }

    public abstract class Graphics2D : Graphics
    {
        // Extends Graphics
    }

    public class FontMetrics
    {
        // Stub, no implementation
    }

    public abstract class JComponent
    {
        // Base class for Swing components
    }

    public abstract class AbstractButton : JComponent
    {
        // Base class for buttons
    }

    public class Insets
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int Bottom { get; set; }
        public int Right { get; set; }

        public Insets(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    // Class under test – replicates javax.swing.plaf.basic.BasicGraphicsUtils
    public class BasicGraphicsUtils
    {
        private BasicGraphicsUtils() { } // prevent instantiation? but we allow for test

        public BasicGraphicsUtils() { }

        public static void DrawString(JComponent c, Graphics2D g, string text, float x, float y)
        {
            // Stub: no-op
        }

        public static void DrawString(Graphics g, string text, int x, int y, int underlinedChar)
        {
            // Stub: no-op
        }

        public static void DrawLoweredBezel(Graphics g, int x, int y, int w, int h,
            Color shadow, Color darkShadow, Color highlight, Color lightHighlight)
        {
            // Stub: no-op
        }

        public static void DrawEtchedRect(Graphics g, int x, int y, int w, int h,
            Color shadow, Color darkShadow, Color highlight, Color lightHighlight)
        {
            // Stub: no-op
        }

        public static Insets GetEtchedInsets()
        {
            return new Insets(0, 0, 0, 0); // default
        }

        public static void DrawGroove(Graphics g, int x, int y, int w, int h,
            Color shadow, Color highlight)
        {
            // Stub: no-op
        }

        public static Insets GetGrooveInsets()
        {
            return new Insets(0, 0, 0, 0); // default
        }

        public static void DrawBezel(Graphics g, int x, int y, int w, int h,
            bool pressed, bool isDefault, Color shadow, Color darkShadow,
            Color highlight, Color lightHighlight)
        {
            // Stub: no-op
        }

        public static void DrawDashedRect(Graphics g, int x, int y, int width, int height)
        {
            // Stub: no-op
        }

        public static string GetClippedString(JComponent c, FontMetrics fm, string text, int availableWidth)
        {
            return text; // stub – returns original
        }

        public static int GetStringWidth(JComponent c, FontMetrics fm, string text)
        {
            return 0; // stub
        }

        public static void DrawStringUnderlineCharAt(JComponent c, Graphics2D g, string text,
            int underlinedIndex, float x, float y)
        {
            // Stub: no-op
        }

        public static void DrawStringUnderlineCharAt(Graphics g, string text,
            int underlinedIndex, int x, int y)
        {
            // Stub: no-op
        }

        public static Dimension GetPreferredButtonSize(AbstractButton b, int textIconGap)
        {
            return new Dimension(0, 0); // stub
        }
    }

    // Test class
    [TestFixture]
    public class BasicGraphicsUtilsAutoTest
    {
        [Test]
        public void DrawString_test_8762(JComponent p0, Graphics2D p1, string p2, float p3, float p4)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawString(p0, p1, p2, p3, p4);
        }

        [Test]
        public void DrawString_test_8763(Graphics p0, string p1, int p2, int p3, int p4)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawString(p0, p1, p2, p3, p4);
        }

        [Test]
        public void DrawLoweredBezel_test_8764(Graphics p0, int p1, int p2, int p3, int p4,
            Color p5, Color p6, Color p7, Color p8)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawLoweredBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8);
        }

        [Test]
        public void DrawEtchedRect_test_8765(Graphics p0, int p1, int p2, int p3, int p4,
            Color p5, Color p6, Color p7, Color p8)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawEtchedRect(p0, p1, p2, p3, p4, p5, p6, p7, p8);
        }

        [Test]
        public void GetEtchedInsets_test_8766()
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.GetEtchedInsets();
        }

        [Test]
        public void DrawGroove_test_8767(Graphics p0, int p1, int p2, int p3, int p4,
            Color p5, Color p6)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawGroove(p0, p1, p2, p3, p4, p5, p6);
        }

        [Test]
        public void GetGrooveInsets_test_8768()
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.GetGrooveInsets();
        }

        [Test]
        public void DrawBezel_test_8769(Graphics p0, int p1, int p2, int p3, int p4,
            bool p5, bool p6, Color p7, Color p8, Color p9, Color p10)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawBezel(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10);
        }

        [Test]
        public void DrawDashedRect_test_8770(Graphics p0, int p1, int p2, int p3, int p4)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawDashedRect(p0, p1, p2, p3, p4);
        }

        [Test]
        public void GetClippedString_test_8771(JComponent p0, FontMetrics p1, string p2, int p3)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.GetClippedString(p0, p1, p2, p3);
        }

        [Test]
        public void GetStringWidth_test_8772(JComponent p0, FontMetrics p1, string p2)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.GetStringWidth(p0, p1, p2);
        }

        [Test]
        public void DrawStringUnderlineCharAt_test_8773(JComponent p0, Graphics2D p1, string p2,
            int p3, float p4, float p5)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawStringUnderlineCharAt(p0, p1, p2, p3, p4, p5);
        }

        [Test]
        public void DrawStringUnderlineCharAt_test_8774(Graphics p0, string p1, int p2, int p3, int p4)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.DrawStringUnderlineCharAt(p0, p1, p2, p3, p4);
        }

        [Test]
        public void GetPreferredButtonSize_test_8775(AbstractButton p0, int p1)
        {
            BasicGraphicsUtils instance = new BasicGraphicsUtils();
            BasicGraphicsUtils.GetPreferredButtonSize(p0, p1);
        }
    }
}
```