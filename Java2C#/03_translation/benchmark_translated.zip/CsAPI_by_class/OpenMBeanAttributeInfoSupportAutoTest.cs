```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    // Simplified OpenType to match Java's javax.management.openmbean.OpenType
    public class OpenType
    {
        public string TypeName { get; }

        public OpenType(string typeName)
        {
            TypeName = typeName;
        }

        public override bool Equals(object obj)
        {
            return obj is OpenType other && TypeName == other.TypeName;
        }

        public override int GetHashCode()
        {
            return TypeName?.GetHashCode() ?? 0;
        }

        public override string ToString()
        {
            return $"OpenType({TypeName})";
        }
    }

    // Simplified OpenMBeanAttributeInfoSupport to match Java's API
    public class OpenMBeanAttributeInfoSupport
    {
        private readonly string _name;
        private readonly string _description;
        private readonly OpenType _openType;
        private readonly bool _isReadable;
        private readonly bool _isWritable;
        private readonly bool _isIs;

        // Fields for default, legal, min, max values (not set by this constructor)
        private readonly object _defaultValue = null;
        private readonly IList<object> _legalValues = null;
        private readonly ComparableValue _minValue = null;
        private readonly ComparableValue _maxValue = null;

        // Helper to simulate Java's Comparable (simplified)
        private class ComparableValue : IComparable<ComparableValue>
        {
            private readonly object _value;

            public ComparableValue(object value)
            {
                _value = value;
            }

            public int CompareTo(ComparableValue other)
            {
                if (_value is IComparable c && other._value is IComparable oc)
                    return c.CompareTo(oc);
                return 0;
            }
        }

        public OpenMBeanAttributeInfoSupport(string name, string description, OpenType openType,
            bool isReadable, bool isWritable, bool isIs)
        {
            _name = name;
            _description = description;
            _openType = openType;
            _isReadable = isReadable;
            _isWritable = isWritable;
            _isIs = isIs;
        }

        public OpenType GetOpenType() => _openType;

        public bool IsValue(object p0) => false; // Simplified

        public bool HasDefaultValue() => _defaultValue != null;

        public bool HasLegalValues() => _legalValues != null;

        public bool HasMinValue() => _minValue != null;

        public bool HasMaxValue() => _maxValue != null;

        public IList<object> GetLegalValues() => _legalValues;

        public object GetMinValue() => _minValue?._value;

        public object GetMaxValue() => _maxValue?._value;

        public object GetDefaultValue() => _defaultValue;

        public override bool Equals(object obj)
        {
            if (obj is OpenMBeanAttributeInfoSupport other)
            {
                return _name == other._name &&
                       _description == other._description &&
                       Equals(_openType, other._openType) &&
                       _isReadable == other._isReadable &&
                       _isWritable == other._isWritable &&
                       _isIs == other._isIs &&
                       Equals(_defaultValue, other._defaultValue) &&
                       Equals(_legalValues, other._legalValues) &&
                       Equals(_minValue, other._minValue) &&
                       Equals(_maxValue, other._maxValue);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(_name, _description, _openType, _isReadable, _isWritable, _isIs);
        }

        public override string ToString()
        {
            return $"OpenMBeanAttributeInfoSupport(name={_name}, desc={_description})";
        }
    }

    [TestFixture]
    public class OpenMBeanAttributeInfoSupportAutoTest
    {
        [Test]
        public void GetOpenType_test_5744(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetOpenType();
        }

        [Test]
        public void IsValue_test_5745(object p0, string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.IsValue(p0);
        }

        [Test]
        public void HasDefaultValue_test_5746(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.HasDefaultValue();
        }

        [Test]
        public void HasLegalValues_test_5747(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.HasLegalValues();
        }

        [Test]
        public void HasMinValue_test_5748(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.HasMinValue();
        }

        [Test]
        public void HasMaxValue_test_5749(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.HasMaxValue();
        }

        [Test]
        public void GetLegalValues_test_5750(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetLegalValues();
        }

        [Test]
        public void GetMinValue_test_5751(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetMinValue();
        }

        [Test]
        public void GetMaxValue_test_5752(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetMaxValue();
        }

        [Test]
        public void Equals_test_5753(object p0, string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_test_5754(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.ToString();
        }

        [Test]
        public void HashCode_test_5755(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetHashCode();
        }

        [Test]
        public void GetDefaultValue_test_5756(string c0, string c1, OpenType c2, bool c3, bool c4, bool c5)
        {
            var instance = new OpenMBeanAttributeInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.GetDefaultValue();
        }
    }
}
```