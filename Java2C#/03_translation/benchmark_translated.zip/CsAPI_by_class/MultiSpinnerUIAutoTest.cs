```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// Simple stub for java.awt.Graphics
public class Graphics
{
    // No actual implementation needed for these tests
}

// Simple stub for javax.swing.JComponent
public class JComponent
{
    // No actual implementation needed for these tests
}

// Stub for javax.swing.plaf.multi.MultiSpinnerUI
public class MultiSpinnerUI
{
    public void InstallUI(JComponent c) { }
    public void UninstallUI(JComponent c) { }
    public object[] GetUIs() { return new object[0]; }
    public static MultiSpinnerUI CreateUI(JComponent c) { return new MultiSpinnerUI(); }
    public System.Drawing.Size GetMaximumSize(JComponent c) { return System.Drawing.Size.Empty; }
    public void Paint(Graphics g, JComponent c) { }
    public int GetAccessibleChildrenCount(JComponent c) { return 0; }
    public object GetAccessibleChild(JComponent c, int index) { return null; }
    public System.Drawing.Size GetPreferredSize(JComponent c) { return System.Drawing.Size.Empty; }
    public System.Drawing.Size GetMinimumSize(JComponent c) { return System.Drawing.Size.Empty; }
    public void Update(Graphics g, JComponent c) { }
    public bool Contains(JComponent c, int x, int y) { return false; }
}

[TestFixture]
public class MultiSpinnerUIAutoTest
{
    [Test]
    public void InstallUI_test_9561()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.InstallUI(p0);
    }

    [Test]
    public void UninstallUI_test_9562()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.UninstallUI(p0);
    }

    [Test]
    public void GetUIs_test_9563()
    {
        var instance = new MultiSpinnerUI();
        instance.GetUIs();
    }

    [Test]
    public void CreateUI_test_9564()
    {
        var p0 = new JComponent();
        MultiSpinnerUI.CreateUI(p0);
    }

    [Test]
    public void GetMaximumSize_test_9565()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.GetMaximumSize(p0);
    }

    [Test]
    public void Paint_test_9566()
    {
        var p0 = new Graphics();
        var p1 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.Paint(p0, p1);
    }

    [Test]
    public void GetAccessibleChildrenCount_test_9567()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.GetAccessibleChildrenCount(p0);
    }

    [Test]
    public void GetAccessibleChild_test_9568()
    {
        var p0 = new JComponent();
        var p1 = 0;
        var instance = new MultiSpinnerUI();
        instance.GetAccessibleChild(p0, p1);
    }

    [Test]
    public void GetPreferredSize_test_9569()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.GetPreferredSize(p0);
    }

    [Test]
    public void GetMinimumSize_test_9570()
    {
        var p0 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.GetMinimumSize(p0);
    }

    [Test]
    public void Update_test_9571()
    {
        var p0 = new Graphics();
        var p1 = new JComponent();
        var instance = new MultiSpinnerUI();
        instance.Update(p0, p1);
    }

    [Test]
    public void Contains_test_9572()
    {
        var p0 = new JComponent();
        var p1 = 10;
        var p2 = 20;
        var instance = new MultiSpinnerUI();
        instance.Contains(p0, p1, p2);
    }
}
```