```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    public class BasicAttributeAutoTest
    {
        [Test]
        public void Remove_Test_5955(int p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Remove(p0);
        }

        [Test]
        public void Remove_Test_5956(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Remove(p0);
        }

        [Test]
        public void Size_Test_5957(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Size();
        }

        [Test]
        public void Equals_Test_5958(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_5959(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_5960(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.GetHashCode();
        }

        [Test]
        public void Clone_Test_5961(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Clone();
        }

        [Test]
        public void Clear_Test_5962(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Clear();
        }

        [Test]
        public void Add_Test_5963(int p0, object p1, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Add(p0, p1);
        }

        [Test]
        public void Add_Test_5964(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Add(p0);
        }

        [Test]
        public void Contains_Test_5965(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Contains(p0);
        }

        [Test]
        public void Set_Test_5966(int p0, object p1, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Set(p0, p1);
        }

        [Test]
        public void IsOrdered_Test_5967(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.IsOrdered();
        }

        [Test]
        public void GetID_Test_5968(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.GetID();
        }
    }

    public class BasicAttribute : ICloneable
    {
        private readonly string _id;
        private readonly List<object> _values = new List<object>();

        public BasicAttribute(string id)
        {
            _id = id ?? throw new ArgumentNullException(nameof(id));
        }

        public string GetID() => _id;

        public bool IsOrdered() => true;

        public int Size() => _values.Count;

        public void Clear() => _values.Clear();

        public void Add(object value) => _values.Add(value);

        public void Add(int index, object value) => _values.Insert(index, value);

        public void Set(int index, object value) => _values[index] = value;

        public void Remove(int index) => _values.RemoveAt(index);

        public bool Remove(object value) => _values.Remove(value);

        public bool Contains(object value) => _values.Contains(value);

        public override bool Equals(object obj)
        {
            if (obj is BasicAttribute other)
            {
                return _id == other._id && _values.SequenceEqual(other._values);
            }
            return false;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + _id.GetHashCode();
                foreach (var val in _values)
                {
                    hash = hash * 31 + (val?.GetHashCode() ?? 0);
                }
                return hash;
            }
        }

        public override string ToString()
        {
            var vals = string.Join(", ", _values.Select(v => v?.ToString() ?? "null"));
            return $"BasicAttribute: ID={_id}, values=[{vals}]";
        }

        public object Clone()
        {
            var cloned = new BasicAttribute(_id);
            cloned._values.AddRange(_values);
            return cloned;
        }
    }
}
```