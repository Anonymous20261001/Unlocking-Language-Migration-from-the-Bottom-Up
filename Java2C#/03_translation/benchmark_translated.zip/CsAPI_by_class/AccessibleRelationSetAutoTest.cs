```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace GeneratedTest
{
    public class AccessibleRelation
    {
        public string Key { get; }

        public AccessibleRelation(string key)
        {
            Key = key;
        }

        public override bool Equals(object obj)
        {
            return obj is AccessibleRelation other && Key == other.Key;
        }

        public override int GetHashCode()
        {
            return Key?.GetHashCode() ?? 0;
        }
    }

    public class AccessibleRelationSet
    {
        private readonly Dictionary<string, AccessibleRelation> _map = new Dictionary<string, AccessibleRelation>();

        public bool Add(AccessibleRelation relation)
        {
            if (_map.ContainsKey(relation.Key))
                return false;
            _map[relation.Key] = relation;
            return true;
        }

        public bool Remove(AccessibleRelation relation)
        {
            if (relation == null || !_map.ContainsKey(relation.Key))
                return false;
            _map.Remove(relation.Key);
            return true;
        }

        public AccessibleRelation Get(string key)
        {
            _map.TryGetValue(key, out var relation);
            return relation;
        }

        public bool Contains(string key)
        {
            return _map.ContainsKey(key);
        }

        public int Size()
        {
            return _map.Count;
        }

        public void Clear()
        {
            _map.Clear();
        }

        public AccessibleRelation[] ToArray()
        {
            return _map.Values.ToArray();
        }

        public bool AddAll(AccessibleRelation[] relations)
        {
            bool changed = false;
            foreach (var rel in relations)
            {
                changed |= Add(rel);
            }
            return changed;
        }

        public override string ToString()
        {
            return string.Join(", ", _map.Keys);
        }
    }

    [TestFixture]
    public class AccessibleRelationSetAutoTest
    {
        [Test]
        public void Remove_test_5216()
        {
            AccessibleRelation p0 = new AccessibleRelation("testKey");
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(p0);
            instance.Remove(p0);
            Assert.AreEqual(0, instance.Size());
        }

        [Test]
        public void Size_test_5217()
        {
            AccessibleRelationSet instance = new AccessibleRelationSet();
            Assert.AreEqual(0, instance.Size());
            instance.Add(new AccessibleRelation("a"));
            Assert.AreEqual(1, instance.Size());
        }

        [Test]
        public void Get_test_5218()
        {
            string key = "test";
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(new AccessibleRelation(key));
            Assert.IsNotNull(instance.Get(key));
            Assert.IsNull(instance.Get("nonexistent"));
        }

        [Test]
        public void ToString_test_5219()
        {
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(new AccessibleRelation("a"));
            instance.Add(new AccessibleRelation("b"));
            string result = instance.ToString();
            Assert.IsTrue(result.Contains("a"));
            Assert.IsTrue(result.Contains("b"));
        }

        [Test]
        public void Clear_test_5220()
        {
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(new AccessibleRelation("x"));
            instance.Clear();
            Assert.AreEqual(0, instance.Size());
        }

        [Test]
        public void Add_test_5221()
        {
            AccessibleRelation p0 = new AccessibleRelation("newKey");
            AccessibleRelationSet instance = new AccessibleRelationSet();
            bool result = instance.Add(p0);
            Assert.IsTrue(result);
            Assert.AreEqual(1, instance.Size());
            // Adding same key again should return false
            Assert.IsFalse(instance.Add(new AccessibleRelation("newKey")));
        }

        [Test]
        public void ToArray_test_5222()
        {
            AccessibleRelationSet instance = new AccessibleRelationSet();
            var rel1 = new AccessibleRelation("a");
            var rel2 = new AccessibleRelation("b");
            instance.Add(rel1);
            instance.Add(rel2);
            AccessibleRelation[] arr = instance.ToArray();
            Assert.AreEqual(2, arr.Length);
            Assert.Contains(rel1, arr);
            Assert.Contains(rel2, arr);
        }

        [Test]
        public void Contains_test_5223()
        {
            string key = "existing";
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(new AccessibleRelation(key));
            Assert.IsTrue(instance.Contains(key));
            Assert.IsFalse(instance.Contains("missing"));
        }

        [Test]
        public void AddAll_test_5224()
        {
            AccessibleRelationSet instance = new AccessibleRelationSet();
            var arr = new[]
            {
                new AccessibleRelation("x"),
                new AccessibleRelation("y"),
                new AccessibleRelation("z")
            };
            bool result = instance.AddAll(arr);
            Assert.IsTrue(result);
            Assert.AreEqual(3, instance.Size());
            // Adding duplicates should return false
            Assert.IsFalse(instance.AddAll(new[] { new AccessibleRelation("x") }));
        }
    }
}
```