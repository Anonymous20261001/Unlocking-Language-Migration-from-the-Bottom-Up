```csharp
using System;
using NUnit.Framework;

namespace generated.test
{
    /// <summary>
    /// C# equivalent of javax.sound.midi.MetaMessage.
    /// </summary>
    public class MetaMessage
    {
        private byte type;
        private byte[] data;

        /// <summary>
        /// Default constructor – creates a MetaMessage with type 0 and empty data.
        /// </summary>
        public MetaMessage()
        {
            type = 0;
            data = new byte[0];
        }

        /// <summary>
        /// Creates a copy of this MetaMessage.
        /// </summary>
        /// <returns>A new MetaMessage with the same type and data.</returns>
        public object clone()
        {
            MetaMessage copy = new MetaMessage();
            copy.type = this.type;
            copy.data = (byte[])this.data.Clone();
            return copy;
        }

        /// <summary>
        /// Returns the type of this MetaMessage.
        /// </summary>
        /// <returns>An int representing the meta message type (0–127).</returns>
        public int getType()
        {
            return type;
        }

        /// <summary>
        /// Returns a copy of the data bytes of this MetaMessage.
        /// </summary>
        /// <returns>A new byte array containing the data.</returns>
        public byte[] getData()
        {
            return (byte[])data.Clone();
        }
    }

    [TestFixture]
    public class MetaMessageAutoTest
    {
        [Test]
        public void clone_test_6475()
        {
            MetaMessage instance = new MetaMessage();
            instance.clone();
        }

        [Test]
        public void getType_test_6476()
        {
            MetaMessage instance = new MetaMessage();
            instance.getType();
        }

        [Test]
        public void getData_test_6477()
        {
            MetaMessage instance = new MetaMessage();
            instance.getData();
        }
    }
}
```