```csharp
using System;
using System.Linq;
using NUnit.Framework;

namespace GeneratedTest
{
    public class EncryptionKey
    {
        private readonly byte[] key;
        private readonly int keyType;
        private bool destroyed;

        public EncryptionKey(byte[] key, int keyType)
        {
            this.key = (byte[])key.Clone();
            this.keyType = keyType;
            this.destroyed = false;
        }

        public override bool Equals(object obj)
        {
            if (obj is EncryptionKey other)
            {
                if (this.destroyed != other.destroyed)
                    return false;
                if (this.keyType != other.keyType)
                    return false;
                return Enumerable.SequenceEqual(this.key, other.key);
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = keyType;
            foreach (byte b in key)
            {
                hash = hash * 31 + b;
            }
            return hash;
        }

        public override string ToString()
        {
            return $"Kerberos key, type: {keyType}, algorithm: {GetAlgorithm()}";
        }

        public bool IsDestroyed()
        {
            return destroyed;
        }

        public byte[] GetEncoded()
        {
            if (destroyed)
                throw new InvalidOperationException("Key is destroyed");
            return (byte[])key.Clone();
        }

        public string GetFormat()
        {
            return "RAW";
        }

        public string GetAlgorithm()
        {
            return "Kerberos"; // simplified; actual mapping would depend on keyType
        }

        public int GetKeyType()
        {
            return keyType;
        }
    }

    [TestFixture]
    public class EncryptionKeyAutoTest
    {
        [Test]
        public void equals_test_6362(object p0, byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.Equals(p0);
        }

        [Test]
        public void toString_test_6363(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.ToString();
        }

        [Test]
        public void hashCode_test_6364(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.GetHashCode();
        }

        [Test]
        public void isDestroyed_test_6365(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.IsDestroyed();
        }

        [Test]
        public void getEncoded_test_6366(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.GetEncoded();
        }

        [Test]
        public void getFormat_test_6367(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.GetFormat();
        }

        [Test]
        public void getAlgorithm_test_6368(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.GetAlgorithm();
        }

        [Test]
        public void getKeyType_test_6369(byte[] c0, int c1)
        {
            EncryptionKey instance = new EncryptionKey(c0, c1);
            instance.GetKeyType();
        }
    }
}
```