```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent to java.net.PasswordAuthentication
    public class PasswordAuthentication
    {
        private readonly string userName;
        private readonly char[] password;

        public PasswordAuthentication(string userName, char[] password)
        {
            this.userName = userName ?? throw new ArgumentNullException(nameof(userName));
            this.password = password ?? throw new ArgumentNullException(nameof(password));
        }

        public string GetUserName()
        {
            return userName;
        }

        public char[] GetPassword()
        {
            return password;
        }
    }

    [TestFixture]
    public class PasswordAuthenticationAutoTest
    {
        [Test]
        public void GetUserName_test_2599()
        {
            // Simplified test – used dummy parameters since original Java test had unused parameters
            var c0 = "testUser";
            var c1 = new char[] { 'p', 'w', 'd' };
            PasswordAuthentication instance = new PasswordAuthentication(c0, c1);
            instance.GetUserName();
        }

        [Test]
        public void GetPassword_test_2600()
        {
            var c0 = "testUser";
            var c1 = new char[] { 'p', 'w', 'd' };
            PasswordAuthentication instance = new PasswordAuthentication(c0, c1);
            instance.GetPassword();
        }
    }
}
```