```csharp
using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.util.concurrent.atomic.DoubleAccumulator
    public class DoubleAccumulator
    {
        private readonly Func<double, double, double> _accumulatorFunction;
        private readonly double _identity;
        private double _current;
        private readonly object _lock = new object();

        public DoubleAccumulator(Func<double, double, double> accumulatorFunction, double identity)
        {
            _accumulatorFunction = accumulatorFunction ?? throw new ArgumentNullException(nameof(accumulatorFunction));
            _identity = identity;
            _current = identity;
        }

        public void Accumulate(double x)
        {
            lock (_lock)
            {
                _current = _accumulatorFunction(_current, x);
            }
        }

        public double Get()
        {
            lock (_lock)
            {
                return _current;
            }
        }

        public double GetThenReset()
        {
            lock (_lock)
            {
                double result = _current;
                _current = _identity;
                return result;
            }
        }

        public void Reset()
        {
            lock (_lock)
            {
                _current = _identity;
            }
        }

        public override string ToString()
        {
            return Get().ToString();
        }

        public int IntValue()
        {
            return (int)Get();
        }

        public long LongValue()
        {
            return (long)Get();
        }

        public float FloatValue()
        {
            return (float)Get();
        }

        public double DoubleValue()
        {
            return Get();
        }
    }

    [TestFixture]
    public class DoubleAccumulatorAutoTest
    {
        [Test]
        public void Accumulate_Test_4945()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            double p0 = 5.0;
            instance.Accumulate(p0);
        }

        [Test]
        public void GetThenReset_Test_4946()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.GetThenReset();
        }

        [Test]
        public void Reset_Test_4947()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.Reset();
        }

        [Test]
        public void Get_Test_4948()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.Get();
        }

        [Test]
        public void ToString_Test_4949()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.ToString();
        }

        [Test]
        public void IntValue_Test_4950()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.IntValue();
        }

        [Test]
        public void LongValue_Test_4951()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.LongValue();
        }

        [Test]
        public void FloatValue_Test_4952()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.FloatValue();
        }

        [Test]
        public void DoubleValue_Test_4953()
        {
            Func<double, double, double> c0 = (a, b) => a + b;
            double c1 = 0.0;
            var instance = new DoubleAccumulator(c0, c1);
            instance.DoubleValue();
        }
    }
}
```