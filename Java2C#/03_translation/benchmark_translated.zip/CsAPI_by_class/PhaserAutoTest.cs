```csharp
using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.util.concurrent.Phaser
    public class Phaser
    {
        private int parties;
        private int arrived;
        private int phase;
        private bool terminated;
        private readonly Phaser parent;
        private readonly Phaser root;
        private readonly object lockObj = new object();
        private readonly ManualResetEventSlim phaseEvent = new ManualResetEventSlim(false);

        public Phaser() : this(null, 0) { }

        public Phaser(int parties) : this(null, parties) { }

        public Phaser(Phaser parent, int parties)
        {
            this.parent = parent;
            this.root = parent == null ? this : parent.root;
            this.parties = parties;
            arrived = 0;
            phase = 0;
            terminated = false;
        }

        public int GetPhase()
        {
            lock (lockObj)
                return phase;
        }

        public int Arrive()
        {
            lock (lockObj)
            {
                if (terminated) return -1;
                if (parties == 0)
                    throw new InvalidOperationException("No registered parties");
                int unarrived = parties - arrived;
                if (unarrived <= 0)
                    throw new InvalidOperationException("No unarrived parties");
                arrived++;
                int currentPhase = phase;
                if (arrived == parties)
                {
                    // advance to next phase
                    phase++;
                    arrived = 0;
                    phaseEvent.Set();
                    phaseEvent.Reset();
                }
                return currentPhase;
            }
        }

        public int ArriveAndAwaitAdvance()
        {
            int currentPhase;
            lock (lockObj)
            {
                if (terminated) return -1;
                if (parties == 0)
                    throw new InvalidOperationException("No registered parties");
                int unarrived = parties - arrived;
                if (unarrived <= 0)
                    throw new InvalidOperationException("No unarrived parties");
                arrived++;
                currentPhase = phase;
                if (arrived == parties)
                {
                    // all arrived, advance immediately
                    phase++;
                    arrived = 0;
                    phaseEvent.Set();
                    phaseEvent.Reset();
                    return phase; // return the new phase
                }
            }
            // wait for phase to advance
            WaitForPhaseAdvance(currentPhase);
            return GetPhase();
        }

        public int AwaitAdvance(int phaseArg)
        {
            lock (lockObj)
            {
                if (terminated) return -1;
                if (phaseArg != phase) return phase; // already advanced
            }
            WaitForPhaseAdvance(phaseArg);
            return GetPhase();
        }

        private void WaitForPhaseAdvance(int oldPhase)
        {
            while (true)
            {
                phaseEvent.Wait(100); // small timeout to re‑check condition
                lock (lockObj)
                {
                    if (terminated) return;
                    if (phase != oldPhase) return;
                }
            }
        }

        public void BulkRegister(int parties)
        {
            if (parties < 0)
                throw new ArgumentException("parties cannot be negative", nameof(parties));
            lock (lockObj)
            {
                this.parties += parties;
            }
        }

        public int ArriveAndDeregister()
        {
            int currentPhase;
            lock (lockObj)
            {
                if (terminated) return -1;
                if (parties == 0)
                    throw new InvalidOperationException("No registered parties");
                int unarrived = parties - arrived;
                if (unarrived <= 0)
                    throw new InvalidOperationException("No unarrived parties");
                arrived++;
                currentPhase = phase;
                if (arrived == parties)
                {
                    phase++;
                    arrived = 0;
                    phaseEvent.Set();
                    phaseEvent.Reset();
                }
                // deregister after arrival
                parties--;
                return currentPhase;
            }
        }

        public void ForceTermination()
        {
            lock (lockObj)
            {
                terminated = true;
                phaseEvent.Set(); // wake any waiters
            }
        }

        public int GetRegisteredParties()
        {
            lock (lockObj)
                return parties;
        }

        public int GetArrivedParties()
        {
            lock (lockObj)
                return arrived;
        }

        public int GetUnarrivedParties()
        {
            lock (lockObj)
                return parties - arrived;
        }

        public void Register()
        {
            BulkRegister(1);
        }

        public Phaser GetParent()
        {
            return parent;
        }

        public bool IsTerminated()
        {
            lock (lockObj)
                return terminated;
        }

        public Phaser GetRoot()
        {
            return root;
        }

        public override string ToString()
        {
            return base.ToString(); // simple stub
        }
    }

    // Test class (NUnit)
    [TestFixture]
    public class PhaserAutoTest
    {
        [Test]
        public void GetPhase_Test_4600()
        {
            Phaser instance = new Phaser();
            instance.GetPhase();
        }

        [Test]
        public void ArriveAndAwaitAdvance_Test_4601()
        {
            Phaser instance = new Phaser();
            instance.ArriveAndAwaitAdvance();
        }

        [Test]
        public void BulkRegister_Test_4602([Random(1, 10, 1)] int p0)
        {
            Phaser instance = new Phaser();
            instance.BulkRegister(p0);
        }

        [Test]
        public void Arrive_Test_4603()
        {
            Phaser instance = new Phaser();
            instance.Arrive();
        }

        [Test]
        public void ArriveAndDeregister_Test_4604()
        {
            Phaser instance = new Phaser();
            instance.ArriveAndDeregister();
        }

        [Test]
        public void AwaitAdvance_Test_4605([Random(0, 5, 1)] int p0)
        {
            Phaser instance = new Phaser();
            instance.AwaitAdvance(p0);
        }

        [Test]
        public void ForceTermination_Test_4606()
        {
            Phaser instance = new Phaser();
            instance.ForceTermination();
        }

        [Test]
        public void GetRegisteredParties_Test_4607()
        {
            Phaser instance = new Phaser();
            instance.GetRegisteredParties();
        }

        [Test]
        public void GetArrivedParties_Test_4608()
        {
            Phaser instance = new Phaser();
            instance.GetArrivedParties();
        }

        [Test]
        public void GetUnarrivedParties_Test_4609()
        {
            Phaser instance = new Phaser();
            instance.GetUnarrivedParties();
        }

        [Test]
        public void ToString_Test_4610()
        {
            Phaser instance = new Phaser();
            instance.ToString();
        }

        [Test]
        public void Register_Test_4611()
        {
            Phaser instance = new Phaser();
            instance.Register();
        }

        [Test]
        public void GetParent_Test_4612()
        {
            Phaser instance = new Phaser();
            instance.GetParent();
        }

        [Test]
        public void IsTerminated_Test_4613()
        {
            Phaser instance = new Phaser();
            instance.IsTerminated();
        }

        [Test]
        public void GetRoot_Test_4614()
        {
            Phaser instance = new Phaser();
            instance.GetRoot();
        }
    }
}
```