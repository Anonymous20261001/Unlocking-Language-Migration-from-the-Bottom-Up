```csharp
using System;
using System.IO;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of Java's java.io.DataOutputStream.
    /// Wraps a Stream and tracks the number of bytes written.
    /// Provides a Size() method that returns the total number of bytes written.
    /// </summary>
    public class DataOutputStream : IDisposable
    {
        private readonly Stream _stream;
        private int _written;
        private bool _disposed;

        public DataOutputStream(Stream stream)
        {
            _stream = stream ?? throw new ArgumentNullException(nameof(stream));
            _written = 0;
        }

        /// <summary>Returns the total number of bytes written to this stream so far.</summary>
        public int Size() => _written;

        public void Write(byte[] buffer, int offset, int count)
        {
            _stream.Write(buffer, offset, count);
            _written += count;
        }

        public void Write(int b) // writes a single byte (low 8 bits)
        {
            _stream.WriteByte((byte)b);
            _written++;
        }

        public void WriteByte(byte value)
        {
            _stream.WriteByte(value);
            _written++;
        }

        public void Flush() => _stream.Flush();

        public void Close() => _stream.Close();

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _stream?.Dispose();
                }
                _disposed = true;
            }
        }
    }

    [TestFixture]
    public class DataOutputStreamAutoTest
    {
        /// <summary>
        /// Corresponds to: void size_test_1729(OutputStream c0)
        /// In C# we create a MemoryStream inside the test method as a substitute for the injected parameter.
        /// </summary>
        [Test]
        public void Size_Test_1729()
        {
            using var stream = new MemoryStream();
            var instance = new DataOutputStream(stream);
            instance.Size(); // Method call only; no assertion in the original test.
        }
    }
}
```