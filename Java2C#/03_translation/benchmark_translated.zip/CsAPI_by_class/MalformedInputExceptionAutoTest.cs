```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.nio.charset.MalformedInputException
    public class MalformedInputException : Exception
    {
        private readonly int _inputLength;

        public MalformedInputException(int inputLength)
        {
            _inputLength = inputLength;
        }

        public int GetInputLength()
        {
            return _inputLength;
        }

        public override string Message => "Input length = " + _inputLength;
    }

    [TestFixture]
    public class MalformedInputExceptionAutoTest
    {
        [Test]
        public void GetInputLength_Test_2642()
        {
            int c0 = 5; // sample value, could be any int
            MalformedInputException instance = new MalformedInputException(c0);
            instance.GetInputLength();
        }

        [Test]
        public void GetMessage_Test_2643()
        {
            int c0 = 5; // sample value, could be any int
            MalformedInputException instance = new MalformedInputException(c0);
            instance.Message;
        }
    }
}
```