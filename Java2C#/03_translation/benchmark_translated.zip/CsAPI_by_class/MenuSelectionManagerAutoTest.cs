```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GeneratedTest
{
    // Minimal equivalents for Java AWT/Swing classes
    public class Component { }

    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point() { }
        public Point(int x, int y) { X = x; Y = y; }
    }

    public class KeyEvent
    {
        // Placeholder – no actual functionality needed for these tests
    }

    public class MouseEvent
    {
        // Placeholder
    }

    public interface ChangeListener
    {
        void StateChanged(object sender, EventArgs e);
    }

    public class MenuElement
    {
        // Minimal implementation – not used in tests beyond passing as array
    }

    public class MenuSelectionManager
    {
        private static MenuSelectionManager _defaultManager;
        private List<ChangeListener> _changeListeners = new List<ChangeListener>();

        public MenuElement[] GetSelectedPath()
        {
            return null;
        }

        public bool IsComponentPartOfCurrentMenu(Component component)
        {
            return false;
        }

        public Component ComponentForPoint(Component source, Point point)
        {
            return null;
        }

        public void ClearSelectedPath()
        {
        }

        public void AddChangeListener(ChangeListener listener)
        {
            _changeListeners.Add(listener);
        }

        public void RemoveChangeListener(ChangeListener listener)
        {
            _changeListeners.Remove(listener);
        }

        public ChangeListener[] GetChangeListeners()
        {
            return _changeListeners.ToArray();
        }

        public static MenuSelectionManager DefaultManager()
        {
            if (_defaultManager == null)
                _defaultManager = new MenuSelectionManager();
            return _defaultManager;
        }

        public void SetSelectedPath(MenuElement[] path)
        {
        }

        public void ProcessKeyEvent(KeyEvent evt)
        {
        }

        public void ProcessMouseEvent(MouseEvent evt)
        {
        }
    }

    [TestFixture]
    public class MenuSelectionManagerAutoTest
    {
        [Test]
        public void GetSelectedPath_Test_8197()
        {
            var instance = new MenuSelectionManager();
            instance.GetSelectedPath();
        }

        [Test]
        public void IsComponentPartOfCurrentMenu_Test_8198()
        {
            var instance = new MenuSelectionManager();
            instance.IsComponentPartOfCurrentMenu(new Component());
        }

        [Test]
        public void ComponentForPoint_Test_8199()
        {
            var instance = new MenuSelectionManager();
            instance.ComponentForPoint(new Component(), new Point());
        }

        [Test]
        public void ClearSelectedPath_Test_8200()
        {
            var instance = new MenuSelectionManager();
            instance.ClearSelectedPath();
        }

        [Test]
        public void AddChangeListener_Test_8201()
        {
            var instance = new MenuSelectionManager();
            instance.AddChangeListener(new TestChangeListener());
        }

        [Test]
        public void RemoveChangeListener_Test_8202()
        {
            var instance = new MenuSelectionManager();
            instance.RemoveChangeListener(new TestChangeListener());
        }

        [Test]
        public void GetChangeListeners_Test_8203()
        {
            var instance = new MenuSelectionManager();
            instance.GetChangeListeners();
        }

        [Test]
        public void DefaultManager_Test_8204()
        {
            var instance = new MenuSelectionManager();
            MenuSelectionManager.DefaultManager();
        }

        [Test]
        public void SetSelectedPath_Test_8205()
        {
            var instance = new MenuSelectionManager();
            instance.SetSelectedPath(new MenuElement[] { });
        }

        [Test]
        public void ProcessKeyEvent_Test_8206()
        {
            var instance = new MenuSelectionManager();
            instance.ProcessKeyEvent(new KeyEvent());
        }

        [Test]
        public void ProcessMouseEvent_Test_8207()
        {
            var instance = new MenuSelectionManager();
            instance.ProcessMouseEvent(new MouseEvent());
        }

        // Helper class to satisfy ChangeListener interface for tests
        private class TestChangeListener : ChangeListener
        {
            public void StateChanged(object sender, EventArgs e) { }
        }
    }
}
```