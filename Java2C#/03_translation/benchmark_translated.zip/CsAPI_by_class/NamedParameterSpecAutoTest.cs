```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class NamedParameterSpec
    {
        private string name;

        public NamedParameterSpec(string name)
        {
            this.name = name;
        }

        public string GetName()
        {
            return name;
        }
    }

    [TestFixture]
    public class NamedParameterSpecAutoTest
    {
        [TestCase("test")]
        public void GetName_test_2897(string c0)
        {
            NamedParameterSpec instance = new NamedParameterSpec(c0);
            instance.GetName();
        }
    }
}
```