```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.print.attribute.standard.CopiesSupported.
    /// Represents a supported range of copies (e.g., for a printer).
    /// This implementation mirrors the Java behavior for the tests provided.
    /// </summary>
    public class CopiesSupported
    {
        private int _lower;
        private int _upper;

        /// <summary>
        /// Constructs a CopiesSupported with a single supported value.
        /// </summary>
        /// <param name="value">The single supported copy value.</param>
        public CopiesSupported(int value)
        {
            _lower = value;
            _upper = value;
        }

        /// <summary>
        /// Constructs a CopiesSupported with a range of supported values.
        /// </summary>
        /// <param name="lower">Lower bound of the supported copy range.</param>
        /// <param name="upper">Upper bound of the supported copy range.</param>
        public CopiesSupported(int lower, int upper)
        {
            _lower = lower;
            _upper = upper;
        }

        /// <summary>
        /// Returns the category of this attribute (the type itself).
        /// Equivalent to Java's getCategory() returning a Class instance.
        /// </summary>
        public Type GetCategory()
        {
            return typeof(CopiesSupported);
        }

        /// <summary>
        /// Returns the name of the attribute as defined in Java.
        /// </summary>
        public string GetName()
        {
            return "copies-supported";
        }

        /// <summary>
        /// Compares this CopiesSupported to another object.
        /// Two CopiesSupported objects are equal if their lower and upper bounds match.
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            CopiesSupported other = (CopiesSupported)obj;
            return _lower == other._lower && _upper == other._upper;
        }

        /// <summary>
        /// Returns a hash code for this instance.
        /// </summary>
        public override int GetHashCode()
        {
            return _lower.GetHashCode() ^ _upper.GetHashCode();
        }
    }

    /// <summary>
    /// Test class corresponding to the provided Java test file.
    /// Each test method exercises one API method of CopiesSupported.
    /// </summary>
    [TestFixture]
    public class CopiesSupportedAutoTest
    {
        [Test]
        public void GetCategory_Test_6100()
        {
            // Using a fixed integer value; original Java test had int c0 parameter.
            int c0 = 10;
            CopiesSupported instance = new CopiesSupported(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6101()
        {
            int c0 = 10;
            CopiesSupported instance = new CopiesSupported(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6102()
        {
            // Using null as a sample object; original Java test had Object p0 parameter.
            object p0 = null;
            int c0 = 10;
            CopiesSupported instance = new CopiesSupported(c0);
            instance.Equals(p0);
        }
    }
}
```