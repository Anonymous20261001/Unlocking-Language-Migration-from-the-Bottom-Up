```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class DoubleSummaryStatistics
    {
        private long _count;
        private double _sum;
        private double _min = double.PositiveInfinity;
        private double _max = double.NegativeInfinity;

        public void Accept(double value)
        {
            if (_count == 0)
            {
                _min = value;
                _max = value;
            }
            else
            {
                if (value < _min) _min = value;
                if (value > _max) _max = value;
            }
            _sum += value;
            _count++;
        }

        public void Combine(DoubleSummaryStatistics other)
        {
            if (other._count == 0) return;
            if (_count == 0)
            {
                _count = other._count;
                _sum = other._sum;
                _min = other._min;
                _max = other._max;
            }
            else
            {
                _count += other._count;
                _sum += other._sum;
                _min = Math.Min(_min, other._min);
                _max = Math.Max(_max, other._max);
            }
        }

        public long GetCount() => _count;

        public double GetSum() => _sum;

        public double GetMin() => _min;

        public double GetMax() => _max;

        public double GetAverage() => _count == 0 ? 0.0 : _sum / _count;

        public override string ToString() =>
            $"DoubleSummaryStatistics{{count={_count}, sum={_sum}, min={_min}, average={GetAverage()}, max={_max}}}";
    }

    [TestFixture]
    public class DoubleSummaryStatisticsAutoTest
    {
        [Test]
        public void ToString_test_3417()
        {
            var instance = new DoubleSummaryStatistics();
            instance.ToString();
        }

        [Test]
        public void Accept_test_3418()
        {
            var instance = new DoubleSummaryStatistics();
            instance.Accept(1.5);
        }

        [Test]
        public void GetCount_test_3419()
        {
            var instance = new DoubleSummaryStatistics();
            instance.GetCount();
        }

        [Test]
        public void Combine_test_3420()
        {
            var instance = new DoubleSummaryStatistics();
            var other = new DoubleSummaryStatistics();
            other.Accept(3.0);
            other.Accept(7.0);
            instance.Combine(other);
        }

        [Test]
        public void GetSum_test_3421()
        {
            var instance = new DoubleSummaryStatistics();
            instance.GetSum();
        }

        [Test]
        public void GetMin_test_3422()
        {
            var instance = new DoubleSummaryStatistics();
            instance.GetMin();
        }

        [Test]
        public void GetAverage_test_3423()
        {
            var instance = new DoubleSummaryStatistics();
            instance.GetAverage();
        }

        [Test]
        public void GetMax_test_3424()
        {
            var instance = new DoubleSummaryStatistics();
            instance.GetMax();
        }
    }
}
```