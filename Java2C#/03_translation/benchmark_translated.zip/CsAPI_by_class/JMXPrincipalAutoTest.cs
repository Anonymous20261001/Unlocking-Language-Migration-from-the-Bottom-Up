```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.management.remote.JMXPrincipal
    public class JMXPrincipal
    {
        private readonly string _name;

        public JMXPrincipal(string name)
        {
            // Mimic Java's behavior: store name as given (allow null for compatibility)
            _name = name;
        }

        public string GetName()
        {
            return _name;
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            if (obj == null || GetType() != obj.GetType())
                return false;
            JMXPrincipal other = (JMXPrincipal)obj;
            return _name == other._name;
        }

        public override int GetHashCode()
        {
            return _name != null ? _name.GetHashCode() : 0;
        }

        public override string ToString()
        {
            return GetName();
        }
    }

    [TestFixture]
    public class JMXPrincipalAutoTest
    {
        [Test]
        public void GetName_Test_5834()
        {
            string c0 = "testUser"; // default value
            JMXPrincipal instance = new JMXPrincipal(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_5835()
        {
            object p0 = null; // default object value
            string c0 = "testUser";
            JMXPrincipal instance = new JMXPrincipal(c0);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_5836()
        {
            string c0 = "testUser";
            JMXPrincipal instance = new JMXPrincipal(c0);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_5837()
        {
            string c0 = "testUser";
            JMXPrincipal instance = new JMXPrincipal(c0);
            instance.GetHashCode();
        }
    }
}
```