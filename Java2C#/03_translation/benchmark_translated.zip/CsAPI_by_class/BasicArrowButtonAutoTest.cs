```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.swing.plaf.basic.BasicArrowButton
    public class BasicArrowButton
    {
        private int direction;

        public BasicArrowButton(int direction)
        {
            this.direction = direction;
        }

        public void SetDirection(int dir)
        {
            direction = dir;
        }

        public void PaintTriangle(Graphics g, int x, int y, int size, int direction, bool isEnabled)
        {
            // Stub implementation – does nothing, matching the original's no‑op in tests
        }

        public int GetDirection()
        {
            return direction;
        }

        public Size GetMaximumSize()
        {
            return Size.Empty; // arbitrary default
        }

        public void Paint(Graphics g)
        {
            // Stub – no actual painting
        }

        public Size GetPreferredSize()
        {
            return Size.Empty;
        }

        public Size GetMinimumSize()
        {
            return Size.Empty;
        }

        public bool IsFocusTraversable()
        {
            return true; // typical default for components
        }
    }

    [TestFixture]
    public class BasicArrowButtonAutoTest
    {
        [Test]
        public void SetDirection_test_8610()
        {
            int p0 = 0;   // dummy value
            int c0 = 0;   // dummy value
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.SetDirection(p0);
        }

        [Test]
        public void PaintTriangle_test_8611()
        {
            Graphics p0 = null; // dummy (would be real in actual test)
            int p1 = 0;
            int p2 = 0;
            int p3 = 0;
            int p4 = 0;
            bool p5 = false;
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.PaintTriangle(p0, p1, p2, p3, p4, p5);
        }

        [Test]
        public void GetDirection_test_8612()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.GetDirection();
        }

        [Test]
        public void GetMaximumSize_test_8613()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.GetMaximumSize();
        }

        [Test]
        public void Paint_test_8614()
        {
            Graphics p0 = null;
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.Paint(p0);
        }

        [Test]
        public void GetPreferredSize_test_8615()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.GetPreferredSize();
        }

        [Test]
        public void GetMinimumSize_test_8616()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.GetMinimumSize();
        }

        [Test]
        public void IsFocusTraversable_test_8617()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.IsFocusTraversable();
        }
    }
}
```