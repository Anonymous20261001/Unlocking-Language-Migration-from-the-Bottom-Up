```csharp
using System;
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.security.spec.ECParameterSpec
    // Simplified for testing purposes.
    public class ECParameterSpec
    {
        public ECParameterSpec()
        {
            // No required initialization for test usage.
        }
    }

    // C# equivalent of java.security.spec.ECPrivateKeySpec
    public class ECPrivateKeySpec
    {
        private readonly BigInteger s;
        private readonly ECParameterSpec paramsSpec;

        public ECPrivateKeySpec(BigInteger s, ECParameterSpec paramsSpec)
        {
            this.s = s ?? throw new ArgumentNullException(nameof(s));
            this.paramsSpec = paramsSpec ?? throw new ArgumentNullException(nameof(paramsSpec));
        }

        public ECParameterSpec GetParams()
        {
            return paramsSpec;
        }

        public BigInteger GetS()
        {
            return s;
        }
    }

    [TestFixture]
    public class ECPrivateKeySpecAutoTest
    {
        [Test]
        public void GetParams_Test_2877()
        {
            // Arrange
            BigInteger c0 = BigInteger.Zero;
            ECParameterSpec c1 = new ECParameterSpec();
            ECPrivateKeySpec instance = new ECPrivateKeySpec(c0, c1);

            // Act
            ECParameterSpec result = instance.GetParams();

            // Assert (no assertion in original test, just verifying no exception is thrown)
        }

        [Test]
        public void GetS_Test_2878()
        {
            // Arrange
            BigInteger c0 = BigInteger.One;
            ECParameterSpec c1 = new ECParameterSpec();
            ECPrivateKeySpec instance = new ECPrivateKeySpec(c0, c1);

            // Act
            BigInteger result = instance.GetS();

            // Assert (no assertion in original test)
        }
    }
}
```