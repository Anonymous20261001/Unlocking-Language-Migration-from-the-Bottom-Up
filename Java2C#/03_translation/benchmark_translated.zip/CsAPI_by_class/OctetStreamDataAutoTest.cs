```csharp
using System.IO;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of javax.xml.crypto.OctetStreamData
    public class OctetStreamData
    {
        private readonly Stream? _octetStream;
        private readonly string? _uri;
        private readonly string? _mimeType;

        public OctetStreamData(Stream octetStream)
            : this(octetStream, null, null)
        {
        }

        public OctetStreamData(Stream octetStream, string? uri, string? mimeType)
        {
            _octetStream = octetStream;
            _uri = uri;
            _mimeType = mimeType;
        }

        public Stream? GetOctetStream() => _octetStream;
        public string? GetURI() => _uri;
        public string? GetMimeType() => _mimeType;
    }

    // Test class – each method name matches the Java original
    public class OctetStreamDataAutoTest
    {
        [Test]
        public void GetMimeType_Test_10865()
        {
            // Provide a dummy stream as input (equivalent to the Java InputStream parameter)
            using var c0 = new MemoryStream();
            var instance = new OctetStreamData(c0);
            instance.GetMimeType();
        }

        [Test]
        public void GetOctetStream_Test_10866()
        {
            using var c0 = new MemoryStream();
            var instance = new OctetStreamData(c0);
            instance.GetOctetStream();
        }

        [Test]
        public void GetURI_Test_10867()
        {
            using var c0 = new MemoryStream();
            var instance = new OctetStreamData(c0);
            instance.GetURI();
        }
    }
}
```