```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class IvParameterSpecAutoTest
    {
        [Test]
        public void GetIV_Test_5249()
        {
            byte[] c0 = new byte[] { 0x00, 0x01, 0x02 }; // sample initialization vector
            IvParameterSpec instance = new IvParameterSpec(c0);
            instance.GetIV();
        }
    }

    /// <summary>
    /// C# equivalent of Java's javax.crypto.spec.IvParameterSpec.
    /// Wraps an initialization vector (IV) as a byte array.
    /// </summary>
    public class IvParameterSpec
    {
        private readonly byte[] iv;

        /// <summary>
        /// Creates a new IvParameterSpec with the given IV bytes.
        /// </summary>
        /// <param name="iv">The IV bytes (not copied).</param>
        public IvParameterSpec(byte[] iv)
        {
            this.iv = iv;
        }

        /// <summary>
        /// Returns the initialization vector (the same array reference).
        /// </summary>
        /// <returns>The IV byte array.</returns>
        public byte[] GetIV()
        {
            return iv;
        }
    }
}
```