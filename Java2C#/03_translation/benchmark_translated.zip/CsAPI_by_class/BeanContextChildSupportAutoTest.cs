```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// -------------------------------------------------------------------------
// Custom event classes (equivalent to Java beans classes)
// -------------------------------------------------------------------------

public class PropertyChangeEvent : EventArgs
{
    public object Source { get; }
    public string PropertyName { get; }
    public object OldValue { get; }
    public object NewValue { get; }

    public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
    {
        Source = source;
        PropertyName = propertyName;
        OldValue = oldValue;
        NewValue = newValue;
    }
}

public class PropertyVetoException : Exception
{
    public PropertyChangeEvent Event { get; }

    public PropertyVetoException(string message, PropertyChangeEvent evt) : base(message)
    {
        Event = evt;
    }
}

public interface PropertyChangeListener
{
    void PropertyChange(PropertyChangeEvent evt);
}

public interface VetoableChangeListener
{
    void VetoableChange(PropertyChangeEvent evt); // throws PropertyVetoException
}

// -------------------------------------------------------------------------
// BeanContext related classes (stubs)
// -------------------------------------------------------------------------

public class BeanContext { }

public class BeanContextServiceAvailableEvent
{
    // Stub – add properties as needed
    public BeanContextServiceAvailableEvent() { }
}

public class BeanContextServiceRevokedEvent
{
    // Stub – add properties as needed
    public BeanContextServiceRevokedEvent() { }
}

// -------------------------------------------------------------------------
// The main class under test
// -------------------------------------------------------------------------

public class BeanContextChildSupport
{
    private BeanContext _beanContext;
    private BeanContextChildSupport _beanContextChildPeer;
    private bool _delegated;
    private readonly Dictionary<string, List<PropertyChangeListener>> _propertyChangeListeners = new Dictionary<string, List<PropertyChangeListener>>();
    private readonly Dictionary<string, List<VetoableChangeListener>> _vetoableChangeListeners = new Dictionary<string, List<VetoableChangeListener>>();

    public BeanContextChildSupport()
    {
        _beanContextChildPeer = null; // default in Java is null
        _delegated = false;
    }

    public void ValidatePendingSetBeanContext(BeanContext p0)
    {
        // In Java this method validates and may throw PropertyVetoException,
        // but for the test we simply store the context.
        _beanContext = p0;
    }

    public BeanContext GetBeanContext()
    {
        return _beanContext;
    }

    public void ServiceRevoked(BeanContextServiceRevokedEvent p0)
    {
        // Stub – no action required by test
    }

    public void ServiceAvailable(BeanContextServiceAvailableEvent p0)
    {
        // Stub – no action required by test
    }

    public BeanContextChildSupport GetBeanContextChildPeer()
    {
        return _beanContextChildPeer;
    }

    public bool IsDelegated()
    {
        return _delegated;
    }

    public void FirePropertyChange(string propertyName, object oldValue, object newValue)
    {
        var evt = new PropertyChangeEvent(this, propertyName, oldValue, newValue);
        if (_propertyChangeListeners.TryGetValue(propertyName, out var listeners))
        {
            foreach (var listener in listeners)
            {
                listener.PropertyChange(evt);
            }
        }
    }

    public void AddPropertyChangeListener(string propertyName, PropertyChangeListener listener)
    {
        if (!_propertyChangeListeners.ContainsKey(propertyName))
            _propertyChangeListeners[propertyName] = new List<PropertyChangeListener>();
        _propertyChangeListeners[propertyName].Add(listener);
    }

    public void RemovePropertyChangeListener(string propertyName, PropertyChangeListener listener)
    {
        if (_propertyChangeListeners.TryGetValue(propertyName, out var listeners))
        {
            listeners.Remove(listener);
            if (listeners.Count == 0)
                _propertyChangeListeners.Remove(propertyName);
        }
    }

    public void AddVetoableChangeListener(string propertyName, VetoableChangeListener listener)
    {
        if (!_vetoableChangeListeners.ContainsKey(propertyName))
            _vetoableChangeListeners[propertyName] = new List<VetoableChangeListener>();
        _vetoableChangeListeners[propertyName].Add(listener);
    }

    public void RemoveVetoableChangeListener(string propertyName, VetoableChangeListener listener)
    {
        if (_vetoableChangeListeners.TryGetValue(propertyName, out var listeners))
        {
            listeners.Remove(listener);
            if (listeners.Count == 0)
                _vetoableChangeListeners.Remove(propertyName);
        }
    }
}

// -------------------------------------------------------------------------
// Test class (mirrors the Java test)
// -------------------------------------------------------------------------

[TestFixture]
public class BeanContextChildSupportAutoTest
{
    [Test]
    public void validatePendingSetBeanContext_test_1631(BeanContext p0)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.ValidatePendingSetBeanContext(p0);
    }

    [Test]
    public void getBeanContext_test_1632()
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.GetBeanContext();
    }

    [Test]
    public void serviceRevoked_test_1633(BeanContextServiceRevokedEvent p0)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.ServiceRevoked(p0);
    }

    [Test]
    public void serviceAvailable_test_1634(BeanContextServiceAvailableEvent p0)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.ServiceAvailable(p0);
    }

    [Test]
    public void getBeanContextChildPeer_test_1635()
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.GetBeanContextChildPeer();
    }

    [Test]
    public void isDelegated_test_1636()
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.IsDelegated();
    }

    [Test]
    public void firePropertyChange_test_1637(string p0, object p1, object p2)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.FirePropertyChange(p0, p1, p2);
    }

    [Test]
    public void addPropertyChangeListener_test_1638(string p0, PropertyChangeListener p1)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.AddPropertyChangeListener(p0, p1);
    }

    [Test]
    public void removePropertyChangeListener_test_1639(string p0, PropertyChangeListener p1)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.RemovePropertyChangeListener(p0, p1);
    }

    [Test]
    public void addVetoableChangeListener_test_1640(string p0, VetoableChangeListener p1)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.AddVetoableChangeListener(p0, p1);
    }

    [Test]
    public void removeVetoableChangeListener_test_1641(string p0, VetoableChangeListener p1)
    {
        BeanContextChildSupport instance = new BeanContextChildSupport();
        instance.RemoveVetoableChangeListener(p0, p1);
    }
}
```