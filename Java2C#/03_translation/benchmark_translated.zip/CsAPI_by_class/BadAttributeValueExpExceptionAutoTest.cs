```csharp
using System;
using NUnit.Framework;

/// <summary>
/// C# equivalent of javax.management.BadAttributeValueExpException.
/// Stores an object value and provides a string representation.
/// </summary>
public class BadAttributeValueExpException : Exception
{
    private readonly object val;

    public BadAttributeValueExpException(object val)
    {
        this.val = val;
    }

    /// <summary>
    /// Returns "BadAttributeValueExpException: " followed by the string representation
    /// of the stored value (or empty string if null).
    /// </summary>
    public override string ToString()
    {
        return "BadAttributeValueExpException: " + (val?.ToString() ?? "");
    }
}

[TestFixture]
public class BadAttributeValueExpExceptionAutoTest
{
    [Test]
    public void toString_test_5545(object c0)
    {
        BadAttributeValueExpException instance = new BadAttributeValueExpException(c0);
        instance.ToString();
    }
}
```