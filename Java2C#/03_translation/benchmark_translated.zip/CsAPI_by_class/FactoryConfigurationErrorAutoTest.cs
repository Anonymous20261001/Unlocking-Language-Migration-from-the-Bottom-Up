```csharp
using System;
using NUnit.Framework;

namespace generated.test
{
    public class FactoryConfigurationErrorAutoTest
    {
        [Test]
        public void GetCause_test_10909()
        {
            FactoryConfigurationError instance = new FactoryConfigurationError();
            instance.GetCause();
        }

        [Test]
        public void GetMessage_test_10910()
        {
            FactoryConfigurationError instance = new FactoryConfigurationError();
            instance.GetMessage();
        }

        [Test]
        public void GetException_test_10911()
        {
            FactoryConfigurationError instance = new FactoryConfigurationError();
            instance.GetException();
        }
    }

    public class FactoryConfigurationError : Exception
    {
        private readonly Exception _exception;

        public FactoryConfigurationError() : base()
        {
            _exception = null;
        }

        public FactoryConfigurationError(Exception e) : base("", e)
        {
            _exception = e;
        }

        public Exception GetCause()
        {
            return InnerException;
        }

        public string GetMessage()
        {
            return Message;
        }

        public Exception GetException()
        {
            return _exception;
        }
    }
}
```