```csharp
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class LdapDnsProviderResultAutoTest
    {
        [Test]
        public void GetDomainName_Test_6018()
        {
            string c0 = "example.com";
            List<string> c1 = new List<string> { "10.0.0.1", "10.0.0.2" };
            LdapDnsProviderResult instance = new LdapDnsProviderResult(c0, c1);
            instance.GetDomainName();
        }

        [Test]
        public void GetEndpoints_Test_6019()
        {
            string c0 = "example.com";
            List<string> c1 = new List<string> { "10.0.0.1", "10.0.0.2" };
            LdapDnsProviderResult instance = new LdapDnsProviderResult(c0, c1);
            instance.GetEndpoints();
        }
    }

    public class LdapDnsProviderResult
    {
        private readonly string _domainName;
        private readonly List<string> _endpoints;

        public LdapDnsProviderResult(string domainName, List<string> endpoints)
        {
            _domainName = domainName;
            _endpoints = endpoints;
        }

        public string GetDomainName()
        {
            return _domainName;
        }

        public List<string> GetEndpoints()
        {
            return _endpoints;
        }
    }
}
```