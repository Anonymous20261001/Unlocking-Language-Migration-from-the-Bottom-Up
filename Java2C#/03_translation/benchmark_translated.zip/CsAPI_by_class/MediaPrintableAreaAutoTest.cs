```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.print.attribute.standard.MediaPrintableArea
    public class MediaPrintableArea
    {
        public static readonly int INCH = 25400;   // microns per inch
        public static readonly int MM = 1000;      // microns per millimeter

        private int xMicrons;
        private int yMicrons;
        private int widthMicrons;
        private int heightMicrons;

        // Constructor: converts input values to micron integer representation
        public MediaPrintableArea(float x, float y, float w, float h, int units)
        {
            // Java's Math.round(float) rounds to the nearest integer, ties to positive infinity
            int round(float value) => (int)Math.Floor(value + 0.5f);

            xMicrons = round(x * units);
            yMicrons = round(y * units);
            widthMicrons = round(w * units);
            heightMicrons = round(h * units);
        }

        // Returns the category (type) of this attribute
        public Type GetCategory()
        {
            return typeof(MediaPrintableArea);
        }

        // Returns the printable area as a float[4] in the given unit
        public float[] GetPrintableArea(int units)
        {
            return new float[] { GetX(units), GetY(units), GetWidth(units), GetHeight(units) };
        }

        // Returns the X coordinate in the given unit
        public float GetX(int units)
        {
            return (float)xMicrons / units;
        }

        // Returns the Y coordinate in the given unit
        public float GetY(int units)
        {
            return (float)yMicrons / units;
        }

        // Returns the width in the given unit
        public float GetWidth(int units)
        {
            return (float)widthMicrons / units;
        }

        // Returns the height in the given unit
        public float GetHeight(int units)
        {
            return (float)heightMicrons / units;
        }

        // Returns the name of the attribute
        public string GetName()
        {
            return "media-printable-area";
        }

        // Compares this attribute to another object
        public override bool Equals(object obj)
        {
            if (obj is MediaPrintableArea other)
            {
                return xMicrons == other.xMicrons &&
                       yMicrons == other.yMicrons &&
                       widthMicrons == other.widthMicrons &&
                       heightMicrons == other.heightMicrons;
            }
            return false;
        }

        // Returns a string representation using the default unit (MM)
        public override string ToString()
        {
            return $"MediaPrintableArea: x: {GetX(MM)} y: {GetY(MM)} w: {GetWidth(MM)} h: {GetHeight(MM)}";
        }

        // Returns a string representation using the specified unit and unit name
        public string ToString(int units, string unitsName)
        {
            return $"MediaPrintableArea: x: {GetX(units)} y: {GetY(units)} w: {GetWidth(units)} h: {GetHeight(units)} {unitsName}";
        }

        // Returns a hash code based on the internal micron values
        public override int GetHashCode()
        {
            // Simple combine to match typical Java pattern
            int hash = 7;
            hash = 31 * hash + xMicrons;
            hash = 31 * hash + yMicrons;
            hash = 31 * hash + widthMicrons;
            hash = 31 * hash + heightMicrons;
            return hash;
        }
    }

    [TestFixture]
    public class MediaPrintableAreaAutoTest
    {
        // All tests use a default MediaPrintableArea with x=0, y=0, w=10, h=10 (in mm)
        private const float DefaultX = 0f;
        private const float DefaultY = 0f;
        private const float DefaultW = 10f;
        private const float DefaultH = 10f;
        private const int DefaultUnits = MediaPrintableArea.MM;

        [Test]
        public void GetCategory_test_6169()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetCategory();
        }

        [Test]
        public void GetPrintableArea_test_6170()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            var area = instance.GetPrintableArea(DefaultUnits);
        }

        [Test]
        public void GetX_test_6171()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetX(DefaultUnits);
        }

        [Test]
        public void GetY_test_6172()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetY(DefaultUnits);
        }

        [Test]
        public void GetWidth_test_6173()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetWidth(DefaultUnits);
        }

        [Test]
        public void GetHeight_test_6174()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetHeight(DefaultUnits);
        }

        [Test]
        public void GetName_test_6175()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetName();
        }

        [Test]
        public void Equals_test_6176()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            var other = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.Equals(other);
        }

        [Test]
        public void ToString_test_6177()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.ToString(DefaultUnits, "mm");
        }

        [Test]
        public void ToString_test_6178()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.ToString();
        }

        [Test]
        public void HashCode_test_6179()
        {
            var instance = new MediaPrintableArea(DefaultX, DefaultY, DefaultW, DefaultH, DefaultUnits);
            instance.GetHashCode();
        }
    }
}
```