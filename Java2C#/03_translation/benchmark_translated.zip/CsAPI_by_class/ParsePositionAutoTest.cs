```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class ParsePosition
    {
        private int index;
        private int errorIndex = -1; // Java default

        public ParsePosition(int index)
        {
            this.index = index;
        }

        public int GetIndex()
        {
            return index;
        }

        public void SetIndex(int index)
        {
            this.index = index;
        }

        public int GetErrorIndex()
        {
            return errorIndex;
        }

        public void SetErrorIndex(int errorIndex)
        {
            this.errorIndex = errorIndex;
        }

        public override bool Equals(object obj)
        {
            if (obj == this) return true;
            if (obj == null || GetType() != obj.GetType()) return false;
            ParsePosition other = (ParsePosition)obj;
            return index == other.index && errorIndex == other.errorIndex;
        }

        public override int GetHashCode()
        {
            int hash = 7;
            hash = 31 * hash + index;
            hash = 31 * hash + errorIndex;
            return hash;
        }

        public override string ToString()
        {
            return $"ParsePosition[index={index}, errorIndex={errorIndex}]";
        }
    }

    [TestFixture]
    public class ParsePositionAutoTest
    {
        [Test]
        public void Equals_test_3196()
        {
            object p0 = null; // or new object() – matches the Java signature
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_test_3197()
        {
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.ToString();
        }

        [Test]
        public void HashCode_test_3198()
        {
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.GetHashCode();
        }

        [Test]
        public void GetIndex_test_3199()
        {
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.GetIndex();
        }

        [Test]
        public void SetIndex_test_3200()
        {
            int p0 = 0;
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.SetIndex(p0);
        }

        [Test]
        public void SetErrorIndex_test_3201()
        {
            int p0 = 0;
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.SetErrorIndex(p0);
        }

        [Test]
        public void GetErrorIndex_test_3202()
        {
            int c0 = 0;
            ParsePosition instance = new ParsePosition(c0);
            instance.GetErrorIndex();
        }
    }
}
```