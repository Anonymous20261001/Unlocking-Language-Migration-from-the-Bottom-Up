```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.swing.plaf.metal.DefaultMetalTheme
    public class DefaultMetalTheme
    {
        public Font GetControlTextFont()
        {
            return new Font("Dialog", 12, FontStyle.Plain);
        }

        public Font GetSystemTextFont()
        {
            return new Font("Dialog", 12, FontStyle.Plain);
        }

        public Font GetUserTextFont()
        {
            return new Font("Dialog", 12, FontStyle.Plain);
        }

        public Font GetMenuTextFont()
        {
            return new Font("Dialog", 12, FontStyle.Plain);
        }

        public Font GetWindowTitleFont()
        {
            return new Font("Dialog", 12, FontStyle.Plain);
        }

        public Font GetSubTextFont()
        {
            return new Font("Dialog", 10, FontStyle.Plain);
        }

        public string GetName()
        {
            return "Steel";
        }
    }

    [TestFixture]
    public class DefaultMetalThemeAutoTest
    {
        [Test]
        public void GetControlTextFont_test_9074()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetControlTextFont();
        }

        [Test]
        public void GetSystemTextFont_test_9075()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetSystemTextFont();
        }

        [Test]
        public void GetUserTextFont_test_9076()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetUserTextFont();
        }

        [Test]
        public void GetMenuTextFont_test_9077()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetMenuTextFont();
        }

        [Test]
        public void GetWindowTitleFont_test_9078()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetWindowTitleFont();
        }

        [Test]
        public void GetSubTextFont_test_9079()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetSubTextFont();
        }

        [Test]
        public void GetName_test_9080()
        {
            DefaultMetalTheme instance = new DefaultMetalTheme();
            instance.GetName();
        }
    }
}
```