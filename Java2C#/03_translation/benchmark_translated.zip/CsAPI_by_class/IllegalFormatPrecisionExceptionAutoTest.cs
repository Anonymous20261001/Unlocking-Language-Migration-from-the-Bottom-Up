```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of Java's IllegalFormatPrecisionException.
    /// </summary>
    public class IllegalFormatPrecisionException : Exception
    {
        /// <summary>
        /// Gets the precision value that caused the exception.
        /// </summary>
        public int Precision { get; }

        /// <summary>
        /// Initializes a new instance with the specified precision.
        /// </summary>
        /// <param name="precision">The illegal precision value.</param>
        public IllegalFormatPrecisionException(int precision)
            : base($"Precision = {precision}")
        {
            Precision = precision;
        }

        /// <summary>
        /// Java-compatible method returning the precision.
        /// </summary>
        public int GetPrecision() => Precision;
    }

    [TestFixture]
    public class IllegalFormatPrecisionExceptionAutoTest
    {
        [Test]
        public void GetPrecision_Test_3571()
        {
            int c0 = 3571; // arbitrary value; original Java test used a parameter
            var instance = new IllegalFormatPrecisionException(c0);
            instance.GetPrecision();
        }

        [Test]
        public void GetMessage_Test_3572()
        {
            int c0 = 3572; // arbitrary value; original Java test used a parameter
            var instance = new IllegalFormatPrecisionException(c0);
            // This invokes the inherited Message property, equivalent to Java's getMessage()
            string message = instance.Message;
        }
    }
}
```