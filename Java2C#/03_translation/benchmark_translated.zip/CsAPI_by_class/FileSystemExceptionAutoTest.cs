```csharp
using System;
using NUnit.Framework;

namespace Test
{
    // C# equivalent of java.nio.file.FileSystemException
    public class FileSystemException : Exception
    {
        private readonly string file;
        private readonly string other;
        private readonly string reason;

        public FileSystemException(string file)
            : base($"FileSystemException: {file}")
        {
            this.file = file;
            this.other = null;
            this.reason = null;
        }

        public string GetFile() => file;
        public string GetOtherFile() => other;
        public string GetReason() => reason;
        public string GetMessage() => Message; // mimics Java's getMessage()
    }

    [TestFixture]
    public class FileSystemExceptionAutoTest
    {
        [Test]
        public void GetMessage_test_2648()
        {
            var instance = new FileSystemException("test");
            instance.GetMessage();
        }

        [Test]
        public void GetFile_test_2649()
        {
            var instance = new FileSystemException("test");
            instance.GetFile();
        }

        [Test]
        public void GetReason_test_2650()
        {
            var instance = new FileSystemException("test");
            instance.GetReason();
        }

        [Test]
        public void GetOtherFile_test_2651()
        {
            var instance = new FileSystemException("test");
            instance.GetOtherFile();
        }
    }
}
```