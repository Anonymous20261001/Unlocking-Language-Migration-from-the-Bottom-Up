```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of java.awt.image.DataBufferByte with a single bank.
    /// Internal storage uses signed bytes (sbyte) to match Java's signed byte behavior.
    /// </summary>
    public class DataBufferByte
    {
        private readonly sbyte[][] bankData;

        /// <summary>
        /// Creates a DataBufferByte with one bank of the specified size.
        /// </summary>
        /// <param name="size">Number of elements (must be positive).</param>
        /// <exception cref="ArgumentException">Thrown if size is not positive.</exception>
        public DataBufferByte(int size)
        {
            if (size <= 0)
                throw new ArgumentException("size must be positive", nameof(size));

            bankData = new sbyte[1][];
            bankData[0] = new sbyte[size];
        }

        /// <summary>
        /// Returns the array of banks (each bank is an sbyte[]).
        /// </summary>
        public sbyte[][] GetBankData() => bankData;

        /// <summary>
        /// Returns the data array of the first (and only) bank.
        /// </summary>
        public sbyte[] GetData() => bankData[0];

        /// <summary>
        /// Returns the data array of the specified bank.
        /// </summary>
        public sbyte[] GetData(int bank) => bankData[bank];

        /// <summary>
        /// Returns the element at index i of the first bank as an int (sign‑extended from sbyte).
        /// </summary>
        public int GetElem(int i) => bankData[0][i];

        /// <summary>
        /// Returns the element at index i of the specified bank as an int (sign‑extended from sbyte).
        /// </summary>
        public int GetElem(int bank, int i) => bankData[bank][i];

        /// <summary>
        /// Sets the element at index i of the first bank to the given int value (truncated to sbyte).
        /// </summary>
        public void SetElem(int i, int val) => bankData[0][i] = (sbyte)val;

        /// <summary>
        /// Sets the element at index i of the specified bank to the given int value (truncated to sbyte).
        /// </summary>
        public void SetElem(int bank, int i, int val) => bankData[bank][i] = (sbyte)val;
    }

    [TestFixture]
    public class DataBufferByteAutoTest
    {
        [Test]
        public void GetBankData_Test_1183()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.GetBankData();
        }

        [Test]
        public void GetElem_Test_1184()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.GetElem(0, 0);
        }

        [Test]
        public void GetElem_Test_1185()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.GetElem(0);
        }

        [Test]
        public void SetElem_Test_1186()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.SetElem(0, 0, 0);
        }

        [Test]
        public void SetElem_Test_1187()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.SetElem(0, 0);
        }

        [Test]
        public void GetData_Test_1188()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.GetData(0);
        }

        [Test]
        public void GetData_Test_1189()
        {
            DataBufferByte instance = new DataBufferByte(10);
            instance.GetData();
        }
    }
}
```