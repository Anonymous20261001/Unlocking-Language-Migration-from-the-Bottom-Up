```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    /// <summary>
    /// C# equivalent of Java's java.util.DuplicateFormatFlagsException.
    /// Mimics the same API: constructor takes a flags string, GetFlags() returns it,
    /// GetMessage() returns the message (inherited from Exception via a custom method).
    /// </summary>
    public class DuplicateFormatFlagsException : Exception
    {
        private readonly string _flags;

        public DuplicateFormatFlagsException(string flags)
            : base("Duplicate format flags: " + flags)
        {
            _flags = flags;
        }

        public string GetFlags()
        {
            return _flags;
        }

        /// <summary>
        /// Method that matches Java's getMessage().
        /// Returns the underlying Exception.Message property.
        /// </summary>
        public string GetMessage()
        {
            return this.Message;
        }
    }

    [TestFixture]
    public class DuplicateFormatFlagsExceptionAutoTest
    {
        [Test]
        public void getMessage_test_3425()
        {
            DuplicateFormatFlagsException instance = new DuplicateFormatFlagsException("test");
            instance.GetMessage();
        }

        [Test]
        public void getFlags_test_3426()
        {
            DuplicateFormatFlagsException instance = new DuplicateFormatFlagsException("test");
            instance.GetFlags();
        }
    }
}
```