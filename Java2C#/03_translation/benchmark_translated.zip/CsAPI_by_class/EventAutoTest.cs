```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.awt.Event
    public class Event
    {
        public const int SHIFT_MASK = 1;
        public const int CTRL_MASK = 2;
        public const int META_MASK = 4;

        public object Target { get; set; }
        public int Id { get; set; }
        public object Arg { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Modifiers { get; set; }

        public Event(object target, int id, object arg)
        {
            Target = target;
            Id = id;
            Arg = arg;
            X = 0;
            Y = 0;
            Modifiers = 0;
        }

        public void Translate(int dx, int dy)
        {
            X += dx;
            Y += dy;
        }

        public bool ShiftDown()
        {
            return (Modifiers & SHIFT_MASK) != 0;
        }

        public bool ControlDown()
        {
            return (Modifiers & CTRL_MASK) != 0;
        }

        public bool MetaDown()
        {
            return (Modifiers & META_MASK) != 0;
        }

        public override string ToString()
        {
            return $"Event[target={Target}, id={Id}, arg={Arg}, x={X}, y={Y}, modifiers={Modifiers}]";
        }
    }

    [TestFixture]
    public class EventAutoTest
    {
        [Test]
        public void Translate_test_213()
        {
            // Using default dummy values; original Java test had parameters (int p0, int p1, Object c0, int c1, Object c2)
            int p0 = 5, p1 = 10;
            object c0 = "target";
            int c1 = 42;
            object c2 = "arg";
            Event instance = new Event(c0, c1, c2);
            instance.Translate(p0, p1);
        }

        [Test]
        public void ShiftDown_test_214()
        {
            object c0 = "target";
            int c1 = 0;
            object c2 = "arg";
            Event instance = new Event(c0, c1, c2);
            instance.ShiftDown();
        }

        [Test]
        public void ControlDown_test_215()
        {
            object c0 = "target";
            int c1 = 0;
            object c2 = "arg";
            Event instance = new Event(c0, c1, c2);
            instance.ControlDown();
        }

        [Test]
        public void MetaDown_test_216()
        {
            object c0 = "target";
            int c1 = 0;
            object c2 = "arg";
            Event instance = new Event(c0, c1, c2);
            instance.MetaDown();
        }

        [Test]
        public void ToString_test_217()
        {
            object c0 = "target";
            int c1 = 0;
            object c2 = "arg";
            Event instance = new Event(c0, c1, c2);
            instance.ToString();
        }
    }
}
```