```csharp
using System;
using System.IO;
using System.Text;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of java.io.OutputStreamWriter
    public class OutputStreamWriter : TextWriter
    {
        private readonly Stream _stream;
        private readonly Encoding _encoding;

        // Default constructor uses UTF-8 encoding (similar to Java's default charset)
        public OutputStreamWriter(Stream stream) : this(stream, Encoding.UTF8)
        {
        }

        public OutputStreamWriter(Stream stream, Encoding encoding)
        {
            _stream = stream ?? throw new ArgumentNullException(nameof(stream));
            _encoding = encoding ?? throw new ArgumentNullException(nameof(encoding));
        }

        // Mimics Java's getEncoding() which returns the canonical charset name (e.g., "UTF-8")
        public string GetEncoding()
        {
            return _encoding.WebName; // e.g., "utf-8" – matches Java's typical output
        }

        // Minimal implementation required to satisfy TextWriter abstract class
        public override Encoding Encoding => _encoding;

        // Not required for the test, but provided for correctness
        public override void Write(char value)
        {
            byte[] bytes = _encoding.GetBytes(new[] { value });
            _stream.Write(bytes, 0, bytes.Length);
        }

        public override void Write(char[] buffer, int index, int count)
        {
            byte[] bytes = _encoding.GetBytes(buffer, index, count);
            _stream.Write(bytes, 0, bytes.Length);
        }

        public override void Flush()
        {
            _stream.Flush();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _stream.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    [TestFixture]
    public class OutputStreamWriterAutoTest
    {
        [Test]
        public void GetEncoding_test_1798(
            [ValueSource(nameof(GetTestStreams))] Stream c0)
        {
            var instance = new OutputStreamWriter(c0);
            instance.GetEncoding();
        }

        // Provides test streams – the Java test passes an OutputStream; here we use Stream.
        private static Stream[] GetTestStreams()
        {
            return new Stream[]
            {
                new MemoryStream(),
                new FileStream(Path.GetTempFileName(), FileMode.Create, FileAccess.Write)
            };
        }
    }
}
```