```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // ------------------------------------------------------------
    // Stub implementations for Java AWT/Swing classes
    // ------------------------------------------------------------

    public class JComponent { }

    public abstract class AbstractButton : JComponent { }

    public class PropertyChangeEvent : EventArgs
    {
        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            Source = source;
            PropertyName = propertyName;
            OldValue = oldValue;
            NewValue = newValue;
        }

        public object Source { get; }
        public string PropertyName { get; }
        public object OldValue { get; }
        public object NewValue { get; }
    }

    public class ChangeEvent : EventArgs
    {
        public ChangeEvent(object source)
        {
            Source = source;
        }

        public object Source { get; }
    }

    public class FocusEvent : EventArgs
    {
        public FocusEvent(object source, int id)
        {
            Source = source;
            Id = id;
        }

        public object Source { get; }
        public int Id { get; }
    }

    public class MouseEvent : EventArgs
    {
        public MouseEvent(object source, int id, long when, int modifiers, int x, int y, int clickCount, bool popupTrigger, int button)
        {
            Source = source;
            Id = id;
            When = when;
            Modifiers = modifiers;
            X = x;
            Y = y;
            ClickCount = clickCount;
            PopupTrigger = popupTrigger;
            Button = button;
        }

        public object Source { get; }
        public int Id { get; }
        public long When { get; }
        public int Modifiers { get; }
        public int X { get; }
        public int Y { get; }
        public int ClickCount { get; }
        public bool PopupTrigger { get; }
        public int Button { get; }
    }

    // ------------------------------------------------------------
    // BasicButtonListener – minimal stub matching Java API
    // ------------------------------------------------------------

    public class BasicButtonListener
    {
        private readonly AbstractButton _button;

        public BasicButtonListener(AbstractButton button)
        {
            _button = button;
        }

        public void PropertyChange(PropertyChangeEvent e) { /* stub */ }
        public void StateChanged(ChangeEvent e) { /* stub */ }
        public void InstallKeyboardActions(JComponent c) { /* stub */ }
        public void UninstallKeyboardActions(JComponent c) { /* stub */ }
        public void FocusGained(FocusEvent e) { /* stub */ }
        public void FocusLost(FocusEvent e) { /* stub */ }
        public void MousePressed(MouseEvent e) { /* stub */ }
        public void MouseReleased(MouseEvent e) { /* stub */ }
        public void MouseClicked(MouseEvent e) { /* stub */ }
        public void MouseExited(MouseEvent e) { /* stub */ }
        public void MouseEntered(MouseEvent e) { /* stub */ }
        public void MouseMoved(MouseEvent e) { /* stub */ }
        public void MouseDragged(MouseEvent e) { /* stub */ }
    }

    // ------------------------------------------------------------
    // Test class (NUnit)
    // ------------------------------------------------------------

    [TestFixture]
    public class BasicButtonListenerAutoTest
    {
        [Test]
        public void PropertyChange_test_8627()
        {
            var p0 = new PropertyChangeEvent(new object(), "test", null, null);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.PropertyChange(p0);
        }

        [Test]
        public void StateChanged_test_8628()
        {
            var p0 = new ChangeEvent(new object());
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.StateChanged(p0);
        }

        [Test]
        public void InstallKeyboardActions_test_8629()
        {
            var p0 = new JComponent();
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.InstallKeyboardActions(p0);
        }

        [Test]
        public void UninstallKeyboardActions_test_8630()
        {
            var p0 = new JComponent();
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.UninstallKeyboardActions(p0);
        }

        [Test]
        public void FocusGained_test_8631()
        {
            var p0 = new FocusEvent(new object(), 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.FocusGained(p0);
        }

        [Test]
        public void FocusLost_test_8632()
        {
            var p0 = new FocusEvent(new object(), 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.FocusLost(p0);
        }

        [Test]
        public void MousePressed_test_8633()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MousePressed(p0);
        }

        [Test]
        public void MouseReleased_test_8634()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseReleased(p0);
        }

        [Test]
        public void MouseClicked_test_8635()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseClicked(p0);
        }

        [Test]
        public void MouseExited_test_8636()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseExited(p0);
        }

        [Test]
        public void MouseEntered_test_8637()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseEntered(p0);
        }

        [Test]
        public void MouseMoved_test_8638()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseMoved(p0);
        }

        [Test]
        public void MouseDragged_test_8639()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MouseDragged(p0);
        }

        // Concrete subclass to instantiate the abstract AbstractButton
        private class ConcreteAbstractButton : AbstractButton { }
    }
}
```