```csharp
using NUnit.Framework;
using System;

namespace GeneratedTest
{
    // ------------------------------------------------------------
    // Lightweight equivalents of Java AWT/Swing classes
    // ------------------------------------------------------------

    public class Graphics
    {
        // Stub class – no functionality needed for these tests
    }

    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public Dimension() : this(0, 0) { }
        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    public abstract class JComponent
    {
        // Minimal stubs required by the UI methods
        public virtual bool Contains(int x, int y) => false;
        public virtual int GetAccessibleChildrenCount() => 0;
        public virtual object GetAccessibleChild(int index) => null;
        public virtual Dimension GetMinimumSize() => new Dimension();
        public virtual Dimension GetMaximumSize() => new Dimension();
        public virtual Dimension GetPreferredSize() => new Dimension();
        public virtual void Paint(Graphics g) { /* stub */ }
        public virtual void Update(Graphics g) { /* stub */ }
    }

    // -----------------------------------------------------------------
    // Base UI classes
    // -----------------------------------------------------------------

    public class ComponentUI
    {
        public virtual void InstallUI(JComponent c) { }
        public virtual void UninstallUI(JComponent c) { }
        public virtual ComponentUI[] GetUIs() => Array.Empty<ComponentUI>();
        public static ComponentUI CreateUI(JComponent c) => new ComponentUI();  // stub
        public virtual Dimension GetMaximumSize(JComponent c) => c?.GetMaximumSize();
        public virtual Dimension GetMinimumSize(JComponent c) => c?.GetMinimumSize();
        public virtual Dimension GetPreferredSize(JComponent c) => c?.GetPreferredSize();
        public virtual void Paint(Graphics g, JComponent c) { }
        public virtual void Update(Graphics g, JComponent c) { }
        public virtual bool Contains(JComponent c, int x, int y) => c?.Contains(x, y) ?? false;
        public virtual int GetAccessibleChildrenCount(JComponent c) => c?.GetAccessibleChildrenCount() ?? 0;
        public virtual object GetAccessibleChild(JComponent c, int index) => c?.GetAccessibleChild(index);
    }

    public class TableUI : ComponentUI
    {
        // Inherits all virtual methods, no additional stubs needed
    }

    public class MultiTableUI : TableUI
    {
        // Override methods as per Java MultiTableUI behaviour (empty stubs)
        public override void InstallUI(JComponent c) { base.InstallUI(c); }
        public override void UninstallUI(JComponent c) { base.UninstallUI(c); }
        public override ComponentUI[] GetUIs() => base.GetUIs();
        public new static ComponentUI CreateUI(JComponent c) => ComponentUI.CreateUI(c); // shadow static
        public override Dimension GetMaximumSize(JComponent c) => base.GetMaximumSize(c);
        public override void Paint(Graphics g, JComponent c) { base.Paint(g, c); }
        public override int GetAccessibleChildrenCount(JComponent c) => base.GetAccessibleChildrenCount(c);
        public override object GetAccessibleChild(JComponent c, int index) => base.GetAccessibleChild(c, index);
        public override Dimension GetPreferredSize(JComponent c) => base.GetPreferredSize(c);
        public override Dimension GetMinimumSize(JComponent c) => base.GetMinimumSize(c);
        public override void Update(Graphics g, JComponent c) { base.Update(g, c); }
        public override bool Contains(JComponent c, int x, int y) => base.Contains(c, x, y);
    }

    // ------------------------------------------------------------
    // Test class – one parameterless test per original @Test method
    // ------------------------------------------------------------

    [TestFixture]
    public class MultiTableUIAutoTest
    {
        [Test]
        public void InstallUI_test_9618()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.InstallUI(component);
        }

        [Test]
        public void UninstallUI_test_9619()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.UninstallUI(component);
        }

        [Test]
        public void GetUIs_test_9620()
        {
            var instance = new MultiTableUI();
            instance.GetUIs();
        }

        [Test]
        public void CreateUI_test_9621()
        {
            var component = new TestJComponent();
            MultiTableUI.CreateUI(component);
        }

        [Test]
        public void GetMaximumSize_test_9622()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.GetMaximumSize(component);
        }

        [Test]
        public void Paint_test_9623()
        {
            var instance = new MultiTableUI();
            var graphics = new Graphics();
            var component = new TestJComponent();
            instance.Paint(graphics, component);
        }

        [Test]
        public void GetAccessibleChildrenCount_test_9624()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.GetAccessibleChildrenCount(component);
        }

        [Test]
        public void GetAccessibleChild_test_9625()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.GetAccessibleChild(component, 0);
        }

        [Test]
        public void GetPreferredSize_test_9626()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.GetPreferredSize(component);
        }

        [Test]
        public void GetMinimumSize_test_9627()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.GetMinimumSize(component);
        }

        [Test]
        public void Update_test_9628()
        {
            var instance = new MultiTableUI();
            var graphics = new Graphics();
            var component = new TestJComponent();
            instance.Update(graphics, component);
        }

        [Test]
        public void Contains_test_9629()
        {
            var instance = new MultiTableUI();
            var component = new TestJComponent();
            instance.Contains(component, 10, 20);
        }

        // Helper concrete JComponent for testing
        private class TestJComponent : JComponent { }
    }
}
```