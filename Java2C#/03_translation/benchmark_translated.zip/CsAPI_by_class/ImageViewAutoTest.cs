```csharp
using NUnit.Framework;
using System;

namespace GeneratedTest
{
    // --- Stub types for Java equivalents ---

    public interface Shape { }
    public interface Graphics { }
    public interface Element { }

    public class DocumentEvent { }

    public class Position
    {
        public class Bias
        {
            public static readonly Bias Forward = new Bias();
            public static readonly Bias Backward = new Bias();
        }
    }

    public class ViewFactory { }

    public class Image : IDisposable
    {
        public void Dispose() { }
    }

    public class Icon { }

    public class AttributeSet { }

    public class URL { }

    public class View
    {
        public virtual int ViewToModel(float x, float y, Shape a, Position.Bias[] bias) => 0;
        public virtual string GetToolTipText(float x, float y, Shape a) => null;
        public virtual void ChangedUpdate(DocumentEvent e, Shape a, ViewFactory f) { }
        public virtual float GetPreferredSpan(int axis) => 0;
        public virtual void Paint(Graphics g, Shape allocation) { }
        public virtual float GetAlignment(int axis) => 0;
        public virtual void SetParent(View parent) { }
        public virtual void SetSize(float width, float height) { }
    }

    // --- ImageView class ---
    public class ImageView : View
    {
        public ImageView(Element elem) { }

        public string GetAltText() => null;
        public Icon GetLoadingImageIcon() => null;
        public Icon GetNoImageIcon() => null;
        public bool GetLoadsSynchronously() => false;
        public void SetLoadsSynchronously(bool sync) { }
        public Image GetImage() => null;
        public URL GetImageURL() => null;
        public AttributeSet GetAttributes() => null;
    }

    // --- Test class ---
    [TestFixture]
    public class ImageViewAutoTest
    {
        [Test]
        public void ViewToModel_Test_10500(float p0, float p1, Shape p2, Position.Bias[] p3, Element c0)
        {
            var instance = new ImageView(c0);
            instance.ViewToModel(p0, p1, p2, p3);
        }

        [Test]
        public void GetToolTipText_Test_10501(float p0, float p1, Shape p2, Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetToolTipText(p0, p1, p2);
        }

        [Test]
        public void ChangedUpdate_Test_10502(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0)
        {
            var instance = new ImageView(c0);
            instance.ChangedUpdate(p0, p1, p2);
        }

        [Test]
        public void GetAltText_Test_10503(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetAltText();
        }

        [Test]
        public void GetLoadingImageIcon_Test_10504(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetLoadingImageIcon();
        }

        [Test]
        public void GetNoImageIcon_Test_10505(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetNoImageIcon();
        }

        [Test]
        public void GetLoadsSynchronously_Test_10506(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetLoadsSynchronously();
        }

        [Test]
        public void SetLoadsSynchronously_Test_10507(bool p0, Element c0)
        {
            var instance = new ImageView(c0);
            instance.SetLoadsSynchronously(p0);
        }

        [Test]
        public void GetPreferredSpan_Test_10508(int p0, Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetPreferredSpan(p0);
        }

        [Test]
        public void GetImage_Test_10509(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetImage();
        }

        [Test]
        public void Paint_Test_10510(Graphics p0, Shape p1, Element c0)
        {
            var instance = new ImageView(c0);
            instance.Paint(p0, p1);
        }

        [Test]
        public void GetAlignment_Test_10511(int p0, Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetAlignment(p0);
        }

        [Test]
        public void GetImageURL_Test_10512(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetImageURL();
        }

        [Test]
        public void GetAttributes_Test_10513(Element c0)
        {
            var instance = new ImageView(c0);
            instance.GetAttributes();
        }

        [Test]
        public void SetParent_Test_10514(View p0, Element c0)
        {
            var instance = new ImageView(c0);
            instance.SetParent(p0);
        }

        [Test]
        public void SetSize_Test_10515(float p0, float p1, Element c0)
        {
            var instance = new ImageView(c0);
            instance.SetSize(p0, p1);
        }
    }
}
```