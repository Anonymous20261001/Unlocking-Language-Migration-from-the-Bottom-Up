```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of Java's LDAPCertStoreParameters
    public class LDAPCertStoreParameters : ICloneable
    {
        private readonly string serverName;
        private readonly int port;

        // Default constructor: serverName = "localhost", port = 389
        public LDAPCertStoreParameters()
        {
            serverName = "localhost";
            port = 389;
        }

        // Constructor with specific server and port (for completeness, though not used in tests)
        public LDAPCertStoreParameters(string serverName, int port)
        {
            this.serverName = serverName ?? throw new ArgumentNullException(nameof(serverName));
            this.port = port;
        }

        public string GetServerName()
        {
            return serverName;
        }

        public int GetPort()
        {
            return port;
        }

        // Java's toString() returns something like "LDAPCertStoreParameters: <serverName>:<port>"
        public override string ToString()
        {
            return $"LDAPCertStoreParameters: {serverName}:{port}";
        }

        // Java's clone() returns Object; in C# we implement ICloneable
        public object Clone()
        {
            return new LDAPCertStoreParameters(this.serverName, this.port);
        }
    }

    [TestFixture]
    public class LDAPCertStoreParametersAutoTest
    {
        [Test]
        public void GetServerName_Test_2773()
        {
            LDAPCertStoreParameters instance = new LDAPCertStoreParameters();
            instance.GetServerName();
        }

        [Test]
        public void ToString_Test_2774()
        {
            LDAPCertStoreParameters instance = new LDAPCertStoreParameters();
            instance.ToString();
        }

        [Test]
        public void Clone_Test_2775()
        {
            LDAPCertStoreParameters instance = new LDAPCertStoreParameters();
            instance.Clone();
        }

        [Test]
        public void GetPort_Test_2776()
        {
            LDAPCertStoreParameters instance = new LDAPCertStoreParameters();
            instance.GetPort();
        }
    }
}
```