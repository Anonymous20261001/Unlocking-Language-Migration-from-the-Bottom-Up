```csharp
using System;
using Xunit;

namespace Generated.Test
{
    // C# equivalent of javax.print.attribute.standard.DateTimeAtCompleted
    public class DateTimeAtCompleted
    {
        private readonly DateTime value;

        public DateTimeAtCompleted(DateTime dateTime)
        {
            value = dateTime;
        }

        // Returns the category (Type) of this attribute (mimics Java's getCategory())
        public Type GetCategory()
        {
            return typeof(DateTimeAtCompleted);
        }

        // Returns the name of this attribute (mimics Java's getName())
        public string GetName()
        {
            return "date-time-at-completed";
        }

        // Override Equals to compare DateTime values
        public override bool Equals(object obj)
        {
            if (obj is DateTimeAtCompleted other)
                return this.value == other.value;
            return false;
        }

        public override int GetHashCode()
        {
            return value.GetHashCode();
        }
    }

    public class DateTimeAtCompletedAutoTest
    {
        [Fact]
        public void GetCategory_test_6103()
        {
            DateTimeAtCompleted instance = new DateTimeAtCompleted(DateTime.Now);
            instance.GetCategory();
        }

        [Fact]
        public void GetName_test_6104()
        {
            DateTimeAtCompleted instance = new DateTimeAtCompleted(DateTime.Now);
            instance.GetName();
        }

        [Fact]
        public void Equals_test_6105()
        {
            DateTimeAtCompleted instance = new DateTimeAtCompleted(DateTime.Now);
            object p0 = new DateTimeAtCompleted(DateTime.Now.AddDays(1));
            instance.Equals(p0);
        }
    }
}
```