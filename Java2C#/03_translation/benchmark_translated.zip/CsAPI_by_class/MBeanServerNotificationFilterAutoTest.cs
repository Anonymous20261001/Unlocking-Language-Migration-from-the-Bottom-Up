```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.management.relation.MBeanServerNotificationFilter
    public class MBeanServerNotificationFilter
    {
        // null means all enabled/disabled accordingly
        private HashSet<string> _enabledObjectNames = null;
        private HashSet<string> _disabledObjectNames = null;

        public MBeanServerNotificationFilter()
        {
            // Default: all notifications enabled (both sets null)
        }

        public void DisableAllObjectNames()
        {
            _enabledObjectNames = new HashSet<string>(); // empty, so nothing is enabled
            _disabledObjectNames = null;                  // no specific disabled items
        }

        public void EnableAllObjectNames()
        {
            _enabledObjectNames = null;   // all enabled
            _disabledObjectNames = null;  // no disabled
        }

        public HashSet<string> GetEnabledObjectNames()
        {
            if (_enabledObjectNames == null)
                return null;
            return new HashSet<string>(_enabledObjectNames);
        }

        public HashSet<string> GetDisabledObjectNames()
        {
            if (_disabledObjectNames == null)
                return null;
            return new HashSet<string>(_disabledObjectNames);
        }
    }

    [TestFixture]
    public class MBeanServerNotificationFilterAutoTest
    {
        [Test]
        public void DisableAllObjectNames_test_5804()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.DisableAllObjectNames();
        }

        [Test]
        public void EnableAllObjectNames_test_5805()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.EnableAllObjectNames();
        }

        [Test]
        public void GetEnabledObjectNames_test_5806()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.GetEnabledObjectNames();
        }

        [Test]
        public void GetDisabledObjectNames_test_5807()
        {
            MBeanServerNotificationFilter instance = new MBeanServerNotificationFilter();
            instance.GetDisabledObjectNames();
        }
    }
}
```