```csharp
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace Generated.Test
{
    // ---------- Supporting types ----------

    // Minimal Point2D (analogous to java.awt.geom.Point2D)
    public class Point2D
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Point2D(double x, double y)
        {
            X = x;
            Y = y;
        }

        public double GetX() => X;
        public double GetY() => Y;
    }

    // Minimal Rectangle (analogous to java.awt.Rectangle)
    public class Rectangle
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public Rectangle(int x, int y, int w, int h)
        {
            X = x; Y = y; Width = w; Height = h;
        }
    }

    // Minimal Rectangle2D (analogous to java.awt.geom.Rectangle2D)
    public class Rectangle2D
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle2D(double x, double y, double w, double h)
        {
            X = x; Y = y; Width = w; Height = h;
        }
    }

    // Minimal AffineTransform (analogous to java.awt.geom.AffineTransform)
    public class AffineTransform
    {
        // No real transformation needed for these tests
        public AffineTransform() { }
    }

    // Minimal RenderingHints (analogous to java.awt.RenderingHints)
    public class RenderingHints : Dictionary<RenderingHints.Key, object>
    {
        // Key inner class (simplified)
        public class Key { }
    }

    // Minimal ColorModel (analogous to java.awt.image.ColorModel)
    public abstract class ColorModel
    {
        public abstract int GetPixelSize();
    }

    // Simple concrete ColorModel for testing
    public class SimpleColorModel : ColorModel
    {
        public override int GetPixelSize() => 32;
    }

    // PaintContext (dummy) - returned from GradientPaint.CreateContext
    public class PaintContext
    {
        // Minimal implementation
    }

    // The main GradientPaint class (analogous to java.awt.GradientPaint)
    public class GradientPaint
    {
        private readonly Point2D point1;
        private readonly Color color1;
        private readonly Point2D point2;
        private readonly Color color2;
        private readonly bool cyclic;

        public GradientPaint(Point2D pt1, Color c1, Point2D pt2, Color c2)
            : this(pt1, c1, pt2, c2, false)
        {
        }

        public GradientPaint(Point2D pt1, Color c1, Point2D pt2, Color c2, bool cyclic)
        {
            this.point1 = pt1;
            this.color1 = c1;
            this.point2 = pt2;
            this.color2 = c2;
            this.cyclic = cyclic;
        }

        public PaintContext CreateContext(ColorModel cm, Rectangle deviceBounds, Rectangle2D userBounds,
                                          AffineTransform xform, RenderingHints hints)
        {
            // In a real implementation this would create a PaintContext,
            // here we just return a dummy object.
            return new PaintContext();
        }

        public int GetTransparency()
        {
            // Simplified: return transparency based on colors
            // In java.awt.GradientPaint this returns OPAQUE if both colors are opaque, etc.
            return (color1.A == 255 && color2.A == 255) ? 1 : 3; // OPAQUE = 1, TRANSLUCENT = 3
        }

        public Point2D GetPoint1() => point1;

        public Color GetColor1() => color1;

        public Point2D GetPoint2() => point2;

        public Color GetColor2() => color2;

        public bool IsCyclic() => cyclic;
    }

    // ---------- Test class ----------

    [TestFixture]
    public class GradientPaintAutoTest
    {
        [Test]
        public void CreateContext_test_309()
        {
            ColorModel p0 = new SimpleColorModel();
            Rectangle p1 = new Rectangle(0, 0, 100, 100);
            Rectangle2D p2 = new Rectangle2D(0, 0, 100, 100);
            AffineTransform p3 = new AffineTransform();
            RenderingHints p4 = new RenderingHints();
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.CreateContext(p0, p1, p2, p3, p4);
        }

        [Test]
        public void GetTransparency_test_310()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.GetTransparency();
        }

        [Test]
        public void GetPoint1_test_311()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.GetPoint1();
        }

        [Test]
        public void GetColor1_test_312()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.GetColor1();
        }

        [Test]
        public void GetPoint2_test_313()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.GetPoint2();
        }

        [Test]
        public void GetColor2_test_314()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.GetColor2();
        }

        [Test]
        public void IsCyclic_test_315()
        {
            Point2D c0 = new Point2D(0, 0);
            Color c1 = Color.Red;
            Point2D c2 = new Point2D(100, 100);
            Color c3 = Color.Blue;

            GradientPaint instance = new GradientPaint(c0, c1, c2, c3);
            instance.IsCyclic();
        }
    }
}
```