```csharp
using System;
using System.Text;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class JPEGQTableAutoTest
    {
        // Helper to create a default 64-element int array for testing
        private int[] CreateDefaultTable()
        {
            int[] table = new int[64];
            for (int i = 0; i < 64; i++)
            {
                table[i] = (i + 1) * 2; // some arbitrary values
            }
            return table;
        }

        [Test]
        public void GetScaledInstance_Test_5413()
        {
            int[] table = CreateDefaultTable();
            JPEGQTable instance = new JPEGQTable(table);
            float scaleFactor = 1.5f;
            bool forceBaseline = true;
            JPEGQTable scaled = instance.GetScaledInstance(scaleFactor, forceBaseline);
            // The test method simply calls the API – no assertions provided in original
        }

        [Test]
        public void ToString_Test_5414()
        {
            int[] table = CreateDefaultTable();
            JPEGQTable instance = new JPEGQTable(table);
            string result = instance.ToString();
        }

        [Test]
        public void GetTable_Test_5415()
        {
            int[] table = CreateDefaultTable();
            JPEGQTable instance = new JPEGQTable(table);
            int[] retrieved = instance.GetTable();
        }
    }

    public class JPEGQTable
    {
        private readonly int[] table;

        public JPEGQTable(int[] table)
        {
            // defensive copy
            this.table = new int[64];
            Array.Copy(table, this.table, Math.Min(table.Length, 64));
            // If input is shorter, remaining entries stay as 0 (Java behavior: table must be length 64)
        }

        public JPEGQTable GetScaledInstance(float scaleFactor, bool forceBaseline)
        {
            int[] scaled = new int[64];
            int maxVal = forceBaseline ? 255 : 32767;
            for (int i = 0; i < 64; i++)
            {
                double scaledVal = table[i] * scaleFactor;
                int clamped = (int)Math.Round(scaledVal);
                if (clamped < 1) clamped = 1;
                if (clamped > maxVal) clamped = maxVal;
                scaled[i] = clamped;
            }
            return new JPEGQTable(scaled);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("JPEGQTable:\n[");
            for (int i = 0; i < table.Length; i++)
            {
                sb.Append(table[i]);
                if (i < table.Length - 1) sb.Append(", ");
            }
            sb.Append("]");
            return sb.ToString();
        }

        public int[] GetTable()
        {
            int[] copy = new int[64];
            Array.Copy(table, copy, 64);
            return copy;
        }
    }
}
```