```csharp
using NUnit.Framework;
using System;

[TestFixture]
public class BadLocationExceptionAutoTest
{
    [Test]
    public void OffsetRequested_Test_10129()
    {
        string c0 = "Test message";
        int c1 = 42;
        BadLocationException instance = new BadLocationException(c0, c1);
        instance.OffsetRequested();
    }
}

public class BadLocationException : Exception
{
    private readonly int offset;

    public BadLocationException(string message, int offs) : base(message)
    {
        this.offset = offs;
    }

    public int OffsetRequested()
    {
        return this.offset;
    }
}
```