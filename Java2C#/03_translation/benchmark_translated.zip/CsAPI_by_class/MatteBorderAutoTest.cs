```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // Minimal Component class (abstract in Java, but here just a concrete class for signature)
    public class Component
    {
        // No members needed for these tests
    }

    // Minimal Graphics class (abstract in Java)
    public class Graphics
    {
        // No members needed
    }

    // Insets class equivalent to java.awt.Insets
    public class Insets
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int Bottom { get; set; }
        public int Right { get; set; }

        public Insets() { }

        public Insets(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    // Minimal Color class (only needed to satisfy return type; not used in icon-based tests)
    public class Color
    {
        // No members
    }

    // Icon interface equivalent to javax.swing.Icon
    public interface Icon
    {
        void PaintIcon(Component c, Graphics g, int x, int y);
        int GetIconWidth();
        int GetIconHeight();
    }

    // MatteBorder class equivalent to javax.swing.border.MatteBorder
    public class MatteBorder
    {
        private readonly Icon tileIcon;

        // Constructor for icon-based border (the only one used in tests)
        public MatteBorder(Icon icon)
        {
            tileIcon = icon;
        }

        public void PaintBorder(Component c, Graphics g, int x, int y, int width, int height)
        {
            // No actual painting – stub
        }

        public Insets GetBorderInsets(Component c, Insets insets)
        {
            // For an icon-based border, insets are based on icon dimensions
            insets.Top = tileIcon.GetIconHeight();
            insets.Left = tileIcon.GetIconWidth();
            insets.Bottom = tileIcon.GetIconHeight();
            insets.Right = tileIcon.GetIconWidth();
            return insets;
        }

        public Insets GetBorderInsets()
        {
            return new Insets(
                tileIcon.GetIconHeight(),
                tileIcon.GetIconWidth(),
                tileIcon.GetIconHeight(),
                tileIcon.GetIconWidth()
            );
        }

        public bool IsBorderOpaque()
        {
            // Icon-based borders are not opaque by default
            return false;
        }

        public Color GetMatteColor()
        {
            // Icon-based border returns null
            return null;
        }

        public Icon GetTileIcon()
        {
            return tileIcon;
        }
    }

    // Test class
    [TestFixture]
    public class MatteBorderAutoTest
    {
        [Test]
        public void PaintBorder_Test_8484(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
            Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.PaintBorder(p0, p1, p2, p3, p4, p5);
        }

        [Test]
        public void GetBorderInsets_Test_8485(Component p0, Insets p1, Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.GetBorderInsets(p0, p1);
        }

        [Test]
        public void GetBorderInsets_Test_8486(Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.GetBorderInsets();
        }

        [Test]
        public void IsBorderOpaque_Test_8487(Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.IsBorderOpaque();
        }

        [Test]
        public void GetMatteColor_Test_8488(Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.GetMatteColor();
        }

        [Test]
        public void GetTileIcon_Test_8489(Icon c0)
        {
            MatteBorder instance = new MatteBorder(c0);
            instance.GetTileIcon();
        }
    }
}
```