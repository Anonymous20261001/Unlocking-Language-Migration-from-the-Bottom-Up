```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.management.ObjectName
    public class ObjectName
    {
        private readonly string _name;

        public ObjectName(string name)
        {
            _name = name ?? throw new ArgumentNullException(nameof(name));
        }

        public override string ToString()
        {
            return _name;
        }
    }

    // C# equivalent of javax.management.MBeanServerNotification
    // Mimics the basic API used in the tests.
    public class MBeanServerNotification
    {
        private readonly string _type;
        private readonly object _source;
        private readonly long _sequenceNumber;
        private readonly ObjectName _objectName;

        public MBeanServerNotification(string type, object source, long sequenceNumber, ObjectName objectName)
        {
            _type = type;
            _source = source;
            _sequenceNumber = sequenceNumber;
            _objectName = objectName;
        }

        public ObjectName GetMBeanName()
        {
            return _objectName;
        }

        public override string ToString()
        {
            return $"MBeanServerNotification[type={_type}, source={_source}, sequenceNumber={_sequenceNumber}, objectName={_objectName}]";
        }
    }

    [TestFixture]
    public class MBeanServerNotificationAutoTest
    {
        [TestCase("", null, 0L, null)]
        public void GetMBeanName_Test_5608(string c0, object c1, long c2, ObjectName c3)
        {
            var instance = new MBeanServerNotification(c0, c1, c2, c3);
            instance.GetMBeanName();
        }

        [TestCase("", null, 0L, null)]
        public void ToString_Test_5609(string c0, object c1, long c2, ObjectName c3)
        {
            var instance = new MBeanServerNotification(c0, c1, c2, c3);
            instance.ToString();
        }
    }
}
```