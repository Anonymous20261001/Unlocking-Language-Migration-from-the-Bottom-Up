```csharp
using System;
using System.IO;
using System.Linq;
using NUnit.Framework;

namespace GeneratedTest
{
    /// <summary>
    /// C# equivalent of Java's javax.swing.filechooser.FileNameExtensionFilter.
    /// </summary>
    public class FileNameExtensionFilter
    {
        private readonly string description;
        private readonly string[] extensions; // stored with leading dot, lower case

        public FileNameExtensionFilter(string description, params string[] extensions)
        {
            this.description = description ?? string.Empty;
            if (extensions == null)
                extensions = Array.Empty<string>();

            // Normalize: add leading dot if missing, convert to lower case (invariant)
            this.extensions = extensions
                .Select(e => (e.StartsWith(".") ? "" : ".") + e.ToLowerInvariant())
                .ToArray();
        }

        public string GetDescription()
        {
            return description;
        }

        public string[] GetExtensions()
        {
            // Return a copy to preserve immutability (as in Java)
            return (string[])extensions.Clone();
        }

        public override string ToString()
        {
            string extList = string.Join(", ", extensions);
            return $"{description} ({extList})";
        }

        public bool Accept(FileInfo file)
        {
            if (file == null)
                return false;

            // Accept directories (only if they exist, Java's File.isDirectory() returns false for non-existent)
            if (file.Exists && (file.Attributes & FileAttributes.Directory) == FileAttributes.Directory)
                return true;

            // Case‑insensitive extension check (Java uses lower‑case comparison)
            string fileName = file.Name.ToLowerInvariant();
            foreach (string ext in extensions)
            {
                if (fileName.EndsWith(ext))
                    return true;
            }
            return false;
        }
    }

    [TestFixture]
    public class FileNameExtensionFilterAutoTest
    {
        [Test]
        public void getDescription_test_8576()
        {
            string c0 = "Test Description";
            string[] c1 = new[] { "txt", "jpg" };
            var instance = new FileNameExtensionFilter(c0, c1);
            instance.GetDescription();
        }

        [Test]
        public void getExtensions_test_8577()
        {
            string c0 = "Test Description";
            string[] c1 = new[] { "txt", "jpg" };
            var instance = new FileNameExtensionFilter(c0, c1);
            instance.GetExtensions();
        }

        [Test]
        public void toString_test_8578()
        {
            string c0 = "Test Description";
            string[] c1 = new[] { "txt", "jpg" };
            var instance = new FileNameExtensionFilter(c0, c1);
            instance.ToString();
        }

        [Test]
        public void accept_test_8579()
        {
            // Use a temporary file to simulate a real file
            string tempFile = Path.GetTempFileName();
            try
            {
                var p0 = new FileInfo(tempFile);
                string c0 = "Test Description";
                string[] c1 = new[] { "txt", "jpg" };
                var instance = new FileNameExtensionFilter(c0, c1);
                instance.Accept(p0);
            }
            finally
            {
                if (File.Exists(tempFile))
                    File.Delete(tempFile);
            }
        }
    }
}
```