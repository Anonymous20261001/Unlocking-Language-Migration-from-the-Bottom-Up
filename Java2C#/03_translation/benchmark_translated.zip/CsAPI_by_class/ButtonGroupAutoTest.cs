```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalents of Java Swing classes
    public class ButtonModel
    {
        private bool selected;
        private ButtonGroup group;

        public ButtonGroup Group
        {
            get => group;
            set => group = value;
        }

        public bool IsSelected
        {
            get => selected;
            set
            {
                selected = value;
                if (selected && group != null)
                {
                    group.SetSelected(this, true);
                }
            }
        }
    }

    public class AbstractButton
    {
        private ButtonModel model;

        public AbstractButton()
        {
            model = new ButtonModel();
        }

        public ButtonModel Model
        {
            get => model;
            set => model = value;
        }
    }

    public class ButtonGroup
    {
        private readonly List<AbstractButton> buttons = new List<AbstractButton>();
        private ButtonModel selection = null;

        public void SetSelected(ButtonModel m, bool b)
        {
            if (b)
            {
                // Deselect previous selection
                if (selection != null && selection != m)
                {
                    selection.IsSelected = false;
                }
                selection = m;
                m.IsSelected = true;
            }
            else
            {
                if (selection == m)
                {
                    selection = null;
                    m.IsSelected = false;
                }
            }
        }

        public void ClearSelection()
        {
            if (selection != null)
            {
                selection.IsSelected = false;
                selection = null;
            }
        }

        public IEnumerable<AbstractButton> GetElements()
        {
            return buttons.AsEnumerable();
        }

        public ButtonModel GetSelection()
        {
            return selection;
        }

        public int GetButtonCount()
        {
            return buttons.Count;
        }

        public bool IsSelected(ButtonModel m)
        {
            return selection == m;
        }

        public void Remove(AbstractButton b)
        {
            buttons.Remove(b);
            if (b.Model == selection)
            {
                ClearSelection();
            }
        }

        public void Add(AbstractButton b)
        {
            buttons.Add(b);
            if (b.Model == selection)
            {
                // Already part of this group
            }
            else if (b.Model.IsSelected)
            {
                // If already selected, set through group to enforce single selection
                SetSelected(b.Model, true);
            }
        }
    }

    // Test class
    [TestFixture]
    public class ButtonGroupAutoTest
    {
        [Test]
        public void SetSelected_Test_6561()
        {
            ButtonGroup instance = new ButtonGroup();
            ButtonModel p0 = new ButtonModel();
            bool p1 = true;
            instance.SetSelected(p0, p1);
        }

        [Test]
        public void ClearSelection_Test_6562()
        {
            ButtonGroup instance = new ButtonGroup();
            instance.ClearSelection();
        }

        [Test]
        public void GetElements_Test_6563()
        {
            ButtonGroup instance = new ButtonGroup();
            instance.GetElements();
        }

        [Test]
        public void GetSelection_Test_6564()
        {
            ButtonGroup instance = new ButtonGroup();
            instance.GetSelection();
        }

        [Test]
        public void GetButtonCount_Test_6565()
        {
            ButtonGroup instance = new ButtonGroup();
            instance.GetButtonCount();
        }

        [Test]
        public void IsSelected_Test_6566()
        {
            ButtonGroup instance = new ButtonGroup();
            ButtonModel p0 = new ButtonModel();
            instance.IsSelected(p0);
        }

        [Test]
        public void Remove_Test_6567()
        {
            ButtonGroup instance = new ButtonGroup();
            AbstractButton p0 = new AbstractButton();
            instance.Remove(p0);
        }

        [Test]
        public void Add_Test_6568()
        {
            ButtonGroup instance = new ButtonGroup();
            AbstractButton p0 = new AbstractButton();
            instance.Add(p0);
        }
    }
}
```