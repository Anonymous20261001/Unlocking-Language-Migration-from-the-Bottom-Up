```csharp
using System;

namespace Generated.Test
{
    // C# equivalent of javax.print.attribute.standard.JobImpressionsSupported
    public class JobImpressionsSupported
    {
        private readonly int _lowerBound;
        private readonly int _upperBound;

        public JobImpressionsSupported(int lowerBound, int upperBound)
        {
            _lowerBound = lowerBound;
            _upperBound = upperBound;
        }

        // Mimics getCategory() in Java - returns the Type of this class
        public Type GetCategory()
        {
            return typeof(JobImpressionsSupported);
        }

        // Mimics getName() in Java
        public string GetName()
        {
            return "job-impressions-supported";
        }

        // Mimics equals(Object) - compares lower/upper bounds
        public override bool Equals(object obj)
        {
            if (obj is JobImpressionsSupported other)
            {
                return _lowerBound == other._lowerBound && _upperBound == other._upperBound;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(_lowerBound, _upperBound);
        }
    }

    // Test class corresponding to Java JobImpressionsSupportedAutoTest
    public class JobImpressionsSupportedAutoTest
    {
        [Test]
        public void GetCategory_Test_6130()
        {
            var instance = new JobImpressionsSupported(1, 10);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6131()
        {
            var instance = new JobImpressionsSupported(1, 10);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6132()
        {
            var instance = new JobImpressionsSupported(1, 10);
            object obj = null; // arbitrary object for equality test
            instance.Equals(obj);
        }
    }
}
```