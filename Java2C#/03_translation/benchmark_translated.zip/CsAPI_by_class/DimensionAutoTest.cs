```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.awt.Dimension
    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public Dimension()
        {
            Width = 0;
            Height = 0;
        }

        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }

        public double GetWidth()
        {
            return Width;
        }

        public double GetHeight()
        {
            return Height;
        }

        public override bool Equals(object obj)
        {
            if (obj is Dimension dim)
            {
                return Width == dim.Width && Height == dim.Height;
            }
            return false;
        }

        public override int GetHashCode()
        {
            // Java's Dimension hashCode: width ^ height
            return Width ^ Height;
        }

        public override string ToString()
        {
            return $"java.awt.Dimension[width={Width},height={Height}]";
        }

        public Dimension GetSize()
        {
            return new Dimension(Width, Height);
        }

        public void SetSize(Dimension d)
        {
            Width = d.Width;
            Height = d.Height;
        }

        public void SetSize(double width, double height)
        {
            Width = (int)Math.Round(width);
            Height = (int)Math.Round(height);
        }

        public void SetSize(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    [TestFixture]
    public class DimensionAutoTest
    {
        [Test]
        public void GetWidth_test_196()
        {
            Dimension instance = new Dimension();
            instance.GetWidth();
        }

        [Test]
        public void GetHeight_test_197()
        {
            Dimension instance = new Dimension();
            instance.GetHeight();
        }

        [Test]
        public void Equals_test_198([Values(null)] object p0)
        {
            Dimension instance = new Dimension();
            instance.Equals(p0);
        }

        [Test]
        public void ToString_test_199()
        {
            Dimension instance = new Dimension();
            instance.ToString();
        }

        [Test]
        public void HashCode_test_200()
        {
            Dimension instance = new Dimension();
            instance.GetHashCode();
        }

        [Test]
        public void GetSize_test_201()
        {
            Dimension instance = new Dimension();
            instance.GetSize();
        }

        [Test]
        public void SetSize_test_202([Values] Dimension p0)
        {
            // Provide a default Dimension value; NUnit will handle null if not specified
            Dimension instance = new Dimension();
            instance.SetSize(p0 ?? new Dimension());
        }

        [Test]
        public void SetSize_test_203(
            [Values(0.0)] double p0,
            [Values(0.0)] double p1)
        {
            Dimension instance = new Dimension();
            instance.SetSize(p0, p1);
        }

        [Test]
        public void SetSize_test_204(
            [Values(0)] int p0,
            [Values(0)] int p1)
        {
            Dimension instance = new Dimension();
            instance.SetSize(p0, p1);
        }
    }
}
```