```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.beans.FeatureDescriptor
    public class FeatureDescriptor
    {
        private string name = "";
        private string displayName = "";
        private string shortDescription = "";
        private bool expert = false;
        private bool hidden = false;
        private bool preferred = false;
        private readonly Dictionary<string, object> attributes = new Dictionary<string, object>();

        public void SetPreferred(bool value) => preferred = value;
        public bool IsPreferred() => preferred;

        public void SetShortDescription(string text) => shortDescription = text ?? "";
        public string GetShortDescription() => shortDescription;

        public void SetDisplayName(string text) => displayName = text ?? "";
        public string GetDisplayName() => displayName;

        public bool IsExpert() => expert;
        public void SetExpert(bool value) => expert = value;

        public void SetHidden(bool value) => hidden = value;
        public bool IsHidden() => hidden;

        public string[] AttributeNames() => attributes.Keys.ToArray();

        public string GetName() => name;
        public void SetName(string value) => name = value ?? "";

        public override string ToString() => string.IsNullOrEmpty(name) ? "FeatureDescriptor" : name;

        public object GetValue(string attributeName)
        {
            attributes.TryGetValue(attributeName, out var value);
            return value;
        }

        public void SetValue(string attributeName, object value)
        {
            attributes[attributeName] = value;
        }
    }

    [TestFixture]
    public class FeatureDescriptorAutoTest
    {
        [Test]
        public void setPreferred_test_1536([Values(false)] bool p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetPreferred(p0);
        }

        [Test]
        public void setShortDescription_test_1537([Values("")] string p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetShortDescription(p0);
        }

        [Test]
        public void setDisplayName_test_1538([Values("")] string p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetDisplayName(p0);
        }

        [Test]
        public void isExpert_test_1539()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.IsExpert();
        }

        [Test]
        public void setExpert_test_1540([Values(false)] bool p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetExpert(p0);
        }

        [Test]
        public void setHidden_test_1541([Values(false)] bool p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetHidden(p0);
        }

        [Test]
        public void isPreferred_test_1542()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.IsPreferred();
        }

        [Test]
        public void getShortDescription_test_1543()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.GetShortDescription();
        }

        [Test]
        public void attributeNames_test_1544()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.AttributeNames();
        }

        [Test]
        public void getName_test_1545()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.GetName();
        }

        [Test]
        public void toString_test_1546()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.ToString();
        }

        [Test]
        public void isHidden_test_1547()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.IsHidden();
        }

        [Test]
        public void getValue_test_1548([Values("")] string p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.GetValue(p0);
        }

        [Test]
        public void setName_test_1549([Values("")] string p0)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetName(p0);
        }

        [Test]
        public void setValue_test_1550([Values("")] string p0, [Values(null)] object p1)
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.SetValue(p0, p1);
        }

        [Test]
        public void getDisplayName_test_1551()
        {
            FeatureDescriptor instance = new FeatureDescriptor();
            instance.GetDisplayName();
        }
    }
}
```