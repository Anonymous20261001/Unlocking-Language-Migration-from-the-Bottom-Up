```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// ReSharper disable UnusedMember.Global - these classes are used in tests

namespace Generated.Test
{
    // ---------- Test class ----------
    [TestFixture]
    public class BasicSplitPaneDividerAutoTest
    {
        [Test]
        public void PropertyChange_test_8937()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            var evt = new PropertyChangeEvent(this, "property", null, null);
            instance.PropertyChange(evt);
        }

        [Test]
        public void SetBasicSplitPaneUI_test_8938()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            var newUi = new BasicSplitPaneUI();
            instance.SetBasicSplitPaneUI(newUi);
        }

        [Test]
        public void GetBasicSplitPaneUI_test_8939()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetBasicSplitPaneUI();
        }

        [Test]
        public void IsMouseOver_test_8940()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.IsMouseOver();
        }

        [Test]
        public void GetBorder_test_8941()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetBorder();
        }

        [Test]
        public void SetBorder_test_8942()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            var border = new Border();
            instance.SetBorder(border);
        }

        [Test]
        public void GetDividerSize_test_8943()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetDividerSize();
        }

        [Test]
        public void SetDividerSize_test_8944()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.SetDividerSize(5);
        }

        [Test]
        public void GetInsets_test_8945()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetInsets();
        }

        [Test]
        public void Paint_test_8946()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            var graphics = new Graphics();
            instance.Paint(graphics);
        }

        [Test]
        public void GetPreferredSize_test_8947()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetPreferredSize();
        }

        [Test]
        public void GetMinimumSize_test_8948()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.GetMinimumSize();
        }

        [Test]
        public void SetEnabled_test_8949()
        {
            var ui = new BasicSplitPaneUI();
            var instance = new BasicSplitPaneDivider(ui);
            instance.SetEnabled(true);
        }
    }

    // ---------- Equivalent C# classes ----------

    public class BasicSplitPaneDivider
    {
        private BasicSplitPaneUI _splitPaneUI;
        private Border _border;
        private int _dividerSize;
        private bool _enabled = true;

        public BasicSplitPaneDivider(BasicSplitPaneUI ui)
        {
            _splitPaneUI = ui ?? throw new ArgumentNullException(nameof(ui));
        }

        public void PropertyChange(PropertyChangeEvent evt) { /* no-op */ }

        public void SetBasicSplitPaneUI(BasicSplitPaneUI ui) => _splitPaneUI = ui;

        public BasicSplitPaneUI GetBasicSplitPaneUI() => _splitPaneUI;

        public bool IsMouseOver() => false; // stub

        public Border GetBorder() => _border;

        public void SetBorder(Border border) => _border = border;

        public int GetDividerSize() => _dividerSize;

        public void SetDividerSize(int size) => _dividerSize = size;

        public Insets GetInsets() => new Insets(0, 0, 0, 0);

        public void Paint(Graphics g) { /* no-op */ }

        public Dimension GetPreferredSize() => new Dimension(10, 10);

        public Dimension GetMinimumSize() => new Dimension(5, 5);

        public void SetEnabled(bool enabled) => _enabled = enabled;
    }

    public class BasicSplitPaneUI { /* stub */ }

    public class PropertyChangeEvent : EventArgs
    {
        public object Source { get; }
        public string PropertyName { get; }
        public object OldValue { get; }
        public object NewValue { get; }

        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            Source = source;
            PropertyName = propertyName;
            OldValue = oldValue;
            NewValue = newValue;
        }
    }

    public class Border { /* stub */ }

    public class Graphics { /* stub */ }

    public class Insets
    {
        public int Top { get; }
        public int Left { get; }
        public int Bottom { get; }
        public int Right { get; }

        public Insets(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    public class Dimension
    {
        public int Width { get; }
        public int Height { get; }

        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }
}
```