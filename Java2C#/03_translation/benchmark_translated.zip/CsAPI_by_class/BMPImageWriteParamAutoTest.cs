```csharp
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of javax.imageio.plugins.bmp.BMPImageWriteParam
    public class BMPImageWriteParam
    {
        private bool topDown;

        public void SetTopDown(bool value)
        {
            topDown = value;
        }

        public bool IsTopDown()
        {
            return topDown;
        }
    }

    [TestFixture]
    public class BMPImageWriteParamAutoTest
    {
        [Test]
        public void SetTopDown_Test_5390(bool p0)
        {
            BMPImageWriteParam instance = new BMPImageWriteParam();
            instance.SetTopDown(p0);
        }

        [Test]
        public void IsTopDown_Test_5391()
        {
            BMPImageWriteParam instance = new BMPImageWriteParam();
            instance.IsTopDown();
        }
    }
}
```