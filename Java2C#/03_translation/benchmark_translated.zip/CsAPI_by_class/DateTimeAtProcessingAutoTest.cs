```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of Java's javax.print.attribute.standard.DateTimeAtProcessing.
    /// Represents a date-time attribute for processing.
    /// </summary>
    public class DateTimeAtProcessing
    {
        private readonly DateTime date;

        public DateTimeAtProcessing(DateTime date)
        {
            this.date = date;
        }

        /// <summary>
        /// Returns the category (type) of this attribute.
        /// </summary>
        public Type GetCategory()
        {
            return typeof(DateTimeAtProcessing);
        }

        /// <summary>
        /// Returns the name of this attribute.
        /// </summary>
        public string GetName()
        {
            return "datetime-at-processing";
        }

        /// <summary>
        /// Compares this DateTimeAtProcessing with another object for equality.
        /// Two instances are equal if they have the same date value and are of the same type.
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            DateTimeAtProcessing other = (DateTimeAtProcessing)obj;
            return date.Equals(other.date);
        }

        /// <summary>
        /// Returns a hash code for this instance.
        /// </summary>
        public override int GetHashCode()
        {
            return date.GetHashCode();
        }
    }

    [TestFixture]
    public class DateTimeAtProcessingAutoTest
    {
        [Test]
        public void getCategory_test_6109()
        {
            DateTimeAtProcessing instance = new DateTimeAtProcessing(DateTime.Now);
            instance.GetCategory();
        }

        [Test]
        public void getName_test_6110()
        {
            DateTimeAtProcessing instance = new DateTimeAtProcessing(DateTime.Now);
            instance.GetName();
        }

        [Test]
        public void equals_test_6111()
        {
            DateTimeAtProcessing instance = new DateTimeAtProcessing(DateTime.Now);
            instance.Equals(new object());
        }
    }
}
```