```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class PBEKeySpecAutoTest
    {
        [Test]
        public void GetSalt_Test_5254()
        {
            char[] c0 = "testpassword".ToCharArray();
            var instance = new PBEKeySpec(c0);
            instance.GetSalt();
        }

        [Test]
        public void GetIterationCount_Test_5255()
        {
            char[] c0 = "testpassword".ToCharArray();
            var instance = new PBEKeySpec(c0);
            instance.GetIterationCount();
        }

        [Test]
        public void GetKeyLength_Test_5256()
        {
            char[] c0 = "testpassword".ToCharArray();
            var instance = new PBEKeySpec(c0);
            instance.GetKeyLength();
        }

        [Test]
        public void GetPassword_Test_5257()
        {
            char[] c0 = "testpassword".ToCharArray();
            var instance = new PBEKeySpec(c0);
            instance.GetPassword();
        }

        [Test]
        public void ClearPassword_Test_5258()
        {
            char[] c0 = "testpassword".ToCharArray();
            var instance = new PBEKeySpec(c0);
            instance.ClearPassword();
        }
    }

    public class PBEKeySpec
    {
        private char[] password;
        private byte[] salt;
        private int iterationCount;
        private int keyLength;

        public PBEKeySpec(char[] password)
        {
            // Clone to prevent external modification (Java behavior)
            this.password = (char[])password.Clone();
            this.salt = null;
            this.iterationCount = 0;
            this.keyLength = 0;
        }

        public byte[] GetSalt()
        {
            // Return a copy of the salt, or null if not set
            return salt?.Clone() as byte[];
        }

        public int GetIterationCount()
        {
            return iterationCount;
        }

        public int GetKeyLength()
        {
            return keyLength;
        }

        public char[] GetPassword()
        {
            // Return a copy of the password (even after clearing)
            return (char[])password.Clone();
        }

        public void ClearPassword()
        {
            // Zero out the internal password array
            Array.Clear(password, 0, password.Length);
        }
    }
}
```