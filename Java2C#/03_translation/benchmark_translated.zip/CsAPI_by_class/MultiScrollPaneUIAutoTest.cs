```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes to mimic Java counterparts
    public class Graphics { }

    public class JComponent { }

    public class ComponentUI { }

    public class MultiScrollPaneUI : ComponentUI
    {
        public void InstallUI(JComponent c) { }

        public void UninstallUI(JComponent c) { }

        public ComponentUI[] GetUIs() => new ComponentUI[0];

        public static MultiScrollPaneUI CreateUI(JComponent c) => new MultiScrollPaneUI();

        public Size? GetMaximumSize(JComponent c) => null;

        public void Paint(Graphics g, JComponent c) { }

        public int GetAccessibleChildrenCount(JComponent c) => 0;

        public object GetAccessibleChild(JComponent c, int i) => null;

        public Size? GetPreferredSize(JComponent c) => null;

        public Size? GetMinimumSize(JComponent c) => null;

        public void Update(Graphics g, JComponent c) { }

        public bool Contains(JComponent c, int x, int y) => false;
    }

    [TestFixture]
    public class MultiScrollPaneUIAutoTest
    {
        [Test]
        public void InstallUI_test_9525()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.InstallUI(p0);
        }

        [Test]
        public void UninstallUI_test_9526()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.UninstallUI(p0);
        }

        [Test]
        public void GetUIs_test_9527()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            instance.GetUIs();
        }

        [Test]
        public void CreateUI_test_9528()
        {
            JComponent p0 = new JComponent();
            MultiScrollPaneUI.CreateUI(p0);
        }

        [Test]
        public void GetMaximumSize_test_9529()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.GetMaximumSize(p0);
        }

        [Test]
        public void Paint_test_9530()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            Graphics p0 = new Graphics();
            JComponent p1 = new JComponent();
            instance.Paint(p0, p1);
        }

        [Test]
        public void GetAccessibleChildrenCount_test_9531()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.GetAccessibleChildrenCount(p0);
        }

        [Test]
        public void GetAccessibleChild_test_9532()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            int p1 = 0;
            instance.GetAccessibleChild(p0, p1);
        }

        [Test]
        public void GetPreferredSize_test_9533()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.GetPreferredSize(p0);
        }

        [Test]
        public void GetMinimumSize_test_9534()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            instance.GetMinimumSize(p0);
        }

        [Test]
        public void Update_test_9535()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            Graphics p0 = new Graphics();
            JComponent p1 = new JComponent();
            instance.Update(p0, p1);
        }

        [Test]
        public void Contains_test_9536()
        {
            MultiScrollPaneUI instance = new MultiScrollPaneUI();
            JComponent p0 = new JComponent();
            int p1 = 0;
            int p2 = 0;
            instance.Contains(p0, p1, p2);
        }
    }
}
```