```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // Simulates Java's ChangeEvent (minimal version)
    public class ChangeEvent : EventArgs
    {
        public object Source { get; }

        public ChangeEvent(object source)
        {
            Source = source;
        }
    }

    // Interface equivalent to Java's ChangeListener
    public interface IChangeListener
    {
        void StateChanged(ChangeEvent e);
    }

    // C# equivalent of javax.swing.DefaultBoundedRangeModel
    public class DefaultBoundedRangeModel
    {
        private int _value;
        private int _extent;
        private int _min;
        private int _max;
        private bool _valueIsAdjusting;
        private readonly List<IChangeListener> _listeners = new List<IChangeListener>();

        public DefaultBoundedRangeModel()
        {
            // Default Swing values: value=0, extent=0, min=0, max=100
            _value = 0;
            _extent = 0;
            _min = 0;
            _max = 100;
            _valueIsAdjusting = false;
        }

        public int GetValue() => _value;
        public int GetExtent() => _extent;
        public int GetMinimum() => _min;
        public int GetMaximum() => _max;
        public bool GetValueIsAdjusting() => _valueIsAdjusting;

        public void SetValue(int newValue)
        {
            if (newValue != _value)
            {
                int oldValue = _value;
                _value = Math.Max(_min, Math.Min(newValue, _max - _extent));
                FireStateChanged();
            }
        }

        public void SetExtent(int newExtent)
        {
            if (newExtent != _extent)
            {
                _extent = Math.Max(0, newExtent);
                // Adjust value if necessary
                if (_value + _extent > _max)
                {
                    _value = _max - _extent;
                }
                FireStateChanged();
            }
        }

        public void SetMinimum(int newMin)
        {
            if (newMin != _min)
            {
                _min = newMin;
                if (_max < _min) _max = _min;
                if (_value < _min) _value = _min;
                if (_value + _extent > _max) _value = _max - _extent;
                FireStateChanged();
            }
        }

        public void SetMaximum(int newMax)
        {
            if (newMax != _max)
            {
                _max = newMax;
                if (_min > _max) _min = _max;
                if (_value > _max) _value = _max;
                if (_value + _extent > _max) _extent = _max - _value;
                FireStateChanged();
            }
        }

        public void SetValueIsAdjusting(bool newValue)
        {
            if (newValue != _valueIsAdjusting)
            {
                _valueIsAdjusting = newValue;
                FireStateChanged();
            }
        }

        public void SetRangeProperties(int value, int extent, int min, int max, bool adjusting)
        {
            bool changed = false;

            if (value != _value || extent != _extent || min != _min || max != _max || adjusting != _valueIsAdjusting)
            {
                _value = Math.Max(min, Math.Min(value, max - extent));
                _extent = Math.Max(0, extent);
                _min = min;
                _max = max;
                _valueIsAdjusting = adjusting;
                // Clamp value and extent after setting bounds
                if (_min > _max) _min = _max;
                if (_value < _min) _value = _min;
                if (_value > _max) _value = _max;
                if (_extent > _max - _min) _extent = _max - _min;
                if (_value + _extent > _max) _value = _max - _extent;
                FireStateChanged();
            }
        }

        public void AddChangeListener(IChangeListener listener)
        {
            if (listener == null) throw new ArgumentNullException(nameof(listener));
            if (!_listeners.Contains(listener))
                _listeners.Add(listener);
        }

        public void RemoveChangeListener(IChangeListener listener)
        {
            _listeners.Remove(listener);
        }

        public IChangeListener[] GetChangeListeners()
        {
            return _listeners.ToArray();
        }

        public object[] GetListeners(Type listenerType)
        {
            return _listeners.Where(l => listenerType.IsAssignableFrom(l.GetType())).ToArray();
        }

        public override string ToString()
        {
            return $"{GetType().Name}[value={_value}, extent={_extent}, min={_min}, max={_max}, adjusting={_valueIsAdjusting}]";
        }

        private void FireStateChanged()
        {
            var e = new ChangeEvent(this);
            // Clone list to avoid modification during iteration
            var listeners = _listeners.ToList();
            foreach (var listener in listeners)
            {
                listener.StateChanged(e);
            }
        }
    }

    [TestFixture]
    public class DefaultBoundedRangeModelAutoTest
    {
        [Test]
        public void SetRangeProperties_Test_6635(int p0, int p1, int p2, int p3, bool p4)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetRangeProperties(p0, p1, p2, p3, p4);
        }

        [Test]
        public void GetExtent_Test_6636()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetExtent();
        }

        [Test]
        public void SetExtent_Test_6637(int p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetExtent(p0);
        }

        [Test]
        public void AddChangeListener_Test_6638(IChangeListener p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.AddChangeListener(p0);
        }

        [Test]
        public void RemoveChangeListener_Test_6639(IChangeListener p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.RemoveChangeListener(p0);
        }

        [Test]
        public void GetChangeListeners_Test_6640()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetChangeListeners();
        }

        [Test]
        public void GetListeners_Test_6641(Type p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetListeners(p0);
        }

        [Test]
        public void SetMinimum_Test_6642(int p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetMinimum(p0);
        }

        [Test]
        public void SetMaximum_Test_6643(int p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetMaximum(p0);
        }

        [Test]
        public void SetValueIsAdjusting_Test_6644(bool p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetValueIsAdjusting(p0);
        }

        [Test]
        public void GetValueIsAdjusting_Test_6645()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetValueIsAdjusting();
        }

        [Test]
        public void ToString_Test_6646()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.ToString();
        }

        [Test]
        public void GetValue_Test_6647()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetValue();
        }

        [Test]
        public void SetValue_Test_6648(int p0)
        {
            var instance = new DefaultBoundedRangeModel();
            instance.SetValue(p0);
        }

        [Test]
        public void GetMaximum_Test_6649()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetMaximum();
        }

        [Test]
        public void GetMinimum_Test_6650()
        {
            var instance = new DefaultBoundedRangeModel();
            instance.GetMinimum();
        }
    }
}
```