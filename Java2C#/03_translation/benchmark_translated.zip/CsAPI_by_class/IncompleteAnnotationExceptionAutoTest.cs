```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class IncompleteAnnotationException : Exception
    {
        public Type AnnotationType { get; }
        public string ElementName { get; }

        public IncompleteAnnotationException(Type annotationType, string elementName)
            : base($"Annotation type not found: {annotationType} for element: {elementName}")
        {
            AnnotationType = annotationType ?? throw new ArgumentNullException(nameof(annotationType));
            ElementName = elementName ?? throw new ArgumentNullException(nameof(elementName));
        }
    }

    [TestFixture]
    public class IncompleteAnnotationExceptionAutoTest
    {
        [Test]
        public void AnnotationType_test_2374()
        {
            var instance = new IncompleteAnnotationException(typeof(string), "test");
            var result = instance.AnnotationType;
        }

        [Test]
        public void ElementName_test_2375()
        {
            var instance = new IncompleteAnnotationException(typeof(string), "test");
            var result = instance.ElementName;
        }
    }
}
```