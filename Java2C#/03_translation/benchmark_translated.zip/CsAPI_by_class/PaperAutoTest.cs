```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class PaperAutoTest
    {
        [Test]
        public void GetImageableY_Test_1499()
        {
            Paper instance = new Paper();
            instance.GetImageableY();
        }

        [Test]
        public void GetImageableHeight_Test_1500()
        {
            Paper instance = new Paper();
            instance.GetImageableHeight();
        }

        [Test]
        public void GetImageableX_Test_1501()
        {
            Paper instance = new Paper();
            instance.GetImageableX();
        }

        [Test]
        public void GetImageableWidth_Test_1502()
        {
            Paper instance = new Paper();
            instance.GetImageableWidth();
        }

        [Test]
        public void SetImageableArea_Test_1503(double p0, double p1, double p2, double p3)
        {
            Paper instance = new Paper();
            instance.SetImageableArea(p0, p1, p2, p3);
        }

        [Test]
        public void GetWidth_Test_1504()
        {
            Paper instance = new Paper();
            instance.GetWidth();
        }

        [Test]
        public void GetHeight_Test_1505()
        {
            Paper instance = new Paper();
            instance.GetHeight();
        }

        [Test]
        public void Clone_Test_1506()
        {
            Paper instance = new Paper();
            instance.Clone();
        }

        [Test]
        public void SetSize_Test_1507(double p0, double p1)
        {
            Paper instance = new Paper();
            instance.SetSize(p0, p1);
        }
    }

    public class Paper
    {
        private double width = 612;   // US Letter width in points (8.5 inches)
        private double height = 792;  // US Letter height in points (11 inches)
        private double imageableX = 0;
        private double imageableY = 0;
        private double imageableWidth = 612;
        private double imageableHeight = 792;

        public Paper()
        {
        }

        // Copy constructor used by Clone
        private Paper(Paper other)
        {
            width = other.width;
            height = other.height;
            imageableX = other.imageableX;
            imageableY = other.imageableY;
            imageableWidth = other.imageableWidth;
            imageableHeight = other.imageableHeight;
        }

        public double GetImageableY()
        {
            return imageableY;
        }

        public double GetImageableHeight()
        {
            return imageableHeight;
        }

        public double GetImageableX()
        {
            return imageableX;
        }

        public double GetImageableWidth()
        {
            return imageableWidth;
        }

        public void SetImageableArea(double x, double y, double w, double h)
        {
            if (x < 0 || y < 0 || w <= 0 || h <= 0 ||
                x + w > width || y + h > height)
            {
                throw new ArgumentException("Invalid imageable area parameters");
            }
            imageableX = x;
            imageableY = y;
            imageableWidth = w;
            imageableHeight = h;
        }

        public double GetWidth()
        {
            return width;
        }

        public double GetHeight()
        {
            return height;
        }

        public Paper Clone()
        {
            return new Paper(this);
        }

        public void SetSize(double w, double h)
        {
            if (w <= 0 || h <= 0)
            {
                throw new ArgumentException("Width and height must be positive");
            }
            width = w;
            height = h;
        }
    }
}
```