```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Tests
{
    // C# equivalent of java.awt.Cursor
    public class Cursor
    {
        // Predefined cursor type constants (matching Java's Cursor)
        public const int DEFAULT_CURSOR = 0;
        public const int CROSSHAIR_CURSOR = 1;
        public const int TEXT_CURSOR = 2;
        public const int WAIT_CURSOR = 3;
        public const int SW_RESIZE_CURSOR = 4;
        public const int SE_RESIZE_CURSOR = 5;
        public const int NW_RESIZE_CURSOR = 6;
        public const int NE_RESIZE_CURSOR = 7;
        public const int N_RESIZE_CURSOR = 8;
        public const int S_RESIZE_CURSOR = 9;
        public const int W_RESIZE_CURSOR = 10;
        public const int E_RESIZE_CURSOR = 11;
        public const int HAND_CURSOR = 12;
        public const int MOVE_CURSOR = 13;

        private readonly int _type;

        // Static mapping from type to name (mimics Java's internal string conversion)
        private static readonly Dictionary<int, string> TypeNames = new Dictionary<int, string>
        {
            { DEFAULT_CURSOR, "Default Cursor" },
            { CROSSHAIR_CURSOR, "Crosshair Cursor" },
            { TEXT_CURSOR, "Text Cursor" },
            { WAIT_CURSOR, "Wait Cursor" },
            { SW_RESIZE_CURSOR, "Southwest Resize Cursor" },
            { SE_RESIZE_CURSOR, "Southeast Resize Cursor" },
            { NW_RESIZE_CURSOR, "Northwest Resize Cursor" },
            { NE_RESIZE_CURSOR, "Northeast Resize Cursor" },
            { N_RESIZE_CURSOR, "North Resize Cursor" },
            { S_RESIZE_CURSOR, "South Resize Cursor" },
            { W_RESIZE_CURSOR, "West Resize Cursor" },
            { E_RESIZE_CURSOR, "East Resize Cursor" },
            { HAND_CURSOR, "Hand Cursor" },
            { MOVE_CURSOR, "Move Cursor" }
        };

        public Cursor(int type)
        {
            _type = type;
        }

        public int GetType()
        {
            return _type;
        }

        public string GetName()
        {
            return TypeNames.TryGetValue(_type, out var name) ? name : "Custom Cursor";
        }

        public override string ToString()
        {
            return $"{GetType().Name}[{GetName()}]";
        }

        // Static factory methods
        public static Cursor GetPredefinedCursor(int type)
        {
            return new Cursor(type);
        }

        public static Cursor GetDefaultCursor()
        {
            return new Cursor(DEFAULT_CURSOR);
        }
    }

    // Test class (NUnit)
    [TestFixture]
    public class CursorAutoTest
    {
        [Test]
        public void GetPredefinedCursor_Test_164()
        {
            int p0 = 0; // Using DEFAULT_CURSOR as an example
            int c0 = 0;
            Cursor instance = new Cursor(c0);
            Cursor.GetPredefinedCursor(p0);
        }

        [Test]
        public void GetDefaultCursor_Test_165()
        {
            int c0 = 0;
            Cursor instance = new Cursor(c0);
            Cursor.GetDefaultCursor();
        }

        [Test]
        public void GetName_Test_166()
        {
            int c0 = 0;
            Cursor instance = new Cursor(c0);
            instance.GetName();
        }

        [Test]
        public void ToString_Test_167()
        {
            int c0 = 0;
            Cursor instance = new Cursor(c0);
            instance.ToString();
        }

        [Test]
        public void GetType_Test_168()
        {
            int c0 = 0;
            Cursor instance = new Cursor(c0);
            instance.GetType();
        }
    }
}
```