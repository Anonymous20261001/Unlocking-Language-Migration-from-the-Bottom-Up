```csharp
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class NumberUpAutoTest
    {
        [Test]
        public void GetCategory_Test_6192()
        {
            int c0 = 0; // placeholder value
            NumberUp instance = new NumberUp(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6193()
        {
            int c0 = 0; // placeholder value
            NumberUp instance = new NumberUp(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6194()
        {
            object p0 = null; // placeholder value
            int c0 = 0;       // placeholder value
            NumberUp instance = new NumberUp(c0);
            instance.Equals(p0);
        }
    }

    public class NumberUp
    {
        private readonly int _value;

        public NumberUp(int value)
        {
            _value = value;
        }

        public System.Type GetCategory()
        {
            return typeof(NumberUp);
        }

        public string GetName()
        {
            return "number-up";
        }

        public override bool Equals(object obj)
        {
            if (obj is NumberUp other)
            {
                return _value == other._value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }
    }
}
```