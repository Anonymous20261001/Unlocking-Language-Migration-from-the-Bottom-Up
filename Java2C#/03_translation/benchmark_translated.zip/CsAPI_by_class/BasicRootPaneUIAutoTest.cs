```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // Simulate java.beans.PropertyChangeEvent
    public class PropertyChangeEvent : EventArgs
    {
        public object Source { get; }
        public string PropertyName { get; }
        public object OldValue { get; }
        public object NewValue { get; }

        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            Source = source;
            PropertyName = propertyName;
            OldValue = oldValue;
            NewValue = newValue;
        }
    }

    // Simulate javax.swing.JComponent (simplified)
    public class JComponent
    {
        // Minimal implementation, no fields or methods required for these tests
    }

    // Simulate javax.swing.plaf.basic.BasicRootPaneUI
    public class BasicRootPaneUI
    {
        public void PropertyChange(PropertyChangeEvent evt)
        {
            // Stub: no behavior needed for tests
        }

        public void InstallUI(JComponent c)
        {
            // Stub
        }

        public void UninstallUI(JComponent c)
        {
            // Stub
        }

        public static BasicRootPaneUI CreateUI(JComponent c)
        {
            // In Java, returns a new instance of BasicRootPaneUI
            return new BasicRootPaneUI();
        }
    }

    [TestFixture]
    public class BasicRootPaneUIAutoTest
    {
        [Test]
        public void PropertyChange_Test_8878()
        {
            // Create a dummy PropertyChangeEvent (source, propertyName, oldValue, newValue)
            var p0 = new PropertyChangeEvent(this, "testProperty", "old", "new");
            var instance = new BasicRootPaneUI();
            instance.PropertyChange(p0);
        }

        [Test]
        public void InstallUI_Test_8879()
        {
            var p0 = new JComponent();
            var instance = new BasicRootPaneUI();
            instance.InstallUI(p0);
        }

        [Test]
        public void UninstallUI_Test_8880()
        {
            var p0 = new JComponent();
            var instance = new BasicRootPaneUI();
            instance.UninstallUI(p0);
        }

        [Test]
        public void CreateUI_Test_8881()
        {
            var p0 = new JComponent();
            BasicRootPaneUI instance = new BasicRootPaneUI();
            BasicRootPaneUI.CreateUI(p0);
        }
    }
}
```