```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class PopupFactory
    {
        private static PopupFactory sharedInstance;

        public PopupFactory() { }

        public static void SetSharedInstance(PopupFactory factory)
        {
            sharedInstance = factory;
        }

        public static PopupFactory GetSharedInstance()
        {
            return sharedInstance;
        }
    }

    [TestFixture]
    public class PopupFactoryAutoTest
    {
        [Test]
        public void SetSharedInstance_test_8219()
        {
            PopupFactory p0 = new PopupFactory();
            PopupFactory instance = new PopupFactory();
            PopupFactory.SetSharedInstance(p0);
        }

        [Test]
        public void GetSharedInstance_test_8220()
        {
            PopupFactory instance = new PopupFactory();
            PopupFactory.GetSharedInstance();
        }
    }
}
```