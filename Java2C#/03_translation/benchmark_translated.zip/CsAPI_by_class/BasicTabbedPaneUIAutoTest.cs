```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes for Java Swing equivalents

    public abstract class Graphics
    {
        // Minimal stub; no actual drawing capabilities needed
    }

    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public Dimension() { }
        public Dimension(int w, int h) { Width = w; Height = h; }
    }

    public class Rectangle
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Rectangle() { }
        public Rectangle(int x, int y, int w, int h) { X = x; Y = y; Width = w; Height = h; }
    }

    public enum BaselineResizeBehavior
    {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    }

    public class JComponent
    {
        // Minimal stub
    }

    public class JTabbedPane : JComponent
    {
        // Minimal stub
    }

    public class ComponentUI
    {
        // Base class for UI delegates
        public virtual void InstallUI(JComponent c) { }
        public virtual void UninstallUI(JComponent c) { }
        public virtual void Paint(Graphics g, JComponent c) { }
        public virtual Dimension GetMinimumSize(JComponent c) => new Dimension(0, 0);
        public virtual Dimension GetMaximumSize(JComponent c) => new Dimension(0, 0);
        public virtual int GetBaseline(JComponent c, int width, int height) => 0;
        public virtual BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c) => BaselineResizeBehavior.OTHER;
    }

    public class BasicTabbedPaneUI : ComponentUI
    {
        // Mimics javax.swing.plaf.basic.BasicTabbedPaneUI

        public int GetTabRunCount(JTabbedPane pane)
        {
            // Stub: return 0
            return 0;
        }

        public Rectangle GetTabBounds(JTabbedPane pane, int tabIndex)
        {
            // Stub: return empty rectangle
            return new Rectangle();
        }

        public int TabForCoordinate(JTabbedPane pane, int x, int y)
        {
            // Stub: return -1 (no tab)
            return -1;
        }

        public static BasicTabbedPaneUI CreateUI(JComponent c)
        {
            // Stub: return new instance
            return new BasicTabbedPaneUI();
        }

        // Override base class methods to match Java API
        public override void InstallUI(JComponent c) { }
        public override void UninstallUI(JComponent c) { }
        public override void Paint(Graphics g, JComponent c) { }
        public override Dimension GetMinimumSize(JComponent c) => new Dimension(10, 10);
        public override Dimension GetMaximumSize(JComponent c) => new Dimension(100, 100);
        public override int GetBaseline(JComponent c, int width, int height) => 0;
        public override BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c) => BaselineResizeBehavior.CONSTANT_ASCENT;
    }

    // Tests
    [TestFixture]
    public class BasicTabbedPaneUIAutoTest
    {
        [Test]
        public void GetTabRunCount_test_8974()
        {
            var p0 = new JTabbedPane();
            var instance = new BasicTabbedPaneUI();
            instance.GetTabRunCount(p0);
        }

        [Test]
        public void GetTabBounds_test_8975()
        {
            var p0 = new JTabbedPane();
            int p1 = 0;
            var instance = new BasicTabbedPaneUI();
            instance.GetTabBounds(p0, p1);
        }

        [Test]
        public void TabForCoordinate_test_8976()
        {
            var p0 = new JTabbedPane();
            int p1 = 0;
            int p2 = 0;
            var instance = new BasicTabbedPaneUI();
            instance.TabForCoordinate(p0, p1, p2);
        }

        [Test]
        public void InstallUI_test_8977()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.InstallUI(p0);
        }

        [Test]
        public void UninstallUI_test_8978()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.UninstallUI(p0);
        }

        [Test]
        public void CreateUI_test_8979()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            BasicTabbedPaneUI.CreateUI(p0);
        }

        [Test]
        public void GetMaximumSize_test_8980()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.GetMaximumSize(p0);
        }

        [Test]
        public void Paint_test_8981()
        {
            var p0 = new Graphics();
            var p1 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.Paint(p0, p1);
        }

        [Test]
        public void GetMinimumSize_test_8982()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.GetMinimumSize(p0);
        }

        [Test]
        public void GetBaseline_test_8983()
        {
            var p0 = new JComponent();
            int p1 = 100;
            int p2 = 50;
            var instance = new BasicTabbedPaneUI();
            instance.GetBaseline(p0, p1, p2);
        }

        [Test]
        public void GetBaselineResizeBehavior_test_8984()
        {
            var p0 = new JComponent();
            var instance = new BasicTabbedPaneUI();
            instance.GetBaselineResizeBehavior(p0);
        }
    }
}
```