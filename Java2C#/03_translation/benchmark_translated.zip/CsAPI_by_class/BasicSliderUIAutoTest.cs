```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes to mimic Java AWT/Swing API
    public class Graphics { }

    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public Dimension() : this(0, 0) { }
        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    public enum BaselineResizeBehavior
    {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    }

    public class JComponent
    {
        // Minimal stub – no actual Swing behavior
    }

    public class JSlider : JComponent
    {
        // Minimal stub – no actual slider state
    }

    public class BasicSliderUI
    {
        private JSlider slider;

        public BasicSliderUI(JSlider slider)
        {
            this.slider = slider;
        }

        public void PaintThumb(Graphics g) { }
        public void ScrollByBlock(int direction) { }
        public void ScrollByUnit(int direction) { }
        public Dimension GetPreferredVerticalSize() => new Dimension();
        public Dimension GetPreferredHorizontalSize() => new Dimension();
        public Dimension GetMinimumVerticalSize() => new Dimension();
        public Dimension GetMinimumHorizontalSize() => new Dimension();
        public void SetThumbLocation(int x, int y) { }
        public int ValueForYPosition(int yPos) => 0;
        public int ValueForXPosition(int xPos) => 0;
        public void InstallUI(JComponent c) { }
        public void UninstallUI(JComponent c) { }
        public void PaintTicks(Graphics g) { }
        public void PaintTrack(Graphics g) { }
        public void PaintLabels(Graphics g) { }
        public void PaintFocus(Graphics g) { }

        public static BasicSliderUI CreateUI(JComponent c) => new BasicSliderUI(null);

        public Dimension GetMaximumSize(JComponent c) => new Dimension();
        public void Paint(Graphics g, JComponent c) { }
        public Dimension GetPreferredSize(JComponent c) => new Dimension();
        public Dimension GetMinimumSize(JComponent c) => new Dimension();
        public int GetBaseline(JComponent c, int width, int height) => 0;
        public BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c) => BaselineResizeBehavior.OTHER;
    }

    // Test class mirroring the Java JUnit tests
    [TestFixture]
    public class BasicSliderUIAutoTest
    {
        [Test]
        public void PaintThumb_Test_8909(Graphics p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.PaintThumb(p0);
        }

        [Test]
        public void ScrollByBlock_Test_8910(int p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.ScrollByBlock(p0);
        }

        [Test]
        public void ScrollByUnit_Test_8911(int p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.ScrollByUnit(p0);
        }

        [Test]
        public void GetPreferredVerticalSize_Test_8912(JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetPreferredVerticalSize();
        }

        [Test]
        public void GetPreferredHorizontalSize_Test_8913(JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetPreferredHorizontalSize();
        }

        [Test]
        public void GetMinimumVerticalSize_Test_8914(JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetMinimumVerticalSize();
        }

        [Test]
        public void GetMinimumHorizontalSize_Test_8915(JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetMinimumHorizontalSize();
        }

        [Test]
        public void SetThumbLocation_Test_8916(int p0, int p1, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.SetThumbLocation(p0, p1);
        }

        [Test]
        public void ValueForYPosition_Test_8917(int p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.ValueForYPosition(p0);
        }

        [Test]
        public void ValueForXPosition_Test_8918(int p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.ValueForXPosition(p0);
        }

        [Test]
        public void InstallUI_Test_8919(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.InstallUI(p0);
        }

        [Test]
        public void UninstallUI_Test_8920(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.UninstallUI(p0);
        }

        [Test]
        public void PaintTicks_Test_8921(Graphics p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.PaintTicks(p0);
        }

        [Test]
        public void PaintTrack_Test_8922(Graphics p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.PaintTrack(p0);
        }

        [Test]
        public void PaintLabels_Test_8923(Graphics p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.PaintLabels(p0);
        }

        [Test]
        public void PaintFocus_Test_8924(Graphics p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.PaintFocus(p0);
        }

        [Test]
        public void CreateUI_Test_8925(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            BasicSliderUI.CreateUI(p0);
        }

        [Test]
        public void GetMaximumSize_Test_8926(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetMaximumSize(p0);
        }

        [Test]
        public void Paint_Test_8927(Graphics p0, JComponent p1, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.Paint(p0, p1);
        }

        [Test]
        public void GetPreferredSize_Test_8928(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetPreferredSize(p0);
        }

        [Test]
        public void GetMinimumSize_Test_8929(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetMinimumSize(p0);
        }

        [Test]
        public void GetBaseline_Test_8930(JComponent p0, int p1, int p2, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetBaseline(p0, p1, p2);
        }

        [Test]
        public void GetBaselineResizeBehavior_Test_8931(JComponent p0, JSlider c0)
        {
            BasicSliderUI instance = new BasicSliderUI(c0);
            instance.GetBaselineResizeBehavior(p0);
        }
    }
}
```