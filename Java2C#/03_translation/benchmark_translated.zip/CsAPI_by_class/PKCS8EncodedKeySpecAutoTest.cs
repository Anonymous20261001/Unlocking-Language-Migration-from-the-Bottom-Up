```csharp
using NUnit.Framework;

namespace GeneratedTest
{
    /// <summary>
    /// C# equivalent of Java's java.security.spec.PKCS8EncodedKeySpec.
    /// Represents an encoded PKCS#8 private key.
    /// </summary>
    public class PKCS8EncodedKeySpec
    {
        private readonly byte[] _encodedKey;

        public PKCS8EncodedKeySpec(byte[] encodedKey)
        {
            _encodedKey = encodedKey;
        }

        public byte[] GetEncoded()
        {
            return _encodedKey;
        }

        public string GetFormat()
        {
            return "PKCS#8";
        }
    }

    [TestFixture]
    public class PKCS8EncodedKeySpecAutoTest
    {
        [Test]
        public void GetEncoded_test_2898()
        {
            byte[] c0 = new byte[0]; // default empty array, no specific test data provided
            var instance = new PKCS8EncodedKeySpec(c0);
            instance.GetEncoded();
        }

        [Test]
        public void GetFormat_test_2899()
        {
            byte[] c0 = new byte[0]; // default empty array, no specific test data provided
            var instance = new PKCS8EncodedKeySpec(c0);
            instance.GetFormat();
        }
    }
}
```