```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of Java's javax.print.attribute.standard.JobKOctetsProcessed.
    /// </summary>
    public class JobKOctetsProcessed
    {
        private readonly int _value;

        public JobKOctetsProcessed(int value)
        {
            _value = value;
        }

        /// <summary>
        /// Returns the category (type) of this attribute.
        /// </summary>
        public Type GetCategory()
        {
            return typeof(JobKOctetsProcessed);
        }

        /// <summary>
        /// Returns the name of this attribute.
        /// </summary>
        public string GetName()
        {
            return "job-k-octets-processed";
        }

        /// <summary>
        /// Compares this object to another for equality. Two JobKOctetsProcessed
        /// objects are equal if they have the same integer value.
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj is JobKOctetsProcessed other)
            {
                return _value == other._value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }
    }

    [TestFixture]
    public class JobKOctetsProcessedAutoTest
    {
        [TestCase(0)]
        public void getCategory_test_6136(int c0)
        {
            var instance = new JobKOctetsProcessed(c0);
            instance.GetCategory();
        }

        [TestCase(0)]
        public void getName_test_6137(int c0)
        {
            var instance = new JobKOctetsProcessed(c0);
            instance.GetName();
        }

        [TestCase(null, 0)]
        public void equals_test_6138(object p0, int c0)
        {
            var instance = new JobKOctetsProcessed(c0);
            instance.Equals(p0);
        }
    }
}
```