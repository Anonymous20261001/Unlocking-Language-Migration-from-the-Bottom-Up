```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# implementation of javax.crypto.spec.RC5ParameterSpec
    public class RC5ParameterSpec
    {
        private readonly int version;
        private readonly int rounds;
        private readonly int wordSize;
        private readonly byte[] iv;

        public RC5ParameterSpec(int version, int rounds, int wordSize)
        {
            this.version = version;
            this.rounds = rounds;
            this.wordSize = wordSize;
            this.iv = null;
        }

        public byte[] GetIV()
        {
            return iv; // may be null
        }

        public int GetRounds()
        {
            return rounds;
        }

        public int GetWordSize()
        {
            return wordSize;
        }

        public int GetVersion()
        {
            return version;
        }

        public override bool Equals(object obj)
        {
            if (obj is RC5ParameterSpec other)
            {
                return version == other.version &&
                       rounds == other.rounds &&
                       wordSize == other.wordSize &&
                       ((iv == null && other.iv == null) ||
                        (iv != null && other.iv != null && CompareArrays(iv, other.iv)));
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + version;
            hash = hash * 31 + rounds;
            hash = hash * 31 + wordSize;
            if (iv != null)
            {
                foreach (byte b in iv)
                    hash = hash * 31 + b;
            }
            return hash;
        }

        private static bool CompareArrays(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
                if (a[i] != b[i]) return false;
            return true;
        }
    }

    [TestFixture]
    public class RC5ParameterSpecAutoTest
    {
        [Test]
        public void GetIV_Test_5266()
        {
            int c0 = 1, c1 = 2, c2 = 3; // arbitrary values
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.GetIV();
        }

        [Test]
        public void GetRounds_Test_5267()
        {
            int c0 = 1, c1 = 2, c2 = 3;
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.GetRounds();
        }

        [Test]
        public void GetWordSize_Test_5268()
        {
            int c0 = 1, c1 = 2, c2 = 3;
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.GetWordSize();
        }

        [Test]
        public void Equals_Test_5269()
        {
            object p0 = null; // arbitrary
            int c0 = 1, c1 = 2, c2 = 3;
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.Equals(p0);
        }

        [Test]
        public void HashCode_Test_5270()
        {
            int c0 = 1, c1 = 2, c2 = 3;
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.GetHashCode();
        }

        [Test]
        public void GetVersion_Test_5271()
        {
            int c0 = 1, c1 = 2, c2 = 3;
            var instance = new RC5ParameterSpec(c0, c1, c2);
            instance.GetVersion();
        }
    }
}
```