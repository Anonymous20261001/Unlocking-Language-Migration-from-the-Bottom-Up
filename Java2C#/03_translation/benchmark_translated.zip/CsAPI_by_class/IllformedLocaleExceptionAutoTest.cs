```csharp
using NUnit.Framework;

namespace GeneratedTest
{
    public class IllformedLocaleExceptionAutoTest
    {
        [Test]
        public void GetErrorIndex_Test_3575()
        {
            IllformedLocaleException instance = new IllformedLocaleException();
            instance.GetErrorIndex();
        }
    }

    public class IllformedLocaleException : System.Exception
    {
        private int errorIndex = -1;

        public IllformedLocaleException() : base() { }

        public IllformedLocaleException(string message) : base(message) { }

        public IllformedLocaleException(string message, int errorIndex) : base(message)
        {
            this.errorIndex = errorIndex;
        }

        public int GetErrorIndex()
        {
            return errorIndex;
        }
    }
}
```