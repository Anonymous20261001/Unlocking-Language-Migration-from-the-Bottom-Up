```csharp
using System;
using System.Buffers;
using NUnit.Framework;

namespace Generated.Test
{
    // Simple CRC-32 implementation matching Java's java.util.zip.CRC32
    public class CRC32
    {
        private const uint Polynomial = 0xEDB88320u;
        private static readonly uint[] Table;

        private uint crc;

        static CRC32()
        {
            Table = new uint[256];
            for (int i = 0; i < 256; i++)
            {
                uint entry = (uint)i;
                for (int j = 0; j < 8; j++)
                    entry = (entry & 1) == 1 ? (entry >> 1) ^ Polynomial : entry >> 1;
                Table[i] = entry;
            }
        }

        public CRC32()
        {
            Reset();
        }

        public void Reset()
        {
            crc = 0xFFFFFFFFu;
        }

        public void Update(int b)
        {
            // Only the low 8 bits are used
            uint index = (crc ^ (byte)b) & 0xFF;
            crc = (crc >> 8) ^ Table[index];
        }

        public void Update(byte[] b, int off, int len)
        {
            if (b == null) throw new ArgumentNullException(nameof(b));
            if (off < 0 || len < 0 || off + len > b.Length)
                throw new ArgumentOutOfRangeException();

            for (int i = off; i < off + len; i++)
                Update(b[i]);
        }

        // Java's CRC32.update(ByteBuffer) reads all remaining bytes from the buffer
        public void Update(ByteBuffer buffer)
        {
            if (buffer == null) throw new ArgumentNullException(nameof(buffer));
            int pos = buffer.Position;
            int limit = buffer.Limit;
            if (buffer.HasArray)
            {
                byte[] array = buffer.Array;
                int offset = buffer.ArrayOffset + pos;
                Update(array, offset, limit - pos);
            }
            else
            {
                // Fallback: read byte by byte
                for (int i = pos; i < limit; i++)
                    Update(buffer.Get(i));
            }
            buffer.Position = limit; // Java's CRC32.update(ByteBuffer) advances the buffer position
        }

        public long GetValue()
        {
            // Return CRC-32 as a 64-bit signed long, matching Java's behavior
            return (long)(crc ^ 0xFFFFFFFFu);
        }

        // Internal helper to support fallback read
        private int Get(int index)
        {
            // This is only used when buffer has no backing array
            throw new NotSupportedException("Direct ByteBuffer not supported in this simple implementation.");
        }
    }

    // Minimal ByteBuffer class that mimics java.nio.ByteBuffer for testing
    public class ByteBuffer
    {
        private byte[] _array;
        private int _position;
        private int _limit;
        private int _arrayOffset;

        private ByteBuffer(byte[] array, int offset, int length)
        {
            _array = array;
            _arrayOffset = offset;
            _position = offset;
            _limit = offset + length;
        }

        public static ByteBuffer Wrap(byte[] array)
        {
            return new ByteBuffer(array, 0, array.Length);
        }

        public static ByteBuffer Wrap(byte[] array, int offset, int length)
        {
            return new ByteBuffer(array, offset, length);
        }

        public int Position
        {
            get => _position - _arrayOffset;
            set => _position = _arrayOffset + value;
        }

        public int Limit
        {
            get => _limit - _arrayOffset;
            set => _limit = _arrayOffset + value;
        }

        public bool HasArray => true;

        public byte[] Array => _array;

        public int ArrayOffset => _arrayOffset;

        public void Get(byte[] dst, int off, int len)
        {
            Buffer.BlockCopy(_array, _position, dst, off, len);
            _position += len;
        }

        // For simplicity, we allow direct index access (used in fallback)
        // But we don't expose Get(int) here; the CRC32.Update(ByteBuffer) fallback uses a method on CRC32.
    }

    [TestFixture]
    public class CRC32AutoTest
    {
        [Test]
        public void Reset_test_5124()
        {
            CRC32 instance = new CRC32();
            instance.Reset();
        }

        [Test]
        public void Update_test_5125(int p0)
        {
            CRC32 instance = new CRC32();
            instance.Update(p0);
        }

        [Test]
        public void Update_test_5126(ByteBuffer p0)
        {
            CRC32 instance = new CRC32();
            instance.Update(p0);
        }

        [Test]
        public void Update_test_5127(byte[] p0, int p1, int p2)
        {
            CRC32 instance = new CRC32();
            instance.Update(p0, p1, p2);
        }

        [Test]
        public void GetValue_test_5128()
        {
            CRC32 instance = new CRC32();
            instance.GetValue();
        }
    }
}
```