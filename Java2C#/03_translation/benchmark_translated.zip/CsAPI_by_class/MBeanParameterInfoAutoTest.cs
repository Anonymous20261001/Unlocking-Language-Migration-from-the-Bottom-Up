```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class MBeanFeatureInfo
    {
        public string Name { get; }
        public string Description { get; }

        public MBeanFeatureInfo(string name, string description)
        {
            Name = name;
            Description = description;
        }

        public override bool Equals(object obj)
        {
            if (obj == this) return true;
            if (obj == null || GetType() != obj.GetType()) return false;
            var other = (MBeanFeatureInfo)obj;
            return Name == other.Name && Description == other.Description;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + (Name?.GetHashCode() ?? 0);
                hash = hash * 31 + (Description?.GetHashCode() ?? 0);
                return hash;
            }
        }

        public override string ToString()
        {
            return $"Name: {Name}, Description: {Description}";
        }
    }

    public class MBeanParameterInfo : MBeanFeatureInfo, ICloneable
    {
        public string Type { get; }

        public MBeanParameterInfo(string name, string type, string description)
            : base(name, description)
        {
            Type = type;
        }

        public new string GetType() // Hides object.GetType(), returns the stored type string
        {
            return Type;
        }

        public object Clone()
        {
            return new MBeanParameterInfo(Name, Type, Description);
        }

        public override bool Equals(object obj)
        {
            if (obj == this) return true;
            if (obj == null || !(obj is MBeanParameterInfo)) return false;
            var other = (MBeanParameterInfo)obj;
            return base.Equals(obj) && Type == other.Type;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = base.GetHashCode();
                hash = hash * 31 + (Type?.GetHashCode() ?? 0);
                return hash;
            }
        }

        public override string ToString()
        {
            return $"Name: {Name}, Type: {Type}, Description: {Description}";
        }
    }

    [TestFixture]
    public class MBeanParameterInfoAutoTest
    {
        [Test]
        public void Equals_Test_5584()
        {
            var instance = new MBeanParameterInfo("name", "type", "desc");
            object p0 = "test";
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_5585()
        {
            var instance = new MBeanParameterInfo("name", "type", "desc");
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_5586()
        {
            var instance = new MBeanParameterInfo("name", "type", "desc");
            instance.GetHashCode();
        }

        [Test]
        public void Clone_Test_5587()
        {
            var instance = new MBeanParameterInfo("name", "type", "desc");
            instance.Clone();
        }

        [Test]
        public void GetType_Test_5588()
        {
            var instance = new MBeanParameterInfo("name", "type", "desc");
            instance.GetType(); // calls our custom GetType() method
        }
    }
}
```