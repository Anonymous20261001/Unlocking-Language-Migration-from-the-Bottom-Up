```csharp
using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class DoubleAdderAutoTest
    {
        [Test]
        public void Reset_test_4954()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.Reset();
        }

        [Test]
        public void ToString_test_4955()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.ToString();
        }

        [Test]
        public void IntValue_test_4956()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.IntValue();
        }

        [Test]
        public void LongValue_test_4957()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.LongValue();
        }

        [Test]
        public void FloatValue_test_4958()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.FloatValue();
        }

        [Test]
        public void DoubleValue_test_4959()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.DoubleValue();
        }

        [Test]
        public void Add_test_4960()
        {
            DoubleAdder instance = new DoubleAdder();
            // The original Java test had a parameter, but we use a default value.
            instance.Add(1.0);
        }

        [Test]
        public void Sum_test_4961()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.Sum();
        }

        [Test]
        public void SumThenReset_test_4962()
        {
            DoubleAdder instance = new DoubleAdder();
            instance.SumThenReset();
        }
    }

    /// <summary>
    /// C# equivalent of Java's java.util.concurrent.atomic.DoubleAdder.
    /// Provides thread-safe accumulation of double values.
    /// </summary>
    public class DoubleAdder
    {
        private double _value;
        private readonly object _lock = new object();

        public DoubleAdder()
        {
            _value = 0.0;
        }

        public void Reset()
        {
            lock (_lock)
            {
                _value = 0.0;
            }
        }

        public override string ToString()
        {
            lock (_lock)
            {
                return _value.ToString();
            }
        }

        public int IntValue()
        {
            lock (_lock)
            {
                return (int)_value;
            }
        }

        public long LongValue()
        {
            lock (_lock)
            {
                return (long)_value;
            }
        }

        public float FloatValue()
        {
            lock (_lock)
            {
                return (float)_value;
            }
        }

        public double DoubleValue()
        {
            lock (_lock)
            {
                return _value;
            }
        }

        public void Add(double x)
        {
            lock (_lock)
            {
                _value += x;
            }
        }

        public double Sum()
        {
            lock (_lock)
            {
                return _value;
            }
        }

        public double SumThenReset()
        {
            lock (_lock)
            {
                double result = _value;
                _value = 0.0;
                return result;
            }
        }
    }
}
```