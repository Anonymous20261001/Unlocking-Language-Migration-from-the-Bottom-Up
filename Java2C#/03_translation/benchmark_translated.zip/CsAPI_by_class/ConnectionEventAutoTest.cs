```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Stub for javax.sql.PooledConnection
    public class PooledConnection
    {
        // Empty stub class
    }

    // Stub for java.sql.SQLException
    public class SQLException : Exception
    {
        public SQLException() { }
        public SQLException(string message) : base(message) { }
    }

    // Equivalent of javax.sql.ConnectionEvent
    public class ConnectionEvent
    {
        private readonly PooledConnection _connection;
        private SQLException _sqlException;

        public ConnectionEvent(PooledConnection con)
        {
            _connection = con;
            _sqlException = null;
        }

        public ConnectionEvent(PooledConnection con, SQLException ex)
        {
            _connection = con;
            _sqlException = ex;
        }

        public PooledConnection GetConnection()
        {
            return _connection;
        }

        public SQLException GetSQLException()
        {
            return _sqlException;
        }
    }

    [TestFixture]
    public class ConnectionEventAutoTest
    {
        [Test]
        public void GetSQLException_test_6523()
        {
            PooledConnection c0 = new PooledConnection();
            ConnectionEvent instance = new ConnectionEvent(c0);
            instance.GetSQLException();
        }
    }
}
```