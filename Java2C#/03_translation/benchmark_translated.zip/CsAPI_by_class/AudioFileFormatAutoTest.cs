```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Tests
{
    public class AudioFileFormatAutoTest
    {
        [Test]
        public void GetByteLength_Test_6497()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetByteLength();
        }

        [Test]
        public void GetFrameLength_Test_6498()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetFrameLength();
        }

        [Test]
        public void GetProperty_Test_6499()
        {
            string propertyKey = "duration";
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetProperty(propertyKey);
        }

        [Test]
        public void ToString_Test_6500()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.ToString();
        }

        [Test]
        public void Properties_Test_6501()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.Properties();
        }

        [Test]
        public void GetType_Test_6502()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetType();
        }

        [Test]
        public void GetFormat_Test_6503()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetFormat();
        }
    }

    // Equivalent of javax.sound.sampled.AudioFormat
    public class AudioFormat
    {
        public float SampleRate { get; }
        public int SampleSizeInBits { get; }
        public int Channels { get; }
        public bool BigEndian { get; }
        public Encoding Encoding { get; }
        public int FrameSize { get; }
        public float FrameRate { get; }

        public AudioFormat(float sampleRate, int sampleSizeInBits, int channels, bool signed, bool bigEndian)
        {
            SampleRate = sampleRate;
            SampleSizeInBits = sampleSizeInBits;
            Channels = channels;
            BigEndian = bigEndian;
            Encoding = signed ? Encoding.PcmSigned : Encoding.PcmUnsigned;
            FrameSize = (sampleSizeInBits / 8) * channels;
            FrameRate = sampleRate;
        }

        // Minimal constructor used for testing
        public AudioFormat(Encoding encoding, float sampleRate, int sampleSizeInBits, int channels, int frameSize, float frameRate, bool bigEndian)
        {
            Encoding = encoding;
            SampleRate = sampleRate;
            SampleSizeInBits = sampleSizeInBits;
            Channels = channels;
            FrameSize = frameSize;
            FrameRate = frameRate;
            BigEndian = bigEndian;
        }

        public override string ToString()
        {
            return $"AudioFormat [sampleRate={SampleRate}, sampleSizeInBits={SampleSizeInBits}, channels={Channels}, bigEndian={BigEndian}]";
        }

        // Nested Encoding class mimicking Java's AudioFormat.Encoding
        public class Encoding
        {
            public static readonly Encoding PcmSigned = new Encoding("PCM_SIGNED");
            public static readonly Encoding PcmUnsigned = new Encoding("PCM_UNSIGNED");
            public static readonly Encoding ULaw = new Encoding("ULAW");
            public static readonly Encoding ALaw = new Encoding("ALAW");

            public string Name { get; }

            private Encoding(string name)
            {
                Name = name;
            }

            public override string ToString() => Name;

            public override bool Equals(object obj)
            {
                return obj is Encoding other && Name == other.Name;
            }

            public override int GetHashCode() => Name.GetHashCode();
        }
    }

    // Equivalent of javax.sound.sampled.AudioFileFormat.Type
    public class AudioFileFormatType
    {
        public static readonly AudioFileFormatType Wave = new AudioFileFormatType("WAVE");
        public static readonly AudioFileFormatType AU = new AudioFileFormatType("AU");
        public static readonly AudioFileFormatType AIFF = new AudioFileFormatType("AIFF");
        public static readonly AudioFileFormatType AIFC = new AudioFileFormatType("AIFC");
        public static readonly AudioFileFormatType Snd = new AudioFileFormatType("SND");

        public string Name { get; }

        private AudioFileFormatType(string name)
        {
            Name = name;
        }

        public override string ToString() => Name;

        public override bool Equals(object obj)
        {
            return obj is AudioFileFormatType other && Name == other.Name;
        }

        public override int GetHashCode() => Name.GetHashCode();
    }

    // Equivalent of javax.sound.sampled.AudioFileFormat
    public class AudioFileFormat
    {
        private readonly AudioFileFormatType _type;
        private readonly AudioFormat _format;
        private readonly int _frameLength;
        private readonly int _byteLength;
        private readonly Dictionary<string, object> _properties;

        public AudioFileFormat(AudioFileFormatType type, AudioFormat format, int frameLength)
        {
            _type = type ?? throw new ArgumentNullException(nameof(type));
            _format = format ?? throw new ArgumentNullException(nameof(format));
            _frameLength = frameLength;
            _byteLength = CalculateByteLength();
            _properties = new Dictionary<string, object>();
        }

        public AudioFileFormat(AudioFileFormatType type, AudioFormat format, int frameLength, Dictionary<string, object> properties)
            : this(type, format, frameLength)
        {
            if (properties != null)
            {
                foreach (var kvp in properties)
                    _properties[kvp.Key] = kvp.Value;
            }
        }

        private int CalculateByteLength()
        {
            if (_frameLength == AudioSystem.NotSpecified)
                return AudioSystem.NotSpecified;
            return _frameLength * _format.FrameSize;
        }

        public int GetByteLength() => _byteLength;

        public int GetFrameLength() => _frameLength;

        public object GetProperty(string key)
        {
            if (_properties.TryGetValue(key, out var value))
                return value;
            return null;
        }

        public override string ToString()
        {
            return $"AudioFileFormat [type={_type}, format={_format}, frameLength={_frameLength}, byteLength={_byteLength}]";
        }

        public IDictionary<string, object> Properties() => new Dictionary<string, object>(_properties);

        public AudioFileFormatType GetType() => _type; // Note: hides object.GetType() – use explicit interface or rename

        public AudioFormat GetFormat() => _format;
    }

    // Helper class to provide AudioSystem constants
    public static class AudioSystem
    {
        public const int NotSpecified = -1;
    }
}
```