```csharp
using NUnit.Framework;
using System;

namespace Generated.Test
{
    public class AccessibleRelation
    {
        private string key;
        private object[] targets;

        public AccessibleRelation(string key)
        {
            this.key = key;
            this.targets = null;
        }

        public string GetKey()
        {
            return key;
        }

        public object GetTarget()
        {
            if (targets == null || targets.Length == 0)
                return null;
            return targets[0];
        }

        public void SetTarget(object target)
        {
            targets = new object[] { target };
        }

        public void SetTarget(object[] target)
        {
            targets = target;
        }
    }

    [TestFixture]
    public class AccessibleRelationAutoTest
    {
        [Test]
        public void GetKey_test_5212()
        {
            AccessibleRelation instance = new AccessibleRelation("testKey");
            instance.GetKey();
        }

        [Test]
        public void GetTarget_test_5213()
        {
            AccessibleRelation instance = new AccessibleRelation("testKey");
            instance.GetTarget();
        }

        [Test]
        public void SetTarget_test_5214()
        {
            object p0 = new object();
            AccessibleRelation instance = new AccessibleRelation("testKey");
            instance.SetTarget(p0);
        }

        [Test]
        public void SetTarget_test_5215()
        {
            object[] p0 = new object[] { new object() };
            AccessibleRelation instance = new AccessibleRelation("testKey");
            instance.SetTarget(p0);
        }
    }
}
```