```csharp
using System;
using Xunit;

namespace Generated.Test
{
    public class OpenURIEventAutoTest
    {
        [Fact]
        public void GetURI_Test_681()
        {
            Uri c0 = new Uri("http://example.com");
            OpenURIEvent instance = new OpenURIEvent(c0);
            instance.GetURI();
        }
    }

    public class OpenURIEvent
    {
        private Uri uri;

        public OpenURIEvent(Uri uri)
        {
            this.uri = uri;
        }

        public Uri GetURI()
        {
            return uri;
        }
    }
}
```