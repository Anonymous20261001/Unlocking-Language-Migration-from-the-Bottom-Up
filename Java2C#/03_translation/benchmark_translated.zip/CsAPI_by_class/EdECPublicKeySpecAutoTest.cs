```csharp
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of java.security.spec.EdECPoint
    public class EdECPoint
    {
        public BigInteger X { get; }
        public BigInteger Y { get; }

        public EdECPoint(BigInteger x, BigInteger y)
        {
            X = x;
            Y = y;
        }
    }

    // Equivalent of java.security.spec.NamedParameterSpec
    public class NamedParameterSpec
    {
        public string Name { get; }

        public NamedParameterSpec(string name)
        {
            Name = name;
        }
    }

    // Equivalent of java.security.spec.EdECPublicKeySpec
    public class EdECPublicKeySpec
    {
        private readonly NamedParameterSpec _params;
        private readonly EdECPoint _point;

        public EdECPublicKeySpec(NamedParameterSpec @params, EdECPoint point)
        {
            _params = @params;
            _point = point;
        }

        // Equivalent of getPoint()
        public EdECPoint GetPoint()
        {
            return _point;
        }

        // Equivalent of getParams()
        public NamedParameterSpec GetParams()
        {
            return _params;
        }
    }

    [TestFixture]
    public class EdECPublicKeySpecAutoTest
    {
        [Test]
        public void GetPoint_Test_2887()
        {
            var c0 = new NamedParameterSpec("Ed25519");
            var c1 = new EdECPoint(BigInteger.Zero, BigInteger.One);
            var instance = new EdECPublicKeySpec(c0, c1);
            instance.GetPoint();
        }

        [Test]
        public void GetParams_Test_2888()
        {
            var c0 = new NamedParameterSpec("Ed25519");
            var c1 = new EdECPoint(BigInteger.Zero, BigInteger.One);
            var instance = new EdECPublicKeySpec(c0, c1);
            instance.GetParams();
        }
    }
}
```