```csharp
using System;
using System.Collections.Generic;
using System.Net;
using NUnit.Framework;

namespace Generated.Test
{
    // ------------------------------------------------------------------------
    // CookiePolicy – equivalent to java.net.CookiePolicy
    // ------------------------------------------------------------------------
    public interface ICookiePolicy
    {
        bool ShouldAccept(Uri uri, Cookie cookie);
    }

    public static class CookiePolicy
    {
        public static readonly ICookiePolicy AcceptAll = new AcceptAllPolicy();
        public static readonly ICookiePolicy AcceptNone = new AcceptNonePolicy();

        private class AcceptAllPolicy : ICookiePolicy
        {
            public bool ShouldAccept(Uri uri, Cookie cookie) => true;
        }

        private class AcceptNonePolicy : ICookiePolicy
        {
            public bool ShouldAccept(Uri uri, Cookie cookie) => false;
        }
    }

    // ------------------------------------------------------------------------
    // CookieStore – equivalent to java.net.CookieStore (simplified)
    // ------------------------------------------------------------------------
    public interface ICookieStore
    {
        void Add(Uri uri, Cookie cookie);
        List<Cookie> Get(Uri uri);
        List<Cookie> GetCookies();
        void RemoveAll();
    }

    public class InMemoryCookieStore : ICookieStore
    {
        private readonly Dictionary<Uri, List<Cookie>> _store = new Dictionary<Uri, List<Cookie>>();

        public void Add(Uri uri, Cookie cookie)
        {
            if (!_store.ContainsKey(uri))
                _store[uri] = new List<Cookie>();
            _store[uri].Add(cookie);
        }

        public List<Cookie> Get(Uri uri)
        {
            return _store.TryGetValue(uri, out var cookies) ? cookies : new List<Cookie>();
        }

        public List<Cookie> GetCookies()
        {
            var all = new List<Cookie>();
            foreach (var list in _store.Values)
                all.AddRange(list);
            return all;
        }

        public void RemoveAll() => _store.Clear();
    }

    // ------------------------------------------------------------------------
    // CookieManager – equivalent to java.net.CookieManager
    // ------------------------------------------------------------------------
    public class CookieManager
    {
        private ICookiePolicy _policy;
        private readonly ICookieStore _store;

        public CookieManager()
        {
            _policy = CookiePolicy.AcceptAll;
            _store = new InMemoryCookieStore();
        }

        public void SetCookiePolicy(ICookiePolicy policy)
        {
            _policy = policy ?? throw new ArgumentNullException(nameof(policy));
        }

        public ICookieStore GetCookieStore() => _store;
    }

    // ------------------------------------------------------------------------
    // Test class
    // ------------------------------------------------------------------------
    [TestFixture]
    public class CookieManagerAutoTest
    {
        [Test]
        public void SetCookiePolicy_test_2543()
        {
            CookieManager instance = new CookieManager();
            instance.SetCookiePolicy(CookiePolicy.AcceptAll);
        }

        [Test]
        public void GetCookieStore_test_2544()
        {
            CookieManager instance = new CookieManager();
            ICookieStore store = instance.GetCookieStore();
            Assert.IsNotNull(store);
        }
    }
}
```