```csharp
using System;
using System.Text.RegularExpressions;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class KerberosPrincipalAutoTest
    {
        // Helper default principal name for tests
        private const string DefaultPrincipal = "user@EXAMPLE.COM";

        [Test]
        public void GetName_Test_6388()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6389()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            object p0 = new object();
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_6390()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_6391()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            instance.GetHashCode();
        }

        [Test]
        public void GetRealm_Test_6392()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            instance.GetRealm();
        }

        [Test]
        public void GetNameType_Test_6393()
        {
            KerberosPrincipal instance = new KerberosPrincipal(DefaultPrincipal);
            instance.GetNameType();
        }
    }

    /// <summary>
    /// C# equivalent of javax.security.auth.kerberos.KerberosPrincipal
    /// </summary>
    public class KerberosPrincipal
    {
        private readonly string _name;
        private readonly string _realm;
        private readonly int _nameType;

        // Default name type constant (KRB_NT_PRINCIPAL = 1)
        private const int KRB_NT_PRINCIPAL = 1;

        /// <summary>
        /// Creates a KerberosPrincipal from a string principal name.
        /// Default name type is KRB_NT_PRINCIPAL (1).
        /// </summary>
        /// <param name="name">The principal name, optionally containing '@realm'.</param>
        public KerberosPrincipal(string name)
        {
            if (name == null)
                throw new ArgumentNullException(nameof(name));

            _name = name;
            _nameType = KRB_NT_PRINCIPAL;

            // Extract realm: if name contains '@', realm is after last '@'
            int atIndex = name.LastIndexOf('@');
            if (atIndex >= 0 && atIndex < name.Length - 1)
                _realm = name.Substring(atIndex + 1);
            else
                _realm = string.Empty;
        }

        /// <summary>
        /// Creates a KerberosPrincipal with a specified name type.
        /// </summary>
        /// <param name="name">The principal name.</param>
        /// <param name="nameType">The name type (e.g., 1 for KRB_NT_PRINCIPAL).</param>
        public KerberosPrincipal(string name, int nameType) : this(name)
        {
            _nameType = nameType;
        }

        /// <summary>
        /// Returns the principal name (full string as passed to constructor).
        /// </summary>
        public string GetName()
        {
            return _name;
        }

        /// <summary>
        /// Returns the realm part of the principal (string after last '@'), or empty if none.
        /// </summary>
        public string GetRealm()
        {
            return _realm;
        }

        /// <summary>
        /// Returns the name type (e.g., KRB_NT_PRINCIPAL).
        /// </summary>
        public int GetNameType()
        {
            return _nameType;
        }

        /// <summary>
        /// Returns the string representation (the principal name).
        /// </summary>
        public override string ToString()
        {
            return _name;
        }

        /// <summary>
        /// Compares this principal to another object.
        /// Two KerberosPrincipal objects are equal if their names (case-sensitive) and realms are equal.
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj is KerberosPrincipal other)
            {
                return string.Equals(_name, other._name, StringComparison.Ordinal)
                    && string.Equals(_realm, other._realm, StringComparison.Ordinal)
                    && _nameType == other._nameType;
            }
            return false;
        }

        /// <summary>
        /// Returns a hash code based on the principal name, realm, and name type.
        /// </summary>
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + (_name?.GetHashCode() ?? 0);
                hash = hash * 31 + (_realm?.GetHashCode() ?? 0);
                hash = hash * 31 + _nameType;
                return hash;
            }
        }
    }
}
```