```csharp
using NUnit.Framework;
using System;

namespace GeneratedTest
{
    // C# equivalent of java.awt.event.ActionEvent
    public class ActionEvent
    {
        public static readonly int ACTION_PERFORMED = 1001;

        private readonly object source;
        private readonly int id;
        private readonly string command;
        private readonly long when;
        private readonly int modifiers;

        public ActionEvent(object source, int id, string command)
        {
            this.source = source;
            this.id = id;
            this.command = command;
            this.when = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            this.modifiers = 0;
        }

        public long GetWhen() => when;

        public string GetActionCommand() => command;

        public int GetModifiers() => modifiers;

        public string ParamString()
        {
            return $"ACTION_PERFORMED,cmd={command},when={when},modifiers={modifiers}";
        }
    }

    [TestFixture]
    public class ActionEventAutoTest
    {
        [Test]
        public void GetWhen_Test_741()
        {
            object c0 = new object();
            int c1 = 0;
            string c2 = "test";
            ActionEvent instance = new ActionEvent(c0, c1, c2);
            instance.GetWhen();
        }

        [Test]
        public void GetActionCommand_Test_742()
        {
            object c0 = new object();
            int c1 = 0;
            string c2 = "test";
            ActionEvent instance = new ActionEvent(c0, c1, c2);
            instance.GetActionCommand();
        }

        [Test]
        public void GetModifiers_Test_743()
        {
            object c0 = new object();
            int c1 = 0;
            string c2 = "test";
            ActionEvent instance = new ActionEvent(c0, c1, c2);
            instance.GetModifiers();
        }

        [Test]
        public void ParamString_Test_744()
        {
            object c0 = new object();
            int c1 = 0;
            string c2 = "test";
            ActionEvent instance = new ActionEvent(c0, c1, c2);
            instance.ParamString();
        }
    }
}
```