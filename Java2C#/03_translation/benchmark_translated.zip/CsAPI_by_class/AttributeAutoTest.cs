```csharp
using NUnit.Framework;
using System;

namespace Generated.Test
{
    [TestFixture]
    public class AttributeAutoTest
    {
        [Test]
        public void GetName_Test_5518()
        {
            var instance = new Attribute("testName", new object());
            instance.GetName();
        }

        [Test]
        public void Equals_Test_5519()
        {
            var instance = new Attribute("testName", new object());
            instance.Equals(new object());
        }

        [Test]
        public void ToString_Test_5520()
        {
            var instance = new Attribute("testName", new object());
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_5521()
        {
            var instance = new Attribute("testName", new object());
            instance.GetHashCode();
        }

        [Test]
        public void GetValue_Test_5522()
        {
            var instance = new Attribute("testName", new object());
            instance.GetValue();
        }
    }

    public class Attribute
    {
        private readonly string _name;
        private readonly object _value;

        public Attribute(string name, object value)
        {
            _name = name ?? throw new ArgumentNullException(nameof(name));
            _value = value;
        }

        public string GetName() => _name;

        public object GetValue() => _value;

        public override bool Equals(object obj)
        {
            if (obj is Attribute other)
            {
                return string.Equals(_name, other._name, StringComparison.Ordinal);
            }
            return false;
        }

        public override int GetHashCode() => _name?.GetHashCode() ?? 0;

        public override string ToString() => $"Attribute: name = {_name} value = {_value}";
    }
}
```