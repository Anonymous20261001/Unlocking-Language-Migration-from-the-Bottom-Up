```csharp
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.security.auth.callback.NameCallback
    public class NameCallback
    {
        private readonly string _prompt;
        private string _name;

        public NameCallback(string prompt)
        {
            _prompt = prompt;
            _name = null;
        }

        public string GetPrompt()
        {
            return _prompt;
        }

        public string GetDefaultName()
        {
            return null;
        }

        public string GetName()
        {
            return _name;
        }

        public void SetName(string name)
        {
            _name = name;
        }
    }

    [TestFixture]
    public class NameCallbackAutoTest
    {
        [Test]
        public void GetPrompt_Test_6342(string c0)
        {
            NameCallback instance = new NameCallback(c0);
            instance.GetPrompt();
        }

        [Test]
        public void GetDefaultName_Test_6343(string c0)
        {
            NameCallback instance = new NameCallback(c0);
            instance.GetDefaultName();
        }

        [Test]
        public void GetName_Test_6344(string c0)
        {
            NameCallback instance = new NameCallback(c0);
            instance.GetName();
        }

        [Test]
        public void SetName_Test_6345(string p0, string c0)
        {
            NameCallback instance = new NameCallback(c0);
            instance.SetName(p0);
        }
    }
}
```