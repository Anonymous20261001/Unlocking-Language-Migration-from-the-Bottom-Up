```csharp
using System;
using System.Globalization;
using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of Java's javax.print.attribute.standard.DocumentName
    public class DocumentName
    {
        private readonly string _name;
        private readonly CultureInfo _locale;

        public DocumentName(string documentName, CultureInfo locale)
        {
            _name = documentName ?? throw new ArgumentNullException(nameof(documentName));
            _locale = locale ?? throw new ArgumentNullException(nameof(locale));
        }

        // Returns the Type of the attribute category (equivalent to Java's getCategory())
        public Type GetCategory()
        {
            return typeof(DocumentName);
        }

        // Returns the string name of the document (equivalent to Java's getName())
        public string GetName()
        {
            return _name;
        }

        // Override Equals to match Java's TextSyntax.equals() behavior
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            DocumentName other = (DocumentName)obj;
            return _name.Equals(other._name) && _locale.Equals(other._locale);
        }

        // Override GetHashCode as required when Equals is overridden
        public override int GetHashCode()
        {
            return HashCode.Combine(_name, _locale);
        }
    }

    // Test class corresponding to DocumentNameAutoTest
    [TestFixture]
    public class DocumentNameAutoTest
    {
        [Test]
        public void GetCategory_Test_6118()
        {
            string c0 = "TestDocument";
            CultureInfo c1 = CultureInfo.InvariantCulture;
            DocumentName instance = new DocumentName(c0, c1);
            instance.GetCategory();
        }

        [Test]
        public void GetName_Test_6119()
        {
            string c0 = "TestDocument";
            CultureInfo c1 = CultureInfo.InvariantCulture;
            DocumentName instance = new DocumentName(c0, c1);
            instance.GetName();
        }

        [Test]
        public void Equals_Test_6120()
        {
            object p0 = new DocumentName("Other", CultureInfo.InvariantCulture);
            string c0 = "TestDocument";
            CultureInfo c1 = CultureInfo.InvariantCulture;
            DocumentName instance = new DocumentName(c0, c1);
            instance.Equals(p0);
        }
    }
}
```