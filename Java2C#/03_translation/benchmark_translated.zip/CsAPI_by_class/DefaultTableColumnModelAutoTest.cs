```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

// ----------------------------------------------------------------------
// Simple event classes to mimic Java Swing event types
// ----------------------------------------------------------------------

public class PropertyChangeEvent
{
    public PropertyChangeEvent() { }
    // Additional properties can be added if needed
}

public class ListSelectionEvent
{
    public ListSelectionEvent() { }
    // Additional properties can be added if needed
}

// ----------------------------------------------------------------------
// ListSelectionModel interface and a default implementation
// ----------------------------------------------------------------------

public interface ListSelectionModel
{
    // Minimal interface – no methods required for these tests
}

public class DefaultListSelectionModel : ListSelectionModel
{
}

// ----------------------------------------------------------------------
// TableColumn class (minimal implementation)
// ----------------------------------------------------------------------

public class TableColumn
{
    private object identifier;
    private int width;
    private int preferredWidth;
    private int minWidth;
    private int maxWidth;

    public TableColumn() : this(0) { }
    public TableColumn(int modelIndex) : this(modelIndex, 75, null) { }
    public TableColumn(int modelIndex, int width, TableCellRenderer renderer)
    {
        this.width = width;
        // Other fields default as in Java
    }

    public object Identifier
    {
        get { return identifier; }
        set { identifier = value; }
    }

    public int Width
    {
        get { return width; }
        set { width = value; }
    }

    public int PreferredWidth
    {
        get { return preferredWidth; }
        set { preferredWidth = value; }
    }

    public int MinWidth
    {
        get { return minWidth; }
        set { minWidth = value; }
    }

    public int MaxWidth
    {
        get { return maxWidth; }
        set { maxWidth = value; }
    }

    // For simplicity, we use a dummy renderer type
    public class TableCellRenderer { }
}

// ----------------------------------------------------------------------
// TableColumnModelListener interface
// ----------------------------------------------------------------------

public interface TableColumnModelListener
{
    void ColumnAdded(TableColumnModelEvent e);
    void ColumnRemoved(TableColumnModelEvent e);
    void ColumnMoved(TableColumnModelEvent e);
    void ColumnMarginChanged(ChangeEvent e);
    void ColumnSelectionChanged(ListSelectionEvent e);
}

// Simple event types for listener methods
public class TableColumnModelEvent : EventArgs
{
    public TableColumn Source { get; }
    public int FromIndex { get; }
    public int ToIndex { get; }

    public TableColumnModelEvent(TableColumn source, int fromIndex, int toIndex)
    {
        Source = source;
        FromIndex = fromIndex;
        ToIndex = toIndex;
    }
}

public class ChangeEvent : EventArgs { }

// ----------------------------------------------------------------------
// DefaultTableColumnModel – C# equivalent of Java class
// ----------------------------------------------------------------------

public class DefaultTableColumnModel : TableColumnModelListener
{
    private List<TableColumn> tableColumns = new List<TableColumn>();
    private ListSelectionModel selectionModel;
    private int columnMargin;
    private bool columnSelectionAllowed;
    private List<TableColumnModelListener> listeners = new List<TableColumnModelListener>();

    public DefaultTableColumnModel()
    {
        selectionModel = new DefaultListSelectionModel();
        columnMargin = 1; // Default as in Java
        columnSelectionAllowed = false;
    }

    // ---- Core column management ----

    public void AddColumn(TableColumn aColumn)
    {
        if (aColumn == null)
            throw new ArgumentNullException(nameof(aColumn));

        tableColumns.Add(aColumn);
        // Fire column added event
        foreach (var listener in listeners)
            listener.ColumnAdded(new TableColumnModelEvent(aColumn, tableColumns.Count - 1, tableColumns.Count - 1));
    }

    public void RemoveColumn(TableColumn column)
    {
        if (column == null)
            throw new ArgumentNullException(nameof(column));

        int index = tableColumns.IndexOf(column);
        if (index >= 0)
        {
            tableColumns.RemoveAt(index);
            foreach (var listener in listeners)
                listener.ColumnRemoved(new TableColumnModelEvent(column, index, index));
        }
    }

    public void MoveColumn(int columnIndex, int newIndex)
    {
        if (columnIndex < 0 || columnIndex >= tableColumns.Count)
            throw new ArgumentOutOfRangeException(nameof(columnIndex));
        if (newIndex < 0 || newIndex >= tableColumns.Count)
            throw new ArgumentOutOfRangeException(nameof(newIndex));

        if (columnIndex == newIndex) return;

        TableColumn col = tableColumns[columnIndex];
        tableColumns.RemoveAt(columnIndex);
        tableColumns.Insert(newIndex, col);
        foreach (var listener in listeners)
            listener.ColumnMoved(new TableColumnModelEvent(col, columnIndex, newIndex));
    }

    public TableColumn GetColumn(int columnIndex)
    {
        if (columnIndex < 0 || columnIndex >= tableColumns.Count)
            throw new IndexOutOfRangeException();
        return tableColumns[columnIndex];
    }

    public int GetColumnCount()
    {
        return tableColumns.Count;
    }

    public IEnumerable<TableColumn> GetColumns()
    {
        return tableColumns.AsReadOnly();
    }

    public int GetColumnIndex(object identifier)
    {
        if (identifier == null)
            throw new ArgumentNullException(nameof(identifier));

        for (int i = 0; i < tableColumns.Count; i++)
        {
            if (identifier.Equals(tableColumns[i].Identifier))
                return i;
        }
        throw new ArgumentException("Identifier not found");
    }

    // ---- Column margin ----

    public void SetColumnMargin(int newMargin)
    {
        columnMargin = newMargin;
        foreach (var listener in listeners)
            listener.ColumnMarginChanged(new ChangeEvent());
    }

    public int GetColumnMargin()
    {
        return columnMargin;
    }

    // ---- Selection ----

    public void SetColumnSelectionAllowed(bool allowed)
    {
        columnSelectionAllowed = allowed;
    }

    public bool GetColumnSelectionAllowed()
    {
        return columnSelectionAllowed;
    }

    public int[] GetSelectedColumns()
    {
        // Dummy – return empty array if no selection model interaction
        return new int[0];
    }

    public int GetSelectedColumnCount()
    {
        return 0;
    }

    public void SetSelectionModel(ListSelectionModel newModel)
    {
        selectionModel = newModel ?? throw new ArgumentNullException(nameof(newModel));
    }

    public ListSelectionModel GetSelectionModel()
    {
        return selectionModel;
    }

    // ---- X mapping ----

    public int GetColumnIndexAtX(int xPosition)
    {
        // Simple linear search based on column widths
        int accum = 0;
        for (int i = 0; i < tableColumns.Count; i++)
        {
            accum += tableColumns[i].Width;
            if (xPosition < accum)
                return i;
        }
        return -1; // or throw? Java returns -1 if not found
    }

    public int GetTotalColumnWidth()
    {
        int total = 0;
        foreach (var col in tableColumns)
            total += col.Width;
        return total;
    }

    // ---- Listener management ----

    public void AddColumnModelListener(TableColumnModelListener l)
    {
        if (l != null && !listeners.Contains(l))
            listeners.Add(l);
    }

    public void RemoveColumnModelListener(TableColumnModelListener l)
    {
        if (l != null)
            listeners.Remove(l);
    }

    public TableColumnModelListener[] GetColumnModelListeners()
    {
        return listeners.ToArray();
    }

    public object[] GetListeners(Type listenerType)
    {
        if (listenerType == typeof(TableColumnModelListener))
        {
            return listeners.ToArray();
        }
        return Array.Empty<object>();
    }

    // ---- PropertyChange (handles changes from TableColumn) ----

    public void PropertyChange(PropertyChangeEvent evt)
    {
        // No specific handling needed for tests
    }

    // ---- ValueChanged (from ListSelectionModel) ----

    public void ValueChanged(ListSelectionEvent e)
    {
        foreach (var listener in listeners)
            listener.ColumnSelectionChanged(e);
    }

    // ---- Explicit implementation of TableColumnModelListener (empty) ----
    void TableColumnModelListener.ColumnAdded(TableColumnModelEvent e) { }
    void TableColumnModelListener.ColumnRemoved(TableColumnModelEvent e) { }
    void TableColumnModelListener.ColumnMoved(TableColumnModelEvent e) { }
    void TableColumnModelListener.ColumnMarginChanged(ChangeEvent e) { }
    void TableColumnModelListener.ColumnSelectionChanged(ListSelectionEvent e) { }
}

// ----------------------------------------------------------------------
// Test class (NUnit)
// ----------------------------------------------------------------------

[TestFixture]
public class DefaultTableColumnModelAutoTest
{
    private DefaultTableColumnModel CreateInstance()
    {
        return new DefaultTableColumnModel();
    }

    [Test]
    public void PropertyChange_Test_9992()
    {
        var instance = CreateInstance();
        var p0 = new PropertyChangeEvent();
        instance.PropertyChange(p0);
    }

    [Test]
    public void SetColumnMargin_Test_9993([Random(1)] int p0)
    {
        var instance = CreateInstance();
        instance.SetColumnMargin(p0);
    }

    [Test]
    public void GetColumnMargin_Test_9994()
    {
        var instance = CreateInstance();
        instance.GetColumnMargin();
    }

    [Test]
    public void GetColumn_Test_9995([Random(1)] int p0)
    {
        var instance = CreateInstance();
        // Need a column to exist for a valid index – for simplicity add one
        instance.AddColumn(new TableColumn());
        instance.GetColumn(0);
    }

    [Test]
    public void RemoveColumn_Test_9996()
    {
        var instance = CreateInstance();
        var p0 = new TableColumn();
        instance.AddColumn(p0);
        instance.RemoveColumn(p0);
    }

    [Test]
    public void AddColumn_Test_9997()
    {
        var instance = CreateInstance();
        var p0 = new TableColumn();
        instance.AddColumn(p0);
    }

    [Test]
    public void GetSelectedColumns_Test_9998()
    {
        var instance = CreateInstance();
        instance.GetSelectedColumns();
    }

    [Test]
    public void GetColumnSelectionAllowed_Test_9999()
    {
        var instance = CreateInstance();
        instance.GetColumnSelectionAllowed();
    }

    [Test]
    public void SetColumnSelectionAllowed_Test_10000([Random] bool p0)
    {
        var instance = CreateInstance();
        instance.SetColumnSelectionAllowed(p0);
    }

    [Test]
    public void GetSelectedColumnCount_Test_10001()
    {
        var instance = CreateInstance();
        instance.GetSelectedColumnCount();
    }

    [Test]
    public void GetColumnIndex_Test_10002()
    {
        var instance = CreateInstance();
        var col = new TableColumn();
        col.Identifier = "test";
        instance.AddColumn(col);
        instance.GetColumnIndex("test");
    }

    [Test]
    public void MoveColumn_Test_10003([Random(1)] int p0, [Random(1)] int p1)
    {
        var instance = CreateInstance();
        instance.AddColumn(new TableColumn());
        instance.AddColumn(new TableColumn());
        // Ensure valid indices
        instance.MoveColumn(0, 1);
    }

    [Test]
    public void GetColumnIndexAtX_Test_10004([Random(1)] int p0)
    {
        var instance = CreateInstance();
        instance.GetColumnIndexAtX(p0);
    }

    [Test]
    public void GetTotalColumnWidth_Test_10005()
    {
        var instance = CreateInstance();
        instance.GetTotalColumnWidth();
    }

    [Test]
    public void RemoveColumnModelListener_Test_10006()
    {
        var instance = CreateInstance();
        TableColumnModelListener p0 = null; // Keep null as in Java test (no listener added)
        instance.RemoveColumnModelListener(p0);
    }

    [Test]
    public void AddColumnModelListener_Test_10007()
    {
        var instance = CreateInstance();
        TableColumnModelListener p0 = null; // Null listener – OK
        instance.AddColumnModelListener(p0);
    }

    [Test]
    public void ValueChanged_Test_10008()
    {
        var instance = CreateInstance();
        var p0 = new ListSelectionEvent();
        instance.ValueChanged(p0);
    }

    [Test]
    public void GetSelectionModel_Test_10009()
    {
        var instance = CreateInstance();
        instance.GetSelectionModel();
    }

    [Test]
    public void SetSelectionModel_Test_10010()
    {
        var instance = CreateInstance();
        var p0 = new DefaultListSelectionModel();
        instance.SetSelectionModel(p0);
    }

    [Test]
    public void GetColumnModelListeners_Test_10011()
    {
        var instance = CreateInstance();
        instance.GetColumnModelListeners();
    }

    [Test]
    public void GetListeners_Test_10012()
    {
        var instance = CreateInstance();
        var p0 = typeof(TableColumnModelListener);
        instance.GetListeners(p0);
    }

    [Test]
    public void GetColumns_Test_10013()
    {
        var instance = CreateInstance();
        instance.GetColumns();
    }

    [Test]
    public void GetColumnCount_Test_10014()
    {
        var instance = CreateInstance();
        instance.GetColumnCount();
    }
}
```