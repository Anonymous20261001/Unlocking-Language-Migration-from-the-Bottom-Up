```csharp
using System;
using System.Collections.Generic;
using Xunit;

// Simulate Java's CRLReason enum
public enum CRLReason
{
    Unspecified,
    KeyCompromise,
    CaCompromise,
    AffiliationChanged,
    Superseded,
    CessationOfOperation,
    CertificateHold,
    RemoveFromCRL,
    PrivilegeWithdrawn,
    AaCompromise
}

// Simulate Java's X500Principal
public class X500Principal
{
    private readonly string _name;

    public X500Principal(string name)
    {
        _name = name;
    }

    // In a real implementation, you would parse X.500 names.
    // For testing purposes, we just store the string.
    public string Name => _name;

    // Override ToString to match Java's X500Principal behavior
    public override string ToString()
    {
        return _name;
    }
}

// Simulate a Java Extension (simplified)
public class Extension
{
    // No real implementation needed for these tests
}

// Simulate Java's CertificateRevokedException
public class CertificateRevokedException : Exception
{
    private readonly DateTime _revocationDate;
    private readonly CRLReason _reason;
    private readonly X500Principal _authority;
    private readonly IDictionary<string, Extension> _extensions;

    // In Java, this constructor also sets the message automatically.
    public CertificateRevokedException(DateTime revocationDate, CRLReason reason,
                                      X500Principal authority, IDictionary<string, Extension> extensions)
        : base($"Certificate revoked on {revocationDate} for reason: {reason}")
    {
        _revocationDate = revocationDate;
        _reason = reason;
        _authority = authority;
        _extensions = extensions ?? new Dictionary<string, Extension>();
    }

    public IDictionary<string, Extension> GetExtensions()
    {
        return _extensions;
    }

    public DateTime GetRevocationDate()
    {
        return _revocationDate;
    }

    public CRLReason GetRevocationReason()
    {
        return _reason;
    }

    public X500Principal GetAuthorityName()
    {
        return _authority;
    }

    // In Java, this returns a Date or null. Here we assume it can be null.
    public DateTime? GetInvalidityDate()
    {
        // For testing, we return null (common when not set)
        return null;
    }

    // Override getMessage() to return the message set in constructor.
    public new string GetMessage()
    {
        return base.Message;
    }
}

// Test class
public class CertificateRevokedExceptionAutoTest
{
    [Fact]
    public void GetExtensions_Test_2764()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetExtensions();
    }

    [Fact]
    public void GetRevocationDate_Test_2765()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetRevocationDate();
    }

    [Fact]
    public void GetRevocationReason_Test_2766()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetRevocationReason();
    }

    [Fact]
    public void GetAuthorityName_Test_2767()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetAuthorityName();
    }

    [Fact]
    public void GetInvalidityDate_Test_2768()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetInvalidityDate();
    }

    [Fact]
    public void GetMessage_Test_2769()
    {
        DateTime c0 = DateTime.Now;
        CRLReason c1 = CRLReason.Unspecified;
        X500Principal c2 = new X500Principal("CN=TestAuthority");
        IDictionary<string, Extension> c3 = new Dictionary<string, Extension>();

        CertificateRevokedException instance = new CertificateRevokedException(c0, c1, c2, c3);
        instance.GetMessage();
    }
}
```