```csharp
using System;
using System.IO;
using System.Text;
using NUnit.Framework;

// Abstract class to mimic Java's OutputStream
public abstract class OutputStream : IDisposable
{
    public abstract void Write(int b);
    public abstract void Write(byte[] buffer, int offset, int count);
    public abstract void Flush();
    public abstract void Close();
    public void Dispose() => Close();
}

// Concrete implementation wrapping a MemoryStream for testing
public class MemoryOutputStream : OutputStream
{
    private readonly MemoryStream _stream = new MemoryStream();

    public override void Write(int b) => _stream.WriteByte((byte)b);
    public override void Write(byte[] buffer, int offset, int count) => _stream.Write(buffer, offset, count);
    public override void Flush() => _stream.Flush();
    public override void Close() => _stream.Close();

    public byte[] ToArray() => _stream.ToArray();
}

// Abstract class to mimic Java's MessageDigest
public abstract class MessageDigest
{
    public abstract void Update(byte[] input, int offset, int count);
    public abstract byte[] Digest();
    public abstract void Reset();
}

// Simple implementation for testing (stores all bytes, returns them as digest)
public class SimpleMessageDigest : MessageDigest
{
    private readonly MemoryStream _data = new MemoryStream();

    public override void Update(byte[] input, int offset, int count)
    {
        _data.Write(input, offset, count);
    }

    public override byte[] Digest()
    {
        byte[] result = _data.ToArray();
        Reset();
        return result;
    }

    public override void Reset() => _data.SetLength(0);

    public override string ToString() => "SimpleMessageDigest";
}

// Equivalent of java.security.DigestOutputStream
public class DigestOutputStream : OutputStream
{
    private readonly OutputStream _stream;
    private MessageDigest _digest;
    private bool _on = true;

    public DigestOutputStream(OutputStream stream, MessageDigest digest)
    {
        _stream = stream ?? throw new ArgumentNullException(nameof(stream));
        _digest = digest ?? throw new ArgumentNullException(nameof(digest));
    }

    public void setMessageDigest(MessageDigest digest)
    {
        _digest = digest ?? throw new ArgumentNullException(nameof(digest));
    }

    public MessageDigest getMessageDigest() => _digest;

    public void on(bool on) => _on = on;

    public override void Write(int b)
    {
        if (_on)
        {
            _digest.Update(new byte[] { (byte)b }, 0, 1);
        }
        _stream.Write(b);
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        if (_on)
        {
            _digest.Update(buffer, offset, count);
        }
        _stream.Write(buffer, offset, count);
    }

    public override void Flush() => _stream.Flush();
    public override void Close() => _stream.Close();

    public override string ToString() => $"DigestOutputStream: {_digest}";
}

// Test class equivalent to Java's DigestOutputStreamAutoTest
[TestFixture]
public class DigestOutputStreamAutoTest
{
    [Test]
    public void SetMessageDigest_test_2700()
    {
        MessageDigest p0 = new SimpleMessageDigest();
        OutputStream c0 = new MemoryOutputStream();
        MessageDigest c1 = new SimpleMessageDigest();
        DigestOutputStream instance = new DigestOutputStream(c0, c1);
        instance.setMessageDigest(p0);
    }

    [Test]
    public void GetMessageDigest_test_2701()
    {
        OutputStream c0 = new MemoryOutputStream();
        MessageDigest c1 = new SimpleMessageDigest();
        DigestOutputStream instance = new DigestOutputStream(c0, c1);
        instance.getMessageDigest();
    }

    [Test]
    public void ToString_test_2702()
    {
        OutputStream c0 = new MemoryOutputStream();
        MessageDigest c1 = new SimpleMessageDigest();
        DigestOutputStream instance = new DigestOutputStream(c0, c1);
        instance.ToString();
    }

    [Test]
    public void On_test_2703()
    {
        bool p0 = true;
        OutputStream c0 = new MemoryOutputStream();
        MessageDigest c1 = new SimpleMessageDigest();
        DigestOutputStream instance = new DigestOutputStream(c0, c1);
        instance.on(p0);
    }
}
```