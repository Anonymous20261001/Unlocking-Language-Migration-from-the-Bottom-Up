Below is the complete C# translation of the Java test file, including the required class implementations and test methods using NUnit.

```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Minimal EventContext stub
    public class EventContext
    {
    }

    // Binding stub (similar to javax.naming.Binding)
    public class Binding
    {
        private readonly string _name;
        private readonly object _obj;

        public Binding(string name, object obj)
        {
            _name = name;
            _obj = obj;
        }

        public string GetName() => _name;
        public object GetObject() => _obj;
    }

    // NamingListener interface (marker interface, same as Java)
    public interface NamingListener
    {
    }

    // Sub-interfaces for specific event types
    public interface ObjectChangeListener : NamingListener
    {
        void ObjectChanged(NamingEvent evt);
    }

    public interface NamespaceChangeListener : NamingListener
    {
        void NamespaceChanged(NamingEvent evt);
    }

    // NamingEvent equivalent
    public class NamingEvent
    {
        // Constants as in javax.naming.event.NamingEvent
        public const int OBJECT_CHANGED = 0;
        public const int NAMESPACE_CHANGED = 1;
        public const int OBJECT_ADDED = 2;
        public const int OBJECT_REMOVED = 3;
        public const int NAMESPACE_ADDED = 4;
        public const int NAMESPACE_REMOVED = 5;

        private readonly EventContext _context;
        private readonly int _type;
        private readonly Binding _oldBinding;
        private readonly Binding _newBinding;
        private readonly object _changeInfo;

        public NamingEvent(EventContext context, int type, Binding oldBinding, Binding newBinding, object changeInfo)
        {
            _context = context;
            _type = type;
            _oldBinding = oldBinding;
            _newBinding = newBinding;
            _changeInfo = changeInfo;
        }

        public EventContext GetEventContext() => _context;
        public Binding GetOldBinding() => _oldBinding;
        public Binding GetNewBinding() => _newBinding;
        public object GetChangeInfo() => _changeInfo;

        // Hides Object.GetType() – matches Java's getType() returning int
        public new int GetType() => _type;

        public void Dispatch(NamingListener listener)
        {
            // Mimics Java dispatch logic
            if (_type == OBJECT_CHANGED && listener is ObjectChangeListener objListener)
            {
                objListener.ObjectChanged(this);
            }
            else if (_type == NAMESPACE_CHANGED && listener is NamespaceChangeListener nsListener)
            {
                nsListener.NamespaceChanged(this);
            }
            else
            {
                // For other type values, no action (Java also does nothing for unhandled types)
            }
        }
    }

    // Simple test listener that implements both interfaces for the dispatch test
    public class TestNamingListener : ObjectChangeListener, NamespaceChangeListener
    {
        public void ObjectChanged(NamingEvent evt) { }
        public void NamespaceChanged(NamingEvent evt) { }
    }

    [TestFixture]
    public class NamingEventAutoTest
    {
        [Test]
        public void GetEventContext_Test_5999()
        {
            var c0 = new EventContext();
            int c1 = 0;
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            instance.GetEventContext();
        }

        [Test]
        public void GetOldBinding_Test_6000()
        {
            var c0 = new EventContext();
            int c1 = 0;
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            instance.GetOldBinding();
        }

        [Test]
        public void GetNewBinding_Test_6001()
        {
            var c0 = new EventContext();
            int c1 = 0;
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            instance.GetNewBinding();
        }

        [Test]
        public void GetChangeInfo_Test_6002()
        {
            var c0 = new EventContext();
            int c1 = 0;
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            instance.GetChangeInfo();
        }

        [Test]
        public void Dispatch_Test_6003()
        {
            var c0 = new EventContext();
            int c1 = NamingEvent.OBJECT_CHANGED; // so dispatch calls ObjectChangeListener
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            var p0 = new TestNamingListener();
            instance.Dispatch(p0);
        }

        [Test]
        public void GetType_Test_6004()
        {
            var c0 = new EventContext();
            int c1 = 0;
            var c2 = new Binding("old", null);
            var c3 = new Binding("new", null);
            object c4 = null;
            var instance = new NamingEvent(c0, c1, c2, c3, c4);
            instance.GetType(); // returns the int type value
        }
    }
}
```