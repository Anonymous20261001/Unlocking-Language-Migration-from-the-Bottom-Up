```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// Replicate Java's Observer interface
public interface IObserver
{
    void Update(Observable o, object arg);
}

// Replicate Java's Observable class
public class Observable
{
    private List<IObserver> observers;
    private bool changed;

    public Observable()
    {
        observers = new List<IObserver>();
        changed = false;
    }

    public void AddObserver(IObserver observer)
    {
        if (observer == null)
            throw new ArgumentNullException(nameof(observer));
        if (!observers.Contains(observer))
            observers.Add(observer);
    }

    public void DeleteObserver(IObserver observer)
    {
        observers.Remove(observer);
    }

    public void DeleteObservers()
    {
        observers.Clear();
    }

    public bool HasChanged()
    {
        return changed;
    }

    public int CountObservers()
    {
        return observers.Count;
    }

    public void NotifyObservers()
    {
        NotifyObservers(null);
    }

    public void NotifyObservers(object arg)
    {
        if (!changed)
            return;

        // Make a copy of the observer list to avoid modification during iteration
        List<IObserver> arrLocal = new List<IObserver>(observers);
        ClearChanged();

        foreach (IObserver observer in arrLocal)
        {
            observer.Update(this, arg);
        }
    }

    protected void SetChanged()
    {
        changed = true;
    }

    protected void ClearChanged()
    {
        changed = false;
    }
}

// Test class
[TestFixture]
public class ObservableAutoTest
{
    [Test]
    public void NotifyObservers_Test_3711(object p0)
    {
        Observable instance = new Observable();
        instance.NotifyObservers(p0);
    }

    [Test]
    public void NotifyObservers_Test_3712()
    {
        Observable instance = new Observable();
        instance.NotifyObservers();
    }

    [Test]
    public void AddObserver_Test_3713(IObserver p0)
    {
        Observable instance = new Observable();
        instance.AddObserver(p0);
    }

    [Test]
    public void DeleteObserver_Test_3714(IObserver p0)
    {
        Observable instance = new Observable();
        instance.DeleteObserver(p0);
    }

    [Test]
    public void DeleteObservers_Test_3715()
    {
        Observable instance = new Observable();
        instance.DeleteObservers();
    }

    [Test]
    public void HasChanged_Test_3716()
    {
        Observable instance = new Observable();
        instance.HasChanged();
    }

    [Test]
    public void CountObservers_Test_3717()
    {
        Observable instance = new Observable();
        instance.CountObservers();
    }
}
```