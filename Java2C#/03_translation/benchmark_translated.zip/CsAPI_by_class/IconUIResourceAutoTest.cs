```csharp
using System;
using System.Drawing;
using System.Windows.Forms;
using Xunit;

namespace Generated.Test
{
    // Equivalent to javax.swing.Icon
    public interface IIcon
    {
        int GetIconWidth();
        int GetIconHeight();
        void PaintIcon(Component c, Graphics g, int x, int y);
    }

    // Equivalent to javax.swing.plaf.IconUIResource
    public class IconUIResource : IIcon
    {
        private readonly IIcon _delegate;

        public IconUIResource(IIcon delegateIcon)
        {
            _delegate = delegateIcon ?? throw new ArgumentNullException(nameof(delegateIcon));
        }

        public int GetIconWidth() => _delegate.GetIconWidth();

        public int GetIconHeight() => _delegate.GetIconHeight();

        public void PaintIcon(Component c, Graphics g, int x, int y) =>
            _delegate.PaintIcon(c, g, x, y);
    }

    // Test class corresponding to IconUIResourceAutoTest
    public class IconUIResourceAutoTest
    {
        [Fact]
        public void GetIconWidth_test_8587()
        {
            IIcon mockIcon = new MockIcon();
            var instance = new IconUIResource(mockIcon);
            instance.GetIconWidth();
        }

        [Fact]
        public void GetIconHeight_test_8588()
        {
            IIcon mockIcon = new MockIcon();
            var instance = new IconUIResource(mockIcon);
            instance.GetIconHeight();
        }

        [Fact]
        public void PaintIcon_test_8589()
        {
            IIcon mockIcon = new MockIcon();
            var instance = new IconUIResource(mockIcon);
            // In the original test, Component and Graphics are provided externally.
            // For the C# translation we use null to keep the test simple, assuming
            // the delegate icon will handle null pointers gracefully (as in typical unit tests).
            instance.PaintIcon(null, null, 10, 20);
        }

        // Simple mock implementation for testing only
        private class MockIcon : IIcon
        {
            public int GetIconWidth() => 0;
            public int GetIconHeight() => 0;
            public void PaintIcon(Component c, Graphics g, int x, int y)
            {
                // No-op
            }
        }
    }
}
```