```csharp
using NUnit.Framework;

namespace Generated.Test
{
    // Simple border class to mimic Java's javax.swing.border.Border
    public class Border { }

    // C# equivalent of javax.swing.plaf.metal.MetalBorders
    public class MetalBorders
    {
        private static Border textBorder;
        private static Border desktopIconBorder;
        private static Border buttonBorder;
        private static Border toggleButtonBorder;
        private static Border textFieldBorder;

        public static Border GetTextBorder()
        {
            if (textBorder == null)
                textBorder = new Border();
            return textBorder;
        }

        public static Border GetDesktopIconBorder()
        {
            if (desktopIconBorder == null)
                desktopIconBorder = new Border();
            return desktopIconBorder;
        }

        public static Border GetButtonBorder()
        {
            if (buttonBorder == null)
                buttonBorder = new Border();
            return buttonBorder;
        }

        public static Border GetToggleButtonBorder()
        {
            if (toggleButtonBorder == null)
                toggleButtonBorder = new Border();
            return toggleButtonBorder;
        }

        public static Border GetTextFieldBorder()
        {
            if (textFieldBorder == null)
                textFieldBorder = new Border();
            return textFieldBorder;
        }
    }

    [TestFixture]
    public class MetalBordersAutoTest
    {
        [Test]
        public void getTextBorder_test_9081()
        {
            MetalBorders instance = new MetalBorders();
            MetalBorders.GetTextBorder();
        }

        [Test]
        public void getDesktopIconBorder_test_9082()
        {
            MetalBorders instance = new MetalBorders();
            MetalBorders.GetDesktopIconBorder();
        }

        [Test]
        public void getButtonBorder_test_9083()
        {
            MetalBorders instance = new MetalBorders();
            MetalBorders.GetButtonBorder();
        }

        [Test]
        public void getToggleButtonBorder_test_9084()
        {
            MetalBorders instance = new MetalBorders();
            MetalBorders.GetToggleButtonBorder();
        }

        [Test]
        public void getTextFieldBorder_test_9085()
        {
            MetalBorders instance = new MetalBorders();
            MetalBorders.GetTextFieldBorder();
        }
    }
}
```