```csharp
using System;
using NUnit.Framework;

namespace generated.test
{
    [TestFixture]
    public class IllegalFormatCodePointExceptionAutoTest
    {
        [Test]
        public void GetMessage_test_3564()
        {
            int c0 = 0; // Placeholder value; original Java had parameter
            IllegalFormatCodePointException instance = new IllegalFormatCodePointException(c0);
            instance.GetMessage(); // Ensure method exists and can be called
        }

        [Test]
        public void GetCodePoint_test_3565()
        {
            int c0 = 0; // Placeholder value; original Java had parameter
            IllegalFormatCodePointException instance = new IllegalFormatCodePointException(c0);
            instance.GetCodePoint(); // Ensure method exists and can be called
        }
    }

    /// <summary>
    /// C# equivalent of Java's java.util.IllegalFormatCodePointException.
    /// </summary>
    public class IllegalFormatCodePointException : Exception
    {
        private readonly int codePoint;

        /// <summary>
        /// Constructs an instance with the specified illegal code point.
        /// </summary>
        /// <param name="c">The illegal Unicode code point.</param>
        public IllegalFormatCodePointException(int c)
            : base(FormatMessage(c))
        {
            codePoint = c;
        }

        /// <summary>
        /// Gets the illegal code point.
        /// </summary>
        /// <returns>The code point value.</returns>
        public int GetCodePoint()
        {
            return codePoint;
        }

        /// <summary>
        /// Gets the detail message string. (Method version, not property, to match Java API.)
        /// </summary>
        /// <returns>The detail message.</returns>
        public string GetMessage()
        {
            // In Java, getMessage() returns the message passed to the superclass constructor.
            // Since we passed the formatted message to the base Exception, we can reuse it.
            return Message;
        }

        private static string FormatMessage(int c)
        {
            return "Code point = 0x" + c.ToString("X");
        }
    }
}
```