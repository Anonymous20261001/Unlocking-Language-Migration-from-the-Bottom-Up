```csharp
using System;
using System.Collections.Generic;
using Xunit;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.imageio.plugins.jpeg.JPEGHuffmanTable.
    /// </summary>
    public class JPEGHuffmanTable
    {
        private readonly short[] _lengths;
        private readonly short[] _values;

        /// <summary>
        /// Creates a new JPEGHuffmanTable from the given arrays.
        /// </summary>
        /// <param name="lengths">Array of 16 Huffman lengths (must have exactly 16 elements).</param>
        /// <param name="values">Array of Huffman values (its length must equal the sum of lengths).</param>
        /// <exception cref="ArgumentException">If the preconditions are not met.</exception>
        public JPEGHuffmanTable(short[] lengths, short[] values)
        {
            if (lengths == null || lengths.Length != 16)
                throw new ArgumentException("lengths must be an array of 16 elements", nameof(lengths));

            if (values == null)
                throw new ArgumentException("values must not be null", nameof(values));

            int sum = 0;
            foreach (short len in lengths)
            {
                if (len < 0 || len > 255)
                    throw new ArgumentException("Each element of lengths must be between 0 and 255", nameof(lengths));
                sum += len;
            }

            if (values.Length != sum)
                throw new ArgumentException("values length must equal the sum of lengths", nameof(values));

            _lengths = (short[])lengths.Clone();
            _values = (short[])values.Clone();
        }

        /// <summary>
        /// Returns the array of lengths for this Huffman table.
        /// </summary>
        /// <returns>A copy of the internal lengths array.</returns>
        public short[] GetLengths()
        {
            return (short[])_lengths.Clone();
        }

        /// <summary>
        /// Returns the array of values for this Huffman table.
        /// </summary>
        /// <returns>A copy of the internal values array.</returns>
        public short[] GetValues()
        {
            return (short[])_values.Clone();
        }

        /// <summary>
        /// Returns a string representation of this Huffman table.
        /// </summary>
        public override string ToString()
        {
            return $"JPEGHuffmanTable(lengths={string.Join(",", _lengths)}, values={string.Join(",", _values)})";
        }
    }

    /// <summary>
    /// Test class equivalent to JPEGHuffmanTableAutoTest.
    /// </summary>
    public class JPEGHuffmanTableAutoTest
    {
        /// <summary>
        /// Provides test data for the parameterized tests.
        /// </summary>
        public static IEnumerable<object[]> GetTestData()
        {
            // Valid case: all lengths zero, empty values
            short[] lengths0 = new short[16]; // all zeros
            short[] values0 = new short[0];
            yield return new object[] { lengths0, values0 };

            // Another valid case: one code of length 1, one value
            short[] lengths1 = new short[16];
            lengths1[0] = 1; // 1 code of bit length 1
            short[] values1 = new short[] { 0x00 };
            yield return new object[] { lengths1, values1 };
        }

        [Theory]
        [MemberData(nameof(GetTestData))]
        public void GetLengths_Test_5392(short[] c0, short[] c1)
        {
            JPEGHuffmanTable instance = new JPEGHuffmanTable(c0, c1);
            instance.GetLengths();
        }

        [Theory]
        [MemberData(nameof(GetTestData))]
        public void GetValues_Test_5393(short[] c0, short[] c1)
        {
            JPEGHuffmanTable instance = new JPEGHuffmanTable(c0, c1);
            instance.GetValues();
        }

        [Theory]
        [MemberData(nameof(GetTestData))]
        public void ToString_Test_5394(short[] c0, short[] c1)
        {
            JPEGHuffmanTable instance = new JPEGHuffmanTable(c0, c1);
            instance.ToString();
        }
    }
}
```