```csharp
using System.Numerics;
using NUnit.Framework;

// Minimal implementations of Java security spec classes
public class ECPoint
{
    public BigInteger AffineX { get; }
    public BigInteger AffineY { get; }

    public ECPoint(BigInteger x, BigInteger y)
    {
        AffineX = x;
        AffineY = y;
    }

    public BigInteger GetAffineX() => AffineX;
    public BigInteger GetAffineY() => AffineY;
}

// Simplified ECField interface
public interface ECField { }

public class ECFieldFp : ECField
{
    public BigInteger Prime { get; }

    public ECFieldFp(BigInteger prime)
    {
        Prime = prime;
    }
}

public class EllipticCurve
{
    private ECField field;
    private BigInteger a;
    private BigInteger b;

    public EllipticCurve(ECField field, BigInteger a, BigInteger b)
    {
        this.field = field;
        this.a = a;
        this.b = b;
    }

    public ECField GetField() => field;
    public BigInteger GetA() => a;
    public BigInteger GetB() => b;
}

public class ECParameterSpec
{
    private EllipticCurve curve;
    private ECPoint generator;
    private BigInteger order;
    private int cofactor;

    public ECParameterSpec(EllipticCurve curve, ECPoint generator, BigInteger order, int cofactor)
    {
        this.curve = curve;
        this.generator = generator;
        this.order = order;
        this.cofactor = cofactor;
    }

    public EllipticCurve GetCurve() => curve;
    public ECPoint GetGenerator() => generator;
    public BigInteger GetOrder() => order;
    public int GetCofactor() => cofactor;
}

[TestFixture]
public class ECParameterSpecAutoTest
{
    // Helper to create a simple EllipticCurve instance (used by all tests)
    private static EllipticCurve CreateCurve()
    {
        ECField field = new ECFieldFp(BigInteger.Zero);
        return new EllipticCurve(field, BigInteger.Zero, BigInteger.Zero);
    }

    [Test]
    public void getCurve_test_2869()
    {
        EllipticCurve c0 = CreateCurve();
        ECPoint c1 = new ECPoint(BigInteger.Zero, BigInteger.Zero);
        BigInteger c2 = BigInteger.Zero;
        int c3 = 0;
        ECParameterSpec instance = new ECParameterSpec(c0, c1, c2, c3);
        instance.GetCurve();
    }

    [Test]
    public void getGenerator_test_2870()
    {
        EllipticCurve c0 = CreateCurve();
        ECPoint c1 = new ECPoint(BigInteger.Zero, BigInteger.Zero);
        BigInteger c2 = BigInteger.Zero;
        int c3 = 0;
        ECParameterSpec instance = new ECParameterSpec(c0, c1, c2, c3);
        instance.GetGenerator();
    }

    [Test]
    public void getCofactor_test_2871()
    {
        EllipticCurve c0 = CreateCurve();
        ECPoint c1 = new ECPoint(BigInteger.Zero, BigInteger.Zero);
        BigInteger c2 = BigInteger.Zero;
        int c3 = 0;
        ECParameterSpec instance = new ECParameterSpec(c0, c1, c2, c3);
        instance.GetCofactor();
    }

    [Test]
    public void getOrder_test_2872()
    {
        EllipticCurve c0 = CreateCurve();
        ECPoint c1 = new ECPoint(BigInteger.Zero, BigInteger.Zero);
        BigInteger c2 = BigInteger.Zero;
        int c3 = 0;
        ECParameterSpec instance = new ECParameterSpec(c0, c1, c2, c3);
        instance.GetOrder();
    }
}
```