```csharp
using System;
using NUnit.Framework;

// Placeholder for Java's OpenMBeanParameterInfo interface
public interface IOpenMBeanParameterInfo { }

// Simple concrete implementation (not used in tests except as array)
public class OpenMBeanParameterInfo : IOpenMBeanParameterInfo { }

// Placeholder for Java's abstract OpenType class
public abstract class OpenType { }

// Equivalent to Java's OpenMBeanOperationInfoSupport
public class OpenMBeanOperationInfoSupport
{
    private readonly string name;
    private readonly string description;
    private readonly IOpenMBeanParameterInfo[] signature;
    private readonly OpenType returnOpenType;
    private readonly int impact;

    public OpenMBeanOperationInfoSupport(
        string name,
        string description,
        IOpenMBeanParameterInfo[] signature,
        OpenType returnOpenType,
        int impact)
    {
        this.name = name;
        this.description = description;
        this.signature = signature;
        this.returnOpenType = returnOpenType;
        this.impact = impact;
    }

    public OpenType GetReturnOpenType()
    {
        return returnOpenType;
    }

    public override bool Equals(object obj)
    {
        if (obj is OpenMBeanOperationInfoSupport other)
        {
            return name == other.name &&
                   description == other.description &&
                   impact == other.impact &&
                   Equals(returnOpenType, other.returnOpenType) &&
                   ArraysEqual(signature, other.signature);
        }
        return false;
    }

    public override int GetHashCode()
    {
        unchecked
        {
            int hash = 17;
            hash = hash * 31 + (name?.GetHashCode() ?? 0);
            hash = hash * 31 + (description?.GetHashCode() ?? 0);
            hash = hash * 31 + impact;
            hash = hash * 31 + (returnOpenType?.GetHashCode() ?? 0);
            hash = hash * 31 + (signature != null ? CombineArrayHash(signature) : 0);
            return hash;
        }
    }

    public override string ToString()
    {
        return $"OpenMBeanOperationInfoSupport[name={name}, description={description}, impact={impact}]";
    }

    private static bool ArraysEqual(IOpenMBeanParameterInfo[] a, IOpenMBeanParameterInfo[] b)
    {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a.Length != b.Length) return false;
        for (int i = 0; i < a.Length; i++)
        {
            if (!Equals(a[i], b[i])) return false;
        }
        return true;
    }

    private static int CombineArrayHash(IOpenMBeanParameterInfo[] arr)
    {
        int hash = 0;
        foreach (var item in arr)
        {
            hash = hash * 31 + (item?.GetHashCode() ?? 0);
        }
        return hash;
    }
}

[TestFixture]
public class OpenMBeanOperationInfoSupportAutoTest
{
    [Test]
    public void GetReturnOpenType_test_5763(string c0, string c1, IOpenMBeanParameterInfo[] c2, OpenType c3, int c4)
    {
        OpenMBeanOperationInfoSupport instance = new OpenMBeanOperationInfoSupport(c0, c1, c2, c3, c4);
        instance.GetReturnOpenType();
    }

    [Test]
    public void Equals_test_5764(object p0, string c0, string c1, IOpenMBeanParameterInfo[] c2, OpenType c3, int c4)
    {
        OpenMBeanOperationInfoSupport instance = new OpenMBeanOperationInfoSupport(c0, c1, c2, c3, c4);
        instance.Equals(p0);
    }

    [Test]
    public void ToString_test_5765(string c0, string c1, IOpenMBeanParameterInfo[] c2, OpenType c3, int c4)
    {
        OpenMBeanOperationInfoSupport instance = new OpenMBeanOperationInfoSupport(c0, c1, c2, c3, c4);
        instance.ToString();
    }

    [Test]
    public void HashCode_test_5766(string c0, string c1, IOpenMBeanParameterInfo[] c2, OpenType c3, int c4)
    {
        OpenMBeanOperationInfoSupport instance = new OpenMBeanOperationInfoSupport(c0, c1, c2, c3, c4);
        instance.GetHashCode();
    }
}
```