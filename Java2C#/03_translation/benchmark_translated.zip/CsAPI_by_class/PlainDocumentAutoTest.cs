```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class PlainDocumentAutoTest
    {
        [Test]
        public void GetDefaultRootElement_Test_10330()
        {
            PlainDocument instance = new PlainDocument();
            instance.GetDefaultRootElement();
        }

        [TestCase(0)]
        public void GetParagraphElement_Test_10331(int p0)
        {
            PlainDocument instance = new PlainDocument();
            instance.GetParagraphElement(p0);
        }
    }

    public class PlainDocument
    {
        public Element GetDefaultRootElement()
        {
            return new Element();
        }

        public Element GetParagraphElement(int index)
        {
            return new Element();
        }
    }

    public class Element
    {
        // Minimal stub class matching the Java API contract
    }
}
```