```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace generated.test
{
    // ---------- CompositeData (simplified) ----------
    public class CompositeData
    {
        private readonly Dictionary<string, object> _data;

        public CompositeData(Dictionary<string, object> data)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
        }

        public object Get(string key)
        {
            if (!_data.ContainsKey(key))
                throw new ArgumentException($"Key '{key}' not found in CompositeData");
            return _data[key];
        }
    }

    // ---------- MemoryUsage ----------
    public class MemoryUsage
    {
        private readonly long _init;
        private readonly long _used;
        private readonly long _committed;
        private readonly long _max;

        public MemoryUsage(long init, long used, long committed, long max)
        {
            _init = init;
            _used = used;
            _committed = committed;
            _max = max;
        }

        public long GetInit() => _init;
        public long GetUsed() => _used;
        public long GetCommitted() => _committed;
        public long GetMax() => _max;

        public static MemoryUsage From(CompositeData cd)
        {
            if (cd == null)
                throw new ArgumentNullException(nameof(cd));

            long init = (long)cd.Get("init");
            long used = (long)cd.Get("used");
            long committed = (long)cd.Get("committed");
            long max = (long)cd.Get("max");

            return new MemoryUsage(init, used, committed, max);
        }
    }

    // ---------- MemoryNotificationInfo ----------
    public class MemoryNotificationInfo
    {
        private readonly string _poolName;
        private readonly MemoryUsage _usage;
        private readonly long _count;

        public MemoryNotificationInfo(string poolName, MemoryUsage usage, long count)
        {
            _poolName = poolName;
            _usage = usage;
            _count = count;
        }

        public string GetPoolName() => _poolName;
        public MemoryUsage GetUsage() => _usage;
        public long GetCount() => _count;

        public static MemoryNotificationInfo From(CompositeData cd)
        {
            if (cd == null)
                throw new ArgumentNullException(nameof(cd));

            string poolName = (string)cd.Get("poolName");
            CompositeData usageData = (CompositeData)cd.Get("usage");
            long count = (long)cd.Get("count");

            MemoryUsage usage = MemoryUsage.From(usageData);
            return new MemoryNotificationInfo(poolName, usage, count);
        }
    }

    // ---------- Test Class ----------
    [TestFixture]
    public class MemoryNotificationInfoAutoTest
    {
        [Test]
        public void GetPoolName_test_2407()
        {
            MemoryUsage usage = new MemoryUsage(100, 50, 80, 200);
            MemoryNotificationInfo instance = new MemoryNotificationInfo("TestPool", usage, 5);
            string actual = instance.GetPoolName();
            Assert.AreEqual("TestPool", actual);
        }

        [Test]
        public void GetUsage_test_2408()
        {
            MemoryUsage usage = new MemoryUsage(100, 50, 80, 200);
            MemoryNotificationInfo instance = new MemoryNotificationInfo("TestPool", usage, 5);
            MemoryUsage actual = instance.GetUsage();
            Assert.AreSame(usage, actual);
        }

        [Test]
        public void From_test_2409()
        {
            // Build nested CompositeData for MemoryUsage
            var usageData = new Dictionary<string, object>
            {
                { "init", 100L },
                { "used", 50L },
                { "committed", 80L },
                { "max", 200L }
            };
            CompositeData usageComposite = new CompositeData(usageData);

            // Build top-level CompositeData for MemoryNotificationInfo
            var data = new Dictionary<string, object>
            {
                { "poolName", "FromPool" },
                { "usage", usageComposite },
                { "count", 7L }
            };
            CompositeData composite = new CompositeData(data);

            MemoryNotificationInfo result = MemoryNotificationInfo.From(composite);

            Assert.AreEqual("FromPool", result.GetPoolName());
            Assert.AreEqual(100, result.GetUsage().GetInit());
            Assert.AreEqual(50, result.GetUsage().GetUsed());
            Assert.AreEqual(80, result.GetUsage().GetCommitted());
            Assert.AreEqual(200, result.GetUsage().GetMax());
            Assert.AreEqual(7, result.GetCount());
        }

        [Test]
        public void GetCount_test_2410()
        {
            MemoryUsage usage = new MemoryUsage(100, 50, 80, 200);
            MemoryNotificationInfo instance = new MemoryNotificationInfo("TestPool", usage, 42);
            long actual = instance.GetCount();
            Assert.AreEqual(42, actual);
        }
    }
}
```