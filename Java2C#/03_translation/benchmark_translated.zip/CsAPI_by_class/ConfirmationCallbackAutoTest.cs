```csharp
using System;
using Xunit;

namespace Generated.Test
{
    // Equivalent of javax.security.auth.callback.ConfirmationCallback
    public class ConfirmationCallback
    {
        // Constants for message types (optional, not used in tests)
        public const int INFORMATION = 0;
        public const int WARNING = 1;
        public const int ERROR = 2;

        // Constant for unspecified option type
        public const int OPTION_UNSPECIFIED = -1;

        private readonly int messageType;
        private readonly int optionType;
        private readonly string[] options;
        private readonly int defaultOption;
        private readonly string prompt;
        private int selectedIndex;

        // Constructor used in tests: (int messageType, string[] options, int defaultOption)
        public ConfirmationCallback(int messageType, string[] options, int defaultOption)
        {
            this.messageType = messageType;
            this.options = options ?? throw new ArgumentNullException(nameof(options));
            this.defaultOption = defaultOption;
            this.optionType = OPTION_UNSPECIFIED;
            this.selectedIndex = defaultOption;
            this.prompt = null;
        }

        public string GetPrompt() => prompt;

        public void SetSelectedIndex(int index) => selectedIndex = index;

        public int GetMessageType() => messageType;

        public int GetOptionType() => optionType;

        public string[] GetOptions() => options;

        public int GetDefaultOption() => defaultOption;

        public int GetSelectedIndex() => selectedIndex;
    }

    public class ConfirmationCallbackAutoTest
    {
        [Fact]
        public void GetPrompt_Test_6333()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetPrompt();
        }

        [Fact]
        public void SetSelectedIndex_Test_6334()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.SetSelectedIndex(1);
        }

        [Fact]
        public void GetMessageType_Test_6335()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetMessageType();
        }

        [Fact]
        public void GetOptionType_Test_6336()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetOptionType();
        }

        [Fact]
        public void GetOptions_Test_6337()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetOptions();
        }

        [Fact]
        public void GetDefaultOption_Test_6338()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetDefaultOption();
        }

        [Fact]
        public void GetSelectedIndex_Test_6339()
        {
            ConfirmationCallback instance = new ConfirmationCallback(0, new string[] {"Yes", "No"}, 0);
            instance.GetSelectedIndex();
        }
    }
}
```