```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class PEMRecord
    {
        private readonly string _type;
        private readonly string _content;

        public PEMRecord(string type, string content)
        {
            _type = type ?? throw new ArgumentNullException(nameof(type));
            _content = content ?? throw new ArgumentNullException(nameof(content));
        }

        public string LeadingData() => string.Empty; // No leading data provided in constructor

        public string Type() => _type;

        public string Content() => _content;

        public override bool Equals(object obj)
        {
            if (obj is PEMRecord other)
                return _type == other._type && _content == other._content;
            return false;
        }

        public override int GetHashCode() => HashCode.Combine(_type, _content);

        public override string ToString() => $"PEMRecord[type={_type}, content={_content}]";
    }

    [TestFixture]
    public class PEMRecordAutoTest
    {
        [Test]
        public void LeadingData_Test_2709()
        {
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.LeadingData();
        }

        [Test]
        public void Type_Test_2710()
        {
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.Type();
        }

        [Test]
        public void Equals_Test_2711()
        {
            object p0 = new object();
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.Equals(p0);
        }

        [Test]
        public void ToString_Test_2712()
        {
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.ToString();
        }

        [Test]
        public void HashCode_Test_2713()
        {
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.GetHashCode();
        }

        [Test]
        public void Content_Test_2714()
        {
            string c0 = "CERTIFICATE";
            string c1 = "base64data";
            PEMRecord instance = new PEMRecord(c0, c1);
            instance.Content();
        }
    }
}
```