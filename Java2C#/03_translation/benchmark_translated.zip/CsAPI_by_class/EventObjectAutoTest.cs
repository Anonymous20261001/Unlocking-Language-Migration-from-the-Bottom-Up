```csharp
using NUnit.Framework;
using System;

namespace Generated.Test
{
    [TestFixture]
    public class EventObjectAutoTest
    {
        [Test]
        public void GetSource_Test_3441()
        {
            object c0 = new object();
            EventObject instance = new EventObject(c0);
            instance.GetSource();
        }

        [Test]
        public void ToString_Test_3442()
        {
            object c0 = new object();
            EventObject instance = new EventObject(c0);
            instance.ToString();
        }
    }

    public class EventObject
    {
        private readonly object source;

        public EventObject(object source)
        {
            this.source = source;
        }

        public object GetSource()
        {
            return source;
        }

        public override string ToString()
        {
            return $"{GetType().Name}[source={source}]";
        }
    }
}
```