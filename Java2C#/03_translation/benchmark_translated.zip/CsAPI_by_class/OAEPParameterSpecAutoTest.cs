```csharp
using System;
using System.Security.Cryptography;
using NUnit.Framework;

// Equivalent to java.security.spec.AlgorithmParameterSpec
public abstract class AlgorithmParameterSpec { }

// Equivalent to javax.crypto.spec.PSource
public class PSource
{
    public string Algorithm { get; }

    public PSource(string algorithm)
    {
        Algorithm = algorithm;
    }

    // Subclass PSpecified
    public class PSpecified : PSource
    {
        public static readonly PSpecified DEFAULT = new PSpecified(new byte[0]);

        public byte[] Value { get; }

        public PSpecified(byte[] value) : base("PSpecified")
        {
            Value = value ?? throw new ArgumentNullException(nameof(value));
        }

        public byte[] GetValue() => Value;
    }
}

// Equivalent to javax.crypto.spec.OAEPParameterSpec
public class OAEPParameterSpec
{
    public string DigestAlgorithm { get; }
    public string MGFAlgorithm { get; }
    public AlgorithmParameterSpec MGFParameters { get; }
    public PSource PSource { get; }

    public OAEPParameterSpec(string mdName, string mgfName, AlgorithmParameterSpec mgfSpec, PSource pSource)
    {
        DigestAlgorithm = mdName;
        MGFAlgorithm = mgfName;
        MGFParameters = mgfSpec;
        PSource = pSource;
    }
}

// Test class corresponding to OAEPParameterSpecAutoTest
[TestFixture]
public class OAEPParameterSpecAutoTest
{
    [Test]
    public void getPSource_test_5250()
    {
        var instance = new OAEPParameterSpec("SHA-256", "MGF1", null, new PSource.PSpecified(new byte[] { 0x01 }));
        var result = instance.PSource;
        Assert.IsNotNull(result);
    }

    [Test]
    public void getDigestAlgorithm_test_5251()
    {
        var instance = new OAEPParameterSpec("SHA-256", "MGF1", null, new PSource.PSpecified(new byte[] { 0x01 }));
        var result = instance.DigestAlgorithm;
        Assert.AreEqual("SHA-256", result);
    }

    [Test]
    public void getMGFAlgorithm_test_5252()
    {
        var instance = new OAEPParameterSpec("SHA-256", "MGF1", null, new PSource.PSpecified(new byte[] { 0x01 }));
        var result = instance.MGFAlgorithm;
        Assert.AreEqual("MGF1", result);
    }

    [Test]
    public void getMGFParameters_test_5253()
    {
        // Use a simple AlgorithmParameterSpec subclass for testing
        var mgfSpec = new TestMGFParameters();
        var instance = new OAEPParameterSpec("SHA-256", "MGF1", mgfSpec, new PSource.PSpecified(new byte[] { 0x01 }));
        var result = instance.MGFParameters;
        Assert.AreSame(mgfSpec, result);
    }

    // Helper class for testing MGF parameters
    private class TestMGFParameters : AlgorithmParameterSpec { }
}
```