```csharp
using NUnit.Framework;
using System;

public class PagesPerMinuteColor
{
    private readonly int _value;

    public PagesPerMinuteColor(int value)
    {
        _value = value;
    }

    public Type GetCategory()
    {
        return typeof(PagesPerMinuteColor);
    }

    public string GetName()
    {
        return "pages-per-minute-color";
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
            return false;

        var other = (PagesPerMinuteColor)obj;
        return _value == other._value;
    }

    public override int GetHashCode()
    {
        return _value.GetHashCode();
    }

    public int GetValue()
    {
        return _value;
    }
}

[TestFixture]
public class PagesPerMinuteColorAutoTest
{
    [Test]
    public void GetCategory_test_6207()
    {
        var instance = new PagesPerMinuteColor(0);
        instance.GetCategory();
    }

    [Test]
    public void GetName_test_6208()
    {
        var instance = new PagesPerMinuteColor(0);
        instance.GetName();
    }

    [Test]
    public void Equals_test_6209()
    {
        var instance = new PagesPerMinuteColor(0);
        instance.Equals(new object());
    }
}
```