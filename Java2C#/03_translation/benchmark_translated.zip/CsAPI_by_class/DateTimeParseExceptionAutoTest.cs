```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class DateTimeParseExceptionAutoTest
    {
        [Test]
        public void GetParsedString_test_3275()
        {
            DateTimeParseException instance = new DateTimeParseException("message", "parsedString", 0);
            instance.GetParsedString();
        }

        [Test]
        public void GetErrorIndex_test_3276()
        {
            DateTimeParseException instance = new DateTimeParseException("message", "parsedString", 0);
            instance.GetErrorIndex();
        }
    }

    public class DateTimeParseException : Exception
    {
        private readonly string parsedString;
        private readonly int errorIndex;

        public DateTimeParseException(string message, string parsedString, int errorIndex) : base(message)
        {
            this.parsedString = parsedString;
            this.errorIndex = errorIndex;
        }

        public string GetParsedString() => parsedString;
        public int GetErrorIndex() => errorIndex;
    }
}
```