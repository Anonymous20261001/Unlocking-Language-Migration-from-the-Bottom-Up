```csharp
using System.Drawing;
using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes to mimic Java AWT types
    public class Component { }
    public class Graphics { }
    public class Insets
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int Bottom { get; set; }
        public int Right { get; set; }

        public Insets() { }
        public Insets(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    // C# equivalent of javax.swing.border.LineBorder
    public class LineBorder
    {
        private readonly Color lineColor;
        private readonly int thickness;
        private readonly bool roundedCorners;

        public LineBorder(Color color) : this(color, 1, false) { }

        public LineBorder(Color color, int thickness, bool roundedCorners)
        {
            this.lineColor = color;
            this.thickness = thickness;
            this.roundedCorners = roundedCorners;
        }

        public static LineBorder CreateBlackLineBorder()
        {
            return new LineBorder(Color.Black);
        }

        public static LineBorder CreateGrayLineBorder()
        {
            return new LineBorder(Color.Gray);
        }

        public void PaintBorder(Component c, Graphics g, int x, int y, int width, int height)
        {
            // No actual drawing – kept as a stub for test compatibility
        }

        public Insets GetBorderInsets(Component c, Insets insets)
        {
            insets.Top = thickness;
            insets.Left = thickness;
            insets.Bottom = thickness;
            insets.Right = thickness;
            return insets;
        }

        public bool IsBorderOpaque()
        {
            return true;
        }

        public Color GetLineColor()
        {
            return lineColor;
        }

        public int GetThickness()
        {
            return thickness;
        }

        public bool GetRoundedCorners()
        {
            return roundedCorners;
        }
    }

    [TestFixture]
    public class LineBorderAutoTest
    {
        [Test]
        public void PaintBorder_test_8476()
        {
            var p0 = new Component();
            var p1 = new Graphics();
            int p2 = 0, p3 = 0, p4 = 0, p5 = 0;
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.PaintBorder(p0, p1, p2, p3, p4, p5);
        }

        [Test]
        public void GetBorderInsets_test_8477()
        {
            var p0 = new Component();
            var p1 = new Insets();
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.GetBorderInsets(p0, p1);
        }

        [Test]
        public void IsBorderOpaque_test_8478()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.IsBorderOpaque();
        }

        [Test]
        public void CreateBlackLineBorder_test_8479()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            LineBorder.CreateBlackLineBorder();
        }

        [Test]
        public void CreateGrayLineBorder_test_8480()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            LineBorder.CreateGrayLineBorder();
        }

        [Test]
        public void GetLineColor_test_8481()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.GetLineColor();
        }

        [Test]
        public void GetThickness_test_8482()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.GetThickness();
        }

        [Test]
        public void GetRoundedCorners_test_8483()
        {
            var c0 = Color.Black;
            LineBorder instance = new LineBorder(c0);
            instance.GetRoundedCorners();
        }
    }
}
```