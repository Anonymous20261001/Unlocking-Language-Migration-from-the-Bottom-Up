```csharp
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.security.spec.DSAParameterSpec
    public class DSAParameterSpec
    {
        private readonly BigInteger p;
        private readonly BigInteger q;
        private readonly BigInteger g;

        public DSAParameterSpec(BigInteger p, BigInteger q, BigInteger g)
        {
            this.p = p;
            this.q = q;
            this.g = g;
        }

        public BigInteger GetP() => p;
        public BigInteger GetQ() => q;
        public BigInteger GetG() => g;
    }

    [TestFixture]
    public class DSAParameterSpecAutoTest
    {
        [Test]
        public void GetP_Test_2848()
        {
            // Using dummy BigInteger values; original Java test expects parameters from runner
            var instance = new DSAParameterSpec(BigInteger.One, BigInteger.Zero, BigInteger.Ten);
            instance.GetP();
        }

        [Test]
        public void GetQ_Test_2849()
        {
            var instance = new DSAParameterSpec(BigInteger.One, BigInteger.Zero, BigInteger.Ten);
            instance.GetQ();
        }

        [Test]
        public void GetG_Test_2850()
        {
            var instance = new DSAParameterSpec(BigInteger.One, BigInteger.Zero, BigInteger.Ten);
            instance.GetG();
        }
    }
}
```