```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GeneratedTest
{
    // Simplified C# equivalent of javax.swing.event.ListSelectionListener
    public interface ListSelectionListener
    {
        void ValueChanged(ListSelectionEvent e);
    }

    // Minimal event class matching Java's ListSelectionEvent
    public class ListSelectionEvent : EventArgs
    {
        public object Source { get; }
        public int FirstIndex { get; }
        public int LastIndex { get; }
        public bool IsAdjusting { get; }

        public ListSelectionEvent(object source, int firstIndex, int lastIndex, bool isAdjusting)
        {
            Source = source;
            FirstIndex = firstIndex;
            LastIndex = lastIndex;
            IsAdjusting = isAdjusting;
        }
    }

    // C# equivalent of javax.swing.DefaultListSelectionModel
    public class DefaultListSelectionModel
    {
        private int _selectionMode = 2; // MULTIPLE_INTERVAL_SELECTION
        private int _anchorIndex = -1;
        private int _leadIndex = -1;
        private bool _leadAnchorNotificationEnabled = true;
        private bool _valueIsAdjusting = false;
        private readonly List<int> _selectedIndices = new List<int>();
        private readonly List<ListSelectionListener> _listeners = new List<ListSelectionListener>();

        // Selection mode constants (matching Java Swing)
        public const int SINGLE_SELECTION = 0;
        public const int SINGLE_INTERVAL_SELECTION = 1;
        public const int MULTIPLE_INTERVAL_SELECTION = 2;

        public void ClearSelection()
        {
            _selectedIndices.Clear();
            _anchorIndex = -1;
            _leadIndex = -1;
        }

        public bool IsSelectionEmpty()
        {
            return _selectedIndices.Count == 0;
        }

        public void SetSelectionInterval(int index0, int index1)
        {
            ClearSelection();
            int min = Math.Min(index0, index1);
            int max = Math.Max(index0, index1);
            for (int i = min; i <= max; i++)
                _selectedIndices.Add(i);
            _anchorIndex = index0;
            _leadIndex = index1;
        }

        public int GetSelectionMode()
        {
            return _selectionMode;
        }

        public int GetMinSelectionIndex()
        {
            if (_selectedIndices.Count == 0)
                return -1;
            int min = _selectedIndices[0];
            foreach (int idx in _selectedIndices)
                if (idx < min) min = idx;
            return min;
        }

        public int GetMaxSelectionIndex()
        {
            if (_selectedIndices.Count == 0)
                return -1;
            int max = _selectedIndices[0];
            foreach (int idx in _selectedIndices)
                if (idx > max) max = idx;
            return max;
        }

        public void SetSelectionMode(int mode)
        {
            _selectionMode = mode;
        }

        public bool IsSelectedIndex(int index)
        {
            return _selectedIndices.Contains(index);
        }

        public void AddListSelectionListener(ListSelectionListener listener)
        {
            _listeners.Add(listener);
        }

        public void RemoveListSelectionListener(ListSelectionListener listener)
        {
            _listeners.Remove(listener);
        }

        public ListSelectionListener[] GetListSelectionListeners()
        {
            return _listeners.ToArray();
        }

        public void SetLeadAnchorNotificationEnabled(bool flag)
        {
            _leadAnchorNotificationEnabled = flag;
        }

        public bool IsLeadAnchorNotificationEnabled()
        {
            return _leadAnchorNotificationEnabled;
        }

        public void AddSelectionInterval(int index0, int index1)
        {
            int min = Math.Min(index0, index1);
            int max = Math.Max(index0, index1);
            for (int i = min; i <= max; i++)
                if (!_selectedIndices.Contains(i))
                    _selectedIndices.Add(i);
            _anchorIndex = index0;
            _leadIndex = index1;
        }

        public void RemoveSelectionInterval(int index0, int index1)
        {
            int min = Math.Min(index0, index1);
            int max = Math.Max(index0, index1);
            _selectedIndices.RemoveAll(idx => idx >= min && idx <= max);
            _anchorIndex = index0;
            _leadIndex = index1;
        }

        public void InsertIndexInterval(int index, int length, bool before)
        {
            int start = before ? index - length + 1 : index;
            int end = index + (before ? 0 : length - 1);
            for (int i = start; i <= end; i++)
                if (!_selectedIndices.Contains(i))
                    _selectedIndices.Add(i);
            // Adjust anchor/lead? Not specified, leave as is.
        }

        public void RemoveIndexInterval(int index0, int index1)
        {
            int min = Math.Min(index0, index1);
            int max = Math.Max(index0, index1);
            _selectedIndices.RemoveAll(idx => idx >= min && idx <= max);
            // Adjust anchor/lead? Not specified, leave as is.
        }

        public int GetAnchorSelectionIndex()
        {
            return _anchorIndex;
        }

        public int GetLeadSelectionIndex()
        {
            return _leadIndex;
        }

        public void SetAnchorSelectionIndex(int index)
        {
            _anchorIndex = index;
        }

        public void MoveLeadSelectionIndex(int index)
        {
            _leadIndex = index;
        }

        public void SetLeadSelectionIndex(int index)
        {
            _leadIndex = index;
        }

        public object[] GetListeners(Type listenerType)
        {
            var result = new List<object>();
            foreach (var listener in _listeners)
            {
                if (listenerType.IsAssignableFrom(listener.GetType()))
                    result.Add(listener);
            }
            return result.ToArray();
        }

        public void SetValueIsAdjusting(bool adjusting)
        {
            _valueIsAdjusting = adjusting;
        }

        public bool GetValueIsAdjusting()
        {
            return _valueIsAdjusting;
        }

        public override string ToString()
        {
            return $"DefaultListSelectionModel[selected={string.Join(",", _selectedIndices)}]";
        }
    }

    [TestFixture]
    public class DefaultListSelectionModelAutoTest
    {
        [Test]
        public void ClearSelection_test_6770()
        {
            var instance = new DefaultListSelectionModel();
            instance.ClearSelection();
        }

        [Test]
        public void IsSelectionEmpty_test_6771()
        {
            var instance = new DefaultListSelectionModel();
            instance.IsSelectionEmpty();
        }

        [Test]
        public void SetSelectionInterval_test_6772()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetSelectionInterval(0, 1);
        }

        [Test]
        public void GetSelectionMode_test_6773()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetSelectionMode();
        }

        [Test]
        public void GetMinSelectionIndex_test_6774()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetMinSelectionIndex();
        }

        [Test]
        public void GetMaxSelectionIndex_test_6775()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetMaxSelectionIndex();
        }

        [Test]
        public void SetSelectionMode_test_6776()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetSelectionMode(0);
        }

        [Test]
        public void IsSelectedIndex_test_6777()
        {
            var instance = new DefaultListSelectionModel();
            instance.IsSelectedIndex(0);
        }

        [Test]
        public void AddListSelectionListener_test_6778()
        {
            var instance = new DefaultListSelectionModel();
            instance.AddListSelectionListener(null);
        }

        [Test]
        public void RemoveListSelectionListener_test_6779()
        {
            var instance = new DefaultListSelectionModel();
            instance.RemoveListSelectionListener(null);
        }

        [Test]
        public void GetListSelectionListeners_test_6780()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetListSelectionListeners();
        }

        [Test]
        public void SetLeadAnchorNotificationEnabled_test_6781()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetLeadAnchorNotificationEnabled(true);
        }

        [Test]
        public void IsLeadAnchorNotificationEnabled_test_6782()
        {
            var instance = new DefaultListSelectionModel();
            instance.IsLeadAnchorNotificationEnabled();
        }

        [Test]
        public void AddSelectionInterval_test_6783()
        {
            var instance = new DefaultListSelectionModel();
            instance.AddSelectionInterval(0, 1);
        }

        [Test]
        public void RemoveSelectionInterval_test_6784()
        {
            var instance = new DefaultListSelectionModel();
            instance.RemoveSelectionInterval(0, 1);
        }

        [Test]
        public void InsertIndexInterval_test_6785()
        {
            var instance = new DefaultListSelectionModel();
            instance.InsertIndexInterval(0, 1, true);
        }

        [Test]
        public void RemoveIndexInterval_test_6786()
        {
            var instance = new DefaultListSelectionModel();
            instance.RemoveIndexInterval(0, 1);
        }

        [Test]
        public void GetAnchorSelectionIndex_test_6787()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetAnchorSelectionIndex();
        }

        [Test]
        public void GetLeadSelectionIndex_test_6788()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetLeadSelectionIndex();
        }

        [Test]
        public void SetAnchorSelectionIndex_test_6789()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetAnchorSelectionIndex(0);
        }

        [Test]
        public void MoveLeadSelectionIndex_test_6790()
        {
            var instance = new DefaultListSelectionModel();
            instance.MoveLeadSelectionIndex(0);
        }

        [Test]
        public void SetLeadSelectionIndex_test_6791()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetLeadSelectionIndex(0);
        }

        [Test]
        public void GetListeners_test_6792()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetListeners(typeof(ListSelectionListener));
        }

        [Test]
        public void SetValueIsAdjusting_test_6793()
        {
            var instance = new DefaultListSelectionModel();
            instance.SetValueIsAdjusting(true);
        }

        [Test]
        public void GetValueIsAdjusting_test_6794()
        {
            var instance = new DefaultListSelectionModel();
            instance.GetValueIsAdjusting();
        }

        [Test]
        public void ToString_test_6795()
        {
            var instance = new DefaultListSelectionModel();
            instance.ToString();
        }
    }
}
```