```csharp
using System.Numerics;
using NUnit.Framework;

namespace generated.test
{
    [TestFixture]
    public class DHPrivateKeySpecAutoTest
    {
        [Test]
        public void GetP_Test_5241()
        {
            BigInteger c0 = new BigInteger(123);
            BigInteger c1 = new BigInteger(456);
            BigInteger c2 = new BigInteger(789);
            DHPrivateKeySpec instance = new DHPrivateKeySpec(c0, c1, c2);
            instance.GetP();
        }

        [Test]
        public void GetG_Test_5242()
        {
            BigInteger c0 = new BigInteger(123);
            BigInteger c1 = new BigInteger(456);
            BigInteger c2 = new BigInteger(789);
            DHPrivateKeySpec instance = new DHPrivateKeySpec(c0, c1, c2);
            instance.GetG();
        }

        [Test]
        public void GetX_Test_5243()
        {
            BigInteger c0 = new BigInteger(123);
            BigInteger c1 = new BigInteger(456);
            BigInteger c2 = new BigInteger(789);
            DHPrivateKeySpec instance = new DHPrivateKeySpec(c0, c1, c2);
            instance.GetX();
        }
    }

    public class DHPrivateKeySpec
    {
        private readonly BigInteger p;
        private readonly BigInteger g;
        private readonly BigInteger x;

        public DHPrivateKeySpec(BigInteger p, BigInteger g, BigInteger x)
        {
            this.p = p;
            this.g = g;
            this.x = x;
        }

        public BigInteger GetP() => p;
        public BigInteger GetG() => g;
        public BigInteger GetX() => x;
    }
}
```