```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class DisplayMode
    {
        private readonly int width;
        private readonly int height;
        private readonly int bitDepth;
        private readonly int refreshRate;

        public DisplayMode(int width, int height, int bitDepth, int refreshRate)
        {
            this.width = width;
            this.height = height;
            this.bitDepth = bitDepth;
            this.refreshRate = refreshRate;
        }

        public int GetWidth() => width;
        public int GetHeight() => height;
        public int GetBitDepth() => bitDepth;
        public int GetRefreshRate() => refreshRate;

        public override bool Equals(object obj)
        {
            if (obj is DisplayMode other)
            {
                return width == other.width &&
                       height == other.height &&
                       bitDepth == other.bitDepth &&
                       refreshRate == other.refreshRate;
            }
            return false;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + width;
                hash = hash * 31 + height;
                hash = hash * 31 + bitDepth;
                hash = hash * 31 + refreshRate;
                return hash;
            }
        }

        public override string ToString()
        {
            return $"DisplayMode[width={width},height={height},bitDepth={bitDepth},refreshRate={refreshRate}]";
        }
    }

    [TestFixture]
    public class DisplayModeAutoTest
    {
        [Test]
        public void getWidth_test_205()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.GetWidth();
        }

        [Test]
        public void getHeight_test_206()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.GetHeight();
        }

        [Test]
        public void getBitDepth_test_207()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.GetBitDepth();
        }

        [Test]
        public void getRefreshRate_test_208()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.GetRefreshRate();
        }

        [Test]
        public void equals_test_209()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            DisplayMode p0 = new DisplayMode(800, 600, 32, 60);
            instance.Equals(p0);
        }

        [Test]
        public void equals_test_210()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            object p0 = new DisplayMode(800, 600, 32, 60);
            instance.Equals(p0);
        }

        [Test]
        public void toString_test_211()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.ToString();
        }

        [Test]
        public void hashCode_test_212()
        {
            DisplayMode instance = new DisplayMode(800, 600, 32, 60);
            instance.GetHashCode();
        }
    }
}
```