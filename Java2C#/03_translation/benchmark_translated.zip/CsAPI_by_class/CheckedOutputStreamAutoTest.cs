```csharp
using System;
using System.IO;
using NUnit.Framework;

namespace Generated.Test
{
    // Interface equivalent to java.util.zip.Checksum
    public interface IChecksum
    {
        void Update(int b);
        void Update(byte[] b, int off, int len);
        long GetValue();
        void Reset();
    }

    // Simple implementation of Adler32 (common Java checksum)
    public class Adler32 : IChecksum
    {
        private const int MOD_ADLER = 65521;
        private uint a = 1;
        private uint b = 0;

        public void Update(int b)
        {
            a = (a + (byte)b) % MOD_ADLER;
            b = (b + a) % MOD_ADLER;
        }

        public void Update(byte[] data, int offset, int count)
        {
            for (int i = offset; i < offset + count; i++)
            {
                a = (a + data[i]) % MOD_ADLER;
                b = (b + a) % MOD_ADLER;
            }
        }

        public long GetValue()
        {
            return (b << 16) | a;
        }

        public void Reset()
        {
            a = 1;
            b = 0;
        }
    }

    // Wrapper equivalent to java.util.zip.CheckedOutputStream
    public class CheckedOutputStream : Stream
    {
        private readonly Stream _output;
        private readonly IChecksum _checksum;

        public CheckedOutputStream(Stream output, IChecksum checksum)
        {
            _output = output ?? throw new ArgumentNullException(nameof(output));
            _checksum = checksum ?? throw new ArgumentNullException(nameof(checksum));
        }

        // Returns the checksum object
        public IChecksum GetChecksum()
        {
            return _checksum;
        }

        // Stream abstract members – delegate to underlying stream where possible
        public override bool CanRead => false;
        public override bool CanSeek => false;
        public override bool CanWrite => true;
        public override long Length => throw new NotSupportedException();
        public override long Position
        {
            get => throw new NotSupportedException();
            set => throw new NotSupportedException();
        }

        public override void Flush()
        {
            _output.Flush();
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            throw new NotSupportedException();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }

        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            // Write to underlying stream
            _output.Write(buffer, offset, count);
            // Update checksum with the written bytes
            _checksum.Update(buffer, offset, count);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _output.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    [TestFixture]
    public class CheckedOutputStreamAutoTest
    {
        [Test]
        public void GetChecksum_test_5135()
        {
            // Create instances – equivalent to Java test parameters
            using var output = new MemoryStream();
            IChecksum checksum = new Adler32();

            // Act
            var instance = new CheckedOutputStream(output, checksum);
            var result = instance.GetChecksum();

            // Verify the returned checksum is the same object
            Assert.That(result, Is.SameAs(checksum));
        }
    }
}
```