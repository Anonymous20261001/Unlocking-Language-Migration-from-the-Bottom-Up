```csharp
using System;
using System.Drawing; // for Graphics stub, though we'll define our own
using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes to emulate Java Swing behavior

    public class Graphics
    {
        // Minimal stub - no actual drawing capability
    }

    public class JComponent
    {
        // Base class for Swing components
    }

    public class AbstractButton : JComponent
    {
        // Represents a button component
    }

    public class MetalButtonUI
    {
        // Static factory method
        public static MetalButtonUI CreateUI(JComponent c)
        {
            // In real Swing, this returns a UI delegate.
            // For test purposes, we just return a new instance.
            return new MetalButtonUI();
        }

        public void InstallDefaults(AbstractButton b)
        {
            // Stub - does nothing
        }

        public void UninstallDefaults(AbstractButton b)
        {
            // Stub - does nothing
        }

        public void Update(Graphics g, JComponent c)
        {
            // Stub - does nothing
        }
    }

    [TestFixture]
    public class MetalButtonUIAutoTest
    {
        [Test]
        public void CreateUI_Test_9086([System.Runtime.CompilerServices.CallerMemberName] string caller = null)
        {
            // Original test signature: createUI_test_9086(JComponent p0)
            // We cannot have a JComponent parameter in a parameterless test,
            // so we create a dummy instance.
            JComponent p0 = new JComponent();
            MetalButtonUI instance = new MetalButtonUI();
            MetalButtonUI.CreateUI(p0);
        }

        [Test]
        public void InstallDefaults_Test_9087()
        {
            AbstractButton p0 = new AbstractButton();
            MetalButtonUI instance = new MetalButtonUI();
            instance.InstallDefaults(p0);
        }

        [Test]
        public void UninstallDefaults_Test_9088()
        {
            AbstractButton p0 = new AbstractButton();
            MetalButtonUI instance = new MetalButtonUI();
            instance.UninstallDefaults(p0);
        }

        [Test]
        public void Update_Test_9089()
        {
            Graphics p0 = new Graphics();
            JComponent p1 = new JComponent();
            MetalButtonUI instance = new MetalButtonUI();
            instance.Update(p0, p1);
        }
    }
}
```