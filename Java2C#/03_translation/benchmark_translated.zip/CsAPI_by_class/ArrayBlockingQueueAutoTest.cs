```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;

namespace generated.test
{
    // Custom ArrayBlockingQueue implementation matching Java's java.util.concurrent.ArrayBlockingQueue
    public class ArrayBlockingQueue : IEnumerable<object>
    {
        private readonly int capacity;
        private readonly Queue<object> queue = new Queue<object>();

        public ArrayBlockingQueue(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentException("Capacity must be positive");
            this.capacity = capacity;
        }

        public int RemainingCapacity() => capacity - queue.Count;

        public int Size() => queue.Count;

        public void Clear() => queue.Clear();

        public bool Add(object item)
        {
            if (queue.Count >= capacity)
                throw new InvalidOperationException("Queue full");
            queue.Enqueue(item);
            return true;
        }

        public bool Offer(object item)
        {
            if (queue.Count >= capacity)
                return false;
            queue.Enqueue(item);
            return true;
        }

        public object Poll()
        {
            if (queue.Count == 0)
                return null;
            return queue.Dequeue();
        }

        public object Peek()
        {
            if (queue.Count == 0)
                return null;
            return queue.Peek();
        }

        public bool Remove(object item) => RemoveFirst(item);

        private bool RemoveFirst(object item)
        {
            // Queue doesn't support removal, rebuild
            bool removed = false;
            var newQueue = new Queue<object>();
            foreach (var obj in queue)
            {
                if (!removed && Equals(obj, item))
                {
                    removed = true;
                    continue;
                }
                newQueue.Enqueue(obj);
            }
            if (removed)
            {
                while (queue.Count > 0)
                    queue.Dequeue(); // clear old
                foreach (var obj in newQueue)
                    queue.Enqueue(obj);
            }
            return removed;
        }

        public bool Contains(object item) => queue.Contains(item);

        public object[] ToArray()
        {
            return queue.ToArray();
        }

        public object[] ToArray(object[] array)
        {
            int count = queue.Count;
            if (array.Length < count)
                array = new object[count];
            queue.CopyTo(array, 0);
            // If array larger, set next element to null as per Java spec (optional)
            return array;
        }

        public int DrainTo(ICollection collection)
        {
            int count = 0;
            while (queue.Count > 0)
            {
                collection.Add(queue.Dequeue());
                count++;
            }
            return count;
        }

        public int DrainTo(ICollection collection, int maxElements)
        {
            int count = 0;
            while (queue.Count > 0 && count < maxElements)
            {
                collection.Add(queue.Dequeue());
                count++;
            }
            return count;
        }

        public IEnumerator<object> GetEnumerator() => queue.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        // Java style Iterator (since test calls iterator(), not GetEnumerator)
        public Iterator Iterator() => new ArrayIterator(this);

        public Spliterator Spliterator() => new ArraySpliterator(this);

        public void ForEach(Consumer consumer)
        {
            foreach (var item in queue)
                consumer.Accept(item);
        }

        public bool RemoveIf(Predicate predicate)
        {
            bool removed = false;
            var newQueue = new Queue<object>();
            foreach (var obj in queue)
            {
                if (predicate.Test(obj))
                {
                    removed = true;
                    continue;
                }
                newQueue.Enqueue(obj);
            }
            if (removed)
            {
                while (queue.Count > 0)
                    queue.Dequeue();
                foreach (var obj in newQueue)
                    queue.Enqueue(obj);
            }
            return removed;
        }

        public bool RemoveAll(ICollection collection)
        {
            bool changed = false;
            var newQueue = new Queue<object>();
            foreach (var obj in queue)
            {
                if (collection.Contains(obj))
                {
                    changed = true;
                    continue;
                }
                newQueue.Enqueue(obj);
            }
            if (changed)
            {
                while (queue.Count > 0)
                    queue.Dequeue();
                foreach (var obj in newQueue)
                    queue.Enqueue(obj);
            }
            return changed;
        }

        public bool RetainAll(ICollection collection)
        {
            bool changed = false;
            var newQueue = new Queue<object>();
            foreach (var obj in queue)
            {
                if (!collection.Contains(obj))
                {
                    changed = true;
                    continue;
                }
                newQueue.Enqueue(obj);
            }
            if (changed)
            {
                while (queue.Count > 0)
                    queue.Dequeue();
                foreach (var obj in newQueue)
                    queue.Enqueue(obj);
            }
            return changed;
        }

        public override string ToString() => "[" + string.Join(", ", queue) + "]";

        // Inner classes for Iterator and Spliterator (stubs)
        public class ArrayIterator : Iterator
        {
            private readonly ArrayBlockingQueue parent;
            private readonly object[] snapshot;
            private int index = 0;

            internal ArrayIterator(ArrayBlockingQueue parent)
            {
                this.parent = parent;
                snapshot = parent.queue.ToArray();
            }

            public bool HasNext() => index < snapshot.Length;
            public object Next() => snapshot[index++];
        }

        public class ArraySpliterator : Spliterator
        {
            private readonly ArrayBlockingQueue parent;
            private readonly object[] snapshot;
            private int index = 0;

            internal ArraySpliterator(ArrayBlockingQueue parent)
            {
                this.parent = parent;
                snapshot = parent.queue.ToArray();
            }

            // Minimal implementation to satisfy interface
            public void ForEachRemaining(Consumer action)
            {
                while (index < snapshot.Length)
                    action.Accept(snapshot[index++]);
            }
        }
    }

    // Interfaces matching Java's functional interfaces
    public interface Consumer
    {
        void Accept(object t);
    }

    public interface Predicate
    {
        bool Test(object t);
    }

    public interface Iterator
    {
        bool HasNext();
        object Next();
    }

    public interface Spliterator
    {
        void ForEachRemaining(Consumer action);
    }

    // Test class (NUnit)
    [TestFixture]
    public class ArrayBlockingQueueAutoTest
    {
        [Test]
        public void DrainTo_test_4082(ICollection p0, int p1, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.DrainTo(p0, p1);
        }

        [Test]
        public void DrainTo_test_4083(ICollection p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.DrainTo(p0);
        }

        [Test]
        public void RemainingCapacity_test_4084(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.RemainingCapacity();
        }

        [Test]
        public void Remove_test_4085(object p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Remove(p0);
        }

        [Test]
        public void Size_test_4086(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Size();
        }

        [Test]
        public void ToString_test_4087(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.ToString();
        }

        [Test]
        public void Clear_test_4088(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Clear();
        }

        [Test]
        public void Add_test_4089(object p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Add(p0);
        }

        [Test]
        public void ToArray_test_4090(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.ToArray();
        }

        [Test]
        public void ToArray_test_4091(object[] p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.ToArray(p0);
        }

        [Test]
        public void Iterator_test_4092(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Iterator();
        }

        [Test]
        public void Contains_test_4093(object p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Contains(p0);
        }

        [Test]
        public void Spliterator_test_4094(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Spliterator();
        }

        [Test]
        public void ForEach_test_4095(Consumer p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.ForEach(p0);
        }

        [Test]
        public void Peek_test_4096(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Peek();
        }

        [Test]
        public void RemoveIf_test_4097(Predicate p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.RemoveIf(p0);
        }

        [Test]
        public void RemoveAll_test_4098(ICollection p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.RemoveAll(p0);
        }

        [Test]
        public void RetainAll_test_4099(ICollection p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.RetainAll(p0);
        }

        [Test]
        public void Poll_test_4100(int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Poll();
        }

        [Test]
        public void Offer_test_4101(object p0, int c0)
        {
            ArrayBlockingQueue instance = new ArrayBlockingQueue(c0);
            instance.Offer(p0);
        }
    }
}
```