```csharp
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.crypto.spec.DHGenParameterSpec.
    /// </summary>
    public class DHGenParameterSpec
    {
        private readonly int primeSize;
        private readonly int exponentSize;

        public DHGenParameterSpec(int primeSize, int exponentSize)
        {
            this.primeSize = primeSize;
            this.exponentSize = exponentSize;
        }

        public int GetPrimeSize()
        {
            return primeSize;
        }

        public int GetExponentSize()
        {
            return exponentSize;
        }
    }

    [TestFixture]
    public class DHGenParameterSpecAutoTest
    {
        [Test]
        public void GetPrimeSize_test_5236(int c0, int c1)
        {
            var instance = new DHGenParameterSpec(c0, c1);
            instance.GetPrimeSize();
        }

        [Test]
        public void GetExponentSize_test_5237(int c0, int c1)
        {
            var instance = new DHGenParameterSpec(c0, c1);
            instance.GetExponentSize();
        }
    }
}
```