```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// Java equivalent classes (stubs)
namespace JavaEquivalents
{
    public class Graphics { }

    public class JComponent { }

    public class JTabbedPane : JComponent { }

    public class Rectangle { }

    public class Dimension { }

    public class UI { }

    public class MultiTabbedPaneUI
    {
        public int GetTabRunCount(JTabbedPane p0) => 0;

        public Rectangle GetTabBounds(JTabbedPane p0, int p1) => new Rectangle();

        public int TabForCoordinate(JTabbedPane p0, int p1, int p2) => -1;

        public void InstallUI(JComponent p0) { }

        public void UninstallUI(JComponent p0) { }

        public UI[] GetUIs() => Array.Empty<UI>();

        public static UI? CreateUI(JComponent p0) => null;

        public Dimension GetMaximumSize(JComponent p0) => new Dimension();

        public void Paint(Graphics p0, JComponent p1) { }

        public int GetAccessibleChildrenCount(JComponent p0) => 0;

        public object? GetAccessibleChild(JComponent p0, int p1) => null;

        public Dimension GetPreferredSize(JComponent p0) => new Dimension();

        public Dimension GetMinimumSize(JComponent p0) => new Dimension();

        public void Update(Graphics p0, JComponent p1) { }

        public bool Contains(JComponent p0, int p1, int p2) => false;
    }
}

// Test class (using NUnit)
namespace Generated.Test
{
    using JavaEquivalents;

    [TestFixture]
    public class MultiTabbedPaneUIAutoTest
    {
        [Test]
        public void GetTabRunCount_test_9591()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JTabbedPane();
            instance.GetTabRunCount(p0);
        }

        [Test]
        public void GetTabBounds_test_9592()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JTabbedPane();
            instance.GetTabBounds(p0, 0);
        }

        [Test]
        public void TabForCoordinate_test_9593()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JTabbedPane();
            instance.TabForCoordinate(p0, 0, 0);
        }

        [Test]
        public void InstallUI_test_9594()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.InstallUI(p0);
        }

        [Test]
        public void UninstallUI_test_9595()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.UninstallUI(p0);
        }

        [Test]
        public void GetUIs_test_9596()
        {
            var instance = new MultiTabbedPaneUI();
            instance.GetUIs();
        }

        [Test]
        public void CreateUI_test_9597()
        {
            var p0 = new JComponent();
            MultiTabbedPaneUI.CreateUI(p0);
        }

        [Test]
        public void GetMaximumSize_test_9598()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.GetMaximumSize(p0);
        }

        [Test]
        public void Paint_test_9599()
        {
            var instance = new MultiTabbedPaneUI();
            var g = new Graphics();
            var p1 = new JComponent();
            instance.Paint(g, p1);
        }

        [Test]
        public void GetAccessibleChildrenCount_test_9600()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.GetAccessibleChildrenCount(p0);
        }

        [Test]
        public void GetAccessibleChild_test_9601()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.GetAccessibleChild(p0, 0);
        }

        [Test]
        public void GetPreferredSize_test_9602()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.GetPreferredSize(p0);
        }

        [Test]
        public void GetMinimumSize_test_9603()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.GetMinimumSize(p0);
        }

        [Test]
        public void Update_test_9604()
        {
            var instance = new MultiTabbedPaneUI();
            var g = new Graphics();
            var p1 = new JComponent();
            instance.Update(g, p1);
        }

        [Test]
        public void Contains_test_9605()
        {
            var instance = new MultiTabbedPaneUI();
            var p0 = new JComponent();
            instance.Contains(p0, 0, 0);
        }
    }
}
```