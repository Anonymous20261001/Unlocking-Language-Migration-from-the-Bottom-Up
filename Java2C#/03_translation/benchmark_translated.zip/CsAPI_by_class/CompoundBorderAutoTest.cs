```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace GeneratedTest
{
    // Minimal equivalents of Java AWT/Swing classes
    public class Component { }
    public class Graphics { }
    public class Insets
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int Bottom { get; set; }
        public int Right { get; set; }

        public Insets() { }
        public Insets(int top, int left, int bottom, int right)
        {
            Top = top;
            Left = left;
            Bottom = bottom;
            Right = right;
        }
    }

    // Abstract base class for borders
    public abstract class Border
    {
        public abstract void PaintBorder(Component c, Graphics g, int x, int y, int width, int height);
        public abstract Insets GetBorderInsets(Component c, Insets insets);
        public abstract bool IsBorderOpaque();
    }

    // CompoundBorder – mimics Java's javax.swing.border.CompoundBorder
    public class CompoundBorder : Border
    {
        private Border _outsideBorder;
        private Border _insideBorder;

        // Default constructor
        public CompoundBorder() : this(null, null) { }

        // Constructor with outside and inside borders
        public CompoundBorder(Border outsideBorder, Border insideBorder)
        {
            _outsideBorder = outsideBorder;
            _insideBorder = insideBorder;
        }

        public Border GetOutsideBorder() => _outsideBorder;
        public Border GetInsideBorder() => _insideBorder;

        public override void PaintBorder(Component c, Graphics g, int x, int y, int width, int height)
        {
            // Mimics Java behavior: if no borders, does nothing
            // If both present, paints outside border, then inside border with adjusted coordinates
            if (_outsideBorder != null)
            {
                _outsideBorder.PaintBorder(c, g, x, y, width, height);
                if (_insideBorder != null)
                {
                    Insets outsideInsets = _outsideBorder.GetBorderInsets(c, new Insets());
                    int ix = x + outsideInsets.Left;
                    int iy = y + outsideInsets.Top;
                    int iw = width - outsideInsets.Left - outsideInsets.Right;
                    int ih = height - outsideInsets.Top - outsideInsets.Bottom;
                    _insideBorder.PaintBorder(c, g, ix, iy, iw, ih);
                }
            }
            else if (_insideBorder != null)
            {
                _insideBorder.PaintBorder(c, g, x, y, width, height);
            }
        }

        public override Insets GetBorderInsets(Component c, Insets insets)
        {
            // Returns combined insets
            Insets outsideInsets = _outsideBorder?.GetBorderInsets(c, new Insets()) ?? new Insets();
            Insets insideInsets = _insideBorder?.GetBorderInsets(c, new Insets()) ?? new Insets();
            insets.Top = outsideInsets.Top + insideInsets.Top;
            insets.Left = outsideInsets.Left + insideInsets.Left;
            insets.Bottom = outsideInsets.Bottom + insideInsets.Bottom;
            insets.Right = outsideInsets.Right + insideInsets.Right;
            return insets;
        }

        public override bool IsBorderOpaque()
        {
            // Opaque if both borders are opaque (or if one is, the other null => false)
            bool outsideOpaque = _outsideBorder?.IsBorderOpaque() ?? false;
            bool insideOpaque = _insideBorder?.IsBorderOpaque() ?? false;
            return outsideOpaque && insideOpaque;
        }
    }

    [TestFixture]
    public class CompoundBorderAutoTest
    {
        [Test]
        public void PaintBorder_test_8459(Component p0, Graphics p1, int p2, int p3, int p4, int p5)
        {
            CompoundBorder instance = new CompoundBorder();
            instance.PaintBorder(p0, p1, p2, p3, p4, p5);
        }

        [Test]
        public void GetBorderInsets_test_8460(Component p0, Insets p1)
        {
            CompoundBorder instance = new CompoundBorder();
            instance.GetBorderInsets(p0, p1);
        }

        [Test]
        public void IsBorderOpaque_test_8461()
        {
            CompoundBorder instance = new CompoundBorder();
            instance.IsBorderOpaque();
        }

        [Test]
        public void GetOutsideBorder_test_8462()
        {
            CompoundBorder instance = new CompoundBorder();
            instance.GetOutsideBorder();
        }

        [Test]
        public void GetInsideBorder_test_8463()
        {
            CompoundBorder instance = new CompoundBorder();
            instance.GetInsideBorder();
        }
    }
}
```