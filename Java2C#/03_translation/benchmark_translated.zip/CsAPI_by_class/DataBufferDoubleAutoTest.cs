```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    public class DataBufferDouble
    {
        private double[][] bankData;
        private int size;

        public DataBufferDouble(int size)
        {
            this.size = size;
            bankData = new double[1][];
            bankData[0] = new double[size];
        }

        public double[][] GetBankData()
        {
            return bankData;
        }

        public double GetElem(int bank, int i)
        {
            return bankData[bank][i];
        }

        public double GetElem(int i)
        {
            return GetElem(0, i);
        }

        public float GetElemFloat(int bank, int i)
        {
            return (float)GetElem(bank, i);
        }

        public float GetElemFloat(int i)
        {
            return GetElemFloat(0, i);
        }

        public double GetElemDouble(int bank, int i)
        {
            return GetElem(bank, i);
        }

        public double GetElemDouble(int i)
        {
            return GetElem(i);
        }

        public void SetElem(int bank, int i, int val)
        {
            bankData[bank][i] = (double)val;
        }

        public void SetElem(int i, int val)
        {
            SetElem(0, i, val);
        }

        public void SetElemFloat(int bank, int i, float val)
        {
            bankData[bank][i] = (double)val;
        }

        public void SetElemFloat(int i, float val)
        {
            SetElemFloat(0, i, val);
        }

        public void SetElemDouble(int bank, int i, double val)
        {
            bankData[bank][i] = val;
        }

        public void SetElemDouble(int i, double val)
        {
            SetElemDouble(0, i, val);
        }

        public double[] GetData(int bank)
        {
            return bankData[bank];
        }

        public double[] GetData()
        {
            return GetData(0);
        }
    }

    [TestFixture]
    public class DataBufferDoubleAutoTest
    {
        [Test]
        public void GetBankData_Test_1190()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetBankData();
        }

        [Test]
        public void GetElem_Test_1191()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElem(0, 0);
        }

        [Test]
        public void GetElem_Test_1192()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElem(0);
        }

        [Test]
        public void GetElemFloat_Test_1193()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElemFloat(0);
        }

        [Test]
        public void GetElemFloat_Test_1194()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElemFloat(0, 0);
        }

        [Test]
        public void GetElemDouble_Test_1195()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElemDouble(0);
        }

        [Test]
        public void GetElemDouble_Test_1196()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetElemDouble(0, 0);
        }

        [Test]
        public void SetElem_Test_1197()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElem(0, 0, 1);
        }

        [Test]
        public void SetElem_Test_1198()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElem(0, 1);
        }

        [Test]
        public void SetElemFloat_Test_1199()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElemFloat(0, 0, 1.0f);
        }

        [Test]
        public void SetElemFloat_Test_1200()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElemFloat(0, 1.0f);
        }

        [Test]
        public void SetElemDouble_Test_1201()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElemDouble(0, 1.0);
        }

        [Test]
        public void SetElemDouble_Test_1202()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.SetElemDouble(0, 0, 1.0);
        }

        [Test]
        public void GetData_Test_1203()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetData(0);
        }

        [Test]
        public void GetData_Test_1204()
        {
            DataBufferDouble instance = new DataBufferDouble(10);
            instance.GetData();
        }
    }
}
```