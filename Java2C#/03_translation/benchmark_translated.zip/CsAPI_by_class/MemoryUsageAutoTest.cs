```csharp
using System;

namespace GeneratedTest
{
    // Minimal implementation of CompositeData for MemoryUsage.From().
    // In a real scenario, this would be the javax.management.openmbean.CompositeData equivalent.
    public class CompositeData
    {
        private readonly long init;
        private readonly long used;
        private readonly long committed;
        private readonly long max;

        public CompositeData(long init, long used, long committed, long max)
        {
            this.init = init;
            this.used = used;
            this.committed = committed;
            this.max = max;
        }

        // Simulates the retrieval of a long value by key as in Java CompositeData.
        public long GetLong(string key)
        {
            return key switch
            {
                "init" => init,
                "used" => used,
                "committed" => committed,
                "max" => max,
                _ => throw new ArgumentException($"Unknown key: {key}")
            };
        }
    }

    // C# equivalent of java.lang.management.MemoryUsage
    public class MemoryUsage
    {
        private readonly long init;
        private readonly long used;
        private readonly long committed;
        private readonly long max;

        public MemoryUsage(long init, long used, long committed, long max)
        {
            // Java's MemoryUsage constructor validates: init >= -1, used >= 0, committed >= 0, and other constraints.
            // For simplicity, we accept any values, but we can add the same checks if needed.
            if (init < -1)
                throw new ArgumentException("init must be >= -1");
            if (used < 0)
                throw new ArgumentException("used must be >= 0");
            if (committed < 0)
                throw new ArgumentException("committed must be >= 0");
            if (max < -1)
                throw new ArgumentException("max must be >= -1");
            // Additional constraint: committed >= used (Java does not enforce this strictly but it's typical)
            // We'll skip for simplicity.

            this.init = init;
            this.used = used;
            this.committed = committed;
            this.max = max;
        }

        public long GetInit() => init;
        public long GetUsed() => used;
        public long GetCommitted() => committed;
        public long GetMax() => max;

        // Equivalent of java.lang.management.MemoryUsage.toString()
        public override string ToString()
        {
            return $"init = {init} used = {used} committed = {committed} max = {max}";
        }

        // Static method from(CompositeData) – creates a MemoryUsage from the composite data.
        public static MemoryUsage From(CompositeData cd)
        {
            if (cd == null)
                throw new ArgumentNullException(nameof(cd));
            long init = cd.GetLong("init");
            long used = cd.GetLong("used");
            long committed = cd.GetLong("committed");
            long max = cd.GetLong("max");
            return new MemoryUsage(init, used, committed, max);
        }
    }

    // NUnit test class – each test method matches the Java @Test exactly in name and signature.
    // Since parameters are present, these are parameterized tests. In NUnit you would typically
    // provide test cases via [TestCase] or [TestCaseSource]. Here we keep the original signature.
    [TestFixture]
    public class MemoryUsageAutoTest
    {
        [Test]
        public void getInit_test_2411(long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            instance.GetInit();
        }

        [Test]
        public void getUsed_test_2412(long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            instance.GetUsed();
        }

        [Test]
        public void getCommitted_test_2413(long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            instance.GetCommitted();
        }

        [Test]
        public void toString_test_2414(long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            instance.ToString();
        }

        [Test]
        public void from_test_2415(CompositeData p0, long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            MemoryUsage.From(p0);
        }

        [Test]
        public void getMax_test_2416(long c0, long c1, long c2, long c3)
        {
            var instance = new MemoryUsage(c0, c1, c2, c3);
            instance.GetMax();
        }
    }
}
```