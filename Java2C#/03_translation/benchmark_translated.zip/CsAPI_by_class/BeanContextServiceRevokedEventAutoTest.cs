Below is the complete C# translation of the provided Java test file and its required supporting classes. The test methods retain the exact names and signatures, using C# types (`Type` for `Class`, `bool` for `boolean`, `BeanContextServices` interface). A minimal stub for `BeanContextServices` is provided to satisfy the compilation. All methods are implemented identically to the Java originals.

```csharp
using System;
using NUnit.Framework;

// Stub for the Java BeanContextServices interface
public interface BeanContextServices
{
    // Add necessary members if needed; for test compilation it can be empty
}

// C# equivalent of java.beans.beancontext.BeanContextServiceRevokedEvent
public class BeanContextServiceRevokedEvent : EventArgs
{
    private readonly BeanContextServices _source;
    private readonly Type _serviceClass;
    private readonly bool _invalidate;

    public BeanContextServiceRevokedEvent(BeanContextServices bcs, Type serviceClass, bool invalidate)
    {
        _source = bcs;
        _serviceClass = serviceClass;
        _invalidate = invalidate;
    }

    public BeanContextServices GetSourceAsBeanContextServices()
    {
        return _source;
    }

    public Type GetServiceClass()
    {
        return _serviceClass;
    }

    public bool IsServiceClass(Type p0)
    {
        return p0 == _serviceClass; // Equivalent to Java's == check on Class objects
    }

    public bool IsCurrentServiceInvalidNow()
    {
        return _invalidate;
    }
}

// Test class corresponding to BeanContextServiceRevokedEventAutoTest
[TestFixture]
public class BeanContextServiceRevokedEventAutoTest
{
    [Test]
    public void GetSourceAsBeanContextServices_test_1649(BeanContextServices c0, Type c1, bool c2)
    {
        var instance = new BeanContextServiceRevokedEvent(c0, c1, c2);
        instance.GetSourceAsBeanContextServices();
    }

    [Test]
    public void GetServiceClass_test_1650(BeanContextServices c0, Type c1, bool c2)
    {
        var instance = new BeanContextServiceRevokedEvent(c0, c1, c2);
        instance.GetServiceClass();
    }

    [Test]
    public void IsServiceClass_test_1651(Type p0, BeanContextServices c0, Type c1, bool c2)
    {
        var instance = new BeanContextServiceRevokedEvent(c0, c1, c2);
        instance.IsServiceClass(p0);
    }

    [Test]
    public void IsCurrentServiceInvalidNow_test_1652(BeanContextServices c0, Type c1, bool c2)
    {
        var instance = new BeanContextServiceRevokedEvent(c0, c1, c2);
        instance.IsCurrentServiceInvalidNow();
    }
}
```