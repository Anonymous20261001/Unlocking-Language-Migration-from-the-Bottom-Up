```csharp
using NUnit.Framework;

namespace Generated.Test
{
    [TestFixture]
    public class InputMethodHighlightAutoTest
    {
        [Test]
        public void getVariation_test_1005()
        {
            InputMethodHighlight instance = new InputMethodHighlight(true, 0);
            instance.getVariation();
        }

        [Test]
        public void getStyle_test_1006()
        {
            InputMethodHighlight instance = new InputMethodHighlight(true, 0);
            instance.getStyle();
        }

        [Test]
        public void isSelected_test_1007()
        {
            InputMethodHighlight instance = new InputMethodHighlight(true, 0);
            instance.isSelected();
        }

        [Test]
        public void getState_test_1008()
        {
            InputMethodHighlight instance = new InputMethodHighlight(true, 0);
            instance.getState();
        }
    }

    public class InputMethodHighlight
    {
        public const int SELECTED = 0;
        public const int UNSELECTED = 1;

        private bool selected;
        private int style;
        private int variation;

        public InputMethodHighlight(bool selected, int style)
        {
            this.selected = selected;
            this.style = style;
            this.variation = 0;
        }

        public int getVariation()
        {
            return variation;
        }

        public int getStyle()
        {
            return style;
        }

        public bool isSelected()
        {
            return selected;
        }

        public int getState()
        {
            return selected ? SELECTED : UNSELECTED;
        }
    }
}
```