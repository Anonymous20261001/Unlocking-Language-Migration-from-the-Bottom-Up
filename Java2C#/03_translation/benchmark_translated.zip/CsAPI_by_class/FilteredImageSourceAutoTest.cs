```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

// Java AWT equivalents for testing purposes
public class ImageConsumer { }  // No-op base class for testing

public class ImageFilter { }   // No-op base class for testing

public class ImageProducer { } // No-op base class for testing

public class FilteredImageSource
{
    private readonly ImageProducer _producer;
    private readonly ImageFilter _filter;
    private readonly List<ImageConsumer> _consumers = new List<ImageConsumer>();

    public FilteredImageSource(ImageProducer producer, ImageFilter filter)
    {
        _producer = producer;
        _filter = filter;
    }

    public void AddConsumer(ImageConsumer consumer)
    {
        _consumers.Add(consumer);
    }

    public void RemoveConsumer(ImageConsumer consumer)
    {
        _consumers.Remove(consumer);
    }

    public void StartProduction(ImageConsumer consumer)
    {
        AddConsumer(consumer);
    }

    public bool IsConsumer(ImageConsumer consumer)
    {
        return _consumers.Contains(consumer);
    }

    public void RequestTopDownLeftRightResend(ImageConsumer consumer)
    {
        // No-op implementation
    }
}

// Test class
[TestFixture]
public class FilteredImageSourceAutoTest
{
    [Test]
    public void AddConsumer_test_1264(ImageConsumer p0, ImageProducer c0, ImageFilter c1)
    {
        FilteredImageSource instance = new FilteredImageSource(c0, c1);
        instance.AddConsumer(p0);
    }

    [Test]
    public void RemoveConsumer_test_1265(ImageConsumer p0, ImageProducer c0, ImageFilter c1)
    {
        FilteredImageSource instance = new FilteredImageSource(c0, c1);
        instance.RemoveConsumer(p0);
    }

    [Test]
    public void StartProduction_test_1266(ImageConsumer p0, ImageProducer c0, ImageFilter c1)
    {
        FilteredImageSource instance = new FilteredImageSource(c0, c1);
        instance.StartProduction(p0);
    }

    [Test]
    public void IsConsumer_test_1267(ImageConsumer p0, ImageProducer c0, ImageFilter c1)
    {
        FilteredImageSource instance = new FilteredImageSource(c0, c1);
        instance.IsConsumer(p0);
    }

    [Test]
    public void RequestTopDownLeftRightResend_test_1268(ImageConsumer p0, ImageProducer c0, ImageFilter c1)
    {
        FilteredImageSource instance = new FilteredImageSource(c0, c1);
        instance.RequestTopDownLeftRightResend(p0);
    }
}
```