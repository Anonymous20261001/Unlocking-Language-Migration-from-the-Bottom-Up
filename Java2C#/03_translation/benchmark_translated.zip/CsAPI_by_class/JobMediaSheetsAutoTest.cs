```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.print.attribute.standard.JobMediaSheets
    public class JobMediaSheets
    {
        private readonly int value;

        public JobMediaSheets(int value)
        {
            this.value = value;
        }

        public Type GetCategory()
        {
            return typeof(JobMediaSheets);
        }

        public string GetName()
        {
            return "job-media-sheets";
        }

        public override bool Equals(object obj)
        {
            if (obj is JobMediaSheets other)
            {
                return this.value == other.value;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return value.GetHashCode();
        }
    }

    [TestFixture]
    public class JobMediaSheetsAutoTest
    {
        [Test]
        public void GetCategory_Test_6142()
        {
            var instance = new JobMediaSheets(42);
            var category = instance.GetCategory();
            Assert.AreEqual(typeof(JobMediaSheets), category);
        }

        [Test]
        public void GetName_Test_6143()
        {
            var instance = new JobMediaSheets(42);
            var name = instance.GetName();
            Assert.AreEqual("job-media-sheets", name);
        }

        [Test]
        public void Equals_Test_6144()
        {
            // Test with same value
            var instance = new JobMediaSheets(100);
            var otherSame = new JobMediaSheets(100);
            Assert.IsTrue(instance.Equals(otherSame));

            // Test with different value
            var otherDiff = new JobMediaSheets(200);
            Assert.IsFalse(instance.Equals(otherDiff));

            // Test with null
            Assert.IsFalse(instance.Equals(null));

            // Test with a different type of object
            Assert.IsFalse(instance.Equals("some string"));
        }
    }
}
```