```csharp
using System;
using NUnit.Framework;

// Custom implementation of Java's HttpRetryException
public class HttpRetryException : Exception
{
    private readonly int _responseCode;
    private readonly string? _location;

    public HttpRetryException(string detail, int responseCode) : base(detail)
    {
        _responseCode = responseCode;
        _location = null;
    }

    public HttpRetryException(string detail, int responseCode, string location) : base(detail)
    {
        _responseCode = responseCode;
        _location = location;
    }

    public int responseCode()
    {
        return _responseCode;
    }

    public string? getLocation()
    {
        return _location;
    }

    public string getReason()
    {
        return Message; // The detail message passed to the constructor
    }
}

[TestFixture]
public class HttpRetryExceptionAutoTest
{
    [Test]
    public void responseCode_test_2587()
    {
        HttpRetryException instance = new HttpRetryException("", 0);
        instance.responseCode();
    }

    [Test]
    public void getLocation_test_2588()
    {
        HttpRetryException instance = new HttpRetryException("", 0);
        instance.getLocation();
    }

    [Test]
    public void getReason_test_2589()
    {
        HttpRetryException instance = new HttpRetryException("", 0);
        instance.getReason();
    }
}
```