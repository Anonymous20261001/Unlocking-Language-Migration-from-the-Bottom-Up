```csharp
using System;
using System.Threading;
using Xunit;

namespace Generated.Test
{
    public class CountDownLatch
    {
        private int count;

        public CountDownLatch(int count)
        {
            if (count < 0)
                throw new ArgumentException("count must be non-negative", nameof(count));
            this.count = count;
        }

        public int GetCount()
        {
            return count;
        }

        public void CountDown()
        {
            if (count > 0)
                Interlocked.Decrement(ref count);
        }

        public override string ToString()
        {
            return base.ToString(); // Mimics Java's default Object.toString()
        }
    }

    public class CountDownLatchAutoTest
    {
        [Fact]
        public void ToString_Test_4441()
        {
            CountDownLatch instance = new CountDownLatch(0);
            instance.ToString();
        }

        [Fact]
        public void GetCount_Test_4442()
        {
            CountDownLatch instance = new CountDownLatch(0);
            instance.GetCount();
        }

        [Fact]
        public void CountDown_Test_4443()
        {
            CountDownLatch instance = new CountDownLatch(0);
            instance.CountDown();
        }
    }
}
```