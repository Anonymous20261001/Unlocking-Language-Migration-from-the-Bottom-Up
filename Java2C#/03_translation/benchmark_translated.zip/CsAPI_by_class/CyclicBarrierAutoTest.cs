```csharp
using System;
using System.Threading;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of java.util.concurrent.CyclicBarrier
    public class CyclicBarrier
    {
        private readonly int _parties;
        private int _waiting;
        private bool _broken;
        private readonly object _lock = new object();

        public CyclicBarrier(int parties)
        {
            if (parties <= 0)
                throw new ArgumentException("parties must be positive", nameof(parties));
            _parties = parties;
            _waiting = 0;
            _broken = false;
        }

        public int GetParties()
        {
            return _parties;
        }

        public bool IsBroken()
        {
            lock (_lock)
            {
                return _broken;
            }
        }

        public int GetNumberWaiting()
        {
            lock (_lock)
            {
                return _waiting;
            }
        }

        public void Reset()
        {
            lock (_lock)
            {
                // Mark as broken to wake up any waiting threads
                _broken = true;
                Monitor.PulseAll(_lock);
                // Reset state
                _waiting = 0;
                _broken = false;
            }
        }

        // Optional: await() method (not used in tests but added for completeness)
        public int Await()
        {
            lock (_lock)
            {
                if (_broken)
                    throw new BrokenBarrierException();

                _waiting++;
                if (_waiting == _parties)
                {
                    // All parties arrived, reset for next use
                    _waiting = 0;
                    _broken = false;
                    Monitor.PulseAll(_lock);
                    return 0; // return value (not used in Java but we mimic)
                }

                while (_waiting < _parties && !_broken)
                {
                    Monitor.Wait(_lock);
                }

                if (_broken)
                    throw new BrokenBarrierException();

                return _waiting; // not correct, but placeholder
            }
        }
    }

    // Simple exception to mimic Java's BrokenBarrierException
    public class BrokenBarrierException : Exception
    {
        public BrokenBarrierException() : base("Barrier is broken") { }
    }

    // Test class mirroring the Java tests
    public class CyclicBarrierAutoTest
    {
        [Test]
        public void getParties_test_4444()
        {
            int c0 = 5; // arbitrary positive number
            CyclicBarrier instance = new CyclicBarrier(c0);
            instance.GetParties();
        }

        [Test]
        public void isBroken_test_4445()
        {
            int c0 = 5;
            CyclicBarrier instance = new CyclicBarrier(c0);
            instance.IsBroken();
        }

        [Test]
        public void getNumberWaiting_test_4446()
        {
            int c0 = 5;
            CyclicBarrier instance = new CyclicBarrier(c0);
            instance.GetNumberWaiting();
        }

        [Test]
        public void reset_test_4447()
        {
            int c0 = 5;
            CyclicBarrier instance = new CyclicBarrier(c0);
            instance.Reset();
        }
    }
}
```