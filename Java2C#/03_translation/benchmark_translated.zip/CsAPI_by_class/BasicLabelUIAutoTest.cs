```csharp
using System;
using System.Drawing;
using NUnit.Framework;

namespace GeneratedTest
{
    // ---------- Supporting types ----------
    public class PropertyChangeEvent
    {
        public object Source { get; }
        public string PropertyName { get; }
        public object OldValue { get; }
        public object NewValue { get; }

        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            Source = source;
            PropertyName = propertyName;
            OldValue = oldValue;
            NewValue = newValue;
        }
    }

    public class Dimension
    {
        public int Width { get; set; }
        public int Height { get; set; }

        public Dimension(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    public enum BaselineResizeBehavior
    {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CONSTANT_BASELINE,
        CENTER_OFFSET,
        OTHER
    }

    // Simple JComponent mimic – no real Swing functionality, just a placeholder.
    public class JComponent
    {
        // In real Swing this would be abstract; we make it concrete for testing.
    }

    // ---------- BasicLabelUI ----------
    public class BasicLabelUI
    {
        public virtual void PropertyChange(PropertyChangeEvent e)
        {
            // No-op
        }

        public virtual void InstallUI(JComponent c)
        {
            // No-op
        }

        public virtual void UninstallUI(JComponent c)
        {
            // No-op
        }

        public static BasicLabelUI CreateUI(JComponent c)
        {
            return new BasicLabelUI();
        }

        public virtual Dimension GetMaximumSize(JComponent c)
        {
            return new Dimension(0, 0);
        }

        public virtual void Paint(Graphics g, JComponent c)
        {
            // No-op
        }

        public virtual Dimension GetPreferredSize(JComponent c)
        {
            return new Dimension(0, 0);
        }

        public virtual Dimension GetMinimumSize(JComponent c)
        {
            return new Dimension(0, 0);
        }

        public virtual int GetBaseline(JComponent c, int width, int height)
        {
            return 0;
        }

        public virtual BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c)
        {
            return BaselineResizeBehavior.CONSTANT_ASCENT;
        }
    }

    // ---------- Test class ----------
    [TestFixture]
    public class BasicLabelUITests
    {
        [Test]
        public void PropertyChange_Test_8804()
        {
            var instance = new BasicLabelUI();
            var evt = new PropertyChangeEvent(null, "testProp", null, null);
            instance.PropertyChange(evt);
        }

        [Test]
        public void InstallUI_Test_8805()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.InstallUI(component);
        }

        [Test]
        public void UninstallUI_Test_8806()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.UninstallUI(component);
        }

        [Test]
        public void CreateUI_Test_8807()
        {
            var component = new JComponent();
            BasicLabelUI.CreateUI(component);
        }

        [Test]
        public void GetMaximumSize_Test_8808()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.GetMaximumSize(component);
        }

        [Test]
        public void Paint_Test_8809()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            using (var bitmap = new Bitmap(1, 1))
            using (var graphics = Graphics.FromImage(bitmap))
            {
                instance.Paint(graphics, component);
            }
        }

        [Test]
        public void GetPreferredSize_Test_8810()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.GetPreferredSize(component);
        }

        [Test]
        public void GetMinimumSize_Test_8811()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.GetMinimumSize(component);
        }

        [Test]
        public void GetBaseline_Test_8812()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.GetBaseline(component, 100, 30);
        }

        [Test]
        public void GetBaselineResizeBehavior_Test_8813()
        {
            var instance = new BasicLabelUI();
            var component = new JComponent();
            instance.GetBaselineResizeBehavior(component);
        }
    }
}
```