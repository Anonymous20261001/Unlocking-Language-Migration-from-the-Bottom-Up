```csharp
using System;
using System.Linq;
using NUnit.Framework;

namespace SmartCardio
{
    /// <summary>
    /// C# equivalent of javax.smartcardio.CommandAPDU.
    /// Supports short APDUs (case 1-4) as defined in ISO 7816-4.
    /// Extended length APDUs are not fully implemented for brevity.
    /// </summary>
    public class CommandAPDU
    {
        private readonly byte[] _apdu;
        private readonly int _cla;
        private readonly int _ins;
        private readonly int _p1;
        private readonly int _p2;
        private readonly int _nc; // number of data bytes (Lc)
        private readonly int _ne; // expected length (Le) or 0 if not present
        private readonly byte[] _data;

        /// <summary>
        /// Constructs a CommandAPDU from a byte array.
        /// </summary>
        /// <param name="apdu">The byte array containing the APDU.</param>
        /// <exception cref="ArgumentException">Thrown if apdu is null or too short.</exception>
        public CommandAPDU(byte[] apdu)
        {
            if (apdu == null || apdu.Length < 4)
                throw new ArgumentException("APDU must be at least 4 bytes long.", nameof(apdu));

            _apdu = apdu.ToArray(); // defensive copy
            _cla = apdu[0] & 0xFF;
            _ins = apdu[1] & 0xFF;
            _p1 = apdu[2] & 0xFF;
            _p2 = apdu[3] & 0xFF;

            int length = apdu.Length;
            if (length == 4)
            {
                // Case 1: No data, no Le
                _nc = 0;
                _ne = 0;
                _data = Array.Empty<byte>();
            }
            else if (length == 5)
            {
                // Case 2S: No data, Le present (1 byte)
                _nc = 0;
                _ne = apdu[4] & 0xFF;
                _data = Array.Empty<byte>();
            }
            else
            {
                // length > 5: Lc present (5th byte)
                int lc = apdu[4] & 0xFF;
                if (lc < 0)
                    throw new ArgumentException("Invalid Lc value.");

                // Data segment: bytes 5 to 5+lc-1
                if (5 + lc > length)
                    throw new ArgumentException("Data length exceeds total APDU length.");

                _data = new byte[lc];
                Array.Copy(apdu, 5, _data, 0, lc);
                _nc = lc;

                // Check for Le after data
                int remaining = length - (5 + lc);
                if (remaining == 0)
                {
                    _ne = 0; // No Le present
                }
                else if (remaining == 1)
                {
                    _ne = apdu[5 + lc] & 0xFF;
                }
                else
                {
                    // For short APDUs, more than 1 remaining byte is invalid.
                    // Extended length would be handled here, but we ignore.
                    throw new ArgumentException("Extended length APDUs not supported in this implementation.");
                }
            }
        }

        /// <summary>
        /// Returns a copy of the raw APDU bytes.
        /// </summary>
        public byte[] GetBytes() => _apdu.ToArray();

        /// <summary>
        /// Returns the data portion of the APDU (empty array if no data).
        /// </summary>
        public byte[] GetData() => _data.ToArray();

        /// <summary>
        /// Returns the CLA byte as an int (0-255).
        /// </summary>
        public int GetCLA() => _cla;

        /// <summary>
        /// Returns the INS byte as an int (0-255).
        /// </summary>
        public int GetINS() => _ins;

        /// <summary>
        /// Returns the P1 byte as an int (0-255).
        /// </summary>
        public int GetP1() => _p1;

        /// <summary>
        /// Returns the P2 byte as an int (0-255).
        /// </summary>
        public int GetP2() => _p2;

        /// <summary>
        /// Returns the number of data bytes (Nc = Lc). 0 if no data.
        /// </summary>
        public int GetNc() => _nc;

        /// <summary>
        /// Returns the expected length (Ne = Le). 0 if no Le field present.
        /// </summary>
        public int GetNe() => _ne;

        /// <summary>
        /// Compares this CommandAPDU to another object for equality.
        /// Two CommandAPDUs are equal if their raw byte arrays are equal.
        /// </summary>
        public override bool Equals(object obj)
        {
            if (obj is CommandAPDU other)
            {
                return _apdu.SequenceEqual(other._apdu);
            }
            return false;
        }

        /// <summary>
        /// Returns a hash code for this CommandAPDU based on its raw bytes.
        /// </summary>
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                foreach (byte b in _apdu)
                    hash = hash * 31 + b;
                return hash;
            }
        }

        /// <summary>
        /// Returns a hexadecimal representation of the raw APDU bytes.
        /// </summary>
        public override string ToString()
        {
            return BitConverter.ToString(_apdu).Replace("-", " ");
        }
    }

    [TestFixture]
    public class CommandAPDUAutoTest
    {
        // Sample APDU: SELECT (case 1) – no data, no Le
        private static readonly byte[] SampleApdu1 = { 0x00, 0xA4, 0x04, 0x00 };

        // Sample APDU with data (case 3S)
        private static readonly byte[] SampleApdu2 = { 0x00, 0x20, 0x00, 0x00, 0x02, 0x01, 0x02 };

        // Sample APDU with data and Le (case 4S)
        private static readonly byte[] SampleApdu3 = { 0x00, 0xC0, 0x00, 0x00, 0x01, 0xFF, 0x10 };

        [Test]
        public void Equals_Test_6455()
        {
            // Original Java signature: equals_test_6455(Object p0, byte[] c0)
            // Parameters replaced with local variables for simplicity.
            byte[] c0 = SampleApdu1;
            object p0 = new CommandAPDU(c0); // Compare with same APDU
            CommandAPDU instance = new CommandAPDU(c0);
            bool result = instance.Equals(p0);
            Assert.IsTrue(result);
        }

        [Test]
        public void ToString_Test_6456()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            string str = instance.ToString();
            Assert.IsNotNull(str);
            Assert.IsNotEmpty(str);
        }

        [Test]
        public void HashCode_Test_6457()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            int code = instance.GetHashCode();
            Assert.AreEqual(instance.GetHashCode(), code);
        }

        [Test]
        public void GetBytes_Test_6458()
        {
            byte[] c0 = SampleApdu2;
            CommandAPDU instance = new CommandAPDU(c0);
            byte[] result = instance.GetBytes();
            CollectionAssert.AreEqual(c0, result);
        }

        [Test]
        public void GetData_Test_6459()
        {
            byte[] c0 = SampleApdu2;
            CommandAPDU instance = new CommandAPDU(c0);
            byte[] data = instance.GetData();
            byte[] expectedData = { 0x01, 0x02 };
            CollectionAssert.AreEqual(expectedData, data);
        }

        [Test]
        public void GetCLA_Test_6460()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            int cla = instance.GetCLA();
            Assert.AreEqual(0x00, cla);
        }

        [Test]
        public void GetINS_Test_6461()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            int ins = instance.GetINS();
            Assert.AreEqual(0xA4, ins);
        }

        [Test]
        public void GetP1_Test_6462()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            int p1 = instance.GetP1();
            Assert.AreEqual(0x04, p1);
        }

        [Test]
        public void GetP2_Test_6463()
        {
            byte[] c0 = SampleApdu1;
            CommandAPDU instance = new CommandAPDU(c0);
            int p2 = instance.GetP2();
            Assert.AreEqual(0x00, p2);
        }

        [Test]
        public void GetNc_Test_6464()
        {
            byte[] c0 = SampleApdu2;
            CommandAPDU instance = new CommandAPDU(c0);
            int nc = instance.GetNc();
            Assert.AreEqual(2, nc);
        }

        [Test]