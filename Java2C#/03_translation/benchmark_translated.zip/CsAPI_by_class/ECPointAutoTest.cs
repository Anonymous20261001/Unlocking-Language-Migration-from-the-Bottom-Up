```csharp
using System;
using System.Numerics;
using Xunit;

namespace Generated.Test
{
    // C# equivalent of java.security.spec.ECPoint
    public class ECPoint
    {
        private readonly BigInteger _affineX;
        private readonly BigInteger _affineY;

        public ECPoint(BigInteger affineX, BigInteger affineY)
        {
            if (affineX == null) throw new ArgumentNullException(nameof(affineX));
            if (affineY == null) throw new ArgumentNullException(nameof(affineY));
            _affineX = affineX;
            _affineY = affineY;
        }

        public BigInteger GetAffineX() => _affineX;
        public BigInteger GetAffineY() => _affineY;

        public override bool Equals(object obj)
        {
            if (obj == this) return true;
            if (!(obj is ECPoint other)) return false;
            return _affineX.Equals(other._affineX) && _affineY.Equals(other._affineY);
        }

        public override int GetHashCode()
        {
            int result = 1;
            result = 31 * result + _affineX.GetHashCode();
            result = 31 * result + _affineY.GetHashCode();
            return result;
        }
    }

    public class ECPointAutoTest
    {
        [Fact]
        public void GetAffineX_test_2873()
        {
            BigInteger c0 = BigInteger.Zero;
            BigInteger c1 = BigInteger.One;
            ECPoint instance = new ECPoint(c0, c1);
            instance.GetAffineX();
        }

        [Fact]
        public void GetAffineY_test_2874()
        {
            BigInteger c0 = BigInteger.Zero;
            BigInteger c1 = BigInteger.One;
            ECPoint instance = new ECPoint(c0, c1);
            instance.GetAffineY();
        }

        [Fact]
        public void Equals_test_2875()
        {
            object p0 = "test";
            BigInteger c0 = BigInteger.Zero;
            BigInteger c1 = BigInteger.One;
            ECPoint instance = new ECPoint(c0, c1);
            instance.Equals(p0);
        }

        [Fact]
        public void HashCode_test_2876()
        {
            BigInteger c0 = BigInteger.Zero;
            BigInteger c1 = BigInteger.One;
            ECPoint instance = new ECPoint(c0, c1);
            instance.GetHashCode();
        }
    }
}
```