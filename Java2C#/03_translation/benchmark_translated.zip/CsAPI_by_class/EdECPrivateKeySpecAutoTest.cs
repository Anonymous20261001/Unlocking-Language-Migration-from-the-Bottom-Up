```csharp
using Xunit;

namespace Generated.Test
{
    // Equivalent to java.security.spec.NamedParameterSpec
    public class NamedParameterSpec
    {
        public string Name { get; }

        public NamedParameterSpec(string name)
        {
            Name = name;
        }
    }

    // Equivalent to java.security.spec.EdECPrivateKeySpec
    public class EdECPrivateKeySpec
    {
        private readonly NamedParameterSpec _params;
        private readonly byte[] _bytes;

        public EdECPrivateKeySpec(NamedParameterSpec paramsSpec, byte[] bytes)
        {
            _params = paramsSpec;
            _bytes = bytes;
        }

        public NamedParameterSpec GetParams()
        {
            return _params;
        }

        public byte[] GetBytes()
        {
            return _bytes;
        }
    }

    public class EdECPrivateKeySpecAutoTest
    {
        [Theory]
        [InlineData("Ed25519", new byte[] { 0x01, 0x02, 0x03 })]
        public void GetParams_Test_2885(string paramName, byte[] privateKeyBytes)
        {
            var c0 = new NamedParameterSpec(paramName);
            var c1 = privateKeyBytes;
            var instance = new EdECPrivateKeySpec(c0, c1);
            instance.GetParams();
        }

        [Theory]
        [InlineData("Ed25519", new byte[] { 0x04, 0x05, 0x06 })]
        public void GetBytes_Test_2886(string paramName, byte[] privateKeyBytes)
        {
            var c0 = new NamedParameterSpec(paramName);
            var c1 = privateKeyBytes;
            var instance = new EdECPrivateKeySpec(c0, c1);
            instance.GetBytes();
        }
    }
}
```