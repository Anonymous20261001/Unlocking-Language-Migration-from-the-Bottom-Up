```csharp
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.crypto.spec.DHParameterSpec
    public class DHParameterSpec
    {
        private readonly BigInteger p;
        private readonly BigInteger g;
        private readonly int l;

        public DHParameterSpec(BigInteger p, BigInteger g)
        {
            this.p = p;
            this.g = g;
            this.l = 0; // Default as in Java
        }

        public DHParameterSpec(BigInteger p, BigInteger g, int l)
        {
            this.p = p;
            this.g = g;
            this.l = l;
        }

        public int GetL() => l;
        public BigInteger GetP() => p;
        public BigInteger GetG() => g;
    }

    [TestFixture]
    public class DHParameterSpecAutoTest
    {
        [Test]
        public void GetL_test_5238()
        {
            BigInteger c0 = new BigInteger(123456789);
            BigInteger c1 = new BigInteger(987654321);
            DHParameterSpec instance = new DHParameterSpec(c0, c1);
            instance.GetL();
        }

        [Test]
        public void GetP_test_5239()
        {
            BigInteger c0 = new BigInteger(123456789);
            BigInteger c1 = new BigInteger(987654321);
            DHParameterSpec instance = new DHParameterSpec(c0, c1);
            instance.GetP();
        }

        [Test]
        public void GetG_test_5240()
        {
            BigInteger c0 = new BigInteger(123456789);
            BigInteger c1 = new BigInteger(987654321);
            DHParameterSpec instance = new DHParameterSpec(c0, c1);
            instance.GetG();
        }
    }
}
```