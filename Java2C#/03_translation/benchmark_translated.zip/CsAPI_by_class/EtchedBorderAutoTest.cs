```csharp
using System;
using System.Drawing;
using System.Windows.Forms;
using NUnit.Framework;

public class Insets
{
    public int Top { get; set; }
    public int Left { get; set; }
    public int Bottom { get; set; }
    public int Right { get; set; }

    public Insets(int top, int left, int bottom, int right)
    {
        Top = top;
        Left = left;
        Bottom = bottom;
        Right = right;
    }
}

public class EtchedBorder
{
    public const int LOWERED = 0;
    public const int RAISED = 1;

    private int etchType;
    private Color? highlight;
    private Color? shadow;

    // Default constructor: lowered, no custom colors
    public EtchedBorder() : this(LOWERED, null, null) { }

    public EtchedBorder(int etchType) : this(etchType, null, null) { }

    public EtchedBorder(int etchType, Color? highlight, Color? shadow)
    {
        this.etchType = etchType;
        this.highlight = highlight;
        this.shadow = shadow;
    }

    public void PaintBorder(Control c, Graphics g, int x, int y, int width, int height)
    {
        Color h = GetHighlightColor(c);
        Color s = GetShadowColor(c);

        // Simple etched effect: draw top/left with highlight, bottom/right with shadow
        using (Pen highlightPen = new Pen(h))
        using (Pen shadowPen = new Pen(s))
        {
            // Top
            g.DrawLine(highlightPen, x, y, x + width - 1, y);
            // Left
            g.DrawLine(highlightPen, x, y, x, y + height - 1);
            // Bottom
            g.DrawLine(shadowPen, x, y + height - 1, x + width - 1, y + height - 1);
            // Right
            g.DrawLine(shadowPen, x + width - 1, y, x + width - 1, y + height - 1);
        }
    }

    public Insets GetBorderInsets(Control c, Insets insets)
    {
        // Typical etched border insets: 2 pixels on each side
        insets.Top = 2;
        insets.Left = 2;
        insets.Bottom = 2;
        insets.Right = 2;
        return insets;
    }

    public bool IsBorderOpaque()
    {
        return false;
    }

    public Color GetHighlightColor(Control c)
    {
        if (highlight.HasValue)
            return highlight.Value;
        // Default: use Control's background brighter if possible, else LightGray
        if (c?.BackColor != null)
            return ControlPaint.Light(c.BackColor);
        return Color.LightGray;
    }

    public Color GetHighlightColor()
    {
        return highlight ?? Color.LightGray;
    }

    public Color GetShadowColor(Control c)
    {
        if (shadow.HasValue)
            return shadow.Value;
        if (c?.BackColor != null)
            return ControlPaint.Dark(c.BackColor);
        return Color.Gray;
    }

    public Color GetShadowColor()
    {
        return shadow ?? Color.Gray;
    }

    public int GetEtchType()
    {
        return etchType;
    }
}

[TestFixture]
public class EtchedBorderAutoTest
{
    [Test]
    public void PaintBorder_test_8468()
    {
        EtchedBorder instance = new EtchedBorder();
        // Create a dummy Component and Graphics for testing
        using (var bitmap = new Bitmap(100, 100))
        using (Graphics g = Graphics.FromImage(bitmap))
        {
            Control control = new Button();
            instance.PaintBorder(control, g, 10, 10, 80, 80);
        }
    }

    [Test]
    public void GetBorderInsets_test_8469()
    {
        EtchedBorder instance = new EtchedBorder();
        Control control = new Button();
        Insets insets = new Insets(0, 0, 0, 0);
        instance.GetBorderInsets(control, insets);
    }

    [Test]
    public void IsBorderOpaque_test_8470()
    {
        EtchedBorder instance = new EtchedBorder();
        instance.IsBorderOpaque();
    }

    [Test]
    public void GetHighlightColor_test_8471()
    {
        EtchedBorder instance = new EtchedBorder();
        Control control = new Button();
        instance.GetHighlightColor(control);
    }

    [Test]
    public void GetHighlightColor_test_8472()
    {
        EtchedBorder instance = new EtchedBorder();
        instance.GetHighlightColor();
    }

    [Test]
    public void GetShadowColor_test_8473()
    {
        EtchedBorder instance = new EtchedBorder();
        instance.GetShadowColor();
    }

    [Test]
    public void GetShadowColor_test_8474()
    {
        EtchedBorder instance = new EtchedBorder();
        Control control = new Button();
        instance.GetShadowColor(control);
    }

    [Test]
    public void GetEtchType_test_8475()
    {
        EtchedBorder instance = new EtchedBorder();
        instance.GetEtchType();
    }
}
```