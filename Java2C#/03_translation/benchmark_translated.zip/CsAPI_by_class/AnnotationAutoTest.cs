```csharp
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of java.text.Annotation.
    /// </summary>
    public class Annotation
    {
        private readonly object _value;

        public Annotation(object value)
        {
            _value = value;
        }

        /// <summary>
        /// Returns a string representation of this Annotation.
        /// Equivalent to Java's toString() which returns "classname[value=...]".
        /// </summary>
        public override string ToString()
        {
            return $"{GetType().FullName}[value={_value}]";
        }

        /// <summary>
        /// Returns the wrapped value.
        /// </summary>
        public object GetValue()
        {
            return _value;
        }
    }

    /// <summary>
    /// Translated test class from Java AnnotationAutoTest.
    /// Each Java @Test method becomes a C# [TestCase] method with the same name (converted to PascalCase with underscore preservation).
    /// </summary>
    [TestFixture]
    public class AnnotationAutoTest
    {
        /// <summary>
        /// Original Java: toString_test_2994(Object c0)
        /// </summary>
        [TestCase(null)]
        public void ToString_Test_2994(object c0)
        {
            var instance = new Annotation(c0);
            instance.ToString();
        }

        /// <summary>
        /// Original Java: getValue_test_2995(Object c0)
        /// </summary>
        [TestCase(null)]
        public void GetValue_Test_2995(object c0)
        {
            var instance = new Annotation(c0);
            instance.GetValue();
        }
    }
}
```