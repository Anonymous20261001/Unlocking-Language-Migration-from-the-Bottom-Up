```csharp
using NUnit.Framework;
using System;
using Javax.Management;

namespace Generated.Test
{
    public class BadStringOperationExceptionAutoTest
    {
        [Test]
        public void toString_test_5548(string c0)
        {
            BadStringOperationException instance = new BadStringOperationException(c0);
            instance.ToString();
        }
    }
}

namespace Javax.Management
{
    public class BadStringOperationException : Exception
    {
        public BadStringOperationException(string message) : base(message)
        {
        }

        public override string ToString()
        {
            // Mimics Java's Throwable.toString(): class name + ": " + message (without stack trace)
            return GetType().Name + ": " + Message;
        }
    }
}
```