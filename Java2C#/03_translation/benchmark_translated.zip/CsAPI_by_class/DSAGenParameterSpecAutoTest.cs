```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class DSAGenParameterSpec
    {
        private readonly int primePLength;
        private readonly int subprimeQLength;
        private readonly int seedLength;

        public DSAGenParameterSpec(int primePLength, int subprimeQLength)
        {
            this.primePLength = primePLength;
            this.subprimeQLength = subprimeQLength;
            this.seedLength = 0;
        }

        public DSAGenParameterSpec(int primePLength, int subprimeQLength, int seedLength)
        {
            this.primePLength = primePLength;
            this.subprimeQLength = subprimeQLength;
            this.seedLength = seedLength;
        }

        public int GetPrimePLength() => primePLength;
        public int GetSubprimeQLength() => subprimeQLength;
        public int GetSeedLength() => seedLength;
    }

    [TestFixture]
    public class DSAGenParameterSpecAutoTest
    {
        [Test]
        public void GetPrimePLength_test_2845(int c0, int c1)
        {
            DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
            instance.GetPrimePLength();
        }

        [Test]
        public void GetSubprimeQLength_test_2846(int c0, int c1)
        {
            DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
            instance.GetSubprimeQLength();
        }

        [Test]
        public void GetSeedLength_test_2847(int c0, int c1)
        {
            DSAGenParameterSpec instance = new DSAGenParameterSpec(c0, c1);
            instance.GetSeedLength();
        }
    }
}
```