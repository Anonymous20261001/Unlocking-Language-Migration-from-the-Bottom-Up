```csharp
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    // ----- Simple Color class (equivalent to java.awt.Color) -----
    public class Color
    {
        public int RGB { get; }

        public Color(int r, int g, int b) : this(r, g, b, 255) { }

        public Color(int r, int g, int b, int a)
        {
            RGB = (a << 24) | (r << 16) | (g << 8) | b;
        }

        public static Color White = new Color(255, 255, 255);
        public static Color Black = new Color(0, 0, 0);
        // Other common colors can be added if needed.
    }

    // ----- ChangeEvent class (equivalent to javax.swing.event.ChangeEvent) -----
    public class ChangeEvent : EventArgs
    {
        public object Source { get; }

        public ChangeEvent(object source)
        {
            Source = source;
        }
    }

    // ----- ChangeListener interface (equivalent to javax.swing.event.ChangeListener) -----
    public interface ChangeListener
    {
        void stateChanged(ChangeEvent e);
    }

    // ----- DefaultColorSelectionModel (equivalent to javax.swing.colorchooser.DefaultColorSelectionModel) -----
    public class DefaultColorSelectionModel
    {
        private List<ChangeListener> listeners = new List<ChangeListener>();
        private Color selectedColor;

        public DefaultColorSelectionModel()
        {
            selectedColor = Color.White;
        }

        public void addChangeListener(ChangeListener listener)
        {
            if (listener == null) throw new ArgumentNullException(nameof(listener));
            listeners.Add(listener);
        }

        public void removeChangeListener(ChangeListener listener)
        {
            if (listener == null) throw new ArgumentNullException(nameof(listener));
            listeners.Remove(listener);
        }

        public ChangeListener[] getChangeListeners()
        {
            return listeners.ToArray();
        }

        public Color getSelectedColor()
        {
            return selectedColor;
        }

        public void setSelectedColor(Color color)
        {
            selectedColor = color;
            fireStateChanged();
        }

        protected void fireStateChanged()
        {
            ChangeEvent evt = new ChangeEvent(this);
            foreach (var listener in listeners)
            {
                listener.stateChanged(evt);
            }
        }
    }

    // ----- Test class (mirror of Java test) -----
    [TestFixture]
    public class DefaultColorSelectionModelAutoTest
    {
        [Test]
        public void addChangeListener_test_8515(ChangeListener p0)
        {
            DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
            instance.addChangeListener(p0);
        }

        [Test]
        public void removeChangeListener_test_8516(ChangeListener p0)
        {
            DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
            instance.removeChangeListener(p0);
        }

        [Test]
        public void getChangeListeners_test_8517()
        {
            DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
            instance.getChangeListeners();
        }

        [Test]
        public void getSelectedColor_test_8518()
        {
            DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
            instance.getSelectedColor();
        }

        [Test]
        public void setSelectedColor_test_8519(Color p0)
        {
            DefaultColorSelectionModel instance = new DefaultColorSelectionModel();
            instance.setSelectedColor(p0);
        }
    }
}
```