```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class ChaCha20ParameterSpec
    {
        private byte[] nonce;
        private int counter;

        public ChaCha20ParameterSpec(byte[] nonce, int counter)
        {
            this.nonce = nonce;
            this.counter = counter;
        }

        public byte[] GetNonce()
        {
            return nonce;
        }

        public int GetCounter()
        {
            return counter;
        }
    }

    [TestFixture]
    public class ChaCha20ParameterSpecAutoTest
    {
        [Test]
        public void getNonce_test_5234()
        {
            byte[] c0 = new byte[12]; // 12-byte nonce
            int c1 = 0;
            ChaCha20ParameterSpec instance = new ChaCha20ParameterSpec(c0, c1);
            instance.GetNonce();
        }

        [Test]
        public void getCounter_test_5235()
        {
            byte[] c0 = new byte[12];
            int c1 = 0;
            ChaCha20ParameterSpec instance = new ChaCha20ParameterSpec(c0, c1);
            instance.GetCounter();
        }
    }
}
```