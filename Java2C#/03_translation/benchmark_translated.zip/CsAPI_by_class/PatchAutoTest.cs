```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class Patch
    {
        private readonly int bank;
        private readonly int program;

        public Patch(int bank, int program)
        {
            this.bank = bank;
            this.program = program;
        }

        public int GetBank()
        {
            return bank;
        }

        public int GetProgram()
        {
            return program;
        }
    }

    [TestFixture]
    public class PatchAutoTest
    {
        [Test]
        public void GetBank_Test_6488()
        {
            int c0 = 0; // default value, could be any int
            int c1 = 0; // default value
            Patch instance = new Patch(c0, c1);
            instance.GetBank();
        }

        [Test]
        public void GetProgram_Test_6489()
        {
            int c0 = 0; // default value
            int c1 = 0; // default value
            Patch instance = new Patch(c0, c1);
            instance.GetProgram();
        }
    }
}
```