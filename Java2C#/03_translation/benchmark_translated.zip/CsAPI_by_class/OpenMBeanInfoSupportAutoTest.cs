```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // ------------------------------------------------------------
    // Dummy implementations of the required JMX-like interfaces/classes
    // ------------------------------------------------------------
    public interface IOpenMBeanAttributeInfo { }
    public interface IOpenMBeanConstructorInfo { }
    public interface IOpenMBeanOperationInfo { }

    public class MBeanNotificationInfo : IEquatable<MBeanNotificationInfo>
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string[] NotifTypes { get; set; }

        public override bool Equals(object obj) => Equals(obj as MBeanNotificationInfo);
        public bool Equals(MBeanNotificationInfo other)
        {
            if (other == null) return false;
            return Name == other.Name &&
                   Description == other.Description &&
                   (NotifTypes ?? Array.Empty<string>()).SequenceEqual(other.NotifTypes ?? Array.Empty<string>());
        }
        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (Name?.GetHashCode() ?? 0);
            hash = hash * 31 + (Description?.GetHashCode() ?? 0);
            foreach (var t in NotifTypes ?? Array.Empty<string>())
                hash = hash * 31 + (t?.GetHashCode() ?? 0);
            return hash;
        }
    }

    public class OpenMBeanAttributeInfo : IOpenMBeanAttributeInfo
    {
        // Minimal implementation – not exercised directly in tests.
        public override bool Equals(object obj) => obj is OpenMBeanAttributeInfo; // dummy
        public override int GetHashCode() => 0; // dummy
    }

    public class OpenMBeanConstructorInfo : IOpenMBeanConstructorInfo
    {
        public override bool Equals(object obj) => obj is OpenMBeanConstructorInfo; // dummy
        public override int GetHashCode() => 0; // dummy
    }

    public class OpenMBeanOperationInfo : IOpenMBeanOperationInfo
    {
        public override bool Equals(object obj) => obj is OpenMBeanOperationInfo; // dummy
        public override int GetHashCode() => 0; // dummy
    }

    // ------------------------------------------------------------
    // OpenMBeanInfoSupport – the main class under test
    // ------------------------------------------------------------
    public class OpenMBeanInfoSupport : IEquatable<OpenMBeanInfoSupport>
    {
        private readonly string _className;
        private readonly string _description;
        private readonly IOpenMBeanAttributeInfo[] _attributes;
        private readonly IOpenMBeanConstructorInfo[] _constructors;
        private readonly IOpenMBeanOperationInfo[] _operations;
        private readonly MBeanNotificationInfo[] _notifications;

        public OpenMBeanInfoSupport(
            string className,
            string description,
            IOpenMBeanAttributeInfo[] attributes,
            IOpenMBeanConstructorInfo[] constructors,
            IOpenMBeanOperationInfo[] operations,
            MBeanNotificationInfo[] notifications)
        {
            _className = className;
            _description = description;
            _attributes = attributes ?? Array.Empty<IOpenMBeanAttributeInfo>();
            _constructors = constructors ?? Array.Empty<IOpenMBeanConstructorInfo>();
            _operations = operations ?? Array.Empty<IOpenMBeanOperationInfo>();
            _notifications = notifications ?? Array.Empty<MBeanNotificationInfo>();
        }

        public override bool Equals(object obj) => Equals(obj as OpenMBeanInfoSupport);

        public bool Equals(OpenMBeanInfoSupport other)
        {
            if (other == null) return false;

            // Compare primitive strings
            if (_className != other._className) return false;
            if (_description != other._description) return false;

            // Compare arrays using SequenceEqual
            if (!_attributes.SequenceEqual(other._attributes)) return false;
            if (!_constructors.SequenceEqual(other._constructors)) return false;
            if (!_operations.SequenceEqual(other._operations)) return false;
            if (!_notifications.SequenceEqual(other._notifications)) return false;

            return true;
        }

        public override int GetHashCode()
        {
            int hash = 17;
            hash = hash * 31 + (_className?.GetHashCode() ?? 0);
            hash = hash * 31 + (_description?.GetHashCode() ?? 0);
            foreach (var a in _attributes) hash = hash * 31 + (a?.GetHashCode() ?? 0);
            foreach (var c in _constructors) hash = hash * 31 + (c?.GetHashCode() ?? 0);
            foreach (var o in _operations) hash = hash * 31 + (o?.GetHashCode() ?? 0);
            foreach (var n in _notifications) hash = hash * 31 + (n?.GetHashCode() ?? 0);
            return hash;
        }

        public override string ToString()
        {
            return $"OpenMBeanInfoSupport[{_className}, {_description}]";
        }
    }

    // ------------------------------------------------------------
    // Test class (NUnit)
    // ------------------------------------------------------------
    [TestFixture]
    public class OpenMBeanInfoSupportAutoTest
    {
        [Test]
        public void Equals_test_5760()
        {
            // Create sample data (Java test passed parameters – we use dummy values)
            var p0 = new object();
            var c0 = "TestClass";
            var c1 = "Test Description";
            var c2 = new IOpenMBeanAttributeInfo[] { new OpenMBeanAttributeInfo() };
            var c3 = new IOpenMBeanConstructorInfo[] { new OpenMBeanConstructorInfo() };
            var c4 = new IOpenMBeanOperationInfo[] { new OpenMBeanOperationInfo() };
            var c5 = new MBeanNotificationInfo[]
            {
                new MBeanNotificationInfo { Name = "notif1", Description = "desc", NotifTypes = new[] {"type1"} }
            };

            var instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
            instance.Equals(p0); // simply exercise the method
        }

        [Test]
        public void ToString_test_5761()
        {
            var c0 = "TestClass";
            var c1 = "Test Description";
            var c2 = new IOpenMBeanAttributeInfo[] { new OpenMBeanAttributeInfo() };
            var c3 = new IOpenMBeanConstructorInfo[] { new OpenMBeanConstructorInfo() };
            var c4 = new IOpenMBeanOperationInfo[] { new OpenMBeanOperationInfo() };
            var c5 = new MBeanNotificationInfo[]
            {
                new MBeanNotificationInfo { Name = "notif1", Description = "desc", NotifTypes = new[] {"type1"} }
            };

            var instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
            var result = instance.ToString(); // simply exercise the method
        }

        [Test]
        public void HashCode_test_5762()
        {
            var c0 = "TestClass";
            var c1 = "Test Description";
            var c2 = new IOpenMBeanAttributeInfo[] { new OpenMBeanAttributeInfo() };
            var c3 = new IOpenMBeanConstructorInfo[] { new OpenMBeanConstructorInfo() };
            var c4 = new IOpenMBeanOperationInfo[] { new OpenMBeanOperationInfo() };
            var c5 = new MBeanNotificationInfo[]
            {
                new MBeanNotificationInfo { Name = "notif1", Description = "desc", NotifTypes = new[] {"type1"} }
            };

            var instance = new OpenMBeanInfoSupport(c0, c1, c2, c3, c4, c5);
            var code = instance.GetHashCode(); // simply exercise the method
        }
    }
}
```