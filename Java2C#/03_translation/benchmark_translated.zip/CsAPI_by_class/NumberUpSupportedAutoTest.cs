```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // Base class to mimic Java's SetOfIntegerSyntax
    public abstract class SetOfIntegerSyntax
    {
        private readonly int[][] _ranges;

        protected SetOfIntegerSyntax(int[][] ranges)
        {
            _ranges = ranges;
        }

        // Expands all ranges to a sorted array of individual integers
        protected int[] GetMembers()
        {
            var members = new List<int>();
            foreach (var range in _ranges)
            {
                if (range.Length != 2)
                    throw new ArgumentException("Each range must be an array of two integers.");
                int lower = range[0];
                int upper = range[1];
                for (int i = lower; i <= upper; i++)
                    members.Add(i);
            }
            members.Sort();
            return members.ToArray();
        }

        public override bool Equals(object obj)
        {
            if (obj == this)
                return true;
            if (!(obj is SetOfIntegerSyntax other))
                return false;
            return GetMembers().SequenceEqual(other.GetMembers());
        }

        public override int GetHashCode()
        {
            int hash = 17;
            foreach (int member in GetMembers())
                hash = hash * 31 + member;
            return hash;
        }
    }

    // C# equivalent of javax.print.attribute.standard.NumberUpSupported
    public class NumberUpSupported : SetOfIntegerSyntax
    {
        public NumberUpSupported(int[][] ranges) : base(ranges)
        {
        }

        public Type GetCategory()
        {
            return typeof(NumberUpSupported);
        }

        public string GetName()
        {
            return "number-up-supported";
        }
    }

    [TestFixture]
    public class NumberUpSupportedAutoTest
    {
        [Test]
        public void GetCategory_test_6195()
        {
            int[][] c0 = new int[][] { new int[] { 1, 2 } };
            NumberUpSupported instance = new NumberUpSupported(c0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_test_6196()
        {
            int[][] c0 = new int[][] { new int[] { 1, 2 } };
            NumberUpSupported instance = new NumberUpSupported(c0);
            instance.GetName();
        }

        [Test]
        public void Equals_test_6197()
        {
            int[][] c0 = new int[][] { new int[] { 1, 2 } };
            NumberUpSupported instance = new NumberUpSupported(c0);
            object p0 = new NumberUpSupported(c0); // same ranges, should be equal
            instance.Equals(p0);
        }
    }
}
```