```csharp
using NUnit.Framework;
using System;

namespace Generated.Test
{
    /// <summary>
    /// C# translation of the Java test class for IllegalCharsetNameException.
    /// </summary>
    [TestFixture]
    public class IllegalCharsetNameExceptionAutoTest
    {
        /// <summary>
        /// Test for the GetCharsetName() method.
        /// </summary>
        [Test]
        public void GetCharsetName_test_2641()
        {
            // The original Java method had a String parameter; here we use a fixed sample value.
            string c0 = "UTF-8";
            IllegalCharsetNameException instance = new IllegalCharsetNameException(c0);
            instance.GetCharsetName();
        }
    }

    /// <summary>
    /// C# equivalent of Java's java.nio.charset.IllegalCharsetNameException.
    /// Represents an exception thrown when an illegal charset name is used.
    /// </summary>
    public class IllegalCharsetNameException : ArgumentException
    {
        private readonly string charsetName;

        /// <summary>
        /// Constructs a new IllegalCharsetNameException with the given charset name.
        /// </summary>
        /// <param name="charsetName">The illegal charset name (may be null).</param>
        public IllegalCharsetNameException(string charsetName)
            : base(charsetName) // The detail message is set to the charset name (as in Java)
        {
            this.charsetName = charsetName;
        }

        /// <summary>
        /// Gets the illegal charset name.
        /// </summary>
        /// <returns>The charset name provided to the constructor.</returns>
        public string GetCharsetName()
        {
            return charsetName;
        }
    }
}
```