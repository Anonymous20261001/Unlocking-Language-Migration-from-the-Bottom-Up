```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    public class FormatFlagsConversionMismatchExceptionAutoTest
    {
        [Test]
        public void GetConversion_Test_3443(string c0, char c1)
        {
            var instance = new FormatFlagsConversionMismatchException(c0, c1);
            instance.GetConversion();
        }

        [Test]
        public void GetMessage_Test_3444(string c0, char c1)
        {
            var instance = new FormatFlagsConversionMismatchException(c0, c1);
            instance.GetMessage();
        }

        [Test]
        public void GetFlags_Test_3445(string c0, char c1)
        {
            var instance = new FormatFlagsConversionMismatchException(c0, c1);
            instance.GetFlags();
        }
    }

    public class FormatFlagsConversionMismatchException : Exception
    {
        private readonly string _flags;
        private readonly char _conversion;

        public FormatFlagsConversionMismatchException(string flags, char conversion)
            : base($"Flags = '{flags}', Conversion = '{conversion}'")
        {
            _flags = flags;
            _conversion = conversion;
        }

        public char GetConversion()
        {
            return _conversion;
        }

        public string GetFlags()
        {
            return _flags;
        }

        // getMessage() in Java is overridden; we mimic it via the base constructor message.
        // The method GetMessage() returns the same string as the Message property.
        public string GetMessage()
        {
            return Message;
        }
    }
}
```