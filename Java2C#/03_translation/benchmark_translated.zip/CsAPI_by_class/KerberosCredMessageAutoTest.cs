```csharp
using System;
using NUnit.Framework;

// ----------------------------------------------------------------------
// C# equivalents of Java classes javax.security.auth.kerberos.KerberosPrincipal
// and javax.security.auth.kerberos.KerberosCredMessage
// ----------------------------------------------------------------------

public class KerberosPrincipal
{
    private readonly string _name;
    private readonly string _realm;

    public KerberosPrincipal(string name)
    {
        // In Java, the constructor parses the principal name (e.g., "user@REALM").
        // For simplicity, we treat the input as the full principal string.
        _name = name;
        int atIndex = name.IndexOf('@');
        _realm = atIndex >= 0 ? name.Substring(atIndex + 1) : string.Empty;
    }

    public KerberosPrincipal(string name, string realm)
    {
        _name = name + "@" + realm;
        _realm = realm;
    }

    public string Name => _name;
    public string Realm => _realm;

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
            return false;

        KerberosPrincipal other = (KerberosPrincipal)obj;
        return _name == other._name;
    }

    public override int GetHashCode()
    {
        return _name.GetHashCode();
    }

    public override string ToString()
    {
        return _name;
    }
}

public class KerberosCredMessage
{
    private KerberosPrincipal _sender;
    private KerberosPrincipal _recipient;
    private byte[] _message;
    private bool _destroyed;

    public KerberosCredMessage(KerberosPrincipal sender, KerberosPrincipal recipient, byte[] message)
    {
        _sender = sender;
        _recipient = recipient;
        _message = message;
        _destroyed = false;
    }

    public KerberosPrincipal Sender => _destroyed ? throw new ObjectDestroyedException() : _sender;
    public KerberosPrincipal Recipient => _destroyed ? throw new ObjectDestroyedException() : _recipient;

    public byte[] GetEncoded()
    {
        if (_destroyed) throw new ObjectDestroyedException();
        // Return a copy of the message array to mimic Java's defensive copy.
        return _message?.Clone() as byte[];
    }

    public bool IsDestroyed() => _destroyed;

    public void Destroy()
    {
        if (_destroyed) throw new ObjectDestroyedException();
        _destroyed = true;
        _sender = null;
        _recipient = null;
        _message = null;
    }

    public override bool Equals(object obj)
    {
        if (obj == null || !(obj is KerberosCredMessage other))
            return false;

        // In Java, equals compares sender, recipient, and message content.
        if (ReferenceEquals(this, other)) return true;
        if (_destroyed != other._destroyed) return false;
        if (_destroyed) return true; // both destroyed, treat as equal (Java behavior?)

        bool senderEqual = (_sender == null && other._sender == null) ||
                           (_sender != null && _sender.Equals(other._sender));
        bool recipientEqual = (_recipient == null && other._recipient == null) ||
                              (_recipient != null && _recipient.Equals(other._recipient));
        bool messageEqual = CompareByteArrays(_message, other._message);

        return senderEqual && recipientEqual && messageEqual;
    }

    public override int GetHashCode()
    {
        if (_destroyed) return 0;
        int hash = 7;
        hash = 31 * hash + (_sender?.GetHashCode() ?? 0);
        hash = 31 * hash + (_recipient?.GetHashCode() ?? 0);
        hash = 31 * hash + GetByteArrayHashCode(_message);
        return hash;
    }

    public override string ToString()
    {
        if (_destroyed) return "Kerberos Cred Message is destroyed";
        return $"KerberosCredMessage[sender={_sender}, recipient={_recipient}]";
    }

    private static bool CompareByteArrays(byte[] a, byte[] b)
    {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a.Length != b.Length) return false;
        for (int i = 0; i < a.Length; i++)
            if (a[i] != b[i]) return false;
        return true;
    }

    private static int GetByteArrayHashCode(byte[] array)
    {
        if (array == null) return 0;
        int hash = 17;
        foreach (byte b in array)
            hash = hash * 31 + b;
        return hash;
    }
}

public class ObjectDestroyedException : Exception
{
    public ObjectDestroyedException() : base("Object has been destroyed") { }
}

// ----------------------------------------------------------------------
// Test class translated from Java
// ----------------------------------------------------------------------

[TestFixture]
public class KerberosCredMessageAutoTest
{
    // We provide one sample test case per method.
    // In a real scenario these would be generated with more data.

    [TestCase(null, "sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void Equals_Test_6370(object p0, string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.Equals(p0);
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void ToString_Test_6371(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.ToString();
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void HashCode_Test_6372(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.GetHashCode();
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void IsDestroyed_Test_6373(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.IsDestroyed();
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void Destroy_Test_6374(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.Destroy();
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void GetEncoded_Test_6375(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.GetEncoded();
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void GetSender_Test_6376(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.GetSender(); // This would be a property in C# – we keep method name for compatibility
    }

    [TestCase("sender@A", "recipient@B", new byte[] { 1, 2, 3 })]
    public void GetRecipient_Test_6377(string senderName, string recipientName, byte[] message)
    {
        var sender = new KerberosPrincipal(senderName);
        var recipient = new KerberosPrincipal(recipientName);
        var instance = new KerberosCredMessage(sender, recipient, message);
        instance.GetRecipient();
    }

    // Helper methods exposed to simulate Java's getSender/getRecipient methods
    // In the translated class