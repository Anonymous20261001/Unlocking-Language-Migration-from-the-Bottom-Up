```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // Custom ArrayList class mimicking Java's ArrayList (raw type)
    public class ArrayList : IList<object>, ICollection<object>, IEnumerable<object>
    {
        private List<object> _list = new List<object>();

        // ---------- Constructors ----------
        public ArrayList() { }
        public ArrayList(ICollection<object> collection) { _list = new List<object>(collection); }
        public ArrayList(int initialCapacity) { _list = new List<object>(initialCapacity); }

        // ---------- List<T> implementation ----------
        public object this[int index]
        {
            get => _list[index];
            set => _list[index] = value;
        }

        public int Count => _list.Count;
        public bool IsReadOnly => false;

        public void Add(object item) => _list.Add(item);
        public void Clear() => _list.Clear();
        public bool Contains(object item) => _list.Contains(item);
        public void CopyTo(object[] array, int arrayIndex) => _list.CopyTo(array, arrayIndex);
        public IEnumerator<object> GetEnumerator() => _list.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _list.GetEnumerator();
        public int IndexOf(object item) => _list.IndexOf(item);
        public void Insert(int index, object item) => _list.Insert(index, item);
        public bool Remove(object item) => _list.Remove(item);
        public void RemoveAt(int index) => _list.RemoveAt(index);

        // ---------- Additional Java ArrayList methods ----------

        // remove(int) overload (distinct from Remove(object))
        public object Remove(int index)
        {
            var removed = _list[index];
            _list.RemoveAt(index);
            return removed;
        }

        public int Size() => _list.Count;
        public bool IsEmpty() => _list.Count == 0;
        public int LastIndexOf(object item) => _list.LastIndexOf(item);

        public void Sort(IComparer<object> comparer)
        {
            _list.Sort(comparer);
        }

        // List.Sort also works with Comparison<object>
        public void Sort(Comparison<object> comparison)
        {
            _list.Sort(comparison);
        }

        public void ReplaceAll(Func<object, object> operatorFunc)
        {
            for (int i = 0; i < _list.Count; i++)
            {
                _list[i] = operatorFunc(_list[i]);
            }
        }

        public void ForEach(Action<object> action)
        {
            _list.ForEach(action);
        }

        public bool RemoveIf(Predicate<object> filter)
        {
            return _list.RemoveAll(filter) > 0;
        }

        public bool AddAll(ICollection<object> collection)
        {
            int oldCount = _list.Count;
            _list.AddRange(collection);
            return _list.Count != oldCount;
        }

        public bool AddAll(int index, ICollection<object> collection)
        {
            int oldCount = _list.Count;
            _list.InsertRange(index, collection);
            return _list.Count != oldCount;
        }

        public bool RemoveAll(ICollection<object> collection)
        {
            return _list.RemoveAll(x => collection.Contains(x)) > 0;
        }

        public bool RetainAll(ICollection<object> collection)
        {
            return _list.RemoveAll(x => !collection.Contains(x)) > 0;
        }

        public object[] ToArray()
        {
            return _list.ToArray();
        }

        public object[] ToArray(object[] array)
        {
            _list.CopyTo(array);
            return array;
        }

        public ArrayList SubList(int fromIndex, int toIndex)
        {
            var sub = new ArrayList();
            for (int i = fromIndex; i < toIndex; i++)
            {
                sub.Add(_list[i]);
            }
            return sub;
        }

        public void TrimToSize()
        {
            // No-op in this implementation (List<T> manages capacity)
        }

        public void EnsureCapacity(int minCapacity)
        {
            if (_list.Capacity < minCapacity)
                _list.Capacity = minCapacity;
        }

        public object Clone()
        {
            var cloned = new ArrayList();
            cloned._list = new List<object>(_list);
            return cloned;
        }

        public override bool Equals(object obj)
        {
            if (obj is ArrayList other)
            {
                return _list.SequenceEqual(other._list);
            }
            return false;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                foreach (var item in _list)
                {
                    hash = hash * 31 + (item?.GetHashCode() ?? 0);
                }
                return hash;
            }
        }

        // Java 21+ methods
        public object GetFirst()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            return _list[0];
        }

        public object GetLast()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            return _list[_list.Count - 1];
        }

        public void AddFirst(object item)
        {
            _list.Insert(0, item);
        }

        public void AddLast(object item)
        {
            _list.Add(item);
        }

        public object RemoveFirst()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            var removed = _list[0];
            _list.RemoveAt(0);
            return removed;
        }

        public object RemoveLast()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            var removed = _list[_list.Count - 1];
            _list.RemoveAt(_list.Count - 1);
            return removed;
        }

        public IEnumerator<object> Iterator() => _list.GetEnumerator();

        // Spliterator not implemented (Java-specific), but we provide a stub
        public object Spliterator() => null;

        // ListIterator stubs (could implement if needed)
        public IEnumerator<object> ListIterator() => _list.GetEnumerator();
        public IEnumerator<object> ListIterator(int index)
        {
            if (index < 0 || index > _list.Count) throw new IndexOutOfRangeException();
            for (int i = index; i < _list.Count; i++)
                yield return _list[i];
        }
    }

    // Test class
    [TestFixture]
    public class ArrayListAutoTest
    {
        [Test]
        public void Remove_Test_3315()
        {
            ArrayList instance = new ArrayList();
            instance.Remove((object)null); // default object
        }

        [Test]
        public void Remove_Test_3316()
        {
            ArrayList instance = new ArrayList();
            instance.Remove(0); // default int
        }

        [Test]
        public void Size_Test_3317()
        {
            ArrayList instance = new ArrayList();
            instance.Size();
        }

        [Test]
        public void Get_Test_3318()
        {
            ArrayList instance = new ArrayList();
            // Will throw because list is empty, but test just calls method
            Assert.Throws<ArgumentOutOfRangeException>(() => instance[0]);
        }

        [Test]
        public void Equals_Test_3319()
        {
            ArrayList instance = new ArrayList();
            instance.Equals(null);
        }

        [Test]
        public void HashCode_Test_3320()
        {
            ArrayList instance = new ArrayList();
            instance.GetHashCode();
        }

        [Test]
        public void Clone_Test_3321()
        {
            ArrayList instance = new ArrayList();
            instance.Clone();
        }

        [Test]
        public void Sort_Test_3322()
        {
            ArrayList instance = new ArrayList();
            instance.Sort((IComparer<object>)null);
        }

        [Test]
        public void IndexOf_Test_3323()
        {
            ArrayList instance = new ArrayList();
            instance.IndexOf(null);
        }

        [Test]
        public void Clear_Test_3324()
        {
            ArrayList instance = new ArrayList();
            instance.Clear();
        }

        [Test]
        public void LastIndexOf_Test_3325()
        {
            ArrayList instance = new ArrayList();
            instance.LastIndexOf(null);
        }

        [Test]
        public void IsEmpty_Test_3326()
        {
            ArrayList instance = new ArrayList();
            instance.IsEmpty();
        }

        [Test]
        public void ReplaceAll_Test_3327()
        {
            ArrayList instance = new ArrayList();
            instance.ReplaceAll(x => x);
        }

        [Test]
        public void Add_Test_3328()
        {
            ArrayList instance = new ArrayList();
            instance.Add(null);
        }

        [Test]
        public void Add_Test_3329()
        {
            ArrayList instance = new ArrayList();
            instance.Add(0, null);
        }

        [Test]
        public void SubList_Test_3330()
        {
            ArrayList instance = new ArrayList();
            instance.SubList(0, 0);
        }

        [Test]
        public void ToArray_Test_3331()
        {
            ArrayList instance = new ArrayList();
            instance.ToArray(new object[0]);
        }

        [Test]
        public void ToArray_Test_3332()
        {
            ArrayList instance = new ArrayList();
            instance.ToArray();
        }

        [Test]
        public void Iterator_Test_3333()
        {
            ArrayList instance = new ArrayList();
            instance.Iterator();
        }

        [Test]
        public void Contains_Test_3334()
        {
            ArrayList instance = new ArrayList();
            instance.Contains(null);
        }

        [Test]
        public void Spliterator_Test_3335()
        {
            ArrayList instance = new ArrayList();
            instance.Spliterator();
        }

        [Test]
        public void AddAll_Test_3336()
        {
            ArrayList instance = new ArrayList();
            instance.AddAll(new ArrayList());
        }

        [Test]
        public void AddAll_Test_3337()
        {
            ArrayList instance = new ArrayList();
            instance.AddAll(0, new ArrayList());
        }

        [Test]
        public void TrimToSize_Test_3338()
        {
            ArrayList instance = new ArrayList();
            instance.TrimToSize();
        }

        [Test]
        public void Set_Test_3339()
        {
            ArrayList instance = new ArrayList();
            // Setting at index 0 on empty list will throw, but test just calls
            Assert.Throws<ArgumentOutOfRangeException>(() => instance[0] = null);
        }

        [Test]
        public void ForEach_Test_3340()
        {
            ArrayList instance = new ArrayList();
            instance.ForEach(x => { });
        }

        [Test]
        public void EnsureCapacity_Test_3341()
        {
            ArrayList instance = new ArrayList();
            instance.EnsureCapacity(10);
        }

        [Test]
        public void RemoveIf_Test_3342()
        {
            ArrayList instance = new ArrayList();
            instance.RemoveIf(x => true);
        }

        [Test]
        public void GetFirst_Test_3343()
        {
            ArrayList instance = new ArrayList();
            Assert.Throws<InvalidOperationException>(() => instance.GetFirst());
        }

        [Test]
        public void GetLast_Test_3344()
        {
            ArrayList instance = new ArrayList();
            Assert.Throws<InvalidOperationException>(() => instance.GetLast());
        }

        [Test]
        public void AddFirst_Test_3345()
        {
            ArrayList instance = new ArrayList();
            instance.AddFirst(null);
        }

        [Test]
        public void AddLast_Test_3346()
        {
            ArrayList instance = new ArrayList();
            instance.AddLast(null);
        }

        [Test]
        public void RemoveFirst_Test_3347()
        {
            ArrayList instance = new ArrayList();
            Assert.Throws<InvalidOperationException>(() => instance.RemoveFirst());
        }

        [Test]
        public void RemoveLast_Test_3348()
        {
            ArrayList instance = new ArrayList();
            Assert.Throws<InvalidOperationException>(() => instance.RemoveLast());
        }

        [Test]
        public void RemoveAll_Test_3349()
        {
            ArrayList instance = new ArrayList();
            instance.RemoveAll(new ArrayList());
        }

        [Test]
        public void RetainAll_Test_3350()
        {
            ArrayList instance = new ArrayList();
            instance.RetainAll(new ArrayList());
        }

        [Test]
        public void ListIterator_Test_3351()
        {
            ArrayList instance = new ArrayList();
            instance.ListIterator(0);
        }

        [Test]
        public void ListIterator_Test_3352()
        {
            ArrayList instance = new ArrayList();
            instance.ListIterator();
        }
    }
}
```