```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of java.beans.Beans static API
    public class Beans
    {
        // Static methods - simplified implementation
        public static bool IsDesignTime() => false;

        public static bool IsGuiAvailable() => false;

        public static void SetDesignTime(bool value) { }

        public static void SetGuiAvailable(bool value) { }

        public static object GetInstanceOf(object obj, Type type) => obj;

        public static bool IsInstanceOf(object obj, Type type) => type.IsInstanceOfType(obj);
    }

    [TestFixture]
    public class BeansAutoTest
    {
        [Test]
        public void IsDesignTime_Test_1512()
        {
            Beans instance = new Beans();
            Beans.IsDesignTime();
        }

        [Test]
        public void IsGuiAvailable_Test_1513()
        {
            Beans instance = new Beans();
            Beans.IsGuiAvailable();
        }

        [Test]
        public void SetDesignTime_Test_1514()
        {
            Beans instance = new Beans();
            Beans.SetDesignTime(false); // default value for missing parameter
        }

        [Test]
        public void SetGuiAvailable_Test_1515()
        {
            Beans instance = new Beans();
            Beans.SetGuiAvailable(false); // default value for missing parameter
        }

        [Test]
        public void GetInstanceOf_Test_1516()
        {
            Beans instance = new Beans();
            Beans.GetInstanceOf(null, typeof(object));
        }

        [Test]
        public void IsInstanceOf_Test_1517()
        {
            Beans instance = new Beans();
            Beans.IsInstanceOf(null, typeof(object));
        }
    }
}
```