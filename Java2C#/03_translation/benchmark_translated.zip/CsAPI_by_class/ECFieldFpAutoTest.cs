```csharp
using System;
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    public class ECFieldFp
    {
        private readonly BigInteger _p;

        public ECFieldFp(BigInteger p)
        {
            _p = p;
        }

        public BigInteger GetP()
        {
            return _p;
        }

        public int GetFieldSize()
        {
            // Java's ECFieldFp.getFieldSize() returns the bit length of p
            return (int)_p.GetBitLength();
        }

        public override bool Equals(object obj)
        {
            if (obj is ECFieldFp other)
                return _p.Equals(other._p);
            return false;
        }

        public override int GetHashCode()
        {
            return _p.GetHashCode();
        }
    }

    [TestFixture]
    public class ECFieldFpAutoTest
    {
        [Test]
        public void GetP_Test_2865()
        {
            BigInteger c0 = BigInteger.One;
            ECFieldFp instance = new ECFieldFp(c0);
            instance.GetP();
        }

        [Test]
        public void GetFieldSize_Test_2866()
        {
            BigInteger c0 = BigInteger.One;
            ECFieldFp instance = new ECFieldFp(c0);
            instance.GetFieldSize();
        }

        [Test]
        public void Equals_Test_2867()
        {
            object p0 = new object();
            BigInteger c0 = BigInteger.One;
            ECFieldFp instance = new ECFieldFp(c0);
            instance.Equals(p0);
        }

        [Test]
        public void HashCode_Test_2868()
        {
            BigInteger c0 = BigInteger.One;
            ECFieldFp instance = new ECFieldFp(c0);
            instance.GetHashCode();
        }
    }
}
```