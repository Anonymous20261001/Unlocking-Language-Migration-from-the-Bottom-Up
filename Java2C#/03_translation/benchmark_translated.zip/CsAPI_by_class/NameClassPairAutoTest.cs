```csharp
using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.naming.NameClassPair.
    /// </summary>
    public class NameClassPair
    {
        private string name;
        private string className;
        private bool isRelative = true; // Java default is true
        private string nameInNamespace;

        public NameClassPair(string name, string className)
        {
            this.name = name ?? throw new ArgumentNullException(nameof(name));
            this.className = className ?? throw new ArgumentNullException(nameof(className));
        }

        public void SetRelative(bool relative)
        {
            isRelative = relative;
        }

        public string GetNameInNamespace()
        {
            return nameInNamespace;
        }

        public void SetNameInNamespace(string nameInNs)
        {
            nameInNamespace = nameInNs;
        }

        public void SetClassName(string className)
        {
            this.className = className ?? throw new ArgumentNullException(nameof(className));
        }

        public string GetName()
        {
            return name;
        }

        public void SetName(string name)
        {
            this.name = name ?? throw new ArgumentNullException(nameof(name));
        }

        public string GetClassName()
        {
            return className;
        }

        public bool IsRelative()
        {
            return isRelative;
        }

        public override string ToString()
        {
            // Matches Java's default toString (simplified)
            return $"{name}: {className}";
        }
    }

    [TestFixture]
    public class NameClassPairAutoTest
    {
        [Test]
        public void SetRelative_test_5912(bool p0, string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.SetRelative(p0);
        }

        [Test]
        public void GetNameInNamespace_test_5913(string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.GetNameInNamespace();
        }

        [Test]
        public void SetNameInNamespace_test_5914(string p0, string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.SetNameInNamespace(p0);
        }

        [Test]
        public void SetClassName_test_5915(string p0, string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.SetClassName(p0);
        }

        [Test]
        public void GetName_test_5916(string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.GetName();
        }

        [Test]
        public void ToString_test_5917(string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.ToString();
        }

        [Test]
        public void SetName_test_5918(string p0, string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.SetName(p0);
        }

        [Test]
        public void GetClassName_test_5919(string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.GetClassName();
        }

        [Test]
        public void IsRelative_test_5920(string c0, string c1)
        {
            NameClassPair instance = new NameClassPair(c0, c1);
            instance.IsRelative();
        }
    }
}
```