```csharp
using System;
using NUnit.Framework;

namespace Generated.Tests
{
    // C# equivalent of javax.print.event.PrintEvent
    public class PrintEvent : EventArgs
    {
        private readonly object source;

        public PrintEvent(object source)
        {
            this.source = source;
        }

        public override string ToString()
        {
            return $"{GetType().Name}[source={source ?? "null"}]";
        }
    }

    [TestFixture]
    public class PrintEventAutoTest
    {
        [TestCase(null)] // provide a default argument to match the original parameter
        public void ToString_Test_6247(object c0)
        {
            var instance = new PrintEvent(c0);
            instance.ToString();
        }
    }
}
```