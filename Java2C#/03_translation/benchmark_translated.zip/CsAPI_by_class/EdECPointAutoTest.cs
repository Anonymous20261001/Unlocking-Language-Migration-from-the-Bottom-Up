```csharp
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of java.security.spec.EdECPoint.
    /// Represents an elliptic curve point in Edwards form.
    /// </summary>
    public class EdECPoint
    {
        private readonly bool _isXOdd;
        private readonly BigInteger _y;

        /// <summary>
        /// Constructs an EdECPoint.
        /// </summary>
        /// <param name="xOdd">Indicates whether the x-coordinate is odd.</param>
        /// <param name="y">The y-coordinate of the point.</param>
        public EdECPoint(bool xOdd, BigInteger y)
        {
            _isXOdd = xOdd;
            _y = y;
        }

        /// <summary>
        /// Returns whether the x-coordinate is odd.
        /// </summary>
        /// <returns>true if the x-coordinate is odd, false otherwise.</returns>
        public bool IsXOdd()
        {
            return _isXOdd;
        }

        /// <summary>
        /// Returns the y-coordinate.
        /// </summary>
        /// <returns>The BigInteger y-coordinate.</returns>
        public BigInteger GetY()
        {
            return _y;
        }
    }

    [TestFixture]
    public class EdECPointAutoTest
    {
        [Test]
        public void IsXOdd_test_2883()
        {
            // Using default values for demonstration; the original Java test had parameters
            // that are not defined. To make the test compilable and runnable, we provide
            // arbitrary values.
            bool c0 = false;
            BigInteger c1 = BigInteger.Zero;

            EdECPoint instance = new EdECPoint(c0, c1);
            instance.IsXOdd();
        }

        [Test]
        public void GetY_test_2884()
        {
            bool c0 = false;
            BigInteger c1 = BigInteger.Zero;

            EdECPoint instance = new EdECPoint(c0, c1);
            instance.GetY();
        }
    }
}
```