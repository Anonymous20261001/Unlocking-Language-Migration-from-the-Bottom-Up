```csharp
using System;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.print.attribute.standard.Copies
    public class Copies
    {
        private readonly int _value;

        public Copies(int value)
        {
            _value = value;
        }

        public Type GetCategory()
        {
            return typeof(Copies);
        }

        public string GetName()
        {
            return "copies";
        }

        public override bool Equals(object obj)
        {
            if (obj is Copies other)
                return _value == other._value;
            return false;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }
    }

    [TestFixture]
    public class CopiesAutoTest
    {
        [Test]
        public void GetCategory_test_6097()
        {
            Copies instance = new Copies(0);
            instance.GetCategory();
        }

        [Test]
        public void GetName_test_6098()
        {
            Copies instance = new Copies(0);
            instance.GetName();
        }

        [Test]
        public void Equals_test_6099()
        {
            Copies instance = new Copies(0);
            instance.Equals(null);
        }
    }
}
```