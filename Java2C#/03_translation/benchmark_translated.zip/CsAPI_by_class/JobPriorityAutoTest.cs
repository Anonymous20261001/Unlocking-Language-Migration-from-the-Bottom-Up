```csharp
using System;
using Xunit;

namespace PrintAttributes
{
    /// <summary>
    /// C# equivalent of javax.print.attribute.standard.JobPriority.
    /// Mimics IntegerSyntax and PrintRequestAttribute behavior.
    /// </summary>
    public class JobPriority
    {
        private readonly int _value;

        public JobPriority(int value)
        {
            _value = value;
        }

        /// <summary>
        /// Returns the category (type) of this attribute.
        /// </summary>
        public Type GetCategory()
        {
            return typeof(JobPriority);
        }

        /// <summary>
        /// Returns the name of this attribute.
        /// </summary>
        public string GetName()
        {
            return "job-priority";
        }

        public override bool Equals(object obj)
        {
            if (obj is JobPriority other)
                return _value == other._value;
            return false;
        }

        public override int GetHashCode()
        {
            return _value.GetHashCode();
        }
    }
}

namespace Generated.Test
{
    using PrintAttributes;

    /// <summary>
    /// C# translation of the Java JUnit test class JobPriorityAutoTest.
    /// Each test method name is PascalCase with the same suffix as the Java original.
    /// </summary>
    public class JobPriorityAutoTest
    {
        [Theory]
        [InlineData(0)]
        public void GetCategory_Test_6160(int c0)
        {
            JobPriority instance = new JobPriority(c0);
            instance.GetCategory();
        }

        [Theory]
        [InlineData(0)]
        public void GetName_Test_6161(int c0)
        {
            JobPriority instance = new JobPriority(c0);
            instance.GetName();
        }

        [Theory]
        [InlineData(null, 0)]
        public void Equals_Test_6162(object p0, int c0)
        {
            JobPriority instance = new JobPriority(c0);
            instance.Equals(p0);
        }
    }
}
```