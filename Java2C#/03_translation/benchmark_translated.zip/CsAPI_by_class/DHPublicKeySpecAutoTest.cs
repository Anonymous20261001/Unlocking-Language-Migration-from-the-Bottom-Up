```csharp
using System.Numerics;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of Java's javax.crypto.spec.DHPublicKeySpec.
    /// </summary>
    public class DHPublicKeySpec
    {
        public BigInteger P { get; }
        public BigInteger G { get; }
        public BigInteger Y { get; }

        public DHPublicKeySpec(BigInteger p, BigInteger g, BigInteger y)
        {
            P = p;
            G = g;
            Y = y;
        }
    }

    [TestFixture]
    public class DHPublicKeySpecAutoTest
    {
        [Test]
        public void GetP_test_5244()
        {
            // Use fixed values to simulate the original parameterized test
            var c0 = BigInteger.One;
            var c1 = new BigInteger(2);
            var c2 = new BigInteger(3);
            var instance = new DHPublicKeySpec(c0, c1, c2);
            var result = instance.P;
            // No assertion; method should execute without exception
        }

        [Test]
        public void GetG_test_5245()
        {
            var c0 = BigInteger.One;
            var c1 = new BigInteger(2);
            var c2 = new BigInteger(3);
            var instance = new DHPublicKeySpec(c0, c1, c2);
            var result = instance.G;
        }

        [Test]
        public void GetY_test_5246()
        {
            var c0 = BigInteger.One;
            var c1 = new BigInteger(2);
            var c2 = new BigInteger(3);
            var instance = new DHPublicKeySpec(c0, c1, c2);
            var result = instance.Y;
        }
    }
}
```