```csharp
using System;
using System.Linq;
using NUnit.Framework;

// ===== Equivalent C# classes =====

/// <summary>
/// Equivalent to Java's OpenMBeanParameterInfo (interface or concrete class).
/// We implement a simple class with name, description, and type for equality.
/// </summary>
public class OpenMBeanParameterInfo
{
    public string Name { get; }
    public string Description { get; }
    public string Type { get; }

    public OpenMBeanParameterInfo(string name, string description, string type)
    {
        Name = name;
        Description = description;
        Type = type;
    }

    public override bool Equals(object obj)
    {
        if (obj == this) return true;
        if (!(obj is OpenMBeanParameterInfo other)) return false;

        return string.Equals(Name, other.Name) &&
               string.Equals(Description, other.Description) &&
               string.Equals(Type, other.Type);
    }

    public override int GetHashCode()
    {
        unchecked
        {
            int hash = 17;
            hash = hash * 31 + (Name?.GetHashCode() ?? 0);
            hash = hash * 31 + (Description?.GetHashCode() ?? 0);
            hash = hash * 31 + (Type?.GetHashCode() ?? 0);
            return hash;
        }
    }

    public override string ToString()
    {
        return $"OpenMBeanParameterInfo(Name={Name}, Description={Description}, Type={Type})";
    }
}

/// <summary>
/// Equivalent to Java's OpenMBeanConstructorInfoSupport.
/// </summary>
public class OpenMBeanConstructorInfoSupport
{
    public string Name { get; }
    public string Description { get; }
    public OpenMBeanParameterInfo[] Signature { get; }

    public OpenMBeanConstructorInfoSupport(string name, string description, OpenMBeanParameterInfo[] signature)
    {
        Name = name;
        Description = description;
        Signature = signature ?? new OpenMBeanParameterInfo[0];
    }

    public override bool Equals(object obj)
    {
        if (obj == this) return true;
        if (!(obj is OpenMBeanConstructorInfoSupport other)) return false;

        return string.Equals(Name, other.Name) &&
               string.Equals(Description, other.Description) &&
               SignatureEquals(other.Signature);
    }

    private bool SignatureEquals(OpenMBeanParameterInfo[] otherSignature)
    {
        return Signature.Length == otherSignature.Length &&
               Signature.Zip(otherSignature, (a, b) => a.Equals(b)).All(x => x);
    }

    public override int GetHashCode()
    {
        unchecked
        {
            int hash = 17;
            hash = hash * 31 + (Name?.GetHashCode() ?? 0);
            hash = hash * 31 + (Description?.GetHashCode() ?? 0);
            hash = hash * 31 + GetSignatureHashCode();
            return hash;
        }
    }

    private int GetSignatureHashCode()
    {
        int hash = 0;
        foreach (var param in Signature)
            hash = hash * 31 + (param?.GetHashCode() ?? 0);
        return hash;
    }

    public override string ToString()
    {
        var sig = string.Join(", ", Signature.Select(p => p?.ToString() ?? "null"));
        return $"OpenMBeanConstructorInfoSupport(Name={Name}, Description={Description}, Signature=[{sig}])";
    }
}

// ===== Test class =====

public class OpenMBeanConstructorInfoSupportAutoTest
{
    // Note: The Java test methods have parameters. In C# NUnit we use TestCaseAttributes
    // with dummy values to make the methods executable. The original test did not specify
    // data – here we provide minimal placeholders.

    [TestCase(null, "", "", new OpenMBeanParameterInfo[0])]
    public void Equals_test_5757(object p0, string c0, string c1, OpenMBeanParameterInfo[] c2)
    {
        var instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
        instance.Equals(p0);
    }

    [TestCase("", "", new OpenMBeanParameterInfo[0])]
    public void ToString_test_5758(string c0, string c1, OpenMBeanParameterInfo[] c2)
    {
        var instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
        instance.ToString();
    }

    [TestCase("", "", new OpenMBeanParameterInfo[0])]
    public void HashCode_test_5759(string c0, string c1, OpenMBeanParameterInfo[] c2)
    {
        var instance = new OpenMBeanConstructorInfoSupport(c0, c1, c2);
        instance.GetHashCode();
    }
}
```