```csharp
using NUnit.Framework;

namespace Generated.Test
{
    public class InvalidClassExceptionAutoTest
    {
        [TestCase("anyString")]
        public void getMessage_test_1783(string c0)
        {
            var instance = new InvalidClassException(c0);
            instance.getMessage();
        }
    }

    public class InvalidClassException
    {
        private readonly string _message;

        public InvalidClassException(string message)
        {
            _message = message;
        }

        public string getMessage()
        {
            return _message;
        }
    }
}
```