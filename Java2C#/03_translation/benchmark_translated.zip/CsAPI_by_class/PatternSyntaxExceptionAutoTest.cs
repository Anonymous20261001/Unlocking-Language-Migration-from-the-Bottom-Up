```csharp
using System;
using System.Text.RegularExpressions;
using NUnit.Framework;

namespace generated.test
{
    // C# equivalent of java.util.regex.PatternSyntaxException
    public class PatternSyntaxException : Exception
    {
        private readonly string description;
        private readonly string pattern;
        private readonly int index;

        public PatternSyntaxException(string desc, string regex, int idx)
            : base(FormatMessage(desc, regex, idx))
        {
            description = desc;
            pattern = regex;
            index = idx;
        }

        public string GetDescription() => description;
        public string GetPattern() => pattern;
        public int GetIndex() => index;
        // GetMessage() is inherited from Exception and returns the formatted message

        private static string FormatMessage(string desc, string pattern, int idx)
        {
            // Replicates Java's PatternSyntaxException message format
            string caret = idx >= 0 ? new string(' ', Math.Min(idx, pattern.Length)) + "^" : "";
            return $"{desc} near index {idx}{Environment.NewLine}{pattern}{Environment.NewLine}{caret}";
        }
    }

    [TestFixture]
    public class PatternSyntaxExceptionAutoTest
    {
        [Test]
        public void GetDescription_test_5115()
        {
            var instance = new PatternSyntaxException("test desc", "abc", 0);
            instance.GetDescription();
        }

        [Test]
        public void GetPattern_test_5116()
        {
            var instance = new PatternSyntaxException("test desc", "abc", 0);
            instance.GetPattern();
        }

        [Test]
        public void GetMessage_test_5117()
        {
            var instance = new PatternSyntaxException("test desc", "abc", 0);
            instance.GetMessage();
        }

        [Test]
        public void GetIndex_test_5118()
        {
            var instance = new PatternSyntaxException("test desc", "abc", 0);
            instance.GetIndex();
        }
    }
}
```