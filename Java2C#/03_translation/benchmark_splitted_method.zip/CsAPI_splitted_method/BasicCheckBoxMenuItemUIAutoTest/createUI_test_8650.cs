using NUnit.Framework;

namespace Javax.Swing
{
    public class JComponent { }
    public class JMenuItem : JComponent { }
    public interface MenuElement { }
    public class MenuSelectionManager { }
}

namespace Java.Awt.Event
{
    public class MouseEvent { }
}

namespace Javax.Swing.Plaf.Basic
{
    public class BasicCheckBoxMenuItemUI
    {
        public static BasicCheckBoxMenuItemUI CreateUI(JComponent component)
        {
            // Stub implementation – returns a new instance.
            return new BasicCheckBoxMenuItemUI();
        }

        public void ProcessMouseEvent(JMenuItem item, MouseEvent mouseEvent, MenuElement[] path, MenuSelectionManager manager)
        {
            // Stub – no operation.
        }
    }
}

namespace Generated.Test
{
public class None
{
        [Test]
        public void CreateUI_test_8650()
        {
            BasicCheckBoxMenuItemUI instance = new BasicCheckBoxMenuItemUI();
            JComponent p0 = new JComponent();
            BasicCheckBoxMenuItemUI.CreateUI(p0);
        }
}
}
