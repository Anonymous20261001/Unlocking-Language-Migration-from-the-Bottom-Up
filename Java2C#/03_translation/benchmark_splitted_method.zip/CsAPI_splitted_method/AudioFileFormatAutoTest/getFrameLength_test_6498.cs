using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Tests
{
public class AudioFileFormatAutoTest
{
        [Test]
        public void GetFrameLength_Test_6498()
        {
            AudioFileFormatType type = AudioFileFormatType.Wave;
            AudioFormat format = new AudioFormat(44100f, 16, 2, true, false);
            int frameLength = 1000;
            AudioFileFormat instance = new AudioFileFormat(type, format, frameLength);
            instance.GetFrameLength();
        }
}
}
