using NUnit.Framework;

namespace Generated.Test
{
    // Minimal JComponent placeholder
    public class JComponent
    {
        // Not needed for this test but could hold properties for future use
    }

    // Equivalent of javax.swing.plaf.basic.BasicColorChooserUI
    public class BasicColorChooserUI
    {
        public void installUI(JComponent c)
        {
            // Implementation would go here; for testing, just a stub
        }

        public void uninstallUI(JComponent c)
        {
            // Implementation would go here; for testing, just a stub
        }

        public static BasicColorChooserUI createUI(JComponent c)
        {
            return new BasicColorChooserUI();
        }
    }

public class None
{
        [Test]
        public void UninstallUI_test_8655(JComponent p0)
        {
            BasicColorChooserUI instance = new BasicColorChooserUI();
            instance.uninstallUI(p0);
        }
}
}
