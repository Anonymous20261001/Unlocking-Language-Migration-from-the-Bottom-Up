using NUnit.Framework;
using System;

namespace Generated.Test
{
    public class AccessibleRelation
    {
        private string key;
        private object[] targets;

        public AccessibleRelation(string key)
        {
            this.key = key;
            this.targets = null;
        }

        public string GetKey()
        {
            return key;
        }

        public object GetTarget()
        {
            if (targets == null || targets.Length == 0)
                return null;
            return targets[0];
        }

        public void SetTarget(object target)
        {
            targets = new object[] { target };
        }

        public void SetTarget(object[] target)
        {
            targets = target;
        }
    }

public class None
{
        [Test]
        public void GetKey_test_5212()
        {
            AccessibleRelation instance = new AccessibleRelation("testKey");
            instance.GetKey();
        }
}
}
