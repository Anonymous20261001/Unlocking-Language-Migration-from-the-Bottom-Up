using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccessibleTests
{
    // Equivalent of javax.accessibility.AccessibleState
    public class AccessibleState : IEquatable<AccessibleState>
    {
        private readonly string _key;

        public static readonly AccessibleState ACTIVE = new AccessibleState("active");
        public static readonly AccessibleState FOCUSED = new AccessibleState("focused");
        public static readonly AccessibleState HORIZONTAL = new AccessibleState("horizontal");
        public static readonly AccessibleState VERTICAL = new AccessibleState("vertical");
        public static readonly AccessibleState SELECTED = new AccessibleState("selected");
        // Add other common states as needed

        public AccessibleState(string key)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Key must be non-null and non-empty", nameof(key));
            _key = key;
        }

        public string Key => _key;

        public override string ToString() => _key;

        public override bool Equals(object obj) => Equals(obj as AccessibleState);

        public bool Equals(AccessibleState other) =>
            other != null && string.Equals(_key, other._key, StringComparison.Ordinal);

        public override int GetHashCode() => _key.GetHashCode();

        public static bool operator ==(AccessibleState left, AccessibleState right) =>
            EqualityComparer<AccessibleState>.Default.Equals(left, right);

        public static bool operator !=(AccessibleState left, AccessibleState right) =>
            !(left == right);
    }

    // Equivalent of javax.accessibility.AccessibleStateSet
    public class AccessibleStateSet
    {
        private readonly HashSet<AccessibleState> _states = new HashSet<AccessibleState>();

        public bool Add(AccessibleState state)
        {
            if (state == null)
                throw new ArgumentNullException(nameof(state));
            return _states.Add(state);
        }

        public void AddAll(AccessibleState[] states)
        {
            if (states == null)
                throw new ArgumentNullException(nameof(states));
            foreach (var state in states)
            {
                Add(state);
            }
        }

        public bool Remove(AccessibleState state)
        {
            if (state == null)
                return false;
            return _states.Remove(state);
        }

        public void Clear()
        {
            _states.Clear();
        }

        public bool Contains(AccessibleState state)
        {
            if (state == null)
                return false;
            return _states.Contains(state);
        }

        public AccessibleState[] ToArray()
        {
            return _states.ToArray();
        }

        public override string ToString()
        {
            if (_states.Count == 0)
                return "[]";
            var sb = new StringBuilder("[");
            bool first = true;
            foreach (var state in _states)
            {
                if (!first)
                    sb.Append(",");
                sb.Append(state.ToString());
                first = false;
            }
            sb.Append("]");
            return sb.ToString();
        }
    }

public class None
{
        [Test]
        public void contains_test_5231()
        {
            AccessibleStateSet instance = new AccessibleStateSet();
            instance.Contains(AccessibleState.ACTIVE);
        }
}
}
