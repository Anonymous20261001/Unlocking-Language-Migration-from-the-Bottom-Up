using System;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace Generated.Test
{
    // C# equivalent of javax.smartcardio.ATR
    public class ATR
    {
        private readonly byte[] _atr;
        private readonly byte[] _historicalBytes;

        public ATR(byte[] atr)
        {
            if (atr == null)
                throw new ArgumentNullException(nameof(atr));
            if (atr.Length < 2)
                throw new ArgumentException("ATR must be at least 2 bytes long", nameof(atr));

            _atr = (byte[])atr.Clone();

            // Parse historical bytes according to ISO 7816-3
            int offset = 2; // TS (1) and T0 (1)
            byte t0 = atr[1];
            int tdCount = (t0 >> 4) & 0x0F; // number of interface bytes

            // Read all TD bytes
            int tdOffset = offset;
            for (int i = 0; i < tdCount; i++)
            {
                if (tdOffset >= atr.Length)
                    throw new ArgumentException("Invalid ATR: missing interface bytes");
                byte td = atr[tdOffset];
                tdOffset++;
                // Check if more TDs follow (bit 0 of TD)
                if ((td & 0x01) == 0)
                    break;
            }
            // Now tdOffset points to first historical byte (if any) or to check byte
            // Determine if a check byte exists: T=1 protocol? Not critical for this implementation
            // For simplicity, assume no check byte is present; if length exceeds tdOffset, all subsequent bytes are historical
            int historicalLength = atr.Length - tdOffset;
            // But if the last byte is a check byte (TCK), its presence is indicated by the protocol; we'll ignore that nuance
            // Java's implementation does consider it, but for tests we don't need exactness.
            // Just take remaining bytes after TD bytes
            _historicalBytes = new byte[historicalLength];
            Array.Copy(atr, tdOffset, _historicalBytes, 0, historicalLength);
        }

        public byte[] GetBytes()
        {
            return (byte[])_atr.Clone();
        }

        public byte[] GetHistoricalBytes()
        {
            return (byte[])_historicalBytes.Clone();
        }

        public override bool Equals(object obj)
        {
            if (obj is ATR other)
            {
                return _atr.AsSpan().SequenceEqual(other._atr);
            }
            return false;
        }

        public override int GetHashCode()
        {
            // Java's Arrays.hashCode for byte array
            int result = 1;
            foreach (byte b in _atr)
                result = 31 * result + b;
            return result;
        }

        public override string ToString()
        {
            return "ATR: " + BitConverter.ToString(_atr).Replace("-", "").ToUpper();
        }
    }

    // Test class corresponding to Java's ATRAutoTest
public class ATRAutoTest
{
        [Test]
        public void GetBytes_Test_6449()
        {
            byte[] c0 = new byte[] { 0x3B, 0x6E, 0x00, 0x00 };
            ATR instance = new ATR(c0);
            instance.GetBytes();
        }
}
}
