using System;
using System.Security;
using Xunit;

namespace Generated.Test
{
    // Minimal Permission class equivalent to java.security.Permission
    public class Permission
    {
        // In Java, Permission is abstract; we keep it simple for the test.
    }

    // Equivalent to java.security.AccessControlException
    public class AccessControlException : SecurityException
    {
        private Permission permission;

        public AccessControlException(string message) : base(message)
        {
            permission = null;
        }

        public AccessControlException(string message, Permission permission) : base(message)
        {
            this.permission = permission;
        }

        public Permission GetPermission()
        {
            return permission;
        }
    }

    // Test class translated from Java
public class AccessControlExceptionAutoTest
{
        [Fact]
        public void GetPermission_test_2678()
        {
            // Use a sample string as the message (Java parameter c0 is not provided in the test, so we use a literal)
            string c0 = "test message";
            var instance = new AccessControlException(c0);
            instance.GetPermission();
        }
}
}
