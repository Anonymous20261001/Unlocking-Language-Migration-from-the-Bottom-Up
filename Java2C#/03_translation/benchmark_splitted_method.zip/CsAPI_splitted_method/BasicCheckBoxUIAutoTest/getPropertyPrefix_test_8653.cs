using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.swing.JComponent
    public class JComponent
    {
        // Minimal stub – additional Swing behaviour is not required for these tests
    }

    // C# equivalent of javax.swing.plaf.basic.BasicCheckBoxUI
    public class BasicCheckBoxUI
    {
        public static BasicCheckBoxUI createUI(JComponent c)
        {
            return new BasicCheckBoxUI();
        }

        public virtual string getPropertyPrefix()
        {
            return "CheckBox.";
        }
    }

public class None
{
        [Test]
        public void getPropertyPrefix_test_8653()
        {
            BasicCheckBoxUI instance = new BasicCheckBoxUI();
            instance.getPropertyPrefix();
        }
}
}
