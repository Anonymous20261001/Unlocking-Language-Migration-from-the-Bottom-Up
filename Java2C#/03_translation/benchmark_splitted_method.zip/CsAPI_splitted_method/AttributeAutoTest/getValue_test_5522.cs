using NUnit.Framework;
using System;

namespace Generated.Test
{
public class None
{
        [Test]
        public void GetValue_Test_5522()
        {
            var instance = new Attribute("testName", new object());
            instance.GetValue();
        }
}
}
