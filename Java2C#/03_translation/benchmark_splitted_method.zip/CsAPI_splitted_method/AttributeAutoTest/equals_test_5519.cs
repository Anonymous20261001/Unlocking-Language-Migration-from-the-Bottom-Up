using NUnit.Framework;
using System;

namespace Generated.Test
{
public class None
{
        [Test]
        public void Equals_Test_5519()
        {
            var instance = new Attribute("testName", new object());
            instance.Equals(new object());
        }
}
}
