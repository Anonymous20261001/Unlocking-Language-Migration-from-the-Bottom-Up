using NUnit.Framework;
using System;

namespace Generated.Test
{
public class None
{
        [Test]
        public void GetName_Test_5518()
        {
            var instance = new Attribute("testName", new object());
            instance.GetName();
        }
}
}
