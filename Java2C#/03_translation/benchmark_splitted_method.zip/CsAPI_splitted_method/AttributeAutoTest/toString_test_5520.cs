using NUnit.Framework;
using System;

namespace Generated.Test
{
public class None
{
        [Test]
        public void ToString_Test_5520()
        {
            var instance = new Attribute("testName", new object());
            instance.ToString();
        }
}
}
