using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
    // Custom ArrayList class mimicking Java's ArrayList (raw type)
    public class ArrayList : IList<object>, ICollection<object>, IEnumerable<object>
    {
        private List<object> _list = new List<object>();

        // ---------- Constructors ----------
        public ArrayList() { }
        public ArrayList(ICollection<object> collection) { _list = new List<object>(collection); }
        public ArrayList(int initialCapacity) { _list = new List<object>(initialCapacity); }

        // ---------- List<T> implementation ----------
        public object this[int index]
        {
            get => _list[index];
            set => _list[index] = value;
        }

        public int Count => _list.Count;
        public bool IsReadOnly => false;

        public void Add(object item) => _list.Add(item);
        public void Clear() => _list.Clear();
        public bool Contains(object item) => _list.Contains(item);
        public void CopyTo(object[] array, int arrayIndex) => _list.CopyTo(array, arrayIndex);
        public IEnumerator<object> GetEnumerator() => _list.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => _list.GetEnumerator();
        public int IndexOf(object item) => _list.IndexOf(item);
        public void Insert(int index, object item) => _list.Insert(index, item);
        public bool Remove(object item) => _list.Remove(item);
        public void RemoveAt(int index) => _list.RemoveAt(index);

        // ---------- Additional Java ArrayList methods ----------

        // remove(int) overload (distinct from Remove(object))
        public object Remove(int index)
        {
            var removed = _list[index];
            _list.RemoveAt(index);
            return removed;
        }

        public int Size() => _list.Count;
        public bool IsEmpty() => _list.Count == 0;
        public int LastIndexOf(object item) => _list.LastIndexOf(item);

        public void Sort(IComparer<object> comparer)
        {
            _list.Sort(comparer);
        }

        // List.Sort also works with Comparison<object>
        public void Sort(Comparison<object> comparison)
        {
            _list.Sort(comparison);
        }

        public void ReplaceAll(Func<object, object> operatorFunc)
        {
            for (int i = 0; i < _list.Count; i++)
            {
                _list[i] = operatorFunc(_list[i]);
            }
        }

        public void ForEach(Action<object> action)
        {
            _list.ForEach(action);
        }

        public bool RemoveIf(Predicate<object> filter)
        {
            return _list.RemoveAll(filter) > 0;
        }

        public bool AddAll(ICollection<object> collection)
        {
            int oldCount = _list.Count;
            _list.AddRange(collection);
            return _list.Count != oldCount;
        }

        public bool AddAll(int index, ICollection<object> collection)
        {
            int oldCount = _list.Count;
            _list.InsertRange(index, collection);
            return _list.Count != oldCount;
        }

        public bool RemoveAll(ICollection<object> collection)
        {
            return _list.RemoveAll(x => collection.Contains(x)) > 0;
        }

        public bool RetainAll(ICollection<object> collection)
        {
            return _list.RemoveAll(x => !collection.Contains(x)) > 0;
        }

        public object[] ToArray()
        {
            return _list.ToArray();
        }

        public object[] ToArray(object[] array)
        {
            _list.CopyTo(array);
            return array;
        }

        public ArrayList SubList(int fromIndex, int toIndex)
        {
            var sub = new ArrayList();
            for (int i = fromIndex; i < toIndex; i++)
            {
                sub.Add(_list[i]);
            }
            return sub;
        }

        public void TrimToSize()
        {
            // No-op in this implementation (List<T> manages capacity)
        }

        public void EnsureCapacity(int minCapacity)
        {
            if (_list.Capacity < minCapacity)
                _list.Capacity = minCapacity;
        }

        public object Clone()
        {
            var cloned = new ArrayList();
            cloned._list = new List<object>(_list);
            return cloned;
        }

        public override bool Equals(object obj)
        {
            if (obj is ArrayList other)
            {
                return _list.SequenceEqual(other._list);
            }
            return false;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                foreach (var item in _list)
                {
                    hash = hash * 31 + (item?.GetHashCode() ?? 0);
                }
                return hash;
            }
        }

        // Java 21+ methods
        public object GetFirst()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            return _list[0];
        }

        public object GetLast()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            return _list[_list.Count - 1];
        }

        public void AddFirst(object item)
        {
            _list.Insert(0, item);
        }

        public void AddLast(object item)
        {
            _list.Add(item);
        }

        public object RemoveFirst()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            var removed = _list[0];
            _list.RemoveAt(0);
            return removed;
        }

        public object RemoveLast()
        {
            if (_list.Count == 0) throw new InvalidOperationException("List is empty");
            var removed = _list[_list.Count - 1];
            _list.RemoveAt(_list.Count - 1);
            return removed;
        }

        public IEnumerator<object> Iterator() => _list.GetEnumerator();

        // Spliterator not implemented (Java-specific), but we provide a stub
        public object Spliterator() => null;

        // ListIterator stubs (could implement if needed)
        public IEnumerator<object> ListIterator() => _list.GetEnumerator();
        public IEnumerator<object> ListIterator(int index)
        {
            if (index < 0 || index > _list.Count) throw new IndexOutOfRangeException();
            for (int i = index; i < _list.Count; i++)
                yield return _list[i];
        }
    }

    // Test class
public class None
{
        [Test]
        public void ListIterator_Test_3351()
        {
            ArrayList instance = new ArrayList();
            instance.ListIterator(0);
        }
}
}
