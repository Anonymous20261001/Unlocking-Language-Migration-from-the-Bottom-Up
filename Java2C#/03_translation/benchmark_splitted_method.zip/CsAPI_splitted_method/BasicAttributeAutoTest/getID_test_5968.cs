using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
public class BasicAttributeAutoTest
{
        [Test]
        public void GetID_Test_5968(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.GetID();
        }
}
}
