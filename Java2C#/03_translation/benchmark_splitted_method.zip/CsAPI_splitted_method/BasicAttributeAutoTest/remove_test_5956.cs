using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
public class BasicAttributeAutoTest
{
        [Test]
        public void Remove_Test_5956(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Remove(p0);
        }
}
}
