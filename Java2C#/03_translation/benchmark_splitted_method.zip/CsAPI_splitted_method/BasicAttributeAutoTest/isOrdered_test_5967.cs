using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
public class BasicAttributeAutoTest
{
        [Test]
        public void IsOrdered_Test_5967(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.IsOrdered();
        }
}
}
