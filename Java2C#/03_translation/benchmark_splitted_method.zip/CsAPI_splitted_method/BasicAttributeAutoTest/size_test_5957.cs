using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
public class BasicAttributeAutoTest
{
        [Test]
        public void Size_Test_5957(string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Size();
        }
}
}
