using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Generated.Test
{
public class BasicAttributeAutoTest
{
        [Test]
        public void Equals_Test_5958(object p0, string c0)
        {
            BasicAttribute instance = new BasicAttribute(c0);
            instance.Equals(p0);
        }
}
}
