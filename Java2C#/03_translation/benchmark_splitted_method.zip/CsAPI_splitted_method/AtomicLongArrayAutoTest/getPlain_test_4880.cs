using System;
using System.Threading;
using NUnit.Framework;

namespace EquivalentCSharp
{
    // C# equivalent of java.util.concurrent.atomic.AtomicLongArray
    public class AtomicLongArray
    {
        private readonly long[] array;

        public AtomicLongArray(int length)
        {
            if (length < 0)
                throw new ArgumentException("Negative array size");
            array = new long[length];
        }

        public int Length() => array.Length;

        public override string ToString()
        {
            return $"[{string.Join(", ", array)}]";
        }

        public long Get(int i) => Volatile.Read(ref array[i]);

        public void Set(int i, long newValue) => Volatile.Write(ref array[i], newValue);

        public long GetOpaque(int i) => Volatile.Read(ref array[i]);

        public void SetOpaque(int i, long newValue) => Volatile.Write(ref array[i], newValue);

        public long GetAcquire(int i)
        {
            long value = Volatile.Read(ref array[i]);
            Thread.MemoryBarrier(); // additional acquire fence (optional)
            return value;
        }

        public void SetRelease(int i, long newValue)
        {
            Thread.MemoryBarrier(); // release fence before store
            Volatile.Write(ref array[i], newValue);
        }

        public bool CompareAndSet(int i, long expected, long newValue)
        {
            return Interlocked.CompareExchange(ref array[i], newValue, expected) == expected;
        }

        public long CompareAndExchange(int i, long expected, long newValue)
        {
            return Interlocked.CompareExchange(ref array[i], newValue, expected);
        }

        public long CompareAndExchangeAcquire(int i, long expected, long newValue)
        {
            // Acquire semantics: same as normal CAS plus acquire barrier on success
            long old = Interlocked.CompareExchange(ref array[i], newValue, expected);
            if (old == expected)
                Thread.MemoryBarrier(); // ensure subsequent reads see the update
            return old;
        }

        public long CompareAndExchangeRelease(int i, long expected, long newValue)
        {
            // Release semantics: barrier before CAS
            Thread.MemoryBarrier();
            return Interlocked.CompareExchange(ref array[i], newValue, expected);
        }

        public bool WeakCompareAndSetPlain(int i, long expected, long newValue)
        {
            return CompareAndSet(i, expected, newValue); // simple CAS (may fail)
        }

        public bool WeakCompareAndSet(int i, long expected, long newValue)
        {
            return CompareAndSet(i, expected, newValue); // same as strong for simplicity
        }

        public bool WeakCompareAndSetAcquire(int i, long expected, long newValue)
        {
            return CompareAndSet(i, expected, newValue);
        }

        public bool WeakCompareAndSetRelease(int i, long expected, long newValue)
        {
            return CompareAndSet(i, expected, newValue);
        }

        public long GetAndSet(int i, long newValue)
        {
            return Interlocked.Exchange(ref array[i], newValue);
        }

        public long GetAndAdd(int i, long delta)
        {
            long oldVal;
            do
            {
                oldVal = Volatile.Read(ref array[i]);
            } while (Interlocked.CompareExchange(ref array[i], oldVal + delta, oldVal) != oldVal);
            return oldVal;
        }

        public long IncrementAndGet(int i) => Interlocked.Increment(ref array[i]);

        public long GetAndIncrement(int i) => Interlocked.Increment(ref array[i]) - 1;

        public long GetAndDecrement(int i) => Interlocked.Decrement(ref array[i]) + 1;

        public long DecrementAndGet(int i) => Interlocked.Decrement(ref array[i]);

        public long AddAndGet(int i, long delta) => Interlocked.Add(ref array[i], delta);

        public bool WeakCompareAndSetVolatile(int i, long expected, long newValue)
        {
            return CompareAndSet(i, expected, newValue);
        }

        public void LazySet(int i, long newValue) => Volatile.Write(ref array[i], newValue); // approximate

        public long GetAndUpdate(int i, Func<long, long> updateFunction)
        {
            long oldVal, newVal;
            do
            {
                oldVal = Volatile.Read(ref array[i]);
                newVal = updateFunction(oldVal);
            } while (Interlocked.CompareExchange(ref array[i], newVal, oldVal) != oldVal);
            return oldVal;
        }

        public long UpdateAndGet(int i, Func<long, long> updateFunction)
        {
            long oldVal, newVal;
            do
            {
                oldVal = Volatile.Read(ref array[i]);
                newVal = updateFunction(oldVal);
            } while (Interlocked.CompareExchange(ref array[i], newVal, oldVal) != oldVal);
            return newVal;
        }

        public long GetAndAccumulate(int i, long x, Func<long, long, long> accumulatorFunction)
        {
            long oldVal, newVal;
            do
            {
                oldVal = Volatile.Read(ref array[i]);
                newVal = accumulatorFunction(oldVal, x);
            } while (Interlocked.CompareExchange(ref array[i], newVal, oldVal) != oldVal);
            return oldVal;
        }

        public long AccumulateAndGet(int i, long x, Func<long, long, long> accumulatorFunction)
        {
            long oldVal, newVal;
            do
            {
                oldVal = Volatile.Read(ref array[i]);
                newVal = accumulatorFunction(oldVal, x);
            } while (Interlocked.CompareExchange(ref array[i], newVal, oldVal) != oldVal);
            return newVal;
        }

        public long GetPlain(int i) => array[i];

        public void SetPlain(int i, long newValue) => array[i] = newValue;
    }

    // Equivalent of the test class
public class None
{
        [Test]
        public void GetPlain_test_4880()
        {
            int p0 = DefaultIndex, c0 = DefaultLength;
            var instance = new AtomicLongArray(c0);
            instance.GetPlain(p0);
        }
}
}
