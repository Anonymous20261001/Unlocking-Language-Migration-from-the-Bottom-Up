using System;
using NUnit.Framework;

namespace Generated.Test
{
    // ------------------------------------------------------------
    // Stub implementations for Java AWT/Swing classes
    // ------------------------------------------------------------

    public class JComponent { }

    public abstract class AbstractButton : JComponent { }

    public class PropertyChangeEvent : EventArgs
    {
        public PropertyChangeEvent(object source, string propertyName, object oldValue, object newValue)
        {
            Source = source;
            PropertyName = propertyName;
            OldValue = oldValue;
            NewValue = newValue;
        }

        public object Source { get; }
        public string PropertyName { get; }
        public object OldValue { get; }
        public object NewValue { get; }
    }

    public class ChangeEvent : EventArgs
    {
        public ChangeEvent(object source)
        {
            Source = source;
        }

        public object Source { get; }
    }

    public class FocusEvent : EventArgs
    {
        public FocusEvent(object source, int id)
        {
            Source = source;
            Id = id;
        }

        public object Source { get; }
        public int Id { get; }
    }

    public class MouseEvent : EventArgs
    {
        public MouseEvent(object source, int id, long when, int modifiers, int x, int y, int clickCount, bool popupTrigger, int button)
        {
            Source = source;
            Id = id;
            When = when;
            Modifiers = modifiers;
            X = x;
            Y = y;
            ClickCount = clickCount;
            PopupTrigger = popupTrigger;
            Button = button;
        }

        public object Source { get; }
        public int Id { get; }
        public long When { get; }
        public int Modifiers { get; }
        public int X { get; }
        public int Y { get; }
        public int ClickCount { get; }
        public bool PopupTrigger { get; }
        public int Button { get; }
    }

    // ------------------------------------------------------------
    // BasicButtonListener – minimal stub matching Java API
    // ------------------------------------------------------------

    public class BasicButtonListener
    {
        private readonly AbstractButton _button;

        public BasicButtonListener(AbstractButton button)
        {
            _button = button;
        }

        public void PropertyChange(PropertyChangeEvent e) { /* stub */ }
        public void StateChanged(ChangeEvent e) { /* stub */ }
        public void InstallKeyboardActions(JComponent c) { /* stub */ }
        public void UninstallKeyboardActions(JComponent c) { /* stub */ }
        public void FocusGained(FocusEvent e) { /* stub */ }
        public void FocusLost(FocusEvent e) { /* stub */ }
        public void MousePressed(MouseEvent e) { /* stub */ }
        public void MouseReleased(MouseEvent e) { /* stub */ }
        public void MouseClicked(MouseEvent e) { /* stub */ }
        public void MouseExited(MouseEvent e) { /* stub */ }
        public void MouseEntered(MouseEvent e) { /* stub */ }
        public void MouseMoved(MouseEvent e) { /* stub */ }
        public void MouseDragged(MouseEvent e) { /* stub */ }
    }

    // ------------------------------------------------------------
    // Test class (NUnit)
    // ------------------------------------------------------------

public class None
{
        [Test]
        public void MousePressed_test_8633()
        {
            var p0 = new MouseEvent(new object(), 0, 0L, 0, 0, 0, 1, false, 0);
            var c0 = new ConcreteAbstractButton();
            var instance = new BasicButtonListener(c0);
            instance.MousePressed(p0);
        }
}
}
