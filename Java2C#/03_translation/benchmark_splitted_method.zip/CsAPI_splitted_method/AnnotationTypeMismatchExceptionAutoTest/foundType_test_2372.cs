using System;
using System.Reflection;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of java.lang.annotation.AnnotationTypeMismatchException.
    /// </summary>
    public class AnnotationTypeMismatchException : Exception
    {
        private readonly MethodInfo _element;
        private readonly string _foundType;

        public AnnotationTypeMismatchException(MethodInfo element, string foundType)
            : base($"Annotation type mismatch: element = {element?.Name}, foundType = {foundType}")
        {
            _element = element;
            _foundType = foundType;
        }

        /// <summary>Equivalent to Java's foundType() method.</summary>
        public string FoundType() => _foundType;

        /// <summary>Equivalent to Java's element() method.</summary>
        public MethodInfo Element() => _element;
    }

public class None
{
        [Test]
        public void FoundType_Test_2372()
        {
            // Create dummy MethodInfo and string as in the Java test
            MethodInfo c0 = typeof(object).GetMethod("ToString");
            string c1 = "java.lang.String";
            
            AnnotationTypeMismatchException instance = new AnnotationTypeMismatchException(c0, c1);
            instance.FoundType();
        }
}
}
