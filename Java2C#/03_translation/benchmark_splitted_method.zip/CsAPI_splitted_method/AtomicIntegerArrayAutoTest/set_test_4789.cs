using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    public class AtomicIntegerArray
    {
        private readonly int[] _array;

        public AtomicIntegerArray(int length)
        {
            _array = new int[length];
        }

        public int Length() => _array.Length;

        public override string ToString() => $"AtomicIntegerArray[{_array.Length}]";

        public int Get(int index) => Volatile.Read(ref _array[index]);

        public void Set(int index, int newValue) => Volatile.Write(ref _array[index], newValue);

        public int GetOpaque(int index) => Volatile.Read(ref _array[index]);

        public void SetOpaque(int index, int newValue) => Volatile.Write(ref _array[index], newValue);

        public int GetAcquire(int index) => Volatile.Read(ref _array[index]);

        public void SetRelease(int index, int newValue) => Volatile.Write(ref _array[index], newValue);

        public bool CompareAndSet(int index, int expected, int newValue)
        {
            return Interlocked.CompareExchange(ref _array[index], newValue, expected) == expected;
        }

        public int CompareAndExchange(int index, int expected, int newValue)
        {
            return Interlocked.CompareExchange(ref _array[index], newValue, expected);
        }

        public int CompareAndExchangeAcquire(int index, int expected, int newValue)
        {
            return CompareAndExchange(index, expected, newValue);
        }

        public int CompareAndExchangeRelease(int index, int expected, int newValue)
        {
            return CompareAndExchange(index, expected, newValue);
        }

        public bool WeakCompareAndSetPlain(int index, int expected, int newValue)
        {
            return CompareAndSet(index, expected, newValue);
        }

        public bool WeakCompareAndSet(int index, int expected, int newValue)
        {
            return CompareAndSet(index, expected, newValue);
        }

        public bool WeakCompareAndSetAcquire(int index, int expected, int newValue)
        {
            return CompareAndSet(index, expected, newValue);
        }

        public bool WeakCompareAndSetRelease(int index, int expected, int newValue)
        {
            return CompareAndSet(index, expected, newValue);
        }

        public int GetAndSet(int index, int newValue)
        {
            return Interlocked.Exchange(ref _array[index], newValue);
        }

        public int GetAndAdd(int index, int delta)
        {
            return Interlocked.Add(ref _array[index], delta) - delta;
        }

        public int IncrementAndGet(int index)
        {
            return Interlocked.Increment(ref _array[index]);
        }

        public bool WeakCompareAndSetVolatile(int index, int expected, int newValue)
        {
            return CompareAndSet(index, expected, newValue);
        }

        public void LazySet(int index, int newValue)
        {
            Volatile.Write(ref _array[index], newValue);
        }

        public int GetAndIncrement(int index)
        {
            int newVal = Interlocked.Increment(ref _array[index]);
            return newVal - 1;
        }

        public int GetAndDecrement(int index)
        {
            int newVal = Interlocked.Decrement(ref _array[index]);
            return newVal + 1;
        }

        public int DecrementAndGet(int index)
        {
            return Interlocked.Decrement(ref _array[index]);
        }

        public int AddAndGet(int index, int delta)
        {
            return Interlocked.Add(ref _array[index], delta);
        }

        public int GetAndUpdate(int index, Func<int, int> updater)
        {
            int old = Volatile.Read(ref _array[index]);
            int newVal = updater(old);
            while (Interlocked.CompareExchange(ref _array[index], newVal, old) != old)
            {
                old = Volatile.Read(ref _array[index]);
                newVal = updater(old);
            }
            return old;
        }

        public int UpdateAndGet(int index, Func<int, int> updater)
        {
            int old = Volatile.Read(ref _array[index]);
            int newVal = updater(old);
            while (Interlocked.CompareExchange(ref _array[index], newVal, old) != old)
            {
                old = Volatile.Read(ref _array[index]);
                newVal = updater(old);
            }
            return newVal;
        }

        public int GetAndAccumulate(int index, int x, Func<int, int, int> accumulator)
        {
            int old = Volatile.Read(ref _array[index]);
            int newVal = accumulator(old, x);
            while (Interlocked.CompareExchange(ref _array[index], newVal, old) != old)
            {
                old = Volatile.Read(ref _array[index]);
                newVal = accumulator(old, x);
            }
            return old;
        }

        public int AccumulateAndGet(int index, int x, Func<int, int, int> accumulator)
        {
            int old = Volatile.Read(ref _array[index]);
            int newVal = accumulator(old, x);
            while (Interlocked.CompareExchange(ref _array[index], newVal, old) != old)
            {
                old = Volatile.Read(ref _array[index]);
                newVal = accumulator(old, x);
            }
            return newVal;
        }

        public int GetPlain(int index) => _array[index];

        public void SetPlain(int index, int value) => _array[index] = value;
    }

public class None
{
        [Test]
        public void Set_test_4789()
        {
            AtomicIntegerArray instance = new AtomicIntegerArray(5);
            instance.Set(0, 42);
        }
}
}
