using NUnit.Framework;

namespace Generated.Test
{
    // Equivalent of javax.imageio.plugins.bmp.BMPImageWriteParam
    public class BMPImageWriteParam
    {
        private bool topDown;

        public void SetTopDown(bool value)
        {
            topDown = value;
        }

        public bool IsTopDown()
        {
            return topDown;
        }
    }

public class None
{
        [Test]
        public void SetTopDown_Test_5390(bool p0)
        {
            BMPImageWriteParam instance = new BMPImageWriteParam();
            instance.SetTopDown(p0);
        }
}
}
