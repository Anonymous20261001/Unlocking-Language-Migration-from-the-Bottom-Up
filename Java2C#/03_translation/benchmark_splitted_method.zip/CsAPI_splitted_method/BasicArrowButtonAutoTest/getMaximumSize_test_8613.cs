using System;
using System.Drawing;
using NUnit.Framework;

namespace GeneratedTest
{
    // C# equivalent of javax.swing.plaf.basic.BasicArrowButton
    public class BasicArrowButton
    {
        private int direction;

        public BasicArrowButton(int direction)
        {
            this.direction = direction;
        }

        public void SetDirection(int dir)
        {
            direction = dir;
        }

        public void PaintTriangle(Graphics g, int x, int y, int size, int direction, bool isEnabled)
        {
            // Stub implementation – does nothing, matching the original's no‑op in tests
        }

        public int GetDirection()
        {
            return direction;
        }

        public Size GetMaximumSize()
        {
            return Size.Empty; // arbitrary default
        }

        public void Paint(Graphics g)
        {
            // Stub – no actual painting
        }

        public Size GetPreferredSize()
        {
            return Size.Empty;
        }

        public Size GetMinimumSize()
        {
            return Size.Empty;
        }

        public bool IsFocusTraversable()
        {
            return true; // typical default for components
        }
    }

public class None
{
        [Test]
        public void GetMaximumSize_test_8613()
        {
            int c0 = 0;
            BasicArrowButton instance = new BasicArrowButton(c0);
            instance.GetMaximumSize();
        }
}
}
