using NUnit.Framework;
using System;
using System.Threading;

namespace Generated.Test
{
    // C# equivalent of Java's AtomicMarkableReference<T>
    public class AtomicMarkableReference<T> where T : class
    {
        private class Pair
        {
            public T Ref;
            public bool Mark;
        }

        private volatile Pair _pair;

        public AtomicMarkableReference(T initialRef, bool initialMark)
        {
            _pair = new Pair { Ref = initialRef, Mark = initialMark };
        }

        public bool IsMarked()
        {
            return _pair.Mark;
        }

        public T GetReference()
        {
            return _pair.Ref;
        }

        public T Get(bool[] markHolder)
        {
            Pair current = _pair;
            markHolder[0] = current.Mark;
            return current.Ref;
        }

        public bool AttemptMark(T expectedReference, bool newMark)
        {
            while (true)
            {
                Pair current = _pair;
                if (!ReferenceEquals(current.Ref, expectedReference))
                    return false;

                Pair updated = new Pair { Ref = current.Ref, Mark = newMark };
                Pair result = Interlocked.CompareExchange(ref _pair, updated, current);
                if (ReferenceEquals(result, current))
                    return true;
                // else CAS failed, retry
            }
        }

        public void Set(T newRef, bool newMark)
        {
            Pair updated = new Pair { Ref = newRef, Mark = newMark };
            Interlocked.Exchange(ref _pair, updated);
        }

        public bool CompareAndSet(T expectedRef, T newRef, bool expectedMark, bool newMark)
        {
            while (true)
            {
                Pair current = _pair;
                if (!ReferenceEquals(current.Ref, expectedRef) || current.Mark != expectedMark)
                    return false;

                Pair updated = new Pair { Ref = newRef, Mark = newMark };
                Pair result = Interlocked.CompareExchange(ref _pair, updated, current);
                if (ReferenceEquals(result, current))
                    return true;
                // retry
            }
        }

        public bool WeakCompareAndSet(T expectedRef, T newRef, bool expectedMark, bool newMark)
        {
            // Same as compareAndSet; memory ordering is not stricter in single-CPU typical case.
            return CompareAndSet(expectedRef, newRef, expectedMark, newMark);
        }
    }

public class None
{
        [Test]
        public void Get_test_4884(bool[] p0, object c0, bool c1)
        {
            var instance = new AtomicMarkableReference<object>(c0, c1);
            instance.Get(p0);
        }
}
}
