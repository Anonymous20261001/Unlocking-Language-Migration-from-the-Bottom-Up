using System;
using System.Threading;
using NUnit.Framework;

public class AtomicInteger
{
    private volatile int _value;

    public AtomicInteger() => _value = 0;

    public AtomicInteger(int initialValue) => _value = initialValue;

    public int Get() => _value;

    public void Set(int newValue) => _value = newValue;

    public override string ToString() => _value.ToString();

    public int IntValue() => _value;

    public long LongValue() => _value;

    public float FloatValue() => _value;

    public double DoubleValue() => _value;

    public int GetOpaque() => _value;

    public void SetOpaque(int newValue) => _value = newValue;

    public int GetAcquire() => _value;

    public void SetRelease(int newValue) => _value = newValue;

    public bool CompareAndSet(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }

    public int CompareAndExchange(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected);
    }

    public int CompareAndExchangeAcquire(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected);
    }

    public int CompareAndExchangeRelease(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected);
    }

    public bool WeakCompareAndSetPlain(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }

    public bool WeakCompareAndSet(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }

    public bool WeakCompareAndSetAcquire(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }

    public bool WeakCompareAndSetRelease(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }

    public int GetAndSet(int newValue)
    {
        return Interlocked.Exchange(ref _value, newValue);
    }

    public int GetAndAdd(int delta)
    {
        return Interlocked.Add(ref _value, delta) - delta;
    }

    public int IncrementAndGet()
    {
        return Interlocked.Increment(ref _value);
    }

    public int DecrementAndGet()
    {
        return Interlocked.Decrement(ref _value);
    }

    public int GetAndIncrement()
    {
        return IncrementAndGet() - 1;
    }

    public int GetAndDecrement()
    {
        return DecrementAndGet() + 1;
    }

    public int AddAndGet(int delta)
    {
        return Interlocked.Add(ref _value, delta);
    }

    public int GetAndUpdate(Func<int, int> updateFunction)
    {
        int current, newValue;
        do
        {
            current = _value;
            newValue = updateFunction(current);
        } while (Interlocked.CompareExchange(ref _value, newValue, current) != current);
        return current;
    }

    public int UpdateAndGet(Func<int, int> updateFunction)
    {
        int current, newValue;
        do
        {
            current = _value;
            newValue = updateFunction(current);
        } while (Interlocked.CompareExchange(ref _value, newValue, current) != current);
        return newValue;
    }

    public int GetAndAccumulate(int x, Func<int, int, int> accumulatorFunction)
    {
        int current, newValue;
        do
        {
            current = _value;
            newValue = accumulatorFunction(current, x);
        } while (Interlocked.CompareExchange(ref _value, newValue, current) != current);
        return current;
    }

    public int AccumulateAndGet(int x, Func<int, int, int> accumulatorFunction)
    {
        int current, newValue;
        do
        {
            current = _value;
            newValue = accumulatorFunction(current, x);
        } while (Interlocked.CompareExchange(ref _value, newValue, current) != current);
        return newValue;
    }

    // Relaxed ordering methods (plain/lazy) – for test purposes we use simple assignment
    public int GetPlain() => _value;
    public void SetPlain(int newValue) => _value = newValue;
    public void LazySet(int newValue) => _value = newValue;
    public bool WeakCompareAndSetVolatile(int expected, int update)
    {
        return Interlocked.CompareExchange(ref _value, update, expected) == expected;
    }
}

public class None
{
    [Test]
    public void weakCompareAndSetVolatile_test_4774()
    {
        AtomicInteger instance = new AtomicInteger();
        instance.WeakCompareAndSetVolatile(0, 1);
    }
}
