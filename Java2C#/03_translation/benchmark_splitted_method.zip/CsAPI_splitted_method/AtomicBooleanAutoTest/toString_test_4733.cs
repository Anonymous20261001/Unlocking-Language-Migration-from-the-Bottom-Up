using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    public class AtomicBoolean
    {
        private int _value; // 0 = false, 1 = true

        public AtomicBoolean() : this(false) { }

        public AtomicBoolean(bool initialValue)
        {
            Volatile.Write(ref _value, initialValue ? 1 : 0);
        }

        // --- get / set (volatile semantics) ---
        public bool Get() => Volatile.Read(ref _value) == 1;
        public void Set(bool newValue) => Volatile.Write(ref _value, newValue ? 1 : 0);

        // --- getOpaque / setOpaque (plain read/write with atomicity) ---
        public bool GetOpaque() => _value == 1;
        public void SetOpaque(bool newValue) => _value = newValue ? 1 : 0;

        // --- getAcquire / setRelease (acquire/release semantics) ---
        public bool GetAcquire()
        {
            int tmp = Volatile.Read(ref _value); // Volatile.Read provides acquire fence
            return tmp == 1;
        }
        public void SetRelease(bool newValue) => Volatile.Write(ref _value, newValue ? 1 : 0); // Volatile.Write provides release fence

        // --- compareAndSet ---
        public bool CompareAndSet(bool expected, bool update)
        {
            int expectedInt = expected ? 1 : 0;
            int updateInt = update ? 1 : 0;
            return Interlocked.CompareExchange(ref _value, updateInt, expectedInt) == expectedInt;
        }

        // --- compareAndExchange (returns old value) ---
        public bool CompareAndExchange(bool expected, bool update)
        {
            int expectedInt = expected ? 1 : 0;
            int updateInt = update ? 1 : 0;
            int old = Interlocked.CompareExchange(ref _value, updateInt, expectedInt);
            return old == 1;
        }

        // --- compareAndExchangeAcquire / Release (same as full CAS for simplicity) ---
        public bool CompareAndExchangeAcquire(bool expected, bool update) => CompareAndExchange(expected, update);
        public bool CompareAndExchangeRelease(bool expected, bool update) => CompareAndExchange(expected, update);

        // --- weakCompareAndSet variants (implement as regular CAS for test compatibility) ---
        public bool WeakCompareAndSetPlain(bool expected, bool update) => CompareAndSet(expected, update);
        public bool WeakCompareAndSet(bool expected, bool update) => CompareAndSet(expected, update);
        public bool WeakCompareAndSetAcquire(bool expected, bool update) => CompareAndSet(expected, update);
        public bool WeakCompareAndSetRelease(bool expected, bool update) => CompareAndSet(expected, update);
        public bool WeakCompareAndSetVolatile(bool expected, bool update) => CompareAndSet(expected, update);

        // --- getAndSet ---
        public bool GetAndSet(bool newValue)
        {
            int newInt = newValue ? 1 : 0;
            int old = Interlocked.Exchange(ref _value, newInt);
            return old == 1;
        }

        // --- lazySet (plain write, no ordering guarantees) ---
        public void LazySet(bool newValue) => _value = newValue ? 1 : 0;

        // --- getPlain / setPlain (plain read/write) ---
        public bool GetPlain() => _value == 1;
        public void SetPlain(bool newValue) => _value = newValue ? 1 : 0;

        // --- toString ---
        public override string ToString() => Get() ? "true" : "false";
    }

public class None
{
        [Test]
        public void ToString_test_4733()
        {
            var instance = new AtomicBoolean();
            instance.ToString();
        }
}
}
