using System;
using NUnit.Framework;

namespace Generated.Test
{
    // Minimal ByteBuffer that matches Java's ByteBuffer for update operations
    public class ByteBuffer
    {
        private readonly byte[] _buffer;
        private int _position;
        private int _limit;

        private ByteBuffer(byte[] buffer, int offset, int length)
        {
            _buffer = buffer;
            _position = offset;
            _limit = offset + length;
        }

        public int Remaining => _limit - _position;
        public bool HasRemaining => Remaining > 0;

        public byte Get()
        {
            if (_position >= _limit)
                throw new InvalidOperationException("Buffer underflow");
            return _buffer[_position++];
        }

        public static ByteBuffer Wrap(byte[] array, int offset, int length)
        {
            return new ByteBuffer(array, offset, length);
        }

        public static ByteBuffer Wrap(byte[] array)
        {
            return Wrap(array, 0, array.Length);
        }
    }

    // C# implementation of Adler32 matching Java's java.util.zip.Adler32
    public class Adler32
    {
        private const uint Mod = 65521;
        private uint _a = 1;
        private uint _b;

        public void Reset()
        {
            _a = 1;
            _b = 0;
        }

        public void Update(int byteVal)
        {
            uint val = (uint)(byteVal & 0xFF);
            _a = (_a + val) % Mod;
            _b = (_b + _a) % Mod;
        }

        public void Update(byte[] b, int off, int len)
        {
            for (int i = off; i < off + len; i++)
            {
                Update(b[i]);
            }
        }

        public void Update(ByteBuffer buffer)
        {
            while (buffer.HasRemaining)
            {
                Update(buffer.Get());
            }
        }

        public long GetValue()
        {
            // Java's getValue returns long (64-bit) with b in high 16 bits, a in low 16 bits
            return ((long)_b << 16) | _a;
        }
    }

    // Test class – each method corresponds to the Java @Test method
public class None
{
        [TestCase(0)]
        public void Update_test_5120(int p0)
        {
            var instance = new Adler32();
            instance.Update(p0);
        }
}
}
