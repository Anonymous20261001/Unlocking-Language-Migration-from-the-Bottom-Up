using NUnit.Framework;
using System;
using Javax.Management;

namespace Generated.Test
{
public class BadStringOperationExceptionAutoTest
{
        [Test]
        public void toString_test_5548(string c0)
        {
            BadStringOperationException instance = new BadStringOperationException(c0);
            instance.ToString();
        }
}
}
