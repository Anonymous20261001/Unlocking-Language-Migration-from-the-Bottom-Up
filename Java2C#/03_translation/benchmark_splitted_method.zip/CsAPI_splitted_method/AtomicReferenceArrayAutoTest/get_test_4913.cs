using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // Delegates to match Java's UnaryOperator and BinaryOperator (raw types -> object)
    public delegate object UnaryOperator(object operand);
    public delegate object BinaryOperator(object operand1, object operand2);

    // C# equivalent of java.util.concurrent.atomic.AtomicReferenceArray (raw type)
    public class AtomicReferenceArray
    {
        private readonly object[] array;

        public AtomicReferenceArray(int length)
        {
            if (length < 0)
                throw new ArgumentException("Length must be non-negative");
            array = new object[length];
        }

        public int Length() => array.Length;

        // Plain volatile get/set
        public object Get(int index) => Volatile.Read(ref array[index]);
        public void Set(int index, object newValue) => Volatile.Write(ref array[index], newValue);

        public override string ToString() => $"AtomicReferenceArray[{array.Length}]";

        // Opaque operations (no ordering guarantees)
        public object GetOpaque(int index) => array[index];
        public void SetOpaque(int index, object value) => array[index] = value;

        // Acquire/Release (use full volatile fence for simplicity)
        public object GetAcquire(int index) => Volatile.Read(ref array[index]);
        public void SetRelease(int index, object value) => Volatile.Write(ref array[index], value);

        // Compare-and-swap
        public bool CompareAndSet(int index, object expected, object newValue)
            => Interlocked.CompareExchange(ref array[index], newValue, expected) == expected;

        // Compare-and-exchange (returns old value)
        public object CompareAndExchange(int index, object expected, object newValue)
            => Interlocked.CompareExchange(ref array[index], newValue, expected);

        public object CompareAndExchangeAcquire(int index, object expected, object newValue)
            => CompareAndExchange(index, expected, newValue);

        public object CompareAndExchangeRelease(int index, object expected, object newValue)
            => CompareAndExchange(index, expected, newValue);

        // Weak CAS (may spuriously fail; implemented as strong CAS for simplicity)
        public bool WeakCompareAndSetPlain(int index, object expected, object newValue)
            => CompareAndSet(index, expected, newValue);

        public bool WeakCompareAndSet(int index, object expected, object newValue)
            => CompareAndSet(index, expected, newValue);

        public bool WeakCompareAndSetAcquire(int index, object expected, object newValue)
            => CompareAndSet(index, expected, newValue);

        public bool WeakCompareAndSetRelease(int index, object expected, object newValue)
            => CompareAndSet(index, expected, newValue);

        public bool WeakCompareAndSetVolatile(int index, object expected, object newValue)
            => CompareAndSet(index, expected, newValue);

        // Get and set (atomic exchange)
        public object GetAndSet(int index, object newValue)
            => Interlocked.Exchange(ref array[index], newValue);

        // Lazy set (use volatile write as approximation)
        public void LazySet(int index, object newValue)
            => Volatile.Write(ref array[index], newValue);

        // Get and update (retry loop)
        public object GetAndUpdate(int index, UnaryOperator updateFunction)
        {
            object oldValue, newValue;
            do
            {
                oldValue = Get(index);
                newValue = updateFunction(oldValue);
            } while (!CompareAndSet(index, oldValue, newValue));
            return oldValue;
        }

        public object UpdateAndGet(int index, UnaryOperator updateFunction)
        {
            object oldValue, newValue;
            do
            {
                oldValue = Get(index);
                newValue = updateFunction(oldValue);
            } while (!CompareAndSet(index, oldValue, newValue));
            return newValue;
        }

        // Get and accumulate
        public object GetAndAccumulate(int index, object x, BinaryOperator accumulatorFunction)
        {
            object oldValue, newValue;
            do
            {
                oldValue = Get(index);
                newValue = accumulatorFunction(oldValue, x);
            } while (!CompareAndSet(index, oldValue, newValue));
            return oldValue;
        }

        public object AccumulateAndGet(int index, object x, BinaryOperator accumulatorFunction)
        {
            object oldValue, newValue;
            do
            {
                oldValue = Get(index);
                newValue = accumulatorFunction(oldValue, x);
            } while (!CompareAndSet(index, oldValue, newValue));
            return newValue;
        }

        // Plain (unordered) get/set
        public object GetPlain(int index) => array[index];
        public void SetPlain(int index, object value) => array[index] = value;
    }

    // Test class (each method matches the Java @Test signatures, including parameters)
public class AtomicReferenceArrayAutoTest
{
        [Test]
        public void Get_test_4913(int p0, int c0)
        {
            var instance = new AtomicReferenceArray(c0);
            instance.Get(p0);
        }
}
}
