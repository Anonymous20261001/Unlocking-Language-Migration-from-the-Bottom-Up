using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Generated.Test
{
    // Minimal interface to mirror javax.swing.Action
    public interface IAction
    {
        // Action interface methods can be added here if needed
    }

    // C# equivalent of javax.swing.ActionMap
    public class ActionMap
    {
        private readonly Dictionary<object, IAction> _map = new Dictionary<object, IAction>();
        private ActionMap _parent;

        public void Remove(object key) => _map.Remove(key);

        public int Size() => _map.Count;

        public IAction Get(object key)
        {
            _map.TryGetValue(key, out IAction value);
            return value;
        }

        public void Put(object key, IAction action) => _map[key] = action;

        public void Clear() => _map.Clear();

        public ActionMap GetParent() => _parent;

        public object[] Keys() => _map.Keys.ToArray();

        public void SetParent(ActionMap map) => _parent = map;

        public object[] AllKeys()
        {
            var keys = new HashSet<object>(_map.Keys);
            if (_parent != null)
            {
                foreach (var key in _parent.AllKeys())
                    keys.Add(key);
            }
            return keys.ToArray();
        }
    }

public class None
{
        [Test]
        public void AllKeys_test_6538()
        {
            ActionMap instance = new ActionMap();
            instance.AllKeys();
        }
}
}
