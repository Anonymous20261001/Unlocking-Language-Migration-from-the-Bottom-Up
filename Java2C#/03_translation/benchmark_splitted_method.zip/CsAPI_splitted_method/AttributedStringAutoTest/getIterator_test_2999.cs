using System;
using System.Collections.Generic;
using System.Linq;

namespace AttributedStringTest
{
    // Mimics java.text.AttributedCharacterIterator.Attribute
    public abstract class Attribute : IEquatable<Attribute>
    {
        private readonly string _name;

        protected Attribute(string name)
        {
            _name = name;
        }

        public string Name => _name;

        public override bool Equals(object obj) => Equals(obj as Attribute);

        public bool Equals(Attribute other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return string.Equals(_name, other._name);
        }

        public override int GetHashCode() => _name?.GetHashCode() ?? 0;

        public override string ToString() => GetType().Name + "(" + _name + ")";

        // Some predefined attributes from Java
        public static readonly Attribute LANGUAGE = new SimpleAttribute("language");
        public static readonly Attribute READING = new SimpleAttribute("reading");
        public static readonly Attribute INPUT_METHOD_SEGMENT = new SimpleAttribute("input_method_segment");

        private class SimpleAttribute : Attribute
        {
            public SimpleAttribute(string name) : base(name) { }
        }
    }

    // Mimics java.text.AttributedCharacterIterator (minimal stub)
    public class AttributedCharacterIterator
    {
        // The nested Attribute class is already defined above.

        private readonly string _text;
        private readonly IReadOnlyList<(int begin, int end, Attribute attribute, object value)> _attributes;

        internal AttributedCharacterIterator(string text, IReadOnlyList<(int, int, Attribute, object)> attributes)
        {
            _text = text;
            _attributes = attributes;
        }

        // Minimal implementation – only enough to satisfy tests (not used in assertions)
        public int BeginIndex => 0;
        public int EndIndex => _text.Length;

        public IReadOnlyList<(int begin, int end, Attribute attribute, object value)> Attributes => _attributes;
    }

    // Mimics java.util.Map (minimal, non-generic)
    public class Map
    {
        private readonly Dictionary<Attribute, object> _inner = new Dictionary<Attribute, object>();

        public void Put(Attribute key, object value) => _inner[key] = value;
        public object Get(Attribute key) => _inner.TryGetValue(key, out var val) ? val : null;
        public bool ContainsKey(Attribute key) => _inner.ContainsKey(key);
        public void PutAll(Map other)
        {
            foreach (var kvp in other._inner)
                _inner[kvp.Key] = kvp.Value;
        }

        // For internal use
        internal IEnumerable<KeyValuePair<Attribute, object>> Entries => _inner;
    }

    // Mimics java.text.AttributedString
    public class AttributedString
    {
        private readonly string _text;
        private readonly List<(int begin, int end, Attribute attribute, object value)> _attributes = new List<(int, int, Attribute, object)>();

        public AttributedString(string text)
        {
            _text = text ?? throw new ArgumentNullException(nameof(text));
        }

        public void AddAttributes(Map attributes, int beginIndex, int endIndex)
        {
            if (attributes == null) throw new ArgumentNullException(nameof(attributes));
            if (beginIndex < 0 || beginIndex > endIndex || endIndex > _text.Length)
                throw new ArgumentException("Invalid range");

            foreach (var entry in attributes.Entries)
            {
                _attributes.Add((beginIndex, endIndex, entry.Key, entry.Value));
            }
        }

        public void AddAttribute(Attribute attribute, object value)
        {
            if (attribute == null) throw new ArgumentNullException(nameof(attribute));
            // In Java, this adds attribute to entire string (0, length)
            _attributes.Add((0, _text.Length, attribute, value));
        }

        public void AddAttribute(Attribute attribute, object value, int beginIndex, int endIndex)
        {
            if (attribute == null) throw new ArgumentNullException(nameof(attribute));
            if (beginIndex < 0 || beginIndex > endIndex || endIndex > _text.Length)
                throw new ArgumentException("Invalid range");
            _attributes.Add((beginIndex, endIndex, attribute, value));
        }

        public AttributedCharacterIterator GetIterator()
        {
            return new AttributedCharacterIterator(_text, _attributes.AsReadOnly());
        }

        public AttributedCharacterIterator GetIterator(Attribute[] attributes)
        {
            // Java returns iterator only for specified attributes
            var filtered = _attributes.Where(a => attributes.Contains(a.attribute)).ToList();
            return new AttributedCharacterIterator(_text, filtered.AsReadOnly());
        }

        public AttributedCharacterIterator GetIterator(Attribute[] attributes, int beginIndex, int endIndex)
        {
            if (beginIndex < 0 || beginIndex > endIndex || endIndex > _text.Length)
                throw new ArgumentException("Invalid range");

            var filtered = _attributes
                .Where(a => attributes.Contains(a.attribute) && a.begin >= beginIndex && a.end <= endIndex)
                .ToList();
            return new AttributedCharacterIterator(_text, filtered.AsReadOnly());
        }
    }

    // Test class – translates the Java test methods into C#
    using NUnit.Framework; // or use [TestMethod] for MSTest; adjust as needed

public class None
{
        [Test]
        public void GetIterator_Test_2999(string c0)
        {
            var instance = new AttributedString(c0);
            instance.GetIterator();
        }
}
}
