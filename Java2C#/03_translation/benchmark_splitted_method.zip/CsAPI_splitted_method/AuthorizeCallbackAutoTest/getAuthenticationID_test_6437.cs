using Xunit;

namespace Generated.Test
{
    /// <summary>
    /// C# equivalent of javax.security.sasl.AuthorizeCallback.
    /// </summary>
    public class AuthorizeCallback
    {
        private readonly string authenticationID;
        private readonly string authorizationID;
        private bool authorized;
        private string authorizedID;

        public AuthorizeCallback(string authnID, string authzID)
        {
            authenticationID = authnID;
            authorizationID = authzID;
            authorized = false;
            authorizedID = null;
        }

        public string GetAuthenticationID() => authenticationID;
        public string GetAuthorizationID() => authorizationID;
        public bool IsAuthorized() => authorized;
        public void SetAuthorized(bool authorized) => this.authorized = authorized;
        public string GetAuthorizedID() => authorizedID;
        public void SetAuthorizedID(string authorizedID) => this.authorizedID = authorizedID;
    }

public class AuthorizeCallbackAutoTest
{
        [Fact]
        public void GetAuthenticationID_test_6437()
        {
            var instance = new AuthorizeCallback("c0", "c1");
            instance.GetAuthenticationID();
        }
}
}
