using System;
using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // Custom implementation of Java's AtomicReference<T>
    public class AtomicReference<T> where T : class
    {
        private volatile object _value; // stored as object to support null

        public AtomicReference() : this(null) { }

        public AtomicReference(T initialValue)
        {
            _value = initialValue;
        }

        public T Get() => (T)Volatile.Read(ref _value);

        public void Set(T newValue) => Volatile.Write(ref _value, newValue);

        public override string ToString() => _value?.ToString() ?? "null";

        // Java 9+ memory order methods (simplified to full volatile semantics)
        public T GetOpaque() => Get();

        public void SetOpaque(T newValue) => Set(newValue);

        public T GetAcquire() => Get();

        public void SetRelease(T newValue) => Set(newValue);

        public bool CompareAndSet(T expected, T newValue)
        {
            return Interlocked.CompareExchange(ref _value, newValue, expected) == (object)expected;
        }

        public T CompareAndExchange(T expected, T newValue)
        {
            return (T)Interlocked.CompareExchange(ref _value, newValue, expected);
        }

        public T CompareAndExchangeAcquire(T expected, T newValue) => CompareAndExchange(expected, newValue);

        public T CompareAndExchangeRelease(T expected, T newValue) => CompareAndExchange(expected, newValue);

        // Weak CAS: implemented as strong CAS (in C# there is no weak CAS)
        public bool WeakCompareAndSetPlain(T expected, T newValue) => CompareAndSet(expected, newValue);

        public bool WeakCompareAndSet(T expected, T newValue) => CompareAndSet(expected, newValue);

        public bool WeakCompareAndSetAcquire(T expected, T newValue) => CompareAndSet(expected, newValue);

        public bool WeakCompareAndSetRelease(T expected, T newValue) => CompareAndSet(expected, newValue);

        public bool WeakCompareAndSetVolatile(T expected, T newValue) => CompareAndSet(expected, newValue);

        public T GetAndSet(T newValue) => (T)Interlocked.Exchange(ref _value, newValue);

        public void LazySet(T newValue) => Volatile.Write(ref _value, newValue); // release only? For test it's fine.

        public T GetAndUpdate(Func<T, T> updateFunction)
        {
            T old, newVal;
            do
            {
                old = Get();
                newVal = updateFunction(old);
            } while (!CompareAndSet(old, newVal));
            return old;
        }

        public T UpdateAndGet(Func<T, T> updateFunction)
        {
            T old, newVal;
            do
            {
                old = Get();
                newVal = updateFunction(old);
            } while (!CompareAndSet(old, newVal));
            return newVal;
        }

        public T GetAndAccumulate(T x, Func<T, T, T> accumulatorFunction)
        {
            T old, newVal;
            do
            {
                old = Get();
                newVal = accumulatorFunction(old, x);
            } while (!CompareAndSet(old, newVal));
            return old;
        }

        public T AccumulateAndGet(T x, Func<T, T, T> accumulatorFunction)
        {
            T old, newVal;
            do
            {
                old = Get();
                newVal = accumulatorFunction(old, x);
            } while (!CompareAndSet(old, newVal));
            return newVal;
        }

        // Plain memory access (no ordering guarantees)
        public T GetPlain() => (T)_value;

        public void SetPlain(T newValue) => _value = newValue;
    }

public class None
{
        [Test]
        public void GetAndSet_test_4904()
        {
            object p0 = null;
            var instance = new AtomicReference<object>();
            instance.GetAndSet(p0);
        }
}
}
