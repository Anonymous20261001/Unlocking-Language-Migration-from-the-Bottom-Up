using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Generated.Test
{
    // ---------- Stub classes to mimic java.awt.geom ----------

    public class Point2D
    {
        public static class Double
        {
            // Minimal implementation
            public double X { get; set; }
            public double Y { get; set; }

            public Double(double x, double y)
            {
                X = x;
                Y = y;
            }

            public Double() { }
        }
    }

    public class Rectangle2D
    {
        public static class Double
        {
            public double X { get; set; }
            public double Y { get; set; }
            public double Width { get; set; }
            public double Height { get; set; }

            public Double(double x, double y, double w, double h)
            {
                X = x;
                Y = y;
                Width = w;
                Height = h;
            }

            public Double() { }
        }
    }

    public class Rectangle : Rectangle2D
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public Rectangle(int x, int y, int w, int h)
        {
            X = x;
            Y = y;
            Width = w;
            Height = h;
        }

        public Rectangle() { }
    }

    public class AffineTransform
    {
        // Stub – no implementation
    }

    public class PathIterator
    {
        // Stub – minimal
    }

    public class Area
    {
        public Area()
        {
        }

        public void exclusiveOr(Area rhs)
        {
            throw new NotImplementedException();
        }

        public bool isPolygonal()
        {
            return false;
        }

        public bool isRectangular()
        {
            return false;
        }

        public bool isSingular()
        {
            return false;
        }

        public Area createTransformedArea(AffineTransform at)
        {
            return new Area();
        }

        public PathIterator getPathIterator(AffineTransform at)
        {
            return new PathIterator();
        }

        public PathIterator getPathIterator(AffineTransform at, double flatness)
        {
            return new PathIterator();
        }

        public Rectangle2D getBounds2D()
        {
            return new Rectangle2D.Double();
        }

        public void reset()
        {
            // noop
        }

        public override bool Equals(object obj)
        {
            // Stub – reference equality
            return ReferenceEquals(this, obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public Area Clone()
        {
            return new Area();
        }

        public bool isEmpty()
        {
            return false;
        }

        public void add(Area rhs)
        {
            throw new NotImplementedException();
        }

        public bool contains(Point2D p)
        {
            return false;
        }

        public bool contains(double x, double y, double w, double h)
        {
            return false;
        }

        public bool contains(double x, double y)
        {
            return false;
        }

        public bool contains(Rectangle2D r)
        {
            return false;
        }

        public void transform(AffineTransform at)
        {
            throw new NotImplementedException();
        }

        public Rectangle getBounds()
        {
            return new Rectangle();
        }

        public void subtract(Area rhs)
        {
            throw new NotImplementedException();
        }

        public bool intersects(Rectangle2D r)
        {
            return false;
        }

        public bool intersects(double x, double y, double w, double h)
        {
            return false;
        }

        public void intersect(Area rhs)
        {
            throw new NotImplementedException();
        }
    }

    // ---------- Test class ----------

public class None
{
        [Test]
        public void intersect_test_997(Area p0)
        {
            Area instance = new Area();
            instance.intersect(p0);
        }
}
}
