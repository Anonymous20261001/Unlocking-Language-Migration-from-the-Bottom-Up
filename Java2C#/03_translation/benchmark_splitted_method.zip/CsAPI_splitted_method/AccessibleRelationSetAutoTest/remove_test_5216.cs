using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace GeneratedTest
{
    public class AccessibleRelation
    {
        public string Key { get; }

        public AccessibleRelation(string key)
        {
            Key = key;
        }

        public override bool Equals(object obj)
        {
            return obj is AccessibleRelation other && Key == other.Key;
        }

        public override int GetHashCode()
        {
            return Key?.GetHashCode() ?? 0;
        }
    }

    public class AccessibleRelationSet
    {
        private readonly Dictionary<string, AccessibleRelation> _map = new Dictionary<string, AccessibleRelation>();

        public bool Add(AccessibleRelation relation)
        {
            if (_map.ContainsKey(relation.Key))
                return false;
            _map[relation.Key] = relation;
            return true;
        }

        public bool Remove(AccessibleRelation relation)
        {
            if (relation == null || !_map.ContainsKey(relation.Key))
                return false;
            _map.Remove(relation.Key);
            return true;
        }

        public AccessibleRelation Get(string key)
        {
            _map.TryGetValue(key, out var relation);
            return relation;
        }

        public bool Contains(string key)
        {
            return _map.ContainsKey(key);
        }

        public int Size()
        {
            return _map.Count;
        }

        public void Clear()
        {
            _map.Clear();
        }

        public AccessibleRelation[] ToArray()
        {
            return _map.Values.ToArray();
        }

        public bool AddAll(AccessibleRelation[] relations)
        {
            bool changed = false;
            foreach (var rel in relations)
            {
                changed |= Add(rel);
            }
            return changed;
        }

        public override string ToString()
        {
            return string.Join(", ", _map.Keys);
        }
    }

public class None
{
        [Test]
        public void Remove_test_5216()
        {
            AccessibleRelation p0 = new AccessibleRelation("testKey");
            AccessibleRelationSet instance = new AccessibleRelationSet();
            instance.Add(p0);
            instance.Remove(p0);
            Assert.AreEqual(0, instance.Size());
        }
}
}
