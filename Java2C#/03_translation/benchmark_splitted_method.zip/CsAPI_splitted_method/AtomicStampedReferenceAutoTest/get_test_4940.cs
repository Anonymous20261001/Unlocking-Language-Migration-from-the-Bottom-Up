using System.Threading;
using NUnit.Framework;

namespace Generated.Test
{
    // C# implementation of java.util.concurrent.atomic.AtomicStampedReference
    public class AtomicStampedReference
    {
        private class Box
        {
            public readonly object Reference;
            public readonly int Stamp;

            public Box(object reference, int stamp)
            {
                Reference = reference;
                Stamp = stamp;
            }
        }

        private volatile Box _box;

        public AtomicStampedReference(object initialRef, int initialStamp)
        {
            _box = new Box(initialRef, initialStamp);
        }

        public int GetStamp()
        {
            return _box.Stamp;
        }

        public bool AttemptStamp(object expectedReference, int newStamp)
        {
            while (true)
            {
                Box current = _box;
                if (current.Reference != expectedReference)
                    return false;

                Box newBox = new Box(current.Reference, newStamp);
                Box old = Interlocked.CompareExchange(ref _box, newBox, current);
                if (old == current)
                    return true;
                // retry
            }
        }

        public object Get(int[] stampHolder)
        {
            Box current = _box;
            stampHolder[0] = current.Stamp;
            return current.Reference;
        }

        public object GetReference()
        {
            return _box.Reference;
        }

        public void Set(object newReference, int newStamp)
        {
            _box = new Box(newReference, newStamp);
        }

        public bool CompareAndSet(object expectedReference, object newReference, int expectedStamp, int newStamp)
        {
            while (true)
            {
                Box current = _box;
                if (current.Reference != expectedReference || current.Stamp != expectedStamp)
                    return false;

                Box newBox = new Box(newReference, newStamp);
                Box old = Interlocked.CompareExchange(ref _box, newBox, current);
                if (old == current)
                    return true;
                // retry
            }
        }

        public bool WeakCompareAndSet(object expectedReference, object newReference, int expectedStamp, int newStamp)
        {
            // Simplified: same as CompareAndSet (may be weaker in practice, but sufficient for testing)
            return CompareAndSet(expectedReference, newReference, expectedStamp, newStamp);
        }
    }

public class None
{
        [Test]
        public void Get_test_4940(int[] p0, object c0, int c1)
        {
            AtomicStampedReference instance = new AtomicStampedReference(c0, c1);
            instance.Get(p0);
        }
}
}
