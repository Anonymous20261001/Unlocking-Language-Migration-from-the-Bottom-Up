using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetButtonBorder_test_8618()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetButtonBorder();
        }
}
}
