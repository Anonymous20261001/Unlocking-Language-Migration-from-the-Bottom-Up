using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetToggleButtonBorder_test_8620()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetToggleButtonBorder();
        }
}
}
