using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetTextFieldBorder_test_8624()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetTextFieldBorder();
        }
}
}
