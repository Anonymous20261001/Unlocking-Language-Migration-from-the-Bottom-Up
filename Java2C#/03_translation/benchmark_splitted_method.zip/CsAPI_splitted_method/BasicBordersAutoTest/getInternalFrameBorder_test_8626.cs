using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetInternalFrameBorder_test_8626()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetInternalFrameBorder();
        }
}
}
