using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetSplitPaneDividerBorder_test_8623()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetSplitPaneDividerBorder();
        }
}
}
