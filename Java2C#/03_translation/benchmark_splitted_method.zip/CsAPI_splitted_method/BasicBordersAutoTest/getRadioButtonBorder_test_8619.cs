using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetRadioButtonBorder_test_8619()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetRadioButtonBorder();
        }
}
}
