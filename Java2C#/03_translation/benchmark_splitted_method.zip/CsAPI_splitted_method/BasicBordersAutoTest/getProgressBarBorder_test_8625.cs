using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetProgressBarBorder_test_8625()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetProgressBarBorder();
        }
}
}
