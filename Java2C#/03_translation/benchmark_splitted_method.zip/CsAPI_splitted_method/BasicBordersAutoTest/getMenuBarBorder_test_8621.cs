using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetMenuBarBorder_test_8621()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetMenuBarBorder();
        }
}
}
