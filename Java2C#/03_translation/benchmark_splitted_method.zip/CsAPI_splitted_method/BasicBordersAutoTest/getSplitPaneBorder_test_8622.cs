using NUnit.Framework;
using System;

namespace generated.test
{
public class None
{
        [Test]
        public void GetSplitPaneBorder_test_8622()
        {
            BasicBorders instance = new BasicBorders();
            BasicBorders.GetSplitPaneBorder();
        }
}
}
