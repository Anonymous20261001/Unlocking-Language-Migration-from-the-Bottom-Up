using NUnit.Framework;

namespace Generated.Test
{
    // Stub classes to mimic Java Swing components and Graphics

    public class JComponent
    {
        // Minimal stub; actual Swing properties not needed for testing signatures
    }

    public class AbstractButton : JComponent
    {
        // Minimal stub
    }

    public class Graphics
    {
        // Minimal stub; Java's Graphics is abstract, we provide a concrete stub
    }

    public enum BaselineResizeBehavior
    {
        CONSTANT_ASCENT,
        CONSTANT_DESCENT,
        CENTER_OFFSET,
        OTHER
    }

    public class BasicButtonUI
    {
        public virtual void InstallUI(JComponent c)
        {
            // Stub implementation
        }

        public virtual void UninstallUI(JComponent c)
        {
            // Stub implementation
        }

        public static BasicButtonUI CreateUI(JComponent c)
        {
            // Static factory method returning a new instance
            return new BasicButtonUI();
        }

        public virtual int GetDefaultTextIconGap(AbstractButton b)
        {
            return 4; // default gap in Swing
        }

        public virtual object GetMaximumSize(JComponent c)
        {
            return null; // Would return Dimension in full implementation
        }

        public virtual void Paint(Graphics g, JComponent c)
        {
            // Stub implementation
        }

        public virtual object GetPreferredSize(JComponent c)
        {
            return null; // Would return Dimension
        }

        public virtual object GetMinimumSize(JComponent c)
        {
            return null; // Would return Dimension
        }

        public virtual int GetBaseline(JComponent c, int width, int height)
        {
            return 0;
        }

        public virtual BaselineResizeBehavior GetBaselineResizeBehavior(JComponent c)
        {
            return BaselineResizeBehavior.OTHER;
        }
    }

public class None
{
        [Test]
        public void GetDefaultTextIconGap_test_8643()
        {
            BasicButtonUI instance = new BasicButtonUI();
            AbstractButton p0 = new AbstractButton();
            instance.GetDefaultTextIconGap(p0);
        }
}
}
