using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

public class Attributes : ICloneable, IDictionary<object, object>
{
    private readonly Dictionary<object, object> _map = new Dictionary<object, object>();

    // Inner class Name (mirrors java.util.jar.Attributes.Name)
    public class Name : IEquatable<Name>
    {
        private readonly string _name;

        public Name(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("Name cannot be null or empty", nameof(name));
            _name = name;
        }

        public override bool Equals(object obj) => Equals(obj as Name);
        public bool Equals(Name other) => other != null && string.Equals(_name, other._name, StringComparison.Ordinal);
        public override int GetHashCode() => _name.GetHashCode();
        public override string ToString() => _name;

        // Utility: convert string to Name (if needed)
        public static implicit operator Name(string s) => new Name(s);
    }

    // IDictionary<object, object> implementation
    public object this[object key]
    {
        get => _map[key];
        set => _map[key] = value;
    }

    public ICollection<object> Keys => _map.Keys;
    public ICollection<object> Values => _map.Values;
    public int Count => _map.Count;
    public bool IsReadOnly => false;

    public void Add(object key, object value) => _map.Add(key, value);
    public void Add(KeyValuePair<object, object> item) => _map.Add(item.Key, item.Value);
    public void Clear() => _map.Clear();
    public bool Contains(KeyValuePair<object, object> item) => _map.Contains(item);
    public bool ContainsKey(object key) => _map.ContainsKey(key);
    public void CopyTo(KeyValuePair<object, object>[] array, int arrayIndex) => ((ICollection<KeyValuePair<object, object>>)_map).CopyTo(array, arrayIndex);
    public IEnumerator<KeyValuePair<object, object>> GetEnumerator() => _map.GetEnumerator();
    public bool Remove(object key) => _map.Remove(key);
    public bool Remove(KeyValuePair<object, object> item) => ((ICollection<KeyValuePair<object, object>>)_map).Remove(item);
    public bool TryGetValue(object key, out object value) => _map.TryGetValue(key, out value);
    IEnumerator IEnumerable.GetEnumerator() => _map.GetEnumerator();

    // Additional methods from Java Attributes
    public string GetValue(Name name)
    {
        if (_map.TryGetValue(name, out var val))
            return val?.ToString();
        return null;
    }

    public string GetValue(string name) => GetValue((Name)name);

    public string PutValue(string name, string value)
    {
        var key = new Name(name);
        var old = GetValue(key);
        _map[key] = value;
        return old;
    }

    public new bool Equals(object obj)
    {
        if (obj is Attributes other)
            return _map.SequenceEqual(other._map);
        return false;
    }

    public override int GetHashCode()
    {
        int hash = 17;
        foreach (var kvp in _map)
        {
            hash = hash * 31 + (kvp.Key?.GetHashCode() ?? 0);
            hash = hash * 31 + (kvp.Value?.GetHashCode() ?? 0);
        }
        return hash;
    }

    public object Clone()
    {
        var clone = new Attributes();
        foreach (var kvp in _map)
            clone._map.Add(kvp.Key, kvp.Value);
        return clone;
    }

    public bool IsEmpty() => _map.Count == 0;

    public ICollection<KeyValuePair<object, object>> EntrySet() => _map.ToList();
    public ICollection<object> KeySet() => _map.Keys;
    public ICollection<object> ValuesCollection() => _map.Values;  // distinct from Values property

    public bool ContainsValue(object value) => _map.ContainsValue(value);

    // PutAll (IDictionary parameter)
    public void PutAll(IDictionary<object, object> map)
    {
        foreach (var kvp in map)
            _map[kvp.Key] = kvp.Value;
    }
}

// Test class (mirrors the Java test file)
public class None
{
    [Test]
    public void Size_test_5037()
    {
        Attributes instance = new Attributes();
        int size = instance.Count;
    }
}
