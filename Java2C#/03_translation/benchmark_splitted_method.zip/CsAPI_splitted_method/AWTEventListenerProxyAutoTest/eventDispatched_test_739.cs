using System;
using NUnit.Framework;

// Dummy AWTEvent class for compatibility
public class AWTEvent
{
    // Minimal implementation for test purposes
}

// Equivalent to java.awt.event.AWTEventListener
public interface AWTEventListener
{
    void EventDispatched(AWTEvent e);
}

// Equivalent to java.awt.event.AWTEventListenerProxy
public class AWTEventListenerProxy : AWTEventListener
{
    private readonly long eventMask;
    private readonly AWTEventListener listener;

    public AWTEventListenerProxy(long eventMask, AWTEventListener listener)
    {
        this.eventMask = eventMask;
        this.listener = listener;
    }

    public void EventDispatched(AWTEvent e)
    {
        listener.EventDispatched(e);
    }

    public long GetEventMask()
    {
        return eventMask;
    }
}

public class None
{
    [Test]
    public void EventDispatched_test_739()
    {
        AWTEvent p0 = new AWTEvent();
        long c0 = 12345L;
        AWTEventListener c1 = new DummyListener();
        AWTEventListenerProxy instance = new AWTEventListenerProxy(c0, c1);
        instance.EventDispatched(p0);
    }
}
