using System;
using NUnit.Framework;

namespace Generated.Test
{
    /// <summary>
    /// Equivalent to javax.management.ValueExp
    /// </summary>
    public interface IValueExp
    {
        // Minimal interface – can be extended as needed
    }

    /// <summary>
    /// Simple concrete implementation of IValueExp for testing purposes.
    /// </summary>
    public class TestValueExp : IValueExp
    {
        public override string ToString() => "TestValueExp";
    }

    /// <summary>
    /// Equivalent to javax.management.BadBinaryOpValueExpException
    /// </summary>
    public class BadBinaryOpValueExpException : Exception
    {
        private readonly IValueExp _exp;

        public BadBinaryOpValueExpException(IValueExp exp)
        {
            _exp = exp;
        }

        public IValueExp GetExp()
        {
            return _exp;
        }

        public override string ToString()
        {
            return "BadBinaryOpValueExpException: " + (_exp?.ToString() ?? "null");
        }
    }

public class None
{
        [Test]
        public void ToString_test_5547()
        {
            IValueExp c0 = new TestValueExp();
            BadBinaryOpValueExpException instance = new BadBinaryOpValueExpException(c0);
            instance.ToString();
        }
}
}
