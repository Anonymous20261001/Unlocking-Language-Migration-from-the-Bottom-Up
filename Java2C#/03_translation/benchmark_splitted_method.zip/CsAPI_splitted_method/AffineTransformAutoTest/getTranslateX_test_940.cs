using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace GeneratedTest
{
    // Minimal Point2D class matching Java's java.awt.geom.Point2D
    public class Point2D
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Point2D() { }

        public Point2D(double x, double y)
        {
            X = x;
            Y = y;
        }

        public virtual void SetLocation(double x, double y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return $"Point2D[{X},{Y}]";
        }

        public override bool Equals(object obj)
        {
            if (obj is Point2D other)
                return X == other.X && Y == other.Y;
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(X, Y);
        }
    }

    // Minimal Shape class (stub) to allow compilation
    public class Shape
    {
        // No implementation needed for these tests
    }

    // Custom AffineTransform class mimicking Java's java.awt.geom.AffineTransform
    public class AffineTransform : ICloneable
    {
        private double m00, m10, m01, m11, m02, m12;

        // Constants for transformation type
        public const int TYPE_IDENTITY = 0;
        public const int TYPE_TRANSLATION = 1;
        public const int TYPE_UNIFORM_SCALE = 2;
        public const int TYPE_GENERAL_SCALE = 4;
        public const int TYPE_FLIP = 8;
        public const int TYPE_QUADRANT_ROTATION = 16;
        public const int TYPE_GENERAL_ROTATION = 32;
        public const int TYPE_GENERAL_TRANSFORM = 64;

        public AffineTransform()
        {
            SetToIdentity();
        }

        public AffineTransform(AffineTransform other)
        {
            m00 = other.m00;
            m10 = other.m10;
            m01 = other.m01;
            m11 = other.m11;
            m02 = other.m02;
            m12 = other.m12;
        }

        public AffineTransform(double m00, double m10, double m01, double m11, double m02, double m12)
        {
            this.m00 = m00;
            this.m10 = m10;
            this.m01 = m01;
            this.m11 = m11;
            this.m02 = m02;
            this.m12 = m12;
        }

        // --- Static factory methods ---
        public static AffineTransform GetRotateInstance(double theta)
        {
            AffineTransform at = new AffineTransform();
            at.SetToRotation(theta);
            return at;
        }

        public static AffineTransform GetRotateInstance(double theta, double anchorX, double anchorY)
        {
            AffineTransform at = new AffineTransform();
            at.SetToRotation(theta, anchorX, anchorY);
            return at;
        }

        public static AffineTransform GetRotateInstance(double vecX, double vecY)
        {
            AffineTransform at = new AffineTransform();
            at.SetToRotation(vecX, vecY);
            return at;
        }

        public static AffineTransform GetRotateInstance(double vecX, double vecY, double anchorX, double anchorY)
        {
            AffineTransform at = new AffineTransform();
            at.SetToRotation(vecX, vecY, anchorX, anchorY);
            return at;
        }

        public static AffineTransform GetQuadrantRotateInstance(int numQuadrants)
        {
            AffineTransform at = new AffineTransform();
            at.SetToQuadrantRotation(numQuadrants);
            return at;
        }

        public static AffineTransform GetQuadrantRotateInstance(int numQuadrants, double anchorX, double anchorY)
        {
            AffineTransform at = new AffineTransform();
            at.SetToQuadrantRotation(numQuadrants, anchorX, anchorY);
            return at;
        }

        public static AffineTransform GetScaleInstance(double sx, double sy)
        {
            AffineTransform at = new AffineTransform();
            at.SetToScale(sx, sy);
            return at;
        }

        public static AffineTransform GetShearInstance(double shx, double shy)
        {
            AffineTransform at = new AffineTransform();
            at.SetToShear(shx, shy);
            return at;
        }

        public static AffineTransform GetTranslateInstance(double tx, double ty)
        {
            AffineTransform at = new AffineTransform();
            at.SetToTranslation(tx, ty);
            return at;
        }

        // --- Instance 'setTo' methods ---
        public void SetToIdentity()
        {
            m00 = 1.0; m10 = 0.0;
            m01 = 0.0; m11 = 1.0;
            m02 = 0.0; m12 = 0.0;
        }

        public void SetToTranslation(double tx, double ty)
        {
            m00 = 1.0; m10 = 0.0;
            m01 = 0.0; m11 = 1.0;
            m02 = tx; m12 = ty;
        }

        public void SetToRotation(double theta)
        {
            double cos = Math.Cos(theta);
            double sin = Math.Sin(theta);
            m00 = cos; m10 = sin;
            m01 = -sin; m11 = cos;
            m02 = 0.0; m12 = 0.0;
        }

        public void SetToRotation(double theta, double anchorX, double anchorY)
        {
            SetToRotation(theta);
            double tx = anchorX * (1.0 - m00) + anchorY * m01;
            double ty = anchorY * (1.0 - m11) - anchorX * m10;
            m02 = tx;
            m12 = ty;
        }

        public void SetToRotation(double vecX, double vecY)
        {
            double len = Math.Sqrt(vecX * vecX + vecY * vecY);
            if (len == 0) { SetToIdentity(); return; }
            double cos = vecX / len;
            double sin = vecY / len;
            m00 = cos; m10 = sin;
            m01 = -sin; m11 = cos;
            m02 = 0.0; m12 = 0.0;
        }

        public void SetToRotation(double vecX, double vecY, double anchorX, double anchorY)
        {
            SetToRotation(vecX, vecY);
            double tx = anchorX * (1.0 - m00) + anchorY * m01;
            double ty = anchorY * (1.0 - m11) - anchorX * m10;
            m02 = tx;
            m12 = ty;
        }

        public void SetToQuadrantRotation(int numQuadrants)
        {
            double sin, cos;
            switch (numQuadrants & 3)
            {
                case 0: cos = 1.0; sin = 0.0; break;
                case 1: cos = 0.0; sin = 1.0; break;
                case 2: cos = -1.0; sin = 0.0; break;
                default: cos = 0.0; sin = -1.0; break;
            }
            m00 = cos; m10 = sin;
            m01 = -sin; m11 = cos;
            m02 = 0.0; m12 = 0.0;
        }

        public void SetToQuadrantRotation(int numQuadrants, double anchorX, double anchorY)
        {
            SetToQuadrantRotation(numQuadrants);
            double tx = anchorX * (1.0 - m00) + anchorY * m01;
            double ty = anchorY * (1.0 - m11) - anchorX * m10;
            m02 = tx;
            m12 = ty;
        }

        public void SetToScale(double sx, double sy)
        {
            m00 = sx; m10 = 0.0;
            m01 = 0.0; m11 = sy;
            m02 = 0.0; m12 = 0.0;
        }

        public void SetToShear(double shx, double shy)
        {
            m00 = 1.0; m10 = shy;
            m01 = shx; m11 = 1.0;
            m02 = 0.0; m12 = 0.0;
        }

        // --- Instance methods ---
        public double GetDeterminant()
        {
            return m00 * m11 - m01 * m10;
        }

        public double GetShearX()
        {
            return m01;
        }

        public double GetShearY()
        {
            return m10;
        }

        public double GetTranslateX()
        {
            return m02;
        }

        public double GetTranslateY()
        {
            return m12;
        }

        public double GetScaleX()
        {
            return m00;
        }

        public double GetScaleY()
        {
            return m11;
        }

        public int GetType()
        {
            int type = TYPE_IDENTITY;
            if (m02 != 0.0 || m12 != 0.0) type |= TYPE_TRANSLATION;
            double det = GetDeterminant();
            if (det < 0) type |= TYPE_FLIP;
            if (m01 != 0.0 || m10 != 0.0)
                type |= (m00 == m11) ? TYPE_GENERAL_ROTATION : TYPE_GENERAL_TRANSFORM;
            else
            {
                if (m00 != m11)
                    type |= TYPE_GENERAL_SCALE;
                else if (m00 != 1.0)
                    type |= TYPE_UNIFORM_SCALE;
            }
            return type;
        }

        public bool IsIdentity()
        {
            return m00 == 1.0 && m10 == 0.0 && m01 == 0.0 && m11 == 1.0 && m02 == 0.0 && m12 == 0.0;
        }

        public void GetMatrix(double[] flatmatrix)
        {
            flatmatrix[0] = m00;
            flatmatrix[1] = m10;
            flatmatrix[2] = m01;
            flatmatrix[3] = m11;
            flatmatrix[4] = m02;
            flatmatrix[5] = m12;
        }

        // --- Translation ---
        public void Translate(double tx, double ty)
        {
            m02 = tx * m00 + ty * m01 + m02;
            m12 = tx * m10 + ty * m11 + m12;
        }

        // --- Rotation ---
        public void Rotate(double theta)
        {
            double cos = Math.Cos(theta);
            double sin = Math.Sin(theta);
            double n00 = m00 * cos + m10 * sin;
            double n10 = -m00 * sin + m10 * cos;
            double n01 = m01 * cos + m11 * sin;
            double n11 = -m01 * sin + m11 * cos;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
        }

        public void Rotate(double theta, double anchorX, double anchorY)
        {
            Translate(anchorX, anchorY);
            Rotate(theta);
            Translate(-anchorX, -anchorY);
        }

        public void Rotate(double vecX, double vecY)
        {
            double len = Math.Sqrt(vecX * vecX + vecY * vecY);
            if (len == 0) return;
            double cos = vecX / len;
            double sin = vecY / len;
            double n00 = m00 * cos + m10 * sin;
            double n10 = -m00 * sin + m10 * cos;
            double n01 = m01 * cos + m11 * sin;
            double n11 = -m01 * sin + m11 * cos;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
        }

        public void Rotate(double vecX, double vecY, double anchorX, double anchorY)
        {
            Translate(anchorX, anchorY);
            Rotate(vecX, vecY);
            Translate(-anchorX, -anchorY);
        }

        // --- Quadrant rotation ---
        public void QuadrantRotate(int numQuadrants)
        {
            double sin, cos;
            switch (numQuadrants & 3)
            {
                case 0: cos = 1.0; sin = 0.0; break;
                case 1: cos = 0.0; sin = 1.0; break;
                case 2: cos = -1.0; sin = 0.0; break;
                default: cos = 0.0; sin = -1.0; break;
            }
            double n00 = m00 * cos + m10 * sin;
            double n10 = -m00 * sin + m10 * cos;
            double n01 = m01 * cos + m11 * sin;
            double n11 = -m01 * sin + m11 * cos;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
        }

        public void QuadrantRotate(int numQuadrants, double anchorX, double anchorY)
        {
            Translate(anchorX, anchorY);
            QuadrantRotate(numQuadrants);
            Translate(-anchorX, -anchorY);
        }

        // --- Scale ---
        public void Scale(double sx, double sy)
        {
            m00 *= sx;
            m10 *= sx;
            m01 *= sy;
            m11 *= sy;
        }

        // --- Shear ---
        public void Shear(double shx, double shy)
        {
            double n00 = m00 + m01 * shy;
            double n10 = m10 + m11 * shy;
            double n01 = m01 + m00 * shx;
            double n11 = m11 + m10 * shx;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
        }

        // --- Transform (single point) ---
        public void Transform(Point2D src, Point2D dst)
        {
            double x = src.X;
            double y = src.Y;
            dst.X = m00 * x + m01 * y + m02;
            dst.Y = m10 * x + m11 * y + m12;
        }

        // --- Transform (array overloads) ---
        public void Transform(double[] srcPts, int srcOff, double[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff++];
                double y = srcPts[srcOff++];
                dstPts[dstOff++] = m00 * x + m01 * y + m02;
                dstPts[dstOff++] = m10 * x + m11 * y + m12;
            }
        }

        public void Transform(double[] srcPts, int srcOff, float[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff++];
                double y = srcPts[srcOff++];
                dstPts[dstOff++] = (float)(m00 * x + m01 * y + m02);
                dstPts[dstOff++] = (float)(m10 * x + m11 * y + m12);
            }
        }

        public void Transform(float[] srcPts, int srcOff, double[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff++];
                double y = srcPts[srcOff++];
                dstPts[dstOff++] = m00 * x + m01 * y + m02;
                dstPts[dstOff++] = m10 * x + m11 * y + m12;
            }
        }

        public void Transform(float[] srcPts, int srcOff, float[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff++];
                double y = srcPts[srcOff++];
                dstPts[dstOff++] = (float)(m00 * x + m01 * y + m02);
                dstPts[dstOff++] = (float)(m10 * x + m11 * y + m12);
            }
        }

        public void Transform(Point2D[] srcPts, int srcOff, Point2D[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff + i].X;
                double y = srcPts[srcOff + i].Y;
                dstPts[dstOff + i].X = m00 * x + m01 * y + m02;
                dstPts[dstOff + i].Y = m10 * x + m11 * y + m12;
            }
        }

        // --- Delta transform ---
        public void DeltaTransform(double[] srcPts, int srcOff, double[] dstPts, int dstOff, int numPts)
        {
            for (int i = 0; i < numPts; i++)
            {
                double x = srcPts[srcOff++];
                double y = srcPts[srcOff++];
                dstPts[dstOff++] = m00 * x + m01 * y;
                dstPts[dstOff++] = m10 * x + m11 * y;
            }
        }

        public void DeltaTransform(Point2D src, Point2D dst)
        {
            double x = src.X;
            double y = src.Y;
            dst.X = m00 * x + m01 * y;
            dst.Y = m10 * x + m11 * y;
        }

        // --- Concatenate / preConcatenate ---
        public void Concatenate(AffineTransform tx)
        {
            double n00 = m00 * tx.m00 + m01 * tx.m10;
            double n01 = m00 * tx.m01 + m01 * tx.m11;
            double n02 = m00 * tx.m02 + m01 * tx.m12 + m02;
            double n10 = m10 * tx.m00 + m11 * tx.m10;
            double n11 = m10 * tx.m01 + m11 * tx.m11;
            double n12 = m10 * tx.m02 + m11 * tx.m12 + m12;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
            m02 = n02; m12 = n12;
        }

        public void PreConcatenate(AffineTransform tx)
        {
            double n00 = tx.m00 * m00 + tx.m01 * m10;
            double n01 = tx.m00 * m01 + tx.m01 * m11;
            double n02 = tx.m00 * m02 + tx.m01 * m12 + tx.m02;
            double n10 = tx.m10 * m00 + tx.m11 * m10;
            double n11 = tx.m10 * m01 + tx.m11 * m11;
            double n12 = tx.m10 * m02 + tx.m11 * m12 + tx.m12;
            m00 = n00; m10 = n10;
            m01 = n01; m11 = n11;
            m02 = n02; m12 = n12;
        }

        // --- SetTransform ---
        public void SetTransform(AffineTransform tx)
        {
            m00 = tx.m00; m10 = tx.m10;
            m01 = tx.m01; m11 = tx.m11;
            m02 = tx.m02; m12 = tx.m12;
        }

        public void SetTransform(double m00, double m10, double m01, double m11, double m02, double m12)
        {
            this.m00 = m00; this.m10 = m10;
            this.m01 = m01; this.m11 = m11;
            this.m02 = m02; this.m12 = m12;
        }

        // --- createTransformedShape (stub) ---
        public Shape CreateTransformedShape(Shape pSrc)
        {
            // For translation purposes, just return a new Shape (no real transformation)
            return new Shape();
        }

        // --- Object overrides ---
        public override bool Equals(object obj)
        {
            if (obj is AffineTransform other)
            {
                return m00 == other.m00 && m10 == other.m10 &&
                       m01 == other.m01 && m11 == other.m11 &&
                       m02 == other.m02 && m12 == other.m12;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(m00, m10, m01, m11, m02, m12);
        }

        public override string ToString()
        {
            return $"AffineTransform[[{m00}, {m01}, {m02}], [{m10}, {m11}, {m12}]]";
        }

        public object Clone()
        {
            return new AffineTransform(this);
        }
    }

    // Test class translated from the Java file
public class None
{
        [Test]
        public void GetTranslateX_test_940()
        {
            AffineTransform instance = new AffineTransform();
            instance.GetTranslateX();
        }
}
}
