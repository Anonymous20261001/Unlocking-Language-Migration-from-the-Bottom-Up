using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace JndiDirectory
{
    // Represents a single attribute (simplified version of javax.naming.directory.BasicAttribute)
    public class BasicAttribute : ICloneable
    {
        public string ID { get; }
        public object Value { get; set; }
        private List<object> _values = new List<object>();

        public BasicAttribute(string id)
        {
            ID = id ?? throw new ArgumentNullException(nameof(id));
        }

        public BasicAttribute(string id, object value) : this(id)
        {
            _values.Add(value);
            Value = value;
        }

        public bool IsEmpty => _values.Count == 0;

        public int Size => _values.Count;

        public void Add(object value)
        {
            _values.Add(value);
            if (Value == null) Value = value;
        }

        public override bool Equals(object obj)
        {
            if (obj is BasicAttribute other)
            {
                return string.Equals(ID, other.ID, StringComparison.OrdinalIgnoreCase) &&
                       _values.SequenceEqual(other._values);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ID.GetHashCode() ^ _values.GetHashCode();
        }

        public override string ToString()
        {
            return $"{ID}: {string.Join(",", _values)}";
        }

        public object Clone()
        {
            var clone = new BasicAttribute(ID);
            foreach (var v in _values)
                clone._values.Add(v);
            clone.Value = Value;
            return clone;
        }
    }

    // Represents javax.naming.directory.BasicAttributes
    public class BasicAttributes : ICloneable
    {
        private readonly bool _ignoreCase;
        private readonly Dictionary<string, BasicAttribute> _attributes;

        public BasicAttributes() : this(true) { }

        public BasicAttributes(bool ignoreCase)
        {
            _ignoreCase = ignoreCase;
            _attributes = new Dictionary<string, BasicAttribute>(
                _ignoreCase ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal
            );
        }

        public bool IsCaseIgnored => _ignoreCase;

        public IEnumerator<string> GetIDs()
        {
            return _attributes.Keys.GetEnumerator();
        }

        public BasicAttribute Remove(string attrID)
        {
            if (attrID == null) throw new ArgumentNullException(nameof(attrID));
            BasicAttribute removed = null;
            if (_attributes.TryGetValue(attrID, out removed))
            {
                _attributes.Remove(attrID);
            }
            return removed;
        }

        public int Size => _attributes.Count;

        public BasicAttribute Get(string attrID)
        {
            if (attrID == null) throw new ArgumentNullException(nameof(attrID));
            BasicAttribute attr = null;
            _attributes.TryGetValue(attrID, out attr);
            return attr;
        }

        public BasicAttribute Put(string attrID, object value)
        {
            if (attrID == null) throw new ArgumentNullException(nameof(attrID));
            var old = Get(attrID);
            var newAttr = new BasicAttribute(attrID, value);
            _attributes[attrID] = newAttr;
            return old;
        }

        public BasicAttribute Put(BasicAttribute attr)
        {
            if (attr == null) throw new ArgumentNullException(nameof(attr));
            var old = Get(attr.ID);
            _attributes[attr.ID] = attr;
            return old;
        }

        public IEnumerator<BasicAttribute> GetAll()
        {
            return _attributes.Values.GetEnumerator();
        }

        public override bool Equals(object obj)
        {
            if (obj is BasicAttributes other)
            {
                if (Size != other.Size || _ignoreCase != other._ignoreCase)
                    return false;

                foreach (var kvp in _attributes)
                {
                    var otherAttr = other.Get(kvp.Key);
                    if (otherAttr == null || !kvp.Value.Equals(otherAttr))
                        return false;
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = _ignoreCase.GetHashCode();
            foreach (var kvp in _attributes)
            {
                hash ^= kvp.Value.GetHashCode();
            }
            return hash;
        }

        public override string ToString()
        {
            return $"BasicAttributes: [{string.Join(", ", _attributes.Values)}]";
        }

        public object Clone()
        {
            var clone = new BasicAttributes(_ignoreCase);
            foreach (var kvp in _attributes)
            {
                clone._attributes[kvp.Key] = (BasicAttribute)kvp.Value.Clone();
            }
            return clone;
        }
    }
}

namespace Test
{
    using JndiDirectory;

public class BasicAttributesAutoTest
{
        [Fact]
        public void Size_test_5972()
        {
            var instance = new BasicAttributes();
            instance.Size();
        }
}
}
