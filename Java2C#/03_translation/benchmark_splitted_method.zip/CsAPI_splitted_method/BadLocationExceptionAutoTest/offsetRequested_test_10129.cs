using NUnit.Framework;
using System;

public class None
{
    [Test]
    public void OffsetRequested_Test_10129()
    {
        string c0 = "Test message";
        int c1 = 42;
        BadLocationException instance = new BadLocationException(c0, c1);
        instance.OffsetRequested();
    }
}
