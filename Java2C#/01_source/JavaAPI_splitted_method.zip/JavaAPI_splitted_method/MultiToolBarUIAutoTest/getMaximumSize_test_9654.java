package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void getMaximumSize_test_9654(JComponent p0) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.getMaximumSize(p0);
    }
}
