package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void contains_test_9661(JComponent p0, int p1, int p2) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.contains(p0, p1, p2);
    }
}
