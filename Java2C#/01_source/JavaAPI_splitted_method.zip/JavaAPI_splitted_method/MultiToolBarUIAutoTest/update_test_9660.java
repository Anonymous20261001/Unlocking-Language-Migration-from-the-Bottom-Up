package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void update_test_9660(Graphics p0, JComponent p1) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.update(p0, p1);
    }
}
