package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void paint_test_9655(Graphics p0, JComponent p1) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.paint(p0, p1);
    }
}
