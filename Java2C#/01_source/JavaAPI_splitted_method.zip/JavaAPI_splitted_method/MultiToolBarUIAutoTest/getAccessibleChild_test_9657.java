package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void getAccessibleChild_test_9657(JComponent p0, int p1) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.getAccessibleChild(p0, p1);
    }
}
