package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void getUIs_test_9652() {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.getUIs();
    }
}
