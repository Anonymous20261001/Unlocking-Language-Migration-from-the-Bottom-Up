package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {

    @Test
    public void createUI_test_9653(JComponent p0) {
      MultiToolBarUI instance = new MultiToolBarUI();
      MultiToolBarUI.createUI(p0);
    }
}
