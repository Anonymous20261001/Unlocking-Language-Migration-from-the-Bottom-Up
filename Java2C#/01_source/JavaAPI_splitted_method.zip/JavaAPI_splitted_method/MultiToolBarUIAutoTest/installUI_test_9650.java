package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiToolBarUI;
import org.junit.jupiter.api.Test;

public class MultiToolBarUIAutoTest {
    @Test
    public void installUI_test_9650(JComponent p0) {
      MultiToolBarUI instance = new MultiToolBarUI();
      instance.installUI(p0);
    }
}
