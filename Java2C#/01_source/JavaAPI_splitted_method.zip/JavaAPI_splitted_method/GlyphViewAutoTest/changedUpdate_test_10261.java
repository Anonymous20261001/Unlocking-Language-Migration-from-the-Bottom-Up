package generated.test;

import java.awt.Graphics;
import java.awt.Shape;
import javax.swing.event.DocumentEvent;
import javax.swing.text.Element;
import javax.swing.text.GlyphView;
import javax.swing.text.Position;
import javax.swing.text.TabExpander;
import javax.swing.text.ViewFactory;
import org.junit.jupiter.api.Test;

public class GlyphViewAutoTest {

    @Test
    public void changedUpdate_test_10261(DocumentEvent p0, Shape p1, ViewFactory p2, Element c0) {
      GlyphView instance = new GlyphView(c0);
      instance.changedUpdate(p0, p1, p2);
    }
}
