package generated.test;

import javax.accessibility.AccessibleResourceBundle;
import org.junit.jupiter.api.Test;

public class AccessibleResourceBundleAutoTest {
    @Test
    public void getContents_test_5225() {
      AccessibleResourceBundle instance = new AccessibleResourceBundle();
      instance.getContents();
    }
}
