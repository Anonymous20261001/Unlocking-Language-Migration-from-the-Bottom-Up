package generated.test;

import java.lang.Object;
import java.util.Collection;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.function.Consumer;
import java.util.function.Predicate;
import org.junit.jupiter.api.Test;

public class ConcurrentLinkedDequeAutoTest {

    @Test
    public void addLast_test_4264(Object p0) {
      ConcurrentLinkedDeque instance = new ConcurrentLinkedDeque();
      instance.addLast(p0);
    }
}
