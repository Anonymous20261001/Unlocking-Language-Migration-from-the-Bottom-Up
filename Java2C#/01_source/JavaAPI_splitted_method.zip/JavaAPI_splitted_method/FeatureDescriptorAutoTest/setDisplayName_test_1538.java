package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void setDisplayName_test_1538(String p0) {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.setDisplayName(p0);
    }
}
