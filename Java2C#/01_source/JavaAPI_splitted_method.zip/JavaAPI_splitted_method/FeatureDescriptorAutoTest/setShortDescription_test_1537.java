package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void setShortDescription_test_1537(String p0) {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.setShortDescription(p0);
    }
}
