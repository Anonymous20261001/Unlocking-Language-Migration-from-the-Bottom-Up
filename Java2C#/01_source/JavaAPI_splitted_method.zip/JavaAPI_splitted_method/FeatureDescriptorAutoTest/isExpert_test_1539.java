package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void isExpert_test_1539() {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.isExpert();
    }
}
