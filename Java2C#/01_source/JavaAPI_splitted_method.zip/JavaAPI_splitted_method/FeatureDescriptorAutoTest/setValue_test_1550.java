package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void setValue_test_1550(String p0, Object p1) {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.setValue(p0, p1);
    }
}
