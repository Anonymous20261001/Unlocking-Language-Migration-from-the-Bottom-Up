package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void setHidden_test_1541(boolean p0) {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.setHidden(p0);
    }
}
