package generated.test;

import java.beans.FeatureDescriptor;
import java.lang.Object;
import java.lang.String;
import org.junit.jupiter.api.Test;

public class FeatureDescriptorAutoTest {

    @Test
    public void setExpert_test_1540(boolean p0) {
      FeatureDescriptor instance = new FeatureDescriptor();
      instance.setExpert(p0);
    }
}
