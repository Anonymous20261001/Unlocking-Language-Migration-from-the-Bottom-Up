package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void standaloneSet_test_10940() {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.standaloneSet();
    }
}
