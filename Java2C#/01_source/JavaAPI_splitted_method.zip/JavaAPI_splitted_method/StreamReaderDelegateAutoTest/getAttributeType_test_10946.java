package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getAttributeType_test_10946(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getAttributeType(p0);
    }
}
