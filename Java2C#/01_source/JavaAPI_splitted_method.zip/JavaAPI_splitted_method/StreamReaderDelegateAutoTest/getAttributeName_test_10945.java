package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getAttributeName_test_10945(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getAttributeName(p0);
    }
}
