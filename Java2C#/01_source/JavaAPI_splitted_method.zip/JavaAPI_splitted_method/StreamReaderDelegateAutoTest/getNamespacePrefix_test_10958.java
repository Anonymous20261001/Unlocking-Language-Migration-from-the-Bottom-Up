package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getNamespacePrefix_test_10958(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getNamespacePrefix(p0);
    }
}
