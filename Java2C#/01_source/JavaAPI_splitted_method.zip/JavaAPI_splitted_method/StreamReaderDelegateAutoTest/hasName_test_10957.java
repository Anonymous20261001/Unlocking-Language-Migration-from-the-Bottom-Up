package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void hasName_test_10957() {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.hasName();
    }
}
