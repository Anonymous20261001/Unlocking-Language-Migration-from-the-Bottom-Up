package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getNamespaceURI_test_10920(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getNamespaceURI(p0);
    }
}
