package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void setParent_test_10954(XMLStreamReader p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.setParent(p0);
    }
}
