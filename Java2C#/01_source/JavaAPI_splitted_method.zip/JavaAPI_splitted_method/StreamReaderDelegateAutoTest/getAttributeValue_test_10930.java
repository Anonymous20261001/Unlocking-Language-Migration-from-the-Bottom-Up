package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getAttributeValue_test_10930(String p0, String p1) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getAttributeValue(p0, p1);
    }
}
