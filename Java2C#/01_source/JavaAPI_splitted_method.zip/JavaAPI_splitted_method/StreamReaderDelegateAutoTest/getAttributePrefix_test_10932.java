package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getAttributePrefix_test_10932(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getAttributePrefix(p0);
    }
}
