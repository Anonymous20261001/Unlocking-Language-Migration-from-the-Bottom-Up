package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getAttributeNamespace_test_10933(int p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getAttributeNamespace(p0);
    }
}
