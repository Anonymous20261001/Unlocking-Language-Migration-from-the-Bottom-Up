package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getProperty_test_10948(String p0) {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getProperty(p0);
    }
}
