package generated.test;

import java.lang.String;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.util.StreamReaderDelegate;
import org.junit.jupiter.api.Test;

public class StreamReaderDelegateAutoTest {

    @Test
    public void getEncoding_test_10951() {
      StreamReaderDelegate instance = new StreamReaderDelegate();
      instance.getEncoding();
    }
}
