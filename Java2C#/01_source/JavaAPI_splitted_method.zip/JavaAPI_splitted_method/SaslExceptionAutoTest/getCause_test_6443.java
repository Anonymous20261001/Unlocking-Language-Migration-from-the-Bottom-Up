package generated.test;

import java.lang.Throwable;
import javax.security.sasl.SaslException;
import org.junit.jupiter.api.Test;

public class SaslExceptionAutoTest {
    @Test
    public void getCause_test_6443() {
      SaslException instance = new SaslException();
      instance.getCause();
    }
}
