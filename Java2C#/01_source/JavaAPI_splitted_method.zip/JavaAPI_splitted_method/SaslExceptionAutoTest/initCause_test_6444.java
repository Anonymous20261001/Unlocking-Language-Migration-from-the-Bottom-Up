package generated.test;

import java.lang.Throwable;
import javax.security.sasl.SaslException;
import org.junit.jupiter.api.Test;

public class SaslExceptionAutoTest {

    @Test
    public void initCause_test_6444(Throwable p0) {
      SaslException instance = new SaslException();
      instance.initCause(p0);
    }
}
