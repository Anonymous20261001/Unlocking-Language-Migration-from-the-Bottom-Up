package generated.test;

import java.lang.Throwable;
import javax.security.sasl.SaslException;
import org.junit.jupiter.api.Test;

public class SaslExceptionAutoTest {

    @Test
    public void toString_test_6445() {
      SaslException instance = new SaslException();
      instance.toString();
    }
}
