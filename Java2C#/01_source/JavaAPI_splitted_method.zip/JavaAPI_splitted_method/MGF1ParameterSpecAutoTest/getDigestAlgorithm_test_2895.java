package generated.test;

import java.lang.String;
import java.security.spec.MGF1ParameterSpec;
import org.junit.jupiter.api.Test;

public class MGF1ParameterSpecAutoTest {
    @Test
    public void getDigestAlgorithm_test_2895(String c0) {
      MGF1ParameterSpec instance = new MGF1ParameterSpec(c0);
      instance.getDigestAlgorithm();
    }
}
