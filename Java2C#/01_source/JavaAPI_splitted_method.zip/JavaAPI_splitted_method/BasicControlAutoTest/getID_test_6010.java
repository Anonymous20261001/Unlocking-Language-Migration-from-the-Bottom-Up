package generated.test;

import java.lang.String;
import javax.naming.ldap.BasicControl;
import org.junit.jupiter.api.Test;

public class BasicControlAutoTest {

    @Test
    public void getID_test_6010(String c0) {
      BasicControl instance = new BasicControl(c0);
      instance.getID();
    }
}
