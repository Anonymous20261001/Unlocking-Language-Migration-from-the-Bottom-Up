package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {
    @Test
    public void spliterator_test_3600() {
      LinkedHashSet instance = new LinkedHashSet();
      instance.spliterator();
    }
}
