package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void reversed_test_3607() {
      LinkedHashSet instance = new LinkedHashSet();
      instance.reversed();
    }
}
