package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void newLinkedHashSet_test_3608(int p0) {
      LinkedHashSet instance = new LinkedHashSet();
      LinkedHashSet.newLinkedHashSet(p0);
    }
}
