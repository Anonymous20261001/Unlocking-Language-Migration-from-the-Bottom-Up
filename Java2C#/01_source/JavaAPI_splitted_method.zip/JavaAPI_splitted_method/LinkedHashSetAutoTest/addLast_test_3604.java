package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void addLast_test_3604(Object p0) {
      LinkedHashSet instance = new LinkedHashSet();
      instance.addLast(p0);
    }
}
