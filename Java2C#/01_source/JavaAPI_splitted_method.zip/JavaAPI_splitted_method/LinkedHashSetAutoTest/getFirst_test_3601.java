package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void getFirst_test_3601() {
      LinkedHashSet instance = new LinkedHashSet();
      instance.getFirst();
    }
}
