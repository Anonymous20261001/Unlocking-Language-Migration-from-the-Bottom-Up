package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void getLast_test_3602() {
      LinkedHashSet instance = new LinkedHashSet();
      instance.getLast();
    }
}
