package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void addFirst_test_3603(Object p0) {
      LinkedHashSet instance = new LinkedHashSet();
      instance.addFirst(p0);
    }
}
