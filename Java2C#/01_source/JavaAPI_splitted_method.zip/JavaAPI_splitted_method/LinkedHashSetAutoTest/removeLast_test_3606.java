package generated.test;

import java.lang.Object;
import java.util.LinkedHashSet;
import org.junit.jupiter.api.Test;

public class LinkedHashSetAutoTest {

    @Test
    public void removeLast_test_3606() {
      LinkedHashSet instance = new LinkedHashSet();
      instance.removeLast();
    }
}
