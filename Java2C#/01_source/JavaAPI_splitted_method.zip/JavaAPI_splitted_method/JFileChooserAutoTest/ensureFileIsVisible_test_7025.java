package generated.test;

import java.awt.event.ActionListener;
import java.io.File;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;
import org.junit.jupiter.api.Test;

public class JFileChooserAutoTest {

    @Test
    public void ensureFileIsVisible_test_7025(File p0) {
      JFileChooser instance = new JFileChooser();
      instance.ensureFileIsVisible(p0);
    }
}
