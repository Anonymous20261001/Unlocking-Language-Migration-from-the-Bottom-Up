package generated.test;

import java.awt.event.ActionListener;
import java.io.File;
import java.lang.String;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;
import org.junit.jupiter.api.Test;

public class JFileChooserAutoTest {

    @Test
    public void getUIClassID_test_7041() {
      JFileChooser instance = new JFileChooser();
      instance.getUIClassID();
    }
}
