package generated.test;

import java.awt.desktop.OpenFilesEvent;
import java.lang.String;
import java.util.List;
import org.junit.jupiter.api.Test;

public class OpenFilesEventAutoTest {
    @Test
    public void getSearchTerm_test_680(List c0, String c1) {
      OpenFilesEvent instance = new OpenFilesEvent(c0, c1);
      instance.getSearchTerm();
    }
}
