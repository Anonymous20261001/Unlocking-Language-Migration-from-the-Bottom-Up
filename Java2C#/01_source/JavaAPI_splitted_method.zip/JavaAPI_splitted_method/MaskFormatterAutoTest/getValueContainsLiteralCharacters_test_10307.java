package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void getValueContainsLiteralCharacters_test_10307() {
      MaskFormatter instance = new MaskFormatter();
      instance.getValueContainsLiteralCharacters();
    }
}
