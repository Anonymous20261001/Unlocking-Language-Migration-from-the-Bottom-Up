package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void getPlaceholderCharacter_test_10308() {
      MaskFormatter instance = new MaskFormatter();
      instance.getPlaceholderCharacter();
    }
}
