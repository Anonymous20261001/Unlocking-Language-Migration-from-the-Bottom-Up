package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void setPlaceholderCharacter_test_10314(char p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.setPlaceholderCharacter(p0);
    }
}
