package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void setValidCharacters_test_10309(String p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.setValidCharacters(p0);
    }
}
