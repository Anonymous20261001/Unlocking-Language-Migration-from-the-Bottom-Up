package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void getValidCharacters_test_10310() {
      MaskFormatter instance = new MaskFormatter();
      instance.getValidCharacters();
    }
}
