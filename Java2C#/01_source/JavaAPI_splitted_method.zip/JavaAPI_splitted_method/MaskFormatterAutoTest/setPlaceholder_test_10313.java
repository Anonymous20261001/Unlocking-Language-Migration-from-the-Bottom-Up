package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void setPlaceholder_test_10313(String p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.setPlaceholder(p0);
    }
}
