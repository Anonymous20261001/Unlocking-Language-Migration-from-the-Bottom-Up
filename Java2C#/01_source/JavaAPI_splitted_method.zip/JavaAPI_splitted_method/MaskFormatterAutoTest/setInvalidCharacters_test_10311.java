package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void setInvalidCharacters_test_10311(String p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.setInvalidCharacters(p0);
    }
}
