package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {

    @Test
    public void setValueContainsLiteralCharacters_test_10315(boolean p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.setValueContainsLiteralCharacters(p0);
    }
}
