package generated.test;

import java.lang.String;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;
import org.junit.jupiter.api.Test;

public class MaskFormatterAutoTest {
    @Test
    public void install_test_10305(JFormattedTextField p0) {
      MaskFormatter instance = new MaskFormatter();
      instance.install(p0);
    }
}
