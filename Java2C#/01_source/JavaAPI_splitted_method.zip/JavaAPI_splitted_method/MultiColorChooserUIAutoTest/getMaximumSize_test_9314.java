package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void getMaximumSize_test_9314(JComponent p0) {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      instance.getMaximumSize(p0);
    }
}
