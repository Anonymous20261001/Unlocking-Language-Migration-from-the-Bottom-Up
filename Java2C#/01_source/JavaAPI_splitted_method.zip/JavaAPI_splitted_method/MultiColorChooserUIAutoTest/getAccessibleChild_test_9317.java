package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void getAccessibleChild_test_9317(JComponent p0, int p1) {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      instance.getAccessibleChild(p0, p1);
    }
}
