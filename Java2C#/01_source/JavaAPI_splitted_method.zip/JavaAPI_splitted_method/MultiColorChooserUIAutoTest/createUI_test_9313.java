package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void createUI_test_9313(JComponent p0) {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      MultiColorChooserUI.createUI(p0);
    }
}
