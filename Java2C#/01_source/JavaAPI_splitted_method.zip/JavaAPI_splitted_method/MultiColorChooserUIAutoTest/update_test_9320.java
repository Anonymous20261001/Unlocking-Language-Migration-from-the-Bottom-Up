package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void update_test_9320(Graphics p0, JComponent p1) {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      instance.update(p0, p1);
    }
}
