package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void contains_test_9321(JComponent p0, int p1, int p2) {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      instance.contains(p0, p1, p2);
    }
}
