package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiColorChooserUI;
import org.junit.jupiter.api.Test;

public class MultiColorChooserUIAutoTest {

    @Test
    public void getUIs_test_9312() {
      MultiColorChooserUI instance = new MultiColorChooserUI();
      instance.getUIs();
    }
}
