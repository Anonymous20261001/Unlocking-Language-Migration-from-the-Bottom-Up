package generated.test;

import java.lang.Error;
import java.lang.String;
import javax.management.remote.JMXServerErrorException;
import org.junit.jupiter.api.Test;

public class JMXServerErrorExceptionAutoTest {
    @Test
    public void getCause_test_5839(String c0, Error c1) {
      JMXServerErrorException instance = new JMXServerErrorException(c0, c1);
      instance.getCause();
    }
}
