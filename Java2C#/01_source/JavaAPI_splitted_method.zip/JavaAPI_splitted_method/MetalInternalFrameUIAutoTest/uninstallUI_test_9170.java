package generated.test;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.plaf.metal.MetalInternalFrameUI;
import org.junit.jupiter.api.Test;

public class MetalInternalFrameUIAutoTest {

    @Test
    public void uninstallUI_test_9170(JComponent p0, JInternalFrame c0) {
      MetalInternalFrameUI instance = new MetalInternalFrameUI(c0);
      instance.uninstallUI(p0);
    }
}
