package generated.test;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.plaf.metal.MetalInternalFrameUI;
import org.junit.jupiter.api.Test;

public class MetalInternalFrameUIAutoTest {

    @Test
    public void createUI_test_9172(JComponent p0, JInternalFrame c0) {
      MetalInternalFrameUI instance = new MetalInternalFrameUI(c0);
      MetalInternalFrameUI.createUI(p0);
    }
}
