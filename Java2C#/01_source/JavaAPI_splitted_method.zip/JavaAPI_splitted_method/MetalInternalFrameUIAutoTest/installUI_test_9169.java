package generated.test;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.plaf.metal.MetalInternalFrameUI;
import org.junit.jupiter.api.Test;

public class MetalInternalFrameUIAutoTest {
    @Test
    public void installUI_test_9169(JComponent p0, JInternalFrame c0) {
      MetalInternalFrameUI instance = new MetalInternalFrameUI(c0);
      instance.installUI(p0);
    }
}
