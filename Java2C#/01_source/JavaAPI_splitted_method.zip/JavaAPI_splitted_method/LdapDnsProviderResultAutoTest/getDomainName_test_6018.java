package generated.test;

import java.lang.String;
import java.util.List;
import javax.naming.ldap.spi.LdapDnsProviderResult;
import org.junit.jupiter.api.Test;

public class LdapDnsProviderResultAutoTest {
    @Test
    public void getDomainName_test_6018(String c0, List c1) {
      LdapDnsProviderResult instance = new LdapDnsProviderResult(c0, c1);
      instance.getDomainName();
    }
}
