package generated.test;

import java.lang.String;
import java.util.List;
import javax.naming.ldap.spi.LdapDnsProviderResult;
import org.junit.jupiter.api.Test;

public class LdapDnsProviderResultAutoTest {

    @Test
    public void getEndpoints_test_6019(String c0, List c1) {
      LdapDnsProviderResult instance = new LdapDnsProviderResult(c0, c1);
      instance.getEndpoints();
    }
}
