package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobMediaSheets;
import org.junit.jupiter.api.Test;

public class JobMediaSheetsAutoTest {

    @Test
    public void equals_test_6144(Object p0, int c0) {
      JobMediaSheets instance = new JobMediaSheets(c0);
      instance.equals(p0);
    }
}
