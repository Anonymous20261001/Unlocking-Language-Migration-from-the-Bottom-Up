package generated.test;

import java.io.LineNumberReader;
import java.io.Reader;
import org.junit.jupiter.api.Test;

public class LineNumberReaderAutoTest {
    @Test
    public void getLineNumber_test_1787(Reader c0) {
      LineNumberReader instance = new LineNumberReader(c0);
      instance.getLineNumber();
    }
}
