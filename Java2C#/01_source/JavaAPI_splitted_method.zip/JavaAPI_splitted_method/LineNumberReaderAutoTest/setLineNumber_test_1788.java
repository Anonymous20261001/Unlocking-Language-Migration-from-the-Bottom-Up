package generated.test;

import java.io.LineNumberReader;
import java.io.Reader;
import org.junit.jupiter.api.Test;

public class LineNumberReaderAutoTest {

    @Test
    public void setLineNumber_test_1788(int p0, Reader c0) {
      LineNumberReader instance = new LineNumberReader(c0);
      instance.setLineNumber(p0);
    }
}
