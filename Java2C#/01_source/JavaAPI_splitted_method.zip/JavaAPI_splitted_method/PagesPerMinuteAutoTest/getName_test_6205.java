package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.PagesPerMinute;
import org.junit.jupiter.api.Test;

public class PagesPerMinuteAutoTest {

    @Test
    public void getName_test_6205(int c0) {
      PagesPerMinute instance = new PagesPerMinute(c0);
      instance.getName();
    }
}
