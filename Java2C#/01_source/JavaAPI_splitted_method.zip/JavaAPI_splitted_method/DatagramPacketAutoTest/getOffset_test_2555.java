package generated.test;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketAddress;
import org.junit.jupiter.api.Test;

public class DatagramPacketAutoTest {

    @Test
    public void getOffset_test_2555(byte[] c0, int c1) {
      DatagramPacket instance = new DatagramPacket(c0, c1);
      instance.getOffset();
    }
}
