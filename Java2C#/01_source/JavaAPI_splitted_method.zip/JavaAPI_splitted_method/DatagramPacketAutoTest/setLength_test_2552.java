package generated.test;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketAddress;
import org.junit.jupiter.api.Test;

public class DatagramPacketAutoTest {

    @Test
    public void setLength_test_2552(int p0, byte[] c0, int c1) {
      DatagramPacket instance = new DatagramPacket(c0, c1);
      instance.setLength(p0);
    }
}
