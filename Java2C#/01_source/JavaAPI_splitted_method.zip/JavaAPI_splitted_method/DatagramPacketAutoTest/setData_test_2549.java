package generated.test;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketAddress;
import org.junit.jupiter.api.Test;

public class DatagramPacketAutoTest {

    @Test
    public void setData_test_2549(byte[] p0, int p1, int p2, byte[] c0, int c1) {
      DatagramPacket instance = new DatagramPacket(c0, c1);
      instance.setData(p0, p1, p2);
    }
}
