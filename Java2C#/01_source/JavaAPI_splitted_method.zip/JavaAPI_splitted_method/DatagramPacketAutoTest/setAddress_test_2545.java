package generated.test;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketAddress;
import org.junit.jupiter.api.Test;

public class DatagramPacketAutoTest {
    @Test
    public void setAddress_test_2545(InetAddress p0, byte[] c0, int c1) {
      DatagramPacket instance = new DatagramPacket(c0, c1);
      instance.setAddress(p0);
    }
}
