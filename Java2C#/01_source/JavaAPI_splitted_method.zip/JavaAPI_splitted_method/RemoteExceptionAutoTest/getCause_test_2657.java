package generated.test;

import java.rmi.RemoteException;
import org.junit.jupiter.api.Test;

public class RemoteExceptionAutoTest {
    @Test
    public void getCause_test_2657() {
      RemoteException instance = new RemoteException();
      instance.getCause();
    }
}
