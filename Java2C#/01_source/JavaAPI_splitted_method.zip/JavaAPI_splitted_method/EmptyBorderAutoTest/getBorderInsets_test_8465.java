package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.EmptyBorder;
import org.junit.jupiter.api.Test;

public class EmptyBorderAutoTest {

    @Test
    public void getBorderInsets_test_8465(Component p0, Insets p1, Insets c0) {
      EmptyBorder instance = new EmptyBorder(c0);
      instance.getBorderInsets(p0, p1);
    }
}
