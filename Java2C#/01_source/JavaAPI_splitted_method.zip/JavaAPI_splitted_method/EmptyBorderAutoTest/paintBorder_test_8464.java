package generated.test;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.EmptyBorder;
import org.junit.jupiter.api.Test;

public class EmptyBorderAutoTest {
    @Test
    public void paintBorder_test_8464(Component p0, Graphics p1, int p2, int p3, int p4, int p5,
        Insets c0) {
      EmptyBorder instance = new EmptyBorder(c0);
      instance.paintBorder(p0, p1, p2, p3, p4, p5);
    }
}
