package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobImpressionsCompleted;
import org.junit.jupiter.api.Test;

public class JobImpressionsCompletedAutoTest {

    @Test
    public void equals_test_6129(Object p0, int c0) {
      JobImpressionsCompleted instance = new JobImpressionsCompleted(c0);
      instance.equals(p0);
    }
}
