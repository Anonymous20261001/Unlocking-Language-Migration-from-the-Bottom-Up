package generated.test;

import java.lang.Object;
import javax.print.attribute.standard.JobImpressionsCompleted;
import org.junit.jupiter.api.Test;

public class JobImpressionsCompletedAutoTest {
    @Test
    public void getCategory_test_6127(int c0) {
      JobImpressionsCompleted instance = new JobImpressionsCompleted(c0);
      instance.getCategory();
    }
}
