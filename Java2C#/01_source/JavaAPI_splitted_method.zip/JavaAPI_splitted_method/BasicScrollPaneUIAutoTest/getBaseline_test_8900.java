package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollPaneUI;
import org.junit.jupiter.api.Test;

public class BasicScrollPaneUIAutoTest {

    @Test
    public void getBaseline_test_8900(JComponent p0, int p1, int p2) {
      BasicScrollPaneUI instance = new BasicScrollPaneUI();
      instance.getBaseline(p0, p1, p2);
    }
}
