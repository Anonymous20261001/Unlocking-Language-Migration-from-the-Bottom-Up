package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollPaneUI;
import org.junit.jupiter.api.Test;

public class BasicScrollPaneUIAutoTest {

    @Test
    public void createUI_test_8897(JComponent p0) {
      BasicScrollPaneUI instance = new BasicScrollPaneUI();
      BasicScrollPaneUI.createUI(p0);
    }
}
