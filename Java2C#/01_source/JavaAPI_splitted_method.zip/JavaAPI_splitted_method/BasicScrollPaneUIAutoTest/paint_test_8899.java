package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollPaneUI;
import org.junit.jupiter.api.Test;

public class BasicScrollPaneUIAutoTest {

    @Test
    public void paint_test_8899(Graphics p0, JComponent p1) {
      BasicScrollPaneUI instance = new BasicScrollPaneUI();
      instance.paint(p0, p1);
    }
}
