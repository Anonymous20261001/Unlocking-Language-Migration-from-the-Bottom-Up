package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicScrollPaneUI;
import org.junit.jupiter.api.Test;

public class BasicScrollPaneUIAutoTest {
    @Test
    public void installUI_test_8895(JComponent p0) {
      BasicScrollPaneUI instance = new BasicScrollPaneUI();
      instance.installUI(p0);
    }
}
