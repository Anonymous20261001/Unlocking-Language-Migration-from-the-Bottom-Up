package generated.test;

import java.lang.String;
import java.nio.file.InvalidPathException;
import org.junit.jupiter.api.Test;

public class InvalidPathExceptionAutoTest {

    @Test
    public void getInput_test_2655(String c0, String c1) {
      InvalidPathException instance = new InvalidPathException(c0, c1);
      instance.getInput();
    }
}
