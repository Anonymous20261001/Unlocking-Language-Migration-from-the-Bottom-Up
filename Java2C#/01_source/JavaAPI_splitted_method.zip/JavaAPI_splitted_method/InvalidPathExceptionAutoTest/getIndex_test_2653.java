package generated.test;

import java.lang.String;
import java.nio.file.InvalidPathException;
import org.junit.jupiter.api.Test;

public class InvalidPathExceptionAutoTest {

    @Test
    public void getIndex_test_2653(String c0, String c1) {
      InvalidPathException instance = new InvalidPathException(c0, c1);
      instance.getIndex();
    }
}
