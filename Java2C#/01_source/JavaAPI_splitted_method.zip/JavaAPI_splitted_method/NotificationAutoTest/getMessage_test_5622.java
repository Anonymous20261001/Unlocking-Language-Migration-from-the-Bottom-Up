package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.Notification;
import org.junit.jupiter.api.Test;

public class NotificationAutoTest {

    @Test
    public void getMessage_test_5622(String c0, Object c1, long c2) {
      Notification instance = new Notification(c0, c1, c2);
      instance.getMessage();
    }
}
