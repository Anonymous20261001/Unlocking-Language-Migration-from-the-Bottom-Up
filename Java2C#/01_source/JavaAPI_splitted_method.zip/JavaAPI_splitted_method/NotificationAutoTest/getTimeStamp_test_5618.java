package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.management.Notification;
import org.junit.jupiter.api.Test;

public class NotificationAutoTest {

    @Test
    public void getTimeStamp_test_5618(String c0, Object c1, long c2) {
      Notification instance = new Notification(c0, c1, c2);
      instance.getTimeStamp();
    }
}
