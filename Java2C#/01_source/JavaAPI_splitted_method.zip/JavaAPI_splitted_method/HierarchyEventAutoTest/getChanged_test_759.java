package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.HierarchyEvent;
import org.junit.jupiter.api.Test;

public class HierarchyEventAutoTest {
    @Test
    public void getChanged_test_759(Component c0, int c1, Component c2, Container c3) {
      HierarchyEvent instance = new HierarchyEvent(c0, c1, c2, c3);
      instance.getChanged();
    }
}
