package generated.test;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalCheckBoxUI;
import org.junit.jupiter.api.Test;

public class MetalCheckBoxUIAutoTest {

    @Test
    public void installDefaults_test_9095(AbstractButton p0) {
      MetalCheckBoxUI instance = new MetalCheckBoxUI();
      instance.installDefaults(p0);
    }
}
