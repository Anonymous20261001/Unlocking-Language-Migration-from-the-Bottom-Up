package generated.test;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalCheckBoxUI;
import org.junit.jupiter.api.Test;

public class MetalCheckBoxUIAutoTest {

    @Test
    public void getPropertyPrefix_test_9094() {
      MetalCheckBoxUI instance = new MetalCheckBoxUI();
      instance.getPropertyPrefix();
    }
}
