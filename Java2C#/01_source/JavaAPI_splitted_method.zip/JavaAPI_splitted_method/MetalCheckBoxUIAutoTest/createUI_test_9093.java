package generated.test;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.plaf.metal.MetalCheckBoxUI;
import org.junit.jupiter.api.Test;

public class MetalCheckBoxUIAutoTest {
    @Test
    public void createUI_test_9093(JComponent p0) {
      MetalCheckBoxUI instance = new MetalCheckBoxUI();
      MetalCheckBoxUI.createUI(p0);
    }
}
