package generated.test;

import java.lang.String;
import java.nio.charset.UnsupportedCharsetException;
import org.junit.jupiter.api.Test;

public class UnsupportedCharsetExceptionAutoTest {
    @Test
    public void getCharsetName_test_2646(String c0) {
      UnsupportedCharsetException instance = new UnsupportedCharsetException(c0);
      instance.getCharsetName();
    }
}
