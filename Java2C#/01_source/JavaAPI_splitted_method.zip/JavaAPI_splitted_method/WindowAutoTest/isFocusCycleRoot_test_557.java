package generated.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Window;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.beans.PropertyChangeListener;
import java.lang.Class;
import java.lang.String;
import java.util.List;
import java.util.ResourceBundle;
import org.junit.jupiter.api.Test;

public class WindowAutoTest {

    @Test
    public void isFocusCycleRoot_test_557(Window c0) {
      Window instance = new Window(c0);
      instance.isFocusCycleRoot();
    }
}
