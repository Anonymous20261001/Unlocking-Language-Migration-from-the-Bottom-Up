package generated.test;

import java.lang.Object;
import javax.rmi.ssl.SslRMIClientSocketFactory;
import org.junit.jupiter.api.Test;

public class SslRMIClientSocketFactoryAutoTest {

    @Test
    public void hashCode_test_6255() {
      SslRMIClientSocketFactory instance = new SslRMIClientSocketFactory();
      instance.hashCode();
    }
}
