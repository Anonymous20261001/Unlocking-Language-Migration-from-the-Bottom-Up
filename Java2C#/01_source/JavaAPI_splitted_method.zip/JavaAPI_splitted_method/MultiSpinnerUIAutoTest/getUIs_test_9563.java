package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void getUIs_test_9563() {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.getUIs();
    }
}
