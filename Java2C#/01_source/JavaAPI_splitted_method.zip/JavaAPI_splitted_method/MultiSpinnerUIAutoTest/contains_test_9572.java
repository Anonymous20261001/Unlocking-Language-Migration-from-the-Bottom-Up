package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void contains_test_9572(JComponent p0, int p1, int p2) {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.contains(p0, p1, p2);
    }
}
