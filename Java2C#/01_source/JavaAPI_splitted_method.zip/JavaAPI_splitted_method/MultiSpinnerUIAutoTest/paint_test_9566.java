package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void paint_test_9566(Graphics p0, JComponent p1) {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.paint(p0, p1);
    }
}
