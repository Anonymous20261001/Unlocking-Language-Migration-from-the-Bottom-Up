package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void getPreferredSize_test_9569(JComponent p0) {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.getPreferredSize(p0);
    }
}
