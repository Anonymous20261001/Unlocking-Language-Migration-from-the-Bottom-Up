package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void getMaximumSize_test_9565(JComponent p0) {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.getMaximumSize(p0);
    }
}
