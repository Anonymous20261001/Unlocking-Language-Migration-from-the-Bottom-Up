package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiSpinnerUI;
import org.junit.jupiter.api.Test;

public class MultiSpinnerUIAutoTest {

    @Test
    public void getAccessibleChild_test_9568(JComponent p0, int p1) {
      MultiSpinnerUI instance = new MultiSpinnerUI();
      instance.getAccessibleChild(p0, p1);
    }
}
