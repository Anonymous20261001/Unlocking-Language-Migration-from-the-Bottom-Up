package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.script.SimpleBindings;
import org.junit.jupiter.api.Test;

public class SimpleBindingsAutoTest {

    @Test
    public void entrySet_test_6283() {
      SimpleBindings instance = new SimpleBindings();
      instance.entrySet();
    }
}
