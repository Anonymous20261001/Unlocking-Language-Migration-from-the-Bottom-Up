package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.script.SimpleBindings;
import org.junit.jupiter.api.Test;

public class SimpleBindingsAutoTest {

    @Test
    public void putAll_test_6284(Map p0) {
      SimpleBindings instance = new SimpleBindings();
      instance.putAll(p0);
    }
}
