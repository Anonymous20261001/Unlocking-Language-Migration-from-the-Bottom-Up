package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.script.SimpleBindings;
import org.junit.jupiter.api.Test;

public class SimpleBindingsAutoTest {

    @Test
    public void put_test_6279(String p0, Object p1) {
      SimpleBindings instance = new SimpleBindings();
      instance.put(p0, p1);
    }
}
