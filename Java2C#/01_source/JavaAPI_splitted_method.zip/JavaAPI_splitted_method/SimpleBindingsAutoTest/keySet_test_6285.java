package generated.test;

import java.lang.Object;
import java.lang.String;
import java.util.Map;
import javax.script.SimpleBindings;
import org.junit.jupiter.api.Test;

public class SimpleBindingsAutoTest {

    @Test
    public void keySet_test_6285() {
      SimpleBindings instance = new SimpleBindings();
      instance.keySet();
    }
}
