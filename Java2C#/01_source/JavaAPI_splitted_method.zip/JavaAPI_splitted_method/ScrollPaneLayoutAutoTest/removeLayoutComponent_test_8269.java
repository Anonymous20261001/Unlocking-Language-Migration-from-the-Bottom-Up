package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.lang.String;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;
import org.junit.jupiter.api.Test;

public class ScrollPaneLayoutAutoTest {

    @Test
    public void removeLayoutComponent_test_8269(Component p0) {
      ScrollPaneLayout instance = new ScrollPaneLayout();
      instance.removeLayoutComponent(p0);
    }
}
