package generated.test;

import java.awt.Component;
import java.awt.Container;
import java.lang.String;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;
import org.junit.jupiter.api.Test;

public class ScrollPaneLayoutAutoTest {

    @Test
    public void addLayoutComponent_test_8270(String p0, Component p1) {
      ScrollPaneLayout instance = new ScrollPaneLayout();
      instance.addLayoutComponent(p0, p1);
    }
}
