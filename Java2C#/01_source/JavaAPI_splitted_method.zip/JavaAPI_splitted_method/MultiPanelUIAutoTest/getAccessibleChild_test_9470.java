package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void getAccessibleChild_test_9470(JComponent p0, int p1) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.getAccessibleChild(p0, p1);
    }
}
