package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void uninstallUI_test_9464(JComponent p0) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.uninstallUI(p0);
    }
}
