package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {
    @Test
    public void installUI_test_9463(JComponent p0) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.installUI(p0);
    }
}
