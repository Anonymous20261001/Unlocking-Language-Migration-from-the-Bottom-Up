package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void getMaximumSize_test_9467(JComponent p0) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.getMaximumSize(p0);
    }
}
