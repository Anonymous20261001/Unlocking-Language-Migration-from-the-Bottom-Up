package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void getUIs_test_9465() {
      MultiPanelUI instance = new MultiPanelUI();
      instance.getUIs();
    }
}
