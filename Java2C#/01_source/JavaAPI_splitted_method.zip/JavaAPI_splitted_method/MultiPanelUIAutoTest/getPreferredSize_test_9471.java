package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void getPreferredSize_test_9471(JComponent p0) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.getPreferredSize(p0);
    }
}
