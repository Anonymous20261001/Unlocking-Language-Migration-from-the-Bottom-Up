package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void contains_test_9474(JComponent p0, int p1, int p2) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.contains(p0, p1, p2);
    }
}
