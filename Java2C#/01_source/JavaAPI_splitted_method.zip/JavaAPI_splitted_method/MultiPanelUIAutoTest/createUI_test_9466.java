package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void createUI_test_9466(JComponent p0) {
      MultiPanelUI instance = new MultiPanelUI();
      MultiPanelUI.createUI(p0);
    }
}
