package generated.test;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.plaf.multi.MultiPanelUI;
import org.junit.jupiter.api.Test;

public class MultiPanelUIAutoTest {

    @Test
    public void paint_test_9468(Graphics p0, JComponent p1) {
      MultiPanelUI instance = new MultiPanelUI();
      instance.paint(p0, p1);
    }
}
