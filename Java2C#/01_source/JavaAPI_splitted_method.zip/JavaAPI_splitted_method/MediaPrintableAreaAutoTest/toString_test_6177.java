package generated.test;

import java.lang.Object;
import java.lang.String;
import javax.print.attribute.standard.MediaPrintableArea;
import org.junit.jupiter.api.Test;

public class MediaPrintableAreaAutoTest {

    @Test
    public void toString_test_6177(int p0, String p1, float c0, float c1, float c2, float c3,
        int c4) {
      MediaPrintableArea instance = new MediaPrintableArea(c0, c1, c2, c3, c4);
      instance.toString(p0, p1);
    }
}
