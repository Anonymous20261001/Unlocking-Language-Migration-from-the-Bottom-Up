package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthScrollPaneUI;
import org.junit.jupiter.api.Test;

public class SynthScrollPaneUIAutoTest {

    @Test
    public void getContext_test_9890(JComponent p0) {
      SynthScrollPaneUI instance = new SynthScrollPaneUI();
      instance.getContext(p0);
    }
}
