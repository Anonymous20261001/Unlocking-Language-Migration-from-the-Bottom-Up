package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthScrollPaneUI;
import org.junit.jupiter.api.Test;

public class SynthScrollPaneUIAutoTest {

    @Test
    public void paintBorder_test_9886(SynthContext p0, Graphics p1, int p2, int p3, int p4, int p5) {
      SynthScrollPaneUI instance = new SynthScrollPaneUI();
      instance.paintBorder(p0, p1, p2, p3, p4, p5);
    }
}
