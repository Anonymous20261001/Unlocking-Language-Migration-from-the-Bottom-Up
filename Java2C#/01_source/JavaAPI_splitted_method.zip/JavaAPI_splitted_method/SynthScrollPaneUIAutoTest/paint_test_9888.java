package generated.test;

import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import javax.swing.JComponent;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthScrollPaneUI;
import org.junit.jupiter.api.Test;

public class SynthScrollPaneUIAutoTest {

    @Test
    public void paint_test_9888(Graphics p0, JComponent p1) {
      SynthScrollPaneUI instance = new SynthScrollPaneUI();
      instance.paint(p0, p1);
    }
}
