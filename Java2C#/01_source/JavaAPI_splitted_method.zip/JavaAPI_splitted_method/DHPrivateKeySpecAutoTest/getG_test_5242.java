package generated.test;

import java.math.BigInteger;
import javax.crypto.spec.DHPrivateKeySpec;
import org.junit.jupiter.api.Test;

public class DHPrivateKeySpecAutoTest {

    @Test
    public void getG_test_5242(BigInteger c0, BigInteger c1, BigInteger c2) {
      DHPrivateKeySpec instance = new DHPrivateKeySpec(c0, c1, c2);
      instance.getG();
    }
}
