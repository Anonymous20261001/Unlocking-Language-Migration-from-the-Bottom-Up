package generated.test;

import java.io.File;
import java.lang.ProcessBuilder;
import java.lang.String;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ProcessBuilderAutoTest {

    @Test
    public void redirectOutput_test_2048(ProcessBuilder.Redirect p0, List c0) {
      ProcessBuilder instance = new ProcessBuilder(c0);
      instance.redirectOutput(p0);
    }
}
