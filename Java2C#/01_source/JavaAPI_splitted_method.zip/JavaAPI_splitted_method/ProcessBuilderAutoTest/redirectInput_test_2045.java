package generated.test;

import java.io.File;
import java.lang.ProcessBuilder;
import java.lang.String;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ProcessBuilderAutoTest {

    @Test
    public void redirectInput_test_2045(ProcessBuilder.Redirect p0, List c0) {
      ProcessBuilder instance = new ProcessBuilder(c0);
      instance.redirectInput(p0);
    }
}
