package generated.test;

import java.io.File;
import java.lang.ProcessBuilder;
import java.lang.String;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ProcessBuilderAutoTest {

    @Test
    public void directory_test_2057(File p0, List c0) {
      ProcessBuilder instance = new ProcessBuilder(c0);
      instance.directory(p0);
    }
}
