package generated.test;

import java.io.File;
import java.lang.ProcessBuilder;
import java.lang.String;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ProcessBuilderAutoTest {

    @Test
    public void redirectError_test_2050(File p0, List c0) {
      ProcessBuilder instance = new ProcessBuilder(c0);
      instance.redirectError(p0);
    }
}
