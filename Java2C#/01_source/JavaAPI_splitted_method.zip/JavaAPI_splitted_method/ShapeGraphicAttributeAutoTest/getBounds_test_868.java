package generated.test;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.font.ShapeGraphicAttribute;
import java.awt.geom.AffineTransform;
import java.lang.Object;
import org.junit.jupiter.api.Test;

public class ShapeGraphicAttributeAutoTest {

    @Test
    public void getBounds_test_868(Shape c0, int c1, boolean c2) {
      ShapeGraphicAttribute instance = new ShapeGraphicAttribute(c0, c1, c2);
      instance.getBounds();
    }
}
