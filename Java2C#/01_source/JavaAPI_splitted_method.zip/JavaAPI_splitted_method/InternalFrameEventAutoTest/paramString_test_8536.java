package generated.test;

import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameEvent;
import org.junit.jupiter.api.Test;

public class InternalFrameEventAutoTest {

    @Test
    public void paramString_test_8536(JInternalFrame c0, int c1) {
      InternalFrameEvent instance = new InternalFrameEvent(c0, c1);
      instance.paramString();
    }
}
