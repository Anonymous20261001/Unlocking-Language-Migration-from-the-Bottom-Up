package generated.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.lang.Object;
import javax.swing.JFileChooser;
import javax.swing.event.ListDataEvent;
import javax.swing.plaf.basic.BasicDirectoryModel;
import org.junit.jupiter.api.Test;

public class BasicDirectoryModelAutoTest {

    @Test
    public void getFiles_test_8726(JFileChooser c0) {
      BasicDirectoryModel instance = new BasicDirectoryModel(c0);
      instance.getFiles();
    }
}
