package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.clear(). */
    @Test
    public void clear_test_6534() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        actionMap0.clear();
    }
}
