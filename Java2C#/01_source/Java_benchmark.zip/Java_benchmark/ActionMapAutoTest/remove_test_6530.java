package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.remove(). */
    @Test
    public void remove_test_6530() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        actionMap0.remove((java.lang.Object) 10);
    }
}
