package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.keys(). */
    @Test
    public void keys_test_6536() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        java.lang.Object[] objArray1 = actionMap0.keys();
        java.lang.Object[] objArray2 = actionMap0.keys();
        org.junit.Assert.assertNull(objArray1);
        org.junit.Assert.assertNull(objArray2);
    }
}
