package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.put(). */
    @Test
    public void put_test_6533() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        javax.swing.Action action2 = null;
        actionMap0.put((java.lang.Object) 10.0d, action2);
    }
}
