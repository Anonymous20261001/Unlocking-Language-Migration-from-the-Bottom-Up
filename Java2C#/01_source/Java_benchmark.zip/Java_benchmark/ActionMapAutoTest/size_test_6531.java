package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.size(). */
    @Test
    public void size_test_6531() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        int int1 = actionMap0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
