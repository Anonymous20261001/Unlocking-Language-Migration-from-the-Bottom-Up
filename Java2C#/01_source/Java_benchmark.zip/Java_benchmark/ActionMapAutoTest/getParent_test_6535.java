package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.getParent(). */
    @Test
    public void getParent_test_6535() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        javax.swing.ActionMap actionMap4 = actionMap0.getParent();
        org.junit.Assert.assertNull(actionMap4);
    }
}
