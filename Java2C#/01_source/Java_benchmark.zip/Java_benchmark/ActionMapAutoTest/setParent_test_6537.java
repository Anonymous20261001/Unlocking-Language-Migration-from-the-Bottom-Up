package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.setParent(). */
    @Test
    public void setParent_test_6537() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        javax.swing.ActionMap actionMap1 = new javax.swing.ActionMap();
        actionMap0.setParent(actionMap1);
    }
}
