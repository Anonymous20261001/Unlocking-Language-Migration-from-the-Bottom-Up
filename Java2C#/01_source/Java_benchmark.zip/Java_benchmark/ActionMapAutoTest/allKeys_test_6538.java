package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.allKeys(). */
    @Test
    public void allKeys_test_6538() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        java.lang.Object[] objArray1 = actionMap0.allKeys();
        org.junit.Assert.assertNull(objArray1);
    }
}
