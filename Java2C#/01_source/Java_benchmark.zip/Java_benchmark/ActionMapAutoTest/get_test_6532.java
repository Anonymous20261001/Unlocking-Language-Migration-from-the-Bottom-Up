package generated.test;

import org.junit.Test;

public class ActionMapAutoTest {

    /** Randoop-generated regression test for javax.swing.ActionMap.get(). */
    @Test
    public void get_test_6532() throws Throwable {
        javax.swing.ActionMap actionMap0 = new javax.swing.ActionMap();
        javax.swing.Action action2 = actionMap0.get((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNull(action2);
    }
}
