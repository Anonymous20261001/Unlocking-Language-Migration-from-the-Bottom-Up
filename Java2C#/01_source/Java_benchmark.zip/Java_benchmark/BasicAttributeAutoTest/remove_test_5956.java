package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.remove(). */
    @Test
    public void remove_test_5956() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute("hi!", true);
        boolean boolean4 = basicAttribute2.remove((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
