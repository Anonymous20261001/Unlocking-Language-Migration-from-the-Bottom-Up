package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.toString(). */
    @Test
    public void toString_test_5959() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute(": No values: No values", (java.lang.Object) ' ');
        java.lang.String str3 = basicAttribute2.toString();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + ": No values: No values:  " + "'", str3, ": No values: No values:  ");
    }
}
