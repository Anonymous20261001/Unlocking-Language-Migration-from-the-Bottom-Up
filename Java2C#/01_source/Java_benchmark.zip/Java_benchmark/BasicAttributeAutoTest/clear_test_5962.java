package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.clear(). */
    @Test
    public void clear_test_5962() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute("", (java.lang.Object) (short) 1);
        basicAttribute2.clear();
    }
}
