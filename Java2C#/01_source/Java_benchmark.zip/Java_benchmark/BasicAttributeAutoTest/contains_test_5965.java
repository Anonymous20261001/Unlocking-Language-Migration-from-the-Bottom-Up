package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.contains(). */
    @Test
    public void contains_test_5965() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute1 = new javax.naming.directory.BasicAttribute(": No values");
        boolean boolean4 = basicAttribute1.contains((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
