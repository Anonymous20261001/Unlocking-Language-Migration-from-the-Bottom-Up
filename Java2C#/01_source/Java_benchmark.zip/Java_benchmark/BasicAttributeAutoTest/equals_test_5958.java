package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.equals(). */
    @Test
    public void equals_test_5958() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute("hi!", false);
        boolean boolean4 = basicAttribute2.equals((java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
