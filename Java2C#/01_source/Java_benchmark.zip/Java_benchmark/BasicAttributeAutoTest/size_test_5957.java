package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.size(). */
    @Test
    public void size_test_5957() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute("hi!: -1", (java.lang.Object) false);
        int int3 = basicAttribute2.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }
}
