package generated.test;

import org.junit.Test;

public class BasicAttributeAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttribute.getID(). */
    @Test
    public void getID_test_5968() throws Throwable {
        javax.naming.directory.BasicAttribute basicAttribute2 = new javax.naming.directory.BasicAttribute("");
        java.lang.String str3 = basicAttribute2.getID();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
