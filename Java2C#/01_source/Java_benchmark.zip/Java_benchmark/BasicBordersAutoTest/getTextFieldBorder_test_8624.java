package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getTextFieldBorder(). */
    @Test
    public void getTextFieldBorder_test_8624() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getTextFieldBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
