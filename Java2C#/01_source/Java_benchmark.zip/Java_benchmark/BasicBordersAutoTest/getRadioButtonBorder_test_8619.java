package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getRadioButtonBorder(). */
    @Test
    public void getRadioButtonBorder_test_8619() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getRadioButtonBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
