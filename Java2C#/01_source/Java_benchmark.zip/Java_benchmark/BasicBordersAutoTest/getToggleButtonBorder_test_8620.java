package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getToggleButtonBorder(). */
    @Test
    public void getToggleButtonBorder_test_8620() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getToggleButtonBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
