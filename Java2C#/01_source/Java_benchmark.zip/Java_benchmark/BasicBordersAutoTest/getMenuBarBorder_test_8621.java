package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getMenuBarBorder(). */
    @Test
    public void getMenuBarBorder_test_8621() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getMenuBarBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
