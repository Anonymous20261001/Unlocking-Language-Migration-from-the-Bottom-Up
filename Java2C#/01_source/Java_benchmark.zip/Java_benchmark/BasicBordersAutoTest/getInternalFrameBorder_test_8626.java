package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getInternalFrameBorder(). */
    @Test
    public void getInternalFrameBorder_test_8626() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getInternalFrameBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
