package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getProgressBarBorder(). */
    @Test
    public void getProgressBarBorder_test_8625() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getProgressBarBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
