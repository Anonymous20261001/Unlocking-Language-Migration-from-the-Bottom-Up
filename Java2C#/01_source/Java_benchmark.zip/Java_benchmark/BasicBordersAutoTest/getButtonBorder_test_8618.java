package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getButtonBorder(). */
    @Test
    public void getButtonBorder_test_8618() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getButtonBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
