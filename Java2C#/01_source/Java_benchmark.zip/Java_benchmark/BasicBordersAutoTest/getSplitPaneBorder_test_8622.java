package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getSplitPaneBorder(). */
    @Test
    public void getSplitPaneBorder_test_8622() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getSplitPaneBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
