package generated.test;

import org.junit.Test;

public class BasicBordersAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicBorders.getSplitPaneDividerBorder(). */
    @Test
    public void getSplitPaneDividerBorder_test_8623() throws Throwable {
        javax.swing.border.Border border0 = javax.swing.plaf.basic.BasicBorders.getSplitPaneDividerBorder();
        org.junit.Assert.assertNotNull(border0);
    }
}
