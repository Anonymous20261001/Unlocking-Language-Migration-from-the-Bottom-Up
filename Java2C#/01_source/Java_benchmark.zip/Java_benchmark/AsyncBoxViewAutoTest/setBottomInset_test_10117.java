package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.setBottomInset(). */
    @Test
    public void setBottomInset_test_10117() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 1000);
        asyncBoxView2.setBottomInset((float) 2000);
    }
}
