package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getMinimumSpan(). */
    @Test
    public void getMinimumSpan_test_10123() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 4);
        float float4 = asyncBoxView2.getMinimumSpan(2000);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 5.0f + "'", float4 == 5.0f);
    }
}
