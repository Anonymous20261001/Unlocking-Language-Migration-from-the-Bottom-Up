package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.setRightInset(). */
    @Test
    public void setRightInset_test_10119() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 6);
        asyncBoxView2.setRightInset((float) 7);
    }
}
