package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getMaximumSpan(). */
    @Test
    public void getMaximumSpan_test_10124() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 32);
        float float4 = asyncBoxView2.getMaximumSpan(6);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.14748365E9f + "'", float4 == 2.14748365E9f);
    }
}
