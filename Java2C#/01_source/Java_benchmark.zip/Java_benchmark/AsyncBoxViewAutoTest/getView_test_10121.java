package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getView(). */
    @Test
    public void getView_test_10121() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 0);
        javax.swing.text.View view4 = asyncBoxView2.getView(4);
        org.junit.Assert.assertNull(view4);
    }
}
