package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.setTopInset(). */
    @Test
    public void setTopInset_test_10116() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 10);
        asyncBoxView2.setTopInset((float) 1);
    }
}
