package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getMajorAxis(). */
    @Test
    public void getMajorAxis_test_10114() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 100);
        int int3 = asyncBoxView2.getMajorAxis();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }
}
