package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getPreferredSpan(). */
    @Test
    public void getPreferredSpan_test_10122() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, 32);
        float float4 = asyncBoxView2.getPreferredSpan(3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 30.0f + "'", float4 == 30.0f);
    }
}
