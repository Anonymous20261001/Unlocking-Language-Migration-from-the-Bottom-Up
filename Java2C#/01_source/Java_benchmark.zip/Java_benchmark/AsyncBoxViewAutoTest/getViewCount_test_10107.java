package generated.test;

import org.junit.Test;

public class AsyncBoxViewAutoTest {

    /** Randoop-generated regression test for javax.swing.text.AsyncBoxView.getViewCount(). */
    @Test
    public void getViewCount_test_10107() throws Throwable {
        javax.swing.text.Element element0 = null;
        javax.swing.text.AsyncBoxView asyncBoxView2 = new javax.swing.text.AsyncBoxView(element0, (int) (byte) 10);
        int int3 = asyncBoxView2.getViewCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}
