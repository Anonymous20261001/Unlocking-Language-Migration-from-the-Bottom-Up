package generated.test;

import org.junit.Test;

public class BasicArrowButtonAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicArrowButton.getPreferredSize(). */
    @Test
    public void getPreferredSize_test_8615() throws Throwable {
        javax.swing.plaf.basic.BasicArrowButton basicArrowButton1 = new javax.swing.plaf.basic.BasicArrowButton(3);
        java.awt.Dimension dimension2 = basicArrowButton1.getPreferredSize();
        org.junit.Assert.assertNotNull(dimension2);
    }
}
