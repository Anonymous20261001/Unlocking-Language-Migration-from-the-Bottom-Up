package generated.test;

import org.junit.Test;

public class BasicArrowButtonAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicArrowButton.getMaximumSize(). */
    @Test
    public void getMaximumSize_test_8613() throws Throwable {
        javax.swing.plaf.basic.BasicArrowButton basicArrowButton1 = new javax.swing.plaf.basic.BasicArrowButton(0);
        java.awt.Dimension dimension2 = basicArrowButton1.getMaximumSize();
        org.junit.Assert.assertNotNull(dimension2);
    }
}
