package generated.test;

import org.junit.Test;

public class BasicArrowButtonAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicArrowButton.getDirection(). */
    @Test
    public void getDirection_test_8612() throws Throwable {
        javax.swing.plaf.basic.BasicArrowButton basicArrowButton1 = new javax.swing.plaf.basic.BasicArrowButton((int) (byte) 10);
        int int4 = basicArrowButton1.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }
}
