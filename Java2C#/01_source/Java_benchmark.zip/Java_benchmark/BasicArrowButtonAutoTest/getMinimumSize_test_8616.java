package generated.test;

import org.junit.Test;

public class BasicArrowButtonAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicArrowButton.getMinimumSize(). */
    @Test
    public void getMinimumSize_test_8616() throws Throwable {
        javax.swing.plaf.basic.BasicArrowButton basicArrowButton1 = new javax.swing.plaf.basic.BasicArrowButton(0);
        java.awt.Dimension dimension3 = basicArrowButton1.getMinimumSize();
        org.junit.Assert.assertNotNull(dimension3);
    }
}
