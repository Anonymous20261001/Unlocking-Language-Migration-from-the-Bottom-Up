package generated.test;

import org.junit.Test;

public class AudioFileFormatAutoTest {

    /** Randoop-generated regression test for javax.sound.sampled.AudioFileFormat.getFrameLength(). */
    @Test
    public void getFrameLength_test_6498() throws Throwable {
        javax.sound.sampled.AudioFileFormat.Type type0 = javax.sound.sampled.AudioFileFormat.Type.SND;
        javax.sound.sampled.AudioFormat audioFormat1 = null;
        javax.sound.sampled.AudioFileFormat audioFileFormat3 = new javax.sound.sampled.AudioFileFormat(type0, audioFormat1, 1);
        int int4 = audioFileFormat3.getFrameLength();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }
}
