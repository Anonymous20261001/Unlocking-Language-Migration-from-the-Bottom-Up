package generated.test;

import org.junit.Test;

public class AudioFileFormatAutoTest {

    /** Randoop-generated regression test for javax.sound.sampled.AudioFileFormat.getFormat(). */
    @Test
    public void getFormat_test_6503() throws Throwable {
        javax.sound.sampled.AudioFileFormat.Type type0 = javax.sound.sampled.AudioFileFormat.Type.AIFC;
        javax.sound.sampled.AudioFormat audioFormat1 = null;
        javax.sound.sampled.AudioFileFormat audioFileFormat3 = new javax.sound.sampled.AudioFileFormat(type0, audioFormat1, 0);
        javax.sound.sampled.AudioFormat audioFormat4 = audioFileFormat3.getFormat();
        org.junit.Assert.assertNull(audioFormat4);
    }
}
