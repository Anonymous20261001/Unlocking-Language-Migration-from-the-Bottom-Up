package generated.test;

import org.junit.Test;

public class AudioFileFormatAutoTest {

    /** Randoop-generated regression test for javax.sound.sampled.AudioFileFormat.getType(). */
    @Test
    public void getType_test_6502() throws Throwable {
        javax.sound.sampled.AudioFileFormat.Type type0 = javax.sound.sampled.AudioFileFormat.Type.SND;
        javax.sound.sampled.AudioFormat audioFormat1 = null;
        javax.sound.sampled.AudioFileFormat audioFileFormat3 = new javax.sound.sampled.AudioFileFormat(type0, audioFormat1, 1);
        javax.sound.sampled.AudioFileFormat.Type type4 = audioFileFormat3.getType();
        org.junit.Assert.assertNotNull(type4);
    }
}
