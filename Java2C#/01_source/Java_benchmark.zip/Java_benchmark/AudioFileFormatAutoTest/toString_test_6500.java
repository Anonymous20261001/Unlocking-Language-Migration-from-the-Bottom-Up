package generated.test;

import org.junit.Test;

public class AudioFileFormatAutoTest {

    /** Randoop-generated regression test for javax.sound.sampled.AudioFileFormat.toString(). */
    @Test
    public void toString_test_6500() throws Throwable {
        javax.sound.sampled.AudioFileFormat.Type type0 = javax.sound.sampled.AudioFileFormat.Type.AU;
        javax.sound.sampled.AudioFormat audioFormat1 = null;
        javax.sound.sampled.AudioFileFormat audioFileFormat3 = new javax.sound.sampled.AudioFileFormat(type0, audioFormat1, (int) (short) -1);
        java.lang.String str4 = audioFileFormat3.toString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "AU (.au) file, data format: null" + "'", str4, "AU (.au) file, data format: null");
    }
}
