package generated.test;

import org.junit.Test;

public class AudioFileFormatAutoTest {

    /** Randoop-generated regression test for javax.sound.sampled.AudioFileFormat.properties(). */
    @Test
    public void properties_test_6501() throws Throwable {
        javax.sound.sampled.AudioFileFormat.Type type0 = javax.sound.sampled.AudioFileFormat.Type.AIFC;
        javax.sound.sampled.AudioFormat audioFormat1 = null;
        javax.sound.sampled.AudioFileFormat audioFileFormat3 = new javax.sound.sampled.AudioFileFormat(type0, audioFormat1, 0);
        java.util.Map<java.lang.String, java.lang.Object> strMap4 = audioFileFormat3.properties();
        org.junit.Assert.assertNotNull(strMap4);
    }
}
