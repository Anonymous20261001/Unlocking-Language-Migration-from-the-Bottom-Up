package generated.test;

import org.junit.Test;

public class BadAttributeValueExpExceptionAutoTest {

    /** Randoop-generated regression test for javax.management.BadAttributeValueExpException.toString(). */
    @Test
    public void toString_test_5545() throws Throwable {
        javax.management.BadAttributeValueExpException badAttributeValueExpException1 = new javax.management.BadAttributeValueExpException((java.lang.Object) (short) 0);
        java.lang.String str2 = badAttributeValueExpException1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "BadAttributeValueException: 0" + "'", str2, "BadAttributeValueException: 0");
    }
}
