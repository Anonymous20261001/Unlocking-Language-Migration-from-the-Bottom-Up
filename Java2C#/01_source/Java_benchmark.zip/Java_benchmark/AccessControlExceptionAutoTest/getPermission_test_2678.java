package generated.test;

import org.junit.Test;

public class AccessControlExceptionAutoTest {

    /** Randoop-generated regression test for java.security.AccessControlException.getPermission(). */
    @Test
    public void getPermission_test_2678() throws Throwable {
        java.security.AccessControlException accessControlException1 = new java.security.AccessControlException("");
        java.security.Permission permission2 = accessControlException1.getPermission();
        org.junit.Assert.assertNull(permission2);
    }
}
