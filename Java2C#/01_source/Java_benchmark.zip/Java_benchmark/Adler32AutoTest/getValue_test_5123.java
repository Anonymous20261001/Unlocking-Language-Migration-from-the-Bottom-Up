package generated.test;

import org.junit.Test;

public class Adler32AutoTest {

    /** Randoop-generated regression test for java.util.zip.Adler32.getValue(). */
    @Test
    public void getValue_test_5123() throws Throwable {
        java.util.zip.Adler32 adler32_0 = new java.util.zip.Adler32();
        long long1 = adler32_0.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }
}
