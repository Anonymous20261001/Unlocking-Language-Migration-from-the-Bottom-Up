package generated.test;

import org.junit.Test;

public class Adler32AutoTest {

    /** Randoop-generated regression test for java.util.zip.Adler32.update(). */
    @Test
    public void update_test_5120() throws Throwable {
        java.util.zip.Adler32 adler32_0 = new java.util.zip.Adler32();
        byte[] byteArray1 = new byte[] {};
        adler32_0.update(byteArray1);
    }
}
