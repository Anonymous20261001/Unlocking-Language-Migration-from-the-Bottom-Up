package generated.test;

import org.junit.Test;

public class Adler32AutoTest {

    /** Randoop-generated regression test for java.util.zip.Adler32.reset(). */
    @Test
    public void reset_test_5119() throws Throwable {
        java.util.zip.Adler32 adler32_0 = new java.util.zip.Adler32();
        adler32_0.reset();
    }
}
