package generated.test;

import org.junit.Test;

public class AtomicLongArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLongArray.lazySet(). */
    @Test
    public void lazySet_test_4871() throws Throwable {
        long[] longArray0 = new long[] {};
        java.util.concurrent.atomic.AtomicLongArray atomicLongArray1 = new java.util.concurrent.atomic.AtomicLongArray(longArray0);
        // The following exception was thrown during execution in test generation
        try {
            atomicLongArray1.lazySet((int) 'a', (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 97 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
