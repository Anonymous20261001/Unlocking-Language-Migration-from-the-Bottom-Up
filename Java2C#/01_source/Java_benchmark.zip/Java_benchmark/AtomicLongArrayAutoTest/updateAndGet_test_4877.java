package generated.test;

import org.junit.Test;

public class AtomicLongArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLongArray.updateAndGet(). */
    @Test
    public void updateAndGet_test_4877() throws Throwable {
        java.util.concurrent.atomic.AtomicLongArray atomicLongArray1 = new java.util.concurrent.atomic.AtomicLongArray(97);
        java.util.function.LongUnaryOperator longUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long4 = atomicLongArray1.updateAndGet((-1), longUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index -1 out of bounds for length 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
