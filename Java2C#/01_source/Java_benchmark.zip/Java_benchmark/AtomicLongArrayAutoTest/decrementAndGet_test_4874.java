package generated.test;

import org.junit.Test;

public class AtomicLongArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLongArray.decrementAndGet(). */
    @Test
    public void decrementAndGet_test_4874() throws Throwable {
        long[] longArray0 = new long[] {};
        java.util.concurrent.atomic.AtomicLongArray atomicLongArray1 = new java.util.concurrent.atomic.AtomicLongArray(longArray0);
        // The following exception was thrown during execution in test generation
        try {
            long long3 = atomicLongArray1.decrementAndGet(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 97 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
