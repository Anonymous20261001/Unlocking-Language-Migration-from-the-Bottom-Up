package generated.test;

import org.junit.Test;

public class AtomicLongArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLongArray.getPlain(). */
    @Test
    public void getPlain_test_4880() throws Throwable {
        java.util.concurrent.atomic.AtomicLongArray atomicLongArray1 = new java.util.concurrent.atomic.AtomicLongArray((int) 'a');
        long long3 = atomicLongArray1.getPlain((int) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }
}
