package generated.test;

import org.junit.Test;

public class AtomicLongArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLongArray.get(). */
    @Test
    public void get_test_4851() throws Throwable {
        java.util.concurrent.atomic.AtomicLongArray atomicLongArray1 = new java.util.concurrent.atomic.AtomicLongArray((int) '#');
        long long3 = atomicLongArray1.get((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }
}
