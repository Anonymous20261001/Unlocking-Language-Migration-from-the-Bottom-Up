package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.get(). */
    @Test
    public void get_test_5218() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet2 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        javax.accessibility.AccessibleRelation accessibleRelation4 = accessibleRelationSet2.get("hi!");
        org.junit.Assert.assertNull(accessibleRelation4);
    }
}
