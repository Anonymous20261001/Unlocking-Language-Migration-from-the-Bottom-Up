package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.contains(). */
    @Test
    public void contains_test_5223() throws Throwable {
        javax.accessibility.AccessibleRelationSet accessibleRelationSet0 = new javax.accessibility.AccessibleRelationSet();
        boolean boolean2 = accessibleRelationSet0.contains("flowsTo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
