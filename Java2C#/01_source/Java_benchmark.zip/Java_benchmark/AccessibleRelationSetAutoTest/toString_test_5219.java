package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.toString(). */
    @Test
    public void toString_test_5219() throws Throwable {
        javax.accessibility.AccessibleRelationSet accessibleRelationSet0 = new javax.accessibility.AccessibleRelationSet();
        java.lang.String str1 = accessibleRelationSet0.toString();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "" + "'", str1, "");
    }
}
