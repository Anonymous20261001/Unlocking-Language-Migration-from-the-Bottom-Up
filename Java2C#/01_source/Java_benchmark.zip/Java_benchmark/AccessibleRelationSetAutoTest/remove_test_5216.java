package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.remove(). */
    @Test
    public void remove_test_5216() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet1 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        javax.accessibility.AccessibleRelation accessibleRelation2 = null;
        boolean boolean3 = accessibleRelationSet1.remove(accessibleRelation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
