package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.add(). */
    @Test
    public void add_test_5221() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet1 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        javax.accessibility.AccessibleRelation accessibleRelation3 = new javax.accessibility.AccessibleRelation("embeddedByProperty");
        boolean boolean4 = accessibleRelationSet1.add(accessibleRelation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}
