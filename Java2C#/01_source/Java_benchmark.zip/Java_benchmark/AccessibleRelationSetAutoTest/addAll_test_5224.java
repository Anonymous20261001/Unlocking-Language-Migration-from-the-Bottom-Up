package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.addAll(). */
    @Test
    public void addAll_test_5224() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet1 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        javax.accessibility.AccessibleRelation[] accessibleRelationArray2 = null;
        // The following exception was thrown during execution in test generation
        try {
            accessibleRelationSet1.addAll(accessibleRelationArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot read the array length because \"relations\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
