package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.toArray(). */
    @Test
    public void toArray_test_5222() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet1 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        javax.accessibility.AccessibleRelation[] accessibleRelationArray2 = accessibleRelationSet1.toArray();
        org.junit.Assert.assertNotNull(accessibleRelationArray2);
        org.junit.Assert.assertArrayEquals(accessibleRelationArray2, new javax.accessibility.AccessibleRelation[] {});
    }
}
