package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.clear(). */
    @Test
    public void clear_test_5220() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet2 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        accessibleRelationSet2.clear();
    }
}
