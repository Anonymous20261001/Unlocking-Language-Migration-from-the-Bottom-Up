package generated.test;

import org.junit.Test;

public class AccessibleRelationSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelationSet.size(). */
    @Test
    public void size_test_5217() throws Throwable {
        javax.accessibility.AccessibleRelation[] accessibleRelationArray0 = new javax.accessibility.AccessibleRelation[] {};
        javax.accessibility.AccessibleRelationSet accessibleRelationSet1 = new javax.accessibility.AccessibleRelationSet(accessibleRelationArray0);
        int int2 = accessibleRelationSet1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
