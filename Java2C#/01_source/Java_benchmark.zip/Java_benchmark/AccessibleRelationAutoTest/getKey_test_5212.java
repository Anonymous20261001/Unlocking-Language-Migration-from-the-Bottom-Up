package generated.test;

import org.junit.Test;

public class AccessibleRelationAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelation.getKey(). */
    @Test
    public void getKey_test_5212() throws Throwable {
        javax.accessibility.AccessibleRelation accessibleRelation1 = new javax.accessibility.AccessibleRelation("parentWindowOfProperty");
        java.lang.String str3 = accessibleRelation1.getKey();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "parentWindowOfProperty" + "'", str3, "parentWindowOfProperty");
    }
}
