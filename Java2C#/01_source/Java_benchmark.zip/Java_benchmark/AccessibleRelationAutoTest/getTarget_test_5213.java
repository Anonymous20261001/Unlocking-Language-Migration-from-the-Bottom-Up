package generated.test;

import org.junit.Test;

public class AccessibleRelationAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelation.getTarget(). */
    @Test
    public void getTarget_test_5213() throws Throwable {
        javax.accessibility.AccessibleRelation accessibleRelation1 = new javax.accessibility.AccessibleRelation("parentWindowOfProperty");
        java.lang.Object[] objArray3 = accessibleRelation1.getTarget();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertArrayEquals(objArray3, new java.lang.Object[] {});
    }
}
