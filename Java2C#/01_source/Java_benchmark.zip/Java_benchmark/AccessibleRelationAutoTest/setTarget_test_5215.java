package generated.test;

import org.junit.Test;

public class AccessibleRelationAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleRelation.setTarget(). */
    @Test
    public void setTarget_test_5215() throws Throwable {
        javax.accessibility.AccessibleRelation accessibleRelation1 = new javax.accessibility.AccessibleRelation("controlledByProperty");
        java.lang.Object[] objArray3 = new java.lang.Object[] { (byte) 1 };
        accessibleRelation1.setTarget(objArray3);
    }
}
