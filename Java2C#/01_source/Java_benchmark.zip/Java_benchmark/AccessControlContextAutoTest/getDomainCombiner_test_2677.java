package generated.test;

import org.junit.Test;

public class AccessControlContextAutoTest {

    /** Randoop-generated regression test for java.security.AccessControlContext.getDomainCombiner(). */
    @Test
    public void getDomainCombiner_test_2677() throws Throwable {
        java.security.ProtectionDomain[] protectionDomainArray0 = new java.security.ProtectionDomain[] {};
        java.security.AccessControlContext accessControlContext1 = new java.security.AccessControlContext(protectionDomainArray0);
        java.security.DomainCombiner domainCombiner2 = accessControlContext1.getDomainCombiner();
        org.junit.Assert.assertNull(domainCombiner2);
    }
}
