package generated.test;

import org.junit.Test;

public class AccessControlContextAutoTest {

    /** Randoop-generated regression test for java.security.AccessControlContext.equals(). */
    @Test
    public void equals_test_2675() throws Throwable {
        java.security.ProtectionDomain[] protectionDomainArray0 = new java.security.ProtectionDomain[] {};
        java.security.AccessControlContext accessControlContext1 = new java.security.AccessControlContext(protectionDomainArray0);
        java.security.ProtectionDomain[] protectionDomainArray2 = new java.security.ProtectionDomain[] {};
        java.security.AccessControlContext accessControlContext3 = new java.security.AccessControlContext(protectionDomainArray2);
        boolean boolean4 = accessControlContext1.equals((java.lang.Object) accessControlContext3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}
