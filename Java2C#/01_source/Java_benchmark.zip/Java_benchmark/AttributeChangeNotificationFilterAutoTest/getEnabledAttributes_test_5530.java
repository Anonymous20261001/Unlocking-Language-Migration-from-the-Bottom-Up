package generated.test;

import org.junit.Test;

public class AttributeChangeNotificationFilterAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeChangeNotificationFilter.getEnabledAttributes(). */
    @Test
    public void getEnabledAttributes_test_5530() throws Throwable {
        javax.management.AttributeChangeNotificationFilter attributeChangeNotificationFilter0 = new javax.management.AttributeChangeNotificationFilter();
        java.util.Vector<java.lang.String> strList1 = attributeChangeNotificationFilter0.getEnabledAttributes();
        org.junit.Assert.assertNotNull(strList1);
    }
}
