package generated.test;

import org.junit.Test;

public class AttributeChangeNotificationFilterAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeChangeNotificationFilter.isNotificationEnabled(). */
    @Test
    public void isNotificationEnabled_test_5527() throws Throwable {
        javax.management.AttributeChangeNotificationFilter attributeChangeNotificationFilter0 = new javax.management.AttributeChangeNotificationFilter();
        javax.management.Notification notification3 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = attributeChangeNotificationFilter0.isNotificationEnabled(notification3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.management.Notification.getType()\" because \"notification\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
