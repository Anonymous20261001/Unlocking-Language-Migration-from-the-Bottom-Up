package generated.test;

import org.junit.Test;

public class AttributeChangeNotificationFilterAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeChangeNotificationFilter.disableAllAttributes(). */
    @Test
    public void disableAllAttributes_test_5529() throws Throwable {
        javax.management.AttributeChangeNotificationFilter attributeChangeNotificationFilter0 = new javax.management.AttributeChangeNotificationFilter();
        attributeChangeNotificationFilter0.disableAllAttributes();
    }
}
