package generated.test;

import org.junit.Test;

public class AttributeChangeNotificationFilterAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeChangeNotificationFilter.disableAttribute(). */
    @Test
    public void disableAttribute_test_5528() throws Throwable {
        javax.management.AttributeChangeNotificationFilter attributeChangeNotificationFilter0 = new javax.management.AttributeChangeNotificationFilter();
        attributeChangeNotificationFilter0.disableAttribute("");
    }
}
