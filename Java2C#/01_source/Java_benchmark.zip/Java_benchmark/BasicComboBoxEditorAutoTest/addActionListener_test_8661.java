package generated.test;

import org.junit.Test;

public class BasicComboBoxEditorAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicComboBoxEditor.addActionListener(). */
    @Test
    public void addActionListener_test_8661() throws Throwable {
        javax.swing.plaf.basic.BasicComboBoxEditor basicComboBoxEditor0 = new javax.swing.plaf.basic.BasicComboBoxEditor();
        java.awt.event.ActionListener actionListener1 = null;
        basicComboBoxEditor0.addActionListener(actionListener1);
    }
}
