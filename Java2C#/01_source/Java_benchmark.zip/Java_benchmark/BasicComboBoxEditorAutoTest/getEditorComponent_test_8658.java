package generated.test;

import org.junit.Test;

public class BasicComboBoxEditorAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicComboBoxEditor.getEditorComponent(). */
    @Test
    public void getEditorComponent_test_8658() throws Throwable {
        javax.swing.plaf.basic.BasicComboBoxEditor basicComboBoxEditor0 = new javax.swing.plaf.basic.BasicComboBoxEditor();
        java.awt.Component component1 = basicComboBoxEditor0.getEditorComponent();
        org.junit.Assert.assertNotNull(component1);
    }
}
