package generated.test;

import org.junit.Test;

public class BasicComboBoxEditorAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicComboBoxEditor.focusGained(). */
    @Test
    public void focusGained_test_8659() throws Throwable {
        javax.swing.plaf.basic.BasicComboBoxEditor basicComboBoxEditor0 = new javax.swing.plaf.basic.BasicComboBoxEditor();
        java.awt.event.FocusEvent focusEvent1 = null;
        basicComboBoxEditor0.focusGained(focusEvent1);
    }
}
