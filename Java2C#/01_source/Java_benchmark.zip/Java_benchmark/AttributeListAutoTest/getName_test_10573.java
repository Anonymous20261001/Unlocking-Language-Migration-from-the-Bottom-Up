package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getName(). */
    @Test
    public void getName_test_10573() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("");
        java.lang.String str3 = attributeList1.getName();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
