package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.name2type(). */
    @Test
    public void name2type_test_10570() throws Throwable {
        int int1 = javax.swing.text.html.parser.AttributeList.name2type("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }
}
