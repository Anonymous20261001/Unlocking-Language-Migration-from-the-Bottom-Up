package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getNext(). */
    @Test
    public void getNext_test_10568() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("CDATA");
        javax.swing.text.html.parser.AttributeList attributeList2 = attributeList1.getNext();
        org.junit.Assert.assertNull(attributeList2);
    }
}
