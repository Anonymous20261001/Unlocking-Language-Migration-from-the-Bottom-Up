package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getValues(). */
    @Test
    public void getValues_test_10572() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("hi!");
        java.util.Enumeration<?> wildcardEnumeration2 = attributeList1.getValues();
        org.junit.Assert.assertNull(wildcardEnumeration2);
    }
}
