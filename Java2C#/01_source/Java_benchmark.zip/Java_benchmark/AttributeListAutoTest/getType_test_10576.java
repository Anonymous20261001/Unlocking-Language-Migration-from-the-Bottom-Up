package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getType(). */
    @Test
    public void getType_test_10576() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("");
        int int3 = attributeList1.getType();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}
