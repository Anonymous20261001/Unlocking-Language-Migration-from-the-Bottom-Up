package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.type2name(). */
    @Test
    public void type2name_test_10571() throws Throwable {
        java.lang.String str1 = javax.swing.text.html.parser.AttributeList.type2name(17);
        org.junit.Assert.assertNull(str1);
    }
}
