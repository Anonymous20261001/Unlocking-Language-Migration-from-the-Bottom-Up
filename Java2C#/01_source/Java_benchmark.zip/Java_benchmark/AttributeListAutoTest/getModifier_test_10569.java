package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getModifier(). */
    @Test
    public void getModifier_test_10569() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("");
        int int4 = attributeList1.getModifier();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }
}
