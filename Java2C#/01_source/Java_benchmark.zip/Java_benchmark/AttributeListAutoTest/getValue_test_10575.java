package generated.test;

import org.junit.Test;

public class AttributeListAutoTest {

    /** Randoop-generated regression test for javax.swing.text.html.parser.AttributeList.getValue(). */
    @Test
    public void getValue_test_10575() throws Throwable {
        javax.swing.text.html.parser.AttributeList attributeList1 = new javax.swing.text.html.parser.AttributeList("");
        java.lang.String str3 = attributeList1.getValue();
        org.junit.Assert.assertNull(str3);
    }
}
