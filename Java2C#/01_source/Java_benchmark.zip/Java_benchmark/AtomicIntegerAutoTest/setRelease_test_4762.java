package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.setRelease(). */
    @Test
    public void setRelease_test_4762() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) '#');
        atomicInteger1.setRelease(35);
    }
}
