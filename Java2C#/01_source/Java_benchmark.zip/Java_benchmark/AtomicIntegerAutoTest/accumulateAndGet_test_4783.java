package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.accumulateAndGet(). */
    @Test
    public void accumulateAndGet_test_4783() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.IntBinaryOperator intBinaryOperator2 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int3 = atomicInteger0.accumulateAndGet((int) (short) 1, intBinaryOperator2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.IntBinaryOperator.applyAsInt(int, int)\" because \"accumulatorFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
