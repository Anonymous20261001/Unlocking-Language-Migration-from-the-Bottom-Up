package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.setOpaque(). */
    @Test
    public void setOpaque_test_4760() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        atomicInteger0.setOpaque(10);
    }
}
