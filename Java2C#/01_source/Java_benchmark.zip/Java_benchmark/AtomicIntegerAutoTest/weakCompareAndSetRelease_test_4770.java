package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.weakCompareAndSetRelease(). */
    @Test
    public void weakCompareAndSetRelease_test_4770() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) ' ');
        boolean boolean4 = atomicInteger1.weakCompareAndSetRelease(100, 8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
