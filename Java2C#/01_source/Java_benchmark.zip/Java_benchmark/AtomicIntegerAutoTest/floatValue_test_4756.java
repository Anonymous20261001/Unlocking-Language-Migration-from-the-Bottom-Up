package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.floatValue(). */
    @Test
    public void floatValue_test_4756() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        float float1 = atomicInteger0.floatValue();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }
}
