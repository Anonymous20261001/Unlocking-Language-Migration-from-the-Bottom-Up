package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.decrementAndGet(). */
    @Test
    public void decrementAndGet_test_4778() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger(10);
        int int3 = atomicInteger1.decrementAndGet();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }
}
