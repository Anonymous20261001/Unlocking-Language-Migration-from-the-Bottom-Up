package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.updateAndGet(). */
    @Test
    public void updateAndGet_test_4781() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger(10);
        java.util.function.IntUnaryOperator intUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int4 = atomicInteger1.updateAndGet(intUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.IntUnaryOperator.applyAsInt(int)\" because \"updateFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
