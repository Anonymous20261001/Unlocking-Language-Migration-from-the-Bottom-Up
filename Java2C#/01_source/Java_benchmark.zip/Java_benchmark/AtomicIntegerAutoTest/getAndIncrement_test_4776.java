package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.getAndIncrement(). */
    @Test
    public void getAndIncrement_test_4776() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        int int1 = atomicInteger0.decrementAndGet();
        int int2 = atomicInteger0.getAndIncrement();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }
}
