package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.getAndAdd(). */
    @Test
    public void getAndAdd_test_4772() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger(10);
        int int4 = atomicInteger1.getAndAdd((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }
}
