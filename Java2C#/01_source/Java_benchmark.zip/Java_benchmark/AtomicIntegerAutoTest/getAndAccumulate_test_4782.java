package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.getAndAccumulate(). */
    @Test
    public void getAndAccumulate_test_4782() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger(1);
        java.util.function.IntBinaryOperator intBinaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int4 = atomicInteger1.getAndAccumulate(10, intBinaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.IntBinaryOperator.applyAsInt(int, int)\" because \"accumulatorFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
