package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.getPlain(). */
    @Test
    public void getPlain_test_4784() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        int int1 = atomicInteger0.getPlain();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
