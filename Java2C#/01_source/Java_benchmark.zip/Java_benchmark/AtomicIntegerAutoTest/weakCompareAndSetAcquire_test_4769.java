package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.weakCompareAndSetAcquire(). */
    @Test
    public void weakCompareAndSetAcquire_test_4769() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) ' ');
        boolean boolean4 = atomicInteger1.weakCompareAndSetAcquire((int) (short) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
