package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.getAndSet(). */
    @Test
    public void getAndSet_test_4771() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) '#');
        int int3 = atomicInteger1.getAndSet(9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }
}
