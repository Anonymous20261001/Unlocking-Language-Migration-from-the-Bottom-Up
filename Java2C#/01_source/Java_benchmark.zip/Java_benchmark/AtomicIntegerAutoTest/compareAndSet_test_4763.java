package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.compareAndSet(). */
    @Test
    public void compareAndSet_test_4763() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) (byte) -1);
        boolean boolean4 = atomicInteger1.compareAndSet(100, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
