package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.incrementAndGet(). */
    @Test
    public void incrementAndGet_test_4773() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger0 = new java.util.concurrent.atomic.AtomicInteger();
        int int4 = atomicInteger0.incrementAndGet();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }
}
