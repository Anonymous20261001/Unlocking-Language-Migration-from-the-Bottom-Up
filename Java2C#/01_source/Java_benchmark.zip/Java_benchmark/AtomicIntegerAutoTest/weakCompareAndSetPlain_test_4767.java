package generated.test;

import org.junit.Test;

public class AtomicIntegerAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicInteger.weakCompareAndSetPlain(). */
    @Test
    public void weakCompareAndSetPlain_test_4767() throws Throwable {
        java.util.concurrent.atomic.AtomicInteger atomicInteger1 = new java.util.concurrent.atomic.AtomicInteger((int) ' ');
        boolean boolean4 = atomicInteger1.weakCompareAndSetPlain((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
