package generated.test;

import org.junit.Test;

public class AnnotationTypeMismatchExceptionAutoTest {

    /** Randoop-generated regression test for java.lang.annotation.AnnotationTypeMismatchException.foundType(). */
    @Test
    public void foundType_test_2372() throws Throwable {
        java.lang.reflect.Method method0 = null;
        java.lang.annotation.AnnotationTypeMismatchException annotationTypeMismatchException2 = new java.lang.annotation.AnnotationTypeMismatchException(method0, "");
        java.lang.String str3 = annotationTypeMismatchException2.foundType();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
