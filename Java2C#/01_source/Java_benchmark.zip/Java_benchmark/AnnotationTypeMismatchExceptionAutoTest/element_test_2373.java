package generated.test;

import org.junit.Test;

public class AnnotationTypeMismatchExceptionAutoTest {

    /** Randoop-generated regression test for java.lang.annotation.AnnotationTypeMismatchException.element(). */
    @Test
    public void element_test_2373() throws Throwable {
        java.lang.reflect.Method method0 = null;
        java.lang.annotation.AnnotationTypeMismatchException annotationTypeMismatchException2 = new java.lang.annotation.AnnotationTypeMismatchException(method0, "hi!");
        java.lang.reflect.Method method3 = annotationTypeMismatchException2.element();
        org.junit.Assert.assertNull(method3);
    }
}
