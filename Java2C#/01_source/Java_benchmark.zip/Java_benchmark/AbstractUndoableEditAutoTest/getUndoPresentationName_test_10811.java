package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.getUndoPresentationName(). */
    @Test
    public void getUndoPresentationName_test_10811() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        java.lang.String str2 = abstractUndoableEdit0.getUndoPresentationName();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "Undo" + "'", str2, "Undo");
    }
}
