package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.getRedoPresentationName(). */
    @Test
    public void getRedoPresentationName_test_10812() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        java.lang.String str1 = abstractUndoableEdit0.getRedoPresentationName();
        java.lang.String str2 = abstractUndoableEdit0.getRedoPresentationName();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "Redo" + "'", str1, "Redo");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "Redo" + "'", str2, "Redo");
    }
}
