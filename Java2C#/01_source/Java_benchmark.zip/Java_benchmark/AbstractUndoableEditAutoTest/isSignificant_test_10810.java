package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.isSignificant(). */
    @Test
    public void isSignificant_test_10810() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        boolean boolean1 = abstractUndoableEdit0.isSignificant();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
