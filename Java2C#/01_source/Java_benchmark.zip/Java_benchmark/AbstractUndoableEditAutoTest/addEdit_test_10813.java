package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.addEdit(). */
    @Test
    public void addEdit_test_10813() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit1 = new javax.swing.undo.AbstractUndoableEdit();
        boolean boolean3 = abstractUndoableEdit0.addEdit((javax.swing.undo.UndoableEdit) abstractUndoableEdit1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
