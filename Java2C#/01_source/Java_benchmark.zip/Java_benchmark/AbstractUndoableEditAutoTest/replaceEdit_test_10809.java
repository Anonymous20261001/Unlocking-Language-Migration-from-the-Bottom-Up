package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.replaceEdit(). */
    @Test
    public void replaceEdit_test_10809() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit1 = new javax.swing.undo.AbstractUndoableEdit();
        boolean boolean4 = abstractUndoableEdit0.replaceEdit((javax.swing.undo.UndoableEdit) abstractUndoableEdit1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
