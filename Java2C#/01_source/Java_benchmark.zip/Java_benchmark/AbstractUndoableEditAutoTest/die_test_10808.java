package generated.test;

import org.junit.Test;

public class AbstractUndoableEditAutoTest {

    /** Randoop-generated regression test for javax.swing.undo.AbstractUndoableEdit.die(). */
    @Test
    public void die_test_10808() throws Throwable {
        javax.swing.undo.AbstractUndoableEdit abstractUndoableEdit0 = new javax.swing.undo.AbstractUndoableEdit();
        abstractUndoableEdit0.die();
    }
}
