package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.remove(). */
    @Test
    public void remove_test_5036() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        java.util.jar.Attributes.Name name1 = java.util.jar.Attributes.Name.IMPLEMENTATION_VERSION;
        java.lang.Object obj2 = attributes0.remove((java.lang.Object) name1);
        org.junit.Assert.assertNull(obj2);
    }
}
