package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.get(). */
    @Test
    public void get_test_5038() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        java.util.jar.Attributes.Name name3 = java.util.jar.Attributes.Name.EXTENSION_NAME;
        java.lang.Object obj4 = attributes0.get((java.lang.Object) name3);
        org.junit.Assert.assertNull(obj4);
    }
}
