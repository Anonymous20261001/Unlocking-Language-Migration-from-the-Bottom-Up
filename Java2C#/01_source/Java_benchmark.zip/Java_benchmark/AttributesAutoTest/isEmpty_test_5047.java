package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.isEmpty(). */
    @Test
    public void isEmpty_test_5047() throws Throwable {
        java.util.jar.Attributes attributes2 = new java.util.jar.Attributes((int) (short) 10);
        boolean boolean4 = attributes2.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}
