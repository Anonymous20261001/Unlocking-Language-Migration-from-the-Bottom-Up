package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.keySet(). */
    @Test
    public void keySet_test_5050() throws Throwable {
        java.util.jar.Attributes attributes1 = new java.util.jar.Attributes((int) ' ');
        java.util.Set<java.lang.Object> objSet3 = attributes1.keySet();
        org.junit.Assert.assertNotNull(objSet3);
    }
}
