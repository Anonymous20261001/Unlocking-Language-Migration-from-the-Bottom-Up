package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.putValue(). */
    @Test
    public void putValue_test_5053() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = attributes0.putValue("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ");
        } catch (java.lang.IllegalArgumentException e) {
            // Expected exception.
        }
    }
}
