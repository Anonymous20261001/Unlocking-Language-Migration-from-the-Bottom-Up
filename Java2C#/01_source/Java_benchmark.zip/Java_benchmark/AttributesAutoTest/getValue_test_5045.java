package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.getValue(). */
    @Test
    public void getValue_test_5045() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        java.util.jar.Attributes.Name name1 = java.util.jar.Attributes.Name.CONTENT_TYPE;
        java.lang.String str2 = attributes0.getValue(name1);
        org.junit.Assert.assertNull(str2);
    }
}
