package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.containsValue(). */
    @Test
    public void containsValue_test_5051() throws Throwable {
        java.util.jar.Attributes attributes1 = new java.util.jar.Attributes((int) (byte) 100);
        boolean boolean3 = attributes1.containsValue((java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
