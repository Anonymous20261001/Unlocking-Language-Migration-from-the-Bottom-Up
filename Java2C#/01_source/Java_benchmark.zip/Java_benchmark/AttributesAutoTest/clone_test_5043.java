package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.clone(). */
    @Test
    public void clone_test_5043() throws Throwable {
        java.util.jar.Attributes attributes2 = new java.util.jar.Attributes((int) (short) 10);
        java.lang.Object obj4 = attributes2.clone();
        org.junit.Assert.assertNotNull(obj4);
    }
}
