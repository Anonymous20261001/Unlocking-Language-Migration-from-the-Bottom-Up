package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.equals(). */
    @Test
    public void equals_test_5040() throws Throwable {
        java.util.jar.Attributes attributes1 = new java.util.jar.Attributes(100);
        java.util.jar.Attributes.Name name2 = java.util.jar.Attributes.Name.EXTENSION_INSTALLATION;
        boolean boolean3 = attributes1.equals((java.lang.Object) name2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
