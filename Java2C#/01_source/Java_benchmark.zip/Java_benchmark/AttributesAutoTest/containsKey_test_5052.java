package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.containsKey(). */
    @Test
    public void containsKey_test_5052() throws Throwable {
        java.util.jar.Attributes attributes1 = new java.util.jar.Attributes(0);
        java.util.jar.Attributes attributes2 = new java.util.jar.Attributes(attributes1);
        java.util.jar.Attributes.Name name3 = java.util.jar.Attributes.Name.SPECIFICATION_VERSION;
        boolean boolean4 = attributes2.containsKey((java.lang.Object) name3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
