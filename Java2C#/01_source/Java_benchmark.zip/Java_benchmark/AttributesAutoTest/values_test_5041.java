package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.values(). */
    @Test
    public void values_test_5041() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        java.util.Collection<java.lang.Object> objCollection1 = attributes0.values();
        org.junit.Assert.assertNotNull(objCollection1);
    }
}
