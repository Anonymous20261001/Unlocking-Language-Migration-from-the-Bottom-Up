package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.clear(). */
    @Test
    public void clear_test_5044() throws Throwable {
        java.util.jar.Attributes attributes2 = new java.util.jar.Attributes((int) (short) 10);
        attributes2.clear();
    }
}
