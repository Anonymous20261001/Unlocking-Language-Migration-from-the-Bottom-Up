package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.size(). */
    @Test
    public void size_test_5037() throws Throwable {
        java.util.jar.Attributes attributes0 = new java.util.jar.Attributes();
        int int1 = attributes0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}
