package generated.test;

import org.junit.Test;

public class AttributesAutoTest {

    /** Randoop-generated regression test for java.util.jar.Attributes.entrySet(). */
    @Test
    public void entrySet_test_5048() throws Throwable {
        java.util.jar.Attributes attributes1 = new java.util.jar.Attributes((int) ' ');
        java.util.Set<java.util.Map.Entry<java.lang.Object, java.lang.Object>> objEntrySet2 = attributes1.entrySet();
        org.junit.Assert.assertNotNull(objEntrySet2);
    }
}
