package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.add(). */
    @Test
    public void add_test_3329() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList0 = new java.util.ArrayList<java.lang.constant.Constable>();
        constableList0.add(0, (java.lang.constant.Constable) (short) 100);
    }
}
