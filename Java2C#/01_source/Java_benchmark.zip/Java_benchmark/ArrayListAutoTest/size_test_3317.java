package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.size(). */
    @Test
    public void size_test_3317() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>(100);
        java.util.ArrayList<java.lang.constant.Constable> constableList2 = new java.util.ArrayList<java.lang.constant.Constable>((java.util.Collection<java.lang.constant.Constable>) constableList1);
        int int3 = constableList2.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}
