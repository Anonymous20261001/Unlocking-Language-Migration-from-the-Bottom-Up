package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.contains(). */
    @Test
    public void contains_test_3334() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>((int) (short) 100);
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = constableList1.contains(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
