package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.addFirst(). */
    @Test
    public void addFirst_test_3345() throws Throwable {
        java.util.ArrayList<java.lang.String> strList0 = new java.util.ArrayList<java.lang.String>();
        strList0.addFirst("");
    }
}
