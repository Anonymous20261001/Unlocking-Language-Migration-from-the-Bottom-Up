package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.trimToSize(). */
    @Test
    public void trimToSize_test_3338() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>((int) (short) 100);
        constableList1.trimToSize();
    }
}
