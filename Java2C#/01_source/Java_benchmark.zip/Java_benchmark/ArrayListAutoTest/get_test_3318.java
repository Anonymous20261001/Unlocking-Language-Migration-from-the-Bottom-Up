package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.get(). */
    @Test
    public void get_test_3318() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList0 = new java.util.ArrayList<java.lang.constant.Constable>();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.constant.Constable constable4 = constableList0.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index 1 out of bounds for length 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
