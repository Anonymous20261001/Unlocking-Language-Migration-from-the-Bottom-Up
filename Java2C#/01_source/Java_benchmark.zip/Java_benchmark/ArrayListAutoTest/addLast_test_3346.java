package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.addLast(). */
    @Test
    public void addLast_test_3346() throws Throwable {
        java.util.ArrayList<java.lang.String> strList0 = new java.util.ArrayList<java.lang.String>();
        strList0.addLast("");
    }
}
