package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.subList(). */
    @Test
    public void subList_test_3330() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList0 = new java.util.ArrayList<java.lang.constant.Constable>();
        // The following exception was thrown during execution in test generation
        try {
            java.util.List<java.lang.constant.Constable> constableList4 = constableList0.subList(1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 100");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
