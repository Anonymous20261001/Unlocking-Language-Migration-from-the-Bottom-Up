package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.toArray(). */
    @Test
    public void toArray_test_3331() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (byte) 100);
        java.lang.Cloneable[] cloneableArray3 = new java.lang.Cloneable[] {};
        java.lang.Cloneable[] cloneableArray4 = objList1.toArray(cloneableArray3);
        org.junit.Assert.assertNotNull(cloneableArray4);
        org.junit.Assert.assertArrayEquals(cloneableArray4, new java.lang.Cloneable[] {});
    }
}
