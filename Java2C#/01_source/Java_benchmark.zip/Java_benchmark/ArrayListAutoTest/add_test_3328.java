package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.add(). */
    @Test
    public void add_test_3328() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>((int) '4');
        java.util.ArrayList<java.lang.reflect.GenericDeclaration> genericDeclarationList2 = new java.util.ArrayList<java.lang.reflect.GenericDeclaration>();
        java.lang.Class<?> wildcardClass3 = genericDeclarationList2.getClass();
        boolean boolean4 = constableList1.add((java.lang.constant.Constable) wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}
