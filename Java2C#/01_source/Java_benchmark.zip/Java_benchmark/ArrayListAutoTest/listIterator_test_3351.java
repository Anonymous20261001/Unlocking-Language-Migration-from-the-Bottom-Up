package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.listIterator(). */
    @Test
    public void listIterator_test_3351() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (byte) 100);
        java.util.ListIterator<java.lang.Object> objItor3 = objList1.listIterator((int) (short) 0);
        org.junit.Assert.assertNotNull(objItor3);
    }
}
