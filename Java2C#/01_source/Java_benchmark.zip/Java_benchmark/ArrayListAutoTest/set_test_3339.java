package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.set(). */
    @Test
    public void set_test_3339() throws Throwable {
        java.util.ArrayList<java.io.Serializable> serializableList0 = new java.util.ArrayList<java.io.Serializable>();
        // The following exception was thrown during execution in test generation
        try {
            java.io.Serializable serializable4 = serializableList0.set((int) (short) -1, (java.io.Serializable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index -1 out of bounds for length 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
