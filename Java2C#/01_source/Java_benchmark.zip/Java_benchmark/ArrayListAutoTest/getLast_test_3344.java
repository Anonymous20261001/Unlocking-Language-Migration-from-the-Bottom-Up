package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.getLast(). */
    @Test
    public void getLast_test_3344() throws Throwable {
        java.util.ArrayList<java.lang.String> strList0 = new java.util.ArrayList<java.lang.String>();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = strList0.getLast();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
    }
}
