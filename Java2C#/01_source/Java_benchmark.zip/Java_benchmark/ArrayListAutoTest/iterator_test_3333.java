package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.iterator(). */
    @Test
    public void iterator_test_3333() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList0 = new java.util.ArrayList<java.lang.Object>();
        java.util.Iterator<java.lang.Object> objItor1 = objList0.iterator();
        org.junit.Assert.assertNotNull(objItor1);
    }
}
