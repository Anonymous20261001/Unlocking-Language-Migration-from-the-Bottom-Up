package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.replaceAll(). */
    @Test
    public void replaceAll_test_3327() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList0 = new java.util.ArrayList<java.lang.Object>();
        java.util.function.UnaryOperator<java.lang.Object> objUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            objList0.replaceAll(objUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
