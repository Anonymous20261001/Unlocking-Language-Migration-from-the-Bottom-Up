package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.removeLast(). */
    @Test
    public void removeLast_test_3348() throws Throwable {
        java.util.ArrayList<java.lang.String> strList1 = new java.util.ArrayList<java.lang.String>((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = strList1.removeLast();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
    }
}
