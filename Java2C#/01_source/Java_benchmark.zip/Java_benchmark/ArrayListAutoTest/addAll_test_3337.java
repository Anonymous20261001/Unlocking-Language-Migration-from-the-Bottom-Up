package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.addAll(). */
    @Test
    public void addAll_test_3337() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>(10);
        java.util.ArrayList<java.lang.constant.Constable> constableList3 = new java.util.ArrayList<java.lang.constant.Constable>(10);
        boolean boolean4 = constableList1.addAll((java.util.Collection<java.lang.constant.Constable>) constableList3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
