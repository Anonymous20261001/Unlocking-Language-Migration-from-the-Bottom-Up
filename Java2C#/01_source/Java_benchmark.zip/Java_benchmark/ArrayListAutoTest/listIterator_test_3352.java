package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.listIterator(). */
    @Test
    public void listIterator_test_3352() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (short) 10);
        java.util.ListIterator<java.lang.Object> objItor2 = objList1.listIterator();
        org.junit.Assert.assertNotNull(objItor2);
    }
}
