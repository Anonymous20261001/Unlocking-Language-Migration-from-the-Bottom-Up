package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.lastIndexOf(). */
    @Test
    public void lastIndexOf_test_3325() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>(100);
        java.util.ArrayList<java.lang.constant.Constable> constableList2 = new java.util.ArrayList<java.lang.constant.Constable>((java.util.Collection<java.lang.constant.Constable>) constableList1);
        int int4 = constableList2.lastIndexOf((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }
}
