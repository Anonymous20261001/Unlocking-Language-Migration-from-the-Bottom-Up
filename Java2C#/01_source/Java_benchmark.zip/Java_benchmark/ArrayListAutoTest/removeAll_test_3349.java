package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.removeAll(). */
    @Test
    public void removeAll_test_3349() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (byte) 0);
        java.util.ArrayList<java.lang.Object> objList3 = new java.util.ArrayList<java.lang.Object>((int) (byte) 100);
        boolean boolean4 = objList1.removeAll((java.util.Collection<java.lang.Object>) objList3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
