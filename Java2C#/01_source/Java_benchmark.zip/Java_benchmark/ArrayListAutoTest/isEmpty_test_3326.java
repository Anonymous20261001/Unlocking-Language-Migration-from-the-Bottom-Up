package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.isEmpty(). */
    @Test
    public void isEmpty_test_3326() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>(100);
        boolean boolean2 = constableList1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
