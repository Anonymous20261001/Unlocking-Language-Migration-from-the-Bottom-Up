package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.equals(). */
    @Test
    public void equals_test_3319() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (short) 10);
        boolean boolean4 = objList1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
