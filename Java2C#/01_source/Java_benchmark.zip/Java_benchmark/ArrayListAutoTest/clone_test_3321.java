package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.clone(). */
    @Test
    public void clone_test_3321() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>(100);
        java.lang.Object obj2 = constableList1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "[]");
    }
}
