package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.ensureCapacity(). */
    @Test
    public void ensureCapacity_test_3341() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>((int) ' ');
        constableList1.ensureCapacity((int) (short) 100);
    }
}
