package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.retainAll(). */
    @Test
    public void retainAll_test_3350() throws Throwable {
        java.util.ArrayList<java.lang.constant.Constable> constableList1 = new java.util.ArrayList<java.lang.constant.Constable>((int) (short) 100);
        java.util.ArrayList<java.lang.constant.Constable> constableList3 = new java.util.ArrayList<java.lang.constant.Constable>((int) (short) 100);
        boolean boolean4 = constableList1.retainAll((java.util.Collection<java.lang.constant.Constable>) constableList3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
