package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.getFirst(). */
    @Test
    public void getFirst_test_3343() throws Throwable {
        java.util.ArrayList<java.lang.String> strList0 = new java.util.ArrayList<java.lang.String>();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = strList0.getFirst();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
    }
}
