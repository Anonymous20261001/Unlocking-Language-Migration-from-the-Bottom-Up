package generated.test;

import org.junit.Test;

public class ArrayListAutoTest {

    /** Randoop-generated regression test for java.util.ArrayList.spliterator(). */
    @Test
    public void spliterator_test_3335() throws Throwable {
        java.util.ArrayList<java.lang.Object> objList1 = new java.util.ArrayList<java.lang.Object>((int) (byte) 100);
        java.util.Spliterator<java.lang.Object> objSpliterator2 = objList1.spliterator();
        org.junit.Assert.assertNotNull(objSpliterator2);
    }
}
