package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.addAll(). */
    @Test
    public void addAll_test_5232() throws Throwable {
        javax.accessibility.AccessibleState[] accessibleStateArray0 = new javax.accessibility.AccessibleState[] {};
        javax.accessibility.AccessibleStateSet accessibleStateSet1 = new javax.accessibility.AccessibleStateSet(accessibleStateArray0);
        javax.accessibility.AccessibleState[] accessibleStateArray2 = new javax.accessibility.AccessibleState[] {};
        accessibleStateSet1.addAll(accessibleStateArray2);
    }
}
