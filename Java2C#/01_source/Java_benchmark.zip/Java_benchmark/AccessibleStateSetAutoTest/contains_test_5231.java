package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.contains(). */
    @Test
    public void contains_test_5231() throws Throwable {
        javax.accessibility.AccessibleStateSet accessibleStateSet0 = new javax.accessibility.AccessibleStateSet();
        javax.accessibility.AccessibleState accessibleState1 = javax.accessibility.AccessibleState.ARMED;
        boolean boolean2 = accessibleStateSet0.contains(accessibleState1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
