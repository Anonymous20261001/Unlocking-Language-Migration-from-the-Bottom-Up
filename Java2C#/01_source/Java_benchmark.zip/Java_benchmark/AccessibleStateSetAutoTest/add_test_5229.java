package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.add(). */
    @Test
    public void add_test_5229() throws Throwable {
        javax.accessibility.AccessibleStateSet accessibleStateSet0 = new javax.accessibility.AccessibleStateSet();
        javax.accessibility.AccessibleState accessibleState1 = javax.accessibility.AccessibleState.ENABLED;
        boolean boolean2 = accessibleStateSet0.add(accessibleState1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
