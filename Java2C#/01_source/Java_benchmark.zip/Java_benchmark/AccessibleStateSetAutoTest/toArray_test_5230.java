package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.toArray(). */
    @Test
    public void toArray_test_5230() throws Throwable {
        javax.accessibility.AccessibleState[] accessibleStateArray0 = new javax.accessibility.AccessibleState[] {};
        javax.accessibility.AccessibleStateSet accessibleStateSet1 = new javax.accessibility.AccessibleStateSet(accessibleStateArray0);
        javax.accessibility.AccessibleState[] accessibleStateArray2 = accessibleStateSet1.toArray();
        org.junit.Assert.assertNotNull(accessibleStateArray2);
        org.junit.Assert.assertArrayEquals(accessibleStateArray2, new javax.accessibility.AccessibleState[] {});
    }
}
