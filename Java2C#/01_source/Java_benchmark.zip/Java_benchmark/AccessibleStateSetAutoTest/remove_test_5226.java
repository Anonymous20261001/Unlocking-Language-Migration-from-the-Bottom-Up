package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.remove(). */
    @Test
    public void remove_test_5226() throws Throwable {
        javax.accessibility.AccessibleStateSet accessibleStateSet0 = new javax.accessibility.AccessibleStateSet();
        javax.accessibility.AccessibleState accessibleState1 = javax.accessibility.AccessibleState.SELECTED;
        boolean boolean2 = accessibleStateSet0.remove(accessibleState1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
