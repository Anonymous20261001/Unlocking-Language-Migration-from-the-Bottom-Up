package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.clear(). */
    @Test
    public void clear_test_5228() throws Throwable {
        javax.accessibility.AccessibleState[] accessibleStateArray0 = new javax.accessibility.AccessibleState[] {};
        javax.accessibility.AccessibleStateSet accessibleStateSet1 = new javax.accessibility.AccessibleStateSet(accessibleStateArray0);
        accessibleStateSet1.clear();
    }
}
