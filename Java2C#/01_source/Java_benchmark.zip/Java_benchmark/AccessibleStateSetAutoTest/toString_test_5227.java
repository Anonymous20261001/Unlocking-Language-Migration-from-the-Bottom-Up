package generated.test;

import org.junit.Test;

public class AccessibleStateSetAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleStateSet.toString(). */
    @Test
    public void toString_test_5227() throws Throwable {
        javax.accessibility.AccessibleState[] accessibleStateArray0 = new javax.accessibility.AccessibleState[] {};
        javax.accessibility.AccessibleStateSet accessibleStateSet1 = new javax.accessibility.AccessibleStateSet(accessibleStateArray0);
        java.lang.String str2 = accessibleStateSet1.toString();
        org.junit.Assert.assertNull(str2);
    }
}
