package generated.test;

import org.junit.Test;

public class AnnotationAutoTest {

    /** Randoop-generated regression test for java.text.Annotation.toString(). */
    @Test
    public void toString_test_2994() throws Throwable {
        java.text.Annotation annotation1 = new java.text.Annotation((java.lang.Object) (byte) 100);
        java.lang.String str2 = annotation1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "java.text.Annotation[value=100]" + "'", str2, "java.text.Annotation[value=100]");
    }
}
