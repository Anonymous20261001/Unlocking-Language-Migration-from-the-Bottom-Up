package generated.test;

import org.junit.Test;

public class AnnotationAutoTest {

    /** Randoop-generated regression test for java.text.Annotation.getValue(). */
    @Test
    public void getValue_test_2995() throws Throwable {
        java.text.Annotation annotation1 = new java.text.Annotation((java.lang.Object) '4');
        java.text.Annotation annotation2 = new java.text.Annotation((java.lang.Object) annotation1);
        java.lang.Object obj3 = annotation2.getValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "java.text.Annotation[value=4]");
    }
}
