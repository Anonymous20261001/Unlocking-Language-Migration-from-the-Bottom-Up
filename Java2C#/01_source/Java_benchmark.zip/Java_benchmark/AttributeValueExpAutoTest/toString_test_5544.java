package generated.test;

import org.junit.Test;

public class AttributeValueExpAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeValueExp.toString(). */
    @Test
    public void toString_test_5544() throws Throwable {
        javax.management.AttributeValueExp attributeValueExp0 = new javax.management.AttributeValueExp();
        java.lang.String str1 = attributeValueExp0.toString();
        org.junit.Assert.assertNull(str1);
    }
}
