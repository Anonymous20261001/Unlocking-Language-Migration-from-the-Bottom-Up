package generated.test;

import org.junit.Test;

public class AttributeValueExpAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeValueExp.getAttributeName(). */
    @Test
    public void getAttributeName_test_5542() throws Throwable {
        javax.management.AttributeValueExp attributeValueExp0 = new javax.management.AttributeValueExp();
        java.lang.String str1 = attributeValueExp0.getAttributeName();
        org.junit.Assert.assertNull(str1);
    }
}
