package generated.test;

import org.junit.Test;

public class AttributeValueExpAutoTest {

    /** Randoop-generated regression test for javax.management.AttributeValueExp.setMBeanServer(). */
    @Test
    public void setMBeanServer_test_5543() throws Throwable {
        javax.management.AttributeValueExp attributeValueExp0 = new javax.management.AttributeValueExp();
        javax.management.MBeanServer mBeanServer1 = null;
        attributeValueExp0.setMBeanServer(mBeanServer1);
    }
}
