package generated.test;

import org.junit.Test;

public class AtomicMarkableReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicMarkableReference.getReference(). */
    @Test
    public void getReference_test_4885() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object> objAtomicMarkableReference3 = new java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object>(obj0, true);
        java.lang.Object obj4 = objAtomicMarkableReference3.getReference();
        org.junit.Assert.assertNotNull(obj4);
    }
}
