package generated.test;

import org.junit.Test;

public class AtomicMarkableReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicMarkableReference.isMarked(). */
    @Test
    public void isMarked_test_4882() throws Throwable {
        java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object> objAtomicMarkableReference2 = new java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object>((java.lang.Object) '4', true);
        boolean boolean3 = objAtomicMarkableReference2.isMarked();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}
