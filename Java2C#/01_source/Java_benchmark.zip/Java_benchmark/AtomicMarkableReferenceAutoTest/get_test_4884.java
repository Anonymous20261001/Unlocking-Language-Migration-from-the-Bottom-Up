package generated.test;

import org.junit.Test;

public class AtomicMarkableReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicMarkableReference.get(). */
    @Test
    public void get_test_4884() throws Throwable {
        java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object> objAtomicMarkableReference2 = new java.util.concurrent.atomic.AtomicMarkableReference<java.lang.Object>((java.lang.Object) true, true);
        boolean[] booleanArray3 = new boolean[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = objAtomicMarkableReference2.get(booleanArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
