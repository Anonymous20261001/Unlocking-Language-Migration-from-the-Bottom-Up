package generated.test;

import org.junit.Test;

public class BMPImageWriteParamAutoTest {

    /** Randoop-generated regression test for javax.imageio.plugins.bmp.BMPImageWriteParam.setTopDown(). */
    @Test
    public void setTopDown_test_5390() throws Throwable {
        javax.imageio.plugins.bmp.BMPImageWriteParam bMPImageWriteParam0 = new javax.imageio.plugins.bmp.BMPImageWriteParam();
        bMPImageWriteParam0.setTopDown(true);
    }
}
