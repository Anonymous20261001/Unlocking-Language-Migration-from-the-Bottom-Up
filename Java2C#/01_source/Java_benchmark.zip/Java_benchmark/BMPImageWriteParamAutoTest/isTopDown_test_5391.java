package generated.test;

import org.junit.Test;

public class BMPImageWriteParamAutoTest {

    /** Randoop-generated regression test for javax.imageio.plugins.bmp.BMPImageWriteParam.isTopDown(). */
    @Test
    public void isTopDown_test_5391() throws Throwable {
        java.util.Locale locale0 = null;
        javax.imageio.plugins.bmp.BMPImageWriteParam bMPImageWriteParam1 = new javax.imageio.plugins.bmp.BMPImageWriteParam(locale0);
        boolean boolean3 = bMPImageWriteParam1.isTopDown();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
