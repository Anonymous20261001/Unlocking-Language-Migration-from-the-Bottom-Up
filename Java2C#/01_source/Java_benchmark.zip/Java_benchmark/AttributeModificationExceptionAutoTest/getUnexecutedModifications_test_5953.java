package generated.test;

import org.junit.Test;

public class AttributeModificationExceptionAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.AttributeModificationException.getUnexecutedModifications(). */
    @Test
    public void getUnexecutedModifications_test_5953() throws Throwable {
        javax.naming.directory.AttributeModificationException attributeModificationException1 = new javax.naming.directory.AttributeModificationException("hi!");
        javax.naming.directory.ModificationItem[] modificationItemArray3 = attributeModificationException1.getUnexecutedModifications();
        org.junit.Assert.assertNull(modificationItemArray3);
    }
}
