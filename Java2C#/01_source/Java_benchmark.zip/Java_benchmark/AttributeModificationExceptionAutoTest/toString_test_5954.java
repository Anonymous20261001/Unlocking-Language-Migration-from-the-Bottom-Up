package generated.test;

import org.junit.Test;

public class AttributeModificationExceptionAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.AttributeModificationException.toString(). */
    @Test
    public void toString_test_5954() throws Throwable {
        javax.naming.directory.AttributeModificationException attributeModificationException1 = new javax.naming.directory.AttributeModificationException("");
        java.lang.String str4 = attributeModificationException1.toString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "javax.naming.directory.AttributeModificationException: " + "'", str4, "javax.naming.directory.AttributeModificationException: ");
    }
}
