package generated.test;

import org.junit.Test;

public class AttributeModificationExceptionAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.AttributeModificationException.setUnexecutedModifications(). */
    @Test
    public void setUnexecutedModifications_test_5952() throws Throwable {
        javax.naming.directory.AttributeModificationException attributeModificationException1 = new javax.naming.directory.AttributeModificationException("javax.naming.directory.AttributeModificationException: hi!");
        javax.naming.directory.ModificationItem[] modificationItemArray2 = new javax.naming.directory.ModificationItem[] {};
        attributeModificationException1.setUnexecutedModifications(modificationItemArray2);
    }
}
