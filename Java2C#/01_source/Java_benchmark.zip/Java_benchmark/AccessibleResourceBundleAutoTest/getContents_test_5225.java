package generated.test;

import org.junit.Test;

public class AccessibleResourceBundleAutoTest {

    /** Randoop-generated regression test for javax.accessibility.AccessibleResourceBundle.getContents(). */
    @Test
    public void getContents_test_5225() throws Throwable {
        javax.accessibility.AccessibleResourceBundle accessibleResourceBundle0 = new javax.accessibility.AccessibleResourceBundle();
        java.lang.Object[][] objArray1 = accessibleResourceBundle0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }
}
