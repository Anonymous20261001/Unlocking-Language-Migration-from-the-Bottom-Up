package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.toString(). */
    @Test
    public void toString_test_4915() throws Throwable {
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray1 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>((int) (byte) 100);
        java.lang.String str2 = strAtomicReferenceArray1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]" + "'", str2, "[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]");
    }
}
