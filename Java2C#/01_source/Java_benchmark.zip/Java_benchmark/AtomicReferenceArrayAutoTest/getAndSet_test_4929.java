package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.getAndSet(). */
    @Test
    public void getAndSet_test_4929() throws Throwable {
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray1 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>((int) (short) 10);
        java.lang.String str4 = strAtomicReferenceArray1.getAndSet((int) (short) 1, "[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]");
        org.junit.Assert.assertNull(str4);
    }
}
