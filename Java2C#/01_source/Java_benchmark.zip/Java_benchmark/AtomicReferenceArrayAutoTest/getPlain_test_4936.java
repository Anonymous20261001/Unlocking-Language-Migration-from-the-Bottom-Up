package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.getPlain(). */
    @Test
    public void getPlain_test_4936() throws Throwable {
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray1 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>((int) (short) 100);
        java.lang.String str3 = strAtomicReferenceArray1.getPlain(10);
        org.junit.Assert.assertNull(str3);
    }
}
