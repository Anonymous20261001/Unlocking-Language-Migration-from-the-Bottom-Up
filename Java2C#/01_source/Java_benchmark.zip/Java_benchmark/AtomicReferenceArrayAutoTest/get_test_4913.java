package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.get(). */
    @Test
    public void get_test_4913() throws Throwable {
        java.lang.String[] strArray1 = new java.lang.String[] { "[null]" };
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray2 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>(strArray1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = strAtomicReferenceArray2.get(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 1 out of bounds for length 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
