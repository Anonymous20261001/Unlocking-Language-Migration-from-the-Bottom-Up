package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.getAndUpdate(). */
    @Test
    public void getAndUpdate_test_4932() throws Throwable {
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray1 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>(10);
        java.util.function.UnaryOperator<java.lang.String> strUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = strAtomicReferenceArray1.getAndUpdate((int) ' ', strUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 32 out of bounds for length 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
