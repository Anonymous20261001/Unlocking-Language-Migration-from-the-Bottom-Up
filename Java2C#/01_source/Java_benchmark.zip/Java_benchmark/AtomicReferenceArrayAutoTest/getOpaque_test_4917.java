package generated.test;

import org.junit.Test;

public class AtomicReferenceArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReferenceArray.getOpaque(). */
    @Test
    public void getOpaque_test_4917() throws Throwable {
        java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String> strAtomicReferenceArray1 = new java.util.concurrent.atomic.AtomicReferenceArray<java.lang.String>(10);
        java.lang.String str3 = strAtomicReferenceArray1.getOpaque((int) (short) 1);
        org.junit.Assert.assertNull(str3);
    }
}
