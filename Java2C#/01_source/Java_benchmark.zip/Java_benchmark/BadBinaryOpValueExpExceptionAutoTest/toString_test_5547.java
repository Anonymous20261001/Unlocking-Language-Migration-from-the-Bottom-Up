package generated.test;

import org.junit.Test;

public class BadBinaryOpValueExpExceptionAutoTest {

    /** Randoop-generated regression test for javax.management.BadBinaryOpValueExpException.toString(). */
    @Test
    public void toString_test_5547() throws Throwable {
        javax.management.ValueExp valueExp0 = null;
        javax.management.BadBinaryOpValueExpException badBinaryOpValueExpException1 = new javax.management.BadBinaryOpValueExpException(valueExp0);
        java.lang.String str2 = badBinaryOpValueExpException1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "BadBinaryOpValueExpException: null" + "'", str2, "BadBinaryOpValueExpException: null");
    }
}
