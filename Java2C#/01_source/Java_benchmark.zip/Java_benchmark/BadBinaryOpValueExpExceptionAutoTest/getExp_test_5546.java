package generated.test;

import org.junit.Test;

public class BadBinaryOpValueExpExceptionAutoTest {

    /** Randoop-generated regression test for javax.management.BadBinaryOpValueExpException.getExp(). */
    @Test
    public void getExp_test_5546() throws Throwable {
        javax.management.ValueExp valueExp0 = null;
        javax.management.BadBinaryOpValueExpException badBinaryOpValueExpException1 = new javax.management.BadBinaryOpValueExpException(valueExp0);
        javax.management.ValueExp valueExp2 = badBinaryOpValueExpException1.getExp();
        org.junit.Assert.assertNull(valueExp2);
    }
}
