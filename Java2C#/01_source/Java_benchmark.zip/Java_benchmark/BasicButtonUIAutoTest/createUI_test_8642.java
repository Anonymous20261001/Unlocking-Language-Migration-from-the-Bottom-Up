package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.createUI(). */
    @Test
    public void createUI_test_8642() throws Throwable {
        javax.swing.JComponent jComponent0 = null;
        javax.swing.plaf.ComponentUI componentUI1 = javax.swing.plaf.basic.BasicButtonUI.createUI(jComponent0);
        org.junit.Assert.assertNotNull(componentUI1);
    }
}
