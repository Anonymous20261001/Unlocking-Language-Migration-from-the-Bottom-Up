package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.uninstallUI(). */
    @Test
    public void uninstallUI_test_8641() throws Throwable {
        javax.swing.plaf.basic.BasicButtonUI basicButtonUI0 = new javax.swing.plaf.basic.BasicButtonUI();
        javax.swing.JComponent jComponent3 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonUI0.uninstallUI(jComponent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.AbstractButton.getMouseMotionListeners()\" because \"b\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
