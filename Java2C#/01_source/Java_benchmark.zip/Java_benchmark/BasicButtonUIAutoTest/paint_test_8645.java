package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.paint(). */
    @Test
    public void paint_test_8645() throws Throwable {
        javax.swing.plaf.basic.BasicButtonUI basicButtonUI0 = new javax.swing.plaf.basic.BasicButtonUI();
        java.awt.Graphics graphics1 = null;
        javax.swing.JComponent jComponent2 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonUI0.paint(graphics1, jComponent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.AbstractButton.getModel()\" because \"b\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
