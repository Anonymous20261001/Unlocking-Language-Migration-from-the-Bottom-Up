package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.getBaseline(). */
    @Test
    public void getBaseline_test_8648() throws Throwable {
        javax.swing.plaf.basic.BasicButtonUI basicButtonUI0 = new javax.swing.plaf.basic.BasicButtonUI();
        javax.swing.JComponent jComponent1 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int4 = basicButtonUI0.getBaseline(jComponent1, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Component must be non-null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
