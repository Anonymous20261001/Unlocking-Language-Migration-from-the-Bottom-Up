package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.getDefaultTextIconGap(). */
    @Test
    public void getDefaultTextIconGap_test_8643() throws Throwable {
        javax.swing.plaf.basic.BasicButtonUI basicButtonUI0 = new javax.swing.plaf.basic.BasicButtonUI();
        javax.swing.AbstractButton abstractButton1 = null;
        int int2 = basicButtonUI0.getDefaultTextIconGap(abstractButton1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
