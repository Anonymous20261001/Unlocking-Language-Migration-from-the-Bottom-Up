package generated.test;

import org.junit.Test;

public class BasicButtonUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonUI.getBaselineResizeBehavior(). */
    @Test
    public void getBaselineResizeBehavior_test_8649() throws Throwable {
        javax.swing.plaf.basic.BasicButtonUI basicButtonUI0 = new javax.swing.plaf.basic.BasicButtonUI();
        javax.swing.JComponent jComponent3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.awt.Component.BaselineResizeBehavior baselineResizeBehavior4 = basicButtonUI0.getBaselineResizeBehavior(jComponent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Component must be non-null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
