package generated.test;

import org.junit.Test;

public class BasicCheckBoxUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicCheckBoxUI.getPropertyPrefix(). */
    @Test
    public void getPropertyPrefix_test_8653() throws Throwable {
        javax.swing.plaf.basic.BasicCheckBoxUI basicCheckBoxUI0 = new javax.swing.plaf.basic.BasicCheckBoxUI();
        java.lang.String str1 = basicCheckBoxUI0.getPropertyPrefix();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "CheckBox." + "'", str1, "CheckBox.");
    }
}
