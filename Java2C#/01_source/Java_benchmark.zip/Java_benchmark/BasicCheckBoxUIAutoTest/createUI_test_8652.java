package generated.test;

import org.junit.Test;

public class BasicCheckBoxUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicCheckBoxUI.createUI(). */
    @Test
    public void createUI_test_8652() throws Throwable {
        javax.swing.JComponent jComponent0 = null;
        javax.swing.plaf.ComponentUI componentUI1 = javax.swing.plaf.basic.BasicCheckBoxUI.createUI(jComponent0);
        org.junit.Assert.assertNotNull(componentUI1);
    }
}
