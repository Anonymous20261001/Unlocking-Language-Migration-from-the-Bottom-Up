package generated.test;

import org.junit.Test;

public class AllPermissionAutoTest {

    /** Randoop-generated regression test for java.security.AllPermission.implies(). */
    @Test
    public void implies_test_2682() throws Throwable {
        java.security.AllPermission allPermission0 = new java.security.AllPermission();
        java.security.AllPermission allPermission1 = new java.security.AllPermission();
        boolean boolean2 = allPermission0.implies((java.security.Permission) allPermission1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
