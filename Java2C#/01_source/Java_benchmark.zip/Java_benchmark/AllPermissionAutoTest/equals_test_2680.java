package generated.test;

import org.junit.Test;

public class AllPermissionAutoTest {

    /** Randoop-generated regression test for java.security.AllPermission.equals(). */
    @Test
    public void equals_test_2680() throws Throwable {
        java.security.AllPermission allPermission2 = new java.security.AllPermission("", "");
        boolean boolean4 = allPermission2.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
