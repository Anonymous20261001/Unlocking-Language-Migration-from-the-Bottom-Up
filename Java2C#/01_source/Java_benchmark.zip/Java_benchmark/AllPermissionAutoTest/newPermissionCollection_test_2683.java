package generated.test;

import org.junit.Test;

public class AllPermissionAutoTest {

    /** Randoop-generated regression test for java.security.AllPermission.newPermissionCollection(). */
    @Test
    public void newPermissionCollection_test_2683() throws Throwable {
        java.security.AllPermission allPermission0 = new java.security.AllPermission();
        java.security.PermissionCollection permissionCollection1 = allPermission0.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection1);
    }
}
