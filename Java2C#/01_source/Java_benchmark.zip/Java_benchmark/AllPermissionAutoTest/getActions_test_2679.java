package generated.test;

import org.junit.Test;

public class AllPermissionAutoTest {

    /** Randoop-generated regression test for java.security.AllPermission.getActions(). */
    @Test
    public void getActions_test_2679() throws Throwable {
        java.security.AllPermission allPermission2 = new java.security.AllPermission("", "hi!");
        java.lang.String str3 = allPermission2.getActions();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "<all actions>" + "'", str3, "<all actions>");
    }
}
