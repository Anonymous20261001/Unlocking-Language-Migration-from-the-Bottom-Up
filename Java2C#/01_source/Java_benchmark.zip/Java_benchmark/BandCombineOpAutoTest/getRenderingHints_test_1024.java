package generated.test;

import org.junit.Test;

public class BandCombineOpAutoTest {

    /** Randoop-generated regression test for java.awt.image.BandCombineOp.getRenderingHints(). */
    @Test
    public void getRenderingHints_test_1024() throws Throwable {
        float[] floatArray0 = new float[] {};
        float[][] floatArray1 = new float[][] { floatArray0 };
        java.awt.RenderingHints renderingHints2 = null;
        java.awt.image.BandCombineOp bandCombineOp3 = new java.awt.image.BandCombineOp(floatArray1, renderingHints2);
        java.awt.RenderingHints renderingHints4 = bandCombineOp3.getRenderingHints();
        org.junit.Assert.assertNull(renderingHints4);
    }
}
