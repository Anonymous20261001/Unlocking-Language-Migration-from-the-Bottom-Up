package generated.test;

import org.junit.Test;

public class BandCombineOpAutoTest {

    /** Randoop-generated regression test for java.awt.image.BandCombineOp.getMatrix(). */
    @Test
    public void getMatrix_test_1026() throws Throwable {
        float[] floatArray0 = new float[] {};
        float[][] floatArray1 = new float[][] { floatArray0 };
        java.awt.RenderingHints renderingHints2 = null;
        java.awt.image.BandCombineOp bandCombineOp3 = new java.awt.image.BandCombineOp(floatArray1, renderingHints2);
        float[][] floatArray4 = bandCombineOp3.getMatrix();
        org.junit.Assert.assertNotNull(floatArray4);
    }
}
