package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getShearX(). */
    @Test
    public void getShearX_test_938() throws Throwable {
        java.awt.geom.AffineTransform affineTransform3 = java.awt.geom.AffineTransform.getQuadrantRotateInstance((int) '4', (double) 0, (double) (byte) 1);
        double double4 = affineTransform3.getShearX();
        org.junit.Assert.assertNotNull(affineTransform3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }
}
