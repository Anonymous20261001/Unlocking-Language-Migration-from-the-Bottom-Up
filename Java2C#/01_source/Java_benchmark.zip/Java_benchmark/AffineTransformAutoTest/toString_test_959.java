package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.toString(). */
    @Test
    public void toString_test_959() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance((double) 100L, (double) 100L);
        java.lang.String str3 = affineTransform2.toString();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "AffineTransform[[1.0, 100.0, 0.0], [100.0, 1.0, 0.0]]" + "'", str3, "AffineTransform[[1.0, 100.0, 0.0], [100.0, 1.0, 0.0]]");
    }
}
