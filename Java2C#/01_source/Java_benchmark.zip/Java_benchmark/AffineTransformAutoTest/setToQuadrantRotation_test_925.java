package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.setToQuadrantRotation(). */
    @Test
    public void setToQuadrantRotation_test_925() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance((double) 100L, (double) (byte) 0);
        affineTransform2.setToQuadrantRotation(10);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
