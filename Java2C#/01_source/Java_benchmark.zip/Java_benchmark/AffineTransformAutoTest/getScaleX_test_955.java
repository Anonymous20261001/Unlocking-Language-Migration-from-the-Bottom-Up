package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getScaleX(). */
    @Test
    public void getScaleX_test_955() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getTranslateInstance((double) 10L, 10.0d);
        double double3 = affineTransform2.getScaleX();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }
}
