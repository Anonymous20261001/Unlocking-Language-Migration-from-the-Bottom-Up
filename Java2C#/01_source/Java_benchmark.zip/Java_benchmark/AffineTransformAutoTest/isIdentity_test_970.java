package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.isIdentity(). */
    @Test
    public void isIdentity_test_970() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance((double) 8, 100.0d);
        boolean boolean3 = affineTransform2.isIdentity();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
