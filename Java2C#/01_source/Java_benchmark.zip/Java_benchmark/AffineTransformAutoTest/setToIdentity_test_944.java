package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.setToIdentity(). */
    @Test
    public void setToIdentity_test_944() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getRotateInstance((double) (short) -1, (double) 64);
        affineTransform2.setToIdentity();
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
