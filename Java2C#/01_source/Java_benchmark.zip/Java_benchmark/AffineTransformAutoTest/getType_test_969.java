package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getType(). */
    @Test
    public void getType_test_969() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getQuadrantRotateInstance((int) (short) 0);
        int int2 = affineTransform1.getType();
        org.junit.Assert.assertNotNull(affineTransform1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
