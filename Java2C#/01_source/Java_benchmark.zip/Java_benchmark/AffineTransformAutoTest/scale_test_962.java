package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.scale(). */
    @Test
    public void scale_test_962() throws Throwable {
        java.awt.geom.AffineTransform affineTransform0 = new java.awt.geom.AffineTransform();
        affineTransform0.scale((double) 10.0f, (double) 8);
    }
}
