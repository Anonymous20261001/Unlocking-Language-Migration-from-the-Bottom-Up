package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.rotate(). */
    @Test
    public void rotate_test_974() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getScaleInstance((double) 0, (double) 100L);
        affineTransform2.rotate((double) 2);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
