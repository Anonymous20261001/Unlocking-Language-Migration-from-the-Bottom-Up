package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.createTransformedShape(). */
    @Test
    public void createTransformedShape_test_945() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getScaleInstance((double) 0, (double) 100L);
        java.awt.Shape shape3 = null;
        java.awt.Shape shape4 = affineTransform2.createTransformedShape(shape3);
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertNull(shape4);
    }
}
