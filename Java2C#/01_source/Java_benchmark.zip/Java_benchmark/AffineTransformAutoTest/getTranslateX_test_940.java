package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getTranslateX(). */
    @Test
    public void getTranslateX_test_940() throws Throwable {
        java.awt.geom.AffineTransform affineTransform3 = java.awt.geom.AffineTransform.getRotateInstance((double) (byte) 0, (double) 100, (double) 1);
        double double4 = affineTransform3.getTranslateX();
        org.junit.Assert.assertNotNull(affineTransform3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }
}
