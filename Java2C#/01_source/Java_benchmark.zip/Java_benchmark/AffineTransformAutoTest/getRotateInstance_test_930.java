package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getRotateInstance(). */
    @Test
    public void getRotateInstance_test_930() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getRotateInstance((double) (byte) 100, (double) (short) 10);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
