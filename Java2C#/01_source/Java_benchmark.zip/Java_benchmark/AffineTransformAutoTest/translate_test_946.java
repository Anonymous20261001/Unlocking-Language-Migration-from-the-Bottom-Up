package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.translate(). */
    @Test
    public void translate_test_946() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getRotateInstance((double) ' ');
        affineTransform1.translate((double) 16, (-1.0d));
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
