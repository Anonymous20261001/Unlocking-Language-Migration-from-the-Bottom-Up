package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.rotate(). */
    @Test
    public void rotate_test_972() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getRotateInstance(10.0d);
        affineTransform1.rotate((-1.0d), 10.0d);
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
