package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getShearInstance(). */
    @Test
    public void getShearInstance_test_936() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance(0.0d, 0.0d);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
