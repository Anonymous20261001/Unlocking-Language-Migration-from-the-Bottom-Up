package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.clone(). */
    @Test
    public void clone_test_961() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance((double) (short) 10, (double) 4);
        java.lang.Object obj3 = affineTransform2.clone();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "AffineTransform[[1.0, 10.0, 0.0], [4.0, 1.0, 0.0]]");
    }
}
