package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getScaleY(). */
    @Test
    public void getScaleY_test_956() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getQuadrantRotateInstance(100);
        double double2 = affineTransform1.getScaleY();
        org.junit.Assert.assertNotNull(affineTransform1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }
}
