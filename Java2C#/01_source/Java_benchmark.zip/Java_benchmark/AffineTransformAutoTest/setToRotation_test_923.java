package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.setToRotation(). */
    @Test
    public void setToRotation_test_923() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getRotateInstance(10.0d);
        affineTransform1.setToRotation((double) 16);
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
