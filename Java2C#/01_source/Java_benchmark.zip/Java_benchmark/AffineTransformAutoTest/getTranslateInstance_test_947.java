package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getTranslateInstance(). */
    @Test
    public void getTranslateInstance_test_947() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getTranslateInstance((double) 0L, 1.0d);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
