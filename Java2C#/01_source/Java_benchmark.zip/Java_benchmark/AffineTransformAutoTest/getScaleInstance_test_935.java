package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getScaleInstance(). */
    @Test
    public void getScaleInstance_test_935() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getScaleInstance((double) 'a', (double) 0.0f);
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
