package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.shear(). */
    @Test
    public void shear_test_943() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getRotateInstance(0.0d);
        affineTransform1.shear(0.0d, (-1.0d));
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
