package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.equals(). */
    @Test
    public void equals_test_958() throws Throwable {
        java.awt.geom.AffineTransform affineTransform0 = new java.awt.geom.AffineTransform();
        boolean boolean2 = affineTransform0.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
