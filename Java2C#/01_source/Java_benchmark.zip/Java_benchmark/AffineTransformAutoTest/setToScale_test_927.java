package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.setToScale(). */
    @Test
    public void setToScale_test_927() throws Throwable {
        java.awt.geom.AffineTransform affineTransform0 = new java.awt.geom.AffineTransform();
        affineTransform0.setToScale(0.5440211108893698d, (double) (short) 1);
    }
}
