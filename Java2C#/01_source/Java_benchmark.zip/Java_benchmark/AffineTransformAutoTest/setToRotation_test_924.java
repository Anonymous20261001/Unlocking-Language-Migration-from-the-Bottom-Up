package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.setToRotation(). */
    @Test
    public void setToRotation_test_924() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getQuadrantRotateInstance((int) (short) 0);
        affineTransform1.setToRotation((-39.0d), (double) 2);
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
