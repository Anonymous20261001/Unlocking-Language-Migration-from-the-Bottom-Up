package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getTranslateY(). */
    @Test
    public void getTranslateY_test_949() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getQuadrantRotateInstance((int) (byte) 0);
        double double2 = affineTransform1.getTranslateY();
        org.junit.Assert.assertNotNull(affineTransform1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }
}
