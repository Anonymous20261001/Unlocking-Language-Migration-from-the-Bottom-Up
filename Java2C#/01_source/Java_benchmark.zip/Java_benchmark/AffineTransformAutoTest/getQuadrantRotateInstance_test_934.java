package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getQuadrantRotateInstance(). */
    @Test
    public void getQuadrantRotateInstance_test_934() throws Throwable {
        java.awt.geom.AffineTransform affineTransform1 = java.awt.geom.AffineTransform.getQuadrantRotateInstance(2);
        org.junit.Assert.assertNotNull(affineTransform1);
    }
}
