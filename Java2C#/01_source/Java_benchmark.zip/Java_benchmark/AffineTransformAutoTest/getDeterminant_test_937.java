package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getDeterminant(). */
    @Test
    public void getDeterminant_test_937() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getTranslateInstance((double) 0.0f, (double) 10);
        double double3 = affineTransform2.getDeterminant();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }
}
