package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.getShearY(). */
    @Test
    public void getShearY_test_939() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getScaleInstance((double) 100, 1.0d);
        double double3 = affineTransform2.getShearY();
        org.junit.Assert.assertNotNull(affineTransform2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }
}
