package generated.test;

import org.junit.Test;

public class AffineTransformAutoTest {

    /** Randoop-generated regression test for java.awt.geom.AffineTransform.preConcatenate(). */
    @Test
    public void preConcatenate_test_948() throws Throwable {
        java.awt.geom.AffineTransform affineTransform2 = java.awt.geom.AffineTransform.getShearInstance((double) (-1), (double) '#');
        java.awt.geom.AffineTransform affineTransform3 = null;
        // The following exception was thrown during execution in test generation
        try {
            affineTransform2.preConcatenate(affineTransform3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot read field \"state\" because \"Tx\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(affineTransform2);
    }
}
