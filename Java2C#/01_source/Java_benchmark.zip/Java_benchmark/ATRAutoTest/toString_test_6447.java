package generated.test;

import org.junit.Test;

public class ATRAutoTest {

    /** Randoop-generated regression test for javax.smartcardio.ATR.toString(). */
    @Test
    public void toString_test_6447() throws Throwable {
        byte[] byteArray0 = new byte[] {};
        javax.smartcardio.ATR aTR1 = new javax.smartcardio.ATR(byteArray0);
        java.lang.String str2 = aTR1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "ATR: 0 bytes" + "'", str2, "ATR: 0 bytes");
    }
}
