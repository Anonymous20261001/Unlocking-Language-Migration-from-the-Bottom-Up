package generated.test;

import org.junit.Test;

public class ATRAutoTest {

    /** Randoop-generated regression test for javax.smartcardio.ATR.getBytes(). */
    @Test
    public void getBytes_test_6449() throws Throwable {
        byte[] byteArray0 = new byte[] {};
        javax.smartcardio.ATR aTR1 = new javax.smartcardio.ATR(byteArray0);
        byte[] byteArray2 = aTR1.getBytes();
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertArrayEquals(byteArray2, new byte[] {});
    }
}
