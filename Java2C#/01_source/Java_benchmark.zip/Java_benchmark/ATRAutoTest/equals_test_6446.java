package generated.test;

import org.junit.Test;

public class ATRAutoTest {

    /** Randoop-generated regression test for javax.smartcardio.ATR.equals(). */
    @Test
    public void equals_test_6446() throws Throwable {
        byte[] byteArray0 = new byte[] {};
        javax.smartcardio.ATR aTR1 = new javax.smartcardio.ATR(byteArray0);
        boolean boolean3 = aTR1.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
