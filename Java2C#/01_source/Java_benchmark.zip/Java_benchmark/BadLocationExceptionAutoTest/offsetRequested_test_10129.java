package generated.test;

import org.junit.Test;

public class BadLocationExceptionAutoTest {

    /** Randoop-generated regression test for javax.swing.text.BadLocationException.offsetRequested(). */
    @Test
    public void offsetRequested_test_10129() throws Throwable {
        javax.swing.text.BadLocationException badLocationException2 = new javax.swing.text.BadLocationException("hi!", 1);
        int int3 = badLocationException2.offsetRequested();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }
}
