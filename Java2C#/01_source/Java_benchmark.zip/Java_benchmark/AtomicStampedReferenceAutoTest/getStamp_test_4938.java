package generated.test;

import org.junit.Test;

public class AtomicStampedReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicStampedReference.getStamp(). */
    @Test
    public void getStamp_test_4938() throws Throwable {
        java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object> objAtomicStampedReference2 = new java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object>((java.lang.Object) (byte) -1, 1);
        int int3 = objAtomicStampedReference2.getStamp();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }
}
