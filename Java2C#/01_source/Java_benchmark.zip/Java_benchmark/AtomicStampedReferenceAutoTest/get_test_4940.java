package generated.test;

import org.junit.Test;

public class AtomicStampedReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicStampedReference.get(). */
    @Test
    public void get_test_4940() throws Throwable {
        java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object> objAtomicStampedReference2 = new java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object>((java.lang.Object) false, 1);
        int[] intArray3 = new int[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj4 = objAtomicStampedReference2.get(intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
