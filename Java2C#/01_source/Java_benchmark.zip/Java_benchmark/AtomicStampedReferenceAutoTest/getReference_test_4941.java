package generated.test;

import org.junit.Test;

public class AtomicStampedReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicStampedReference.getReference(). */
    @Test
    public void getReference_test_4941() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object> objAtomicStampedReference3 = new java.util.concurrent.atomic.AtomicStampedReference<java.lang.Object>(obj0, 1);
        java.lang.Object obj4 = objAtomicStampedReference3.getReference();
        org.junit.Assert.assertNotNull(obj4);
    }
}
