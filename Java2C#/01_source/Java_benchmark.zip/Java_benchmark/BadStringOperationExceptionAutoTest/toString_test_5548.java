package generated.test;

import org.junit.Test;

public class BadStringOperationExceptionAutoTest {

    /** Randoop-generated regression test for javax.management.BadStringOperationException.toString(). */
    @Test
    public void toString_test_5548() throws Throwable {
        javax.management.BadStringOperationException badStringOperationException1 = new javax.management.BadStringOperationException("");
        java.lang.String str2 = badStringOperationException1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "BadStringOperationException: " + "'", str2, "BadStringOperationException: ");
    }
}
