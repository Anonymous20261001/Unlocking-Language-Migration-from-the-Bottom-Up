package generated.test;

import org.junit.Test;

public class BasicColorChooserUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicColorChooserUI.createUI(). */
    @Test
    public void createUI_test_8656() throws Throwable {
        javax.swing.JComponent jComponent0 = null;
        javax.swing.plaf.ComponentUI componentUI1 = javax.swing.plaf.basic.BasicColorChooserUI.createUI(jComponent0);
        org.junit.Assert.assertNotNull(componentUI1);
    }
}
