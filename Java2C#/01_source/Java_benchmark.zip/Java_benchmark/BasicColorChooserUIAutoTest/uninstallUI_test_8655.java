package generated.test;

import org.junit.Test;

public class BasicColorChooserUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicColorChooserUI.uninstallUI(). */
    @Test
    public void uninstallUI_test_8655() throws Throwable {
        javax.swing.plaf.basic.BasicColorChooserUI basicColorChooserUI0 = new javax.swing.plaf.basic.BasicColorChooserUI();
        javax.swing.JComponent jComponent3 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicColorChooserUI0.uninstallUI(jComponent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.JColorChooser.remove(java.awt.Component)\" because \"this.chooser\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
