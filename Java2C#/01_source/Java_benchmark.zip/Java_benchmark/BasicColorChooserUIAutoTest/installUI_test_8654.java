package generated.test;

import org.junit.Test;

public class BasicColorChooserUIAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicColorChooserUI.installUI(). */
    @Test
    public void installUI_test_8654() throws Throwable {
        javax.swing.plaf.basic.BasicColorChooserUI basicColorChooserUI0 = new javax.swing.plaf.basic.BasicColorChooserUI();
        javax.swing.JComponent jComponent3 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicColorChooserUI0.installUI(jComponent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.JComponent.getFont()\" because \"c\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
