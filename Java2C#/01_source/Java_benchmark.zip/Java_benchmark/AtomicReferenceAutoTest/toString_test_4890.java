package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.toString(). */
    @Test
    public void toString_test_4890() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>((java.lang.invoke.TypeDescriptor) wildcardClass1);
        java.lang.String str3 = typeDescriptorAtomicReference2.toString();
        java.lang.String str4 = typeDescriptorAtomicReference2.toString();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "class java.lang.Object" + "'", str3, "class java.lang.Object");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "class java.lang.Object" + "'", str4, "class java.lang.Object");
    }
}
