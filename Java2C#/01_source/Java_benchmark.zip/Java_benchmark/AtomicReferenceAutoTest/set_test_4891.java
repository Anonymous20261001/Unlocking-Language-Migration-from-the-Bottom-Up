package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.set(). */
    @Test
    public void set_test_4891() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>((java.lang.invoke.TypeDescriptor) wildcardClass1);
        java.lang.invoke.TypeDescriptor typeDescriptor3 = null;
        typeDescriptorAtomicReference2.set(typeDescriptor3);
    }
}
