package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.get(). */
    @Test
    public void get_test_4889() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>((java.lang.invoke.TypeDescriptor) wildcardClass1);
        java.lang.invoke.TypeDescriptor typeDescriptor3 = typeDescriptorAtomicReference2.get();
        org.junit.Assert.assertNotNull(typeDescriptor3);
    }
}
