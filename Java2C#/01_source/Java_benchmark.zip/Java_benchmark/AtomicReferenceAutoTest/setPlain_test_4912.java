package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.setPlain(). */
    @Test
    public void setPlain_test_4912() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.lang.invoke.TypeDescriptor typeDescriptor3 = null;
        typeDescriptorAtomicReference0.setPlain(typeDescriptor3);
    }
}
