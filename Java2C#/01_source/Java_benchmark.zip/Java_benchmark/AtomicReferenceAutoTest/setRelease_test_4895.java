package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.setRelease(). */
    @Test
    public void setRelease_test_4895() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable> constableAtomicReference1 = new java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable>();
        java.lang.Class<?> wildcardClass2 = constableAtomicReference1.getClass();
        typeDescriptorAtomicReference0.setRelease((java.lang.invoke.TypeDescriptor) wildcardClass2);
    }
}
