package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.getAndSet(). */
    @Test
    public void getAndSet_test_4904() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable> constableAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable>((java.lang.constant.Constable) 10.0d);
        java.lang.Class<?> wildcardClass3 = constableAtomicReference2.getClass();
        java.lang.invoke.TypeDescriptor typeDescriptor4 = typeDescriptorAtomicReference0.getAndSet((java.lang.invoke.TypeDescriptor) wildcardClass3);
        org.junit.Assert.assertNull(typeDescriptor4);
    }
}
