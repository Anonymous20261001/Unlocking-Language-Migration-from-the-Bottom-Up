package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.getAndUpdate(). */
    @Test
    public void getAndUpdate_test_4907() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>((java.lang.invoke.TypeDescriptor) wildcardClass1);
        java.util.function.UnaryOperator<java.lang.invoke.TypeDescriptor> typeDescriptorUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.TypeDescriptor typeDescriptor4 = typeDescriptorAtomicReference2.getAndUpdate(typeDescriptorUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.UnaryOperator.apply(Object)\" because \"updateFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
