package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.getAndAccumulate(). */
    @Test
    public void getAndAccumulate_test_4909() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.lang.invoke.TypeDescriptor typeDescriptor2 = null;
        java.util.function.BinaryOperator<java.lang.invoke.TypeDescriptor> typeDescriptorBinaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.invoke.TypeDescriptor typeDescriptor4 = typeDescriptorAtomicReference0.getAndAccumulate(typeDescriptor2, typeDescriptorBinaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.BinaryOperator.apply(Object, Object)\" because \"accumulatorFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
