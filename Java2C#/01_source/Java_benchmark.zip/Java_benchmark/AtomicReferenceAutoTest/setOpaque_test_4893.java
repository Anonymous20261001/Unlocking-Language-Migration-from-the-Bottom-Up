package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.setOpaque(). */
    @Test
    public void setOpaque_test_4893() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.lang.invoke.TypeDescriptor typeDescriptor1 = null;
        typeDescriptorAtomicReference0.setOpaque(typeDescriptor1);
    }
}
