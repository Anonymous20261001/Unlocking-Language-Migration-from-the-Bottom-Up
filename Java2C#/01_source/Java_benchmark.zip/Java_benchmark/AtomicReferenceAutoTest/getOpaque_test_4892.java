package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.getOpaque(). */
    @Test
    public void getOpaque_test_4892() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.lang.invoke.TypeDescriptor typeDescriptor1 = typeDescriptorAtomicReference0.getOpaque();
        org.junit.Assert.assertNull(typeDescriptor1);
    }
}
