package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.getPlain(). */
    @Test
    public void getPlain_test_4911() throws Throwable {
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>((java.lang.invoke.TypeDescriptor) wildcardClass1);
        java.lang.invoke.TypeDescriptor typeDescriptor3 = typeDescriptorAtomicReference2.getPlain();
        org.junit.Assert.assertNotNull(typeDescriptor3);
    }
}
