package generated.test;

import org.junit.Test;

public class AtomicReferenceAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicReference.lazySet(). */
    @Test
    public void lazySet_test_4906() throws Throwable {
        java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor> typeDescriptorAtomicReference0 = new java.util.concurrent.atomic.AtomicReference<java.lang.invoke.TypeDescriptor>();
        java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable> constableAtomicReference2 = new java.util.concurrent.atomic.AtomicReference<java.lang.constant.Constable>();
        java.lang.Class<?> wildcardClass3 = constableAtomicReference2.getClass();
        typeDescriptorAtomicReference0.lazySet((java.lang.invoke.TypeDescriptor) wildcardClass3);
    }
}
