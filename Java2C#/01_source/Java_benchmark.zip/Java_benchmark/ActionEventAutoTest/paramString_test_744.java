package generated.test;

import org.junit.Test;

public class ActionEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.ActionEvent.paramString(). */
    @Test
    public void paramString_test_744() throws Throwable {
        java.awt.event.ActionEvent actionEvent3 = new java.awt.event.ActionEvent((java.lang.Object) (-1.0f), 0, "hi!");
        java.lang.String str4 = actionEvent3.paramString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "unknown type,cmd=hi!,when=0,modifiers=" + "'", str4, "unknown type,cmd=hi!,when=0,modifiers=");
    }
}
