package generated.test;

import org.junit.Test;

public class ActionEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.ActionEvent.getModifiers(). */
    @Test
    public void getModifiers_test_743() throws Throwable {
        java.awt.event.ActionEvent actionEvent3 = new java.awt.event.ActionEvent((java.lang.Object) (-1.0f), 0, "hi!");
        int int4 = actionEvent3.getModifiers();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }
}
