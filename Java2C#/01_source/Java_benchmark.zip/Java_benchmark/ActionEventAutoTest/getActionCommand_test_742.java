package generated.test;

import org.junit.Test;

public class ActionEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.ActionEvent.getActionCommand(). */
    @Test
    public void getActionCommand_test_742() throws Throwable {
        java.awt.event.ActionEvent actionEvent3 = new java.awt.event.ActionEvent((java.lang.Object) (-1.0f), 0, "hi!");
        java.lang.String str4 = actionEvent3.getActionCommand();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "hi!" + "'", str4, "hi!");
    }
}
