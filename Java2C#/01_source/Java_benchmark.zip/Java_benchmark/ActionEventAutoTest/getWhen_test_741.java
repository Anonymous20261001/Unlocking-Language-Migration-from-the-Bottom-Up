package generated.test;

import org.junit.Test;

public class ActionEventAutoTest {

    /** Randoop-generated regression test for java.awt.event.ActionEvent.getWhen(). */
    @Test
    public void getWhen_test_741() throws Throwable {
        java.awt.event.ActionEvent actionEvent3 = new java.awt.event.ActionEvent((java.lang.Object) (short) 100, 0, "hi!");
        long long4 = actionEvent3.getWhen();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }
}
