package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.setAuthorizedID(). */
    @Test
    public void setAuthorizedID_test_6442() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        authorizeCallback2.setAuthorizedID("");
    }
}
