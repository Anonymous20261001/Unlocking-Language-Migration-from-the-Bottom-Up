package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.getAuthorizedID(). */
    @Test
    public void getAuthorizedID_test_6441() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        java.lang.String str3 = authorizeCallback2.getAuthorizedID();
        org.junit.Assert.assertNull(str3);
    }
}
