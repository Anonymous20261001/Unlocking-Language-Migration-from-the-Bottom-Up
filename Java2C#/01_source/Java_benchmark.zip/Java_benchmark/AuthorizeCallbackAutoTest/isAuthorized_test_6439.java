package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.isAuthorized(). */
    @Test
    public void isAuthorized_test_6439() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        boolean boolean3 = authorizeCallback2.isAuthorized();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
