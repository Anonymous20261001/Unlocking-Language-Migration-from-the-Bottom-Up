package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.setAuthorized(). */
    @Test
    public void setAuthorized_test_6440() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        authorizeCallback2.setAuthorized(true);
    }
}
