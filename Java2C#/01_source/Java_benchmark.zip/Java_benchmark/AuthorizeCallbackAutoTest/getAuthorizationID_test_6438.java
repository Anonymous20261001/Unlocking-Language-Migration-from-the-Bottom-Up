package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.getAuthorizationID(). */
    @Test
    public void getAuthorizationID_test_6438() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        java.lang.String str3 = authorizeCallback2.getAuthorizationID();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
