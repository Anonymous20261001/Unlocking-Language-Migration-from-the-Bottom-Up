package generated.test;

import org.junit.Test;

public class AuthorizeCallbackAutoTest {

    /** Randoop-generated regression test for javax.security.sasl.AuthorizeCallback.getAuthenticationID(). */
    @Test
    public void getAuthenticationID_test_6437() throws Throwable {
        javax.security.sasl.AuthorizeCallback authorizeCallback2 = new javax.security.sasl.AuthorizeCallback("", "");
        java.lang.String str3 = authorizeCallback2.getAuthenticationID();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
