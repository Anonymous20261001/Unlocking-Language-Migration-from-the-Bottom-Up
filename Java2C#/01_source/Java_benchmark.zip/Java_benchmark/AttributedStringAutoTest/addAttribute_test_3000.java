package generated.test;

import org.junit.Test;

public class AttributedStringAutoTest {

    /** Randoop-generated regression test for java.text.AttributedString.addAttribute(). */
    @Test
    public void addAttribute_test_3000() throws Throwable {
        java.text.AttributedString attributedString1 = new java.text.AttributedString("");
        java.text.AttributedCharacterIterator.Attribute attribute2 = null;
        // The following exception was thrown during execution in test generation
        try {
            attributedString1.addAttribute(attribute2, (java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
