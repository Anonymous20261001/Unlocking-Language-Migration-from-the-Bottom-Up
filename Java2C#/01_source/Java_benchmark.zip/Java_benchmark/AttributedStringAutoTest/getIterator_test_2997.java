package generated.test;

import org.junit.Test;

public class AttributedStringAutoTest {

    /** Randoop-generated regression test for java.text.AttributedString.getIterator(). */
    @Test
    public void getIterator_test_2997() throws Throwable {
        java.text.AttributedString attributedString1 = new java.text.AttributedString("");
        java.text.AttributedCharacterIterator.Attribute[] attributeArray2 = new java.text.AttributedCharacterIterator.Attribute[] {};
        java.text.AttributedCharacterIterator attributedCharacterIterator3 = attributedString1.getIterator(attributeArray2);
        org.junit.Assert.assertNotNull(attributedCharacterIterator3);
    }
}
