package generated.test;

import org.junit.Test;

public class AttributedStringAutoTest {

    /** Randoop-generated regression test for java.text.AttributedString.getIterator(). */
    @Test
    public void getIterator_test_2999() throws Throwable {
        java.text.AttributedString attributedString1 = new java.text.AttributedString("");
        java.text.AttributedCharacterIterator attributedCharacterIterator2 = attributedString1.getIterator();
        org.junit.Assert.assertNotNull(attributedCharacterIterator2);
    }
}
