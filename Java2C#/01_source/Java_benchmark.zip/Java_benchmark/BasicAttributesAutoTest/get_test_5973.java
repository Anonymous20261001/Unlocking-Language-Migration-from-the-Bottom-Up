package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.get(). */
    @Test
    public void get_test_5973() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(false);
        javax.naming.directory.Attribute attribute3 = basicAttributes1.get("No attributes");
        org.junit.Assert.assertNull(attribute3);
    }
}
