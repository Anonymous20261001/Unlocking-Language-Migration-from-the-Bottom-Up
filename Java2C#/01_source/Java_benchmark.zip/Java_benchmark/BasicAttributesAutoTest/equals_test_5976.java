package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.equals(). */
    @Test
    public void equals_test_5976() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(false);
        boolean boolean3 = basicAttributes1.equals((java.lang.Object) "No attributes");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
