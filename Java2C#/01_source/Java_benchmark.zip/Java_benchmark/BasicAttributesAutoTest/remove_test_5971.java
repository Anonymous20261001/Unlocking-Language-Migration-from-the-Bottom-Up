package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.remove(). */
    @Test
    public void remove_test_5971() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(true);
        javax.naming.directory.Attribute attribute3 = basicAttributes1.remove("hi!");
        org.junit.Assert.assertNull(attribute3);
    }
}
