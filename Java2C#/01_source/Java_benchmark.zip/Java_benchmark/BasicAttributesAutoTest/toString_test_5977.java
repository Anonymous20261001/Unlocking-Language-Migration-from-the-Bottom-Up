package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.toString(). */
    @Test
    public void toString_test_5977() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(false);
        java.lang.String str2 = basicAttributes1.toString();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "No attributes" + "'", str2, "No attributes");
    }
}
