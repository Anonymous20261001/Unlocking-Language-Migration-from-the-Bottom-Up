package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.size(). */
    @Test
    public void size_test_5972() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes2 = new javax.naming.directory.BasicAttributes("hi!", (java.lang.Object) "{=: No attributes}");
        int int3 = basicAttributes2.size();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }
}
