package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.getAll(). */
    @Test
    public void getAll_test_5980() throws Throwable {
        java.lang.Object obj1 = null;
        javax.naming.directory.BasicAttributes basicAttributes2 = new javax.naming.directory.BasicAttributes("{=: 0}", obj1);
        javax.naming.NamingEnumeration<javax.naming.directory.Attribute> attributeNamingEnumeration3 = basicAttributes2.getAll();
        org.junit.Assert.assertNotNull(attributeNamingEnumeration3);
    }
}
