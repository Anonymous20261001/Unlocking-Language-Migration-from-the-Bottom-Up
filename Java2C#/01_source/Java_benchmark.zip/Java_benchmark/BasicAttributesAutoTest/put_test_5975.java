package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.put(). */
    @Test
    public void put_test_5975() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes0 = new javax.naming.directory.BasicAttributes();
        javax.naming.directory.Attribute attribute3 = null;
        // The following exception was thrown during execution in test generation
        try {
            javax.naming.directory.Attribute attribute4 = basicAttributes0.put(attribute3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.naming.directory.Attribute.getID()\" because \"attr\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
