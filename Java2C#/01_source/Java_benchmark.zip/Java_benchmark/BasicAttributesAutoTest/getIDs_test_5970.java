package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.getIDs(). */
    @Test
    public void getIDs_test_5970() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes0 = new javax.naming.directory.BasicAttributes();
        javax.naming.NamingEnumeration<java.lang.String> strNamingEnumeration1 = basicAttributes0.getIDs();
        org.junit.Assert.assertNotNull(strNamingEnumeration1);
    }
}
