package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.put(). */
    @Test
    public void put_test_5974() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(false);
        javax.naming.directory.Attribute attribute4 = basicAttributes1.put("", (java.lang.Object) (-1));
        org.junit.Assert.assertNull(attribute4);
    }
}
