package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.isCaseIgnored(). */
    @Test
    public void isCaseIgnored_test_5969() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes2 = new javax.naming.directory.BasicAttributes("", (java.lang.Object) 'a');
        boolean boolean3 = basicAttributes2.isCaseIgnored();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
