package generated.test;

import org.junit.Test;

public class BasicAttributesAutoTest {

    /** Randoop-generated regression test for javax.naming.directory.BasicAttributes.clone(). */
    @Test
    public void clone_test_5979() throws Throwable {
        javax.naming.directory.BasicAttributes basicAttributes1 = new javax.naming.directory.BasicAttributes(true);
        java.lang.Object obj2 = basicAttributes1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "No attributes");
    }
}
