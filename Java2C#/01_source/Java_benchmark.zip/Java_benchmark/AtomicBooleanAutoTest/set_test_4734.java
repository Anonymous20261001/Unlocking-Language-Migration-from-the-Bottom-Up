package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.set(). */
    @Test
    public void set_test_4734() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean0 = new java.util.concurrent.atomic.AtomicBoolean();
        atomicBoolean0.set(true);
    }
}
