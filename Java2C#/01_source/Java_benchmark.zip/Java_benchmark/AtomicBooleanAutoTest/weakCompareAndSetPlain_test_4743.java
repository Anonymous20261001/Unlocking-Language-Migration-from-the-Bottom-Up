package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.weakCompareAndSetPlain(). */
    @Test
    public void weakCompareAndSetPlain_test_4743() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean1 = new java.util.concurrent.atomic.AtomicBoolean(true);
        boolean boolean4 = atomicBoolean1.weakCompareAndSetPlain(true, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}
