package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.compareAndExchange(). */
    @Test
    public void compareAndExchange_test_4740() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean0 = new java.util.concurrent.atomic.AtomicBoolean();
        boolean boolean3 = atomicBoolean0.compareAndExchange(true, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
