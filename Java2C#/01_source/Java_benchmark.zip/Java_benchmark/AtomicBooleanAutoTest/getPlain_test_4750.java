package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.getPlain(). */
    @Test
    public void getPlain_test_4750() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean1 = new java.util.concurrent.atomic.AtomicBoolean(true);
        boolean boolean2 = atomicBoolean1.getPlain();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
