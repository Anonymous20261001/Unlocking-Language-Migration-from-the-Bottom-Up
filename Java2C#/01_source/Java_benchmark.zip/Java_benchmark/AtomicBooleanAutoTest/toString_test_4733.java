package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.toString(). */
    @Test
    public void toString_test_4733() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean0 = new java.util.concurrent.atomic.AtomicBoolean();
        java.lang.String str1 = atomicBoolean0.toString();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "false" + "'", str1, "false");
    }
}
