package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.setOpaque(). */
    @Test
    public void setOpaque_test_4736() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean1 = new java.util.concurrent.atomic.AtomicBoolean(true);
        atomicBoolean1.setOpaque(false);
    }
}
