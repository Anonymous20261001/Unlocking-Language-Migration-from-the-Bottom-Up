package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.weakCompareAndSetVolatile(). */
    @Test
    public void weakCompareAndSetVolatile_test_4748() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean1 = new java.util.concurrent.atomic.AtomicBoolean(false);
        boolean boolean4 = atomicBoolean1.weakCompareAndSetVolatile(true, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
