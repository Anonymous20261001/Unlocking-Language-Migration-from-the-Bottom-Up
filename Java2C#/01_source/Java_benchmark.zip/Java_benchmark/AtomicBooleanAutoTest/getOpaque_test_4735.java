package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.getOpaque(). */
    @Test
    public void getOpaque_test_4735() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean0 = new java.util.concurrent.atomic.AtomicBoolean();
        boolean boolean2 = atomicBoolean0.getOpaque();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}
