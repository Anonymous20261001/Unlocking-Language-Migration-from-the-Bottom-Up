package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.get(). */
    @Test
    public void get_test_4732() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean0 = new java.util.concurrent.atomic.AtomicBoolean();
        boolean boolean1 = atomicBoolean0.get();
        boolean boolean2 = atomicBoolean0.get();
        boolean boolean3 = atomicBoolean0.get();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
