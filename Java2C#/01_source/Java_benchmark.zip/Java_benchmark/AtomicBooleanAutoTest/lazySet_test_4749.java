package generated.test;

import org.junit.Test;

public class AtomicBooleanAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicBoolean.lazySet(). */
    @Test
    public void lazySet_test_4749() throws Throwable {
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean1 = new java.util.concurrent.atomic.AtomicBoolean(false);
        atomicBoolean1.lazySet(true);
    }
}
