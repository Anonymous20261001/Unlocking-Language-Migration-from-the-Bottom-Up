package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.iterator(). */
    @Test
    public void iterator_test_3286() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue1 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>((int) (short) 0);
        java.util.Iterator<java.lang.constant.ConstantDesc> constantDescItor4 = constantDescQueue1.iterator();
        org.junit.Assert.assertNotNull(constantDescItor4);
    }
}
