package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.removeFirstOccurrence(). */
    @Test
    public void removeFirstOccurrence_test_3310() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue1 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>((int) (short) 0);
        boolean boolean3 = constantDescQueue1.removeFirstOccurrence((java.lang.Object) "[100]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
