package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.addFirst(). */
    @Test
    public void addFirst_test_3296() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue0 = new java.util.ArrayDeque<java.lang.String>();
        strQueue0.addFirst("[]");
    }
}
