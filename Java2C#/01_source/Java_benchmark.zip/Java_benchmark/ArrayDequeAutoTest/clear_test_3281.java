package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.clear(). */
    @Test
    public void clear_test_3281() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        strQueue1.clear();
    }
}
