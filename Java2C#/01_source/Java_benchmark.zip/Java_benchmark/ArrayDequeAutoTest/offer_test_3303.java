package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.offer(). */
    @Test
    public void offer_test_3303() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>(1);
        boolean boolean3 = strQueue1.offer("hi!");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}
