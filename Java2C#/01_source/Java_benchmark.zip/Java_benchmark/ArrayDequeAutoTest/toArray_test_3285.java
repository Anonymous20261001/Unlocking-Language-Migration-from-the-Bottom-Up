package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.toArray(). */
    @Test
    public void toArray_test_3285() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue0 = new java.util.ArrayDeque<java.lang.String>();
        java.lang.Object[] objArray1 = strQueue0.toArray();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertArrayEquals(objArray1, new java.lang.Object[] {});
    }
}
