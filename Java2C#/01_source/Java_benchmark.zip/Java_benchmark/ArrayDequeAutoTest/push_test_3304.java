package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.push(). */
    @Test
    public void push_test_3304() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        strQueue1.push("");
    }
}
