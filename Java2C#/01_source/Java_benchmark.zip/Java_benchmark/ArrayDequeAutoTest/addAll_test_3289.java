package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.addAll(). */
    @Test
    public void addAll_test_3289() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue0 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>();
        java.util.Collection<java.lang.constant.ConstantDesc> constantDescCollection3 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = constantDescQueue0.addAll(constantDescCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.Collection.size()\" because \"c\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
