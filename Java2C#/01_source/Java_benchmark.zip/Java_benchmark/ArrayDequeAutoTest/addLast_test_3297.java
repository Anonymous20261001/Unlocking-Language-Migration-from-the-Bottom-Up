package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.addLast(). */
    @Test
    public void addLast_test_3297() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue1 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>((int) (short) 0);
        constantDescQueue1.addLast((java.lang.constant.ConstantDesc) 100L);
    }
}
