package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.spliterator(). */
    @Test
    public void spliterator_test_3288() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        java.util.Spliterator<java.lang.String> strSpliterator4 = strQueue1.spliterator();
        org.junit.Assert.assertNotNull(strSpliterator4);
    }
}
