package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.removeLastOccurrence(). */
    @Test
    public void removeLastOccurrence_test_3313() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>(0);
        java.lang.Object obj2 = null;
        boolean boolean3 = strQueue1.removeLastOccurrence(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
