package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.toArray(). */
    @Test
    public void toArray_test_3284() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue0 = new java.util.ArrayDeque<java.lang.String>();
        java.lang.String[] strArray3 = new java.lang.String[] { "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray4 = strQueue0.toArray((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strComparableArray4);
        org.junit.Assert.assertArrayEquals(strComparableArray4, new java.lang.String[] { null });
    }
}
