package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.size(). */
    @Test
    public void size_test_3279() throws Throwable {
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.util.ArrayDeque<java.lang.String> strQueue2 = new java.util.ArrayDeque<java.lang.String>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strQueue2, strArray1);
        int int4 = strQueue2.size();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertArrayEquals(strArray1, new java.lang.String[] { "hi!" });
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }
}
