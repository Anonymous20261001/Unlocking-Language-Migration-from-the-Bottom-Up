package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.removeFirst(). */
    @Test
    public void removeFirst_test_3298() throws Throwable {
        java.lang.String[] strArray1 = new java.lang.String[] { "" };
        java.util.ArrayDeque<java.lang.String> strQueue2 = new java.util.ArrayDeque<java.lang.String>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strQueue2, strArray1);
        java.lang.String str4 = strQueue2.removeFirst();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertArrayEquals(strArray1, new java.lang.String[] { "" });
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
    }
}
