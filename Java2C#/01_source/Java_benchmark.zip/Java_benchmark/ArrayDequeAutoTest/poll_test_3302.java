package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.poll(). */
    @Test
    public void poll_test_3302() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) '#');
        java.lang.String str2 = strQueue1.poll();
        org.junit.Assert.assertNull(str2);
    }
}
