package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.peek(). */
    @Test
    public void peek_test_3291() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        java.lang.String str2 = strQueue1.peek();
        org.junit.Assert.assertNull(str2);
    }
}
