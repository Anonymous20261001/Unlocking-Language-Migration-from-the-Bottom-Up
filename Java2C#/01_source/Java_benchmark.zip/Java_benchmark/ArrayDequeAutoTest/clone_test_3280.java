package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.clone(). */
    @Test
    public void clone_test_3280() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue0 = new java.util.ArrayDeque<java.lang.String>();
        strQueue0.addFirst("[]");
        java.util.ArrayDeque<java.lang.String> strQueue3 = strQueue0.clone();
        org.junit.Assert.assertNotNull(strQueue3);
    }
}
