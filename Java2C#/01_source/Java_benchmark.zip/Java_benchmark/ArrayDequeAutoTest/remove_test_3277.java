package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.remove(). */
    @Test
    public void remove_test_3277() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = strQueue1.remove();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
            // Expected exception.
        }
    }
}
