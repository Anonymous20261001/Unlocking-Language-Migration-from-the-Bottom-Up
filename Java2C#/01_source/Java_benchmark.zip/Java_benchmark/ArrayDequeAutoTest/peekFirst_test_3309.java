package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.peekFirst(). */
    @Test
    public void peekFirst_test_3309() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        java.lang.String str3 = strQueue1.peekFirst();
        org.junit.Assert.assertNull(str3);
    }
}
