package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.descendingIterator(). */
    @Test
    public void descendingIterator_test_3314() throws Throwable {
        java.util.ArrayDeque<java.lang.String> strQueue1 = new java.util.ArrayDeque<java.lang.String>((int) 'a');
        java.util.Iterator<java.lang.String> strItor4 = strQueue1.descendingIterator();
        org.junit.Assert.assertNotNull(strItor4);
    }
}
