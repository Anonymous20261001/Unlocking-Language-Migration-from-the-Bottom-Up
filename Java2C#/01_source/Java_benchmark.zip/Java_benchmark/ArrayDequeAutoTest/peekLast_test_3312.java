package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.peekLast(). */
    @Test
    public void peekLast_test_3312() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue1 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>((int) (short) 0);
        java.lang.constant.ConstantDesc constantDesc4 = constantDescQueue1.peekLast();
        org.junit.Assert.assertNull(constantDesc4);
    }
}
