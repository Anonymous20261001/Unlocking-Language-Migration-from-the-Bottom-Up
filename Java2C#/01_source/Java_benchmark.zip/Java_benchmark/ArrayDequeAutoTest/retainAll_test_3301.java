package generated.test;

import org.junit.Test;

public class ArrayDequeAutoTest {

    /** Randoop-generated regression test for java.util.ArrayDeque.retainAll(). */
    @Test
    public void retainAll_test_3301() throws Throwable {
        java.util.ArrayDeque<java.lang.constant.ConstantDesc> constantDescQueue0 = new java.util.ArrayDeque<java.lang.constant.ConstantDesc>();
        java.util.Collection<java.lang.constant.ConstantDesc> constantDescCollection2 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean3 = constantDescQueue0.retainAll(constantDescCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
