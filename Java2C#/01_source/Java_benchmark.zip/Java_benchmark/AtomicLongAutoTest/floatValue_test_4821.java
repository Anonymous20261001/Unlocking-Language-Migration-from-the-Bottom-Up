package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.floatValue(). */
    @Test
    public void floatValue_test_4821() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong0 = new java.util.concurrent.atomic.AtomicLong();
        float float1 = atomicLong0.floatValue();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }
}
