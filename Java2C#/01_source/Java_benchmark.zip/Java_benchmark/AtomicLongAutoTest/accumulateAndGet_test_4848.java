package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.accumulateAndGet(). */
    @Test
    public void accumulateAndGet_test_4848() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong0 = new java.util.concurrent.atomic.AtomicLong();
        java.util.function.LongBinaryOperator longBinaryOperator2 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long3 = atomicLong0.accumulateAndGet((long) '#', longBinaryOperator2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.LongBinaryOperator.applyAsLong(long, long)\" because \"accumulatorFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
