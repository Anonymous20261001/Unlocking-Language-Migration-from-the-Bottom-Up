package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.longValue(). */
    @Test
    public void longValue_test_4820() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong0 = new java.util.concurrent.atomic.AtomicLong();
        long long2 = atomicLong0.getAndAdd(2L);
        long long3 = atomicLong0.longValue();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }
}
