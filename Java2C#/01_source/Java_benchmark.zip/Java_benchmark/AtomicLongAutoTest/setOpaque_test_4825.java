package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.setOpaque(). */
    @Test
    public void setOpaque_test_4825() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong0 = new java.util.concurrent.atomic.AtomicLong();
        atomicLong0.setOpaque(100L);
    }
}
