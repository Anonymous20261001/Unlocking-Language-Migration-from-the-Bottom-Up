package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.toString(). */
    @Test
    public void toString_test_4818() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong0 = new java.util.concurrent.atomic.AtomicLong();
        java.lang.String str1 = atomicLong0.toString();
        java.lang.String str2 = atomicLong0.toString();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "0" + "'", str1, "0");
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "0" + "'", str2, "0");
    }
}
