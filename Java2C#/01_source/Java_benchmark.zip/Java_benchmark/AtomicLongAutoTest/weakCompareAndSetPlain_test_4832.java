package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.weakCompareAndSetPlain(). */
    @Test
    public void weakCompareAndSetPlain_test_4832() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong1 = new java.util.concurrent.atomic.AtomicLong((long) (short) 1);
        boolean boolean4 = atomicLong1.weakCompareAndSetPlain((long) (byte) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
