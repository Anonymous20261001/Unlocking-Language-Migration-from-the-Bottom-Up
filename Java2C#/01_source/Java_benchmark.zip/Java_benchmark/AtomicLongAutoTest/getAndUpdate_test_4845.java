package generated.test;

import org.junit.Test;

public class AtomicLongAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicLong.getAndUpdate(). */
    @Test
    public void getAndUpdate_test_4845() throws Throwable {
        java.util.concurrent.atomic.AtomicLong atomicLong1 = new java.util.concurrent.atomic.AtomicLong((long) (short) 1);
        java.util.function.LongUnaryOperator longUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long4 = atomicLong1.getAndUpdate(longUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.util.function.LongUnaryOperator.applyAsLong(long)\" because \"updateFunction\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
