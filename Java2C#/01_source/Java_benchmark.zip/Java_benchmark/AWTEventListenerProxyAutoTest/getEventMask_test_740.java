package generated.test;

import org.junit.Test;

public class AWTEventListenerProxyAutoTest {

    /** Randoop-generated regression test for java.awt.event.AWTEventListenerProxy.getEventMask(). */
    @Test
    public void getEventMask_test_740() throws Throwable {
        java.awt.event.AWTEventListener aWTEventListener1 = null;
        java.awt.event.AWTEventListenerProxy aWTEventListenerProxy2 = new java.awt.event.AWTEventListenerProxy(0L, aWTEventListener1);
        long long3 = aWTEventListenerProxy2.getEventMask();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }
}
