package generated.test;

import org.junit.Test;

public class AWTEventListenerProxyAutoTest {

    /** Randoop-generated regression test for java.awt.event.AWTEventListenerProxy.eventDispatched(). */
    @Test
    public void eventDispatched_test_739() throws Throwable {
        java.awt.event.AWTEventListener aWTEventListener1 = null;
        java.awt.event.AWTEventListenerProxy aWTEventListenerProxy2 = new java.awt.event.AWTEventListenerProxy(0L, aWTEventListener1);
        java.awt.AWTEvent aWTEvent3 = null;
        // The following exception was thrown during execution in test generation
        try {
            aWTEventListenerProxy2.eventDispatched(aWTEvent3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.event.AWTEventListener.eventDispatched(java.awt.AWTEvent)\" because the return value of \"java.awt.event.AWTEventListenerProxy.getListener()\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
