package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.getAndUpdate(). */
    @Test
    public void getAndUpdate_test_4811() throws Throwable {
        int[] intArray0 = new int[] {};
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray(intArray0);
        java.util.function.IntUnaryOperator intUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int4 = atomicIntegerArray1.getAndUpdate((int) (short) 0, intUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 0 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
