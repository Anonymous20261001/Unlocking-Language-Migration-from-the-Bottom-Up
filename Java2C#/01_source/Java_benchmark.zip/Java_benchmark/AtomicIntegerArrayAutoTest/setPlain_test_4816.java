package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.setPlain(). */
    @Test
    public void setPlain_test_4816() throws Throwable {
        int[] intArray0 = new int[] {};
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray(intArray0);
        // The following exception was thrown during execution in test generation
        try {
            atomicIntegerArray1.setPlain((int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 100 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
