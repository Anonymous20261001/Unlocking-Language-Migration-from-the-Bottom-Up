package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.updateAndGet(). */
    @Test
    public void updateAndGet_test_4812() throws Throwable {
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray(100);
        java.util.function.IntUnaryOperator intUnaryOperator3 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int4 = atomicIntegerArray1.updateAndGet(100, intUnaryOperator3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 100 out of bounds for length 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
