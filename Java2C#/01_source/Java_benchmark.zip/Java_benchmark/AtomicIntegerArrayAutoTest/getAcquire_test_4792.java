package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.getAcquire(). */
    @Test
    public void getAcquire_test_4792() throws Throwable {
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray((int) 'a');
        int int3 = atomicIntegerArray1.getAcquire(35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}
