package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.length(). */
    @Test
    public void length_test_4787() throws Throwable {
        int[] intArray0 = new int[] {};
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray(intArray0);
        int int2 = atomicIntegerArray1.length();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}
