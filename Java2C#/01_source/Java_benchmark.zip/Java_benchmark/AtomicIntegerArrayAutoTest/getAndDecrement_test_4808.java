package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.getAndDecrement(). */
    @Test
    public void getAndDecrement_test_4808() throws Throwable {
        int[] intArray0 = new int[] {};
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray2 = new java.util.concurrent.atomic.AtomicIntegerArray(intArray0);
        // The following exception was thrown during execution in test generation
        try {
            int int4 = atomicIntegerArray2.getAndDecrement((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Index 100 out of bounds for length 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            // Expected exception.
        }
    }
}
