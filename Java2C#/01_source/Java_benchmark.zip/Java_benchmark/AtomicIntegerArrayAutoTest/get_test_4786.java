package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.get(). */
    @Test
    public void get_test_4786() throws Throwable {
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray1 = new java.util.concurrent.atomic.AtomicIntegerArray((int) 'a');
        int int3 = atomicIntegerArray1.get((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}
