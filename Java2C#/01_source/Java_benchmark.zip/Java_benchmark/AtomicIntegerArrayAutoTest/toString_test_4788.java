package generated.test;

import org.junit.Test;

public class AtomicIntegerArrayAutoTest {

    /** Randoop-generated regression test for java.util.concurrent.atomic.AtomicIntegerArray.toString(). */
    @Test
    public void toString_test_4788() throws Throwable {
        int[] intArray0 = new int[] {};
        java.util.concurrent.atomic.AtomicIntegerArray atomicIntegerArray3 = new java.util.concurrent.atomic.AtomicIntegerArray(intArray0);
        java.lang.String str4 = atomicIntegerArray3.toString();
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
    }
}
