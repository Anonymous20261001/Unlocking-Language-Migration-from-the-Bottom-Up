package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.mouseReleased(). */
    @Test
    public void mouseReleased_test_8634() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        java.awt.event.MouseEvent mouseEvent2 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonListener1.mouseReleased(mouseEvent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.event.MouseEvent.getID()\" because \"anEvent\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
