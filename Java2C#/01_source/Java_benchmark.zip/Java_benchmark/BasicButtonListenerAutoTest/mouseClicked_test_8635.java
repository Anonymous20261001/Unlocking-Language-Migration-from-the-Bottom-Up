package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.mouseClicked(). */
    @Test
    public void mouseClicked_test_8635() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        java.awt.event.MouseEvent mouseEvent2 = null;
        basicButtonListener1.mouseClicked(mouseEvent2);
    }
}
