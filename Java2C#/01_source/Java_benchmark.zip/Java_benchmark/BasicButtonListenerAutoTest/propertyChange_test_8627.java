package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.propertyChange(). */
    @Test
    public void propertyChange_test_8627() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        java.beans.PropertyChangeEvent propertyChangeEvent2 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonListener1.propertyChange(propertyChangeEvent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.beans.PropertyChangeEvent.getPropertyName()\" because \"e\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
