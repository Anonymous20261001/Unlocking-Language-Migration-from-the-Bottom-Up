package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.uninstallKeyboardActions(). */
    @Test
    public void uninstallKeyboardActions_test_8630() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        javax.swing.JComponent jComponent2 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonListener1.uninstallKeyboardActions(jComponent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.JComponent.getInputMap(int, boolean)\" because \"component\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
