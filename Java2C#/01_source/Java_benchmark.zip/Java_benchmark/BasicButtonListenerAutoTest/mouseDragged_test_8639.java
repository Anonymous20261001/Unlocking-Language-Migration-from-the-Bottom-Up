package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.mouseDragged(). */
    @Test
    public void mouseDragged_test_8639() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        java.awt.event.MouseEvent mouseEvent2 = null;
        basicButtonListener1.mouseDragged(mouseEvent2);
    }
}
