package generated.test;

import org.junit.Test;

public class BasicButtonListenerAutoTest {

    /** Randoop-generated regression test for javax.swing.plaf.basic.BasicButtonListener.installKeyboardActions(). */
    @Test
    public void installKeyboardActions_test_8629() throws Throwable {
        javax.swing.AbstractButton abstractButton0 = null;
        javax.swing.plaf.basic.BasicButtonListener basicButtonListener1 = new javax.swing.plaf.basic.BasicButtonListener(abstractButton0);
        javax.swing.JComponent jComponent2 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicButtonListener1.installKeyboardActions(jComponent2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"javax.swing.AbstractButton.getMnemonic()\" because \"b\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
