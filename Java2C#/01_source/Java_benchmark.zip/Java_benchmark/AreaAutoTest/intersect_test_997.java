package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.intersect(). */
    @Test
    public void intersect_test_997() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Area area2 = new java.awt.geom.Area();
        area0.intersect(area2);
    }
}
