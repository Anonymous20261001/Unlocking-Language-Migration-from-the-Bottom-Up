package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.exclusiveOr(). */
    @Test
    public void exclusiveOr_test_975() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Area area2 = new java.awt.geom.Area();
        area0.exclusiveOr(area2);
    }
}
