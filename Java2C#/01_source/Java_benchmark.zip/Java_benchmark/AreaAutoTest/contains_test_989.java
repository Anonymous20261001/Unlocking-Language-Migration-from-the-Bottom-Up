package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.contains(). */
    @Test
    public void contains_test_989() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        boolean boolean3 = area0.contains((double) (short) 1, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}
