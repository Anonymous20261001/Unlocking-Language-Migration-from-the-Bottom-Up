package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.isRectangular(). */
    @Test
    public void isRectangular_test_977() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Area area1 = new java.awt.geom.Area((java.awt.Shape) area0);
        boolean boolean3 = area1.isRectangular();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}
