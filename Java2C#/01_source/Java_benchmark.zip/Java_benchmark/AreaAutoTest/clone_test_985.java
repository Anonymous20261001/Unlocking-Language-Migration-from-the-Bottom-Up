package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.clone(). */
    @Test
    public void clone_test_985() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.lang.Object obj1 = area0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }
}
