package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.isSingular(). */
    @Test
    public void isSingular_test_978() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Area area1 = new java.awt.geom.Area((java.awt.Shape) area0);
        boolean boolean2 = area1.isSingular();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
