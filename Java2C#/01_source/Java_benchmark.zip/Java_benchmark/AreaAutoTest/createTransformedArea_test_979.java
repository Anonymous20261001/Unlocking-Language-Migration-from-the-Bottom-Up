package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.createTransformedArea(). */
    @Test
    public void createTransformedArea_test_979() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.AffineTransform affineTransform3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.awt.geom.Area area4 = area0.createTransformedArea(affineTransform3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: transform must not be null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
