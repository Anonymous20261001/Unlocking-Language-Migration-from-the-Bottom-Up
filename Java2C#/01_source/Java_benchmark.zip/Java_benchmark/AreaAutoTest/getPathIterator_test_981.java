package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.getPathIterator(). */
    @Test
    public void getPathIterator_test_981() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.AffineTransform affineTransform1 = null;
        java.awt.geom.PathIterator pathIterator3 = area0.getPathIterator(affineTransform1, (double) ' ');
        org.junit.Assert.assertNotNull(pathIterator3);
    }
}
