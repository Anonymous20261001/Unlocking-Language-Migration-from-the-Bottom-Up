package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.getBounds(). */
    @Test
    public void getBounds_test_993() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.Rectangle rectangle2 = area0.getBounds();
        org.junit.Assert.assertNotNull(rectangle2);
    }
}
