package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.add(). */
    @Test
    public void add_test_987() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Area area1 = new java.awt.geom.Area();
        area0.add(area1);
    }
}
