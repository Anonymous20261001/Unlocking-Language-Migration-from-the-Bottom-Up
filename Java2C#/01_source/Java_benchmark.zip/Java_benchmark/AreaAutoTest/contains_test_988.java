package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.contains(). */
    @Test
    public void contains_test_988() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Point2D point2D2 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean3 = area0.contains(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.geom.Point2D.getX()\" because \"p\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
