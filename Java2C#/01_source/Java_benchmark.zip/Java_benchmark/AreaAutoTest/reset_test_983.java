package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.reset(). */
    @Test
    public void reset_test_983() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        area0.reset();
    }
}
