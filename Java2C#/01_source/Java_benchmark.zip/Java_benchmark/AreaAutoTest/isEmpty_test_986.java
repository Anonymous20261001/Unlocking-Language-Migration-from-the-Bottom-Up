package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.isEmpty(). */
    @Test
    public void isEmpty_test_986() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        boolean boolean1 = area0.isEmpty();
        boolean boolean2 = area0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}
