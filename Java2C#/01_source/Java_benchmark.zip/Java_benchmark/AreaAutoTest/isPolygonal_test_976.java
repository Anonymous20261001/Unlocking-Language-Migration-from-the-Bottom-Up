package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.isPolygonal(). */
    @Test
    public void isPolygonal_test_976() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        boolean boolean1 = area0.isPolygonal();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}
