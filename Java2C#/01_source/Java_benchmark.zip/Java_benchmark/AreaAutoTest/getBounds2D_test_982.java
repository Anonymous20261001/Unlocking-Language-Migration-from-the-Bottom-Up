package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.getBounds2D(). */
    @Test
    public void getBounds2D_test_982() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Rectangle2D rectangle2D3 = area0.getBounds2D();
        org.junit.Assert.assertNotNull(rectangle2D3);
    }
}
