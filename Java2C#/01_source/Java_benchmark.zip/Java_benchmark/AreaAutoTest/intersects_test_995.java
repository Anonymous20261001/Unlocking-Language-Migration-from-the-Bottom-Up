package generated.test;

import org.junit.Test;

public class AreaAutoTest {

    /** Randoop-generated regression test for java.awt.geom.Area.intersects(). */
    @Test
    public void intersects_test_995() throws Throwable {
        java.awt.geom.Area area0 = new java.awt.geom.Area();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = area0.intersects(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot invoke \"java.awt.geom.Rectangle2D.getX()\" because \"r\" is null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
    }
}
