package generated.test;

import org.junit.Test;

public class AttributeAutoTest {

    /** Randoop-generated regression test for javax.management.Attribute.equals(). */
    @Test
    public void equals_test_5519() throws Throwable {
        javax.management.Attribute attribute2 = new javax.management.Attribute("hi!", (java.lang.Object) 0.0d);
        boolean boolean4 = attribute2.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}
