package generated.test;

import org.junit.Test;

public class AttributeAutoTest {

    /** Randoop-generated regression test for javax.management.Attribute.getValue(). */
    @Test
    public void getValue_test_5522() throws Throwable {
        java.lang.Object obj1 = new java.lang.Object();
        java.lang.Class<?> wildcardClass2 = obj1.getClass();
        javax.management.Attribute attribute3 = new javax.management.Attribute(" = a", (java.lang.Object) wildcardClass2);
        java.lang.Object obj4 = attribute3.getValue();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals(obj4.toString(), "class java.lang.Object");
    }
}
