package generated.test;

import org.junit.Test;

public class AttributeAutoTest {

    /** Randoop-generated regression test for javax.management.Attribute.toString(). */
    @Test
    public void toString_test_5520() throws Throwable {
        javax.management.Attribute attribute2 = new javax.management.Attribute("", (java.lang.Object) 'a');
        java.lang.String str3 = attribute2.toString();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + " = a" + "'", str3, " = a");
    }
}
