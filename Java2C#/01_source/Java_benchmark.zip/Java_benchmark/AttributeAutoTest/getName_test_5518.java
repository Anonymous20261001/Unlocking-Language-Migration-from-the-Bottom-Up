package generated.test;

import org.junit.Test;

public class AttributeAutoTest {

    /** Randoop-generated regression test for javax.management.Attribute.getName(). */
    @Test
    public void getName_test_5518() throws Throwable {
        javax.management.Attribute attribute2 = new javax.management.Attribute("", (java.lang.Object) 'a');
        java.lang.String str3 = attribute2.getName();
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "" + "'", str3, "");
    }
}
